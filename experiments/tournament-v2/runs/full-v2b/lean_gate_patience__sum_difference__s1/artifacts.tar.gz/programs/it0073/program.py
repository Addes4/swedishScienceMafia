# EVOLVE-BLOCK-START
"""Constructive multi-cluster builder + greedy polish.

Idea: A is a union of g clusters, each cluster being a short arithmetic progression
(with common difference d, drawn from a pool). Intra-cluster sums and differences
collide heavily -> few sums. Clusters are placed at offsets resembling a Golomb
ruler / Sidon-ish spread so that cross-cluster differences spread widely -> many
differences. Then we greedily add/remove/adjust elements to improve the score.
"""
import math
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
        for j in range(n):
            diffs.add(ai - a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    """Score with counts; used in tight polish loops."""
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(g, clen, d, offsets, start):
    """Union of g arithmetic progressions: {start+off + k*d : k=0..clen-1}."""
    A = []
    for o in offsets:
        base = start + o
        for k in range(clen):
            A.append(base + k * d)
    return sorted(set(A))


def _offsets_greedy(g, step, jitter=0):
    """Golomb-ruler-like offsets: start at 0, greedily pick next offset far from
    all existing pairwise differences to spread cross-cluster diffs."""
    offs = [0]
    while len(offs) < g:
        best_o = None
        best_v = -1
        for o in range(offs[-1] + step, offs[-1] + step + jitter + 1):
            diffs = set()
            for x in offs:
                for y in offs:
                    diffs.add(x - y)
            bad = 0
            for x in offs:
                if abs(o - x) in diffs:
                    bad += 1
            cand_v = len(set(abs(o - x) for x in offs)) - bad
            if cand_v > best_v:
                best_v = cand_v
                best_o = o
        offs.append(best_o if best_o is not None else offs[-1] + step)
    return offs


def solve():
    """Multi-cluster constructive builder + greedy polish."""
    deadline = time.time() + 110

    # Candidate base configurations
    best = None
    best_score = -1.0

    # Grid-ish search over parameters (kept small for time).
    configs = []
    for g in (4, 5, 6, 7, 8):
        for clen in (2, 3, 4, 5, 6):
            for d in (1, 2, 3, 4):
                configs.append((g, clen, d))

    for (g, clen, d) in configs:
        if time.time() > deadline - 20:
            break
        # simple Sidon-ish offsets: 0, 1, 3, 7, 12, 20, 30, 44, ...
        offs = []
        cur_off = 0
        step = 1
        for i in range(g):
            offs.append(cur_off)
            cur_off += step
            step += 1
        start = 0
        cand = _build(g, clen, d, offs, start)
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    # also try scaled offsets
    for (g, clen, d) in [(5, 4, 1), (6, 3, 1), (5, 5, 1), (7, 3, 1), (4, 6, 1),
                         (6, 4, 1), (5, 6, 1), (8, 3, 1), (6, 5, 1), (7, 4, 1),
                         (5, 8, 1), (4, 10, 1), (6, 6, 1), (8, 4, 1)]:
        if time.time() > deadline - 20:
            break
        offs = []
        cur_off = 0
        step = clen + d
        for i in range(g):
            offs.append(cur_off)
            cur_off += step
            step += 1
        cand = _build(g, clen, d, offs, 0)
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    if best is None:
        best = [0, 1, 3]

    # Greedy polish: add/remove/adjust elements.
    A = sorted(set(best))
    cur_score = _score_fast(A)

    # Greedy "add best element" pass
    def try_local(A, value_pool, rounds, deadline):
        A = sorted(set(A))
        cur = _score_fast(A)
        for _ in range(rounds):
            if time.time() > deadline:
                break
            improved = False
            # try adding
            span = (max(A) - min(A)) if len(A) >= 2 else 1
            lo = min(A) - span
            hi = max(A) + span
            best_add = None
            best_add_s = cur
            for v in value_pool:
                if v in A:
                    continue
                cand = sorted(A + [v])
                s = _score_fast(cand)
                if s > best_add_s:
                    best_add_s = s
                    best_add = v
            if best_add is not None:
                A = sorted(A + [best_add])
                cur = best_add_s
                improved = True
            # try removing
            if len(A) > 3:
                best_rm = None
                best_rm_s = cur
                for i in range(len(A)):
                    cand = A[:i] + A[i + 1:]
                    s = _score_fast(cand)
                    if s > best_rm_s:
                        best_rm_s = s
                        best_rm = i
                if best_rm is not None:
                    A = A[:best_rm] + A[best_rm + 1:]
                    cur = best_rm_s
                    improved = True
            if not improved:
                break
        return A, cur

    # Build a pool of candidate values around the span.
    span = max(A) - min(A)
    pool = []
    base = min(A)
    for v in range(base - span, base + 2 * span + 1):
        pool.append(v)

    A, cur_score = try_local(A, pool, 60, deadline - 1)
    A, cur_score = try_local(A, pool, 60, deadline - 0.5)

    # Final greedy removal of useless elements
    changed = True
    while changed and time.time() < deadline - 0.2:
        changed = False
        for i in range(len(A)):
            if len(A) <= 3:
                break
            cand = A[:i] + A[i + 1:]
            s = _score_fast(cand)
            if s >= cur_score:
                A = cand
                cur_score = s
                changed = True
                break

    A = sorted(set(A))
    return A
# EVOLVE-BLOCK-END
