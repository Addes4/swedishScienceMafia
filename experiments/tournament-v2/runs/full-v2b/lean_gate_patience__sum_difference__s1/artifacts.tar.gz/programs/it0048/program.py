# EVOLVE-BLOCK-START
"""Two-block family + fast incremental-multiplicity local search.

Idea: A = X  U  (M + {0..k-1})
  - The interval block {0..k-1} is very "additive": its sums cover only 2k-1 values.
  - Cross sums X + interval are also additive-ish.
  - Differences of the interval span a contiguous range of length ~k.
  - A Sidon-like base X contributes many distinct differences.

We maintain dicts cntD[v], cntS[v] of multiplicities so that adding/removing/moving
one element can be evaluated in O(n) time by only touching pairs with that element.
This allows a high-throughput local search maximizing
    log|A-A|/log|A+A| + (1 - 1/|A|)/100.
"""
import math
import random
import time


def _build_base(nbase):
    """Greedy Sidon-like base: all pairwise sums (and hence many differences) distinct."""
    B = [0]
    sums = {0}
    while len(B) < nbase:
        cand = B[-1] + 1
        while True:
            ok = True
            for b in B:
                if cand + b in sums:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        for b in B:
            sums.add(cand + b)
        sums.add(cand + cand)
        B.append(cand)
    return B


class State:
    __slots__ = ("A", "cntD", "cntS", "d", "s", "nd", "ns", "score")

    def __init__(self, A):
        self.A = sorted(A)
        self.cntD = {}
        self.cntS = {}
        for x in self.A:
            for y in self.A:
                self.cntD[x - y] = self.cntD.get(x - y, 0) + 1
                self.cntS[x + y] = self.cntS.get(x + y, 0) + 1
        self.d = len(self.cntD)
        self.s = len(self.cntS)
        self.nd = self.s
        self.ns = self.s
        self.score = self._sc()

    def _sc(self):
        n = len(self.A)
        if n < 2 or self.s <= 1:
            return -1.0
        return math.log(self.d) / math.log(self.s) + (1.0 - 1.0 / n) / 100.0

    def _add_delta(self, v):
        """Return (delta_d, delta_s) if we add value v (not in A)."""
        dd = 0
        dsd = 0
        for x in self.A:
            k = self.cntD.get(v - x, 0)
            if k == 0:
                dd += 1
            k = self.cntD.get(x - v, 0)
            if k == 0:
                dd += 1
            # v-v self difference is new too (only once)
        # self difference v - v
        if self.cntD.get(0, 0) == 0:
            dd += 1
        for x in self.A:
            k = self.cntS.get(v + x, 0)
            if k == 0:
                dsd += 1
        if self.cntS.get(2 * v, 0) == 0:
            dsd += 1
        return dd, dsd

    def add(self, v):
        if v in self.A:
            return False
        dd, dsd = self._add_delta(v)
        for x in self.A:
            self.cntD[v - x] = self.cntD.get(v - x, 0) + 1
            self.cntD[x - v] = self.cntD.get(x - v, 0) + 1
            self.cntS[v + x] = self.cntS.get(v + x, 0) + 1
        self.cntD[0] = self.cntD.get(0, 0) + 1
        self.cntS[2 * v] = self.cntS.get(2 * v, 0) + 1
        self.d += dd
        self.s += dsd
        self.A.append(v)
        self.A.sort()
        self.score = self._sc()
        return True

    def remove_at(self, idx):
        v = self.A[idx]
        dd = 0
        dsd = 0
        for x in self.A:
            k = self.cntD.get(v - x, 0)
            if k == 1:
                dd += 1
            k = self.cntD.get(x - v, 0)
            if k == 1:
                dd += 1
        if self.cntD.get(0, 0) == 1:
            dd += 1
        for x in self.A:
            k = self.cntS.get(v + x, 0)
            if k == 1:
                dsd += 1
        if self.cntS.get(2 * v, 0) == 1:
            dsd += 1
        for x in self.A:
            for key in (v - x, x - v):
                c = self.cntD[key] - 1
                if c == 0:
                    del self.cntD[key]
                else:
                    self.cntD[key] = c
            key = v + x
            c = self.cntS[key] - 1
            if c == 0:
                del self.cntS[key]
            else:
                self.cntS[key] = c
        key = 0
        c = self.cntD[key] - 1
        if c == 0:
            del self.cntD[key]
        else:
            self.cntD[key] = c
        key = 2 * v
        c = self.cntS[key] - 1
        if c == 0:
            del self.cntS[key]
        else:
            self.cntS[key] = c
        self.d -= dd
        self.s -= dsd
        del self.A[idx]
        self.score = self._sc()
        return v


def _search(A, deadline, rng):
    st = State(A)
    best = st.A[:]
    bscore = st.score
    it = 0
    while time.time() < deadline:
        it += 1
        r = rng.random()
        n = len(st.A)
        if n < 2:
            break
        if r < 0.5 and n < 4000:
            # add near an existing element
            base = st.A[rng.randrange(n)]
            v = base + rng.randint(-6, 6)
            if v not in st.A:
                prev_score = st.score
                st.add(v)
                if st.score >= prev_score:
                    if st.score > bscore:
                        best, bscore = st.A[:], st.score
                else:
                    st.remove_at(st.A.index(v))
        elif r < 0.75:
            # move a random element
            i = rng.randrange(n)
            v = st.A[i]
            nv = v + rng.choice([-3, -2, -1, 1, 2, 3])
            if nv not in st.A:
                prev_score = st.score
                st.remove_at(i)
                st.add(nv)
                if st.score < prev_score:
                    # revert
                    i2 = st.A.index(nv)
                    st.remove_at(i2)
                    st.add(v)
                elif st.score > bscore:
                    best, bscore = st.A[:], st.score
        else:
            if n > 6:
                i = rng.randrange(n)
                prev_score = st.score
                v = st.remove_at(i)
                if st.score >= prev_score:
                    if st.score > bscore:
                        best, bscore = st.A[:], st.score
                else:
                    st.add(v)
    return best, bscore


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = len({x - y for x in a for y in a})
    sums = len({x + y for x in a for y in a})
    return math.log(diffs) / math.log(sums) + (1.0 - 1.0 / n) / 100.0


def solve():
    t_end = time.time() + 115
    rng = random.Random(12345)

    best = [7, 15, 18, 22, -3, -2]
    bscore = _score(best)

    # construct two-block family: X (Sidon-ish base) U (M + {0..k-1})
    configs = []
    for nbase in (6, 8, 10, 12, 16, 20):
        for k in (10, 20, 30, 40, 60, 80, 120, 160):
            configs.append((nbase, k))
    for (nbase, k) in configs:
        X = _build_base(nbase)
        span = X[-1] if X else 1
        M = span + k + 3
        A = list(X) + [M + i for i in range(k)]
        s = _score(A)
        if s > bscore:
            best, bscore = A, s

    # local search within remaining time
    best_ls, bs = _search(best, t_end, rng)
    if bs > bscore:
        best, bscore = best_ls, bs

    return sorted(set(best))
# EVOLVE-BLOCK-END
