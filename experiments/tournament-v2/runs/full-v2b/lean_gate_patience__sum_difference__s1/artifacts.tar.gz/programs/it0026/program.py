# EVOLVE-BLOCK-START
"""Grid construction A = X + M*Y with a fast unique-count scorer and M sweep."""
import math
import random
import time
import numpy as np


def _score_from_arr(arr):
    n = arr.size
    if n < 2:
        return 0.0
    d = arr[:, None] - arr[None, :]
    s = arr[:, None] + arr[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _fast_score(arr):
    """Unique counts via sorted concatenation without huge intermediate copies beyond needed."""
    n = arr.size
    if n < 2:
        return 0.0
    # differences: use broadcasting in chunks to limit memory, but small n usually fine
    d = (arr[:, None] - arr[None, :]).ravel()
    nd = np.unique(d).size
    s = (arr[:, None] + arr[None, :]).ravel()
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _golomb(n, span):
    marks = [0]
    used = {0}
    cand = 1
    while len(marks) < n and cand <= span:
        ok = True
        for m in marks:
            if abs(cand - m) in used:
                ok = False
                break
        if ok:
            for m in marks:
                used.add(abs(cand - m))
            marks.append(cand)
        cand += 1
    return marks


def _make_grid(X, Y, M):
    a = np.array([x + M * y for y in Y for x in X], dtype=np.int64)
    return np.unique(a)


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    gol_cache = {}

    def gol(n, span):
        key = (n, span)
        if key not in gol_cache:
            gol_cache[key] = _golomb(n, span)
        return gol_cache[key]

    # Phase 1: coarse grid search.
    for nX in range(2, 60):
        if time.time() > deadline:
            break
        X = gol(nX, 30 * nX)
        if len(X) != nX:
            continue
        for nY in range(2, 20):
            Yint = list(range(nY))
            Ygol = gol(nY, 20 * nY)
            for Y in (Ygol, Yint):
                if len(Y) < 2:
                    continue
                for M in (30, 60, 120, 300, 700, 1500, 4000, 10000, 30000):
                    if time.time() > deadline:
                        break
                    arr = _make_grid(X, Y, M)
                    if arr.size < 2:
                        continue
                    sc = _fast_score(arr)
                    if sc > best_score:
                        best_score = sc
                        best = arr.copy()

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)
        best_score = _fast_score(best)

    # Phase 2: fine M sweep around the best.
    bx = int(np.min(best))
    span = int(np.max(best)) - bx
    base = best - bx
    # try to recover structure: assume best is X + M0*Y.
    # Rather than guess, just try scaling the whole set by various factors and shifting.
    for k in range(2, 60):
        if time.time() > deadline:
            break
        cand = (base * k).astype(np.int64)
        cand = np.unique(cand)
        if cand.size < 2:
            continue
        sc = _fast_score(cand)
        if sc > best_score:
            best_score = sc
            best = cand.copy()

    # Phase 3: local search with single-element moves.
    cur = best.copy()
    cur_score = best_score
    it = 0
    max_delta = max(2, int(np.max(np.abs(cur))) // 20 + 2)
    while time.time() < deadline and it < 20000:
        it += 1
        cand = cur.copy()
        k = random.randint(1, max(1, len(cand) // 20))
        idx = np.random.randint(0, len(cand), size=k)
        cand[idx] += np.random.randint(-max_delta, max_delta + 1, size=k).astype(np.int64)
        cand = np.unique(cand)
        if cand.size < 2:
            continue
        sc = _fast_score(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand.copy(), sc

    return sorted(int(v) for v in np.unique(best))
# EVOLVE-BLOCK-END
