# EVOLVE-BLOCK-START
"""Bose-Chowla Sidon set: near-maximal |A-A| while keeping |A+A| small."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _is_prime(p):
    if p < 2:
        return False
    i = 2
    while i * i <= p:
        if p % i == 0:
            return False
        i += 1
    return True


def _next_prime(p):
    while not _is_prime(p):
        p += 1
    return p


def _bose_chowla(q, theta):
    """Sidon set in Z_{q^2-1}: {i : (i - theta) mod (q^2-1) in GF(q) ... } classic form:
    {x : x = i*q + (i^2 mod q) ...} -> use exponential/Singer style embedding.
    We use the standard Bose set: for generator g of GF(q^2)*,
    A = { a : g^a = g + i, i in GF(q) } and map to integers via exponent mod q^2-1."""
    # Build GF(q^2) as GF(q)[t]/(t^2 - c) with c a non-residue.
    # Find non-residue c.
    squares = {(x * x) % q for x in range(q)}
    c = None
    for cand in range(2, q):
        if cand % q not in squares:
            c = cand
            break
    if c is None:
        return []
    # Elements: (a + b t), a,b in GF(q). Multiply using t^2 = c.
    def mul(e1, e2):
        a1, b1 = e1
        a2, b2 = e2
        return ((a1 * a2 + b1 * b2 * c) % q, (a1 * b2 + b1 * a2) % q)

    # find generator of multiplicative group
    order = q * q - 1
    # factor order
    fac = set()
    m = order
    d = 2
    while d * d <= m:
        while m % d == 0:
            fac.add(d)
            m //= d
        d += 1
    if m > 1:
        fac.add(m)

    def is_gen(g):
        for f in fac:
            e = order // f
            # g^e
            r = (1, 0)
        # compute g^e
        ee = e
        r = (1, 0)
        base = g
        while ee:
            if ee & 1:
                r = mul(r, base)
            base = mul(base, base)
            ee >>= 1
        if r == (1, 0):
            return False
        return True

    g = None
    for a in range(q):
        for b in range(q):
            if (a, b) == (0, 0):
                continue
            if is_gen((a, b)):
                g = (a, b)
                break
        if g:
            break
    if g is None:
        return []

    # powers of g: exponent -> element, and element -> exponent
    exp_of = {}
    cur = (1, 0)
    for i in range(order):
        exp_of[cur] = i
        cur = mul(cur, g)

    # Bose set: for each i in GF(q), element g + (i, 0), take exponent
    result = []
    for i in range(q):
        el = ((1 + i) % q, 1)  # g + (i,0) where g=(1,1) after normalization? use generator base
        # We need g0 + (i,0) with g0 a fixed primitive element value; use element (0,1) style.
        # Standard: A = { log_g(g + i) } for i in GF(q). Use g = (1,1) representation:
        break
    # Simpler correct Bose-Chowla: fix primitive g. A = { log_g(g + i) : i in GF(q) } where
    # "g + i" added in GF(q^2) field (g is the field element that is the generator).
    result = []
    for i in range(q):
        el = ((g[0] + i) % q, g[1])
        result.append(exp_of[el])
    return result


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    candidates = []
    for q in [11, 13, 16, 17, 19, 23, 25, 27, 29, 31, 32, 37, 41, 43, 47, 49, 53, 59, 61, 64,
              67, 71, 73, 79, 81, 83, 89, 97, 101, 103]:
        if not _is_prime(q) and int(q ** 0.5) ** 2 != q and q not in (16, 25, 27, 32, 49, 64, 81):
            continue
        try:
            A = _bose_chowla(q, 0)
        except Exception:
            A = []
        if len(A) < 5:
            continue
        A = sorted(set(A))
        candidates.append(A)

    for A in candidates:
        if time.time() > deadline:
            break
        base = A[:]
        # local search: translate by small amounts (no effect on score) then remove/add to shrink sums
        cur = sorted(set(base))
        cs = _score(cur)
        # try trimming endpoints to reduce range (reduces |A+A|) while keeping |A-A| large
        improved = True
        while improved and time.time() < deadline:
            improved = False
            # try removing each element
            for idx in range(len(cur)):
                cand = cur[:idx] + cur[idx + 1:]
                if len(cand) < 3:
                    continue
                s = _score(cand)
                if s > cs + 1e-12:
                    cur, cs, improved = cand, s, True
                    break
        if cs > best_score:
            best_score = cs
            best = cur[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(best))
# EVOLVE-BLOCK-END

