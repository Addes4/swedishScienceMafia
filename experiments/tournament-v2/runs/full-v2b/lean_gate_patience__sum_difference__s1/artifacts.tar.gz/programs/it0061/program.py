# EVOLVE-BLOCK-START
"""Two translated APs (heavy sum collisions) + Sidon-ish gap block; exact incremental search."""
import math
import time
import random

try:
    import numpy as np
except Exception:
    np = None


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _fast_score(a):
    """Exact numpy set-based score."""
    n = len(a)
    if n < 2:
        return 0.0
    arr = np.array(a, dtype=np.int64)
    diffs = arr[:, None] - arr[None, :]
    sums = arr[:, None] + arr[None, :]
    nd = np.unique(diffs).size
    ns = np.unique(sums).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _golomb_base(r):
    """Greedy Sidon-ish base with distinct differences."""
    marks = [0]
    used = {0}
    while len(marks) < r:
        best = None
        for cand in range(marks[-1] + 1, marks[-1] + 500):
            ok = True
            add = []
            for m in marks:
                d = cand - m
                if d in used or d in add or -d in used:
                    ok = False
                    break
                add.append(d)
            if ok:
                for d in add:
                    used.add(d)
                    used.add(-d)
                best = cand
                break
        if best is None:
            best = marks[-1] + 1
            for m in marks:
                used.add(best - m)
                used.add(m - best)
        marks.append(best)
    return marks


def solve():
    deadline = time.time() + 108
    best = None
    best_score = -1.0

    # Seed family: A = {0..L-1} ∪ (Q + {0..L-1})  -> two APs, many sum collisions.
    # Optionally add a small Sidon block far away to boost distinct differences.
    sidon = _golomb_base(6)

    candidates = []
    for L in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 30, 40, 50, 64, 80, 100):
        for Q in (L, L + 1, L + 2, 2 * L, 2 * L + 1, 3 * L, 5 * L):
            a = list(range(L)) + [Q + i for i in range(L)]
            candidates.append(a)
            # add a Sidon gap far away
            gap = Q + L + 3
            b = a + [gap + s for s in sidon]
            candidates.append(b)

    random.shuffle(candidates)

    for a in candidates:
        if time.time() > deadline - 30:
            break
        a = list(set(a))
        if len(a) < 2:
            continue
        s = _fast_score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    if best is None:
        best = list(range(8)) + [16 + i for i in range(8)]
        best_score = _fast_score(best)

    # Hill-climb: try extending the long AP, shifting offsets, adding/removing elements.
    a = best[:]
    bs = best_score
    while time.time() < deadline:
        improved = False
        n = len(a)

        # try appending the next element of the second AP (extend cluster)
        tried = 0
        for _ in range(40):
            v = random.randint(min(a) - 5, max(a) + 5)
            if v in a:
                continue
            cand = a + [v]
            s = _fast_score(cand)
            tried += 1
            if s > bs:
                bs = s
                a = cand
                improved = True
                break
        if improved:
            continue

        # try removing each element (prefer non-core)
        if n > 4:
            idxs = list(range(n))
            random.shuffle(idxs)
            for i in idxs[:30]:
                cand = a[:i] + a[i + 1:]
                s = _fast_score(cand)
                if s > bs:
                    bs = s
                    a = cand
                    improved = True
                    break
        if improved:
            continue

        # try shifting a single element by a small delta
        span = max(a) - min(a) if a else 1
        for _ in range(60):
            i = random.randrange(n)
            delta = random.randint(-max(1, span // 50), max(1, span // 50))
            cand = a[:]
            cand[i] = cand[i] + delta
            if len(set(cand)) != len(cand):
                continue
            s = _fast_score(cand)
            if s > bs:
                bs = s
                a = cand
                improved = True
                break
        if not improved:
            break

    if bs > best_score:
        best_score = bs
        best = a[:]

    return sorted(set(best))


if __name__ == "__main__":
    a = solve()
    a = list(set(a))
    if len(a) > 4000:
        a = a[:4000]
    print(len(a), _score(a))
# EVOLVE-BLOCK-END
