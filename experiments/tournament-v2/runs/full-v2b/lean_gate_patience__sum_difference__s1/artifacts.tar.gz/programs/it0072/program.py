# EVOLVE-BLOCK-START
"""Search for A with large difference set and small sum set.

Key structure exploited: the two-interval family
    A = {0,1,...,L-1}  u  {Q, Q+1, ..., Q+L-1}
has |A+A| growing only like ~ (a small multiple of L + a few) intervals
while |A-A| collects the wide ~2L-long range from the cross differences.
This gives a large log|A-A|/log|A+A|.  We score candidates exactly with
numpy (fast enough for the modest sizes involved), sweep (L, Q), and then
run a focused random local search that perturbs L, Q, and individual
elements, keeping the best.
"""
import math
import time
import numpy as np


def _score(a):
    n = len(a)
    if n < 2:
        return -1.0, 1, 1
    a = np.asarray(a, dtype=np.int64)
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    ns = int(sums.size)
    nd = int(diffs.size)
    if ns < 2:
        return -1.0, nd, ns
    return math.log(nd) / math.log(ns), nd, ns


def _two_interval(L, Q):
    a = np.concatenate([np.arange(L, dtype=np.int64),
                        Q + np.arange(L, dtype=np.int64)])
    return np.unique(a)


def solve():
    t_end = time.time() + 116.0
    rng = np.random.default_rng(1234567)

    best = None
    best_sc = -1.0

    def consider(arr, sc=None):
        nonlocal best, best_sc
        arr = np.unique(np.asarray(arr, dtype=np.int64))
        if arr.size < 2:
            return
        if sc is None:
            sc, _, _ = _score(arr)
        if sc > best_sc:
            best_sc = sc
            best = arr.copy()

    # ---- structured seed sweep over the two-interval family ----------
    for L in range(2, 260):
        if time.time() > t_end:
            break
        # Q around a few times L gives wide differences but compressed sums
        for mult in (2, 3, 4, 5, 6, 8, 10, 13, 16, 20, 25, 32, 40, 50,
                     64, 80, 100, 128, 160, 200, 256, 320, 400, 512):
            if time.time() > t_end:
                break
            Q = mult * L
            if Q > 10 ** 15:
                break
            a = _two_interval(L, Q)
            s, _, _ = _score(a)
            consider(a, s)

    # also some other structured seeds
    consider(np.arange(0, 40, dtype=np.int64))
    consider(np.array([1 << i for i in range(14)], dtype=np.int64))

    # ---- focused random local search ---------------------------------
    n_list = [16, 20, 25, 32, 40, 50, 64, 80, 100, 128, 160, 200, 256]
    idx = 0
    while time.time() < t_end:
        n = n_list[idx % len(n_list)]
        idx += 1
        rmax = int(8 * n * n)

        # half the time start from the best-known two-interval style seed
        if rng.random() < 0.5 and best is not None:
            a = best.copy()
        else:
            L = max(2, n // 2)
            Q = int(L * rng.integers(2, max(3, n)))
            Q = min(Q, rmax)
            a = _two_interval(L, Q)

        cur, _, _ = _score(a)
        local_best = a.copy()
        local_best_sc = cur
        T = 0.25
        b_step = max(1, n // 4)
        it = 0
        while time.time() < t_end:
            it += 1
            if (it & 255) == 0 and time.time() > t_end:
                break
            m = len(a)
            r = rng.random()
            if r < 0.90:
                i = int(rng.integers(m))
                if rng.random() < 0.5:
                    v = int(a[i]) + int(rng.integers(-b_step, b_step + 1))
                else:
                    v = int(rng.integers(0, rmax + 1))
                v = max(0, min(rmax, v))
                if v == int(a[i]):
                    continue
                b = a.copy()
                b[i] = v
                b = np.unique(b)
            elif r < 0.96:
                if m >= 4000:
                    continue
                v = int(rng.integers(0, rmax + 1))
                b = np.unique(np.append(a, v))
            else:
                if m <= 4:
                    continue
                i = int(rng.integers(m))
                b = np.delete(a, i)

            if b.size < 2:
                continue
            s, _, _ = _score(b)
            if s > cur or rng.random() < math.exp((s - cur) / max(T, 1e-9)):
                a = b
                cur = s
                if s > local_best_sc:
                    local_best_sc = s
                    local_best = b.copy()
                    if s > best_sc:
                        best_sc = s
                        best = b.copy()

            T *= 0.99985
            if T < 1e-4:
                T = 0.12

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)

    best = np.unique(best.astype(np.int64))
    if best.size > 4000:
        best = best[:4000]
    lo = -10 ** 15
    hi = 10 ** 15
    out = [int(max(lo, min(hi, int(x)))) for x in best]
    return out
# EVOLVE-BLOCK-END
