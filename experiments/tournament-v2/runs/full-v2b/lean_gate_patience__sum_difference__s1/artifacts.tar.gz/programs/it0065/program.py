# EVOLVE-BLOCK-START
"""Constructive multi-cluster family with exact numpy scoring.

Idea: A = union over clusters of (offset_c + {0..L-1}).  Intra-cluster sums
all land in [2*offset_c, 2*offset_c+2L-2], so the sum set stays small if
clusters share structure; differences between clusters spread widely.

We search over cluster counts g, block length L, and offsets chosen greedily
to maximize the log-ratio, then polish by add/remove.
"""
import math
import time
import numpy as np


def _score_parts(a):
    a = np.asarray(sorted(set(int(x) for x in a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    nd, ns = diffs.size, sums.size
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def _score(a):
    return _score_parts(a)[0]


def _build(g, L, offsets):
    a = []
    for off in offsets:
        for k in range(L):
            a.append(off + k)
    return a


def _greedy_offsets(g, L, base_gap, deadline):
    """Greedily choose g cluster offsets to maximise objective."""
    offsets = [0]
    cur = _build(1, L, offsets)
    csc = _score(cur)[0]
    while len(offsets) < g:
        if time.time() > deadline:
            break
        best_add = None
        best_s = csc
        # candidate next offset: base_gap from current max region
        cand_offsets = []
        top = max(offsets) + L
        for mult in (1, 2, 3, 4, 5):
            cand_offsets.append(top + mult * base_gap)
        for off in cand_offsets:
            trial = offsets + [off]
            s = _score(_build(len(trial), L, trial))[0]
            if s > best_s:
                best_s = s
                best_add = off
        if best_add is None:
            break
        offsets.append(best_add)
        csc = best_s
    return offsets, csc


def _polish(a, deadline):
    cur = sorted(set(int(x) for x in a))
    sc = _score(cur)[0]
    improved = True
    while improved:
        improved = False
        if time.time() > deadline:
            break
        n = len(cur)
        lo, hi = cur[0], cur[-1]
        # try adding just outside range
        for nx in (hi + 1, lo - 1, hi + 2, lo - 2, hi + 3, lo - 3):
            if nx in cur:
                continue
            cand = cur + [nx]
            s = _score(cand)[0]
            if s > sc:
                cur = sorted(set(cand))
                sc = s
                improved = True
                break
        if improved:
            continue
        # try removing an extreme
        for x in (lo, hi):
            if len(cur) <= 3:
                break
            cand = [y for y in cur if y != x]
            s = _score(cand)[0]
            if s > sc:
                cur = cand
                sc = s
                improved = True
                break
        if improved:
            continue
        # try shifting an element into a gap
        for idx in range(n):
            if time.time() > deadline:
                break
            x = cur[idx]
            for dx in (1, -1, 2, -2, 3, -3):
                nx = x + dx
                if nx in cur:
                    continue
                cand = cur[:idx] + cur[idx + 1:] + [nx]
                s = _score(cand)[0]
                if s > sc:
                    cur = sorted(set(cand))
                    sc = s
                    improved = True
                    break
            if improved:
                break
    return cur, sc


def solve():
    t_end = time.time() + 110.0
    best = None
    best_sc = -1.0

    # Seed the two-interval family explicitly (g=2), then multi-cluster.
    configs = []
    for L in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 32):
        for Q in (2 * L, 3 * L, 4 * L, 6 * L, 8 * L, 12 * L, 20 * L, 40 * L):
            configs.append((L, Q))
    for (L, Q) in configs:
        if time.time() > t_end - 60:
            break
        a = _build(2, L, [0, Q])
        s = _score(a)[0]
        if s > best_sc:
            best_sc = s
            best = list(a)

    # Multi-cluster greedy builds.
    for g in (2, 3, 4, 5, 6):
        for L in (2, 3, 4, 5, 6, 8):
            if time.time() > t_end - 25:
                break
            for base_gap in (2 * L, 3 * L, 5 * L, 8 * L, 13 * L):
                if time.time() > t_end - 25:
                    break
                offsets, sc = _greedy_offsets(
                    g, L, base_gap, t_end - 20)
                a = _build(len(offsets), L, offsets)
                if sc > best_sc:
                    best_sc = sc
                    best = list(a)

    # Polish the best candidate.
    if best is not None:
        rem = t_end - time.time()
        if rem > 1:
            cand, sc = _polish(best, t_end - 0.5)
            if sc > best_sc:
                best_sc = sc
                best = cand

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    best = [max(-10**15, min(10**15, x)) for x in best]
    return best
# EVOLVE-BLOCK-END
