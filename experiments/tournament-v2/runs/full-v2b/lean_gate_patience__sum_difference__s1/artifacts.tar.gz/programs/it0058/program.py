# EVOLVE-BLOCK-START
"""Efficient incremental multiplicity hill-climber over multi-cluster AP seeds."""
import math
import time
import random


def _counts(a):
    """Return difference multiplicity dict and sum multiplicity dict (as dicts value->count)."""
    n = len(a)
    d = {}
    for i in range(n):
        ai = a[i]
        for j in range(n):
            v = ai - a[j]
            d[v] = d.get(v, 0) + 1
    s = {}
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            v = ai + a[j]
            s[v] = s.get(v, 0) + 1
    return d, s


def _score_from_counts(d, s, n):
    if n < 2 or len(s) == 0:
        return -1.0
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / n) / 100


def _diff_update(d, a, idx, old, new):
    """Update difference counts when a[idx] changes old->new. Returns nothing (mutates d)."""
    n = len(a)
    # account for element at idx vs all others (and itself)
    for j in range(n):
        if j == idx:
            continue
        # old differences: a[idx]-a[j] removed, a[j]-a[idx] removed
        v1 = old - a[j]
        d[v1] -= 1
        if d[v1] == 0:
            del d[v1]
        v2 = a[j] - old
        d[v2] -= 1
        if d[v2] == 0:
            del d[v2]
        # new differences
        v3 = new - a[j]
        d[v3] = d.get(v3, 0) + 1
        v4 = a[j] - new
        d[v4] = d.get(v4, 0) + 1


def _sum_update(s, a, idx, old, new):
    n = len(a)
    for j in range(n):
        if j == idx:
            # self pair old+old and new+new
            v = old + old
            s[v] -= 1
            if s[v] == 0:
                del s[v]
            v2 = new + new
            s[v2] = s.get(v2, 0) + 1
        else:
            v = old + a[j]
            s[v] -= 1
            if s[v] == 0:
                del s[v]
            v2 = new + a[j]
            s[v2] = s.get(v2, 0) + 1


def _golomb(r):
    marks = [0]
    used = {0}
    while len(marks) < r:
        cand = marks[-1] + 1
        while True:
            ok = True
            for m in marks:
                if cand - m in used:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        for m in marks:
            used.add(cand - m)
        marks.append(cand)
    return marks


def _hillclimb(a, deadline):
    a = list(set(a))
    a.sort()
    n = len(a)
    if n < 2:
        return a
    d, s = _counts(a)
    best = a[:]
    bs = _score_from_counts(d, s, n)

    while time.time() < deadline:
        improved = False
        n = len(a)
        lo, hi = a[0], a[-1]

        # Relocate each element to a few candidate positions
        for i in range(min(n, 200)):
            old = a[i]
            span = hi - lo if hi > lo else 1
            cands = set()
            # a few interesting spots: next to existing elements, near gaps
            for j in range(max(0, i - 3), min(n, i + 4)):
                if j != i:
                    cands.add(a[j] + 1)
                    cands.add(a[j] - 1)
            cands.add(old + 1)
            cands.add(old - 1)
            cands.add(lo - 1)
            cands.add(hi + 1)
            for delta in (span // (n + 1), -(span // (n + 1))):
                if delta != 0:
                    cands.add(old + delta)
            for new in cands:
                if new == old or new in a:
                    continue
                _diff_update(d, a, i, old, new)
                _sum_update(s, a, i, old, new)
                sc = _score_from_counts(d, s, n)
                if sc > bs:
                    bs = sc
                    a[i] = new
                    best = a[:]
                    improved = True
                    break
                else:
                    # revert
                    _diff_update(d, a, i, new, old)
                    _sum_update(s, a, i, new, old)
            if improved:
                break
        if improved:
            continue

        # Try adding an element
        for _ in range(60):
            v = random.randint(lo - 2, hi + 2)
            if v in a:
                continue
            # tentative
            for m in a:
                d[v - m] = d.get(v - m, 0) + 1
                d[m - v] = d.get(m - v, 0) + 1
            for m in a:
                s[v + m] = s.get(v + m, 0) + 1
            s[v + v] = s.get(v + v, 0) + 1
            n2 = n + 1
            sc = _score_from_counts(d, s, n2)
            if sc > bs:
                bs = sc
                a.append(v)
                a.sort()
                best = a[:]
                improved = True
                break
            else:
                for m in a:
                    d[v - m] -= 1
                    if d[v - m] == 0:
                        del d[v - m]
                    d[m - v] -= 1
                    if d[m - v] == 0:
                        del d[m - v]
                for m in a:
                    s[v + m] -= 1
                    if s[v + m] == 0:
                        del s[v + m]
                s[v + v] -= 1
                if s[v + v] == 0:
                    del s[v + v]
        if improved:
            continue

        # Try removing an element
        if n > 8:
            for i in range(n):
                old = a[i]
                _diff_update(d, a, i, old, old)
                # removing: subtract contributions of old
                for j in range(n):
                    if j == i:
                        continue
                    d[old - a[j]] -= 1
                    if d[old - a[j]] == 0:
                        del d[old - a[j]]
                    d[a[j] - old] -= 1
                    if d[a[j] - old] == 0:
                        del d[a[j] - old]
                for j in range(n):
                    if j == i:
                        continue
                    s[old + a[j]] -= 1
                    if s[old + a[j]] == 0:
                        del s[old + a[j]]
                s[old + old] -= 1
                if s[old + old] == 0:
                    del s[old + old]
                n2 = n - 1
                sc = _score_from_counts(d, s, n2)
                if sc > bs:
                    bs = sc
                    a.pop(i)
                    best = a[:]
                    improved = True
                    break
                else:
                    # restore
                    for j in range(n):
                        if j == i:
                            continue
                        d[old - a[j]] = d.get(old - a[j], 0) + 1
                        d[a[j] - old] = d.get(a[j] - old, 0) + 1
                    for j in range(n):
                        if j == i:
                            continue
                        s[old + a[j]] = s.get(old + a[j], 0) + 1
                    s[old + old] = s.get(old + old, 0) + 1

        if not improved:
            break
    return best


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Phase 1: build multi-cluster AP seeds and evaluate cheaply.
    seeds = []
    for g in (2, 3, 4, 5, 6, 8, 10, 12, 16):
        for L in (2, 3, 4, 5, 6, 8, 10, 12):
            for step in (1, 2, 3, 5, 7):
                offsets = _golomb(g)
                a = []
                for o in offsets:
                    for k in range(L):
                        a.append(o * step + k * step)
                a = sorted(set(a))
                if len(a) >= 2:
                    seeds.append(a)

    # also two-interval family
    for L in (4, 6, 8, 10, 12, 16, 20, 24, 30):
        for q in (L, 2 * L, 3 * L, 4 * L):
            a = list(range(L)) + [q + k for k in range(L)]
            seeds.append(sorted(set(a)))

    random.shuffle(seeds)

    for seed in seeds:
        if time.time() > deadline - 30:
            break
        d, s = _counts(seed)
        sc = _score_from_counts(d, s, len(seed))
        if sc > best_score:
            best_score = sc
            best = seed[:]

    if best is None:
        best = list(range(20))

    # Phase 2: hill climb from best seed with full budget.
    best = _hillclimb(best, deadline)
    _, _, _ = None, None, None
    return sorted(set(best))


if __name__ == "__main__":
    a = solve()
    a = list(set(a))
    if len(a) > 4000:
        a = a[:4000]
    print(len(a), a[:5], "...")
# EVOLVE-BLOCK-END
