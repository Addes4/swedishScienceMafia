# EVOLVE-BLOCK-START
"""Constructive builder targeting large |A-A| and small |A+A|.

Family: A = B ∪ (q + [0, M)) where B is a Sidon/B_h-like base set with many
distinct internal differences, and [0, M) is a dense interval. The dense
interval makes internal sums collapse to ~2M values (2M-1 sums), while its
internal differences fill an interval of length M. Placing the two blocks far
apart (large q) makes cross-differences cover a long interval, boosting
|A-A| strongly. We sweep (B, M, q) and polish.
"""
import math
import random
import time


def _eval(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    s = math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0
    return s, len(diffs), len(sums)


def _sidon(k, limit=10**15):
    """Greedy Sidon-like set of size k: all pairwise sums (and differences) distinct."""
    S = [0]
    used_sums = {0}
    used_diffs = {0}
    c = 1
    while len(S) < k:
        ok = True
        for x in S:
            if (c + x) in used_sums or (c - x) in used_diffs or (x - c) in used_diffs:
                ok = False
                break
        if ok:
            for x in S:
                used_sums.add(c + x)
                used_diffs.add(c - x)
                used_diffs.add(x - c)
            used_sums.add(2 * c)
            used_diffs.add(0)
            S.append(c)
        c += 1
        if c > 10**7:
            break
    return S


def _build(B, M, q):
    A = list(B)
    for i in range(M):
        A.append(q + i)
    return A


def _greedy_polish(best, deadline):
    best = sorted(set(best))
    bscore, _, _ = _eval(best)
    if bscore < 0:
        return best
    cur = best[:]
    cscore = bscore
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.5 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2, 3, -3])
        elif r < 0.8:
            base = random.choice(cand)
            cand.append(base + random.randint(-4, 4))
        else:
            if len(cand) > 4:
                del cand[random.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s, _, _ = _eval(cand)
        if s >= cscore:
            cur, cscore = cand, s
            if s > bscore:
                best, bscore = cand[:], s
    return best


def solve():
    t_end = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    bscore, _, _ = _eval(best)

    # Sweep the structured family.
    for k in range(3, 12):
        B = _sidon(k)
        for M in [4, 6, 8, 10, 12, 15, 20, 25, 30, 40, 50, 70, 100, 150,
                  200, 300, 500, 800, 1500, 3000]:
            if k + M > 4000:
                continue
            span_B = max(B) - min(B)
            for mult in [1, 2, 3, 4, 6, 8]:
                q = (span_B + M) * mult + M + span_B
                for extra in [0, 1, 2, 3, M]:
                    A = _build(B, M, q + extra)
                    if len(A) > 4000 or max(abs(x) for x in A) > 10**15:
                        continue
                    s, _, _ = _eval(A)
                    if s > bscore:
                        best, bscore = A[:], s

    best = _greedy_polish(best, t_end - 20)
    if time.time() < t_end:
        best = _greedy_polish(best, t_end)
    return sorted(set(best))
# EVOLVE-BLOCK-END
