# EVOLVE-BLOCK-START
"""Difference-dominant set builder using a fast incremental scorer with
greedy growth, plus a product family A = {x + M*y} sweep.

Goal: maximize log|A-A| / log|A+A|.

Strategy
--------
1. Fast exact incremental scorer keeping difference and sum multiplicity sets,
   enabling cheap add/remove evaluation of single elements.
2. Greedy growth: maintain a set where adding a new element yields few new sums
   but many new differences (the "coset" trick: use an interval-like structure
   so sums collide but differences spread).
3. Product family A = {x + M*y}: X a Golomb/Sidon set (distinct differences),
   Y a short interval (sums collapse). Sweep M, |X|, |Y|.
4. Pick the best across all candidates.
"""
import math
import random
import time


def _differences(a):
    s = set()
    for x in a:
        for y in a:
            s.add(x - y)
    return s


def _sums(a):
    n = len(a)
    s = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            s.add(ai + a[j])
    return s


def _score(nd, ns, n):
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _stats(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 1, 1, 0.0
    nd = len(_differences(a))
    ns = len(_sums(a))
    return nd, ns, _score(nd, ns, n)


def _golomb(n):
    """A Sidon-ish set with many distinct pairwise differences (greedy Golomb)."""
    offs = [0]
    used = {0}
    cur = 0
    while len(offs) < n:
        cur += 1
        ok = True
        nd = set()
        for o in offs:
            d = cur - o
            if d in used or d in nd:
                ok = False
                break
            nd.add(d)
        if ok:
            offs.append(cur)
            for o in offs[:-1]:
                used.add(cur - o)
                used.add(o - cur)
    return offs


def _build_product(rng, deadline):
    """A = {x + M*y : x in X, y in [0,t)}."""
    best = None
    best_sc = -1.0
    while time.time() < deadline:
        t = rng.randint(2, 8)              # interval length (Y)
        nx = rng.randint(4, 40)            # size of X
        if nx * t > 4000:
            nx = max(2, 4000 // t)
        X = _golomb(nx)
        spread = X[-1] if X else 1
        M = max(1, (spread // max(1, t - 1))) if t > 1 else spread + 1
        # try a few M values
        for Mfac in (1, 2, 3, t, t * 2, t + 1):
            Mv = max(1, M * Mfac)
            A = []
            for x in X:
                for y in range(t):
                    A.append(x + Mv * y)
            _, _, sc = _stats(A)
            if sc > best_sc:
                best_sc = sc
                best = list(A)
        if time.time() > deadline:
            break
    return best, best_sc


def _greedy_grow(seed, target, deadline):
    """Greedily add elements that maximize the ratio (few new sums, many new diffs)."""
    A = list(dict.fromkeys(seed))
    if not A:
        A = [0]
    diffs = _differences(A)
    sums = _sums(A)
    nd = len(diffs)
    ns = len(sums)
    while len(A) < target and time.time() < deadline:
        anchor = rng_anchor(A)
        best_cand = None
        best_delta = -1e18
        base_nd = nd
        base_ns = ns
        for off in range(1, 60):
            c = anchor + off
            if c in A:
                continue
            newd = 0
            for a2 in A:
                if (c - a2) not in diffs:
                    newd += 1
                if (a2 - c) not in diffs:
                    newd += 1
            news = 0
            for a2 in A:
                if (c + a2) not in sums:
                    news += 1
            if (2 * c) not in sums:
                news += 1
            # value: gain in log(nd) minus loss in log(ns)
            val = math.log(base_nd + newd) - math.log(base_nd) \
                - (math.log(base_ns + news) - math.log(base_ns))
            if val > best_delta:
                best_delta = val
                best_cand = c
        if best_cand is None:
            break
        c = best_cand
        for a2 in A:
            diffs.add(c - a2)
            diffs.add(a2 - c)
            sums.add(c + a2)
        sums.add(2 * c)
        A.append(c)
        nd = len(diffs)
        ns = len(sums)
    return A


def rng_anchor(A):
    # choose from a random-ish subset to spread growth
    return A[len(A) // 2] if len(A) > 1 else A[0]


def solve():
    start = time.time()
    deadline = start + 110.0
    rng = random.Random(987654321)

    best = None
    best_sc = -1.0

    # 1) Product family sweep.
    b, sc = _build_product(rng, start + 35.0)
    if b and sc > best_sc:
        best_sc = sc
        best = list(b)

    # 2) Greedy growth from several seeds.
    seeds = [
        [0, 1],
        [0, 1, 3],
        [0, 1, 2, 4],
        [0, 3, 6, 9],
        [0, 1, 2, 4, 8, 13],
    ]
    t_targets = (30, 60, 100, 150, 220)
    for seed in seeds:
        for t in t_targets:
            if time.time() > deadline - 10:
                break
            A = _greedy_grow(seed, t, deadline - 10)
            _, _, s = _stats(A)
            if s > best_sc:
                best_sc = s
                best = list(A)

    # 3) Light polish via product retry with varied params.
    if time.time() < deadline - 5:
        b, sc = _build_product(rng, deadline - 5)
        if b and sc > best_sc:
            best_sc = sc
            best = list(b)

    if best is None:
        best = [0, 1, 2, 4, 8]

    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    return best
# EVOLVE-BLOCK-END
