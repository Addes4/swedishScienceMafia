# EVOLVE-BLOCK-START
"""Greedy Sidon construction + span-constrained local search, optimizing the real objective."""
import math
import random
import time


def _stats(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return n, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return n, len(diffs), len(sums)


def _score(a):
    n, d, s = _stats(a)
    if n < 2 or s < 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _greedy_sidon(target_n, span, rng):
    """Greedily build a set with many distinct differences inside [0, span]."""
    A = [0]
    used_diffs = {0}
    candidates = list(range(1, span + 1))
    rng.shuffle(candidates)
    while len(A) < target_n:
        best_c = None
        best_new = -1
        for c in candidates:
            new = 0
            ok = True
            for x in A:
                if (c - x) in used_diffs or (x - c) in used_diffs:
                    ok = False
                    break
                new += 1
            if ok and new > best_new:
                best_new = new
                best_c = c
        if best_c is None:
            break
        A.append(best_c)
        for x in A[:-1]:
            used_diffs.add(best_c - x)
            used_diffs.add(x - best_c)
    return sorted(A)


def _local_search(start, deadline):
    best = sorted(set(start))
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    span = max(cur) - min(cur)
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-span // 4 - 1, span // 4 + 1)
            if cand[i] in cand[:i] + cand[i + 1:]:
                continue
        elif op < 0.85:
            cand.append(random.randint(min(cur), max(cur)))
            if len(cand) != len(set(cand)):
                continue
        else:
            if len(cand) <= 5:
                continue
            cand.pop(random.randrange(len(cand)))
        s = _score(cand)
        if s > best_score:
            best, best_score = sorted(cand), s
            cur, cur_score = cand[:], s
        elif s >= cur_score - 1e-9:
            cur, cur_score = cand[:], s
        else:
            cur, cur_score = best[:], best_score
    return best


def solve():
    deadline = time.time() + 90
    rng = random.Random(12345)
    best = None
    best_score = -1.0
    # Try several target sizes / spans during the time budget.
    configs = []
    for n in (12, 16, 20, 24, 30, 40, 60):
        for span_mult in (2, 3, 4, 6, 10):
            configs.append((n, n * n * span_mult // 2))
    rng.shuffle(configs)
    for n, span in configs:
        if time.time() > deadline - 5:
            break
        span = max(span, n)
        A = _greedy_sidon(n, span, rng)
        A = _local_search(A, min(deadline - 1, time.time() + 6))
        s = _score(A)
        if s > best_score:
            best, best_score = A, s
    # Final polish on the overall best.
    if best is not None:
        best = _local_search(best, deadline - 0.5)
    return sorted(set(best)) if best else [7, 15, 18, 22, -3, -2]
# EVOLVE-BLOCK-END
