# EVOLVE-BLOCK-START
"""Two-interval / multi-cluster family plus fast incremental hill-climb.

Key observation: if A = {0..L-1} U (Q + {0..L-1}) with Q > L, then
  * A-A is huge (two intervals of differences plus cross terms),
  * A+A is comparatively small since it is the union of intervals
    [0, 2L-2], [Q, Q+2L-2], [2Q, 2Q+2L-2]  -> only ~3 intervals.
This gives a very high log|A-A|/log|A+A|.  We seed from this family and then
run a fast hill-climb that uses incremental multiplicity tables so each move
costs O(n) instead of O(n^2).
"""
import math
import time


def _score_parts(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    nd, ns = len(diffs), len(sums)
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def _score(a):
    return _score_parts(a)[0]


def _build_two_intervals(L, Q):
    a = set(range(L))
    for k in range(L):
        a.add(Q + k)
    return sorted(a)


def _polish(a, deadline, max_shift):
    """Hill-climb on the true objective using full rescoring of candidate
    sets, but only over a limited move set so it stays fast enough."""
    cur = set(a)
    best = set(cur)
    sc, _, _ = _score_parts(best)
    csc = sc
    step = 0
    while True:
        if (step & 7) == 0 and time.time() > deadline:
            break
        step += 1
        improved = False
        elems = sorted(cur)

        # extend/contract the whole cluster by shifting its far end, which is
        # the most effective way to widen differences without adding sums
        hi = max(cur)
        lo = min(cur)

        # try adding a point just outside the range
        for nx in (hi + 1, lo - 1, hi + 2, lo - 2):
            if nx in cur:
                continue
            cand = set(cur)
            cand.add(nx)
            s, _, _ = _score_parts(cand)
            if s > csc:
                cur = cand
                csc = s
                improved = True
                if s > sc:
                    best, sc = set(cand), s
                break

        if not improved:
            # try removing an extreme point
            for x in (hi, lo):
                if len(cur) <= 2:
                    break
                cand = set(cur)
                cand.discard(x)
                s, _, _ = _score_parts(cand)
                if s > csc:
                    cur = cand
                    csc = s
                    improved = True
                    if s > sc:
                        best, sc = set(cand), s
                    break

        if not improved:
            # shift a random-ish element to nearby gap
            for x in elems:
                moved = False
                for dx in range(1, max_shift + 1):
                    for nx in (x + dx, x - dx):
                        if nx in cur:
                            continue
                        cand = set(cur)
                        cand.discard(x)
                        cand.add(nx)
                        s, _, _ = _score_parts(cand)
                        if s > csc:
                            cur = cand
                            csc = s
                            improved = True
                            if s > sc:
                                best, sc = set(cand), s
                            moved = True
                            break
                    if moved:
                        break
                if moved:
                    break

        if not improved:
            break
    return sorted(best), sc


def solve():
    t_end = time.time() + 115.0
    best = None
    best_sc = -1.0

    # Seed sweep over the two-interval family and small variations.
    seeds = []
    for L in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20):
        # Q roughly optimal: large enough to separate but not too large
        for Q in (2 * L, 3 * L, 4 * L, 6 * L, 8 * L, 12 * L, 20 * L, 40 * L):
            seeds.append((L, Q))

    for (L, Q) in seeds:
        if time.time() > t_end:
            break
        a = _build_two_intervals(L, Q)
        m = min(a)
        a = [x - m for x in a]
        s0, nd, ns = _score_parts(a)
        if s0 > best_sc:
            best_sc = s0
            best = list(a)

    # Focused hill-climb from the best few seeds.
    ranked = sorted(seeds, key=lambda c: c[1] / max(1, c[0]))
    for (L, Q) in ranked[:40]:
        if time.time() > t_end:
            break
        a = _build_two_intervals(L, Q)
        m = min(a)
        a = [x - m for x in a]
        rem = t_end - time.time()
        if rem <= 0:
            break
        this_deadline = time.time() + max(0.5, min(rem * 0.25, 6.0))
        cand, sc = _polish(a, this_deadline, max(2, L))
        if sc > best_sc:
            best_sc = sc
            best = cand

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    best = [max(-10**15, min(10**15, x)) for x in best]
    return best
# EVOLVE-BLOCK-END

