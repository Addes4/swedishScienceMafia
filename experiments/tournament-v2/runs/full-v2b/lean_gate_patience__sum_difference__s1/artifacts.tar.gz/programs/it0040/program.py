# EVOLVE-BLOCK-START
"""Sets with many differences and few sums.

The classic near-optimal shapes are "sum-poor, difference-rich" sets such as
A = X + M*{0,1,...,k-1} where X has the property that its differences are
numerous/distinct (Sidon-like or Golomb) and M is a large multiplier so that
the sum set stays inside a short interval range while differences fan out.

We do a constructive multi-start over (base set, multiplier M, length k),
then run a fast incremental-multiplicity local search that maintains exact
difference/sum multiplicity dictionaries so add/remove/shift moves are O(n)
and we can grow |A| (size bonus) while maximizing the ratio.
"""
import math
import random
import time


def _build_stats(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return {0: 1}, {0: 1}
    dd = {}
    ss = {}
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            dd[ai - aj] = dd.get(ai - aj, 0) + 1
            ss[ai + aj] = ss.get(ai + aj, 0) + 1
    return dd, ss


def _score_from_counts(nd, ns, n):
    if ns <= 1:
        ns = 2
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    if not isinstance(a, list):
        a = list(a)
    dd, ss = _build_stats(a)
    n = len(set(a))
    return len(dd), len(ss), _score_from_counts(len(dd), len(ss), n)


class State:
    """Maintains multiset counts for diffs and sums for incremental moves."""

    __slots__ = ("els", "d", "s", "nd", "ns")

    def __init__(self, A):
        self.els = sorted(set(int(x) for x in A))
        self._recount()

    def _recount(self):
        d = {}
        s = {}
        els = self.els
        n = len(els)
        for i in range(n):
            ai = els[i]
            for j in range(n):
                aj = els[j]
                d[ai - aj] = d.get(ai - aj, 0) + 1
                s[ai + aj] = s.get(ai + aj, 0) + 1
        self.d = d
        self.s = s
        self.nd = len(d)
        self.ns = len(s)

    def score(self):
        return _score_from_counts(self.nd, self.ns, len(self.els))

    def _add_counts(self, v):
        """Tentative multiset effect of adding v; returns (new_nd, new_ns)."""
        d = self.d
        s = self.s
        nd = self.nd
        ns = self.ns
        for u in self.els:
            a = v - u
            b = v + u
            if d.get(a, 0) == 0:
                nd += 1
            if s.get(b, 0) == 0:
                ns += 1
        # v - v = 0 and v + v = 2v
        if d.get(0, 0) == 0:
            nd += 1
        if s.get(2 * v, 0) == 0:
            ns += 1
        return nd, ns

    def add(self, v):
        nd, ns = self._add_counts(v)
        d = self.d
        s = self.s
        for u in self.els:
            a = v - u
            b = v + u
            d[a] = d.get(a, 0) + 1
            s[b] = s.get(b, 0) + 1
            d[-a] = d.get(-a, 0) + 1
            s[b] = s.get(b, 0) + 1
            # careful: we must add symmetric diff (u - v) and sum is symmetric already
            # u - v = -(v-u); handled above
        # self terms
        d[0] = d.get(0, 0) + 1
        s[2 * v] = s.get(2 * v, 0) + 1
        self.els.append(v)
        self.els.sort()
        self.nd = len(d)
        self.ns = len(s)

    def _remove_counts(self, v):
        d = self.d
        s = self.s
        tmpd = {}
        tmps = {}
        # simulate removing v: recompute only affected keys
        for u in self.els:
            if u == v:
                continue
            a = v - u
            b = v + u
            tmpd[a] = tmpd.get(a, 0) + 1
            tmpd[-a] = tmpd.get(-a, 0) + 1
            tmps[b] = tmps.get(b, 0) + 1
        nd = self.nd
        ns = self.ns
        for k, c in tmpd.items():
            if d.get(k, 0) - c <= 0:
                nd -= 1
        for k, c in tmps.items():
            if s.get(k, 0) - c <= 0:
                ns -= 1
        if d.get(0, 0) - 1 <= 0:
            nd -= 1
        if s.get(2 * v, 0) - 1 <= 0:
            ns -= 1
        return nd, ns

    def remove(self, v):
        nd, ns = self._remove_counts(v)
        # actually rebuild counts for correctness (still fast for moderate n)
        self.els = [x for x in self.els if x != v]
        self._recount()


def _golomb_like(k, rng):
    """A small set with many distinct differences (B_2/Sidon-ish)."""
    # use a known good ruler-like construction: powers-ish + greedy
    chosen = [0]
    while len(chosen) < k:
        cands = range(max(chosen) + 1, max(chosen) + 40)
        best = None
        best_v = -1
        for c in cands:
            diffs = set()
            ok = True
            for x in chosen:
                for y in chosen:
                    dd = abs(x - y)
                    diffs.add(dd)
            for x in chosen:
                pass
            # count new distinct diffs
            cnt = set()
            for x in chosen:
                cnt.add(abs(c - x))
            v = len(cnt)
            if v > best_v:
                best_v = v
                best = c
                if v >= len(chosen):
                    break
        chosen.append(best)
    return chosen


def _multi_cluster_build(g, L, d, span, rng):
    offsets = [0]
    used = {0}
    for _ in range(g - 1):
        best_off = None
        best_val = -1
        for _try in range(80):
            cand = rng.randint(-span, span)
            if cand in used:
                continue
            md = min(abs(cand - o) for o in offsets)
            v = md - abs(cand) * 0.001
            if v > best_val:
                best_val = v
                best_off = cand
        if best_off is None:
            best_off = rng.randint(-span, span)
        offsets.append(best_off)
        used.add(best_off)
    A = []
    for o in offsets:
        for t in range(L):
            A.append(o + t * d)
    return A


def _local_search(A, deadline, rng, iters_hint=100000):
    st = State(A)
    best_els = st.els[:]
    best_score = st.score()
    it = 0
    nbr_deltas = (-MULT, -1, 1, MULT) if False else None
    while time.time() < deadline and it < iters_hint:
        it += 1
        n = len(st.els)
        move = rng.random()
        cur = st.score()
        if move < 0.45 and n < 4000:
            # add a candidate near the current range
            lo = st.els[0]
            hi = st.els[-1]
            spread = hi - lo + 1
            v = rng.randint(lo - spread // 3 - 1, hi + spread // 3 + 1)
            if v in st.els:
                continue
            nd, ns = st._add_counts(v)
            sc = _score_from_counts(nd, ns, n + 1)
            if sc > cur:
                st.add(v)
                if sc > best_score:
                    best_score = sc
                    best_els = st.els[:]
        elif move < 0.75 and n > 4:
            i = rng.randrange(n)
            v = st.els[i]
            nd, ns = st._remove_counts(v)
            sc = _score_from_counts(nd, ns, n - 1)
            if sc > cur:
                st.remove(v)
                if sc > best_score:
                    best_score = sc
                    best_els = st.els[:]
        else:
            if n < 2:
                continue
            i = rng.randrange(n)
            v = st.els[i]
            step = rng.choice((-2, -1, 1, 2, -3, 3))
            w = v + step
            if w in st.els:
                continue
            nd_r, ns_r = st._remove_counts(v)
            sc_r = _score_from_counts(nd_r, ns_r, n - 1)
            # temporarily remove
            saved = st.els[:]
            st.remove(v)
            nd_a, ns_a = st._add_counts(w)
            sc = _score_from_counts(nd_a, ns_a, n)
            if sc > cur:
                st.add(w)
                if sc > best_score:
                    best_score = sc
                    best_els = st.els[:]
            else:
                # revert
                st = State(saved)
    return best_els


MULT = 0  # placeholder, set later


def solve():
    best = [0, 1, 2, 3, 4, 5]
    _, _, best_score = _score(best)
    deadline = time.time() + 110
    rng = random.Random(20240607)

    seeds = []

    # 1) multi-cluster family
    for g in (2, 3, 4, 5, 6, 8):
        for L in (3, 4, 5, 6, 8, 10, 12):
            for d in (1, 2, 3, 4, 6, 8):
                for span in (10, 30, 80, 160):
                    seeds.append(_multi_cluster_build(g, L, d, span, rng))

    # 2) X + M*interval family, X Golomb-like with many distinct differences
    for k in (3, 4, 5, 6, 7, 8):
        X = _golomb_like(k, rng)
        for L in (4, 6, 8, 10, 14, 20):
            for M in (13, 29, 61, 127, 251, 509, 1021, 2039):
                A = []
                for x in X:
                    for t in range(L):
                        A.append(x + M * t)
                seeds.append(A)

    rng.shuffle(seeds)

    # evaluate seeds, keep several best to polish
    scored = []
    for A in seeds:
        if time.time() > deadline - 20:
            break
        A = sorted(set(int(x) for x in A))
        if len(A) < 2:
            continue
        nd, ns, sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A[:]
        scored.append((sc, A))

    scored.sort(key=lambda t: -t[0])
    top = [A for _, A in scored[:8]] if scored else [best]

    # polish the top seeds with the incremental local search
    per = max(1.0, (deadline - time.time()) / max(1, len(top)))
    for A in top:
        if time.time() > deadline - 2:
            break
        t_end = min(deadline - 1, time.time() + per)
        cand = _local_search(A, t_end, rng)
        nd, ns, sc = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]

    # final polish
    if time.time() < deadline - 1:
        cand = _local_search(best, deadline - 0.5, rng)
        nd, ns, sc = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]

    best = sorted(set(int(x) for x in best))
    return best
# EVOLVE-BLOCK-END
