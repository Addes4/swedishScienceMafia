# EVOLVE-BLOCK-START
"""Simulated-annealing search for sets maximising log|A-A|/log|A+A|.

Key efficiency fix: the annealer no longer recomputes |A+A| and |A-A| from
scratch (O(n^2)) on every candidate.  Instead it keeps running multiplicity
counts of the sums and differences, updated in O(n) for a single element move
or an add/remove.  Exact numpy scoring is used only to validate/refresh the
global best.  This lets far more moves happen inside the time budget, so the
search can effectively drive the ratio upward.
"""
import math
import time
import numpy as np


def _score(a):
    n = len(a)
    if n < 2:
        return -1.0, 1, 1
    a = np.asarray(a, dtype=np.int64)
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    ns = int(sums.size)
    nd = int(diffs.size)
    if ns < 2:
        return -1.0, nd, ns
    return math.log(nd) / math.log(ns), nd, ns


class State:
    """Maintains multiset counts of sums and differences counted as distinct
    values (nonzero count == present).  Supports single moves / add / remove."""
    __slots__ = ("vals", "s_cnt", "d_cnt", "nz_s", "nz_d")

    def __init__(self, vals):
        self.vals = list(int(v) for v in sorted(set(vals)))
        self._rebuild()

    def _rebuild(self):
        v = self.vals
        m = len(v)
        s_cnt = {}
        d_cnt = {}
        for i in range(m):
            vi = v[i]
            for j in range(m):
                vj = v[j]
                s = vi + vj
                s_cnt[s] = s_cnt.get(s, 0) + 1
                d = vi - vj
                d_cnt[d] = d_cnt.get(d, 0) + 1
        self.s_cnt = s_cnt
        self.d_cnt = d_cnt
        self.nz_s = len(s_cnt)
        self.nz_d = len(d_cnt)

    @staticmethod
    def _upd(cnt, key, delta, nz):
        c = cnt.get(key, 0) + delta
        if c <= 0:
            if key in cnt:
                del cnt[key]
            return nz - 1 if cnt.get(key, 0) == 0 and delta < 0 else nz
        else:
            was0 = cnt.get(key, 0) == 0
            cnt[key] = c
            return nz + 1 if was0 else nz

    def _add_value(self, x):
        """Incrementally add value x to the multiset (x not present)."""
        s_cnt, d_cnt = self.s_cnt, self.d_cnt
        nzs, nzd = self.nz_s, self.nz_d
        for v in self.vals:
            # sums: x+v and v+x  (two ordered contributions)
            for s in (x + v, v + x):
                o = s_cnt.get(s, 0)
                if o == 0:
                    nzs += 1
                s_cnt[s] = o + 1
            # diffs: x-v and v-x
            for d in (x - v, v - x):
                o = d_cnt.get(d, 0)
                if o == 0:
                    nzd += 1
                d_cnt[d] = o + 1
        # self terms
        for s in (x + x,):
            o = s_cnt.get(s, 0)
            if o == 0:
                nzs += 1
            s_cnt[s] = o + 1
        o = d_cnt.get(0, 0)
        if o == 0:
            nzd += 1
        d_cnt[0] = o + 1
        self.nz_s = nzs
        self.nz_d = nzd

    def _remove_value(self, x):
        """Remove value x (present)."""
        s_cnt, d_cnt = self.s_cnt, self.d_cnt
        nzs, nzd = self.nz_s, self.nz_d
        for v in self.vals:
            if v == x:
                continue
            for s in (x + v, v + x):
                c = s_cnt.get(s, 0) - 1
                if c <= 0:
                    if s in s_cnt:
                        del s_cnt[s]
                        nzs -= 1
                else:
                    s_cnt[s] = c
            for d in (x - v, v - x):
                c = d_cnt.get(d, 0) - 1
                if c <= 0:
                    if d in d_cnt:
                        del d_cnt[d]
                        nzd -= 1
                else:
                    d_cnt[d] = c
        c = s_cnt.get(x + x, 0) - 1
        if c <= 0:
            if (x + x) in s_cnt:
                del s_cnt[x + x]
                nzs -= 1
        else:
            s_cnt[x + x] = c
        c = d_cnt.get(0, 0) - 1
        if c <= 0:
            if 0 in d_cnt:
                del d_cnt[0]
                nzd -= 1
        else:
            d_cnt[0] = c
        self.nz_s = nzs
        self.nz_d = nzd

    def ratio(self):
        if self.nz_s < 2:
            return -1.0
        return math.log(self.nz_d) / math.log(self.nz_s)


def _polish(a, deadline, rng, rmax):
    """Greedy single-element polish using the incremental state."""
    st = State(a)
    cur = st.ratio()
    while True:
        if time.time() > deadline:
            break
        improved = False
        order = list(rng.permutation(len(st.vals)))
        for i in order:
            if time.time() > deadline:
                break
            base = st.vals[i]
            best_v, best_s = base, cur
            for v in (base + 1, base - 1, base + 2, base - 2):
                if v < 0 or v > rmax or v in st.s_cnt and False:
                    pass
                if v < 0 or v > rmax:
                    continue
                if v == base or v in set(st.vals):
                    continue
                # temporarily move
                st._remove_value(base)
                st.vals.remove(base)
                st._add_value(v)
                st.vals.append(v)
                st.vals.sort()
                s = st.ratio()
                if s > best_s + 1e-12:
                    best_s, best_v = s, v
                    # keep and break to next i
                    cur = s
                    improved = True
                    break
                else:
                    # revert
                    st._remove_value(v)
                    st.vals.remove(v)
                    st._add_value(base)
                    st.vals.append(base)
                    st.vals.sort()
            if best_v != base and False:
                pass
        if not improved:
            break
    return st.vals, st.ratio()


def solve():
    t_end = time.time() + 117.0
    rng = np.random.default_rng(0xC0FFEE)

    best = None
    best_sc = -1.0

    def consider(vals):
        nonlocal best, best_sc
        arr = np.unique(np.asarray(list(vals), dtype=np.int64))
        if arr.size < 2:
            return
        s, _, _ = _score(arr)
        if s > best_sc:
            best_sc = s
            best = arr.copy()

    # ---- crafted seeds -------------------------------------------------
    consider(np.arange(0, 40, dtype=np.int64))
    for L, Q in ((3, 9), (4, 16), (5, 30), (6, 60), (8, 120)):
        consider(np.concatenate([np.arange(L), Q + np.arange(L)]))
    consider(np.array([1 << i for i in range(14)], dtype=np.int64))

    sizes = [16, 20, 25, 32, 40, 50, 64, 80, 100, 128, 160]

    for n in sizes:
        if time.time() > t_end:
            break
        rmax = int(4 * n * n)
        for _ in range(2):
            R = max(n + 1, int(n ** 1.5))
            R = min(R, rmax)
            a = np.sort(rng.choice(R, size=n, replace=False)).astype(np.int64)
            consider(a)

    n_list = sizes[:]
    idx = 0
    while time.time() < t_end:
        n = n_list[idx % len(n_list)]
        idx += 1
        rmax = int(4 * n * n)

        if best is not None and len(best) == n and rng.random() < 0.5:
            a = best.copy()
        else:
            R = max(n + 1, min(int(n ** 1.5), rmax))
            a = np.sort(rng.choice(R, size=n, replace=False)).astype(np.int64)

        st = State(a)
        cur = st.ratio()
        T = 0.30
        b_step = max(1, n // 4)
        it = 0
        while time.time() < t_end:
            it += 1
            if (it & 1023) == 0 and time.time() > t_end:
                break

            r = rng.random()
            if r < 0.90:
                m = len(st.vals)
                i = int(rng.integers(m))
                base = st.vals[i]
                if rng.random() < 0.5:
                    v = base + int(rng.integers(-b_step, b_step + 1))
                else:
                    v = int(rng.integers(0, rmax + 1))
                if v < 0:
                    v = 0
                if v > rmax:
                    v = rmax
                if v == base or v in set(st.vals):
                    continue
                # apply
                st._remove_value(base)
                st.vals.remove(base)
                st._add_value(v)
                st.vals.append(v)
                st.vals.sort()
                s = st.ratio()
                accept = (s > cur) or (rng.random() < math.exp((s - cur) / max(T, 1e-9)))
                if accept:
                    cur = s
                    if s > best_sc:
                        # validate exactly
                        sc, _, _ = _score(np.array(st.vals, dtype=np.int64))
                        if sc > best_sc:
                            best_sc = sc
                            best = np.array(st.vals, dtype=np.int64)
                else:
                    # revert
                    st._remove_value(v)
                    st.vals.remove(v)
                    st._add_value(base)
                    st.vals.append(base)
                    st.vals.sort()
            elif r < 0.96:
                if len(st.vals) >= 4000:
                    continue
                v = int(rng.integers(0, rmax + 1))
                if v in set(st.vals):
                    continue
                st._add_value(v)
                st.vals.append(v)
                st.vals.sort()
                s = st.ratio()
                accept = (s > cur) or (rng.random() < math.exp((s - cur) / max(T, 1e-9)))
                if accept:
                    cur = s
                    if s > best_sc:
                        sc, _, _ = _score(np.array(st.vals, dtype=np.int64))
                        if sc > best_sc:
                            best_sc = sc
                            best = np.array(st.vals, dtype=np.int64)
                else:
                    st._remove_value(v)
                    st.vals.remove(v)
            else:
                if len(st.vals) <= 4:
                    continue
                i = int(rng.integers(len(st.vals)))
                base = st.vals[i]
                st._remove_value(base)
                st.vals.remove(base)
                s = st.ratio()
                accept = (s > cur) or (rng.random() < math.exp((s - cur) / max(T, 1e-9)))
                if accept:
                    cur = s
                    if s > best_sc:
                        sc, _, _ = _score(np.array(st.vals, dtype=np.int64))
                        if sc > best_sc:
                            best_sc = sc
                            best = np.array(st.vals, dtype=np.int64)
                else:
                    st._add_value(base)
                    st.vals.append(base)
                    st.vals.sort()

            T *= 0.9999
            if T < 1e-4:
                T = 0.15

        if time.time() < t_end - 1.0:
            pv, psc = _polish(st.vals, time.time() + 1.0, rng, rmax)
            sc, _, _ = _score(np.array(pv, dtype=np.int64))
            if sc > best_sc:
                best_sc = sc
                best = np.array(pv, dtype=np.int64)

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)

    best = np.unique(best.astype(np.int64))
    if best.size > 4000:
        best = best[:4000]
    lo = -10 ** 15
    hi = 10 ** 15
    out = [int(max(lo, min(hi, int(x)))) for x in best]
    return out
# EVOLVE-BLOCK-END
