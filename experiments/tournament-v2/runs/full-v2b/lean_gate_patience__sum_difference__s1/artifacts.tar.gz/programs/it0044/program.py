# EVOLVE-BLOCK-START
"""Two-block construction: A = B union (q + B) with B = {0,1,...,L-1}.

A - A: within-block differences cover [-(L-1), L-1]; cross differences cover
[q-(L-1), q+(L-1)] which is a contiguous interval of length 2L-1 (for q >= L-1).
So |A-A| is at least (2L-1) + (2L-1) = 4L-2 for the union of intervals.
A + A: within-block sums cover [0, 2L-2]; cross sums cover [q, q+2L-2].
Choosing q small (~L-1) merges the sum ranges so |A+A| stays ~small while the
difference range stays wide. We sweep (L, q) and polish with a fast incremental
multiplicity-based local search that maintains difference/sum count tables.
"""
import math
import time


def _stats(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 1, 1, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return len(diffs), len(sums), score


def _score_from_counts(diff_count, sum_count, n):
    d = diff_count
    s = sum_count
    if s < 2 or d < 2:
        return -1.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


class _State:
    """Maintains counts of differences and sums for a set A."""
    __slots__ = ("A", "dc", "sc", "diff_n", "sum_n")

    def __init__(self, A):
        self.A = sorted(set(int(x) for x in A))
        self._rebuild()

    def _rebuild(self):
        A = self.A
        dc = {}
        sc = {}
        for x in A:
            for y in A:
                dc[x - y] = dc.get(x - y, 0) + 1
                sc[x + y] = sc.get(x + y, 0) + 1
        self.dc = dc
        self.sc = sc
        self.diff_n = len(dc)
        self.sum_n = len(sc)

    # incremental ops
    def _add_val(self, v):
        A = self.A
        dc = self.dc
        sc = self.sc
        for x in A:
            k1 = v - x
            k2 = x - v
            dc[k1] = dc.get(k1, 0) + 1
            dc[k2] = dc.get(k2, 0) + 1
            k3 = v + x
            sc[k3] = sc.get(k3, 0) + 1
            sc[k3] = sc[k3] + 1  # count (v,x) and (x,v)
        dc[0] = dc.get(0, 0) + 1
        sc[2 * v] = sc.get(2 * v, 0) + 1
        A.append(v)
        A.sort()

    def _remove_val(self, v):
        A = self.A
        dc = self.dc
        sc = self.sc
        for x in A:
            if x == v:
                continue
            k1 = v - x
            k2 = x - v
            c1 = dc[k1] - 1
            c2 = dc[k2] - 1
            if c1 <= 0:
                del dc[k1]
            else:
                dc[k1] = c1
            if c2 <= 0:
                del dc[k2]
            else:
                dc[k2] = c2
            k3 = v + x
            c = sc[k3] - 2
            if c <= 0:
                del sc[k3]
            else:
                sc[k3] = c
        c = dc.get(0, 0) - 1
        if c <= 0:
            dc.pop(0, None)
        else:
            dc[0] = c
        c = sc.get(2 * v, 0) - 1
        if c <= 0:
            sc.pop(2 * v, None)
        else:
            sc[2 * v] = c
        A.remove(v)

    def score(self):
        if self.sum_n < 2:
            return -1.0
        return math.log(self.diff_n) / math.log(self.sum_n) + (1 - 1 / len(self.A)) / 100


def _polish(A, deadline):
    st = _State(A)
    best = st.A[:]
    best_score = st.score()
    cur_score = best_score

    # candidate pool offsets relative to current elements
    while time.time() < deadline:
        improved = False
        Acur = st.A
        n = len(Acur)
        lo = min(Acur) - 2
        hi = max(Acur) + 2
        span = hi - lo

        # try additions
        pool = set()
        for x in Acur:
            for delta in (-1, 1, -2, 2, -3, 3, -5, 5, -8, 8):
                v = x + delta
                if v not in pool:
                    pool.add(v)
        for v in pool:
            if v in st.A:
                continue
            if v < lo or v > hi:
                continue
            st._add_val(v)
            s = st.score()
            if s > best_score:
                best_score = s
                best = st.A[:]
                improved = True
                break
            else:
                st._remove_val(v)
        if improved:
            continue

        # try removals
        for v in list(st.A):
            if len(st.A) <= 4:
                break
            st._remove_val(v)
            s = st.score()
            if s > best_score:
                best_score = s
                best = st.A[:]
                improved = True
                break
            else:
                st._add_val(v)
        if improved:
            continue

        # try shifts
        for i in range(len(st.A)):
            v = st.A[i]
            for delta in (-1, 1, -2, 2, -3, 3):
                w = v + delta
                if w == v or w in st.A:
                    continue
                st._remove_val(v)
                st._add_val(w)
                s = st.score()
                if s > best_score:
                    best_score = s
                    best = st.A[:]
                    improved = True
                    break
                else:
                    st._remove_val(w)
                    st._add_val(v)
            if improved:
                break
        if not improved:
            break
    return best


def _two_block(L, q):
    A = list(range(L)) + [q + i for i in range(L)]
    return sorted(set(A))


def solve():
    best = [0, 1, 2, 3, 4, 5]
    _, _, best_score = _stats(best)
    deadline = time.time() + 110

    # Sweep two-block family: L up to ~2000, q around L-1 or a bit more.
    candidates = []
    for L in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 32, 40, 50, 64, 80,
              100, 125, 150, 200, 250, 300, 400, 500, 600, 800, 1000):
        for q in (L - 1, L, L + 1, L + 2, 2 * L, 3 * L, L * L // 2 + 1):
            if q < 1:
                continue
            candidates.append((L, q))

    for (L, q) in candidates:
        if time.time() > deadline - 3:
            break
        A = _two_block(L, q)
        if len(A) < 2:
            continue
        _, _, s = _stats(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # polish the best two-block construction
    if time.time() < deadline - 1:
        A = _polish(best, deadline - 0.5)
        _, _, s = _stats(A)
        if s > best_score:
            best_score = s
            best = A[:]

    best = sorted(set(int(x) for x in best))
    return best
# EVOLVE-BLOCK-END
