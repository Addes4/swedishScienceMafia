# EVOLVE-BLOCK-START
"""Constructive search: union of translated AP clusters at Golomb-like offsets,
balancing a small sum set against a large difference set.  Uses exact fast
set-cardinality computation via bit-packed difference/sum counting on a dense
range when feasible, falling back to Python sets otherwise."""
import math
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    lo = a[0]
    hi = a[-1]
    span = hi - lo
    # dense counting if range small enough
    if span <= 40_000_000:
        sset = bytearray(span + 1)          # possible sums offset by 2*lo
        dset = bytearray(2 * span + 1)      # diffs offset by span
        for i, x in enumerate(a):
            xs = x - lo
            for y in a[i:]:
                sset[(x + y) - 2 * lo] = 1
                d = x - y
                if d < 0:
                    d = -d
                dset[span + d] = 1
                dset[span - d] = 1
        nd = sum(dset) - 1
        ns = sum(sset)
        if ns < 2 or nd < 1:
            return 0.0
        return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns < 2 or nd < 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _golomb(n):
    """Approximate Golomb ruler with n marks using a greedy search."""
    marks = [0]
    used = {0}
    while len(marks) < n:
        cand = marks[-1] + 1
        while True:
            ok = True
            for m in marks:
                d = cand - m
                if d in used or d == 0:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        for m in marks:
            used.add(cand - m)
        marks.append(cand)
    return marks


def _build(clusters, width, offset_scale, gap=1):
    """Union of `clusters` translated copies of an AP of length `width`."""
    offs = _golomb(clusters)
    offs = [o * offset_scale for o in offs]
    A = []
    for o in offs:
        for k in range(width):
            A.append(o + k * gap)
    return A


def solve():
    """Return A making |A-A| large and |A+A| small."""
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # Structured candidates: scan clusters/width/scale
    for clusters in range(2, 60):
        base_offs = _golomb(clusters)
        maxo = base_offs[-1] if base_offs else 1
        for width in range(2, 60):
            n = clusters * width
            if n < 4 or n > 4000:
                continue
            for scale in (
                width * (maxo + 1),
                width * maxo,
                width * (maxo + 1) * 2,
                width * (maxo // 2 + 1),
                width * 3,
                width * 5,
                width * 8,
            ):
                if scale < 1:
                    continue
                A = _build(clusters, width, scale)
                if len(A) > 4000 or len(A) < 4:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score, best = s, A[:]
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    if best is None:
        best = [0, 1, 2, 4, 8]
        best_score = _score(best)

    return sorted(set(best))
# EVOLVE-BLOCK-END
