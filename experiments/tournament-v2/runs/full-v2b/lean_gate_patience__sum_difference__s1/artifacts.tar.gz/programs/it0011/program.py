# EVOLVE-BLOCK-START
"""Union of translated AP clusters: many differences, few sums."""
import math
import time
import numpy as np


def _sizes(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0, n
    # difference set size
    diffs = np.unique(a[:, None] - a[None, :])
    # sum set size
    sums = np.unique(a[:, None] + a[None, :])
    return diffs.size, sums.size, n


def _score_parts(d, s, n):
    if n < 2 or s < 2 or d < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _golomb(n):
    marks = [0]
    used = {0}
    best = None
    while len(marks) < n:
        cand = marks[-1] + 1
        while True:
            ok = True
            for m in marks:
                if cand - m in used:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        for m in marks:
            used.add(cand - m)
        marks.append(cand)
    return marks


def _build(offs, step, width):
    """Union over offsets of AP {o + step*k}, k=0..width-1."""
    A = []
    for o in offs:
        for k in range(width):
            A.append(o + step * k)
    return A


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 110

    # precompute golomb offsets for many cluster counts
    gol_cache = {}

    def gol(c):
        if c not in gol_cache:
            gol_cache[c] = _golomb(c)
        return gol_cache[c]

    # Scan: number of clusters, width, step, and offset scale
    for clusters in range(2, 61):
        if time.time() > deadline:
            break
        offs0 = gol(clusters)
        maxoff = offs0[-1] if offs0 else 1
        for width in range(2, 41):
            n = clusters * width
            if n < 2 or n > 4000:
                continue
            for step_mult in (1, 2):
                # scale offsets so clusters are separated by ~ width*step
                scale = width * step_mult
                offs = [o * scale for o in offs0]
                A = _build(offs, 1, width)
                if len(set(A)) != n:
                    # allow overlaps; still ok
                    pass
                d, s, nn = _sizes(A)
                sc = _score_parts(d, s, nn)
                if sc > best_score:
                    best_score, best = sc, list(set(A))
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break

    if best is None:
        best = [0, 1, 2, 4, 8]

    return sorted(set(best))
# EVOLVE-BLOCK-END
