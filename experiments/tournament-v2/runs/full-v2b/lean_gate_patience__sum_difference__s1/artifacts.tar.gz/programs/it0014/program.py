# EVOLVE-BLOCK-START
"""Behrend-style construction: points on a sphere in a low-dimensional box.

We build A as a set of integer points inside a d-dimensional grid box, all of
which lie on a common sphere. Points on a sphere have the property that a
random pair's difference lands in a bounded region, and (crucially for this
problem) choosing a *small* radius relative to the box makes the *sum set*
collapse (all sums lie near 2*center) while the difference set still spans the
box — giving many distinct differences but few distinct sums.
"""
import math
import time


def _unique_count(arr):
    arr = sorted(arr)
    c = 1
    for i in range(1, len(arr)):
        if arr[i] != arr[i - 1]:
            c += 1
    return c


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = [x - y for x in a for y in a]
    sums = [x + y for x in a for y in a]
    nd = _unique_count(diffs)
    ns = _unique_count(sums)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _behrend(d, r, m):
    """Integer points (x_1..x_d) in [0,m)^d with sum of squares == r."""
    pts = []

    def rec(idx, remaining, cur):
        if remaining < 0:
            return
        if idx == d:
            if remaining == 0:
                pts.append(tuple(cur))
            return
        # prune: with d-idx slots left, max achievable is (d-idx)*m*m
        max_sq = (d - idx) * (m - 1) * (m - 1)
        if remaining > max_sq:
            return
        lo = 0 if idx > 0 else 0
        hi = m - 1
        for v in range(lo, hi + 1):
            rec(idx + 1, remaining - v * v, cur + [v])

    rec(0, r, [])
    return pts


def _flatten(pts, m):
    A = []
    for p in pts:
        x = 0
        for v in p:
            x = x * m + v
        A.append(x)
    return A


def solve():
    deadline = time.time() + 105
    best = None
    best_score = -1.0

    base = [0, 1, 2, 4, 7, 13, 24, 44, 81, 149, 274]
    for d in range(2, 6):
        for m in (5, 7, 9, 11, 13, 17, 23, 29, 37):
            for rfrac in (0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85):
                if time.time() > deadline:
                    break
                r = int(round(rfrac * d * ((m - 1) ** 2) / 2.0))
                if r <= 0:
                    continue
                pts = _behrend(d, r, m)
                if len(pts) < 3:
                    continue
                # Try a few radii around r
                for rr in range(max(1, r - 2), r + 3):
                    pts2 = _behrend(d, rr, m)
                    if len(pts2) < 3:
                        continue
                    A = _flatten(pts2, m)
                    sc = _score(A)
                    if sc > best_score:
                        best_score = sc
                        best = A[:]
                if len(best or []) > 0 and best_score > 0.9:
                    pass
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    if best is None:
        best = base[:]

    # Local refinement on the flattened representation via small integer moves.
    cur = sorted(set(best))
    if len(cur) > 3000:
        cur = cur[:3000]
    cur_score = _score(cur)
    it = 0
    import random
    random.seed(12345)
    while time.time() < deadline and it < 200000:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.5 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-3, 3)
        elif op < 0.75 and len(cand) > 3:
            i = random.randrange(len(cand))
            cand.pop(i)
        elif len(cand) < 3000:
            cand.append(random.randint(0, max(2, max(cur) if cur else 100)))
        cand = sorted(set(cand))
        if len(cand) < 3:
            continue
        sc = _score(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
