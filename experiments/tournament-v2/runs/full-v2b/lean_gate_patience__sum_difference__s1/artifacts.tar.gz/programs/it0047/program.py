# EVOLVE-BLOCK-START
"""Maximize log|A-A|/log|A+A|.

Strategy: A = X + M*[0,k) where X is a small "Sidon-like" base whose differences are
all distinct, and the interval factor {0,M,2M,...} makes many sums collide.  We sweep
base sets X, scaling M, and interval length k.  A second family (two dense blocks at a
big gap) is also tried.  All evaluations use fast set construction (built once, not a
slow O(n^2) random search over the whole space)."""
import math
import time


def _ratio(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    ds = {x - y for x in a for y in a}
    ss = {x + y for x in a for y in a}
    return math.log(len(ds)) / math.log(len(ss)) + (1.0 - 1.0 / n) / 100.0


def _sidon_base(m):
    """Greedy Sidon-like set: build B so that all pairwise sums (hence
    differences up to sign) are as distinct as possible.  Returns |B| distinct ints."""
    B = [0]
    used_sums = {0}
    cand = 1
    while len(B) < m and cand < 10**7:
        ok = True
        for b in B:
            s = b + cand
            if s in used_sums:
                ok = False
                break
        if ok:
            for b in B:
                used_sums.add(b + cand)
            used_sums.add(cand + cand)
            B.append(cand)
        cand += 1
    return B


def _family1(X, k, M):
    """A = union_{j=0..k-1} (X + j*M)."""
    return [x + j * M for j in range(k) for x in X]


def _family2(L, gap):
    """Two dense contiguous blocks of length L separated by gap."""
    A = list(range(L))
    A += [gap + i for i in range(L)]
    return A


def solve():
    t_end = time.time() + 100
    best = [7, 15, 18, 22, -3, -2]
    bscore = _ratio(best)

    # ----- Family 1: X + M*[0,k) -----
    sidons = {}
    for m in (4, 5, 6, 7, 8, 9, 10, 12, 14, 16):
        sidons[m] = _sidon_base(m)

    for m, X in sidons.items():
        span = max(X) - min(X) if len(X) > 1 else 1
        for k in (4, 6, 8, 10, 12, 16, 20, 25):
            for mult in (1, 2, 3, 5, 8, 13, 21):
                M = span * mult + 1
                A = _family1(X, k, M)
                if len(A) > 4000:
                    continue
                s = _ratio(A)
                if s > bscore:
                    best, bscore = A, s
        if time.time() > t_end * 0.6:
            break

    # ----- Family 2: two dense blocks -----
    for L in (40, 80, 120, 200, 300, 500, 800, 1200, 2000):
        for gap in (L, 2 * L, 3 * L, 5 * L, L * L, 2 * L * L + 1):
            A = _family2(L, gap)
            if len(A) > 4000:
                continue
            s = _ratio(A)
            if s > bscore:
                best, bscore = A, s

    # ----- Family 3: three dense blocks at varied gaps (more diff ranges) -----
    for L in (30, 60, 100, 200, 400, 700):
        for g1 in (L + 1, 2 * L + 1, 3 * L + 1):
            for g2 in (g1 + L + 1, g1 + 2 * L + 5, g1 + 3 * L + 3, 2 * g1 + L):
                A = list(range(L)) + [g1 + i for i in range(L)] + [g2 + i for i in range(L)]
                if len(A) > 4000:
                    continue
                s = _ratio(A)
                if s > bscore:
                    best, bscore = A, s

    # ----- Family 4: X + M*[0,k) with X itself compressed (add a dense tail) -----
    for m, X in sidons.items():
        for k in (8, 12, 20, 30):
            span = max(X) - min(X) + 1 if len(X) > 1 else 1
            for mult in (2, 4, 7):
                M = span * mult
                A = _family1(X, k, M)
                if len(A) > 4000:
                    continue
                s = _ratio(A)
                if s > bscore:
                    best, bscore = A, s

    return sorted(set(best))
# EVOLVE-BLOCK-END
