# EVOLVE-BLOCK-START
"""
Sets with many differences and few sums.

Strategy: build a seed from parametric families and refine with an
incremental-multiplicity local search.

Key families considered:
  (a) Two-block AP:  A = [0,L) u (q + [0,L))
      - intra-block sums collide (only 2L-1 values each),
      - cross differences fill long intervals (up to 2L-1 values),
      gives an excellent ratio when q is large.
  (b) Difference-rich base + long interval:
      A = X u (M + [0,k)) with X small Sidon-like (many distinct diffs).

Then a fast hill climber maintains dicts Dd[x]=#pairs with difference x and
Ds[x]=#pairs with sum x, allowing O(n) add/remove/move evaluation.
"""

import math
import random
import time
from collections import defaultdict


def _counts(a):
    Dd = defaultdict(int)
    Ds = defaultdict(int)
    n = len(a)
    for i in range(n):
        xi = a[i]
        for j in range(n):
            Dd[xi - a[j]] += 1
            Ds[xi + a[j]] += 1
    return Dd, Ds


def _score_from_counts(Dd, Ds, n):
    nd = len(Dd)
    ns = len(Ds)
    if nd < 2 or ns < 2 or n < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    if len(set(a)) != len(a):
        a = list(set(a))
    if len(a) < 2:
        return -1.0
    Dd, Ds = _counts(a)
    return _score_from_counts(Dd, Ds, len(a))


def _add(a, Dd, Ds, x):
    for y in a:
        Dd[x - y] += 1
        Dd[y - x] += 1
        Ds[x + y] += 1
    Dd[0] += 1
    Ds[2 * x] += 1
    a.append(x)


def _remove(a, Dd, Ds, idx):
    x = a[idx]
    for j, y in enumerate(a):
        if j == idx:
            continue
        for key in (x - y, y - x):
            Dd[key] -= 1
            if Dd[key] == 0:
                del Dd[key]
        sk = x + y
        Ds[sk] -= 1
        if Ds[sk] == 0:
            del Ds[sk]
    Dd[0] -= 1
    if Dd[0] == 0:
        del Dd[0]
    sk = 2 * x
    Ds[sk] -= 1
    if Ds[sk] == 0:
        del Ds[sk]
    a[idx] = a[-1]
    a.pop()


def _make_two_block(L, q):
    a = list(range(L))
    for k in range(L):
        a.append(q + k)
    return sorted(set(a))


def _make_base_interval(X, M, k):
    a = list(X)
    for j in range(k):
        a.append(M + j)
    return sorted(set(a))


def _local_search(a, deadline, max_n=3800):
    a = sorted(set(a))
    Dd, Ds = _counts(a)
    n = len(a)
    best = _score_from_counts(Dd, Ds, n)
    a = list(a)
    while time.time() < deadline:
        improved = False
        # Try removals (cheap, often good since diffs are redundant)
        if len(a) > 2:
            for i in range(len(a) - 1, -1, -1):
                if time.time() > deadline:
                    break
                x = a[i]
                saved_dd = {}
                saved_ds = {}
                # tentatively remove
                for j, y in enumerate(a):
                    if j == i:
                        continue
                    for key in (x - y, y - x):
                        Dd[key] -= 1
                        if Dd[key] == 0:
                            del Dd[key]
                    sk = x + y
                    Ds[sk] -= 1
                    if Ds[sk] == 0:
                        del Ds[sk]
                Dd[0] -= 1
                if Dd[0] == 0:
                    del Dd[0]
                sk = 2 * x
                Ds[sk] -= 1
                if Ds[sk] == 0:
                    del Ds[sk]
                nn = len(a) - 1
                sc = _score_from_counts(Dd, Ds, nn)
                if sc > best + 1e-12:
                    best = sc
                    a[i] = a[-1]
                    a.pop()
                    improved = True
                else:
                    # undo
                    for j, y in enumerate(a):
                        if j == i:
                            continue
                        for key in (x - y, y - x):
                            Dd[key] += 1
                        sk = x + y
                        Ds[sk] += 1
                    Dd[0] += 1
                    sk = 2 * x
                    Ds[sk] += 1
        # Try adding elements in promising locations
        if len(a) < max_n:
            lo = min(a)
            hi = max(a)
            span = hi - lo if hi > lo else 1
            cands = [lo - 1, lo - 2, hi + 1, hi + 2]
            for _ in range(6):
                cands.append(random.randint(lo - 2 * span, hi + 2 * span))
            for x in cands:
                if time.time() > deadline:
                    break
                if x in Dd and False:
                    continue
                # check membership
                if x in a:
                    continue
                # tentatively add
                for y in a:
                    Dd[x - y] += 1
                    Dd[y - x] += 1
                    Ds[x + y] += 1
                Dd[0] += 1
                Ds[2 * x] += 1
                nn = len(a) + 1
                sc = _score_from_counts(Dd, Ds, nn)
                if sc > best + 1e-12:
                    best = sc
                    a.append(x)
                    improved = True
                else:
                    for y in a:
                        for key in (x - y, y - x):
                            Dd[key] -= 1
                            if Dd[key] == 0:
                                del Dd[key]
                        sk = x + y
                        Ds[sk] -= 1
                        if Ds[sk] == 0:
                            del Ds[sk]
                    Dd[0] -= 1
                    if Dd[0] == 0:
                        del Dd[0]
                    sk = 2 * x
                    Ds[sk] -= 1
                    if Ds[sk] == 0:
                        del Ds[sk]
        if not improved:
            break
    return sorted(set(a)), best


def solve():
    random.seed(1234567)
    deadline = time.time() + 108

    best = None
    best_score = -1.0

    # ---- Seed from two-block AP family over a sweep of L, q ----
    for L in (20, 30, 40, 50, 60, 80, 100, 120, 150, 200, 250, 300, 400, 500, 600):
        for qmul in (2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25):
            if time.time() > deadline - 20:
                break
            q = qmul * L
            a = _make_two_block(L, q)
            if len(a) > 4000:
                continue
            sc = _score(a)
            if sc > best_score:
                best_score = sc
                best = a[:]

    # ---- Seed from base+interval family ----
    sidon_seed = [0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96, 122, 147, 181, 203]
    for M in (100, 200, 400, 600, 1000):
        for k in (20, 40, 80, 160, 320, 640):
            if time.time() > deadline - 20:
                break
            a = _make_base_interval(sidon_seed, M, k)
            if len(a) > 4000:
                continue
            sc = _score(a)
            if sc > best_score:
                best_score = sc
                best = a[:]

    if best is None:
        best = _make_two_block(100, 300)

    # ---- Local search from best seed ----
    pol, psc = _local_search(best, deadline - 2)
    if psc > best_score:
        best = pol
        best_score = psc

    # ---- A few perturbed restarts ----
    while time.time() < deadline - 2:
        if best_score > 0.5:
            # perturb best
            base = list(best)
            for _ in range(random.randint(1, 4)):
                if not base:
                    break
                i = random.randrange(len(base))
                base[i] += random.randint(-3, 3)
            base = sorted(set(base))
            seed = base
        else:
            L = random.randint(30, 400)
            q = random.randint(2, 20) * L
            seed = _make_two_block(L, q)
        pol, psc = _local_search(seed, min(deadline - 1, time.time() + 15))
        if psc > best_score:
            best = pol
            best_score = psc

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
