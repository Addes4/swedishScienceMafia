import math
import time


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if nd < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _sidon_base(r):
    """Return a set of r integers with all pairwise differences distinct
    (a Sidon set / perfect difference set), via greedy search."""
    if r < 2:
        return [0]
    base = [0]
    used = {0}
    cur = 0
    while len(base) < r:
        cur += 1
        ok = True
        new_diffs = []
        for b in base:
            d1 = cur - b
            d2 = b - cur
            if d1 in used or d2 in used:
                ok = False
                break
            new_diffs.append(d1)
            new_diffs.append(d2)
        if ok:
            for d in new_diffs:
                used.add(d)
            base.append(cur)
    return base


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 115

    # Cache Sidon bases for small r.
    sidon_cache = {}
    for r in range(2, 12):
        try:
            sidon_cache[r] = _sidon_base(r)
        except Exception:
            pass

    # Family: A = X + M * [0, k)  where X is Sidon base spread out.
    # We place base elements at large multiples so cross differences stay distinct.
    candidates = []

    # Pure interval captures the sum-collapse idea: base {0} gives A = AP.
    # A longer AP -> sums collapse strongly; diffs = interval too.
    for k in (32768, 16384, 8192, 4096, 2048, 1024, 512, 256, 128, 64, 32):
        candidates.append(("ap", [0], 1, k))

    # Two-block: X small Sidon spread plus a big AP.
    for r in range(2, 8):
        X = sidon_cache.get(r)
        if not X:
            continue
        for k in (1024, 512, 256, 128, 64, 32, 16, 8):
            # Put AP far from X so it does not interfere much; base X at scale.
            candidates.append(("xap", X, 1, k))

    # Also AP as the interval factor added to a Sidon base shifted by large M.
    for r in (2, 3, 4, 5, 6):
        X = sidon_cache.get(r)
        if not X:
            continue
        for M in (1, 2, 4, 8, 16, 32):
            for k in (16, 32, 64, 128, 256, 512, 1024, 2048, 4096):
                candidates.append(("xm", X, M, k))

    def build(kind, X, M, k):
        if kind == "ap":
            return [i for i in range(k)]
        if kind == "xap":
            # Sidon base shifted far away, plus a long AP of length k.
            off = max(X) + k + 1
            a = list(X) + [off + M * i for i in range(k)]
            return a
        # kind == "xm": A = X + M*[0,k) with X placed at multiples of M*k*2
        shift = M * k + 1
        spread = []
        for i, x in enumerate(X):
            spread.append(x * shift)
        res = set()
        for s in spread:
            for j in range(k):
                res.add(s + M * j)
        # ensure the bases' APs don't overlap; use large spacing between bases
        return sorted(res)

    seen = set()
    for (kind, X, M, k) in candidates:
        if time.time() > deadline:
            break
        try:
            a = build(kind, X, M, k)
        except Exception:
            continue
        a = sorted(set(a))
        if len(a) < 2 or len(a) > 4000:
            continue
        key = tuple(a)
        if key in seen:
            continue
        seen.add(key)
        sc = _score(a)
        if sc > best_score:
            best_score = sc
            best = a

    if best is None:
        best = [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]

    return sorted(set(int(x) for x in best))
