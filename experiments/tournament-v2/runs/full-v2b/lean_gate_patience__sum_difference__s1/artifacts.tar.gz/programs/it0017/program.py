# EVOLVE-BLOCK-START
"""Grid construction: A = X + M*Y, difference-rich X and Y, fast numpy scorer."""
import math
import random
import time
import numpy as np


def _score_np(arr):
    n = arr.size
    if n < 2:
        return 0.0
    d = np.subtract.outer(arr, arr).ravel()
    s = np.add.outer(arr, arr).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score_list(a):
    a = list(set(a))
    return _score_np(np.array(a, dtype=np.int64))


def _golomb(n, span):
    marks = [0]
    used = {0}
    cand = 1
    while len(marks) < n and cand <= span:
        ok = True
        for m in marks:
            if abs(cand - m) in used:
                ok = False
                break
        if ok:
            for m in marks:
                used.add(abs(cand - m))
            marks.append(cand)
        cand += 1
    return marks


def solve():
    deadline = time.time() + 105
    best = None
    best_score = -1.0

    # Grid construction: A = { x + M*y : x in X, y in Y }
    # Choose X rich in differences, Y small, M large to spread y-axis.
    for nX in range(2, 40):
        if time.time() > deadline:
            break
        X = _golomb(nX, 40 * nX)
        if len(X) < nX:
            continue
        for nY in range(2, 30):
            for M in (50, 100, 200, 500, 1000, 3000):
                Y = list(range(nY))
                # or a golomb Y for richer differences
                Y = _golomb(nY, 30 * nY)
                if len(Y) < nY:
                    continue
                arr = np.array([x + M * y for y in Y for x in X], dtype=np.int64)
                sc = _score_np(arr)
                if sc > best_score:
                    best_score = sc
                    best = arr.copy()
            if time.time() > deadline:
                break

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)
        best_score = _score_np(best)

    # Targeted hill-climb on the grid construction parameters only (keep structure).
    cur = best.copy()
    cur_score = best_score
    it = 0
    while time.time() < deadline and it < 4000:
        it += 1
        cand = cur.copy()
        k = random.randint(1, max(1, len(cand) // 20))
        idx = np.random.randint(0, len(cand), size=k)
        cand[idx] += np.random.randint(-3, 4, size=k).astype(np.int64)
        cand = np.unique(cand)
        if cand.size < 2:
            continue
        sc = _score_np(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand.copy(), sc

    return sorted(int(v) for v in np.unique(best))
# EVOLVE-BLOCK-END

