# EVOLVE-BLOCK-START
"""Grid construction A = X + M*Y, tuned multiplier + structured coordinate descent."""
import math
import time
import numpy as np


def _score_arr(arr):
    """Exact score for a 1D int64 array of distinct ints."""
    n = arr.size
    if n < 2:
        return 0.0
    d = np.subtract.outer(arr, arr).ravel()
    s = np.add.outer(arr, arr).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _golomb(n, span):
    marks = [0]
    used = {0}
    cand = 1
    while len(marks) < n and cand <= span:
        ok = True
        for m in marks:
            if abs(cand - m) in used:
                ok = False
                break
        if ok:
            for m in marks:
                used.add(abs(cand - m))
            marks.append(cand)
        cand += 1
    return marks


def _grid(X, Y, M):
    a = np.array([x + M * y for y in Y for x in X], dtype=np.int64)
    return np.unique(a)


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    gol_cache = {}

    def gol(n, span):
        key = (n, span)
        if key not in gol_cache:
            gol_cache[key] = _golomb(n, span)
        return gol_cache[key]

    # Coarse scan over grid families.
    for nX in range(2, 50):
        if time.time() > deadline:
            break
        X = gol(nX, 70 * nX)
        if len(X) < nX:
            continue
        Xa = np.array(X, dtype=np.int64)
        for nY in range(2, 30):
            for Y in (list(range(nY)), gol(nY, 45 * nY)):
                if len(Y) < 2:
                    continue
                Ya = np.array(Y, dtype=np.int64)
                for M in (30, 60, 100, 150, 220, 300, 450, 650, 900,
                          1300, 1800, 2600, 3600, 5000, 8000, 13000, 21000):
                    arr = np.unique((Xa[None, :] + M * Ya[:, None]).ravel())
                    if arr.size < 2:
                        continue
                    sc = _score_arr(arr)
                    if sc > best_score:
                        best_score = sc
                        best = arr.copy()
            if time.time() > deadline:
                break

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)
        best_score = _score_arr(best)

    # Structured coordinate descent: try replacing individual rows/columns by
    # shifting element positions while keeping the product structure.
    cur = best.copy()
    cur_score = best_score
    n = cur.size
    maxv = int(np.max(np.abs(cur))) + 1

    def try_shift(arr, i, delta):
        cand = arr.copy()
        cand[i] += delta
        cand = np.unique(cand)
        if cand.size < 2:
            return None, -1.0
        sc = _score_arr(cand)
        return cand, sc

    it = 0
    step = 1
    while time.time() < deadline and it < 200000:
        it += 1
        improved = False
        idxs = np.random.permutation(n)
        for i in idxs:
            if time.time() > deadline:
                break
            base = cur[i]
            for delta in (step, -step, 2 * step, -2 * step):
                cand, sc = try_shift(cur, i, delta)
                if cand is not None and sc > cur_score:
                    cur, cur_score = cand, sc
                    if sc > best_score:
                        best, best_score = cand.copy(), sc
                    improved = True
                    break
        if not improved:
            step *= 2
            if step > maxv:
                break

    return sorted(int(v) for v in np.unique(best))
# EVOLVE-BLOCK-END
