# EVOLVE-BLOCK-START
"""Constructive: union of shifted short arithmetic progressions at Golomb-ruler offsets,
then a greedy asymmetric local polish (add/remove/shift) using fast incremental scoring."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    L = list(a)
    for i in range(n):
        xi = L[i]
        for j in range(i, n):
            xj = L[j]
            sums.add(xi + xj)
            if i != j:
                diffs.add(xi - xj)
                diffs.add(xj - xi)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _diffs_sums(a):
    a = set(a)
    L = list(a)
    n = len(L)
    diffs = set()
    sums = set()
    for i in range(n):
        xi = L[i]
        for j in range(i, n):
            xj = L[j]
            sums.add(xi + xj)
            if i != j:
                diffs.add(xi - xj)
                diffs.add(xj - xi)
    return diffs, sums


def golomb_marks(k, maxv):
    """Greedy Golomb-ruler-like marks: each new mark far from all differences."""
    marks = [0]
    used = {0}
    while len(marks) < k:
        # pick candidate minimising number of collisions with existing diff set
        best_c = None
        best_cost = None
        for c in range(marks[-1] + 1, maxv + 1):
            cost = 0
            for m in marks:
                if abs(c - m) in used:
                    cost += 1
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_c = c
                if cost == 0:
                    break
        c = best_c
        newd = {abs(c - m) for m in marks}
        used |= newd
        used.add(c)
        marks.append(c)
    return marks


def build_clusters(budget=70):
    """Union of short APs at Golomb offsets."""
    best = None
    best_score = -1.0
    rnd = random.Random(12345)
    for trials in range(40):
        k = rnd.randint(3, 6)          # number of clusters
        clen = rnd.randint(3, 8)       # cluster length
        step = rnd.randint(1, 3)       # AP step
        span = k * clen * step * 4 + 50
        offs = golomb_marks(k, span)
        base = []
        for o in offs:
            for t in range(clen):
                base.append(o * 3 + t * step)
        if len(base) > budget:
            base = base[:budget]
        s = _score(base)
        if s > best_score:
            best_score = s
            best = base
    return best


def polish(a, deadline):
    """Greedy asymmetric local search: try add / remove / shift one element."""
    cur = sorted(set(a))
    cur_score = _score(cur)

    def try_list(cand):
        nonlocal cur, cur_score
        cand = sorted(set(cand))
        if len(cand) < 2:
            return
        s = _score(cand)
        if s > cur_score:
            cur = cand
            cur_score = s

    rnd = random.Random(999)
    while time.time() < deadline:
        # removal pass
        improved = False
        for i in range(len(cur)):
            cand = cur[:i] + cur[i + 1:]
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            s = _score(cand)
            if s > cur_score:
                cur, cur_score, improved = cand, s, True
                break
        if improved:
            continue
        # shift pass
        for i in range(len(cur)):
            for delta in (-3, -2, -1, 1, 2, 3):
                cand = cur[:]
                cand[i] += delta
                s = _score(cand)
                if s > cur_score:
                    cur, cur_score, improved = sorted(set(cand)), s, True
                    break
            if improved:
                break
        if improved:
            continue
        # add pass
        lo, hi = min(cur), max(cur)
        cands = set()
        for _ in range(30):
            cands.add(rnd.randint(lo - 10, hi + 10))
        # also try midpoints between far-apart elements
        for i in range(len(cur)):
            for j in range(i + 1, len(cur)):
                cands.add((cur[i] + cur[j]) // 2)
                cands.add((cur[i] + cur[j]) // 2 + 1)
        for c in cands:
            if c in cur:
                continue
            cand = cur + [c]
            s = _score(cand)
            if s > cur_score:
                cur, cur_score, improved = sorted(set(cand)), s, True
                break
        if not improved:
            # random restart-ish perturbation around best
            cand = cur[:]
            for _ in range(rnd.randint(1, 3)):
                i = rnd.randrange(len(cand))
                cand[i] += rnd.randint(-5, 5)
            cand = sorted(set(cand))
            if len(cand) >= 2 and _score(cand) > cur_score:
                cur = cand
                cur_score = _score(cand)
            else:
                break
    return cur


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # constructive seeds
    seeds = [build_clusters()]
    rnd = random.Random(7)
    for _ in range(6):
        k = rnd.randint(3, 7)
        clen = rnd.randint(2, 9)
        step = rnd.randint(1, 4)
        span = k * clen * step * 4 + 60
        offs = golomb_marks(k, span)
        base = []
        for o in offs:
            for t in range(clen):
                base.append(o * 3 + t * step)
        seeds.append(base)

    for seed in seeds:
        if time.time() > deadline:
            break
        pol = polish(seed, min(deadline, time.time() + 20))
        s = _score(pol)
        if s > best_score:
            best_score = s
            best = pol

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    best = sorted(set(int(x) for x in best))
    # final safety: dedupe and bounds
    if len(best) > 4000:
        best = best[:4000]
    best = [x for x in best if abs(x) <= 10 ** 15]
    return best
# EVOLVE-BLOCK-END

if __name__ == "__main__":
    res = solve()
    print(len(res), _score(res))
