# EVOLVE-BLOCK-START
"""Constructive search: union of translated AP clusters at Golomb-like offsets,
balancing a small sum set against a large difference set. Uses a fast numpy
exact scorer for many more candidate evaluations."""
import math
import random
import time

import numpy as np


def _score_fast(arr):
    """Exact score for a numpy int64 array of distinct values."""
    n = arr.size
    if n < 2:
        return 0.0
    d = np.unique(arr[:, None] - arr[None, :])
    s = np.unique(arr[:, None] + arr[None, :])
    nd = d.size
    ns = s.size
    if nd < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _golomb(n):
    marks = [0]
    used = {0}
    while len(marks) < n:
        cand = marks[-1] + 1
        while True:
            ok = True
            for m in marks:
                d = cand - m
                if d in used or d == 0:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        for m in marks:
            used.add(cand - m)
        marks.append(cand)
    return marks


def _build(clusters, width, offset_scale):
    offs = _golomb(clusters)
    offs = [o * offset_scale for o in offs]
    A = []
    for o in offs:
        for k in range(width):
            A.append(o + k)
    return A


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 60

    # structured candidates over a wide parameter space
    for clusters in range(2, 60):
        goff = _golomb(clusters)
        span = goff[-1] if goff[-1] > 0 else 1
        for width in range(2, 60):
            n = clusters * width
            if n < 2 or n > 4000:
                continue
            scale = width * (span + clusters)
            A = _build(clusters, width, scale)
            s = _score_fast(np.array(sorted(set(A)), dtype=np.int64))
            if s > best_score:
                best_score, best = s, sorted(set(A))
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    if best is None:
        best = [0, 1, 2, 4, 8]
        best_score = _score_fast(np.array(best, dtype=np.int64))

    # local refinement with exact numpy scoring
    cur = list(best)
    improve_deadline = time.time() + 50
    while time.time() < improve_deadline:
        cand = cur[:]
        if random.random() < 0.7:
            # add a few far-apart elements
            span = max(cur) - min(cur) + 1
            for _ in range(random.randint(1, 3)):
                cand.append(random.randint(min(cur) - span, max(cur) + span))
        else:
            # remove one element
            if len(cand) > 4:
                cand.pop(random.randrange(len(cand)))
        cand = sorted(set(cand))
        if len(cand) > 4000 or len(cand) < 3:
            continue
        s = _score_fast(np.array(cand, dtype=np.int64))
        if s >= best_score:
            best_score, best, cur = s, cand[:], cand

    return sorted(set(best))
# EVOLVE-BLOCK-END
