# EVOLVE-BLOCK-START
"""Constructive + fast incremental local search for difference-dominant sets.

We maintain, for the current set A (a dict value->count, all counts 0/1):
  dcount[d] = number of ordered pairs (a,b), a!=b, with a-b=d   (d>0 only)
  scount[s] = number of unordered pairs (a<=b) with a+b=s
Then |A-A| = number of d>0 with dcount>0  (times 2, symmetric)
     |A+A| = number of s with scount>0
Incremental updates let us try add/remove/shift cheaply.
"""
import math
import random
import time


def _full(a):
    a = list(a)
    n = len(a)
    dcount = {}
    scount = {}
    for i in range(n):
        xi = a[i]
        for j in range(i, n):
            xj = a[j]
            s = xi + xj
            scount[s] = scount.get(s, 0) + 1
            if i != j:
                d = xi - xj if xi > xj else xj - xi
                dcount[d] = dcount.get(d, 0) + 2
    return dcount, scount


def _score_from(dcount, scount, n):
    if n < 2:
        return 0.0
    nd = sum(1 for v in dcount.values() if v > 0)
    ns = sum(1 for v in scount.values() if v > 0)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _add(a, x, dcount, scount):
    """Add x to the set (x not present). Mutates dcount/scount. Returns nothing."""
    for y in list(a):
        s = x + y
        scount[s] = scount.get(s, 0) + 1
        d = x - y if x > y else y - x
        dcount[d] = dcount.get(d, 0) + 2
    s = x + x
    scount[s] = scount.get(s, 0) + 1
    a.add(x)


def _remove(a, x, dcount, scount):
    """Remove x (present)."""
    a.discard(x)
    for y in list(a):
        s = x + y
        scount[s] -= 1
        d = x - y if x > y else y - x
        dcount[d] -= 2
    s = x + x
    scount[s] -= 1


def _score_quick(a):
    dcount, scount = _full(a)
    return _score_from(dcount, scount, len(a))


def golomb_marks(k, maxv):
    marks = [0]
    used = {0}
    while len(marks) < k:
        best_c = None
        best_cost = None
        for c in range(marks[-1] + 1, maxv + 1):
            cost = 0
            for m in marks:
                if (c - m) in used:
                    cost += 1
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_c = c
                if cost == 0:
                    break
            if c - marks[-1] > 60 and best_cost == 0:
                break
        c = best_c
        if c is None:
            break
        newd = {abs(c - m) for m in marks}
        used |= newd
        marks.append(c)
    return marks


def build_seeds():
    seeds = []
    rnd = random.Random(2024)
    # Family 1: Golomb offsets * step + short AP clusters (difference-rich, AP keeps sums low)
    for _ in range(10):
        k = rnd.randint(4, 9)
        clen = rnd.randint(2, 6)
        step = rnd.randint(1, 3)
        span = k * clen * step * 3 + 80
        offs = golomb_marks(k, span)
        base = []
        for o in offs:
            for t in range(clen):
                base.append(o * step + t)
        seeds.append(base)
    # Family 2: pure Golomb ruler (max differences, but sums also large)
    for _ in range(4):
        seeds.append(golomb_marks(rnd.randint(8, 14), 400))
    # Family 3: AP (sums tiny) as a starting scaffold
    seeds.append(list(range(0, 10)))
    return seeds


def _try_add_best(a, dcount, scount, cur, rnd, span, tries=40):
    best_gain = 0.0
    best_x = None
    lo, hi = min(a), max(a)
    cands = set()
    for _ in range(tries):
        cands.add(rnd.randint(lo - span, hi + span))
    for x in cands:
        if x in a:
            continue
        # incremental
        a.add(x)
        for y in list(a):
            if y == x:
                continue
            s = x + y
            scount[s] = scount.get(s, 0) + 1
            d = x - y if x > y else y - x
            dcount[d] = dcount.get(d, 0) + 2
        scount[x + x] = scount.get(x + x, 0) + 1
        s2 = _score_from(dcount, scount, len(a))
        # undo
        a.discard(x)
        for y in list(a):
            s = x + y
            scount[s] -= 1
            d = x - y if x > y else y - x
            dcount[d] -= 2
        scount[x + x] -= 1
        if s2 > cur:
            g = s2 - cur
            if g > best_gain:
                best_gain = g
                best_x = x
    return best_x, best_gain


def _try_remove_best(a, dcount, scount, cur):
    best_gain = 0.0
    best_x = None
    for x in list(a):
        _remove(a, x, dcount, scount)
        s2 = _score_from(dcount, scount, len(a))
        if s2 > cur:
            g = s2 - cur
            if g > best_gain:
                best_gain = g
                best_x = x
        _add(a, x, dcount, scount)
    return best_x, best_gain


def polish(seed, deadline, rnd):
    a = set(int(x) for x in seed)
    if len(a) < 2:
        return list(a)
    dcount, scount = _full(a)
    cur = _score_from(dcount, scount, len(a))
    span = max(8, (max(a) - min(a)) // max(1, len(a)) + 5)

    while time.time() < deadline:
        improved = False
        # greedy add
        while len(a) < 4000:
            bx, bg = _try_add_best(a, dcount, scount, cur, rnd, span, tries=30)
            if bx is not None:
                _add(a, bx, dcount, scount)
                dcount2, scount2 = dcount, scount
                cur = _score_from(dcount, scount, len(a))
                improved = True
            else:
                break
        # greedy remove
        bx, bg = _try_remove_best(a, dcount, scount, cur)
        if bx is not None:
            _remove(a, bx, dcount, scount)
            cur = _score_from(dcount, scount, len(a))
            improved = True
        if not improved:
            # perturbation
            k = rnd.randint(1, 3)
            for _ in range(k):
                x = rnd.choice(list(a))
                _remove(a, x, dcount, scount)
                nx = x + rnd.randint(-span, span)
                if nx in a:
                    _add(a, x, dcount, scount)
                else:
                    _add(a, nx, dcount, scount)
            cur = _score_from(dcount, scount, len(a))
            # if worse than before perturbation kept going anyway (diversify)
    return list(a)


def solve():
    deadline = time.time() + 110
    rnd = random.Random(31337)
    best = None
    best_score = -1.0
    seeds = build_seeds()
    # shuffle for diversity
    rnd.shuffle(seeds)
    for i, seed in enumerate(seeds):
        if time.time() > deadline:
            break
        remaining = deadline - time.time()
        budget = min(remaining, max(5.0, remaining / max(1, len(seeds) - i)))
        pol = polish(seed, time.time() + budget, rnd)
        s = _score_quick(pol)
        if s > best_score:
            best_score = s
            best = pol

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    best = [x for x in best if abs(x) <= 10 ** 15]
    return best
# EVOLVE-BLOCK-END


if __name__ == "__main__":
    res = solve()
    print(len(res), _score_quick(res))
