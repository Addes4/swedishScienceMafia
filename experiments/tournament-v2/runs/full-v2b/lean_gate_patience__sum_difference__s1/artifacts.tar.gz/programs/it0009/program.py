# EVOLVE-BLOCK-START
"""Union of many translated same-step AP clusters placed at Golomb-like offsets;
fast numpy scoring plus a bounded parameter sweep."""
import math
import time
import numpy as np


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    arr = np.asarray(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _golomb_fast(n):
    """Greedy approximate Golomb ruler with n marks (largest-gap avoiding repeat diffs)."""
    marks = [0]
    used = {0}
    while len(marks) < n:
        cand = marks[-1] + 1
        while True:
            ok = True
            for m in marks:
                d = cand - m
                if d in used:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        for m in marks:
            used.add(cand - m)
        marks.append(cand)
    return marks


def _build(clusters, width, scale):
    offs = _golomb_fast(clusters)
    offs = [o * scale for o in offs]
    A = []
    for o in offs:
        for k in range(width):
            A.append(o + k)
    return A


def solve():
    best = [0, 1, 2, 4, 8]
    best_score = -1.0
    deadline = time.time() + 100

    golomb_cache = {}

    def gol(n):
        if n not in golomb_cache:
            golomb_cache[n] = _golomb_fast(n)
        return golomb_cache[n]

    # wide sweep over clusters, width, scale
    for clusters in range(2, 60):
        g = gol(clusters)
        span = g[-1] if len(g) > 1 else 1
        for width in range(2, 50):
            n = clusters * width
            if n < 2 or n > 4000:
                continue
            for scale in (width, width * 2, width * 4, width * 8, max(1, span)):
                offs = [o * scale for o in g]
                A = []
                for o in offs:
                    for k in range(width):
                        A.append(o + k)
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A[:]
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    return sorted(set(best))
# EVOLVE-BLOCK-END
