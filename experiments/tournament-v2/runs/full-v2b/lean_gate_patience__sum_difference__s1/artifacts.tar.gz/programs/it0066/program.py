# EVOLVE-BLOCK-START
"""Multi-cluster construction with exact scoring.

Idea: A = union_{i} (t_i + B) where B is a short arithmetic progression
{0..b-1} and the offsets t_i form a Sidon set (all pairwise differences
distinct) scaled by a large gap G.

* A + A is contained in  union_{i<=j} (t_i + t_j + {0..2b-2}),
  i.e. only C(g+1,2) short intervals => |A+A| ~ g^2 * 2b (not g^2 * 4b^2).
* A - A picks up cross differences t_i - t_j + (B - B); with Sidon offsets
  scaled by G the shifted difference blocks barely overlap in the interior,
  so |A-A| ~ g^2 * (b-1)^2 + ... much larger.

We search over (b, g, G) and the offset set, scoring exactly.
"""
import math
import time

N_LIMIT = 4000
V_LIMIT = 10 ** 15


def _exact_counts(a):
    """Return (|A-A|, |A+A|) using a dict of multiplicity-free membership."""
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _score_list(a):
    if len(a) < 2:
        return 0.0, 0, 0
    nd, ns = _exact_counts(a)
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100, nd, ns


def _golomb_offsets(g):
    """Offsets 0 = t_0 < t_1 < ... < t_{g-1} with distinct pairwise diffs,
    greedily built (Sidon set)."""
    offs = [0]
    used = {0}
    cand = 1
    while len(offs) < g and cand < 10 ** 6:
        ok = True
        for o in offs:
            d = cand - o
            if d in used:
                ok = False
                break
        if ok:
            for o in offs:
                used.add(cand - o)
                used.add(o)
            offs.append(cand)
        cand += 1
    return offs


def _build(b, g, G, offsets):
    base = list(range(b))
    A = []
    for t in offsets[:g]:
        off = t * G
        for x in base:
            A.append(off + x)
    return A


def _polish_offsets(A, b, g, G, deadline):
    """Greedily adjust each offset by +/-1 unit of G to improve score."""
    cur = list(A)
    sc, _, _ = _score_list(cur)
    improved = True
    while improved and time.time() < deadline:
        improved = False
        # try shifting each cluster (cluster i occupies sorted positions b*i..)
        base_sorted = sorted(cur)
        # reconstruct clusters by contiguous runs of length b
        for i in range(g):
            for d in (1, -1):
                cand = list(cur)
                lo = i * b
                hi = lo + b
                if hi > len(cand):
                    continue
                for k in range(lo, hi):
                    cand[k] += d * G
                s, _, _ = _score_list(cand)
                if s > sc + 1e-12:
                    cur = cand
                    sc = s
                    improved = True
                    break
            if improved:
                break
    return sorted(cur), sc


def solve():
    t_end = time.time() + 112.0
    best = None
    best_sc = -1.0

    # Candidate (b, g) pairs; keep n = b*g <= 4000.
    pairs = []
    for b in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 24, 32):
        for g in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 30, 50, 80, 120, 200):
            if b * g <= N_LIMIT and g >= 2:
                pairs.append((b, g))

    offs_cache = {}

    # Sweep G values broadly.
    for (b, g) in pairs:
        if time.time() > t_end:
            break
        if g not in offs_cache:
            offs_cache[g] = _golomb_offsets(g)
        offsets = offs_cache[g]
        if len(offsets) < g:
            continue
        span = offsets[g - 1] if g > 1 else 1
        for G in (b, 2 * b, 3 * b, 5 * b, 8 * b, 12 * b, 20 * b, 40 * b):
            A = _build(b, g, G, offsets)
            if min(A) < -V_LIMIT or max(A) > V_LIMIT:
                continue
            sc, nd, ns = _score_list(A)
            if sc > best_sc:
                best_sc = sc
                best = list(A)

    # Polish the best candidates' offsets.
    if best is not None:
        # find approx (b, g) of best by trying to detect
        for (b, g) in pairs:
            if time.time() > t_end:
                break
            if g not in offs_cache:
                offs_cache[g] = _golomb_offsets(g)
            offsets = offs_cache[g]
            if len(offsets) < g:
                continue
            for G in (b, 2 * b, 3 * b, 5 * b, 8 * b, 12 * b, 20 * b):
                A = _build(b, g, G, offsets)
                sc, _, _ = _score_list(A)
                if sc < best_sc - 0.02:
                    continue
                rem = t_end - time.time()
                if rem <= 0:
                    break
                cand, csc = _polish_offsets(A, b, g, G,
                                            time.time() + min(rem, 3.0))
                if csc > best_sc:
                    best_sc = csc
                    best = cand

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    best = sorted(set(int(x) for x in best))
    if len(best) > N_LIMIT:
        best = best[:N_LIMIT]
    best = [max(-V_LIMIT, min(V_LIMIT, x)) for x in best]
    return best
# EVOLVE-BLOCK-END
