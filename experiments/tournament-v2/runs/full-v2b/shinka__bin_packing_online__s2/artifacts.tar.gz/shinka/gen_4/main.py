# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    base = -(bins - item).astype(np.float64)
    # Prefer bins that become exactly full (reinforce perfect fits).
    base += 0.01 * (bins == item)
    # Prefer already-used bins over opening a fresh bin, breaking ties toward
    # consolidation without overriding genuine best-fit choices (residuals are
    # integers, so the 0.001 bonus never changes a real capacity comparison).
    base += 0.001 * (bins < 100)
    return base
# EVOLVE-BLOCK-END