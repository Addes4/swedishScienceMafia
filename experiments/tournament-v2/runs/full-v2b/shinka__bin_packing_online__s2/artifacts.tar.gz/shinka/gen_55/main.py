# EVOLVE-BLOCK-START
"""Best-Fit with a bounded, distribution-aware residual tie-breaker.

The returned priority is strict Best-Fit (smallest integer residual wins)
plus a secondary term of magnitude < 0.5, so it can only break ties among
bins sharing the same minimal integer slack and can never override a
genuine capacity difference.  The tie-breaker slightly prefers a leftover
close to the typical future item size for this Weibull-shaped distribution
(mean ~40), keeping the bin useful without disturbing Best-Fit ordering.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Primary term: strict Best-Fit (smallest residual wins).
    score = -residual

    # Secondary term: bounded (< 0.5) tie-breaker that prefers a leftover
    # close to the typical next item size, so tied bins stay useful.
    score += 0.5 * np.exp(-((residual - 35.0) ** 2) / (2.0 * 15.0 ** 2))
    return score
# EVOLVE-BLOCK-END