# EVOLVE-BLOCK-START
"""Harmonic-residual best-fit with a distribution-aware fillability tie-break.

Primary key (unchanged, provably safe): strict best fit — smallest residual
after placing the item wins. All tie-breakers are strictly sub-unit, so they
can only reorder bins with *identical* integer residual and can never override
the best-fit ordering.

New idea — a "fillability potential" used ONLY as a tie-break:
Given the item-size distribution (Weibull-shaped, mean ~40, range 1..100),
certain residual capacities are much more likely to be exactly consumed by a
short sequence of upcoming items. We reward residuals that sit on a
"harmonic ladder" of typical partial sums (multiples/combinations of the
mean ~40, plus the 100 boundary) and penalize residuals that fall in the
"dead zone" just below a typical item size (30-39, 70-79), where the next
typical item cannot fit and the residual tends to be wasted.

We additionally keep a small online-learned histogram of residuals that were
later observed to be exactly filled, and bias toward those values. This is
stateful but distribution-driven, not instance-tuned.

Everything is bounded well below the integer residual gap K=1000 so best-fit
is never violated.
"""
import numpy as np


_K = 1000.0  # integer residual gap always dominates all tie-breaks


# --- static fillability potential from the known distribution -------------
# Residuals that are "good" (easy to exactly fill with a few future items).
_GOOD_RESIDUALS = np.array(
    [0, 20, 30, 40, 50, 60, 70, 80, 90, 95, 100], dtype=np.int64
)
# Residuals in the "dead zone" just below a typical item size: the next
# typical (~40) item cannot fit and the slack is easily wasted.
_DEAD_RESIDUALS = np.array(
    [31, 32, 33, 34, 35, 36, 37, 38, 39,
     71, 72, 73, 74, 75, 76, 77, 78, 79], dtype=np.int64
)


# --- tiny online-learned bias --------------------------------------------
# Histogram of residuals that were later exactly filled. Updated lazily by
# comparing the previous arrival's chosen residual against the current item.
_hist = np.zeros(101, dtype=np.float64)
_prev_residual = -1


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    global _prev_residual

    residual = bins - item  # >= 0 by contract

    # --- primary key: strict best fit ------------------------------------
    score = -_K * residual.astype(np.float64)

    # --- tie-break 1: fillability potential (static, distribution-derived)
    # Good residuals get a small bonus; dead-zone residuals a small penalty.
    good = np.isin(residual, _GOOD_RESIDUALS).astype(np.float64)
    dead = np.isin(residual, _DEAD_RESIDUALS).astype(np.float64)
    score = score + 0.30 * good - 0.20 * dead

    # --- tie-break 2: online-learned fill bias ---------------------------
    # If a residual value has historically been exactly filled, prefer it.
    if _hist.any():
        # Normalize to a bounded [0,1) contribution.
        h = _hist[residual]
        hmax = _hist.max()
        if hmax > 0:
            score = score + 0.25 * (h / hmax)

    # --- tie-break 3: don't open a fresh bin on an exact-residual tie ----
    score = score - 0.05 * (bins == 100)

    # --- update online histogram lazily ----------------------------------
    # If the previous chosen residual equals the current item, that residual
    # was exactly filled -> reward it.
    if _prev_residual >= 0 and _prev_residual == int(item):
        _hist[_prev_residual] += 1.0
        # Mild decay so the histogram adapts to the stream.
        _hist *= 0.999

    # Remember this arrival's item so the next call can detect an exact fill
    # of whatever residual we are about to consume. We don't know the chosen
    # bin here, so approximate by tracking the item size itself (a residual
    # equal to a future item is exactly what we want to reward).
    _prev_residual = int(item)

    return score
# EVOLVE-BLOCK-END