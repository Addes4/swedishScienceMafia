# EVOLVE-BLOCK-START
"""Distribution-aware best-fit via a precomputed residual preference profile.

Structure:
  * `_build_profile()` constructs a length-101 table P[r] giving the desirability
    of leaving residual capacity r (0..100) after placing the current item.
  * `priority(item, bins)` gathers P[bins - item] and adds a tiny deterministic
    fill-fraction tie-break so equal residuals resolve to the fuller bin.

The dominant term is strict best-fit (monotonically decreasing in residual);
all other effects are bounded well below 1.0 so they only decide near-ties.
"""
import numpy as np


# Running statistics of the item stream (updated incrementally, Welford-style).
_MEAN = 40.0
_VAR = 400.0
_N = 0
_LAST_PROFILE = None
_LAST_MEAN = None
_LAST_STD = None


def _update_stats(item):
    """Incremental mean/variance update (no future information used)."""
    global _MEAN, _VAR, _N
    _N += 1
    delta = item - _MEAN
    _MEAN += delta / _N
    _VAR += delta * (item - _MEAN)


def _build_profile(mean, std):
    """Return array P of length 101: P[r] = score for leaving residual r.

    The useful-band shape is adaptive: instead of a single wide bump, use two
    narrow bumps whose widths scale with the running std of the item stream.
    """
    r = np.arange(101, dtype=np.float64)

    # Dominant term: strict best-fit. Prefer smallest residual.
    base = -r

    # Exact-fit bonus: residual ~0 means the bin is perfectly packed.
    exact = (r <= 0.5).astype(np.float64)

    # Adaptive narrow bumps: strong core inside mean +/- 0.25*std,
    # weaker shoulder inside mean +/- 0.75*std.
    core = (np.abs(r - mean) <= 0.25 * std).astype(np.float64)
    shoulder = (np.abs(r - mean) <= 0.75 * std).astype(np.float64)
    bump = 0.4 * core + 0.2 * shoulder

    # Dead zone: residuals near a small fraction of the mean are hard to reuse.
    dead_center = max(2.0, 0.15 * mean)
    dead_width = max(3.0, 0.15 * mean)
    dead = np.maximum(0.0, 1.0 - np.abs(r - dead_center) / dead_width)

    # Tiny sliver: residuals 1..4 essentially never refillable.
    sliver = ((r >= 1.0) & (r <= 4.0)).astype(np.float64)

    return (base
            + 0.5 * exact
            + bump
            - 0.3 * dead
            - 0.2 * sliver)


def _get_profile():
    """Rebuild the profile only when mean/std have moved enough to matter."""
    global _LAST_PROFILE, _LAST_MEAN, _LAST_STD
    std = float(np.sqrt(max(_VAR / max(_N, 1), 1.0)))
    if (_LAST_PROFILE is None
            or abs(_MEAN - _LAST_MEAN) > 0.5
            or abs(std - _LAST_STD) > 0.5):
        _LAST_PROFILE = _build_profile(_MEAN, std)
        _LAST_MEAN = _MEAN
        _LAST_STD = std
    return _LAST_PROFILE


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    profile = _get_profile()
    residual = (bins - item).astype(np.int64)
    # Gather precomputed residual desirability.
    score = profile[residual]

    # Fresh-bin penalty: opening a brand-new bin is slightly discouraged.
    score = score - 0.25 * (bins == 100)

    # Deterministic tie-break: among equal residuals, prefer the fuller bin
    # (smaller remaining capacity -> higher fill fraction). Bounded << 1.0.
    score = score + 1e-3 * (bins.astype(np.float64) / 100.0)

    # Update running statistics AFTER scoring this item.
    _update_stats(int(item))

    return score
# EVOLVE-BLOCK-END