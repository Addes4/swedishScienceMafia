# EVOLVE-BLOCK-START
"""Strict best-fit with deterministic tie-breaking.

Rule:
  - Primary key: strict best fit. Prefer the bin whose residual after
    placing the item is smallest (tightest packing).
  - Tie-break: the harness's "highest score, first on ties" already
    implements lowest-index preference among equal scores, so equal
    residuals resolve to the lowest bin index deterministically.
  - A single sub-unit penalty discourages opening a fresh bin when an
    already-open bin offers the same residual.

All sub-unit terms are bounded well below the integer residual gap
K = 1000.0, so they can only resolve exact ties and never override the
strict best-fit ordering. No randomness, no state, no jitter.
"""
import collections
import numpy as np


# Scale factor: any integer difference in residual (>= 1) dominates all
# sub-unit tie-breakers below, preserving "tighter fit always wins".
_K = 1000.0

# Bounded history of recently seen item sizes, used for a data-driven
# tie-break that prefers residuals exactly matching a modal upcoming size.
_recent = collections.deque(maxlen=64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Primary key: strict best fit (smallest residual wins).
    score = -_K * residual.astype(np.float64)

    # Sub-unit tie-breaker: prefer an already-open bin over opening a
    # fresh one. Residual == 100 only occurs for empty bins; this term
    # only fires on exact-residual ties and is bounded well below _K.
    score -= 0.5 * (bins == 100)

    # Data-driven tie-break: prefer bins whose exact residual matches a
    # modal recent item size, since such a bin is more likely to be exactly
    # filled by an upcoming item. Bounded well below _K so it only resolves
    # integer-equal residual ties without overriding best-fit ordering.
    _recent.append(int(item))
    if len(_recent) >= 8:
        counts = {}
        for s in _recent:
            counts[s] = counts.get(s, 0) + 1
        max_c = max(counts.values())
        if max_c >= 2:
            modal = np.array(
                [s for s, c in counts.items() if c == max_c], dtype=np.int64
            )
            score = score + 0.4 * np.isin(residual, modal).astype(np.float64)

    return score
# EVOLVE-BLOCK-END