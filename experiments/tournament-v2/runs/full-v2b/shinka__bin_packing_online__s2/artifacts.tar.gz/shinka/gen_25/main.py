# EVOLVE-BLOCK-START
"""Best fit with residual-usefulness tie-breaking (adaptive)."""
import numpy as np

# Running estimate of the mean item size seen so far (adaptive threshold).
_mean_item = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean_item, _count
    # Update running mean of item sizes (simple incremental average).
    _count += 1
    _mean_item += (item - _mean_item) / _count

    slack = (bins - item).astype(np.float64)
    base = -slack  # Best Fit: tightest fit first.

    residual = slack  # capacity left after placing the item in this bin

    # Sub-1 tie-breakers (slack is integer, so these never override real fits):
    # 1) Prefer bins that become exactly full.
    base += 0.01 * (residual == 0)

    # 2) Residual usefulness: a residual near the mean item size is likely to be
    #    reused; a very small residual is usually wasted. Add a small bonus for
    #    residuals in a useful band around the running mean, and a tiny penalty
    #    for near-zero residuals.
    mu = _mean_item
    useful = (residual >= 0.5 * mu) & (residual <= 1.5 * mu)
    base += 0.005 * useful
    base -= 0.002 * ((residual > 0) & (residual < 0.25 * mu))

    # 3) Slight preference for already-used bins (consolidation).
    base += 0.001 * (bins < 100)

    # 4) Penalize dead-space residuals (1..4) that can rarely be refilled by any
    #    future item; this complements the useful-residual reward above. Scale
    #    the penalty by a stateless utilization signal derived from `bins` itself:
    #    as more visible bins are already in use, dead-space residuals are more
    #    costly, so the penalty grows (multiplier in [1, 2]). The coefficient
    #    therefore stays in [0.2, 0.4], well below 1.0, so it only resolves ties.
    used_frac = np.mean(bins < 100)
    base -= 0.2 * (1.0 + used_frac) * ((residual >= 1) & (residual <= 4))

    return base
# EVOLVE-BLOCK-END