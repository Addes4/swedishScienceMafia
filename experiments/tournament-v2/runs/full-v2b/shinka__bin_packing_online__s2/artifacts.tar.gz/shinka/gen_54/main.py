# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with a dual-mode tie-breaker.

Architecture
------------
The score is a strict sum of three layers, each with a well-defined job:

  L1  Capacity layer   : -(bins - item).  Dominant; encodes Best-Fit exactly.
                         Any genuine integer slack difference is decided here.
  L2  Closure layer    : sigmoid kernel centered near a small residual target.
                         Bounded in (0, 0.5).  On exact-slack ties it mildly
                         prefers bins that will be "closed off" (left with a
                         small residual), reducing long-term fragmentation.
  L3  Sweet-spot layer : sigmoid kernel centered on the *empirical* mean of
                         arriving items.  Bounded in (0, 0.4).  On exact-slack
                         ties it prefers residuals near the typical future
                         item size, so the bin stays usable.

L2 + L3 < 1.0, so together they can never override a real capacity gap.
The sigmoid (rather than Gaussian) kernel gives heavier tails, so the
tie-breaker is non-inert in the slack-differs-by-1 regime.

Running item statistics are kept in a single mutable holder updated with a
fused Welford step, minimizing per-call Python overhead.
"""
import numpy as np


class _Stats:
    __slots__ = ("n", "mean", "m2")

    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0

    def update(self, x):
        self.n += 1
        d = x - self.mean
        self.mean += d / self.n
        self.m2 += d * (x - self.mean)


_stats = _Stats()


def _sigmoid_kernel(x, center, width):
    """Bounded logistic bump in (0, 1); heavier tails than a Gaussian."""
    z = (x - center) / width
    # 1 / (1 + e^|z|) style bump: peaks at x == center, decays outward.
    az = np.abs(z)
    # clip to avoid overflow in exp
    az = np.minimum(az, 60.0)
    return 1.0 / (1.0 + np.exp(az))


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties).

    item : integer size 1..100.
    bins : numpy int64 array of remaining capacities (only fitting bins shown).
    """
    _stats.update(item)
    n = _stats.n
    mean = _stats.mean
    if n > 1:
        var = _stats.m2 / (n - 1)
        std = var ** 0.5 if var > 0.0 else 20.0
    else:
        std = 20.0

    slack = bins.astype(np.float64) - float(item)

    # --- L1: strict Best-Fit (dominant). ---
    score = -slack

    # --- L2: closure preference. Peak near a small residual (bin gets sealed). ---
    # Width is a fraction of the empirical std, floored to keep it sharp.
    close_w = 0.30 * std
    if close_w < 3.0:
        close_w = 3.0
    score += 0.45 * _sigmoid_kernel(slack, 3.0, close_w)

    # --- L3: sweet-spot preference near the empirical item mean. ---
    sweet_w = 0.60 * std
    if sweet_w < 6.0:
        sweet_w = 6.0
    score += 0.35 * _sigmoid_kernel(slack, mean, sweet_w)

    # --- Deterministic micro tie-break: prefer the fuller bin on exact ties. ---
    score += 0.001 * (100.0 - slack) / 100.0

    return score
# EVOLVE-BLOCK-END