# EVOLVE-BLOCK-START
"""Best-fit core plus a distribution-scaled sweet-spot band.

Evidence: nineteen generations of *fixed* `[35,50]` tie-breakers produced
bit-identical scores (0.962099 / 0.961184), matching pure best-fit exactly.
That means the fixed band never flipped an argmax. This edit tests whether a
band scaled to the *observed* item distribution (running mean/variance via
Welford) can be non-inert.

The bonus is kept strictly below 1.0 so it can never override a genuine
integer capacity difference; it only resolves cases where two bins' slacks
differ by exactly 1 — a regime where best-fit's index tie-break is
arbitrary and a distribution-aware leftover is plausibly better.
"""
import numpy as np

# Running statistics of arriving item sizes (Welford, O(1) per call).
_n = 0
_mean = 0.0
_m2 = 0.0


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties).

    Term 1 (dominant): best-fit slack, `-(bins - item)`.
    Term 2 (band): bonus for leftovers near the empirical item mean,
                   width scaled by the empirical std.
    Term 3 (tie-break): tiny fill-fraction preference for exact ties.
    """
    global _n, _mean, _m2
    # --- Welford update with the arriving item ---
    _n += 1
    delta = item - _mean
    _mean += delta / _n
    _m2 += delta * (item - _mean)
    if _n > 1:
        var = _m2 / (_n - 1)
        std = var ** 0.5 if var > 0.0 else 1.0
    else:
        std = 20.0  # prior width before variance is estimable

    slack = bins.astype(np.float64) - float(item)
    score = -slack  # dominant best-fit term

    # Band scaled by empirical mean and std (two nested widths).
    d = slack - _mean
    inner = np.exp(-(d * d) / (2.0 * (0.25 * std) ** 2))
    outer = np.exp(-(d * d) / (2.0 * (0.75 * std) ** 2))
    score += 0.4 * inner + 0.2 * outer  # < 1.0, cannot override integer slack

    # Deterministic tie-break among identical residuals: prefer fuller bin.
    score += 0.001 * (100.0 - slack) / 100.0
    return score
# EVOLVE-BLOCK-END