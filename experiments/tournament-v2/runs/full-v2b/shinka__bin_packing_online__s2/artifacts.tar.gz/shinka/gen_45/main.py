# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with online-learned residual reservation.

Core idea:
  * Best-Fit remains the dominant term (smallest slack wins).
  * We maintain running statistics of arriving item sizes to estimate the
    typical "large" item size, and reward bins whose leftover capacity is
    close to that typical size (so a future large item can still fit).
  * The reservation strength adapts: early on it is weak (exploration),
    later it stabilizes on the observed distribution.
  * No future information is used; only past items seen in this instance.
"""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_state = {
    "n": 0,
    # cumulative size histogram over 1..100 (index 0 unused)
    "counts": np.zeros(101, dtype=np.float64),
    # recent-window histogram (last RECENT items) for modal residual matching
    "recent": np.zeros(101, dtype=np.float64),
    "recent_q": [],
    "recent_cap": 256,
    # cached modal residual targets from the recent window
    "res_set": None,
    "res_vals": None,
    "update_every": 32,
}


def _update_stats(item):
    s = _state
    s["n"] += 1
    s["counts"][item] += 1.0
    # maintain a bounded recent-window histogram
    q = s["recent_q"]
    cap = s["recent_cap"]
    if len(q) >= cap:
        old = q.pop(0)
        s["recent"][old] -= 1.0
    q.append(item)
    s["recent"][item] += 1.0


def _refresh_residual_targets():
    """Pick a small set of *currently modal* item sizes to aim residuals at.

    Using the recent window (rather than the cumulative histogram) makes the
    targets track the stream's current mode, which is what a future item is
    most likely to be. Leaving a residual equal to a modal item size lets a
    future common item fit exactly, reducing fragmentation.
    """
    s = _state
    c = s["recent"].copy()
    c[0] = 0.0
    # pure recent frequency: modal sizes are the best residual targets
    idx = np.argsort(-c)[:4]
    vals = idx[idx > 0].astype(np.float64)
    s["res_set"] = set(int(v) for v in vals)
    s["res_vals"] = vals


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties).

    Dominant term is strict best-fit (-slack). The only place a real-valued
    term can influence the choice is among bins with *equal* integer slack,
    so we restrict adaptation to a sub-unit tie-break (<1) that prefers
    residuals matching frequent future item sizes.
    """
    _update_stats(item)
    s = _state
    # refresh the residual-target set periodically (cheap, amortized)
    if s["res_set"] is None or (s["n"] % s["update_every"] == 0):
        _refresh_residual_targets()

    slack = bins.astype(np.float64) - float(item)

    # Dominant integer best-fit term.
    score = -slack

    # Sub-unit tie-break: reward residuals equal to a currently modal item size.
    res_vals = s["res_vals"]
    if res_vals is not None and res_vals.size > 0:
        # residual after placing this item
        residual = slack
        # distance to nearest "good" residual target
        diff = np.abs(residual[:, None] - res_vals[None, :])
        nearest = diff.min(axis=1)
        # bonus in [0, 0.5): exact match gets 0.5, decays sharply with distance
        tie = 0.5 * np.exp(-(nearest ** 2) / (2.0 * 2.0 * 2.0))
        # tiny secondary term: among near-exact matches, marginally prefer a
        # slightly larger residual (less tight) to avoid over-packing tight bins.
        tie = tie + 0.05 * np.exp(-(nearest ** 2) / (2.0 * 1.0 * 1.0)) * np.minimum(
            residual, 1.0
        )
        score = score + tie

    return score
# EVOLVE-BLOCK-END