# EVOLVE-BLOCK-START
"""Best-fit with an empirical-residual-target tie-break.

Pure best-fit is the dominant term. The previous mean-aligned tie-breaker
scored identically to pure BF because its effect is confined to integer
ties. Here we make the tie-breaker target *empirically reachable* residuals:
sizes that have actually been observed as arriving items (so a future
arrival is likely to seal the bin exactly), weighted by observed frequency.

This is the online analogue of the BFD insight: BFD leaves residuals that
small late items can fill; we approximate it by preferring, among equal-slack
bins, the one whose leftover is a high-probability future item size.
"""
import numpy as np

# Running statistics (O(1) per call, no per-call allocation).
_state = {
    "n": 0,
    "counts": np.zeros(101, dtype=np.float64),  # histogram of past item sizes
    "target": None,       # cached: boolean mask over residuals 0..100
    "update_every": 64,
}


def _refresh_target():
    """Set of residuals that are likely to be matched by a future item.

    A residual r is 'reachable' if some observed item size equals r (then a
    future item of that size seals the bin). We also mark residuals that are
    the *complement* of a frequent size, since filling a bin of capacity 100
    with two items of sizes a and 100-a leaves residual 0 — so residuals near
    frequent sizes are more useful than arbitrary ones. Weight by frequency.
    """
    s = _state
    c = s["counts"]
    total = c.sum()
    if total <= 0:
        s["target"] = np.zeros(101, dtype=np.float64)
        return
    freq = c / total
    # Reachability score for a residual r: probability that a future item
    # has size exactly r (seals immediately), plus a small contribution for
    # r being large enough to hold a common small item.
    score_r = freq.copy()
    score_r[0] = 0.0
    # Prefer residuals that can still hold a typical small item (5..20):
    small = freq[5:21].sum()
    score_r[5:21] += 0.25 * small
    # Normalize to [0, 1] so the tie-break stays strictly below 1.
    m = score_r.max()
    if m > 0:
        score_r = score_r / m
    s["target"] = score_r


def priority(item, bins):
    """Best-fit with an empirical-residual-target tie-break.

    Primary term: best fit (smallest residual wins). Dominates.
    Secondary term: in [0, 1), never overrides a genuine integer residual
    gap. Among equal-slack bins, prefer the one whose leftover is a
    high-probability future item size (so it can be sealed exactly).
    """
    s = _state
    s["n"] += 1
    if item < 101:
        s["counts"][item] += 1.0
    if s["target"] is None or (s["n"] % s["update_every"] == 0):
        _refresh_target()

    residual = (bins - item).astype(np.float64)
    score = -residual

    # Bounded tie-break in [0, 1): look up target score for each residual.
    r_int = np.clip(np.round(residual).astype(np.int64), 0, 100)
    tie = s["target"][r_int]
    score = score + tie
    return score
# EVOLVE-BLOCK-END