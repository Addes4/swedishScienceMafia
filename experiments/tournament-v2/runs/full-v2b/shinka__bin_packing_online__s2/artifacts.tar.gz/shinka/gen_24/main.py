# EVOLVE-BLOCK-START
"""Pure Best-Fit core, with an explicit ablation of the tie-breaker stack.

Evidence: nineteen generations of bounded sub-1.0 tie-breakers produced
bit-identical scores (0.962099 / 0.961184), matching the pure best-fit
baseline exactly. This indicates the tie-breaker terms never change the
argmax on these instances, because the integer slack ordering from
`-(bins - item)` fully determines the placement.

This edit strips all bounded bonuses/penalties and all mutable state,
leaving only the dominant Best-Fit term. It is the cleanest possible
ablation: if the score is unchanged, the bonus stack is confirmed inert
and future effort should pivot to a different algorithmic family; if the
score changes, we have isolated a harmful term.
"""
import numpy as np


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties).

    Pure best-fit: place the item in the bin with the smallest remaining
    slack after placement. Ties are broken by bin order (first wins),
    which is deterministic and allocation-light.
    """
    slack = bins.astype(np.float64) - float(item)
    return -slack
# EVOLVE-BLOCK-END