# EVOLVE-BLOCK-START
"""Strict Best-Fit with a dead-space tie-break (offline-inspired, stateless).

The online Best-Fit class has plateaued at ~0.962099/0.961184 across many
sub-unit bonus variants, so we drop the adaptive running-mean machinery and
the consolidation/usefulness bonuses (which were numerically neutral or
noisy) and keep only the load-bearing invariant: strict Best-Fit.

We add one genuinely different, offline-inspired element: a dead-space
tie-break.  When two bins have *identical* slack (i.e. the primary
Best-Fit score ties), prefer the bin whose residual after placement is
either exactly 0 (a perfect fill, which the constructive FFD/BFD schemes
always favor) or large enough to accept a typical future item (residual
>= 5), and penalize dead-space residuals (1..4) that no future item can
fill.  Because slack is an integer, this tie-break can never override a
tighter fit, so it cannot regress from strict Best-Fit.

This removes all mutable global state, making the rule identical across
instances and robust to the unseen evaluation set.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    slack = (bins - item).astype(np.float64)
    # Primary term: strict Best-Fit (tightest slack wins).  Integer slack, so
    # any sub-unit term below is a pure tie-breaker and cannot override a
    # tighter fit.
    base = -slack

    residual = slack  # capacity left in this bin after placing the item

    # Dead-space tie-break (only meaningful when slack ties):
    #  - exact fill (residual == 0) is the best possible outcome.
    #  - residual >= 5 can still host a small future item, so it is fine.
    #  - residual in 1..4 is dead space no future item (size >= 1) can use
    #    efficiently; prefer avoiding it.
    base += 0.5 * (residual == 0)
    base += 0.25 * (residual >= 5)
    base -= 0.25 * ((residual >= 1) & (residual <= 4))

    return base
# EVOLVE-BLOCK-END