# EVOLVE-BLOCK-START
"""Best-fit with soft dead-space awareness and a tiny lookahead buffer.

Rule (all tie-breakers are strictly sub-unit, so the strict best-fit ordering
over integer residuals is preserved):
  - Base: best fit (prefer smallest residual = -residual).
  - +0.5 bonus when residual >= 10 (leaves usable room for future items).
  - -0.25 penalty when residual == 100 (fresh/empty bin).
  - For residual in [1,4] (a likely dead sliver): a soft penalty whose size
    depends on whether a recently-seen item could plausibly refill it.
    If no buffered item is small enough -> -0.4; otherwise -> -0.1.
    Both are < 1.0, so a looser fit (residual +1 or more) can never overtake
    a tighter fit.
  - +0.4 bonus for residual in [35,50] (near the typical item size ~40).
"""
import numpy as np
from collections import deque

# Persistent small lookahead buffer of recently arrived item sizes.
_RECENT = deque(maxlen=8)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    residual_f = residual.astype(np.float64)

    # Base: strict best fit.
    score = -residual_f

    # Bonus for leaving usable room for future items.
    score += 0.5 * (residual >= 10)

    # Penalty for opening a fresh bin.
    score -= 0.25 * (bins == 100)

    # Sweet-spot bonus near the typical item size (~40).
    score += 0.4 * ((residual >= 35) & (residual <= 50))

    # Soft dead-sliver handling for residuals 1..4.
    tiny_mask = (residual >= 1) & (residual <= 4)
    if tiny_mask.any():
        # Can any recently seen item fit into a sliver of size <= 4?
        has_small = any(s <= 4 for s in _RECENT)
        penalty = -0.1 if has_small else -0.4
        score += penalty * tiny_mask

    # Update the lookahead buffer with the current item (state persists).
    _RECENT.append(int(item))

    return score
# EVOLVE-BLOCK-END