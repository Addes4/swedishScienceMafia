# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with online-learned residual reservation.

Core idea:
  * Best-Fit remains the dominant term (smallest slack wins).
  * We maintain running statistics of arriving item sizes to estimate the
    typical "large" item size, and reward bins whose leftover capacity is
    close to that typical size (so a future large item can still fit).
  * The reservation strength adapts: early on it is weak (exploration),
    later it stabilizes on the observed distribution.
  * No future information is used; only past items seen in this instance.
"""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_state = {
    "n": 0,
    "sum": 0.0,
    "sum_sq": 0.0,
    # exponential moving estimate of the "large item" size (top decile-ish)
    "large_ema": 50.0,
    "counts": np.zeros(101, dtype=np.float64),  # size histogram
}


def _update_stats(item):
    s = _state
    s["n"] += 1
    s["sum"] += item
    s["sum_sq"] += item * item
    s["counts"][item] += 1.0
    # EMA toward larger items: only update meaningfully when item is sizeable
    # Update with a mild rate so it tracks the upper part of the distribution.
    rate = 0.02
    s["large_ema"] = (1.0 - rate) * s["large_ema"] + rate * float(item)


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties)."""
    _update_stats(item)

    slack = bins.astype(np.float64) - float(item)

    # ----- adaptive reservation target -----
    n = _state["n"]
    # Confidence grows with sample count, capped.
    conf = min(1.0, n / 300.0)

    # Large-item estimate: blend EMA with an empirical upper quantile once we
    # have enough samples. This is cheap: histogram lookup.
    if n >= 50:
        counts = _state["counts"]
        cum = np.cumsum(counts)
        total = cum[-1]
        # 80th percentile as a proxy for "large" items
        target_idx = np.searchsorted(cum, 0.80 * total)
        q80 = float(target_idx)
        large_est = 0.5 * _state["large_ema"] + 0.5 * q80
    else:
        large_est = _state["large_ema"]

    # Clamp target to a sane range.
    target = float(np.clip(large_est, 20.0, 90.0))

    # ----- scoring -----
    # Best-fit core: prefer tightest fit.
    score = -slack

    # Reservation bonus: reward bins whose leftover is close to `target`,
    # i.e. bins that can still accept a typical large item.
    # Use a smooth Gaussian-like band around target.
    width = 12.0
    band = np.exp(-((slack - target) ** 2) / (2.0 * width * width))

    # Strength of reservation: grows with confidence but stays moderate so
    # Best-Fit behavior is not destroyed.
    strength = 6.0 * conf

    # Penalize bins that are almost full only if they cannot hold the target;
    # this discourages wasting a bin on a small item when a larger one could
    # have fit. Keep it mild.
    near_full = np.maximum(0.0, target - slack)  # >0 if leftover < target
    full_penalty = 0.15 * conf * near_full

    return score + strength * band - full_penalty
# EVOLVE-BLOCK-END