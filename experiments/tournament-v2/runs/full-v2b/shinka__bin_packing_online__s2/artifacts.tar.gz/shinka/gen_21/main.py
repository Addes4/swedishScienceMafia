# EVOLVE-BLOCK-START
"""Best-fit with dead-space awareness for online bin packing.

Rule:
  - Base: best fit (prefer the smallest residual after placing the item).
  - Small bonus for residuals that leave usable room (>= 10) for future items.
  - Small penalty for opening a fresh bin (residual == 100 means the bin was empty).
  - Small penalty for leaving a tiny, hard-to-refill residual (1..4).

All adjustments are bounded well below 1.0, so they only resolve near-ties
and never override the primary best-fit ordering (integer residuals differ
by at least 1).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    residual_f = residual.astype(np.float64)

    # Base: best fit (prefer smallest residual).
    score = -residual_f

    # Bonus for residuals that leave usable room for future items.
    score += 0.5 * (residual >= 10)

    # Penalty for opening a brand-new bin.
    score -= 0.25 * (bins == 100)

    # Penalty for leaving a tiny, essentially dead residual (1..4).
    # Residual 0 is perfect (exact fill) and is not penalized.
    score -= 0.2 * ((residual >= 1) & (residual <= 4))

    return score
# EVOLVE-BLOCK-END