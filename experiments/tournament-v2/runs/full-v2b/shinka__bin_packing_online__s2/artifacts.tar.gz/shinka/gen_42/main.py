# EVOLVE-BLOCK-START
"""Distribution-aware best-fit for online bin packing.

Architecture change vs. the previous fixed-rule version:
  * The function is no longer purely stateless.  It keeps a compact running
    histogram of observed item sizes (a 101-bin count array) shared across
    calls via a module-level object.  This is the only state; it never
    looks at future items and is reset implicitly per process.
  * Scoring is split into two explicit stages:
      1) PRIMARY: strict best fit.  Scaled by a large constant so that any
         integer difference in residual dominates every secondary term.
         This preserves the proven "tighter fit always wins" invariant.
      2) SECONDARY: a subset-sum-aware tie-breaker.  For bins with equal
         residual we prefer ones whose residual is "complementary" to the
         current item or to frequently observed item sizes, i.e. residuals
         that can be exactly filled by a common future item, or that leave a
         residual which itself matches a common item size.
  * The secondary term is bounded strictly below the primary scale, so it
    only ever resolves exact-residual ties.

This keeps the same `priority(item, bins)` signature and return type.
"""
import numpy as np

# --- shared, cross-call state -------------------------------------------------
# Running histogram of item sizes seen so far.  Index = size (0..100).
# Used only to weight the subset-sum-aware tie-breaker; it never changes the
# primary best-fit ordering.
_SIZE_HIST = np.zeros(101, dtype=np.float64)
_TOTAL_SEEN = 0.0

# Primary scale: must exceed the sum of all secondary magnitudes.
_PRIMARY_SCALE = 100.0
# Secondary magnitudes (kept well below _PRIMARY_SCALE).
_BONUS_EXACT_FILL = 0.5      # residual == 100 - item  (perfect complement)
_BONUS_COMMON_COMPL = 0.35   # residual is a frequent item size
_BONUS_USABLE = 0.2          # residual leaves reusable room
_PENALTY_DEAD = 0.4          # residual 1..4 (hard to refill)
_PENALTY_FRESH = 0.25        # opening a brand-new bin


def _common_item_mask():
    """Return a boolean mask of item sizes that are 'common' so far.

    A size is common if it has been seen at least a small fraction of the
    time.  Falls back to a coarse default before enough data is collected.
    """
    global _SIZE_HIST, _TOTAL_SEEN
    mask = np.zeros(101, dtype=bool)
    if _TOTAL_SEEN < 50.0:
        # Not enough data: treat mid-range sizes as plausibly common.
        mask[10:60] = True
        return mask
    freq = _SIZE_HIST / _TOTAL_SEEN
    # Sizes accounting for the bulk of the distribution.
    mask = freq >= 0.005
    # Always consider the very small and very large tails as "not common"
    # unless they really are frequent.
    return mask


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _SIZE_HIST, _TOTAL_SEEN

    # --- update running histogram (state, not future info) -----------------
    if 1 <= item <= 100:
        _SIZE_HIST[item] += 1.0
        _TOTAL_SEEN += 1.0

    residual = bins - item
    residual_f = residual.astype(np.float64)

    # --- STAGE 1: primary strict best fit ---------------------------------
    score = -_PRIMARY_SCALE * residual_f

    # --- STAGE 2: subset-sum-aware secondary tie-breakers -----------------
    # (a) Perfect complement: placing `item` leaves a residual that exactly
    #     matches a size we may plausibly see again (residual itself is a
    #     valid item size, i.e. 1..100).  Prefer such residuals.
    common = _common_item_mask()
    # residual in 1..100 and that size is common -> good complement
    residual_valid = (residual >= 1) & (residual <= 100)
    score += _BONUS_COMMON_COMPL * (residual_valid & common[residual])

    # (b) Exact fill of the bin: residual == 0 is ideal (already favored by
    #     primary, but make it explicit and robust to float noise).
    score += _BONUS_EXACT_FILL * (residual == 0)

    # (c) Usable room bonus: residuals >= 5 can still absorb a small item.
    score += _BONUS_USABLE * (residual >= 5)

    # (d) Penalty for tiny dead residual (1..4); residual 0 not penalized.
    score -= _PENALTY_DEAD * ((residual >= 1) & (residual <= 4))

    # (e) Penalty for opening a fresh bin (only breaks exact-residual ties).
    score -= _PENALTY_FRESH * (bins == 100)

    return score
# EVOLVE-BLOCK-END