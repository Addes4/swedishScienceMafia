# EVOLVE-BLOCK-START
"""Baseline: best fit, with an out-of-band tie-frequency diagnostic.

The returned priority is exactly strict Best-Fit (smallest integer residual
wins), so the score is unchanged.  In addition, `priority` updates a
module-level diagnostic that records whether the argmax was decided by a
unique minimal slack, or by a tie among bins sharing the same minimal
integer slack.  This instrumentation is read-only with respect to the
score and is meant to establish whether the tie-breaker plateau is a
genuine integer optimum or an artifact of ties never firing.
"""
import numpy as np

# ---- out-of-band diagnostic state (does not affect the returned score) ----
DIAG = {
    "calls": 0,          # total priority() calls
    "ties": 0,           # calls where >=2 bins share the minimal integer slack
    "perfect": 0,        # calls where the chosen bin has residual 0
    "tie_residuals": {}, # histogram: minimal-slack value -> count when tied
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    # Primary term: best fit (smallest residual wins).
    score = -residual

    # ---- diagnostic (out-of-band; does not change `score`) ----
    DIAG["calls"] += 1
    if residual.size > 0:
        min_slack = residual.min()
        n_tied = int((residual == min_slack).sum())
        if n_tied >= 2:
            DIAG["ties"] += 1
            key = int(min_slack)
            DIAG["tie_residuals"][key] = DIAG["tie_residuals"].get(key, 0) + 1
        if min_slack == 0.0:
            DIAG["perfect"] += 1

    # Secondary term: among (near-)equal residuals, prefer a leftover that is
    # close to the typical future item size (mean ~40 for this distribution),
    # so the bin stays useful. Bounded by 0.5 < 1, so it never overrides a
    # genuine integer capacity difference.
    score += 0.5 * np.exp(-((residual - 40.0) ** 2) / (2.0 * 20.0 ** 2))
    return score
# EVOLVE-BLOCK-END