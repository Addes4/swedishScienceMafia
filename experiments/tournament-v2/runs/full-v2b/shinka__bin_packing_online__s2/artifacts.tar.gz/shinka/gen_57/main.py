# EVOLVE-BLOCK-START
"""Two-layer adaptive best-fit.

Architecture:
  LAYER 1 (integer): strict best fit. Bins are ranked by residual = bins - item.
           This is the dominant ordering and matches the known integer optimum
           for the Weibull-shaped distribution.
  LAYER 2 (sub-unit): only fires on integer-equal residuals. Uses
           (a) a data-driven residual-reuse probability estimated from
               the empirical histogram of observed item sizes, and
           (b) a fresh-bin penalty to delay opening new bins.

All layer-2 terms are bounded in [-0.9, +0.9], strictly below the unit
gap between distinct integer residuals, so the best-fit invariant holds
exactly. No randomness. State is bounded (histogram + counts).
"""
import numpy as np

# Capacity of every bin.
_CAP = 100

# Bounded empirical histogram of observed item sizes (1..100).
_hist = np.zeros(_CAP + 1, dtype=np.float64)
_count = 0

# Layer-2 magnitude bound: strictly < 1.0 so integer residual always dominates.
_L2_SCALE = 0.9


def _reuse_probability(residuals):
    """Estimate P(future item == residual) from the empirical histogram.

    residuals: int64 array of non-negative residuals.
    Returns float64 array in [0, 1] of the same length.
    """
    global _hist, _count
    if _count < 32:
        # Not enough data yet: uniform prior, no preference.
        return np.zeros(residuals.shape[0], dtype=np.float64)
    p = _hist / float(_count)
    # Clip residuals to histogram range; residuals > _CAP cannot match any
    # item (max item is 100), so probability is 0 there.
    r = residuals.astype(np.int64)
    in_range = (r >= 1) & (r <= _CAP)
    out = np.zeros(r.shape[0], dtype=np.float64)
    if in_range.any():
        out[in_range] = p[r[in_range]]
    return out


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item (1..100).
    bins: numpy int64 array of remaining capacities (all bins the item fits in).
    """
    global _hist, _count

    # ---- Update empirical histogram with the arriving item ----
    # We update BEFORE scoring so the current item contributes to its own
    # reuse estimate, which is valid because we know item's size now.
    _hist[int(item)] += 1.0
    _count += 1

    residual = bins - item  # int64, >= 0 for every bin shown

    # ---- LAYER 1: strict best fit ----
    # Larger score = better. Use a scale of 1.0 per residual unit so that
    # any one-unit residual difference strictly dominates layer 2.
    score = -residual.astype(np.float64)

    # ---- LAYER 2: sub-unit tie-breakers (only matter on integer ties) ----
    # (a) Residual-reuse bonus: prefer bins whose resulting residual is a
    #     likely future item size. This is the only signal that can improve
    #     packing beyond pure best-fit, because it aims to create
    #     exactly-fillable gaps.
    reuse = _reuse_probability(residual)
    # Normalize reuse to [0, 1] by dividing by the current max probability,
    # so the bonus stays bounded regardless of distribution shape.
    if _count > 0:
        max_p = float(_hist.max()) / float(_count)
        if max_p > 0:
            reuse = reuse / max_p
    score += _L2_SCALE * 0.5 * reuse

    # (b) Fresh-bin penalty: discourage opening a brand-new bin when an
    #     existing bin offers the same integer residual.
    #     bins == _CAP only for untouched (empty) bins.
    score -= _L2_SCALE * 0.5 * (bins == _CAP).astype(np.float64)

    return score
# EVOLVE-BLOCK-END