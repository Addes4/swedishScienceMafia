# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    # Primary term: best fit (smallest residual wins).
    score = -residual
    # Secondary term: among (near-)equal residuals, prefer a leftover that is
    # close to the typical future item size (mean ~40 for this distribution),
    # so the bin stays useful. Bounded by 0.5 < 1, so it never overrides a
    # genuine integer capacity difference.
    score += 0.5 * np.exp(-((residual - 40.0) ** 2) / (2.0 * 20.0 ** 2))
    # Tertiary deterministic tie-break: among bins with identical residual,
    # consistently prefer the fuller bin (smaller residual -> larger fill).
    # Fill fraction = (100 - residual) / 100. Coefficient 0.001 << 1.0, so it
    # cannot override any genuine integer capacity difference, yet it breaks
    # exact ties reproducibly without jitter.
    score += 0.001 * (100.0 - residual) / 100.0
    return score
# EVOLVE-BLOCK-END