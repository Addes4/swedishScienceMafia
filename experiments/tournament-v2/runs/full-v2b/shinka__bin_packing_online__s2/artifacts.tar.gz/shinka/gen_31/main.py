# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    # Primary term: best fit (smallest residual wins). This dominates and
    # cannot be overridden by any bounded secondary term below.
    score = -residual
    # Secondary term (bounded by 0.5 < 1, never overrides an integer residual
    # difference): prefer residuals that match the *small* and *medium* size
    # classes of the item distribution, so that bins keep "useful" leftover
    # room for the many small items instead of being sealed by a rare large
    # one. Two soft bumps at residual ~20 and ~60.
    score += 0.30 * np.exp(-((residual - 20.0) ** 2) / (2.0 * 12.0 ** 2))
    score += 0.40 * np.exp(-((residual - 60.0) ** 2) / (2.0 * 15.0 ** 2))
    return score
# EVOLVE-BLOCK-END