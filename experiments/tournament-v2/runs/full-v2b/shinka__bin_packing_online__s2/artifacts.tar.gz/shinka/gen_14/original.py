# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    slack = bins - item
    # Best Fit: prefer the tightest fit (smallest slack).
    # Additional penalty when the leftover would exceed the item size, to
    # preserve roomy bins for future large items (threshold-style Best Fit).
    alpha = 0.05
    penalty = alpha * np.maximum(0, slack - item)
    return -slack - penalty
# EVOLVE-BLOCK-END