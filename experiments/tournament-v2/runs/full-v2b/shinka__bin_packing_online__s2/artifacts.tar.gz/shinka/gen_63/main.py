# EVOLVE-BLOCK-START
"""Best-Fit with a strictly-monotone, non-uniform residual valuation.

Motivation
----------
Forty-plus generations of bounded additive tie-breakers on top of the
integer slack `-(bins - item)` have produced bit-identical scores
(0.962099 / 0.961184).  The reason is structural: any tie-breaker whose
magnitude is < 1 only fires when two bins have *identical* integer
residual, and on this Weibull-shaped distribution the integer argmax is
already unique almost always.  So the tie-breaker never changes the
winner.

What actually matters is the *slope* of the primary term.  Pure Best-Fit
treats every extra unit of residual as equally valuable, but on a
distribution with mean item size ~40 and minimum item size 1, a residual
of 1..4 is essentially dead space (it can almost never be refilled by a
future item), while a residual near the mean is highly likely to be
refilled.  Best-Fit's "tighter is better" rule therefore actively hurts
when it prefers a bin that would be left with residual 2 over one that
would be left with residual 5.

Idea
----
Replace the primary integer slack with a strictly-decreasing function of
residual whose *slope* is non-uniform: steeper (more penalising) in the
dead zone of small residuals, shallower near the typical item size.  This
changes the argmax only between bins whose residuals differ by a small
amount -- exactly the regime where Best-Fit's tie-breaking is arbitrary
-- while preserving strict capacity ordering (a bin with smaller residual
always outscores one with larger residual).

Form
----
    f(r) = -r - alpha * dead(r) + beta * useful(r) + eps * used(r)

    dead(r)   = exp(-r / s)                     # large for tiny r
    useful(r) = exp(-(r - mu)^2 / (2 sigma^2))  # peak at running mean
    used(r)   = 1 if bin is already used

with mu the running mean item size, s ~ 3, sigma ~ 15, alpha = 0.25,
beta = 0.15, eps = 1e-6.  The perturbation is bounded by 2*(alpha+beta)
= 0.8 < 1, so f is strictly decreasing in r: capacity ordering is never
violated.  The `used` term is a bounded tie-breaker (magnitude << 1e-3)
that only breaks exact ties and gently consolidates load.
"""
import numpy as np

# Running estimate of the mean item size seen so far (adaptive centre of
# the "useful residual" band).  Initialised to the known distribution mean.
_mu = 40.0
_n = 0


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties).

    Parameters
    ----------
    item : int
        Size of the arriving item, 1..100.
    bins : numpy.ndarray (int64)
        Remaining capacity of every bin the item fits in, in bin order.

    Returns
    -------
    numpy.ndarray (float64)
        One score per bin, same length as `bins`.
    """
    global _mu, _n

    # Update running mean of item sizes (incremental average, O(1)).
    _n += 1
    _mu += (item - _mu) / _n

    residual = (bins - item).astype(np.float64)  # capacity left after placement

    # Primary term: strictly decreasing in residual (smaller residual wins).
    score = -residual

    # Non-uniform slope deformation: penalise dead-zone residuals (1..~4)
    # more steeply than the linear baseline, so Best-Fit does not chase
    # a tiny, unrefillable leftover over a slightly larger, reusable one.
    s = 3.0
    score -= 0.25 * np.exp(-residual / s)

    # Reward residuals near the running mean item size: these bins are
    # the ones most likely to be refilled by a future item.
    sigma = 15.0
    score += 0.15 * np.exp(-((residual - _mu) ** 2) / (2.0 * sigma * sigma))

    # Bounded consolidation tie-breaker: prefer already-used bins so the
    # number of open bins does not grow unnecessarily.  Magnitude is far
    # below the unit gap between consecutive integer residuals.
    score += 1e-6 * (bins < 100)

    return score
# EVOLVE-BLOCK-END