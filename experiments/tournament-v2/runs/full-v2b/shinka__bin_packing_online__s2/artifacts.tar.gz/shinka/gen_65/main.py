# EVOLVE-BLOCK-START
"""Minimal best-fit plus modal-residual bonus.

Rule (tie-breaker is strictly sub-unit, so the strict best-fit ordering over
integer residuals is preserved):
  - Base: best fit (prefer smallest residual = -residual).
  - +0.5 bonus when the residual exactly matches the modal size of the last
    64 seen items (only once at least 8 items have been seen and the modal
    size has count >= 2).

This is the stripped-down variant used to test whether the plateau at
0.962099 / 0.961184 is a genuine integer optimum for best-fit-style rules.
"""
import collections
import numpy as np


# Bounded history of recently seen item sizes, used for a data-driven tie-break.
_recent = collections.deque(maxlen=64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)

    # Data-driven tie-break: prefer bins whose exact residual matches a modal
    # recent item size.  The bonus (< 1.0) only reorders integer-equal
    # residuals, so the best-fit invariant is preserved.
    _recent.append(int(item))
    if len(_recent) >= 8:
        counts = {}
        for s in _recent:
            counts[s] = counts.get(s, 0) + 1
        max_c = max(counts.values())
        if max_c >= 2:
            modal = np.array(
                [s for s, c in counts.items() if c == max_c], dtype=np.int64
            )
            score = score + 0.5 * np.isin(residual, modal).astype(np.float64)

    return score
# EVOLVE-BLOCK-END