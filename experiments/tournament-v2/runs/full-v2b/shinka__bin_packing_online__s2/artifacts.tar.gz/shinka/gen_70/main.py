# EVOLVE-BLOCK-START
"""Strict best-fit with a bounded top-K reusable-residual tie-break.

The dominant term is exact best-fit (prefer smallest integer residual). On top
of that we add a strictly sub-unit bonus when a bin's residual matches one of
the K most frequent recent item sizes (a "reusable residual"). All bonuses are
in (-1, 1), so they can only reorder bins with *equal* integer residuals -- the
strict best-fit ordering over integer residuals is preserved exactly.

No lookahead: we only track a bounded deque of past items. No NaN risk.
"""
from collections import deque
import numpy as np


_WINDOW = 64
_TOP_K = 3
# Descending, strictly sub-unit bonuses for the K modes.
_BONUSES = (0.5, 0.33, 0.2)

_recent = deque(maxlen=_WINDOW)


def _topk_modes():
    """Return up to _TOP_K most frequent recent item sizes (descending count)."""
    if not _recent:
        return ()
    counts = {}
    for s in _recent:
        counts[s] = counts.get(s, 0) + 1
    # Sort by (count desc, size desc) for determinism.
    ordered = sorted(counts.items(), key=lambda kv: (-kv[1], -kv[0]))
    return tuple(s for s, _ in ordered[:_TOP_K])


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (capacity 100), in fixed bin order.

    Rule: strict best-fit, plus a strictly sub-unit bonus when the residual
    matches one of the top-K most frequent recent item sizes. A 1e-9 index
    preference breaks remaining exact ties toward the earlier bin.
    """
    residual = bins - item
    score = -residual.astype(np.float64)

    # Data-driven top-K reusable-residual bonus (strictly sub-unit).
    modes = _topk_modes()
    if modes:
        for b, m in zip(_BONUSES, modes):
            score += b * (residual == m)

    # Stable tie-break: prefer earlier bins. 1e-9 << 1.0.
    n = bins.shape[0]
    if n > 1:
        idx = np.arange(n, dtype=np.float64)
        score -= 1e-9 * idx

    # Record this item for future calls (after scoring, so no self-influence).
    _recent.append(int(item))
    return score
# EVOLVE-BLOCK-END