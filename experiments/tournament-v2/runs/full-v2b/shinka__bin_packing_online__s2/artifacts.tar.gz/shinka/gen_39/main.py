# EVOLVE-BLOCK-START
"""Strict Best-Fit with explicit stable tie-break by bin index.

Hypothesis under test: the plateau at ~0.962099/0.961184 across many
bounded-bonus variants is the integer optimum of the online Best-Fit
heuristic class, and all sub-unit tie-breakers are numerically neutral.

We therefore replace the accumulated sub-unit bonuses with an explicit
strict Best-Fit selection: score = -slack. Because the harness selects the
highest score and breaks ties by *first bin index*, returning the raw
negated slack already implements a deterministic, stable tie-break
favoring earlier bins. No mutable state is needed.

If this matches the current scores exactly, the plateau is confirmed and
further online priority tweaks are futile; effort should shift to the
constructive/offline family. If it differs, the bonuses were doing work
and we can re-tune from this clean baseline.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Strict Best-Fit: tightest slack wins. Ties broken by first index by the
    # harness's selection rule (highest score, first on ties). We return float
    # to guarantee no integer overflow / dtype surprises in the argmax path.
    slack = (bins - item).astype(np.float64)
    return -slack
# EVOLVE-BLOCK-END