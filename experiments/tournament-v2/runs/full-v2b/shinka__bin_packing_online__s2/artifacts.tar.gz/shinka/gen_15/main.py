# EVOLVE-BLOCK-START
"""Distribution-aware Best Fit for online bin packing.

Idea: rank bins not only by how tightly the item fits, but also by how
"reusable" the resulting residual capacity is expected to be, given the
item-size distribution (Weibull-shaped, mean ~40). A tiny deterministic
perturbation breaks ties to avoid the pathological symmetry of pure Best Fit.
"""
import numpy as np


# --- distribution-aware score for the residual after placing the item ---
# Residual r = remaining_capacity - item  (>= 0 for bins shown).
# Lower r is generally better (best-fit). But residuals that are exactly
# in a "pairing sweet spot" for the mean item size (~40) are slightly better
# than neighbours, because they can be efficiently filled later.
# We build a smooth preference curve and combine it with a small tie-break.

def _residual_score(r):
    """Vectorized score for an array of residuals r >= 0. Higher = better.

    Pure Best Fit (`-r`) is the dominant term. We add:

    * a LARGE bonus when the bin is exactly filled (residual 0). This is the
      only deviation from Best Fit that is provably safe: closing a bin
      perfectly can never be worse than leaving slack, and it strictly beats
      any non-zero residual.
    * a SMALL bonus (< 1.0) when the residual matches a common item size, so
      that among residuals that are already very close, the one that a future
      item is most likely to fit exactly is preferred. Kept strictly below 1.0
      so it can never override a strictly tighter fit.
    """
    rf = r.astype(np.float64)

    # base: strongly prefer small residuals (classic best-fit).
    base = -rf

    # Exact-fit: always dominate. 1000 >> any possible residual gap (<= 100).
    exact = 1000.0 * (r == 0)

    # Near-exact / reusable residual tie-break: residuals that equal a
    # plausible upcoming item size (drawn from a Weibull with mean ~40) are
    # marginally better than residuals that do not. Magnitude < 1.0 keeps this
    # purely a tie-breaker.
    reusable = 0.5 * ((r >= 20) & (r <= 60))

    return base + exact + reusable


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    # bins is a numpy int64 array of remaining capacities (only fitting bins).
    residual = bins - item                      # >= 0 by contract
    score = _residual_score(residual)

    # Deterministic tie-break. Among bins whose base score is within a tiny
    # window (i.e. genuine near-ties in residual), prefer the one with the
    # LARGER residual (worst-fit among near-ties) so we keep more room for
    # future large items. This is implemented as a smooth, bounded term that
    # can never override a strictly better residual (gap >= 1 is untouched).
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)

    # Worst-fit-among-near-ties: tiny positive reward proportional to residual,
    # scaled well below 1.0 so it only breaks exact/within-epsilon ties.
    worst_fit = 1e-3 * residual.astype(np.float64)

    # Tiny deterministic jitter to break remaining exact ties without
    # depending on instance ordering.
    jitter = 1e-6 * (((item * 131 + residual * 17 + idx * 7) % 97) / 97.0)

    return score + worst_fit + jitter
# EVOLVE-BLOCK-END