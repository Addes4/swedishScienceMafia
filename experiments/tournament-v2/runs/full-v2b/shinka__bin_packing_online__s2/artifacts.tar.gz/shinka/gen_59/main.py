# EVOLVE-BLOCK-START
"""Best-fit with strictly sub-unit, data-driven residual-reuse tie-breaking.

Confirmed invariant (from prior programs): the integer best-fit ordering
(prefer smallest residual = remaining_capacity - item) must dominate. All
tie-breakers below are bounded strictly below 1.0, so a one-unit residual
difference can never be overturned.

Novel component: on integer-equal residuals, prefer the bin whose resulting
residual exactly equals a *modal recently-seen item size*, estimated from a
bounded deque (<=64) of the live item stream. This uses real data (not a
fixed band) and is applied only as a tie-break, never as an override.
"""
import numpy as np

_CAP = 100
_DEQUE_MAX = 64
_hist = np.zeros(_CAP + 1, dtype=np.float64)
_recent = []  # bounded list of recent item sizes


def _mode_size():
    """Most frequent recent item size (tie -> larger size). 0 if none."""
    if not _recent:
        return 0
    counts = {}
    for s in _recent:
        counts[s] = counts.get(s, 0) + 1
    best_s, best_c = 0, 0
    for s, c in counts.items():
        if c > best_c or (c == best_c and s > best_s):
            best_s, best_c = s, c
    return best_s


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    global _recent

    # Update bounded recent-item buffer and histogram with the arriving item.
    _recent.append(int(item))
    if len(_recent) > _DEQUE_MAX:
        _recent.pop(0)
    _hist[int(item)] += 1.0

    residual = bins - item                  # int64, >= 0 for every shown bin
    rf = residual.astype(np.float64)

    # ---- LAYER 1: strict best fit (dominant) ----
    score = -rf

    # ---- LAYER 2: sub-unit tie-breakers (only matter on integer ties) ----
    # (a) Data-driven residual-reuse bonus: prefer bins whose residual equals
    #     the modal recent item size (most likely to be exactly filled).
    mode = _mode_size()
    if mode > 0:
        score += 0.5 * (residual == mode).astype(np.float64)

    # (b) Mild structural preference: residuals in [35, 55] are near the
    #     typical item size (~40) and are reusable.
    score += 0.15 * ((residual >= 35) & (residual <= 55)).astype(np.float64)

    # (c) Fresh-bin penalty: discourage opening a new bin on a tie.
    score -= 0.25 * (bins == _CAP).astype(np.float64)

    # (d) Dead-sliver penalty: residual in [1,4] is unlikely to be reused.
    score -= 0.3 * ((residual >= 1) & (residual <= 4)).astype(np.float64)

    return score
# EVOLVE-BLOCK-END