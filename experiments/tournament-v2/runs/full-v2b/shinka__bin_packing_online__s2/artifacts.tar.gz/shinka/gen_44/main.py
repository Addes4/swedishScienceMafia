# EVOLVE-BLOCK-START
"""Distribution-aware Best Fit with fresh-bin penalty.

Combines:
  - smooth residual preference curve (best-fit base + sweet-spot bump + tight bonus)
  - small penalty for opening a fresh bin
  - deterministic tie-break jitter + index preference
"""
import collections
import numpy as np


# Bounded history of recently seen item sizes, used for a data-driven tie-break.
_recent = collections.deque(maxlen=64)


def _residual_score(r):
    """Vectorized score for residuals r >= 0. Higher = better."""
    r = r.astype(np.float64)
    base = -r
    # Sweet spot around mean item size (~50) to absorb another average item.
    bump = np.maximum(0.0, 1.0 - np.abs(r - 50.0) / 25.0)
    # Tight residuals are best-fit territory; mild bonus.
    tight = np.maximum(0.0, 1.0 - r / 10.0)
    return base + 0.6 * bump + 0.4 * tight


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    residual = bins - item
    score = _residual_score(residual)

    # Penalize opening a fresh (previously empty) bin.
    score -= 0.25 * (bins == 100)

    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    # Deterministic tie-break jitter keyed on (item, residual, index).
    jitter = 1e-4 * (((item * 131 + residual * 17 + idx * 7) % 97) / 97.0)
    # Slight preference for lower-index bins (packing stability).
    idx_pref = -1e-5 * idx

    # Data-driven tie-break: prefer bins whose exact residual matches a modal
    # recent item size.  The bonus (< 1.0 - max bump/tight slope ~0.064) only
    # reorders integer-equal residuals, so the best-fit invariant is preserved.
    _recent.append(int(item))
    if len(_recent) >= 8:
        counts = {}
        for s in _recent:
            counts[s] = counts.get(s, 0) + 1
        max_c = max(counts.values())
        if max_c >= 2:
            modal = np.array(
                [s for s, c in counts.items() if c == max_c], dtype=np.int64
            )
            score = score + 0.4 * np.isin(residual, modal).astype(np.float64)

    return score + jitter + idx_pref
# EVOLVE-BLOCK-END