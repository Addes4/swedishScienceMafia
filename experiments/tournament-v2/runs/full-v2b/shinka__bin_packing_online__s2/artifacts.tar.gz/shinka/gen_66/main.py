# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with top-K recent-modal residual reservation.

Core idea:
  * Best-Fit remains the dominant term (smallest slack wins).
  * We maintain a bounded recent-window histogram of arriving item sizes and
    extract the top-K most frequent sizes. Leaving a residual equal to one of
    these common sizes lets a future common item fit exactly, reducing
    fragmentation.
  * Bonuses for matching the top-K targets are strictly sub-unit (0.5, 0.33,
    0.2), so a full unit of integer slack always dominates. The tie-break only
    acts among bins with identical integer slack.
  * No future information is used; only past items seen in this instance.
"""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_state = {
    "n": 0,
    # recent-window histogram (last RECENT items) for modal residual matching
    "recent": np.zeros(101, dtype=np.float64),
    "recent_q": [],
    "recent_cap": 256,
    # cached top-K residual targets from the recent window
    "res_vals": None,
    "update_every": 32,
}

# strictly sub-unit descending bonuses for the top-K targets
_BONUS = (0.5, 0.33, 0.2)


def _update_stats(item):
    s = _state
    s["n"] += 1
    q = s["recent_q"]
    cap = s["recent_cap"]
    if len(q) >= cap:
        old = q.pop(0)
        s["recent"][old] -= 1.0
    q.append(item)
    s["recent"][item] += 1.0


def _refresh_residual_targets():
    """Pick the top-K *currently modal* item sizes as residual targets.

    Using the recent window (rather than the cumulative histogram) makes the
    targets track the stream's current mode, which is what a future item is
    most likely to be. Leaving a residual equal to a modal item size lets a
    future common item fit exactly, reducing fragmentation.
    """
    s = _state
    c = s["recent"].copy()
    c[0] = 0.0
    idx = np.argsort(-c)[:3]
    vals = idx[idx > 0].astype(np.float64)
    s["res_vals"] = vals


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties).

    Dominant term is strict best-fit (-slack). The only place a real-valued
    term can influence the choice is among bins with *equal* integer slack,
    so we restrict adaptation to a sub-unit tie-break (<1) that prefers
    residuals matching a currently modal future item size.
    """
    _update_stats(item)
    s = _state
    # refresh the residual-target set periodically (cheap, amortized)
    if s["res_vals"] is None or (s["n"] % s["update_every"] == 0):
        _refresh_residual_targets()

    slack = bins.astype(np.float64) - float(item)

    # Dominant integer best-fit term.
    score = -slack

    # Sub-unit tie-break: reward residuals equal to a currently modal item size.
    res_vals = s["res_vals"]
    if res_vals is not None and res_vals.size > 0:
        residual = slack
        # distance to nearest "good" residual target
        diff = np.abs(residual[:, None] - res_vals[None, :])
        nearest = diff.min(axis=1)
        # bonus in [0, 0.5): exact match gets 0.5, decays sharply with distance
        tie = 0.5 * np.exp(-(nearest ** 2) / (2.0 * 2.0 * 2.0))
        # descending extra bonus for matching higher-priority (more frequent)
        # targets exactly; still strictly sub-unit overall.
        for k, b in enumerate(_BONUS):
            if k < res_vals.size:
                tie = tie + b * 0.25 * (np.abs(residual - res_vals[k]) < 0.5)
        score = score + tie

    return score
# EVOLVE-BLOCK-END