# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with online-learned residual reservation.

Core idea:
  * Best-Fit remains the dominant term (smallest slack wins).
  * We maintain a running mean of arriving item sizes; for SMALL items we
    prefer bins whose leftover after placement is close to that mean, so a
    future average/large item can still fill them.
  * For large items, plain Best-Fit is already near-optimal, so no bonus.
  * No future information is used; only past items seen in this instance.
"""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_state = {
    "n": 0,
    "sum": 0.0,
}


def _update_stats(item):
    s = _state
    s["n"] += 1
    s["sum"] += item


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties)."""
    _update_stats(item)

    slack = bins.astype(np.float64) - float(item)

    # ----- adaptive reservation target (running mean item size) -----
    n = _state["n"]
    mean_est = _state["sum"] / n if n > 0 else 40.0
    target = float(np.clip(mean_est, 20.0, 90.0))

    # ----- scoring -----
    # Best-fit core: prefer tightest fit.
    score = -slack

    # Only apply reservation logic for small items; for large items Best-Fit
    # is already near-optimal and the bonus would only cause churn.
    if item < target:
        # Reward residuals matching the typical item size (so a future item
        # can fill the bin exactly), and mildly penalize residuals below it.
        band = np.exp(-((slack - target) ** 2) / (2.0 * 6.0 * 6.0))
        exact = (slack == target).astype(np.float64)
        near_full = np.maximum(0.0, target - slack)
        score = score + 0.30 * band + 0.50 * exact - 0.02 * near_full

    # Dead-space penalty: a residual of 1..4 is almost never refillable given
    # the item distribution (sizes 1..100, mean ~40), so avoid creating such
    # leftovers when a comparable alternative exists. Bounded well below 1.0
    # so it only breaks ties/near-ties and never overrides Best-Fit.
    dead = ((slack >= 1.0) & (slack <= 4.0)).astype(np.float64)
    score = score - 0.2 * dead

    return score
# EVOLVE-BLOCK-END