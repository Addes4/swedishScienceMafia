# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with an adaptively-centered residual kernel.

Crossover of prior implementations, extended per the recommendation:
  * Best-Fit (tightest slack) is the dominant term.
  * A running mean of item sizes drives a small "useful residual" bonus.
  * A second Welford tracker records the running mean of the *smallest
    positive residual* produced at each placement.
  * An L2-style Gaussian kernel, whose center adapts to that residual mean
    via max(2.0, min(8.0, residual_mean)) with amplitude 0.48, provides a
    bounded tie-break that is *genuinely consumed* rather than dead state.

All non-Best-Fit bonuses stay inside (-0.5, 0.5) so they never override a
genuine integer Best-Fit choice; they only resolve near-ties.
"""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_mean_item = 40.0
_count = 0


class _Stats:
    """Fused Welford mean tracker (no per-call allocation)."""
    __slots__ = ("n", "mean")

    def __init__(self, init_mean):
        self.n = 0
        self.mean = float(init_mean)

    def update(self, x):
        self.n += 1
        self.mean += (x - self.mean) / self.n


# Residual tracker: running mean of the smallest positive residual seen.
_res_stats = _Stats(4.0)


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties)."""
    global _mean_item, _count

    # Incremental running mean of item sizes seen so far.
    _count += 1
    _mean_item += (item - _mean_item) / _count
    mu = _mean_item

    slack = (bins - item).astype(np.float64)
    residual = slack

    # Update residual tracker with the smallest positive residual (the
    # tightest fit achievable this step). This is the genuinely consumed
    # signal that drives the adaptive kernel center.
    pos = residual[residual > 0.0]
    if pos.size > 0:
        _res_stats.update(float(pos.min()))

    # Adaptive L2 kernel center, clamped to a safe range.
    center = max(2.0, min(8.0, _res_stats.mean))

    # Best-Fit core: tightest fit first.
    score = -slack

    # 1) Prefer bins that become exactly full.
    score += 0.01 * (residual == 0.0)

    # 2) Residual usefulness: residuals near the running mean are likely to be
    #    filled by a future item; tiny residuals are usually wasted.
    useful = (residual >= 0.5 * mu) & (residual <= 1.5 * mu)
    score += 0.005 * useful.astype(np.float64)
    score -= 0.002 * ((residual > 0.0) & (residual < 0.25 * mu)).astype(np.float64)

    # 3) Slight preference for already-used bins (consolidation).
    score += 0.001 * (bins < 100).astype(np.float64)

    # 4) Penalize dead-space residuals (1..4) that rarely get refilled.
    score -= 0.2 * ((residual >= 1.0) & (residual <= 4.0)).astype(np.float64)

    # 5) Adaptively-centered L2 kernel tie-break (bounded in (-0.5, 0.5)).
    d2 = (residual - center) ** 2
    score += 0.48 * np.exp(-0.5 * d2)

    return score
# EVOLVE-BLOCK-END