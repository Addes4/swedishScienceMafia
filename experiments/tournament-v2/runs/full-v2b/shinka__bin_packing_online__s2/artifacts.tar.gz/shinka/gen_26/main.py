# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Rule: strict best-fit as the dominant term, plus small sub-unit tie-break
    bonuses that never override a strictly tighter fit (residuals are integers,
    so a bonus in (-1, 1) only reorders bins with equal residuals).
    """
    residual = bins - item
    # Dominant term: best fit (prefer smallest residual).
    score = -residual.astype(np.float64)
    # Sweet-spot bonus: residuals near a typical item size (~40) can often be
    # filled efficiently by exactly one more item. Sub-unit, so tie-break only.
    score += 0.4 * ((residual >= 35) & (residual <= 50))
    # Small bonus for residuals that leave usable room for future items;
    # residuals below ~10 are hard to reuse.
    score += 0.15 * (residual >= 10)
    # Slight penalty for opening a brand-new bin (residual == 100 means empty).
    score -= 0.25 * (bins == 100)
    return score
# EVOLVE-BLOCK-END