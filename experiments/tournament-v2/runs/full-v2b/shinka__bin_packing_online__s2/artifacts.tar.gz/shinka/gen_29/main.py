# EVOLVE-BLOCK-START
"""Distribution-aware Best Fit for online bin packing.

Idea: rank bins not only by how tightly the item fits, but also by how
"reusable" the resulting residual capacity is expected to be, given the
item-size distribution (Weibull-shaped, mean ~40). A tiny deterministic
perturbation breaks ties to avoid the pathological symmetry of pure Best Fit.
"""
import numpy as np


# --- size-regime-dependent bin choice -------------------------------------
# With a Weibull-shaped item distribution (mean ~40, capacity 100), the stream
# contains many items larger than half the bin.  Placing such a large item into
# the tightest-fitting bin strands the remaining sliver, which small items could
# otherwise have used.  So we use two regimes:
#   * item <= 50 (small/medium): strict best-fit (fill gaps tightly).
#   * item >  50 (large):        worst-fit among fitting bins (leave the most
#                                remaining room for future small items).
# Residual r = remaining_capacity - item (>= 0 for bins shown).


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    # bins is a numpy int64 array of remaining capacities (only fitting bins).
    residual = bins - item                      # >= 0 by contract
    if item > 50:
        # Large item: prefer the emptiest fitting bin (most remaining room).
        score = residual.astype(np.float64)
    else:
        # Small/medium item: strict best-fit (tightest fit).
        score = -residual.astype(np.float64)

    # Deterministic, distribution-aware tie-break:
    # slight preference for lower-index bins (packing stability), plus a tiny
    # pseudo-random jitter keyed on (item, residual) to break exact ties in a
    # way that does not depend on instance-specific ordering.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    # jitter magnitude must be far below the real score gaps
    jitter = 1e-4 * (((item * 131 + residual * 17 + idx * 7) % 97) / 97.0)

    # small index preference (earlier bins slightly preferred)
    idx_pref = -1e-5 * idx

    return score + jitter + idx_pref
# EVOLVE-BLOCK-END