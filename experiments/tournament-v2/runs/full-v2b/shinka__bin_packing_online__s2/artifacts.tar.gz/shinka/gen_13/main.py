# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Improved rule: best-fit with a small bonus for residuals that are still "useful"
    (avoid creating tiny dead space) and a small penalty for opening a fresh bin.
    """
    residual = bins - item
    # Base: best fit (prefer smallest residual).
    score = -residual.astype(np.float64)
    # Distribution-aware sweet-spot bonus: residuals that can still absorb
    # another average-sized item (~40) are more reusable than neighbours.
    # Two narrow bumps keep the shape bounded and below 1.0 so best-fit order holds.
    score += 0.4 * ((residual >= 35) & (residual <= 45))
    score += 0.2 * ((residual >= 46) & (residual <= 55))
    # Mid residuals (10-29) are also reusable; small extra reward.
    score += 0.1 * ((residual >= 10) & (residual <= 29))
    # Slight penalty for opening a brand-new bin (residual == 100 means bin was empty).
    score -= 0.25 * (bins == 100)
    return score
# EVOLVE-BLOCK-END