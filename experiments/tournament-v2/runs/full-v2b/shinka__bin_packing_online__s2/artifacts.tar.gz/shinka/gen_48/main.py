# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with residual-usefulness tie-breaking.

Crossover of prior implementations:
  * Best-Fit (tightest slack) is the dominant term.
  * A running mean of item sizes drives a small "useful residual" bonus.
  * Dead-space residuals (1..4) are mildly penalized.
  * Exact fills and already-used bins get tiny tie-break bonuses.

All bonuses are < 0.01, so they never override a genuine best-fit choice
(slack is integer-valued); they only resolve near-ties.
"""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_mean_item = 40.0
_count = 0


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties)."""
    global _mean_item, _count

    # Incremental running mean of item sizes seen so far.
    _count += 1
    _mean_item += (item - _mean_item) / _count
    mu = _mean_item

    slack = (bins - item).astype(np.float64)
    residual = slack

    # Best-Fit core: tightest fit first.
    score = -slack

    # 1) Prefer bins that become exactly full.
    score += 0.01 * (residual == 0.0)

    # 2) Residual usefulness: residuals near the running mean are likely to be
    #    filled by a future item; tiny residuals are usually wasted.
    useful = (residual >= 0.5 * mu) & (residual <= 1.5 * mu)
    score += 0.005 * useful.astype(np.float64)
    score -= 0.002 * ((residual > 0.0) & (residual < 0.25 * mu)).astype(np.float64)

    # 3) Slight preference for already-used bins (consolidation).
    score += 0.001 * (bins < 100).astype(np.float64)

    # 4) Penalize dead-space residuals (1..4) that rarely get refilled.
    score -= 0.2 * ((residual >= 1.0) & (residual <= 4.0)).astype(np.float64)

    return score
# EVOLVE-BLOCK-END