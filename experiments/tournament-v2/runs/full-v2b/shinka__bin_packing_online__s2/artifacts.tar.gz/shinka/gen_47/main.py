# EVOLVE-BLOCK-START
"""Hybrid Distribution-aware Best Fit with fresh-bin penalty.

Combines:
  - smooth residual preference curve (best-fit base + sweet spots + exact-fit bonus + dead-zone penalty)
  - small penalty for opening a fresh bin
  - deterministic tie-break jitter + index preference
"""
import numpy as np


def _residual_score(r):
    """Vectorized score for residuals r >= 0. Higher = better."""
    rf = r.astype(np.float64)

    # base: strongly prefer small residuals (classic best-fit).
    base = -rf

    # High-reuse band: residuals near the mean item size (~40) can absorb
    # another typical item cleanly. Sharper triangular bump centred at 40.
    bump = np.maximum(0.0, 1.0 - np.abs(rf - 40.0) / 20.0)

    # Secondary sweet spot: residuals near 80 can absorb two average items.
    bump2 = np.maximum(0.0, 1.0 - np.abs(rf - 80.0) / 15.0)

    # Exact-fit bonus: residual ~0 means the bin is perfectly filled.
    exact = (rf <= 0.5).astype(np.float64)

    # Dead zone penalty: residuals 1-12 are hard to reuse given mean ~40.
    dead = np.maximum(0.0, 1.0 - np.abs(rf - 6.0) / 6.0)

    return base + 0.7 * bump + 0.3 * bump2 + 0.5 * exact - 0.3 * dead


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    residual = bins - item
    score = _residual_score(residual)

    # Penalize opening a fresh (previously empty) bin.
    score -= 0.25 * (bins == 100)

    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)

    # Deterministic tie-break jitter keyed on (item, residual, index).
    jitter = 1e-4 * (((item * 131 + residual * 17 + idx * 7) % 97) / 97.0)

    # Slight preference for lower-index bins (packing stability).
    idx_pref = -1e-5 * idx

    return score + jitter + idx_pref
# EVOLVE-BLOCK-END