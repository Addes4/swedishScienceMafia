# EVOLVE-BLOCK-START
"""Pure best-fit core with a deterministic index tie-break.

Stripped to the minimal rule per the Gen 24/27/36/37/39/40/41/62 plateau
evidence: every bounded secondary term (modal, mean-aligned, Gaussian bumps)
scored identically to pure best-fit because all are bounded below 1.0 and so
can never override a genuine integer residual gap of 1. The plateau at
0.962099 / 0.961184 is a genuine integer optimum for the best-fit family.

We keep only:
  - primary term: best fit (smallest residual wins), and
  - a 1e-9 * index tie-break (strictly below any integer residual gap and
    below any index-induced capacity decision), which makes the argmax
    deterministic and reproducible without changing the chosen bin.

This avoids the per-call np.exp / allocation overhead of the Gaussian bumps
(5000 calls per instance) while preserving the exact argmax.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    score = -residual
    # Deterministic tie-break by bin order (matches harness "first on ties").
    # 1e-9 << 1, so it never overrides an integer residual difference.
    score += 1e-9 * np.arange(bins.shape[0], dtype=np.float64)
    return score
# EVOLVE-BLOCK-END