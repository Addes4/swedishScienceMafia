# EVOLVE-BLOCK-START
"""Hybrid Distribution-aware Best Fit (v2).

Combines a strict best-fit base with a hard exact-fit bonus and a set of
bounded, distribution-aware tie-breakers whose total magnitude is strictly
less than 1.0, so a one-unit residual difference can never be overturned.

Tie-breakers (all sub-unit):
  * reusable residual bump centred at ~40 (mean item size)
  * secondary bump near 80 (two average items)
  * dead-zone penalty for residuals 1-12
  * fresh-bin penalty
  * small worst-fit-among-near-ties reward
  * tiny deterministic jitter + slight lower-index preference
"""
import numpy as np

_CAP = 100


def _residual_score(r):
    """Vectorized score for residuals r >= 0. Higher = better."""
    rf = r.astype(np.float64)

    # ---- LAYER 1: strict best fit (dominant) ----
    base = -rf

    # ---- LAYER 2: hard exact-fit bonus (dominates any residual gap) ----
    exact = 1000.0 * (r == 0).astype(np.float64)

    # ---- LAYER 3: bounded, sub-unit tie-breakers ----
    # High-reuse band: residuals near the mean item size (~40).
    bump = np.maximum(0.0, 1.0 - np.abs(rf - 40.0) / 20.0)

    # Secondary sweet spot: residuals near 80 can absorb two average items.
    bump2 = np.maximum(0.0, 1.0 - np.abs(rf - 80.0) / 15.0)

    # Dead zone: residuals 1-12 are hard to reuse given mean ~40.
    dead = np.maximum(0.0, 1.0 - np.abs(rf - 6.0) / 6.0)

    return base + exact + 0.6 * bump + 0.25 * bump2 - 0.35 * dead


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    residual = bins - item
    score = _residual_score(residual)

    # Fresh-bin penalty: discourage opening a new bin on a tie.
    score -= 0.2 * (bins == _CAP).astype(np.float64)

    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)

    # Worst-fit-among-near-ties: tiny positive reward proportional to residual,
    # scaled well below 1.0 so it only breaks genuine ties.
    worst_fit = 1e-3 * residual.astype(np.float64)

    # Deterministic jitter keyed on (item, residual, index).
    jitter = 1e-6 * (((item * 131 + residual * 17 + idx * 7) % 97) / 97.0)

    # Slight preference for lower-index bins (packing stability).
    idx_pref = -1e-6 * idx

    return score + worst_fit + jitter + idx_pref
# EVOLVE-BLOCK-END