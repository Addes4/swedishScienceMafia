# EVOLVE-BLOCK-START
"""Best fit with adaptive residual-usefulness tie-breaking."""
import numpy as np

# Running estimate of the mean item size seen so far (adaptive band center).
_mean_item = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean_item, _count
    # Incremental running mean of item sizes.
    _count += 1
    _mean_item += (item - _mean_item) / _count

    residual = (bins - item).astype(np.float64)
    # Primary term: best fit (smallest residual wins).
    score = -residual

    # Secondary term: prefer a leftover close to the typical future item size,
    # so the bin stays reusable. Bounded by 0.5 < 1.0, so it never overrides a
    # genuine integer capacity difference.
    mu = _mean_item
    sigma = 0.5 * mu
    score += 0.5 * np.exp(-((residual - mu) ** 2) / (2.0 * sigma * sigma))

    # Tertiary deterministic tie-break: among bins with identical residual,
    # consistently prefer the fuller bin. Coefficient 0.001 << 1.0, so it
    # cannot override any genuine integer capacity difference.
    score += 0.001 * (100.0 - residual) / 100.0
    return score
# EVOLVE-BLOCK-END