# EVOLVE-BLOCK-START
"""Strict best-fit with a stable, sub-unit index tie-break.

Rationale: prior generations showed that every distribution-aware bonus in
(-1, 1) only reorders bins with *equal* integer residuals, and the resulting
bin counts were bit-identical across dozens of variants (~0.962, ~4% above
LB). That is an integer optimum for the best-fit family, so the correct move
is to make the dominant term exactly strict best-fit and remove all bonuses
that cannot change the integer ordering. This guarantees we never do worse
than the baseline while cutting per-call work.

The only non-dominant term is a 1e-9 index preference, which is far below any
possible integer residual gap (>= 1.0), so it can only break exact ties -- and
it breaks them toward the earliest bin, matching the harness's "first on ties"
rule. No state, no distribution assumptions, no NaN risk.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (capacity 100), in fixed bin order.

    Rule: strict best-fit. Prefer the bin with the smallest residual
    (remaining_capacity - item). Ties are broken deterministically toward the
    earlier bin index via a 1e-9 preference that cannot override any strictly
    tighter fit.
    """
    residual = bins - item
    score = -residual.astype(np.float64)

    # Stable tie-break: prefer earlier bins. Magnitude 1e-9 << 1.0, so it
    # cannot overturn a one-unit residual difference.
    n = bins.shape[0]
    if n > 1:
        idx = np.arange(n, dtype=np.float64)
        score -= 1e-9 * idx
    return score
# EVOLVE-BLOCK-END