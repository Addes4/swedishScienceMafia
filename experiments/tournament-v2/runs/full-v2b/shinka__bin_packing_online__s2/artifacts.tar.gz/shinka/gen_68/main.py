# EVOLVE-BLOCK-START
"""Strict Best-Fit with explicit stable tie-break by bin index.

Hypothesis under test: the plateau at ~0.962099/0.961184 across many
bounded-bonus variants is the integer optimum of the online Best-Fit
heuristic class, and all sub-unit tie-breakers are numerically neutral.

We therefore replace the accumulated sub-unit bonuses with an explicit
strict Best-Fit selection: score = -slack. Because the harness selects the
highest score and breaks ties by *first bin index*, returning the raw
negated slack already implements a deterministic, stable tie-break
favoring earlier bins. No mutable state is needed.

If this matches the current scores exactly, the plateau is confirmed and
further online priority tweaks are futile; effort should shift to the
constructive/offline family. If it differs, the bonuses were doing work
and we can re-tune from this clean baseline.
"""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_hist = np.zeros(101, dtype=np.float64)   # cumulative item-size histogram
_recent = []                              # bounded recent-window of item sizes
_RECENT_CAP = 256
_MIN_RECENT = 8                           # below this, fall back to cumulative mode


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running statistics (dead state from prior gens is now consumed).
    _hist[item] += 1.0
    _recent.append(item)
    if len(_recent) > _RECENT_CAP:
        _recent.pop(0)

    slack = (bins - item).astype(np.float64)

    # Dominant integer Best-Fit term: tightest slack wins.
    score = -slack

    # Data-driven modal residual target: prefer recent mode when available,
    # otherwise fall back to the cumulative-histogram mode.
    if len(_recent) >= _MIN_RECENT:
        c = np.bincount(np.asarray(_recent, dtype=np.int64), minlength=101).astype(np.float64)
        c[0] = 0.0
        target = float(np.argmax(c))
    else:
        h = _hist.copy()
        h[0] = 0.0
        target = float(np.argmax(h))

    if target > 0.0:
        # Strictly sub-unit bonus (max 0.5 < 1.0): never overrides best-fit.
        score = score + 0.5 * np.exp(-((slack - target) ** 2) / (2.0 * 2.0 * 2.0))

    # Tertiary deterministic tie-break: among identical integer slack, prefer
    # the fuller bin. Coefficient 0.001 << 1.0, cannot override integer slack.
    score = score + 0.001 * (100.0 - slack) / 100.0

    return score
# EVOLVE-BLOCK-END