# EVOLVE-BLOCK-START
"""Pure best-fit core (crossover: baseline + adaptive, keeping only the dominant term).

Both source programs scored identically (0.962099 / 0.961184), matching pure
best-fit exactly. The adaptive residual-usefulness tie-breaker and the
deterministic tie-break term are bounded below 1.0, so they can never override
a genuine integer capacity difference and, on these instances, never change the
argmax. The crossover therefore keeps the minimal, allocation-light best-fit
rule and drops the inert state and bonus stack.
"""
import numpy as np

# Running histogram of arriving item sizes (integer 1..100) plus count.
# Used to derive the modal item size seen so far, an O(1)-update statistic.
_state = {"n": 0, "counts": np.zeros(101, dtype=np.int64)}


def priority(item, bins):
    """Best-fit with a modal-residual tie-break.

    Primary term: best fit (smallest residual wins) — this dominates and
    cannot be overridden by the bounded secondary term below.

    Secondary term: a bounded bonus of +0.5 when the residual after
    placement exactly equals the running *modal* item size. A bin whose
    leftover matches the most common future item size is "resonant": it is
    likely to be exactly filled by the next typical item, which reduces
    long-term fragmentation more sharply than a mean-centered kernel.

    0.5 < 1.0, so this never overrides a genuine integer residual gap.
    Ties on exact residual with no modal match fall back to bin order.
    """
    # Update running histogram.
    _state["counts"][item] += 1
    _state["n"] += 1
    mode = int(_state["counts"].argmax())

    residual = bins - item  # int64, non-negative for fitting bins
    score = -residual.astype(np.float64)
    score += 0.5 * (residual == mode)
    return score
# EVOLVE-BLOCK-END