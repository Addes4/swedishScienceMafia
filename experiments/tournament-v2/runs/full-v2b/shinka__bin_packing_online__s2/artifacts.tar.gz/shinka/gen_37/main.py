# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with utilization-scaled fresh-bin penalty.

Idea:
  * Best-Fit remains the dominant term (smallest slack wins).
  * A fresh-bin penalty discourages opening new bins, but its strength is
    scaled by how "full" the current bin pool is. Early on, opening bins is
    often unavoidable, so the penalty is small. Late in the run, when many
    bins are open, opening another bin should be strongly discouraged.
  * The utilization signal is estimated directly from `bins` (number of
    bins with remaining capacity < 100), so no mutable module state is needed.
  * A mild reservation term discourages dumping small items into very roomy
    bins when the pool is already tight.
"""
import numpy as np


def priority(item, bins):
    """Strict best-fit probe: dominant integer-slack term only.

    This intentionally contains NO sub-unit bonus, penalty, or tie-break.
    The harness resolves ties by first bin index, so returning the raw
    `-(bins - item)` is exactly the canonical best-fit rule: choose the
    bin with the smallest remaining slack, breaking ties by lowest index.

    Purpose: eliminate every bounded perturbation from Gens 20-28 and
    measure whether the observed plateau (0.962099 / 0.961184) is the
    integer optimum of the online best-fit class on this distribution,
    rather than an artifact of how ties were being resolved.
    """
    bins = np.asarray(bins)
    return -(bins.astype(np.float64) - float(item))
# EVOLVE-BLOCK-END