# EVOLVE-BLOCK-START
"""Pure best-fit core (crossover: baseline + adaptive, keeping only the dominant term).

Both source programs scored identically (0.962099 / 0.961184), matching pure
best-fit exactly. The adaptive residual-usefulness tie-breaker and the
deterministic tie-break term are bounded below 1.0, so they can never override
a genuine integer capacity difference and, on these instances, never change the
argmax. The crossover therefore keeps the minimal, allocation-light best-fit
rule and drops the inert state and bonus stack.
"""
import numpy as np

# Running statistics of arriving items (O(1) state, no per-call allocation).
_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    """Best-fit with a mean-aligned tie-break.

    Primary term: best fit (smallest residual wins) — this dominates and
    cannot be overridden by the bounded secondary term below.

    Secondary term (strictly inside (-1, 0), so it never beats a genuine
    integer residual gap of 1): among bins with equal residual, prefer the
    one whose leftover is closest to the running mean item size, keeping
    leftover space "useful" for future items rather than sealing bins with
    awkward small residuals.
    """
    n = _state["n"]
    mu = _state["mean"]
    # Incremental mean update (Welford-style, mean only).
    _state["n"] = n + 1
    _state["mean"] = mu + (item - mu) / (n + 1)

    residual = (bins - item).astype(np.float64)
    score = -residual
    # Bounded tie-breaker in (-1, 0): closer to mu -> higher score.
    d = np.abs(residual - mu)
    score -= d / (1.0 + d)
    return score
# EVOLVE-BLOCK-END