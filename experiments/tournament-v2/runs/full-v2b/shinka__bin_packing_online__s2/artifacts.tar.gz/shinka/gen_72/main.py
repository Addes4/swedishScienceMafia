# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with online-learned residual reservation.

Core idea:
  * Best-Fit remains the dominant term (smallest slack wins).
  * We maintain running statistics of arriving item sizes to estimate the
    typical "large" item size, and reward bins whose leftover capacity is
    close to that typical size (so a future large item can still fit).
  * The reservation strength adapts: early on it is weak (exploration),
    later it stabilizes on the observed distribution.
  * No future information is used; only past items seen in this instance.
"""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_state = {
    "n": 0,
    # size histogram over 1..100 (index 0 unused)
    "counts": np.zeros(101, dtype=np.float64),
    # cached "common residual" set: sizes whose observed frequency is high
    "res_set": None,
    "res_vals": None,
    "update_every": 64,
    # ---- diagnostic counters (do not affect scoring) ----
    # Used to determine whether integer-slack ties actually fire, which
    # decides whether tie-break research is viable at all.
    "diag": {
        "n_placements": 0,   # total priority() calls
        "n_ties": 0,         # calls where >=2 bins share the minimal slack
        "n_perfect": 0,      # calls where the chosen residual would be 0
        "n_min_width_sum": 0,  # sum of tie widths (for mean tie width)
        "tie_residual_hist": np.zeros(101, dtype=np.int64),
    },
}


def _update_stats(item):
    s = _state
    s["n"] += 1
    s["counts"][item] += 1.0


def _refresh_residual_targets():
    """Pick a small set of high-probability item sizes to aim residuals at.

    Leaving a residual equal to a frequent item size lets a future common
    item fit exactly, which tends to reduce fragmentation. We select the
    top few sizes by observed frequency, weighted toward larger sizes since
    they are harder to place.
    """
    s = _state
    counts = s["counts"]
    c = counts.copy()
    c[0] = 0.0
    # score sizes by frequency * sqrt(size): favor frequent AND large.
    sizes = np.arange(101, dtype=np.float64)
    weight = c * np.sqrt(sizes)
    # take top 6 sizes
    idx = np.argsort(-weight)[:6]
    vals = idx[idx > 0].astype(np.float64)
    s["res_set"] = set(int(v) for v in vals)
    s["res_vals"] = vals


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties).

    Dominant term is strict best-fit (-slack). The only place a real-valued
    term can influence the choice is among bins with *equal* integer slack,
    so we restrict adaptation to a sub-unit tie-break (<1) that prefers
    residuals matching frequent future item sizes.
    """
    _update_stats(item)
    s = _state
    # refresh the residual-target set periodically (cheap, amortized)
    if s["res_set"] is None or (s["n"] % s["update_every"] == 0):
        _refresh_residual_targets()

    slack = bins.astype(np.float64) - float(item)

    # ---- diagnostic: measure whether integer-slack ties actually fire ----
    # This is pure instrumentation; it does not affect the returned score.
    diag = s["diag"]
    diag["n_placements"] += 1
    if slack.size > 0:
        min_slack = float(slack.min())
        n_min = int(np.count_nonzero(slack == min_slack))
        diag["n_min_width_sum"] += n_min
        if n_min >= 2:
            diag["n_ties"] += 1
            r = int(min_slack)
            if 0 <= r <= 100:
                diag["tie_residual_hist"][r] += 1
        if min_slack == 0.0:
            diag["n_perfect"] += 1

    # Dominant integer best-fit term.
    score = -slack

    # Sub-unit tie-break (< 1.0, never overrides integer slack): among bins
    # with equal slack, prefer the one whose leftover is "useful" rather than
    # a tiny wasted residual in [1,4]. A residual in [1,4] is effectively
    # dead space (the swap-repair insight), so we penalize it slightly and
    # reward residuals that can still hold a small item. Bounded by 0.5 so
    # best-fit integer slack always dominates.
    residual = slack
    # Penalize near-zero-but-nonzero residuals ([1,4]) which waste a bin.
    dead = (residual >= 1.0) & (residual <= 4.0)
    # Reward residuals in a "useful small item" band [5, 15].
    useful = (residual >= 5.0) & (residual <= 15.0)
    tie = 0.5 * useful.astype(np.float64) - 0.5 * dead.astype(np.float64)
    score = score + tie

    return score
# EVOLVE-BLOCK-END