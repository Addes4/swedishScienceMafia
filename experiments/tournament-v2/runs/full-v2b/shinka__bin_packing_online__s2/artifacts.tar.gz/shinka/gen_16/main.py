# EVOLVE-BLOCK-START
"""Distribution-aware Best Fit for online bin packing.

Idea: rank bins not only by how tightly the item fits, but also by how
"reusable" the resulting residual capacity is expected to be, given the
item-size distribution (Weibull-shaped, mean ~40). A tiny deterministic
perturbation breaks ties to avoid the pathological symmetry of pure Best Fit.
"""
import numpy as np


# --- distribution-aware score for the residual after placing the item ---
# Residual r = remaining_capacity - item  (>= 0 for bins shown).
# Lower r is generally better (best-fit). But residuals that are exactly
# in a "pairing sweet spot" for the mean item size (~40) are slightly better
# than neighbours, because they can be efficiently filled later.
# We build a smooth preference curve and combine it with a small tie-break.

def _residual_score(r):
    """Vectorized score for an array of residuals r >= 0. Higher = better."""
    rf = r.astype(np.float64)

    # base: strongly prefer small residuals (classic best-fit).
    base = -rf

    # High-reuse band: residuals near the mean item size (~40) can absorb
    # another typical item cleanly. Sharper triangular bump centred at 40.
    bump = np.maximum(0.0, 1.0 - np.abs(rf - 40.0) / 20.0)

    # Secondary sweet spot: residuals near 80 can absorb two average items.
    bump2 = np.maximum(0.0, 1.0 - np.abs(rf - 80.0) / 15.0)

    # Exact-fit bonus: residual ~0 means the bin is perfectly filled.
    exact = (rf <= 0.5).astype(np.float64)

    # Dead zone penalty: residuals 1-12 are hard to reuse given mean ~40.
    dead = np.maximum(0.0, 1.0 - np.abs(rf - 6.0) / 6.0)

    # Tiny-sliver penalty: residuals 1-4 are essentially never refillable
    # (no realistic future item is that small), so leaving them wastes a bin.
    tiny_dead = ((rf >= 1.0) & (rf <= 4.0)).astype(np.float64)

    return (base + 0.7 * bump + 0.3 * bump2 + 0.5 * exact
            - 0.3 * dead - 0.2 * tiny_dead)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    # bins is a numpy int64 array of remaining capacities (only fitting bins).
    residual = bins - item                      # >= 0 by contract
    score = _residual_score(residual)

    # Deterministic, distribution-aware tie-break:
    # slight preference for lower-index bins (packing stability), plus a tiny
    # pseudo-random jitter keyed on (item, residual) to break exact ties in a
    # way that does not depend on instance-specific ordering.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    # jitter magnitude must be far below the real score gaps
    jitter = 1e-4 * (((item * 131 + residual * 17 + idx * 7) % 97) / 97.0)

    # small index preference (earlier bins slightly preferred)
    idx_pref = -1e-5 * idx

    return score + jitter + idx_pref
# EVOLVE-BLOCK-END