# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    # Primary term: best fit (smallest residual wins).
    score = -residual
    # Secondary term: among (near-)equal residuals, prefer a leftover that is
    # close to the typical future item size (mean ~40 for this distribution),
    # so the bin stays useful. Bounded by 0.5 < 1, so it never overrides a
    # genuine integer capacity difference.
    score += 0.5 * np.exp(-((residual - 40.0) ** 2) / (2.0 * 20.0 ** 2))
    return score
# EVOLVE-BLOCK-END