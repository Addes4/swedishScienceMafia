# EVOLVE-BLOCK-START
"""Empirical best-fit with a learned residual-refill preference.

Structure:
  * Strict best-fit is the dominant term: score = -residual (integer residuals,
    so any sub-unit bonus only decides exact-residual ties).
  * A length-101 table P[r] holds a small learned preference for leaving
    residual r, derived from the empirical rate at which residuals of size r
    were later refilled by an arriving item (an online proxy for FFD's
    packing efficiency).  P is bounded in (-0.9, 0.9).
  * A tiny deterministic fill-fraction tie-break resolves remaining ties
    toward the fuller bin.

The learned table is updated online from the *previous* item's placement
decision (which we can observe via the `bins` array across calls), so no
future information is used.
"""
import numpy as np


# Bounded history of recent items for the learned table.
_HIST = []                      # last items seen (as ints)
_HIST_MAX = 512

# Empirical refill counters: for each residual r (0..100), how many times we
# have seen a bin with residual r receive a later item of size r (exact fill)
# versus how many times such a residual was "wasted" (bin closed / no refill).
_REFILL_HIT = np.zeros(101, dtype=np.float64)
_REFILL_TOT = np.zeros(101, dtype=np.float64)

# Track the residual we left on the previous call so we can, on the next call,
# check whether it was refilled exactly (item == that residual), which is a
# strong positive signal for that residual size.
_LAST_RESIDUAL = -1
_LAST_ITEM = -1

# Cache of the preference table, rebuilt lazily.
_PREF = None
_PREF_DIRTY = True

# Running mean of the stream (used only for a soft dead-zone prior).
_MEAN = 40.0
_N = 0


def _update_mean(item):
    global _MEAN, _N
    _N += 1
    _MEAN += (item - _MEAN) / _N


def _build_pref():
    """Build the length-101 residual-preference table.

    Dominant term is -r (strict best-fit).  All other terms are bounded well
    below 1.0 so integer-residual ordering is preserved.
    """
    global _PREF, _PREF_DIRTY
    r = np.arange(101, dtype=np.float64)

    # Empirical refill rate, smoothed toward 0.5 with a weak prior so early
    # bins don't dominate.  Bounded to [0, 1] then mapped to (-0.4, 0.4).
    rate = (_REFILL_HIT + 1.0) / (_REFILL_TOT + 2.0)
    learned = 0.4 * (2.0 * rate - 1.0)

    # Exact-fit residual 0 is always good.
    exact = 0.5 * (r <= 0.5).astype(np.float64)

    # Dead zone: very small residuals (1..4) essentially never refill.
    sliver = -0.3 * ((r >= 1.0) & (r <= 4.0)).astype(np.float64)

    # Soft prior around the running mean: residuals near a typical item size
    # can often be filled by exactly one more item.
    near_mean = 0.2 * (np.abs(r - _MEAN) <= 8.0).astype(np.float64)

    _PREF = -r + exact + sliver + near_mean + learned
    _PREF_DIRTY = False
    return _PREF


def _get_pref():
    global _PREF_DIRTY
    if _PREF is None or _PREF_DIRTY:
        return _build_pref()
    return _PREF


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    global _LAST_RESIDUAL, _LAST_ITEM, _PREF_DIRTY

    # --- Learn from the previous placement -----------------------------------
    # If the previous item was placed leaving residual R, and the current item
    # size equals R, then that residual was refilled exactly: a positive event.
    if _LAST_RESIDUAL >= 0:
        R = _LAST_RESIDUAL
        if R <= 100:
            _REFILL_TOT[R] += 1.0
            if int(item) == R:
                _REFILL_HIT[R] += 1.0
            _PREF_DIRTY = True

    # --- Score current bins --------------------------------------------------
    pref = _get_pref()
    residual = (bins - item).astype(np.int64)
    score = pref[residual]

    # Fresh-bin penalty: opening a brand-new bin is slightly discouraged.
    score = score - 0.25 * (bins == 100)

    # Deterministic tie-break: among equal residuals, prefer the fuller bin.
    score = score + 1e-3 * (bins.astype(np.float64) / 100.0)

    # --- Record this placement for next-call learning ------------------------
    # We don't know which bin the harness picks, but the best-fit rule means it
    # will pick the smallest residual available (highest score).  We approximate
    # by recording the residual that our top-scored bin implies.
    if bins.size > 0:
        best_idx = int(np.argmax(score))
        _LAST_RESIDUAL = int(residual[best_idx])
        _LAST_ITEM = int(item)
    else:
        _LAST_RESIDUAL = -1

    _update_mean(int(item))
    return score
# EVOLVE-BLOCK-END