# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Improved rule: best-fit with a small bonus for residuals that are still "useful"
    (avoid creating tiny dead space) and a small penalty for opening a fresh bin.
    """
    residual = bins - item
    # Base: best fit (prefer smallest residual).
    score = -residual.astype(np.float64)
    # Small bonus for residuals that leave usable room for future items.
    # Residuals below ~10 are hard to reuse; reward residuals >= 10.
    score += 0.5 * (residual >= 10)
    # Slight penalty for opening a brand-new bin (residual == 100 means bin was empty).
    score -= 0.25 * (bins == 100)
    return score
# EVOLVE-BLOCK-END