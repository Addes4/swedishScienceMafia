# EVOLVE-BLOCK-START
"""Strict Best-Fit with a data-driven modal-residual tie-break.

The online Best-Fit class has plateaued at ~0.962099/0.961184 across many
sub-unit bonus variants.  This variant keeps strict Best-Fit as the
dominant, load-bearing term (integer slack, so any sub-unit bonus is a
pure tie-breaker that cannot override a tighter fit) and introduces a new
tie-break class never tested before: a *data-driven residual-to-future-item
match*.

We keep a small bounded histogram of the last W item sizes seen so far.
For each candidate bin, we look at the integer slack s = bin_remaining -
item; if s equals a size that has appeared frequently in the recent item
stream, that bin is likely to be filled exactly by a nearby future item,
so we give it a small bonus proportional to the recent frequency of s.
This complements (rather than replaces) the dead-space rule: exact fills
are already covered by the frequency match when s == 0 is frequent, and
residuals in 1..4 that no recent item can fill get a small penalty.

State (the histogram) is module-level and persists across calls within an
instance; it is a purely online signal (no future items are seen).
"""
import numpy as np
from collections import deque

# ---- module-level state ----
_WINDOW = 64
_recent = deque(maxlen=_WINDOW)
# Histogram over sizes 0..100 (index by integer size; index 0 unused).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update the recent-item histogram (drop the oldest entry if the window is full).
    if len(_recent) == _WINDOW:
        _hist[_recent[0]] -= 1.0
    _recent.append(item)
    _hist[item] += 1.0

    slack = (bins - item).astype(np.float64)
    # Primary term: strict Best-Fit (tightest slack wins).  Integer slack, so
    # any sub-unit term below is a pure tie-breaker and cannot override a
    # tighter fit.
    base = -slack

    residual = slack  # capacity left in this bin after placing the item

    # ---- tie-breakers (only matter when slack ties) ----
    # Normalized recent frequency of the integer residual value (0..100).
    # Bins whose residual matches a modal recent item size are likely to be
    # filled exactly by a nearby future item.
    is_int = (residual >= 0) & (residual <= 100) & (residual == np.floor(residual))
    idx = np.where(is_int, residual, 0).astype(np.int64)
    freq = _hist[idx] / float(_WINDOW)

    # Small bonus proportional to recent modal match (bounded by 1.0).
    base += 0.05 * freq

    # Exact fill: still slightly preferred on top of any frequency match.
    base += 0.01 * (residual == 0)

    # Dead-space penalty: residuals 1..4 that no recent item can fill.
    # Only apply when the residual is not itself a modal recent size.
    dead = (residual >= 1) & (residual <= 4)
    base -= 0.01 * (dead & (freq < 0.05)).astype(np.float64)

    return base
# EVOLVE-BLOCK-END