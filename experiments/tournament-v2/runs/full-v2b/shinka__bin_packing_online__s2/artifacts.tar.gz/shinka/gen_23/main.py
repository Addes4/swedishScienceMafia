# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with utilization-scaled fresh-bin penalty.

Idea:
  * Best-Fit remains the dominant term (smallest slack wins).
  * A fresh-bin penalty discourages opening new bins, but its strength is
    scaled by how "full" the current bin pool is. Early on, opening bins is
    often unavoidable, so the penalty is small. Late in the run, when many
    bins are open, opening another bin should be strongly discouraged.
  * The utilization signal is estimated directly from `bins` (number of
    bins with remaining capacity < 100), so no mutable module state is needed.
  * A mild reservation term discourages dumping small items into very roomy
    bins when the pool is already tight.
"""
import numpy as np


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties)."""
    bins = np.asarray(bins)
    slack = bins.astype(np.float64) - float(item)

    # ----- utilization signal from the current bin array -----
    # A bin is "open" (already used) if its remaining capacity is less than
    # the full capacity 100. Unused bins have capacity exactly 100.
    n_total = bins.shape[0]
    n_open = int(np.count_nonzero(bins < 100))
    # Fraction of visible bins that are already open. Grows as the run
    # progresses; bounded in [0, 1].
    util = n_open / float(n_total) if n_total > 0 else 0.0

    # ----- Best-Fit core (dominant term: smallest slack wins) -----
    score = -slack

    # ----- utilization-scaled fresh-bin penalty (sub-1.0 tie-breaker) -----
    # Kept strictly below 1.0 so it can never override the integer slack
    # ordering that protected every program scoring >= 0.96. Early (util
    # small) the penalty is tiny; late (util large) it approaches ~0.5,
    # discouraging opening yet another bin while still remaining a
    # tie-breaker relative to a full unit of slack.
    fresh_penalty = 0.05 + 0.45 * util
    score = score - fresh_penalty * (bins == 100).astype(np.float64)

    # ----- mild reservation for very roomy bins (sub-1.0 tie-breaker) -----
    # Only penalize when the leftover after placement would be much larger
    # than the item itself AND the pool is already tight. This preserves
    # roomy bins for future large items without hurting early packing.
    roomy = np.maximum(0.0, slack - float(item))
    score = score - (0.01 + 0.05 * util) * roomy

    # ----- deterministic fill-fraction tie-break -----
    # Among bins with identical residual (the only situation where any
    # sub-1.0 term can act), consistently prefer the fuller bin: smaller
    # remaining capacity -> larger score. This replaces unobservable
    # pseudo-random tie-breaks with a reproducible, allocation-light term
    # that cannot override the dominant -slack ordering.
    score = score + 0.001 * (bins.astype(np.float64) / 100.0)

    return score
# EVOLVE-BLOCK-END