# EVOLVE-BLOCK-START
"""Distribution-aware best-fit via a precomputed residual preference profile.

Structure:
  * `_build_profile()` constructs a length-101 table P[r] giving the desirability
    of leaving residual capacity r (0..100) after placing the current item.
  * `priority(item, bins)` gathers P[bins - item] and adds a tiny deterministic
    fill-fraction tie-break so equal residuals resolve to the fuller bin.

The dominant term is strict best-fit (monotonically decreasing in residual);
all other effects are bounded well below 1.0 so they only decide near-ties.
"""
import numpy as np


def _build_profile():
    """Return array P of length 101: P[r] = score for leaving residual r."""
    r = np.arange(101, dtype=np.float64)

    # Dominant term: strict best-fit. Prefer smallest residual.
    base = -r

    # Exact-fit bonus: residual ~0 means the bin is perfectly packed.
    exact = (r <= 0.5).astype(np.float64)

    # Sweet spot near a typical item size (~40): can absorb one more item.
    bump40 = np.maximum(0.0, 1.0 - np.abs(r - 40.0) / 20.0)
    # Sweet spot near ~80: can absorb two average items.
    bump80 = np.maximum(0.0, 1.0 - np.abs(r - 80.0) / 15.0)

    # Dead zone: residuals 1..12 are hard to reuse given mean ~40.
    dead = np.maximum(0.0, 1.0 - np.abs(r - 6.0) / 6.0)

    # Tiny sliver: residuals 1..4 essentially never refillable.
    sliver = ((r >= 1.0) & (r <= 4.0)).astype(np.float64)

    # Fresh-bin marker handled in priority via bins==100; profile stays residual-only.
    return (base
            + 0.5 * exact
            + 0.7 * bump40
            + 0.3 * bump80
            - 0.3 * dead
            - 0.2 * sliver)


_PROFILE = _build_profile()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    residual = (bins - item).astype(np.int64)
    # Gather precomputed residual desirability.
    score = _PROFILE[residual]

    # Fresh-bin penalty: opening a brand-new bin is slightly discouraged.
    score = score - 0.25 * (bins == 100)

    # Deterministic tie-break: among equal residuals, prefer the fuller bin
    # (smaller remaining capacity -> higher fill fraction). Bounded << 1.0.
    score = score + 1e-3 * (bins.astype(np.float64) / 100.0)

    return score
# EVOLVE-BLOCK-END