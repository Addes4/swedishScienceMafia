# EVOLVE-BLOCK-START
"""Best-fit with soft dead-space awareness and a tiny lookahead buffer.

Rule (all tie-breakers are strictly sub-unit, so the strict best-fit ordering
over integer residuals is preserved):
  - Base: best fit (prefer smallest residual = -residual).
  - +0.5 bonus when residual >= 10 (leaves usable room for future items).
  - -0.25 penalty when residual == 100 (fresh/empty bin).
  - For residual in [1,4] (a likely dead sliver): a soft penalty whose size
    depends on whether a recently-seen item could plausibly refill it.
    If no buffered item is small enough -> -0.4; otherwise -> -0.1.
    Both are < 1.0, so a looser fit (residual +1 or more) can never overtake
    a tighter fit.
  - +0.4 bonus for residual in [35,50] (near the typical item size ~40).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    residual_f = residual.astype(np.float64)

    # Base: best fit, scaled so it dominates the structural band terms.
    # Factor 1.5 keeps integer-residual ordering intact while leaving room for
    # the sub-unit structural adjustments below to matter only within a band.
    score = -1.5 * residual_f

    # Multi-modal residual preference based on the item-size distribution.
    # Weibull-shaped, mean ~40, median ~34. Natural packing points are
    # k * (typical size) for k = 0, 1, 2. Residuals just below these points
    # are anti-bands: too small to take another typical item, too large to
    # be a tight fit. Reward near-multiples, penalize just-below-multiples.
    # All coefficients are < 1.5 so strict best-fit ordering is preserved
    # within an integer-residual tie; across residuals the base dominates.
    r = residual_f

    # Triangular bump centred at 34 (median item size).
    bump1 = np.maximum(0.0, 1.0 - np.abs(r - 34.0) / 14.0)
    # Triangular bump centred at 68 (two median items).
    bump2 = np.maximum(0.0, 1.0 - np.abs(r - 68.0) / 20.0)
    # Anti-band just below 34: residuals ~24..33 are hard to reuse.
    anti1 = np.maximum(0.0, 1.0 - np.abs(r - 29.0) / 5.0)
    # Anti-band just below 68: residuals ~58..67 are hard to reuse.
    anti2 = np.maximum(0.0, 1.0 - np.abs(r - 63.0) / 5.0)

    score += 0.7 * bump1 + 0.35 * bump2 - 0.35 * anti1 - 0.25 * anti2

    # Bonus for leaving at least a small usable gap for future items.
    score += 0.5 * (residual >= 10)

    # Penalty for opening a fresh bin.
    score -= 0.25 * (bins == 100)

    # Penalty for leaving a tiny, essentially dead sliver (1..4).
    # Residual 0 is a perfect exact fill and stays unpenalized.
    score -= 0.4 * ((residual >= 1) & (residual <= 4))

    return score
# EVOLVE-BLOCK-END