# EVOLVE-BLOCK-START
"""Dual-threshold Best Fit for online bin packing.

The previous family of programs (best-fit plus various bounded bonuses) all
plateaued at the same score, confirming the bonuses are inert. The real
inefficiency of Best Fit on this distribution is that it happily creates
small residuals (e.g. 5-15) that no future ~40-sized item can ever reclaim,
stranding capacity.

This rule separates the decision into two regimes:

  1. Exact fit (residual 0): always take it. This closes a bin perfectly.
  2. Otherwise prefer the *tightest fit whose residual is still usable*,
     i.e. the smallest residual >= THRESH. Such a bin can still accept
     another typical item later.
  3. If no bin leaves a usable residual, fall back to plain Best Fit
     (minimize residual) so we do not waste an entire bin on a bad fit.

A tiny deterministic jitter breaks ties without altering the ordering.
"""
import numpy as np

# A typical item size under the Weibull-shaped distribution (mean ~40).
# A residual at least this large can plausibly absorb another item.
THRESH = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    residual = (bins - item).astype(np.float64)   # >= 0 by contract
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)

    # --- regime 1: exact fit dominates everything ---
    exact = 1000.0 * (residual == 0)

    # --- regime 2: usable residuals, tighter is better ---
    # For residuals >= THRESH, score decreases with residual (best-fit among
    # usable), but any usable residual beats any unusable one.
    usable = residual >= THRESH
    usable_score = np.where(usable, -residual, 0.0)

    # --- regime 3: fallback best-fit for unusable residuals ---
    # Among residuals < THRESH (and > 0), minimize residual as usual, but
    # strictly below the usable regime.
    unusable_score = np.where(usable, 0.0, -residual - 200.0)

    score = exact + usable_score + unusable_score

    # Tiny deterministic tie-break jitter (never changes the ordering).
    jitter = 1e-6 * (((item * 131 + residual * 17 + idx * 7) % 97) / 97.0)

    return score + jitter
# EVOLVE-BLOCK-END