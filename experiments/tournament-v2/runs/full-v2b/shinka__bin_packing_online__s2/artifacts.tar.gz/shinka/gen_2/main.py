# EVOLVE-BLOCK-START
"""Distribution-aware Best Fit for online bin packing.

Idea: rank bins not only by how tightly the item fits, but also by how
"reusable" the resulting residual capacity is expected to be, given the
item-size distribution (Weibull-shaped, mean ~40). A tiny deterministic
perturbation breaks ties to avoid the pathological symmetry of pure Best Fit.
"""
import numpy as np


# --- distribution-aware score for the residual after placing the item ---
# Residual r = remaining_capacity - item  (>= 0 for bins shown).
# Lower r is generally better (best-fit). But residuals that are exactly
# in a "pairing sweet spot" for the mean item size (~40) are slightly better
# than neighbours, because they can be efficiently filled later.
# We build a smooth preference curve and combine it with a small tie-break.

def _residual_score(r):
    """Vectorized score for an array of residuals r >= 0. Higher = better."""
    # base: strongly prefer small residuals (negative linear + slight convexity)
    base = -r.astype(np.float64)

    # sweet spot: residuals near 40-60 can absorb another average item well.
    # add a mild bonus with a triangular bump centred at 50, width 25.
    bump = np.maximum(0.0, 1.0 - np.abs(r - 50.0) / 25.0)

    # small residual (0-10) is best-fit territory; give it a mild bonus too
    tight = np.maximum(0.0, 1.0 - r / 10.0)

    return base + 0.6 * bump + 0.4 * tight


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    # bins is a numpy int64 array of remaining capacities (only fitting bins).
    residual = bins - item                      # >= 0 by contract
    score = _residual_score(residual)

    # Deterministic, distribution-aware tie-break:
    # slight preference for lower-index bins (packing stability), plus a tiny
    # pseudo-random jitter keyed on (item, residual) to break exact ties in a
    # way that does not depend on instance-specific ordering.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    # jitter magnitude must be far below the real score gaps
    jitter = 1e-4 * (((item * 131 + residual * 17 + idx * 7) % 97) / 97.0)

    # small index preference (earlier bins slightly preferred)
    idx_pref = -1e-5 * idx

    return score + jitter + idx_pref
# EVOLVE-BLOCK-END
