# EVOLVE-BLOCK-START
"""Strict best-fit with deterministic tie-breaking.

Rule:
  - Primary key: strict best fit. Prefer the bin whose residual after
    placing the item is smallest (tightest packing).
  - Tie-break: the harness's "highest score, first on ties" already
    implements lowest-index preference among equal scores, so equal
    residuals resolve to the lowest bin index deterministically.
  - A single sub-unit penalty discourages opening a fresh bin when an
    already-open bin offers the same residual.

All sub-unit terms are bounded well below the integer residual gap
K = 1000.0, so they can only resolve exact ties and never override the
strict best-fit ordering. No randomness, no state, no jitter.
"""
import numpy as np


# Scale factor: any integer difference in residual (>= 1) dominates all
# sub-unit tie-breakers below, preserving "tighter fit always wins".
_K = 1000.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Primary key: strict best fit (smallest residual wins).
    score = -_K * residual.astype(np.float64)

    # Sub-unit tie-breaker: prefer an already-open bin over opening a
    # fresh one. Residual == 100 only occurs for empty bins; this term
    # only fires on exact-residual ties and is bounded well below _K.
    score -= 0.5 * (bins == 100)

    return score
# EVOLVE-BLOCK-END