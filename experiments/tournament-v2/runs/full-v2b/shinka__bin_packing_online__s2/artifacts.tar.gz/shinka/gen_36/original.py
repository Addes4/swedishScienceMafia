# EVOLVE-BLOCK-START
"""Distribution-aware Best Fit with fresh-bin penalty.

Combines:
  - smooth residual preference curve (best-fit base + sweet-spot bump + tight bonus)
  - small penalty for opening a fresh bin
  - deterministic tie-break jitter + index preference
"""
import numpy as np


def _residual_score(r):
    """Vectorized score for residuals r >= 0. Higher = better."""
    r = r.astype(np.float64)
    base = -r
    # Sweet spot around mean item size (~50) to absorb another average item.
    bump = np.maximum(0.0, 1.0 - np.abs(r - 50.0) / 25.0)
    # Tight residuals are best-fit territory; mild bonus.
    tight = np.maximum(0.0, 1.0 - r / 10.0)
    return base + 0.6 * bump + 0.4 * tight


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    residual = bins - item
    score = _residual_score(residual)

    # Penalize opening a fresh (previously empty) bin.
    score -= 0.25 * (bins == 100)

    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    # Deterministic tie-break jitter keyed on (item, residual, index).
    jitter = 1e-4 * (((item * 131 + residual * 17 + idx * 7) % 97) / 97.0)
    # Slight preference for lower-index bins (packing stability).
    idx_pref = -1e-5 * idx

    return score + jitter + idx_pref
# EVOLVE-BLOCK-END