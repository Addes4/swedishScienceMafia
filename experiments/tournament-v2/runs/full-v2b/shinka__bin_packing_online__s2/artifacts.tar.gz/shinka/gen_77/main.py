# EVOLVE-BLOCK-START
"""Minimal best-fit with index tie-break.

Strips the histogram-based reuse bonus and fresh-bin penalty. Only two
terms remain:

  1) PRIMARY: strict best fit. score = -residual, so a one-unit residual
     difference strictly dominates any tie-breaker.
  2) TIE-BREAK: +1e-9 * index. Among bins with equal residual, prefer the
     one that appears earliest in the array (i.e. was created earlier),
     which is equivalent to "first-fit among equals" and avoids opening
     new bins when an older bin offers the same residual.

The tie-break magnitude 1e-9 is many orders of magnitude below the unit
gap between distinct integer residuals, so the best-fit invariant holds
exactly. No state, no randomness, no histogram.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item (1..100).
    bins: numpy int64 array of remaining capacities (all bins the item fits in),
          in fixed bin-index order.
    """
    residual = bins - item  # int64, >= 0 for every bin shown

    # PRIMARY: strict best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # TIE-BREAK: prefer earlier bins on exact residual ties.
    n = bins.shape[0]
    score += 1e-9 * np.arange(n, dtype=np.float64)

    return score
# EVOLVE-BLOCK-END