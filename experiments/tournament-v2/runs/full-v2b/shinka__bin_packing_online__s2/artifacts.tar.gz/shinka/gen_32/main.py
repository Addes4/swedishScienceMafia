# EVOLVE-BLOCK-START
"""Distribution-derived best-fit: rank residuals by expected future packability.

Instead of hand-tuned bumps near 40/80, build the residual preference profile
from the item distribution itself. For a residual r, define

    fit_prob(r)  = P(next item fits in r)      = P(item <= r)
    fill(r)      = E[ r/(r+item) | item <= r ]  (fraction of residual reclaimed)

and score residual r by fit_prob(r) * fill(r). Residuals near multiples of the
mean have both high fit probability and high expected fill, so the 40/80 sweet
spots emerge from the distribution rather than being hard-coded. Strict
best-fit is preserved as the dominant term so ordering is well-defined.
"""
import numpy as np


def _weibull_pmf():
    """Return pmf over item sizes 1..100 for the target distribution.

    The harness draws integer sizes from a Weibull-shaped distribution with
    mean about 40. We approximate it with a discretized Weibull(k=2, lam=45)
    truncated to [1,100] and renormalized. This is a fixed, instance-independent
    prior; it does not depend on observed items.
    """
    sizes = np.arange(1, 101, dtype=np.float64)
    k, lam = 2.0, 45.0
    pdf = (k / lam) * (sizes / lam) ** (k - 1.0) * np.exp(-(sizes / lam) ** k)
    pdf = np.maximum(pdf, 1e-12)
    return pdf / pdf.sum()


def _build_profile():
    """Return array P of length 101: P[r] = desirability of leaving residual r."""
    r = np.arange(101, dtype=np.float64)
    pmf = _weibull_pmf()          # index i -> P(item == i+1)
    cdf = np.cumsum(pmf)          # cdf[i] = P(item <= i+1)

    # fit_prob(r) = P(item <= r); use cdf at r-1 (0-based) for r >= 1.
    fit_prob = np.zeros(101, dtype=np.float64)
    for rv in range(1, 101):
        fit_prob[rv] = cdf[rv - 1]

    # fill(r) = E[ r/(r+item) | item <= r ] = sum_{i<=r} p_i * r/(r+i) / fit_prob(r)
    fill = np.zeros(101, dtype=np.float64)
    for rv in range(1, 101):
        idx = np.arange(1, rv + 1, dtype=np.float64)   # item sizes 1..rv
        p = pmf[:rv]
        num = np.sum(p * (rv / (rv + idx)))
        fill[rv] = num / fit_prob[rv] if fit_prob[rv] > 0 else 0.0

    # Expected future utility of residual r. Bounded in [0, 1].
    utility = fit_prob * fill

    # Dominant term: strict best-fit. Prefer smallest residual.
    base = -r

    # Exact-fit bonus: residual ~0 is perfectly packed.
    exact = (r <= 0.5).astype(np.float64)

    return base + 0.5 * exact + 0.6 * utility


_PROFILE = _build_profile()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    residual = (bins - item).astype(np.int64)
    score = _PROFILE[residual]

    # Deterministic tie-break: among equal residuals, prefer the fuller bin.
    # Bounded well below 1.0 so it only resolves exact ties.
    score = score + 1e-3 * (bins.astype(np.float64) / 100.0)

    return score
# EVOLVE-BLOCK-END