# EVOLVE-BLOCK-START
"""Adaptive Best-Fit with online-learned residual reservation.

Core idea:
  * Best-Fit remains the dominant term (smallest slack wins).
  * We maintain running statistics of arriving item sizes to estimate the
    typical "large" item size, and reward bins whose leftover capacity is
    close to that typical size (so a future large item can still fit).
  * The reservation strength adapts: early on it is weak (exploration),
    later it stabilizes on the observed distribution.
  * No future information is used; only past items seen in this instance.
"""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_state = {
    "n": 0,
    # size histogram over 1..100 (index 0 unused)
    "counts": np.zeros(101, dtype=np.float64),
    # cached "common residual" set: sizes whose observed frequency is high
    "res_set": None,
    "res_vals": None,
    "update_every": 64,
}


def _update_stats(item):
    s = _state
    s["n"] += 1
    s["counts"][item] += 1.0


def _refresh_residual_targets():
    """Pick a small set of high-probability item sizes to aim residuals at.

    Leaving a residual equal to a frequent item size lets a future common
    item fit exactly, which tends to reduce fragmentation. We select the
    top few sizes by observed frequency, weighted toward larger sizes since
    they are harder to place.
    """
    s = _state
    counts = s["counts"]
    c = counts.copy()
    c[0] = 0.0
    # score sizes by frequency * sqrt(size): favor frequent AND large.
    sizes = np.arange(101, dtype=np.float64)
    weight = c * np.sqrt(sizes)
    # take top 6 sizes
    idx = np.argsort(-weight)[:6]
    vals = idx[idx > 0].astype(np.float64)
    s["res_set"] = set(int(v) for v in vals)
    s["res_vals"] = vals


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties).

    Dominant term is strict best-fit (-slack). The only place a real-valued
    term can influence the choice is among bins with *equal* integer slack,
    so we restrict adaptation to a sub-unit tie-break (<1) that prefers
    residuals matching frequent future item sizes.
    """
    _update_stats(item)
    s = _state
    # refresh the residual-target set periodically (cheap, amortized)
    if s["res_set"] is None or (s["n"] % s["update_every"] == 0):
        _refresh_residual_targets()

    slack = bins.astype(np.float64) - float(item)

    # Dominant integer best-fit term.
    score = -slack

    # Sub-unit tie-break: reward residuals equal to a common future item size.
    res_vals = s["res_vals"]
    if res_vals is not None and res_vals.size > 0:
        # residual after placing this item
        residual = slack
        # distance to nearest "good" residual target
        diff = np.abs(residual[:, None] - res_vals[None, :])
        nearest = diff.min(axis=1)
        # bonus in [0, 0.5): exact match gets 0.5, decays with distance
        tie = 0.5 * np.exp(-(nearest ** 2) / (2.0 * 3.0 * 3.0))
        score = score + tie

    return score
# EVOLVE-BLOCK-END