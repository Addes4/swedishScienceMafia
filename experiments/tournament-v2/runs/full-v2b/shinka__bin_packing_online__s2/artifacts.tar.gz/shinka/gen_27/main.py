# EVOLVE-BLOCK-START
"""Pure best-fit core (crossover: baseline + adaptive, keeping only the dominant term).

Both source programs scored identically (0.962099 / 0.961184), matching pure
best-fit exactly. The adaptive residual-usefulness tie-breaker and the
deterministic tie-break term are bounded below 1.0, so they can never override
a genuine integer capacity difference and, on these instances, never change the
argmax. The crossover therefore keeps the minimal, allocation-light best-fit
rule and drops the inert state and bonus stack.
"""
import numpy as np


def priority(item, bins):
    """Return a per-bin priority; highest score wins (first on ties).

    Pure best-fit: place the item in the bin with the smallest remaining
    slack after placement. Ties are broken by bin order (first wins),
    which is deterministic and allocation-light.
    """
    return -(bins - item)
# EVOLVE-BLOCK-END