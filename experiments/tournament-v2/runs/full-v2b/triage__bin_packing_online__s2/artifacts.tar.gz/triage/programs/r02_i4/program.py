# EVOLVE-BLOCK-START
"""Online k-means clustering of item sizes + cluster-dedicated bin placement.

Idea:
  - Maintain K small online k-means centroids over item sizes (the item stream is
    Weibull-shaped with mean ~40, so a handful of centroids summarise it well).
  - Each bin remembers a soft histogram (or centroid estimate) of the sizes of the
    items currently inside it.
  - Score a bin by how similar its contents are to the arriving item, combined with
    a best-fit residual term so that we still pack tightly.

Instances are single distributions and single streams, so the state is module-level
and reset lazily when the bin array length jumps (i.e., a new instance started with
size 0 -> 1 bins growth pattern; simpler: track call count and detect big jumps).
"""

import numpy as np

# ----------------------------------------------------------------------------
# Online k-means over item sizes
# ----------------------------------------------------------------------------
K = 6                      # number of size clusters
CENTROIDS = np.array([15.0, 30.0, 45.0, 60.0, 78.0, 95.0])  # init roughly spread
COUNTS = np.ones(K)        # per-centroid observation counts (for the moving lr)
ALPHA0 = 0.20              # initial learning rate

# ----------------------------------------------------------------------------
# Per-bin cluster affinity.  Keyed by relative bin index within the current call,
# but bin identity is stable within an instance (bins are appended, never removed
# here since the harness only shows bins that fit and we don't own them...).
# We key by the *order* of bins as given, which is stable per instance.
# ----------------------------------------------------------------------------
BIN_AFF = {}               # local bin position -> np.array(K) of soft contents
_last_len = 0              # length of last bins array, for instance-change detection
_last_item_seen = None


def _reset():
    global CENTROIDS, COUNTS, BIN_AFF, _last_len, _last_item_seen
    CENTROIDS = np.array([15.0, 30.0, 45.0, 60.0, 78.0, 95.0])
    COUNTS = np.ones(K)
    BIN_AFF = {}
    _last_len = 0
    _last_item_seen = None


def _assign(item):
    """Return soft membership weights (K,) of `item` in the current clusters."""
    d = CENTROIDS - item
    d2 = d * d
    # softmax-like with temperature; sharper -> more dedicated
    m = d2.min()
    w = np.exp(-(d2 - m) / 60.0)
    s = w.sum()
    if s <= 0:
        w = np.zeros(K)
        w[int(np.argmin(d2))] = 1.0
        return w
    return w / s


def _update_centroids(item):
    """Online k-means step: move the nearest centroid toward the item."""
    d2 = (CENTROIDS - item) ** 2
    j = int(np.argmin(d2))
    COUNTS[j] += 1.0
    lr = ALPHA0 / (COUNTS[j] ** 0.5)
    CENTROIDS[j] += lr * (item - CENTROIDS[j])


def priority(item, bins):
    """
    item: integer size
    bins: numpy int64 array of remaining capacities where the item fits
    """
    global _last_len, _last_item_seen

    n = len(bins)

    # --- instance change detection -------------------------------------------
    # A fresh instance starts with the bins array length small/1 and then the
    # number of *shown* bins generally does not shrink much.  If the length
    # dropped a lot, or we haven't seen an item, treat it as a new instance.
    if _last_item_seen is None or n < _last_len - 8 or (_last_len > 0 and n < _last_len and n <= 2):
        _reset()
        n = len(bins)

    _last_len = n
    _last_item_seen = item

    # --- update the size clustering ------------------------------------------
    _update_centroids(item)
    w = _assign(item)  # soft membership of this item in the K clusters

    # --- per-bin soft content vectors ----------------------------------------
    # Bins are indexed by their position in `bins`.  When the harness shows us a
    # bin for the first time we initialise its content to reflect an empty bin
    # (capacity 100 -> we treat it as offset ~ 0 content).
    for i in range(n):
        if i not in BIN_AFF:
            BIN_AFF[i] = np.zeros(K)

    # --- build scores ---------------------------------------------------------
    # remaining capacity gives us the wasted space if placed here:
    residual = bins - item          # >= 0 because bins were filtered to fit

    # similarity term: dot(w, bin_aff) in [0,1]; higher -> item matches contents
    aff = np.empty(n, dtype=np.float64)
    used = np.empty(n, dtype=np.float64)
    for i in range(n):
        a = BIN_AFF[i]
        aff[i] = float(np.dot(w, a))
        s = a.sum()
        used[i] = s

    # residual goodness: prefer tight fits (small residual).  Normalise by 100.
    tight = -(residual.astype(np.float64) / 100.0)

    # A bin that already has content and matches the size cluster is best.
    # Empty bins (sum ~ 0) get a mild penalty so they are held in reserve.
    # Similarity dominates when there is content; tight-fit breaks ties.
    score = 2.5 * aff + 0.9 * tight

    # small bonus for bins that are already somewhat full of the same cluster
    score += 0.4 * np.tanh(used)

    # --- record placement effect (we don't know which bin wins; approximate) --
    # The harness picks argmax with first-on-ties.  Update that bin's contents:
    # we cannot know for sure, but the deterministic rule means we can predict it.
    best = int(np.argmax(score))
    BIN_AFF[best] = BIN_AFF[best] + w
    # slight decay to allow drift (bins get filled and effectively vanish)
    # note: bins that are shown next time already exclude full bins.
    return score
# EVOLVE-BLOCK-END
