import numpy as np

# Global state to track interval counts per bin
_bin_counts = None  # np.array of shape (n_bins, num_intervals)
_num_intervals = 3
_interval_boundaries = [10, 35]  # Items 1-10: interval 0, 11-35: interval 1, 36-100: interval 2

# Track for each interval the mean size to guide balancing
_interval_mean = np.zeros(3)
_interval_items = np.zeros(3)

def _get_interval(item):
    if item <= _interval_boundaries[0]:
        return 0
    elif item <= _interval_boundaries[1]:
        return 1
    else:
        return 2

def _init_bins_state(n_bins):
    global _bin_counts
    _bin_count = np.zeros((n_bins, n_intervals), dtype=np.int64)
    return _bin_count

def priority(item, bins):
    global _bin_counts, _interval_mean, _interval_items
    
    placed_count = _interval_items.sum()
    n_bins = len(bins)
    n_intervals = 3
    items_n = np.where(bins > 0)[0]
    
    if placed_count == 0 or n_bins == 0:
        # No prior items or no eligible bins
        if n_bins > 0:
            # Default: prefer the first bin that fits
            return bins.astype(np.float64) + 1e-9
        return np.ones(n_bins, dtype=np.float64)
    
    # Get eligible indices
    eligible = np.where(bins > item)[0]
    if len(eligible) == 0:
        # Should not happen (problem guarantees bins array shows valid bins)
        return np.ones(n_bins, dtype=np.float64)
    
    item_interval = _get_interval(item)
    
    # Update interval counts for eligible bins after placing item
    new_counts = _bin_counts[eligible].copy()
    new_counts[:, item_interval] += 1
    
    # Compute count diversity: lower variance across intervals is better
    # Using sum across intervals and variability as inverse
    # Better bins are those closer to having equal interval distribution
    mean_interval_per_bin = _interval_items.sum() / max(placed_count, 1)
    
    # Per-bins accumulated measures from past interval distributions
    div_score = np.zeros(len(eligible), dtype=np.float64)
    for idx, b_idx in enumerate(eligible):
        current_profile = new_counts[idx]
        profile_mean = _interval_items.sum() / max(_interval_items.size, 1)
        if profile_mean > 0:
            # Closer profile to equality (i.e., proportions more balanced)
            diversity = np.var(current_profile) / profile_mean.item() + 1e-12
            div_score[idx] = 1.0 / diversity
        else:
            div_score[idx] = 1.0
    
    # Renormalize weights
    if np.any(div_score > 0):
        div_score = div_score / div_score.max()
    
    # Capacity factor: favor bins with more room relative to mean
    room_util = ((bins > item) * (bins - item)).astype(np.float64)
    room_cap = np.where(room_util > 0, room_util.max() - room_util + 1e-9, 1e-9)
    cap_weights = np.ones(len(eligible), dtype=np.float64)
    
    # Mix diversity and capacity
    mix_weight = 0.4
    final_scores = div_score + mix_weight * (room_util / room_cap.max() + 1e-9)
    
    return final_scores.astype(np.int64)
