import numpy as np

# ---------------------------------------------------------------------------
# Global learning state
# ---------------------------------------------------------------------------
_hist = np.zeros(101, dtype=np.float64)      # _hist[g] = count of placements that left gap g
_total = 0.0                                  # total placements observed
_unused_bins_seen = np.zeros(101, dtype=np.float64)  # empirical availability of gaps
LOOKBACK = 0.85                                # decay for old statistics


def priority(item, bins):
    """Rank bins by the empirical historical fill rate of the resulting gap.

    For each candidate bin the item would leave a remaining capacity
    ``rem = bins[i] - item``.  We score that bin by how often, historically,
    a gap of exactly that size was later successfully used (i.e. filled) by
    an incoming item.  Unseen gaps fall back to a Laplace-smoothed estimate
    derived from the item-size distribution.
    """
    global _hist, _total, _unused_bins_seen

    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Remaining capacity after hypothetically placing the item
    rem = bins - item          # all bins shown are eligible so rem >= 0

    # Laplace-smoothed empirical "fill rate" of gap g:
    #   fill_rate(g) = (hist[g] + alpha) / (unused[g] + beta)
    # hist[g]      : number of times a gap of size g was actually used later
    # unused[g]    : number of times a gap of size g existed in the bin set
    # alpha/beta   : Laplace prior (weak, = 1/1) plus a distribution shape prior
    alpha = 1.0
    beta = 1.0

    # ---- Empirical success probability with Laplace smoothing -------------
    gap_rate = (_hist + alpha) / (_unused_bins_seen + beta)

    # ---- Prior: probability a random item fits in a gap of size g --------
    # For a Weibull-shaped distribution with mean 40, small gaps are unlikely
    # to be filled, large gaps almost surely will be.  Use a monotone prior.
    g = np.arange(101, dtype=np.float64)
    # survival-ish prior: P(item <= g).  Approximate with a smooth curve
    prior_fit = 1.0 - np.exp(-(g / 38.0) ** 1.8)
    prior_fit = np.clip(prior_fit, 0.0, 1.0)

    # Blend: for well-observed gaps trust data, else trust prior
    obs = _unused_bins_seen
    weight = obs / (obs + 5.0)          # 0 -> prior, 1 -> data
    prob = weight * gap_rate + (1.0 - weight) * prior_fit

    # Score each candidate bin by success probability of its resulting gap
    rem_idx = np.clip(rem, 0, 100).astype(np.int64)
    scores = prob[rem_idx]

    # Small tie-breaker: slightly prefer tighter fits (smaller resulting gap)
    # among equal probabilities, expressed as a tiny bonus.
    scores = scores + (1.0 - rem / 100.0) * 1e-4

    # ---- Update statistics from this placement (using the chosen bin) ----
    # We cannot know the true choice here (harness picks the max score), so we
    # update the "unused gap" histogram for every gap currently present, and
    # treat the tightest gap as the likely fill target for _hist.
    present_gaps = np.clip(bins, 0, 100).astype(np.int64)
    counts = np.bincount(present_gaps, minlength=101)

    # Decay old stats so the model adapts (nonstationary-like behavior)
    _unused_bins_seen *= LOOKBACK
    _hist *= LOOKBACK
    _total *= LOOKBACK

    _unused_bins_seen[:counts.shape[0]] += counts
    _total += n

    # Record that the gap just before item placement (best-fit-ish) was used:
    # distribute a unit of "fill" to the resulting gap of the best candidate.
    best = int(np.argmax(scores))
    filled_gap = int(rem_idx[best])
    _hist[filled_gap] += 1.0

    return scores
