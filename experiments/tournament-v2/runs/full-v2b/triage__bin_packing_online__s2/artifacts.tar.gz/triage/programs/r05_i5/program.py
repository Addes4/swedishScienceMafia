import numpy as np

# ---------- persistent state ----------
_state = {
    "initialized": False,
    "centers": None,          # cluster centers (item types)
    "counts": None,           # number of items assigned to each center
    "dual": None,             # dual variable per item type
    "gamma": None,            # dual variable per bin size class
    "step": 0,                # number of arrivals seen
    "eta": 1.0,               # subgradient step size
    "cap_classes": None,      # representative capacity per bin class
    "bin_class": None,        # map capacity -> class index
    "last_y": None,           # primal y for last configuration LP step
    "n_types": 0,
}

CAP = 100.0


def _init_state(item):
    """Lazily initialize clustering / dual structures (sizes 1..100)."""
    n_types = 10  # canonical item types
    # spread initial centers across plausible sizes
    centers = np.linspace(5.0, 95.0, n_types)
    # bin capacity classes: all integer capacities 1..100 (fine enough)
    cap_classes = np.arange(1, 101, dtype=np.float64)
    bin_class = np.zeros(101, dtype=np.int64)
    for c in range(1, 101):
        # nearest capacity class
        bin_class[c] = int(np.argmin(np.abs(cap_classes - c)))
    _state["centers"] = centers
    _state["counts"] = np.zeros(n_types, dtype=np.float64)
    _state["dual"] = np.zeros(n_types, dtype=np.float64)
    _state["gamma"] = np.zeros(cap_classes.shape[0], dtype=np.float64)
    _state["cap_classes"] = cap_classes
    _state["bin_class"] = bin_class
    _state["n_types"] = n_types
    _state["initialized"] = True


def _cluster_item(item):
    """Online k-means-like assignment + center update. Returns type index."""
    centers = _state["centers"]
    counts = _state["counts"]
    d = np.abs(centers - item)
    k = int(np.argmin(d))
    # exponential-moving-average style center update
    lr = 1.0 / (counts[k] + 1.0)
    centers[k] += lr * (item - centers[k])
    counts[k] += 1.0
    return k


def _config_lp_step(item, k, chosen_bin_remaining):
    """
    One incremental subgradient step for the configuration LP duals.

    Primal (configuration LP, simplified): maximize sum_j v_j y_j
      where each y_j is a packing configuration (multiset of item types fitting
      capacity 100), sum over configs y_j <= 1 (well, per-bin supply), and
      coverage constraints: for each item type i, sum_j a_{i,j} y_j >= n_i.
    Dual: minimize sum_i n_i * alpha_i + sum (bin supply) * beta, s.t.
      sum_i a_{i,j} alpha_i <= 1 for all feasible configs j.

    We approximate the dual by a per-item-type price alpha_i. For a bin with
    remaining capacity r, its "value" for receiving a type-k item is
    alpha_k, and we want to choose the bin whose feasible residual configs
    have the highest dual surplus.  Because exact config enumeration is
    expensive, we use a cheap surrogate: for each candidate bin,
    score = alpha_k - (price-to-consume-space) where space-price is
    approximated by a capacity-class dual gamma[r].

    The subgradient update nudges alpha_k toward covering observed demand and
    nudges gamma_r toward tighter packing when small residuals are wasted.
    """
    dual = _state["dual"]
    gamma = _state["gamma"]
    cap_classes = _state["cap_classes"]
    bin_class = _state["bin_class"]

    # --- subgradient directions (online, noisy but cheap) ---
    # alpha_k should rise if type k items are "hard" to pack (small / awkward),
    # fall if easy. We use a counter-pressure: demand grows, but placing an item
    # in a bin reduces future flexibility. So alpha_k gets pulled up by scarcity
    # of suitable residual capacities.
    r = chosen_bin_remaining
    cls = bin_class[int(r)]
    # gamma class dual: higher when residual space r is scarce relative to demand
    # (i.e., when many bins sit near this capacity). Encourage leaving capacity
    # that can still host future items.
    # Approximate surplus: a bin of residual r should be "cheap" if r is large.
    # Define gamma to penalize wasted small residuals.
    # Update alpha toward a target derived from the packed density.
    density = 1.0 if r <= 0 else (item / (item + r))
    # alpha target: types that leave poor residual should be more expensive
    target_alpha = density
    dual[k] += _state["eta"] * (target_alpha - 0.5) * 0.05

    # gamma target: bins with tiny residual get penalized (they're nearly useless)
    if r < item:  # shouldn't normally happen, but guard
        target_gamma = 1.0
    else:
        # residual r is more valuable if it can still fit typical future item
        target_gamma = 1.0 - (r / CAP)
    gamma[cls] += _state["eta"] * (target_gamma - gamma[cls]) * 0.05

    # keep duals bounded & non-negative-ish
    np.clip(dual, -5.0, 5.0, out=dual)
    np.clip(gamma, 0.0, 5.0, out=gamma)

    # decay step size slowly for stability
    _state["step"] += 1
    _state["eta"] = 1.0 / np.sqrt(_state["step"] + 1.0)


def priority(item, bins):
    """
    Priority rule based on configuration-LP duals.

    For the arriving item, we compute its canonical type via online clustering.
    The item's dual variable alpha_k measures the "price" of that item type in
    the LP.  Each candidate bin (with remaining capacity r) is scored by:
        score = alpha_k  +  gamma_weight * (dual surplus of residual r)
    The idea: prefer bins whose residual capacity, after placing the item,
    still has high dual value (i.e., leaves room for valuable future types),
    while also respecting the type's own price.
    """
    if not _state["initialized"]:
        _init_state(item)

    # ---- 1. cluster the item into a canonical type ----
    k = _cluster_item(item)

    dual = _state["dual"]
    gamma = _state["gamma"]
    cap_classes = _state["cap_classes"]
    bin_class = _state["bin_class"]

    alpha_k = float(dual[k])

    # ---- 2. score every candidate bin ----
    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    # Precompute class indices for all bins
    cap = bins.astype(np.int64)
    # clamp to valid range
    np.clip(cap, 0, 100, out=cap)
    cls = bin_class[cap]

    # residual dual value: prefer larger residual capacities, but discounted by
    # the dual "price" of the capacity class (scarce residual space is valuable)
    residual = bins.astype(np.float64)

    # gamma-cls values
    g = gamma[cls]

    # Base: best-fit component (tighter residual is generally good),
    # plus dual-based flexibility term.
    # tightness: smaller residual -> higher score, but must keep enough room.
    # Use alpha_k to scale: if the item type is expensive, prioritize
    # placements that pack tightly (save space); if cheap, prioritize
    # placements that leave flexible residuals.
    tightness = (CAP - residual) / CAP            # 0..1, higher = tighter
    flexibility = residual / CAP                   # 0..1, higher = roomier

    # Dual-directed mix: alpha_k positive -> care more about tightness
    # (the type is "expensive", so pack it efficiently);
    # alpha_k negative -> care more about flexibility.
    w = 0.5 + 0.5 * np.tanh(alpha_k)              # in (0,1)

    scores = w * tightness + (1.0 - w) * flexibility

    # Add gamma correction: bins whose residual class is scarce get a bonus
    scores += 0.15 * g

    # Slight bonus for residual capacity left after placing item exceeds a
    # typical item size (flexibility threshold around mean item size ~40).
    leftover = residual - item
    scores += 0.05 * np.tanh(leftover / 20.0)

    # If alpha_k high, strongly prefer bins that end up nearly full
    if alpha_k > 0.0:
        end_ratio = (leftover + 0.0) / CAP
        scores -= 0.10 * alpha_k * np.tanh(end_ratio)

    # ---- 3. choose best bin and update duals ----
    best = int(np.argmax(scores))
    chosen_remaining = int(bins[best])

    # update dual variables using the placement
    _config_lp_step(item, k, chosen_remaining)

    return scores
