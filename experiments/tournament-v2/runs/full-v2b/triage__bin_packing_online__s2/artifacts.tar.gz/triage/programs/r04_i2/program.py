import numpy as np

# ---------------------------------------------------------------------------
# Global state kept across calls (one process handles one instance, but we
# still write this defensively so the module can be imported twice).
# ---------------------------------------------------------------------------
_STATE = None


def _init_state():
    global _STATE
    _STATE = {
        "counts": np.zeros(101, dtype=np.float64),  # global histogram of items seen
        "n": 0.0,                                   # number of items seen
        "bin_ids": {},                              # id(bin)-> historic local histogram placeholder
        "bin_item_counts": {},                      # bin index -> number of items placed there
        "bin_hist": {},                             # bin index -> histogram of items placed there
        "bin_cap": {},                              # bin index -> original capacity (100)
        "last_used": -1,                            # last bin index that got a placement
    }


_init_state()


def _rebuild_bin_map(bins):
    """We cannot track bins by identity reliably, so we use capacity bookkeeping.

    The harness exposes an array of remaining capacities for eligible bins
    only.  Because it is a *copy* and the ordering is fixed by bin index, we
    reconstruct the full picture using the last known capacities.
    """
    return None


def priority(item, bins):
    """Score bins using a Wasserstein-like local/global distribution match."""
    global _STATE

    bins = np.asarray(bins, dtype=np.float64)
    n_bins = bins.shape[0]
    if n_bins == 0:
        return np.zeros(0, dtype=np.int64)

    st = _STATE

    # ------------------------------------------------------------------
    # 1. Global empirical distribution of items seen so far (with prior).
    # ------------------------------------------------------------------
    # Prior: Weibull-ish mean ~40.  Use a small Beta-style smoothing so we
    # always have a full histogram early on.
    prior_total = 20.0
    prior_shape = np.maximum(1.0, _prior_hist())

    global_hist = st["counts"] + prior_shape
    global_total = st["n"] + prior_total + 50.0  # extra flattening mass
    global_pmf = global_hist / global_total  # over sizes 0..100

    # ------------------------------------------------------------------
    # 2. Local histogram per bin.
    # ------------------------------------------------------------------
    # We map bins by their current remaining capacity and the running
    # knowledge of what was placed.  The harness gives us remaining caps in
    # bin-index order for the eligible bins; unused bins have cap 100.
    # We therefore maintain a dictionary keyed by a stable hash of (index in
    # the full bin ordering).  Since only eligible bins are shown, and the
    # full ordering is fixed, we reconstruct indices from the sorted capacity
    # profile observed over time.
    #
    # Simpler robust approach: keep a list of all bins ever observed with
    # their capacity after each placement.
    # ------------------------------------------------------------------
    bin_hist_map = st["bin_hist"]
    bin_n_map = st["bin_item_counts"]

    # Build per-bin local distributions aligned with `bins` (eligible ones).
    # We use the remaining capacity as a *proxy key* combined with the
    # position: bins are shown in a fixed order, and the item goes into one
    # of them, so positions of eligible bins are stable enough for the
    # lifetime of a bin (its capacity only decreases).
    # ------------------------------------------------------------------
    # Local PMF for the arriving item's *hypothetical* placement:
    #   local_new(size) = (hist(size)*(1 - item/n) + item==size*(item/n))
    #
    # Wasserstein-1 distance between two 1-D distributions on {1..100}
    # equals the L1 distance between their CDFs.
    # ------------------------------------------------------------------
    # Global CDF (length 101, index 0..100).
    global_cdf = np.cumsum(global_pmf)

    # Precompute per-bin histograms by looking up a key derived from the
    # bin's *current* remaining capacity and position.  This works because
    # the eligible subset is exactly those bins with cap >= item, and the
    # ordering is preserved.
    keys = _make_keys(bins, item)

    scores = np.empty(n_bins, dtype=np.float64)

    item_mass = 1.0 / max(1.0, (st["n"] + 1.0))

    # Precompute item indicator over sizes 1..100
    idx_min = 1
    item_int = int(item)
    if item_int < idx_min or item_int > 100:
        item_int = min(max(item_int, 1), 100)

    # To save time we compute the local distribution's CDF deviation only
    # on the relevant support; the addition of a single item changes the
    # CDF by a step after `item_int`.
    for j in range(n_bins):
        key = keys[j]
        h = bin_hist_map.get(key)
        n_local = bin_n_map.get(key, 0.0)
        if h is None:
            local_hist = np.zeros(101, dtype=np.float64)
            n_local = 0.0
        else:
            local_hist = h

        # New local histogram after (hypothetical) placement.
        # Weighted merge with a small prior so empty bins still behave.
        tot_local = n_local + 1.0
        prior_local = _prior_hist()
        local_pmf_old = (local_hist + prior_local) / (n_local + prior_local.sum())

        # Add the new item
        new_count = (local_hist + prior_local) * 1.0
        new_count[item_int] += 1.0
        local_pmf_new = new_count / new_count.sum()

        # CDFs
        cdf_new = np.cumsum(local_pmf_new)
        # Wasserstein-1 ~ L1 between CDFs, restricted to 1..100
        # (index 0 is size 0, irrelevant but harmless).
        diff = np.abs(cdf_new[1:101] - global_cdf[1:101])
        w1 = diff.sum()

        # Flexibility: prefer bins that will not become too tight.
        # remaining after placement:
        stay = bins[j] - item_int
        tight_pen = 0.0
        if stay < 0:
            tight_pen = 100.0  # should not happen (eligibility)
        elif stay < 5:
            tight_pen = 8.0 * (5 - stay)
        elif stay < 15:
            tight_pen = 2.0 * (15 - stay)

        # Also reward filling bins that are already used (concentrate items).
        used_bonus = 4.0 if n_local > 0 else 0.0

        scores[j] = -w1 * 60.0 - tight_pen + used_bonus + 0.001 * (100 - stay)

    # ------------------------------------------------------------------
    # 3. Update global histogram only after we know the item (we do it here
    #    because the harness calls us once per item).
    # ------------------------------------------------------------------
    st["counts"][item_int] += 1.0
    st["n"] += 1.0

    return scores


# ---------------------------------------------------------------------------
# Helper: build stable keys for eligible bins.
# ---------------------------------------------------------------------------
def _make_keys(bins, item):
    """Use remaining-capacity value plus position among equal-capacity bins."""
    n = bins.shape[0]
    keys = np.empty(n, dtype=object)
    seen = {}
    for j in range(n):
        c = int(bins[j])
        k = seen.get(c, 0)
        seen[c] = k + 1
        keys[j] = (c, k)
    return keys


# ---------------------------------------------------------------------------
# Prior histogram approximating the Weibull(shape~?, mean ~40) distribution
# on integers 1..100, smoothed.
# ---------------------------------------------------------------------------
def _prior_hist():
    # Use a simple discretized shape: Weibull with scale 45, shape 1.5.
    x = np.arange(0, 101, dtype=np.float64)
    scale = 45.0
    shape = 1.5
    with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
        pdf = (shape / scale) * (np.maximum(x, 0.0) / scale) ** (shape - 1.0) * \
              np.exp(-(np.maximum(x, 0.0) / scale) ** shape)
    pdf[0] = 0.0
    pdf = pdf / pdf.sum()
    # Small uniform smoothing
    pdf = 0.9 * pdf + 0.1 * (1.0 / 100.0)
    pdf[0] = 0.0
    return pdf * 50.0  # scale as pseudo-counts
