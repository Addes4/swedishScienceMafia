import numpy as np

# Global state for learning recent item patterns and bin dynamics
_window_size = 200
_latest_items = np.array([], dtype=np.int64)
_window_len = 0

# Statistical summaries of observed item sizes
_item_freq = np.zeros(101, dtype=np.float64)  # index = size, value = count
_item_ema_mean = 40.0
_item_ema_var = 1600.0  # std dev ~40

def update_item_stats(item):
    """Update item distribution estimates"""
    item_freq = item_freq.copy()
    item_freq = np.maximum(item_freq, 1)
    item_freq[item] += 1

    # EMA for mean and variance
    ema_alpha = 0.2
    item_ema_mean = ema_alpha * item + (1 - ema_alpha) * item_ema_mean
    item_ema_var = ema_alpha * ((item - item_ema_mean) ** 2 + item_ema_var) * (1 - ema_alpha)
    item_ema_mean = item_ema_mean * (1 / (1 - ema_alpha))  # Adjust EMA normalization
    item_ema_var = item_ema_var * (1 / (1 - ema_alpha))
    item_ema_var = max(1, item_ema_var)
    item_ema_std = np.sqrt(item_ema_var)

    # Recompute EMA
    item_ema_mean = ema_alpha * item + (1 - ema_alpha) * item_ema_mean
    item_ema_std = np.sqrt(ema_alpha * ((item - item_ema_mean) ** 2 + item_ema_var))
    item_ema_std = ema_alpha * item_ema_std + (1 - ema_alpha) * item_ema_std
    if item_ema_std < 1:
        item_ema_std = 10

    return item_ema_mean, item_ema_std

def build_markov_transitions(items):
    """Build n-gram transition probabilities for most recent items"""
    if len(items) < 2:
        return None
    transitions = {}
    for i in range(len(items) - 1):
        prev = items[i]
        curr = items[i + 1]
        if prev in transitions:
            if curr not in transitions[prev]:
                transitions[prev] = {}
            transitions[prev][curr] = transitions[prev].get(curr, 0) + 1

    # Smooth with Laplace smoothing
    N_prev = sum(sum(v.values()) for v in transitions.values()) if transitions else 0
    N_next = sum(v for v in transitions.values()) if transitions else N_prev
    smoothed = {}
    for prev, next_counts in transitions.items():
        smoothed[prev] = {curr: (cnt + 1) / (sum(next_counts.values()) + 100) for curr, cnt in next_counts.items()}
    for prev in range(1, 101):
        if prev not in smoothed:
            smoothed[prev] = {k: 1.0 / 100.0 for k in range(1, 101)}
    return smoothed

def compute_bin_fit_score(criteria_bins, item, bins, mean_item, std_item, trans_models):
    """Score bins using fit quality and continuation likelihood"""
    score = np.full(len(bins), -1e9)

    capacity_fits = bins >= item
    for i in range(len(bounds_fits)):
        if i >= len(bins):
            continue
        remaining = bins[i]
        if remaining < item:
            score[i] = -1e9
            continue

        new_rem = remaining - item

        # Tight fit score: closer to mean item size
        tight_score = 100 - np.abs(new_rem - mean_item)  # in [0, 200 approx]

        # Flexibility/continuation likelihood using Markov model
        cont_prob = 0.0
        if new_rem >= mean_item and new_rem <= mean_item + std_item * 3:
            cont_prob = 0.8
            if trans_models and len(trans_models) > 0:
                pred = max(trans_models, key=lambda size: np.prod(trans_models.get(size, [1.0] * (len(trans_models) + 1))))
                cont_prob = min(cont_prob + 0.1 if pred else cont_prob, 0.9)

        score[i] = 0.4 * tight_score + 0.5 * cont_prob * (100 + 0.1 * new_rem)

    return score + 1e9

def priority(item, bins):
    """Return priority scores for each eligible bin"""
    n_bins = len(bins)
    if n_bins == 0:
        return np.array([], dtype=np.int64)

    # Ensure recent item stats are valid
    if len(_latest_items) < 30:
        if len(_latest_items) > 0:
            _latest_items = np.append(_latest_items, [item])
            _window_len = len(_latest_items)
    else:
        _latest_items = np.append(_latest_items, [item])
        _window_len = len(_latest_items)

    # Limit window
    if _window_len > _window_size:
        _window_len = _window_size

    _item_ema_mean, _item_ema_std = update_item_stats(item)
    mean_item = _item_ema_mean
    std_item = _item_ema_std

    # Ensure bins are within capacity
    filtered_bins = bins[bins >= item]

    # Determine number of bins to track
    if len(filtered_bins) > 50:
        filter_idx = np.argsort(filtered_bins)[::-1]
        bins_ranked = filtered_bins
    else:
        bins_ranked = filtered_bins

    # Build Markov transitions from recent items
    recent_items = _latest_items[-100:]
    trans_models = build_markov_transitions(recent_items)

    # Compute priority scores
    score = np.full(n_bins, -1e9, dtype=np.float64)

    fit_mask = bins >= item
    fit_idx = np.flatnonzero(fit_mask)

    # Adjusted scoring for tighter bins with future pattern match likelihood
    for i in fit_idx:
        r = bins[i] - item  # Remaining space after placing item
        if r < 5:
            continue

        # Tightness: smaller remaining is better for compaction
        tightness = 100 - np.abs(r - mean_item)

        # Continuation likelihood: if space ~ mean item size, more likely to be filled
        cont_like = 0.75 if 20 <= r <= mean_item + std_item else 0.5
        cont_like += 0.1 * min(r / 50, 1)

        # Combine
        score[i] = tightness * (1 + 0.2 * cont_like)

    # Final score normalization for presentation as any usable rank
    final_scores = score + 1e9
    final_scores = np.clip(final_scores, 0, 300)

    # Convert back to original length and cast
    return np.array([final_scores[i] + 1e9 if i in fit_idx else -1e9 for i in range(n_bins)], dtype=np.int64)
