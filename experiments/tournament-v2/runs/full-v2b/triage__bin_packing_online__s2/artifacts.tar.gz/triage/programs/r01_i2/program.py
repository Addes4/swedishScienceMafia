import numpy as np

# Adaptive optimal gap parameter based on past item statistics
# Using a simple online update of item size mean and variance
class AdaptiveGap:
    def __init__(self, capacity=100):
        self.capacity = capacity
        self.n_items = 0
        self.mean_size = 0.0
        self.m2 = 0.0  # sum of squared differences from the mean
    
    def update(self, item):
        self.n_items += 1
        delta = item - self.mean_size
        self.mean_size += delta / self.n_items
        delta2 = item - self.mean_size
        self.m2 += delta * delta2
    
    @property
    def var_size(self):
        if self.n_items < 2:
            return 0.0
        return self.m2 / (self.n_items - 1)
    
    @property
    def std_size(self):
        return np.sqrt(self.var_size)
    
    def optimal_gap(self):
        """Compute the optimal gap based on current item size distribution.
        
        The idea: to leave bins well-prepared for future items, 
        we want a gap that accounts for typical item sizes.
        A heuristic: the optimal gap is related to the mean item size,
        but we also consider the variance to avoid too tight or too loose fits.
        """
        if self.n_items == 0:
            return 0.0
        
        # Simple heuristic: optimal gap scales with standard deviation
        # but is bounded by the capacity constraints.
        # The goal is to leave room for items around the mean size.
        # If the mean is large, we need tighter fits; if small, looser.
        # We use: optimal_gap = mean_size * (1 - mean_size/capacity)
        # This peaks at capacity/2 = 50, which is 0.25 * capacity = 25.
        # But we also consider std to avoid gaps that are too variable.
        mean_frac = self.mean_size / self.capacity  # ~0.4 expected
        base_gap = self.mean_size * (1.0 - mean_frac)  # leaves expected leftover
        
        # Adjust by std: if items are highly variable, prefer slightly tighter fits
        # to reduce variance in bin utilization.
        adjust = 0.5 * self.std_size  # half a standard deviation shift
        # But keep the gap positive and reasonable
        gap = max(0.0, base_gap - adjust)
        # Also don't exceed mean size (don't aim for gap larger than typical item)
        gap = min(gap, self.mean_size)
        return gap

# Global state (persists across calls)
_adaptive_gap = AdaptiveGap()

def priority(item, bins):
    """Return a priority (score) for every bin in `bins`.
    
    Uses a balanced worst-fit with adaptive quadratic penalty around an optimal gap.
    Higher score means better bin for this item.
    """
    global _adaptive_gap
    
    # Update statistics with the current item
    _adaptive_gap.update(item)
    
    # Calculate the optimal gap we want after placing the item
    optimal_gap = _adaptive_gap.optimal_gap()
    
    # If no items seen yet (first call), fallback to basic best-fit
    if _adaptive_gap.n_items <= 1:
        return -(bins - item)
    
    # Compute the gap that would remain after placing the item
    remaining_after = bins - item  # numpy int64 array
    
    # Quadratic penalty: distance of remaining gap from the optimal gap
    # Negative score because we return priorities (higher is better)
    # Using float64 to avoid overflow
    diff = remaining_after.astype(np.float64) - optimal_gap
    score = -(diff ** 2)
    
    return score
