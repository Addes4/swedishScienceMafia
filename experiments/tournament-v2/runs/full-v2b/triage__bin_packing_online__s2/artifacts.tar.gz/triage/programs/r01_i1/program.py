# EVOLVE-BLOCK-START
"""Expected size grouping: put items in bins aligned to EMA of item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # We need persistent state between calls, so use a function-scoped closure
    # to simulate a module namespace.
    try:
        ema = priority._ema
        decay = priority._decay
    except AttributeError:
        priority._ema = 50.0  # Initial expected item size (global prior)
        priority._decay = 0.20
        ema = priority._ema
        decay = priority._decay

    alpha = decay

    # Update EMA after each successful placement using the whole item
    ema = alpha * item + (1.0 - alpha) * ema

    # Compute priority for bins where this item fits
    candidates = bins >= item

    if not np.any(candidates):
        # Nothing fits (should not happen in normal work), return all zeros
        n = len(bins)
        return np.zeros(n, dtype=np.float64)

    rem = bins[candidates] - item  # remaining capacity after we place it

    # Priority: smaller remainder modulo EMA is better, we don't want to fragment
    s = rem % ema
    p = -s

    return np.concatenate([p, np.zeros(len(bins) - len(candidates))])
# EVOLVE-BLOCK-END
