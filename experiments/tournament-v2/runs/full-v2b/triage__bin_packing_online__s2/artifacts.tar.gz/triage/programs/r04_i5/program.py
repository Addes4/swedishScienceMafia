import numpy as np

# Global state for learning across calls
_has_state = False

if not _has_state:
    global _dual_price, _item_count, _total_size, _target_util
    # Shadow price (dual variable) for capacity, initialized to a reasonable value
    _dual_price = 0.0
    _item_count = 0
    _total_size = 0.0
    _target_util = 0.8  # target utilization per bin
    _has_state = True

def priority(item, bins):
    """
    Shadow-price-based scoring: compute the net value of placing the item in each bin,
    where the value is the item size minus the opportunity cost (shadow price * used capacity).
    The shadow price adapts online based on capacity utilization.
    """
    global _dual_price, _item_count, _total_size, _target_util
    
    # Update item statistics for adaptive shadow price
    _item_count += 1
    _total_size += item
    
    # Estimate mean item size for adapting shadow price
    mean_item = _total_size / _item_count
    
    # Number of bins seen so far (including empty ones)
    n_bins = len(bins)
    
    # Compute current overall utilization and adjust shadow price
    # The shadow price should increase when bins are too full (scarce capacity)
    # and decrease when there is plenty of capacity.
    # We use a simple online gradient-like update based on observed remaining capacity.
    
    # Average remaining capacity across all bins
    avg_remaining = np.mean(bins)
    
    # Desired average remaining capacity based on target utilization
    # If we want 80% utilization on average, remaining should be about 20 per bin.
    desired_remaining = 100 * (1 - _target_util)
    
    # Update shadow price: if remaining > desired, capacity is plentiful -> lower price
    # if remaining < desired, capacity is scarce -> raise price
    # Learning rate decays with number of items seen
    lr = 0.1 / (1 + 0.001 * _item_count)
    _dual_price += lr * (desired_remaining - avg_remaining)
    _dual_price = max(0.0, min(_dual_price, 2.0))  # keep in reasonable range
    
    # Now score each bin using the shadow price
    # Value of placing item in bin = item size (benefit of using capacity)
    # Cost = shadow_price * (100 - remaining) — but we already used (100 - remaining) capacity
    # Actually, placing item reduces remaining by item, so the marginal cost is shadow_price * item
    # But we care about which bin to choose. If all bins can fit the item,
    # the net benefit is the same for all? No, we also want to prefer bins that are
    # already partially filled (to concentrate items) or bins that preserve flexibility.
    # We score by: -shadow_price * (remaining after placement) + value of filling the bin.
    # Equivalent: reward bins with smaller remaining after placement if shadow_price is positive,
    # because we want to pack tightly when capacity is expensive.
    # Actually, the dual approach: the score should be the "reduced cost" — 
    # for bin packing, we want to minimize bins used. The dual price reflects the cost
    # of opening a new bin vs using existing ones.
    
    # For each bin, compute remaining after placing the item
    remaining_after = bins - item  # all bins in the array can fit the item
    
    # The "cost" of using this bin: the opportunity cost of the remaining capacity
    # that will be left.  We want to minimize wasted capacity in the chosen bin.
    # A bin with small remaining_after is good (tight packing).
    # We combine: prefer bins where remaining_after is small, but also account
    # for the shadow price of capacity.
    
    # Score = -remaining_after  (so smaller remaining_after gives higher score)
    # but also incorporate shadow price: if price is high, we strongly prefer tight packing;
    # if price is low, we might be more flexible.
    # Additional: we can add a term to preserve bins that are almost empty for large items,
    # but the dual price should handle that.
    
    # Base score: how much capacity is left after placing — we want this minimal.
    tightness_score = 100 - remaining_after  # higher if less space left
    
    # Flexibility bonus: if remaining_after is close to mean_item, it's good for future items.
    # But we weight this by (1 - shadow_price_norm) because when capacity is expensive,
    # we don't care about flexibility.
    mean_item_est = mean_item
    # Normalize shadow price to [0,1] for blending
    price_norm = min(1.0, _dual_price)
    
    # Flexibility score: remaining_after near mean_item_est is ideal
    flexibility_score = 100 - np.abs(remaining_after - mean_item_est)
    
    # Blend: when price is high, use tightness; when low, consider flexibility
    final_score = price_norm * tightness_score + (1 - price_norm) * flexibility_score
    
    # Small tie-breaking: if multiple bins have same score, prefer lower index (already default)
    # Also add tiny random-like component based on index to break ties deterministically
    # but numpy argmax takes first max, so not needed.
    
    return final_score.astype(np.float64)
