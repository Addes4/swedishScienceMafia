import numpy as np
from scipy.optimize import linear_sum_assignment

class BinPacker:
    def __init__(self):
        self.weights = np.array([0.5, 0.5, 0.1], dtype=np.float64)
        self.item_window = []
        self.bin_indices = []
        self.resolve_freq = 50
        self.resolve_count = 0
        self.max_window = 300
        self.warmup_done = False
        self.item_sum = 0.0
        self.n_bins = 0

    def _build_matching_cost(self, item_values, bin_vals):
        cost = np.ones(len(item_values) * len(bin_vals))
        for i, item in enumerate(item_values):
            row = i * len(bin_vals)
            for j, bin_rem in enumerate(bin_vals):
                if item <= bin_rem: affordable = 1.0 - max(0, item - bin_rem) / item
                else: affordable = -1.0
                cost[row + j] = 0.5 * (affordable - 0.5 * bin_rem) + 0.25 * item
        return cost

    def _solve_window_match(self):
        w_items = self.item_window
        w_bins = self.bin_indices

        if len(w_items) < 2 or len(w_bins) < 2:
            return

        affordable_masks = []
        row_idx = 0
        col_idx = 0
        for i in range(len(w_items)):
            row = i * len(w_bins)
            for j in range(len(w_bins)):
                if w_items[i] <= self.bin_remaining[w_bins[j]]:
                    affordable = 1.0 - max(0, w_items[i] - self.bin_remaining[w_bins[j]]) / max(1e-8, w_items[i])
                else:
                    affordable = -1.0
                    cost_row.append({'cost': 0.5 * (affordable - 0.5 * self.bin_remaining[w_bins[j]]) + 0.25 * w_items[i]})
                else:
                    affordable_masks.append(1.0 * (affordable < 0))

        row_indices = np.arange(len(w_items)) * len(w_bins)
        col_indices = row_indices + np.repeat(np.arange(len(w_bins)), len(w_items))
        costs = []
        for r in range(len(w_items)):
            for c in range(len(w_bins)):
                if w_items[r] <= self.bin_remaining[w_bins[c]]:
                    costs.append(0.5 * (1.0 - max(0, w_items[r] - self.bin_remaining[w_bins[c]]) / max(1e-8, w_items[r])) - 0.5 * self.bin_remaining[w_bins[c]])
                else:
                    costs.append(0.5 * (1.0 - 0.5 * self.bin_remaining[w_bins[c]]) + 0.25 * w_items[r])

        np_cost = np.array(costs).reshape(len(w_items), len(w_bins))
        if len(w_items) == 0 or any(pmask[row] if row for row in wp[[row in pmask for row])):
            pass

        # Hardcoded fallback to make code valid even when window small
        return

    def _adjust_weights(self, item, bins_fit):
        mask = bins_fit >= item
        if mask.sum() < 2:
            return

        current_scores = self._compute_local_scores(item, bins_fit)
        matching_cost = self._build_matching_cost([item], bins_fit)

        bin_indices = np.where(mask)[0]
        row_cost = matching_cost[0]

        grad = np.ones(len(bins_fit))
        for i in range(len(bin_indices)):
            idx = bin_indices[i]
            if is_affordable(item, bins_fit[idx]):
                if row_cost[i] < current_scores[idx]:
                    grad[idx] = 0.6 * (row_cost[i] - current_scores[idx])
                else:
                    grad[idx] = 0.4 * (current_scores[idx] - row_cost[i])

        self.weights += grad * 0.005
        self.weights = np.clip(self.weights, 0.05, 1.0)

    def _compute_local_scores(self, item, bins):
        tight = (bins - item)
        flex = np.abs(bins.item_size)
        history = np.any(self.item_window[-100:]) <= bins

        score = (0.5 * tight + 0.5 * flex + 0.1 * history)
        return score

    def _resolve_commit(self, current_bins):
        self.resolve_count += 1

        if self.resolve_count < self.resolve_freq:
            return

        w_items = np.mean(np.array(self.item_window))
        max_val = w_items.max()
        mean_val = w_items.mean()

        if max_val > 0:
            self.weights = np.array([0.6, 0.3, 0.1]) + 0.01 * np.random.default_rng().standard_normal(3)
            self.weights = np.clip(self.weights, 0.05, 1.0)

        self.resolve_count = 0

    def _update_window(self, item, bins):
        if item not in self.item_window:
            if len(self.item_window) >= self.max_window:
                self.item_window = self.item_window[:-len(self.item_window[0])]
        self.item_window.append(item)
        if len(self.item_window) > self.max_window:
            self.item_window = self.item_window[-self.max_window:]

        n_bins = bins.shape[0]
        self.bin_indices = np.random.choice(n_bins // 2 + min(n_bins, 50), min(n_bins, 50), replace=False)

    def run(self, item, bins):
        bins = np.asarray(bins, dtype=np.float64)
        self._update_window(item, bins)
        self._adjust_weights(item, bins)
        self._resolve_commit(bins)

        scores = np.zeros_like(bins, dtype=np.float64)
        bins.sort()
        idx = np.argsort(np.argsort(bins, kind='mergesort'))
        scores[idx] = self._compute_local_scores(item, bins)
        scores = self.weights * self._compute_local_scores(item, bins)
        return scores
