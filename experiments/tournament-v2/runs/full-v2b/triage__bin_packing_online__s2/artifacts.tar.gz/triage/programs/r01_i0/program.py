# EVOLVE-BLOCK-START
"""Best-fit with a small bonus for bins that end up tightly packed.

Best fit alone (minimize remaining capacity) is a strong online rule.  A small
amount of residual capacity in a bin is wasted space: it can rarely be filled
by a later item, since items have mean about 40 and the smallest useful item is
1.  So when the item would leave a bin with a small leftover (below a cutoff),
we give that bin a slight bonus.  This breaks ties among near-equal fits toward
the bin that gets packed most tightly, reducing the number of bins with tiny
unusable slivers.

The score is designed so the primary ordering is still best fit: the bonus is
strictly smaller than one unit of remaining capacity, so a bin with smaller
leftover always outranks a bin with larger leftover, and the bonus only decides
between bins whose leftovers are within the cutoff band.
"""
import numpy as np

# Leftovers at or below this many units are considered "tight"; such a bin
# gets a bonus that grows as the leftover shrinks toward zero.
CUTOFF = 20


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item  # remaining capacity if the item is placed here

    # Best fit: smaller leftover => higher score.
    score = -leftover.astype(np.float64)

    # Bonus for tight packing.  It is < 1 so it never overrides the primary
    # best-fit ordering; it only separates bins with equal / near-equal
    # leftovers, pushing toward the tightest possible pack in the band.
    tight = leftover <= CUTOFF
    if np.any(tight):
        # (CUTOFF - leftover) is in [0, CUTOFF]; scale to a fraction of a unit.
        bonus = np.where(tight, (CUTOFF - leftover + 1) / (CUTOFF + 1), 0.0)
        score = score + bonus

    return score
# EVOLVE-BLOCK-END
