import numpy as np

# Fuzzy type bounds and discrete type array
# Item sizes 1-100 mapped to fuzzy types [0=small, 1=medium, 2=large]
_LOW, _MID, _HI = 0.0, 60.0, 90.0
type_bins = np.array([0, 30, 60, 100], dtype=np.float32)

# Initialize state
_state_ready = False

def _init_state(n_items=5000):
    global _state_ready
    if _state_ready:
        return
    
    # Track item type counts
    _type_counts = np.zeros(3, dtype=np.int64)
    # Per-type remainder histograms (remaining cap counts per type)
    # _hist[t, r] where t in {0,1,2}, r in 0..100
    _hist = np.zeros((3, 101), dtype=np.float64)
    
    _state_ready = True

def _get_type_membership(size):
    """Return fuzzy membership vector for sizes: [small, medium, large]"""
    r = np.zeros(3, dtype=np.float32)
    b = np.array([-10.0, 3.33, 40.0, 110.0], dtype=np.float32)  # overlap boundaries
    for i in range(3):
        # Linear interpolation for membership
        l, h = b[i], b[i+1]
        if l <= size < h:
            z = min(max(size - l, 0.0), h - size, 0.0) / (h - l) if h != l else 0.5
            r[i] = 1.0 - z if i == 0 else z if i == 2 else 1.0 - z
    # Normalize for membership
    s = np.sum(r)
    if s == 0:
        r[:] = 1/3.0
    else:
        r /= s
    return r

def _updatehist(type_idx, remaining):
    """Update histogram for a bin's remaining capacity by fuzzy type"""
    _hist[type_idx, np.clip(remaining, 0, 100)] += 1.0

def _compute_type_probs():
    """Estimate item type probability from observed counts"""
    t = np.sum(_type_counts)
    if t <= 0:
        return np.array([1/3.0, 1/3.0, 1/3.0], dtype=np.float64)
    return _type_counts / t

def _buffer_score(item_type_hist):
    """Compute buffer score from type distribution for optimization"""
    t = np.sum(_type_counts)
    if t <= 1e-6:
        return np.array([1.0, 1.0, 1.0], dtype=np.float64)
    return _type_counts / t

def priority(item, bins):
    """
    Priority function for online bin packing.
    Score based on fuzzy type matching and expected completions.
    """
    global _state_ready, _type_counts, _hist
    
    # Ensure state is initialized
    if not _state_ready:
        _init_state(len(bins))
    
    # Convert to float for computation
    bins_f = bins.astype(np.float64)
    n_bins = len(bins)
    
    # Handle empty bins
    if n_bins == 0:
        return np.array([], dtype=np.int64)
    
    # Fuzzy type membership for current item
    item_type = _get_type_membership(item)
    
    # Get type probability distribution from observed history
    type_prob = _compute_type_probs()
    
    # Compute membership-based bin scores
    scores = np.zeros_like(bins_f)
    
    for t in range(3):
        # Compute expected compatible remainder for type t
        # Using histogram-based convolution approximation
        h = np.sum(_hist[t, :])
        
        if h > 0:
            # Prioritize bins where item fits with minimal waste: score by (r - item) >= 0
            compat_mask = bins_f >= item
            if np.any(compat_mask):
                # Compute average "matched-type" fill for compatible bins
                # Use bin history weighted by type probability
                expected_fill = 1.0
                scores[compat_mask] += item_type[t] * type_prob[t] * 100.0
    
    # Rank competing bins based on compatibility with incoming item
    # Bonus for bins whose remaining space aligns with same fuzzy type
    for i in range(3):
        # How well bin remainders match current fuzzy type
        match = _hist[i, bins_f] + 0.01  # Sparse histogram lookup
        scores += item_type[i] * match * 10.0
    
    # Apply penalty for placements that leave too large gaps (waste minimization)
    gap_penalty = np.clip(100.0 - bins_f, 0, 50)
    scores -= gap_penalty * 0.02
    
    # Ties broken by first such bin
    scores = scores.astype(np.float32)
    return scores
