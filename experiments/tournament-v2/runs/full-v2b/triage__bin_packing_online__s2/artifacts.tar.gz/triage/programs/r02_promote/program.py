import numpy as np
from collections import deque
from scipy import stats

# Global state for learning across calls
if not hasattr(priority, '_item_history'):
    priority._item_history = deque(maxlen=200)  # recent item sizes
    priority._bin_usage_history = deque(maxlen=100)  # recent bin counts
    priority._target_mean = 40.0  # estimate of mean item size
    priority._target_std = 20.0   # estimate of std of item size
    priority._phase = 'early'     # early, mid, late
    priority._call_count = 0
    priority._total_bins_used = 0

def priority(item, bins):
    """Return a priority array; highest score (first tie) gets the item.

    item: integer size of the arriving item, 1..100
    bins: numpy int64 array with remaining capacity of all eligible bins
    """
    # Update state with observed item
    priority._item_history.append(item)
    priority._call_count += 1
    
    # Update distribution estimates periodically
    if len(priority._item_history) >= 50 and priority._call_count % 100 == 0:
        recent_items = np.array(priority._item_history)
        priority._target_mean = np.mean(recent_items)
        priority._target_std = np.std(recent_items)
    
    n_bins = len(bins)
    if n_bins == 0:
        return np.array([], dtype=np.int64)
    
    # Determine phase based on how many bins are in use vs fresh
    fresh_bins = np.sum(bins == 100)
    used_bins = n_bins - fresh_bins
    
    # Estimate future items remaining (5000 total, but we don't know exact count)
    if priority._call_count < 100:
        priority._phase = 'early'
    elif priority._call_count < 4500:
        priority._phase = 'mid'
    else:
        priority._phase = 'late'
    
    # Best-fit score: how well item fills the bin
    waste = bins - item
    # Perfect fit is best (waste = 0), but negative waste is handled by harness
    # We score bins where waste is small and positive highly
    best_fit_score = np.where(waste >= 0, 100 - waste, -1000)  # negative waste impossible thanks to harness filtering
    
    # Future flexibility score: how useful bin will be for remaining items distribution
    # We want remaining capacity that can accommodate likely future items
    mean_item = priority._target_mean
    std_item = max(priority._target_std, 15)
    
    # Bin flexibility: remaining capacity should be at least mean + some buffer
    # But not too close to 100 (wasteful) nor too tight
    ideal_remaining = mean_item + 0.5 * std_item  # typical future item plus buffer
    
    # Distance from ideal remaining capacity
    remaining = bins
    distance_from_ideal = np.abs(remaining - ideal_remaining)
    flex_score = 100 - distance_from_ideal * 1.5
    
    # Also penalize bins that will be too tight after this placement
    after_placement = remaining - item
    too_tight_penalty = np.where(after_placement < mean_item * 0.3, 30, 0)
    flex_score -= too_tight_penalty
    
    # For late phase, strongly prefer bins that will be near-full after placement
    # This reduces fragmentation when we're running out of items
    if priority._phase == 'late':
        # Encourage finishing bins
        finish_bonus = np.where(after_placement <= 10, 50, 0)
        # Also avoid leaving tiny gaps
        small_gap_penalty = np.where((after_placement > 0) & (after_placement < 15), 20, 0)
        flex_score = flex_score + finish_bonus - small_gap_penalty
    elif priority._phase == 'early':
        # In early phase, prefer bins that maintain flexibility
        # Specifically, prefer remaining capacities that are multiples of typical items
        # This helps with packing efficiency
        flex_score += np.where((remaining % max(1, int(mean_item))) < 5, 10, 0)
    
    # Compute weights based on how many bins we have and phase
    # More bins = more options = weight flexibility higher
    # Few bins = tighter = weight best-fit higher
    if used_bins == 0 and fresh_bins == n_bins:
        # Very first items, just use best-fit temporarily
        alpha = 0.2
    else:
        utilization = 1.0 - (np.sum(bins) / (n_bins * 100))
        # As utilization increases, shift toward best-fit
        base_alpha = 0.7 if priority._phase == 'late' else 0.5
        alpha = base_alpha - utilization * 0.3
        alpha = np.clip(alpha, 0.2, 0.8)
    
    # Combine scores
    combined = alpha * best_fit_score + (1 - alpha) * flex_score
    
    # Small tie-breaking: prefer bins with lower index (already handled by np.argmax, but we can reinforce)
    # Also apply a tiny noise based on index to break ties consistently with index order
    tiny_index_bonus = np.arange(n_bins) * 0.001
    combined = combined + tiny_index_bonus
    
    # Ensure no NaN and reasonable range
    combined = np.nan_to_num(combined, nan=-1000.0, posinf=1000.0, neginf=-1000.0)
    
    return combined.astype(np.float64)  # return float for precision in scoring
