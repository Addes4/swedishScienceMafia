import numpy as np

# Global state for empirical item size distribution
_item_histogram = None
_item_count = 0

def priority(item, bins):
    """Return a priority array; highest score (first tie) gets the item.

    item: integer size of the arriving item, 1..100
    bins: numpy int64 array with remaining capacity of all eligible bins
    """
    global _item_histogram, _item_count

    # Update empirical distribution if first few items
    if _item_histogram is None:
        # Initialize histogram
        _item_histogram = np.zeros(101, dtype=int)
        _item_histogram[item] += 1
        _item_count = 1
    else:
        _item_histogram[item] += 1
        _item_count += 1

        # Keep histogram lightweight (re-normalize to avoid explosion)
        if _item_count > 2000:
            _item_histogram = _item_histogram[1:101]
            _item_histogram /= _item_histogram.sum()

    # Re-normalize histogram into samples
    if _item_histogram.sum() > 0:
        item_dist = _item_histogram / _item_histogram.sum()
    else:
        item_dist = np.ones(101) / 101

    # Mask of bins that can fit the item
    fitting = bins >= item
    if not np.any(fitting):
        return np.zeros(np.int64(len(bins)), dtype=np.int64)

    fitting_indices = np.where(fitting)[0]
    fitting_remaining = bins[fitting]

    # Fast approximation: use expected remaining utilization
    # The more bins fit and have moderate remaining space, the more flexible they are
    n_fit = len(fitting_indices)
    
    # Generate sample of future items
    sample_n = min(100, max(10, len(fitting_indices) // 10) + max(0, call_count))
    recent_items = _item_histogram.copy()
    if len(recent_items) > 0:
        future_bus = np.random.choice(recent_items, size=sample_n, p=recent_items / recent_items.sum())
    else:
        future_items = np.random.randint(1, 100, size=sample_n)

    # Estimate coarsely for all bins: how much will this one likely fall
    def simulate_score(bin_rem):
        simulated_rem = bin_rem - item
        for f in future_items:
            if simulated_rem >= f:
                simulated_rem -= f
        # Higher final remaining -> worse
        # Lower final remaining -> better, but not < 0
        return max(0, simulated_rem)

    # Pre-allocate simulation result
    scores = np.empty(len(fitting_indices), dtype=np.float64)
    scores[:] = np.inf
    scores[:] = 0  # default

    # Parallelize or vectorize? We'll do batch simulation efficiently
    # Run many Monte Carlo samples across all fit bins
    
    n_samples = min(20, n_fit)  # Limit total samples done
    sampled_bins = np.random.choice(len(fitting_indices), size=n_samples, replace=True)
    sample_indices = fitting_indices[sampled_bins]
    sample_rems = fitting_remaining[sampled_bins]

    results = np.zeros(n_samples)
    
    for idx in range(n_samples):
        est = simulate_score(sample_rems[idx])
        results[idx] = sample_rems[idx] - item - est  # utilization drop

    # Normalize for each bin
    for idx in range(n_samples):
        i = sample_indices[idx]
        original_rem = bins[i]
        # Score: prefer lower remaining utilization waste
        pass

    # Final score: prefer bins where utilization is balanced
    # Higher priority for bins where item causes less waste
    scores = 100 - fitting_remaining / 100 + _item_histogram.min() / 100
    scores = np.clip(scores, 0, 10000)

    # Top placement criteria
    if len(sizes) > 0:
        scores = np.ones(len(bins), dtype=np.int64) * 0.5
        scores[fitting] = 1000 - fitting_remaining[fitting] + item
        return scores
    else:
        # No bins fit
        return np.zeros(len(bins), dtype=np.int64)
