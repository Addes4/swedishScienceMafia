import numpy as np

def priority(item, bins):
    """
    Score bins using an online-MDP value iteration approximation.
    
    The value of a bin is approximated as v(r) ~ r / E[future_item].
    We choose bins to maximize remaining future value (best-fit).
    
    item: integer size of the arriving item, 1..100
    bins: numpy int64 array with remaining capacity of all eligible bins
    """
    
    # Estimate expected future item size from Past observations
    if not hasattr(priority, '_observed_items'):
        priority._observed_items = []
    
    observed = priority._observed_items[-10000:].copy()  # sliding window
    
    if len(observed) > 0:
        est_mean_item = np.mean(observed).astype(np.float64)
        # Ensure reasonable estimate
        est_mean_item = max(1.0, min(50.0, est_mean_item))
    else:
        est_mean_item = 40.0
    
    # Identify bins that fit the current item
    fits = bins >= item
    n_fits = fits.sum()
    
    if n_fits == 0:
        scores = np.zeros_like(bins, dtype=np.int64)
        scores[fits] = 1e6
        return scores
    
    # Value iteration approximation: value(r) = r / mean_item
    # Score remaining capacity after placement
    remaining_after = bins[fits] - item
    value_after = remaining_after.astype(np.float64) / est_mean_item
    
    # Better bins have higher remaining value (more future items can fit)
    # Convert to score: max value wins
    scores = value_after.astype(np.float64)
    
    return np.clip(scores, 0, None)
