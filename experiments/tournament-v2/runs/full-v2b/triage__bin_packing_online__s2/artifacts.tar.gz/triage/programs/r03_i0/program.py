import numpy as np

# Global state for online regression
_initialized = False

if not _initialized:
    # Feature dimension: [bias, item_size, bin_capacity, item/bin_ratio, 
    #                     is_empty, is_tight, capacity_squared, capacity_sqrt]
    _feature_dim = 8
    _weights = np.zeros(_feature_dim)
    _lr = 0.01
    _decay = 0.9999
    _eps = 1e-8
    
    # Running statistics for normalization
    _item_mean = 40.0
    _item_var = 400.0
    _n_items = 0
    
    # Surrogate loss tracking
    _total_loss = 0.0
    _loss_count = 0
    
    _initialized = True

def _extract_features(item, bins):
    """Extract normalized features for each bin."""
    n_bins = len(bins)
    features = np.zeros((n_bins, _feature_dim))
    
    # Normalize item size
    item_norm = (item - _item_mean) / (np.sqrt(_item_var) + _eps)
    
    # Bin features
    cap = bins.astype(np.float64)
    cap_norm = (cap - 50.0) / 30.0  # rough normalization
    
    # Feature 0: bias
    features[:, 0] = 1.0
    
    # Feature 1: item size
    features[:, 1] = item_norm
    
    # Feature 2: bin remaining capacity
    features[:, 2] = cap_norm
    
    # Feature 3: ratio of item to capacity
    ratio = np.where(cap > 0, item / cap, 100.0)
    ratio_norm = (ratio - 1.0) / 2.0
    features[:, 3] = ratio_norm
    
    # Feature 4: is empty bin (capacity == 100)
    features[:, 4] = (cap >= 99.9).astype(np.float64)
    
    # Feature 5: is tight fit (capacity - item < 20)
    features[:, 5] = (cap - item < 20).astype(np.float64)
    
    # Feature 6: capacity squared
    features[:, 6] = cap_norm ** 2
    
    # Feature 7: capacity sqrt
    features[:, 7] = np.sqrt(np.maximum(cap, 0)) / 10.0 - 0.5
    
    return features

def priority(item, bins):
    """Return priority scores using online regression.

    item: integer size, 1..100
    bins: numpy int64 array of remaining capacities
    """
    global _weights, _lr, _decay, _eps
    global _item_mean, _item_var, _n_items
    global _total_loss, _loss_count
    
    n_bins = len(bins)
    
    # Update item statistics incrementally (Welford's online algorithm)
    _n_items += 1
    delta = item - _item_mean
    _item_mean += delta / _n_items
    delta2 = item - _item_mean
    _item_var = (_item_var * (_n_items - 1) + delta * delta2) / _n_items if _n_items > 1 else 400.0
    
    if n_bins == 0:
        return np.array([], dtype=np.int64)
    
    # Extract features
    X = _extract_features(item, bins)
    
    # Predict scores
    scores = X @ _weights
    
    # If we have multiple bins and some history, update weights with surrogate loss
    if n_bins > 1 and _n_items > 10:
        # Choose the winning bin (highest score, first tie)
        best_idx = np.argmax(scores)
        best_score = scores[best_idx]
        
        # Compute surrogate loss: encourage scores to rank bins well
        # Loss based on capacity utilization: prefer bins where item fills more of remaining space
        # This is a proxy for making good packing decisions
        target_util = item / np.maximum(bins, 1)
        target_scores = target_util * 100.0  # Higher utilization -> higher target score
        
        # Normalize target scores to similar scale
        target_scores = target_scores / (np.max(target_scores) + _eps) * np.max(scores) if np.max(target_scores) > 0 else scores
        
        # Gradient: MSE between predicted and target scores
        errors = scores - target_scores
        grad = X.T @ errors / n_bins
        
        # L2 regularization (small)
        grad += 0.001 * _weights
        
        # Update weights with decaying learning rate
        _weights -= _lr * grad
        _lr *= _decay
        
        # Track loss for diagnostics (not used in decision)
        _total_loss += np.mean(errors ** 2)
        _loss_count += 1
    
    # Ensure scores are reasonable integers
    scores_int = np.clip(scores, 0, 1000).astype(np.int64)
    
    return scores_int
