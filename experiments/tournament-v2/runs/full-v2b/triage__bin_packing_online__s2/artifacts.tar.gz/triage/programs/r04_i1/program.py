import numpy as np

# Global state: track how many items each bin index currently holds.
# Bins are presented in fixed index order and the array always covers all bins,
# so index i refers to the same physical bin across calls.
_fill_counts = None
_last_len = 0

def _get_fill():
    global _fill_counts, _last_len
    return _fill_counts

def priority(item, bins):
    global _fill_counts, _last_len

    n = len(bins)

    # (Re)initialize fill counts if the bin-set length changed.
    if _fill_counts is None or _last_len != n or len(_fill_counts) != n:
        _fill_counts = np.zeros(n, dtype=np.int64)
        _last_len = n

    # Tightness: prefer bins whose remaining capacity is just enough.
    # Remaining space after placing item:
    leftover = bins - item
    # Score higher when leftover is small (best fit), but never negative-favor empty bins absurdly.
    # Use a base tightness that rewards small leftovers.
    tight = 100.0 - np.maximum(leftover, 0)

    # Harmonic balancing: divide tightness by sqrt(1 + fill_count).
    denom = np.sqrt(1.0 + _fill_counts.astype(np.float64))

    # Avoid picking a bin that leaves huge waste: penalize large leftover modestly.
    # Combine tightness with a mild preference for fuller bins via fill count.
    scores = tight / denom

    # Slight tie-break toward fitting exactly (leftover == 0) is already in tightness.
    # Make sure no NaN/inf.
    scores = np.nan_to_num(scores, nan=-1e9, posinf=1e9, neginf=-1e9)

    # Choose argmax now, and update fill count for the chosen bin.
    # The harness places into highest score, first tie. We replicate that choice
    # to keep _fill_counts in sync. To match exact behavior we return scores.
    best = int(np.argmax(scores))
    _fill_counts[best] += 1

    return scores
