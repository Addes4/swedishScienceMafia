import numpy as np

# ---------------------------------------------------------------------------
# Learning-to-rank bin-choice rule
#
# At every call we (a) score the candidate bins with a tiny linear model,
# (b) place the item in the best bin, and (c) run a few online gradient steps
# on a ranking loss that uses a hindsight "oracle" target order.  The oracle
# is a best-fit / best-worst-fit hybrid that we know is a strong heuristic,
# so the model is trained to imitate an idealised packing order rather than
# just reacting to the current bin vector.
# ---------------------------------------------------------------------------

# --- model / state ---------------------------------------------------------
_D = 5                      # feature dimension
_w = np.zeros(_D)           # learnable weights (linear scorer)
_b = 0.0                    # bias
_lr = 0.02                  # learning rate for online updates
_l2 = 1e-4                  # tiny weight decay
_step = 0

# feature extractor for a *single* bin given the item size
def _feats(item, cap):
    # cap is remaining capacity of the bin
    room = cap - item                      # leftover after placement (>=0)
    return np.array([
        cap / 100.0,                       # 1) how empty the bin is
        (100.0 - cap) / 100.0,             # 2) how full the bin is
        room / 100.0,                      # 3) leftover after placing
        (cap - item) / 100.0 if cap >= item else -1.0,   # 4) signed slack
        ((cap - item) == 0) * 1.0 + 0.5 * (cap / 100.0), # 5) exact-fit bonus
    ])

def _score_vec(item, bins):
    # vectorised scoring of all bins
    cap = bins.astype(np.float64)
    n = len(cap)
    F = np.empty((n, _D), dtype=np.float64)
    F[:, 0] = cap / 100.0
    F[:, 1] = (100.0 - cap) / 100.0
    F[:, 2] = (cap - item) / 100.0
    F[:, 3] = np.where(cap >= item, (cap - item) / 100.0, -1.0)
    F[:, 4] = ((cap - item) == 0).astype(np.float64) + 0.5 * (cap / 100.0)
    return F @ _w + _b, F

# the "oracle" order we want the model to imitate: a good packing puts the
# item where the leftover is small but not pathologically small, and keeps
# the set of bin sizes diverse (avoid making many tiny slivers).
def _oracle_target(item, bins, F):
    cap = bins.astype(np.float64)
    room = cap - item
    # residual quality: prefer small positive residual, heavily penalise
    # near-zero residual bins (they become unusable) and prefer bins that
    # keep a reasonable residual distribution.
    near_zero = np.exp(-room / 6.0)          # spike at room == 0
    small = room / 100.0                     # linear preference for tighter fit
    # diversity term: penalise bins that are much larger than the mean
    mu = cap.mean() if len(cap) else 0.0
    div = np.abs(cap - mu) / 100.0
    return -(1.2 * small + 0.8 * near_zero + 0.15 * div)

def priority(item, bins):
    """Score every bin; highest score wins, ties to the first bin."""
    global _w, _b, _step

    bins = np.asarray(bins)
    if bins.size == 0:
        return np.zeros(0, dtype=np.int64)

    scores, F = _score_vec(item, bins)

    # ----- online ranking update (differentiable RankNet-style loss) -----
    # Use the last few calls' gradients accumulated through a simple SGD step.
    # target order comes from the oracle heuristic on the same feature set.
    if bins.size > 1:
        t = _oracle_target(item, bins, F)
        t = t - t.mean()
        # softmax-style pair weights: emphasise top-vs-rest comparisons
        order = np.argsort(-t)
        # gradient of a listwise loss (approx. via weighted regression to t)
        # dL/dw = sum_i (s_i - t_i) * F_i, pulled towards oracle ranking.
        g = F.T @ (scores - t) / bins.size
        _w -= _lr * (g + _l2 * _w)
        _b -= _lr * float((scores - t).mean() * 0.1)
        _step += 1

    # ----- final scores (recompute with updated weights) -----
    final, _ = _score_vec(item, bins)
    return final
