import numpy as np

# Fast empirical sampler for future items based on observed sizes
# We maintain a histogram/count of all item sizes seen so far
_shapes_counts = np.zeros(101, dtype=np.int64)
_samples_seen = 0
_buffer = np.zeros(5000, dtype=np.int16) # Buffer to store recent items for quick sampling if needed

def priority(item, bins):
    """
    Strategy: Multi-step lookahead simulation.
    
    1. Immediate placement fits item 'item' into eligible bins.
    2. We conduct a fast rollout: for each candidate bin that can fit the item,
       we simulate placing the current item, then greedily pack the next |bins|-1 
       (or similar number of steps) items using our learned distribution.
    3. We score bins by the remaining space after this rollout. We prefer bins that 
       leave less residual space (denser).
    
    To be extremely fast (5000 calls within 30s), we avoid heavy NumPy operations 
    inside the loop over bins if possible, or vectorize heavily.
    Given N bins ~ 5000 (since bins array length equals max potential bins + unused capacity 100 items, 
    actually len(bins) grows with time but is capped at time budget), a pure simulation per bin 
    for N future steps is O(N^2) which is too slow.
    
    Optimization: 
    Instead of simulating 'k' future items per bin, we use a heuristic derived from the 
    "Next Fit" or "First Fit" density on average. However, the prompt asks specifically for 
    a "fast one-step rollout" with a forecast.
    
    Let's interpret "one-step rollout" as: 
    Place the current item. Then check how many items from our empirical distribution 
    fit in the *new* remaining space of each bin greedily (one step meaning one greedy packing 
    traversal using the forecast?).
    
    Actually, the constraint "Time limit: 30 seconds per instance" with 5000 items is loose enough 
    for optimized CPython+NumPy if we are smart. The trickiest part is 5000 bins * 5000 items check?
    Wait, the bin array length is the number of bins used so far. At time t, it's roughly t.
    So at the end, we have 5000 bins. Checking 5000 bins for 5 future items: 25,000 ops per call * 5000 calls = 125M ops. 
    This is borderline for Python 30s. We must vectorize.
    
    Revised Approach for Speed:
    1. Identify candidate bins where `bins > item`.
    2. Calculate `new_remaining = bins - item` for these candidates.
    3. Compute the "max additional items" that can fit in `new_remaining` using a greedy strategy 
       based on our empirical distribution of future items.
       Instead of simulating the exact sequence, we approximate the "density" of `new_remaining`.
       Density = sum of items that fit in `new_remaining` if we pick optimally? No, we must be greedy.
       
       Approximation for speed: 
       Predicted 'number of future items' that fit in space `S` = S / Mean(Item). 
       This is a very fast heuristic. The prompt says "forecast... and score... using a fast one-step rollout".
       Maybe "one-step" means checking *one* future item?
       
       Let's try to implement a strictly vectorized greedy check for ONE future item per candidate bin.
       This aligns with "one-step rollout".
       1. Place current item.
       2. Sample ONE next item from the distribution seen so far.
       3. Check if that specific item fits in the newly remaining space.
       4. Score = Item + (Item2 fits ? Item2 : 0).
       This is trivial vectorization.
       
       But wait, if the item doesn't fit, we stop. If it fits, do we stop? 
       "Rollout" implies continuation. But "fast one-step" implies only one step.
       Let's do: Current Item + Next Item (from dist). If Current + Next > Bin, then Next doesn't fit.
       If we do more steps, say 3, it might slow down significantly if done per bin.
       
       Let's try to leverage the fact that the distribution is Weibull (~mean 40). 
       Most items won't fit tightly if the remaining space is small.
       
       Faster Heuristic (The "Virtual Bin" Idea):
       For each candidate bin with remaining capacity R:
          Score = R - item.
          Forecast: Draw K items from history. 
          Count how many fit in (Score) greedily.
          Use this count (or total filled) as a reward.
          
       To make this fast:
          Pre-calculate `possible_counts` for all R derived from bins.
          This requires counting how many items from a SET of K items fit in R.
          This is O(N_bins * K). K=5, R=100. 
          If we use numpy, we can sort future items and use vectorized search.
    
    Let's refine the "one-step rollout":
    1. Get empirical distribution.
    2. Sample M items (e.g., M=3).
    3. For each candidate bin:
       a. Remaining after current item = r.
       b. Try to fit sample_0. (Uses 1 step).
       c. If fit, try sample_1. (Uses 2 steps).
       d. ...
       e. Score = number of samples that fit? Or sum of sizes?
          Usually, higher utilization (less leftover) is better. 
          Utilization = (item + filled_samples) / 100.
    
    Implementation Details:
    - `_hist_dist`: NumPy array of counts of sizes seen so far (len 101).
    - Sampling: `np.random.choice(a=_hist_dist > 0, size=1, p=...)`? No, manual sampling for vectorization.
    - We will sample a fixed number of future items (e.g., 3) ONCE per call, but we need to align them across bins.
      Actually, the rollout is per bin, but the future distribution is global.
      To avoid repeating the sampling logic vectorization-wise, we can pre-sample a small batch of "future items" 
      and use them as a uniform "next item" for all bins, repeating it if we simulate multiple steps.
      Then the "Greedy" check for the next item is: `r >= sample_i`.
    
    Wait, "Priority" function takes `bins` (remaining capacity).
    Let's implement:
    1. Calculate `potential_remaining = bins`.
    2. Mask where `potential_remaining > item`. Apply mask.
    3. We need to select ONE bin index to return (final score array).
    
    Algorithm:
    1. Estimate mean of distribution seen so far.
    2. Construct a sequence of `L` hypothetical items (e.g., L=3) from this distribution. To save time, 
       we can generate these items once, but since the previous item was just placed, the next is independent.
       We can use a deterministic seed or just sample.
       Better: Generate `L` items.
    3. For each candidate bin (vectorized):
       rem = bins[mask] - item
       # Check step 1: can next item[i] fit in rem?
       # We need to check if `rem >= sample[0]`.
       # If yes, `rem -= sample[0]`.
       # Check step 2: `rem >= sample[1]`.
       # ...
       # Score = -(item + sum_of_filled)  (negative because we use max score)
       # Actually higher score = better utilization means remaining capacity should be minimized.
       # Score = -remaining_capacity.
    
    To ensure speed and compliance:
    We will only roll out for 2 items (Current + 1 future) to be safe on time, OR simply calculate the 
    "Average Fit Density" of the current remaining space `banks` and score based on that, combined with a 
    sample check to break ties.
    
    However, the prompt explicitly says "one-step rollout".
    Let's stick to: Current Item + 1 Draft Item. 
    Score = (item + draft_item) if (item + draft_item <= bins) else item.
    Wait, minimizing "Remaining Capacity" is the goal.
    Score = 100 - Remaining.
    Remaining = bins - item - (draft_item if fits else 0).
    We want to minimize this remaining.
    So we want to maximize `item + (draft_item if fits else 0)`.
    
    BUT: This ignores deeper fits. The "one-step" might be interpreted as the lookahead length.
    Let's try to do a slightly deeper lookahead if the cost is low. 
    Total Bins max 5000. Operations = 5000 (bins) * 3 (steps) * 5000 (calls).
    If each call has 25000 checks, that's 125,000,000. In C++ this is fast. In Python with NumPy vectorization?
    Vectorizing 5000 bins requires operations on arrays of size 5000.
    We can do `np.greater` which is fast. 
    The limiting factor is creating the `sample` arrays for every bin? No, one sample array of size 3.
    `rem >= sample[0]` is a broadcast compare: [5000] vs [3] -> result [5000, 5000, 5000]?? No.
    Result is [5000] where each element is compared to sample[0].
    Yes, simple broadcasting works.
    
    Plan:
    1. Accumulate item counts in `hist` to sample future.
    2. In `priority`:
       a. Sample `L=3` future items (e.g., [10, 50, 8]).
       b. `cands = bins > item`
       c. `rem = bins[cands] - item`
       d. `filled = item`
       e. Iterate `step` in 0..L-1:
          if `cands` is empty -> return defaults for rest.
          # Check if all remaining blocks in `rem` can fit `sample[step]`
          # Note: Greedy means try largest first? The problem doesn't say we can reorder future items. 
          # "Forecast... and score". We usually assume the stream is fixed or random.
          # "Forecast... greedy... pack". Usually means we have a set, we pack best fit. 
          # But for speed, we assume a random draw from dist and check if it fits.
          # To be "Greedy", if we have multiple items to pick, we pick the largest?
          # Let's stick to "Sample from distribution, does it fit?".
          # To improve, we check the sampled item against current freedom.
          # If sample_item > rem, we cannot take it.
          # If we take it, we mark bin as 'taken'.
          # BUT: If we take a small item instead of a large one, we might fit more.
          # This is getting complex for "one-step".
          
          Let's simplify:
          Target: Minimize remaining capacity.
          Metric: `score = 1 / (remaining + eps)`.
          We project: `remaining_proj = remaining - next_item` IF `remaining >= next_item`.
          We want the bin where `next_item` is minimal (best fit) AND fits?
          No, we want the projection `remaining_proj` to be minimal.
          
          So: Iterate candidate bins.
          Value = remaining - item.
          Check sample[0]: if sample[0] <= Value, then Value -= sample[0].
          Check sample[1]: if sample[1] <= Value, then Value -= sample[1].
          ...
          Score = -Value.
    
    Optimization: We sample the *same* sequence of future items for all bins? 
    No, usually future items depend on the state, but for "forecast", we can just fix a seed or draw one set.
    Actually, changing the result based on the *same* random draw makes it unstable but fast.
    Drawing a different random stream for every bin is impossible (too slow).
    We draw one sequence of "Next 3 Items" globally. Every bin is tested against the *same* sequence.
    This ensures we are scoring bins against the *same* idealized future.
    
    One catch: If we pick a bin that is "tight" now but not tight after the sample item, it loses.
    This is exactly what the problem asks.
    
    Edge case: `bins` array might have different shapes or lengths across calls? 
    "bins is a numpy int64 array... There are as many bins as items...".
    So size grows.
    
    Let's code the hist accumulation and the vectorized greedy check.
    
    History: `counts` array size 101.
    Sampling: `np.random.choice` is slow if called once? No.
    We can use `np.random.choice(100, size=3, replace=True, p=...)` but that's generic.
    Better: `choice` by indices proportional to counts.
    `total = counts.sum()`. `indices = np.random.choice(range(100), size=100)`.
    Actually, standard numpy `choice` with `p` is fine.
    
    Wait, `bins` array is a *copy* (according to problem: "array is a copy").
    Wait, "bins ... array is a copy" might mean the caller provides a copy, or we should treat it as immutable?
    "There are as many bins as items; unused bins have remaining capacity 100".
    This usually implies the runtime builds the array up to `current_item_count`.
    We treat it as read-only for our scoring.
    
    Let's refine the "Distribution" accumulation.
    We can't accumulate inside `priority` too much if it triggers Python overhead.
    But `hist` is global (persistent). Updates are trivial.
    
    Implementation Detail on Speed:
    If `bins` length is 5000, 3 steps.
    Vectorized logic:
    `rem = bins > item` mask.
    `rem_size = bins[rem] - item`
    
    `samples` is shape (3,).
    `can_fit_0 = rem_size >= samples[0]`
    `rem_size = np.where(can_fit_0, rem_size - samples[0], rem_size)`
    `can_fit_1 = rem_size >= samples[1]`
    `rem_size = np.where(can_fit_1, rem_size - samples[1], rem_size)`
    
    This allows us to process all candidates in one go per step.
    This is extremely fast.
    
    Also, we need to fill the resulting scores for ALL bins (not just candidates) with `0` (or very low) to ensure they lose?
    Wait, "unused bins have remaining capacity 100". 
    If an unused bin (capacity 100) is chosen, we waste time if a better bin exists.
    "Ties go to first such bin". We must return valid scores for ALL bins length.
    If a bin doesn't fit (`bins <= item`), score should be -infinity (or -1, but bias matters).
    Best practice: return -999999 for invalid bins in priority score?
    Wait, harness says "Return a numpy array ... with one score per bin".
    "The item goes into the bin with the highest score".
    If we return -1 for invalid, and 0 for valid, it picks first valid?
    Wait, unused bins have capacity 100. They are valid!
    So all bins are valid candidates.
    Unused bins (capacity 100) will always have high capacity. We must penalize them if they leave nothing?
    Wait, we want to minimize remaining capacity.
    Unused bin (cap 100) -> after item -> 100-item.
    If used bin (cap 40) -> after item -> 0.
    Score should be lower for 0 remaining.
    Utility = -remaining.
    So unused bin (100) -> -60. Used bin (40) -> -60 (if 40 remaining).
    If used bin (1) -> -99.
    So we just want to match "Minimize Remaining".
    
    What about time limit? 30s for 5000 items.
    My vectorized approach: 
    5000 calls * (Histogram updates + 3 Vectorized steps on size=5000 arrays).
    125M operations in C (Vectorized). Python overhead per call is negligible.
    Should pass.
    
    Refinement on sampling:
    Drawing from histogram.
    We need to ensure the weights sum to 1. `counts` sum is `_samples_seen`.
    If `_samples_seen` is 0, we default to uniform 1..50 (estimating Weibull shape).
    
    Also, the problem asks to "score the bin by the resulting space utilization".
    Utilization = (Item + Filled) / 100.
    Score = 100 - (100 - Item - Filled) = Item + Filled.
    So Maximize `Filled`.
    
    Wait, if we have a bin with remaining 100 and a bin with 50.
    Item size 60.
    Bin 100: Filled 60 (plus future).
    Bin 50: Cannot fit (validity check? "bins ... remaining capacity of every bin the item fits in").
    Wait! The problem says: "`bins`... with the remaining capacity of every bin the item fits in."
    This means `bins` only contains bins that CAN fit the item! 
    Re-reading: "bins is a numpy int64 array with the remaining capacity of every bin the item fits in."
    Ah! This simplifies it immensely! 
    We do NOT need to check `bins > item`. All inputs are valid.
    Unused bins (capacity 100) are included.
    So `bins` array contains ONLY valid candidates.
    
    Wait, "unused bins have remaining capacity 100 and are included."
    So yes, all bins fit the item (since item <= 100).
    Okay, no validity masking needed!
    
    One more check: "ties go to the first such bin".
    If our scores are equal, numpy `argmax` returns the first? 
    Yes, `np.argmax` for ties returns the first index.
    But wait, if `bins` order is important.
    "Bins appear in a fixed order".
    If we sort, we lose order? 
    No, `priority` returns score array. Harness picks `bin_idx = argmax(scores)`.
    If scores are equal, harness picks lowest index (first).
    So we just need to ensure `scores` don't break this tie-breaking preference unless we want to influence it.
    The problem doesn't ask us to break ties manually.
    However, "Return a numpy array... one score per bin".
    If we return identical scores for 2 bins, harness picks the first.
    This is acceptable.
    
    Final Algorithm:
    1. Update Global `hist` with `item`.
    2. Sample `seq` (e.g. 12 items? No, too many. 3 items is "one-step lookahead" effectively).
       Maybe 3 items is enough. "Fast one-step".
       Let's try 4 items.
    3. Compute `space_after_current = bins - item`.
    4. `filled_current = item`.
    5. Loop `i` from 0 to 3:
       `item_next = seq[i]`
       `can_fit = space_after_current >= item_next`
       `space_after_current = np.where(can_fit, space_after_current - item_next, space_after_current)`
       `filled_easy = filled_current` + `item_next * can_fit` (summed? No, sum of fitted items).
       Actually, we just want the *remaining capacity*.
       `final_rem = space_after_current`.
    6. `score = -final_rem`.
    7. Return `score.astype(np.int64)`.
    
    Wait, we can't modify `space_after_current` in place for NumPy descending.
    But `np.where` creates new ans. Vectorized steps are cheap.
    4 steps * 5000 items = 20,000 ops per call. 5000 calls = 100M ops.
    Safe.
    
    Wait, `bins` array is a copy. We shouldn't depend on its order being preserved in `bins` logic?
    It says "Bins appear in a fixed order".
    Is it possible `bins` is sorted by index? Yes.
    
    One optimization: `spaces` is `int64`. `item` is `int64`. 
    Arithmetic is fast.
    
    Let's refine the "Forecast" logic.
    If the empirical distribution is not fully formed (early in instance), use a reasonable prior (e.g. mean 40).
    Also, "Weibull-shaped".
    
    Is 12 items really "fast"?
    If we can do 10 items in 5ms... 30s is plenty.
    The prompt says "one-step rollout". This phrasing is slightly ambiguous.
    It could mean "one step into the future".
    "Pack it greedily with a forecast of the next few items".
    Okay, "next few items" (plural).
    We will do 3 steps.
    
    Let's write the code.
</think>

