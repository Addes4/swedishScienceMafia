import numpy as np

# Global state for learning across calls
_has_state = False

if not _has_state:
    global _agent_stats, _alpha_val
    _agent_stats = {
        'total_bins': 0,
        'total_remaining': 0,
        'placements': 0,
    }
    _alpha_val = 0.5  # initial mix weight

def priority(item, bins):
    """Return a priority array; highest score (first tie) gets the item.

    item: integer size of the arriving item, 1..100
    bins: numpy int64 array with remaining capacity of all eligible bins
    """
    global _alpha_val

    global _agent_stats
    placements = _agent_stats['placements']
    total_bins = len(bins)

    # Determine a weighted mix between best-fit and flexibility score
    if len(bins) > 0:
        avg_remaining = bins.mean()
        # scale mixing alpha with average remaining capacity
        if avg_remaining < 40:
            _alpha_val = 0.3  # tighter utilization favors best-fit
        elif avg_remaining > 80:
            _alpha_val = 0.9  # more free space favors flexibility
        else:
            _alpha_val = 0.5

    # Best-fit score (tighter remaining space is better)
    tight = 100 - bins

    # Flexibility score: reward bins whose remaining capacity is close to mean item size (~40)
    target_fit = 40
    flex_target = np.abs(bins - target_fit)
    flex_raw = 100 - flex_target

    # Observed item sizes for learning future distribution
    global _item_size_moments
    if hasattr(priority, '_item_size_moments'):
        # Adaptive moments
        _mean_item = priority._item_size_moments.get('_mean', 40)
        _scale_item = priority._item_size_moments.get('_scale', 40)
    else:
        _mean_item = 40
        _scale_item = 40

    # Normalized flexibility: remaining capacity relative to expected future items
    normalized_flex = (bins >= _mean_item) & (bins >= _scale_item)
    flex_score = np.where(normalized_flex, 100, 50) + (bins / 100) * 40

    # Convex blending
    tight_score = tight
    flex_score_normal = flex_score

    # Mixing weight: 0 = pure tightness, 1 = full flexibility
    mix_weight = _alpha_val

    # Final combination: weighted average
    final_scores = mix_weight * tight_score + (1 - mix_weight) * flex_score_normal

    # Cap scores to prevent NaN issues
    final_scores = np.clip(final_scores, 0, 200)

    return final_scores.astype(np.int64)
