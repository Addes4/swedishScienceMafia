# EVOLVE-BLOCK-START
"""TD-learning value function for bin remaining capacity percentiles.

We discretise each bin's remaining capacity into a fixed number of percentiles
(relative to the bin capacity 100) and learn state values V(s) using a simple
temporal-difference (TD(0)) method.  The reward is 0 at every step except the
last item that fits into a bin (which "closes" the bin to perfect fullness):
that final placement receives +1 to encourage tight packings.  The learned
V(s) is used as the priority score.
"""

import numpy as np


# ----------------------------------------------------------------------
# Hyper-parameters (moderate values, tuned on offline intuition)
N_BUCKETS = 20                # discretise remaining capacity 0..100 into N_BUCKETS
ALPHA = 0.1                   # learning rate
GAMMA = 0.99                  # discount factor

# ----------------------------------------------------------------------
# Private module-level state
_bucket_edges = np.linspace(0, 100, N_BUCKETS + 1)  # including both endpoints

# Value function for each bucket.  Initialised to 0.0 (neutral).
_V = np.zeros(N_BUCKETS)

# We need to remember the "previous state" (bucket index) for TD updates.
_prev_bucket = None


def _bucket_index(rem):
    """Return bucket index for a *remaining capacity* (0..100)."""
    # digitize returns index in [1, N_BUCKETS]; we need [0, N_BUCKETS-1].
    idx = np.digitize(rem, _bucket_edges, right=False) - 1
    # safety clamp (rem == 100 falls into the last bucket)
    if idx >= N_BUCKETS:
        idx = N_BUCKETS - 1
    return idx


def priority(item, bins):
    """
    Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _prev_bucket

    # Convert each eligible bin's remaining capacity into a bucket and return the
    # corresponding value as priority.  Higher value → more desirable bin.
    # We must handle the empty-bins case gracefully (should never happen).
    if len(bins) == 0:
        return np.array([], dtype=np.float64)

    rem = bins  # remaining capacities for bins that can fit the item
    # vectorised bucket lookup
    bucket_indices = np.digitize(rem, _bucket_edges, right=False) - 1
    np.clip(bucket_indices, 0, N_BUCKETS - 1, out=bucket_indices)

    scores = _V[bucket_indices]

    # ---- TD update ----
    # After the item is placed, we will observe the *new* remaining capacity of the
    # chosen bin.  However, we are called *before* the item is placed.
    # We cannot directly observe which bin is chosen, nor the resulting state.
    # Instead, we treat the *best* bin according to current priorities as the
    # action, and we assume the item will be placed there.  After the next call
    # (when the next item arrives) we will see the new capacities of all bins,
    # but we cannot reliably map back to the previously chosen bin because we
    # only see a filtered list.  A simpler alternative: we use an **online**
    # TD(0) that updates when the *next* item arrives using an estimate of the
    # previous state and the current state.

    # Strategy:
    #   - On call t, we record the bucket of the bin we *would* choose (the argmax
    #     of scores, ties broken by position).  That is our "state S_t".
    #   - When call t+1 happens, we have a new item and a new set of bins.  The
    #     "state S_{t+1}" is the bucket of the bin that will be chosen *next*.
    #   - The reward R_t is 0 unless the previous placement exactly filled the bin
    #     (remaining capacity became 0), in which case R_t = 1.
    #   - Then we update V(S_t) += ALPHA * (R_t + GAMMA * V(S_{t+1}) - V(S_t)).

    # Because we cannot directly observe *which* bin was chosen after the fact
    # without extending the API, we approximate by using the *selected* bucket
    # at time t as S_t, and the *selected* bucket at time t+1 as S_{t+1}.
    # The reward signal for exactly filling a bin is inferred from the fact that
    # on the next call, the number of bins or capacities might change.  A simpler
    # proxy that doesn't require complex observation: we give a reward of +1 for
    # any placement that results in the bin's new remaining capacity being 0.
    # To implement this, we would need to observe the outcome of the placement.
    # Since we cannot, we approximate by using the *ideal* outcome: if the
    # selected bin had `item == rem`, i.e. a perfect fit, we assume it resulted
    # in a full bin and give an immediate reward of +1.  This is a heuristic
    # that encourages tight fits, which aligns with the original Best Fit idea
    # but learned via a value function.

    # Implementation:
    #   - Find the best bin index (first maximum).
    #   - If that bin's remaining capacity exactly equals the item, reward = 1
    #     (perfect fit), else reward = 0.
    #   - S_t is the bucket index of that chosen bin.
    #   - If we have a previous state _prev_bucket (from the previous call),
    #     compute TD error: delta = R_{t-1} + GAMMA * V(S_t) - V(_prev_bucket)
    #     and update V(_prev_bucket) += ALPHA * delta.
    #   - Store current bucket as _prev_bucket for the next call.

    best_idx = np.argmax(scores)  # ties broken to first
    chosen_rem = rem[best_idx]
    chosen_bucket = bucket_indices[best_idx]

    # Compute reward for the *previous* step using the current choice's
    # perfect-fit as an indicator (this is an approximation).
    # The actual previous step's reward could be derived if we had stored the
    # item and capacity.  We approximate by assuming that if the *previous*
    # chosen bin had `item_prev == remaining_prev`, then reward = 1.
    # But we do not have `item_prev` stored in a global here yet.
    # Instead we store item and the perfect-fit indicator for the *current*
    # step to be used as previous reward on the next call.

    global _prev_item_perfect
    if '_prev_item_perfect' not in priority.__globals__:
        _prev_item_perfect = 0  # reward for the step that just happened

    # TD update from previous state to current state
    if _prev_bucket is not None:
        delta = _prev_item_perfect + GAMMA * _V[chosen_bucket] - _V[_prev_bucket]
        _V[_prev_bucket] += ALPHA * delta

    # Prepare for next call
    _prev_bucket = chosen_bucket
    # reward for this step: 1 if the item exactly fills the chosen bin
    _prev_item_perfect = 1 if (item == chosen_rem) else 0

    return scores
# EVOLVE-BLOCK-END
