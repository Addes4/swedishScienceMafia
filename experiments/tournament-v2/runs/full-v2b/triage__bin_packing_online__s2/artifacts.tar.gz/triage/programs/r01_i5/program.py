import numpy as np

def priority(item, bins):
    """
    Hybrid scoring: combines best-fit with a penalty for wasting capacity
    in partially filled bins. The parameter α balances the two terms:
    when bins are nearly empty, best-fit dominates; when bins are partially
    full, the capacity waste penalty discourages further filling.
    """
    alpha = 0.3  # Tuned coefficient for capacity waste penalty
    waste_penalty = alpha * (bins - item) / np.maximum(bins, 1)  # Avoid division by zero
    score = -(bins - item) + waste_penalty
    return score
