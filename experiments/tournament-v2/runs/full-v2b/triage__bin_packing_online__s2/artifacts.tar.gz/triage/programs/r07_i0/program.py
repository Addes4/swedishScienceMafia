import numpy as np

# Global state for online learning
_initialized = False

if not _initialized:
    # Single-layer perceptron: weights for 5 input features + bias
    # Features per bin: [remaining_capacity/100, item_size/100, (remaining_capacity - item_size)/100, 
    #                    gap_size/100, bin_fill_count/100]
    global _weights, _bias, _learning_rate, _momentum, _velocity_w, _velocity_b
    global _bin_fill_counts, _bin_history, _placed_bins
    
    _weights = np.random.randn(5) * 0.01
    _bias = 0.0
    _learning_rate = 0.005
    _momentum = 0.9
    _velocity_w = np.zeros(5)
    _velocity_b = 0.0
    
    # Track which bin each item went into and bin fill counts
    _bin_fill_counts = []  # List of cumulative fill amounts per bin
    _bin_history = []  # Track (item, bin_index) for recent placements
    _placed_bins = set()  # Track active bin indices

def _sigmoid(x):
    """Sigmoid activation function, clipped to avoid overflow."""
    x = np.clip(x, -50, 50)
    return 1.0 / (1.0 + np.exp(-x))

def _extract_features(item, bins):
    """Extract feature vectors for all candidate bins.
    
    Features:
    0: remaining_capacity / 100
    1: item_size / 100
    2: (remaining_capacity - item_size) / 100
    3: gap_size / 100 (how much space is left if placed here)
    4: bin_fill_count / 100 (how filled this bin currently is)
    """
    n_bins = len(bins)
    features = np.zeros((n_bins, 5), dtype=np.float64)
    
    remaining = bins.astype(np.float64)
    item_norm = item / 100.0
    remaining_after = (remaining - item) / 100.0
    gap = remaining_after  # Same as remaining after in normalized form
    
    features[:, 0] = remaining / 100.0
    features[:, 1] = item_norm
    features[:, 2] = remaining_after
    features[:, 3] = gap
    
    # For fill count, we need to know which physical bin each candidate corresponds to
    # Since the harness provides bins as an array where index corresponds to bin identity,
    # and unused bins have capacity 100, we can estimate fill count as 100 - remaining
    features[:, 4] = (100.0 - remaining) / 100.0
    
    return features

def _update_model(item, bin_index, bins_before, bins_after_placement, all_bins):
    """Update model weights based on placement outcome.
    
    Reward bins that lead to tight packing. The loss encourages:
    - If the remaining gap after placement is small, it was a good choice (positive reward)
    - If another bin later gets filled exactly by a subsequent item, the bin that created
      the matching gap gets retroactive reward
    """
    global _weights, _bias, _velocity_w, _velocity_b, _learning_rate, _momentum
    global _bin_history, _placed_bins, _bin_fill_counts
    
    remaining_before = bins_before[bin_index]
    remaining_after = remaining_before - item
    
    # Primary reward: tighter fit is better
    # Loss: we want high score for bins that result in small remaining capacity
    # Target: 1.0 if perfect fit (remaining_after == 0), decreases as gap grows
    gap_ratio = remaining_after / 100.0
    target_score = np.exp(-gap_ratio * 3.0)  # Decay rapidly for larger gaps
    
    # Compute features for the chosen bin
    features = _extract_features(item, np.array([bins_before[bin_index]]))[0]
    
    # Forward pass for the chosen bin
    linear_output = np.dot(features, _weights) + _bias
    predicted_score = _sigmoid(linear_output)
    
    # Error
    error = target_score - predicted_score
    
    # Gradient of sigmoid
    grad = error * predicted_score * (1.0 - predicted_score)
    
    # Update weights with momentum
    _velocity_w = _momentum * _velocity_w + _learning_rate * grad * features
    _velocity_b = _momentum * _velocity_b + _learning_rate * grad
    _weights += _velocity_w
    _bias += _velocity_b
    
    # Track this placement for potential retroactive rewards
    _bin_history.append((item, bin_index, remaining_after))
    
    # Keep only recent history (last 200 placements)
    if len(_bin_history) > 200:
        _bin_history.pop(0)
    
    # Check for retroactive rewards: did this item exactly fill a gap left by a previous item?
    # Look back through recent history
    if len(_bin_history) > 1:
        # For the last few placements into the same bin, check if this item filled a gap
        bin_placements = [(it, idx, gap) for it, idx, gap in _bin_history if idx == bin_index]
        if len(bin_placements) >= 2:
            # The previous placement left a gap; this placement filled part or all of it
            prev_item, prev_idx, prev_gap = bin_placements[-2]
            if abs(prev_gap - item) <= 1:  # Exact or near-exact fill
                # Retroactive reward for the previous placement
                prev_features = _extract_features(prev_item, np.array([bins_before[prev_idx]]))[0]
                prev_linear = np.dot(prev_features, _weights) + _bias
                prev_pred = _sigmoid(prev_linear)
                prev_error = 1.0 - prev_pred  # Target 1.0 for perfect fill prediction
                prev_grad = prev_error * prev_pred * (1.0 - prev_pred)
                
                _velocity_w = _momentum * _velocity_w + _learning_rate * 0.5 * prev_grad * prev_features
                _velocity_b = _momentum * _velocity_b + _learning_rate * 0.5 * prev_grad
                _weights += _velocity_w
                _bias += _velocity_b

def priority(item, bins):
    """Return a priority array; highest score (first tie) gets the item.
    
    item: integer size of the arriving item, 1..100
    bins: numpy int64 array with remaining capacity of all eligible bins
    """
    global _weights, _bias
    
    if len(bins) == 0:
        return np.array([], dtype=np.int64)
    
    # Extract features for all candidate bins
    features = _extract_features(item, bins)
    
    # Forward pass: compute scores
    linear_outputs = np.dot(features, _weights) + _bias
    scores = _sigmoid(linear_outputs)
    
    # Scale to integers for tie-breaking
    scores = np.nan_to_num(scores, nan=0.0)
    
    # Add tiny random noise for tie-breaking
    noise = np.random.rand(len(scores)) * 1e-6
    scores += noise
    
    # Scale to range [0, 1000] for nice integer output
    if scores.max() > scores.min():
        scores = 1000.0 * (scores - scores.min()) / (scores.max() - scores.min())
    else:
        scores = np.full_like(scores, 500.0)
    
    return scores.astype(np.int64)

def _on_placement(item, chosen_bin_index, bins_before, bins_after, all_bins):
    """Called after the harness places the item to update the model.
    
    This would need to be hooked into the harness, but since we can't modify the harness,
    we include this function for documentation and as a placeholder. In practice, we
    can't intercept the placement decision without harness support.
    
    However, we can use a hack: memorize the state during priority() call and perform
    the update on the next call, assuming the harness uses our returned scores immediately.
    """
    pass

# Since we can't hook into placement events, we use a side-channel: 
# store the last bins and item to infer what happened
_last_item = None
_last_bins = None
_last_scores = None
_call_count = 0

def priority(item, bins):
    """Return a priority array; highest score (first tie) gets the item.
    
    item: integer size of the arriving item, 1..100
    bins: numpy int64 array with remaining capacity of all eligible bins
    """
    global _weights, _bias, _last_item, _last_bins, _last_scores, _call_count
    global _bin_history, _placed_bins
    
    _call_count += 1
    
    # Try to infer what happened on the last call for learning
    if _last_item is not None and _last_bins is not None and _last_scores is not None:
        if len(_last_bins) > 0:
            # Find which bin was likely chosen (highest score, first tie)
            chosen_idx = np.argmax(_last_scores)
            
            # The current bins array reflects the state after last placement
            # (since one bin's capacity changed)
            # Actually, this is tricky - we get bins array fresh each call.
            # We don't have direct access to previous bins state.
            # Instead, we'll use a simpler approach: learn from the feature that 
            # "if item fits with small gap, that's good"
            
            # Simpler: just update based on the placement we're about to recommend
            # by assuming our top choice will be used. If another bin gets used,
            # the model will adapt over time.
            pass
    
    if len(bins) == 0:
        _last_item = item
        _last_bins = bins
        _last_scores = np.array([], dtype=np.int64)
        return _last_scores
    
    # Extract features
    features = _extract_features(item, bins)
    
    # Forward pass
    linear_outputs = np.dot(features, _weights) + _bias
    scores = _sigmoid(linear_outputs)
    scores = np.nan_to_num(scores, nan=0.0)
    
    # Add tiny noise for tie-breaking
    noise = np.random.rand(len(scores)) * 1e-6
    scores += noise
    
    # Store for potential learning on next call
    _last_item = item
    _last_bins = bins.copy()
    
    # Scale scores
    if scores.max() > scores.min():
        final_scores = 1000.0 * (scores - scores.min()) / (scores.max() - scores.min())
    else:
        final_scores = np.full_like(scores, 500.0)
    
    _last_scores = final_scores.copy()
    
    # Perform online learning on the current placement decision
    # We do a small update encouraging the chosen bin if it leads to tight packing
    if len(bins) > 0:
        top_idx = np.argmax(final_scores[:len(bins)])
        remaining_after = bins[top_idx] - item
        gap_ratio = max(0, remaining_after) / 100.0
        target = np.exp(-gap_ratio * 3.0)
        
        feat = features[top_idx]
        pred = _sigmoid(np.dot(feat, _weights) + _bias)
        error = target - pred
        grad = error * pred * (1.0 - pred)
        
        global _velocity_w, _velocity_b, _learning_rate, _momentum
        _velocity_w = _momentum * _velocity_w + _learning_rate * grad * feat
        _velocity_b = _momentum * _velocity_b + _learning_rate * grad
        _weights += _velocity_w
        _bias += _velocity_b
    
    return final_scores.astype(np.int64)
