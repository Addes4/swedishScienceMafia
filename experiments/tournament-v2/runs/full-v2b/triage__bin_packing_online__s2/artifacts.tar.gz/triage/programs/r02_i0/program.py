import numpy as np
from collections import deque

def priority(item, bins):
    # State initialization on first call
    if not hasattr(priority, "counts"):
        priority.counts = np.zeros(101, dtype=np.float64)  # index 1..100 used
        priority.total = 0
        priority.smooth_dist = np.ones(101, dtype=np.float64) / 100.0  # uniform prior
        priority.smooth_dist[0] = 0.0
        priority.alpha = 0.01  # smoothing factor for exponential moving average

    # Update item size distribution estimate
    priority.counts[item] += 1
    priority.total += 1
    # Exponential moving average of distribution
    emp_dist = priority.counts / priority.total
    priority.smooth_dist = (1 - priority.alpha) * priority.smooth_dist + priority.alpha * emp_dist
    priority.smooth_dist[0] = 0.0
    dist = priority.smooth_dist / priority.smooth_dist.sum()  # normalize

    # Compute scores for each bin
    # For each bin, compute expected number of future items that exactly fit the remaining space
    # after placing the current item.
    residue = bins - item  # remaining capacity after placing item
    # Clip residues to valid range [0, 100]
    residue_clipped = np.clip(residue, 0, 100).astype(int)
    scores = dist[residue_clipped]

    # Break ties: prefer bins with smaller residue (more tightly packed)
    # Add a small tie-breaking term inversely proportional to residue
    scores = scores + 1.0 / (residue_clipped + 1) * 1e-6

    return scores.astype(np.float64)
