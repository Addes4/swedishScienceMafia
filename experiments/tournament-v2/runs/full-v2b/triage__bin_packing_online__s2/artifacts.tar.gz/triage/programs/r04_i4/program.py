import numpy as np

# Global state
_initialized = False

def _init_state():
    global _counts, _thresholds, _decay
    # Discretize item sizes into 10 bins: 0-10, 11-20, ..., 91-100
    # Discretize remaining capacity into 10 percentiles (learned adaptively)
    # 3D table: [item_cat, cap_cat, 2] -> counts of [success (filled well), total placements]
    _counts = np.ones((10, 10, 2))  # Laplace smoothing
    _thresholds = np.linspace(0, 100, 11)[1:-1]  # initial equal-width bins
    _decay = 0.999  # exponential recency weight

def _item_category(item):
    # 0-indexed category: 0-9 -> 0, 10-19 -> 1, ..., 90-100 -> 9
    return min(int(item) // 10, 9)

def _cap_category(capacity, thresholds):
    # Find which bucket the capacity falls into
    # thresholds are boundaries between buckets
    for i, t in enumerate(thresholds):
        if capacity <= t:
            return i
    return len(thresholds)  # last bucket (above all thresholds)

def priority(item, bins):
    """Return a priority array; highest score (first tie) gets the item.

    item: integer size of the arriving item, 1..100
    bins: numpy int64 array with remaining capacity of all eligible bins
    """
    global _initialized, _counts, _thresholds, _decay
    
    if not _initialized:
        _init_state()
        _initialized = True
    
    n_bins = len(bins)
    if n_bins == 0:
        return np.array([], dtype=np.int64)
    
    item_cat = _item_category(item)
    
    # Determine capacity categories for all bins
    cap_cats = np.array([_cap_category(b, _thresholds) for b in bins])
    
    # Look up success probabilities: counts[item_cat, cap_cat, 0] / counts[item_cat, cap_cat, 1]
    # Higher probability = better bin
    success = _counts[item_cat, cap_cats, 0]
    total = _counts[item_cat, cap_cats, 1]
    
    # Score is empirical probability of successful fill
    scores = success / total
    
    # Tie-breaking: among equal scores, prefer bins with capacity closer to item size
    # (minimize waste)
    waste = bins - item
    # Small bonus inversely proportional to waste (max 0.01 adjustment)
    tie_break = np.where(waste >= 0, 0.01 * (1.0 - waste / 100.0), -0.01)
    
    final_scores = scores + tie_break
    
    return final_scores.astype(np.float64)


def update_priority_state(item, chosen_bin_capacity, success):
    """Called by harness after placement to update learning.
    
    success: True if fill was efficient (waste <= 10% of bin capacity or bin is full)
    """
    global _counts, _decay
    item_cat = _item_category(item)
    cap_cat = _cap_category(chosen_bin_capacity, _thresholds)
    
    # Apply decay to all counts
    _counts *= _decay
    
    # Update specific cell
    if success:
        _counts[item_cat, cap_cat, 0] += 1
    _counts[item_cat, cap_cat, 1] += 1
    
    # Periodically update thresholds based on observed capacity distribution
    # (This would require storing a histogram; simplified here but mentioned for completeness)
    # For simplicity, keep fixed equal-width thresholds
