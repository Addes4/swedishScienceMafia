import numpy as np
from scipy.stats import rv_histogram

# Global state for learning across calls
_state_initialized = False

if not _state_initialized:
    global _item_history, _survival_dist
    _item_history = []
    _survival_dist = None
    _state_initialized = True

def _update_survival():
    """Update empirical survival function from observed item sizes."""
    global _item_history, _survival_dist
    if len(_item_history) >= 3:  # Need some data for distribution
        # Create histogram distribution
        hist_dist = rv_histogram(np.histogram(_item_history, bins=100, range=(1, 100), density=True))
        _survival_dist = hist_dist
    else:
        # Default: uniform-like survival
        class DefaultSurvival:
            def sf(self, x):
                return np.maximum(0, (100 - x) / 100)
        _survival_dist = DefaultSurvival()

def _expected_fits(capacity, survival_dist):
    """Expected number of items that can fit into remaining capacity.
    
    Uses the survival function integrated over item sizes that would fit.
    """
    if capacity <= 0:
        return 0.0
    
    # We compute expected number of items by dynamic programming approximation
    # Using integral of survival function: E[items] ≈ Σ P(item ≤ capacity) * (1 + E_fits(capacity - item_size))
    # Accurate computation is complex, so we use approximation:
    # Expected items ≈ capacity / E[item_size] (first order) but refined by survival
    
    # Get survival values at discrete points
    sizes = np.arange(1, capacity + 1)
    surv = survival_dist.sf(sizes)
    
    # Expected number of items ≈ sum over sizes of survival probability
    # This is a rough approximation: each size has probability of fitting
    expected = np.sum(surv) / len(sizes) * (capacity / np.mean(sizes[sizes <= capacity])) if np.sum(sizes <= capacity) > 0 else 0
    
    # Better: use empirical mean
    if len(_item_history) > 0:
        mean_item = np.mean(_item_history)
    else:
        mean_item = 40  # Default
    
    expected = capacity / mean_item  # Simple approximation
    
    return expected

def _marginal_value(bin_capacity, item_size, survival_dist):
    """Compute marginal value: expected number of additional items lost by using this bin."""
    if bin_capacity < item_size:
        return -np.inf  # Can't place
    
    # Before placement
    expected_before = _expected_fits(bin_capacity, survival_dist)
    # After placement
    expected_after = _expected_fits(bin_capacity - item_size, survival_dist)
    
    # Value is how much we lose (negative, so smaller loss is better)
    # We want to minimize the reduction in expected future items
    return expected_before - expected_after

def priority(item, bins):
    """Return priority array for bin selection.
    
    item: integer size of the arriving item, 1..100
    bins: numpy int64 array with remaining capacity of all eligible bins
    """
    global _item_history, _survival_dist
    
    # Record item for learning
    _item_history.append(item)
    if len(_item_history) > 5000:
        _item_history.pop(0)
    
    # Update survival distribution
    _update_survival()
    
    if len(bins) == 0:
        return np.array([], dtype=np.int64)
    
    # Compute marginal value for each bin (smaller loss = better = higher score)
    scores = np.zeros(len(bins), dtype=np.float64)
    
    for i, cap in enumerate(bins):
        marginal = _marginal_value(cap, item, _survival_dist)
        # Convert to score: smaller marginal loss means higher score
        # Use -marginal (since marginal is loss) and add constant to avoid negative
        scores[i] = -marginal
    
    # Handle any NaN/Inf
    scores = np.nan_to_num(scores, nan=-1e10, posinf=-1e10, neginf=-1e10)
    
    # Normalize to 0-100 range for stability
    if len(scores) > 0:
        min_score = np.min(scores)
        max_score = np.max(scores)
        if max_score > min_score:
            scores = 100 * (scores - min_score) / (max_score - min_score)
        else:
            scores = np.ones_like(scores) * 50
    
    return scores.astype(np.int64)
