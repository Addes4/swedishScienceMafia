import numpy as np

# ---------------------------------------------------------------------------
# Global state (persists across calls, never sees future items)
# ---------------------------------------------------------------------------
_state = {
    "items_seen": 0,
    "item_hist": None,       # rolling buffer of observed item sizes
    "hist_len": 0,
    "ecdf_sorted": None,     # sorted copy for fast quantile lookups
    "q_target": 40.0,        # running percentile target (median)
    "mean_item": 40.0,
    "n_past": 0,
}

_HIST_CAP = 2048
_WARMUP = 32


def _update_stats(item):
    s = _state
    s["items_seen"] += 1
    s["n_past"] += 1
    # exponential running mean
    s["mean_item"] += (item - s["mean_item"]) / max(1.0, min(s["n_past"], 200.0))

    if s["item_hist"] is None:
        s["item_hist"] = np.empty(_HIST_CAP, dtype=np.float64)
        s["hist_len"] = 0

    idx = s["hist_len"]
    if idx < _HIST_CAP:
        s["item_hist"][idx] = item
        s["hist_len"] = idx + 1
    else:
        # reservoir-free ring replacement: overwrite positions pseudo-randomly
        pos = (s["items_seen"] * 2654435761) % _HIST_CAP
        s["item_hist"][pos] = item

    if s["hist_len"] >= 3:
        s["ecdf_sorted"] = np.sort(s["item_hist"][: s["hist_len"]])
        s["q_target"] = float(np.median(s["ecdf_sorted"]))


def _gap_density(bins, ecdf_sorted, mean_item):
    """For each bin, estimate how many future items (from empirical size
    distribution) can fit in the remaining gap.  Higher is better."""
    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    if ecdf_sorted is not None and len(ecdf_sorted) >= 3:
        # piecewise-constant survival function over integer sizes 1..100
        # P(size <= k) via searchsorted on sorted samples
        surv_scores = np.empty(n, dtype=np.float64)
        # estimate expected count of items fitting in gap g:
        #   integrate over item sizes s of P(fit | s) ~ (g >= s)
        # Use the survival distribution: expected number of items that fit
        # is bounded by sum over possible sizes of P(size == s) * (g >= s)
        # but to make it a *density* of packable mass, use:
        #   E[mass that fits] = sum_s P(s) * s * [g >= s]
        vals = ecdf_sorted
        m = len(vals)
        # cumulative mass by size threshold
        sorted_vals = vals
        cum_mass = np.cumsum(sorted_vals)
        total_mass = float(cum_mass[-1])

        for i in range(n):
            g = bins[i]
            if g <= 0:
                surv_scores[i] = 0.0
                continue
            k = np.searchsorted(sorted_vals, g, side="right")
            if k <= 0:
                surv_scores[i] = 0.0
                continue
            mass_fit = float(cum_mass[k - 1])
            count_fit = float(k)
            # expected number of items that fit, weighted by mass fraction
            score = count_fit + 3.0 * (mass_fit / max(1.0, total_mass)) * 100.0
            surv_scores[i] = score
        # normalize into a reasonable range
        return surv_scores

    # fallback: simple expected count assuming mean_item
    return np.minimum(bins / max(1.0, mean_item), 8.0) * 10.0


def priority(item, bins):
    """Adaptive bin-choice: dynamic percentile target + gap-density penalty."""
    _update_stats(item)

    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.int64)

    bins_f = bins.astype(np.float64)

    # ------------------------------------------------------------------
    # 1) Best-fit style tightness: smaller remaining capacity preferred
    # ------------------------------------------------------------------
    tight_score = (100.0 - bins_f) * 1.0

    # ------------------------------------------------------------------
    # 2) Adaptive flexibility: bins whose remaining capacity is near the
    #    running median of past items are "well-shaped" for the future.
    # ------------------------------------------------------------------
    q_target = _state["q_target"]
    mean_item = _state["mean_item"]
    # blend target between running median and running mean
    target = 0.5 * q_target + 0.5 * mean_item
    if target < 1.0:
        target = 40.0

    flex = -np.abs(bins_f - target)
    # small bonus for bins that still have room for a "typical" item
    flex_bonus = (bins_f >= target).astype(np.float64) * (target * 0.5)
    flex_score = flex + flex_bonus

    # ------------------------------------------------------------------
    # 3) Gap-density penalty: reward bins whose gap can fit many future
    #    items from the empirical distribution (packable mass).
    # ------------------------------------------------------------------
    ecdf = _state["ecdf_sorted"]
    gap_score = _gap_density(bins_f, ecdf, mean_item)

    # ------------------------------------------------------------------
    # Blend.  Early on (little data) lean best-fit; later blend in the
    # adaptive target and the gap density.
    # ------------------------------------------------------------------
    seen = _state["items_seen"]
    if seen < _WARMUP:
        w_gap = 0.05
        w_flex = 0.05
    else:
        # grow gap density influence as more data accumulates, bounded
        conf = min(1.0, seen / 1500.0)
        w_gap = 0.15 + 0.35 * conf
        w_flex = 0.15 + 0.25 * conf

    w_tight = 1.0

    final = w_tight * tight_score + w_flex * flex_score + w_gap * gap_score

    # prefer exact-ish fits: tiny nudge to reduce fragmentation risk
    final = final + 0.001 * (100.0 - bins_f)

    final = np.clip(final, -1e6, 1e6)
    if not np.all(np.isfinite(final)):
        final = np.nan_to_num(final, nan=0.0, posinf=1e6, neginf=-1e6)

    return final
