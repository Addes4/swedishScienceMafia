import numpy as np

# Global state: for each bin ever created (indexed by bin index), we store its "birth time"
# (the number of items that have arrived so far when the bin was first used).
# Since we don't know the absolute bin index from the bins array alone (the array is a copy
# of current capacities for bins the item fits in, in fixed order), we maintain a parallel
# array of birth times for all bins seen so far.

class State:
    def __init__(self):
        self.birth_time = []  # birth_time[bin_index] = item_count when bin first used
        self.item_count = 0   # number of items processed so far
        self.bin_count = 0    # number of bins created so far

state = State()

def priority(item, bins):
    """Harmonic aging score: prefer bins that have been open longer (older birth time)
    and have higher fill percentage. Ties go to first bin.
    
    Score = - (age_rank_component) + fill_component
    where age_rank_component is rank of birth time (older = smaller rank = better)
    and fill_component is current fill ratio.
    """
    state.item_count += 1
    
    # The length of bins tells us how many bins currently exist (including unused ones)
    num_bins = len(bins)
    
    # Extend birth_time array if new bins were created
    while len(state.birth_time) < num_bins:
        state.birth_time.append(state.item_count - 1)  # This bin is being "born" now
        state.bin_count += 1
    
    # Update: if any bin that previously had capacity 100 now has <100, it means
    # it was used. But we don't have previous capacity. Instead, we assume a bin gets
    # its birth time the first time it appears with capacity < 100, but we can't
    # detect that from current snapshot alone. Better: when a new bin index appears
    # beyond previous count, it's born. When an existing bin is used for the first time,
    # its capacity drops from 100 to something else. We can detect this by checking
    # if capacity < 100 and birth_time is unset (we can use a sentinel like -1).
    # Initialize new birth times to -1.
    for i in range(num_bins):
        if i >= len(state.birth_time):
            state.birth_time.append(-1)
    for i in range(num_bins):
        if state.birth_time[i] == -1 and bins[i] < 100:
            state.birth_time[i] = state.item_count - 1
        elif state.birth_time[i] == -1 and bins[i] == 100:
            # Might be unused bin waiting; don't set birth time yet
            pass
    
    # Now compute scores
    # Age component: older bins (smaller birth time) should have higher priority.
    # Use rank of birth time (1 = oldest among current bins). For bins with birth_time == -1
    # (unused so far), treat them as newest.
    ages = np.array([state.birth_time[i] if i < len(state.birth_time) and state.birth_time[i] != -1 
                     else state.item_count + 1 for i in range(num_bins)], dtype=np.float64)
    
    # Rank ages: smallest age (oldest) gets rank 1
    # Use scipy or manual ranking. Since numpy only, we can do argsort of ages, then assign ranks.
    # Ties: first bin wins on ties, so we need a stable rank. We'll use the order as secondary key.
    order = np.arange(num_bins, dtype=np.float64)
    # Combine age and order for stable sorting
    composite = ages * 1e9 + order  # ages dominate, order breaks ties
    ranks = np.empty(num_bins, dtype=np.float64)
    sorted_idx = np.argsort(composite)
    ranks[sorted_idx] = np.arange(1, num_bins + 1)
    
    # Fill component: current fill ratio = (100 - remaining) / 100
    fill_ratios = (100.0 - bins) / 100.0
    
    # Final score: higher is better. We want old bins (lower rank) to have high score.
    # Score = -ranks + alpha * fill_ratios, where alpha balances age vs fill.
    # Empirically, alpha around 0.5 to 2.0; tune slightly.
    alpha = 1.0
    score = -ranks + alpha * fill_ratios
    
    return score
