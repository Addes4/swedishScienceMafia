import numpy as np

# Global state for adaptive moment tracking
_item_mean = None
_item_count = 0
_initialized = False

if not _initialized:
    _item_mean = 0.0
    _item_count = 0
    _initialized = True

def priority(item, bins):
    """
    Online sum-of-squares bin packing heuristic.
    
    Score each bin by the squared fill level after the item would be placed.
    Favor bins that become very full (near 100) or remain very empty,
    implicitly penalizing medium-fill bins that waste capacity.
    
    item: integer size of the arriving item, 1..100
    bins: numpy int64 array with remaining capacity of all eligible bins
    """
    global _item_mean, _item_count
    
    # Update running mean of item sizes for adaptive empty-bin heuristic
    _item_count += 1
    _item_mean = _item_mean + (item - _item_mean) / _item_count
    
    n = len(bins)
    
    # Current fill level for each bin
    current_fill = 100 - bins
    
    # Fill level if item placed in each bin
    fill_after = current_fill + item
    
    # Sum-of-squares: square the fill percentage (0.0 to 1.0)
    # This creates a convex function that rewards extremes (0 or 100)
    fill_ratio = fill_after / 100.0
    sq_score = fill_ratio * fill_ratio
    
    # Scale to approximately 0-100 range for score dominance
    base_score = sq_score * 100.0
    
    # Add small tiebreaker: prefer bins with slightly more remaining space
    # among similar fill levels, so we don't waste nearly-full bins
    # This helps when two bins would have identical fill after placing
    tiebreaker = bins.astype(np.float64) * 0.001
    
    # Combine: primary score from squared fill, tiny tiebreaker
    scores = base_score + tiebreaker
    
    return scores.astype(np.float64)
