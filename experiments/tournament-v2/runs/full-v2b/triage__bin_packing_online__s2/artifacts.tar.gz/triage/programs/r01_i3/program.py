# EVOLVE-BLOCK-START
"""Best-fit with capacity-scaled jitter to reduce systematic bias."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base score: minimize remaining capacity after placement (tight fit)
    waste = bins - item  # waste after placing item in this bin
    base_score = -waste  # higher is better (lower waste = higher score)

    # Add small random jitter scaled inversely with remaining capacity after placement
    # This allows exploration among nearly equivalent tight fits
    remaining_after = waste
    jitter_scale = 2.0  # base jitter magnitude

    # Avoid division by zero and scale jitter inversely with tightness
    # Smaller remaining capacity (tighter fit) => larger jitter for exploration
    min_remaining = remaining_after.min() if remaining_after.size > 0 else 100

    if min_remaining > 0 and remaining_after.size > 0:
        jitter_scale = jitter_scale / min_remaining

    # Generate jitter, ensuring it doesn't flip every bin's score deterministically
    jitter = jitter_scale * np.random.normal(0, 1.0, bins.size)

    return base_score + jitter
# EVOLVE-BLOCK-END
