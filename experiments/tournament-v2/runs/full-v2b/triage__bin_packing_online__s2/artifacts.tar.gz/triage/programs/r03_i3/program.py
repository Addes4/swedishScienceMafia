import numpy as np

# Global state for learning across calls
_has_state = False

if not _has_state:
    # Gap histogram tracking
    # We track gaps (remaining capacity after placement) and whether they were later filled
    # We discretize gaps into bins of size 5 for compact representation
    _gap_bin_size = 5
    _num_gap_bins = 21  # 0-4, 5-9, ..., 95-99, 100 (but 100 means empty bin, not a gap from placement)
    _gap_created_count = np.zeros(_num_gap_bins, dtype=np.float64)  # how many times each gap size was created
    _gap_filled_count = np.zeros(_num_gap_bins, dtype=np.float64)   # how many times that gap was later filled
    _gap_total_waste = np.zeros(_num_gap_bins, dtype=np.float64)    # total waste associated with gap sizes
    
    # For tracking which bins have which gaps
    _bin_gaps = {}  # bin_index -> gap size after placement
    _current_bin_count = 0
    
    # Running statistics
    _mean_item_size = 40.0
    _item_count = 0
    _alpha_val = 0.5

def _gap_index(gap):
    """Convert a gap size to histogram bin index."""
    if gap <= 0:
        return 0
    if gap >= 100:
        return _num_gap_bins - 1
    return min(int(gap // _gap_bin_size), _num_gap_bins - 1)

def _gap_center(idx):
    """Get the center value of a gap histogram bin."""
    if idx == _num_gap_bins - 1:
        return 100
    return idx * _gap_bin_size + _gap_bin_size / 2

def priority(item, bins):
    """Return a priority array; highest score (first tie) gets the item.

    item: integer size of the arriving item, 1..100
    bins: numpy int64 array with remaining capacity of all eligible bins
    """
    global _alpha_val, _mean_item_size, _item_count
    global _gap_created_count, _gap_filled_count, _gap_total_waste
    global _bin_gaps, _current_bin_count

    # Update item size statistics
    _item_count += 1
    _mean_item_size = (_mean_item_size * (_item_count - 1) + item) / _item_count

    # Determine mixing weight based on system state
    if len(bins) > 0:
        avg_remaining = bins.mean()
        if avg_remaining < 30:
            _alpha_val = 0.15  # very tight, strongly prefer best-fit
        elif avg_remaining < 50:
            _alpha_val = 0.3
        elif avg_remaining > 85:
            _alpha_val = 0.95  # lots of space, prefer flexibility
        elif avg_remaining > 70:
            _alpha_val = 0.7
        else:
            _alpha_val = 0.5

    # ---- Compute best-fit score ----
    tight_score = (100.0 - bins).astype(np.float64)
    
    # ---- Compute gap-penalty score based on historical data ----
    # For each bin, compute what gap would remain if item were placed there
    potential_gaps = bins - item
    gap_indices = np.array([_gap_index(g) for g in potential_gaps], dtype=np.int64)
    
    # Compute fill rate for each potential gap (how often gaps of that size get filled)
    total_created = _gap_created_count[gap_indices]
    total_filled = _gap_filled_count[gap_indices]
    
    # Fill rate: proportion of gaps of this size that were eventually filled
    # Small epsilon to avoid division by zero
    fill_rate = np.where(total_created > 0, total_filled / (total_created + 1e-9), 0.5)
    
    # Waste penalty: average waste associated with this gap size (normalized)
    # Waste is capacity that was never used in bins that ended with this gap
    avg_waste = np.where(total_created > 0, _gap_total_waste[gap_indices] / (total_created + 1e-9), 0.0)
    waste_penalty = avg_waste / 100.0  # normalize to 0-1 range
    
    # Gap desirability score: high if historically well-filled, low if wasteful
    # Scale to 0-100 range
    gap_score = fill_rate * 100.0 - waste_penalty * 50.0
    
    # ---- Compute flexibility score ----
    # Reward bins with capacity close to expected future item sizes
    target = _mean_item_size
    flex_distance = np.abs(bins - target)
    flex_score = 100.0 - flex_distance * 1.5
    flex_score = np.clip(flex_score, 0, 100)
    
    # Penalize bins that are nearly full (hard to use later)
    almost_full_penalty = np.where(bins < 10, 30, 0)
    flex_score -= almost_full_penalty
    
    # ---- Combine scores ----
    # Blend gap score with tight score
    combined_efficiency = 0.7 * tight_score + 0.3 * gap_score
    
    # Final blend with flexibility
    final_scores = _alpha_val * combined_efficiency + (1 - _alpha_val) * flex_score
    
    # Boost bins that exactly fit the item (perfect fit)
    exact_fit = (potential_gaps == 0)
    final_scores = np.where(exact_fit, 200.0, final_scores)
    
    # Cap and ensure non-negative
    final_scores = np.clip(final_scores, 0, 200)
    
    # ---- Store information about which bin was chosen ----
    # We'll update gap statistics in a separate tracking step
    # Store the potential gaps for all bins so we can update after choice
    priority._last_potential_gaps = potential_gaps.copy()
    priority._last_bins = bins.copy()
    priority._last_item = item
    
    return final_scores.astype(np.int64)


def _update_gap_statistics(chosen_bin_idx, item, bins, potential_gaps):
    """Update gap statistics after an item is placed. Called externally by harness hook."""
    global _gap_created_count, _gap_filled_count, _gap_total_waste
    global _bin_gaps, _current_bin_count
    
    chosen_gap = potential_gaps[chosen_bin_idx]
    chosen_gap_idx = _gap_index(chosen_gap)
    
    # Record that this gap was created
    _gap_created_count[chosen_gap_idx] += 1
    
    # Record the gap for this bin
    # If this is a new bin (was empty before), increment bin count
    if bins[chosen_bin_idx] == 100:
        _current_bin_count += 1
        bin_id = _current_bin_count - 1
    else:
        # Find bin ID - in practice we track by index
        # We need a way to identify bins; use a simple counter-based approach
        # Check if we've seen this remaining capacity before
        bin_id = chosen_bin_idx  # approximate, works for tracking
    
    # Store the gap for this bin
    old_gap = _bin_gaps.get(bin_id, None)
    if old_gap is not None:
        # This bin previously had a gap that is now being partially filled
        old_gap_idx = _gap_index(old_gap)
        _gap_filled_count[old_gap_idx] += 1
        # The waste avoided is the item size placed
        # (This is approximate - the gap wasn't fully "wasted" since we used part of it)
    
    # Update current gap
    _bin_gaps[bin_id] = chosen_gap
    
    # If this placement exactly fills the bin (gap = 0), record successful fill
    if chosen_gap == 0:
        _gap_filled_count[chosen_gap_idx] += 1


# The harness will call this function; we need to hook into the placement decision
# Since we can't modify the harness, we store state and provide a wrapper
# The priority function above will be called, and we need to update after placement.
# We'll use a post-placement tracking approach by checking in the next call.

# Track previous placement for delayed update
_prev_placement_done = False
_prev_chosen_idx = -1
_prev_potential_gaps = None
_prev_bins = None
_prev_item = None

# Monkey-patch: we'll detect placement by comparing bins from one call to next
# This is done in the priority function itself


# Override priority to include delayed update
_original_priority = priority

def priority(item, bins):
    global _prev_placement_done, _prev_chosen_idx, _prev_potential_gaps, _prev_bins, _prev_item
    
    # First, update statistics from previous placement if any
    if _prev_placement_done and _prev_potential_gaps is not None:
        _update_gap_statistics(_prev_chosen_idx, _prev_item, _prev_bins, _prev_potential_gaps)
        _prev_placement_done = False
    
    # Compute scores
    scores = _original_priority(item, bins)
    
    # The harness will place in the bin with highest score (first tie)
    # We need to predict which bin will be chosen
    # Find the index with maximum score (first occurrence)
    max_score = np.max(scores)
    chosen_idx = np.argmax(scores)  # returns first occurrence of max
    
    # Store for next call
    _prev_potential_gaps = priority._last_potential_gaps
    _prev_bins = bins
    _prev_item = item
    _prev_chosen_idx = chosen_idx
    _prev_placement_done = True
    
    return scores
