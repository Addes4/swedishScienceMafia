import numpy as np

# Global state: moving statistics of item sizes seen so far
state = {
    "count": 0,
    "mean": 40.0,  # reasonable initial guess for Weibull-like distribution
    "M2": 0.0,     # for running variance
    "buffer_item": None  # store one "upcoming" item for simulation (explained below)
}

# We cannot truly look ahead, so we simulate future items by sampling from our current
# estimate of the distribution. To keep it fast, we use a single "lookahead" item
# generated from recent statistics. This "dynamic lookahead simulation" places the
# current item into a candidate bin, then tries to place a sampled future item into
# the remaining bins. Priority is based on how well the remaining capacity can
# accommodate the future item.

def priority(item, bins):
    global state

    # Update running mean and variance of item sizes (Welford's online algorithm)
    state["count"] += 1
    count = state["count"]
    delta = item - state["mean"]
    state["mean"] += delta / count
    delta2 = item - state["mean"]
    state["M2"] += delta * delta2

    # If we have enough samples, generate a representative "future item" size
    # We simulate only one step ahead to keep O(n) complexity low.
    # The future item is sampled as mean + random noise scaled by variance.
    if count >= 10:
        var = state["M2"] / (count - 1) if count > 1 else 0.0
        std = max(np.sqrt(var), 1.0)  # avoid zero std
        # Use a simple triangular/beta-like shape: mean +/- uniform * std, clipped
        # to [1,100] and integer.
        noise = (np.random.random() - 0.5) * 2.0 * std  # roughly uniform [-std, std]
        future_size = int(np.clip(state["mean"] + noise, 1, 100))
    else:
        # not enough data: use a conservative default (e.g., mean of 40)
        future_size = 40

    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    # For each candidate bin, simulate putting the current item, then the future item
    # into the best-fitting bin among the remaining ones (including the current bin
    # after placement). Score = negative wasted space of future item placement,
    # plus a small bonus for tighter packing of current item.
    for i in range(n_bins):
        rem_after_current = bins[i] - item  # capacity if we put item here
        # Simulate future item placement:
        # We consider all bins after current placement (the bins array passed to us
        # is a copy, so we can safely modify a local copy).
        # But to avoid O(n^2), we only need the best fit for future_size among:
        #  - bin i with capacity rem_after_current
        #  - all other bins j != i with capacity bins[j]
        # The best fit is the bin with smallest capacity >= future_size.
        # We can compute this efficiently:
        best_fit_rem = 101  # impossible
        # check bin i
        if rem_after_current >= future_size and rem_after_current < best_fit_rem:
            best_fit_rem = rem_after_current
        # check others
        # Since bins is an array of remaining capacities, we can find min over bins[j]
        # where bins[j] >= future_size. We need to skip i if we already considered it.
        # We'll just compute over all bins including i: min over all valid bins.
        # But bin i's capacity after placement is rem_after_current, not bins[i].
        # So we need a combined view.
        # A straightforward O(n) scan is acceptable because we only do it once per bin,
        # leading to O(n^2) overall. For 5000 items this might be borderline but
        # we are within 30 sec. We can also vectorize partially.
        # Let's do a simple loop for clarity; but we can speed up by using numpy operations
        # on the other bins.
        # Actually we can compute best fit over all bins except i, then combine.

        # Get capacities of all other bins
        other_caps = bins.copy()
        other_caps[i] = 101  # ignore
        valid_others = other_caps[other_caps >= future_size]
        if valid_others.size > 0:
            min_other = valid_others.min()
            if min_other < best_fit_rem:
                best_fit_rem = min_other

        # Now best_fit_rem is the remaining capacity after placing future item into
        # the tightest possible bin. The waste is best_fit_rem - future_size.
        # Lower waste => higher score.
        if best_fit_rem <= 100:
            waste = best_fit_rem - future_size
            # score: negative waste (higher is better)
            # also add a very small bonus for using less capacity now (like best fit)
            # to break ties towards tight packing of current item.
            score = -waste + (item - bins[i]) * 1e-6  # small tie-break: prefer tighter now
        else:
            # Future item doesn't fit anywhere in existing bins -> it would open new bin.
            # This is worst case. We'll assign a low score.
            # The actual waste would be 100 - future_size (waste in a new bin).
            # But we want to avoid this state. So give a bigger penalty.
            score = -200.0  # worse than any possible waste of fitting (max waste 99)

        scores[i] = score

    return scores
