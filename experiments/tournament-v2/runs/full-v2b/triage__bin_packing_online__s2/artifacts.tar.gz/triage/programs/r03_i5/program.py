import numpy as np

# ----------------------------------------------------------------------
# Global adaptive state
# ----------------------------------------------------------------------
_has_state = False

if not _has_state:
    global _item_log, _pool_fill, _n_items, _exp_adapt
    _item_log = []          # list of observed item sizes (capped)
    _pool_fill = 0.0        # running mean fill fraction of open bins
    _n_items = 0            # number of items seen
    _exp_adapt = 1.0        # adaptive exponent for generalized mean
    _has_state = True

_MAX_LOG = 512
_TARGET = 40.0              # expected mean item size


def _generalized_mean_gap(gaps, p):
    """Generalized mean of the gaps.  Lower result = tighter bin.

    p -> -inf gives min (best-fit); p=1 gives arithmetic mean;
    p -> +inf gives max.  We use it as a soft best-fit selector.
    """
    gaps = np.asarray(gaps, dtype=np.float64)
    if gaps.size == 0:
        return gaps
    # clamp gaps to avoid zero/negative
    gaps = np.clip(gaps, 1e-6, None)
    abs_p = abs(p)
    if abs_p < 1e-6:
        return np.exp(np.mean(np.log(gaps)))
    return np.power(np.mean(np.power(gaps, p)), 1.0 / p)


def priority(item, bins):
    global _item_log, _pool_fill, _n_items, _exp_adapt

    bins = np.asarray(bins)
    n = bins.size
    if n == 0:
        return bins.astype(np.float64)

    # --------------------------------------------------------------
    # Online statistics of item sizes
    # --------------------------------------------------------------
    _n_items += 1
    if len(_item_log) < _MAX_LOG:
        _item_log.append(item)
    else:
        # reservoir-ish: overwrite an index based on the count
        idx = _n_items % _MAX_LOG
        _item_log[idx] = item

    arr = np.asarray(_item_log, dtype=np.float64)
    mean_item = float(arr.mean()) if arr.size else _TARGET
    # quantiles of observed sizes
    if arr.size >= 8:
        q25 = float(np.quantile(arr, 0.25))
        q50 = float(np.quantile(arr, 0.50))
        q75 = float(np.quantile(arr, 0.75))
    else:
        q25 = q50 = q75 = mean_item

    # --------------------------------------------------------------
    # Gaps: remaining capacity after placing item, per bin
    # --------------------------------------------------------------
    rem_after = bins - item          # remaining capacity if placed here
    rem_after = np.clip(rem_after, 0, 100).astype(np.float64)

    # free space of the bin (for fill fraction)
    fill_frac = 1.0 - bins.astype(np.float64) / 100.0
    _pool_fill = 0.9 * _pool_fill + 0.1 * float(fill_frac.mean())

    # --------------------------------------------------------------
    # Adaptive exponent from running statistics
    #   - large items (item big relative to observed quantiles) -> favor
    #     small gaps strongly (negative p, near best-fit)
    #   - small items -> balanced packing (p near 0 / log / harmonic)
    # --------------------------------------------------------------
    # relative size of current item vs distribution
    if arr.size >= 8:
        size_rank = (item - q25) / max(1.0, (q75 - q25))
    else:
        size_rank = (item - mean_item) / max(1.0, mean_item)

    size_rank = float(np.clip(size_rank, -1.0, 2.0))

    # base exponent: strong best-fit pressure for big items
    exp_raw = -3.0 * size_rank + 0.5
    # more steals toward best-fit when the pool is already packed
    exp_raw += 1.5 * (_pool_fill - 0.5)
    # clamp and smooth
    exp_raw = float(np.clip(exp_raw, -6.0, 2.0))
    _exp_adapt = 0.85 * _exp_adapt + 0.15 * exp_raw
    p = _exp_adapt

    # --------------------------------------------------------------
    # Score: negative generalized mean of the post-placement gaps
    #   smaller gap -> higher score
    # --------------------------------------------------------------
    # sensitivity scale: use quantile spread to normalize gaps
    spread = max(1.0, (q75 - q25))
    g_scaled = rem_after / spread

    gm = _generalized_mean_gap(g_scaled, p)

    # We want high score for small gm.  Combine absolute tightness with
    # the generalized-mean signal.
    score = 1000.0 - 100.0 * gm

    # Extra flexibility term: avoid leaving bins that exactly fit future
    # mid-size items when we just made a small packing.
    # Softly encourage leaving a bit of comfortable room for large items.
    comfort = -(np.abs(rem_after - q50) / max(1.0, mean_item))
    score = score + 3.0 * comfort

    # Prefer first bins on near-ties deterministically by tiny index decay
    idx_decay = np.arange(n, dtype=np.float64) * 1e-6
    score = score - idx_decay

    return score.astype(np.float64)
