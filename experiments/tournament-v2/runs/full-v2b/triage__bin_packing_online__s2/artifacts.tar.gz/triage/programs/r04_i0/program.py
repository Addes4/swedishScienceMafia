import numpy as np

_global_item_hist = np.zeros(100, dtype=np.float64)
_global_count = 0
_global_mean = 40.0

def update_global(item):
    """Update empirical item distribution. Accessed internally and via global."""
    global _global_item_hist, _global_count, _global_mean
    _global_item_hist[1:101] = _global_item_hist[1:101] + _global_item_hist[0:100]*0.99 + 1
    _global_item_hist[0:100] = _global_item_hist[0:100] * 0.99
    _global_item_hist[100] = 0
    _global_count += 1
    if _global_count <= 10:
        _global_mean = 40.0
    elif _global_count <= 100:
        _global_mean = 45.0
    else:
        _global_mean = 40.0 + 5.0 * (1.0 / (1.0 + _global_count / 500))

def priority(item, bins):
    global _global_item_hist, _global_count, _global_mean
    
    if _global_count < 50:
        _global_mean = 40.0
    
    item_hist = _global_item_hist.copy()
    item_hist = item_hist[:100]
    ecdf = np.cumsum(item_hist)
    ecdf_max = ecdf.sum()
    ecdf = ecdf / ecdf_max if ecdf_max > 0 else np.ones(100, dtype=np.float64) / 100

    target_bins = bins.copy()
    n_bins = len(bins)

    if n_bins == 0:
        return np.zeros(0, dtype=np.float32)

    tolerance = 4
    gap_fill_prob = np.zeros(n_bins, dtype=np.float64)
    for i in range(n_bins):
        rem = bins[i]
        if rem > 100:
            continue
        fillable_mask = (rem - tolerance <= 99) & (item_hist > 0)
        p_density = np.maximum(0,
            np.max(item_hist[max(rem - tolerance, 1):min(rem + tolerance, 100)]) / 100)
        prob_fit = ecdf[max(rem - tolerance, 1):min(rem + 1, 100)].sum() / 99 if ecdf[rem - tolerance:rem + 1].sum() > 0 else 1
        gap_fill_prob[i] = 0.7 * p_density + 0.3 * prob_fit

    tight_score = 100 - target_bins
    last_gap = 100 - bins
    gap_fill_prob_norm = gap_fill_prob / (gap_fill_prob.max() + 1e-9)

    target_fit = 40.0
    if _global_count > 500:
        target_fit = 40.0
    elif _global_count > 100:
        target_fit = 45.0
    else:
        target_fit = 40.0

    flex_score = np.abs(last_gap - target_fit)
    flex_score_raw = 100.0 - flex_score

    alpha = 0.5
    if gap_fill_prob_mean_ok := gap_fill_prob_norm.mean() > 0.7 if n_bins > 10 else None:
        alpha = 0.35
    else:
        alpha = 0.55

    weighted_score = alpha * tight_score + (1 - alpha) * (gap_fill_prob_norm * 80 + flex_score_raw)
    return np.array(weighted_score, dtype=np.int32)
