# EVOLVE-BLOCK-START
"""Adaptive bilinear priority: reward high utilization while penalizing tiny gaps."""
import numpy as np


_PRIORITY_HISTORY = []


def priority(item, bins):
    """Score bins for which item should go, balancing utilization and gap avoidance.
    
    Uses: score = utilization * (1 - exp(-gap / threshold))
    where threshold adapts to the median item size seen so far.
    """
    global _priority_history
    
    # Track item sizes for adaptive threshold
    _priority_history.append(float(item))
    history = _priority_history[-1000:]  # Recent history window
    threshold = np.median(history) if len(history) > 0 else 40.0
    threshold = np.clip(threshold, 1.0, 60.0)
    
    n_bins = len(bins)
    scores = np.full(n_bins, -1e9, dtype=np.float64)
    
    # Only bins that fit the item (problem guarantees bins >= item)
    valid_mask = bins >= item
    
    if valid_mask.any():
        utilization = item / bins[valid_mask]
        gap = bins[valid_mask] - item
        
        # Bilinear score: high utilization + lower penalty for small gaps
        valid_scores = utilization * (1 - np.exp(-gap / threshold))
        scores[valid_mask] = valid_scores
    
    return scores
# EVOLVE-BLOCK-END
