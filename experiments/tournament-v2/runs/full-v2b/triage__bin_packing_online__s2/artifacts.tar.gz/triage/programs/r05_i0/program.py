import numpy as np

# Track item sizes to learn the distribution over time
_item_history = []
_slot_size = 40  # Default slot size (typical item size in distribution)

def priority(item, bins):
    """
    Decompose bins into capacity slots based on moving item size quantile.
    Score bins by how many slot-sized units they can accommodate.
    Bins with more slots (higher remaining_capacity / slot_size) get higher scores.
    This naturally creates modular capacity packing.
    """
    global _slot_size, _item_history
    
    # Update history for learning the item size distribution
    if len(_item_history) < 50:
        _item_history.append(item)
    
    # Update slot size based on moving median of recent items
    if len(_item_history) >= 10:
        recent_items = _item_history[-10:]
        slot_size = int(round(np.median(recent_items)))
        # Clamp slot size to valid range [1, 100]
        slot_size = max(1, min(100, slot_size))
    elif slot_size == 40:
        # Keep default if not much history yet
        slot_size = max(1, min(100, 40))
    
    _slot_size = slot_size
    
    # Score bins by remaining capacity scaled to slot size
    # Bins that can fit more items get higher scores
    # This creates modular packing around the typical item size
    scores = np.ceil(bins / float(_slot_size)).astype(np.int64)
    
    return scores
