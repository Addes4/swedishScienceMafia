import numpy as np

# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------
_state = {}

def _init():
    _state['t'] = 0                 # number of items processed
    _state['bins_used'] = 0         # count of non-pristine opens we've observed
    _state['waste'] = 0.0           # accumulated waste (leftover after placements)
    _state['placement_sum'] = 0.0   # sum of remaining capacity after placement
    _state['placement_count'] = 0
    _state['recent_waste'] = []     # rolling window of waste per call
    _state['temp'] = 1.0            # current temperature
    _state['rng'] = np.random.RandomState(12345)

if 'inited' not in _state:
    _init()
    _state['inited'] = True


def priority(item, bins):
    """Softmax exploration over bins with decaying temperature.

    Early: high temperature -> diverse placements, learn bin capacity layout.
    Late: low temperature -> sharp best-fit selection.
    """
    n = len(bins)
    t = _state['t']
    _state['t'] = t + 1

    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # ------------------------------------------------------------------
    # Base score: best-fit quality. Prefer bins that leave the least waste
    # after placing the item, but weight a bit by how much room remains for
    # future items (a flexibility term).
    # ------------------------------------------------------------------
    remaining_after = bins - item           # leftover if item placed here
    # Tighter fit is principal; normalize into a reasonable range.
    tight_score = (100.0 - remaining_after)   # = item + used capacity

    # Flexibility: mild preference for bins with moderate remaining capacity
    # so slightly larger items still find a home later. Target around mean.
    target = 40.0
    flex = -np.abs(bins - target)

    # Composite raw score
    raw = tight_score * 1.0 + flex * 0.15

    # ------------------------------------------------------------------
    # Adaptive temperature from running waste statistics.
    # If recent placements have been wasteful (high leftover), explore more;
    # if we are packing tightly, sharpen.
    # ------------------------------------------------------------------
    rw = _state['recent_waste']
    if len(rw) >= 50:
        avg_waste = sum(rw) / len(rw)
    else:
        avg_waste = 0.0

    # Progress within the instance (5000 items typical); guard against unknown.
    progress = min(1.0, t / 5000.0)

    # Base temperature schedule: start warm, cool down.  Clamp floor so we
    # never entirely freeze (keeps tie-breaking stochastic-ish but mild).
    base_temp = 8.0 * (1.0 - progress) + 0.15

    # Waste modulation: higher waste -> raise temperature a bit.
    waste_factor = 1.0 + (avg_waste / 30.0)
    waste_factor = float(np.clip(waste_factor, 0.5, 3.0))

    temp = base_temp * waste_factor
    temp = float(np.clip(temp, 0.05, 12.0))
    _state['temp'] = temp

    # ------------------------------------------------------------------
    # Softmax over raw scores with temperature.
    # Use max-subtraction for numerical stability.
    # ------------------------------------------------------------------
    scaled = raw / temp
    scaled -= scaled.max()
    exp_s = np.exp(scaled)
    probs = exp_s / exp_s.sum()

    # ------------------------------------------------------------------
    # The harness picks the highest score.  To realize sampling without
    # returning random garbage, we draw an index from the softmax and give
    # it a large score; everything else gets its probability as a tiny
    # secondary score so that if the chosen one is unavailable (shouldn't
    # happen) the fallback ranking is still sensible.
    # Actually harness always takes a valid bin - so we just push the
    # sampled bin to the top.
    # ------------------------------------------------------------------
    # Use a deterministic-ish low variance: sample only while temperature is
    # meaningfully high; otherwise go greedy.
    if temp > 0.4 and n > 1:
        r = _state['rng'].rand()
        c = np.cumsum(probs)
        idx = int(np.searchsorted(c, r))
        if idx >= n:
            idx = n - 1
    else:
        idx = int(np.argmax(probs))

    scores = probs.astype(np.float64) * 1e-3
    scores[idx] = 1.0

    # ------------------------------------------------------------------
    # Update waste statistics for the actual placement the harness will make.
    # The harness places into bins[idx] (or first max).  We can approximate
    # using the bin we selected.
    # ------------------------------------------------------------------
    leftover = bins[idx] - item
    _state['placement_sum'] += leftover
    _state['placement_count'] += 1
    rw.append(int(leftover))
    if len(rw) > 500:
        del rw[:len(rw) - 500]

    _state['bins_used'] = max(_state['bins_used'], int((bins < 100).sum()))

    return scores
