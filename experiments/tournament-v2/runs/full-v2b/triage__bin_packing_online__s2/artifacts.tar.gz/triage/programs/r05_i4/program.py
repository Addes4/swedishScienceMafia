import numpy as np

# Global state: track empirical distribution of item sizes
if not hasattr(priority, '_initialized'):
    priority._initialized = True
    priority._item_sizes = []  # store all seen items for distribution estimation
    priority._total_items = 0
    priority._sum_items = 0
    priority._sum_sq_items = 0

def priority(item, bins):
    """Score bins by competitive ratio: evaluate worst-case and best-case futures
    after placing the item, and return minimax scores.
    
    item: integer size of arriving item
    bins: numpy int64 array of remaining capacities of eligible bins
    """
    # Update global statistics
    priority._item_sizes.append(item)
    priority._total_items += 1
    priority._sum_items += item
    priority._sum_sq_items += item * item
    
    if len(bins) == 0:
        return np.array([], dtype=np.int64)
    
    # Estimate distribution parameters from seen items
    n = priority._total_items
    mean_item = priority._sum_items / n
    var_item = max(0, priority._sum_sq_items / n - mean_item * mean_item)
    std_item = np.sqrt(var_item)
    
    # After placing item, remaining capacity in each bin
    remaining = bins - item
    
    # Model two futures:
    # 1. Adversarial worst case: smallest possible items (size 1) fill remaining
    #    Number of items that can fit = remaining / 1 = remaining
    #    Utilization = (capacity_used + future_used) / capacity
    #    After placing item: used = 100 - remaining
    #    Worst-case: all space filled with size-1 items -> perfect utilization = 1.0
    #    But competitive ratio considers wasted space: worst-case waste
    #    Actually, worst-case future: many items of size = remaining (just one fits perfectly)
    #    This wastes nothing, so competitive ratio = 1 for that bin
    #    Better: worst-case wastes as much as possible given item distribution
    
    # 2. Favorable case: large items arrive that fit perfectly
    #    Number of large items fitting = 1 if remaining >= mean_item
    
    # Competitive ratio approach:
    # For each bin, simulate:
    #   - Worst-case adversary: gives items that maximize waste given remaining capacity
    #     This is items just larger than remaining/2, etc. But simpler:
    #     Adversary gives items of size = max(1, min(remaining, mean_item + 2*std_item))
    #     such that each only fits one, leaving waste.
    #   - Favorable: gives perfectly fitting items (size = remaining if large, else mean_item)
    
    # Simplified minimax: score by how well bin handles both small and large futures
    # High score = good competitive ratio (low waste in worst case, high utilization in best case)
    
    # Worst-case future: adversary sends items of size = remaining + 1? No, they must fit
    # Adversary sends items just fitting: size = remaining, waste = 0
    # Or sends many small items: waste = remaining mod small_size
    # We model adversarial as: sends items of size just above remaining/2 (creates waste ~remaining/2)
    # Better model: adversary knows our bin capacity and sends worst sequence
    
    # Let's implement a clean minimax scoring:
    # Worst case: after placing this item, remaining can be filled with items that
    # maximize wasted space = remaining % item_size, where item_size is chosen adversarially
    # from a realistic range (1 to 100). The adversary picks size that maximizes waste.
    # waste_worst = max_{s in [1,100]} (remaining % s)
    waste_worst = np.zeros_like(remaining, dtype=np.float64)
    # But computing for each bin individually is O(n_bins * 100), which is okay for 5000 items
    # actually 5000 * 100 = 500k operations per call, 5000 calls = 2.5B, too slow
    # Precompute worst-case waste for all possible remainders
    if not hasattr(priority, '_waste_cache'):
        cache = np.zeros(101, dtype=np.int64)
        for rem in range(1, 101):
            max_waste = 0
            for s in range(1, 101):
                waste = rem % s
                if waste > max_waste:
                    max_waste = waste
            cache[rem] = max_waste
        priority._waste_cache = cache
    
    # Use cache: waste_worst[remaining < 0]? remaining is >=0 since bins have capacity >= item
    rem_int = remaining.astype(np.int64)
    rem_int = np.clip(rem_int, 0, 100)
    worst_waste = priority._waste_cache[rem_int]
    
    # Best case: favorable items arrive that fit well
    # If remaining is large (>= mean_item), can fit another mean_item + something
    # Best-case waste: we can fill it perfectly with some combination? Optimistic: waste=0
    best_waste = np.zeros_like(remaining, dtype=np.float64)
    
    # Instead of pure waste, consider utilization ratio: worst = (100 - worst_waste)/100, best = 1.0
    worst_util = (100 - worst_waste) / 100.0
    best_util = 1.0
    
    # Competitive ratio: best_possible / achieved_in_worst_case
    # We want to maximize the worst-case utilization, so score = worst_util
    # But also incorporate best-case to break ties: prefer bins where best future is also good
    
    # Minimax: score = worst_util - penalty for difference between best and worst
    # Actually, minimax: we want to minimize the maximum regret = max_future (optimal - achieved)
    # optimal = 1.0 (perfect packing), achieved_worst = worst_util
    # So regret_worst = 1.0 - worst_util
    # Regret_best = 1.0 - best_util = 0
    # Minimax regret = max(regret_worst, regret_best) = regret_worst
    # So we just care about maximizing worst_util
    # But this ignores that some bins might be better for favorable futures
    
    # Better: evaluate score as fraction of capacity that can be "saved" for large items
    # while still handling small items well.
    # We want bins that can accommodate both small and large future items.
    # Score = worst_util * (0.5 + 0.5 * (remaining / 100)) = balance
    
    # Or: use competitive ratio from online algorithms literature:
    # Bin that minimizes the maximum ratio of optimal packing to online packing
    # For each bin, consider two extreme futures:
    # F1: all future items are size 1 (small)
    # F2: all future items are size = min(remaining, 100) (large, just fit)
    # Waste in F1 = remaining % 1 = 0 -> util = 1.0
    # Waste in F2 = 0 -> util = 1.0
    # That's not distinguishing.
    
    # Better adversary: items drawn from empirical distribution
    # We can simulate many random futures and measure expected waste
    # But need to be efficient.
    
    # Instead: score bins by a weighted combination of:
    # - How well they pack the current item (tightness)
    # - How much remaining capacity they have for future items
    # but adjust based on adversarial vs favorable distribution.
    
    # Idea: Use the empirical distribution to estimate the probability
    # that the remaining capacity can be perfectly filled in the future.
    # Higher probability = better bin.
    # We can approximate by: probability that sum of k future items exactly equals remaining.
    # Hard to compute.
    
    # Let's implement a robust scoring:
    # 1. Worst-case: adversary picks item sizes to maximize waste
    #    This is already worst_waste computed above.
    # 2. Best-case: favorable draws that match remaining capacity
    #    Score = (remaining % mean_item == 0) bonus
    
    # Mix them:
    tightness = 100 - bins  # how full is the bin already? Higher = fuller
    worst_score = 100 - worst_waste  # higher is better
    best_bonus = np.where(remaining % max(1, int(mean_item)) == 0, 20, 0)
    
    # Also consider expected utilization: we want bins where remaining matches
    # typical item sizes well.
    # Expected waste = average waste if future items come from empirical distribution
    # Approximate: if remaining >= mean_item, can fit another typical item, waste = remaining - mean_item
    # else waste = remaining (can't fit a typical item)
    expected_waste = np.where(remaining >= mean_item, remaining - mean_item, remaining)
    expected_score = 100 - expected_waste
    
    # Final score: combine worst-case performance with expected performance
    # Weighted toward worst-case for minimax robustness
    score = 0.7 * worst_score + 0.3 * expected_score + best_bonus
    
    # Prefer bins that are neither too empty nor too full (balance)
    # Add bonus for bins with remaining close to optimal reserve
    optimal_reserve = mean_item * 1.5  # can fit 1-2 future items
    balance = 100 - np.abs(remaining - optimal_reserve)
    score += 0.1 * balance
    
    return score.astype(np.int64)
