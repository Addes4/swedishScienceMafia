# Research notebook: bin_packing_online

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.961642.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Maintain per-bin age or fill rate count as state, and adapt priorities to favor bins that have been open longer or have higher current fill percentage, effectiv | 0.27 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.959312 |
| 5 | Treat the problem as an approximate knapsack-online: compute a score `-(bins - item) + α * (bins - item) / bins` where `α` is tuned, making the algorithm lean t | 0.25 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961642 |
| 2 | Implement a balanced worst-fit variant: compute a score that penalizes both very tight fits and very loose fits, using a quadratic penalty `-(bin - item - optim | 0.23 | middle | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.901662 |
| 0 | Use a threshold-based heuristic: if the remaining capacity after placing would be below a learned cutoff (e.g., 20), assign a slight bonus to that bin to minimi | 0.22 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 1 | Keep an exponential moving average of item sizes and preemptively reserve capacity in a bin for expected future items: assign higher priority to bins whose rema | 0.19 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.940646 |
| 3 | Add a small random jitter to the scores that scales inversely with remaining bin capacity after placement, so that among nearly equivalent tight fits the algori | 0.17 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.960010 |

Best after round 1: **0.961642** (spent $0.01)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Model the bin-choice problem as a bandit: maintain for each bin-fill-level (current remaining capacity percentile) an estimate of the value of placing an item t | 0.10 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.406443 |
| 1 | Implement a dynamic lookahead simulation: for each candidate bin, simulate placing the item, then greedily pack a small buffer of upcoming items (using a learne | 0.09 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 4 | Cluster items by size using online k-means on the fly, and maintain per-bin "dedication" to a cluster: prioritize placing items into bins already containing ite | 0.07 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 0 | Use a smoothed "sum of gaps" heuristic: maintain a running estimate of the distribution of item sizes, and score bins by the expected number of future items tha | 0.02 | middle | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.735476 |
| 2 | Use a bilinear score combining total bin utilization and a penalty for creating small gaps: score = utilization * (1 - exp(-gap / threshold)), where threshold a | -0.05 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 5 | Transform the problem into a dual-priority system: compute both best-fit and a measure of "future flexibility" (e.g., remaining capacity variance after placemen | -0.08 | long_shot | Qwen/Qwen3.5-9B:together | improved | 0.961642 |

Promotion: Qwen/Qwen3.5-9B:together found an improvement; deepseek-ai/DeepSeek-V4-Pro:deepinfra refined it -> invalid (0.000000).

Best after round 2: **0.961642** (spent $0.03)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Replace the hand-tuned mixing logic with a lightweight online regression that maps bin and item features to priority scores, trained incrementally via stochasti | 0.12 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.959312 |
| 3 | Maintain a compact histogram of leftover gaps from previous placements and explicitly penalize bins that would create gap sizes that historically led to wasted  | 0.07 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.960942 |
| 4 | Use a differentiable ranking loss to treat bin choice as a learning-to-rank problem: at each step, compute a gradient-based update to a small neural network sco | 0.05 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961408 |
| 5 | Keep a pool of open bins sorted by their current fill percentage and implement a priority function based on a generalized mean of the gaps, where the exponent i | 0.05 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.720713 |
| 1 | Model each bin’s remaining capacity as a state in a small Markov decision process and apply online value iteration to compute a score that estimates the expecte | 0.01 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.396100 |
| 2 | Introduce a virtual “phantom bin” for each candidate: after placing the item, further pack it greedily with a forecast of the next few items (sampled from a run | -0.00 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 3: **0.961642** (spent $0.05)

## Round 4

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Replace the convex blend with a decision-tree split on remaining capacity percentiles and item size: learn thresholds that map (item, bin_state) directly to a l | 0.14 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 5 | Treat the bin’s remaining capacity as a resource and apply a reserve price: compute the shadow price of capacity from a fast online dual-update rule for the fra | 0.07 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.708588 |
| 1 | Adopt a “harmonic best-fit” score that divides tightness by the square root of the bin’s current fill count, so that among equally tight bins, the one already h | 0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 2 | Compute a Wasserstein-like distance between the empirical distribution of items placed in a bin and the overall item distribution seen so far; prioritize bins w | 0.01 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 0 | Use the empirical cumulative distribution of item sizes to derive the probability that the remaining gap after placement will be exactly fillable by future item | -0.01 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 3 | Frame each placement as a bipartite matching in hindsight: maintain a sliding window of recent bins and arrivals, periodically re-solve a minimum-cost assignmen | -0.01 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 4: **0.961642** (spent $0.07)

## Round 5

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Implement an online variant of the “sum of squares” bin packing heuristic: score a bin by the squared fill level after placing the item, so that the algorithm i | 0.07 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961642 |
| 4 | Frame scoring as a competitive ratio minimization: simulate two hypothetical futures (adversarial worst-case small items vs. favorable large items) for each bin | 0.05 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 2 | Use a softmax-based exploration over bins with a temperature that decays with the instance progress: early on favor diverse placements (high temperature) to lea | 0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.952851 |
| 5 | Convert the item stream into a small set of canonical “item types” via online clustering of sizes, then maintain per-type dual variables via a fast online subgr | 0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.396100 |
| 0 | Decompose bins into capacity “slots” of size equal to a moving quantile of item sizes, and score bins by how many more full slots they can accommodate minus the | 0.01 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 3 | Maintain a suffix tree or Markov chain of recent item sequences and, for each candidate bin, compute the likelihood that the residual capacity after placement c | -0.09 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 5: **0.961642** (spent $0.09)

## Round 6

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 5 | Compute a score based on the expected number of items that can still fit into the bin by integrating the empirical survival function of item sizes over the rema | 0.18 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 3 | Use an online exponent update: maintain a small set of base heuristics (best-fit, worst-fit, gap-aware) as experts and a weight vector updated via multiplicativ | 0.12 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | improved | 0.961875 |
| 0 | Replace the static target in the flexibility score with a dynamic target equal to a running percentile (e.g., median) of past item sizes, and blend this adaptiv | 0.11 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 2 | Maintain a histogram of unused gap sizes and compute, for each candidate bin after placement, the historical fill rate of that exact remaining capacity; score b | 0.02 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.802327 |
| 4 | Partition the item size range into a few static intervals and maintain a running count of items placed into each interval per bin; prioritize bins where placing | 0.02 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.396100 |
| 1 | Treat each bin's remaining capacity as a state and apply a simple online Monte Carlo policy improvement: for each candidate bin, sample a trajectory of future i | -0.04 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 6: **0.961875** (spent $0.11)

## Round 7

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Replace the expert mixture with a single learned scoring function: use a lightweight online linear regression (e.g., a single-layer perceptron with sigmoid outp | 0.13 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961642 |
| 2 | Treat bin selection as a contextual bandit where each (item_size, bin_capacity) pair is a context; use a UCB-style scoring that adds an exploration bonus propor | 0.10 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | api_error |  |
| 5 | Use a gradient-boosted decision tree (online XGBoost-style) that updates incrementally after each instance: store all past (item, chosen_bin, remaining_capacity | 0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | api_error |  |
| 3 | Maintain a global histogram of successfully "closed" bins (bins that reached 0 remaining capacity) and their fill sequences; score bins by the similarity of the | -0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | api_error |  |
| 4 | Implement a fuzzy matching with virtual item types: discretize item sizes into weighted fuzzy types (e.g., small/medium/large with soft memberships), maintain p | -0.04 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 1 | Introduce a "reservation score" that models the opportunity cost of using remaining capacity now: maintain a running estimate of the probability density of futu | -0.10 | long_shot | Qwen/Qwen3.5-9B:together | api_error |  |

Best after round 7: **0.961875** (spent $0.13)

