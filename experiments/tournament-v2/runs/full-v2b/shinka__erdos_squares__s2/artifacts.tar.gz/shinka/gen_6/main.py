# EVOLVE-BLOCK-START
"""Layered optimizer for packing squares in the unit square.

Architecture:
  - Feasibility utilities: SAT-style overlap test for rotated squares.
  - Candidate generators: grid, guillotine, greedy, rotated-grid.
  - Local search: size/position/angle perturbation with feasibility repair.
  - Orchestrator: time-budgeted portfolio that returns the best packing.
"""
import math
import random
import time


# ---------- geometry ----------

def _corners(cx, cy, ang, s):
    """Return 4 corners of a square centered at (cx,cy), side s, angle ang (turns)."""
    h = s * 0.5
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap_axes(pts1, pts2):
    """Separating Axis Theorem overlap test for two convex polygons."""
    for poly in (pts1, pts2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ax, ay = -(y2 - y1), (x2 - x1)
            n = math.hypot(ax, ay)
            if n == 0:
                continue
            ax, ay = ax / n, ay / n
            p1 = [x * ax + y * ay for x, y in pts1]
            p2 = [x * ax + y * ay for x, y in pts2]
            if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
                return False
    return True


def _inside_unit(pts):
    for x, y in pts:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(sol):
    """Check all squares inside unit and pairwise disjoint interiors."""
    polys = []
    for cx, cy, ang, s in sol:
        if s <= 0:
            polys.append(None)
            continue
        p = _corners(cx, cy, ang, s)
        if not _inside_unit(p):
            return False
        polys.append(p)
    n = len(polys)
    for i in range(n):
        if polys[i] is None:
            continue
        for j in range(i + 1, n):
            if polys[j] is None:
                continue
            if _overlap_axes(polys[i], polys[j]):
                return False
    return True


def _score(sol):
    return sum(max(0.0, s) for _, _, _, s in sol)


def _overlap_area(pts1, pts2):
    """Approximate overlap area using bounding boxes."""
    x1_min = min(p[0] for p in pts1)
    x1_max = max(p[0] for p in pts1)
    y1_min = min(p[1] for p in pts1)
    y1_max = max(p[1] for p in pts1)
    x2_min = min(p[0] for p in pts2)
    x2_max = max(p[0] for p in pts2)
    y2_min = min(p[1] for p in pts2)
    y2_max = max(p[1] for p in pts2)
    w = max(0, min(x1_max, x2_max) - max(x1_min, x2_min))
    h = max(0, min(y1_max, y2_max) - max(y1_min, y2_min))
    return w * h


def _repair(sol, rng, max_iter=60):
    """Attempt to repair an infeasible solution by shrinking/moving overlaps."""
    sol = [list(t) for t in sol]
    n = len(sol)
    for _ in range(max_iter):
        overlaps = []
        for i in range(n):
            if sol[i][3] <= 0:
                continue
            pi = _corners(*sol[i])
            for j in range(i + 1, n):
                if sol[j][3] <= 0:
                    continue
                pj = _corners(*sol[j])
                if _overlap_axes(pi, pj):
                    overlaps.append((_overlap_area(pi, pj), i, j))
        if not overlaps:
            ok = True
            for i in range(n):
                if sol[i][3] > 0 and not _inside_unit(_corners(*sol[i])):
                    sol[i][3] *= 0.95
                    ok = False
            if ok:
                return [tuple(s) for s in sol]
            continue
        overlaps.sort(reverse=True)
        _, i, j = overlaps[0]
        if sol[i][3] >= sol[j][3]:
            sol[i][3] *= rng.uniform(0.85, 0.95)
        else:
            sol[j][3] *= rng.uniform(0.85, 0.95)
        idx = i if rng.random() < 0.5 else j
        sol[idx][0] = min(1.0, max(0.0, sol[idx][0] + rng.uniform(-0.02, 0.02)))
        sol[idx][1] = min(1.0, max(0.0, sol[idx][1] + rng.uniform(-0.02, 0.02)))
    return [tuple(s) for s in sol]


# ---------- generators ----------

def _grid(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
           for i in range(k) for j in range(k)]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]


def _guillotine(n, rng):
    """Recursively split the unit square into n cells, then fill each with a square."""
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        # pick the largest cell
        cells.sort(key=lambda c: -(c[2] * c[3]))
        idx = 0
        x, y, w, h = cells.pop(idx)
        if w >= h:
            t = rng.uniform(0.35, 0.65)
            cells.append((x, y, w * t, h))
            cells.append((x + w * t, y, w * (1 - t), h))
        else:
            t = rng.uniform(0.35, 0.65)
            cells.append((x, y, w, h * t))
            cells.append((x, y + h * t, w, h * (1 - t)))
    out = []
    for (x, y, w, h) in cells:
        s = min(w, h)
        out.append((x + w * 0.5, y + h * 0.5, 0.0, s))
    return out


def _greedy(n, rng):
    """Greedy: place squares one by one in largest available gap, axis-aligned."""
    # start with a coarse grid of candidate positions
    sol = []
    for _ in range(n):
        best = None
        best_s = -1.0
        for _try in range(40):
            cx = rng.uniform(0.0, 1.0)
            cy = rng.uniform(0.0, 1.0)
            # binary-search largest s that fits
            lo, hi = 0.0, 1.0
            for _ in range(20):
                mid = 0.5 * (lo + hi)
                cand = sol + [(cx, cy, 0.0, mid)]
                if _feasible(cand):
                    lo = mid
                else:
                    hi = mid
            if lo > best_s:
                best_s = lo
                best = (cx, cy, 0.0, lo)
        if best is None or best[3] <= 0:
            sol.append((0.5, 0.5, 0.0, 0.0))
        else:
            sol.append(best)
    return sol


def _rotated_grid(n, rng):
    """Grid but with some squares rotated to allow tighter packing variants."""
    base = _grid(n)
    out = []
    for cx, cy, _, s in base:
        ang = rng.choice([0.0, 0.0, 0.0, 0.125, 0.25])
        out.append((cx, cy, ang, s))
    return out


def _rows_layout(n, sizes):
    """Build a layout by stacking rows of squares with given sizes."""
    out = []
    y = 1.0
    for row in sizes:
        row_h = max(row) if row else 0.0
        if row_h <= 0:
            continue
        y -= row_h
        x = 0.0
        for s in row:
            out.append((x + s * 0.5, y + row_h * 0.5, 0.0, s))
            x += s
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seeded_layouts(n):
    """Deterministic candidate layouts known to be good for small n."""
    cands = []
    for r in range(1, n + 1):
        k = n // r
        rem = n - k * r
        if k == 0:
            continue
        sizes = [[1.0 / k] * k for _ in range(r)]
        if rem:
            sizes[-1] = [1.0 / (k + rem)] * (k + rem)
        cands.append(_rows_layout(n, sizes))
    if n == 5:
        cands.append([
            (0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
            (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5),
            (0.5, 0.5, 0.0, 0.0),
        ])
    if n == 6:
        cands.append(_rows_layout(6, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
        cands.append(_rows_layout(6, [[1/3, 1/3, 1/3], [1/3, 1/3, 1/3]]))
    if n == 7:
        cands.append(_rows_layout(7, [[0.5, 0.5], [1/3, 1/3, 1/3]]))
    if n in (8, 11, 12, 13, 14, 15):
        cands.append(_rows_layout(n, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [1/3, 1/3, 1/3]]))
    return cands


def _polish(sol, deadline):
    """Deterministic coordinate descent: grow/slide/rotate each square."""
    cur = [list(t) for t in sol]
    n = len(cur)
    step_grow = 0.01
    step_move = 0.01
    improve = True
    while improve and time.time() < deadline:
        improve = False
        for i in range(n):
            for _ in range(3):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][3] += step_grow
                if _feasible(trial):
                    cur = trial
                    improve = True
                else:
                    break
        for i in range(n):
            if cur[i][3] <= 0:
                continue
            for dx, dy in ((step_move, 0), (-step_move, 0),
                           (0, step_move), (0, -step_move)):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][0] = min(1.0, max(0.0, trial[i][0] + dx))
                trial[i][1] = min(1.0, max(0.0, trial[i][1] + dy))
                if _feasible(trial):
                    cur = trial
                    improve = True
        for i in range(n):
            if cur[i][3] <= 0:
                continue
            for da in (0.02, -0.02):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][2] = (trial[i][2] + da) % 1.0
                if _feasible(trial):
                    cur = trial
                    improve = True
        if not improve:
            step_grow = max(0.0005, step_grow * 0.7)
            step_move = max(0.0005, step_move * 0.7)
    return [tuple(t) for t in cur]


# ---------- local search ----------

def _perturb(sol, rng, scale, n_moves=None):
    new = [list(t) for t in sol]
    n = len(new)
    if n_moves is None:
        n_moves = 1 + n // 3
    for _ in range(n_moves):
        i = rng.randrange(n)
        kind = rng.random()
        if kind < 0.45:
            new[i][3] = max(0.0, new[i][3] + rng.uniform(-scale, scale))
        elif kind < 0.75:
            new[i][0] = min(1.0, max(0.0, new[i][0] + rng.uniform(-scale, scale)))
            new[i][1] = min(1.0, max(0.0, new[i][1] + rng.uniform(-scale, scale)))
        elif kind < 0.9:
            new[i][2] = (new[i][2] + rng.uniform(-0.125, 0.125)) % 1.0
        else:
            j = rng.randrange(n)
            dx = rng.uniform(-scale, scale)
            dy = rng.uniform(-scale, scale)
            new[i][0] = min(1.0, max(0.0, new[i][0] + dx))
            new[i][1] = min(1.0, max(0.0, new[i][1] + dy))
            new[j][0] = min(1.0, max(0.0, new[j][0] + dx))
            new[j][1] = min(1.0, max(0.0, new[j][1] + dy))
    return [tuple(t) for t in new]


def _local_search(sol, rng, deadline, use_repair=True):
    best = [t for t in sol]
    best_score = _score(best)
    cur = best
    cur_score = best_score
    scale = 0.05
    it = 0
    stagnation = 0
    max_stagnation = 500
    while time.time() < deadline:
        it += 1
        stagnation += 1
        n_moves = 1 + rng.randrange(max(1, len(sol) // 2))
        cand = _perturb(cur, rng, scale, n_moves)
        if _feasible(cand):
            cs = _score(cand)
            if cs >= cur_score - 1e-9:
                cur, cur_score = cand, cs
                if cs > best_score:
                    best, best_score = cand, cs
                    stagnation = 0
            elif use_repair:
                repaired = _repair(cand, rng, max_iter=20)
                if _feasible(repaired):
                    rs = _score(repaired)
                    if rs > best_score:
                        best, best_score = repaired, rs
                        cur, cur_score = repaired, rs
                        stagnation = 0
        if it % 200 == 0:
            scale = max(0.005, scale * 0.97)
        if stagnation > max_stagnation:
            cur = _perturb(best, rng, scale * 2, len(sol))
            if not _feasible(cur):
                cur = [t for t in best]
            cur_score = _score(cur)
            stagnation = 0
            scale = min(0.1, scale * 1.5)
    return best


# ---------- orchestrator ----------

def solve(n):
    rng = random.Random(12345 + n)
    deadline = time.time() + 8.0  # leave headroom under 60s limit

    candidates = []
    candidates.append(_grid(n))
    for c in _seeded_layouts(n):
        candidates.append(c)
    for _ in range(3):
        candidates.append(_guillotine(n, rng))
    for _ in range(2):
        candidates.append(_greedy(n, rng))
    candidates.append(_rotated_grid(n, rng))

    # repair / verify
    feasible = []
    for c in candidates:
        c = list(c) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(c))
        c = c[:n]
        if _feasible(c):
            feasible.append(c)
        else:
            repaired = _repair(c, rng, max_iter=80)
            if _feasible(repaired):
                feasible.append(repaired)

    if not feasible:
        feasible = [_grid(n)]

    # improve each briefly, then focus on the best
    improved = []
    per = max(1.0, (deadline - time.time()) / (len(feasible) + 1))
    for c in feasible:
        sub_deadline = min(deadline, time.time() + per)
        improved.append(_local_search(c, rng, sub_deadline))

    improved.sort(key=_score, reverse=True)
    best = improved[0]

    # Deterministic polish on the current best
    polish_deadline = min(deadline, time.time() + max(1.0, (deadline - time.time()) * 0.4))
    polished = _polish(best, polish_deadline)
    if _score(polished) > _score(best):
        best = polished

    # final push on the best
    best = _local_search(best, rng, deadline)

    # Polish again with remaining time
    polished = _polish(best, deadline)
    if _score(polished) > _score(best):
        best = polished

    # ensure exactly n entries, all within [0,1]
    out = []
    for cx, cy, ang, s in best:
        out.append((min(1.0, max(0.0, cx)),
                    min(1.0, max(0.0, cy)),
                    ang % 1.0,
                    max(0.0, s)))
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]
# EVOLVE-BLOCK-END