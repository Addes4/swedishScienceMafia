# EVOLVE-BLOCK-START
"""Guillotine packing: recursively split the unit square and pack grids in each part."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    result = []
    memo = {}
    plans = {}
    _pack(1.0, 1.0, n, 0.0, 0.0, result, memo, plans)
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]


def _best_grid_val(w, h, c):
    best = 0.0
    bm = bp = 0
    bs = 0.0
    for m in range(1, c + 1):
        p = c // m
        s = min(w / m, h / p)
        val = m * p * s
        if val > best:
            best = val
            bm = m
            bp = p
            bs = s
    return best, bm, bp, bs


def _val(w, h, c, memo):
    if c <= 0:
        return 0.0
    key = (round(w, 6), round(h, 6), c)
    if key in memo:
        return memo[key]
    gv, _, _, _ = _best_grid_val(w, h, c)
    best = gv
    for m in range(1, c):
        for tn in range(1, 13):
            t = tn / 12.0
            w1 = w * t
            w2 = w - w1
            if w1 > 1e-9 and w2 > 1e-9:
                v = _val(w1, h, m, memo) + _val(w2, h, c - m, memo)
                if v > best:
                    best = v
            h1 = h * t
            h2 = h - h1
            if h1 > 1e-9 and h2 > 1e-9:
                v = _val(w, h1, m, memo) + _val(w, h2, c - m, memo)
                if v > best:
                    best = v
    memo[key] = best
    return best


def _pack(w, h, c, x0, y0, result, memo, plans):
    if c <= 0:
        return
    key = (round(w, 6), round(h, 6), c)
    if key in plans:
        plan = plans[key]
    else:
        gv, gm, gp, gs = _best_grid_val(w, h, c)
        best = gv
        bestplan = ('grid', gm, gp, gs)
        for m in range(1, c):
            for tn in range(1, 13):
                t = tn / 12.0
                w1 = w * t
                w2 = w - w1
                if w1 > 1e-9 and w2 > 1e-9:
                    v = _val(w1, h, m, memo) + _val(w2, h, c - m, memo)
                    if v > best + 1e-12:
                        best = v
                        bestplan = ('v', t, m)
                h1 = h * t
                h2 = h - h1
                if h1 > 1e-9 and h2 > 1e-9:
                    v = _val(w, h1, m, memo) + _val(w, h2, c - m, memo)
                    if v > best + 1e-12:
                        best = v
                        bestplan = ('h', t, m)
        plans[key] = bestplan
        plan = bestplan
    if plan[0] == 'grid':
        _, m, p, s = plan
        ox = x0 + (w - m * s) / 2
        oy = y0 + (h - p * s) / 2
        for i in range(m):
            for j in range(p):
                result.append((ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s))
    elif plan[0] == 'v':
        _, t, m = plan
        w1 = w * t
        _pack(w1, h, m, x0, y0, result, memo, plans)
        _pack(w - w1, h, c - m, x0 + w1, y0, result, memo, plans)
    else:
        _, t, m = plan
        h1 = h * t
        _pack(w, h1, m, x0, y0, result, memo, plans)
        _pack(w, h - h1, c - m, x0, y0 + h1, result, memo, plans)
# EVOLVE-BLOCK-END