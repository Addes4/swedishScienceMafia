# EVOLVE-BLOCK-START
"""Layered optimizer for packing squares in the unit square.

Architecture
============
  geometry     : SAT-based feasibility + overlap area.
  repair       : shrink/move/inside-fix loop.
  templates    : curated deterministic layouts (rows, grid+strip, pinwheel,
                 cross, staircase, kxk+subgrid).
  generators   : stochastic (guillotine, greedy, rotated/hybrid grid).
  improve      : local search + deterministic polish, unified.
  orchestrator : build candidates -> score -> improve top-K -> improve best.

The public entry point is solve(n).
"""
import math
import random
import time


# ---------------------------------------------------------------------------
# geometry
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, s):
    """Corners of a square centered at (cx,cy), side s, angle ang (turns)."""
    h = s * 0.5
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    return [
        (cx + dx * ca - dy * sa, cy + dx * sa + dy * ca)
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h))
    ]


def _overlap_axes(pts1, pts2):
    """Separating Axis Theorem overlap test for two convex polygons."""
    for poly in (pts1, pts2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ax, ay = -(y2 - y1), (x2 - x1)
            n = math.hypot(ax, ay)
            if n == 0:
                continue
            ax, ay = ax / n, ay / n
            p1 = [x * ax + y * ay for x, y in pts1]
            p2 = [x * ax + y * ay for x, y in pts2]
            if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
                return False
    return True


def _inside_unit(pts):
    for x, y in pts:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(sol):
    """All squares inside unit and pairwise disjoint interiors."""
    polys = []
    for cx, cy, ang, s in sol:
        if s <= 0:
            polys.append(None)
            continue
        p = _corners(cx, cy, ang, s)
        if not _inside_unit(p):
            return False
        polys.append(p)
    n = len(polys)
    for i in range(n):
        if polys[i] is None:
            continue
        for j in range(i + 1, n):
            if polys[j] is None:
                continue
            if _overlap_axes(polys[i], polys[j]):
                return False
    return True


def _score(sol):
    return sum(max(0.0, s) for _, _, _, s in sol)


def _overlap_area(pts1, pts2):
    """Approximate overlap area using bounding boxes."""
    x1_min = min(p[0] for p in pts1); x1_max = max(p[0] for p in pts1)
    y1_min = min(p[1] for p in pts1); y1_max = max(p[1] for p in pts1)
    x2_min = min(p[0] for p in pts2); x2_max = max(p[0] for p in pts2)
    y2_min = min(p[1] for p in pts2); y2_max = max(p[1] for p in pts2)
    w = max(0, min(x1_max, x2_max) - max(x1_min, x2_min))
    h = max(0, min(y1_max, y2_max) - max(y1_min, y2_min))
    return w * h


# ---------------------------------------------------------------------------
# repair
# ---------------------------------------------------------------------------

def _repair(sol, rng, max_iter=60):
    """Shrink/move overlapping squares; also fix out-of-bounds centers."""
    sol = [list(t) for t in sol]
    n = len(sol)
    for _ in range(max_iter):
        # 1) Clamp centers into [0,1] and shrink out-of-bounds squares.
        for i in range(n):
            sol[i][0] = min(1.0, max(0.0, sol[i][0]))
            sol[i][1] = min(1.0, max(0.0, sol[i][1]))
            if sol[i][3] > 0 and not _inside_unit(_corners(*sol[i])):
                sol[i][3] *= 0.9

        # 2) Find worst overlap.
        worst = None
        worst_area = 0.0
        for i in range(n):
            if sol[i][3] <= 0:
                continue
            pi = _corners(*sol[i])
            for j in range(i + 1, n):
                if sol[j][3] <= 0:
                    continue
                pj = _corners(*sol[j])
                if _overlap_axes(pi, pj):
                    a = _overlap_area(pi, pj)
                    if a > worst_area:
                        worst_area = a
                        worst = (i, j)

        if worst is None:
            return [tuple(s) for s in sol]

        i, j = worst
        if sol[i][3] >= sol[j][3]:
            sol[i][3] *= rng.uniform(0.85, 0.95)
        else:
            sol[j][3] *= rng.uniform(0.85, 0.95)
        idx = i if rng.random() < 0.5 else j
        sol[idx][0] = min(1.0, max(0.0, sol[idx][0] + rng.uniform(-0.03, 0.03)))
        sol[idx][1] = min(1.0, max(0.0, sol[idx][1] + rng.uniform(-0.03, 0.03)))
    return [tuple(s) for s in sol]


# ---------------------------------------------------------------------------
# layout helpers
# ---------------------------------------------------------------------------

def _rows_layout(n, sizes):
    """Stack rows of axis-aligned squares with the given sizes."""
    out = []
    y = 1.0
    for row in sizes:
        row_h = max(row) if row else 0.0
        if row_h <= 0:
            continue
        y -= row_h
        x = 0.0
        for s in row:
            out.append((x + s * 0.5, y + row_h * 0.5, 0.0, s))
            x += s
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _grid(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
           for i in range(k) for j in range(k)]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]


def _side_grid(n, rng):
    """k x k grid plus a sub-grid in a leftover strip."""
    k = max(1, math.isqrt(n))
    m = n - k * k
    if m <= 0:
        return _grid(n)
    best = None
    best_s = -1.0
    for orient in (0, 1):
        for strip_frac in (0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65):
            main = 1.0 - strip_frac
            side = main / k
            out = []
            if orient == 0:
                for i in range(k):
                    for j in range(k):
                        out.append(((i + 0.5) * side,
                                    (j + 0.5) * side, 0.0, side))
                sub_k = max(1, int(math.ceil(math.sqrt(m))))
                sub_side = min(strip_frac / sub_k, 1.0 / sub_k)
                placed = 0
                for i in range(sub_k):
                    for j in range(sub_k):
                        if placed >= m:
                            break
                        cx = main + (i + 0.5) * (strip_frac / sub_k)
                        cy = (j + 0.5) * (1.0 / sub_k)
                        out.append((cx, cy, 0.0, sub_side))
                        placed += 1
                    if placed >= m:
                        break
            else:
                for i in range(k):
                    for j in range(k):
                        out.append(((i + 0.5) * side,
                                    (j + 0.5) * side, 0.0, side))
                sub_k = max(1, int(math.ceil(math.sqrt(m))))
                sub_side = min(strip_frac / sub_k, 1.0 / sub_k)
                placed = 0
                for i in range(sub_k):
                    for j in range(sub_k):
                        if placed >= m:
                            break
                        cx = (i + 0.5) * (1.0 / sub_k)
                        cy = main + (j + 0.5) * (strip_frac / sub_k)
                        out.append((cx, cy, 0.0, sub_side))
                        placed += 1
                    if placed >= m:
                        break
            while len(out) < n:
                out.append((0.5, 0.5, 0.0, 0.0))
            out = out[:n]
            if _feasible(out):
                s = _score(out)
                if s > best_s:
                    best_s = s
                    best = out
    return best if best is not None else _grid(n)


def _pinwheel_layout(n):
    """4-quadrant pinwheel with a genuine central rotated square.

    Four axis-aligned squares of side q sit in the quadrants with a gap
    of width `gap` along the central cross. A 45-degree square of side
    gap*sqrt(2) fits in the diamond. Then we fill the four corner-adjacent
    rectangular gaps with small squares.
    """
    if n < 5:
        return _grid(n)
    gap = 0.06
    q = (1.0 - gap) * 0.5
    out = [
        (q * 0.5,              q * 0.5,              0.0, q),
        (1.0 - q * 0.5,        q * 0.5,              0.0, q),
        (q * 0.5,              1.0 - q * 0.5,        0.0, q),
        (1.0 - q * 0.5,        1.0 - q * 0.5,        0.0, q),
    ]
    # Central rotated square: diagonal along gap direction.
    s_center = gap * math.sqrt(2.0) * 0.85
    out.append((0.5, 0.5, 0.125, s_center))
    # Fillers in the four cross arms (thin rectangles of width gap).
    filler = gap * 0.55
    arms = [
        (0.5, gap * 0.5),
        (0.5, 1.0 - gap * 0.5),
        (gap * 0.5, 0.5),
        (1.0 - gap * 0.5, 0.5),
    ]
    k = 0
    while len(out) < n and k < len(arms):
        cx, cy = arms[k]
        out.append((cx, cy, 0.0, filler))
        k += 1
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _cross_layout(n):
    """5-square cross (n=5) extended to larger n by adding small squares."""
    if n < 5:
        return _grid(n)
    out = [
        (0.5, 0.5, 0.0, 0.5),
        (0.25, 0.25, 0.0, 0.5),
        (0.75, 0.25, 0.0, 0.5),
        (0.25, 0.75, 0.0, 0.5),
        (0.75, 0.75, 0.0, 0.5),
    ]
    # Remove the center to leave a cross-shaped hole, then fill corners.
    # Actually simpler: replace one quadrant with smaller squares.
    if n > 5:
        out = out[:4]
        small = 1.0 / 3.0
        # Fill the 2x2 quadrant that we removed with a 3x3 grid.
        for i in range(3):
            for j in range(3):
                if len(out) >= n:
                    break
                out.append((0.5 + (i + 0.5) * small / 1.5 - 0.25,
                            0.5 + (j + 0.5) * small / 1.5 - 0.25,
                            0.0, small * 0.9))
            if len(out) >= n:
                break
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _staircase_layout(n):
    """Diagonal staircase of decreasing squares."""
    if n < 2:
        return _grid(n)
    out = []
    x = 0.0
    y = 0.0
    s = 1.0
    for k in range(n):
        if s <= 1e-6:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        out.append((x + s * 0.5, y + s * 0.5, 0.0, s))
        if k % 2 == 0:
            x += s
        else:
            y += s
        s = min(1.0 - x, 1.0 - y)
        if s <= 1e-6:
            s = 0.0
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


# ---------------------------------------------------------------------------
# deterministic template portfolio
# ---------------------------------------------------------------------------

def _templates(n):
    """Curated deterministic layouts for any n."""
    cands = []

    # 1) Equal rows: r rows of k squares, remainder in the last row.
    for r in range(1, n + 1):
        k = n // r
        if k == 0:
            continue
        rem = n - k * r
        sizes = [[1.0 / k] * k for _ in range(r)]
        if rem:
            extra = 1.0 / (k + rem)
            sizes[-1] = [extra] * (k + rem)
            for i in range(r - 1):
                sizes[i] = [1.0 / (k + rem)] * (k + rem)
        cands.append(_rows_layout(n, sizes))

    # 2) kxk + strip layout.
    cands.append(_grid(n))
    try:
        cands.append(_side_grid(n, random.Random(n)))
    except Exception:
        pass

    # 3) Pinwheel for n % 4 == 2 (four quadrants + center).
    if n % 4 == 2 and n >= 6:
        cands.append(_pinwheel_layout(n))

    # 4) Cross for small n.
    if 5 <= n <= 12:
        cands.append(_cross_layout(n))

    # 5) Staircase.
    if 3 <= n <= 20:
        cands.append(_staircase_layout(n))

    # 6) Hand-crafted strong seeds.
    if n == 5:
        cands.append([
            (0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
            (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5),
            (0.5, 0.5, 0.0, 0.0),
        ])
    if n == 6:
        cands.append(_rows_layout(6, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
        cands.append(_rows_layout(6, [[1/3, 1/3, 1/3], [1/3, 1/3, 1/3]]))
        cands.append(_rows_layout(6, [[0.5, 0.5], [1/3, 1/3, 1/3, 0.0]]))
    if n == 7:
        cands.append(_rows_layout(7, [[0.5, 0.5], [1/3, 1/3, 1/3]]))
        cands.append(_rows_layout(7, [[0.5, 0.5, 0.5], [1/4, 1/4, 1/4, 1/4]]))
    if n == 8:
        cands.append(_rows_layout(8, [[0.5, 0.5], [0.5, 0.5]]))
    if n == 11:
        # 3 large + 8 medium in two strips.
        cands.append(_rows_layout(11, [[0.5, 0.5, 0.5],
                                        [7/32] * 4, [7/32] * 4]))
        cands.append(_rows_layout(11, [[0.5, 0.5], [0.5, 0.5],
                                        [1/3, 1/3, 1/3]]))
    if n == 12:
        cands.append(_rows_layout(12, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
    if n == 13:
        cands.append(_rows_layout(13, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
    if n == 14:
        cands.append(_rows_layout(14, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
    if n == 15:
        cands.append(_rows_layout(15, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
    return cands


# ---------------------------------------------------------------------------
# stochastic generators
# ---------------------------------------------------------------------------

def _guillotine(n, rng):
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        cells.sort(key=lambda c: -(c[2] * c[3]))
        x, y, w, h = cells.pop(0)
        if w >= h:
            t = rng.uniform(0.35, 0.65)
            cells.append((x, y, w * t, h))
            cells.append((x + w * t, y, w * (1 - t), h))
        else:
            t = rng.uniform(0.35, 0.65)
            cells.append((x, y, w, h * t))
            cells.append((x, y + h * t, w, h * (1 - t)))
    return [(x + w * 0.5, y + h * 0.5, 0.0, min(w, h))
            for (x, y, w, h) in cells]


def _greedy(n, rng):
    sol = []
    for _ in range(n):
        best = None
        best_s = -1.0
        for _try in range(30):
            cx = rng.uniform(0.0, 1.0)
            cy = rng.uniform(0.0, 1.0)
            lo, hi = 0.0, 1.0
            for _ in range(18):
                mid = 0.5 * (lo + hi)
                if _feasible(sol + [(cx, cy, 0.0, mid)]):
                    lo = mid
                else:
                    hi = mid
            if lo > best_s:
                best_s = lo
                best = (cx, cy, 0.0, lo)
        sol.append(best if (best and best[3] > 0) else (0.5, 0.5, 0.0, 0.0))
    return sol


def _rotated_grid(n, rng):
    return [(cx, cy, rng.choice([0.0, 0.0, 0.0, 0.125, 0.25]), s)
            for cx, cy, _, s in _grid(n)]


def _hybrid_grid(n, rng):
    out = []
    for cx, cy, ang, s in _grid(n):
        if s > 0:
            cx = min(1.0, max(0.0, cx + rng.uniform(-0.02, 0.02)))
            cy = min(1.0, max(0.0, cy + rng.uniform(-0.02, 0.02)))
        out.append((cx, cy, ang, s))
    return out


def _candidates(n, rng):
    """Yield (name, layout) pairs from all generators."""
    for i, c in enumerate(_templates(n)):
        yield ("template_%d" % i, c)
    for i in range(3):
        yield ("guillotine_%d" % i, _guillotine(n, rng))
    yield ("greedy", _greedy(n, rng))
    yield ("rotated_grid", _rotated_grid(n, rng))
    yield ("hybrid_grid", _hybrid_grid(n, rng))


# ---------------------------------------------------------------------------
# local search + polish
# ---------------------------------------------------------------------------

def _perturb(sol, rng, scale, n_moves=None):
    new = [list(t) for t in sol]
    n = len(new)
    if n_moves is None:
        n_moves = 1 + n // 3
    for _ in range(n_moves):
        i = rng.randrange(n)
        kind = rng.random()
        if kind < 0.45:
            new[i][3] = max(0.0, new[i][3] + rng.uniform(-scale, scale))
        elif kind < 0.75:
            new[i][0] = min(1.0, max(0.0, new[i][0] + rng.uniform(-scale, scale)))
            new[i][1] = min(1.0, max(0.0, new[i][1] + rng.uniform(-scale, scale)))
        elif kind < 0.9:
            new[i][2] = (new[i][2] + rng.uniform(-0.125, 0.125)) % 1.0
        else:
            j = rng.randrange(n)
            dx = rng.uniform(-scale, scale)
            dy = rng.uniform(-scale, scale)
            new[i][0] = min(1.0, max(0.0, new[i][0] + dx))
            new[i][1] = min(1.0, max(0.0, new[i][1] + dy))
            new[j][0] = min(1.0, max(0.0, new[j][0] + dx))
            new[j][1] = min(1.0, max(0.0, new[j][1] + dy))
    return [tuple(t) for t in new]


def _swap_perturb(sol, rng):
    new = [list(t) for t in sol]
    n = len(new)
    if n == 0:
        return [tuple(t) for t in new]
    i = rng.randrange(n)
    for _ in range(5):
        cx = rng.uniform(0.05, 0.95)
        cy = rng.uniform(0.05, 0.95)
        trial = [list(t) for t in new]
        trial[i][0] = cx
        trial[i][1] = cy
        if _feasible(trial):
            return [tuple(t) for t in trial]
    return [tuple(t) for t in new]


def _local_search(sol, rng, deadline, use_repair=True):
    best = [t for t in sol]
    best_score = _score(best)
    cur = list(best)
    cur_score = best_score
    scale = 0.05
    it = 0
    stagnation = 0
    max_stagnation = 350
    while time.time() < deadline:
        it += 1
        stagnation += 1
        n_moves = 1 + rng.randrange(max(1, len(sol) // 2))
        if rng.random() < 0.15 and len(sol) >= 3:
            cand = _swap_perturb(cur, rng)
        else:
            cand = _perturb(cur, rng, scale, n_moves)
        if _feasible(cand):
            cs = _score(cand)
            if cs >= cur_score - 1e-9:
                cur, cur_score = cand, cs
                if cs > best_score:
                    best, best_score = cand, cs
                    stagnation = 0
        elif use_repair:
            repaired = _repair(cand, rng, max_iter=15)
            if _feasible(repaired):
                rs = _score(repaired)
                if rs > best_score:
                    best, best_score = repaired, rs
                    cur, cur_score = repaired, rs
                    stagnation = 0
        if it % 200 == 0:
            scale = max(0.005, scale * 0.97)
        if stagnation > max_stagnation:
            cur = _perturb(best, rng, scale * 2, len(sol))
            if not _feasible(cur):
                cur = [t for t in best]
            cur_score = _score(cur)
            stagnation = 0
            scale = min(0.1, scale * 1.5)
    return best


def _polish(sol, deadline):
    """Deterministic coordinate descent: grow, slide, rotate."""
    cur = [list(t) for t in sol]
    n = len(cur)
    best_score = _score(cur)
    step_grow = 0.01
    step_move = 0.01
    improve = True
    while improve and time.time() < deadline:
        improve = False
        for i in range(n):
            for _ in range(3):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][3] += step_grow
                if _feasible(trial):
                    cur = trial
                    improve = True
                else:
                    break
        for i in range(n):
            if cur[i][3] <= 0:
                continue
            for dx, dy in ((step_move, 0), (-step_move, 0),
                           (0, step_move), (0, -step_move)):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][0] = min(1.0, max(0.0, trial[i][0] + dx))
                trial[i][1] = min(1.0, max(0.0, trial[i][1] + dy))
                if _feasible(trial):
                    cur = trial
                    improve = True
        for i in range(n):
            if cur[i][3] <= 0:
                continue
            for da in (0.02, -0.02):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][2] = (trial[i][2] + da) % 1.0
                if _feasible(trial):
                    cur = trial
                    improve = True
        new_score = _score(cur)
        if new_score > best_score + 1e-9:
            best_score = new_score
        else:
            step_grow = max(0.0005, step_grow * 0.7)
            step_move = max(0.0005, step_move * 0.7)
    return [tuple(t) for t in cur]


def _improve(sol, rng, deadline, use_repair=True):
    """Search then polish; returns best found before deadline."""
    if time.time() >= deadline:
        return [tuple(t) for t in sol]
    mid = time.time() + 0.5 * (deadline - time.time())
    searched = _local_search(sol, rng, mid, use_repair=use_repair)
    polished = _polish(searched, deadline)
    return polished if _score(polished) > _score(searched) else searched


# ---------------------------------------------------------------------------
# orchestrator
# ---------------------------------------------------------------------------

_BUDGET = 8.0


def solve(n):
    rng = random.Random(12345 + n)
    deadline = time.time() + _BUDGET

    # 1) Build candidates.
    feasible = []
    for name, c in _candidates(n, rng):
        c = list(c) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(c))
        c = c[:n]
        if _feasible(c):
            feasible.append(c)
        else:
            repaired = _repair(c, rng, max_iter=60)
            if _feasible(repaired):
                feasible.append(repaired)

    if not feasible:
        feasible = [_grid(n)]

    # 2) Rank candidates: higher score, fewer zero-side squares.
    def _rank(sol):
        return (_score(sol), -sum(1 for t in sol if t[3] <= 0))

    feasible.sort(key=_rank, reverse=True)

    # 3) Keep a diverse top set (plus grid).
    keep = feasible[:max(3, len(feasible) // 2)]
    grid = _grid(n)
    if grid not in keep:
        keep.append(grid)

    # 4) Time budget split: 30% initial search, 25% polish, 45% final.
    total = max(0.5, deadline - time.time())
    search_deadline = time.time() + total * 0.30
    polish_deadline = time.time() + total * 0.25

    # 5) Improve each kept candidate briefly.
    improved = []
    per = max(0.4, (search_deadline - time.time()) / max(1, len(keep)))
    for c in keep:
        sub = min(search_deadline, time.time() + per)
        improved.append(_local_search(c, rng, sub))

    improved.sort(key=_rank, reverse=True)
    best = improved[0]

    # 6) Deterministic polish on the best.
    polished = _polish(best, polish_deadline)
    if _score(polished) > _score(best):
        best = polished

    # 7) Final combined improve on the best.
    best = _improve(best, rng, deadline)

    # 8) Normalise output.
    out = []
    for cx, cy, ang, s in best:
        out.append((min(1.0, max(0.0, cx)),
                    min(1.0, max(0.0, cy)),
                    ang % 1.0,
                    max(0.0, s)))
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]
# EVOLVE-BLOCK-END