# EVOLVE-BLOCK-START
"""Greedy grid + recursive subdivision to make use of all n squares."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    best_cells = None
    best_sum = -1.0
    max_k = math.isqrt(n)
    for k in range(1, max_k + 1):
        s = 1.0 / k
        cells = [(i * s, j * s, s) for i in range(k) for j in range(k)]
        # Recursively subdivide the largest cell until we have at least n cells.
        guard = 0
        while len(cells) < n and guard < 100000:
            guard += 1
            idx = 0
            for i in range(1, len(cells)):
                if cells[i][2] > cells[idx][2]:
                    idx = i
            x, y, ss = cells[idx]
            h = ss * 0.5
            cells[idx] = (x, y, h)
            cells.append((x + h, y, h))
            cells.append((x, y + h, h))
            cells.append((x + h, y + h, h))
        # Keep only the n largest cells if we overshot.
        if len(cells) > n:
            cells.sort(key=lambda t: -t[2])
            cells = cells[:n]
        total = 0.0
        for c in cells:
            total += c[2]
        if total > best_sum:
            best_sum = total
            best_cells = cells
    result = []
    for (x, y, s) in best_cells:
        result.append((x + s * 0.5, y + s * 0.5, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END