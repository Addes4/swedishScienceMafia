# EVOLVE-BLOCK-START
"""Hybrid optimizer for packing squares in the unit square.

Architecture:
  - Feasibility utilities: SAT-style overlap test for rotated squares.
  - Candidate generators: grid, guillotine, greedy, rotated-grid.
  - Local search: size/position/angle perturbation with feasibility repair.
  - Orchestrator: time-budgeted portfolio that returns the best packing.

Improvements:
  - Combined grid baseline with advanced generators.
  - Enhanced local search with adaptive scaling and restarts.
  - Feasibility repair for infeasible candidates.
  - Coordinated multi-square perturbations.
"""
import math
import random
import time


# ---------- geometry ----------

def _corners(cx, cy, ang, s):
    """Return 4 corners of a square centered at (cx,cy), side s, angle ang (turns)."""
    h = s * 0.5
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap_axes(pts1, pts2):
    """Separating Axis Theorem overlap test for two convex polygons."""
    for poly in (pts1, pts2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ax, ay = -(y2 - y1), (x2 - x1)
            n = math.hypot(ax, ay)
            if n == 0:
                continue
            ax, ay = ax / n, ay / n
            p1 = [x * ax + y * ay for x, y in pts1]
            p2 = [x * ax + y * ay for x, y in pts2]
            if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
                return False
    return True


def _inside_unit(pts):
    for x, y in pts:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(sol):
    """Check all squares inside unit and pairwise disjoint interiors."""
    polys = []
    for cx, cy, ang, s in sol:
        if s <= 0:
            polys.append(None)
            continue
        p = _corners(cx, cy, ang, s)
        if not _inside_unit(p):
            return False
        polys.append(p)
    n = len(polys)
    for i in range(n):
        if polys[i] is None:
            continue
        for j in range(i + 1, n):
            if polys[j] is None:
                continue
            if _overlap_axes(polys[i], polys[j]):
                return False
    return True


def _score(sol):
    return sum(max(0.0, s) for _, _, _, s in sol)


def _overlap_area(pts1, pts2):
    """Approximate overlap area using bounding boxes (for repair heuristic)."""
    x1_min = min(p[0] for p in pts1)
    x1_max = max(p[0] for p in pts1)
    y1_min = min(p[1] for p in pts1)
    y1_max = max(p[1] for p in pts1)
    x2_min = min(p[0] for p in pts2)
    x2_max = max(p[0] for p in pts2)
    y2_min = min(p[1] for p in pts2)
    y2_max = max(p[1] for p in pts2)
    
    overlap_w = max(0, min(x1_max, x2_max) - max(x1_min, x2_min))
    overlap_h = max(0, min(y1_max, y2_max) - max(y1_min, y2_min))
    return overlap_w * overlap_h


def _repair(sol, rng, max_iter=50):
    """Attempt to repair an infeasible solution by shrinking/moving overlapping squares."""
    sol = [list(t) for t in sol]
    n = len(sol)
    
    for _ in range(max_iter):
        # Find overlapping pairs
        overlaps = []
        for i in range(n):
            if sol[i][3] <= 0:
                continue
            pi = _corners(*sol[i])
            for j in range(i + 1, n):
                if sol[j][3] <= 0:
                    continue
                pj = _corners(*sol[j])
                if _overlap_axes(pi, pj):
                    area = _overlap_area(pi, pj)
                    overlaps.append((area, i, j))
        
        if not overlaps:
            # Check boundaries
            for i in range(n):
                if sol[i][3] > 0:
                    p = _corners(*sol[i])
                    if not _inside_unit(p):
                        # Shrink to fit
                        sol[i][3] *= 0.95
            if all(_inside_unit(_corners(*s)) if s[3] > 0 else True for s in sol):
                return [tuple(s) for s in sol]
            continue
        
        # Sort by overlap area (largest first)
        overlaps.sort(reverse=True)
        _, i, j = overlaps[0]
        
        # Shrink the larger square
        if sol[i][3] >= sol[j][3]:
            sol[i][3] *= rng.uniform(0.85, 0.95)
        else:
            sol[j][3] *= rng.uniform(0.85, 0.95)
        
        # Also try small random moves
        idx = i if rng.random() < 0.5 else j
        sol[idx][0] = min(1.0, max(0.0, sol[idx][0] + rng.uniform(-0.02, 0.02)))
        sol[idx][1] = min(1.0, max(0.0, sol[idx][1] + rng.uniform(-0.02, 0.02)))
    
    return [tuple(s) for s in sol]


# ---------- generators ----------

def _grid(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
           for i in range(k) for j in range(k)]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]


def _guillotine(n, rng):
    """Recursively split the unit square into n cells, then fill each with a square."""
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        # pick the largest cell
        cells.sort(key=lambda c: -(c[2] * c[3]))
        idx = 0
        x, y, w, h = cells.pop(idx)
        if w >= h:
            t = rng.uniform(0.35, 0.65)
            cells.append((x, y, w * t, h))
            cells.append((x + w * t, y, w * (1 - t), h))
        else:
            t = rng.uniform(0.35, 0.65)
            cells.append((x, y, w, h * t))
            cells.append((x, y + h * t, w, h * (1 - t)))
    out = []
    for (x, y, w, h) in cells:
        s = min(w, h)
        out.append((x + w * 0.5, y + h * 0.5, 0.0, s))
    return out


def _greedy(n, rng):
    """Greedy: place squares one by one in largest available gap, axis-aligned."""
    sol = []
    for _ in range(n):
        best = None
        best_s = -1.0
        for _try in range(40):
            cx = rng.uniform(0.0, 1.0)
            cy = rng.uniform(0.0, 1.0)
            # binary-search largest s that fits
            lo, hi = 0.0, 1.0
            for _ in range(20):
                mid = 0.5 * (lo + hi)
                cand = sol + [(cx, cy, 0.0, mid)]
                if _feasible(cand):
                    lo = mid
                else:
                    hi = mid
            if lo > best_s:
                best_s = lo
                best = (cx, cy, 0.0, lo)
        if best is None or best[3] <= 0:
            sol.append((0.5, 0.5, 0.0, 0.0))
        else:
            sol.append(best)
    return sol


def _rotated_grid(n, rng):
    """Grid but with some squares rotated to allow tighter packing variants."""
    base = _grid(n)
    out = []
    for cx, cy, _, s in base:
        ang = rng.choice([0.0, 0.0, 0.0, 0.125, 0.25])
        out.append((cx, cy, ang, s))
    return out


def _hybrid_grid(n, rng):
    """Grid with slight random perturbations for better packing."""
    base = _grid(n)
    out = []
    for cx, cy, ang, s in base:
        if s > 0:
            # Small random perturbations
            cx += rng.uniform(-0.02, 0.02)
            cy += rng.uniform(-0.02, 0.02)
            cx = min(1.0, max(0.0, cx))
            cy = min(1.0, max(0.0, cy))
        out.append((cx, cy, ang, s))
    return out


# ---------- local search ----------

def _perturb(sol, rng, scale, n_moves=None):
    """Perturb the solution with adaptive move types."""
    new = [list(t) for t in sol]
    n = len(new)
    if n_moves is None:
        n_moves = 1 + n // 3
    
    for _ in range(n_moves):
        i = rng.randrange(n)
        kind = rng.random()
        if kind < 0.45:
            # resize
            new[i][3] = max(0.0, new[i][3] + rng.uniform(-scale, scale))
        elif kind < 0.75:
            # move
            new[i][0] = min(1.0, max(0.0, new[i][0] + rng.uniform(-scale, scale)))
            new[i][1] = min(1.0, max(0.0, new[i][1] + rng.uniform(-scale, scale)))
        elif kind < 0.9:
            # rotate
            new[i][2] = (new[i][2] + rng.uniform(-0.125, 0.125)) % 1.0
        else:
            # coordinated move: move multiple squares
            j = rng.randrange(n)
            dx = rng.uniform(-scale, scale)
            dy = rng.uniform(-scale, scale)
            new[i][0] = min(1.0, max(0.0, new[i][0] + dx))
            new[i][1] = min(1.0, max(0.0, new[i][1] + dy))
            new[j][0] = min(1.0, max(0.0, new[j][0] + dx))
            new[j][1] = min(1.0, max(0.0, new[j][1] + dy))
    
    return [tuple(t) for t in new]


def _local_search(sol, rng, deadline, use_repair=True):
    """Enhanced local search with adaptive scaling and restarts."""
    best = [t for t in sol]
    best_score = _score(best)
    cur = best
    cur_score = best_score
    scale = 0.05
    it = 0
    stagnation = 0
    max_stagnation = 500
    
    while time.time() < deadline:
        it += 1
        stagnation += 1
        
        # Adaptive number of moves
        n_moves = 1 + rng.randrange(max(1, len(sol) // 2))
        cand = _perturb(cur, rng, scale, n_moves)
        
        if _feasible(cand):
            cs = _score(cand)
            if cs >= cur_score - 1e-9:
                cur, cur_score = cand, cs
                if cs > best_score:
                    best, best_score = cand, cs
                    stagnation = 0
            elif use_repair:
                # Try to repair if close
                repaired = _repair(cand, rng, max_iter=20)
                if _feasible(repaired):
                    rs = _score(repaired)
                    if rs > best_score:
                        best, best_score = repaired, rs
                        cur, cur_score = repaired, rs
                        stagnation = 0
        
        # Adaptive scaling
        if it % 200 == 0:
            scale = max(0.005, scale * 0.97)
        
        # Restart if stagnated
        if stagnation > max_stagnation:
            # Create a fresh perturbation from best
            cur = _perturb(best, rng, scale * 2, len(sol))
            if not _feasible(cur):
                cur = [t for t in best]
            cur_score = _score(cur)
            stagnation = 0
            scale = min(0.1, scale * 1.5)
    
    return best


# ---------- orchestrator ----------

def solve(n):
    rng = random.Random(12345 + n)
    deadline = time.time() + 8.0  # leave headroom under 60s limit

    # Generate diverse candidates
    candidates = []
    
    # Always include the simple grid (reliable baseline)
    candidates.append(_grid(n))
    
    # Advanced generators
    for _ in range(3):
        candidates.append(_guillotine(n, rng))
    for _ in range(2):
        candidates.append(_greedy(n, rng))
    candidates.append(_rotated_grid(n, rng))
    candidates.append(_hybrid_grid(n, rng))

    # Repair / verify
    feasible = []
    for c in candidates:
        c = list(c) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(c))
        c = c[:n]
        if _feasible(c):
            feasible.append(c)
        else:
            # Try to repair
            repaired = _repair(c, rng, max_iter=100)
            if _feasible(repaired):
                feasible.append(repaired)

    if not feasible:
        feasible = [_grid(n)]

    # Improve each briefly, then focus on the best
    improved = []
    per = max(1.0, (deadline - time.time()) / (len(feasible) + 1))
    for c in feasible:
        sub_deadline = min(deadline, time.time() + per)
        improved.append(_local_search(c, rng, sub_deadline))

    improved.sort(key=_score, reverse=True)
    best = improved[0]

    # Final push on the best
    best = _local_search(best, rng, deadline)

    # Ensure exactly n entries, all within [0,1]
    out = []
    for cx, cy, ang, s in best:
        out.append((min(1.0, max(0.0, cx)),
                    min(1.0, max(0.0, cy)),
                    ang % 1.0,
                    max(0.0, s)))
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]
# EVOLVE-BLOCK-END
