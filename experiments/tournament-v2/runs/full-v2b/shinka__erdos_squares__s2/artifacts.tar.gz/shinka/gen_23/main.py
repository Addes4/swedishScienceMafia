# EVOLVE-BLOCK-START
"""Depth-aware guillotine-cut layout optimiser (SA + coordinate polish)."""
import math
import random


# ----------------------------------------------------------------------
# Fallback: greedy grid + recursive subdivision heuristic.
# ----------------------------------------------------------------------
def _grid_subdivision(n):
    if n <= 0:
        return [], 0.0
    best_cells = None
    best_sum = -1.0
    max_k = math.isqrt(n)
    for k in range(1, max_k + 1):
        s = 1.0 / k
        cells = [(i * s, j * s, s) for i in range(k) for j in range(k)]
        guard = 0
        while len(cells) < n and guard < 100000:
            guard += 1
            idx = 0
            for i in range(1, len(cells)):
                if cells[i][2] > cells[idx][2]:
                    idx = i
            x, y, ss = cells[idx]
            h = ss * 0.5
            cells[idx] = (x, y, h)
            cells.append((x + h, y, h))
            cells.append((x, y + h, h))
            cells.append((x + h, y + h, h))
        if len(cells) > n:
            cells.sort(key=lambda t: -t[2])
            cells = cells[:n]
        total = sum(c[2] for c in cells)
        if total > best_sum:
            best_sum = total
            best_cells = cells
    return best_cells, best_sum


# ----------------------------------------------------------------------
# Guillotine tree representation.  Every node carries its rectangle so
# that mutations only need to refresh the path from root to the cut.
#   Leaf = ['L', x0, y0, x1, y1, depth]
#   Node = ['V'|'H', pos, left, right, x0, y0, x1, y1, depth]
# ----------------------------------------------------------------------
def _build_balanced(n, x0, y0, x1, y1, rng, depth=0):
    if n == 1:
        return ['L', x0, y0, x1, y1, depth]
    if n == 2:
        a = 1
    else:
        a = rng.randint(1, n - 1)
        if rng.random() < 0.5:
            a = n // 2
    b = n - a
    w = x1 - x0
    h = y1 - y0
    if w >= h:
        vertical = rng.random() < 0.85
    else:
        vertical = rng.random() < 0.15
    if vertical:
        frac = a / float(n)
        frac = min(0.95, max(0.05, frac + rng.uniform(-0.15, 0.15)))
        pos = x0 + frac * w
        left = _build_balanced(a, x0, y0, pos, y1, rng, depth + 1)
        right = _build_balanced(b, pos, y0, x1, y1, rng, depth + 1)
        return ['V', pos, left, right, x0, y0, x1, y1, depth]
    else:
        frac = a / float(n)
        frac = min(0.95, max(0.05, frac + rng.uniform(-0.15, 0.15)))
        pos = y0 + frac * h
        left = _build_balanced(a, x0, y0, x1, pos, rng, depth + 1)
        right = _build_balanced(b, x0, pos, x1, y1, rng, depth + 1)
        return ['H', pos, left, right, x0, y0, x1, y1, depth]


def _refresh(node):
    """Recompute rectangles bottom-up; return score of subtree."""
    t = node[0]
    if t == 'L':
        w = node[3] - node[1]
        h = node[4] - node[2]
        return min(w, h)
    x0, y0, x1, y1 = node[4], node[5], node[6], node[7]
    pos = node[1]
    if t == 'V':
        if pos < x0 + 1e-9:
            pos = x0 + 1e-9
        if pos > x1 - 1e-9:
            pos = x1 - 1e-9
        node[1] = pos
        l, r = node[2], node[3]
        l[3] = pos
        r[1] = pos
        sl = _refresh(l)
        sr = _refresh(r)
        return sl + sr
    else:
        if pos < y0 + 1e-9:
            pos = y0 + 1e-9
        if pos > y1 - 1e-9:
            pos = y1 - 1e-9
        node[1] = pos
        l, r = node[2], node[3]
        l[4] = pos
        r[2] = pos
        sl = _refresh(l)
        sr = _refresh(r)
        return sl + sr


def _collect_leaves(node, out):
    if node[0] == 'L':
        out.append((node[1], node[2], node[3], node[4]))
        return
    _collect_leaves(node[2], out)
    _collect_leaves(node[3], out)


def _list_cuts(node, acc):
    if node[0] == 'L':
        return
    acc.append((node, node[0], node[1], node[8]))
    _list_cuts(node[2], acc)
    _list_cuts(node[3], acc)


def _polish(tree, rng, rounds=3):
    cur = _refresh(tree)
    for _ in range(rounds):
        cuts = []
        _list_cuts(tree, cuts)
        improved = False
        for (node, kind, pos, depth) in cuts:
            base = pos
            for delta in (0.01, -0.01, 0.03, -0.03, 0.005, -0.005):
                node[1] = min(0.999999, max(0.000001, base + delta))
                sc = _refresh(tree)
                if sc > cur + 1e-12:
                    cur = sc
                    improved = True
                    break
                node[1] = base
        if not improved:
            break
    return tree, cur


def _optimize_tree(tree, rng, iters):
    cur = _refresh(tree)
    best = cur
    best_leaves = []
    _collect_leaves(tree, best_leaves)

    cuts = []
    _list_cuts(tree, cuts)
    if not cuts:
        return tree, cur, best_leaves

    temp0 = 0.20
    temp1 = 0.002
    for it in range(iters):
        T = temp0 * (temp1 / temp0) ** (it / max(1, iters - 1))
        node, kind, pos, depth = cuts[rng.randrange(len(cuts))]
        step = (0.015 + 0.30 * T) * (0.6 ** depth)
        new_pos = pos + rng.gauss(0.0, step)
        new_pos = min(0.999999, max(0.000001, new_pos))
        node[1] = new_pos
        sc = _refresh(tree)
        if sc >= cur or rng.random() < math.exp((sc - cur) / max(1e-9, T)):
            cur = sc
            if sc > best:
                best = sc
                best_leaves = []
                _collect_leaves(tree, best_leaves)
        else:
            node[1] = pos
            _refresh(tree)
    return tree, best, best_leaves


def _cells_to_tree(cells, x0, y0, x1, y1, rng, depth=0):
    if len(cells) == 1:
        cx, cy, s = cells[0]
        return ['L', cx, cy, cx + s, cy + s, depth]
    xs = sorted(set(round(c[0], 12) for c in cells))
    ys = sorted(set(round(c[1], 12) for c in cells))
    if len(xs) > 1 and (len(xs) >= len(ys) or rng.random() < 0.5):
        mid = xs[len(xs) // 2]
        left = [c for c in cells if c[0] + 1e-9 < mid]
        right = [c for c in cells if c[0] + 1e-9 >= mid]
        if not left or not right:
            left = cells[:len(cells) // 2]
            right = cells[len(cells) // 2:]
        ltree = _cells_to_tree(left, x0, y0, mid, y1, rng, depth + 1)
        rtree = _cells_to_tree(right, mid, y0, x1, y1, rng, depth + 1)
        return ['V', mid, ltree, rtree, x0, y0, x1, y1, depth]
    else:
        mid = ys[len(ys) // 2]
        down = [c for c in cells if c[1] + 1e-9 < mid]
        up = [c for c in cells if c[1] + 1e-9 >= mid]
        if not down or not up:
            down = cells[:len(cells) // 2]
            up = cells[len(cells) // 2:]
        dtree = _cells_to_tree(down, x0, y0, x1, mid, rng, depth + 1)
        utree = _cells_to_tree(up, x0, mid, x1, y1, rng, depth + 1)
        return ['H', mid, dtree, utree, x0, y0, x1, y1, depth]


def _leaves_to_result(leaves):
    cells = []
    for (x0, y0, x1, y1) in leaves:
        w = x1 - x0
        h = y1 - y0
        s = min(w, h)
        cx = 0.5 * (x0 + x1)
        cy = 0.5 * (y0 + y1)
        cells.append((cx - s * 0.5, cy - s * 0.5, s))
    return cells


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    base_cells, base_sum = _grid_subdivision(n)
    best_cells = base_cells
    best_sum = base_sum

    rng = random.Random(0xC0FFEE + n)

    n_restarts = 8 + max(0, (n - 8) // 2)
    iters = max(600, 350 * n)

    # Seed 1: greedy grid layout converted to a guillotine tree.
    if base_cells:
        seed_tree = _cells_to_tree(list(base_cells), 0.0, 0.0, 1.0, 1.0, rng)
        seed_tree, sc, leaves = _optimize_tree(seed_tree, rng, iters)
        seed_tree, sc = _polish(seed_tree, rng, rounds=4)
        leaves = []
        _collect_leaves(seed_tree, leaves)
        cells = _leaves_to_result(leaves)
        if sc > best_sum:
            best_sum = sc
            best_cells = cells

    # Random restarts.
    for _ in range(n_restarts):
        tree = _build_balanced(n, 0.0, 0.0, 1.0, 1.0, rng)
        _, sc, _ = _optimize_tree(tree, rng, iters)
        tree, sc = _polish(tree, rng, rounds=3)
        if sc > best_sum:
            leaves = []
            _collect_leaves(tree, leaves)
            best_sum = sc
            best_cells = _leaves_to_result(leaves)

    result = []
    for (x, y, s) in best_cells:
        result.append((x + s * 0.5, y + s * 0.5, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END