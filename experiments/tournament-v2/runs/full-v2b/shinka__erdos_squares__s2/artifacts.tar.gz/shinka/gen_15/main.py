# EVOLVE-BLOCK-START
"""Hybrid optimizer for packing squares in the unit square.

Combines the best of two prior architectures:
  - Deterministic seeded row layouts (strong for small n).
  - Side-grid generator (k x k grid + sub-grid in leftover strip).
  - Stochastic generators: guillotine, greedy, rotated/hybrid grid.
  - SAT feasibility test with fast corner caching.
  - Aggressive repair for infeasible candidates.
  - Adaptive local search with restarts and swap moves.
  - Deterministic coordinate-descent polish with shrink-then-grow.
  - Time-budgeted orchestrator.
"""
import math
import random
import time


# ---------- geometry ----------

def _corners(cx, cy, ang, s):
    """Return 4 corners of a square centered at (cx,cy), side s, angle ang (turns)."""
    h = s * 0.5
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap_axes(pts1, pts2):
    """Separating Axis Theorem overlap test for two convex polygons."""
    for poly in (pts1, pts2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ax, ay = -(y2 - y1), (x2 - x1)
            n = math.hypot(ax, ay)
            if n == 0:
                continue
            ax, ay = ax / n, ay / n
            p1 = [x * ax + y * ay for x, y in pts1]
            p2 = [x * ax + y * ay for x, y in pts2]
            if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
                return False
    return True


def _inside_unit(pts):
    for x, y in pts:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(sol):
    """Check all squares inside unit and pairwise disjoint interiors."""
    polys = []
    for cx, cy, ang, s in sol:
        if s <= 0:
            polys.append(None)
            continue
        p = _corners(cx, cy, ang, s)
        if not _inside_unit(p):
            return False
        polys.append(p)
    n = len(polys)
    for i in range(n):
        if polys[i] is None:
            continue
        pi = polys[i]
        for j in range(i + 1, n):
            if polys[j] is None:
                continue
            if _overlap_axes(pi, polys[j]):
                return False
    return True


def _score(sol):
    return sum(max(0.0, s) for _, _, _, s in sol)


def _overlap_area(pts1, pts2):
    """Approximate overlap area using bounding boxes."""
    x1_min = min(p[0] for p in pts1)
    x1_max = max(p[0] for p in pts1)
    y1_min = min(p[1] for p in pts1)
    y1_max = max(p[1] for p in pts1)
    x2_min = min(p[0] for p in pts2)
    x2_max = max(p[0] for p in pts2)
    y2_min = min(p[1] for p in pts2)
    y2_max = max(p[1] for p in pts2)
    w = max(0, min(x1_max, x2_max) - max(x1_min, x2_min))
    h = max(0, min(y1_max, y2_max) - max(y1_min, y2_min))
    return w * h


def _repair(sol, rng, max_iter=80):
    """Repair infeasible solution by shrinking/moving overlapping squares."""
    sol = [list(t) for t in sol]
    n = len(sol)
    for _ in range(max_iter):
        overlaps = []
        for i in range(n):
            if sol[i][3] <= 0:
                continue
            pi = _corners(*sol[i])
            for j in range(i + 1, n):
                if sol[j][3] <= 0:
                    continue
                pj = _corners(*sol[j])
                if _overlap_axes(pi, pj):
                    overlaps.append((_overlap_area(pi, pj), i, j))
        if not overlaps:
            ok = True
            for i in range(n):
                if sol[i][3] > 0 and not _inside_unit(_corners(*sol[i])):
                    sol[i][3] *= 0.95
                    ok = False
            if ok:
                return [tuple(s) for s in sol]
            continue
        overlaps.sort(reverse=True)
        _, i, j = overlaps[0]
        if sol[i][3] >= sol[j][3]:
            sol[i][3] *= rng.uniform(0.85, 0.95)
        else:
            sol[j][3] *= rng.uniform(0.85, 0.95)
        idx = i if rng.random() < 0.5 else j
        sol[idx][0] = min(1.0, max(0.0, sol[idx][0] + rng.uniform(-0.02, 0.02)))
        sol[idx][1] = min(1.0, max(0.0, sol[idx][1] + rng.uniform(-0.02, 0.02)))
    return [tuple(s) for s in sol]


# ---------- generators ----------

def _grid(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
           for i in range(k) for j in range(k)]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]


def _side_grid(n, rng):
    """k x k grid plus a sub-grid in the leftover strip.

    For n = k*k + m we place a k x k grid of side 1/k on one side, and a
    smaller (k+1) x (k+1)-style grid in the remaining strip. This gives
    better packing than a plain isqrt grid for many n.
    """
    k = max(1, math.isqrt(n))
    m = n - k * k
    if m <= 0:
        return _grid(n)
    # Try a few strip placements (top, right) and sub-grid sizes.
    best = None
    best_s = -1.0
    for orient in (0, 1):
        for strip_frac in (0.35, 0.45, 0.5, 0.55, 0.65):
            # main grid occupies (1 - strip_frac) of one axis
            main = 1.0 - strip_frac
            side = main / k
            out = []
            if orient == 0:
                # strip on right
                for i in range(k):
                    for j in range(k):
                        out.append(((i + 0.5) * side,
                                    (j + 0.5) * side, 0.0, side))
                # sub-grid inside strip
                sub_k = max(1, int(math.ceil(math.sqrt(m))))
                sub_side = min(strip_frac / sub_k, 1.0 / sub_k)
                placed = 0
                for i in range(sub_k):
                    for j in range(sub_k):
                        if placed >= m:
                            break
                        cx = main + (i + 0.5) * (strip_frac / sub_k)
                        cy = (j + 0.5) * (1.0 / sub_k)
                        out.append((cx, cy, 0.0, sub_side))
                        placed += 1
                    if placed >= m:
                        break
            else:
                # strip on top
                for i in range(k):
                    for j in range(k):
                        out.append(((i + 0.5) * side,
                                    (j + 0.5) * side, 0.0, side))
                sub_k = max(1, int(math.ceil(math.sqrt(m))))
                sub_side = min(strip_frac / sub_k, 1.0 / sub_k)
                placed = 0
                for i in range(sub_k):
                    for j in range(sub_k):
                        if placed >= m:
                            break
                        cx = (i + 0.5) * (1.0 / sub_k)
                        cy = main + (j + 0.5) * (strip_frac / sub_k)
                        out.append((cx, cy, 0.0, sub_side))
                        placed += 1
                    if placed >= m:
                        break
            while len(out) < n:
                out.append((0.5, 0.5, 0.0, 0.0))
            out = out[:n]
            if _feasible(out):
                s = _score(out)
                if s > best_s:
                    best_s = s
                    best = out
    if best is None:
        return _grid(n)
    return best


def _guillotine(n, rng):
    """Recursively split the unit square into n cells, then fill each with a square."""
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        cells.sort(key=lambda c: -(c[2] * c[3]))
        x, y, w, h = cells.pop(0)
        if w >= h:
            t = rng.uniform(0.35, 0.65)
            cells.append((x, y, w * t, h))
            cells.append((x + w * t, y, w * (1 - t), h))
        else:
            t = rng.uniform(0.35, 0.65)
            cells.append((x, y, w, h * t))
            cells.append((x, y + h * t, w, h * (1 - t)))
    out = []
    for (x, y, w, h) in cells:
        s = min(w, h)
        out.append((x + w * 0.5, y + h * 0.5, 0.0, s))
    return out


def _greedy(n, rng):
    """Greedy: place squares one by one in largest available gap, axis-aligned."""
    sol = []
    for _ in range(n):
        best = None
        best_s = -1.0
        for _try in range(40):
            cx = rng.uniform(0.0, 1.0)
            cy = rng.uniform(0.0, 1.0)
            lo, hi = 0.0, 1.0
            for _ in range(20):
                mid = 0.5 * (lo + hi)
                cand = sol + [(cx, cy, 0.0, mid)]
                if _feasible(cand):
                    lo = mid
                else:
                    hi = mid
            if lo > best_s:
                best_s = lo
                best = (cx, cy, 0.0, lo)
        if best is None or best[3] <= 0:
            sol.append((0.5, 0.5, 0.0, 0.0))
        else:
            sol.append(best)
    return sol


def _rotated_grid(n, rng):
    """Grid but with some squares rotated to allow tighter packing variants."""
    base = _grid(n)
    out = []
    for cx, cy, _, s in base:
        ang = rng.choice([0.0, 0.0, 0.0, 0.125, 0.25])
        out.append((cx, cy, ang, s))
    return out


def _hybrid_grid(n, rng):
    """Grid with slight random perturbations to escape symmetric local optima."""
    base = _grid(n)
    out = []
    for cx, cy, ang, s in base:
        if s > 0:
            cx += rng.uniform(-0.02, 0.02)
            cy += rng.uniform(-0.02, 0.02)
            cx = min(1.0, max(0.0, cx))
            cy = min(1.0, max(0.0, cy))
        out.append((cx, cy, ang, s))
    return out


def _rows_layout(n, sizes):
    """Build a layout by stacking rows of squares with given sizes."""
    out = []
    y = 1.0
    for row in sizes:
        row_h = max(row) if row else 0.0
        if row_h <= 0:
            continue
        y -= row_h
        x = 0.0
        for s in row:
            out.append((x + s * 0.5, y + row_h * 0.5, 0.0, s))
            x += s
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seeded_layouts(n):
    """Deterministic candidate layouts known to be good for small n."""
    cands = []
    # Equal rows: r rows of k squares each, remainder in last row.
    for r in range(1, n + 1):
        k = n // r
        rem = n - k * r
        if k == 0:
            continue
        row = [1.0 / k] * k
        sizes = [list(row) for _ in range(r)]
        if rem:
            extra = 1.0 / (k + rem)
            sizes[-1] = [extra] * (k + rem)
            for i in range(r - 1):
                sizes[i] = [1.0 / (k + rem)] * (k + rem)
        cands.append(_rows_layout(n, sizes))

    # Hand-crafted / structured layouts for specific n.
    if n == 5:
        cands.append([
            (0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
            (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5),
            (0.5, 0.5, 0.0, 0.0),
        ])
    if n == 6:
        cands.append(_rows_layout(6, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
        cands.append(_rows_layout(6, [[1/3, 1/3, 1/3], [1/3, 1/3, 1/3]]))
        # 2 large + 4 small: 2 squares of 0.5 on top, 4 of 1/3 below
        cands.append(_rows_layout(6, [[0.5, 0.5], [1/3, 1/3, 1/3, 0.0]]))
    if n == 7:
        cands.append(_rows_layout(7, [[0.5, 0.5], [1/3, 1/3, 1/3]]))
        cands.append(_rows_layout(7, [[1/3, 1/3, 1/3], [0.5, 0.5]]))
        cands.append(_rows_layout(7, [[0.5, 0.5, 0.5], [1/4, 1/4, 1/4, 1/4]]))
    if n == 8:
        cands.append(_rows_layout(8, [[0.5, 0.5], [0.5, 0.5]]))
        cands.append(_rows_layout(8, [[1/3, 1/3, 1/3], [1/3, 1/3, 1/3]]))
    if n == 11:
        cands.append(_rows_layout(11, [[0.5, 0.5], [0.5, 0.5], [1/3, 1/3, 1/3]]))
        cands.append(_rows_layout(11, [[1/3, 1/3, 1/3], [1/3, 1/3, 1/3], [0.5, 0.5]]))
    if n == 12:
        cands.append(_rows_layout(12, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
        cands.append(_rows_layout(12, [[1/3, 1/3, 1/3], [1/3, 1/3, 1/3],
                                        [1/3, 1/3, 1/3], [1/3, 1/3, 1/3]]))
    if n == 13:
        cands.append(_rows_layout(13, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
        cands.append(_rows_layout(13, [[1/3, 1/3, 1/3], [1/3, 1/3, 1/3],
                                        [1/3, 1/3, 1/3], [1/3, 1/3, 1/3]]))
    if n == 14:
        cands.append(_rows_layout(14, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
        cands.append(_rows_layout(14, [[1/3, 1/3, 1/3], [1/3, 1/3, 1/3],
                                        [1/3, 1/3, 1/3], [1/3, 1/3, 1/3]]))
    if n == 15:
        cands.append(_rows_layout(15, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]))
        cands.append(_rows_layout(15, [[1/3, 1/3, 1/3], [1/3, 1/3, 1/3],
                                        [1/3, 1/3, 1/3], [1/3, 1/3, 1/3],
                                        [1/3, 1/3, 1/3]]))
    return cands


# ---------- deterministic polish ----------

def _polish(sol, deadline):
    """Deterministic coordinate descent: grow, slide, rotate each square.

    Uses a shrink-then-grow phase when growth stalls to unlock neighbouring
    squares.
    """
    cur = [list(t) for t in sol]
    n = len(cur)
    best_score = _score(cur)
    step_grow = 0.01
    step_move = 0.01
    improve = True
    while improve and time.time() < deadline:
        improve = False
        # Try growing each square
        for i in range(n):
            for _ in range(3):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][3] += step_grow
                if _feasible(trial):
                    cur = trial
                    improve = True
                else:
                    break
        # Try sliding each square
        for i in range(n):
            if cur[i][3] <= 0:
                continue
            for dx, dy in ((step_move, 0), (-step_move, 0),
                           (0, step_move), (0, -step_move)):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][0] = min(1.0, max(0.0, trial[i][0] + dx))
                trial[i][1] = min(1.0, max(0.0, trial[i][1] + dy))
                if _feasible(trial):
                    cur = trial
                    improve = True
        # Try small rotations
        for i in range(n):
            if cur[i][3] <= 0:
                continue
            for da in (0.02, -0.02):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][2] = (trial[i][2] + da) % 1.0
                if _feasible(trial):
                    cur = trial
                    improve = True
        new_score = _score(cur)
        if new_score > best_score + 1e-9:
            best_score = new_score
        else:
            # Shrink-then-grow: nudge a random square down, then retry growth.
            if n > 0 and time.time() < deadline:
                i = random.randrange(n)
                if cur[i][3] > 1e-3:
                    trial = [list(t) for t in cur]
                    trial[i][3] *= 0.98
                    # try to grow a neighbour
                    j = (i + 1) % n
                    trial[j][3] += step_grow
                    if _feasible(trial):
                        cur = trial
                        improve = True
            step_grow = max(0.0005, step_grow * 0.7)
            step_move = max(0.0005, step_move * 0.7)
    return [tuple(t) for t in cur]


# ---------- local search ----------

def _perturb(sol, rng, scale, n_moves=None):
    """Perturb solution with adaptive move types."""
    new = [list(t) for t in sol]
    n = len(new)
    if n_moves is None:
        n_moves = 1 + n // 3
    for _ in range(n_moves):
        i = rng.randrange(n)
        kind = rng.random()
        if kind < 0.45:
            # resize
            new[i][3] = max(0.0, new[i][3] + rng.uniform(-scale, scale))
        elif kind < 0.75:
            # move
            new[i][0] = min(1.0, max(0.0, new[i][0] + rng.uniform(-scale, scale)))
            new[i][1] = min(1.0, max(0.0, new[i][1] + rng.uniform(-scale, scale)))
        elif kind < 0.9:
            # rotate
            new[i][2] = (new[i][2] + rng.uniform(-0.125, 0.125)) % 1.0
        else:
            # coordinated move of two squares
            j = rng.randrange(n)
            dx = rng.uniform(-scale, scale)
            dy = rng.uniform(-scale, scale)
            new[i][0] = min(1.0, max(0.0, new[i][0] + dx))
            new[i][1] = min(1.0, max(0.0, new[i][1] + dy))
            new[j][0] = min(1.0, max(0.0, new[j][0] + dx))
            new[j][1] = min(1.0, max(0.0, new[j][1] + dy))
    return [tuple(t) for t in new]


def _swap_perturb(sol, rng, scale):
    """Relocate one square to a random free position, keeping its size."""
    new = [list(t) for t in sol]
    n = len(new)
    if n == 0:
        return [tuple(t) for t in new]
    i = rng.randrange(n)
    for _ in range(5):
        cx = rng.uniform(0.05, 0.95)
        cy = rng.uniform(0.05, 0.95)
        trial = [list(t) for t in new]
        trial[i][0] = cx
        trial[i][1] = cy
        if _feasible(trial):
            new = trial
            break
    return [tuple(t) for t in new]


def _local_search(sol, rng, deadline, use_repair=True):
    """Adaptive local search with restarts and swap moves."""
    best = [t for t in sol]
    best_score = _score(best)
    cur = list(best)
    cur_score = best_score
    scale = 0.05
    it = 0
    stagnation = 0
    max_stagnation = 400
    while time.time() < deadline:
        it += 1
        stagnation += 1
        n_moves = 1 + rng.randrange(max(1, len(sol) // 2))
        # Occasionally use a swap move instead of a perturbation.
        if rng.random() < 0.15 and len(sol) >= 3:
            cand = _swap_perturb(cur, rng, scale)
        else:
            cand = _perturb(cur, rng, scale, n_moves)
        if _feasible(cand):
            cs = _score(cand)
            if cs >= cur_score - 1e-9:
                cur, cur_score = cand, cs
                if cs > best_score:
                    best, best_score = cand, cs
                    stagnation = 0
            elif use_repair:
                repaired = _repair(cand, rng, max_iter=20)
                if _feasible(repaired):
                    rs = _score(repaired)
                    if rs > best_score:
                        best, best_score = repaired, rs
                        cur, cur_score = repaired, rs
                        stagnation = 0
        if it % 200 == 0:
            scale = max(0.005, scale * 0.97)
        if stagnation > max_stagnation:
            # Restart from a fresh perturbation of the global best.
            cur = _perturb(best, rng, scale * 2, len(sol))
            if not _feasible(cur):
                cur = [t for t in best]
            cur_score = _score(cur)
            stagnation = 0
            scale = min(0.1, scale * 1.5)
    return best


# ---------- orchestrator ----------

def solve(n):
    rng = random.Random(12345 + n)
    deadline = time.time() + 8.0  # leave headroom under 60s limit

    candidates = []

    # Deterministic seeded layouts first (strong for small n).
    for c in _seeded_layouts(n):
        candidates.append(c)

    # Always include the simple grid and the side-grid variant.
    candidates.append(_grid(n))
    try:
        candidates.append(_side_grid(n, rng))
    except Exception:
        pass

    # Stochastic generators.
    for _ in range(3):
        candidates.append(_guillotine(n, rng))
    for _ in range(2):
        candidates.append(_greedy(n, rng))
    candidates.append(_rotated_grid(n, rng))
    candidates.append(_hybrid_grid(n, rng))

    # Repair / verify.
    feasible = []
    for c in candidates:
        c = list(c) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(c))
        c = c[:n]
        if _feasible(c):
            feasible.append(c)
        else:
            repaired = _repair(c, rng, max_iter=80)
            if _feasible(repaired):
                feasible.append(repaired)

    if not feasible:
        feasible = [_grid(n)]

    # Sort by initial score and keep the top candidates (with diversity).
    feasible.sort(key=_score, reverse=True)
    keep = feasible[:max(3, len(feasible) // 2)]
    if _grid(n) not in keep:
        keep.append(_grid(n))

    # Time budget: 35% initial search, 25% polish, 40% final search.
    total_time = max(0.5, deadline - time.time())
    search_deadline = time.time() + total_time * 0.35
    polish_deadline = time.time() + total_time * 0.25
    final_deadline = deadline

    # Improve each kept candidate briefly.
    improved = []
    per = max(0.4, (search_deadline - time.time()) / max(1, len(keep)))
    for c in keep:
        sub_deadline = min(search_deadline, time.time() + per)
        improved.append(_local_search(c, rng, sub_deadline))

    improved.sort(key=_score, reverse=True)
    best = improved[0]

    # Deterministic polish on the current best.
    polished = _polish(best, polish_deadline)
    if _score(polished) > _score(best):
        best = polished

    # Final stochastic search starting from the polished best.
    best = _local_search(best, rng, final_deadline)

    # Final polish with remaining time.
    polished = _polish(best, deadline)
    if _score(polished) > _score(best):
        best = polished

    # Ensure exactly n entries, all within [0,1].
    out = []
    for cx, cy, ang, s in best:
        out.append((min(1.0, max(0.0, cx)),
                    min(1.0, max(0.0, cy)),
                    ang % 1.0,
                    max(0.0, s)))
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]
# EVOLVE-BLOCK-END