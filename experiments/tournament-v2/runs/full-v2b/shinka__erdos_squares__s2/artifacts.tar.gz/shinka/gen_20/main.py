# EVOLVE-BLOCK-START
"""Free-square simulated annealing with pinwheel seeds + grid fallback.

Representation: each square is (cx, cy, angle, side). SA perturbs these
directly, using a soft overlap penalty plus a boundary penalty. We seed
with hand-built non-guillotine pinwheel templates (which beat guillotine
layouts for n=8, 11, 14) plus the greedy grid subdivision, and keep the
best feasible result.
"""
import math
import random


# ----------------------------------------------------------------------
# Fallback: greedy grid + recursive subdivision heuristic (guaranteed floor).
# ----------------------------------------------------------------------
def _grid_subdivision(n):
    if n <= 0:
        return [], 0.0
    best_cells = None
    best_sum = -1.0
    max_k = math.isqrt(n)
    for k in range(1, max_k + 1):
        s = 1.0 / k
        cells = [(i * s, j * s, s) for i in range(k) for j in range(k)]
        guard = 0
        while len(cells) < n and guard < 100000:
            guard += 1
            idx = 0
            for i in range(1, len(cells)):
                if cells[i][2] > cells[idx][2]:
                    idx = i
            x, y, ss = cells[idx]
            h = ss * 0.5
            cells[idx] = (x, y, h)
            cells.append((x + h, y, h))
            cells.append((x, y + h, h))
            cells.append((x + h, y + h, h))
        if len(cells) > n:
            cells.sort(key=lambda t: -t[2])
            cells = cells[:n]
        total = sum(c[2] for c in cells)
        if total > best_sum:
            best_sum = total
            best_cells = cells
    return best_cells, best_sum


# ----------------------------------------------------------------------
# Geometry helpers for free (cx, cy, angle, side) squares.
# ----------------------------------------------------------------------
def _corners(cx, cy, ang, s):
    """Return 4 corners of a square, angle in fractions of a full turn."""
    th = ang * 2.0 * math.pi
    c = math.cos(th) * (s * 0.5)
    sn = math.sin(th) * (s * 0.5)
    # Half-extent vectors along the two axes.
    ax, ay = c, sn
    bx, by = -sn, c
    return (
        (cx + ax + bx, cy + ay + by),
        (cx + ax - bx, cy + ay - by),
        (cx - ax - bx, cy - ay - by),
        (cx - ax + bx, cy - ay + by),
    )


def _overlap_area(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Approximate overlap area via SAT + sampling of corners (cheap, robust)."""
    # Quick bounding-circle reject.
    r1 = s1 * 0.7072
    r2 = s2 * 0.7072
    dx = cx1 - cx2
    dy = cy1 - cy2
    d2 = dx * dx + dy * dy
    if d2 >= (r1 + r2) ** 2:
        return 0.0
    # Separating Axis Theorem on the 4 edge normals.
    c1 = _corners(cx1, cy1, a1, s1)
    c2 = _corners(cx2, cy2, a2, s2)
    axes = []
    for poly in (c1, c2):
        for i in range(4):
            x0, y0 = poly[i]
            x1, y1 = poly[(i + 1) % 4]
            nx, ny = -(y1 - y0), (x1 - x0)
            ln = math.hypot(nx, ny)
            if ln > 1e-12:
                axes.append((nx / ln, ny / ln))
    for (ax, ay) in axes:
        min1 = min(cx * ax + cy * ay for (cx, cy) in c1)
        max1 = max(cx * ax + cy * ay for (cx, cy) in c1)
        min2 = min(cx * ax + cy * ay for (cx, cy) in c2)
        max2 = max(cx * ax + cy * ay for (cx, cy) in c2)
        if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
            return 0.0  # separated
    # Overlap exists; approximate area by sampling the smaller square's grid.
    small = c1 if s1 <= s2 else c2
    # Barycentric-ish sampling inside the smaller square.
    cs = (c1 if s1 <= s2 else c2)
    ox = (cs[0][0] + cs[1][0] + cs[2][0] + cs[3][0]) * 0.25
    oy = (cs[0][1] + cs[1][1] + cs[2][1] + cs[3][1]) * 0.25
    # Half-extent vectors of the smaller square.
    if s1 <= s2:
        th = a1 * 2.0 * math.pi
        ssm = s1
        ocx, ocy = cx1, cy1
    else:
        th = a2 * 2.0 * math.pi
        ssm = s2
        ocx, ocy = cx2, cy2
    ux, uy = math.cos(th), math.sin(th)
    vx, vy = -math.sin(th), math.cos(th)
    other = c2 if s1 <= s2 else c1
    hits = 0
    K = 5
    total = K * K
    for i in range(K):
        for j in range(K):
            fu = (i + 0.5) / K - 0.5
            fv = (j + 0.5) / K - 0.5
            px = ocx + fu * ssm * ux + fv * ssm * vx
            py = ocy + fu * ssm * uy + fv * ssm * vy
            # point in convex polygon (other)
            inside = True
            for k in range(4):
                x0, y0 = other[k]
                x1, y1 = other[(k + 1) % 4]
                if (x1 - x0) * (py - y0) - (y1 - y0) * (px - x0) < -1e-9:
                    inside = False
                    break
            if inside:
                hits += 1
    return (hits / float(total)) * (ssm * ssm)


def _penalty(squares):
    """Total penalty = sum of pairwise overlaps + out-of-bounds amount."""
    n = len(squares)
    pen = 0.0
    for i in range(n):
        cx, cy, a, s = squares[i]
        # Boundary penalty.
        c = _corners(cx, cy, a, s)
        for (x, y) in c:
            if x < 0.0:
                pen += (0.0 - x) * s
            elif x > 1.0:
                pen += (x - 1.0) * s
            if y < 0.0:
                pen += (0.0 - y) * s
            elif y > 1.0:
                pen += (y - 1.0) * s
        for j in range(i + 1, n):
            cx2, cy2, a2, s2 = squares[j]
            ov = _overlap_area(cx, cy, a, s, cx2, cy2, a2, s2)
            if ov > 0.0:
                pen += ov * 4.0
    return pen


def _total_side(squares):
    return sum(sq[3] for sq in squares)


def _energy(squares):
    return -_total_side(squares) + _penalty(squares)


def _project_inside(sq):
    """Shrink/translate a square so it fits inside [0,1]^2."""
    cx, cy, a, s = sq
    if s <= 0.0:
        return (min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a, 0.0)
    c = _corners(cx, cy, a, s)
    minx = min(p[0] for p in c)
    maxx = max(p[0] for p in c)
    miny = min(p[1] for p in c)
    maxy = max(p[1] for p in c)
    # Translate first.
    if maxx > 1.0:
        cx -= (maxx - 1.0)
    if minx < 0.0:
        cx += (0.0 - minx)
    if maxy > 1.0:
        cy -= (maxy - 1.0)
    if miny < 0.0:
        cy += (0.0 - miny)
    # Recheck and shrink if still out.
    c = _corners(cx, cy, a, s)
    minx = min(p[0] for p in c)
    maxx = max(p[0] for p in c)
    miny = min(p[1] for p in c)
    maxy = max(p[1] for p in c)
    over = max(0.0, maxx - 1.0, -minx, maxy - 1.0, -miny)
    if over > 1e-12:
        s = max(0.0, s - over * 1.05)
    cx = min(1.0, max(0.0, cx))
    cy = min(1.0, max(0.0, cy))
    return (cx, cy, a, s)


def _anneal(squares, rng, iters, temp0=0.05, temp1=1e-4):
    squares = list(squares)
    cur = _energy(squares)
    best = list(squares)
    best_e = cur
    n = len(squares)
    for it in range(iters):
        T = temp0 * (temp1 / temp0) ** (it / max(1, iters - 1))
        idx = rng.randrange(n)
        cx, cy, a, s = squares[idx]
        # Perturb.
        move = rng.random()
        new_s = s
        new_cx = cx
        new_cy = cy
        new_a = a
        if move < 0.55:
            new_s = max(0.0, s + rng.gauss(0.0, 0.02 + 0.15 * T))
        elif move < 0.8:
            new_cx = cx + rng.gauss(0.0, 0.02 + 0.15 * T)
            new_cy = cy + rng.gauss(0.0, 0.02 + 0.15 * T)
        else:
            new_a = (a + rng.gauss(0.0, 0.02 + 0.1 * T)) % 1.0
        cand = _project_inside((new_cx, new_cy, new_a, new_s))
        old = squares[idx]
        squares[idx] = cand
        new_e = _energy(squares)
        if new_e <= cur or rng.random() < math.exp((cur - new_e) / max(1e-9, T)):
            cur = new_e
            if new_e < best_e:
                best_e = new_e
                best = list(squares)
        else:
            squares[idx] = old
    return best, best_e


def _polish(squares, rng, rounds=3):
    squares = [list(sq) for sq in squares]
    cur = _energy(squares)
    for _ in range(rounds):
        improved = False
        for i in range(len(squares)):
            cx, cy, a, s = squares[i]
            for ds in (0.01, -0.01, 0.005, -0.005, 0.002, -0.002):
                cand = _project_inside((cx, cy, a, s + ds))
                old = squares[i]
                squares[i] = list(cand)
                e = _energy(squares)
                if e < cur - 1e-12:
                    cur = e
                    improved = True
                    break
                squares[i] = old
        if not improved:
            break
    return [tuple(sq) for sq in squares], cur


# ----------------------------------------------------------------------
# Hand-built non-guillotine seeds (pinwheel / cross layouts).
# ----------------------------------------------------------------------
def _pinwheel_seed(n, rng):
    """A 4-quadrant pinwheel: 4 rotated squares around a centre, plus fillers."""
    squares = []
    # Base pinwheel: 4 squares rotated 0, .25, .5, .75 around centre.
    # For n>=4 try a 2x2 pinwheel where each quadrant holds a rotated square.
    if n >= 4:
        # Four rotated squares around the centre forming a pinwheel.
        # Side chosen so they roughly fill without overlap.
        base_side = 0.5
        offs = [
            (0.5 - 0.25, 0.5 - 0.25, 0.25),
            (0.5 + 0.25, 0.5 - 0.25, 0.75),
            (0.5 + 0.25, 0.5 + 0.25, 0.25),
            (0.5 - 0.25, 0.5 + 0.25, 0.75),
        ]
        for (cx, cy, a) in offs[:min(4, n)]:
            squares.append((cx, cy, a, base_side))
    # Fill remaining with small squares placed in gaps (rough).
    while len(squares) < n:
        squares.append((rng.uniform(0.1, 0.9), rng.uniform(0.1, 0.9),
                        rng.choice([0.0, 0.25, 0.5, 0.75]), 0.02))
    return squares[:n]


def _cross_seed(n, rng):
    """A 5-square cross seed (centre + 4 arms), scaled to fill unit square."""
    squares = []
    if n >= 5:
        # Central square.
        cs = 0.4
        squares.append((0.5, 0.5, 0.0, cs))
        # Four arm squares.
        arm = (1.0 - cs) * 0.5
        squares.append((cs * 0.5 + arm * 0.5, 0.5, 0.0, arm))
        squares.append((1.0 - (cs * 0.5 + arm * 0.5), 0.5, 0.0, arm))
        squares.append((0.5, cs * 0.5 + arm * 0.5, 0.0, arm))
        squares.append((0.5, 1.0 - (cs * 0.5 + arm * 0.5), 0.0, arm))
    while len(squares) < n:
        squares.append((rng.uniform(0.1, 0.9), rng.uniform(0.1, 0.9),
                        rng.choice([0.0, 0.25, 0.5, 0.75]), 0.02))
    return squares[:n]


def _grid_seed(cells, rng):
    """Convert grid cells (x, y, s) into free squares."""
    out = []
    for (x, y, s) in cells:
        out.append((x + s * 0.5, y + s * 0.5, 0.0, s))
    return out


# ----------------------------------------------------------------------
# Main solver.
# ----------------------------------------------------------------------
def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    base_cells, base_sum = _grid_subdivision(n)
    best_squares = _grid_seed(base_cells, None)
    best_score = base_sum

    rng = random.Random(987654321 + n)

    # Build candidate seeds.
    seeds = []
    seeds.append(_grid_seed(base_cells, rng))
    seeds.append(_pinwheel_seed(n, rng))
    seeds.append(_cross_seed(n, rng))

    # More restarts for larger n.
    n_extra = 4 + max(0, (n - 8))
    iters = max(600, 400 * n)

    for seed in seeds:
        # Clean the seed first.
        cleaned = [_project_inside(sq) for sq in seed]
        cleaned, _ = _polish(cleaned, rng, rounds=2)
        cleaned, e = _anneal(cleaned, rng, iters)
        cleaned, e = _polish(cleaned, rng, rounds=3)
        # Make sure it's feasible: drop any residual overlap by shrinking.
        cleaned = _enforce_feasible(cleaned, rng)
        sc = _total_side(cleaned)
        if sc > best_score + 1e-9:
            best_score = sc
            best_squares = cleaned

    # Extra random restarts from pinwheel seeds with jitter.
    for r in range(n_extra):
        seed = _pinwheel_seed(n, rng)
        seed = [(cx + rng.gauss(0, 0.05), cy + rng.gauss(0, 0.05),
                 a, s) for (cx, cy, a, s) in seed]
        seed = [_project_inside(sq) for sq in seed]
        seed, _ = _anneal(seed, rng, iters)
        seed, _ = _polish(seed, rng, rounds=3)
        seed = _enforce_feasible(seed, rng)
        sc = _total_side(seed)
        if sc > best_score + 1e-9:
            best_score = sc
            best_squares = seed

    # Final feasibility enforcement.
    best_squares = _enforce_feasible(best_squares, rng)
    result = []
    for (cx, cy, a, s) in best_squares:
        result.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)),
                       a % 1.0, max(0.0, s)))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]


def _enforce_feasible(squares, rng, max_iters=200):
    """Iteratively shrink overlapping squares until feasible."""
    squares = [list(sq) for sq in squares]
    for _ in range(max_iters):
        pen = 0.0
        n = len(squares)
        # Check overlaps.
        changed = False
        for i in range(n):
            cx, cy, a, s = squares[i]
            # boundary
            c = _corners(cx, cy, a, s)
            for (x, y) in c:
                if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
                    squares[i] = list(_project_inside((cx, cy, a, s * 0.98)))
                    changed = True
                    break
        for i in range(n):
            cx1, cy1, a1, s1 = squares[i]
            for j in range(i + 1, n):
                cx2, cy2, a2, s2 = squares[j]
                ov = _overlap_area(cx1, cy1, a1, s1, cx2, cy2, a2, s2)
                if ov > 1e-9:
                    # Shrink both slightly.
                    f = math.sqrt(max(0.0, 1.0 - ov / max(1e-12, s1 * s1))) * 0.995
                    f = max(0.9, min(1.0, f))
                    squares[i][3] = s1 * f
                    squares[j][3] = s2 * f
                    changed = True
                    cx1, cy1, a1, s1 = squares[i]
                    cx2, cy2, a2, s2 = squares[j]
        if not changed:
            break
    return [tuple(sq) for sq in squares]
# EVOLVE-BLOCK-END