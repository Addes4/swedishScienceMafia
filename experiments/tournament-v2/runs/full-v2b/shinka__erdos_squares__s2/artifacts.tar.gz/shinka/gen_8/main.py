# EVOLVE-BLOCK-START
"""Layered portfolio optimizer for packing squares in the unit square.

Architecture (two-phase pipeline):
  1. EXPLORE: generate many cheap candidate seeds (grid, rows, guillotine,
     greedy, rotated). Evaluate quickly. Pick the best K.
  2. EXPLOIT: on the best seed, run a deterministic "grow-from-scratch"
     solver that inserts squares into the largest free corner and then
     push-grows all squares. Follow with stochastic local search and a
     final deterministic polish.

Key structural change: feasibility is cached in a Feas object, and the
core solver builds layouts by insertion rather than perturbing an existing
layout. This is much stronger for small n.
"""
import math
import random
import time


# =====================================================================
# Geometry + feasibility (cached)
# =====================================================================

def _corners(cx, cy, ang, s):
    h = s * 0.5
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    return [
        (cx - h * ca + h * sa, cy - h * sa - h * ca),
        (cx + h * ca + h * sa, cy + h * sa - h * ca),
        (cx + h * ca - h * sa, cy + h * sa + h * ca),
        (cx - h * ca - h * sa, cy - h * sa + h * ca),
    ]


def _overlap_axes(p1, p2):
    for poly in (p1, p2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ax, ay = -(y2 - y1), (x2 - x1)
            n = math.hypot(ax, ay)
            if n == 0:
                continue
            ax, ay = ax / n, ay / n
            a1 = [x * ax + y * ay for x, y in p1]
            a2 = [x * ax + y * ay for x, y in p2]
            if max(a1) <= min(a2) + 1e-12 or max(a2) <= min(a1) + 1e-12:
                return False
    return True


def _inside_unit(pts):
    for x, y in pts:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _score(sol):
    return sum(max(0.0, s) for _, _, _, s in sol)


def _overlap_area(p1, p2):
    x1a = min(p[0] for p in p1); x1b = max(p[0] for p in p1)
    y1a = min(p[1] for p in p1); y1b = max(p[1] for p in p1)
    x2a = min(p[0] for p in p2); x2b = max(p[0] for p in p2)
    y2a = min(p[1] for p in p2); y2b = max(p[1] for p in p2)
    w = max(0.0, min(x1b, x2b) - max(x1a, x2a))
    h = max(0.0, min(y1b, y2b) - max(y1a, y2a))
    return w * h


class Feas:
    """Feasibility checker with a per-call corner cache."""

    __slots__ = ("n",)

    def __init__(self, n):
        self.n = n

    def check(self, sol):
        polys = [None] * self.n
        for i in range(self.n):
            cx, cy, ang, s = sol[i]
            if s <= 0:
                continue
            p = _corners(cx, cy, ang, s)
            if not _inside_unit(p):
                return False
            polys[i] = p
        for i in range(self.n):
            pi = polys[i]
            if pi is None:
                continue
            for j in range(i + 1, self.n):
                pj = polys[j]
                if pj is None:
                    continue
                if _overlap_axes(pi, pj):
                    return False
        return True


def _repair(sol, rng, max_iter=80):
    sol = [list(t) for t in sol]
    n = len(sol)
    for _ in range(max_iter):
        # clamp inside
        bad = False
        for i in range(n):
            if sol[i][3] <= 0:
                continue
            p = _corners(*sol[i])
            while not _inside_unit(p) and sol[i][3] > 1e-6:
                sol[i][3] *= 0.9
                p = _corners(*sol[i])
                bad = True
        # find overlaps
        overlaps = []
        for i in range(n):
            if sol[i][3] <= 0:
                continue
            pi = _corners(*sol[i])
            for j in range(i + 1, n):
                if sol[j][3] <= 0:
                    continue
                pj = _corners(*sol[j])
                if _overlap_axes(pi, pj):
                    overlaps.append((_overlap_area(pi, pj), i, j))
        if not overlaps and not bad:
            return [tuple(s) for s in sol]
        if overlaps:
            overlaps.sort(reverse=True)
            _, i, j = overlaps[0]
            if sol[i][3] >= sol[j][3]:
                sol[i][3] *= rng.uniform(0.85, 0.95)
            else:
                sol[j][3] *= rng.uniform(0.85, 0.95)
            k = i if rng.random() < 0.5 else j
            sol[k][0] = min(1.0, max(0.0, sol[k][0] + rng.uniform(-0.02, 0.02)))
            sol[k][1] = min(1.0, max(0.0, sol[k][1] + rng.uniform(-0.02, 0.02)))
    return [tuple(s) for s in sol]


# =====================================================================
# Candidate generators (EXPLORE phase)
# =====================================================================

def _grid(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
           for i in range(k) for j in range(k)]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]


def _rows_layout(n, sizes):
    out = []
    y = 1.0
    for row in sizes:
        rh = max(row) if row else 0.0
        if rh <= 0:
            continue
        y -= rh
        x = 0.0
        for s in row:
            out.append((x + s * 0.5, y + rh * 0.5, 0.0, s))
            x += s
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seeded_layouts(n):
    """Deterministic row-based layouts covering the common good patterns."""
    cands = []
    # Uniform k-per-row layouts
    for r in range(1, n + 1):
        k = n // r
        if k == 0:
            continue
        rem = n - k * r
        sizes = [[1.0 / k] * k for _ in range(r)]
        if rem:
            sizes[-1] = [1.0 / (k + rem)] * (k + rem)
        cands.append(_rows_layout(n, sizes))
    # Mixed-size patterns that beat uniform rows for several small n.
    patterns = {
        5:  [[0.5, 0.5], [1/3, 1/3, 1/3]],
        6:  [[0.5, 0.5, 0.5], [0.5, 0.5, 0.5]],
        7:  [[0.5, 0.5], [0.5, 0.5], [1/3, 1/3, 1/3]],
        8:  [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5]],
        9:  [[1/3, 1/3, 1/3]] * 3,
        10: [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5]],
        11: [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [1/3, 1/3, 1/3]],
        12: [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5]],
        13: [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [1/3, 1/3, 1/3]],
        14: [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5]],
        15: [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5], [0.5, 0.5]],
    }
    if n in patterns:
        cands.append(_rows_layout(n, patterns[n]))
    # Also try 3-row patterns for n in 11..15
    if 11 <= n <= 15:
        for r in (2, 3, 4):
            k = n // r
            if k == 0:
                continue
            rem = n - k * r
            sizes = [[1.0 / k] * k for _ in range(r)]
            if rem:
                sizes[-1] = [1.0 / (k + rem)] * (k + rem)
            cands.append(_rows_layout(n, sizes))
    return cands


def _guillotine(n, rng):
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        cells.sort(key=lambda c: -(c[2] * c[3]))
        x, y, w, h = cells.pop(0)
        if w >= h:
            t = rng.uniform(0.35, 0.65)
            cells.append((x, y, w * t, h))
            cells.append((x + w * t, y, w * (1 - t), h))
        else:
            t = rng.uniform(0.35, 0.65)
            cells.append((x, y, w, h * t))
            cells.append((x, y + h * t, w, h * (1 - t)))
    return [(x + w * 0.5, y + h * 0.5, 0.0, min(w, h)) for (x, y, w, h) in cells]


def _greedy(n, rng, feas):
    sol = []
    for _ in range(n):
        best_s = -1.0
        best = (0.5, 0.5, 0.0, 0.0)
        for _try in range(24):
            cx = rng.uniform(0.02, 0.98)
            cy = rng.uniform(0.02, 0.98)
            lo, hi = 0.0, 1.0
            for _ in range(16):
                mid = 0.5 * (lo + hi)
                cand = sol + [(cx, cy, 0.0, mid)]
                if feas.check(cand):
                    lo = mid
                else:
                    hi = mid
            if lo > best_s:
                best_s = lo
                best = (cx, cy, 0.0, lo)
        sol.append(best)
    return sol


def _rotated_grid(n, rng):
    base = _grid(n)
    out = []
    for cx, cy, _, s in base:
        ang = rng.choice([0.0, 0.0, 0.0, 0.125, 0.25])
        out.append((cx, cy, ang, s))
    return out


# =====================================================================
# Grow-from-scratch solver (EXPLOIT phase, deterministic)
# =====================================================================

def _grow_solver(n, feas, rng, deadline):
    """Build a packing by repeatedly inserting the largest square that fits
    into the most promising free corner, then push-grow all squares."""
    # Start from a small seed square in the bottom-left corner.
    # We'll use a scan over candidate positions to find the largest free spot.
    best_sol = None
    best_score = -1.0

    for _restart in range(4):
        if time.time() > deadline:
            break
        # Build incrementally: at each step, scan a fine grid of candidate
        # positions and choose the one allowing the largest new square.
        sol = []
        # Seed with one square
        seed = (0.5, 0.5, 0.0, 0.5)
        if feas.check([seed]):
            sol.append(seed)
        else:
            sol.append((0.5, 0.5, 0.0, 0.25))

        steps = max(0, n - 1)
        for _step in range(steps):
            if time.time() > deadline:
                break
            # candidate positions: coarse grid with jitter
            best_pos = None
            best_s = -1.0
            grid_k = 7
            for gi in range(grid_k):
                for gj in range(grid_k):
                    cx = (gi + 0.5) / grid_k + rng.uniform(-0.03, 0.03)
                    cy = (gj + 0.5) / grid_k + rng.uniform(-0.03, 0.03)
                    cx = min(0.98, max(0.02, cx))
                    cy = min(0.98, max(0.02, cy))
                    # binary search largest s
                    lo, hi = 0.0, 0.5
                    for _ in range(14):
                        mid = 0.5 * (lo + hi)
                        cand = sol + [(cx, cy, 0.0, mid)]
                        if feas.check(cand):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_pos = (cx, cy)
            if best_pos is None or best_s <= 1e-6:
                sol.append((0.5, 0.5, 0.0, 0.0))
            else:
                sol.append((best_pos[0], best_pos[1], 0.0, best_s))

        # pad to n
        while len(sol) < n:
            sol.append((0.5, 0.5, 0.0, 0.0))
        sol = sol[:n]

        # Push-grow: try to grow every square, then shrink offenders.
        sol = _push_grow(sol, feas, rng, deadline)

        sc = _score(sol)
        if sc > best_score:
            best_score = sc
            best_sol = sol

    if best_sol is None:
        best_sol = _grid(n)
    return best_sol


def _push_grow(sol, feas, rng, deadline, iters=6):
    """Grow all squares slightly, then shrink only the ones that overlap."""
    cur = [list(t) for t in sol]
    n = len(cur)
    for _ in range(iters):
        if time.time() > deadline:
            break
        # grow every positive square
        trial = [list(t) for t in cur]
        for i in range(n):
            if trial[i][3] > 0:
                trial[i][3] *= 1.03
        # shrink offenders until feasible
        for _ in range(60):
            if feas.check(trial):
                break
            # find worst overlap
            worst = None
            worst_area = -1.0
            polys = [None] * n
            for i in range(n):
                if trial[i][3] > 0:
                    polys[i] = _corners(*trial[i])
            for i in range(n):
                if polys[i] is None:
                    continue
                for j in range(i + 1, n):
                    if polys[j] is None:
                        continue
                    if _overlap_axes(polys[i], polys[j]):
                        a = _overlap_area(polys[i], polys[j])
                        if a > worst_area:
                            worst_area = a
                            worst = (i, j)
            if worst is None:
                # boundary violation
                for i in range(n):
                    if trial[i][3] > 0 and not _inside_unit(_corners(*trial[i])):
                        trial[i][3] *= 0.9
                continue
            i, j = worst
            if trial[i][3] >= trial[j][3]:
                trial[i][3] *= 0.9
            else:
                trial[j][3] *= 0.9
        if _score(trial) > _score(cur) and feas.check(trial):
            cur = trial
    return [tuple(t) for t in cur]


# =====================================================================
# Stochastic local search
# =====================================================================

def _perturb(sol, rng, scale, n_moves=None):
    new = [list(t) for t in sol]
    n = len(new)
    if n_moves is None:
        n_moves = 1 + n // 3
    for _ in range(n_moves):
        i = rng.randrange(n)
        kind = rng.random()
        if kind < 0.45:
            new[i][3] = max(0.0, new[i][3] + rng.uniform(-scale, scale))
        elif kind < 0.75:
            new[i][0] = min(1.0, max(0.0, new[i][0] + rng.uniform(-scale, scale)))
            new[i][1] = min(1.0, max(0.0, new[i][1] + rng.uniform(-scale, scale)))
        elif kind < 0.9:
            new[i][2] = (new[i][2] + rng.uniform(-0.125, 0.125)) % 1.0
        else:
            j = rng.randrange(n)
            dx = rng.uniform(-scale, scale)
            dy = rng.uniform(-scale, scale)
            new[i][0] = min(1.0, max(0.0, new[i][0] + dx))
            new[i][1] = min(1.0, max(0.0, new[i][1] + dy))
            new[j][0] = min(1.0, max(0.0, new[j][0] + dx))
            new[j][1] = min(1.0, max(0.0, new[j][1] + dy))
    return [tuple(t) for t in new]


def _local_search(sol, feas, rng, deadline, use_repair=True):
    best = [t for t in sol]
    best_score = _score(best)
    cur = best
    cur_score = best_score
    scale = 0.06
    it = 0
    stagnation = 0
    max_stagnation = 400

    while time.time() < deadline:
        it += 1
        stagnation += 1
        n_moves = 1 + rng.randrange(max(1, len(sol) // 2))
        cand = _perturb(cur, rng, scale, n_moves)

        if feas.check(cand):
            cs = _score(cand)
            if cs >= cur_score - 1e-9:
                cur, cur_score = cand, cs
                if cs > best_score:
                    best, best_score = cand, cs
                    stagnation = 0
            elif use_repair:
                repaired = _repair(cand, rng, max_iter=15)
                if feas.check(repaired):
                    rs = _score(repaired)
                    if rs > best_score:
                        best, best_score = repaired, rs
                        cur, cur_score = repaired, rs
                        stagnation = 0

        if it % 200 == 0:
            scale = max(0.005, scale * 0.97)

        if stagnation > max_stagnation:
            cur = _perturb(best, rng, scale * 2, len(sol))
            if not feas.check(cur):
                cur = [t for t in best]
            cur_score = _score(cur)
            stagnation = 0
            scale = min(0.1, scale * 1.5)

    return best


def _polish(sol, feas, deadline):
    cur = [list(t) for t in sol]
    n = len(cur)
    step_grow = 0.01
    step_move = 0.01
    improve = True
    while improve and time.time() < deadline:
        improve = False
        for i in range(n):
            for _ in range(3):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][3] += step_grow
                if feas.check(trial):
                    cur = trial
                    improve = True
                else:
                    break
        for i in range(n):
            if cur[i][3] <= 0:
                continue
            for dx, dy in ((step_move, 0), (-step_move, 0),
                           (0, step_move), (0, -step_move)):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][0] = min(1.0, max(0.0, trial[i][0] + dx))
                trial[i][1] = min(1.0, max(0.0, trial[i][1] + dy))
                if feas.check(trial):
                    cur = trial
                    improve = True
        for i in range(n):
            if cur[i][3] <= 0:
                continue
            for da in (0.02, -0.02):
                if time.time() >= deadline:
                    break
                trial = [list(t) for t in cur]
                trial[i][2] = (trial[i][2] + da) % 1.0
                if feas.check(trial):
                    cur = trial
                    improve = True
        if not improve:
            step_grow = max(0.0005, step_grow * 0.7)
            step_move = max(0.0005, step_move * 0.7)
    return [tuple(t) for t in cur]


# =====================================================================
# Orchestrator
# =====================================================================

def solve(n):
    rng = random.Random(12345 + n)
    feas = Feas(n)
    deadline = time.time() + 8.0

    # ---------- EXPLORE ----------
    candidates = []
    candidates.append(_grid(n))
    for c in _seeded_layouts(n):
        candidates.append(c)
    for _ in range(3):
        candidates.append(_guillotine(n, rng))
    for _ in range(2):
        candidates.append(_greedy(n, rng, feas))
    candidates.append(_rotated_grid(n, rng))

    feasible = []
    for c in candidates:
        c = list(c) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(c))
        c = c[:n]
        if feas.check(c):
            feasible.append(c)
        else:
            r = _repair(c, rng, max_iter=80)
            if feas.check(r):
                feasible.append(r)

    if not feasible:
        feasible = [_grid(n)]

    feasible.sort(key=_score, reverse=True)

    # ---------- EXPLOIT ----------
    # 1. Grow-from-scratch solver (deterministic, strong for small n)
    grow_budget = min(deadline, time.time() + 2.5)
    grow_sol = _grow_solver(n, feas, rng, grow_budget)
    if feas.check(grow_sol):
        feasible.append(grow_sol)

    # 2. Short local search on the best few seeds
    feasible.sort(key=_score, reverse=True)
    top = feasible[:3]
    per = max(0.5, (deadline - time.time()) * 0.35 / len(top))
    improved = []
    for c in top:
        sub = min(deadline, time.time() + per)
        improved.append(_local_search(c, feas, rng, sub))
    improved.sort(key=_score, reverse=True)
    best = improved[0]

    # 3. Deterministic polish
    polish_budget = min(deadline, time.time() + max(1.0, (deadline - time.time()) * 0.5))
    polished = _polish(best, feas, polish_budget)
    if _score(polished) > _score(best):
        best = polished

    # 4. Final stochastic push with remaining time
    if time.time() < deadline:
        best = _local_search(best, feas, rng, deadline)

    # 5. Final polish
    if time.time() < deadline:
        polished = _polish(best, feas, deadline)
        if _score(polished) > _score(best):
            best = polished

    # ---------- output ----------
    out = []
    for cx, cy, ang, s in best:
        out.append((min(1.0, max(0.0, cx)),
                    min(1.0, max(0.0, cy)),
                    ang % 1.0,
                    max(0.0, s)))
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]
# EVOLVE-BLOCK-END
