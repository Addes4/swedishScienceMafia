# EVOLVE-BLOCK-START
"""Penalty-based continuous optimizer for packing squares in the unit square.

Idea
----
We maximise sum of side lengths subject to (a) all squares inside [0,1]^2 and
(b) no two squares sharing interior points.  Both constraints are folded into a
single smooth-ish objective

    obj = sum(side) - LAMBDA * (pairwise_overlap + outside_penetration)

and the placement vectors (cx, cy, angle, side) are optimised with a simple
(1+1) evolution strategy: random Gaussian perturbations with an adaptive step
size and occasional annealing accepts (so we can cross small penalty ridges).

A valid rectangular-grid layout is always kept as a guaranteed fallback, and the
optimizer is seeded both from that grid and from random restarts.  Only the
standard library is used; deterministic per n.
"""

import math
import random


# ----------------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------------

def _overlap(a, b):
    """Penetration depth (>=0) between two squares via the separating axis
    theorem using the four edge normals of the two squares."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return 0.0
    ha = asz * 0.5
    hb = bsz * 0.5
    ta = 2.0 * math.pi * aa
    tb = 2.0 * math.pi * ba
    ca, sa = math.cos(ta), math.sin(ta)
    cb, sb = math.cos(tb), math.sin(tb)
    axes = ((ca, sa), (-sa, ca), (cb, sb), (-sb, cb))
    dx = bx - ax
    dy = by - ay
    best = float('inf')
    for ux, uy in axes:
        ra = (abs(ux * ca + uy * sa) + abs(ux * (-sa) + uy * ca)) * ha
        rb = (abs(ux * cb + uy * sb) + abs(ux * (-sb) + uy * cb)) * hb
        d = abs(dx * ux + dy * uy)
        pen = ra + rb - d
        if pen < best:
            best = pen
    return best if best > 0.0 else 0.0


def _outside(cx, cy, ang, side):
    """Total penetration of the four corners outside the unit square."""
    if side <= 0.0:
        return 0.0
    t = 2.0 * math.pi * ang
    c, s = math.cos(t), math.sin(t)
    h = side * 0.5
    pen = 0.0
    for sx in (h, -h):
        for sy in (h, -h):
            x = cx + c * sx - s * sy
            y = cy + s * sx + c * sy
            if x < 0.0:
                pen += -x
            elif x > 1.0:
                pen += x - 1.0
            if y < 0.0:
                pen += -y
            elif y > 1.0:
                pen += y - 1.0
    return pen


def _penalty(sqs):
    n = len(sqs)
    pen = 0.0
    for i in range(n):
        pen += _outside(*sqs[i])
        ai = sqs[i]
        for j in range(i + 1, n):
            pen += _overlap(ai, sqs[j])
    return pen


def _obj(sqs, lam):
    return sum(s[3] for s in sqs) - lam * _penalty(sqs)


# ----------------------------------------------------------------------------
# baseline: best axis-aligned rectangular grid (always valid)
# ----------------------------------------------------------------------------

def _grid_layout(n):
    best = [(0.5, 0.5, 0.0, 0.0)] * n
    best_val = 0.0
    for r in range(1, n + 1):
        for c in range(1, n - r + 1):
            if r * c > n:
                continue
            side = min(1.0 / r, 1.0 / c)
            if side * (r * c) <= best_val:
                continue
            # tile r rows x c cols of equal squares, leftover -> points
            pads = n - r * c
            layout = []
            for i in range(c):
                for j in range(r):
                    layout.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            for _ in range(pads):
                layout.append((0.5, 0.5, 0.0, 0.0))
            val = side * r * c
            if val > best_val:
                best_val = val
                best = layout
    return best, best_val


# ----------------------------------------------------------------------------
# (1+1) evolution strategy
# ----------------------------------------------------------------------------

def _step_size_for(n):
    return 0.08 if n <= 12 else (0.05 if n <= 40 else 0.03)


def _optimize(n, start, rng, iters, lam=4.0):
    cur = [list(s) for s in start]
    cur_o = _obj(cur, lam)
    step = _step_size_for(n)
    best = [list(s) for s in cur]
    best_o = cur_o
    T = 0.02
    for it in range(iters):
        cand = [list(s) for s in cur]
        # perturb a few squares chosen at random
        k = 1 + rng.randrange(max(1, n // 4 + 1))
        for _ in range(k):
            i = rng.randrange(n)
            if cand[i][3] <= 1e-12 and rng.random() < 0.5:
                # occasionally try to revive a dead square
                cand[i][0] = rng.random()
                cand[i][1] = rng.random()
                cand[i][2] = rng.random()
                cand[i][3] = rng.random() * step
                continue
            cand[i][0] += rng.gauss(0.0, step)
            cand[i][1] += rng.gauss(0.0, step)
            cand[i][2] += rng.gauss(0.0, step * 0.5)
            cand[i][3] += rng.gauss(0.0, step * 0.5)
            # clamp to sane ranges
            if cand[i][0] < 0.0:
                cand[i][0] = 0.0
            elif cand[i][0] > 1.0:
                cand[i][0] = 1.0
            if cand[i][1] < 0.0:
                cand[i][1] = 0.0
            elif cand[i][1] > 1.0:
                cand[i][1] = 1.0
            if cand[i][3] < 0.0:
                cand[i][3] = 0.0
            elif cand[i][3] > 1.0:
                cand[i][3] = 1.0
            cand[i][2] = cand[i][2] % 1.0
        cand_o = _obj(cand, lam)
        if cand_o >= cur_o:
            cur = cand
            cur_o = cand_o
        else:
            # annealing accept with small probability
            if T > 0.0 and (cand_o - cur_o) / max(T, 1e-9) > -20.0:
                if rng.random() < math.exp((cand_o - cur_o) / max(T, 1e-9)):
                    cur = cand
                    cur_o = cand_o
        if cur_o > best_o:
            best = [list(s) for s in cur]
            best_o = cur_o
        # adaptive step
        if it % 500 == 499:
            step *= 0.9
            T *= 0.9
            if step < 1e-4:
                step = 1e-4
    return best, best_o


def _repair(sqs):
    """Shrink/push to guarantee validity, then return list."""
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    # fix outside
    for i in range(n):
        cx, cy, ang, sz = sqs[i]
        if sz <= 0.0:
            sqs[i] = [0.5, 0.5, 0.0, 0.0]
            continue
        for _ in range(40):
            if _outside(cx, cy, ang, sz) <= 1e-9:
                break
            sz *= 0.92
        sqs[i] = [cx, cy, ang, sz]
    # fix overlaps by shrinking the smaller of each offending pair
    for _ in range(80):
        worst = 0.0
        pair = None
        for i in range(n):
            if sqs[i][3] <= 0.0:
                continue
            for j in range(i + 1, n):
                if sqs[j][3] <= 0.0:
                    continue
                p = _overlap(sqs[i], sqs[j])
                if p > worst:
                    worst = p
                    pair = (i, j)
        if worst <= 1e-8 or pair is None:
            break
        i, j = pair
        for idx in (i, j):
            sqs[idx][3] *= 0.95
    return [tuple(s) for s in sqs]


# ----------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(104729 + n)

    base, base_val = _grid_layout(n)
    base = [tuple(s) for s in base]
    best = base
    best_val = base_val
    best_pen = _penalty(base)

    # budget: smaller n can afford many more iterations
    if n <= 12:
        iters = 120000
        restarts = 3
    elif n <= 30:
        iters = 60000
        restarts = 3
    elif n <= 80:
        iters = 25000
        restarts = 2
    else:
        iters = 12000
        restarts = 1

    seeds = [base]
    for _ in range(restarts):
        r = []
        for _ in range(n):
            r.append([rng.random(), rng.random(), rng.random(), 0.2])
        # give them a naive inside/overlap repair to start feasible-ish
        seeds.append(_repair(r))

    for s0 in seeds:
        sqs, _o = _optimize(n, s0, rng, iters)
        fixed = _repair(sqs)
        pen = _penalty(fixed)
        val = sum(s[3] for s in fixed)
        if pen <= 1e-5 and val > best_val:
            best_val = val
            best = fixed

    # guarantee: never return an invalid packing
    if _penalty(best) > 1e-4:
        best = base

    if len(best) < n:
        best = list(best) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    best = best[:n]

    out = []
    for cx, cy, ang, sz in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        sz = min(max(sz, 0.0), 1.0)
        out.append((cx, cy, ang, sz))
    return out
# EVOLVE-BLOCK-END
