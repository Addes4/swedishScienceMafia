# EVOLVE-BLOCK-START
"""Grid initialisation followed by coordinate-descent refinement.

The idea: a perfect k x k grid is optimal when n is a perfect square. When n is
not a perfect square we instead place the largest k x k grid (k = floor(sqrt(n)))
and then use the leftover squares to "steal" space from the grid via a local
search. The local search moves centres / rotates / resizes squares and shrinks
any pair that overlaps, greedily growing the sum of sides.
"""
import math


def _overlap(a, b):
    """Return the penetration area between two (cx, cy, ang, s) squares.

    Uses the separating-axis theorem: for each of the 4 edge normals, find the
    gap between the projections of the two OBBs. If all gaps are positive the
    squares are disjoint. Otherwise the minimum overlap along the axes is a
    cheap proxy for penetration depth.
    """
    ax, ay, aa, as_ = a
    bx, by, ba, bs = b
    if as_ <= 0.0 or bs <= 0.0:
        return 0.0
    best = 1e30
    for (cx, cy, ang, s) in (a, b):
        pass
    # normals of both squares
    import math as _m
    normals = []
    for ang in (aa, ba):
        t = ang * 2.0 * _m.pi
        c, sn = _m.cos(t), _m.sin(t)
        normals.append((c, sn))
        normals.append((-sn, c))
    # centres
    for (nx, ny) in normals:
        ta = abs((ax - bx) * nx + (ay - by) * ny)
        ra = 0.5 * as_ * (abs(nx * _m.cos(aa * 2 * _m.pi)) + abs(nx * _m.sin(aa * 2 * _m.pi))
                          + abs(ny * _m.cos(aa * 2 * _m.pi)) + abs(ny * _m.sin(aa * 2 * _m.pi)))
        # simpler: half-diagonal projection * exact support
        ra = 0.5 * as_ * (abs(nx) + abs(ny)) * _m.sqrt(2.0)
        rb = 0.5 * bs * (abs(nx) + abs(ny)) * _m.sqrt(2.0)
        gap = ta - (ra + rb)
        if gap > 0.0:
            return 0.0
        if -gap < best:
            best = -gap
    return best


def _support(ang, nx, ny):
    """Support radius of a unit-side square with rotation ang along normal (nx,ny)."""
    t = ang * 2.0 * math.pi
    c, s = math.cos(t), math.sin(t)
    # corners at (+-0.5, +-0.5) rotated
    maxv = -1e30
    for (px, py) in ((0.5, 0.5), (0.5, -0.5), (-0.5, 0.5), (-0.5, -0.5)):
        rx = px * c - py * s
        ry = px * s + py * c
        v = rx * nx + ry * ny
        if v > maxv:
            maxv = v
    return maxv


def _penetration(sq, s, others):
    """Max penetration of square (cx,cy,ang,s) over the others (list of (cx,cy,ang))."""
    cx, cy, ang = sq
    worst = 0.0
    for (ox, oy, oang, os) in others:
        if os <= 0.0:
            continue
        t = ang * 2.0 * math.pi
        c, sn = math.cos(t), math.sin(t)
        normals = [(c, sn), (-sn, c)]
        t2 = oang * 2.0 * math.pi
        c2, s2 = math.cos(t2), math.sin(t2)
        normals.append((c2, s2))
        normals.append((-s2, c2))
        minov = 1e30
        for (nx, ny) in normals:
            dist = abs((cx - ox) * nx + (cy - oy) * ny)
            ra = _support(ang, nx, ny) * s
            rb = _support(oang, nx, ny) * os
            gap = dist - (ra + rb)
            if gap > 0.0:
                minov = 0.0
                break
            if -gap < minov:
                minov = -gap
        if minov > worst:
            worst = minov
    return worst


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square."""
    if n <= 0:
        return []
    k = math.isqrt(n)
    side = 1.0 / k if k > 0 else 1.0
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    # leftover squares placed at centre with zero size
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    if k == 0:
        squares = [(0.5, 0.5, 0.0, 1.0)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
        return squares[:n]

    # Remove some grid squares to make room for the leftovers if beneficial is
    # handled by the shrink-based local search below.
    state = [list(s) for s in squares]
    m = len(state)

    def cost(st):
        total = 0.0
        for (cx, cy, ang, s) in st:
            total += s
        pen = 0.0
        for i in range(m):
            for j in range(i + 1, m):
                a = st[i]
                b = st[j]
                if a[3] <= 0.0 or b[3] <= 0.0:
                    continue
                d = _pen_pair(a, b)
                if d > 0.0:
                    pen += d * d
        return -total + 1000.0 * pen

    def _pen_pair(a, b):
        ax, ay, aa, as_ = a
        bx, by, ba, bs = b
        t = aa * 2.0 * math.pi
        c, sn = math.cos(t), math.sin(t)
        t2 = ba * 2.0 * math.pi
        c2, s2 = math.cos(t2), math.sin(t2)
        normals = [(c, sn), (-sn, c), (c2, s2), (-s2, c2)]
        minov = 1e30
        for (nx, ny) in normals:
            dist = abs((ax - bx) * nx + (ay - by) * ny)
            ra = _support(aa, nx, ny) * as_
            rb = _support(ba, nx, ny) * bs
            gap = dist - (ra + rb)
            if gap > 0.0:
                return 0.0
            if -gap < minov:
                minov = -gap
        return minov

    def repair(st):
        """Shrink squares until no overlaps remain, keeping centres/angles."""
        for _ in range(200):
            changed = False
            for i in range(m):
                others = [st[j] for j in range(m) if j != i]
                a = st[i]
                if a[3] <= 0.0:
                    continue
                p = _penetration((a[0], a[1], a[2]), a[3], others)
                if p > 1e-9:
                    a[3] = max(0.0, a[3] - 0.5 * p)
                    changed = True
            if not changed:
                break
        # clamp to unit square
        for a in st:
            h = 0.5 * a[3] * (abs(math.cos(a[2] * 2 * math.pi)) +
                              abs(math.sin(a[2] * 2 * math.pi))) * math.sqrt(2.0)
            h = 0.5 * a[3] * (abs(math.cos(a[2] * 2 * math.pi)) +
                              abs(math.sin(a[2] * 2 * math.pi)))
            h = 0.5 * a[3] * math.sqrt(2.0)
            h = min(0.5, a[3] * 0.5 * math.sqrt(2.0))
            a[0] = min(max(a[0], h), 1.0 - h)
            a[1] = min(max(a[1], h), 1.0 - h)
        return st

    # local search
    import random
    random.seed(12345)
    best = [list(x) for x in state]
    repair(best)
    best_cost = cost(best)
    cur = [list(x) for x in best]
    steps = 4000 if n <= 16 else 2000
    scale = 0.3
    for it in range(steps):
        cand = [list(x) for x in cur]
        idx = random.randrange(m)
        cx, cy, ang, s = cand[idx]
        # perturb
        r = random.random()
        if r < 0.4:
            cx += random.uniform(-scale, scale) * 0.1
            cy += random.uniform(-scale, scale) * 0.1
        elif r < 0.6:
            ang += random.uniform(-scale, scale) * 0.1
        elif r < 0.85:
            s += random.uniform(-scale, scale) * 0.1
            s = max(0.0, min(1.0, s))
        else:
            cx += random.uniform(-scale, scale) * 0.05
            cy += random.uniform(-scale, scale) * 0.05
            s += random.uniform(-scale, scale) * 0.05
            s = max(0.0, min(1.0, s))
        cand[idx] = [cx, cy, ang, s]
        repair(cand)
        cc = cost(cand)
        if cc < best_cost or random.random() < 0.02:
            cur = cand
            if cc < best_cost:
                best_cost = cc
                best = [list(x) for x in cand]
    # final: return best with remaining zero-size squares
    out = [(a[0], a[1], a[2], a[3]) for a in best]
    return out


# EVOLVE-BLOCK-END
