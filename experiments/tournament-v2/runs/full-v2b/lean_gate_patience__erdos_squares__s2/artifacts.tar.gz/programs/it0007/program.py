# EVOLVE-BLOCK-START
"""Rectangular grid plus a recursive guillotine packer for the leftover region."""
import math


def _pack(rects, count, memo):
    """Try to place `count` squares into the list of free axis-aligned rectangles
    `rects` (each (x, y, w, h)), returning (total_side, placements) or None.
    Uses a memo keyed by a coarse state; greedy: put the biggest fitting square
    in the largest rectangle, recurse."""
    if count == 0:
        return 0.0, []
    # key for memo
    key = (count, tuple(sorted((round(w, 6), round(h, 6)) for _, _, w, h in rects)))
    if key in memo:
        return memo[key]
    # choose the rectangle with the largest min-side to host the next square
    best = None
    for idx, (rx, ry, rw, rh) in enumerate(rects):
        s = min(rw, rh)
        if s <= 1e-12:
            continue
        # place square of side s in corner of this rect, split remainder into
        # two rects (right strip and top strip), guillotine split
        cx = rx + s / 2.0
        cy = ry + s / 2.0
        rest = rects[:idx] + rects[idx + 1:]
        # split: either (right strip width rw-s, height rh) and (top strip width s, height rh-s)
        right = (rx + s, ry, rw - s, rh)
        top = (rx, ry + s, s, rh - s)
        newrects = rest + [right, top]
        newrects = [r for r in newrects if r[2] > 1e-12 and r[3] > 1e-12]
        sub = _pack(newrects, count - 1, memo)
        if sub is not None:
            total, place = sub
            cand = (s + total, [(cx, cy, 0.0, s)] + place)
            if best is None or cand[0] > best[0]:
                best = cand
    memo[key] = best
    return best


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    best = None
    best_score = -1.0

    # Try axis-aligned grids of r rows x c cols of equal squares, then fill the
    # leftover free rectangles (right and top strips) with a guillotine packer.
    for r in range(1, n + 1):
        for c in range(1, n + 1):
            if r * c > n:
                continue
            s = min(1.0 / r, 1.0 / c)
            used = r * c
            rem = n - used
            squares = []
            w = c * s
            h = r * s
            for i in range(c):
                for j in range(r):
                    squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
            if rem == 0:
                total = used * s
                if total > best_score:
                    best_score = total
                    best = squares
                continue
            # free rectangles: right strip and top strip
            free = []
            if 1.0 - w > 1e-12:
                free.append((w, 0.0, 1.0 - w, 1.0))
            if 1.0 - h > 1e-12:
                free.append((0.0, h, w, 1.0 - h))
            memo = {}
            sub = _pack(free, rem, memo)
            if sub is not None:
                extra_total, extra_place = sub
                total = used * s + extra_total
                if total > best_score:
                    best_score = total
                    best = squares + extra_place

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return [tuple(x) for x in best[:n]]
# EVOLVE-BLOCK-END
