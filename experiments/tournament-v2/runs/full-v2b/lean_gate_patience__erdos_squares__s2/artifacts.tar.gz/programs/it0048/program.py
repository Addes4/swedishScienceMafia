# EVOLVE-BLOCK-START
"""Deterministic structural seeder for squares in the unit square.

Strategy
--------
The sum of side lengths is maximised by tilings that resemble a grid: cut the
unit square into bands (horizontal or vertical), and fill each band with its
own uniform grid of equal squares.  We also include "big square + L-strip"
tilings: one large axis-aligned square in a corner plus equal squares filling
the remaining L-shaped region along two strips.

This is deterministic and produces valid packings for every n, scaling from
small n (few bands) to large n (dense grids).
"""

import math
import time


def _rot_cos_sin(angle):
    a = angle * 2.0 * math.pi
    return math.cos(a), math.sin(a)


def _half_extent(half, c, s):
    return half * (abs(c) + abs(s))


def _sep_min_dist(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    ah = 0.5 * asz
    bh = 0.5 * bsz
    ca, sa = _rot_cos_sin(aa)
    cb, sb = _rot_cos_sin(ba)
    axes = ((ca, sa), (-sa, ca), (cb, sb), (-sb, cb))
    dx = bx - ax
    dy = by - ay
    best = float('inf')
    for (ux, uy) in axes:
        dist = abs(dx * ux + dy * uy)
        ra = ah * (abs(ca * ux + sa * uy) + abs(-sa * ux + ca * uy))
        rb = bh * (abs(cb * ux + sb * uy) + abs(-sb * ux + cb * uy))
        gap = dist - (ra + rb)
        if gap < best:
            best = gap
    return best


def _total_overlap(sqs):
    n = len(sqs)
    tot = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            g = _sep_min_dist(sqs[i], sqs[j])
            if g < 0.0:
                tot += -g
    return tot


def _repair(sqs, iters):
    """Push overlapping axis-aligned squares apart; clamp to unit box."""
    n = len(sqs)
    sqs = [[float(c) for c in s] for s in sqs]
    for _ in range(iters):
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                g = _sep_min_dist(tuple(sqs[i]), tuple(sqs[j]))
                if g < -1e-9:
                    moved = True
                    dx = sqs[i][0] - sqs[j][0]
                    dy = sqs[i][1] - sqs[j][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-12:
                        dx, dy, d = 1.0, 0.0, 1.0
                    ux, uy = dx / d, dy / d
                    push = -g * 0.5 + 1e-6
                    sqs[i][0] += ux * push
                    sqs[i][1] += uy * push
                    sqs[j][0] -= ux * push
                    sqs[j][1] -= uy * push
        for i in range(n):
            cx, cy, ang, side = sqs[i]
            c, s = _rot_cos_sin(ang)
            h = 0.5 * side
            ex = _half_extent(h, c, s)
            ey = _half_extent(h, c, s)
            if ex > 0.5 or ey > 0.5:
                sc = 0.5 / max(ex, ey)
                side *= sc
                h = 0.5 * side
                ex = _half_extent(h, c, s)
                ey = _half_extent(h, c, s)
            sqs[i][0] = min(max(cx, ex), 1.0 - ex)
            sqs[i][1] = min(max(cy, ey), 1.0 - ey)
            sqs[i][3] = side
        if not moved:
            break
    return [tuple(s) for s in sqs]


def _grid_band(x0, y0, w, h, r, c):
    """Fill a w x h rectangle (bottom-left x0,y0) with r rows x c cols squares."""
    if r <= 0 or c <= 0:
        return []
    side = min(w / c, h / r)
    out = []
    totw = side * c
    toth = side * r
    ox = x0 + (w - totw) * 0.5
    oy = y0 + (h - toth) * 0.5
    for i in range(r):
        for j in range(c):
            cx = ox + (j + 0.5) * side
            cy = oy + (i + 0.5) * side
            out.append((cx, cy, 0.0, side))
    return out


def _split_candidates(rA, cA, rB, cB):
    ts = []
    for denom in (rA + rB,):
        if denom > 0:
            ts.append(rA / denom)
    for denom in (cA + cB,):
        if denom > 0:
            ts.append(cA / denom)
    for k in range(1, 10):
        ts.append(k / 10.0)
    out = []
    eps = 1e-9
    for t in ts:
        if eps < t < 1.0 - eps:
            out.append(t)
    return out


def _big_square_strip_candidates(n):
    """One large axis-aligned square in a corner plus equal squares filling
    the remaining L-shaped region along the two strips.

    The big square has side s in the bottom-left corner. The L-region consists
    of a right strip of width 1-s (full height 1) and a top strip of height 1-s
    (width s). We try to place m squares in the right strip (a column grid) and
    k squares in the top strip (a row grid), m + k = n - 1, sweeping s.
    """
    results = []
    if n < 2:
        return results
    remaining = n - 1
    # Try four corner positions (we'll reflect strips accordingly)
    for corner in range(4):
        # corner 0: BL big square, strips on right + top
        for m in range(0, remaining + 1):
            k = remaining - m
            # try s values around the ideal packing
            for t in range(1, 60):
                s = t / 60.0
                if s <= 0.0 or s >= 1.0:
                    continue
                w = 1.0 - s  # strip width
                # right strip: width w, height 1
                # place m squares in a grid r x c == m
                best_this = None
                for ra in range(1, m + 1):
                    if m and m % ra:
                        continue
                    ca = m // ra if m else 0
                    if m == 0:
                        ra, ca = 0, 0
                    for rb in range(1, k + 1):
                        if k and k % rb:
                            continue
                        cb = k // rb if k else 0
                        if k == 0:
                            rb, cb = 0, 0
                        # right strip (width w, height 1): ra rows, ca cols
                        right = _grid_band(1.0 - w, 0.0, w, 1.0, ra, ca) if m else []
                        # top strip (width s, height w): rb rows, cb cols
                        top = _grid_band(0.0, 1.0 - w, s, w, rb, cb) if k else []
                        sqs = [(s / 2, s / 2, 0.0, s)] + right + top
                        if len(sqs) != n:
                            continue
                        sc = _score(sqs)
                        if best_this is None or sc > best_this[0]:
                            best_this = (sc, sqs)
                if best_this is not None:
                    results.append(best_this[1])
    # Deduplicate by transforming corners by reflection is unnecessary; keep all
    return results


def _candidate_tilings(n):
    results = []

    # Pure single grid r x c with r*c == n
    for r in range(1, n + 1):
        if n % r:
            continue
        c = n // r
        band = _grid_band(0.0, 0.0, 1.0, 1.0, r, c)
        if len(band) == n:
            results.append(band)

    # Two horizontal bands
    for a in range(1, n):
        b = n - a
        for ra in range(1, a + 1):
            if a % ra:
                continue
            ca = a // ra
            for rb in range(1, b + 1):
                if b % rb:
                    continue
                cb = b // rb
                for t in _split_candidates(ra, ca, rb, cb):
                    bottom = _grid_band(0.0, 0.0, 1.0, t, rb, cb)
                    top = _grid_band(0.0, t, 1.0, 1.0 - t, ra, ca)
                    if len(bottom) + len(top) == n:
                        results.append(bottom + top)

    # Two vertical bands
    for a in range(1, n):
        b = n - a
        for ra in range(1, a + 1):
            if a % ra:
                continue
            ca = a // ra
            for rb in range(1, b + 1):
                if b % rb:
                    continue
                cb = b // rb
                for t in _split_candidates(ca, ra, cb, rb):
                    left = _grid_band(0.0, 0.0, t, 1.0, ra, ca)
                    right = _grid_band(t, 0.0, 1.0 - t, 1.0, rb, cb)
                    if len(left) + len(right) == n:
                        results.append(left + right)

    # Big square + L-strip structures
    results.extend(_big_square_strip_candidates(n))

    return results


def _score(sqs):
    return sum(s[3] for s in sqs)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    deadline = time.time() + 50.0

    best = None
    best_score = -1e18

    # fallback single grid
    k = max(1, math.isqrt(n))
    while k * k < n:
        k += 1
    side = 1.0 / k
    best = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side)
            for i in range(n)]
    best_score = _score(best)

    cands = _candidate_tilings(n)
    for cand in cands:
        if time.time() > deadline:
            break
        if _total_overlap(cand) > 1e-9:
            cand = _repair(cand, 80)
        ov = _total_overlap(cand)
        if ov > 1e-6:
            continue
        sc = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand

    # light perturbation
    import random
    rng = random.Random(99991)
    cur = [list(s) for s in best]
    cur_score = best_score
    while time.time() < deadline:
        trial = [list(s) for s in cur]
        i = rng.randrange(n)
        trial[i][3] *= (0.9 + 0.1 * rng.random())
        trial[i][0] = min(max(trial[i][0] + (rng.random() - 0.5) * 0.05, 0.0), 1.0)
        trial[i][1] = min(max(trial[i][1] + (rng.random() - 0.5) * 0.05, 0.0), 1.0)
        trial = _repair(trial, 40)
        if _total_overlap(trial) > 1e-6:
            continue
        sc = _score(trial)
        if sc > cur_score:
            cur = trial
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = [tuple(s) for s in trial]

    out = []
    for i in range(n):
        if i < len(best):
            cx, cy, ang, sd = best[i]
        else:
            cx, cy, ang, sd = 0.0, 0.0, 0.0, 0.0
        cx = min(max(float(cx), 0.0), 1.0)
        cy = min(max(float(cy), 0.0), 1.0)
        ang = float(ang) % 1.0
        sd = min(max(float(sd), 0.0), 1.0)
        out.append((cx, cy, ang, sd))
    return out
# EVOLVE-BLOCK-END
