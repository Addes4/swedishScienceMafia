# EVOLVE-BLOCK-START
"""Packing squares in a unit square by expand-and-repair local search.

Strategy:
 - Seed with a rectangular grid (axis-aligned, guaranteed valid).
 - Then run an iterative "expand" refinement: for each square, compute the
   largest side length that still fits inside the unit square and does not
   overlap any neighbour (checked with an exact SAT separation test against
   rotated squares), and enlarge it. When enlargement is blocked, nudge
   positions apart and retry, allowing angles to vary for random restarts.
 - Track the best valid packing over several restarts.
"""

import math
import random


def _normals(angle):
    c = math.cos(2.0 * math.pi * angle)
    s = math.sin(2.0 * math.pi * angle)
    return (c, s), (-s, c)


def _overlap(a, b):
    """Penetration depth between two squares (0 if disjoint)."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return 0.0
    ha = asz * 0.5
    hb = bsz * 0.5
    (ca, sa), (na, ma) = _normals(aa)
    (cb, sb), (nb, mb) = _normals(ba)
    axes = ((ca, sa), (na, ma), (cb, sb), (nb, mb))
    dx = bx - ax
    dy = by - ay
    best = float('inf')
    for ux, uy in axes:
        ra = abs(ux * ca + uy * sa) * ha + abs(ux * na + uy * ma) * ha
        rb = abs(ux * cb + uy * sb) * hb + abs(ux * nb + uy * mb) * hb
        d = abs(dx * ux + dy * uy)
        pen = ra + rb - d
        if pen < best:
            best = pen
    return best if best > 0.0 else 0.0


def _inside_penalty(cx, cy, angle, side):
    c = math.cos(2.0 * math.pi * angle)
    s = math.sin(2.0 * math.pi * angle)
    h = side * 0.5
    pen = 0.0
    for sx, sy in ((h, h), (h, -h), (-h, h), (-h, -h)):
        x = cx + c * sx - s * sy
        y = cy + s * sx + c * sy
        if x < 0.0:
            pen += -x
        elif x > 1.0:
            pen += x - 1.0
        if y < 0.0:
            pen += -y
        elif y > 1.0:
            pen += y - 1.0
    return pen


def _total_penalty(sqs):
    n = len(sqs)
    pen = 0.0
    for i in range(n):
        pen += _inside_penalty(*sqs[i])
        for j in range(i + 1, n):
            pen += _overlap(sqs[i], sqs[j])
    return pen


def _max_size_at(cx, cy, angle, others):
    """Largest side length for a square centred at (cx,cy) with given angle,
    that stays inside the unit square and disjoint from `others`."""
    c = math.cos(2.0 * math.pi * angle)
    s = math.sin(2.0 * math.pi * angle)
    # half-extents in x and y: for a square of side L rotated by angle,
    # the axis-aligned bounding half-width is |c|*L/2 + |s|*L/2.
    ax = abs(c) + abs(s)
    # inside constraint: cx +- (ax*L/2) in [0,1]
    lim = 1e18
    if ax > 1e-12:
        lim = min(cx, 1.0 - cx) * 2.0 / ax
    lim = max(lim, 0.0)
    # separation against each other square: find max L such that no overlap.
    # SAT: for each axis, penetration ra+rb-d <= 0.
    (ca, sa), (na, ma) = _normals(angle)
    for o in others:
        ox, oy, oa, osz = o
        if osz <= 0.0:
            continue
        hb = osz * 0.5
        (cb, sb), (nb, mb) = _normals(oa)
        dx = ox - cx
        dy = oy - cy
        axes = ((ca, sa), (na, ma), (cb, sb), (nb, mb))
        # For each axis: ra + rb - d <= 0 where ra = |proj A| * L/2
        # Solve for L bounds.
        for ux, uy in axes:
            ra_coef = abs(ux * ca + uy * sa) + abs(ux * na + uy * ma)  # times L/2
            rb = abs(ux * cb + uy * sb) * hb + abs(ux * nb + uy * mb) * hb
            d = abs(dx * ux + dy * uy)
            # need (ra_coef * L/2) + rb - d <= 0  =>  L <= 2*(d - rb)/ra_coef
            if ra_coef > 1e-12:
                cap = 2.0 * (d - rb) / ra_coef
                if cap < lim:
                    lim = cap
    return max(lim, 0.0)


def _relax(sqs, steps=40):
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    for _ in range(steps):
        moved = False
        for i in range(n):
            cx, cy, ang, sz = sqs[i]
            if sz <= 0.0:
                continue
            p = _inside_penalty(cx, cy, ang, sz)
            if p > 0.0:
                dx = 0.5 - cx
                dy = 0.5 - cy
                L = math.hypot(dx, dy) or 1.0
                step = min(p * 0.5, 0.02)
                sqs[i][0] = cx + dx / L * step
                sqs[i][1] = cy + dy / L * step
                moved = True
        for i in range(n):
            for j in range(i + 1, n):
                pi = _overlap(sqs[i], sqs[j])
                if pi <= 1e-12:
                    continue
                dx = sqs[j][0] - sqs[i][0]
                dy = sqs[j][1] - sqs[i][1]
                L = math.hypot(dx, dy)
                if L < 1e-9:
                    rnd = random.random() * 2.0 * math.pi
                    dx, dy = math.cos(rnd), math.sin(rnd)
                    L = 1.0
                step = min(pi * 0.5 + 1e-5, 0.03)
                ux, uy = dx / L, dy / L
                si, sj = sqs[i][3], sqs[j][3]
                tot = si + sj or 1.0
                fi, fj = sj / tot, si / tot
                sqs[i][0] -= ux * step * fi
                sqs[i][1] -= uy * step * fi
                sqs[j][0] += ux * step * fj
                sqs[j][1] += uy * step * fj
                moved = True
        if not moved:
            break
    return sqs


def _expand_pass(sqs, rng, order=None):
    """One pass: for each square (in some order), grow it to max feasible size."""
    n = len(sqs)
    if order is None:
        order = list(range(n))
    for i in order:
        cx, cy, ang, sz = sqs[i]
        others = [sqs[j] for j in range(n) if j != i]
        maxs = _max_size_at(cx, cy, ang, others)
        if maxs > sz + 1e-9:
            sqs[i][3] = maxs
    return sqs


def _refine(sqs, rng, iters=60):
    """Iteratively expand squares and repair any residual overlaps."""
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    for it in range(iters):
        # try expanding each square (rotate angle slightly on some iterations)
        if it > 0 and rng.random() < 0.3:
            for i in range(n):
                sqs[i][2] = (sqs[i][2] + rng.uniform(-0.02, 0.02)) % 1.0
        order = list(range(n))
        rng.shuffle(order)
        _expand_pass(sqs, rng, order)
        pen = _total_penalty(sqs)
        if pen > 1e-9:
            sqs = _relax(sqs, steps=25)
            # re-run expand once after relax
            order = list(range(n))
            rng.shuffle(order)
            _expand_pass(sqs, rng, order)
        # early stop if penalty small and no progress
        if it > 5 and it % 10 == 0:
            if _total_penalty(sqs) < 1e-9:
                pass
    return sqs


def _grid_seed(n, rng=None, jitter=0.0):
    k = math.isqrt(n)
    if k < 1:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    sqs = []
    for i in range(k):
        for j in range(k):
            if len(sqs) >= n:
                break
            cx = (i + 0.5) * side
            cy = (j + 0.5) * side
            if jitter and rng:
                cx += rng.uniform(-jitter, jitter) * side
                cy += rng.uniform(-jitter, jitter) * side
            ang = 0.0
            if jitter and rng:
                ang = (rng.uniform(-0.02, 0.02)) % 1.0
            sqs.append([cx, cy, ang, side])
        if len(sqs) >= n:
            break
    # remainder squares: place small ones in corners with tiny size
    while len(sqs) < n:
        sqs.append([0.5, 0.5, 0.0, 0.0])
    return sqs


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(1000 + n)

    base = _grid_seed(n)
    best = [list(s) for s in base]
    best_val = sum(s[3] for s in base)

    # Restarts: grid seed with jitter and expand
    restarts = 8 if n <= 30 else (5 if n <= 80 else 3)
    for r in range(restarts):
        jitter = 0.0 if r == 0 else 0.3
        sqs = _grid_seed(n, rng, jitter)
        # give remainder squares a tiny positive size so expansion can grow them
        for s in sqs:
            if s[3] <= 1e-9:
                s[3] = 0.01
        # shrink any that violate inside constraint initially
        for s in sqs:
            if _inside_penalty(*s) > 1e-9:
                cx, cy, ang, sz = s
                for _ in range(20):
                    if _inside_penalty(cx, cy, ang, sz) <= 1e-9:
                        break
                    sz *= 0.8
                s[3] = sz
        sqs = _refine(sqs, rng, iters=40 if n <= 40 else 25)
        pen = _total_penalty(sqs)
        if pen > 1e-6:
            sqs = _relax(sqs, steps=50)
            sqs = _refine(sqs, rng, iters=15)
            pen = _total_penalty(sqs)
        # final validity shrink
        if pen > 1e-7:
            for _ in range(40):
                if _total_penalty(sqs) <= 1e-7:
                    break
                for i in range(n):
                    for j in range(i + 1, n):
                        if _overlap(sqs[i], sqs[j]) > 1e-7:
                            sqs[i][3] *= 0.97
                            sqs[j][3] *= 0.97
                for s in sqs:
                    if _inside_penalty(*s) > 1e-9:
                        s[3] *= 0.95
            pen = _total_penalty(sqs)
        val = sum(s[3] for s in sqs)
        if pen < 1e-5 and val > best_val:
            best_val = val
            best = [list(s) for s in sqs]

    # final safety: clamp and validate
    if _total_penalty(best) > 1e-4:
        best = [list(s) for s in _grid_seed(n)]

    if len(best) < n:
        best = best + [[0.5, 0.5, 0.0, 0.0]] * (n - len(best))
    best = best[:n]

    out = []
    for cx, cy, ang, sz in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        sz = min(max(sz, 0.0), 1.0)
        out.append((cx, cy, ang, sz))
    return out
# EVOLVE-BLOCK-END
