# EVOLVE-BLOCK-START
"""Randomized multi-start packing of squares in the unit square.

For each n we try many randomized greedy packings (largest squares first,
with random placement jitter and rotation candidates), then refine each by a
simple overlap-relaxation: repeatedly push apart overlapping pairs along the
line of centres and clamp centres inside the unit square.  The side length of
each square is also adjusted so the whole thing stays feasible.  We keep the
best total side length found.
"""
import math
import random
import time


def _corners(cx, cy, ang, s):
    """Corner points of a square (centre, angle in turns, side s)."""
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap(p, q):
    """Separating axis test for two convex quads. Returns True if interiors overlap."""
    r1 = 0.0
    r2 = 0.0
    cx1 = sum(a for a, _ in p) / 4.0
    cy1 = sum(b for _, b in p) / 4.0
    cx2 = sum(a for a, _ in q) / 4.0
    cy2 = sum(b for _, b in q) / 4.0
    for a, b in p:
        r1 = max(r1, (a - cx1) ** 2 + (b - cy1) ** 2)
    for a, b in q:
        r2 = max(r2, (a - cx2) ** 2 + (b - cy2) ** 2)
    r1 = math.sqrt(r1)
    r2 = math.sqrt(r2)
    if (cx1 - cx2) ** 2 + (cy1 - cy2) ** 2 > (r1 + r2) ** 2:
        return False
    for poly in (p, q):
        for i in range(4):
            ax, ay = poly[i]
            bx, by = poly[(i + 1) % 4]
            ex, ey = bx - ax, by - ay
            nx, ny = -ey, ex
            dmin1 = dmax1 = None
            for a, b in p:
                d = a * nx + b * ny
                if dmin1 is None or d < dmin1:
                    dmin1 = d
                if dmax1 is None or d > dmax1:
                    dmax1 = d
            dmin2 = dmax2 = None
            for a, b in q:
                d = a * nx + b * ny
                if dmin2 is None or d < dmin2:
                    dmin2 = d
                if dmax2 is None or d > dmax2:
                    dmax2 = d
            if dmax1 <= dmin2 or dmax2 <= dmin1:
                return False
    return True


def _feasible(cfg):
    polys = [_corners(cx, cy, a, s) for (cx, cy, a, s) in cfg]
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _inside(cfg):
    """Check every square is fully inside the unit square."""
    for (cx, cy, a, s) in cfg:
        if s <= 1e-12:
            if not (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0):
                return False
            continue
        pts = _corners(cx, cy, a, s)
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
        if minx < -1e-9 or maxx > 1 + 1e-9 or miny < -1e-9 or maxy > 1 + 1e-9:
            return False
    return True


def _clamp_inside(cfg):
    """Shift each square so it lies inside the unit square (reducing side if needed)."""
    out = []
    for (cx, cy, a, s) in cfg:
        if s <= 1e-12:
            out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a % 1.0, 0.0))
            continue
        # if square diagonal too large to fit, reduce side
        diag = 0.5 * s * math.sqrt(2)
        if diag > 0.5 + 1e-12:
            s = 1.0 / math.sqrt(2)
        pts = _corners(cx, cy, a, s)
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
        if maxx - minx > 1.0 + 1e-12 or maxy - miny > 1.0 + 1e-12:
            # shrink side proportionally
            scale = min(1.0 / (maxx - minx), 1.0 / (maxy - miny))
            s *= scale
            pts = _corners(cx, cy, a, s)
            minx = min(p[0] for p in pts)
            maxx = max(p[0] for p in pts)
            miny = min(p[1] for p in pts)
            maxy = max(p[1] for p in pts)
        if minx < 0:
            cx -= minx
            maxx -= minx
        if maxx > 1:
            cx -= (maxx - 1)
        if miny < 0:
            cy -= miny
            maxy -= miny
        if maxy > 1:
            cy -= (maxy - 1)
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        out.append((cx, cy, a % 1.0, s))
    return out


def _cost(cfg):
    polys = [_corners(cx, cy, a, s) for (cx, cy, a, s) in cfg]
    tot = 0.0
    n = len(polys)
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(polys[i], polys[j]):
                cx1 = sum(a for a, _ in polys[i]) / 4.0
                cy1 = sum(b for _, b in polys[i]) / 4.0
                cx2 = sum(a for a, _ in polys[j]) / 4.0
                cy2 = sum(b for _, b in polys[j]) / 4.0
                d = math.hypot(cx1 - cx2, cy1 - cy2)
                r1 = cfg[i][3] * 0.5 * math.sqrt(2)
                r2 = cfg[j][3] * 0.5 * math.sqrt(2)
                tot += max(0.0, r1 + r2 - d)
    return tot


def _relax(cfg, iters=200):
    cfg = [list(x) for x in cfg]
    n = len(cfg)
    for _ in range(iters):
        moved = False
        polys = [_corners(c[0], c[1], c[2], c[3]) for c in cfg]
        for i in range(n):
            for j in range(i + 1, n):
                si = cfg[i][3]
                sj = cfg[j][3]
                if si <= 1e-12 or sj <= 1e-12:
                    continue
                r1 = si * 0.5 * math.sqrt(2)
                r2 = sj * 0.5 * math.sqrt(2)
                dx = cfg[i][0] - cfg[j][0]
                dy = cfg[i][1] - cfg[j][1]
                d = math.hypot(dx, dy)
                if d < 1e-12:
                    dx, dy = 1.0, 0.0
                    d = 1.0
                need = r1 + r2 - d
                if need > 1e-9:
                    if _overlap(polys[i], polys[j]):
                        ux, uy = dx / d, dy / d
                        push = need * 0.5 + 1e-4
                        cfg[i][0] += ux * push
                        cfg[i][1] += uy * push
                        cfg[j][0] -= ux * push
                        cfg[j][1] -= uy * push
                        moved = True
        for c in cfg:
            if c[3] <= 1e-12:
                c[0] = min(1.0, max(0.0, c[0]))
                c[1] = min(1.0, max(0.0, c[1]))
                continue
            pts = _corners(c[0], c[1], c[2], c[3])
            minx = min(a for a, _ in pts)
            maxx = max(a for a, _ in pts)
            miny = min(b for _, b in pts)
            maxy = max(b for _, b in pts)
            if minx < 0:
                c[0] -= minx
            if maxx > 1:
                c[0] -= (maxx - 1)
            if miny < 0:
                c[1] -= miny
            if maxy > 1:
                c[1] -= (maxy - 1)
        if not moved:
            if _feasible([(c[0], c[1], c[2], c[3]) for c in cfg]):
                break
    return [(c[0], c[1], c[2], c[3]) for c in cfg]


def _shrink_to_feasible(cfg, total):
    cfg = [(c[0], c[1], c[2], c[3]) for c in cfg]
    if _feasible(cfg):
        return cfg, sum(c[3] for c in cfg)
    lo, hi = 0.0, 1.0
    for _ in range(30):
        mid = (lo + hi) * 0.5
        test = [(c[0], c[1], c[2], c[3] * mid) for c in cfg]
        if _feasible(test):
            lo = mid
        else:
            hi = mid
    return [(c[0], c[1], c[2], c[3] * lo) for c in cfg], sum(c[3] * lo for c in cfg)


def _greedy(n, rng, sizes_scale=1.0):
    base = 1.0 / math.sqrt(n)
    order = []
    for i in range(n):
        if rng.random() < 0.5:
            s = base * (0.6 + 0.8 * rng.random())
        else:
            s = base * (0.3 + 1.7 * rng.random())
        s = min(1.0, max(0.0, s * sizes_scale))
        order.append(s)
    order.sort(reverse=True)
    placed = []
    for s in order:
        if s <= 0:
            placed.append([0.5, 0.5, 0.0, 0.0])
            continue
        best = None
        for _try in range(12):
            a = rng.choice([0.0, 0.25, 0.5, 0.75, rng.random()])
            r = s * 0.5 * math.sqrt(2)
            cx = rng.uniform(r, 1.0 - r)
            cy = rng.uniform(r, 1.0 - r)
            cand = [cx, cy, a, s]
            polys = [_corners(c[0], c[1], c[2], c[3]) for c in placed]
            ok = True
            for p in polys:
                if _overlap(p, _corners(cx, cy, a, s)):
                    ok = False
                    break
            if ok:
                best = cand
                break
            pts = _corners(cx, cy, a, s)
            mind = 1e9
            for p in polys:
                cx1 = sum(x for x, _ in p) / 4.0
                cy1 = sum(y for _, y in p) / 4.0
                d = math.hypot(cx - cx1, cy - cy1)
                mind = min(mind, d)
            if best is None or mind > best[0]:
                best = (mind, cand)
        if best is None:
            placed.append([0.5, 0.5, 0.0, 0.0])
        elif isinstance(best, tuple):
            placed.append(best[1])
        else:
            placed.append(best)
    return placed


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    t0 = time.time()
    rng = random.Random(12345 + n)
    best = None
    best_score = -1.0
    time_budget = 45.0
    attempts = 0
    k = math.isqrt(n)
    if k * k == n and k > 0:
        s = 1.0 / k
        grid = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        sc = sum(c[3] for c in grid)
        if _feasible(grid):
            best = grid
            best_score = sc
    if best is None:
        s = 1.0 / max(1.0, math.sqrt(n) + 1)
        g = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(int(1.0 / s) + 1) for j in range(int(1.0 / s) + 1)]
        g = g[:n] + [(0.5, 0.5, 0.0, 0.0)] * max(0, n - len(g))
        best = g
        best_score = sum(c[3] for c in g[:n])
    while time.time() - t0 < time_budget and attempts < 400:
        attempts += 1
        cfg = _greedy(n, rng, sizes_scale=1.0)
        cfg = _relax(cfg, iters=150)
        cfg, sc = _shrink_to_feasible(cfg, 0.0)
        for _ in range(3):
            if time.time() - t0 > time_budget:
                break
            cand = [(c[0] + rng.uniform(-0.01, 0.01), c[1] + rng.uniform(-0.01, 0.01),
                     c[2] + rng.choice([0.0, 0.01, -0.01]), c[3]) for c in cfg]
            cand = _relax(cand, iters=80)
            cand, scc = _shrink_to_feasible(cand, 0.0)
            if scc > sc:
                cfg, sc = cand, scc
        if sc > best_score:
            best_score = sc
            best = cfg
    # FINAL: guarantee inside unit square, then guarantee feasibility
    out = _clamp_inside(best)
    if not _feasible(out):
        out, _ = _shrink_to_feasible(out, 0.0)
    # clamp again in case shrink moved anything (it doesn't, but be safe)
    out = _clamp_inside(out)
    if not _feasible(out):
        # last resort: scale all sides to zero (always valid)
        out = [(min(1.0, max(0.0, c[0])), min(1.0, max(0.0, c[1])), c[2] % 1.0, 0.0) for c in out]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    out = out[:n]
    return out
# EVOLVE-BLOCK-END
