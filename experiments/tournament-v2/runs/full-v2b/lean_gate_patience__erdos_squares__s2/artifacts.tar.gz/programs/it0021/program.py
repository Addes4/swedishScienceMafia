# EVOLVE-BLOCK-START
"""Randomized multi-start packing of squares in the unit square.

Strategy: place squares largest-first.  For each new square we generate a
large pool of candidate (centre, angle) placements derived from corners of
already-placed squares, unit-square corners and random jitter, keep the
feasible ones, and pick among the most promising (closest to touching /
best fit).  Then refine with an overlap-relaxation projection loop and a
bisection shrink-to-feasible.  The best total side length over many
randomized restarts is kept.
"""
import math
import random
import time


def _corners(cx, cy, ang, s):
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _bbox(pts):
    return (min(p[0] for p in pts), min(p[1] for p in pts),
            max(p[0] for p in pts), max(p[1] for p in pts))


def _overlap(p, q):
    """Separating axis test for two convex quads. True if interiors overlap."""
    cx1 = sum(a for a, _ in p) / 4.0
    cy1 = sum(b for _, b in p) / 4.0
    cx2 = sum(a for a, _ in q) / 4.0
    cy2 = sum(b for _, b in q) / 4.0
    r1 = 0.0
    for a, b in p:
        r1 = max(r1, (a - cx1) ** 2 + (b - cy1) ** 2)
    r2 = 0.0
    for a, b in q:
        r2 = max(r2, (a - cx2) ** 2 + (b - cy2) ** 2)
    if (cx1 - cx2) ** 2 + (cy1 - cy2) ** 2 > (math.sqrt(r1) + math.sqrt(r2)) ** 2:
        return False
    for poly in (p, q):
        for i in range(4):
            ax, ay = poly[i]
            bx, by = poly[(i + 1) % 4]
            ex, ey = bx - ax, by - ay
            nx, ny = -ey, ex
            d1min = d1max = None
            d2min = d2max = None
            for a, b in p:
                d = a * nx + b * ny
                if d1min is None or d < d1min:
                    d1min = d
                if d1max is None or d > d1max:
                    d1max = d
            for a, b in q:
                d = a * nx + b * ny
                if d2min is None or d < d2min:
                    d2min = d
                if d2max is None or d > d2max:
                    d2max = d
            if d1max <= d2min or d2max <= d1min:
                return False
    return True


def _feasible(cfg):
    polys = [_corners(cx, cy, a, s) for (cx, cy, a, s) in cfg]
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _inside_pt(cx, cy, a, s):
    if s <= 1e-12:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    minx, miny, maxx, maxy = _bbox(_corners(cx, cy, a, s))
    return minx >= -1e-9 and maxx <= 1 + 1e-9 and miny >= -1e-9 and maxy <= 1 + 1e-9


def _clamp_inside(cfg):
    out = []
    for (cx, cy, a, s) in cfg:
        if s <= 1e-12:
            out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a % 1.0, 0.0))
            continue
        if 0.5 * s * math.sqrt(2) > 0.5 + 1e-12:
            s = 1.0 / math.sqrt(2)
        minx, miny, maxx, maxy = _bbox(_corners(cx, cy, a, s))
        if maxx - minx > 1.0 + 1e-12 or maxy - miny > 1.0 + 1e-12:
            scale = min(1.0 / (maxx - minx), 1.0 / (maxy - miny))
            s *= scale
            minx, miny, maxx, maxy = _bbox(_corners(cx, cy, a, s))
        if minx < 0:
            cx -= minx
            maxx -= minx
        if maxx > 1:
            cx -= (maxx - 1)
        if miny < 0:
            cy -= miny
            maxy -= miny
        if maxy > 1:
            cy -= (maxy - 1)
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        out.append((cx, cy, a % 1.0, s))
    return out


def _relax(cfg, iters=200):
    cfg = [list(x) for x in cfg]
    n = len(cfg)
    for _ in range(iters):
        moved = False
        polys = [_corners(c[0], c[1], c[2], c[3]) for c in cfg]
        for i in range(n):
            for j in range(i + 1, n):
                si = cfg[i][3]
                sj = cfg[j][3]
                if si <= 1e-12 or sj <= 1e-12:
                    continue
                r1 = si * 0.5 * math.sqrt(2)
                r2 = sj * 0.5 * math.sqrt(2)
                dx = cfg[i][0] - cfg[j][0]
                dy = cfg[i][1] - cfg[j][1]
                d = math.hypot(dx, dy)
                if d < 1e-12:
                    dx, dy = 1.0, 0.0
                    d = 1.0
                need = r1 + r2 - d
                if need > 1e-9 and _overlap(polys[i], polys[j]):
                    ux, uy = dx / d, dy / d
                    push = need * 0.5 + 1e-4
                    cfg[i][0] += ux * push
                    cfg[i][1] += uy * push
                    cfg[j][0] -= ux * push
                    cfg[j][1] -= uy * push
                    moved = True
        for c in cfg:
            if c[3] <= 1e-12:
                c[0] = min(1.0, max(0.0, c[0]))
                c[1] = min(1.0, max(0.0, c[1]))
                continue
            minx, miny, maxx, maxy = _bbox(_corners(c[0], c[1], c[2], c[3]))
            if minx < 0:
                c[0] -= minx
            if maxx > 1:
                c[0] -= (maxx - 1)
            if miny < 0:
                c[1] -= miny
            if maxy > 1:
                c[1] -= (maxy - 1)
        if not moved:
            if _feasible([(c[0], c[1], c[2], c[3]) for c in cfg]):
                break
    return [(c[0], c[1], c[2], c[3]) for c in cfg]


def _shrink_to_feasible(cfg):
    cfg = [(c[0], c[1], c[2], c[3]) for c in cfg]
    if _feasible(cfg):
        return cfg, sum(c[3] for c in cfg)
    lo, hi = 0.0, 1.0
    for _ in range(30):
        mid = (lo + hi) * 0.5
        test = [(c[0], c[1], c[2], c[3] * mid) for c in cfg]
        if _feasible(test):
            lo = mid
        else:
            hi = mid
    return [(c[0], c[1], c[2], c[3] * lo) for c in cfg], sum(c[3] * lo for c in cfg)


def _candidate_positions(s, placed_polys, rng):
    """Generate candidate (cx,cy,ang) placements for a square of side s."""
    cands = []
    angles = [0.0, 0.25, 0.5, 0.75]
    if rng.random() < 0.4:
        angles.append(rng.random())
    # corner-anchored candidates against already placed squares
    for poly in placed_polys:
        for (ax, ay) in poly:
            for ang in angles:
                # anchor own corner at (ax, ay): centre offset
                th = ang * 2.0 * math.pi
                c, sn = math.cos(th), math.sin(th)
                h = s * 0.5
                # try all 4 own corners at this anchor point + small offsets
                for (dx, dy) in ((h, h), (-h, h), (-h, -h), (h, -h)):
                    ox = dx * c - dy * sn
                    oy = dx * sn + dy * c
                    cands.append((ax - ox, ay - oy, ang))
                # also a grid of small offsets
                cands.append((ax + s * rng.uniform(-0.3, 0.3),
                              ay + s * rng.uniform(-0.3, 0.3), ang))
    # unit-square corners / edges
    r = s * 0.5 * math.sqrt(2)
    for ang in angles:
        for (px, py) in ((0.5, 0.5), (0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0)):
            cands.append((px, py, ang))
    # random interior jitter
    for _ in range(20):
        ang = rng.choice(angles)
        rr = s * 0.5 * math.sqrt(2)
        if rr <= 0.5:
            cands.append((rng.uniform(rr, 1 - rr), rng.uniform(rr, 1 - rr), ang))
        else:
            cands.append((0.5, 0.5, ang))
    return cands


def _greedy(n, rng, sizes_scale=1.0):
    base = 1.0 / math.sqrt(n)
    sizes = []
    for i in range(n):
        if rng.random() < 0.5:
            s = base * (0.6 + 0.8 * rng.random())
        else:
            s = base * (0.3 + 1.7 * rng.random())
        sizes.append(min(1.0, max(0.0, s * sizes_scale)))
    sizes.sort(reverse=True)
    placed = []
    polys = []
    for s in sizes:
        if s <= 0:
            placed.append([0.5, 0.5, 0.0, 0.0])
            continue
        cands = _candidate_positions(s, polys, rng)
        rng.shuffle(cands)
        best = None
        best_metric = -1.0
        tried = 0
        for (cx, cy, ang) in cands:
            if tried > 60:
                break
            if not _inside_pt(cx, cy, ang, s):
                continue
            newpoly = _corners(cx, cy, ang, s)
            ok = True
            for p in polys:
                if _overlap(p, newpoly):
                    ok = False
                    break
            if ok:
                # metric: count touching neighbours + centrality
                touch = 0
                for p in polys:
                    pminx, pminy, pmaxx, pmaxy = _bbox(p)
                    nminx, nminy, nmaxx, nmaxy = _bbox(newpoly)
                    gap = max(nminx - pmaxx, pminx - nmaxx, nminy - pmaxy, pminy - nmaxy)
                    if gap < 1e-6:
                        touch += 1
                metric = touch + rng.random() * 0.5
                if metric > best_metric:
                    best_metric = metric
                    best = [cx, cy, ang, s]
                tried += 1
        if best is None:
            placed.append([0.5, 0.5, 0.0, 0.0])
        else:
            placed.append(best)
            polys.append(_corners(best[0], best[1], best[2], best[3]))
    return placed


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    t0 = time.time()
    rng = random.Random(12345 + n)
    best = None
    best_score = -1.0
    time_budget = 50.0
    attempts = 0
    k = math.isqrt(n)
    if k * k == n and k > 0:
        s = 1.0 / k
        grid = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        if _feasible(grid):
            best = grid
            best_score = sum(c[3] for c in grid)
    if best is None:
        s = 1.0 / max(1.0, math.sqrt(n) + 1)
        g = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
             for i in range(int(1.0 / s) + 1) for j in range(int(1.0 / s) + 1)]
        g = g[:n] + [(0.5, 0.5, 0.0, 0.0)] * max(0, n - len(g))
        best = g
        best_score = sum(c[3] for c in g[:n])
    while time.time() - t0 < time_budget and attempts < 600:
        attempts += 1
        cfg = _greedy(n, rng, sizes_scale=1.0)
        cfg = _relax(cfg, iters=150)
        cfg, sc = _shrink_to_feasible(cfg)
        for _ in range(4):
            if time.time() - t0 > time_budget:
                break
            cand = [(c[0] + rng.uniform(-0.01, 0.01), c[1] + rng.uniform(-0.01, 0.01),
                     c[2] + rng.choice([0.0, 0.01, -0.01]), c[3]) for c in cfg]
            cand = _relax(cand, iters=80)
            cand, scc = _shrink_to_feasible(cand)
            if scc > sc:
                cfg, sc = cand, scc
        if sc > best_score:
            best_score = sc
            best = cfg
    out = _clamp_inside(best)
    if not _feasible(out):
        out, _ = _shrink_to_feasible(out)
    out = _clamp_inside(out)
    if not _feasible(out):
        out = [(min(1.0, max(0.0, c[0])), min(1.0, max(0.0, c[1])), c[2] % 1.0, 0.0) for c in out]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    out = out[:n]
    return out
# EVOLVE-BLOCK-END
