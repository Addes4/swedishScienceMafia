# EVOLVE-BLOCK-START
"""Rectangular grid layout plus stochastic grow/repair local search."""
import math
import random


def _rect_grid_layout(n):
    """Return best axis-aligned rectangular grid layout with leftover strip fill."""
    best = None
    best_score = -1.0
    for r in range(1, n + 1):
        for c in range(1, n + 1):
            if r * c > n:
                continue
            s = min(1.0 / r, 1.0 / c)
            used = r * c
            rem = n - used
            squares = []
            w = c * s
            h = r * s
            for i in range(c):
                for j in range(r):
                    squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
            extra = []
            if rem > 0:
                for a in range(rem + 1):
                    b = rem - a
                    strip_w = 1.0 - w
                    strip_h = 1.0 - h
                    cand = []
                    ok = True
                    if a > 0:
                        if strip_w <= 0:
                            ok = False
                        else:
                            ss = min(strip_w, strip_h / a) if a > 0 else 0.0
                            if ss <= 0:
                                ok = False
                            else:
                                for k in range(a):
                                    cand.append((w + ss / 2, (k + 0.5) * ss, 0.0, ss))
                    if ok and b > 0:
                        if strip_h <= 0:
                            ok = False
                        else:
                            ss = min(1.0 / b, strip_h) if b > 0 else 0.0
                            if ss <= 0:
                                ok = False
                            else:
                                for k in range(b):
                                    cx = (k + 0.5) * ss
                                    cand.append((cx, 1.0 - ss / 2, 0.0, ss))
                    if ok:
                        total = used * s + sum(q[3] for q in cand)
                        if total > best_score:
                            best_score = total
                            best = squares + cand
    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return [tuple(x) for x in best[:n]]


def _square_corners(cx, cy, ang, s):
    # angle as fraction of full turn
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    hx = 0.5 * s
    pts = []
    for dx, dy in ((-hx, -hx), (hx, -hx), (hx, hx), (-hx, hx)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap_sat(a, b):
    """Separating axis test for two convex quads. Returns True if interiors overlap."""
    pa = _square_corners(*a)
    pb = _square_corners(*b)
    for quad in (pa, pb):
        for i in range(4):
            x1, y1 = quad[i]
            x2, y2 = quad[(i + 1) % 4]
            ax, ay = -(y2 - y1), (x2 - x1)
            # project both
            amin = amax = None
            bmin = bmax = None
            for px, py in pa:
                d = px * ax + py * ay
                if amin is None or d < amin:
                    amin = d
                if amax is None or d > amax:
                    amax = d
            for px, py in pb:
                d = px * ax + py * ay
                if bmin is None or d < bmin:
                    bmin = d
                if bmax is None or d > bmax:
                    bmax = d
            # strict overlap requires positive overlap on every axis
            if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
                return False
    return True


def _inside_unit(sq):
    for x, y in _square_corners(*sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _valid(layout):
    n = len(layout)
    for i in range(n):
        if not _inside_unit(layout[i]):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap_sat(layout[i], layout[j]):
                return False
    return True


def _total(layout):
    return sum(sq[3] for sq in layout)


def _clamp_to_unit(cx, cy, ang, s):
    """Shrink s and move centre to fit inside unit square."""
    pts = _square_corners(cx, cy, ang, s)
    minx = min(p[0] for p in pts)
    maxx = max(p[0] for p in pts)
    miny = min(p[1] for p in pts)
    maxy = max(p[1] for p in pts)
    # translate to fit
    if minx < 0:
        cx -= minx
    if maxx > 1.0:
        cx -= (maxx - 1.0)
    if miny < 0:
        cy -= miny
    if maxy > 1.0:
        cy -= (maxy - 1.0)
    # shrink if needed
    for _ in range(30):
        pts = _square_corners(cx, cy, ang, s)
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
        if minx >= -1e-9 and maxx <= 1.0 + 1e-9 and miny >= -1e-9 and maxy <= 1.0 + 1e-9:
            break
        s *= 0.9
    return (cx, cy, ang, s)


def _local_search(layout, n, rng, iters):
    best = [tuple(x) for x in layout]
    best_score = _total(best)
    cur = [list(x) for x in best]

    for it in range(iters):
        cand = [list(x) for x in cur]
        i = rng.randrange(n)
        # pick a move type
        mv = rng.random()
        if mv < 0.5:
            # grow square i
            grow = 1.0 + rng.uniform(0.02, 0.25)
            cand[i][3] = min(1.0, cand[i][3] * grow)
        elif mv < 0.75:
            # jitter position
            cand[i][0] += rng.uniform(-0.05, 0.05)
            cand[i][1] += rng.uniform(-0.05, 0.05)
        else:
            # rotate slightly
            cand[i][2] = (cand[i][2] + rng.uniform(-0.05, 0.05)) % 1.0

        # clamp into unit square
        for k in range(n):
            cand[k] = list(_clamp_to_unit(cand[k][0], cand[k][1], cand[k][2], cand[k][3]))

        # repair overlaps: for each overlapping pair, shrink the smaller
        for _ in range(60):
            found = False
            for a in range(n):
                for b in range(a + 1, n):
                    if _overlap_sat(tuple(cand[a]), tuple(cand[b])):
                        found = True
                        if cand[a][3] <= cand[b][3]:
                            cand[a][3] *= 0.92
                        else:
                            cand[b][3] *= 0.92
            if not found:
                break

        # clamp again
        for k in range(n):
            cand[k] = list(_clamp_to_unit(cand[k][0], cand[k][1], cand[k][2], cand[k][3]))

        if not _valid([tuple(x) for x in cand]):
            continue

        sc = _total(cand)
        if sc > _total(cur) - 1e-9 or rng.random() < 0.05:
            cur = cand
        if sc > best_score:
            best_score = sc
            best = [tuple(x) for x in cand]

    return best


def solve(n):
    if n <= 0:
        return []

    base = _rect_grid_layout(n)
    best = base
    best_score = _total(best)

    rng = random.Random(12345 + n)
    # run local search from several perturbed starts
    starts = [base]
    for scale in (0.95, 0.9, 0.85, 0.8):
        perturbed = []
        for sq in base:
            perturbed.append((
                min(1.0, max(0.0, sq[0] + rng.uniform(-0.02, 0.02))),
                min(1.0, max(0.0, sq[1] + rng.uniform(-0.02, 0.02))),
                sq[2],
                sq[3] * scale,
            ))
        starts.append(perturbed)

    # time-bounded loop
    import time
    t0 = time.time()
    iters_per = 4000
    si = 0
    while time.time() - t0 < 8.0:
        st = starts[si % len(starts)]
        si += 1
        res = _local_search(st, n, rng, iters_per)
        sc = _total(res)
        if sc > best_score and _valid(res):
            best_score = sc
            best = res

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return [tuple(x) for x in best[:n]]
# EVOLVE-BLOCK-END
