# EVOLVE-BLOCK-START
"""Structured seeding + scipy SLSQP continuous refinement.

Objective: maximize sum of side lengths.  We build good structured seeds
(grids, strip tilings, greedy multistart), then refine with a smooth
nonlinear program (SLSQP) over all (cx, cy, angle, side) variables using
containment and pairwise-separation constraints.  This escapes the rigid
grid shape that limits small-n cases.
"""
import math
import random

try:
    import numpy as np
    from scipy.optimize import minimize
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False


def _extent(ang, sz):
    t = ang * 2.0 * math.pi
    c, s = abs(math.cos(t)), abs(math.sin(t))
    h = sz * 0.5
    return h * (c + s), h * (c + s)


def _penetration(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 1e-12 or bsz <= 1e-12:
        return -1.0
    ta = aa * 2.0 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    tb = ba * 2.0 * math.pi
    cb, sb = math.cos(tb), math.sin(tb)
    ha = asz * 0.5
    hb = bsz * 0.5
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    minov = float('inf')
    for (ux, uy) in axes:
        ea = abs(ux * ca + uy * sa) + abs(ux * (-sa) + uy * ca)
        eb = abs(ux * cb + uy * sb) + abs(ux * (-sb) + uy * cb)
        dist = abs(ux * (ax - bx) + uy * (ay - by))
        ov = ha * ea + hb * eb - dist
        if ov < minov:
            minov = ov
    return minov


def _clamp_in_unit(sq, i):
    ex, ey = _extent(sq[i][2], sq[i][3])
    lo_x, hi_x = ex, 1.0 - ex
    lo_y, hi_y = ey, 1.0 - ey
    if lo_x > hi_x:
        sq[i][0] = 0.5
    else:
        sq[i][0] = min(max(sq[i][0], lo_x), hi_x)
    if lo_y > hi_y:
        sq[i][1] = 0.5
    else:
        sq[i][1] = min(max(sq[i][1], lo_y), hi_y)


def _project(squares, iters=200):
    sq = [list(s) for s in squares]
    m = len(sq)
    for i in range(m):
        _clamp_in_unit(sq, i)
    for _ in range(iters):
        moved = False
        for i in range(m):
            if sq[i][3] <= 1e-12:
                continue
            for j in range(i + 1, m):
                if sq[j][3] <= 1e-12:
                    continue
                ov = _penetration(sq[i], sq[j])
                if ov > 1e-9:
                    moved = True
                    dx = sq[i][0] - sq[j][0]
                    dy = sq[i][1] - sq[j][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        ang = random.random() * 2.0 * math.pi
                        dx, dy, d = math.cos(ang), math.sin(ang), 1.0
                    push = ov * 0.5 + 1e-4
                    ux, uy = dx / d, dy / d
                    sq[i][0] += ux * push
                    sq[i][1] += uy * push
                    sq[j][0] -= ux * push
                    sq[j][1] -= uy * push
        for i in range(m):
            _clamp_in_unit(sq, i)
        if not moved:
            break
    return [tuple(s) for s in sq]


def _total_overlap(squares):
    tot = 0.0
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 1e-12:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 1e-12:
                continue
            ov = _penetration(squares[i], squares[j])
            if ov > 0:
                tot += ov
    return tot


def _max_outside(squares):
    worst = 0.0
    for (cx, cy, ang, sz) in squares:
        if sz <= 1e-12:
            continue
        ex, ey = _extent(ang, sz)
        worst = max(worst, ex - cx, cx - (1.0 - ex), ey - cy, cy - (1.0 - ey))
    return worst


def _feasible(squares):
    return _max_outside(squares) <= 1e-6 and _total_overlap(squares) <= 1e-6


# ---------- SLSQP refinement ----------

def _sep_con(u, va, vb, i, j):
    """Separation constraint value >= 0 (returns margin)."""
    ax, ay, aa, asz = va
    bx, by, ba, bsz = vb
    ta = aa * 2.0 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    tb = ba * 2.0 * math.pi
    cb, sb = math.cos(tb), math.sin(tb)
    ha = max(0.0, asz) * 0.5
    hb = max(0.0, bsz) * 0.5
    axes = ((ca, sa), (-sa, ca), (cb, sb), (-sb, cb))
    minov = float('inf')
    for (ux, uy) in axes:
        ea = abs(ux * ca + uy * sa) + abs(ux * (-sa) + uy * ca)
        eb = abs(ux * cb + uy * sb) + abs(ux * (-sb) + uy * cb)
        dist = abs(ux * (ax - bx) + uy * (ay - by))
        ov = ha * ea + hb * eb - dist
        if ov < minov:
            minov = ov
    return minov


def _slsqp_refine(squares, maxiter=120):
    if not _HAVE_SCIPY:
        return squares
    n = len(squares)
    if n == 0:
        return squares
    x0 = np.zeros(4 * n)
    for i, (cx, cy, ang, sz) in enumerate(squares):
        x0[4 * i] = cx
        x0[4 * i + 1] = cy
        x0[4 * i + 2] = ang
        x0[4 * i + 3] = max(0.0, sz)

    def unpack(x):
        return x.reshape(n, 4)

    def obj(x):
        return -float(np.sum(np.maximum(0.0, x[3::4])))

    def obj_grad(x):
        g = np.zeros_like(x)
        g[3::4] = -1.0
        return g

    cons = []

    def make_cont(i, sign, cval):
        def f(x):
            v = unpack(x)[i]
            ex, _ = _extent(v[2], max(0.0, v[3]))
            _, ey = _extent(v[2], max(0.0, v[3]))
            if sign > 0:
                return cval - (v[0] + ex)  # ex <= 1 - cx -> cval - cx - ex >=0
            return cval
        return f

    # containment: cx + ex <= 1, ex - cx <= 0, cy + ey <= 1, ey - cy <= 0
    for i in range(n):
        def f1(x, i=i):
            v = unpack(x)[i]
            ex, _ = _extent(v[2], max(0.0, v[3]))
            return 1.0 - (v[0] + ex)
        def f2(x, i=i):
            v = unpack(x)[i]
            ex, _ = _extent(v[2], max(0.0, v[3]))
            return (v[0] - ex)
        def f3(x, i=i):
            v = unpack(x)[i]
            _, ey = _extent(v[2], max(0.0, v[3]))
            return 1.0 - (v[1] + ey)
        def f4(x, i=i):
            v = unpack(x)[i]
            _, ey = _extent(v[2], max(0.0, v[3]))
            return (v[1] - ey)
        cons.append({'type': 'ineq', 'fun': f1})
        cons.append({'type': 'ineq', 'fun': f2})
        cons.append({'type': 'ineq', 'fun': f3})
        cons.append({'type': 'ineq', 'fun': f4})

    for i in range(n):
        for j in range(i + 1, n):
            def g(x, i=i, j=j):
                v = unpack(x)
                return _sep_con(x, v[i], v[j], i, j)
            cons.append({'type': 'ineq', 'fun': g})

    bounds = []
    for i in range(n):
        bounds += [(0.0, 1.0), (0.0, 1.0), (-1.0, 1.0), (0.0, 1.0)]

    try:
        res = minimize(obj, x0, jac=obj_grad, method='SLSQP',
                       bounds=bounds, constraints=cons,
                       options={'maxiter': maxiter, 'ftol': 1e-9})
        xr = res.x
        cand = [(float(xr[4 * i]), float(xr[4 * i + 1]),
                 float(xr[4 * i + 2] % 1.0), float(max(0.0, xr[4 * i + 3])))
                for i in range(n)]
        cand = _project(cand, iters=120)
        if _feasible(cand) and sum(s[3] for s in cand) >= sum(s[3] for s in squares) - 1e-6:
            return cand
    except Exception:
        pass
    return squares


# ---------- structured seeds ----------

def _grid_tiling(n, r, c, horiz):
    if r < 1 or c < 1:
        return None
    main = r * c
    if main > n:
        return None
    rem = n - main
    s_main = 1.0 / c
    used_h = r * s_main
    if used_h > 1.0 + 1e-12:
        return None
    squares = []
    if horiz:
        for j in range(r):
            for i in range(c):
                squares.append((i * s_main + s_main / 2,
                                j * s_main + s_main / 2, 0.0, s_main))
        strip_h = 1.0 - used_h
        if rem > 0:
            if strip_h <= 1e-12:
                for _ in range(rem):
                    squares.append((0.5, 1.0, 0.0, 0.0))
            else:
                s = min(strip_h, 1.0 / rem)
                total_w = rem * s
                x0 = (1.0 - total_w) / 2.0
                yc = used_h + strip_h / 2.0
                for i in range(rem):
                    squares.append((x0 + i * s + s / 2, yc, 0.0, s))
    else:
        used_w = r * s_main
        if used_w > 1.0 + 1e-12:
            return None
        for j in range(c):
            for i in range(r):
                squares.append((i * s_main + s_main / 2,
                                j * s_main + s_main / 2, 0.0, s_main))
        strip_w = 1.0 - used_w
        if rem > 0:
            if strip_w <= 1e-12:
                for _ in range(rem):
                    squares.append((1.0, 0.5, 0.0, 0.0))
            else:
                s = min(strip_w, 1.0 / rem)
                total_h = rem * s
                y0 = (1.0 - total_h) / 2.0
                xc = used_w + strip_w / 2.0
                for i in range(rem):
                    squares.append((xc, y0 + i * s + s / 2, 0.0, s))
    if len(squares) != n:
        return None
    return squares


def _greedy_start(n, rng):
    base = 1.0 / max(1.0, math.sqrt(n))
    sizes = []
    for _ in range(n):
        f = rng.uniform(0.55, 1.35)
        sizes.append(min(0.999, base * f * rng.uniform(0.8, 1.2)))
    order = list(range(n))
    rng.shuffle(order)
    placed = []
    for idx in order:
        sz = sizes[idx]
        best = None
        best_score = -1e18
        for _try in range(40):
            ang = rng.choice([0.0, 0.25, rng.random()])
            ex, ey = _extent(ang, sz)
            lo_x, hi_x = ex, 1.0 - ex
            lo_y, hi_y = ey, 1.0 - ey
            if lo_x > hi_x or lo_y > hi_y:
                continue
            cx = rng.uniform(lo_x, hi_x)
            cy = rng.uniform(lo_y, hi_y)
            cand = (cx, cy, ang, sz)
            ov = 0.0
            ok = True
            for p in placed:
                ov += _penetration(cand, p)
                if ov > 0.25 * sz:
                    ok = False
                    break
            score = -ov
            if ok and score > best_score:
                best_score = score
                best = cand
        if best is None:
            ex, ey = _extent(0.0, sz)
            cx = min(max(0.5, ex), 1.0 - ex) if ex <= 0.5 else 0.5
            cy = min(max(0.5, ey), 1.0 - ey) if ey <= 0.5 else 0.5
            best = (cx, cy, 0.0, sz)
        placed.append(best)
    return placed


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(987654321)
    best = None
    best_score = -1e18
    seeds = []

    def collect(squares):
        if squares is None:
            return
        rel = _project(squares, iters=150)
        if _feasible(rel):
            seeds.append(rel)

    for r in range(1, n + 1):
        for c in range(1, n + 1):
            if r * c > n:
                continue
            for horiz in (True, False):
                collect(_grid_tiling(n, r, c, horiz))

    k = math.isqrt(n)
    if k >= 1:
        side = 1.0 / k
        grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
        collect(grid[:n])

    tries = 20 if n <= 12 else (12 if n <= 30 else 6)
    for t in range(tries):
        collect(_greedy_start(n, rng))

    # pick best seed
    for s in seeds:
        sc = sum(x[3] for x in s)
        if sc > best_score:
            best_score = sc
            best = s

    # SLSQP refinement on several top seeds.
    if _HAVE_SCIPY and seeds:
        seeds.sort(key=lambda s: -sum(x[3] for x in s))
        cand_list = seeds[:4] if len(seeds) > 4 else seeds
        for s in cand_list:
            ref = _slsqp_refine(s, maxiter=150)
            sc = sum(x[3] for x in ref)
            if _feasible(ref) and sc > best_score + 1e-9:
                best = ref
                best_score = sc

    # second SLSQP pass from current best
    if _HAVE_SCIPY and best is not None:
        for _ in range(2):
            ref = _slsqp_refine(best, maxiter=150)
            sc = sum(x[3] for x in ref)
            if _feasible(ref) and sc > best_score + 1e-10:
                best = ref
                best_score = sc
            else:
                break

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    result = list(best)
    if len(result) < n:
        result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]
# EVOLVE-BLOCK-END
