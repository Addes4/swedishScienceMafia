# EVOLVE-BLOCK-START
"""Deterministic structural seeder for squares in the unit square.

Strategy
--------
Fill the unit square with 1, 2, or 3 axis-aligned bands (horizontal or
vertical).  Each band holds its own uniform grid of equal squares.  We
enumerate all factor pairs for every band, all splits of the unit interval
between bands, and compute the achievable sum for each candidate.  Band
split fractions are chosen to equalize square sizes between neighbouring
bands for maximum efficiency.  A short overlap-relaxation projection then
guarantees a valid configuration.
"""

import math
import time


def _rot_cos_sin(angle):
    a = angle * 2.0 * math.pi
    return math.cos(a), math.sin(a)


def _sep_min_dist(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    ah = 0.5 * asz
    bh = 0.5 * bsz
    ca, sa = _rot_cos_sin(aa)
    cb, sb = _rot_cos_sin(ba)
    axes = ((ca, sa), (-sa, ca), (cb, sb), (-sb, cb))
    dx = bx - ax
    dy = by - ay
    best = float('inf')
    for (ux, uy) in axes:
        dist = abs(dx * ux + dy * uy)
        ra = ah * (abs(ca * ux + sa * uy) + abs(-sa * ux + ca * uy))
        rb = bh * (abs(cb * ux + sb * uy) + abs(-sb * ux + cb * uy))
        gap = dist - (ra + rb)
        if gap < best:
            best = gap
    return best


def _total_overlap(sqs):
    n = len(sqs)
    tot = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            g = _sep_min_dist(sqs[i], sqs[j])
            if g < 0.0:
                tot += -g
    return tot


def _repair(sqs, iters):
    n = len(sqs)
    sqs = [[float(c) for c in s] for s in sqs]
    for _ in range(iters):
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                g = _sep_min_dist(tuple(sqs[i]), tuple(sqs[j]))
                if g < -1e-9:
                    moved = True
                    dx = sqs[i][0] - sqs[j][0]
                    dy = sqs[i][1] - sqs[j][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-12:
                        dx, dy, d = 1.0, 0.0, 1.0
                    ux, uy = dx / d, dy / d
                    push = -g * 0.5 + 1e-6
                    sqs[i][0] += ux * push
                    sqs[i][1] += uy * push
                    sqs[j][0] -= ux * push
                    sqs[j][1] -= uy * push
        for i in range(n):
            cx, cy, ang, side = sqs[i]
            c, s = _rot_cos_sin(ang)
            h = 0.5 * side
            ex = h * (abs(c) + abs(s))
            ey = h * (abs(c) + abs(s))
            if ex > 0.5 or ey > 0.5:
                sc = 0.5 / max(ex, ey)
                side *= sc
                h = 0.5 * side
                ex = h * (abs(c) + abs(s))
                ey = h * (abs(c) + abs(s))
            sqs[i][0] = min(max(cx, ex), 1.0 - ex)
            sqs[i][1] = min(max(cy, ey), 1.0 - ey)
            sqs[i][3] = side
        if not moved:
            break
    return [tuple(s) for s in sqs]


def _grid_band(x0, y0, w, h, r, c):
    if r <= 0 or c <= 0:
        return []
    side = min(w / c, h / r)
    out = []
    totw = side * c
    toth = side * r
    ox = x0 + (w - totw) * 0.5
    oy = y0 + (h - toth) * 0.5
    for i in range(r):
        for j in range(c):
            cx = ox + (j + 0.5) * side
            cy = oy + (i + 0.5) * side
            out.append((cx, cy, 0.0, side))
    return out


def _side_r_c(band_w, band_h, r, c):
    """Uniform square side for an r x c grid inside a w x h rectangle."""
    return min(band_w / c, band_h / r)


def _factors(k):
    fs = []
    for r in range(1, k + 1):
        if k % r == 0:
            fs.append((r, k // r))
    return fs


def _band_grids(k, band_len, band_thick):
    """For a band of length L and thickness T with k grid squares, return
    list of (r, c, side) where r counts along thickness, c along length.
    We consider both orientations so 'thickness' rows r and 'length' cols c.
    """
    out = []
    for (r, c) in _factors(k):
        # r rows across thickness, c cols across length
        s = min(band_thick / r, band_len / c)
        out.append((r, c, s))
    return out


def _tiling_score_from_splits(splits_grids, total_len):
    """splits: list of (thickness_fraction, [(r,c),...]) meaning this band
    occupies fraction of total_len along thickness.  Simpler: work with
    explicit thicknesses.  Return best sum given thicknesses.
    """
    return None


def _candidate_tilings(n):
    results = []

    # ---- 1 band (pure grid) ----
    for (r, c) in _factors(n):
        band = _grid_band(0.0, 0.0, 1.0, 1.0, r, c)
        if len(band) == n:
            results.append(band)

    # ---- 2 horizontal bands ----
    for a in range(1, n):
        b = n - a
        for rb, cb in _factors(b):
            for ra, ca in _factors(a):
                # optimize split t (bottom band height)
                # bottom grid: rows rb, cols cb, band width 1 -> side cmp = min(t/rb, 1/cb)
                # top   grid: rows ra, cols ca, band width 1 -> side = min((1-t)/ra, 1/ca)
                for t in _best_splits_2(rb, cb, ra, ca):
                    bottom = _grid_band(0.0, 0.0, 1.0, t, rb, cb)
                    top = _grid_band(0.0, t, 1.0, 1.0 - t, ra, ca)
                    if len(bottom) + len(top) == n:
                        results.append(bottom + top)

    # ---- 2 vertical bands ----
    for a in range(1, n):
        b = n - a
        for rb, cb in _factors(b):
            for ra, ca in _factors(a):
                # left band width t: rows rb across height, cols cb across width
                # side_left = min(1/rb, t/cb)
                # right band width 1-t: side_right = min(1/ra, (1-t)/ca)
                for t in _best_splits_2_v(cb, rb, ca, ra):
                    left = _grid_band(0.0, 0.0, t, 1.0, rb, cb)
                    right = _grid_band(t, 0.0, 1.0 - t, 1.0, ra, ca)
                    if len(left) + len(right) == n:
                        results.append(left + right)

    # ---- 3 horizontal bands ----
    for a in range(1, n - 1):
        for b in range(1, n - a):
            c = n - a - b
            if c < 1:
                continue
            fa = _factors(a)
            fb = _factors(b)
            fc = _factors(c)
            # limit combinatorics
            if len(fa) * len(fb) * len(fc) > 4096:
                fa = fa[:len(fa)]
            for (ra, ca) in fa:
                for (rb, cb) in fb:
                    for (rc, cc_) in fc:
                        for (t1, t2) in _best_splits_3(ra, ca, rb, cb, rc, cc_):
                            ba = _grid_band(0.0, 0.0, 1.0, t1, ra, ca)
                            bb = _grid_band(0.0, t1, 1.0, t2 - t1, rb, cb)
                            bc = _grid_band(0.0, t2, 1.0, 1.0 - t2, rc, cc_)
                            if len(ba) + len(bb) + len(bc) == n:
                                results.append(ba + bb + bc)

    # ---- 3 vertical bands ----
    for a in range(1, n - 1):
        for b in range(1, n - a):
            c = n - a - b
            if c < 1:
                continue
            for (ra, ca) in _factors(a):
                for (rb, cb) in _factors(b):
                    for (rc, cc_) in _factors(c):
                        for (t1, t2) in _best_splits_3(ca, ra, cb, rb, cc_, rc):
                            ba = _grid_band(0.0, 0.0, t1, 1.0, ra, ca)
                            bb = _grid_band(t1, 0.0, t2 - t1, 1.0, rb, cb)
                            bc = _grid_band(t2, 0.0, 1.0 - t2, 1.0, rc, cc_)
                            if len(ba) + len(bb) + len(bc) == n:
                                results.append(ba + bb + bc)

    return results


def _best_splits_2(rA, cA, rB, cB):
    """Horizontal: band A occupies fraction t (bottom), B fraction 1-t (top).
    side_A = min(t/rA, 1/cA); side_B = min((1-t)/rB, 1/cB).
    Maximize a_side*count?  We just maximize min?  Return candidate t's."""
    ts = set()
    # equalize thickness-limited: t/rA == (1-t)/rB -> t = rA/(rA+rB)
    ts.add(rA / (rA + rB))
    # equalize width-limited equality of sides: 1/cA == 1/cB impossible unless cA=cB
    for k in range(1, 20):
        ts.add(k / 20.0)
    out = []
    eps = 1e-9
    for t in ts:
        if eps < t < 1.0 - eps:
            out.append(t)
    return out


def _best_splits_2_v(cA, rA, cB, rB):
    """Vertical: left band width t.  side_A = min(1/rA, t/cA);
    side_B = min(1/rB, (1-t)/cB)."""
    ts = set()
    ts.add(cA / (cA + cB))
    for k in range(1, 20):
        ts.add(k / 20.0)
    out = []
    eps = 1e-9
    for t in ts:
        if eps < t < 1.0 - eps:
            out.append(t)
    return out


def _best_splits_3(rA, cA, rB, cB, rC, cC):
    """Three horizontal bands stacked.  side_A = min(t1/rA, 1/cA),
    side_B = min((t2-t1)/rB, 1/cB), side_C = min((1-t2)/rC, 1/cC).
    Return candidate (t1, t2)."""
    cands = set()
    tot = rA + rB + rC
    if tot > 0:
        t1 = rA / tot
        t2 = (rA + rB) / tot
        cands.add((t1, t2))
    for t1 in (k / 8.0 for k in range(1, 8)):
        for t2 in (k / 8.0 for k in range(1, 8)):
            if t1 < t2:
                cands.add((round(t1, 6), round(t2, 6)))
    out = []
    eps = 1e-9
    for (t1, t2) in cands:
        if eps < t1 < t2 < 1.0 - eps:
            out.append((t1, t2))
    return out


def _score(sqs):
    return sum(s[3] for s in sqs)


def _try_candidates(cands, deadline, best, best_score):
    cnt = 0
    for cand in cands:
        if time.time() > deadline:
            break
        if _total_overlap(cand) > 1e-9:
            cand = _repair(cand, 60)
        ov = _total_overlap(cand)
        if ov > 1e-6:
            continue
        sc = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand
    return best, best_score


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    deadline = time.time() + 50.0

    # pure grid fallback
    k = max(1, math.isqrt(n))
    while k * k < n:
        k += 1
    side = 1.0 / k
    best = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side)
            for i in range(n)]
    best_score = _score(best)

    cands = _candidate_tilings(n)
    best, best_score = _try_candidates(cands, deadline, best, best_score)

    # light random perturbation search around the best, keeping validity
    import random
    rng = random.Random(12345)
    cur = [list(s) for s in best]
    cur_score = best_score
    stall = 0
    while time.time() < deadline:
        trial = [list(s) for s in cur]
        for _ in range(rng.randrange(1, 3)):
            i = rng.randrange(n)
            trial[i][3] = max(0.0, trial[i][3] * (0.9 + 0.2 * rng.random()))
            trial[i][0] = min(max(trial[i][0] + (rng.random() - 0.5) * 0.03, 0.0), 1.0)
            trial[i][1] = min(max(trial[i][1] + (rng.random() - 0.5) * 0.03, 0.0), 1.0)
            if rng.random() < 0.15:
                trial[i][2] = rng.random()
        trial = _repair(trial, 40)
        if _total_overlap(trial) > 1e-6:
            continue
        sc = _score(trial)
        if sc > cur_score:
            cur = trial
            cur_score = sc
            stall = 0
            if sc > best_score:
                best_score = sc
                best = [tuple(s) for s in trial]
        else:
            stall += 1
            if stall > 4000:
                # restart from best
                cur = [list(s) for s in best]
                cur_score = best_score
                stall = 0

    out = []
    for i in range(n):
        if i < len(best):
            cx, cy, ang, sd = best[i]
        else:
            cx, cy, ang, sd = 0.0, 0.0, 0.0, 0.0
        cx = min(max(float(cx), 0.0), 1.0)
        cy = min(max(float(cy), 0.0), 1.0)
        ang = float(ang) % 1.0
        sd = min(max(float(sd), 0.0), 1.0)
        out.append((cx, cy, ang, sd))
    return out
# EVOLVE-BLOCK-END
