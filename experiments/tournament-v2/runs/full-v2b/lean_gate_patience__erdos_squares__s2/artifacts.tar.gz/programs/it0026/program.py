# EVOLVE-BLOCK-START
"""Randomized best-fit-corner packing of squares in the unit square.

For each n we try many randomized greedy packings (largest squares first).
Each square is placed at a candidate position taken from the corners and edges
of already-placed squares and the unit-square corners, optionally rotated; the
best candidates by free-space are sampled randomly.  Each packing is refined by
an overlap-relaxation projection (push overlapping pairs apart, clamp centres),
then we keep the best total side length found.  A final per-square grow-and-nudge
local search exploits leftover free space without ever reducing a side, followed
by a remove-and-reinsert pass that drops the smallest squares, re-grows the rest,
and optimally re-places the removed ones.
"""
import math
import random
import time


def _corners(cx, cy, ang, s):
    """Corner points of a square (centre, angle in turns, side s)."""
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap(p, q):
    """Separating axis test for two convex quads. Returns True if interiors overlap."""
    cx1 = sum(a for a, _ in p) / 4.0
    cy1 = sum(b for _, b in p) / 4.0
    cx2 = sum(a for a, _ in q) / 4.0
    cy2 = sum(b for _, b in q) / 4.0
    r1 = 0.0
    r2 = 0.0
    for a, b in p:
        r1 = max(r1, (a - cx1) ** 2 + (b - cy1) ** 2)
    for a, b in q:
        r2 = max(r2, (a - cx2) ** 2 + (b - cy2) ** 2)
    r1 = math.sqrt(r1)
    r2 = math.sqrt(r2)
    if (cx1 - cx2) ** 2 + (cy1 - cy2) ** 2 > (r1 + r2) ** 2:
        return False
    for poly in (p, q):
        for i in range(4):
            ax, ay = poly[i]
            bx, by = poly[(i + 1) % 4]
            ex, ey = bx - ax, by - ay
            nx, ny = -ey, ex
            dmin1 = dmax1 = None
            for a, b in p:
                d = a * nx + b * ny
                if dmin1 is None or d < dmin1:
                    dmin1 = d
                if dmax1 is None or d > dmax1:
                    dmax1 = d
            dmin2 = dmax2 = None
            for a, b in q:
                d = a * nx + b * ny
                if dmin2 is None or d < dmin2:
                    dmin2 = d
                if dmax2 is None or d > dmax2:
                    dmax2 = d
            if dmax1 <= dmin2 or dmax2 <= dmin1:
                return False
    return True


def _feasible(cfg):
    polys = [_corners(cx, cy, a, s) for (cx, cy, a, s) in cfg]
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _inside(cfg):
    """Check every square is fully inside the unit square."""
    for (cx, cy, a, s) in cfg:
        if s <= 1e-12:
            if not (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0):
                return False
            continue
        pts = _corners(cx, cy, a, s)
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
        if minx < -1e-9 or maxx > 1 + 1e-9 or miny < -1e-9 or maxy > 1 + 1e-9:
            return False
    return True


def _clamp_inside(cfg):
    """Shift each square so it lies inside the unit square (reducing side if needed)."""
    out = []
    for (cx, cy, a, s) in cfg:
        if s <= 1e-12:
            out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a % 1.0, 0.0))
            continue
        diag = 0.5 * s * math.sqrt(2)
        if diag > 0.5 + 1e-12:
            s = 1.0 / math.sqrt(2)
        pts = _corners(cx, cy, a, s)
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
        if maxx - minx > 1.0 + 1e-12 or maxy - miny > 1.0 + 1e-12:
            scale = min(1.0 / (maxx - minx), 1.0 / (maxy - miny))
            s *= scale
            pts = _corners(cx, cy, a, s)
            minx = min(p[0] for p in pts)
            maxx = max(p[0] for p in pts)
            miny = min(p[1] for p in pts)
            maxy = max(p[1] for p in pts)
        if minx < 0:
            cx -= minx
            maxx -= minx
        if maxx > 1:
            cx -= (maxx - 1)
        if miny < 0:
            cy -= miny
            maxy -= miny
        if maxy > 1:
            cy -= (maxy - 1)
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        out.append((cx, cy, a % 1.0, s))
    return out


def _relax(cfg, iters=200):
    cfg = [list(x) for x in cfg]
    n = len(cfg)
    for _ in range(iters):
        moved = False
        polys = [_corners(c[0], c[1], c[2], c[3]) for c in cfg]
        for i in range(n):
            for j in range(i + 1, n):
                si = cfg[i][3]
                sj = cfg[j][3]
                if si <= 1e-12 or sj <= 1e-12:
                    continue
                r1 = si * 0.5 * math.sqrt(2)
                r2 = sj * 0.5 * math.sqrt(2)
                dx = cfg[i][0] - cfg[j][0]
                dy = cfg[i][1] - cfg[j][1]
                d = math.hypot(dx, dy)
                if d < 1e-12:
                    dx, dy = 1.0, 0.0
                    d = 1.0
                need = r1 + r2 - d
                if need > 1e-9:
                    if _overlap(polys[i], polys[j]):
                        ux, uy = dx / d, dy / d
                        push = need * 0.5 + 1e-4
                        cfg[i][0] += ux * push
                        cfg[i][1] += uy * push
                        cfg[j][0] -= ux * push
                        cfg[j][1] -= uy * push
                        moved = True
        for c in cfg:
            if c[3] <= 1e-12:
                c[0] = min(1.0, max(0.0, c[0]))
                c[1] = min(1.0, max(0.0, c[1]))
                continue
            pts = _corners(c[0], c[1], c[2], c[3])
            minx = min(a for a, _ in pts)
            maxx = max(a for a, _ in pts)
            miny = min(b for _, b in pts)
            maxy = max(b for _, b in pts)
            if minx < 0:
                c[0] -= minx
            if maxx > 1:
                c[0] -= (maxx - 1)
            if miny < 0:
                c[1] -= miny
            if maxy > 1:
                c[1] -= (maxy - 1)
        if not moved:
            if _feasible([(c[0], c[1], c[2], c[3]) for c in cfg]):
                break
    return [(c[0], c[1], c[2], c[3]) for c in cfg]


def _shrink_to_feasible(cfg, total):
    cfg = [(c[0], c[1], c[2], c[3]) for c in cfg]
    if _feasible(cfg):
        return cfg, sum(c[3] for c in cfg)
    lo, hi = 0.0, 1.0
    for _ in range(30):
        mid = (lo + hi) * 0.5
        test = [(c[0], c[1], c[2], c[3] * mid) for c in cfg]
        if _feasible(test):
            lo = mid
        else:
            hi = mid
    return [(c[0], c[1], c[2], c[3] * lo) for c in cfg], sum(c[3] * lo for c in cfg)


def _anchor_points(placed):
    """Candidate (cx, cy) anchor points for a new square's lower-left corner."""
    pts = [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0)]
    for c in placed:
        for (px, py) in _corners(c[0], c[1], c[2], c[3]):
            pts.append((px, py))
            pts.append((px, 0.0))
            pts.append((0.0, py))
            pts.append((px, 1.0))
            pts.append((1.0, py))
    return pts


def _maximal_side_at(cx, cy, a, placed, limit=1.0, skip=-1):
    """Largest side for a square centred at (cx,cy) with angle a, keeping it inside
    the unit square and disjoint from placed squares. Uses binary search + SAT.
    The square at index `skip` is ignored (for growing one square at a time)."""
    th = a * 2.0 * math.pi
    c = abs(math.cos(th))
    sn = abs(math.sin(th))
    hw = (c + sn) * 0.5
    dxw = min(cx, 1.0 - cx)
    dyw = min(cy, 1.0 - cy)
    s_inside = limit
    if hw > 1e-12:
        s_inside = min(s_inside, dxw / hw, dyw / hw)
    if s_inside <= 0:
        return 0.0
    others = [q for i, q in enumerate(placed) if i != skip]

    def ok(s):
        if s <= 0:
            return True
        p = _corners(cx, cy, a, s)
        for q in others:
            if _overlap(p, _corners(q[0], q[1], q[2], q[3])):
                return False
        return True

    if not ok(s_inside):
        lo, hi = 0.0, s_inside
        for _ in range(30):
            mid = (lo + hi) * 0.5
            if ok(mid):
                lo = mid
            else:
                hi = mid
        return lo
    return s_inside


def _place_at(s, a, ux, uy, placed):
    """Place a square of side s, angle a, with its lowest-left-ish corner near (ux,uy)."""
    th = a * 2.0 * math.pi
    c = math.cos(th)
    sn = math.sin(th)
    h = s * 0.5
    corners = [(h, h), (-h, h), (-h, -h), (h, -h)]
    xs = []
    ys = []
    for dx, dy in corners:
        xs.append(dx * c - dy * sn)
        ys.append(dx * sn + dy * c)
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)
    cx = ux - minx
    cy = uy - miny
    if maxx - minx > 1.0 + 1e-12 or maxy - miny > 1.0 + 1e-12:
        return None
    if cx + maxx > 1.0:
        cx = 1.0 - maxx
    if cx + minx < 0.0:
        cx = -minx
    if cy + maxy > 1.0:
        cy = 1.0 - maxy
    if cy + miny < 0.0:
        cy = -miny
    p = _corners(cx, cy, a, s)
    for q in placed:
        if _overlap(p, _corners(q[0], q[1], q[2], q[3])):
            return None
    return (cx, cy, a, s)


def _greedy(n, rng, sizes_scale=1.0):
    placed = []
    base = 1.0 / math.sqrt(n)
    order = []
    for i in range(n):
        if rng.random() < 0.5:
            s = base * (0.7 + 0.6 * rng.random())
        else:
            s = base * (0.4 + 1.4 * rng.random())
        s = min(1.0, max(0.0, s * sizes_scale))
        order.append(s)
    order.sort(reverse=True)

    for s in order:
        if s <= 0:
            placed.append([0.5, 0.5, 0.0, 0.0])
            continue
        anchors = _anchor_points(placed)
        rng.shuffle(anchors)
        anchors = anchors[:40]
        cands = []
        angles = [0.0, 0.25] if rng.random() < 0.7 else [0.0, 0.25, 0.5, rng.random()]
        for (ux, uy) in anchors:
            for a in angles:
                res = _place_at(s, a, ux, uy, placed)
                if res is not None:
                    cands.append(res)
        if not cands:
            for _try in range(30):
                a = rng.choice(angles)
                cx = rng.uniform(s * 0.5, 1.0 - s * 0.5) if s < 1 else 0.5
                cy = rng.uniform(s * 0.5, 1.0 - s * 0.5) if s < 1 else 0.5
                ms = _maximal_side_at(cx, cy, a, placed, limit=s)
                if ms > 1e-12:
                    cands.append((cx, cy, a, ms))
            if not cands:
                placed.append([0.5, 0.5, 0.0, 0.0])
                continue
        cands.sort(key=lambda c: -c[3])
        topk = max(1, min(len(cands), 4))
        chosen = cands[rng.randrange(topk)]
        placed.append(list(chosen))
    return placed


def _grow_squares(cfg, rng, t0, time_budget):
    """Grow each square in turn (and nudge its position/angle), accepting only
    strict improvements that remain fully feasible.  Never reduces a side."""
    cfg = [list(c) for c in cfg]
    n = len(cfg)
    angles_extra = [0.0, 0.01, -0.01, 0.02, -0.02, 0.05, -0.05, 0.125]
    for _ in range(8):
        improved_any = False
        idxs = list(range(n))
        idxs.sort(key=lambda i: cfg[i][3])
        for i in idxs:
            if time.time() - t0 > time_budget:
                return cfg
            best_here = cfg[i][3]
            best_trip = None
            cands = [(cfg[i][0], cfg[i][1], cfg[i][2])]
            for _t in range(12):
                cands.append((cfg[i][0] + rng.uniform(-0.035, 0.035),
                              cfg[i][1] + rng.uniform(-0.035, 0.035),
                              (cfg[i][2] + rng.choice(angles_extra)) % 1.0))
            for (cx, cy, a) in cands:
                cx = min(1.0, max(0.0, cx))
                cy = min(1.0, max(0.0, cy))
                ms = _maximal_side_at(cx, cy, a, cfg, limit=1.0, skip=i)
                if ms > best_here + 1e-9:
                    test_cfg = [tuple(cfg[k]) if k != i else (cx, cy, a, ms) for k in range(n)]
                    if _inside(test_cfg) and _feasible(test_cfg):
                        best_here = ms
                        best_trip = (cx, cy, a)
            if best_trip is not None:
                cfg[i] = [best_trip[0], best_trip[1], best_trip[2], best_here]
                improved_any = True
        if not improved_any:
            break
    return cfg


def _reinsert_search(cfg, rng, t0, time_budget):
    """Remove the smallest squares, re-grow the rest, then optimally re-place the
    removed ones.  Accept only strict improvements that stay feasible."""
    cfg = [list(c) for c in cfg]
    n = len(cfg)
    if n < 4:
        return cfg
    best_total = sum(c[3] for c in cfg)

    for _round in range(4):
        if time.time() - t0 > time_budget:
            break
        k = max(1, min(n // 4, 3))
        idxs = sorted(range(n), key=lambda i: cfg[i][3])
        removed_idx = idxs[:k]
        rest = [cfg[i] for i in range(n) if i not in removed_idx]
        removed = [cfg[i] for i in removed_idx]

        rest = _grow_squares(rest, rng, t0, time_budget)

        # Re-place each removed square (largest first) into the best free spot.
        removed_sorted = sorted(removed, key=lambda c: -c[3])
        placed = [list(c) for c in rest]
        ok_all = True
        for rc in removed_sorted:
            s_target = rc[3]
            anchors = _anchor_points(placed)
            rng.shuffle(anchors)
            anchors = anchors[:60]
            best_place = None
            best_s = -1.0
            angles = [0.0, 0.25, 0.5, 0.75, rc[2] % 1.0]
            for (ux, uy) in anchors:
                for a in angles:
                    res = _place_at(s_target, a, ux, uy, placed)
                    if res is not None:
                        # try to grow it a bit more at this spot
                        ms = _maximal_side_at(res[0], res[1], res[2], placed, limit=s_target)
                        ms2 = max(ms, res[3])
                        if ms2 > best_s:
                            best_s = ms2
                            best_place = (res[0], res[1], res[2], ms2)
            # also sample random centres
            for _try in range(40):
                a = rng.choice(angles)
                cx = rng.uniform(0.0, 1.0)
                cy = rng.uniform(0.0, 1.0)
                ms = _maximal_side_at(cx, cy, a, placed, limit=s_target)
                if ms > best_s:
                    best_s = ms
                    best_place = (cx, cy, a, ms)
            if best_place is None or best_s <= 1e-12:
                ok_all = False
                break
            placed.append(list(best_place))

        if not ok_all:
            continue
        total = sum(c[3] for c in placed)
        if total > best_total + 1e-9 and _inside(placed) and _feasible(placed):
            best_total = total
            cfg = [list(c) for c in placed]
        else:
            break
    return cfg


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    t0 = time.time()
    rng = random.Random(12345 + n)
    best = None
    best_score = -1.0
    time_budget = 40.0
    attempts = 0
    k = math.isqrt(n)
    if k * k == n and k > 0:
        s = 1.0 / k
        grid = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        sc = sum(c[3] for c in grid)
        if _feasible(grid):
            best = grid
            best_score = sc
    if best is None:
        s = 1.0 / max(1.0, math.sqrt(n) + 1)
        g = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(int(1.0 / s) + 1) for j in range(int(1.0 / s) + 1)]
        g = g[:n] + [(0.5, 0.5, 0.0, 0.0)] * max(0, n - len(g))
        best = g
        best_score = sum(c[3] for c in g[:n])
    while time.time() - t0 < time_budget and attempts < 400:
        attempts += 1
        cfg = _greedy(n, rng, sizes_scale=1.0)
        cfg = _relax(cfg, iters=150)
        cfg, sc = _shrink_to_feasible(cfg, 0.0)
        for _ in range(3):
            if time.time() - t0 > time_budget:
                break
            cand = [(c[0] + rng.uniform(-0.01, 0.01), c[1] + rng.uniform(-0.01, 0.01),
                     c[2] + rng.choice([0.0, 0.01, -0.01]), c[3]) for c in cfg]
            cand = _relax(cand, iters=80)
            cand, scc = _shrink_to_feasible(cand, 0.0)
            if scc > sc:
                cfg, sc = cand, scc
        if sc > best_score:
            best_score = sc
            best = cfg

    # Final grow + reinsert local search on the best configuration found.
    if best is not None:
        cfg = _grow_squares(best, rng, t0, time_budget + 10.0)
        cfg = _reinsert_search(cfg, rng, t0, time_budget + 14.0)
        cfg = _grow_squares(cfg, rng, t0, time_budget + 17.0)
        sc = sum(c[3] for c in cfg)
        if sc > best_score and _feasible(cfg) and _inside(cfg):
            best = cfg
            best_score = sc

    out = _clamp_inside(best)
    if not _feasible(out):
        out, _ = _shrink_to_feasible(out, 0.0)
    out = _clamp_inside(out)
    if not _feasible(out):
        out = [(min(1.0, max(0.0, c[0])), min(1.0, max(0.0, c[1])), c[2] % 1.0, 0.0) for c in out]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    out = out[:n]
    return out
# EVOLVE-BLOCK-END
