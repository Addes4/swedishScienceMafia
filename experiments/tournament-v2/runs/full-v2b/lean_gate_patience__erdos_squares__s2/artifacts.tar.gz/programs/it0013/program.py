# EVOLVE-BLOCK-START
"""Rectangular-grid + guillotine leftover packing of squares in the unit square.

Approach:
 - Enumerate axis-aligned rectangular grids r x c whose cells tile a sub-rectangle
   of the unit square. The remaining strip (an L-shape) is filled with a
   recursive guillotine packer that places the largest possible square at a
   corner of a free rectangle and splits the remainder.
 - Every candidate layout is verified to have no overlapping interiors (SAT test)
   before being considered.
 - The layout maximising the total side length is returned.

Standard library only. Deterministic (seeded by n).
"""

import math
import functools


# ----------------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------------

def _corners(cx, cy, ang, sz):
    c = math.cos(2.0 * math.pi * ang)
    s = math.sin(2.0 * math.pi * ang)
    h = sz * 0.5
    out = []
    for sx, sy in ((h, h), (h, -h), (-h, h), (-h, -h)):
        out.append((cx + c * sx - s * sy, cy + s * sx + c * sy))
    return out


def _inside_penalty(cx, cy, ang, sz):
    pen = 0.0
    for x, y in _corners(cx, cy, ang, sz):
        if x < 0.0:
            pen += -x
        elif x > 1.0:
            pen += x - 1.0
        if y < 0.0:
            pen += -y
        elif y > 1.0:
            pen += y - 1.0
    return pen


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return 0.0
    ha = asz * 0.5
    hb = bsz * 0.5
    ca = math.cos(2.0 * math.pi * aa)
    sa = math.sin(2.0 * math.pi * aa)
    cb = math.cos(2.0 * math.pi * ba)
    sb = math.sin(2.0 * math.pi * ba)
    axes = ((ca, sa), (-sa, ca), (cb, sb), (-sb, cb))
    dx = bx - ax
    dy = by - ay
    best = float('inf')
    for ux, uy in axes:
        ra = abs(ux * ca + uy * sa) * ha + abs(ux * (-sa) + uy * ca) * ha
        rb = abs(ux * cb + uy * sb) * hb + abs(ux * (-sb) + uy * cb) * hb
        d = abs(dx * ux + dy * uy)
        pen = ra + rb - d
        if pen < best:
            best = pen
    return best if best > 0.0 else 0.0


# ----------------------------------------------------------------------------
# guillotine packer for a rectangular region
# ----------------------------------------------------------------------------

def _guillotine(w, h, count, memo):
    """Place `count` axis-aligned squares of equal side s inside a w x h
    rectangle at the origin (so they fit exactly tiled by a guillotine),
    maximising s. Returns (s, list_of_(x0,y0) of square lower-left corners).
    Uses recursive splitting: place one square of side s at the corner, then
    recursively split the remaining L-shape via a horizontal/vertical cut.
    We approximate: choose best of many (rows x cols) tilings of the region.
    """
    if count <= 1:
        if count == 1:
            return min(w, h), [(0.0, 0.0)]
        return 0.0, []
    key = (round(w, 6), round(h, 6), count)
    if key in memo:
        return memo[key]

    best_s = 0.0
    best_pos = []

    # Try rows x cols grid that tiles the region (approx: ignore leftover)
    for rows in range(1, count + 1):
        for cols in range(1, count + 1):
            if rows * cols > count:
                continue
            s = min(w / cols, h / rows)
            if s <= 0.0:
                continue
            if s > best_s:
                best_s = s
                best_pos = [((i + 0.5) * s, (j + 0.5) * s)
                            for i in range(cols) for j in range(rows)]

    # Recursive guillotine: split into two sub-rectangles
    for cut in range(1, count):
        # vertical split at some x
        for frac in (0.5,):
            xw = w * frac
            if xw > 1e-6 and w - xw > 1e-6:
                s1, p1 = _guillotine(xw, h, cut, memo)
                s2, p2 = _guillotine(w - xw, h, count - cut, memo)
                if p1 and p2:
                    s = min(s1, s2)
                    if s > best_s:
                        best_s = s
                        best_pos = (p1 + [(x + xw, y) for x, y in p2])
            yh = h * frac
            if yh > 1e-6 and h - yh > 1e-6:
                s1, p1 = _guillotine(w, yh, cut, memo)
                s2, p2 = _guillotine(w, h - yh, count - cut, memo)
                if p1 and p2:
                    s = min(s1, s2)
                    if s > best_s:
                        best_s = s
                        best_pos = (p1 + [(x, y + yh) for x, y in p2])

    memo[key] = (best_s, best_pos)
    return best_s, best_pos


# ----------------------------------------------------------------------------
# layout candidates
# ----------------------------------------------------------------------------

def _grid_layout(n, rows, cols, ox, oy, w, h):
    """Place rows*cols equal squares of side min(w/cols, h/rows) in the
    sub-rectangle [ox, ox+w] x [oy, oy+h]. Returns list of squares and the
    free regions to fill with leftover count."""
    s = min(w / cols, h / rows)
    if s <= 0.0:
        return [], []
    sqs = []
    for i in range(cols):
        for j in range(rows):
            cx = ox + (i + 0.5) * s
            cy = oy + (j + 0.5) * s
            sqs.append((cx, cy, 0.0, s))
    placed = rows * cols
    leftover = n - placed
    free = []
    used_w = cols * s
    used_h = rows * s
    if used_w < w - 1e-9:
        free.append((ox + used_w, oy, w - used_w, h))
    if used_h < h - 1e-9:
        free.append((ox, oy + used_h, w, h - used_h))
    return sqs, (free, leftover, s)


def _fill_free(free_rects, leftover, memo):
    """Greedy fill of leftover squares into free rectangles."""
    if leftover <= 0 or not free_rects:
        return []
    sqs = []
    rem = leftover
    rects = [list(r) for r in free_rects]
    # sort by area descending
    rects.sort(key=lambda r: -(r[2] * r[3]))
    for (fx, fy, fw, fh) in rects:
        if rem <= 0:
            break
        s, pos = _guillotine(fw, fh, rem, memo)
        if s <= 1e-9:
            continue
        # place them
        for (px, py) in pos[:rem]:
            cx = fx + px
            cy = fy + py
            sqs.append((cx, cy, 0.0, s))
            rem -= 1
        if rem <= 0:
            break
    return sqs


def _total_penalty(sqs):
    n = len(sqs)
    pen = 0.0
    for i in range(n):
        pen += _inside_penalty(*sqs[i])
        for j in range(i + 1, n):
            pen += _overlap(sqs[i], sqs[j])
    return pen


def _best_layout(n):
    memo = {}
    best_val = -1.0
    best = None

    maxrc = max(2, math.isqrt(n) + 2)
    for rows in range(1, maxrc + 1):
        for cols in range(1, maxrc + 1):
            if rows * cols > n:
                continue
            sqs, info = _grid_layout(n, rows, cols, 0.0, 0.0, 1.0, 1.0)
            if not sqs:
                continue
            free, leftover, s = info
            extra = _fill_free(free, leftover, memo)
            cand = sqs + extra
            if len(cand) != n:
                continue
            if _total_penalty(cand) > 1e-7:
                continue
            val = sum(c[3] for c in cand)
            if val > best_val:
                best_val = val
                best = cand
    return best, best_val


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best, val = _best_layout(n)

    # baseline guaranteed-valid grid fallback
    k = math.isqrt(n)
    if k < 1:
        k = 1
    side = 1.0 / k
    base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(k) for j in range(k)]
    base += [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
    base = base[:n]
    base_val = sum(b[3] for b in base)

    if best is None or val < base_val:
        best = base

    if len(best) < n:
        best = list(best) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    best = best[:n]

    out = []
    for cx, cy, ang, sz in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        sz = min(max(sz, 0.0), 1.0)
        out.append((cx, cy, ang, sz))
    return out
# EVOLVE-BLOCK-END
