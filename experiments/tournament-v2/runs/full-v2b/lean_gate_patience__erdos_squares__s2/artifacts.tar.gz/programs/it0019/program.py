# EVOLVE-BLOCK-START
"""Packing squares in the unit square via max-expand refinement."""
import math
import random
import time


def _corners(cx, cy, ang, s):
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    return [
        (cx + h * c - h * sn, cy + h * sn + h * c),
        (cx - h * c - h * sn, cy - h * sn + h * c),
        (cx - h * c + h * sn, cy - h * sn - h * c),
        (cx + h * c + h * sn, cy + h * sn - h * c),
    ]


def _overlap(p, q):
    # SAT for two convex quads
    for poly in (p, q):
        for i in range(4):
            ax, ay = poly[i]
            bx, by = poly[(i + 1) % 4]
            nx, ny = -(by - ay), (bx - ax)
            pmin = pmax = p[0][0] * nx + p[0][1] * ny
            for a, b in p:
                d = a * nx + b * ny
                if d < pmin: pmin = d
                if d > pmax: pmax = d
            qmin = qmax = q[0][0] * nx + q[0][1] * ny
            for a, b in q:
                d = a * nx + b * ny
                if d < qmin: qmin = d
                if d > qmax: qmax = d
            if pmax <= qmin or qmax <= pmin:
                return False
    return True


def _inside(cx, cy, ang, s):
    for a, b in _corners(cx, cy, ang, s):
        if a < -1e-9 or a > 1 + 1e-9 or b < -1e-9 or b > 1 + 1e-9:
            return False
    return True


def _feasible(cfg):
    n = len(cfg)
    polys = [_corners(*c) for c in cfg]
    for i in range(n):
        if not _inside(cfg[i][0], cfg[i][1], cfg[i][2], cfg[i][3]):
            return False
        for j in range(i + 1, n):
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _max_side_fit(i, cfg, lo=0.0, hi_init=None):
    """Binary search largest side for square i keeping cfg feasible (others fixed)."""
    cx, cy, ang = cfg[i][0], cfg[i][1], cfg[i][2]
    n = len(cfg)
    others = [_corners(*cfg[j]) for j in range(n) if j != i]

    def ok(s):
        if not _inside(cx, cy, ang, s):
            return False
        pts = _corners(cx, cy, ang, s)
        for p in others:
            if _overlap(pts, p):
                return False
        return True

    hi = 1.0 if hi_init is None else hi_init
    if not ok(lo):
        return lo
    if ok(hi):
        return hi
    for _ in range(40):
        mid = (lo + hi) * 0.5
        if ok(mid):
            lo = mid
        else:
            hi = mid
    return lo


def _expand_refine(cfg, rounds=6):
    cfg = [[c[0], c[1], c[2], c[3]] for c in cfg]
    n = len(cfg)
    for _ in range(rounds):
        improved = False
        order = list(range(n))
        # prioritize smallest first
        order.sort(key=lambda i: cfg[i][3])
        for i in order:
            old = cfg[i][3]
            ns = _max_side_fit(i, cfg)
            if ns > old + 1e-9:
                cfg[i][3] = ns
                improved = True
        if not improved:
            break
    return [(c[0], c[1], c[2], c[3]) for c in cfg]


def _place_greedy(n, rng):
    base = 1.0 / math.sqrt(n)
    sizes = []
    for _ in range(n):
        r = rng.random()
        if r < 0.5:
            s = base * (0.5 + 0.9 * rng.random())
        else:
            s = base * (0.2 + 1.6 * rng.random())
        sizes.append(min(0.999, max(0.0, s)))
    sizes.sort(reverse=True)
    placed = []
    learn = rng.random()
    for s in sizes:
        if s <= 1e-9:
            placed.append((0.5, 0.5, 0.0, 0.0))
            continue
        best = None
        best_gap = -1.0
        for _ in range(20):
            a = rng.choice([0.0, 0.25, 0.5, 0.75, rng.random()])
            r = s * 0.5 * math.sqrt(2)
            if r > 0.5:
                break
            cx = rng.uniform(r, 1.0 - r)
            cy = rng.uniform(r, 1.0 - r)
            pts = _corners(cx, cy, a, s)
            ok = True
            gap = 1e9
            for p in placed:
                if p[3] <= 1e-12:
                    continue
                q = _corners(*p)
                if _overlap(pts, q):
                    ok = False
                    break
                cx1 = sum(x for x, _ in q) / 4.0
                cy1 = sum(y for _, y in q) / 4.0
                gap = min(gap, math.hypot(cx - cx1, cy - cy1))
            if ok:
                if learn < 0.5:
                    best = (cx, cy, a, s)
                    break
                if gap > best_gap:
                    best_gap = gap
                    best = (cx, cy, a, s)
            else:
                if best is None and gap > best_gap:
                    best_gap = gap
                    best = (cx, cy, a, s)
        if best is None:
            placed.append((0.5, 0.5, 0.0, 0.0))
        else:
            placed.append(best)
    return placed


def _cascade(cfg):
    """Drop to a feasible config by scaling sides & recentering."""
    cfg = [[c[0], c[1], c[2], c[3]] for c in cfg]
    for c in cfg:
        c[0] = min(1.0, max(0.0, c[0]))
        c[1] = min(1.0, max(0.0, c[1]))
    # scale all
    lo, hi = 0.0, 1.0
    def ok(f):
        for c in cfg:
            c[3] = c[3] * f
        res = _feasible([(c[0], c[1], c[2], c[3]) for c in cfg])
        for c in cfg:
            c[3] = c[3] / f
        return res
    if ok(1.0):
        return [(c[0], c[1], c[2], c[3]) for c in cfg]
    for _ in range(40):
        mid = (lo + hi) * 0.5
        if ok(mid):
            lo = mid
        else:
            hi = mid
    return [(c[0], c[1], c[2], c[3] * lo) for c in cfg]


def _total(cfg):
    return sum(c[3] for c in cfg)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    t0 = time.time()
    rng = random.Random(987654 + n)
    time_budget = 50.0

    best = None
    best_score = -1.0

    # deterministic grid baseline
    k = int(math.isqrt(n))
    if k * k == n and k > 0:
        s = 1.0 / k
        grid = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        ref = _expand_refine(grid, rounds=8)
        sc = _total(ref)
        if _feasible(ref) and sc > best_score:
            best, best_score = ref, sc

    attempts = 0
    while time.time() - t0 < time_budget and attempts < 500:
        attempts += 1
        cfg = _place_greedy(n, rng)
        cfg = _cascade(cfg)
        if not _feasible(cfg):
            continue
        cfg = _expand_refine(cfg, rounds=8)
        sc = _total(cfg)
        # perturb and re-refine
        for _ in range(2):
            if time.time() - t0 > time_budget:
                break
            cand = [[c[0] + rng.uniform(-0.02, 0.02),
                     c[1] + rng.uniform(-0.02, 0.02),
                     c[2] + rng.choice([0.0, 0.01, -0.01, 0.03]),
                     c[3]] for c in cfg]
            cand = _cascade(cand)
            if not _feasible(cand):
                continue
            cand = _expand_refine(cand, rounds=6)
            csc = _total(cand)
            if csc > sc:
                cfg, sc = cand, csc
        if _feasible(cfg) and sc > best_score:
            best, best_score = cfg, sc

    if best is None:
        # safe fallback grid
        s = 1.0 / (math.isqrt(n) + 1)
        g = []
        cnt = 0
        for i in range(int(1.0 / s) + 1):
            for j in range(int(1.0 / s) + 1):
                if cnt < n:
                    g.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                    cnt += 1
        while len(g) < n:
            g.append((0.5, 0.5, 0.0, 0.0))
        best = g[:n]

    out = []
    for c in best:
        cx = min(1.0, max(0.0, c[0]))
        cy = min(1.0, max(0.0, c[1]))
        a = c[2] % 1.0
        s = min(1.0, max(0.0, c[3]))
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    out = out[:n]

    if not _feasible(out):
        out = _cascade(out)
        if not _feasible(out):
            out = [(0.5, 0.5, 0.0, 0.0)] * n
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    out = out[:n]
    return out
# EVOLVE-BLOCK-END

