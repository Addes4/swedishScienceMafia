# EVOLVE-BLOCK-START
"""Randomized multi-start packer with physics relaxation, structured seeding,
and a corner-placement constructor.

Objective: maximise the sum of side lengths of n squares (axis-aligned or
rotated) packed without interior overlap inside the unit square.
"""
import math
import random


def _extent(ang, sz):
    """Half-extents of the axis-aligned bounding box of a rotated square."""
    t = ang * 2.0 * math.pi
    c, s = abs(math.cos(t)), abs(math.sin(t))
    h = sz * 0.5
    return h * (c + s), h * (c + s)


def _penetration(a, b):
    """Approximate penetration depth (positive if overlapping)."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 1e-12 or bsz <= 1e-12:
        return -1.0
    ta = aa * 2.0 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    tb = ba * 2.0 * math.pi
    cb, sb = math.cos(tb), math.sin(tb)
    ha = asz * 0.5
    hb = bsz * 0.5
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    minov = float('inf')
    for (ux, uy) in axes:
        ea = abs(ux * ca + uy * sa) + abs(ux * (-sa) + uy * ca)
        eb = abs(ux * cb + uy * sb) + abs(ux * (-sb) + uy * cb)
        dist = abs(ux * (ax - bx) + uy * (ay - by))
        ov = ha * ea + hb * eb - dist
        if ov < minov:
            minov = ov
    return minov


def _clamp_in_unit(sq, i):
    """Clamp centre of square i so its rotated bbox stays inside the unit square."""
    ex, ey = _extent(sq[i][2], sq[i][3])
    lo_x, hi_x = ex, 1.0 - ex
    lo_y, hi_y = ey, 1.0 - ey
    if lo_x > hi_x:
        sq[i][0] = 0.5
    else:
        sq[i][0] = min(max(sq[i][0], lo_x), hi_x)
    if lo_y > hi_y:
        sq[i][1] = 0.5
    else:
        sq[i][1] = min(max(sq[i][1], lo_y), hi_y)


def _project(squares, iters=200):
    """Push overlapping squares apart; keep each inside the unit square."""
    sq = [list(s) for s in squares]
    m = len(sq)
    for i in range(m):
        _clamp_in_unit(sq, i)
    for _ in range(iters):
        moved = False
        for i in range(m):
            if sq[i][3] <= 1e-12:
                continue
            for j in range(i + 1, m):
                if sq[j][3] <= 1e-12:
                    continue
                ov = _penetration(sq[i], sq[j])
                if ov > 1e-9:
                    moved = True
                    dx = sq[i][0] - sq[j][0]
                    dy = sq[i][1] - sq[j][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        ang = random.random() * 2.0 * math.pi
                        dx, dy, d = math.cos(ang), math.sin(ang), 1.0
                    push = ov * 0.5 + 1e-4
                    ux, uy = dx / d, dy / d
                    sq[i][0] += ux * push
                    sq[i][1] += uy * push
                    sq[j][0] -= ux * push
                    sq[j][1] -= uy * push
        for i in range(m):
            _clamp_in_unit(sq, i)
        if not moved:
            break
    return [tuple(s) for s in sq]


def _total_overlap(squares):
    tot = 0.0
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 1e-12:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 1e-12:
                continue
            ov = _penetration(squares[i], squares[j])
            if ov > 0:
                tot += ov
    return tot


def _max_outside(squares):
    worst = 0.0
    for (cx, cy, ang, sz) in squares:
        if sz <= 1e-12:
            continue
        ex, ey = _extent(ang, sz)
        worst = max(worst, ex - cx, cx - (1.0 - ex), ey - cy, cy - (1.0 - ey))
    return worst


def _feasible(squares):
    return _max_outside(squares) <= 1e-7 and _total_overlap(squares) <= 1e-6


def _greedy_start(n, rng):
    """Build a configuration by placing squares one by one."""
    base = 1.0 / max(1.0, math.sqrt(n))
    sizes = []
    for _ in range(n):
        f = rng.uniform(0.55, 1.35)
        sizes.append(min(0.999, base * f * rng.uniform(0.8, 1.2)))
    order = list(range(n))
    rng.shuffle(order)

    placed = []
    for idx in order:
        sz = sizes[idx]
        best = None
        best_score = -1e18
        for _try in range(40):
            ang = rng.choice([0.0, 0.25, rng.random()])
            ex, ey = _extent(ang, sz)
            lo_x, hi_x = ex, 1.0 - ex
            lo_y, hi_y = ey, 1.0 - ey
            if lo_x > hi_x or lo_y > hi_y:
                continue
            cx = rng.uniform(lo_x, hi_x)
            cy = rng.uniform(lo_y, hi_y)
            cand = (cx, cy, ang, sz)
            ov = 0.0
            ok = True
            for p in placed:
                ov += _penetration(cand, p)
                if ov > 0.25 * sz:
                    ok = False
                    break
            score = -ov
            if ok and score > best_score:
                best_score = score
                best = cand
        if best is None:
            ex, ey = _extent(0.0, sz)
            cx = min(max(0.5, ex), 1.0 - ex) if ex <= 0.5 else 0.5
            cy = min(max(0.5, ey), 1.0 - ey) if ey <= 0.5 else 0.5
            best = (cx, cy, 0.0, sz)
        placed.append(best)
    return placed


def _corner_candidates(placed):
    """Candidate lower-left corner points for a new square."""
    pts = [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0)]
    for (cx, cy, ang, sz) in placed:
        if sz <= 1e-12:
            continue
        ex, ey = _extent(ang, sz)
        # top-right, top-left, bottom-right corners of the bbox
        pts.append((cx + ex, cy + ey))
        pts.append((cx - ex, cy + ey))
        pts.append((cx + ex, cy - ey))
        pts.append((cx, cy + ey))
        pts.append((cx + ex, cy))
    return pts


def _max_side_at(px, py, placed, orient=0.0):
    """Largest axis-aligned square with lower-left at (px,py) not overlapping."""
    if px < -1e-9 or py < -1e-9 or px > 1.0 + 1e-9 or py > 1.0 + 1e-9:
        return 0.0
    hi = min(1.0 - px, 1.0 - py)
    if hi <= 0:
        return 0.0
    lo = 0.0
    # binary search the largest side whose centre square does not overlap
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        cx = px + mid * 0.5
        cy = py + mid * 0.5
        cand = (cx, cy, orient, mid)
        bad = False
        for p in placed:
            if _penetration(cand, p) > 1e-9:
                bad = True
                break
        if bad:
            hi = mid
        else:
            lo = mid
    return lo


def _corner_start(n, rng):
    """Place squares largest first into the tightest free corner."""
    base = 1.0 / max(1.0, math.sqrt(n))
    struct = rng.random() < 0.5
    placed = []
    # choose how many squares placed constructively; rest as tiny points
    for k in range(n):
        best = None
        best_side = -1.0
        cands = _corner_candidates(placed)
        if struct:
            # prefer tight geometric spots
            target = base * (1.0 + 0.6 * rng.random())
        else:
            target = None
        for (px, py) in cands:
            s = _max_side_at(px, py, placed, 0.0)
            if s <= 1e-9:
                continue
            score = s if target is None else -abs(s - target)
            if score > best_side:
                best_side = score
                best = (px + s * 0.5, py + s * 0.5, 0.0, s)
        if best is None:
            # try a few random spots
            for _ in range(20):
                px = rng.random()
                py = rng.random()
                s = _max_side_at(px, py, placed, 0.0)
                if s > best_side:
                    best_side = s
                    best = (px + s * 0.5, py + s * 0.5, 0.0, s)
        if best is None:
            best = (0.5, 0.5, 0.0, 0.0)
        placed.append(best)
    return placed


def _grow_and_nudge(squares, rng, rounds=6):
    """Try to grow each square slightly; keep only feasible improvements."""
    best = [list(s) for s in squares]
    for _ in range(rounds):
        improved = False
        order = list(range(len(best)))
        rng.shuffle(order)
        for i in order:
            if best[i][3] <= 1e-12:
                continue
            delta = 0.01 * (1.0 - best[i][3]) + 1e-4
            trial = [s[:] for s in best]
            trial[i][3] = min(0.999, best[i][3] + delta)
            trial = _project(trial, iters=80)
            if _feasible(trial) and sum(s[3] for s in trial) > sum(s[3] for s in best) + 1e-12:
                best = [list(s) for s in trial]
                improved = True
        if not improved:
            break
    return [tuple(s) for s in best]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(987654321)
    best = None
    best_score = -1e18

    tries = 40 if n <= 12 else (24 if n <= 30 else 12)

    # Structured seed: grid-based start.
    k = math.isqrt(n)
    if k >= 1:
        side = 1.0 / k
        grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
        grid = grid[:n]
        grid = _project(grid, iters=120)
        if _feasible(grid):
            sc = sum(s[3] for s in grid)
            if sc > best_score:
                best_score = sc
                best = grid

    # Corner-placement constructive starts.
    for _ in range(12):
        start = _corner_start(n, rng)
        refined = _project(start, iters=150)
        sc = sum(s[3] for s in refined)
        if _feasible(refined) and sc > best_score:
            best_score = sc
            best = refined

    for t in range(tries):
        start = _greedy_start(n, rng)
        refined = _project(start, iters=120)
        sc = sum(s[3] for s in refined)
        if _feasible(refined) and sc > best_score:
            best_score = sc
            best = refined

    if best is not None and _feasible(best):
        grown = _grow_and_nudge(best, rng)
        if _feasible(grown) and sum(s[3] for s in grown) > best_score:
            best = grown
            best_score = sum(s[3] for s in grown)

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    result = list(best)
    if len(result) < n:
        result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]
# EVOLVE-BLOCK-END
