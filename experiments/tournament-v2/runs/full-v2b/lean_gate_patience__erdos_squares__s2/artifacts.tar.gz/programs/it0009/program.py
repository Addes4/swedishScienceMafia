# EVOLVE-BLOCK-START
"""Grid of equal squares plus a strip packed with equal squares, jointly optimised."""
import math


def solve(n):
    if n <= 0:
        return []
    best = None
    best_score = -1.0

    def consider(squares, total):
        nonlocal best, best_score
        if total > best_score:
            best_score = total
            best = squares

    # Option A: r x c grid of equal squares filling the whole unit square,
    # leftover squares packed into a strip of the largest remaining region.
    for r in range(1, n + 1):
        for c in range(1, n + 1):
            if r * c > n:
                continue
            s = min(1.0 / r, 1.0 / c)
            used = r * c
            rem = n - used
            squares = []
            w = c * s
            h = r * s
            for i in range(c):
                for j in range(r):
                    squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
            if rem == 0:
                consider(list(squares), used * s)
                continue
            strip_w = 1.0 - w
            strip_h = 1.0 - h
            # split rem between right strip (a) and top strip (b)
            for a in range(rem + 1):
                b = rem - a
                cand = []
                ok = True
                if a > 0:
                    if strip_w <= 0:
                        ok = False
                    else:
                        ss = min(strip_w, strip_h / a)
                        if ss <= 0:
                            ok = False
                        else:
                            for k in range(a):
                                cand.append((w + ss / 2, (k + 0.5) * ss, 0.0, ss))
                if ok and b > 0:
                    if strip_h <= 0:
                        ok = False
                    else:
                        avail_w = 1.0
                        ss = min(avail_w / b, strip_h)
                        if ss <= 0:
                            ok = False
                        else:
                            for k in range(b):
                                cand.append(((k + 0.5) * ss, 1.0 - ss / 2, 0.0, ss))
                if ok:
                    consider(squares + cand, used * s + sum(q[3] for q in cand))

    # Option B: two blocks side by side / stacked, jointly sized.
    # A left column of c1 columns x r1 rows and a right column of c2 x r2,
    # searched over all splits of n, with a shared height and widths summing to 1.
    for r1 in range(1, n + 1):
        for c1 in range(1, n + 1):
            u1 = r1 * c1
            if u1 >= n:
                if u1 == n:
                    # full grid already covered
                    pass
                continue
            rem = n - u1
            for r2 in range(1, rem + 1):
                if rem % r2 != 0:
                    continue
                c2 = rem // r2
                # grid A occupies w1 x hA, grid B occupies w2 x hB with w1+w2<=1
                # sizes sa, sb; hA=r1*sa, hB=r2*sb, widths w1=c1*sa, w2=c2*sb
                # maximize u1*sa + u2*sb subject to c1*sa+c2*sb<=1,
                # r1*sa<=1, r2*sb<=1. LP optimum at a vertex.
                cands = []
                # vertex: both height constraints tight if feasible
                sa = 1.0 / r1
                sb = 1.0 / r2
                if c1 * sa + c2 * sb <= 1.0 + 1e-12:
                    cands.append((sa, sb))
                # vertex: width constraint tight, one height tight
                # c1*sa + c2*sb = 1 with r1*sa=1 -> sb=(1-c1/r1)/c2
                if r1 * (1.0 / r1) <= 1.0:
                    sa = 1.0 / r1
                    sb = (1.0 - c1 * sa) / c2
                    if sb > 0 and r2 * sb <= 1.0 + 1e-12:
                        cands.append((sa, sb))
                sa = 1.0 / r1
                sb = 1.0 / r2
                sa2 = (1.0 - c2 * sb) / c1
                if sa2 > 0 and r1 * sa2 <= 1.0 + 1e-12:
                    cands.append((sa2, sb))
                # width tight, both widths equal split of size limited by height
                for sa, sb in cands:
                    if sa <= 0 or sb <= 0:
                        continue
                    if c1 * sa + c2 * sb > 1.0 + 1e-9:
                        continue
                    if r1 * sa > 1.0 + 1e-9 or r2 * sb > 1.0 + 1e-9:
                        continue
                    starts_b = c1 * sa
                    sq = []
                    for i in range(c1):
                        for j in range(r1):
                            sq.append(((i + 0.5) * sa, (j + 0.5) * sa, 0.0, sa))
                    for i in range(c2):
                        for j in range(r2):
                            sq.append((starts_b + (i + 0.5) * sb, (j + 0.5) * sb, 0.0, sb))
                    consider(sq, u1 * sa + (rem) * sb)

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return [tuple(x) for x in best[:n]]
# EVOLVE-BLOCK-END
