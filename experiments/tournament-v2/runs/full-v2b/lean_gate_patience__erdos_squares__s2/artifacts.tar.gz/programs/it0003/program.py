# EVOLVE-BLOCK-START
"""Grid + rotation search: pick the best axis-aligned grid packing, then try
small rotations of the whole lattice to see if a tilted arrangement fits better."""
import math


def _grid(n, k):
    """k columns x ceil(n/k) rows grid, plus size-zero squares for the rest."""
    rows = (n + k - 1) // k
    # side limited by both dimensions
    side = min(1.0 / k, 1.0 / rows)
    sq = []
    for i in range(k):
        for j in range(rows):
            if len(sq) < n:
                sq.append((0.5, 0.5, 0.0, side))
    # place them properly
    out = []
    for i in range(k):
        for j in range(rows):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]


def _value(sq):
    return sum(s[3] for s in sq)


def _try_rotate(sq, ang):
    """Rotate every square about its own centre by ang; centres unchanged."""
    return [(x, y, ang, s) for (x, y, a, s) in sq]


def solve(n):
    if n == 0:
        return []
    best = None
    best_val = -1.0
    # candidate grids: square-ish k
    kmax = min(n, max(1, math.isqrt(n) + 2))
    for k in range(1, kmax + 1):
        sq = _grid(n, k)
        v = _value(sq)
        if v > best_val:
            best_val = v
            best = sq
    # try a small set of rotations applied to the whole packing
    for ang in (0.05, 0.1, 0.125, 0.15, 0.2):
        rotsq = _try_rotate(best, ang)
        # verify fit roughly (bounding of axis-aligned grid under small rotation)
        # only accept if all squares stay within the unit square
        ok = True
        for (x, y, a, s) in rotsq:
            r = s * (abs(math.cos(2 * math.pi * a)) + abs(math.sin(2 * math.pi * a)))
            # rotated square needs half-diagonal along axes depending on angle
            ca = abs(math.cos(2 * math.pi * a))
            sa = abs(math.sin(2 * math.pi * a))
            hx = s / 2 * (ca + sa)
            hy = s / 2 * (ca + sa)
            if x - hx < -1e-9 or x + hx > 1 + 1e-9 or y - hy < -1e-9 or y + hy > 1 + 1e-9:
                ok = False
                break
        if ok and _value(rotsq) > best_val:
            best_val = _value(rotsq)
            best = rotsq
    return best
# EVOLVE-BLOCK-END
