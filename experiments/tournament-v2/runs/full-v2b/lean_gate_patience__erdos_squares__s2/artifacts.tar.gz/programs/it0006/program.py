# EVOLVE-BLOCK-START
"""Grid search plus recursive guillotine packing of the leftover L-shaped strip."""
import math


def _pack_rect(x, y, w, h, count, memo):
    """Pack up to `count` squares into rectangle (x,y,w,h) via guillotine splits,
    returning a list of (cx, cy, side). Best-effort, memoized on (w,h,count)."""
    if count <= 0 or w < 1e-9 or h < 1e-9:
        return []
    key = (round(w, 6), round(h, 6), count)
    if key in memo:
        return [(px + x, py + y, ps) for px, py, ps in memo[key]]
    s = min(w, h)
    r1w = w - s      # right sub-rectangle width
    r2h = h - s      # top sub-rectangle height
    bestv = -1.0
    best = []
    for a in range(count):
        b = count - 1 - a
        p1 = _pack_rect(0.0, 0.0, r1w, h, a, memo)     # right of the square
        p2 = _pack_rect(0.0, 0.0, s, r2h, b, memo)     # above the square
        v = s + sum(q[2] for q in p1) + sum(q[2] for q in p2)
        if v > bestv:
            bestv = v
            best = [(s / 2.0, s / 2.0, s)]
            best += [(q[0] + s, q[1], q[2]) for q in p1]
            best += [(q[0], q[1] + s, q[2]) for q in p2]
    memo[key] = best
    return [(px + x, py + y, ps) for px, py, ps in best]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    best = None
    best_score = -1.0

    for r in range(1, n + 1):
        for c in range(1, n + 1):
            if r * c > n:
                continue
            s = min(1.0 / r, 1.0 / c)
            w = c * s
            h = r * s
            used = r * c
            rem = n - used

            grid = []
            for i in range(c):
                for j in range(r):
                    grid.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))

            if rem == 0:
                total = used * s
                if total > best_score:
                    best_score = total
                    best = grid
                continue

            # Leftover region: right strip [w,1]x[0,1] and top strip [0,w]x[h,1].
            memo = {}
            rw = 1.0 - w
            th = 1.0 - h
            for a in range(rem + 1):
                b = rem - a
                p1 = _pack_rect(w, 0.0, rw, 1.0, a, memo) if rw > 1e-9 else []
                p2 = _pack_rect(0.0, h, w, th, b, memo) if th > 1e-9 else []
                total = used * s + sum(q[2] for q in p1) + sum(q[2] for q in p2)
                if total > best_score:
                    best_score = total
                    best = grid + p1 + p2

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)]
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return [tuple(x) for x in best[:n]]
# EVOLVE-BLOCK-END
