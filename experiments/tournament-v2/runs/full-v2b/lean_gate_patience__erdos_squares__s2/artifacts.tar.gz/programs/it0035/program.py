# EVOLVE-BLOCK-START
"""Randomized multi-start physics-style packer with a robust feasibility projection.

Strategy: treat the sum of side lengths as the objective.  We repeatedly build a
configuration by greedily inserting squares (largest sizes first) with random
jitter and a few random rotation candidates, then refine the whole layout with an
overlap-relaxation loop (push apart overlapping pairs, clamp everything to the
unit square using rotated bounding-box half-extents).  Many random restarts,
keep the best feasible configuration.  Structured grid seeds are also tried.
"""
import math
import random


def _extent(ang, sz):
    """Half-extents of the axis-aligned bounding box of a rotated square."""
    t = ang * 2.0 * math.pi
    c, s = abs(math.cos(t)), abs(math.sin(t))
    h = sz * 0.5
    return h * (c + s), h * (c + s)


def _penetration(a, b):
    """Approximate penetration depth (positive if overlapping)."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 1e-12 or bsz <= 1e-12:
        return -1.0
    ta = aa * 2.0 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    tb = ba * 2.0 * math.pi
    cb, sb = math.cos(tb), math.sin(tb)
    ha = asz * 0.5
    hb = bsz * 0.5
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    minov = float('inf')
    for (ux, uy) in axes:
        ea = abs(ux * ca + uy * sa) + abs(ux * (-sa) + uy * ca)
        eb = abs(ux * cb + uy * sb) + abs(ux * (-sb) + uy * cb)
        dist = abs(ux * (ax - bx) + uy * (ay - by))
        ov = ha * ea + hb * eb - dist
        if ov < minov:
            minov = ov
    return minov


def _clamp_in_unit(sq, i):
    """Clamp centre of square i so its rotated bbox stays inside the unit square."""
    ex, ey = _extent(sq[i][2], sq[i][3])
    lo_x, hi_x = ex, 1.0 - ex
    lo_y, hi_y = ey, 1.0 - ey
    if lo_x > hi_x:
        sq[i][0] = 0.5
    else:
        sq[i][0] = min(max(sq[i][0], lo_x), hi_x)
    if lo_y > hi_y:
        sq[i][1] = 0.5
    else:
        sq[i][1] = min(max(sq[i][1], lo_y), hi_y)


def _project(squares, iters=200):
    """Push overlapping squares apart; always keep each inside the unit square."""
    sq = [list(s) for s in squares]
    m = len(sq)
    for i in range(m):
        _clamp_in_unit(sq, i)
    for _ in range(iters):
        moved = False
        for i in range(m):
            if sq[i][3] <= 1e-12:
                continue
            for j in range(i + 1, m):
                if sq[j][3] <= 1e-12:
                    continue
                ov = _penetration(sq[i], sq[j])
                if ov > 1e-9:
                    moved = True
                    dx = sq[i][0] - sq[j][0]
                    dy = sq[i][1] - sq[j][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        ang = random.random() * 2.0 * math.pi
                        dx, dy, d = math.cos(ang), math.sin(ang), 1.0
                    push = ov * 0.5 + 1e-4
                    ux, uy = dx / d, dy / d
                    sq[i][0] += ux * push
                    sq[i][1] += uy * push
                    sq[j][0] -= ux * push
                    sq[j][1] -= uy * push
        for i in range(m):
            _clamp_in_unit(sq, i)
        if not moved:
            break
    return [tuple(s) for s in sq]


def _total_overlap(squares):
    tot = 0.0
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 1e-12:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 1e-12:
                continue
            ov = _penetration(squares[i], squares[j])
            if ov > 0:
                tot += ov
    return tot


def _max_outside(squares):
    """How far any square sticks out of the unit square."""
    worst = 0.0
    for (cx, cy, ang, sz) in squares:
        if sz <= 1e-12:
            continue
        ex, ey = _extent(ang, sz)
        worst = max(worst, ex - cx, cx - (1.0 - ex), ey - cy, cy - (1.0 - ey))
    return worst


def _feasible(squares):
    return _max_outside(squares) <= 1e-7 and _total_overlap(squares) <= 1e-6


def _row_seed(n, rows):
    """Axis-aligned layout: n squares in `rows` horizontal rows, each row's
    squares equal-sized and filling the unit square exactly in that row."""
    if rows < 1:
        rows = 1
    # distribute n squares among rows as evenly as possible
    counts = [n // rows] * rows
    for i in range(n % rows):
        counts[i] += 1
    # row heights proportional to square sizes; row width filled by its squares
    # Use the classic equal-square-in-row layout: row i has c_i squares side s_i
    # chosen so c_i*s_i = 1 (fill width) and sum(s_i) = 1 (fill height).
    # Then s_i = 1/c_i.  Normalize so sum(s_i)=1 -> scale.
    sizes = [1.0 / c for c in counts if c > 0]
    tot = sum(sizes)
    if tot <= 0:
        return None
    sizes = [s / tot for s in sizes]
    squares = []
    y = 0.0
    for c, s in zip(counts, sizes):
        if c <= 0:
            continue
        w = 1.0 / c
        d = min(w, s)
        # shrink size to fit both width per cell and row height
        sz = min(d, s)
        for k in range(c):
            cx = (k + 0.5) * (1.0 / c)
            cy = y + s * 0.5
            squares.append((cx, cy, 0.0, sz))
        y += s
    return squares


def _structured_seeds(n):
    """Yield deterministic grid-like seed layouts."""
    seeds = []
    if n == 1:
        return [[(0.5, 0.5, 0.0, 1.0)]]

    # perfect grid seeds
    for a in range(1, n + 1):
        if n % a != 0:
            continue
        b = n // a
        # a columns, b rows -> cell side 1/max(a,b)
        cols, rows = a, b
        s = 1.0 / max(cols, rows)
        grid = []
        for i in range(cols):
            for j in range(rows):
                grid.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        seeds.append(grid)

    # row-layout seeds for various row counts
    for rows in range(1, n + 1):
        s = _row_seed(n, rows)
        if s is not None:
            seeds.append(s)

    # sqrt grid with remainder as tiny points
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(k) for j in range(k)]
    grid = grid[:n]
    while len(grid) < n:
        grid.append((0.5, 0.5, 0.0, 0.0))
    seeds.append(grid)
    return seeds


def _greedy_start(n, rng):
    """Build a configuration by placing squares one by one."""
    base = 1.0 / max(1.0, math.sqrt(n))
    sizes = []
    for _ in range(n):
        f = rng.uniform(0.55, 1.35)
        sizes.append(min(0.999, base * f * rng.uniform(0.8, 1.2)))
    order = list(range(n))
    rng.shuffle(order)

    placed = []
    for idx in order:
        sz = sizes[idx]
        best = None
        best_score = -1e18
        for _try in range(40):
            ang = rng.choice([0.0, 0.25, rng.random()])
            ex, ey = _extent(ang, sz)
            lo_x, hi_x = ex, 1.0 - ex
            lo_y, hi_y = ey, 1.0 - ey
            if lo_x > hi_x or lo_y > hi_y:
                continue
            cx = rng.uniform(lo_x, hi_x)
            cy = rng.uniform(lo_y, hi_y)
            cand = (cx, cy, ang, sz)
            ov = 0.0
            ok = True
            for p in placed:
                ov += _penetration(cand, p)
                if ov > 0.25 * sz:
                    ok = False
                    break
            score = -ov
            if ok and score > best_score:
                best_score = score
                best = cand
        if best is None:
            ex, ey = _extent(0.0, sz)
            cx = min(max(0.5, ex), 1.0 - ex) if ex <= 0.5 else 0.5
            cy = min(max(0.5, ey), 1.0 - ey) if ey <= 0.5 else 0.5
            best = (cx, cy, 0.0, sz)
        placed.append(best)
    return placed


def _grow_and_nudge(squares, rng, rounds=6):
    """Try to grow each square slightly; keep only strictly feasible improvements."""
    best = [list(s) for s in squares]
    for _ in range(rounds):
        improved = False
        order = list(range(len(best)))
        rng.shuffle(order)
        for i in order:
            if best[i][3] <= 1e-12:
                continue
            delta = 0.01 * (1.0 - best[i][3]) + 1e-4
            trial = [s[:] for s in best]
            trial[i][3] = min(0.999, best[i][3] + delta)
            trial = _project(trial, iters=80)
            if _feasible(trial) and sum(s[3] for s in trial) > sum(s[3] for s in best) + 1e-12:
                best = [list(s) for s in trial]
                improved = True
        if not improved:
            break
    return [tuple(s) for s in best]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(987654321)
    best = None
    best_score = -1e18

    # --- Structured seeds first ---
    for seed in _structured_seeds(n):
        cand = _project(seed, iters=150)
        if _feasible(cand):
            sc = sum(s[3] for s in cand)
            if sc > best_score:
                best_score = sc
                best = cand

    # --- Random greedy multi-start ---
    tries = 40 if n <= 12 else (24 if n <= 30 else 12)
    for t in range(tries):
        start = _greedy_start(n, rng)
        refined = _project(start, iters=120)
        sc = sum(s[3] for s in refined)
        if _feasible(refined) and sc > best_score:
            best_score = sc
            best = refined

    # --- Local refinement ---
    if best is not None and _feasible(best):
        grown = _grow_and_nudge(best, rng)
        if _feasible(grown) and sum(s[3] for s in grown) > best_score:
            best = grown
            best_score = sum(s[3] for s in grown)

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    result = list(best)
    if len(result) < n:
        result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]
# EVOLVE-BLOCK-END
