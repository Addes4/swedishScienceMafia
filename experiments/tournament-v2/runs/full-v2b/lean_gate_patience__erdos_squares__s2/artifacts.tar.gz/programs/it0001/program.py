# EVOLVE-BLOCK-START
"""Packing squares of varying sizes: guillotine grid + greedy size search + local growth."""
import math


def _layout_from_sizes(sizes):
    """Pack given side lengths (descending) into the unit square axis-aligned via
    a simple shelf algorithm. Return list of (cx, cy, 0.0, s) or None if infeasible."""
    # greedy shelf packing: place squares left-to-right on shelves
    shelves = []  # each shelf: (y_bottom, height, x_used)
    placements = []
    x = 0.0
    y = 0.0
    shelf_h = 0.0
    pos = []
    for s in sizes:
        if x + s > 1.0 + 1e-12:
            # new shelf
            y += shelf_h
            if y > 1.0 + 1e-12:
                return None
            x = 0.0
            shelf_h = 0.0
        if y + s > 1.0 + 1e-12:
            return None
        pos.append((x + s / 2.0, y + s / 2.0, 0.0, s))
        x += s
        shelf_h = max(shelf_h, s)
    return pos


def _grid_layout(n, k):
    side = 1.0 / k
    return [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(k) for j in range(k)]


def _greedy_sizes(n):
    """Try to find n sizes maximising sum via simple heuristic: fill grid of m,
    leave remainder tiny? Use a recursive shrink search instead."""
    best = None
    best_sum = -1.0
    # Try starting from a k x k grid where one row/col is used differently.
    k = math.isqrt(n)
    # Candidate: k*k full cells (side 1/k) + remaining as equal smaller square
    # fitted by splitting space? Instead try uniform-size packing of all n:
    # n squares uniform side s fits in ceil(sqrt(n)) grid only.
    # Use shelf packing with sizes = one big + rest small.
    for big_k in (k, k + 1):
        if big_k < 1:
            continue
        base = 1.0 / big_k
        # place big_k*big_k squares of size base in grid, remainder need space
        pass
    return None


def _optimize(n):
    """Coordinate descent: start from grid, try scaling each square up/down and
    repositioning to increase sum while avoiding overlaps."""
    k = math.isqrt(n)
    squares = _grid_layout(n, k)
    # pad with zero squares
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]

    def sep(a, b):
        # approximate separation check via AABB of rotated squares
        ha = a[3] / 2.0
        hb = b[3] / 2.0
        # conservative circle overlap radius = s*sqrt(2)/2
        ra = a[3] * math.sqrt(2) / 2.0
        rb = b[3] * math.sqrt(2) / 2.0
        d = math.hypot(a[0] - b[0], a[1] - b[1])
        return d + 1e-12 >= ra + rb

    improved = True
    it = 0
    while improved and it < 200:
        improved = False
        it += 1
        for i in range(n):
            cx, cy, ang, s = squares[i]
            # try growing this square
            for grow in (1.1, 1.05, 1.02):
                ns = s * grow
                if ns <= 0:
                    continue
                r = ns * math.sqrt(2) / 2.0
                # keep inside unit square (use AABB for safety)
                # approximate AABB half-extent
                ext = ns / 2.0 * (abs(math.cos(2 * math.pi * ang)) +
                                  abs(math.sin(2 * math.pi * ang)))
                if cx - ext < -1e-9 or cx + ext > 1 + 1e-9:
                    continue
                if cy - ext < -1e-9 or cy + ext > 1 + 1e-9:
                    continue
                trial = (cx, cy, ang, ns)
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if not sep(trial, squares[j]):
                        ok = False
                        break
                if ok:
                    squares[i] = trial
                    improved = True
                    break
    return squares


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    squares = _optimize(n)
    # final safety clamp
    out = []
    for cx, cy, ang, s in squares:
        s = max(0.0, min(1.0, s))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        out.append((cx, cy, ang % 1.0, s))
    return out[:n]
# EVOLVE-BLOCK-END
