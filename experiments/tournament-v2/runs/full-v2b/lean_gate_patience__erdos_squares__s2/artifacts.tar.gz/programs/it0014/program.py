# EVOLVE-BLOCK-START
"""Greedy placement + iterative "grow & re-settle" refinement for packing
squares in the unit square to maximise the sum of their side lengths.

Strategy:
 1. Build a deterministic axis-aligned grid baseline (always valid).
 2. Build randomized greedy packings (largest-first style) with overlap relaxation.
 3. Run a "grow & re-settle" loop from every candidate: repeatedly try to enlarge
    each square to the largest size that fits (exact SAT clearance against
    neighbours and the unit-square walls), settling overlaps with a relaxation
    step, keeping the best valid configuration by total side sum.
Only the standard library is used. Deterministic per n via a fixed seed.
"""

import math
import random
import time


def _overlap(a, b):
    """Return penetration depth between two squares (0 if disjoint).
    Squares are (cx, cy, angle, side). Uses SAT with axes = both squares' normals."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return 0.0
    ha = asz * 0.5
    hb = bsz * 0.5
    ca = math.cos(2.0 * math.pi * aa)
    sa = math.sin(2.0 * math.pi * aa)
    cb = math.cos(2.0 * math.pi * ba)
    sb = math.sin(2.0 * math.pi * ba)
    axes = ((ca, sa), (-sa, ca), (cb, sb), (-sb, cb))
    dx = bx - ax
    dy = by - ay
    best = float('inf')
    for ux, uy in axes:
        ra = abs(ux * ca + uy * sa) * ha + abs(ux * (-sa) + uy * ca) * ha
        rb = abs(ux * cb + uy * sb) * hb + abs(ux * (-sb) + uy * cb) * hb
        d = abs(dx * ux + dy * uy)
        pen = ra + rb - d
        if pen < best:
            best = pen
    return best if best > 0.0 else 0.0


def _inside_penalty(cx, cy, angle, side):
    """Return 0 if fully inside unit square, else penetration outside."""
    c = math.cos(2.0 * math.pi * angle)
    s = math.sin(2.0 * math.pi * angle)
    h = side * 0.5
    pen = 0.0
    for sx, sy in ((h, h), (h, -h), (-h, h), (-h, -h)):
        x = cx + c * sx - s * sy
        y = cy + s * sx + c * sy
        if x < 0.0:
            pen += -x
        elif x > 1.0:
            pen += x - 1.0
        if y < 0.0:
            pen += -y
        elif y > 1.0:
            pen += y - 1.0
    return pen


def _total_penalty(sqs):
    n = len(sqs)
    pen = 0.0
    for i in range(n):
        pen += _inside_penalty(*sqs[i])
        for j in range(i + 1, n):
            pen += _overlap(sqs[i], sqs[j])
    return pen


def _max_side_at(cx, cy, ang, others):
    """Largest side for a square centred at (cx,cy) with angle ang that fits
    inside the unit square and doesn't overlap any square in `others`."""
    # wall constraint: perpendicular half-extents along the axes
    c = abs(math.cos(2.0 * math.pi * ang))
    s = abs(math.sin(2.0 * math.pi * ang))
    eh = c + s  # half-extent factor: side*half-extent <= min dist to wall
    dxw = min(cx, 1.0 - cx) / eh
    dyw = min(cy, 1.0 - cy) / eh
    wall = 2.0 * min(dxw, dyw)
    best = wall
    if best <= 0.0:
        return 0.0
    # neighbour constraints: side <= 2*clearance where clearance is max scale
    for o in others:
        ox, oy, oa, osz = o
        if osz <= 0.0:
            continue
        # SAT along the four axes; solve for our side length
        ca = math.cos(2.0 * math.pi * ang)
        sa = math.sin(2.0 * math.pi * ang)
        cb = math.cos(2.0 * math.pi * oa)
        sb = math.sin(2.0 * math.pi * oa)
        hb = osz * 0.5
        ddx = ox - cx
        ddy = oy - cy
        # our radii are proportional to our half-side ha:
        # ra(axis) = ha * (|ux*ca+uy*sa| + |ux*(-sa)+uy*ca|)
        for ux, uy in ((ca, sa), (-sa, ca), (cb, sb), (-sb, cb)):
            raf = abs(ux * ca + uy * sa) + abs(ux * (-sa) + uy * ca)
            rb = abs(ux * cb + uy * sb) * hb + abs(ux * (-sb) + uy * cb) * hb
            d = abs(ddx * ux + ddy * uy)
            # need raf*ha <= d - rb  => ha <= (d-rb)/raf
            if raf < 1e-12:
                continue
            lim = (d - rb) / raf
            if lim < 0.0:
                lim = 0.0
            cand = 2.0 * lim
            if cand < best:
                best = cand
    return best if best > 0.0 else 0.0


def _relax(sqs, steps=40):
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    for _ in range(steps):
        moved = False
        for i in range(n):
            cx, cy, ang, sz = sqs[i]
            if sz <= 0.0:
                continue
            p = _inside_penalty(cx, cy, ang, sz)
            if p > 0.0:
                dx = 0.5 - cx
                dy = 0.5 - cy
                L = math.hypot(dx, dy) or 1.0
                step = min(p * 0.5, 0.02)
                sqs[i][0] = cx + dx / L * step
                sqs[i][1] = cy + dy / L * step
                moved = True
        for i in range(n):
            for j in range(i + 1, n):
                pi = _overlap(sqs[i], sqs[j])
                if pi <= 1e-12:
                    continue
                dx = sqs[j][0] - sqs[i][0]
                dy = sqs[j][1] - sqs[i][1]
                L = math.hypot(dx, dy)
                if L < 1e-9:
                    rnd = random.random() * 2.0 * math.pi
                    dx, dy = math.cos(rnd), math.sin(rnd)
                    L = 1.0
                step = min(pi * 0.6 + 1e-4, 0.03)
                ux = dx / L
                uy = dy / L
                si = sqs[i][3]
                sj = sqs[j][3]
                tot = si + sj or 1.0
                fi = sj / tot
                fj = si / tot
                sqs[i][0] -= ux * step * fi
                sqs[i][1] -= uy * step * fi
                sqs[j][0] += ux * step * fj
                sqs[j][1] += uy * step * fj
                moved = True
        if not moved:
            break
    return [tuple(s) for s in sqs]


def _grow_refine(sqs, rng, iters=8):
    """Iteratively try to enlarge each square to its max feasible side."""
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    for _ in range(iters):
        changed = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, sz = sqs[i]
            others = [sqs[j] for j in range(n) if j != i]
            mx = _max_side_at(cx, cy, ang, others)
            if mx > sz + 1e-9:
                sqs[i][3] = mx  # grow exactly (removes overlap by construction)
                changed = True
            elif mx < sz - 1e-9:
                sqs[i][3] = mx
                changed = True
        if not changed:
            break
    return sqs


def _greedy_packing(n, rng, tries=3):
    best = None
    best_pen = float('inf')
    for _ in range(tries):
        sqs = []
        nc = 40 if n <= 30 else (20 if n <= 80 else 10)
        for idx in range(n):
            best_cand = None
            best_score = -float('inf')
            for _c in range(nc):
                cx = rng.random()
                cy = rng.random()
                ang = rng.random()
                mx = min(cx, 1.0 - cx, cy, 1.0 - cy) / 1.2
                if mx <= 0.0:
                    continue
                for frac in (0.25, 0.5, 0.75, 1.0):
                    sz = mx * frac
                    if sz <= 0.0:
                        continue
                    test = (cx, cy, ang, sz)
                    ok = True
                    for s in sqs:
                        if _overlap(test, s) > 1e-9:
                            ok = False
                            break
                    if not ok:
                        continue
                    clearance = 1.0
                    for s in sqs:
                        d = math.hypot(cx - s[0], cy - s[1])
                        clearance = min(clearance, d)
                    score = sz * 3.0 + clearance
                    if score > best_score:
                        best_score = score
                        best_cand = test
            if best_cand is None:
                best_cand = (rng.random(), rng.random(), rng.random(), 0.0)
            sqs.append(best_cand)
        sqs = _relax(sqs, steps=50)
        pen = _total_penalty(sqs)
        if pen < best_pen:
            best_pen = pen
            best = sqs
        if pen < 1e-6:
            break
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    t0 = time.time()
    budget = 55.0

    rng = random.Random(987654 + n)

    # ---- deterministic grid baseline -------------------------------------------------
    k = math.isqrt(n)
    side = 1.0 / k if k >= 1 else 1.0
    base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(k) for j in range(k)]
    base += [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
    base = base[:n]

    candidates = [ [list(s) for s in base] ]

    # ---- randomized greedy candidates ----------------------------------------------
    tries = 6 if n <= 40 else (4 if n <= 100 else 2)
    for _ in range(tries):
        if time.time() - t0 > budget * 0.25:
            break
        g = _greedy_packing(n, rng, tries=2)
        if g is not None:
            candidates.append([list(s) for s in g])

    best = None
    best_val = -1.0

    # ---- refine every candidate with grow & re-settle -------------------------------
    for cand in candidates:
        cur = [list(s) for s in cand]
        # clean inside
        for i in range(n):
            cx, cy, ang, sz = cur[i]
            if sz <= 0.0:
                cur[i] = [0.5, 0.5, 0.0, 0.0]
                continue
            for _ in range(25):
                if _inside_penalty(cx, cy, ang, sz) <= 1e-10:
                    break
                sz *= 0.9
            cur[i] = [cx, cy, ang, sz]

        cur = _relax(cur, steps=40)

        # grow & re-settle loop
        rounds = 0
        while time.time() - t0 < budget and rounds < 25:
            rounds += 1
            cur = _grow_refine(cur, rng, iters=3)
            cur = _relax(cur, steps=25)
            # enforce validity by shrinking on any remaining overlap
            for _ in range(15):
                worst = 0.0
                bad = None
                for i in range(n):
                    for j in range(i + 1, n):
                        p = _overlap(cur[i], cur[j])
                        if p > worst:
                            worst = p
                            bad = (i, j)
                if worst <= 1e-8:
                    break
                if bad is not None:
                    for idx in bad:
                        cur[idx][3] *= 0.985
                    cur = [list(s) for s in _relax(cur, steps=12)]
            # clamp inside
            for i in range(n):
                cx, cy, ang, sz = cur[i]
                for _ in range(20):
                    if _inside_penalty(cx, cy, ang, sz) <= 1e-9:
                        break
                    sz *= 0.9
                cur[i] = [cx, cy, ang, sz]

            val = sum(s[3] for s in cur)
            if _total_penalty(cur) <= 1e-5 and val > best_val:
                best_val = val
                best = [tuple(s) for s in cur]

    if best is None:
        best = base

    if len(best) < n:
        best = list(best) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    best = best[:n]

    out = []
    for cx, cy, ang, sz in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        sz = min(max(sz, 0.0), 1.0)
        out.append((cx, cy, ang, sz))
    return out
# EVOLVE-BLOCK-END
