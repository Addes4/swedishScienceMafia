# EVOLVE-BLOCK-START
"""Randomized multi-start physics-style packer for squares in the unit square.

Strategy
--------
For each random restart we build a configuration by placing squares in a
randomised "largest first" order.  Each square is given a random target size
(from a schedule of candidate sizes), a random rotation, and its centre is
chosen greedily: we sample many random candidate positions, pick the one with
the largest minimum-separation margin to the already placed squares, then drop
it.  After the greedy construction we run an overlap-relaxation loop: for each
overlapping pair of squares we push their centres apart along the separating
direction (a few iterations), clamp every centre (with its rotated bounding
circle / AABB) into [0,1]^2, and shrink squares that stubbornly overlap.  We
keep the best configuration seen over all restarts within the time budget.

Only the standard library, numpy and scipy are used.
"""

import math
import random
import time


# ---------------------------------------------------------------------------
# geometry helpers
# ---------------------------------------------------------------------------

def _rot_cos_sin(angle):
    a = angle * 2.0 * math.pi
    return math.cos(a), math.sin(a)


def _half_extent(half, c, s):
    """Half-extents of the AABB of a square rotated by (c, s)."""
    return half * (abs(c) + abs(s))


def _overshoot(sq):
    """How far the square sticks out of the unit box (>=0)."""
    cx, cy, ang, side = sq
    half = 0.5 * side
    c, s = _rot_cos_sin(ang)
    ex = _half_extent(half, c, s)
    ey = _half_extent(half, c, s)
    ox = max(0.0, ex - cx, cx + ex - 1.0)
    oy = max(0.0, ey - cy, cy + ey - 1.0)
    return ox + oy


def _clamp(sq):
    """Clamp a square's centre so its rotated AABB lies in the unit box."""
    cx, cy, ang, side = sq
    half = 0.5 * side
    c, s = _rot_cos_sin(ang)
    ex = _half_extent(half, c, s)
    ey = _half_extent(half, c, s)
    if ex > 0.5:
        ex = 0.5
    if ey > 0.5:
        ey = 0.5
    cx = min(max(cx, ex), 1.0 - ex)
    cy = min(max(cy, ey), 1.0 - ey)
    return (cx, cy, ang, side)


def _sep_min_dist(sq_a, sq_b):
    """Minimum separation distance between two squares (negative => overlap).

    Uses the separating-axis theorem on the two oriented boxes.
    """
    ax, ay, aa, asz = sq_a
    bx, by, ba, bsz = sq_b
    ah = 0.5 * asz
    bh = 0.5 * bsz
    ca, sa = _rot_cos_sin(aa)
    cb, sb = _rot_cos_sin(ba)

    # axes of A: (ca, sa) and (-sa, ca); axes of B likewise
    axes = ((ca, sa), (-sa, ca), (cb, sb), (-sb, cb))
    # separation along each axis: distance between centre projections minus
    # sum of projected half-extents
    dx = bx - ax
    dy = by - ay
    best = float('inf')
    for (ux, uy) in axes:
        dist = abs(dx * ux + dy * uy)
        ra = ah * (abs(ca * ux + sa * uy) + abs(-sa * ux + ca * uy))
        rb = bh * (abs(cb * ux + sb * uy) + abs(-sb * ux + cb * uy))
        gap = dist - (ra + rb)
        if gap < best:
            best = gap
    return best


def _push_dir(sq_a, sq_b):
    """Unit direction to push A away from B (centre-to-centre, fallback axis)."""
    ax, ay = sq_a[0], sq_a[1]
    bx, by = sq_b[0], sq_b[1]
    dx = ax - bx
    dy = ay - by
    d = math.hypot(dx, dy)
    if d < 1e-12:
        ang = random.random() * 2.0 * math.pi
        return math.cos(ang), math.sin(ang)
    return dx / d, dy / d


# ---------------------------------------------------------------------------
# greedy construction
# ---------------------------------------------------------------------------

def _greedy_config(n, sizes, rng, n_samples):
    """Place n squares greedily, largest first, with random jitter."""
    order = list(range(n))
    # sort mostly by decreasing target size with a little randomness
    order.sort(key=lambda i: -(sizes[i] * (0.85 + 0.3 * rng.random())))

    placed = []
    for idx in order:
        target = sizes[idx]
        # small random variation of the size
        side = target * (0.9 + 0.2 * rng.random())
        # random rotation among 0, 90 deg and some oblique angles
        r = rng.random()
        if r < 0.4:
            ang = 0.0
        elif r < 0.7:
            ang = 0.25
        elif r < 0.85:
            ang = 0.5
        else:
            ang = rng.random()

        best_sq = None
        best_margin = -1e18
        for _ in range(n_samples):
            cx = rng.random()
            cy = rng.random()
            cand = (cx, cy, ang, side)
            cand = _clamp(cand)
            if placed:
                margin = min(_sep_min_dist(cand, p) for p in placed)
            else:
                margin = 1.0
            if margin > best_margin:
                best_margin = margin
                best_sq = cand
                if margin > 0.0:
                    # good enough, stop early sometimes
                    if rng.random() < 0.35:
                        break
        placed.append(best_sq)

    # restore original indexing order
    result = [None] * n
    for pos, idx in enumerate(order):
        result[idx] = placed[pos]
    return result


def _repair(sqs, iters, rng):
    """Overlap-relaxation: push overlapping squares apart, clamp, shrink."""
    n = len(sqs)
    sqs = [list(s) for s in sqs]
    for it in range(iters):
        moved = False
        # collect overlapping pairs
        for i in range(n):
            for j in range(i + 1, n):
                g = _sep_min_dist(tuple(sqs[i]), tuple(sqs[j]))
                if g < 0.0:
                    moved = True
                    ux, uy = _push_dir(tuple(sqs[i]), tuple(sqs[j]))
                    push = -g * 0.5 + 1e-4
                    sqs[i][0] += ux * push
                    sqs[i][1] += uy * push
                    sqs[j][0] -= ux * push
                    sqs[j][1] -= uy * push
        # clamp everything
        for i in range(n):
            cx, cy, ang, side = sqs[i]
            c, s = _rot_cos_sin(ang)
            half = 0.5 * side
            ex = _half_extent(half, c, s)
            ey = _half_extent(half, c, s)
            if ex > 0.5 or ey > 0.5:
                # too big for any placement: shrink
                scale = 0.5 / max(ex, ey)
                side *= scale
                half = 0.5 * side
                ex = _half_extent(half, c, s)
                ey = _half_extent(half, c, s)
            cx = min(max(cx, ex), 1.0 - ex)
            cy = min(max(cy, ey), 1.0 - ey)
            sqs[i][0] = cx
            sqs[i][1] = cy
            sqs[i][3] = side
        if not moved:
            break
    return [tuple(s) for s in sqs]


def _total_overlap(sqs):
    n = len(sqs)
    tot = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            g = _sep_min_dist(sqs[i], sqs[j])
            if g < 0.0:
                tot += -g
    return tot


def _score(sqs):
    return sum(s[3] for s in sqs) - 10.0 * _total_overlap(sqs) \
        - 10.0 * sum(_overshoot(s) for s in sqs)


# ---------------------------------------------------------------------------
# main solver
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []

    rng = random.Random(12345)
    deadline = time.time() + 55.0

    # candidate equal-ish starting sizes: a base grid of ceil(sqrt(n)) tiles
    k = max(1, math.isqrt(n))
    while k * k < n:
        k += 1
    base = 1.0 / k

    best = None
    best_score = -1e18

    # the number of placement samples grows for small n
    n_samples = 40 if n <= 40 else (20 if n <= 200 else 10)

    attempt = 0
    while True:
        if time.time() > deadline and attempt > 0:
            break
        attempt += 1

        # size schedule: normally base, with random perturbations; sometimes
        # a geometric-ish spread that may pack better
        mode = rng.random()
        if mode < 0.6:
            # near-uniform sizes with jitter
            sizes = [base * (0.9 + 0.2 * rng.random()) for _ in range(n)]
        elif mode < 0.85:
            # mixed: a few big squares plus smaller ones
            big = min(n, rng.randint(max(1, n // 4), max(1, n // 2)))
            sizes = []
            for i in range(n):
                if i < big:
                    sizes.append(base * (1.0 + 0.5 * rng.random()))
                else:
                    sizes.append(base * (0.4 + 0.6 * rng.random()))
        else:
            # geometric spread of sizes (largest first)
            sizes = []
            ratio = 0.6 + 0.3 * rng.random()
            s = base * (1.0 + 0.3 * rng.random())
            for i in range(n):
                sizes.append(s)
                s = max(base * 0.05, s * ratio)
        rng.shuffle(sizes)

        try:
            cfg = _greedy_config(n, sizes, rng, n_samples)
        except Exception:
            continue

        # repair with several rounds
        cfg = _repair(cfg, iters=60, rng=rng)

        # a light second repair pass with more iterations if overlapping
        if _total_overlap(cfg) > 1e-6:
            cfg = _repair(cfg, iters=120, rng=rng)

        sc = _score(cfg)
        if sc > best_score:
            best_score = sc
            best = cfg

        # very small n: try a few explicit rotation tweaks on the best config
        if n <= 8:
            for _ in range(3):
                trial = list(best)
                cfg2 = _repair(trial, iters=80, rng=rng)
                sc2 = _score(cfg2)
                if sc2 > best_score:
                    best_score = sc2
                    best = cfg2

        if time.time() > deadline:
            break

    if best is None:
        # fallback to grid
        side = 1.0 / k
        best = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side)
                for i in range(n)]

    # final cleanup: ensure exactly n, all in [0,1], clamp again
    out = []
    for i in range(n):
        if i < len(best):
            cx, cy, ang, side = best[i]
        else:
            cx, cy, ang, side = 0.5, 0.5, 0.0, 0.0
        cx = min(max(float(cx), 0.0), 1.0)
        cy = min(max(float(cy), 0.0), 1.0)
        ang = float(ang) % 1.0
        side = min(max(float(side), 0.0), 1.0)
        out.append((cx, cy, ang, side))
    return out
# EVOLVE-BLOCK-END

