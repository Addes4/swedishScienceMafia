# EVOLVE-BLOCK-START
"""Randomized greedy + overlap relaxation packing of squares in a unit square.

Approach:
 - Repeatedly try to place squares from largest to smallest.
 - For each square, sample candidate placements (centre + angle) on a grid
   perturbed by random noise; pick the candidate that allows the largest side
   given existing squares, or the one with most clearance.
 - After constructing a packing, run a relaxation loop: compute pairwise overlaps
   and push squares apart (and slightly toward the unit-square interior) until
   overlaps vanish or a step budget expires.
 - If overlaps remain, shrink offending squares by a small factor and repeat.
 - Track the best total side sum found across multiple restarts.

Only standard library used. Deterministic by seeding with n for reproducibility.
"""

import math
import random


def _overlap(a, b):
    """Return penetration depth between two squares (0 if disjoint).
    Squares are (cx, cy, angle, side). Uses SAT with axes = both squares' normals."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return 0.0
    # half extents
    ha = asz * 0.5
    hb = bsz * 0.5
    # normals
    ca = math.cos(2.0 * math.pi * aa)
    sa = math.sin(2.0 * math.pi * aa)
    cb = math.cos(2.0 * math.pi * ba)
    sb = math.sin(2.0 * math.pi * ba)
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    dx = bx - ax
    dy = by - ay
    best = float('inf')
    for ux, uy in axes:
        # projection radius of each square onto axis
        ra = abs(ux * ca + uy * sa) * ha + abs(ux * (-sa) + uy * ca) * ha
        rb = abs(ux * cb + uy * sb) * hb + abs(ux * (-sb) + uy * cb) * hb
        d = abs(dx * ux + dy * uy)
        pen = ra + rb - d
        if pen < best:
            best = pen
    return best if best > 0.0 else 0.0


def _inside_penalty(cx, cy, angle, side):
    """Return 0 if fully inside unit square, else penetration outside."""
    c = math.cos(2.0 * math.pi * angle)
    s = math.sin(2.0 * math.pi * angle)
    h = side * 0.5
    # four corners
    xs = []
    ys = []
    for sx, sy in ((h, h), (h, -h), (-h, h), (-h, -h)):
        xs.append(cx + c * sx - s * sy)
        ys.append(cy + s * sx + c * sy)
    pen = 0.0
    for x in xs:
        if x < 0.0:
            pen += -x
        elif x > 1.0:
            pen += x - 1.0
    for y in ys:
        if y < 0.0:
            pen += -y
        elif y > 1.0:
            pen += y - 1.0
    return pen


def _total_penalty(sqs):
    n = len(sqs)
    pen = 0.0
    for i in range(n):
        pen += _inside_penalty(*sqs[i])
        for j in range(i + 1, n):
            pen += _overlap(sqs[i], sqs[j])
    return pen


def _relax(sqs, steps=60):
    """Push squares apart / inward to reduce overlap penalty."""
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    for _ in range(steps):
        moved = False
        # inside correction
        for i in range(n):
            cx, cy, ang, sz = sqs[i]
            if sz <= 0.0:
                continue
            p = _inside_penalty(cx, cy, ang, sz)
            if p > 0.0:
                # nudge toward centre
                dx = 0.5 - cx
                dy = 0.5 - cy
                L = math.hypot(dx, dy) or 1.0
                step = min(p * 0.25, 0.01)
                cx += dx / L * step
                cy += dy / L * step
                sqs[i][0] = cx
                sqs[i][1] = cy
                moved = True
        # pairwise separation
        for i in range(n):
            for j in range(i + 1, n):
                pi = _overlap(sqs[i], sqs[j])
                if pi <= 1e-12:
                    continue
                dx = sqs[j][0] - sqs[i][0]
                dy = sqs[j][1] - sqs[i][1]
                L = math.hypot(dx, dy)
                if L < 1e-9:
                    # random tiny push
                    rnd = random.random() * 2.0 * math.pi
                    dx, dy = math.cos(rnd), math.sin(rnd)
                    L = 1.0
                step = min(pi * 0.5 + 1e-4, 0.02)
                ux = dx / L
                uy = dy / L
                # move proportional to relative size
                si = sqs[i][3]
                sj = sqs[j][3]
                tot = si + sj or 1.0
                fi = sj / tot
                fj = si / tot
                sqs[i][0] -= ux * step * fi
                sqs[i][1] -= uy * step * fi
                sqs[j][0] += ux * step * fj
                sqs[j][1] += uy * step * fj
                moved = True
        if not moved:
            break
    return [tuple(s) for s in sqs]


def _greedy_packing(n, rng, tries=5):
    """Try to build a packing greedily with random tries."""
    best = None
    best_pen = float('inf')
    for _ in range(tries):
        sqs = []
        # Start with some initial size guess
        for idx in range(n):
            best_cand = None
            best_score = -float('inf')
            # candidate count depends on remaining slots for speed
            nc = 40 if n <= 30 else (20 if n <= 80 else 10)
            for _c in range(nc):
                cx = rng.random()
                cy = rng.random()
                ang = rng.random()
                # estimate max size from unit square alone
                # (use a conservative bound: distance to nearest edge / ~1.42)
                mx = min(cx, 1.0 - cx, cy, 1.0 - cy)
                max_size = mx / 1.2
                if max_size <= 0.0:
                    continue
                # try a few sizes
                for frac in (0.25, 0.5, 0.75, 1.0):
                    sz = max_size * frac
                    if sz <= 0.0:
                        continue
                    # check against existing squares quickly
                    ok = True
                    pen = 0.0
                    test = (cx, cy, ang, sz)
                    for s in sqs:
                        p = _overlap(test, s)
                        if p > 1e-9:
                            ok = False
                            break
                    if not ok:
                        continue
                    # score: larger size good, more clearance good
                    clearance = 1.0
                    for s in sqs:
                        d = math.hypot(cx - s[0], cy - s[1])
                        clearance = min(clearance, d)
                    score = sz * 3.0 + clearance
                    if score > best_score:
                        best_score = score
                        best_cand = test
            if best_cand is None:
                # try a tiny square anywhere
                cx = rng.random()
                cy = rng.random()
                ang = rng.random()
                # find a size that fits
                sz = 0.0
                for trial in range(6):
                    tsz = sz + 0.05
                    if _inside_penalty(cx, cy, ang, tsz) <= 1e-9:
                        test = (cx, cy, ang, tsz)
                        ok = True
                        for s in sqs:
                            if _overlap(test, s) > 1e-9:
                                ok = False
                                break
                        if ok:
                            sz = tsz
                best_cand = (cx, cy, ang, sz)
            sqs.append(best_cand)
        # relax to remove residual overlaps
        sqs = _relax(sqs, steps=50)
        pen = _total_penalty(sqs)
        if pen < best_pen:
            best_pen = pen
            best = sqs
        if pen < 1e-6:
            break
    return best, best_pen


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    # baseline: simple grid, always valid (axis-aligned, fits)
    k = math.isqrt(n)
    if k >= 1:
        side = 1.0 / k
        base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        base += [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
        base = base[:n]
        base_val = sum(s[3] for s in base)
    else:
        base = [(0.5, 0.5, 0.0, 0.0)] * n
        base_val = 0.0

    # randomized greedy attempts
    tries = 6 if n <= 40 else (4 if n <= 100 else 2)
    best = base
    best_val = base_val
    best_pen = _total_penalty(base) if base else 0.0

    try:
        for attempt in range(tries):
            sqs, pen = _greedy_packing(n, rng, tries=2)
            if sqs is None:
                continue
            # enforce validity: shrink/remove overlapping squares
            sqs = [list(s) for s in sqs]
            for _ in range(30):
                maxpen = 0.0
                bad = None
                for i in range(n):
                    for j in range(i + 1, n):
                        p = _overlap(sqs[i], sqs[j])
                        if p > maxpen:
                            maxpen = p
                            bad = (i, j)
                if maxpen <= 1e-7:
                    break
                i, j = bad
                # shrink both
                for idx in (i, j):
                    if sqs[idx][3] > 1e-9:
                        sqs[idx][3] *= 0.97
                # re-relax
                sqs = [list(s) for s in _relax(sqs, steps=20)]
            # final clean-up: drop any zero or negative, shrink tiny overlaps
            sqs = [list(s) for s in sqs]
            for _ in range(10):
                anybad = False
                for i in range(n):
                    for j in range(i + 1, n):
                        if _overlap(sqs[i], sqs[j]) > 1e-7:
                            anybad = True
                            ssz = min(sqs[i][3], sqs[j][3])
                            for idx in (i, j):
                                sqs[idx][3] *= 0.9
                if not anybad:
                    break
            # also clamp inside
            for i in range(n):
                cx, cy, ang, sz = sqs[i]
                if sz <= 0.0:
                    sqs[i] = [0.5, 0.5, 0.0, 0.0]
                    continue
                # binary shrink until inside
                for _ in range(20):
                    if _inside_penalty(cx, cy, ang, sz) <= 1e-9:
                        break
                    sz *= 0.9
                sqs[i] = [cx, cy, ang, sz]

            val = sum(s[3] for s in sqs)
            pen = _total_penalty(sqs)
            if pen <= 1e-5 and val > best_val:
                best_val = val
                best = [tuple(s) for s in sqs]
    except Exception:
        pass

    # final guarantee: if best still has overlap, fall back to base grid
    if _total_penalty(best) > 1e-4:
        best = base

    # ensure lengths
    if len(best) < n:
        best = list(best) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    best = best[:n]

    # clamp all values to [0,1] safely (centres and angles; side length in [0,1])
    out = []
    for cx, cy, ang, sz in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        sz = min(max(sz, 0.0), 1.0)
        out.append((cx, cy, ang, sz))
    return out
# EVOLVE-BLOCK-END
