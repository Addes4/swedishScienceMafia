# EVOLVE-BLOCK-START
"""Structural seeder + continuous refinement for squares in the unit square.

Strategy
--------
1) Enumerate structural tilings: cut the unit square into bands (horizontal or
   vertical) and fill each band with its own uniform grid of equal squares.
   Collect the best few seeds.
2) Refine the best seed with a continuous optimizer (SLSQP) that treats all
   (cx, cy, angle, side) as free variables, maximising the sum of side lengths
   subject to containment and pairwise non-overlap constraints.  A final
   overlap-repair projection guarantees validity.
"""

import math
import time


def _rot_cos_sin(angle):
    a = angle * 2.0 * math.pi
    return math.cos(a), math.sin(a)


def _half_extent(half, c, s):
    return half * (abs(c) + abs(s))


def _sep_min_dist(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    ah = 0.5 * asz
    bh = 0.5 * bsz
    ca, sa = _rot_cos_sin(aa)
    cb, sb = _rot_cos_sin(ba)
    axes = ((ca, sa), (-sa, ca), (cb, sb), (-sb, cb))
    dx = bx - ax
    dy = by - ay
    best = float('inf')
    for (ux, uy) in axes:
        dist = abs(dx * ux + dy * uy)
        ra = ah * (abs(ca * ux + sa * uy) + abs(-sa * ux + ca * uy))
        rb = bh * (abs(cb * ux + sb * uy) + abs(-sb * ux + cb * uy))
        gap = dist - (ra + rb)
        if gap < best:
            best = gap
    return best


def _total_overlap(sqs):
    n = len(sqs)
    tot = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            g = _sep_min_dist(sqs[i], sqs[j])
            if g < 0.0:
                tot += -g
    return tot


def _repair(sqs, iters):
    """Push overlapping axis-aligned squares apart; clamp to unit box."""
    n = len(sqs)
    sqs = [[float(c) for c in s] for s in sqs]
    for _ in range(iters):
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                g = _sep_min_dist(tuple(sqs[i]), tuple(sqs[j]))
                if g < -1e-9:
                    moved = True
                    dx = sqs[i][0] - sqs[j][0]
                    dy = sqs[i][1] - sqs[j][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-12:
                        dx, dy, d = 1.0, 0.0, 1.0
                    ux, uy = dx / d, dy / d
                    push = -g * 0.5 + 1e-6
                    sqs[i][0] += ux * push
                    sqs[i][1] += uy * push
                    sqs[j][0] -= ux * push
                    sqs[j][1] -= uy * push
        for i in range(n):
            cx, cy, ang, side = sqs[i]
            c, s = _rot_cos_sin(ang)
            h = 0.5 * side
            ex = _half_extent(h, c, s)
            ey = _half_extent(h, c, s)
            if ex > 0.5 or ey > 0.5:
                sc = 0.5 / max(ex, ey)
                side *= sc
                h = 0.5 * side
                ex = _half_extent(h, c, s)
                ey = _half_extent(h, c, s)
            sqs[i][0] = min(max(cx, ex), 1.0 - ex)
            sqs[i][1] = min(max(cy, ey), 1.0 - ey)
            sqs[i][3] = side
        if not moved:
            break
    return [tuple(s) for s in sqs]


def _grid_band(x0, y0, w, h, r, c):
    if r <= 0 or c <= 0:
        return []
    side = min(w / c, h / r)
    out = []
    totw = side * c
    toth = side * r
    ox = x0 + (w - totw) * 0.5
    oy = y0 + (h - toth) * 0.5
    for i in range(r):
        for j in range(c):
            cx = ox + (j + 0.5) * side
            cy = oy + (i + 0.5) * side
            out.append((cx, cy, 0.0, side))
    return out


def _split_candidates(rA, cA, rB, cB):
    ts = []
    if rA + rB > 0:
        ts.append(rA / (rA + rB))
    if cA + cB > 0:
        ts.append(cA / (cA + cB))
    for k in range(1, 10):
        ts.append(k / 10.0)
    out = []
    eps = 1e-9
    for t in ts:
        if eps < t < 1.0 - eps:
            out.append(t)
    return out


def _candidate_tilings(n):
    results = []
    for r in range(1, n + 1):
        if n % r:
            continue
        c = n // r
        band = _grid_band(0.0, 0.0, 1.0, 1.0, r, c)
        if len(band) == n:
            results.append(band)

    for a in range(1, n):
        b = n - a
        for ra in range(1, a + 1):
            if a % ra:
                continue
            ca = a // ra
            for rb in range(1, b + 1):
                if b % rb:
                    continue
                cb = b // rb
                for t in _split_candidates(ra, ca, rb, cb):
                    bottom = _grid_band(0.0, 0.0, 1.0, t, rb, cb)
                    top = _grid_band(0.0, t, 1.0, 1.0 - t, ra, ca)
                    if len(bottom) + len(top) == n:
                        results.append(bottom + top)
                for t in _split_candidates(ca, ra, cb, rb):
                    left = _grid_band(0.0, 0.0, t, 1.0, ra, ca)
                    right = _grid_band(t, 0.0, 1.0 - t, 1.0, rb, cb)
                    if len(left) + len(right) == n:
                        results.append(left + right)
    return results


def _score(sqs):
    return sum(s[3] for s in sqs)


def _refine_slsqp(seed, deadline):
    """Continuous refinement of a seed using SLSQP.

    Variables per square: cx, cy, angle, side.  Maximise sum(side) subject to
    containment (box constraints on cx/cy given angle/side, plus side <= 1) and
    pairwise non-overlap via separating-axis minimum distance >= 0.
    """
    try:
        import numpy as np
        from scipy.optimize import minimize
    except Exception:
        return seed

    n = len(seed)
    if n < 2:
        return seed

    x0 = np.zeros(4 * n)
    for i, (cx, cy, ang, sd) in enumerate(seed):
        x0[4 * i] = cx
        x0[4 * i + 1] = cy
        x0[4 * i + 2] = ang
        x0[4 * i + 3] = sd

    # Penalize side reduction from the seed so we don't collapse; final objective
    # is dominated by sum(side). Use bounds to keep variables reasonable.
    lb = np.zeros(4 * n)
    ub = np.zeros(4 * n)
    for i in range(n):
        lb[4 * i] = 0.0
        ub[4 * i] = 1.0
        lb[4 * i + 1] = 0.0
        ub[4 * i + 1] = 1.0
        lb[4 * i + 2] = -0.5
        ub[4 * i + 2] = 0.5
        lb[4 * i + 3] = 0.0
        ub[4 * i + 3] = 1.0

    def unpack(x):
        sqs = []
        for i in range(n):
            cx = x[4 * i]
            cy = x[4 * i + 1]
            ang = x[4 * i + 2]
            sd = x[4 * i + 3]
            sqs.append((cx, cy, ang, sd))
        return sqs

    def obj(x):
        return -float(np.sum(x[3::4]))

    def jac_obj(x):
        g = np.zeros(4 * n)
        g[3::4] = -1.0
        return g

    def cons(x):
        sqs = unpack(x)
        vals = []
        # containment: half extent must fit
        for i in range(n):
            cx, cy, ang, sd = sqs[i]
            c, s = _rot_cos_sin(ang)
            h = 0.5 * sd
            ex = _half_extent(h, c, s)
            ey = _half_extent(h, c, s)
            vals.append(0.5 - ex - cx)   # cx + ex <= 0.5
            vals.append(0.5 - ex - (1.0 - cx))
            vals.append(0.5 - ey - cy)
            vals.append(0.5 - ey - (1.0 - cy))
        # pairwise separation
        for i in range(n):
            for j in range(i + 1, n):
                g = _sep_min_dist(sqs[i], sqs[j])
                vals.append(g)
        return np.array(vals)

    # Use a tolerance-based constraint with a small slack so SLSQP is feasible.
    def cons_slack(x):
        return cons(x) + 1e-7

    try:
        res = minimize(obj, x0, jac=jac_obj, method='SLSQP',
                       bounds=list(zip(lb, ub)),
                       constraints=[{'type': 'ineq', 'fun': cons_slack}],
                       options={'maxiter': 300, 'ftol': 1e-10})
        xf = res.x
        cand = [tuple(xf[4 * i:4 * i + 4]) for i in range(n)]
        # normalize angles and clamp
        out = []
        for cx, cy, ang, sd in cand:
            out.append((float(cx), float(cy), float(ang), max(0.0, float(sd))))
        return out
    except Exception:
        return seed


def _expand(seed, deadline):
    """Greedy grow: increase each square's side while keeping feasibility, then
    repair small overlaps and rescale if infeasible."""
    n = len(seed)
    sqs = [[float(c) for c in s] for s in seed]
    order = list(range(n))
    for _ in range(120):
        if time.time() > deadline:
            break
        changed = False
        # try to grow each square in turn
        for i in order:
            cx, cy, ang, sd = sqs[i]
            grow = sd * 0.01 + 1e-4
            trial = [list(s) for s in sqs]
            trial[i][3] = sd + grow
            # containment clamp
            c, s_ = _rot_cos_sin(ang)
            h = 0.5 * trial[i][3]
            ex = _half_extent(h, c, s_)
            ey = _half_extent(h, c, s_)
            if ex > 0.5 or ey > 0.5:
                continue
            trial[i][0] = min(max(cx, ex), 1.0 - ex)
            trial[i][1] = min(max(cy, ey), 1.0 - ey)
            # check overlap with others
            ok = True
            for j in range(n):
                if j == i:
                    continue
                if _sep_min_dist(tuple(trial[i]), tuple(trial[j])) < -1e-9:
                    ok = False
                    break
            if ok:
                sqs = trial
                changed = True
        if not changed:
            break
    return [tuple(s) for s in sqs]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    deadline = time.time() + 55.0

    # Fallback grid
    k = max(1, math.isqrt(n))
    while k * k < n:
        k += 1
    side = 1.0 / k
    best = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side)
            for i in range(n)]
    best_score = _score(best)

    # Enumerate structural tilings, keep the few best seeds
    seeds = []
    for cand in _candidate_tilings(n):
        if _total_overlap(cand) > 1e-9:
            cand = _repair(cand, 80)
        if _total_overlap(cand) > 1e-6:
            continue
        sc = _score(cand)
        seeds.append((sc, cand))
        if sc > best_score:
            best_score = sc
            best = cand

    seeds.sort(key=lambda t: -t[0])
    seeds = seeds[:6]

    # Continuous refinement of top seeds
    for sc0, seed in seeds:
        if time.time() > deadline:
            break
        try:
            ref = _refine_slsqp(seed, deadline)
        except Exception:
            ref = seed
        ref = _repair(ref, 60)
        if _total_overlap(ref) > 1e-6:
            continue
        # Greedy expansion to use any slack
        ref = _expand(ref, deadline)
        ref = _repair(ref, 40)
        if _total_overlap(ref) > 1e-6:
            continue
        sc = _score(ref)
        if sc > best_score:
            best_score = sc
            best = ref

    # Also expand the best structural seed directly (cheap, helps large n)
    if seeds and time.time() < deadline:
        seed = seeds[0][1]
        e = _expand(seed, deadline)
        e = _repair(e, 40)
        if _total_overlap(e) <= 1e-6:
            sc = _score(e)
            if sc > best_score:
                best_score = sc
                best = e

    out = []
    for i in range(n):
        if i < len(best):
            cx, cy, ang, sd = best[i]
        else:
            cx, cy, ang, sd = 0.0, 0.0, 0.0, 0.0
        cx = min(max(float(cx), 0.0), 1.0)
        cy = min(max(float(cy), 0.0), 1.0)
        ang = float(ang) % 1.0
        sd = min(max(float(sd), 0.0), 1.0)
        out.append((cx, cy, ang, sd))
    return out
# EVOLVE-BLOCK-END
