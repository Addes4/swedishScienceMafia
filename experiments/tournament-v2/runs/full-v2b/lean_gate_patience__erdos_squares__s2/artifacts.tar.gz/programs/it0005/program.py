# EVOLVE-BLOCK-START
"""Best rectangular grid layout plus a greedy shelf fill of the leftover strip."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    best = None
    best_score = -1.0

    # Try axis-aligned grids of r rows x c cols of equal squares, then fill the
    # leftover region (whichever strip is larger) with additional squares.
    for r in range(1, n + 1):
        for c in range(1, n + 1):
            if r * c > n:
                continue
            s = min(1.0 / r, 1.0 / c)
            used = r * c
            rem = n - used
            squares = []
            # place the r x c grid in the corner
            w = c * s
            h = r * s
            for i in range(c):
                for j in range(r):
                    squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
            # leftover strips: right strip width 1-w, top strip height 1-h
            # greedy shelf packing of rem equal squares into the two strips
            extra = []
            if rem > 0:
                # try splitting rem between the two strips
                for a in range(rem + 1):
                    b = rem - a
                    strip_w = 1.0 - w
                    strip_h = 1.0 - h
                    cand = []
                    ok = True
                    # right strip: fit a squares in a column (stack vertically)
                    if a > 0:
                        if strip_w <= 0:
                            ok = False
                        else:
                            ss = min(strip_w, strip_h / a) if a > 0 else 0.0
                            if ss <= 0:
                                ok = False
                            else:
                                for k in range(a):
                                    cand.append((w + ss / 2, (k + 0.5) * ss, 0.0, ss))
                    # top strip: fit b squares
                    if ok and b > 0:
                        if strip_h <= 0:
                            ok = False
                        else:
                            # top strip spans full width but avoid overlap with right strip region
                            avail_w = 1.0 - w if False else 1.0
                            # place along top, but respect already placed right column height
                            ss = min(avail_w / b, strip_h) if b > 0 else 0.0
                            if ss <= 0:
                                ok = False
                            else:
                                # only place where it doesn't overlap right strip squares
                                for k in range(b):
                                    cx = (k + 0.5) * ss
                                    cand.append((cx, 1.0 - ss / 2, 0.0, ss))
                    if ok:
                        total = used * s + sum(q[3] for q in cand)
                        if total > best_score:
                            best_score = total
                            best = squares + cand
    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    # pad with zero-size squares if needed
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return [tuple(x) for x in best[:n]]
# EVOLVE-BLOCK-END

