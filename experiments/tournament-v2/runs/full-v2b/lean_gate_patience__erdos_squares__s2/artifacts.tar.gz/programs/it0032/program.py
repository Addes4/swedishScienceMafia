# EVOLVE-BLOCK-START
"""Randomized multi-start physics-style packer with rotated-bounds repair.

Strategy: treat the sum of side lengths as the objective.  We repeatedly build a
configuration by greedily inserting squares (largest sizes first) with random
jitter and a few random rotation candidates, then refine the whole layout with an
overlap-relaxation loop (push apart overlapping pairs, clamp everything to the
unit square).  Many random restarts, keep the best.  Finally a rotated-extent
repair enforces the unit-square constraint exactly.
"""
import math
import random


def _extent(sz, ang):
    """Half-width and half-height of a rotated square's axis-aligned bbox."""
    t = ang * 2.0 * math.pi
    c, s = abs(math.cos(t)), abs(math.sin(t))
    h = sz * 0.5
    return h * (c + s), h * (c + s)


def _penetration(a, b):
    """Approximate penetration depth (positive if overlapping)."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    ta = aa * 2.0 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    tb = ba * 2.0 * math.pi
    cb, sb = math.cos(tb), math.sin(tb)
    ha = asz * 0.5
    hb = bsz * 0.5
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    minov = float('inf')
    for (ux, uy) in axes:
        ea = abs(ux * ca + uy * sa) + abs(ux * (-sa) + uy * ca)
        eb = abs(ux * cb + uy * sb) + abs(ux * (-sb) + uy * cb)
        dist = abs(ux * (ax - bx) + uy * (ay - by))
        ov = ha * ea + hb * eb - dist
        if ov < minov:
            minov = ov
    return minov


def _total_overlap(squares):
    tot = 0.0
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 1e-9:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 1e-9:
                continue
            ov = _penetration(squares[i], squares[j])
            if ov > 0:
                tot += ov
    return tot


def _clamp(sq):
    """Clamp centres using rotated bounding-box half-extents."""
    for i in range(len(sq)):
        if sq[i][3] <= 1e-9:
            continue
        ex, ey = _extent(sq[i][3], sq[i][2])
        ex = min(ex, 0.5)
        ey = min(ey, 0.5)
        sq[i][0] = min(max(sq[i][0], ex), 1.0 - ex)
        sq[i][1] = min(max(sq[i][1], ey), 1.0 - ey)
    return sq


def _relax(squares, iters=80, rng=None):
    """Push overlapping squares apart; clamp to unit square; fixed sizes."""
    if rng is None:
        rng = random.Random(0)
    sq = [list(s) for s in squares]
    m = len(sq)
    for _ in range(iters):
        moved = False
        for i in range(m):
            if sq[i][3] <= 1e-9:
                continue
            for j in range(i + 1, m):
                if sq[j][3] <= 1e-9:
                    continue
                ov = _penetration(sq[i], sq[j])
                if ov > 1e-9:
                    moved = True
                    dx = sq[i][0] - sq[j][0]
                    dy = sq[i][1] - sq[j][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        ang = rng.random() * 2.0 * math.pi
                        dx, dy, d = math.cos(ang), math.sin(ang), 1.0
                    push = ov * 0.5 + 1e-4
                    ux, uy = dx / d, dy / d
                    sq[i][0] += ux * push
                    sq[i][1] += uy * push
                    sq[j][0] -= ux * push
                    sq[j][1] -= uy * push
        _clamp(sq)
        if not moved:
            break
    return _clamp(sq)


def _feasible(squares, tol=1e-7):
    for (cx, cy, ang, sz) in squares:
        if sz <= 1e-9:
            continue
        ex, ey = _extent(sz, ang)
        if ex > 0.5 + 1e-6 or ey > 0.5 + 1e-6:
            return False
        if cx < ex - 1e-6 or cx > 1.0 - ex + 1e-6:
            return False
        if cy < ey - 1e-6 or cy > 1.0 - ey + 1e-6:
            return False
    return _total_overlap(squares) < tol


def _repair(squares, rng):
    """Shrink sides to fit the unit square, then relax to restore feasibility."""
    sq = [list(s) for s in squares]
    for i in range(len(sq)):
        if sq[i][3] <= 1e-9:
            continue
        sz = sq[i][3]
        ex, ey = _extent(sz, sq[i][2])
        m = max(ex, ey)
        if m > 0.5 + 1e-9:
            # scale down side so rotated extent fits inside the unit square
            sq[i][3] = sz * (0.5 / m) * 0.999
    sq = _relax(sq, iters=120, rng=rng)
    return [tuple(s) for s in sq]


def _greedy_start(n, rng):
    base = 1.0 / max(1.0, math.sqrt(n))
    sizes = []
    for _ in range(n):
        f = rng.uniform(0.55, 1.35)
        sizes.append(min(0.999, base * f * rng.uniform(0.8, 1.2)))
    order = list(range(n))
    rng.shuffle(order)

    placed = []
    for idx in order:
        sz = sizes[idx]
        best = None
        best_pen = 1e18
        for _try in range(48):
            ex, ey = _extent(sz, 0.0)
            cx = rng.uniform(ex, 1.0 - ex)
            cy = rng.uniform(ey, 1.0 - ey)
            ang = rng.choice([0.0, 0.25, rng.random()])
            cand = (cx, cy, ang, sz)
            ov = 0.0
            for p in placed:
                ov += max(0.0, _penetration(cand, p))
            if ov < best_pen:
                best_pen = ov
                best = cand
                if ov <= 1e-9:
                    break
        placed.append(best)
    return placed


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345)
    best = None
    best_score = -1e18

    def consider(cand):
        nonlocal best, best_score
        refined = _relax(cand, iters=100, rng=rng)
        s = sum(x[3] for x in refined) - 10.0 * _total_overlap(refined)
        ok = _feasible(refined)
        score = s if ok else s - 1000.0
        if score > best_score:
            best_score = score
            best = refined

    # Structured grid seed.
    k = math.isqrt(n)
    if k >= 1:
        side = 1.0 / k
        grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
        consider(grid[:n])

    tries = 40 if n <= 12 else (24 if n <= 30 else 12)
    for t in range(tries):
        consider(_greedy_start(n, rng))

    # Final safety: repair best if not feasible.
    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    if not _feasible(best):
        best = _repair(best, rng)

    result = list(best)
    if len(result) < n:
        result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]
# EVOLVE-BLOCK-END
