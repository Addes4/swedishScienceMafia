# EVOLVE-BLOCK-START
"""Grow-and-repair optimizer for packing squares in a unit square.

Strategy:
 - Build a valid rectangular-grid baseline (fast, guaranteed feasible).
 - Iterative "expand then repair":
     * For each square, binary-search the largest side that keeps it inside the
       unit square and disjoint (SAT) from all others.
     * Apply small random perturbations (jitter centre/angle) between sweeps.
     * Repair any residual overlaps by scaling offenders down and re-checking.
 - Track the best valid configuration across restarts.
"""

import math
import random

TAU = 2.0 * math.pi


def _corners(cx, cy, ang, sz):
    c = math.cos(ang)
    s = math.sin(ang)
    h = sz * 0.5
    return [
        (cx + c * h - s * h, cy + s * h + c * h),
        (cx + c * h + s * h, cy + s * h - c * h),
        (cx - c * h + s * h, cy - s * h - c * h),
        (cx - c * h - s * h, cy - s * h + c * h),
    ]


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return 0.0
    ha = asz * 0.5
    hb = bsz * 0.5
    ca = math.cos(aa); sa = math.sin(aa)
    cb = math.cos(ba); sb = math.sin(ba)
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    dx = bx - ax; dy = by - ay
    best = float('inf')
    for ux, uy in axes:
        ra = ha * (abs(ux * ca + uy * sa) + abs(-ux * sa + uy * ca))
        rb = hb * (abs(ux * cb + uy * sb) + abs(-ux * sb + uy * cb))
        d = abs(dx * ux + dy * uy)
        pen = ra + rb - d
        if pen < best:
            best = pen
    return best if best > 0.0 else 0.0


def _inside_penalty(cx, cy, ang, sz):
    if sz <= 0.0:
        return 0.0
    c = math.cos(ang); s = math.sin(ang)
    h = sz * 0.5
    pen = 0.0
    for sx, sy in ((h, h), (h, -h), (-h, h), (-h, -h)):
        x = cx + c * sx - s * sy
        y = cy + s * sx + c * sy
        if x < 0.0: pen += -x
        elif x > 1.0: pen += x - 1.0
        if y < 0.0: pen += -y
        elif y > 1.0: pen += y - 1.0
    return pen


def _total_overlap(sqs):
    n = len(sqs)
    p = 0.0
    for i in range(n):
        p += _inside_penalty(*sqs[i])
        for j in range(i + 1, n):
            p += _overlap(sqs[i], sqs[j])
    return p


def _ok(sqs, i, cx, cy, ang, sz, tol=1e-9):
    t = (cx, cy, ang, sz)
    if _inside_penalty(cx, cy, ang, sz) > tol:
        return False
    for j, s in enumerate(sqs):
        if j == i:
            continue
        if _overlap(t, s) > tol:
            return False
    return True


def _clamp_inside(cx, cy, ang, sz):
    """Shrink side until inside, keeping centre/angle."""
    if _inside_penalty(cx, cy, ang, sz) <= 1e-12:
        return sz
    lo, hi = 0.0, sz
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        if _inside_penalty(cx, cy, ang, mid) <= 1e-12:
            lo = mid
        else:
            hi = mid
    return lo


def _max_expand(sqs, i, cx, cy, ang, hi_bound=1.0):
    """Largest side for square i placed at (cx,cy,ang), disjoint from others."""
    lo = 0.0
    hi = hi_bound
    # ensure feasibility at lo
    if not _ok(sqs, i, cx, cy, ang, hi, 1e-9):
        for _ in range(40):
            mid = 0.5 * (lo + hi)
            if _ok(sqs, i, cx, cy, ang, mid, 1e-9):
                lo = mid
            else:
                hi = mid
    else:
        return hi
    return lo


def _repair(sqs, rng, rounds=40):
    n = len(sqs)
    sqs = [list(s) for s in sqs]
    for _ in range(rounds):
        worst = 0.0
        pair = None
        for i in range(n):
            p = _inside_penalty(*sqs[i])
            if p > worst:
                worst = p
                pair = ('inside', i)
        if worst <= 1e-9:
            for i in range(n):
                for j in range(i + 1, n):
                    p = _overlap(sqs[i], sqs[j])
                    if p > worst:
                        worst = p
                        pair = ('pair', i, j)
        if worst <= 1e-9:
            break
        if pair[0] == 'inside':
            i = pair[1]
            cx, cy, ang, sz = sqs[i]
            # move centre toward middle
            dx = 0.5 - cx
            dy = 0.5 - cy
            L = math.hypot(dx, dy) or 1.0
            step = min(worst * 1.01, 0.02)
            sqs[i][0] = cx + dx / L * step
            sqs[i][1] = cy + dy / L * step
            sqs[i][3] = _clamp_inside(sqs[i][0], sqs[i][1], ang, sz)
        else:
            i, j = pair[1], pair[2]
            dx = sqs[j][0] - sqs[i][0]
            dy = sqs[j][1] - sqs[i][1]
            L = math.hypot(dx, dy)
            if L < 1e-9:
                r = rng.random() * TAU
                dx, dy = math.cos(r), math.sin(r)
                L = 1.0
            ux, uy = dx / L, dy / L
            step = min(worst * 0.6 + 1e-4, 0.02)
            si = sqs[i][3]; sj = sqs[j][3]
            tot = si + sj or 1.0
            fi = sj / tot; fj = si / tot
            sqs[i][0] -= ux * step * fi
            sqs[i][1] -= uy * step * fi
            sqs[j][0] += ux * step * fj
            sqs[j][1] += uy * step * fj
    return sqs


def _expand_sweep(sqs, rng, order):
    """Try to grow squares (in the given order) to their max feasible size."""
    n = len(sqs)
    for i in order:
        cx, cy, ang, sz = sqs[i]
        best_cx, best_cy, best_ang, best_sz = cx, cy, ang, sz
        # try several centres/angles perturbations to find a larger fit
        cands = [(cx, cy, ang)]
        for _ in range(6):
            dx = (rng.random() - 0.5) * 0.4
            dy = (rng.random() - 0.5) * 0.4
            da = (rng.random() - 0.5) * 0.5
            cands.append((min(max(cx + dx, 0.0), 1.0),
                          min(max(cy + dy, 0.0), 1.0),
                          (ang + da) % 1.0))
        for (tcx, tcy, tang) in cands:
            tsz = _max_expand(sqs, i, tcx, tcy, tang, hi_bound=1.0)
            tsz = _clamp_inside(tcx, tcy, tang, tsz)
            if tsz > best_sz + 1e-12:
                # verify
                if _ok(sqs, i, tcx, tcy, tang, tsz, 1e-9):
                    best_cx, best_cy, best_ang, best_sz = tcx, tcy, tang, tsz
        sqs[i] = [best_cx, best_cy, best_ang, best_sz]
    return sqs


def _grid_baseline(n):
    k = math.isqrt(n)
    side = 1.0 / k
    out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
           for i in range(k) for j in range(k)]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]


def _jitter(sqs, rng, amount=0.02):
    out = [list(s) for s in sqs]
    for s in out:
        s[0] = min(max(s[0] + (rng.random() - 0.5) * amount, 0.0), 1.0)
        s[1] = min(max(s[1] + (rng.random() - 0.5) * amount, 0.0), 1.0)
        s[2] = (s[2] + (rng.random() - 0.5) * amount) % 1.0
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(987654321 + n)

    base = [list(s) for s in _grid_baseline(n)]
    best = [tuple(s) for s in base]
    best_val = sum(s[3] for s in base)

    # Convert angle fraction to radians for our helpers.
    def to_rad(sqs):
        return [[s[0], s[1], s[2] * TAU, s[3]] for s in sqs]

    def from_rad(sqs):
        return [(s[0], s[1], (s[2] / TAU) % 1.0, s[3]) for s in sqs]

    work = to_rad(base)

    # Baseline iterative expansion on the grid (deterministic boost).
    def run(start, iters, jit):
        sqs = [list(s) for s in start]
        for _ in range(iters):
            order = list(range(n))
            rng.shuffle(order)
            sqs = _expand_sweep(sqs, rng, order)
            if jit > 0:
                sqs = _jitter(sqs, rng, jit)
                sqs = _repair(sqs, rng, rounds=n * 2 + 20)
            cur = sum(s[3] for s in sqs)
            nonlocal best_val, best
            if cur > best_val + 1e-9 and _total_overlap(sqs) <= 1e-7:
                best_val = cur
                best = from_rad(sqs)
        return sqs

    # Main effort: alternating expansion sweeps with small & larger jitters.
    try:
        sqs = run(work, iters=8, jit=0.0)
        for restart in range(4 if n <= 40 else 2):
            start = _jitter(sqs, rng, 0.10)
            start = _repair(start, rng, rounds=n * 2 + 30)
            sqs = run(start, iters=10, jit=0.01 + 0.01 * restart)
    except Exception:
        pass

    # Final guarantee of validity.
    final = [list(s) for s in to_rad(best)]
    if _total_overlap(final) > 1e-6:
        final = [list(s) for s in to_rad(_grid_baseline(n))]
    final = from_rad(final)

    # Cleanup: clamp values.
    out = []
    for cx, cy, ang, sz in final:
        out.append((
            min(max(cx, 0.0), 1.0),
            min(max(cy, 0.0), 1.0),
            ang % 1.0,
            min(max(sz, 0.0), 1.0),
        ))
    if len(out) < n:
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]
# EVOLVE-BLOCK-END
