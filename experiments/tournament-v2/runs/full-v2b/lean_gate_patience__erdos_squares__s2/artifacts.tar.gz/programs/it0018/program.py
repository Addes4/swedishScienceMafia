# EVOLVE-BLOCK-START
"""Squares in a square: randomised multi-start with strictly feasible refinement.

Strategy:
  1. Build many candidate configurations by placing squares largest-first
     into random free rectangles (guillotine subdivision), so every candidate
     is valid by construction.
  2. Refine with a strict "max-expand" loop: for each square, binary search the
     largest side that (a) keeps it inside the unit square and (b) keeps it
     disjoint from all other squares (exact SAT test on rotated quads).
  3. Keep the best total; always verify and scale down at the end so the
     returned configuration is guaranteed feasible.
"""
import math
import random
import time

SQ2 = math.sqrt(2.0)


def _corners(cx, cy, ang, s):
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    return [
        (cx + h * c - h * sn, cy + h * sn + h * c),
        (cx - h * c - h * sn, cy - h * sn + h * c),
        (cx - h * c + h * sn, cy - h * sn - h * c),
        (cx + h * c + h * sn, cy + h * sn - h * c),
    ]


def _sep(p, q):
    """Separating-axis: True if interiors do NOT overlap."""
    # interval overlap on each edge normal
    for poly in (p, q):
        for i in range(4):
            ax, ay = poly[i]
            bx, by = poly[(i + 1) % 4]
            nx, ny = -(by - ay), (bx - ax)
            mn1 = mx1 = None
            for a, b in p:
                d = a * nx + b * ny
                if mn1 is None or d < mn1:
                    mn1 = d
                if mx1 is None or d > mx1:
                    mx1 = d
            mn2 = mx2 = None
            for a, b in q:
                d = a * nx + b * ny
                if mn2 is None or d < mn2:
                    mn2 = d
                if mx2 is None or d > mx2:
                    mx2 = d
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return True
    return False


def _inside(pts, eps=1e-9):
    for a, b in pts:
        if a < -eps or a > 1.0 + eps or b < -eps or b > 1.0 + eps:
            return False
    return True


def _max_side(cfg, i, polys):
    """Largest side for square i keeping it inside and disjoint from others."""
    cx, cy, ang, s = cfg[i]
    lo, hi = 0.0, 2.0 * SQ2
    for _ in range(34):
        mid = 0.5 * (lo + hi)
        pts = _corners(cx, cy, ang, mid)
        if not _inside(pts):
            hi = mid
            continue
        ok = True
        for j in range(len(cfg)):
            if j == i:
                continue
            if not _sep(pts, polys[j]):
                ok = False
                break
        if ok:
            lo = mid
        else:
            hi = mid
    return lo


def _expand_all(cfg, rounds=6):
    cfg = [list(c) for c in cfg]
    n = len(cfg)
    for _ in range(rounds):
        polys = [_corners(c[0], c[1], c[2], c[3]) for c in cfg]
        changed = False
        order = sorted(range(n), key=lambda k: cfg[k][3])
        for i in order:
            ns = _max_side(cfg, i, polys)
            if ns > cfg[i][3] + 1e-7:
                cfg[i][3] = ns
                polys[i] = _corners(cfg[i][0], cfg[i][1], cfg[i][2], ns)
                changed = True
        if not changed:
            break
    return cfg


def _feasible(cfg):
    polys = [_corners(c[0], c[1], c[2], c[3]) for c in cfg]
    for i in range(len(polys)):
        if not _inside(polys[i]):
            return False
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if not _sep(polys[i], polys[j]):
                return False
    return True


def _place_rect(x0, y0, w, h, n, rng, out):
    """Guillotine: split rectangle into n squares (recursively)."""
    if n <= 0:
        return
    if n == 1:
        s = min(w, h)
        ang = 0.0
        out.append((x0 + w * 0.5, y0 + h * 0.5, ang, s))
        return
    # split direction: proportional
    if w >= h:
        side = min(h, w)
        # place a square along the left
        ratio = rng.choice([0.5, 1.0 / 3.0, 2.0 / 3.0])
        k = max(1, min(n - 1, int(round(n * ratio))))
        sw = side
        s = min(sw, h)
        out.append((x0 + s * 0.5, y0 + h * 0.5, 0.0, s))
        _place_rect(x0 + s, y0, max(w - s, 0.0), h, n - 1, rng, out)
    else:
        side = min(w, h)
        ratio = rng.choice([0.5, 1.0 / 3.0, 2.0 / 3.0])
        s = min(side, w)
        out.append((x0 + w * 0.5, y0 + s * 0.5, 0.0, s))
        _place_rect(x0, y0 + s, w, max(h - s, 0.0), n - 1, rng, out)


def _greedy_random(n, rng):
    """Randomised guillotine packing with cutting planes."""
    # choose k, m split of n so k*m grid + remainder
    best = None
    best_sc = -1.0
    for _ in range(6):
        cfg = []
        # recursively split whole unit square into n cells
        _split_rect(0.0, 0.0, 1.0, 1.0, n, rng, cfg, depth=0)
        cfg = _expand_all(cfg, rounds=8)
        sc = sum(c[3] for c in cfg)
        if _feasible(cfg) and sc > best_sc:
            best_sc = sc
            best = cfg
    return best if best is not None else cfg


def _split_rect(x0, y0, w, h, n, rng, out, depth):
    if n <= 0:
        return
    if n == 1:
        s = min(w, h)
        out.append([x0 + w * 0.5, y0 + h * 0.5, 0.0, s])
        return
    if depth > 12:
        s = min(w, h) / max(1.0, math.sqrt(n))
        for _ in range(n):
            out.append([x0 + w * 0.5, y0 + h * 0.5, 0.0, 0.0])
        return
    # split into two sub-rectangles
    if w >= h:
        cut = rng.uniform(0.25, 0.75) * w
        k = max(1, min(n - 1, int(round(n * cut / w))))
        _split_rect(x0, y0, cut, h, k, rng, out, depth + 1)
        _split_rect(x0 + cut, y0, w - cut, h, n - k, rng, out, depth + 1)
    else:
        cut = rng.uniform(0.25, 0.75) * h
        k = max(1, min(n - 1, int(round(n * cut / h))))
        _split_rect(x0, y0, w, cut, k, rng, out, depth + 1)
        _split_rect(x0, y0 + cut, w, h - cut, n - k, rng, out, depth + 1)


def _scale_to_feasible(cfg):
    """Ensure feasibility by scaling sides down if needed."""
    if _feasible(cfg):
        return cfg
    lo, hi = 0.0, 1.0
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        test = [(c[0], c[1], c[2], c[3] * mid) for c in cfg]
        if _feasible(test):
            lo = mid
        else:
            hi = mid
    return [(c[0], c[1], c[2], c[3] * lo) for c in cfg]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    rng = random.Random(987654 + n)
    t0 = time.time()
    budget = 50.0

    best = None
    best_sc = -1.0

    # baseline: uniform grid if perfect square
    k = math.isqrt(n)
    if k * k == n:
        s = 1.0 / k
        g = [(i * s + s * 0.5, j * s + s * 0.5, 0.0, s) for i in range(k) for j in range(k)]
        if _feasible(g):
            best = g
            best_sc = sum(c[3] for c in g)

    attempts = 0
    while time.time() - t0 < budget and attempts < 600:
        attempts += 1
        cfg = _greedy_random(n, rng)
        if cfg is None:
            continue
        cfg = _expand_all(cfg, rounds=10)
        cfg = _scale_to_feasible(cfg)

        # local jitter + re-expand
        improved_cfg = [list(c) for c in cfg]
        improved_sc = sum(c[3] for c in improved_cfg)
        for _ in range(4):
            if time.time() - t0 > budget:
                break
            cand = []
            for c in improved_cfg:
                cand.append([
                    min(1.0, max(0.0, c[0] + rng.uniform(-0.02, 0.02))),
                    min(1.0, max(0.0, c[1] + rng.uniform(-0.02, 0.02))),
                    c[2] + rng.choice([0.0, 0.01, -0.01, 0.25, -0.25]),
                    c[3],
                ])
            cand = _expand_all(cand, rounds=8)
            cand = _scale_to_feasible(cand)
            sc = sum(c[3] for c in cand)
            if sc > improved_sc:
                improved_cfg = cand
                improved_sc = sc

        if improved_sc > best_sc and _feasible(improved_cfg):
            best_sc = improved_sc
            best = improved_cfg

    if best is None:
        # safe fallback: tiny grid
        m = int(math.ceil(math.sqrt(n)))
        s = 1.0 / m
        best = []
        cnt = 0
        for i in range(m):
            for j in range(m):
                if cnt >= n:
                    break
                best.append([i * s + s * 0.5, j * s + s * 0.5, 0.0, s * 0.999])
                cnt += 1
            if cnt >= n:
                break
        best = _scale_to_feasible(best)

    # final strict check
    if not _feasible(best):
        best = _scale_to_feasible(best)

    out = []
    for c in best:
        out.append((min(1.0, max(0.0, c[0])), min(1.0, max(0.0, c[1])),
                    c[2] % 1.0, min(1.0, max(0.0, c[3]))))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    out = out[:n]
    if not _feasible([(a, b, c, d) for (a, b, c, d) in out]):
        out = _scale_to_feasible([list(x) for x in out])
        out = [(min(1.0, max(0.0, c[0])), min(1.0, max(0.0, c[1])),
                c[2] % 1.0, min(1.0, max(0.0, c[3]))) for c in out]
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        out = out[:n]
    return out
# EVOLVE-BLOCK-END
