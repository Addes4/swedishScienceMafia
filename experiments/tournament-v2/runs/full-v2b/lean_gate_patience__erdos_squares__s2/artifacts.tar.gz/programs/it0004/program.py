# EVOLVE-BLOCK-START
"""Fill the unit square with equal squares in a k x k grid, then place the
leftover squares in the remaining strip using the best simple construction."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    best = None

    # Try every k where a k x k grid plus a leftover strip can hold n squares.
    # Grid of k columns of side s spanning [0, k*s]; leftover extra squares are
    # packed into the vertical strip of the square using a second rectangular grid.
    for k in range(1, n + 1):
        base = k * k
        if base > n:
            break
        # Place a k x k grid of side s plus (n - base) squares in the right strip.
        # The strip has width (1 - k*s) and height 1 (in normalized coordinates
        # once we scale).  We look for s and a strip packing maximizing total.
        # Strip packing: use a j-column, r-row grid in the strip.
        left = n - base
        # s = width available for the k x k block; strip uses remaining width.
        # Choose s, and put leftover squares in a grid of side t with j cols.
        for j in range(1, left + 1) if left > 0 else [0]:
            rows = math.ceil(left / j) if j else 0
            # Solve: k*s + j*t <= 1, and r*t <= 1 (strip height)
            # maximize k*k*s + left*t  -> use t = min((1 - k*s)/j, 1/rows)
            # optimal s from linear problem: balance. Try candidate s values.
            s = 1.0 / k  # maximal grid side if strip width zero
            # t limited by height
            t_h = 1.0 / rows if rows else 0.0
            # s limited so that strip width >= j*t_h
            s_w = (1.0 - j * t_h) / k if k else 0.0
            s = min(s, s_w)
            if s <= 0:
                continue
            t = min((1.0 - k * s) / j, t_h) if j else 0.0
            val = base * s + left * t
            if t < 0:
                continue
            if best is None or val > best[0]:
                best = (val, k, j, rows, s, t, base, left)

    if best is None:
        k = math.isqrt(n)
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        return squares[:n]

    _, k, j, rows, s, t, base, left = best
    squares = []
    for i in range(k):
        for m in range(k):
            squares.append(((i + 0.5) * s, (m + 0.5) * s, 0.0, s))
    # leftover squares in a j-column, rows-row grid in the right strip
    if left > 0 and j > 0 and t > 0:
        x0 = k * s
        cnt = 0
        for c in range(j):
            for r in range(rows):
                if cnt >= left:
                    break
                cx = x0 + (c + 0.5) * t
                cy = (r + 0.5) * t
                squares.append((cx, cy, 0.0, t))
                cnt += 1
        # any remaining (padding with zero-size)
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
# EVOLVE-BLOCK-END

