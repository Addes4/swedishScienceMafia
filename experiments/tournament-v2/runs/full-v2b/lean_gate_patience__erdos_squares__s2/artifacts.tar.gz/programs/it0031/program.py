# EVOLVE-BLOCK-START
"""Randomized multi-start physics-style packer.

Strategy: treat the sum of side lengths as the objective.  We repeatedly build a
configuration by greedily inserting squares (largest sizes first) with random
jitter and a few random rotation candidates, then refine the whole layout with an
overlap-relaxation loop (push apart overlapping pairs, clamp everything to the
unit square).  Many random restarts, keep the best.
"""
import math
import random
import numpy as np


def _overlaps(a, b):
    """Approximate overlap test between two squares using their corner points."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    na, nb = 4, 4
    # Use separating axis theorem on the 4 edge normals of each square.
    axes = []
    for ang in (aa, ba):
        t = ang * 2.0 * math.pi
        c, s = math.cos(t), math.sin(t)
        axes.append((c, s))
        axes.append((-s, c))
    ha = asz * 0.5
    hb = bsz * 0.5
    for (ux, uy) in axes:
        pa = abs(ux * 0) + abs(uy * 0)
        # project extents
        # projection half-width of a square rotated by aa onto axis (ux,uy)
        ta = aa * 2.0 * math.pi
        ca, sa = math.cos(ta), math.sin(ta)
        ea = abs((ux * ca + uy * sa)) + abs((ux * (-sa) + uy * ca))
        tb = ba * 2.0 * math.pi
        cb, sb = math.cos(tb), math.sin(tb)
        eb = abs((ux * cb + uy * sb)) + abs((ux * (-sb) + uy * cb))
        dist = abs(ux * (ax - bx) + uy * (ay - by))
        if dist >= ha * ea + hb * eb - 1e-12:
            return 0.0
    return 1.0


def _penetration(a, b):
    """Approximate penetration depth (positive if overlapping)."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    ta = aa * 2.0 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    tb = ba * 2.0 * math.pi
    cb, sb = math.cos(tb), math.sin(tb)
    ha = asz * 0.5
    hb = bsz * 0.5
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    minov = float('inf')
    for (ux, uy) in axes:
        ea = abs(ux * ca + uy * sa) + abs(ux * (-sa) + uy * ca)
        eb = abs(ux * cb + uy * sb) + abs(ux * (-sb) + uy * cb)
        dist = abs(ux * (ax - bx) + uy * (ay - by))
        ov = ha * ea + hb * eb - dist
        if ov < minov:
            minov = ov
    return minov


def _relax(squares, iters=60):
    """Push overlapping squares apart; clamp to unit square; squares stay fixed size."""
    sq = [list(s) for s in squares]
    m = len(sq)
    for _ in range(iters):
        moved = False
        for i in range(m):
            if sq[i][3] <= 1e-9:
                continue
            for j in range(i + 1, m):
                if sq[j][3] <= 1e-9:
                    continue
                ov = _penetration(sq[i], sq[j])
                if ov > 1e-9:
                    moved = True
                    dx = sq[i][0] - sq[j][0]
                    dy = sq[i][1] - sq[j][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        ang = random.random() * 2.0 * math.pi
                        dx, dy, d = math.cos(ang), math.sin(ang), 1.0
                    push = ov * 0.5 + 1e-4
                    ux, uy = dx / d, dy / d
                    sq[i][0] += ux * push
                    sq[i][1] += uy * push
                    sq[j][0] -= ux * push
                    sq[j][1] -= uy * push
        # clamp centres so squares stay inside unit square
        for i in range(m):
            if sq[i][3] <= 1e-9:
                continue
            h = sq[i][3] * 0.5
            sq[i][0] = min(max(sq[i][0], h), 1.0 - h)
            sq[i][1] = min(max(sq[i][1], h), 1.0 - h)
        if not moved:
            break
    return [tuple(s) for s in sq]


def _total_overlap(squares):
    tot = 0.0
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 1e-9:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 1e-9:
                continue
            ov = _penetration(squares[i], squares[j])
            if ov > 0:
                tot += ov
    return tot


def _greedy_start(n, rng):
    """Build a configuration by placing squares one by one."""
    # candidate sizes: start around 1/sqrt(n) and vary
    base = 1.0 / max(1.0, math.sqrt(n))
    squares = []
    order = []
    # Decide target sizes per square with random variation.
    sizes = []
    for _ in range(n):
        f = rng.uniform(0.55, 1.35)
        sizes.append(min(0.999, base * f * rng.uniform(0.8, 1.2)))
    order = list(range(n))
    rng.shuffle(order)

    placed = []
    gridN = max(2, int(math.ceil(math.sqrt(n))) + 1)
    for idx in order:
        sz = sizes[idx]
        best = None
        best_score = -1e9
        for _try in range(40):
            cx = rng.uniform(sz * 0.5, 1.0 - sz * 0.5)
            cy = rng.uniform(sz * 0.5, 1.0 - sz * 0.5)
            ang = rng.choice([0.0, 0.25, rng.random()])
            cand = (cx, cy, ang, sz)
            ov = 0.0
            ok = True
            for p in placed:
                ov += _penetration(cand, p)
                if ov > 0.25 * sz:
                    ok = False
                    break
            score = -ov
            if ok and score > best_score:
                best_score = score
                best = cand
        placed.append(best if best is not None else (0.5, 0.5, 0.0, sz))
    return placed


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345)
    best = None
    best_score = -1e18

    tries = 40 if n <= 12 else (24 if n <= 30 else 12)

    # Structured seed: grid-based start.
    k = math.isqrt(n)
    if k >= 1:
        side = 1.0 / k
        grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
        grid = grid[:n]
        grid_score = sum(s[3] for s in grid) - 10.0 * _total_overlap(grid)
        if grid_score > best_score:
            best_score = grid_score
            best = grid

    for t in range(tries):
        start = _greedy_start(n, rng)
        refined = _relax(start, iters=80)
        score = sum(s[3] for s in refined) - 10.0 * _total_overlap(refined)
        if score > best_score:
            best_score = score
            best = refined

    # return, with any leftover room used for zero-size points
    result = list(best)
    if len(result) < n:
        result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]
# EVOLVE-BLOCK-END
