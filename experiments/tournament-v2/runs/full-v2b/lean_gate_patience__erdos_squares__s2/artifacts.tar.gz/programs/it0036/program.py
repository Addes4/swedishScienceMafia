# EVOLVE-BLOCK-START
"""Randomized multi-start physics-style packer with a robust feasibility projection.

Strategy: treat the sum of side lengths as the objective.  We repeatedly build a
configuration by greedily inserting squares (largest sizes first) with random
jitter and a few random rotation candidates, then refine the whole layout with an
overlap-relaxation loop (push apart overlapping pairs, clamp everything to the
unit square using rotated bounding-box half-extents).  Many random restarts,
keep the best feasible configuration.

Additional seeding: randomized binary space partitions (BSP) of the unit square
into rectangles, each filled by its largest inscribed axis-aligned square.  These
structured layouts complement the greedy starts.
"""
import math
import random


def _extent(ang, sz):
    """Half-extents of the axis-aligned bounding box of a rotated square."""
    t = ang * 2.0 * math.pi
    c, s = abs(math.cos(t)), abs(math.sin(t))
    h = sz * 0.5
    # bounding box half-width of a square with half-side h rotated by t
    return h * (c + s), h * (c + s)


def _penetration(a, b):
    """Approximate penetration depth (positive if overlapping)."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 1e-12 or bsz <= 1e-12:
        return -1.0
    ta = aa * 2.0 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    tb = ba * 2.0 * math.pi
    cb, sb = math.cos(tb), math.sin(tb)
    ha = asz * 0.5
    hb = bsz * 0.5
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    minov = float('inf')
    for (ux, uy) in axes:
        ea = abs(ux * ca + uy * sa) + abs(ux * (-sa) + uy * ca)
        eb = abs(ux * cb + uy * sb) + abs(ux * (-sb) + uy * cb)
        dist = abs(ux * (ax - bx) + uy * (ay - by))
        ov = ha * ea + hb * eb - dist
        if ov < minov:
            minov = ov
    return minov


def _clamp_in_unit(sq, i):
    """Clamp centre of square i so its rotated bbox stays inside the unit square."""
    ex, ey = _extent(sq[i][2], sq[i][3])
    lo_x, hi_x = ex, 1.0 - ex
    lo_y, hi_y = ey, 1.0 - ey
    if lo_x > hi_x:
        sq[i][0] = 0.5
    else:
        sq[i][0] = min(max(sq[i][0], lo_x), hi_x)
    if lo_y > hi_y:
        sq[i][1] = 0.5
    else:
        sq[i][1] = min(max(sq[i][1], lo_y), hi_y)


def _project(squares, iters=200):
    """Push overlapping squares apart; always keep each inside the unit square.

    Squares keep fixed size and angle.  Returns a configuration that is (near)
    feasible: no square sticks out and overlaps are driven to zero.
    """
    sq = [list(s) for s in squares]
    m = len(sq)
    for i in range(m):
        _clamp_in_unit(sq, i)
    for _ in range(iters):
        moved = False
        for i in range(m):
            if sq[i][3] <= 1e-12:
                continue
            for j in range(i + 1, m):
                if sq[j][3] <= 1e-12:
                    continue
                ov = _penetration(sq[i], sq[j])
                if ov > 1e-9:
                    moved = True
                    dx = sq[i][0] - sq[j][0]
                    dy = sq[i][1] - sq[j][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        ang = random.random() * 2.0 * math.pi
                        dx, dy, d = math.cos(ang), math.sin(ang), 1.0
                    push = ov * 0.5 + 1e-4
                    ux, uy = dx / d, dy / d
                    sq[i][0] += ux * push
                    sq[i][1] += uy * push
                    sq[j][0] -= ux * push
                    sq[j][1] -= uy * push
        for i in range(m):
            _clamp_in_unit(sq, i)
        if not moved:
            break
    return [tuple(s) for s in sq]


def _total_overlap(squares):
    tot = 0.0
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 1e-12:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 1e-12:
                continue
            ov = _penetration(squares[i], squares[j])
            if ov > 0:
                tot += ov
    return tot


def _max_outside(squares):
    """How far any square sticks out of the unit square."""
    worst = 0.0
    for (cx, cy, ang, sz) in squares:
        if sz <= 1e-12:
            continue
        ex, ey = _extent(ang, sz)
        worst = max(worst, ex - cx, cx - (1.0 - ex), ey - cy, cy - (1.0 - ey))
    return worst


def _feasible(squares):
    return _max_outside(squares) <= 1e-7 and _total_overlap(squares) <= 1e-6


def _greedy_start(n, rng):
    """Build a configuration by placing squares one by one."""
    base = 1.0 / max(1.0, math.sqrt(n))
    sizes = []
    for _ in range(n):
        f = rng.uniform(0.55, 1.35)
        sizes.append(min(0.999, base * f * rng.uniform(0.8, 1.2)))
    order = list(range(n))
    rng.shuffle(order)

    placed = []
    for idx in order:
        sz = sizes[idx]
        best = None
        best_score = -1e18
        for _try in range(40):
            ang = rng.choice([0.0, 0.25, rng.random()])
            ex, ey = _extent(ang, sz)
            lo_x, hi_x = ex, 1.0 - ex
            lo_y, hi_y = ey, 1.0 - ey
            if lo_x > hi_x or lo_y > hi_y:
                continue
            cx = rng.uniform(lo_x, hi_x)
            cy = rng.uniform(lo_y, hi_y)
            cand = (cx, cy, ang, sz)
            ov = 0.0
            ok = True
            for p in placed:
                ov += _penetration(cand, p)
                if ov > 0.25 * sz:
                    ok = False
                    break
            score = -ov
            if ok and score > best_score:
                best_score = score
                best = cand
        if best is None:
            ex, ey = _extent(0.0, sz)
            cx = min(max(0.5, ex), 1.0 - ex) if ex <= 0.5 else 0.5
            cy = min(max(0.5, ey), 1.0 - ey) if ey <= 0.5 else 0.5
            best = (cx, cy, 0.0, sz)
        placed.append(best)
    return placed


def _bsp_squares(n, rng):
    """Randomized binary space partition of the unit square into n rectangles,
    each filled with the largest inscribed axis-aligned square."""
    rects = [(0.0, 0.0, 1.0, 1.0)]  # x, y, w, h
    while len(rects) < n:
        # pick the rectangle with the largest area (with slight randomness)
        idx = max(range(len(rects)),
                  key=lambda k: rects[k][2] * rects[k][3] * (0.85 + 0.3 * rng.random()))
        x, y, w, h = rects.pop(idx)
        # choose split direction: split the longer dimension
        if w >= h:
            frac = rng.uniform(0.35, 0.65)
            w1 = w * frac
            w2 = w - w1
            rects.append((x, y, w1, h))
            rects.append((x + w1, y, w2, h))
        else:
            frac = rng.uniform(0.35, 0.65)
            h1 = h * frac
            h2 = h - h1
            rects.append((x, y, w, h1))
            rects.append((x, y + h1, w, h2))
    squares = []
    for (x, y, w, h) in rects:
        s = min(w, h)
        cx = x + w * 0.5
        cy = y + h * 0.5
        squares.append((cx, cy, 0.0, s))
    return squares


def _strip_seed(n, rng):
    """Tiling into k columns; largest squares fill whole columns."""
    best = None
    best_score = -1e18
    for k in range(1, n + 1):
        # columns of width 1/k, each split into rows
        cols = k
        rows = int(math.ceil(n / cols))
        # distribute squares: fill columns equally
        cnt = [0] * cols
        for i in range(n):
            cnt[i % cols] += 1
        squares = []
        colw = 1.0 / cols
        ok = True
        for c in range(cols):
            m = cnt[c]
            if m == 0:
                continue
            roww = 1.0 / m
            s = min(colw, roww)
            for r in range(m):
                cx = (c + 0.5) * colw
                cy = (r + 0.5) * roww
                squares.append((cx, cy, 0.0, s))
        if len(squares) == n:
            sc = sum(s[3] for s in squares)
            if sc > best_score:
                best_score = sc
                best = squares
    return best


def _grow_and_nudge(squares, rng, rounds=6):
    """Try to grow each square slightly; keep only strictly feasible improvements."""
    best = [list(s) for s in squares]
    for _ in range(rounds):
        improved = False
        order = list(range(len(best)))
        rng.shuffle(order)
        for i in order:
            if best[i][3] <= 1e-12:
                continue
            delta = 0.01 * (1.0 - best[i][3]) + 1e-4
            trial = [s[:] for s in best]
            trial[i][3] = min(0.999, best[i][3] + delta)
            trial = _project(trial, iters=80)
            if _feasible(trial) and sum(s[3] for s in trial) > sum(s[3] for s in best) + 1e-12:
                best = [list(s) for s in trial]
                improved = True
        if not improved:
            break
    return [tuple(s) for s in best]


def _consider(cand, best, best_score):
    refined = _project(cand, iters=120)
    sc = sum(s[3] for s in refined)
    if _feasible(refined) and sc > best_score:
        return refined, sc
    return best, best_score


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(987654321)
    best = None
    best_score = -1e18

    # Structured seed: grid-based start.
    k = math.isqrt(n)
    if k >= 1:
        side = 1.0 / k
        grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
        grid = grid[:n]
        best, best_score = _consider(grid, best, best_score)

    # Strip-based structured seed.
    strip = _strip_seed(n, rng)
    if strip is not None:
        best, best_score = _consider(strip, best, best_score)

    # Randomized BSP seeds.
    bsp_tries = 30 if n <= 20 else 16
    for _ in range(bsp_tries):
        cand = _bsp_squares(n, rng)
        best, best_score = _consider(cand, best, best_score)

    tries = 40 if n <= 12 else (24 if n <= 30 else 12)
    for t in range(tries):
        start = _greedy_start(n, rng)
        best, best_score = _consider(start, best, best_score)

    # Only refine feasible configurations, never allowing invalid output.
    if best is not None and _feasible(best):
        grown = _grow_and_nudge(best, rng)
        if _feasible(grown) and sum(s[3] for s in grown) > best_score:
            best = grown
            best_score = sum(s[3] for s in grown)

    if best is None:
        # Fallback: tiny points, always feasible.
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    result = list(best)
    if len(result) < n:
        result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]
# EVOLVE-BLOCK-END
