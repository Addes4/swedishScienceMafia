# EVOLVE-BLOCK-START
"""Grid/shelf baseline plus a SAT-checked stochastic local search that grows and
rotates individual squares, repairing overlaps by shrinking, to escape fully
tiled grids and reach better packings for non-square n."""
import math
import random
import time


def _verts(cx, cy, ang, s):
    th = 2.0 * math.pi * ang
    ca = math.cos(th)
    sa = math.sin(th)
    h = s * 0.5
    base = ((h, h), (-h, h), (-h, -h), (h, -h))
    return [(cx + dx * ca - dy * sa, cy + dx * sa + dy * ca) for dx, dy in base]


def _poly_overlap(A, B):
    """True if the interiors of two convex polygons overlap (touching is OK)."""
    for poly in (A, B):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ax = -(y2 - y1)
            ay = (x2 - x1)
            if ax == 0.0 and ay == 0.0:
                continue
            pa = [ax * x + ay * y for x, y in A]
            pb = [ax * x + ay * y for x, y in B]
            if min(pa) >= max(pb) - 1e-12 or min(pb) >= max(pa) - 1e-12:
                return False
    return True


def _valid(sqs):
    vs = [_verts(*q) for q in sqs]
    for v in vs:
        for x, y in v:
            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                return False
    m = len(sqs)
    for i in range(m):
        if sqs[i][3] <= 0.0:
            continue
        for j in range(i + 1, m):
            if sqs[j][3] <= 0.0:
                continue
            if _poly_overlap(vs[i], vs[j]):
                return False
    return True


def _clip(sq):
    sq[0] = min(1.0, max(0.0, sq[0]))
    sq[1] = min(1.0, max(0.0, sq[1]))
    sq[2] = sq[2] % 1.0
    if sq[3] < 0.0:
        sq[3] = 0.0


def _repair(sqs, rounds=80):
    for _ in range(rounds):
        bad = [False] * len(sqs)
        vs = [_verts(*q) for q in sqs]
        for i in range(len(sqs)):
            if sqs[i][3] <= 0.0:
                continue
            for x, y in vs[i]:
                if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                    bad[i] = True
                    break
        for i in range(len(sqs)):
            if sqs[i][3] <= 0.0:
                continue
            for j in range(i + 1, len(sqs)):
                if sqs[j][3] <= 0.0:
                    continue
                if _poly_overlap(vs[i], vs[j]):
                    bad[i] = True
                    bad[j] = True
        if not any(bad):
            return True
        for i in range(len(sqs)):
            if bad[i]:
                sqs[i][3] *= 0.94
                sqs[i][0] = min(1.0, max(0.0, sqs[i][0]))
                sqs[i][1] = min(1.0, max(0.0, sqs[i][1]))
    return _valid(sqs)


def _baseline(n):
    """Best valid rectangular grid + shelf fill (deterministic)."""
    best = None
    best_score = -1.0
    for r in range(1, n + 1):
        for c in range(1, n + 1):
            if r * c > n:
                continue
            s = min(1.0 / r, 1.0 / c)
            used = r * c
            rem = n - used
            squares = []
            w = c * s
            h = r * s
            for i in range(c):
                for j in range(r):
                    squares.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
            extra = []
            if rem > 0:
                for a in range(rem + 1):
                    b = rem - a
                    strip_w = 1.0 - w
                    strip_h = 1.0 - h
                    cand = []
                    ok = True
                    if a > 0:
                        if strip_w <= 0:
                            ok = False
                        else:
                            ss = min(strip_w, strip_h / a)
                            if ss <= 0:
                                ok = False
                            else:
                                for k in range(a):
                                    cand.append([w + ss / 2, (k + 0.5) * ss, 0.0, ss])
                    if ok and b > 0:
                        if strip_h <= 0:
                            ok = False
                        else:
                            ss = min(1.0 / b, strip_h)
                            if ss <= 0:
                                ok = False
                            else:
                                for k in range(b):
                                    cand.append([(k + 0.5) * ss, 1.0 - ss / 2, 0.0, ss])
                    if ok:
                        full = squares + cand
                        full = [q[:] for q in full]
                        full += [[0.5, 0.5, 0.0, 0.0]] * (n - len(full))
                        if _valid(full):
                            total = sum(q[3] for q in full)
                            if total > best_score:
                                best_score = total
                                best = full
    if best is None:
        # simple fallback grid
        c = max(1, int(math.isqrt(n)))
        r = (n + c - 1) // c
        s = min(1.0 / r, 1.0 / c)
        best = [[(i % c + 0.5) * s, (i // c + 0.5) * s, 0.0, s] for i in range(n)]
        # pad / shrink if needed
        for i in range(n):
            if best[i][0] > 1 or best[i][1] > 1:
                best[i][3] = 0.0
                best[i][0] = best[i][1] = 0.5
    while len(best) < n:
        best.append([0.5, 0.5, 0.0, 0.0])
    return best[:n]


def solve(n):
    if n <= 0:
        return []
    base = _baseline(n)
    if not _valid(base):
        base = [[0.5, 0.5, 0.0, 0.0] for _ in range(n)]

    rnd = random.Random(987654321)
    cur = [q[:] for q in base]
    cur_s = sum(q[3] for q in cur)
    best = [q[:] for q in cur]
    best_s = cur_s

    budget = min(8000, max(1500, 500000 // (n * n + 1)))
    t0 = time.time()
    it = 0
    while it < budget:
        it += 1
        if (it & 127) == 0 and time.time() - t0 > 50.0:
            break
        cand = [q[:] for q in cur]
        i = rnd.randrange(n)
        mode = rnd.random()
        if mode < 0.75:
            # grow square i
            cand[i][3] = min(1.0, cand[i][3] * rnd.uniform(1.05, 1.8) + 0.01)
        elif mode < 0.9:
            # jitter position / angle
            cand[i][0] += rnd.uniform(-0.08, 0.08)
            cand[i][1] += rnd.uniform(-0.08, 0.08)
            cand[i][2] += rnd.uniform(-0.04, 0.04)
        else:
            # random re-place with a fresh centre
            cand[i][0] = rnd.random()
            cand[i][1] = rnd.random()
        _clip(cand[i])
        if _repair(cand):
            s = sum(q[3] for q in cand)
            if s > cur_s or rnd.random() < 0.04:
                cur = cand
                cur_s = s
                if s > best_s:
                    best = [q[:] for q in cand]
                    best_s = s

    for q in best:
        _clip(q)
    if not _valid(best):
        best = base
    return [tuple(q) for q in best[:n]]
# EVOLVE-BLOCK-END
