# EVOLVE-BLOCK-START
"""Deterministic strip/grid tiling enumerator + physics-relaxation refinement.

The objective is the sum of side lengths.  For most n the best layouts are
row/column (grid-like) constructions: a big rectangle tiled by an r x c grid
plus a leftover strip tiled by a secondary grid, or one big square plus a strip.
We enumerate these seeds exhaustively, relax each to feasibility, then apply
per-square grow-and-nudge.  A randomized greedy multi-start is kept as fallback.
"""
import math
import random


def _extent(ang, sz):
    t = ang * 2.0 * math.pi
    c, s = abs(math.cos(t)), abs(math.sin(t))
    h = sz * 0.5
    return h * (c + s), h * (c + s)


def _penetration(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 1e-12 or bsz <= 1e-12:
        return -1.0
    ta = aa * 2.0 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    tb = ba * 2.0 * math.pi
    cb, sb = math.cos(tb), math.sin(tb)
    ha = asz * 0.5
    hb = bsz * 0.5
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    minov = float('inf')
    for (ux, uy) in axes:
        ea = abs(ux * ca + uy * sa) + abs(ux * (-sa) + uy * ca)
        eb = abs(ux * cb + uy * sb) + abs(ux * (-sb) + uy * cb)
        dist = abs(ux * (ax - bx) + uy * (ay - by))
        ov = ha * ea + hb * eb - dist
        if ov < minov:
            minov = ov
    return minov


def _clamp_in_unit(sq, i):
    ex, ey = _extent(sq[i][2], sq[i][3])
    lo_x, hi_x = ex, 1.0 - ex
    lo_y, hi_y = ey, 1.0 - ey
    if lo_x > hi_x:
        sq[i][0] = 0.5
    else:
        sq[i][0] = min(max(sq[i][0], lo_x), hi_x)
    if lo_y > hi_y:
        sq[i][1] = 0.5
    else:
        sq[i][1] = min(max(sq[i][1], lo_y), hi_y)


def _project(squares, iters=200):
    sq = [list(s) for s in squares]
    m = len(sq)
    for i in range(m):
        _clamp_in_unit(sq, i)
    for _ in range(iters):
        moved = False
        for i in range(m):
            if sq[i][3] <= 1e-12:
                continue
            for j in range(i + 1, m):
                if sq[j][3] <= 1e-12:
                    continue
                ov = _penetration(sq[i], sq[j])
                if ov > 1e-9:
                    moved = True
                    dx = sq[i][0] - sq[j][0]
                    dy = sq[i][1] - sq[j][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        ang = random.random() * 2.0 * math.pi
                        dx, dy, d = math.cos(ang), math.sin(ang), 1.0
                    push = ov * 0.5 + 1e-4
                    ux, uy = dx / d, dy / d
                    sq[i][0] += ux * push
                    sq[i][1] += uy * push
                    sq[j][0] -= ux * push
                    sq[j][1] -= uy * push
        for i in range(m):
            _clamp_in_unit(sq, i)
        if not moved:
            break
    return [tuple(s) for s in sq]


def _total_overlap(squares):
    tot = 0.0
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 1e-12:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 1e-12:
                continue
            ov = _penetration(squares[i], squares[j])
            if ov > 0:
                tot += ov
    return tot


def _max_outside(squares):
    worst = 0.0
    for (cx, cy, ang, sz) in squares:
        if sz <= 1e-12:
            continue
        ex, ey = _extent(ang, sz)
        worst = max(worst, ex - cx, cx - (1.0 - ex), ey - cy, cy - (1.0 - ey))
    return worst


def _feasible(squares):
    return _max_outside(squares) <= 1e-7 and _total_overlap(squares) <= 1e-6


def _grid_tiling(n, r, c, horiz):
    """Seed: unit square split into a main rectangle (r x c grid) and a strip."""
    if r < 1 or c < 1:
        return None
    main = r * c
    if main > n:
        return None
    rem = n - main
    s_main = 1.0 / c
    used = r * s_main
    if used > 1.0 + 1e-12:
        return None
    squares = []
    if horiz:
        for j in range(r):
            for i in range(c):
                squares.append((i * s_main + s_main / 2,
                                j * s_main + s_main / 2, 0.0, s_main))
        strip_h = 1.0 - used
        if rem > 0:
            if strip_h <= 1e-12:
                for _ in range(rem):
                    squares.append((0.5, 1.0, 0.0, 0.0))
            else:
                s = min(strip_h, 1.0 / rem)
                total_w = rem * s
                x0 = (1.0 - total_w) / 2.0
                yc = used + strip_h / 2.0
                for i in range(rem):
                    squares.append((x0 + i * s + s / 2, yc, 0.0, s))
    else:
        used_w = r * s_main
        if used_w > 1.0 + 1e-12:
            return None
        for j in range(c):
            for i in range(r):
                squares.append((i * s_main + s_main / 2,
                                j * s_main + s_main / 2, 0.0, s_main))
        strip_w = 1.0 - used_w
        if rem > 0:
            if strip_w <= 1e-12:
                for _ in range(rem):
                    squares.append((1.0, 0.5, 0.0, 0.0))
            else:
                s = min(strip_w, 1.0 / rem)
                total_h = rem * s
                y0 = (1.0 - total_h) / 2.0
                xc = used_w + strip_w / 2.0
                for i in range(rem):
                    squares.append((xc, y0 + i * s + s / 2, 0.0, s))
    if len(squares) != n:
        return None
    return squares


def _big_square_strip(n):
    """One large square in a corner + (n-1) equal squares along the L-strip.

    Place a square of side s in the bottom-left. The remaining region is the
    L-shape: right strip of width (1-s) full height plus top strip of height
    (1-s) width s. If the remaining n-1 squares all have side t, they must fit
    in this L. Enumerate splits of k along the right strip and (n-1-k) along
    the top strip and solve for the best t (and s) maximizing s + (n-1)*t.
    """
    seeds = []
    if n < 2:
        return seeds
    m = n - 1
    # Enumerate s candidates finely.
    for si in range(1, 200):
        s = si / 200.0
        if s >= 1.0:
            break
        w = 1.0 - s  # width/height of the L-strip
        if w <= 0:
            continue
        for k in range(0, m + 1):
            # k squares in right strip (width w, height 1 -> can stack in a column
            # each of side <= w and fill height: k squares height k*t <= 1)
            # m-k squares in top strip (height w, width s -> row: (m-k)*t <= s)
            # Also right strip can hold squares side <= w and if k>=1 we can also
            # use multiple columns. Use simple single-column / single-row model.
            if k > 0:
                t1 = w  # max side limited by strip width
                # also height constraint: k squares stacked => k*t <= 1
                t1 = min(t1, 1.0 / k)
            else:
                t1 = float('inf')
            kr = m - k
            if kr > 0:
                t2 = w  # height limit of top strip
                # width of top strip rows: each row holds floor(s/t) squares.
                # assume one row of kr squares: kr*t <= s
                if s <= 1e-12:
                    t2 = 0.0
                else:
                    t2 = min(t2, s / kr)
            else:
                t2 = float('inf')
            t = min(t1, t2)
            if t <= 1e-9 or t == float('inf'):
                continue
            total = s + m * t
            seeds.append((total, s, t, k, kr))
    # Also try the reverse orientation (big square in a corner; same by symmetry)
    # Build the best few layouts.
    seeds.sort(reverse=True)
    out = []
    for (total, s, t, k, kr) in seeds[:40]:
        sq = [(s / 2.0, s / 2.0, 0.0, s)]
        w = 1.0 - s
        # right strip squares: stack k along right, side t, in x = s + w/2
        xr = s + w / 2.0
        if k > 0:
            for i in range(k):
                yc = (i + 0.5) / k  # spread across full height
                # place tightly from bottom actually:
            # place from bottom tightly
            for i in range(k):
                yc = i * t + t / 2.0
                if yc + t / 2.0 > 1.0 + 1e-12:
                    break
                sq.append((xr, yc, 0.0, t))
        # top strip squares: row starting at y = s, x from s..1
        yr = s + w / 2.0
        if kr > 0:
            for i in range(kr):
                xc = s + i * t + t / 2.0
                if xc + t / 2.0 > 1.0 + 1e-12:
                    break
                sq.append((xc, yr, 0.0, t))
        if len(sq) == n:
            out.append(sq)
    return out


def _grow_and_nudge(squares, rng, rounds=8):
    best = [list(s) for s in squares]
    for _ in range(rounds):
        improved = False
        order = list(range(len(best)))
        rng.shuffle(order)
        for i in order:
            if best[i][3] <= 1e-12:
                continue
            delta = 0.01 * (1.0 - best[i][3]) + 1e-4
            trial = [s[:] for s in best]
            trial[i][3] = min(0.999, best[i][3] + delta)
            trial = _project(trial, iters=80)
            if _feasible(trial) and sum(s[3] for s in trial) > sum(s[3] for s in best) + 1e-12:
                best = [list(s) for s in trial]
                improved = True
        if not improved:
            break
    return [tuple(s) for s in best]


def _greedy_start(n, rng):
    base = 1.0 / max(1.0, math.sqrt(n))
    sizes = []
    for _ in range(n):
        f = rng.uniform(0.55, 1.35)
        sizes.append(min(0.999, base * f * rng.uniform(0.8, 1.2)))
    order = list(range(n))
    rng.shuffle(order)
    placed = []
    for idx in order:
        sz = sizes[idx]
        best = None
        best_score = -1e18
        for _try in range(40):
            ang = rng.choice([0.0, 0.25, rng.random()])
            ex, ey = _extent(ang, sz)
            lo_x, hi_x = ex, 1.0 - ex
            lo_y, hi_y = ey, 1.0 - ey
            if lo_x > hi_x or lo_y > hi_y:
                continue
            cx = rng.uniform(lo_x, hi_x)
            cy = rng.uniform(lo_y, hi_y)
            cand = (cx, cy, ang, sz)
            ov = 0.0
            ok = True
            for p in placed:
                ov += _penetration(cand, p)
                if ov > 0.25 * sz:
                    ok = False
                    break
            score = -ov
            if ok and score > best_score:
                best_score = score
                best = cand
        if best is None:
            ex, ey = _extent(0.0, sz)
            cx = min(max(0.5, ex), 1.0 - ex) if ex <= 0.5 else 0.5
            cy = min(max(0.5, ey), 1.0 - ey) if ey <= 0.5 else 0.5
            best = (cx, cy, 0.0, sz)
        placed.append(best)
    return placed


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(987654321)
    best = None
    best_score = -1e18

    def consider(squares):
        nonlocal best, best_score
        if squares is None:
            return
        rel = _project(squares, iters=150)
        if _feasible(rel):
            sc = sum(s[3] for s in rel)
            if sc > best_score:
                best_score = sc
                best = rel

    # Big-square + strip layouts.
    for seed in _big_square_strip(n):
        consider(seed)

    # Structured double-grid strip tilings (deterministic enumeration).
    for r in range(1, n + 1):
        for c in range(1, n + 1):
            if r * c > n:
                continue
            for horiz in (True, False):
                seed = _grid_tiling(n, r, c, horiz)
                consider(seed)

    # sqrt grid.
    k = math.isqrt(n)
    if k >= 1:
        side = 1.0 / k
        grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
        consider(grid[:n])

    # Randomized multi-start fallback.
    tries = 30 if n <= 12 else (16 if n <= 30 else 8)
    for t in range(tries):
        start = _greedy_start(n, rng)
        consider(start)

    # Refine the best feasible configuration.
    if best is not None and _feasible(best):
        for _ in range(3):
            grown = _grow_and_nudge(best, rng)
            if _feasible(grown) and sum(s[3] for s in grown) > best_score + 1e-12:
                best = grown
                best_score = sum(s[3] for s in grown)
            else:
                break

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    result = list(best)
    if len(result) < n:
        result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]
# EVOLVE-BLOCK-END
