# EVOLVE-BLOCK-START
"""Optimized packing via parametric layout families + local search."""
import math


def _sum_sides(sqs):
    return sum(s[3] for s in sqs)


def _pure_grid(n):
    k = math.isqrt(n)
    side = 1.0 / k
    sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
           for i in range(k) for j in range(k)]
    sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs))
    return sqs[:n]


def _layout_strip_right(k, r, a):
    """k x k grid of side a, plus r squares of side b in a right strip.
    Grid occupies [0, k*a] x [0, k*a]. Strip width = 1 - k*a.
    We fit r squares in a column: b = min(1-k*a, 1.0/r) but we can stack."""
    if a <= 0 or k * a > 1.0 + 1e-12:
        return None
    strip_w = 1.0 - k * a
    if strip_w <= 1e-12:
        return None
    # Stack r squares vertically in the strip of width strip_w, height 1.
    # Each square side b = min(strip_w, 1.0/r). But we could also use 2 columns.
    # Try 1 column: b1 = min(strip_w, 1.0/r)
    b1 = min(strip_w, 1.0 / r) if r > 0 else 0.0
    # Try 2 columns if r >= 2: each column has ceil(r/2) squares
    best = (b1, 1, r)
    if r >= 2:
        for cols in range(2, min(r, 4) + 1):
            rows = (r + cols - 1) // cols
            b = min(strip_w / cols, 1.0 / rows)
            if b > best[0]:
                best = (b, cols, rows)
    b, cols, rows = best
    if b <= 1e-12:
        return None
    sqs = []
    for i in range(k):
        for j in range(k):
            sqs.append(((i + 0.5) * a, (j + 0.5) * a, 0.0, a))
    # place r squares in strip [k*a, 1] x [0,1]
    cnt = 0
    for c in range(cols):
        for rr in range(rows):
            if cnt >= r:
                break
            cx = k * a + (c + 0.5) * (strip_w / cols)
            cy = (rr + 0.5) * (1.0 / rows)
            sqs.append((cx, cy, 0.0, b))
            cnt += 1
    return sqs


def _layout_strip_top(k, r, a):
    """k x k grid of side a in bottom-left, r squares in top strip."""
    if a <= 0 or k * a > 1.0 + 1e-12:
        return None
    strip_h = 1.0 - k * a
    if strip_h <= 1e-12:
        return None
    b1 = min(strip_h, 1.0 / r) if r > 0 else 0.0
    best = (b1, 1, r)
    if r >= 2:
        for rows in range(2, min(r, 4) + 1):
            cols = (r + rows - 1) // rows
            b = min(strip_h / rows, 1.0 / cols)
            if b > best[0]:
                best = (b, rows, cols)
    b, rows, cols = best
    if b <= 1e-12:
        return None
    sqs = []
    for i in range(k):
        for j in range(k):
            sqs.append(((i + 0.5) * a, (j + 0.5) * a, 0.0, a))
    cnt = 0
    for rr in range(rows):
        for c in range(cols):
            if cnt >= r:
                break
            cx = (c + 0.5) * (1.0 / cols)
            cy = k * a + (rr + 0.5) * (strip_h / rows)
            sqs.append((cx, cy, 0.0, b))
            cnt += 1
    return sqs


def _layout_L_corner(k, r, a):
    """k x k grid of side a, plus r squares filling an L-shaped corner region.
    Split r into two groups: r1 in right strip, r2 in top strip.
    Grid is [0, k*a]^2. Right strip: [k*a,1] x [0, k*a]. Top strip: [0,1] x [k*a,1].
    Top strip has full width 1 (over the grid + right strip)."""
    if a <= 0 or k * a > 1.0 + 1e-12:
        return None
    strip_w = 1.0 - k * a
    strip_h = 1.0 - k * a
    if strip_w <= 1e-12:
        return None
    best = None
    best_val = -1
    # Try splitting r into r1 (right strip of width strip_w, height k*a)
    # and r2 (top strip full width 1, height strip_h)
    for r1 in range(0, r + 1):
        r2 = r - r1
        # Right strip: r1 squares in width strip_w, height k*a
        b1 = 0.0
        if r1 > 0:
            # stack vertically; height available = k*a
            b1 = min(strip_w, k * a / r1)
            # try multiple columns
            for cols in range(2, min(r1, 4) + 1):
                rows = (r1 + cols - 1) // cols
                bb = min(strip_w / cols, k * a / rows)
                if bb > b1:
                    b1 = bb
        b2 = 0.0
        if r2 > 0:
            # top strip: width 1, height strip_h
            b2 = min(strip_h, 1.0 / r2)
            for rows in range(2, min(r2, 4) + 1):
                cols = (r2 + rows - 1) // rows
                bb = min(strip_h / rows, 1.0 / cols)
                if bb > b2:
                    b2 = bb
        val = r1 * b1 + r2 * b2
        if val > best_val:
            best_val = val
            best = (r1, b1, r2, b2)
    if best is None:
        return None
    r1, b1, r2, b2 = best
    sqs = []
    for i in range(k):
        for j in range(k):
            sqs.append(((i + 0.5) * a, (j + 0.5) * a, 0.0, a))
    # Place r1 in right strip: [k*a,1] x [0, k*a]
    if r1 > 0 and b1 > 1e-12:
        cols_best = 1
        for cols in range(2, min(r1, 4) + 1):
            rows = (r1 + cols - 1) // cols
            bb = min(strip_w / cols, k * a / rows)
            if abs(bb - b1) < 1e-9:
                cols_best = cols
                break
        cols = cols_best
        rows = (r1 + cols - 1) // cols
        cnt = 0
        for c in range(cols):
            for rr in range(rows):
                if cnt >= r1:
                    break
                cx = k * a + (c + 0.5) * (strip_w / cols)
                cy = (rr + 0.5) * (k * a / rows)
                sqs.append((cx, cy, 0.0, b1))
                cnt += 1
    # Place r2 in top strip: [0,1] x [k*a,1]
    if r2 > 0 and b2 > 1e-12:
        rows_best = 1
        for rows in range(2, min(r2, 4) + 1):
            cols = (r2 + rows - 1) // rows
            bb = min(strip_h / rows, 1.0 / cols)
            if abs(bb - b2) < 1e-9:
                rows_best = rows
                break
        rows = rows_best
        cols = (r2 + rows - 1) // rows
        cnt = 0
        for rr in range(rows):
            for c in range(cols):
                if cnt >= r2:
                    break
                cx = (c + 0.5) * (1.0 / cols)
                cy = k * a + (rr + 0.5) * (strip_h / rows)
                sqs.append((cx, cy, 0.0, b2))
                cnt += 1
    return sqs


def _score_layout(k, r, a, layout_fn):
    """Compute sum of sides for given a."""
    sqs = layout_fn(k, r, a)
    if sqs is None or len(sqs) < k * k + r:
        return -1.0
    return _sum_sides(sqs)


def _optimize_a(k, r, layout_fn):
    """Golden-section search over a in (0, 1/k) to maximize sum of sides."""
    lo = 1e-6
    hi = 1.0 / k - 1e-9
    if hi <= lo:
        return hi
    # coarse scan first
    N = 60
    best_a = lo
    best_v = -1.0
    for i in range(N + 1):
        a = lo + (hi - lo) * i / N
        v = _score_layout(k, r, a, layout_fn)
        if v > best_v:
            best_v = v
            best_a = a
    # refine with golden section around best
    gr = (math.sqrt(5) - 1) / 2
    left = max(lo, best_a - (hi - lo) / N)
    right = min(hi, best_a + (hi - lo) / N)
    c = right - gr * (right - left)
    d = left + gr * (right - left)
    fc = _score_layout(k, r, c, layout_fn)
    fd = _score_layout(k, r, d, layout_fn)
    for _ in range(50):
        if right - left < 1e-12:
            break
        if fc > fd:
            right = d
            d = c
            fd = fc
            c = right - gr * (right - left)
            fc = _score_layout(k, r, c, layout_fn)
        else:
            left = c
            c = d
            fc = fd
            d = left + gr * (right - left)
            fd = _score_layout(k, r, d, layout_fn)
    a_star = (left + right) / 2
    return a_star


def _validate(sqs):
    """Check no two squares overlap in interior."""
    n = len(sqs)
    for i in range(n):
        cx1, cy1, _, s1 = sqs[i]
        if s1 <= 1e-12:
            continue
        h1 = s1 / 2
        for j in range(i + 1, n):
            cx2, cy2, _, s2 = sqs[j]
            if s2 <= 1e-12:
                continue
            h2 = s2 / 2
            # axis-aligned check (angles are 0 here)
            if abs(cx1 - cx2) < h1 + h2 - 1e-9 and abs(cy1 - cy2) < h1 + h2 - 1e-9:
                return False
    # bounds check
    for cx, cy, _, s in sqs:
        h = s / 2
        if cx - h < -1e-9 or cx + h > 1 + 1e-9:
            return False
        if cy - h < -1e-9 or cy + h > 1 + 1e-9:
            return False
    return True


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    k = math.isqrt(n)
    r = n - k * k

    if r == 0:
        return _pure_grid(n)

    # Try several layout families and pick the best
    candidates = []

    # Family 1: right strip
    a1 = _optimize_a(k, r, _layout_strip_right)
    sqs1 = _layout_strip_right(k, r, a1)
    if sqs1 is not None and len(sqs1) >= n:
        candidates.append(sqs1[:n])

    # Family 2: top strip
    a2 = _optimize_a(k, r, _layout_strip_top)
    sqs2 = _layout_strip_top(k, r, a2)
    if sqs2 is not None and len(sqs2) >= n:
        candidates.append(sqs2[:n])

    # Family 3: L-corner
    a3 = _optimize_a(k, r, _layout_L_corner)
    sqs3 = _layout_L_corner(k, r, a3)
    if sqs3 is not None and len(sqs3) >= n:
        candidates.append(sqs3[:n])

    # Also consider k+1 grid with some zero squares (baseline fallback)
    candidates.append(_pure_grid(n))

    # Also consider (k+1) x (k+1) partial grid: place as many as fit
    k2 = k + 1
    side2 = 1.0 / k2
    sqs_k2 = [((i + 0.5) * side2, (j + 0.5) * side2, 0.0, side2)
              for i in range(k2) for j in range(k2)]
    if len(sqs_k2) >= n:
        candidates.append(sqs_k2[:n])
    else:
        sqs_k2 += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs_k2))
        candidates.append(sqs_k2[:n])

    # Select best valid candidate
    best = None
    best_val = -1.0
    for c in candidates:
        if len(c) != n:
            continue
        if not _validate(c):
            continue
        v = _sum_sides(c)
        if v > best_val:
            best_val = v
            best = c

    if best is None:
        return _pure_grid(n)

    # Final local jitter: try to grow each square slightly
    best = _local_improve(best)
    return best


def _local_improve(sqs):
    """Try to grow squares slightly by shrinking others. Simple coordinate ascent."""
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    improved = True
    iters = 0
    while improved and iters < 30:
        improved = False
        iters += 1
        for i in range(n):
            # try to grow square i
            cx, cy, ang, s = sqs[i]
            if s <= 1e-12:
                continue
            # max growth allowed by bounds
            h = s / 2
            max_s = 2 * min(cx, cy, 1 - cx, 1 - cy)
            # max growth allowed by neighbors
            for j in range(n):
                if i == j:
                    continue
                cx2, cy2, _, s2 = sqs[j]
                if s2 <= 1e-12:
                    continue
                h2 = s2 / 2
                dx = abs(cx - cx2) - (h2)
                dy = abs(cy - cy2) - (h2)
                if dx < 0 and dy < 0:
                    # overlapping in projection; max allowed half
                    allowed = max(dx, dy)  # the larger of the two negatives
                    if allowed < 0:
                        max_s = min(max_s, 2 * (min(abs(cx - cx2), abs(cy - cy2)) - h2 + h2))
            # simpler: just try small increments
            for delta in (0.01, 0.005, 0.001):
                new_s = s + delta
                new_h = new_s / 2
                if new_h > min(cx, cy, 1 - cx, 1 - cy) + 1e-9:
                    continue
                ok = True
                for j in range(n):
                    if i == j:
                        continue
                    cx2, cy2, _, s2 = sqs[j]
                    if s2 <= 1e-12:
                        continue
                    h2 = s2 / 2
                    if abs(cx - cx2) < new_h + h2 - 1e-9 and abs(cy - cy2) < new_h + h2 - 1e-9:
                        ok = False
                        break
                if ok:
                    sqs[i][3] = new_s
                    improved = True
                    break
    return [tuple(s) for s in sqs]
# EVOLVE-BLOCK-END