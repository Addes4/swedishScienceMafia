# EVOLVE-BLOCK-START
"""Recursive guillotine packing: try grids, splits and corner squares."""
import math


_memo = {}


def _grid_pack(w, h, m):
    """Best near-square grid packing of m squares in a w x h rectangle.
    Returns (score, layout) with layout relative to (0, 0)."""
    if m <= 0:
        return 0.0, []
    best = (-1.0, None)
    for c in range(1, m + 1):
        r = (m + c - 1) // c
        side = min(w / c, h / r)
        if side <= 1e-12:
            continue
        score = m * side
        if score > best[0]:
            best = (score, (c, r, side))
    c, r, side = best[1]
    out = []
    for i in range(c):
        for j in range(r):
            if len(out) >= m:
                break
            out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    return best[0], out


def _pack_rel(w, h, m):
    """Pack m squares into a w x h rectangle, layout relative to (0, 0)."""
    key = (round(w, 6), round(h, 6), m)
    if key in _memo:
        return _memo[key]
    if m <= 0:
        _memo[key] = (0.0, [])
        return _memo[key]

    best_score, best_layout = _grid_pack(w, h, m)

    if 2 <= m <= 20:
        # Option 2: split into two rectangles (vertical or horizontal cut).
        for frac in (1.0 / 3.0, 0.5, 2.0 / 3.0):
            for vertical in (True, False):
                if vertical:
                    w1, w2, h1, h2 = w * frac, w * (1.0 - frac), h, h
                else:
                    w1, w2, h1, h2 = w, w, h * frac, h * (1.0 - frac)
                if min(w1, w2, h1, h2) < 1e-9:
                    continue
                for m1 in range(1, m):
                    m2 = m - m1
                    s1, l1 = _pack_rel(w1, h1, m1)
                    s2, l2 = _pack_rel(w2, h2, m2)
                    tot = s1 + s2
                    if tot > best_score:
                        best_score = tot
                        if vertical:
                            best_layout = l1 + [(cx + w1, cy, a, s)
                                                for (cx, cy, a, s) in l2]
                        else:
                            best_layout = l1 + [(cx, cy + h1, a, s)
                                                for (cx, cy, a, s) in l2]

        # Option 3: place a square in the bottom-left corner, recurse on L-shape.
        for f in (1.0 / 3.0, 0.5, 2.0 / 3.0):
            s = min(w, h) * f
            if s <= 1e-9:
                continue
            for m1 in range(0, m):
                m2 = m - 1 - m1
                score = s
                layout = [(s / 2.0, s / 2.0, 0.0, s)]
                ok = True
                if m1 > 0:
                    if w - s > 1e-9:
                        s1, l1 = _pack_rel(w - s, h, m1)
                        score += s1
                        layout += [(cx + s, cy, a, sz) for (cx, cy, a, sz) in l1]
                    else:
                        ok = False
                if ok and m2 > 0:
                    if h - s > 1e-9:
                        s2, l2 = _pack_rel(s, h - s, m2)
                        score += s2
                        layout += [(cx, cy + s, a, sz) for (cx, cy, a, sz) in l2]
                    else:
                        ok = False
                if ok and score > best_score:
                    best_score = score
                    best_layout = layout

    _memo[key] = (best_score, best_layout)
    return _memo[key]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    _score, layout = _pack_rel(1.0, 1.0, n)
    result = []
    for (cx, cy, a, s) in layout[:n]:
        result.append((min(1.0, max(0.0, cx)),
                       min(1.0, max(0.0, cy)),
                       a,
                       max(0.0, s)))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END