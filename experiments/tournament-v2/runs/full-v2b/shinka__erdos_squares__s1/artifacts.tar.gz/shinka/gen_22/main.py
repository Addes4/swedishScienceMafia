# EVOLVE-BLOCK-START
"""Boundary-evolution packing optimiser.

A layout is a list of squares (cx, cy, ang, s).  We start from a cheap
axis-aligned seed and then run a feasibility-preserving growth loop:

    1. try to grow every square by a small amount;
    2. repair any overlaps by pushing squares apart along the minimum
       translation vector (MTV) of the separating-axis test;
    3. shrink squares that remain infeasible after repair;
    4. accept the move if the total side length increased.

A short simulated-annealing polish over (angle, side) then improves the
best candidate.  Everything is clamped to the unit square and finally
sanitised so no two squares share interior points.
"""

import math
import random


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, s):
    half = s / 2.0
    ca = math.cos(2.0 * math.pi * ang)
    sa = math.sin(2.0 * math.pi * ang)
    pts = [(-half, -half), (half, -half), (half, half), (-half, half)]
    return [(cx + ca * px - sa * py, cy + sa * px + ca * py) for (px, py) in pts]


def _bbox(cx, cy, ang, s):
    ca = abs(math.cos(2.0 * math.pi * ang))
    sa = abs(math.sin(2.0 * math.pi * ang))
    hx = (ca + sa) * s / 2.0
    return (cx - hx, cx + hx, cy - hx, cy + hx)


def _mtv(cfg, i, j):
    """Return the minimum translation vector that separates square j from i
    (applied to j), or None if they are already separated."""
    A = _corners(*cfg[i])
    B = _corners(*cfg[j])
    axes = []
    for P in (A, B):
        for a, b in ((0, 1), (1, 2)):
            ex = P[b][0] - P[a][0]
            ey = P[b][1] - P[a][1]
            n = math.hypot(ex, ey)
            if n > 1e-15:
                axes.append((-ey / n, ex / n))
    best = None
    best_len = float('inf')
    for (ax, ay) in axes:
        pa = [ax * p[0] + ay * p[1] for p in A]
        pb = [ax * p[0] + ay * p[1] for p in B]
        lo_a, hi_a = min(pa), max(pa)
        lo_b, hi_b = min(pb), max(pb)
        if hi_a <= lo_b + 1e-12 or hi_b <= lo_a + 1e-12:
            return None  # separated on this axis
        # overlap on this axis
        d1 = hi_a - lo_b
        d2 = hi_b - lo_a
        if d1 < d2:
            d = d1
            sign = 1.0
        else:
            d = d2
            sign = -1.0
        if d < best_len:
            best_len = d
            best = (ax * sign * d, ay * sign * d)
    return best


def _overlap(cfg, i, j):
    return _mtv(cfg, i, j) is not None


def _score(cfg):
    return sum(s for (_, _, _, s) in cfg)


# ---------------------------------------------------------------------------
# Feasibility repair
# ---------------------------------------------------------------------------

def _clamp_one(cx, cy, ang, s):
    ca = abs(math.cos(2.0 * math.pi * ang)) + abs(math.sin(2.0 * math.pi * ang))
    if ca > 0:
        s = min(s, 1.0 / ca)
    hx = s * ca / 2.0
    cx = min(max(cx, hx), 1.0 - hx)
    cy = min(max(cy, hx), 1.0 - hx)
    return (cx, cy, ang, s)


def _repair(cfg, max_iter=40):
    """Push overlapping squares apart; shrink as a last resort."""
    cfg = [_clamp_one(*sq) for sq in cfg]
    n = len(cfg)
    for _ in range(max_iter):
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                if cfg[i][3] <= 0.0 or cfg[j][3] <= 0.0:
                    continue
                mtv = _mtv(cfg, i, j)
                if mtv is None:
                    continue
                moved = True
                mx, my = mtv
                # push both halves
                xi, yi, ai, si = cfg[i]
                xj, yj, aj, sj = cfg[j]
                cfg[i] = _clamp_one(xi - mx * 0.5, yi - my * 0.5, ai, si)
                cfg[j] = _clamp_one(xj + mx * 0.5, yj + my * 0.5, aj, sj)
        # after pushes, anything still overlapping gets shrunk
        for i in range(n):
            for j in range(i + 1, n):
                if cfg[i][3] <= 0.0 or cfg[j][3] <= 0.0:
                    continue
                if _overlap(cfg, i, j):
                    xi, yi, ai, si = cfg[i]
                    xj, yj, aj, sj = cfg[j]
                    # shrink the larger one slightly
                    if si >= sj:
                        cfg[i] = _clamp_one(xi, yi, ai, si * 0.97)
                    else:
                        cfg[j] = _clamp_one(xj, yj, aj, sj * 0.97)
                    moved = True
        if not moved:
            break
    return cfg


# ---------------------------------------------------------------------------
# Seeding
# ---------------------------------------------------------------------------

def _seed_grid(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    s = 1.0 / k
    cfg = [( (i + 0.5) * s, (j + 0.5) * s, 0.0, s)
           for i in range(k) for j in range(k)]
    # fill the remainder with small squares stacked in a corner
    r = n - k * k
    if r > 0:
        t = min(1.0 - k * s, 1.0 / r)
        if t <= 0:
            t = 1e-6
        for i in range(r):
            cfg.append((t / 2.0 + i * t, k * s + t / 2.0, 0.0, t))
    cfg = cfg[:n]
    while len(cfg) < n:
        cfg.append((0.5, 0.5, 0.0, 0.0))
    return cfg


def _seed_random(n, rng):
    cfg = []
    for _ in range(n):
        s = rng.uniform(0.05, 0.3)
        a = rng.choice([0.0, 0.0, 0.0, 0.125, 0.25])
        cfg.append((rng.uniform(s, 1.0 - s), rng.uniform(s, 1.0 - s), a, s))
    return cfg


def _seed_corner(n):
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0 if n == 1 else 0.0)]
    # one big square + strip of n-1 squares
    m = n - 1
    best_t = 1.0
    best_v = -1.0
    for it in range(200):
        t = 1e-6 + (1.0 - 1e-6) * it / 199.0
        b = 1.0 - t
        if b <= 0 or m * t > 1.0 + 1e-12:
            continue
        v = b + m * t
        if v > best_v:
            best_v = v
            best_t = t
    t = best_t
    b = 1.0 - t
    cfg = [(b / 2.0, b / 2.0, 0.0, b)]
    for i in range(m):
        cfg.append((t / 2.0 + i * t, b + t / 2.0, 0.0, t))
    return cfg


# ---------------------------------------------------------------------------
# Boundary-evolution growth
# ---------------------------------------------------------------------------

def _grow(cfg, n, rng, iters=300, grow_rate=0.02):
    cfg = _repair(cfg)
    best = list(cfg)
    best_v = _score(cfg)
    for it in range(iters):
        cand = list(cfg)
        # grow each square a little (with jitter)
        for idx in range(n):
            cx, cy, a, s = cand[idx]
            if s <= 0.0:
                s = 1e-4
            ns = s * (1.0 + grow_rate * rng.uniform(0.5, 1.5))
            # occasionally jitter the centre and angle
            if rng.random() < 0.3:
                cx += rng.uniform(-0.01, 0.01)
                cy += rng.uniform(-0.01, 0.01)
            if rng.random() < 0.15:
                a += rng.uniform(-0.05, 0.05)
            cand[idx] = _clamp_one(cx, cy, a, ns)
        cand = _repair(cand)
        v = _score(cand)
        if v > best_v + 1e-9:
            best_v = v
            best = list(cand)
            cfg = cand
        elif v > _score(cfg) - 1e-3:
            # accept near-neutral moves to keep exploring
            cfg = cand
        else:
            # reject: shrink slightly
            cfg = list(best)
    return best


# ---------------------------------------------------------------------------
# Simulated-annealing polish
# ---------------------------------------------------------------------------

def _polish(cfg, n, rng, iters=600):
    cfg = _repair(cfg)
    cur = list(cfg)
    cur_v = _score(cur)
    best = list(cur)
    best_v = cur_v
    T0 = 0.05
    for it in range(iters):
        T = T0 * (1.0 - it / iters) + 1e-4
        i = rng.randrange(n)
        cx, cy, a, s = cur[i]
        # propose a small perturbation
        new_s = max(0.0, s + rng.gauss(0.0, 0.01))
        new_a = a + rng.gauss(0.0, 0.02)
        new_cx = cx + rng.gauss(0.0, 0.01)
        new_cy = cy + rng.gauss(0.0, 0.01)
        trial = list(cur)
        trial[i] = _clamp_one(new_cx, new_cy, new_a, new_s)
        trial = _repair(trial, max_iter=15)
        tv = _score(trial)
        if tv > cur_v or rng.random() < math.exp((tv - cur_v) / max(T, 1e-9)):
            cur = trial
            cur_v = tv
            if tv > best_v:
                best_v = tv
                best = list(trial)
    return best


# ---------------------------------------------------------------------------
# Final safety net
# ---------------------------------------------------------------------------

def _sanitize(cfg):
    out = []
    for (cx, cy, ang, s) in cfg:
        if s <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        out.append(_clamp_one(cx, cy, ang, s))
    for i in range(len(out)):
        if out[i][3] <= 0.0:
            continue
        for j in range(i + 1, len(out)):
            if out[j][3] <= 0.0:
                continue
            if _overlap(out, i, j):
                out[j] = (0.5, 0.5, 0.0, 0.0)
    return out


def _pad(cfg, n):
    cfg = list(cfg)
    cfg += [(0.5, 0.5, 0.0, 0.0)] * (n - len(cfg))
    return cfg[:n]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    seeds = [
        _seed_grid(n),
        _seed_corner(n),
    ]
    for _ in range(4):
        seeds.append(_seed_random(n, rng))

    best_cfg = None
    best_v = -1.0
    for seed in seeds:
        try:
            cfg = _repair(seed)
            v = _score(cfg)
            if v > best_v:
                best_v = v
                best_cfg = cfg
        except Exception:
            continue

    if best_cfg is None:
        best_cfg = _pad(_seed_grid(n), n)

    # Growth phase from each of the top seeds
    for seed in seeds[:3]:
        try:
            cand = _grow(_repair(seed), n, rng, iters=200, grow_rate=0.03)
            v = _score(cand)
            if v > best_v:
                best_v = v
                best_cfg = cand
        except Exception:
            continue

    # Polish the best
    try:
        polished = _polish(best_cfg, n, rng, iters=500)
        if _score(polished) > best_v:
            best_v = _score(polished)
            best_cfg = polished
    except Exception:
        pass

    best_cfg = _pad(best_cfg, n)
    best_cfg = _sanitize(best_cfg)
    return best_cfg
# EVOLVE-BLOCK-END