# EVOLVE-BLOCK-START
"""Recursive guillotine packing + L-corner 3-block search.

Instead of a fixed template registry, we recursively split the unit square
with axis-aligned guillotine cuts and fill each leaf rectangle with a
uniform grid of squares.  A small set of split ratios is explored and the
square budget is allocated between the two sub-rectangles proportionally
to their areas.  This subsumes the grid / strip / L-shape / two-strip
templates and additionally covers the 3-way L-corner split that the
previous programs missed.

A safety sanitizer clamps squares into the unit square and removes any
overlapping pair (turning the offending square into a point).
"""
import math

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _score(config):
    return sum(s for (_, _, _, s) in config)


def _pad(config, n):
    config = list(config)
    config += [(0.5, 0.5, 0.0, 0.0)] * (n - len(config))
    return config[:n]


def _grid_in_rect(x0, y0, w, h, k):
    """k squares packed as a grid in the rect [x0,x0+w] x [y0,y0+h].

    Choose the grid dimensions (nx, ny) with nx*ny >= k, minimizing the
    largest side that fits, i.e. maximizing side = min(w/nx, h/ny) while
    nx*ny == k (exact tiling) when possible, else fill exactly k cells
    using the ceil grid and shrink to fit.
    """
    if k <= 0 or w <= 0.0 or h <= 0.0:
        return []
    # try exact factorizations nx*ny == k
    best = None
    best_s = -1.0
    for nx in range(1, k + 1):
        if k % nx != 0:
            continue
        ny = k // nx
        s = min(w / nx, h / ny)
        if s > best_s:
            best_s = s
            best = (nx, ny, s)
    # also try ceil grids (nx*ny >= k) which can be better when k is prime
    for nx in range(1, k + 1):
        ny = (k + nx - 1) // nx
        s = min(w / nx, h / ny)
        if s > best_s + 1e-15:
            best_s = s
            best = (nx, ny, s)
    if best is None:
        return []
    nx, ny, s = best
    if s <= 0.0:
        return []
    # center the used block of size nx*s x ny*s in the rect
    used_w = nx * s
    used_h = ny * s
    ox = x0 + (w - used_w) / 2.0
    oy = y0 + (h - used_h) / 2.0
    out = []
    placed = 0
    for j in range(ny):
        for i in range(nx):
            if placed >= k:
                break
            cx = ox + (i + 0.5) * s
            cy = oy + (j + 0.5) * s
            out.append((cx, cy, 0.0, s))
            placed += 1
        if placed >= k:
            break
    return out


# ---------------------------------------------------------------------------
# Recursive guillotine split
# ---------------------------------------------------------------------------

def _split_rect(x0, y0, w, h, n, depth, out):
    """Place n squares in rect [x0,x0+w] x [y0,y0+h] using guillotine splits."""
    if n <= 0:
        return
    if n == 1:
        s = min(w, h)
        out.append((x0 + w / 2.0, y0 + h / 2.0, 0.0, s))
        return
    if depth >= 3:
        out.extend(_grid_in_rect(x0, y0, w, h, n))
        return

    # baseline: uniform grid in this rect
    base = _grid_in_rect(x0, y0, w, h, n)
    base_s = _score(base)

    best = base
    best_v = base_s

    # candidate split fractions
    ratios = [0.25, 0.3, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.7, 0.75]

    # vertical split
    for fr in ratios:
        w1 = w * fr
        w2 = w - w1
        if w1 <= 1e-9 or w2 <= 1e-9:
            continue
        # allocate squares proportional to area
        a1 = w1 * h
        a2 = w2 * h
        tot = a1 + a2
        n1 = int(round(n * a1 / tot))
        n1 = max(1, min(n - 1, n1))
        n2 = n - n1
        cfg = []
        _split_rect(x0, y0, w1, h, n1, depth + 1, cfg)
        _split_rect(x0 + w1, y0, w2, h, n2, depth + 1, cfg)
        v = _score(cfg)
        if v > best_v:
            best_v = v
            best = cfg

    # horizontal split
    for fr in ratios:
        h1 = h * fr
        h2 = h - h1
        if h1 <= 1e-9 or h2 <= 1e-9:
            continue
        a1 = w * h1
        a2 = w * h2
        tot = a1 + a2
        n1 = int(round(n * a1 / tot))
        n1 = max(1, min(n - 1, n1))
        n2 = n - n1
        cfg = []
        _split_rect(x0, y0, w, h1, n1, depth + 1, cfg)
        _split_rect(x0, y0 + h1, w, h2, n2, depth + 1, cfg)
        v = _score(cfg)
        if v > best_v:
            best_v = v
            best = cfg

    out.extend(best)


def _template_recursive(n):
    out = []
    _split_rect(0.0, 0.0, 1.0, 1.0, n, 0, out)
    return _pad(out, n)


# ---------------------------------------------------------------------------
# L-corner 3-block template (direct target of the recommendation)
# ---------------------------------------------------------------------------

def _template_L_corner(n):
    """Corner square of side a, right strip with r1 squares, top strip with
    r2 squares, and a top-right corner block with r3 squares.
    r1 + r2 + r3 = n - 1, a + strip_width = 1."""
    if n <= 1:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    m = n - 1
    best = None
    best_v = -1.0

    for r1 in range(0, m + 1):
        for r2 in range(0, m - r1 + 1):
            r3 = m - r1 - r2

            # given a (corner size), strip width t = 1 - a
            # right strip: r1 squares of side t1 in column of width t, height a
            # top strip:  r2 squares of side t2 in row of height t, width a
            # top-right block: r3 squares in square of side t (region [a,1]x[a,1])
            def make(a):
                if a <= 0.0 or a >= 1.0:
                    return None
                t = 1.0 - a
                cfg = [(a / 2.0, a / 2.0, 0.0, a)]
                # right strip [a,1] x [0,a]
                if r1 > 0:
                    t1 = min(t, a / r1) if r1 > 0 else 0.0
                    if t1 <= 0.0:
                        return None
                    for i in range(r1):
                        cfg.append((a + t / 2.0, (i + 0.5) * t1, 0.0, t1))
                # top strip [0,a] x [a,1]
                if r2 > 0:
                    t2 = min(a, t / r2) if r2 > 0 else 0.0
                    if t2 <= 0.0:
                        return None
                    for i in range(r2):
                        cfg.append(((i + 0.5) * t2, a + t / 2.0, 0.0, t2))
                # top-right block [a,1] x [a,1], side t
                if r3 > 0:
                    sub = _grid_in_rect(a, a, t, t, r3)
                    if len(sub) < r3:
                        return None
                    cfg.extend(sub)
                return cfg

            def obj(a):
                cfg = make(a)
                return -1.0 if cfg is None else _score(cfg)

            # coarse scan then golden refine
            best_a = None
            best_av = -1.0
            for i in range(1, 40):
                a = i / 40.0
                v = obj(a)
                if v > best_av:
                    best_av = v
                    best_a = a
            if best_a is None:
                continue
            # local refine around best_a
            lo = max(1e-6, best_a - 0.05)
            hi = min(1.0 - 1e-6, best_a + 0.05)
            gr = (math.sqrt(5.0) - 1.0) / 2.0
            aa, bb = lo, hi
            c = bb - gr * (bb - aa)
            d = aa + gr * (bb - aa)
            fc, fd = obj(c), obj(d)
            for _ in range(40):
                if fc > fd:
                    bb, d, fd = d, c, fc
                    c = bb - gr * (bb - aa)
                    fc = obj(c)
                else:
                    aa, c, fc = c, d, fd
                    d = aa + gr * (bb - aa)
                    fd = obj(d)
            a_opt = (aa + bb) / 2.0
            cfg = make(a_opt)
            if cfg is None:
                continue
            v = _score(cfg)
            if v > best_v:
                best_v = v
                best = cfg

    if best is None:
        return None
    return _pad(best, n)


# ---------------------------------------------------------------------------
# Two-strip fine scan (subsumes old _template_two_strips)
# ---------------------------------------------------------------------------

def _template_two_strips(n):
    k = math.isqrt(n)
    r = n - k * k
    if k == 0 or r == 0:
        return None
    best = None
    best_v = -1.0
    S = 200
    r_top_best = 0
    for r_top in range(0, r + 1):
        r_right = r - r_top
        for i in range(1, S + 1):
            s = i / S
            if k * s >= 1.0:
                break
            avail = 1.0 - k * s
            if avail <= 0.0:
                continue
            t_top = min(avail, 1.0 / r_top) if r_top > 0 else 0.0
            t_right = min(avail, 1.0 / r_right) if r_right > 0 else 0.0
            total = k * k * s + r_top * t_top + r_right * t_right
            if total > best_v:
                best_v = total
                r_top_best = r_top
                s_best = s
    if best_v < 0:
        return None
    r_top = r_top_best
    r_right = r - r_top
    s = s_best
    avail = 1.0 - k * s
    t_top = min(avail, 1.0 / r_top) if r_top > 0 else 0.0
    t_right = min(avail, 1.0 / r_right) if r_right > 0 else 0.0
    cfg = []
    for ii in range(k):
        for jj in range(k):
            cfg.append((s / 2.0 + ii * s, s / 2.0 + jj * s, 0.0, s))
    for ii in range(r_top):
        cfg.append((t_top / 2.0 + ii * t_top, k * s + t_top / 2.0, 0.0, t_top))
    for jj in range(r_right):
        cfg.append((k * s + t_right / 2.0, t_right / 2.0 + jj * t_right, 0.0, t_right))
    return _pad(cfg, n)


# ---------------------------------------------------------------------------
# Big-corner + strips (n = 2k+2 special case generalised)
# ---------------------------------------------------------------------------

def _template_big_corner(n):
    """One big corner square + remaining squares split between top row and
    right column, with sizes allowed to differ.  Tries every split r1+r2=n-1."""
    if n <= 1:
        return None
    m = n - 1
    best = None
    best_v = -1.0
    S = 200
    for r1 in range(0, m + 1):
        r2 = m - r1
        for i in range(1, S + 1):
            a = i / S  # big square side
            if a >= 1.0:
                break
            t = 1.0 - a  # strip width
            # right column: r1 squares of side t1 in [a,1]x[0,a]
            t1 = min(t, a / r1) if r1 > 0 else 0.0
            # top row: r2 squares of side t2 in [0,a]x[a,1]
            t2 = min(a, t / r2) if r2 > 0 else 0.0
            total = a + r1 * t1 + r2 * t2
            if total > best_v:
                best_v = total
                best = (a, r1, r2, t1, t2)
    if best is None:
        return None
    a, r1, r2, t1, t2 = best
    cfg = [(a / 2.0, a / 2.0, 0.0, a)]
    t = 1.0 - a
    for jj in range(r1):
        cfg.append((a + t / 2.0, (jj + 0.5) * t1, 0.0, t1))
    for ii in range(r2):
        cfg.append(((ii + 0.5) * t2, a + t / 2.0, 0.0, t2))
    return _pad(cfg, n)


# ---------------------------------------------------------------------------
# Safety: clamp and resolve overlaps
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, s):
    half = s / 2.0
    ca = math.cos(2.0 * math.pi * ang)
    sa = math.sin(2.0 * math.pi * ang)
    pts = [(-half, -half), (half, -half), (half, half), (-half, half)]
    return [(cx + ca * px - sa * py, cy + sa * px + ca * py) for (px, py) in pts]


def _bbox(cx, cy, ang, s):
    ca = abs(math.cos(2.0 * math.pi * ang))
    sa = abs(math.sin(2.0 * math.pi * ang))
    hx = (ca + sa) * s / 2.0
    return (cx - hx, cx + hx, cy - hx, cy + hx)


def _overlap(cfg, i, j):
    A = _corners(*cfg[i])
    B = _corners(*cfg[j])
    axes = []
    for P in (A, B):
        for a, b in ((0, 1), (1, 2)):
            ex = P[b][0] - P[a][0]
            ey = P[b][1] - P[a][1]
            n = math.hypot(ex, ey)
            if n > 1e-15:
                axes.append((-ey / n, ex / n))
    for (ax, ay) in axes:
        pa = [ax * p[0] + ay * p[1] for p in A]
        pb = [ax * p[0] + ay * p[1] for p in B]
        if max(pa) <= min(pb) + 1e-12 or max(pb) <= min(pa) + 1e-12:
            return False
    return True


def _sanitize(cfg):
    out = []
    for (cx, cy, ang, s) in cfg:
        if s <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ca = abs(math.cos(2.0 * math.pi * ang)) + abs(math.sin(2.0 * math.pi * ang))
        max_s = 1.0 / ca if ca > 0 else 1.0
        s = min(s, max_s)
        cx = min(max(cx, s * ca / 2.0), 1.0 - s * ca / 2.0)
        cy = min(max(cy, s * ca / 2.0), 1.0 - s * ca / 2.0)
        out.append((cx, cy, ang, s))

    boxes = [_bbox(*item) for item in out]
    for i in range(len(out)):
        if out[i][3] <= 0.0:
            continue
        bi = boxes[i]
        for j in range(i + 1, len(out)):
            if out[j][3] <= 0.0:
                continue
            bj = boxes[j]
            if (bi[1] <= bj[0] + 1e-12 or bj[1] <= bi[0] + 1e-12 or
                    bi[3] <= bj[2] + 1e-12 or bj[3] <= bi[2] + 1e-12):
                continue
            if _overlap(out, i, j):
                out[j] = (0.5, 0.5, 0.0, 0.0)
                boxes[j] = _bbox(*out[j])
    return out


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []

    candidates = []

    try:
        candidates.append(_template_recursive(n))
    except Exception:
        pass

    try:
        candidates.append(_template_L_corner(n))
    except Exception:
        pass

    try:
        candidates.append(_template_two_strips(n))
    except Exception:
        pass

    try:
        candidates.append(_template_big_corner(n))
    except Exception:
        pass

    # pure grid fallback
    k = math.isqrt(n)
    if k > 0:
        s = 1.0 / k
        grid = [(s / 2.0 + i * s, s / 2.0 + j * s, 0.0, s)
                for i in range(k) for j in range(k)]
        candidates.append(_pad(grid, n))

    best = None
    best_v = -1.0
    for cfg in candidates:
        if cfg is None:
            continue
        v = _score(cfg)
        if v > best_v:
            best_v = v
            best = cfg

    if best is None:
        k = math.isqrt(n) if n > 0 else 0
        if k == 0:
            best = [(0.5, 0.5, 0.0, 0.0)] * n
        else:
            s = 1.0 / k
            best = _pad([(s / 2.0 + i * s, s / 2.0 + j * s, 0.0, s)
                         for i in range(k) for j in range(k)], n)

    best = _pad(best, n)
    best = _sanitize(best)
    return best
# EVOLVE-BLOCK-END