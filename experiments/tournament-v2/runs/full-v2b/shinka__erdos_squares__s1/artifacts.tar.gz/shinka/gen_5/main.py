# EVOLVE-BLOCK-START
"""Adaptive layout optimizer for packing squares in the unit square.

Architecture:
  * Layout templates: small functions that, given parameters, produce a list of
    non-overlapping squares inside [0,1]^2.
  * Parameter optimizers: generic 1-D and 2-D search routines (golden-section
    and coordinate descent) that tune the parameters of each template.
  * Selector: runs every template, scores the result, and returns the best.
"""

import math

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _grid(k, s, x0=0.0, y0=0.0):
    """k x k grid of side s anchored at (x0, y0)."""
    out = []
    for i in range(k):
        for j in range(k):
            out.append((x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, 0.0, s))
    return out


def _row(r, t, x0=0.0, y0=0.0):
    """r squares of side t in a horizontal row anchored at (x0, y0)."""
    return [(x0 + (i + 0.5) * t, y0 + 0.5 * t, 0.0, t) for i in range(r)]


def _col(r, t, x0=0.0, y0=0.0):
    """r squares of side t in a vertical column anchored at (x0, y0)."""
    return [(x0 + 0.5 * t, y0 + (i + 0.5) * t, 0.0, t) for i in range(r)]


def _score(config):
    return sum(s for (_, _, _, s) in config)


def _pad(config, n):
    config = list(config)
    config += [(0.5, 0.5, 0.0, 0.0)] * (n - len(config))
    return config[:n]


# ---------------------------------------------------------------------------
# Parameter optimizers
# ---------------------------------------------------------------------------

def _golden_max(f, lo, hi, iters=40):
    """Maximize a unimodal-ish 1-D function on [lo, hi]."""
    gr = (math.sqrt(5.0) - 1.0) / 2.0
    a, b = lo, hi
    c = b - gr * (b - a)
    d = a + gr * (b - a)
    fc, fd = f(c), f(d)
    for _ in range(iters):
        if fc > fd:
            b, d, fd = d, c, fc
            c = b - gr * (b - a)
            fc = f(c)
        else:
            a, c, fc = c, d, fd
            d = a + gr * (b - a)
            fd = f(d)
    return (a + b) / 2.0


def _coordinate_descent(f, x0, bounds, iters=6, steps=25):
    """Simple coordinate descent maximizer over a box."""
    x = list(x0)
    for _ in range(iters):
        improved = False
        for i in range(len(x)):
            lo, hi = bounds[i]
            best_x, best_v = x[i], f(x)
            for j in range(steps + 1):
                v = lo + (hi - lo) * j / steps
                x[i] = v
                fv = f(x)
                if fv > best_v:
                    best_v, best_x = fv, v
            x[i] = best_x
            if best_x != x[i]:
                improved = True
        if not improved:
            break
    return x


# ---------------------------------------------------------------------------
# Layout templates
# ---------------------------------------------------------------------------

def _template_grid(n):
    """Pure k x k grid (k = isqrt(n))."""
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    s = 1.0 / k
    return _pad(_grid(k, s), n)


def _template_strip(n):
    """k x k grid of side s in bottom-left, plus r extra squares in a top strip."""
    k = math.isqrt(n)
    r = n - k * k
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    if r == 0:
        return _template_grid(n)

    def make(s):
        if s <= 0.0 or k * s >= 1.0:
            return None
        # top strip height available
        avail_h = 1.0 - k * s
        if avail_h <= 0.0:
            return None
        # r squares in a row: side t <= avail_h, and r*t <= 1
        t = min(avail_h, 1.0 / r)
        if t <= 0.0:
            return None
        cfg = _grid(k, s)
        cfg += _row(r, t, 0.0, k * s)
        return cfg

    def obj(s):
        cfg = make(s)
        if cfg is None:
            return -1.0
        return _score(cfg)

    # search s in (0, 1/k)
    hi = 1.0 / k
    s_opt = _golden_max(obj, 1e-6, hi - 1e-9, iters=45)
    cfg = make(s_opt)
    if cfg is None:
        return _template_grid(n)
    return _pad(cfg, n)


def _template_lshape(n):
    """Big square of side b in bottom-left, plus rows/cols of small squares."""
    # n = 1 + a + c, big square side b, small side t, a squares on top, c on right.
    # Feasible: b + t <= 1, a*t <= 1, c*t <= 1.
    best = None
    best_v = -1.0
    for a in range(0, n):
        c = n - 1 - a
        if c < 0:
            continue
        # choose b and t to maximize b + (a+c)*t with b + t <= 1
        # given t, best b = 1 - t; total = (1 - t) + (a+c)*t = 1 + (a+c-1)*t
        # but also b >= t (optional) and a*t <= 1, c*t <= 1
        def obj(t):
            if t <= 0.0 or t >= 1.0:
                return -1.0
            b = 1.0 - t
            if a * t > 1.0 + 1e-12 or c * t > 1.0 + 1e-12:
                return -1.0
            return b + (a + c) * t
        t_opt = _golden_max(obj, 1e-6, 1.0 - 1e-9, iters=45)
        v = obj(t_opt)
        if v > best_v:
            b = 1.0 - t_opt
            if a * t_opt > 1.0 + 1e-9 or c * t_opt > 1.0 + 1e-9:
                continue
            cfg = [(b / 2.0, b / 2.0, 0.0, b)]
            cfg += _row(a, t_opt, 0.0, b)
            cfg += _col(c, t_opt, b, 0.0)
            best_v = v
            best = cfg
    if best is None:
        return _template_grid(n)
    return _pad(best, n)


def _template_corner_plus_row(n):
    """One big square in a corner, remaining squares in a single row/col strip."""
    # n = 1 + m, big side b, m small squares side t in a row along one side.
    m = n - 1
    if m <= 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n

    def make(t):
        if t <= 0.0:
            return None
        # big square side b = 1 - t, row of m squares side t along top
        b = 1.0 - t
        if b <= 0.0 or m * t > 1.0 + 1e-12:
            return None
        cfg = [(b / 2.0, b / 2.0, 0.0, b)]
        cfg += _row(m, t, 0.0, b)
        return cfg

    def obj(t):
        cfg = make(t)
        if cfg is None:
            return -1.0
        return _score(cfg)

    t_opt = _golden_max(obj, 1e-6, 1.0 - 1e-9, iters=45)
    cfg = make(t_opt)
    if cfg is None:
        return _template_grid(n)
    return _pad(cfg, n)


def _template_two_strips(n):
    """k x k grid, then two strips (top and right) filled with squares."""
    k = math.isqrt(n)
    r = n - k * k
    if k == 0 or r == 0:
        return _template_grid(n)

    # split r into r_top + r_right
    best = None
    best_v = -1.0
    for r_top in range(0, r + 1):
        r_right = r - r_top

        def make(s):
            if s <= 0.0 or k * s >= 1.0:
                return None
            avail_top = 1.0 - k * s
            avail_right = 1.0 - k * s
            if avail_top <= 0.0 or avail_right <= 0.0:
                return None
            t_top = min(avail_top, 1.0 / r_top) if r_top > 0 else 0.0
            t_right = min(avail_right, 1.0 / r_right) if r_right > 0 else 0.0
            cfg = _grid(k, s)
            if r_top > 0:
                cfg += _row(r_top, t_top, 0.0, k * s)
            if r_right > 0:
                cfg += _col(r_right, t_right, k * s, 0.0)
            return cfg

        def obj(s):
            cfg = make(s)
            if cfg is None:
                return -1.0
            return _score(cfg)

        s_opt = _golden_max(obj, 1e-6, 1.0 / k - 1e-9, iters=35)
        cfg = make(s_opt)
        if cfg is not None:
            v = _score(cfg)
            if v > best_v:
                best_v = v
                best = cfg
    if best is None:
        return _template_grid(n)
    return _pad(best, n)


def _template_rotated(n):
    """Try a rotated square in the corner plus a grid, to escape axis-aligned limits."""
    if n < 5:
        return None
    k = math.isqrt(n)
    r = n - k * k
    if r == 0:
        return None

    # Big rotated square in bottom-left corner (45 deg), side b.
    # Its bounding box is b*sqrt(2) x b*sqrt(2). Place small squares in the
    # remaining L-shaped region using axis-aligned grid.
    def make(b):
        if b <= 0.0:
            return None
        diag = b * math.sqrt(2.0)
        if diag >= 1.0:
            return None
        # remaining region: right column of width 1 - diag, and top row of height 1 - diag
        # put r squares in the remaining region (approximate: use a row of r squares)
        t = min(1.0 - diag, 1.0 / r) if r > 0 else 0.0
        if t <= 0.0:
            return None
        cfg = [(b / 2.0, b / 2.0, 0.125, b)]  # angle 0.125 = 45 deg
        cfg += _row(r, t, 0.0, diag)
        return cfg

    def obj(b):
        cfg = make(b)
        if cfg is None:
            return -1.0
        return _score(cfg)

    b_opt = _golden_max(obj, 1e-6, 1.0 / math.sqrt(2.0) - 1e-9, iters=35)
    cfg = make(b_opt)
    if cfg is None:
        return None
    return _pad(cfg, n)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    templates = [
        _template_grid,
        _template_strip,
        _template_lshape,
        _template_corner_plus_row,
        _template_two_strips,
    ]

    best_cfg = None
    best_v = -1.0
    for tmpl in templates:
        try:
            cfg = tmpl(n)
        except Exception:
            cfg = None
        if cfg is None:
            continue
        v = _score(cfg)
        if v > best_v:
            best_v = v
            best_cfg = cfg

    # rotated template as an optional extra
    rot = _template_rotated(n)
    if rot is not None:
        v = _score(rot)
        if v > best_v:
            best_v = v
            best_cfg = rot

    if best_cfg is None:
        best_cfg = _template_grid(n)

    return _pad(best_cfg, n)
# EVOLVE-BLOCK-END