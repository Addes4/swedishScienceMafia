# EVOLVE-BLOCK-START
"""Adaptive layout optimizer: grid + strip + L-shape + two-strip + rotated,
with golden-section tuning of each template's continuous parameter."""

import math

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _grid(k, s, x0=0.0, y0=0.0):
    return [(x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, 0.0, s)
            for i in range(k) for j in range(k)]


def _row(r, t, x0=0.0, y0=0.0):
    return [(x0 + (i + 0.5) * t, y0 + 0.5 * t, 0.0, t) for i in range(r)]


def _col(r, t, x0=0.0, y0=0.0):
    return [(x0 + 0.5 * t, y0 + (i + 0.5) * t, 0.0, t) for i in range(r)]


def _score(config):
    return sum(s for (_, _, _, s) in config)


def _pad(config, n):
    config = list(config)
    config += [(0.5, 0.5, 0.0, 0.0)] * (n - len(config))
    return config[:n]


def _golden_max(f, lo, hi, iters=40):
    gr = (math.sqrt(5.0) - 1.0) / 2.0
    a, b = lo, hi
    c = b - gr * (b - a)
    d = a + gr * (b - a)
    fc, fd = f(c), f(d)
    for _ in range(iters):
        if fc > fd:
            b, d, fd = d, c, fc
            c = b - gr * (b - a)
            fc = f(c)
        else:
            a, c, fc = c, d, fd
            d = a + gr * (b - a)
            fd = f(d)
    return (a + b) / 2.0


# ---------------------------------------------------------------------------
# Templates
# ---------------------------------------------------------------------------

def _template_grid(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    s = 1.0 / k
    return _pad(_grid(k, s), n)


def _template_strip(n):
    """k x k grid of side s + r extra squares in a top strip."""
    k = math.isqrt(n)
    r = n - k * k
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    if r == 0:
        return _template_grid(n)

    def make(s):
        if s <= 0.0 or k * s >= 1.0:
            return None
        avail_h = 1.0 - k * s
        if avail_h <= 0.0:
            return None
        t = min(avail_h, 1.0 / r)
        if t <= 0.0:
            return None
        cfg = _grid(k, s)
        cfg += _row(r, t, 0.0, k * s)
        return cfg

    def obj(s):
        cfg = make(s)
        return -1.0 if cfg is None else _score(cfg)

    hi = 1.0 / k
    s_opt = _golden_max(obj, 1e-7, hi - 1e-9, iters=45)
    cfg = make(s_opt)
    if cfg is None:
        return _template_grid(n)
    return _pad(cfg, n)


def _template_lshape(n):
    """Big square of side b in bottom-left + a squares on top + c squares on right."""
    best = None
    best_v = -1.0
    for a in range(0, n):
        c = n - 1 - a
        if c < 0:
            continue

        def obj(t):
            if t <= 0.0 or t >= 1.0:
                return -1.0
            if a * t > 1.0 + 1e-12 or c * t > 1.0 + 1e-12:
                return -1.0
            b = 1.0 - t
            return b + (a + c) * t

        t_opt = _golden_max(obj, 1e-7, 1.0 - 1e-9, iters=45)
        v = obj(t_opt)
        if v > best_v:
            b = 1.0 - t_opt
            if a * t_opt > 1.0 + 1e-9 or c * t_opt > 1.0 + 1e-9:
                continue
            cfg = [(b / 2.0, b / 2.0, 0.0, b)]
            if a > 0:
                cfg += _row(a, t_opt, 0.0, b)
            if c > 0:
                cfg += _col(c, t_opt, b, 0.0)
            best_v = v
            best = cfg
    if best is None:
        return _template_grid(n)
    return _pad(best, n)


def _template_corner_plus_row(n):
    """One big square in a corner + m squares in a single strip."""
    m = n - 1
    if m <= 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n

    def make(t):
        if t <= 0.0:
            return None
        b = 1.0 - t
        if b <= 0.0 or m * t > 1.0 + 1e-12:
            return None
        cfg = [(b / 2.0, b / 2.0, 0.0, b)]
        cfg += _row(m, t, 0.0, b)
        return cfg

    def obj(t):
        cfg = make(t)
        return -1.0 if cfg is None else _score(cfg)

    t_opt = _golden_max(obj, 1e-7, 1.0 - 1e-9, iters=45)
    cfg = make(t_opt)
    if cfg is None:
        return _template_grid(n)
    return _pad(cfg, n)


def _template_two_strips(n):
    """k x k grid + split r extras between a top row and a right column."""
    k = math.isqrt(n)
    r = n - k * k
    if k == 0 or r == 0:
        return _template_grid(n)

    best = None
    best_v = -1.0
    for r_top in range(0, r + 1):
        r_right = r - r_top

        def make(s):
            if s <= 0.0 or k * s >= 1.0:
                return None
            avail = 1.0 - k * s
            if avail <= 0.0:
                return None
            t_top = min(avail, 1.0 / r_top) if r_top > 0 else 0.0
            t_right = min(avail, 1.0 / r_right) if r_right > 0 else 0.0
            cfg = _grid(k, s)
            if r_top > 0:
                cfg += _row(r_top, t_top, 0.0, k * s)
            if r_right > 0:
                cfg += _col(r_right, t_right, k * s, 0.0)
            return cfg

        def obj(s):
            cfg = make(s)
            return -1.0 if cfg is None else _score(cfg)

        s_opt = _golden_max(obj, 1e-7, 1.0 / k - 1e-9, iters=35)
        cfg = make(s_opt)
        if cfg is not None:
            v = _score(cfg)
            if v > best_v:
                best_v = v
                best = cfg
    if best is None:
        return _template_grid(n)
    return _pad(best, n)


def _template_rotated(n):
    """Rotated (45 deg) square in a corner + axis-aligned strip for the rest."""
    if n < 5:
        return None
    k = math.isqrt(n)
    r = n - k * k
    if r == 0:
        return None

    def make(b):
        if b <= 0.0:
            return None
        diag = b * math.sqrt(2.0)
        if diag >= 1.0:
            return None
        t = min(1.0 - diag, 1.0 / r) if r > 0 else 0.0
        if t <= 0.0:
            return None
        cfg = [(b / 2.0, b / 2.0, 0.125, b)]
        cfg += _row(r, t, 0.0, diag)
        return cfg

    def obj(b):
        cfg = make(b)
        return -1.0 if cfg is None else _score(cfg)

    b_opt = _golden_max(obj, 1e-7, 1.0 / math.sqrt(2.0) - 1e-9, iters=35)
    cfg = make(b_opt)
    if cfg is None:
        return None
    return _pad(cfg, n)


# ---------------------------------------------------------------------------
# Safety: clamp and resolve overlaps
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, s):
    """Return the four corners of a square as (x, y) tuples."""
    half = s / 2.0
    ca = math.cos(2.0 * math.pi * ang)
    sa = math.sin(2.0 * math.pi * ang)
    pts = [(-half, -half), (half, -half), (half, half), (-half, half)]
    return [(cx + ca * px - sa * py, cy + sa * px + ca * py) for (px, py) in pts]


def _overlap(cfg, i, j):
    """SAT test for two squares (axis-aligned bounding is enough for our templates,
    but we do a full SAT on the four corners for robustness)."""
    A = _corners(*cfg[i])
    B = _corners(*cfg[j])
    axes = []
    for P in (A, B):
        for a, b in ((0, 1), (1, 2)):
            ex = P[b][0] - P[a][0]
            ey = P[b][1] - P[a][1]
            n = math.hypot(ex, ey)
            if n > 1e-15:
                axes.append((-ey / n, ex / n))
    for (ax, ay) in axes:
        pa = [ax * p[0] + ay * p[1] for p in A]
        pb = [ax * p[0] + ay * p[1] for p in B]
        if max(pa) <= min(pb) + 1e-12 or max(pb) <= min(pa) + 1e-12:
            return False
    return True


def _sanitize(cfg):
    """Clamp into [0,1] and shrink overlapping squares to zero."""
    out = []
    for (cx, cy, ang, s) in cfg:
        if s <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        # clamp side so square fits inside unit box (worst-case rotated bbox)
        ca = abs(math.cos(2.0 * math.pi * ang)) + abs(math.sin(2.0 * math.pi * ang))
        max_s = 1.0 / ca if ca > 0 else 1.0
        s = min(s, max_s)
        cx = min(max(cx, s * ca / 2.0), 1.0 - s * ca / 2.0)
        cy = min(max(cy, s * ca / 2.0), 1.0 - s * ca / 2.0)
        out.append((cx, cy, ang, s))
    # resolve overlaps by zeroing the later square
    for i in range(len(out)):
        for j in range(i + 1, len(out)):
            if out[i][3] <= 0.0 or out[j][3] <= 0.0:
                continue
            if _overlap(out, i, j):
                out[j] = (0.5, 0.5, 0.0, 0.0)
    return out


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []

    templates = [
        _template_grid,
        _template_strip,
        _template_lshape,
        _template_corner_plus_row,
        _template_two_strips,
    ]

    best_cfg = None
    best_v = -1.0
    for tmpl in templates:
        try:
            cfg = tmpl(n)
        except Exception:
            cfg = None
        if cfg is None:
            continue
        v = _score(cfg)
        if v > best_v:
            best_v = v
            best_cfg = cfg

    try:
        rot = _template_rotated(n)
    except Exception:
        rot = None
    if rot is not None:
        v = _score(rot)
        if v > best_v:
            best_v = v
            best_cfg = rot

    if best_cfg is None:
        best_cfg = _template_grid(n)

    best_cfg = _pad(best_cfg, n)
    best_cfg = _sanitize(best_cfg)
    return best_cfg
# EVOLVE-BLOCK-END