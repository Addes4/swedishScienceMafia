# EVOLVE-BLOCK-START
"""Try several general constructions and pick the one with the largest sum of side lengths."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n == 0:
        return []
    k = math.isqrt(n)
    # Candidate 1: pure k x k grid
    best_sum = k
    side = 1.0 / k
    best_config = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
    best_config += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_config))
    best_config = best_config[:n]

    # Candidate 2: strip method (shrink grid, place extra squares in a strip)
    r = n - k * k
    if r > 0:
        # scan s from a small positive value up to 1/k
        for i in range(1, 1001):
            s = i / 1000.0
            if k * s > 1.0:
                break
            t = min(1.0 / r, 1.0 - k * s)
            if t <= 0.0:
                continue
            total = k * k * s + r * t
            if total > best_sum:
                best_sum = total
                config = []
                # k x k grid of side s in bottom-left corner
                for ii in range(k):
                    for jj in range(k):
                        config.append((s / 2.0 + ii * s, s / 2.0 + jj * s, 0.0, s))
                # r squares of side t in a row along the top strip
                for ii in range(r):
                    config.append((t / 2.0 + ii * t, k * s + t / 2.0, 0.0, t))
                config += [(0.5, 0.5, 0.0, 0.0)] * (n - len(config))
                best_config = config[:n]

    # Candidate 3: one big square plus small ones for n = 2k+2
    if n == 2 * k + 2:
        total = (3 * k + 1) / (k + 1)
        if total > best_sum:
            best_sum = total
            big = k / (k + 1)
            small = 1.0 / (k + 1)
            config = [(big / 2.0, big / 2.0, 0.0, big)]
            # top strip: k+1 squares of side small
            for ii in range(k + 1):
                config.append((small / 2.0 + ii * small, big + small / 2.0, 0.0, small))
            # right strip: k squares of side small
            for jj in range(k):
                config.append((big + small / 2.0, small / 2.0 + jj * small, 0.0, small))
            config += [(0.5, 0.5, 0.0, 0.0)] * (n - len(config))
            best_config = config[:n]

    return best_config
# EVOLVE-BLOCK-END