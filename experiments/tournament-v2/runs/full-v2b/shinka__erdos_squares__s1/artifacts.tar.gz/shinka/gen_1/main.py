# EVOLVE-BLOCK-START
"""Recursive guillotine packing: subdivide the unit square into rectangles."""
import math


def _pack_rect(x, y, w, h, m):
    """Pack m squares into rectangle [x,x+w] x [y,y+h]. Return list of (cx,cy,ang,s)."""
    if m <= 0:
        return []
    if m == 1:
        s = min(w, h)
        return [(x + w / 2.0, y + h / 2.0, 0.0, s)]

    # Candidate split sizes: place a square of side s in one corner.
    # Leftover: strip of size (w-s) x h and s x (h-s) (if square in top-left)
    # We try several s values and pick the one maximizing estimated sum.
    best = None
    best_score = -1.0

    # Candidate s values
    cands = set()
    cands.add(min(w, h))
    cands.add(w / 2.0)
    cands.add(h / 2.0)
    if w > h:
        cands.add(h)
        cands.add(w - h)
    else:
        cands.add(w)
        cands.add(h - w)
    # a few fractions
    for f in (0.25, 0.333333, 0.5, 0.666667, 0.75):
        cands.add(min(w, h) * f)
        cands.add(w * f)
        cands.add(h * f)
    cands = [s for s in cands if 1e-9 < s <= min(w, h) + 1e-9]

    for s in cands:
        s = min(s, w, h)
        # Two leftover rectangles: horizontal strip (w-s) x s  and vertical (w) x (h-s)
        # Actually with square in bottom-left corner (x,y):
        #   strip A: (x+s, y) size (w-s) x h
        #   strip B: (x, y+s) size s x (h-s)
        areaA = (w - s) * h
        areaB = s * (h - s)
        total_area = areaA + areaB
        if total_area < 1e-15:
            m1 = m - 1
            m2 = 0
        else:
            # allocate squares proportionally to area
            m1 = int(round((m - 1) * areaA / total_area))
            m1 = max(0, min(m - 1, m1))
            m2 = m - 1 - m1
        # Estimate: sum of sides if each region packed as single big square
        est = s
        if m1 > 0:
            est += m1 * min(w - s, h) if (w - s) > 0 else 0
        if m2 > 0:
            est += m2 * min(s, h - s) if (h - s) > 0 else 0
        if est > best_score:
            best_score = est
            best = (s, m1, m2)

    s, m1, m2 = best
    result = [(x + s / 2.0, y + s / 2.0, 0.0, s)]
    # Recurse on the two leftover rectangles
    if w - s > 1e-9 and m1 > 0:
        result += _pack_rect(x + s, y, w - s, h, m1)
    elif m1 > 0:
        # no room, dump as zero-size
        result += [(x + w / 2.0, y + h / 2.0, 0.0, 0.0)] * m1
    if h - s > 1e-9 and m2 > 0:
        result += _pack_rect(x, y + s, s, h - s, m2)
    elif m2 > 0:
        result += [(x + w / 2.0, y + h / 2.0, 0.0, 0.0)] * m2
    return result


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    return _pack_rect(0.0, 0.0, 1.0, 1.0, n)
# EVOLVE-BLOCK-END