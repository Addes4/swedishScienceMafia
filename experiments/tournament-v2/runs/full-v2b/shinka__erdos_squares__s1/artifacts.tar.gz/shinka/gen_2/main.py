# EVOLVE-BLOCK-START
import math


def _grid_squares(k, m=None):
    """Return a k x m grid of equal squares filling the unit square."""
    if m is None:
        m = k
    if k <= 0 or m <= 0:
        return []
    side = 1.0 / max(k, m)
    out = []
    for i in range(k):
        for j in range(m):
            out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    return out


def _strip_layout(n):
    """Try all k x m factorisations and keep the best total side sum."""
    best = []
    best_sum = -1.0
    for k in range(1, n + 1):
        for m in range(1, n + 1):
            if k * m <= n:
                sq = _grid_squares(k, m)
                extra = n - len(sq)
                total = len(sq) * (1.0 / max(k, m))
                if total > best_sum:
                    best_sum = total
                    best = sq[:]
                    if extra:
                        # place zero-size squares at the centre
                        best += [(0.5, 0.5, 0.0, 0.0)] * extra
    return best[:n]


def _mixed_layout(n):
    """Use a large grid plus a remainder strip along one side."""
    best = []
    best_sum = -1.0
    for k in range(1, n + 1):
        for m in range(1, n + 1):
            used = k * m
            if used > n:
                continue
            rem = n - used
            side = 1.0 / max(k, m)
            base_sum = used * side
            # Try to fill a remainder strip with equal squares.
            if rem > 0:
                # strip along the shorter dimension
                if k >= m:
                    strip_side = 1.0 / (k + rem)
                    strip_sum = rem * strip_side
                else:
                    strip_side = 1.0 / (m + rem)
                    strip_sum = rem * strip_side
            else:
                strip_sum = 0.0
            total = base_sum + strip_sum
            if total > best_sum:
                best_sum = total
                sq = _grid_squares(k, m)
                if rem:
                    if k >= m:
                        s = 1.0 / (k + rem)
                        for r in range(rem):
                            sq.append((0.5, (r + 0.5) * s, 0.0, s))
                    else:
                        s = 1.0 / (m + rem)
                        for r in range(rem):
                            sq.append(((r + 0.5) * s, 0.5, 0.0, s))
                best = sq
    return best[:n]


def _recursive_layout(n):
    """Recursively split the unit square into smaller grids."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # Try splitting into a grid plus a subproblem.
    best = []
    best_sum = -1.0
    for k in range(1, n + 1):
        for m in range(1, n + 1):
            used = k * m
            if used > n:
                continue
            rem = n - used
            side = 1.0 / max(k, m)
            base_sum = used * side
            if rem == 0:
                total = base_sum
                sq = _grid_squares(k, m)
            else:
                sub = _recursive_layout(rem)
                sub_sum = sum(s[3] for s in sub)
                total = base_sum + sub_sum
                sq = _grid_squares(k, m)
                # place sub-squares in remaining area (scaled)
                if k >= m:
                    scale = 1.0 / (k + rem)
                    for s in sub:
                        sq.append((0.5, 0.5, 0.0, s[3] * scale))
                else:
                    scale = 1.0 / (m + rem)
                    for s in sub:
                        sq.append((0.5, 0.5, 0.0, s[3] * scale))
            if total > best_sum:
                best_sum = total
                best = sq
    return best[:n]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    candidates = []
    candidates.append(_strip_layout(n))
    candidates.append(_mixed_layout(n))
    candidates.append(_recursive_layout(n))
    best = max(candidates, key=lambda sq: sum(s[3] for s in sq))
    # ensure exactly n squares
    if len(best) < n:
        best = best + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]
# EVOLVE-BLOCK-END
