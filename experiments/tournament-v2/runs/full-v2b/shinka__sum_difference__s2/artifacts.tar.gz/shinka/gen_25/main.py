# EVOLVE-BLOCK-START
"""Constructive approach: multi-level Golomb-ruler embedding.

Build A = union_{t=0}^{k-1} (t*M + B) where B is a Golomb ruler (all
pairwise differences distinct).  This gives:
  |A - A| ~ k^2 * |B - B|          (differences within and across levels)
  |A + A| ~ (2k-1) * |B + B|       (sums land in 2k-1 shifted copies of B+B)
so the ratio log|A-A|/log|A+A| approaches 2, far above local-search results.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _metrics(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score_from(d, s, n):
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _golomb(n, seed=0):
    """Greedy Golomb ruler of size n (differences all distinct)."""
    if n <= 1:
        return [0]
    if n == 2:
        return [0, 1]
    rng = random.Random(seed)
    a = [0, 1]
    diffs = {1, -1}
    while len(a) < n:
        x = a[-1] + 1
        while True:
            ok = True
            new_d = set()
            for y in a:
                d1 = x - y
                d2 = y - x
                if d1 in diffs or d2 in diffs or d1 in new_d or d2 in new_d:
                    ok = False
                    break
                new_d.add(d1)
                new_d.add(d2)
            if ok:
                break
            x += 1
        a.append(x)
        diffs |= new_d
    return a


def _golomb_cached(n):
    """Precomputed small Golomb rulers (optimal / near-optimal)."""
    table = {
        1: [0],
        2: [0, 1],
        3: [0, 1, 3],
        4: [0, 1, 4, 6],
        5: [0, 1, 4, 9, 11],
        6: [0, 1, 4, 10, 12, 17],
        7: [0, 1, 4, 10, 18, 23, 25],
        8: [0, 1, 4, 9, 15, 22, 32, 34],
        9: [0, 1, 5, 12, 25, 27, 35, 41, 44],
        10: [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
        11: [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
        12: [0, 2, 6, 24, 29, 40, 43, 55, 68, 75, 76, 85],
        13: [0, 2, 5, 25, 37, 43, 59, 70, 85, 89, 98, 99, 106],
        14: [0, 4, 6, 20, 35, 52, 59, 77, 78, 86, 89, 99, 122, 127],
    }
    if n in table:
        return table[n][:]
    return _golomb(n, seed=n)


def _build_multilevel(B, k, M):
    """A = union_{t=0}^{k-1} (t*M + B)."""
    out = set()
    for t in range(k):
        off = t * M
        for b in B:
            out.add(off + b)
    return sorted(out)


def _center(a):
    if not a:
        return a
    m = (min(a) + max(a)) // 2
    return [x - m for x in a]


def solve():
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2 or len(a) > 4000:
            return
        if any(abs(x) > 10**15 for x in a):
            return
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # ---- Phase 1: systematic multi-level construction search ----
    # Try many (m, k, M) triples.
    # Optimal m is bounded by total size constraint: k*m <= 4000.
    # For fixed m, |B-B| ~ m^2/2 (Golomb), |B+B| ~ m^2/4.
    # We want k large enough to boost cross-differences.
    best_ms = []

    # Precompute Golomb rulers for various m
    golomb_cache = {}
    for m in list(range(2, 30)) + [30, 35, 40, 50, 60, 80, 100, 130, 170, 220]:
        try:
            golomb_cache[m] = _golomb_cached(m)
        except Exception:
            pass

    # Search (m, k, M)
    for m in sorted(golomb_cache.keys()):
        B = golomb_cache[m]
        Bspan = B[-1] - B[0]
        if Bspan <= 0:
            continue
        # M must exceed Bspan so that levels don't overlap in differences
        # but not too large (else it doesn't matter).  Try a range.
        for k in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 30]:
            if k * m > 3800:
                continue
            # M choices: just above Bspan, and multiples
            for M in [Bspan + 1, Bspan + 2, 2 * Bspan, 3 * Bspan,
                      10 * Bspan, 100 * Bspan, 10**6, 10**9]:
                A = _build_multilevel(B, k, M)
                consider(_center(A))
            if time.time() > deadline * 0.35:
                break
        if time.time() > deadline * 0.35:
            break

    # ---- Phase 2: perturb M and B for the best configuration ----
    # Detect current best shape: try to identify (m, k, M) by trying
    # small perturbations of B and M around the current best.

    # First, figure out current best parameters heuristically by trying
    # to reconstruct: assume best came from some (B, k, M).
    # Instead, just do local search on the structure (B, k, M).

    # Track a set of candidate (B, k, M) structures and refine each.
    structures = []
    for m in sorted(golomb_cache.keys()):
        B = golomb_cache[m]
        Bspan = B[-1] - B[0]
        if Bspan <= 0:
            continue
        for k in [3, 4, 5, 6, 8, 10, 12, 16, 20]:
            if k * m > 3800:
                continue
            for M in [Bspan + 1, 2 * Bspan + 1, 3 * Bspan + 1]:
                A = _build_multilevel(B, k, M)
                sc = _score(_center(A))
                structures.append((sc, list(B), k, M))

    structures.sort(key=lambda x: -x[0])
    structures = structures[:20]

    t_refine_end = deadline * 0.85

    def refine_structure(B0, k, M0, budget):
        """Local search on B (integers) and M."""
        B = list(B0)
        M = M0
        A = _center(_build_multilevel(B, k, M))
        cur_score = _score(A)
        best_local = A[:]
        best_local_score = cur_score
        t0 = time.time()
        while time.time() - t0 < budget and time.time() < t_refine_end:
            op = random.random()
            newB = B[:]
            newM = M
            if op < 0.5:
                # perturb one element of B
                i = random.randrange(len(newB))
                span = max(1, newB[-1] - newB[0])
                delta = random.choice([-1, 1]) * random.choice(
                    [1, 2, max(1, span // 20), max(1, span // 5)])
                newB[i] += delta
            elif op < 0.8:
                # perturb M
                newM = M + random.choice([-1, 1]) * random.choice(
                    [1, 2, max(1, M // 20), max(1, M // 5)])
                if newM <= (newB[-1] - newB[0]):
                    newM = newB[-1] - newB[0] + 1
            else:
                # perturb all of B slightly
                rng = random.Random(random.randrange(10**9))
                for i in range(len(newB)):
                    if rng.random() < 0.3:
                        newB[i] += rng.choice([-1, 1])
            newB = sorted(set(newB))
            if len(newB) != len(B):
                continue
            A2 = _center(_build_multilevel(newB, k, newM))
            if len(A2) < 2 or len(A2) > 4000:
                continue
            sc = _score(A2)
            if sc > cur_score or random.random() < 0.02:
                B = newB
                M = newM
                cur_score = sc
                if sc > best_local_score:
                    best_local_score = sc
                    best_local = A2[:]
        return best_local, best_local_score

    for (sc0, B0, k, M0) in structures:
        if time.time() > t_refine_end:
            break
        budget = min(5.0, (t_refine_end - time.time()) / max(1, len(structures)))
        A, sc = refine_structure(B0, k, M0, budget)
        consider(A)

    # ---- Phase 3: generic polish on the best found ----
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        remaining = max(0.0, deadline - time.time())
        temp = max(0.02, min(0.5, remaining / 60.0))
        span = max(cand) - min(cand) if cand else 1
        span = max(1, span)
        mags = [1, 2, max(1, span // 200), max(1, span // 30), max(1, span // 5)]
        w = [math.exp(-abs(math.log(m)) / temp) for m in mags]
        tot = sum(w)
        rr = random.random() * tot
        acc = 0.0
        mag = mags[-1]
        for m, ww in zip(mags, w):
            acc += ww
            if rr <= acc:
                mag = m
                break

        if r < 0.75 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * mag
        elif r < 0.92:
            if len(cand) < 3800:
                cand.append(random.randint(min(cand) - span, max(cand) + span))
        else:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.005:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END