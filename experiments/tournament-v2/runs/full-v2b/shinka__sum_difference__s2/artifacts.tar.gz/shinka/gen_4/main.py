# EVOLVE-BLOCK-START
"""Hybrid: Cauchy–Davenport construction + aggressive randomized local search."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build_base(n, modulus):
    """Residue-class base: choose n residues mod `modulus` that are spread out."""
    residues = []
    step = modulus // n if n else 1
    if step < 1:
        step = 1
    for i in range(n):
        r = (i * step) % modulus
        residues.append(r)
    return residues


def _expand_geometric(base, levels, factor):
    """Expand a base set by geometric scaling to multiply differences."""
    result = set(base)
    cur = set(base)
    for _ in range(levels):
        nxt = set()
        for v in cur:
            nxt.add(v * factor)
        result |= nxt
        cur = nxt
    return sorted(result)


def _construct_seeds():
    """Build a pool of promising deterministic seeds."""
    seeds = []
    seeds.append([7, 15, 18, 22, -3, -2])

    # Cauchy–Davenport style bases
    for n in range(4, 10):
        modulus = max(53, n * 7 + 1)
        base = _build_base(n, modulus)
        base = [r - modulus // 2 for r in base]
        for levels in (1, 2, 3):
            for factor in (2, 3, 5):
                expanded = _expand_geometric(base, levels, factor)
                if 2 <= len(expanded) <= 4000:
                    seeds.append(expanded)

    # Symmetric arithmetic + geometric hybrid
    for k in range(3, 8):
        arith = list(range(-k, k + 1))
        for factor in (2, 3, 4):
            hybrid = sorted(set(arith + [v * factor for v in arith]))
            if 2 <= len(hybrid) <= 4000:
                seeds.append(hybrid)

    return seeds


def _random_walk(best, best_score, deadline):
    """Aggressive randomized local search with mixed move types."""
    cur = best[:]
    cur_score = best_score
    span = max(cur) - min(cur) if cur else 1
    if span <= 0:
        span = 1

    while time.time() < deadline:
        cand = cur[:]
        roll = random.random()

        if roll < 0.55 and len(cand) > 0:
            # mutate a random element
            i = random.randrange(len(cand))
            step = max(1, span // max(4, len(cand)))
            cand[i] += random.randint(-step, step)
        elif roll < 0.75 and len(cand) < 4000:
            # insert near an existing element or at the extremes
            if random.random() < 0.5 and cand:
                base = cand[random.randrange(len(cand))]
                cand.append(base + random.randint(-span, span))
            else:
                lo, hi = min(cand), max(cand)
                cand.append(hi + random.randint(1, span))
        elif roll < 0.90 and len(cand) > 5:
            # remove a random element
            i = random.randrange(len(cand))
            cand = cand[:i] + cand[i + 1:]
        else:
            # large jump: shift all or several elements
            if cand:
                shift = random.randint(-span, span)
                cand = [v + shift for v in cand]

        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue

        s = _score(cand)
        if s >= best_score:
            best, best_score = cand[:], s
            cur, cur_score = cand, s
            span = max(best) - min(best)
            if span <= 0:
                span = 1
        elif s >= cur_score or random.random() < 0.05:
            cur, cur_score = cand, s
        else:
            # occasional restart from best
            if random.random() < 0.02:
                cur = best[:]
                cur_score = best_score

    return best, best_score


def solve():
    """Return a list of distinct integers A maximising log|A-A|/log|A+A|."""
    start = time.time()
    total_budget = 110.0

    # Stage 1: deterministic seed construction (fast)
    seeds = _construct_seeds()
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best, best_score = s[:], sc

    # Stage 2: aggressive randomized local search on the best seed
    remaining = total_budget - (time.time() - start)
    if remaining > 0:
        deadline = time.time() + remaining
        best, best_score = _random_walk(best, best_score, deadline)

    return sorted(set(best))
# EVOLVE-BLOCK-END
