# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _beatty(alpha, n, shift=0):
    """Return {floor(k*alpha)+shift : k=1..n} as a sorted list of distinct ints."""
    out = []
    seen = set()
    for k in range(1, n + 1):
        v = int(math.floor(k * alpha)) + shift
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def _beatty_pair(alpha, beta, n):
    """Return {floor(k*alpha)+floor(k*beta) : k=1..n}."""
    out = []
    seen = set()
    for k in range(1, n + 1):
        v = int(math.floor(k * alpha)) + int(math.floor(k * beta))
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110

    # -------- Phase 1: Beatty / Sturmian seed family --------
    alphas = [
        (1 + 5 ** 0.5) / 2,          # golden ratio phi
        2 ** 0.5,                    # sqrt2
        3 ** 0.5,                    # sqrt3
        5 ** 0.5,                    # sqrt5
        math.pi,
        math.e,
        math.pi / 2,
        1 + 2 ** 0.5,                # silver ratio
        (1 + 13 ** 0.5) / 2,
        (1 + 2 ** 0.5) ** 0.5,
        1.2207440846057596,          # plastic-ish
        1.7548776662466927,          # root of x^3-x^2-1
    ]
    ns = [30, 60, 100, 150, 220, 320, 450, 650, 900, 1300]

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    def consider(a):
        nonlocal best, best_score
        if len(a) < 2:
            return
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # single-irrational Beatty seeds
    for alpha in alphas:
        for n in ns:
            if time.time() > deadline:
                break
            consider(_beatty(alpha, n))
    # shifted Beatty seeds (floor(k*alpha) + c*k)
    for alpha in alphas[:6]:
        for c in (-2, -1, 1, 2, 3):
            for n in (150, 300, 600):
                if time.time() > deadline:
                    break
                consider(_beatty(alpha + c, n))
    # two-irrational Beatty sums
    pairs = [
        ((1 + 5 ** 0.5) / 2, 2 ** 0.5),
        ((1 + 5 ** 0.5) / 2, 3 ** 0.5),
        (2 ** 0.5, 3 ** 0.5),
        (math.pi, math.e),
        ((1 + 5 ** 0.5) / 2, math.pi),
        ((1 + 5 ** 0.5) / 2, (1 + 5 ** 0.5) ** 2 / 2),  # phi and phi^2 complementary
    ]
    for (a1, a2) in pairs:
        for n in (100, 200, 400, 700):
            if time.time() > deadline:
                break
            consider(_beatty_pair(a1, a2, n))
    # complementary Beatty pair: floor(k*phi) and floor(k*phi^2)
    phi = (1 + 5 ** 0.5) / 2
    for n in (100, 200, 400, 700, 1000):
        if time.time() > deadline:
            break
        consider(_beatty(phi, n) + _beatty(phi * phi, n))

    # -------- Phase 2: local search / annealing from best Beatty seed --------
    cur = best[:]
    cur_score = best_score
    T = 0.05
    step = 5
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.5 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.8:
            if len(cand) < 2000:
                if cand and random.random() < 0.5:
                    cand.append(max(cand) + random.randint(1, 200))
                else:
                    cand.append(random.randint(-5000, 5000))
        else:
            if len(cand) > 2:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-6)):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]
        if random.random() < 0.01:
            step = max(1, min(5000, int(step * random.uniform(0.8, 1.2))))
        T *= 0.99995
        if T < 1e-6:
            T = 1e-6

    return sorted(set(best))
# EVOLVE-BLOCK-END