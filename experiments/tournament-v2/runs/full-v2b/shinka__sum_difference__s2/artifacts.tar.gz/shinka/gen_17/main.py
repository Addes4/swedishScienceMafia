# EVOLVE-BLOCK-START
"""Sum-collapse search: wide difference set, narrow sum set, with a strict
Pareto polish at the end that only accepts moves that do not increase |A+A|
and do not decrease |A-A|.

Strategy:
  1. Warm-start with dilated Golomb/Sidon constructions (wide |A-A|).
  2. Spend the main budget in a dedicated sum-collapse phase using the
     "target-sum" move: given a target sum s = a_j1 + a_j2, set
     a_k = s - a_j3 so that a_k + a_j3 collides with a_j1 + a_j2.
  3. Final ~10% of the budget: strict Pareto polish. Accept a candidate iff
     (d2 >= d and s2 < s) or (d2 > d and s2 <= s). This monotonically
     tightens the sum set near the plateau without drifting away from the
     large-difference region.
"""
import math
import random
import time


# ---------------------------------------------------------------- scoring
def _diffs_sums(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return diffs, sums


def _score_from(diffs, sums, n):
    if len(sums) < 2 or n < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs, sums = _diffs_sums(a)
    return _score_from(diffs, sums, len(a))


# ---------------------------------------------------------------- warm starts
def greedy_golomb(n, max_val=None):
    marks = [0]
    used = {0}
    c = 1
    while len(marks) < n:
        ok = True
        new_d = []
        for m in marks:
            d = c - m
            if d in used:
                ok = False
                break
            new_d.append(d)
        if ok:
            for d in new_d:
                used.add(d)
                used.add(-d)
            marks.append(c)
            c += 1
        else:
            c += 1
            if max_val is not None and c > max_val:
                break
    return marks


def dilate(base, T, K):
    out = set()
    for k in range(K):
        off = T * k
        for b in base:
            out.add(b + off)
    return sorted(out)


# ---------------------------------------------------------------- moves
def _target_sum_move(a, rng, multi=1):
    """Force sum collisions: a_k = target - a_j3 with target = a_j1 + a_j2."""
    n = len(a)
    if n < 4:
        return a
    cand = a[:]
    for _ in range(multi):
        j1 = rng.randrange(n)
        j2 = rng.randrange(n)
        if j1 == j2:
            continue
        target = a[j1] + a[j2]
        j3 = rng.randrange(n)
        new_val = target - a[j3]
        k = rng.randrange(n)
        if new_val == cand[k]:
            continue
        if new_val in cand and new_val != cand[k]:
            new_val += rng.choice([-1, 1])
            if new_val in cand:
                continue
        cand[k] = new_val
    return cand


def _difference_move(a, rng):
    """Push an element far out to expand the difference set."""
    n = len(a)
    if n < 2:
        return a
    cand = a[:]
    lo = min(cand)
    hi = max(cand)
    span = max(1, hi - lo)
    i = rng.randrange(n)
    cand[i] = hi + rng.randint(1, max(2, span))
    return cand


def _perturb_move(a, rng):
    """Small local perturbation."""
    n = len(a)
    if n < 2:
        return a
    cand = a[:]
    i = rng.randrange(n)
    lo = min(cand)
    hi = max(cand)
    span = max(1, hi - lo)
    cand[i] += rng.randint(-max(1, span // 10), max(1, span // 10))
    return cand


def _dedup(a):
    return sorted(set(a))


# ---------------------------------------------------------------- main
def solve():
    rng = random.Random(20240607)
    deadline = time.time() + 115

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # ---------- Phase 1: construction warm starts (~10% budget) ----------
    phase1_end = time.time() + 0.10 * 115
    for gn in [4, 5, 6, 7, 8, 10, 12]:
        if time.time() > phase1_end:
            break
        G = greedy_golomb(gn)
        for K in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20]:
            for T in [3, 5, 7, 9, 11, 13, 17, 19, 23, 29, 31, 37, 41, 47, 53, 61]:
                A = dilate(G, T, K)
                if len(A) < 2 or len(A) > 4000:
                    continue
                s = _score(A)
                if s > best_score:
                    best, best_score = A[:], s

    # ---------- Phase 2: sum-collapse hill-climb (~55% budget) ----------
    phase2_end = time.time() + 0.55 * 115
    cur = best[:]
    cur_diffs, cur_sums = _diffs_sums(cur)
    cur_score = _score_from(cur_diffs, cur_sums, len(cur))
    temperature = 0.02

    while time.time() < phase2_end:
        r = rng.random()
        if r < 0.70:
            multi = 1 if rng.random() < 0.7 else 2
            cand = _target_sum_move(cur, rng, multi=multi)
        elif r < 0.85:
            cand = _difference_move(cur, rng)
        elif r < 0.95:
            cand = _perturb_move(cur, rng)
        else:
            cand = cur[:]  # identity / shift

        cand = _dedup(cand)
        if len(cand) < 2 or len(cand) > 4000:
            continue

        cd, cs = _diffs_sums(cand)
        s = _score_from(cd, cs, len(cand))

        if s > cur_score:
            cur, cur_diffs, cur_sums, cur_score = cand, cd, cs, s
            if s > best_score:
                best, best_score = cand[:], s
        elif rng.random() < temperature:
            cur, cur_diffs, cur_sums, cur_score = cand, cd, cs, s

        temperature *= 0.99995
        if temperature < 0.005:
            temperature = 0.02

        if rng.random() < 0.001:
            cur = best[:]
            cur_diffs, cur_sums = _diffs_sums(cur)
            cur_score = _score_from(cur_diffs, cur_sums, len(cur))

    # ---------- Phase 3: strict Pareto polish (~10% budget) ----------
    # Accept iff the move does not decrease |A-A| and strictly decreases |A+A|,
    # or strictly increases |A-A| without increasing |A+A|.
    # This monotonically tightens the sum set near the plateau.
    pareto_end = time.time() + 0.10 * 115
    cur = best[:]
    cd, cs = _diffs_sums(cur)
    d, s = len(cd), len(cs)
    n = len(cur)
    cur_score = _score_from(cd, cs, n)

    while time.time() < pareto_end:
        r = rng.random()
        if r < 0.80:
            cand = _target_sum_move(cur, rng, multi=1)
        elif r < 0.90:
            cand = _target_sum_move(cur, rng, multi=2)
        else:
            cand = _perturb_move(cur, rng)

        cand = _dedup(cand)
        if len(cand) < 2 or len(cand) > 4000:
            continue

        cd2, cs2 = _diffs_sums(cand)
        d2, s2 = len(cd2), len(cs2)
        n2 = len(cand)

        # strict Pareto filter (do not shrink |A|)
        pareto_ok = (
            n2 >= n
            and ((d2 >= d and s2 < s) or (d2 > d and s2 <= s))
        )
        if pareto_ok:
            cur, cd, cs, d, s, n = cand, cd2, cs2, d2, s2, n2
            cur_score = _score_from(cd, cs, n)
            if cur_score > best_score:
                best, best_score = cand[:], cur_score
        elif rng.random() < 0.02:
            # tiny escape probability to avoid getting stuck (does not
            # update the Pareto reference d,s,n, only the working set)
            cur = cand
            cd, cs = cd2, cs2
            d, s, n = d2, s2, n2
            cur_score = _score_from(cd, cs, n)

    return sorted(set(best))
# EVOLVE-BLOCK-END