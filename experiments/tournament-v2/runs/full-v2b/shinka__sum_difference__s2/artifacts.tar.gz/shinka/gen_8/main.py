# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    def init_golomb(n, deadline):
        # Greedy Golomb ruler: all pairwise differences distinct.
        a = [0]
        diffs = set()
        while len(a) < n:
            if time.time() > deadline:
                break
            x = a[-1] + 1
            while True:
                new_diffs = set()
                ok = True
                for y in a:
                    d = x - y
                    if d in diffs or d in new_diffs:
                        ok = False
                        break
                    new_diffs.add(d)
                if ok:
                    break
                x += 1
            diffs |= new_diffs
            a.append(x)
        # center around 0
        if a:
            m = (a[0] + a[-1]) // 2
            a = [x - m for x in a]
        return a

    def init_geom(n):
        return [2**i for i in range(n)]

    def init_random(n):
        return random.sample(range(-1000, 1000), n)

    best_set = None
    best_score = -1.0
    deadline = time.time() + 100

    # Golomb rulers: maximize |A-A| while keeping |A+A| moderate.
    for n in [20, 40, 60, 80, 100, 120, 150, 200, 300]:
        if time.time() > deadline:
            break
        try:
            a = init_golomb(n, deadline)
        except Exception:
            continue
        if len(a) >= 2:
            s = _score(a)
            if s > best_score:
                best_score = s
                best_set = a[:]

    for init_func, ns in [(init_geom, [10, 20, 30, 40, 50]),
                          (init_random, [30, 50, 80, 120, 200])]:
        for n in ns:
            if time.time() > deadline:
                break
            try:
                a = init_func(n)
            except Exception:
                continue
            s = _score(a)
            if s > best_score:
                best_score = s
                best_set = a[:]

    if best_set is None:
        best_set = [7, 15, 18, 22, -3, -2]
        best_score = _score(best_set)

    cur = best_set[:]
    cur_score = best_score
    T = 0.1
    step = 10
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.5 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.8:
            if len(cand) < 1000:
                # bias additions toward extending the range (larger diffs)
                if cand and random.random() < 0.5:
                    cand.append(max(cand) + random.randint(1, 50))
                else:
                    cand.append(random.randint(-1000, 1000))
        else:
            if len(cand) > 2:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < math.exp((s - cur_score) / T):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best_set = cand[:]
        if random.random() < 0.01:
            step = max(1, min(1000, int(step * random.uniform(0.8, 1.2))))
        T *= 0.9999
        if T < 1e-6:
            T = 1e-6

    return sorted(set(best_set))
# EVOLVE-BLOCK-END