# EVOLVE-BLOCK-START
"""Improved solver: Sidon base + geometric dilation + asymmetric shift.

Key idea: maximize log|A-A|/log|A+A| by building a set whose difference set
grows multiplicatively under dilation while the sum set grows only additively.
"""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _stats(a):
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    return len(diffs), len(sums)


def _score_fast(a, nd, ns, n):
    if ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def greedy_bh_base(n, max_candidates=400):
    """Greedy B_2-like base: add candidates that add many new differences but
    few new sums.  Start from {0, 1}."""
    marks = [0, 1]
    diffs = {0, 1, -1}
    sums = {0, 1, 2}
    last = 1
    while len(marks) < n:
        best_c = None
        best_cost = None
        for c in range(last + 1, last + 1 + max_candidates):
            new_d = set()
            for m in marks:
                new_d.add(c - m)
                new_d.add(m - c)
            nd = len(new_d - diffs)
            new_s = set()
            for m in marks:
                new_s.add(c + m)
            ns = len(new_s - sums)
            if nd == 0:
                continue
            cost = ns / nd
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_c = c
        if best_c is None:
            best_c = last + 1
        for m in marks:
            diffs.add(best_c - m)
            diffs.add(m - best_c)
            sums.add(best_c + m)
        marks.append(best_c)
        last = best_c
    return marks


def geometric_dilate(base, levels, factor):
    """Multiply base by powers of `factor` and union."""
    result = set()
    cur = list(base)
    for _ in range(levels + 1):
        for v in cur:
            result.add(v)
        cur = [v * factor for v in cur]
    return sorted(result)


def asymmetric_shift(base, shift):
    """Shift part of the set to make A-A larger than A+A."""
    return sorted(set(base) | {x + shift for x in base})


def local_search(a, deadline, best_score):
    """Fast local search using incremental scoring."""
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return a, 0.0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    nd, ns = len(diffs), len(sums)
    cur = _score_fast(a, nd, ns, n)
    best = a[:]
    bs = cur
    if bs > best_score:
        best_score = bs

    while time.time() < deadline:
        move = random.random()
        if move < 0.55 and a:
            i = random.randrange(len(a))
            delta = random.randint(-8, 8)
            if delta == 0:
                continue
            old = a[i]
            new = old + delta
            if new in a:
                continue
            # incremental diff/sum update
            new_diffs = set()
            new_sums = set()
            for j, x in enumerate(a):
                if j == i:
                    continue
                new_diffs.add(new - x)
                new_diffs.add(x - new)
                new_sums.add(new + x)
            old_diffs_used = set()
            for j, x in enumerate(a):
                if j == i:
                    continue
                old_diffs_used.add(old - x)
                old_diffs_used.add(x - old)
            # count removed diffs (those only from old element)
            removed_d = 0
            for d in old_diffs_used:
                if d not in new_diffs:
                    # check if still present from other pairs
                    present = False
                    for j, x in enumerate(a):
                        if j == i:
                            continue
                        for k, y in enumerate(a):
                            if k == i:
                                continue
                            if x - y == d:
                                present = True
                                break
                        if present:
                            break
                    if not present:
                        removed_d += 1
            added_d = len(new_diffs - diffs)
            removed_s = 0
            old_sums_used = set()
            for j, x in enumerate(a):
                if j == i:
                    continue
                old_sums_used.add(old + x)
            for s in old_sums_used:
                if s not in new_sums:
                    present = False
                    for j, x in enumerate(a):
                        if j == i:
                            continue
                        for k, y in enumerate(a):
                            if k == i:
                                continue
                            if x + y == s:
                                present = True
                                break
                        if present:
                            break
                    if not present:
                        removed_s += 1
            added_s = len(new_sums - sums)
            cand_nd = nd + added_d - removed_d
            cand_ns = ns + added_s - removed_s
            if cand_ns < 2:
                continue
            cand = a[:]
            cand[i] = new
            s = _score_fast(cand, cand_nd, cand_ns, n)
            if s > cur:
                a = sorted(cand)
                diffs = set()
                for x in a:
                    for y in a:
                        diffs.add(x - y)
                sums = set()
                for x in a:
                    for y in y_range(a):
                        sums.add(x + y)
                sums = set()
                for x in a:
                    for y in a:
                        sums.add(x + y)
                nd, ns = len(diffs), len(sums)
                cur = s
                if s > bs:
                    best = a[:]
                    bs = s
        elif move < 0.85 and len(a) < 4000:
            # add element
            lo = min(a)
            hi = max(a)
            span = max(hi - lo, 1)
            new = random.randint(lo - span, hi + span)
            if new in a:
                continue
            cand = sorted(set(a) | {new})
            s = _score(cand)
            if s > cur:
                a = cand
                cur = s
                if s > bs:
                    best = a[:]
                    bs = s
        elif move < 0.95 and len(a) > 3:
            i = random.randrange(len(a))
            cand = a[:i] + a[i + 1:]
            s = _score(cand)
            if s > cur:
                a = cand
                cur = s
                if s > bs:
                    best = a[:]
                    bs = s
        else:
            # global shift doesn't change score, but try reflection of subset
            if len(a) >= 4:
                k = random.randint(1, len(a) - 1)
                lo = min(a)
                hi = max(a)
                center = (lo + hi) // 2
                cand = sorted(set(a[:k]) | {2 * center - x for x in a[k:]})
                if len(cand) >= 2:
                    s = _score(cand)
                    if s > cur:
                        a = cand
                        cur = s
                        if s > bs:
                            best = a[:]
                            bs = s
    return best, bs


def y_range(a):
    return a


def solve():
    """Return list maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Strategy 1: Sidon-like base + geometric dilation
    bases = []
    for n in [6, 8, 10, 12, 14, 16, 20, 24]:
        if time.time() > deadline:
            break
        b = greedy_bh_base(n, max_candidates=300)
        bases.append(b)

    for base in bases:
        if time.time() > deadline:
            break
        for levels in [2, 3, 4, 5, 6, 7, 8]:
            for factor in [2, 3]:
                cand = geometric_dilate(base, levels, factor)
                if len(cand) < 2 or len(cand) > 4000:
                    continue
                s = _score(cand)
                if s > best_score:
                    best, best_score = cand[:], s
                # also try with asymmetric shift
                span = max(cand) - min(cand)
                for sh in [span // 2, span, span * 2]:
                    cand2 = asymmetric_shift(cand, sh)
                    if len(cand2) > 4000:
                        continue
                    s2 = _score(cand2)
                    if s2 > best_score:
                        best, best_score = cand2[:], s2

    # Strategy 2: multi-cluster construction
    # Place several translated copies of a Sidon base far apart so that
    # cross-cluster differences are all distinct.
    for n in [5, 6, 8, 10, 12]:
        if time.time() > deadline:
            break
        base = greedy_bh_base(n, max_candidates=200)
        bspan = max(base) - min(base)
        for num_clusters in [2, 3, 4, 5, 6, 8]:
            for gap_mult in [2, 4, 8, 16, 32]:
                gap = max(bspan * gap_mult, 10)
                cand = []
                for c in range(num_clusters):
                    for v in base:
                        cand.append(v + c * gap)
                cand = sorted(set(cand))
                if len(cand) > 4000 or len(cand) < 2:
                    continue
                s = _score(cand)
                if s > best_score:
                    best, best_score = cand[:], s

    # Strategy 3: "two-scale" — small cluster + geometric dilation
    for n in [5, 6, 8, 10, 12, 16]:
        if time.time() > deadline:
            break
        base = greedy_bh_base(n, max_candidates=200)
        for factor in [2, 3, 4]:
            for levels in [3, 4, 5, 6]:
                cand = geometric_dilate(base, levels, factor)
                if len(cand) > 4000 or len(cand) < 2:
                    continue
                # add a translated copy
                span = max(cand) - min(cand)
                for sh in [span + 1, 2 * span + 1, 3 * span + 1]:
                    cand2 = sorted(set(cand) | {x + sh for x in cand})
                    if len(cand2) > 4000:
                        continue
                    s = _score(cand2)
                    if s > best_score:
                        best, best_score = cand2[:], s

    # Strategy 4: local search polish on the best found
    while time.time() < deadline:
        b, bs = local_search(best, min(deadline, time.time() + 6), best_score)
        if bs > best_score:
            best, best_score = b[:], bs
        else:
            break

    return sorted(set(best))
# EVOLVE-BLOCK-END
