# EVOLVE-BLOCK-START
"""Coset-based construction: A = union of arithmetic progressions with a shared
modulus, so that sums collapse heavily while differences stay rich.

Key idea: A = { m*k + r : k in [0,K), r in R } for small modulus m and residue set R.
Sums of pairs land in 2R (mod m) collapsed windows; differences fill a wide range.
We optimize (m, R, K) with bitset-based fast metric evaluation and local search."""
import math
import random
import time


def _score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _bitset_metrics(vals):
    """Compute |diff| and |sum| using Python big-int bitsets.
    vals must be integers (possibly negative). Shift to non-negative."""
    if len(vals) < 2:
        return 0, 0
    mn = min(vals)
    mx = max(vals)
    span = mx - mn
    # difference bitset: index = d + span  (d in [-span, span])
    diff_bits = 0
    sum_bits = 0
    # sums range [2*mn, 2*mx], size 2*span+1
    s_off = 2 * mn
    # build bitsets via shifts
    # For each value v, diff |= (mask << (v - mn)) >> ... we do it pairwise but
    # using the trick: for each v, OR the set of (v - u + span).
    # We'll just do O(n^2) but with fast int ops; n is small (<= few hundred).
    for i, v in enumerate(vals):
        # differences v - u for all u
        for u in vals:
            diff_bits |= (1 << (v - u + span))
            sum_bits |= (1 << (v + u - s_off))
    return bin(diff_bits).count("1"), bin(sum_bits).count("1")


def _fast_metrics_vals(vals):
    """Return (|diff|, |sum|) using sets (fallback, robust)."""
    n = len(vals)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = vals[i]
        for j in range(i, n):
            aj = vals[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _eval_coset(m, R, K):
    """Build A = { m*k + r : k in [0,K), r in R } and compute metrics."""
    vals = []
    for k in range(K):
        base = m * k
        for r in R:
            vals.append(base + r)
    vals = list(set(vals))
    if len(vals) < 2:
        return 0, 0, vals
    d, s = _fast_metrics_vals(vals)
    return d, s, vals


def _score_coset(m, R, K):
    d, s, vals = _eval_coset(m, R, K)
    if s <= 1 or len(vals) < 2:
        return -1e18, vals
    return math.log(d) / math.log(s) + (1 - 1 / len(vals)) / 100, vals


def _greedy_residues(m, T, K, time_limit=5.0):
    """Greedily add residues to R to maximize score."""
    deadline = time.time() + time_limit
    R = [0]
    best_score, _ = _score_coset(m, R, K)
    while len(R) < T and time.time() < deadline:
        best_r = None
        best_sc = best_score
        for r in range(m):
            if r in R:
                continue
            cand = R + [r]
            sc, _ = _score_coset(m, cand, K)
            if sc > best_sc:
                best_sc = sc
                best_r = r
            if time.time() > deadline:
                break
        if best_r is None:
            break
        R.append(best_r)
        best_score = best_sc
    return R, best_score


def _local_search_R(m, R, K, time_limit, best_global):
    """Local search on R: swap, add, remove residues."""
    deadline = time.time() + time_limit
    R = list(set(R))
    sc, _ = _score_coset(m, R, K)
    best_R = R[:]
    best_sc = sc
    while time.time() < deadline:
        cand = R[:]
        op = random.random()
        if op < 0.4 and len(cand) < m:
            # add
            r = random.randrange(m)
            if r not in cand:
                cand.append(r)
        elif op < 0.7 and len(cand) > 2:
            # remove
            cand.pop(random.randrange(len(cand)))
        else:
            # swap
            if cand:
                i = random.randrange(len(cand))
                r = random.randrange(m)
                if r not in cand:
                    cand[i] = r
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc2, _ = _score_coset(m, cand, K)
        if sc2 > sc or random.random() < 0.02:
            R = cand
            sc = sc2
            if sc2 > best_sc:
                best_sc = sc2
                best_R = cand[:]
                if sc2 > best_global[0]:
                    best_global[0] = sc2
                    best_global[1] = (m, cand[:], K)
    return best_R, best_sc


def solve():
    """Return list of distinct integers maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best_score = -1e18
    best_vals = None

    # Phase 1: grid search over (m, T, K) with greedy residue selection
    # Small m -> heavy sum collapse; K controls span.
    grid = []
    for m in [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 24, 30]:
        for K in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20]:
            T = m  # full residue set first
            grid.append((m, K, T))
    # Also try dense smaller T
    for m in [5, 6, 7, 8, 10, 12, 15, 20, 25, 30, 40]:
        for K in [3, 5, 8, 12, 20, 30]:
            for T in [max(2, m // 2), max(2, m - 1), m]:
                grid.append((m, K, T))

    random.shuffle(grid)
    phase1_end = time.time() + 40
    tested = 0
    for (m, K, T) in grid:
        if time.time() > phase1_end:
            break
        try:
            R, sc = _greedy_residues(m, T, K, time_limit=min(0.8, max(0.05, (phase1_end - time.time()) / 20)))
            if sc > best_score:
                _, vals = _score_coset(m, R, K)
                best_score = sc
                best_vals = vals[:]
            tested += 1
        except Exception:
            continue

    if best_vals is None:
        best_vals = [0, 1, 3, 7, 12]
        best_score = _score_set(best_vals)

    # Phase 2: local search on best residues
    best_global = [best_score, None]
    # Recover (m, R, K) from best by trying candidate grids again briefly
    # Instead: run local search on several promising (m, K) with random R seeds
    phase2_end = time.time() + 40
    seeds = []
    for m in [4, 5, 6, 7, 8, 10, 12, 15, 20, 30]:
        for K in [4, 6, 8, 12, 20]:
            seeds.append((m, K))
    random.shuffle(seeds)
    for (m, K) in seeds:
        if time.time() > phase2_end:
            break
        # random R seed
        T = random.randint(2, m)
        R = random.sample(range(m), T)
        try:
            R2, sc = _local_search_R(m, R, K,
                                     time_limit=min(3.0, max(0.2, (phase2_end - time.time()) / 10)),
                                     best_global=best_global)
            if sc > best_score:
                _, vals = _score_coset(m, R2, K)
                best_score = sc
                best_vals = vals[:]
        except Exception:
            continue
    if best_global[1] is not None:
        m, R, K = best_global[1]
        _, vals = _score_coset(m, R, K)
        if _score_set(vals) > best_score:
            best_score = _score_set(vals)
            best_vals = vals[:]

    # Phase 3: generic polish on best_vals
    cur = list(set(best_vals))
    cur_score = _score_set(cur)
    if cur_score > best_score:
        best_score = cur_score
        best_vals = cur[:]
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        remaining = max(0.0, deadline - time.time())
        temp = max(0.05, min(1.0, remaining / 30.0))
        span = max(cand) - min(cand) if cand else 1
        span = max(1, span)
        mags = [1, 2, max(1, span // 100), max(1, span // 20), max(1, span // 4)]
        w = [math.exp(-abs(math.log(mg)) / temp) for mg in mags]
        tot = sum(w)
        rr = random.random() * tot
        acc = 0.0
        mag = mags[-1]
        for mg, ww in zip(mags, w):
            acc += ww
            if rr <= acc:
                mag = mg
                break
        if r < 0.75 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * mag
        elif r < 0.9:
            if len(cand) < 4000:
                cand.append(random.randint(min(cand) - span, max(cand) + span))
        else:
            if len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score_set(cand)
        if s > cur_score or random.random() < 0.01:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best_vals = cand[:]

    return sorted(set(best_vals))
# EVOLVE-BLOCK-END