# EVOLVE-BLOCK-START
"""Hybrid: Beatty seeding + dense-core/separated-tail refinement.

Combine the Beatty/Sturmian seed family (good for |A-A|/|A+A|) with the
core+tail decomposition and core-only local search (good for squeezing |A+A|
while preserving |A-A|).
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _metrics(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score_from(d, s, n):
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


# ---------------------------------------------------------------------------
# Beatty / Sturmian seeds
# ---------------------------------------------------------------------------

def _beatty(alpha, n, shift=0):
    out = []
    seen = set()
    for k in range(1, n + 1):
        v = int(math.floor(k * alpha)) + shift
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def _beatty_pair(alpha, beta, n):
    out = []
    seen = set()
    for k in range(1, n + 1):
        v = int(math.floor(k * alpha)) + int(math.floor(k * beta))
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


# ---------------------------------------------------------------------------
# Core/tail helpers (from the core+tail program)
# ---------------------------------------------------------------------------

def _combine(core, tail):
    return sorted(set(core) | set(tail))


def _split_core_tail(a, core_size):
    a = sorted(set(a))
    if core_size >= len(a):
        return a[:], []
    best_i, best_span = 0, float("inf")
    for i in range(len(a) - core_size + 1):
        span = a[i + core_size - 1] - a[i]
        if span < best_span:
            best_span = span
            best_i = i
    core = a[best_i:best_i + core_size]
    tail = a[:best_i] + a[best_i + core_size:]
    return core, tail


def _core_refine(core, tail, deadline):
    core = list(set(core))
    tail = list(set(tail))
    combined = _combine(core, tail)
    d, s = _metrics(combined)
    best_score = _score_from(d, s, len(combined))
    best_core = core[:]
    best_d, best_s = d, s

    cur_core = core[:]
    cur_d, cur_s = d, s
    cur_score = best_score

    t0 = time.time()
    total = max(1e-3, deadline - t0)

    while time.time() < deadline:
        cand_core = cur_core[:]
        if not cand_core:
            break
        frac = max(0.0, min(1.0, (deadline - time.time()) / total))
        temp = max(0.03, frac)

        op = random.random()
        if op < 0.55:
            i = random.randrange(len(cand_core))
            span = max(cand_core) - min(cand_core) if len(cand_core) > 1 else 1
            span = max(1, span)
            mags = [1, 2, max(1, span // 50), max(1, span // 10), max(1, span // 3)]
            w = [math.exp(-abs(math.log(m)) / temp) for m in mags]
            tot = sum(w)
            r = random.random() * tot
            acc = 0.0
            mag = mags[-1]
            for m, ww in zip(mags, w):
                acc += ww
                if r <= acc:
                    mag = m
                    break
            cand_core[i] += random.choice([-1, 1]) * mag
        elif op < 0.8:
            if len(cand_core) >= 2:
                i = random.randrange(len(cand_core))
                others = [cand_core[j] for j in range(len(cand_core)) if j != i]
                others += tail
                if len(others) >= 2:
                    j1 = random.randrange(len(others))
                    j2 = random.randrange(len(others))
                    target = others[j1] + others[j2]
                    k = random.randrange(len(others))
                    new_val = target - others[k]
                    cand_core[i] = new_val
        else:
            if len(cand_core) > 2 and random.random() < 0.4:
                i = random.randrange(len(cand_core))
                cand_core.pop(i)
            else:
                span = max(cand_core) - min(cand_core) if len(cand_core) > 1 else 1
                span = max(1, span)
                lo = min(cand_core) - span
                hi = max(cand_core) + span
                cand_core.append(random.randint(lo, hi))

        cand_core = list(set(cand_core))
        if len(cand_core) < 1:
            continue
        combined = _combine(cand_core, tail)
        if len(combined) < 2:
            continue
        d, s = _metrics(combined)
        sc = _score_from(d, s, len(combined))
        if sc > cur_score or random.random() < 0.05 * temp:
            cur_core = cand_core
            cur_score = sc
            cur_d, cur_s = d, s
            if sc > best_score:
                best_score = sc
                best_core = cand_core[:]
                best_d, best_s = d, s

    return best_core, tail, best_score


# ---------------------------------------------------------------------------
# Main solve
# ---------------------------------------------------------------------------

def solve():
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2:
            return
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # -------- Phase 1: Beatty / Sturmian seed family --------
    alphas = [
        (1 + 5 ** 0.5) / 2,
        2 ** 0.5,
        3 ** 0.5,
        5 ** 0.5,
        math.pi,
        math.e,
        math.pi / 2,
        1 + 2 ** 0.5,
        (1 + 13 ** 0.5) / 2,
        (1 + 2 ** 0.5) ** 0.5,
        1.2207440846057596,
        1.7548776662466927,
    ]
    ns = [30, 60, 100, 150, 220, 320, 450, 650, 900, 1300]

    for alpha in alphas:
        for n in ns:
            if time.time() > deadline * 0.20:
                break
            consider(_beatty(alpha, n))
    for alpha in alphas[:6]:
        for c in (-2, -1, 1, 2, 3):
            for n in (150, 300, 600):
                if time.time() > deadline * 0.20:
                    break
                consider(_beatty(alpha + c, n))
    pairs = [
        ((1 + 5 ** 0.5) / 2, 2 ** 0.5),
        ((1 + 5 ** 0.5) / 2, 3 ** 0.5),
        (2 ** 0.5, 3 ** 0.5),
        (math.pi, math.e),
        ((1 + 5 ** 0.5) / 2, math.pi),
        ((1 + 5 ** 0.5) / 2, (1 + 5 ** 0.5) ** 2 / 2),
    ]
    for (a1, a2) in pairs:
        for n in (100, 200, 400, 700):
            if time.time() > deadline * 0.20:
                break
            consider(_beatty_pair(a1, a2, n))
    phi = (1 + 5 ** 0.5) / 2
    for n in (100, 200, 400, 700, 1000):
        if time.time() > deadline * 0.20:
            break
        consider(_beatty(phi, n) + _beatty(phi * phi, n))

    # -------- Phase 1b: quick greedy polish of the Beatty best --------
    cur = best[:]
    cur_score = best_score
    T = 0.05
    step = 5
    quick_deadline = time.time() + 8.0
    while time.time() < quick_deadline and time.time() < deadline * 0.30:
        cand = cur[:]
        r = random.random()
        if r < 0.6 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.85:
            if len(cand) < 2000:
                if cand and random.random() < 0.5:
                    cand.append(max(cand) + random.randint(1, 200))
                else:
                    cand.append(random.randint(-5000, 5000))
        else:
            if len(cand) > 2:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-6)):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]
        if random.random() < 0.02:
            step = max(1, min(5000, int(step * random.uniform(0.8, 1.2))))
        T *= 0.99995
        if T < 1e-6:
            T = 1e-6

    # -------- Phase 2: core/tail refinement of best --------
    cur_best = best[:]
    cur_best_score = best_score

    while time.time() < deadline * 0.92:
        remaining = deadline - time.time()
        if remaining < 2:
            break

        n = len(cur_best)
        if n < 4:
            core_size = max(1, n - 1)
        else:
            core_size = random.choice([
                max(2, n // 4), max(3, n // 3), max(4, n // 2),
                max(5, (2 * n) // 3), max(6, (3 * n) // 4),
            ])
            core_size = min(core_size, n - 1)
        core, tail = _split_core_tail(cur_best, core_size)
        if not core:
            core = cur_best[:1]
        time_slice = min(remaining * 0.4, 6.0)
        new_core, tail, sc = _core_refine(core, tail, time.time() + time_slice)
        improved = _combine(new_core, tail)
        s = _score(improved)
        if s > cur_best_score:
            cur_best_score = s
            cur_best = sorted(set(improved))
            if s > best_score:
                best_score = s
                best = cur_best[:]

        # Occasionally restart from a fresh Beatty seed
        if random.random() < 0.25:
            alpha = random.choice(alphas)
            n_seed = random.choice([150, 300, 600, 900])
            cur_best = _beatty(alpha, n_seed)
            cur_best_score = _score(cur_best)
            if cur_best_score > best_score:
                best_score = cur_best_score
                best = cur_best[:]

    # -------- Phase 3: final generic polish --------
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        remaining = max(0.0, deadline - time.time())
        temp = max(0.05, min(1.0, remaining / 30.0))
        span = max(cand) - min(cand) if cand else 1
        span = max(1, span)
        mags = [1, 2, max(1, span // 100), max(1, span // 20), max(1, span // 4)]
        w = [math.exp(-abs(math.log(m)) / temp) for m in mags]
        tot = sum(w)
        rr = random.random() * tot
        acc = 0.0
        mag = mags[-1]
        for m, ww in zip(mags, w):
            acc += ww
            if rr <= acc:
                mag = m
                break

        if r < 0.7 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * mag
        elif r < 0.9:
            if len(cand) < 2000:
                cand.append(random.randint(min(cand) - span, max(cand) + span))
        else:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.01:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END