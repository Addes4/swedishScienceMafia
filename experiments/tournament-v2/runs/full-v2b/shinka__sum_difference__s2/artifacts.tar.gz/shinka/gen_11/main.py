# EVOLVE-BLOCK-START
"""Construct sets with large difference sets and small sum sets using Sidon sets,
Golomb rulers, and structured subset selection. This is a fundamentally different
approach from random local search: it builds large structured sets analytically
and then selects the best subset via efficient scoring."""

import math
import random
import time
from bisect import bisect_left


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _fast_metrics(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def greedy_sidon(n, max_val=10**9, time_limit=10.0):
    """Build a Sidon set greedily: each new element must not create any
    duplicate sum with existing elements. This maximizes |A-A|."""
    deadline = time.time() + time_limit
    a = [0]
    sums = {0}
    diffs = {0}
    while len(a) < n and time.time() < deadline:
        start = a[-1] + 1
        # try candidates
        found = False
        x = start
        # Use a smarter search: we need x + y not in sums for all y in a,
        # and 2x not in sums.
        # We can iterate over possible x, but for large n this is slow.
        # We use a randomized search with a limit.
        attempts = 0
        while attempts < 200000 and time.time() < deadline:
            x = start + attempts
            # check only against sums
            ok = True
            for y in a:
                if x + y in sums:
                    ok = False
                    break
            if ok and 2 * x in sums:
                ok = False
            if ok:
                break
            attempts += 1
        if not ok:
            # fallback: random large value
            x = random.randint(start, start + 10**6)
            # still check
            while any(x + y in sums for y in a) or 2 * x in sums:
                x += 1
        a.append(x)
        for y in a:
            sums.add(x + y)
            diffs.add(x - y)
            diffs.add(y - x)
    return a


def greedy_golomb(n, time_limit=10.0):
    """Build a Golomb ruler: all pairwise differences distinct.
    This maximizes |A-A| = n(n-1)+1."""
    deadline = time.time() + time_limit
    a = [0]
    diffs = {0}
    while len(a) < n and time.time() < deadline:
        start = a[-1] + 1
        found = False
        x = start
        attempts = 0
        while attempts < 200000 and time.time() < deadline:
            x = start + attempts
            ok = True
            for y in a:
                d = x - y
                if d in diffs or -d in diffs:
                    ok = False
                    break
            if ok:
                break
            attempts += 1
        if not ok:
            x = random.randint(start, start + 10**6)
            while any((x - y) in diffs or (y - x) in diffs for y in a):
                x += 1
        a.append(x)
        for y in a:
            diffs.add(x - y)
            diffs.add(y - x)
    return a


def scale_translate(a, scale, offset):
    return [scale * x + offset for x in a]


def select_best_subset(a, target_n, time_limit=5.0):
    """Given a large structured set a, select a subset of size target_n
    that maximizes the score. Uses a greedy removal strategy."""
    deadline = time.time() + time_limit
    cur = list(a)
    if len(cur) <= target_n:
        return cur
    # remove elements one by one, choosing the removal that hurts least
    while len(cur) > target_n and time.time() < deadline:
        best_rem = None
        best_score = -1e18
        # sample a few removal candidates
        indices = list(range(len(cur)))
        random.shuffle(indices)
        for idx in indices[:min(len(indices), 30)]:
            cand = cur[:idx] + cur[idx+1:]
            sc = _score(cand)
            if sc > best_score:
                best_score = sc
                best_rem = idx
        if best_rem is None:
            break
        cur.pop(best_rem)
    return cur


def local_improve(a, time_limit=5.0):
    """Local search: try to reduce sum set by shifting elements to create
    sum collisions, while keeping difference set large."""
    deadline = time.time() + time_limit
    a = list(set(a))
    best = a[:]
    best_score = _score(best)
    cur = a[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.6 and len(cand) >= 2:
            # shift one element to create a sum collision
            i = random.randrange(len(cand))
            others = [cand[j] for j in range(len(cand)) if j != i]
            if len(others) >= 2:
                j1 = random.randrange(len(others))
                j2 = random.randrange(len(others))
                k = random.randrange(len(others))
                target = others[j1] + others[j2]
                new_val = target - others[k]
                cand[i] = new_val
        elif r < 0.85:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-2, 2)
        else:
            if len(cand) < 500:
                lo = min(cand)
                hi = max(cand)
                cand.append(random.randint(lo, hi))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc > cur_score or random.random() < 0.05:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = cand[:]
    return best


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110
    best_set = None
    best_score = -1e18

    # Phase 1: Build structured sets (Sidon / Golomb rulers)
    structured_sets = []
    for n in [20, 30, 40, 50, 60, 80, 100]:
        if time.time() > deadline * 0.3:
            break
        try:
            s = greedy_sidon(n, time_limit=2.0)
            structured_sets.append(s)
        except Exception:
            pass
        try:
            g = greedy_golomb(n, time_limit=2.0)
            structured_sets.append(g)
        except Exception:
            pass

    # Phase 2: Try scaling and translating structured sets
    for base in structured_sets:
        if time.time() > deadline * 0.4:
            break
        for scale in [1, 2, 3, 5]:
            for offset in [0, 1, -1, 100, -100]:
                a = scale_translate(base, scale, offset)
                # deduplicate
                a = list(set(a))
                if len(a) < 2:
                    continue
                sc = _score(a)
                if sc > best_score:
                    best_score = sc
                    best_set = a[:]

    # Phase 3: Subset selection from larger structured sets
    if structured_sets:
        largest = max(structured_sets, key=len)
        for target_n in [20, 30, 40, 50, 60, 80, 100, 150, 200]:
            if time.time() > deadline * 0.6:
                break
            try:
                sub = select_best_subset(largest, target_n, time_limit=2.0)
                sc = _score(sub)
                if sc > best_score:
                    best_score = sc
                    best_set = sub[:]
            except Exception:
                pass

    # Phase 4: Local improvement on the best set
    if best_set is None:
        best_set = [0, 1, 3, 7, 12, 20]
        best_score = _score(best_set)

    cur = best_set[:]
    while time.time() < deadline * 0.95:
        try:
            improved = local_improve(cur, time_limit=min(10.0, deadline * 0.95 - time.time()))
            sc = _score(improved)
            if sc > best_score:
                best_score = sc
                best_set = improved[:]
            cur = improved
        except Exception:
            break
        if random.random() < 0.3:
            # restart from a new structured set
            if structured_sets:
                base = random.choice(structured_sets)
                n = random.randint(10, min(len(base), 200))
                cur = random.sample(base, n)
                cur = scale_translate(cur, random.choice([1, 2, 3]), random.randint(-100, 100))
                cur = list(set(cur))

    # Final polish: try small perturbations
    cur = best_set[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.7:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-1, 1)
        elif r < 0.9:
            if len(cand) < 500:
                cand.append(random.randint(min(cand), max(cand)))
        else:
            if len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc > cur_score or random.random() < 0.01:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best_set = cand[:]

    return sorted(set(best_set))
# EVOLVE-BLOCK-END
