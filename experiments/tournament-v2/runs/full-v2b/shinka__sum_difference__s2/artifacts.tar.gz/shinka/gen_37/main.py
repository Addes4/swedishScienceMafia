# EVOLVE-BLOCK-START
"""Coset construction + Golomb-ruler seeding + bitset metrics.

A = { m*k + r : k in [0,K), r in R } makes sums collapse (only 2R mod m
windows) while differences fill a wide range. We seed with Golomb rulers
(which maximize distinct differences) and polish with a fast bitset metric."""
import math
import random
import time


def _bitset_metrics(vals):
    """Return (|diff|, |sum|) using big-int bitsets. vals are integers."""
    n = len(vals)
    if n < 2:
        return 0, 0
    mn = min(vals)
    mx = max(vals)
    span = mx - mn
    if span == 0:
        return 1, 1
    # difference bitset: index = d + span, d in [-span, span]
    diff_bits = 0
    # sum bitset: index = s - 2*mn, s in [2*mn, 2*mx]
    s_off = 2 * mn
    # shift trick: precompute masks per value
    for v in vals:
        # differences v - u for all u
        # build a local mask
        local = 0
        for u in vals:
            local |= (1 << (v - u + span))
        diff_bits |= local
        # sums
        for u in vals:
            pass  # handled below
    # sums: build once
    sum_bits = 0
    for i in range(n):
        ai = vals[i]
        for j in range(i, n):
            aj = vals[j]
            sum_bits |= (1 << (ai + aj - s_off))
            sum_bits |= (1 << (ai + aj - s_off))  # duplicated pair, still fine
    return bin(diff_bits).count("1"), bin(sum_bits).count("1")


def _fast_metrics(vals):
    """Faster set-based metric for small n; falls back to bitset for large n."""
    n = len(vals)
    if n < 2:
        return 0, 0
    if n <= 60:
        diffs = set()
        sums = set()
        for i in range(n):
            ai = vals[i]
            for j in range(i, n):
                aj = vals[j]
                diffs.add(ai - aj)
                diffs.add(aj - ai)
                sums.add(ai + aj)
        return len(diffs), len(sums)
    # bitset version for larger n
    mn = min(vals)
    mx = max(vals)
    span = mx - mn
    s_off = 2 * mn
    diff_bits = 0
    for v in vals:
        for u in vals:
            diff_bits |= (1 << (v - u + span))
    sum_bits = 0
    for i in range(n):
        ai = vals[i]
        for j in range(i, n):
            sum_bits |= (1 << (ai + vals[j] - s_off))
    return bin(diff_bits).count("1"), bin(sum_bits).count("1")


def _score_vals(vals):
    d, s = _fast_metrics(vals)
    n = len(set(vals))
    if n < 2 or s <= 1:
        return -1e18
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _eval_coset(m, R, K):
    vals = []
    seen = set()
    for k in range(K):
        base = m * k
        for r in R:
            v = base + r
            if v not in seen:
                seen.add(v)
                vals.append(v)
    return vals


def _score_coset(m, R, K):
    vals = _eval_coset(m, R, K)
    if len(vals) < 2:
        return -1e18, vals
    return _score_vals(vals), vals


def _greedy_residues(m, T, K, time_limit=2.0):
    deadline = time.time() + time_limit
    R = [0]
    best_score, _ = _score_coset(m, R, K)
    while len(R) < T and time.time() < deadline:
        best_r = None
        best_sc = best_score
        for r in range(m):
            if r in R:
                continue
            cand = R + [r]
            sc, _ = _score_coset(m, cand, K)
            if sc > best_sc:
                best_sc = sc
                best_r = r
            if time.time() > deadline:
                break
        if best_r is None:
            break
        R.append(best_r)
        best_score = best_sc
    return R, best_score


def _local_search_R(m, R, K, time_limit, best_global):
    deadline = time.time() + time_limit
    R = list(set(R))
    sc, _ = _score_coset(m, R, K)
    best_R = R[:]
    best_sc = sc
    while time.time() < deadline:
        cand = R[:]
        op = random.random()
        if op < 0.4 and len(cand) < m:
            r = random.randrange(m)
            if r not in cand:
                cand.append(r)
        elif op < 0.7 and len(cand) > 2:
            cand.pop(random.randrange(len(cand)))
        else:
            if cand:
                i = random.randrange(len(cand))
                r = random.randrange(m)
                if r not in cand:
                    cand[i] = r
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc2, _ = _score_coset(m, cand, K)
        if sc2 > sc or random.random() < 0.02:
            R = cand
            sc = sc2
            if sc2 > best_sc:
                best_sc = sc2
                best_R = cand[:]
                if sc2 > best_global[0]:
                    best_global[0] = sc2
                    best_global[1] = (m, cand[:], K)
    return best_R, best_sc


def _golomb_ruler(n):
    if n <= 1:
        return [0]
    a = [0, 1]
    diffs = {1, -1}
    while len(a) < n:
        x = a[-1] + 1
        while True:
            ok = True
            new_diffs = set()
            for y in a:
                d1 = x - y
                d2 = y - x
                if d1 in diffs or d2 in diffs or d1 in new_diffs or d2 in new_diffs:
                    ok = False
                    break
                new_diffs.add(d1)
                new_diffs.add(d2)
            if ok:
                break
            x += 1
        a.append(x)
        diffs |= new_diffs
    return a


def solve():
    """Return list of distinct integers maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best_score = -1e18
    best_vals = None

    # --- Phase 0: Golomb-ruler seeds (maximize differences) ---
    golomb_seeds = []
    for n in [10, 20, 30, 40, 50, 60, 80, 100, 150, 200]:
        if time.time() > deadline - 100:
            break
        try:
            a = _golomb_ruler(n)
            m = a[-1] // 2
            a = [x - m for x in a]
            golomb_seeds.append(a)
        except Exception:
            pass
    for a in golomb_seeds:
        sc = _score_vals(a)
        if sc > best_score:
            best_score = sc
            best_vals = a[:]
    # also try small cosets built from Golomb residues
    for a in golomb_seeds[:5]:
        if len(a) < 2:
            continue
        mn = min(a)
        a2 = [x - mn for x in a]
        span = max(a2)
        if span < 2:
            continue
        # use as a residue set mod (span+1)
        m = span + 1
        R = sorted(set(x % m for x in a2))
        if len(R) < 2:
            continue
        K = 2
        sc, vals = _score_coset(m, R, K)
        if sc > best_score:
            best_score = sc
            best_vals = vals[:]

    # --- Phase 1: coset grid search with greedy residues ---
    grid = []
    for m in [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 24, 30, 40, 50]:
        for K in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 30]:
            grid.append((m, K, m))
    for m in [5, 6, 7, 8, 10, 12, 15, 20, 25, 30, 40, 60]:
        for K in [3, 5, 8, 12, 20, 30, 50]:
            for T in [max(2, m // 2), max(2, m - 1), m]:
                grid.append((m, K, T))
    random.shuffle(grid)
    phase1_end = time.time() + 35
    for (m, K, T) in grid:
        if time.time() > phase1_end:
            break
        try:
            tl = min(1.0, max(0.02, (phase1_end - time.time()) / 30))
            R, sc = _greedy_residues(m, T, K, time_limit=tl)
            if sc > best_score:
                _, vals = _score_coset(m, R, K)
                if vals and len(vals) >= 2:
                    best_score = sc
                    best_vals = vals[:]
        except Exception:
            continue

    if best_vals is None:
        best_vals = [0, 1, 3, 7, 12]
        best_score = _score_vals(best_vals)

    # --- Phase 2: local search on coset parameters ---
    best_global = [best_score, None]
    phase2_end = time.time() + 35
    seeds = []
    for m in [4, 5, 6, 7, 8, 10, 12, 15, 20, 30, 40]:
        for K in [3, 4, 6, 8, 12, 20, 30]:
            seeds.append((m, K))
    random.shuffle(seeds)
    for (m, K) in seeds:
        if time.time() > phase2_end:
            break
        T = random.randint(2, m)
        R = random.sample(range(m), T)
        try:
            tl = min(3.0, max(0.1, (phase2_end - time.time()) / 12))
            R2, sc = _local_search_R(m, R, K, time_limit=tl, best_global=best_global)
            if sc > best_score:
                _, vals = _score_coset(m, R2, K)
                if vals and len(vals) >= 2 and _score_vals(vals) > best_score:
                    best_score = _score_vals(vals)
                    best_vals = vals[:]
        except Exception:
            continue

    if best_global[1] is not None:
        m, R, K = best_global[1]
        vals = _eval_coset(m, R, K)
        sc = _score_vals(vals)
        if sc > best_score:
            best_score = sc
            best_vals = vals[:]

    # --- Phase 3: generic polish on best integer set ---
    cur = list(set(best_vals))
    cur_score = _score_vals(cur)
    if cur_score > best_score:
        best_score = cur_score
        best_vals = cur[:]
    T0 = 0.3
    T = T0
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        span = (max(cand) - min(cand)) if cand else 1
        span = max(1, span)
        # adaptive magnitude
        mags = [1, 2, max(1, span // 200), max(1, span // 50), max(1, span // 10), max(1, span // 3)]
        mag = random.choice(mags)
        if r < 0.7 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * mag
        elif r < 0.88:
            if len(cand) < 4000:
                lo = min(cand) - span
                hi = max(cand) + span
                cand.append(random.randint(lo, hi))
        else:
            if len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue
        s = _score_vals(cand)
        if s > cur_score or random.random() < math.exp(min(0.0, (s - cur_score) / max(T, 1e-6))):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best_vals = cand[:]
        T *= 0.99995
        if T < 1e-6:
            T = T0 * 0.1

    return sorted(set(best_vals))
# EVOLVE-BLOCK-END