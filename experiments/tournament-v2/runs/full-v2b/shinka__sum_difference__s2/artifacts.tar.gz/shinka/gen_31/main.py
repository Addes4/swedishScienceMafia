# EVOLVE-BLOCK-START
"""Hybrid: Beatty/Sturmian seeds + greedy diff-max growth + simulated-annealing
Pareto polish that monotonically tightens |A+A| while preserving |A-A|."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _fast_metrics(a):
    """Return (|diff|, |sum|) for set a."""
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def beatty_set(n, alpha, offset=0):
    """Generate n distinct integers from floor(k*alpha) + offset."""
    vals = []
    seen = set()
    k = 1
    while len(vals) < n and k < n * 100:
        v = int(math.floor(k * alpha)) + offset
        if v not in seen:
            seen.add(v)
            vals.append(v)
        k += 1
    return vals


def greedy_diff_max(n, seed_set=None, time_limit=3.0):
    """Greedily build a set maximizing |diff|/|sum| ratio by adding elements."""
    deadline = time.time() + time_limit
    if seed_set is None:
        a = [0, 1]
    else:
        a = list(set(seed_set))
    while len(a) < n and time.time() < deadline:
        best_x = None
        best_gain = -1e18
        lo = min(a) - max(1, max(a) - min(a))
        hi = max(a) + max(1, max(a) - min(a))
        candidates = set()
        for _ in range(150):
            candidates.add(random.randint(lo, hi))
        for x in a:
            candidates.add(x + 1)
            candidates.add(x - 1)
        candidates -= set(a)
        if not candidates:
            break
        cur_d, cur_s = _fast_metrics(a)
        cur_score = math.log(cur_d) / math.log(cur_s) if cur_s > 1 else 0
        for x in candidates:
            if time.time() > deadline:
                break
            b = a + [x]
            d, s = _fast_metrics(b)
            if s <= 1:
                continue
            sc = math.log(d) / math.log(s)
            if sc > best_gain:
                best_gain = sc
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def sa_search(seed, deadline, T0=0.1, step0=10):
    """Simulated annealing on the raw score, with adaptive step."""
    cur = list(set(seed))
    if len(cur) < 2:
        cur = [0, 1]
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    T = T0
    step = step0
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.6 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.8:
            if len(cand) < 400:
                cand.append(random.randint(min(cand) - 100, max(cand) + 100))
        else:
            if len(cand) > 2:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-9)):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]
        if random.random() < 0.01:
            step = max(1, min(1000, int(step * random.uniform(0.8, 1.2))))
        T *= 0.9999
        if T < 1e-6:
            T = 1e-6
    return best, best_score


def pareto_polish(seed, deadline):
    """Monotone Pareto polish: accept only moves that tighten the frontier
    (|A-A| up or equal AND |A+A| strictly down) or (|A-A| strictly up and
    |A+A| equal or down).  Falls back to lateral moves on plateaus."""
    cur = list(set(seed))
    if len(cur) < 2:
        return cur, _score(cur)
    cur_d, cur_s = _fast_metrics(cur)
    best = cur[:]
    best_score = _score(cur)
    while time.time() < deadline:
        cand = cur[:]
        if not cand:
            break
        span = max(cand) - min(cand) if len(cand) > 1 else 1
        span = max(1, span)
        r = random.random()
        if r < 0.55:
            i = random.randrange(len(cand))
            mags = [1, 2, max(1, span // 200), max(1, span // 50), max(1, span // 10)]
            mag = random.choice(mags)
            cand[i] += random.choice([-1, 1]) * mag
        elif r < 0.85:
            if len(cand) >= 3:
                i = random.randrange(len(cand))
                others = [cand[j] for j in range(len(cand)) if j != i]
                j1 = random.randrange(len(others))
                j2 = random.randrange(len(others))
                k = random.randrange(len(others))
                cand[i] = others[j1] + others[j2] - others[k]
        else:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        d2, s2 = _fast_metrics(cand)
        if (d2 >= cur_d and s2 < cur_s) or (d2 > cur_d and s2 <= cur_s):
            cur = cand
            cur_d, cur_s = d2, s2
            sc = _score(cand)
            if sc > best_score:
                best_score = sc
                best = cand[:]
        elif d2 == cur_d and s2 == cur_s:
            if random.random() < 0.05:
                cur = cand
    return best, best_score


def solve():
    """Return list of distinct integers maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best_set = None
    best_score = -1e18

    # -------- Phase 1: Beatty / Sturmian seeds --------
    alphas = [
        (1 + math.sqrt(5)) / 2,
        math.sqrt(2),
        math.sqrt(3),
        math.sqrt(5),
        1 + math.sqrt(2),
        math.pi,
        math.e,
        2.414213562373095,
        1.6180339887498949,
        1.7320508075688772,
    ]
    sizes = [20, 30, 40, 50, 60, 80, 100, 150, 200]
    phase1_deadline = time.time() + 25
    for alpha in alphas:
        for n in sizes:
            if time.time() > phase1_deadline:
                break
            try:
                a = beatty_set(n, alpha)
                s = _score(a)
                if s > best_score:
                    best_score = s
                    best_set = a[:]
            except Exception:
                continue

    # -------- Phase 2: greedy diff-max growth from best seed --------
    if best_set is not None:
        phase2_deadline = time.time() + 15
        for _ in range(3):
            if time.time() > phase2_deadline:
                break
            try:
                g = greedy_diff_max(min(len(best_set) + 20, 200),
                                    seed_set=best_set[:10],
                                    time_limit=3.0)
                s = _score(g)
                if s > best_score:
                    best_score = s
                    best_set = g[:]
            except Exception:
                continue

    if best_set is None:
        best_set = [0, 1, 3, 7, 12]
        best_score = _score(best_set)

    # -------- Phase 3: short SA from best seed --------
    sa_deadline = time.time() + 20
    try:
        sa_best, sa_score = sa_search(best_set, sa_deadline, T0=0.1, step0=10)
        if sa_score > best_score:
            best_score = sa_score
            best_set = sa_best[:]
    except Exception:
        pass

    # -------- Phase 4: Pareto polish (monotone sum reduction) --------
    remaining = max(1.0, deadline - time.time())
    try:
        pb, ps = pareto_polish(best_set, time.time() + remaining)
        if ps > best_score:
            best_score = ps
            best_set = pb[:]
    except Exception:
        pass

    # -------- Phase 5: final SA + Pareto polish loop if time remains --------
    while time.time() < deadline:
        try:
            sa_best, sa_score = sa_search(best_set, min(time.time() + 5, deadline),
                                          T0=0.05, step0=5)
            if sa_score > best_score:
                best_score = sa_score
                best_set = sa_best[:]
            pb, ps = pareto_polish(best_set, min(time.time() + 5, deadline))
            if ps > best_score:
                best_score = ps
                best_set = pb[:]
        except Exception:
            break

    return sorted(set(best_set))
# EVOLVE-BLOCK-END