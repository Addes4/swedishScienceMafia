# EVOLVE-BLOCK-START
"""Ratio-first local search with relaxed Pareto (sum-tightening) acceptance.

Primary objective: log|A-A| / log|A+A|.
Secondary tie-breaker: among moves that do not decrease the ratio, accept those
that keep |A-A| non-decreasing while strictly shrinking |A+A|.
"""
import math
import random
import time


def _stats(a):
    """Return (|A-A|, |A+A|) in a single O(n^2) pass."""
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _ratio(d, s):
    if s < 2 or d < 1:
        return 0.0
    return math.log(d) / math.log(s)


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    d, s = _stats(a)
    if s < 2:
        return 0.0
    return _ratio(d, s) + (1 - 1 / n) / 100


# ---------------------------------------------------------------------------
# Constructions (kept from the previous version - they are good seeds)
# ---------------------------------------------------------------------------

def greedy_golomb(n, max_val=None, seed=0):
    marks = [0]
    used_diffs = {0}
    candidate = 1
    while len(marks) < n:
        ok = True
        new_diffs = []
        for m in marks:
            d = candidate - m
            if d in used_diffs:
                ok = False
                break
            new_diffs.append(d)
        if ok:
            for d in new_diffs:
                used_diffs.add(d)
                used_diffs.add(-d)
            marks.append(candidate)
            candidate += 1
        else:
            candidate += 1
            if max_val is not None and candidate > max_val:
                break
    return marks


def greedy_sidon_weighted(n, weight=0.5, window=200, seed=0):
    marks = [0, 1]
    while len(marks) < n:
        existing_diffs = set()
        existing_sums = set()
        for x in marks:
            for y in marks:
                existing_diffs.add(x - y)
                existing_sums.add(x + y)
        best_c = None
        best_cost = None
        start = marks[-1] + 1
        for c in range(start, start + window):
            diffs = set()
            sums = set()
            for m in marks:
                diffs.add(c - m)
                diffs.add(m - c)
                sums.add(c + m)
            nd = len(diffs - existing_diffs)
            ns = len(sums - existing_sums)
            cost = ns - weight * nd
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_c = c
        if best_c is None:
            best_c = marks[-1] + 1
        marks.append(best_c)
    return marks


def ratio_greedy(n, seed=0, window=80):
    A = [0, 1]
    while len(A) < n:
        base_score = _score(A)
        best_c = None
        best_s = base_score
        start = A[-1] + 1
        for c in range(start, start + window):
            cand = A + [c]
            s = _score(cand)
            if s > best_s:
                best_s = s
                best_c = c
        if best_c is None:
            best_c = A[-1] + 1
        A.append(best_c)
    return A


def dilate(base, T, K):
    out = set()
    for k in range(K):
        off = T * k
        for b in base:
            out.add(b + off)
    return sorted(out)


def multi_band(base, gaps):
    out = set()
    for g in gaps:
        for b in base:
            out.add(b + g)
    return sorted(out)


def _beatty_pair(n, alpha, beta):
    """A = {floor(k*alpha) + floor(k*beta) : k=1..n}.

    Complementary Beatty pairs (1/alpha + 1/beta = 1) partition the integers,
    producing a very dense difference set; incommensurable (alpha, beta) keep
    the sum set relatively sparse.
    """
    out = set()
    for k in range(1, n + 1):
        out.add(int(math.floor(k * alpha)) + int(math.floor(k * beta)))
    return sorted(out)


def _beatty_union(n, alpha, beta):
    """A = {floor(k*alpha)} U {floor(k*beta)} for k=1..n."""
    out = set()
    for k in range(1, n + 1):
        out.add(int(math.floor(k * alpha)))
        out.add(int(math.floor(k * beta)))
    return sorted(out)


# ---------------------------------------------------------------------------
# Ratio-first local search with relaxed Pareto acceptance
# ---------------------------------------------------------------------------

def _accept(cur_d, cur_s, new_d, new_s):
    """Return True if the move should be accepted.

    Primary: strictly better ratio.
    Tie-breaker (relaxed Pareto): non-decreasing |A-A| and strictly smaller |A+A|.
    """
    if new_s < 2 or new_d < 1:
        return False
    cur_ratio = _ratio(cur_d, cur_s)
    new_ratio = _ratio(new_d, new_s)
    if new_ratio > cur_ratio:
        return True
    if new_d >= cur_d and new_s < cur_s:
        return True
    return False


def ratio_local_search(a, deadline, temperature=2.0):
    """Local search driven by ratio + relaxed sum-tightening tie-breaker."""
    a = list(set(a))
    if len(a) < 2:
        return a, 0.0
    cur_d, cur_s = _stats(a)
    best = a[:]
    best_d, best_s = cur_d, cur_s
    best_score = _score(a)

    lo = min(a)
    hi = max(a)
    span = max(1, hi - lo)
    step_base = max(1, span // 20)

    while time.time() < deadline:
        move = random.random()
        cand = a[:]
        if move < 0.45 and cand:
            i = random.randrange(len(cand))
            step = max(1, int(step_base * (0.1 + temperature * random.random())))
            cand[i] += random.randint(-step, step)
        elif move < 0.7:
            new_val = random.randint(lo - span, hi + span)
            cand.append(new_val)
        elif move < 0.9 and len(cand) > 3:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            shift = random.randint(-step_base, step_base)
            cand = [x + shift for x in cand]

        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue

        new_d, new_s = _stats(cand)

        if _accept(cur_d, cur_s, new_d, new_s):
            a = cand
            cur_d, cur_s = new_d, new_s
            new_score = _ratio(new_d, new_s) + (1 - 1 / len(cand)) / 100
            if new_score > best_score:
                best = cand[:]
                best_d, best_s = new_d, new_s
                best_score = new_score
        elif random.random() < 0.02:
            # occasional exploratory move
            a = cand
            cur_d, cur_s = new_d, new_s

        temperature *= 0.99995

    return best, best_score


def squeeze_sums(a, deadline, best_score):
    """Last-phase: reduce |A+A| while keeping |A-A| non-decreasing."""
    a = list(set(a))
    if len(a) < 3:
        return a, best_score
    cur_d, cur_s = _stats(a)
    best = a[:]
    best_d, best_s = cur_d, cur_s
    best_local = best_score
    lo = min(a)
    hi = max(a)
    span = max(1, hi - lo)

    while time.time() < deadline:
        cand = a[:]
        r = random.random()
        if r < 0.4 and cand:
            # small perturbation
            i = random.randrange(len(cand))
            cand[i] += random.randint(-max(1, span // 50), max(1, span // 50))
        elif r < 0.75 and len(cand) > 3:
            # remove an interior element (often tightens sums)
            cand.sort()
            i = random.randrange(1, len(cand) - 1)
            cand.pop(i)
        else:
            # try replacing an element with a value near the median
            cand.sort()
            mid = cand[len(cand) // 2]
            i = random.randrange(len(cand))
            cand[i] = mid + random.randint(-max(1, span // 30), max(1, span // 30))

        cand = list(set(cand))
        if len(cand) < 3 or len(cand) > 4000:
            continue

        new_d, new_s = _stats(cand)
        # Only accept if the ratio does not regress and |A-A| is non-decreasing
        # while |A+A| strictly shrinks (relaxed Pareto tie-breaker).
        if new_d >= cur_d and new_s < cur_s:
            a = cand
            cur_d, cur_s = new_d, new_s
            new_score = _ratio(new_d, new_s) + (1 - 1 / len(cand)) / 100
            if new_score > best_local:
                best = cand[:]
                best_d, best_s = new_d, new_s
                best_local = new_score
        elif _ratio(new_d, new_s) > _ratio(cur_d, cur_s):
            a = cand
            cur_d, cur_s = new_d, new_s
            new_score = _ratio(new_d, new_s) + (1 - 1 / len(cand)) / 100
            if new_score > best_local:
                best = cand[:]
                best_d, best_s = new_d, new_s
                best_local = new_score

    return best, best_local


# ---------------------------------------------------------------------------
# Main solver
# ---------------------------------------------------------------------------

def solve():
    """Return a list of distinct integers A maximising log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # --- Strategy 1: dilated Golomb rulers ---
    for gn in [4, 5, 6, 7, 8, 10, 12]:
        if time.time() > deadline:
            break
        G = greedy_golomb(gn)
        for K in [2, 3, 4, 5, 6, 8, 10, 12, 16]:
            for T in [3, 5, 7, 9, 11, 13, 17, 19, 23, 29, 31, 37, 41, 47, 53]:
                A = dilate(G, T, K)
                if len(A) < 2 or len(A) > 4000:
                    continue
                s = _score(A)
                if s > best_score:
                    best, best_score = A[:], s

    # --- Strategy 2: dilated Sidon sets ---
    for gn in [5, 6, 7, 8, 10]:
        if time.time() > deadline:
            break
        for w in [0.3, 0.5, 0.7, 1.0]:
            S = greedy_sidon_weighted(gn, weight=w, window=150)
            for K in [2, 3, 4, 6, 8, 10, 12]:
                for T in [5, 7, 9, 11, 13, 17, 19, 23, 29, 31, 41, 47]:
                    A = dilate(S, T, K)
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    s = _score(A)
                    if s > best_score:
                        best, best_score = A[:], s
            if time.time() > deadline:
                break

    # --- Strategy 3: multi-band with chosen gaps ---
    for gn in [4, 5, 6, 7, 8]:
        if time.time() > deadline:
            break
        G = greedy_golomb(gn)
        for gaps in (
            [0, 1, 3, 7, 15, 31, 63],
            [0, 2, 6, 14, 30, 62],
            [0, 1, 4, 10, 22, 46, 94],
            [0, 3, 9, 27, 81],
            [0, 5, 15, 45, 135],
        ):
            A = multi_band(G, gaps)
            if len(A) < 2 or len(A) > 4000:
                continue
            s = _score(A)
            if s > best_score:
                best, best_score = A[:], s

    # --- Strategy 4: ratio-aware greedy ---
    for n in [8, 12, 16, 20, 25, 30]:
        if time.time() > deadline:
            break
        A = ratio_greedy(n, window=60)
        s = _score(A)
        if s > best_score:
            best, best_score = A[:], s

    # --- Strategy 5: pure Golomb rulers ---
    for n in [8, 12, 16, 20, 25, 30, 40, 50]:
        if time.time() > deadline:
            break
        G = greedy_golomb(n)
        s = _score(G)
        if s > best_score:
            best, best_score = G[:], s

    # --- Strategy 5b: Beatty / Sturmian seeds (complementary + two-irrational) ---
    phi = (1.0 + math.sqrt(5.0)) / 2.0
    phi2 = phi * phi
    sqrt2 = math.sqrt(2.0)
    sqrt3 = math.sqrt(3.0)
    beatty_pairs = [
        (phi, phi2),        # complementary Beatty (1/phi + 1/phi^2 = 1)
        (phi, sqrt2),
        (phi, sqrt3),
        (sqrt2, sqrt3),
        (sqrt2, phi2),
        (sqrt3, phi2),
    ]
    for n in [100, 200, 400, 700]:
        if time.time() > deadline:
            break
        for (al, be) in beatty_pairs:
            A = _beatty_pair(n, al, be)
            if 2 <= len(A) <= 4000:
                s = _score(A)
                if s > best_score:
                    best, best_score = A[:], s
            A = _beatty_union(n, al, be)
            if 2 <= len(A) <= 4000:
                s = _score(A)
                if s > best_score:
                    best, best_score = A[:], s

    # --- Strategy 6: ratio-first local search from best and promising starts ---
    starts = [best]
    for gn in [5, 6, 7]:
        G = greedy_golomb(gn)
        for K in [4, 6, 8]:
            for T in [7, 11, 17, 23, 31]:
                starts.append(dilate(G, T, K))

    # Reserve ~10% of the budget for the dedicated sum-squeeze phase.
    now = time.time()
    remaining = max(0.0, deadline - now)
    squeeze_budget = remaining * 0.10
    ls_deadline = deadline - squeeze_budget

    for st in starts:
        if time.time() > ls_deadline:
            break
        b, bs = ratio_local_search(st, min(ls_deadline, time.time() + 6))
        if bs > best_score:
            best, best_score = b[:], bs

    # --- Strategy 7: random restarts + ratio-first local search ---
    while time.time() < ls_deadline:
        mode = random.random()
        if mode < 0.5:
            gn = random.randint(4, 8)
            G = greedy_golomb(gn)
            K = random.randint(2, 12)
            T = random.choice([3, 5, 7, 9, 11, 13, 17, 19, 23, 29, 31, 37, 41, 47, 53, 61, 71])
            a = dilate(G, T, K)
        else:
            n = random.randint(6, 30)
            a = sorted(random.sample(range(-200, 500), n))
        if len(a) < 2 or len(a) > 4000:
            continue
        s = _score(a)
        if s > best_score:
            best, best_score = a[:], s
        b, bs = ratio_local_search(a, min(ls_deadline, time.time() + 3))
        if bs > best_score:
            best, best_score = b[:], bs

    # --- Strategy 8: dedicated sum-squeeze phase (last ~10% of budget) ---
    if time.time() < deadline:
        b, bs = squeeze_sums(best, deadline, best_score)
        if bs > best_score:
            best, best_score = b[:], bs

    return sorted(set(best))
# EVOLVE-BLOCK-END