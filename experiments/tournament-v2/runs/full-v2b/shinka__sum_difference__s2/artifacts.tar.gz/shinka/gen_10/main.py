# EVOLVE-BLOCK-START
"""Hybrid solver: dilated Golomb/Sidon constructions with ratio-aware local search."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _stats(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def greedy_golomb(n, max_val=None, seed=0):
    """Greedy Golomb ruler: add smallest integer keeping all differences distinct."""
    rng = random.Random(seed)
    marks = [0]
    used_diffs = {0}
    candidate = 1
    while len(marks) < n:
        ok = True
        new_diffs = []
        for m in marks:
            d = candidate - m
            if d in used_diffs:
                ok = False
                break
            new_diffs.append(d)
        if ok:
            for d in new_diffs:
                used_diffs.add(d)
                used_diffs.add(-d)
            marks.append(candidate)
            candidate += 1
        else:
            candidate += 1
            if max_val is not None and candidate > max_val:
                break
    return marks


def greedy_sidon_weighted(n, weight=0.5, window=200, seed=0):
    """Greedy Sidon-like: prefer candidates adding many diffs, few sums."""
    rng = random.Random(seed)
    marks = [0, 1]
    while len(marks) < n:
        existing_diffs = set()
        existing_sums = set()
        for x in marks:
            for y in marks:
                existing_diffs.add(x - y)
                existing_sums.add(x + y)
        best_c = None
        best_cost = None
        start = marks[-1] + 1
        for c in range(start, start + window):
            diffs = set()
            sums = set()
            for m in marks:
                diffs.add(c - m)
                diffs.add(m - c)
                sums.add(c + m)
            nd = len(diffs - existing_diffs)
            ns = len(sums - existing_sums)
            cost = ns - weight * nd
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_c = c
        if best_c is None:
            best_c = marks[-1] + 1
        marks.append(best_c)
    return marks


def ratio_greedy(n, seed=0, window=80):
    """Greedily add the candidate maximizing the marginal ratio."""
    rng = random.Random(seed)
    A = [0, 1]
    target = n
    while len(A) < target:
        base_score = _score(A)
        best_c = None
        best_s = base_score
        start = A[-1] + 1
        for c in range(start, start + window):
            cand = A + [c]
            s = _score(cand)
            if s > best_s:
                best_s = s
                best_c = c
        if best_c is None:
            best_c = A[-1] + 1
        A.append(best_c)
    return A


def dilate(base, T, K):
    """A = base + T*{0..K-1}: differences multiply, sums concentrate."""
    out = set()
    for k in range(K):
        off = T * k
        for b in base:
            out.add(b + off)
    return sorted(out)


def multi_band(base, gaps):
    """A = union of base + g for g in gaps (gaps chosen to spread differences)."""
    out = set()
    for g in gaps:
        for b in base:
            out.add(b + g)
    return sorted(out)


def local_search(a, deadline, best_global_score, temperature=3.0):
    """Hill-climb with adaptive temperature and wider integer range."""
    a = list(set(a))
    if len(a) < 2:
        return a, _score(a)
    cur_score = _score(a)
    best = a[:]
    best_score = cur_score
    lo = min(a)
    hi = max(a)
    span = max(1, hi - lo)
    step_base = max(1, span // 20)
    while time.time() < deadline:
        move = random.random()
        cand = a[:]
        if move < 0.45 and cand:
            i = random.randrange(len(cand))
            step = max(1, int(step_base * (0.1 + temperature * random.random())))
            cand[i] += random.randint(-step, step)
        elif move < 0.7:
            new_val = random.randint(lo - span, hi + span)
            cand.append(new_val)
        elif move < 0.9 and len(cand) > 3:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            shift = random.randint(-step_base, step_base)
            cand = [x + shift for x in cand]
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s > cur_score:
            a = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif random.random() < 0.03:
            a = cand
            cur_score = s
        temperature *= 0.9999
    return best, best_score


def solve():
    """Hybrid search maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # --- Strategy 1: dilated Golomb rulers (key new construction) ---
    # A = G + T*{0..K-1}. Differences span ~K*range(G), sums concentrate in bands.
    for gn in [4, 5, 6, 7, 8, 10, 12]:
        if time.time() > deadline:
            break
        G = greedy_golomb(gn)
        for K in [2, 3, 4, 5, 6, 8, 10, 12, 16]:
            for T in [3, 5, 7, 9, 11, 13, 17, 19, 23, 29, 31, 37, 41, 47, 53]:
                A = dilate(G, T, K)
                if len(A) < 2 or len(A) > 4000:
                    continue
                s = _score(A)
                if s > best_score:
                    best, best_score = A[:], s

    # --- Strategy 2: dilated Sidon sets ---
    for gn in [5, 6, 7, 8, 10]:
        if time.time() > deadline:
            break
        for w in [0.3, 0.5, 0.7, 1.0]:
            S = greedy_sidon_weighted(gn, weight=w, window=150)
            for K in [2, 3, 4, 6, 8, 10, 12]:
                for T in [5, 7, 9, 11, 13, 17, 19, 23, 29, 31, 41, 47]:
                    A = dilate(S, T, K)
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    s = _score(A)
                    if s > best_score:
                        best, best_score = A[:], s
            if time.time() > deadline:
                break

    # --- Strategy 3: multi-band with carefully chosen gaps ---
    for gn in [4, 5, 6, 7, 8]:
        if time.time() > deadline:
            break
        G = greedy_golomb(gn)
        for gaps in (
            [0, 1, 3, 7, 15, 31, 63],
            [0, 2, 6, 14, 30, 62],
            [0, 1, 4, 10, 22, 46, 94],
            [0, 3, 9, 27, 81],
            [0, 5, 15, 45, 135],
        ):
            A = multi_band(G, gaps)
            if len(A) < 2 or len(A) > 4000:
                continue
            s = _score(A)
            if s > best_score:
                best, best_score = A[:], s

    # --- Strategy 4: ratio-aware greedy ---
    for n in [8, 12, 16, 20, 25, 30]:
        if time.time() > deadline:
            break
        A = ratio_greedy(n, window=60)
        s = _score(A)
        if s > best_score:
            best, best_score = A[:], s

    # --- Strategy 5: pure Golomb rulers of several sizes (baseline) ---
    for n in [8, 12, 16, 20, 25, 30, 40, 50]:
        if time.time() > deadline:
            break
        G = greedy_golomb(n)
        s = _score(G)
        if s > best_score:
            best, best_score = G[:], s

    # --- Strategy 6: local search from best and from promising starts ---
    starts = [best]
    for gn in [5, 6, 7]:
        G = greedy_golomb(gn)
        for K in [4, 6, 8]:
            for T in [7, 11, 17, 23, 31]:
                starts.append(dilate(G, T, K))

    for st in starts:
        if time.time() > deadline:
            break
        b, bs = local_search(st, min(deadline, time.time() + 6), best_score)
        if bs > best_score:
            best, best_score = b[:], bs

    # --- Strategy 7: random restarts + local search ---
    while time.time() < deadline:
        mode = random.random()
        if mode < 0.5:
            gn = random.randint(4, 8)
            G = greedy_golomb(gn)
            K = random.randint(2, 12)
            T = random.choice([3, 5, 7, 9, 11, 13, 17, 19, 23, 29, 31, 37, 41, 47, 53, 61, 71])
            a = dilate(G, T, K)
        else:
            n = random.randint(6, 30)
            a = sorted(random.sample(range(-200, 500), n))
        if len(a) < 2 or len(a) > 4000:
            continue
        s = _score(a)
        if s > best_score:
            best, best_score = a[:], s
        b, bs = local_search(a, min(deadline, time.time() + 3), best_score)
        if bs > best_score:
            best, best_score = b[:], bs

    return sorted(set(best))
# EVOLVE-BLOCK-END
