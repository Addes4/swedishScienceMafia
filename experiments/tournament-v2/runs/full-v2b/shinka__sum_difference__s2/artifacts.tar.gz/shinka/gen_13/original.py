# EVOLVE-BLOCK-START
"""Construct sets with large difference sets and small sum sets using Sturmian sequences
and greedy difference-maximizing construction with sum-collision local search."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _fast_metrics(a):
    """Return (|diff|, |sum|) for set a."""
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def beatty_set(n, alpha, offset=0):
    """Generate n distinct integers from floor(k*alpha) + offset."""
    vals = []
    seen = set()
    k = 1
    while len(vals) < n and k < n * 100:
        v = int(math.floor(k * alpha)) + offset
        if v not in seen:
            seen.add(v)
            vals.append(v)
        k += 1
    return vals


def greedy_diff_max(n, seed_set=None, time_limit=5.0):
    """Greedily build a set maximizing |diff|/|sum| ratio by adding elements.
    Start from seed_set or a small base, add element that maximizes score gain."""
    deadline = time.time() + time_limit
    if seed_set is None:
        a = [0, 1]
    else:
        a = list(set(seed_set))
    while len(a) < n and time.time() < deadline:
        best_x = None
        best_gain = -1e18
        # candidate range based on current spread
        lo = min(a) - max(1, max(a) - min(a))
        hi = max(a) + max(1, max(a) - min(a))
        # sample candidates
        candidates = set()
        for _ in range(200):
            candidates.add(random.randint(lo, hi))
        for x in a:
            candidates.add(x + 1)
            candidates.add(x - 1)
        candidates -= set(a)
        if not candidates:
            break
        cur_d, cur_s = _fast_metrics(a)
        cur_score = math.log(cur_d) / math.log(cur_s) if cur_s > 1 else 0
        for x in candidates:
            if time.time() > deadline:
                break
            b = a + [x]
            d, s = _fast_metrics(b)
            if s <= 1:
                continue
            sc = math.log(d) / math.log(s)
            if sc > best_gain:
                best_gain = sc
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def sum_collapse_local(a, time_limit=10.0):
    """Local search specifically trying to reduce sum set while keeping diff set large.
    Moves elements to create sum collisions."""
    deadline = time.time() + time_limit
    a = list(set(a))
    best_d, best_s = _fast_metrics(a)
    if best_s <= 1:
        return a
    best_score = math.log(best_d) / math.log(best_s) + (1 - 1/len(a))/100
    cur = a[:]
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5 and len(cand) >= 2:
            # try to shift an element to create a sum collision
            i = random.randrange(len(cand))
            others = [cand[j] for j in range(len(cand)) if j != i]
            if others:
                # pick two others whose sum we want to match
                j1 = random.randrange(len(others))
                j2 = random.randrange(len(others))
                target_sum = others[j1] + others[j2]
                # try new value near current that makes sum with some other element equal target
                k = random.randrange(len(others))
                new_val = target_sum - others[k]
                if new_val not in cand or new_val == cand[i]:
                    cand[i] = new_val
        elif op < 0.8:
            # small perturbation
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        else:
            # replace with a value that mimics an existing difference
            if len(cand) >= 2:
                i = random.randrange(len(cand))
                j = random.randrange(len(cand))
                k = random.randrange(len(cand))
                cand[i] = cand[j] - cand[k] + cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        d, s = _fast_metrics(cand)
        if s <= 1:
            continue
        sc = math.log(d) / math.log(s) + (1 - 1/len(cand))/100
        if sc > best_score or random.random() < 0.02:
            cur = cand
            if sc > best_score:
                best_score = sc
                best_d, best_s = d, s
    return cur


def solve():
    """Return list of distinct integers maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best_set = None
    best_score = -1e18

    # Phase 1: Try Beatty/Sturmian sequences with various slopes
    alphas = [
        (1 + math.sqrt(5)) / 2,  # golden ratio
        math.sqrt(2),
        math.sqrt(3),
        math.sqrt(5),
        1 + math.sqrt(2),
        math.pi,
        math.e,
        2.414213562373095,  # 1+sqrt(2)
        1.6180339887498949,
        1.7320508075688772,  # sqrt(3)
    ]
    sizes = [20, 30, 40, 50, 60, 80, 100, 150, 200]
    for alpha in alphas:
        for n in sizes:
            if time.time() > deadline * 0.4:
                break
            try:
                a = beatty_set(n, alpha)
                s = _score(a)
                if s > best_score:
                    best_score = s
                    best_set = a[:]
            except Exception:
                continue

    # Phase 2: Greedy difference-max construction from best seeds
    if best_set is not None:
        for _ in range(3):
            if time.time() > deadline * 0.6:
                break
            try:
                g = greedy_diff_max(min(len(best_set) + 20, 200),
                                    seed_set=best_set[:10],
                                    time_limit=3.0)
                s = _score(g)
                if s > best_score:
                    best_score = s
                    best_set = g[:]
            except Exception:
                continue

    # Phase 3: Sum-collapse local search
    if best_set is None:
        best_set = [0, 1, 3, 7, 12]
        best_score = _score(best_set)

    cur = best_set[:]
    while time.time() < deadline * 0.95:
        try:
            improved = sum_collapse_local(cur, time_limit=min(15.0, deadline - time.time()))
            s = _score(improved)
            if s > best_score:
                best_score = s
                best_set = improved[:]
            cur = improved
        except Exception:
            break
        # occasionally restart from a Beatty set
        if random.random() < 0.3:
            try:
                alpha = random.choice(alphas)
                n = random.randint(20, 100)
                cur = beatty_set(n, alpha)
            except Exception:
                pass

    # Phase 4: final polish with generic local search
    cur = best_set[:]
    cur_score = best_score
    step = 3
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.7 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.9:
            if len(cand) < 500:
                cand.append(random.randint(min(cand) - 50, max(cand) + 50))
        else:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.01:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best_set = cand[:]
        if random.random() < 0.005:
            step = max(1, random.randint(1, 20))

    return sorted(set(best_set))
# EVOLVE-BLOCK-END