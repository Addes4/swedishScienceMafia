# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 100

    def golomb_ruler(n):
        if n <= 1:
            return [0]
        a = [0, 1]
        diffs = {1, -1}
        while len(a) < n:
            x = a[-1] + 1
            while True:
                ok = True
                new_diffs = set()
                for y in a:
                    d1 = x - y
                    d2 = y - x
                    if d1 in diffs or d2 in diffs or d1 in new_diffs or d2 in new_diffs:
                        ok = False
                        break
                    new_diffs.add(d1)
                    new_diffs.add(d2)
                if ok:
                    break
                x += 1
            a.append(x)
            diffs |= new_diffs
        return a

    def quadratic_set(n, M):
        return [i * M + i * i for i in range(n)]

    def geom_set(n):
        return [2**i for i in range(n)]

    def random_set(n):
        return random.sample(range(-1000, 1000), n)

    initial_sets = []
    for n in [10, 20, 30, 40, 50, 60, 80, 100]:
        if time.time() > deadline:
            break
        try:
            a = golomb_ruler(n)
            m = a[-1] // 2
            a = [x - m for x in a]
            initial_sets.append(a)
        except:
            pass
    for n in [20, 30, 40, 50, 60, 80, 100]:
        for M in [100, 1000, 10000, 100000]:
            initial_sets.append(quadratic_set(n, M))
    for n in [10, 20, 30, 40, 50]:
        initial_sets.append(geom_set(n))
    for n in [20, 30, 40, 50, 60, 80, 100]:
        initial_sets.append(random_set(n))

    best_set = None
    best_score = -1.0
    for a in initial_sets:
        if time.time() > deadline:
            break
        s = _score(a)
        if s > best_score:
            best_score = s
            best_set = a[:]

    if best_set is None:
        best_set = [7, 15, 18, 22, -3, -2]
        best_score = _score(best_set)

    cur = best_set[:]
    cur_score = best_score
    T = 0.5
    step = 10
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.5 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.7:
            if len(cand) < 4000:
                cand.append(random.randint(-1000, 1000))
        elif r < 0.85:
            if len(cand) > 2:
                i = random.randrange(len(cand))
                cand.pop(i)
        else:
            if len(cand) >= 2:
                i, j = random.sample(range(len(cand)), 2)
                cand[i], cand[j] = cand[j], cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if any(abs(x) > 1e15 for x in cand):
            continue
        s = _score(cand)
        if s > cur_score or random.random() < math.exp((s - cur_score) / T):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best_set = cand[:]
        if random.random() < 0.01:
            step = max(1, min(1000, int(step * random.uniform(0.8, 1.2))))
        T *= 0.9999
        if T < 1e-6:
            T = 1e-6

    return sorted(set(best_set))
# EVOLVE-BLOCK-END