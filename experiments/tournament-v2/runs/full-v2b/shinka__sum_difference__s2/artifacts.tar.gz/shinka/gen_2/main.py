# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    def init_sidon(n):
        a = [1]
        sums = {2}
        while len(a) < n:
            x = a[-1] + 1
            while True:
                new_sums = {x + y for y in a} | {2*x}
                if len(new_sums) == len(a) + 1 and not (new_sums & sums):
                    break
                x += 1
            sums |= new_sums
            a.append(x)
        return a

    def init_geom(n):
        return [2**i for i in range(n)]

    def init_random(n):
        return random.sample(range(-1000, 1000), n)

    best_set = None
    best_score = -1.0
    deadline = time.time() + 100

    for init_func, ns in [(init_sidon, [30, 50, 80, 120, 200]),
                          (init_geom, [10, 20, 30, 40, 50]),
                          (init_random, [30, 50, 80, 120, 200])]:
        for n in ns:
            if time.time() > deadline:
                break
            try:
                a = init_func(n)
            except:
                continue
            s = _score(a)
            if s > best_score:
                best_score = s
                best_set = a[:]

    if best_set is None:
        best_set = [7, 15, 18, 22, -3, -2]
        best_score = _score(best_set)

    cur = best_set[:]
    cur_score = best_score
    T = 0.1
    step = 10
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.6 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.8:
            if len(cand) < 400:
                cand.append(random.randint(-1000, 1000))
        else:
            if len(cand) > 2:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < math.exp((s - cur_score) / T):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best_set = cand[:]
        if random.random() < 0.01:
            step = max(1, min(1000, int(step * random.uniform(0.8, 1.2))))
        T *= 0.9999
        if T < 1e-6:
            T = 1e-6

    return sorted(set(best_set))
# EVOLVE-BLOCK-END