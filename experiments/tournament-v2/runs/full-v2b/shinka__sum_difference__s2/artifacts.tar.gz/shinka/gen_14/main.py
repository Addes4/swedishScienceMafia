# EVOLVE-BLOCK-START
"""Construct sets with large difference sets and small sum sets.

Strategy:
  1. Sturmian / Beatty seeds, emphasising complementary pairs (phi, phi^2) and
     two-irrational sums, which give the best known baseline ratios.
  2. Greedy extension that maximises the ratio while tracking (d, s).
  3. Sum-collapse local search with a STRICT PARETO FILTER on (|A-A|, |A+A|):
     accept a move only if it does not decrease |A-A| and strictly decreases
     |A+A|, or strictly increases |A-A| without increasing |A+A|.
     Cardinality is preserved (moves that shrink |A| are rejected).
  4. Final polish under the same Pareto filter, with adaptive step decay.

The strict Pareto filter is the key change: it prevents |A+A| from drifting up
near the plateau, which is what held the previous version at ~1.137 instead of
the best known ~1.281.
"""
import math
import random
import time


# ---------------------------------------------------------------- metrics

def _metrics(a):
    """Return (|A-A|, |A+A|) for a list of distinct integers."""
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score_from(d, s, n):
    if s <= 1 or n < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    d, s = _metrics(a)
    return _score_from(d, s, len(a))


# ---------------------------------------------------------------- seeds

def beatty_set(n, alpha, offset=0):
    """Return n distinct integers floor(k*alpha)+offset."""
    vals = []
    seen = set()
    k = 1
    limit = n * 200
    while len(vals) < n and k < limit:
        v = int(math.floor(k * alpha)) + offset
        if v not in seen:
            seen.add(v)
            vals.append(v)
        k += 1
    return vals


def beatty_pair(a1, a2, n):
    """Return {floor(k*a1)+floor(k*a2) : k=1..n}."""
    vals = []
    seen = set()
    for k in range(1, n + 1):
        v = int(math.floor(k * a1)) + int(math.floor(k * a2))
        if v not in seen:
            seen.add(v)
            vals.append(v)
    return vals


# ---------------------------------------------------------------- greedy

def greedy_extend(n, seed, time_limit):
    """Greedily add elements maximising the ratio."""
    deadline = time.time() + time_limit
    a = list(set(seed))
    while len(a) < n and time.time() < deadline:
        base_d, base_s = _metrics(a)
        base_score = _score_from(base_d, base_s, len(a))
        lo = min(a)
        hi = max(a)
        span = max(1, hi - lo)
        candidates = set()
        for _ in range(50):
            candidates.add(random.randint(lo - span // 2, hi + span // 2))
        for x in a:
            candidates.add(x + 1)
            candidates.add(x - 1)
            candidates.add(x + 2)
            candidates.add(x - 2)
        candidates -= set(a)
        if not candidates:
            break
        best_x = None
        best_sc = base_score
        for x in candidates:
            if time.time() > deadline:
                break
            b = a + [x]
            d, s = _metrics(b)
            if s <= 1:
                continue
            sc = math.log(d) / math.log(s)
            if sc > best_sc:
                best_sc = sc
                best_x = x
        if best_x is None:
            best_x = random.randint(lo - span, hi + span)
            if best_x in a:
                best_x += 1
        a.append(best_x)
    return a


# ---------------------------------------------------------------- Pareto

def _pareto_accept(d_old, s_old, d_new, s_new):
    """Strict Pareto improvement on (d, s): d not worse AND s strictly better,
    OR d strictly better AND s not worse."""
    if d_new >= d_old and s_new < s_old:
        return True
    if d_new > d_old and s_new <= s_old:
        return True
    return False


def _pareto_collapse(a, time_limit, min_n):
    """Local search under a strict Pareto filter on (|A-A|, |A+A|).

    Never accepts a move that increases |A+A| without strictly decreasing it
    elsewhere, and never lets |A| drop below min_n (protects the cardinality
    bonus)."""
    deadline = time.time() + time_limit
    a = list(set(a))
    d, s = _metrics(a)
    if s <= 1:
        return a
    best = a[:]
    best_d, best_s = d, s
    cur = a[:]
    cur_d, cur_s = d, s
    n = len(cur)

    while time.time() < deadline:
        cand = cur[:]
        r = random.random()

        if r < 0.55 and len(cand) >= 3:
            # Move one element so that its sum with some other equals a
            # target sum already present -> creates a sum collision.
            i = random.randrange(len(cand))
            others = [cand[j] for j in range(len(cand)) if j != i]
            if len(others) >= 3:
                j1 = random.randrange(len(others))
                j2 = random.randrange(len(others))
                k = random.randrange(len(others))
                target = others[j1] + others[j2]
                cand[i] = target - others[k]
        elif r < 0.8:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-4, 4)
        else:
            if len(cand) >= 3:
                i = random.randrange(len(cand))
                j = random.randrange(len(cand))
                k = random.randrange(len(cand))
                cand[i] = cand[j] - cand[k] + cand[i]

        cand = list(set(cand))
        if len(cand) < min_n or len(cand) < 2:
            continue
        if len(cand) < n:
            # reject cardinality shrinkage
            continue

        d2, s2 = _metrics(cand)
        if s2 <= 1:
            continue

        # Strict Pareto filter on (d, s)
        if _pareto_accept(cur_d, cur_s, d2, s2):
            cur = cand
            cur_d, cur_s = d2, s2
            n = len(cand)
            if (d2 > best_d) or (d2 == best_d and s2 < best_s):
                best = cand[:]
                best_d, best_s = d2, s2
        elif d2 == cur_d and s2 == cur_s:
            # allow lateral moves occasionally to escape plateaus
            if random.random() < 0.01:
                cur = cand
                n = len(cand)
    return best


# ---------------------------------------------------------------- solve

def solve():
    """Return a list of distinct integers maximising log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best_set = None
    best_score = -1e18
    best_d = 0
    best_s = 0

    phi = (1.0 + math.sqrt(5.0)) / 2.0
    alphas = [
        phi,
        math.sqrt(2),
        math.sqrt(3),
        math.sqrt(5),
        1 + math.sqrt(2),
        math.pi,
        math.e,
        1.2207440846057596,
        1.7548776662466927,
    ]
    sizes = [20, 30, 40, 60, 80, 110, 150, 200, 280]

    def consider(a):
        nonlocal best_set, best_score, best_d, best_s
        if len(a) < 2:
            return
        a = list(set(a))
        d, s = _metrics(a)
        sc = _score_from(d, s, len(a))
        if sc > best_score:
            best_score = sc
            best_set = a[:]
            best_d, best_s = d, s

    # Phase 1a: single-irrational Beatty seeds
    for alpha in alphas:
        for n in sizes:
            if time.time() > deadline * 0.20:
                break
            consider(beatty_set(n, alpha))

    # Phase 1b: complementary Beatty pair (phi, phi^2) -- best known baseline
    for n in (40, 80, 150, 260, 400, 600, 900):
        if time.time() > deadline * 0.30:
            break
        consider(beatty_set(n, phi) + beatty_set(n, phi * phi))

    # Phase 1c: two-irrational Beatty sums
    pairs = [
        (phi, math.sqrt(2)),
        (phi, math.sqrt(3)),
        (math.sqrt(2), math.sqrt(3)),
        (phi, math.pi),
        (math.pi, math.e),
    ]
    for (a1, a2) in pairs:
        for n in (60, 120, 220, 380):
            if time.time() > deadline * 0.40:
                break
            consider(beatty_pair(a1, a2, n))

    if best_set is None:
        best_set = [0, 1, 3, 7, 12]
        best_score = _score(best_set)
        best_d, best_s = _metrics(best_set)

    # Phase 2: greedy extension from the best seed
    if time.time() < deadline * 0.55:
        for _ in range(3):
            if time.time() > deadline * 0.55:
                break
            seed = best_set[:min(len(best_set), 14)]
            n_target = min(len(best_set) + 60, 400)
            g = greedy_extend(n_target, seed, time_limit=3.5)
            consider(g)

    # Phase 3: Pareto-filtered sum-collapse
    cur = best_set[:]
    cur_d, cur_s = _metrics(cur)
    min_n = max(2, len(cur) - 5)  # never shrink more than a few elements
    while time.time() < deadline * 0.85:
        remaining = deadline * 0.85 - time.time()
        if remaining <= 0:
            break
        improved = _pareto_collapse(
            cur, time_limit=min(10.0, remaining), min_n=min_n
        )
        d2, s2 = _metrics(improved)
        sc = _score_from(d2, s2, len(improved))
        if sc > best_score:
            best_score = sc
            best_set = improved[:]
            best_d, best_s = d2, s2
        # keep the current best's cardinality as a floor for further work
        if len(improved) > len(cur):
            cur = improved[:]
            cur_d, cur_s = d2, s2
        else:
            cur = improved[:]
            cur_d, cur_s = d2, s2

    # Phase 4: strict-Pareto polish with adaptive step decay
    cur = best_set[:]
    cur_d, cur_s = _metrics(cur)
    n_cur = len(cur)
    step = 3
    stalls = 0
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.75 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.9:
            if len(cand) < 600:
                cand.append(random.randint(min(cand) - 50, max(cand) + 50))
        else:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < n_cur or len(cand) < 2:
            continue
        d2, s2 = _metrics(cand)
        if s2 <= 1:
            continue

        if _pareto_accept(cur_d, cur_s, d2, s2):
            cur = cand
            cur_d, cur_s = d2, s2
            n_cur = len(cand)
            stalls = 0
            if (d2 > best_d) or (d2 == best_d and s2 < best_s):
                best_set = cand[:]
                best_d, best_s = d2, s2
                best_score = _score_from(d2, s2, len(cand))
        else:
            stalls += 1
            if stalls > 400:
                step = max(1, step // 2)
                stalls = 0
                if step == 1 and random.random() < 0.5:
                    # occasionally re-widen to escape
                    step = random.randint(1, 5)

    return sorted(set(best_set))
# EVOLVE-BLOCK-END
