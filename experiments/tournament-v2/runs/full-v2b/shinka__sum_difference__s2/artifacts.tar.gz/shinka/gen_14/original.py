# EVOLVE-BLOCK-START
"""Construct sets with large difference sets and small sum sets using Sturmian
sequences, greedy difference-maximizing construction, and sum-collision local search.

Goal: maximise log|A-A| / log|A+A| (+ small bonus favouring larger |A|).
"""
import math
import random
import time


def _metrics(a):
    """Return (|A-A|, |A+A|) for a list of distinct integers."""
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    d, s = _metrics(list(a))
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def beatty_set(n, alpha, offset=0):
    """Generate n distinct integers floor(k*alpha)+offset."""
    vals = []
    seen = set()
    k = 1
    limit = n * 200
    while len(vals) < n and k < limit:
        v = int(math.floor(k * alpha)) + offset
        if v not in seen:
            seen.add(v)
            vals.append(v)
        k += 1
    return vals


def greedy_extend(n, seed, time_limit):
    """Greedily add elements maximising score, using efficient candidate sampling."""
    deadline = time.time() + time_limit
    a = list(set(seed))
    while len(a) < n and time.time() < deadline:
        base_d, base_s = _metrics(a)
        if base_s <= 1:
            base_score = 0.0
        else:
            base_score = math.log(base_d) / math.log(base_s)
        lo = min(a)
        hi = max(a)
        span = max(1, hi - lo)
        candidates = set()
        # sample candidates from a wide range
        for _ in range(60):
            candidates.add(random.randint(lo - span // 2, hi + span // 2))
        # candidates near existing elements (to create sum collisions)
        for x in a:
            candidates.add(x + 1)
            candidates.add(x - 1)
            candidates.add(x + 2)
            candidates.add(x - 2)
        candidates -= set(a)
        if not candidates:
            break
        best_x = None
        best_sc = base_score
        for x in candidates:
            if time.time() > deadline:
                break
            b = a + [x]
            d, s = _metrics(b)
            if s <= 1:
                continue
            sc = math.log(d) / math.log(s)
            if sc > best_sc:
                best_sc = sc
                best_x = x
        if best_x is None:
            # fall back: add a random far element
            best_x = random.randint(lo - span, hi + span)
            if best_x in a:
                best_x += 1
        a.append(best_x)
    return a


def sum_collapse(a, time_limit):
    """Local search: try to reduce |A+A| while keeping |A-A| large."""
    deadline = time.time() + time_limit
    a = list(set(a))
    d, s = _metrics(a)
    if s <= 1:
        return a
    best = a[:]
    best_sc = math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100
    cur = a[:]
    cur_d, cur_s = d, s
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55 and len(cand) >= 2:
            # shift an element to create a sum collision
            i = random.randrange(len(cand))
            others = [cand[j] for j in range(len(cand)) if j != i]
            if len(others) >= 2:
                j1 = random.randrange(len(others))
                j2 = random.randrange(len(others))
                k = random.randrange(len(others))
                target = others[j1] + others[j2]
                new_val = target - others[k]
                cand[i] = new_val
        elif r < 0.8:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-4, 4)
        else:
            if len(cand) >= 3:
                i = random.randrange(len(cand))
                j = random.randrange(len(cand))
                k = random.randrange(len(cand))
                cand[i] = cand[j] - cand[k] + cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        d2, s2 = _metrics(cand)
        if s2 <= 1:
            continue
        sc = math.log(d2) / math.log(s2) + (1 - 1 / len(cand)) / 100
        if sc > best_sc or random.random() < 0.02:
            cur = cand
            cur_d, cur_s = d2, s2
            if sc > best_sc:
                best_sc = sc
                best = cand[:]
    return best


def solve():
    """Return a list of distinct integers maximising log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best_set = None
    best_score = -1e18

    alphas = [
        (1 + math.sqrt(5)) / 2,
        math.sqrt(2),
        math.sqrt(3),
        math.sqrt(5),
        1 + math.sqrt(2),
        math.pi,
        math.e,
        2.414213562373095,
        1.6180339887498949,
        1.7320508075688772,
        2.718281828459045,
        1.4142135623730951,
    ]
    sizes = [20, 30, 40, 50, 60, 80, 100, 150, 200, 300]

    # Phase 1: Beatty/Sturmian seeds
    for alpha in alphas:
        for n in sizes:
            if time.time() > deadline * 0.35:
                break
            try:
                a = beatty_set(n, alpha)
                s = _score(a)
                if s > best_score:
                    best_score = s
                    best_set = a[:]
            except Exception:
                continue

    # Phase 2: greedy extension from good seeds
    if best_set is not None:
        for _ in range(4):
            if time.time() > deadline * 0.55:
                break
            try:
                seed = best_set[:min(len(best_set), 12)]
                n_target = min(len(best_set) + 40, 350)
                g = greedy_extend(n_target, seed, time_limit=4.0)
                s = _score(g)
                if s > best_score:
                    best_score = s
                    best_set = g[:]
            except Exception:
                continue

    if best_set is None:
        best_set = [0, 1, 3, 7, 12]
        best_score = _score(best_set)

    # Phase 3: sum-collapse local search
    cur = best_set[:]
    while time.time() < deadline * 0.95:
        try:
            improved = sum_collapse(cur, time_limit=min(12.0, deadline - time.time()))
            s = _score(improved)
            if s > best_score:
                best_score = s
                best_set = improved[:]
            cur = improved
        except Exception:
            break
        if random.random() < 0.35:
            try:
                alpha = random.choice(alphas)
                n = random.randint(20, 150)
                cur = beatty_set(n, alpha)
            except Exception:
                pass

    # Phase 4: final polish
    cur = best_set[:]
    cur_score = best_score
    step = 3
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.7 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.9:
            if len(cand) < 500:
                cand.append(random.randint(min(cand) - 50, max(cand) + 50))
        else:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.01:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best_set = cand[:]
        if random.random() < 0.005:
            step = max(1, random.randint(1, 20))

    return sorted(set(best_set))
# EVOLVE-BLOCK-END
