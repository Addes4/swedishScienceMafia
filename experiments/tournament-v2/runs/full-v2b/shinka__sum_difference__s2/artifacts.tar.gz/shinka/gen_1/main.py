# EVOLVE-BLOCK-START
"""Improved solver: hybrid Golomb-ruler / Sidon-set construction with local search."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _stats(a):
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    return len(diffs), len(sums)


def greedy_golomb(n, max_val=None, seed=0):
    """Greedy construction: add smallest integer keeping all differences distinct."""
    rng = random.Random(seed)
    marks = [0]
    used_diffs = {0}
    candidate = 1
    while len(marks) < n:
        ok = True
        new_diffs = []
        for m in marks:
            d = candidate - m
            if d in used_diffs:
                ok = False
                break
            new_diffs.append(d)
        if ok:
            for m in marks:
                used_diffs.add(candidate - m)
                used_diffs.add(m - candidate)
            marks.append(candidate)
            candidate += 1
        else:
            candidate += 1
            if max_val is not None and candidate > max_val:
                break
    return marks


def greedy_sidon_like(n, seed=0):
    """Greedy construction with small sum set bias: prefer candidates that don't
    create too many new sums."""
    rng = random.Random(seed)
    marks = [0, 1]
    while len(marks) < n:
        best_c = None
        best_cost = None
        # try candidates in a window after the last mark
        start = marks[-1] + 1
        for c in range(start, start + 60):
            new_diffs = 0
            new_sums = 0
            diffs = set()
            sums = set()
            for m in marks:
                diffs.add(c - m)
                diffs.add(m - c)
                sums.add(c + m)
            # count new diffs
            existing_diffs = set()
            for x in marks:
                for y in marks:
                    existing_diffs.add(x - y)
            existing_sums = set()
            for x in marks:
                for y in marks:
                    existing_sums.add(x + y)
            nd = len(diffs - existing_diffs)
            ns = len(sums - existing_sums)
            # cost: want many new diffs, few new sums
            cost = ns - nd * 0.5
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_c = c
        if best_c is None:
            best_c = marks[-1] + 1
        marks.append(best_c)
    return marks


def local_search(a, deadline, best_global):
    """Hill-climb on the score with add/shift/remove moves."""
    a = list(a)
    cur_score = _score(a)
    best = a[:]
    best_score = cur_score
    n = len(a)
    while time.time() < deadline:
        move = random.random()
        cand = a[:]
        if move < 0.5 and cand:
            # shift one element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif move < 0.8:
            # add an element
            cand.append(random.randint(-50, 200))
        elif move < 0.95 and len(cand) > 3:
            # remove an element
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # shift whole set
            shift = random.randint(-10, 10)
            cand = [x + shift for x in cand]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score:
            a = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif random.random() < 0.02:
            a = cand
            cur_score = s
    return best, best_score


def solve():
    """Hybrid search for sets maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 100
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Strategy 1: greedy Golomb rulers of various sizes
    for n in [20, 40, 60, 80, 100, 150, 200, 300]:
        if time.time() > deadline:
            break
        g = greedy_golomb(n)
        if len(g) >= 2:
            s = _score(g)
            if s > best_score:
                best, best_score = g[:], s

    # Strategy 2: Sidon-like greedy
    for n in [20, 40, 60, 80, 100, 150, 200]:
        if time.time() > deadline:
            break
        g = greedy_sidon_like(n)
        if len(g) >= 2:
            s = _score(g)
            if s > best_score:
                best, best_score = g[:], s

    # Strategy 3: local search from best starting points
    starts = [
        [0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96, 122, 147, 181, 203, 251, 289],
        [0, 1, 4, 10, 18, 23, 25, 29, 36, 46, 55, 63, 80, 96, 118, 141],
        [0, 1, 3, 8, 12, 18, 27, 34, 44, 55, 67, 79, 92, 106, 121, 137],
        [0, 1, 4, 9, 15, 22, 32, 34, 45, 57, 70, 84, 99, 115, 132, 150],
    ]
    for st in starts:
        if time.time() > deadline:
            break
        s = _score(st)
        if s > best_score:
            best, best_score = st[:], s
        b, bs = local_search(st, min(deadline, time.time() + 8), best)
        if bs > best_score:
            best, best_score = b[:], bs

    # Strategy 4: random restarts + local search
    while time.time() < deadline:
        n = random.randint(6, 40)
        a = sorted(random.sample(range(-100, 300), n))
        s = _score(a)
        if s > best_score:
            best, best_score = a[:], s
        b, bs = local_search(a, min(deadline, time.time() + 3), best)
        if bs > best_score:
            best, best_score = b[:], bs

    return sorted(set(best))
# EVOLVE-BLOCK-END
