# EVOLVE-BLOCK-START
"""Construct sets with large difference set and small sum set.

Novel approach: explicitly design A = core ∪ tail where
  - core is a dense small-span set (e.g. {0,1,...,k} or AP) giving |core+core| small,
  - tail is a set of well-separated large elements giving |A-A| large.
Then refine with a targeted local search that perturbs only the core to further
reduce |A+A| while preserving the tail's contribution to |A-A|.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _metrics(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score_from(d, s, n):
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


# ---------------------------------------------------------------------------
# Structural constructions
# ---------------------------------------------------------------------------

def _dense_core(k, kind="ap"):
    """Return a small-span set of size ~k with small sum set."""
    if kind == "ap":
        return list(range(k))
    if kind == "ap_shift":
        return list(range(k)) + [k + 2]
    if kind == "quad":
        # quadratic residues mod p, chosen so sum set stays in [0, 2p]
        p = 2 * k + 1
        return sorted({(i * i) % p for i in range(k)})
    if kind == "gp":
        # geometric-ish small span
        return sorted({int(round((1.3 ** i))) for i in range(k)})
    if kind == "squares":
        return [i * i for i in range(k)]
    return list(range(k))


def _tail(n_tail, base_offset, spacing, jitter=0):
    """Well-separated tail: distinct large values, spacing chosen to be generic."""
    out = []
    v = base_offset
    for i in range(n_tail):
        out.append(v)
        step = spacing + (jitter and random.randint(0, jitter))
        v += max(1, step)
    return out


def _combine(core, tail):
    return sorted(set(core) | set(tail))


# ---------------------------------------------------------------------------
# Targeted local search on the core only (tail fixed)
# ---------------------------------------------------------------------------

def _core_refine(core, tail, deadline, span_hint):
    """Perturb only the core, keeping tail fixed. Try to reduce |A+A| while
    keeping |A-A| from shrinking."""
    core = list(set(core))
    tail = list(set(tail))
    combined = _combine(core, tail)
    d, s = _metrics(combined)
    best_score = _score_from(d, s, len(combined))
    best_core = core[:]
    best_d, best_s = d, s

    cur_core = core[:]
    cur_d, cur_s = d, s
    cur_score = best_score

    # temperature schedule based on remaining time
    t0 = time.time()
    total = max(1e-3, deadline - t0)

    while time.time() < deadline:
        cand_core = cur_core[:]
        if not cand_core:
            break
        frac = max(0.0, min(1.0, (deadline - time.time()) / total))
        temp = max(0.03, frac)

        op = random.random()
        if op < 0.55:
            # shift an element by a scale-aware step
            i = random.randrange(len(cand_core))
            span = max(cand_core) - min(cand_core) if len(cand_core) > 1 else 1
            span = max(1, span)
            mags = [1, 2, max(1, span // 50), max(1, span // 10), max(1, span // 3)]
            w = [math.exp(-abs(math.log(m)) / temp) for m in mags]
            tot = sum(w)
            r = random.random() * tot
            acc = 0.0
            mag = mags[-1]
            for m, ww in zip(mags, w):
                acc += ww
                if r <= acc:
                    mag = m
                    break
            cand_core[i] += random.choice([-1, 1]) * mag
        elif op < 0.8:
            # snap an element to create a sum collision
            if len(cand_core) >= 2:
                i = random.randrange(len(cand_core))
                others = [cand_core[j] for j in range(len(cand_core)) if j != i]
                others += tail
                if len(others) >= 2:
                    j1 = random.randrange(len(others))
                    j2 = random.randrange(len(others))
                    target = others[j1] + others[j2]
                    k = random.randrange(len(others))
                    new_val = target - others[k]
                    cand_core[i] = new_val
        else:
            # add or remove a core element
            if len(cand_core) > 2 and random.random() < 0.4:
                i = random.randrange(len(cand_core))
                cand_core.pop(i)
            else:
                span = max(cand_core) - min(cand_core) if len(cand_core) > 1 else 1
                span = max(1, span)
                lo = min(cand_core) - span
                hi = max(cand_core) + span
                cand_core.append(random.randint(lo, hi))

        cand_core = list(set(cand_core))
        if len(cand_core) < 1:
            continue
        combined = _combine(cand_core, tail)
        if len(combined) < 2:
            continue
        d, s = _metrics(combined)
        sc = _score_from(d, s, len(combined))
        if sc > cur_score or random.random() < 0.05 * temp:
            cur_core = cand_core
            cur_score = sc
            cur_d, cur_s = d, s
            if sc > best_score:
                best_score = sc
                best_core = cand_core[:]
                best_d, best_s = d, s

    return best_core, tail, best_score


# ---------------------------------------------------------------------------
# Main solve
# ---------------------------------------------------------------------------

def solve():
    deadline = time.time() + 110
    best = [0, 1, 3, 7]
    best_score = _score(best)

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2:
            return
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # -------- Phase 1: structural seeds --------
    # Try many (core, tail) combinations
    core_kinds = ["ap", "ap_shift", "quad", "gp", "squares"]
    tail_specs = []
    for base in (10, 50, 200, 1000, 5000, 20000):
        for spacing in (3, 5, 7, 11, 17, 31, 101, 1009):
            tail_specs.append((base, spacing))

    for kind in core_kinds:
        for k in (5, 8, 12, 18, 25, 40, 60):
            if time.time() > deadline * 0.25:
                break
            core = _dense_core(k, kind)
            # normalize core to start at 0
            mn = min(core)
            core = [c - mn for c in core]
            for (base, spacing) in tail_specs:
                for nt in (3, 6, 10, 15, 25):
                    if time.time() > deadline * 0.25:
                        break
                    tail = _tail(nt, base, spacing)
                    consider(_combine(core, tail))

    # Also try pure Beatty-like sets as fallback
    alphas = [
        (1 + math.sqrt(5)) / 2,
        math.sqrt(2), math.sqrt(3), math.sqrt(5),
        1 + math.sqrt(2), math.pi, math.e,
    ]
    for alpha in alphas:
        for n in (30, 60, 100, 150, 220, 320):
            if time.time() > deadline * 0.3:
                break
            vals = []
            seen = set()
            k = 1
            while len(vals) < n and k < n * 50:
                v = int(math.floor(k * alpha))
                if v not in seen:
                    seen.add(v)
                    vals.append(v)
                k += 1
            consider(vals)

    # -------- Phase 2: refine best seed's core --------
    cur_best = best[:]
    cur_best_score = best_score

    # split current best into "core" (dense cluster) and "tail"
    def split_core_tail(a, core_size):
        a = sorted(set(a))
        if core_size >= len(a):
            return a[:], []
        # core = the core_size elements with smallest span when clustered
        # simple heuristic: take the contiguous cluster with smallest span
        best_i, best_span = 0, float("inf")
        for i in range(len(a) - core_size + 1):
            span = a[i + core_size - 1] - a[i]
            if span < best_span:
                best_span = span
                best_i = i
        core = a[best_i:best_i + core_size]
        tail = a[:best_i] + a[best_i + core_size:]
        return core, tail

    while time.time() < deadline * 0.95:
        remaining = deadline - time.time()
        if remaining < 2:
            break

        # choose a core size and split
        n = len(cur_best)
        if n < 4:
            core_size = max(1, n - 1)
        else:
            # try a few core sizes
            core_size = random.choice([
                max(2, n // 4), max(3, n // 3), max(4, n // 2),
                max(5, (2 * n) // 3), max(6, (3 * n) // 4),
            ])
            core_size = min(core_size, n - 1)
        core, tail = split_core_tail(cur_best, core_size)
        if not core:
            core = cur_best[:1]
        time_slice = min(remaining * 0.4, 8.0)
        new_core, tail, sc = _core_refine(
            core, tail, time.time() + time_slice, span_hint=None
        )
        improved = _combine(new_core, tail)
        s = _score(improved)
        if s > cur_best_score:
            cur_best_score = s
            cur_best = sorted(set(improved))
            if s > best_score:
                best_score = s
                best = cur_best[:]

        # occasionally restart from a fresh structural seed
        if random.random() < 0.35:
            kind = random.choice(core_kinds)
            k = random.randint(4, 30)
            core = _dense_core(k, kind)
            mn = min(core)
            core = [c - mn for c in core]
            base = random.choice([10, 50, 200, 1000, 5000])
            spacing = random.choice([3, 5, 7, 11, 17, 31, 101])
            nt = random.randint(3, 20)
            tail = _tail(nt, base, spacing)
            cur_best = _combine(core, tail)
            cur_best_score = _score(cur_best)
            if cur_best_score > best_score:
                best_score = cur_best_score
                best = cur_best[:]

    # -------- Phase 3: final generic polish with adaptive steps --------
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        remaining = max(0.0, deadline - time.time())
        temp = max(0.05, min(1.0, remaining / 30.0))
        span = max(cand) - min(cand) if cand else 1
        span = max(1, span)
        mags = [1, 2, max(1, span // 100), max(1, span // 20), max(1, span // 4)]
        w = [math.exp(-abs(math.log(m)) / temp) for m in mags]
        tot = sum(w)
        rr = random.random() * tot
        acc = 0.0
        mag = mags[-1]
        for m, ww in zip(mags, w):
            acc += ww
            if rr <= acc:
                mag = m
                break

        if r < 0.7 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * mag
        elif r < 0.9:
            if len(cand) < 2000:
                cand.append(random.randint(min(cand) - span, max(cand) + span))
        else:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.01:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END