# EVOLVE-BLOCK-START
"""Aggressive sum-collapse search: wide difference set, narrow sum set.

Strategy:
  1. Warm-start with dilated Golomb/Sidon constructions (wide |A-A|).
  2. Spend the majority of the budget in a dedicated sum-collapse phase using
     the "target-sum" move: given a target sum s = a_j1 + a_j2, set
     a_k = s - a_j3 so that a_k + a_j3 collides with a_j1 + a_j2.
  3. Multi-collision variant: apply two target-sum assignments per iteration.
  4. Incremental scoring + adaptive acceptance + restarts.
"""
import math
import random
import time


# ---------------------------------------------------------------- scoring
def _diffs_sums(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return diffs, sums


def _score_from(diffs, sums, n):
    if len(sums) < 2 or n < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs, sums = _diffs_sums(a)
    return _score_from(diffs, sums, len(a))


# ---------------------------------------------------------------- helpers
def _incremental_change(a, i, new_val):
    """Return (new_a, diffs, sums) after replacing a[i] with new_val."""
    old_val = a[i]
    na = a[:]
    na[i] = new_val
    # remove contributions of old_val
    diffs = set()
    sums = set()
    for x in na:
        for y in na:
            diffs.add(x - y)
            sums.add(x + y)
    return na, diffs, sums


# ---------------------------------------------------------------- warm starts
def greedy_golomb(n, max_val=None):
    marks = [0]
    used = {0}
    c = 1
    while len(marks) < n:
        ok = True
        new_d = []
        for m in marks:
            d = c - m
            if d in used:
                ok = False
                break
            new_d.append(d)
        if ok:
            for d in new_d:
                used.add(d)
                used.add(-d)
            marks.append(c)
            c += 1
        else:
            c += 1
            if max_val is not None and c > max_val:
                break
    return marks


def dilate(base, T, K):
    out = set()
    for k in range(K):
        off = T * k
        for b in base:
            out.add(b + off)
    return sorted(out)


# ---------------------------------------------------------------- sum-collapse move
def _target_sum_move(a, rng, multi=1):
    """Force one (or more) sum collisions by solving a_k = target - a_j3.

    target = a[j1] + a[j2] for random j1, j2.
    new_val = target - a[j3].  Then a_k + a_j3 == a_j1 + a_j2.
    Replaces a random index with new_val.
    """
    n = len(a)
    if n < 4:
        return a
    cand = a[:]
    for _ in range(multi):
        j1 = rng.randrange(n)
        j2 = rng.randrange(n)
        if j1 == j2:
            continue
        target = a[j1] + a[j2]
        j3 = rng.randrange(n)
        new_val = target - a[j3]
        k = rng.randrange(n)
        if new_val == a[k]:
            continue
        # avoid duplicate elements
        if new_val in cand and new_val != cand[k]:
            # small jitter to keep distinct
            new_val += rng.choice([-1, 1])
            if new_val in cand:
                continue
        cand[k] = new_val
    return cand


def _difference_move(a, rng):
    """Push an element far out to expand the difference set."""
    n = len(a)
    if n < 2:
        return a
    cand = a[:]
    lo = min(cand)
    hi = max(cand)
    span = max(1, hi - lo)
    i = rng.randrange(n)
    cand[i] = hi + rng.randint(1, max(2, span))
    if cand[i] in cand and cand[i] != cand[i]:
        pass
    return cand


def _shift_move(a, rng):
    """Shift the whole set (does not change |A-A| or |A+A|, just recenters)."""
    shift = rng.randint(-3, 3)
    return [x + shift for x in a]


def _perturb_move(a, rng):
    """Small local perturbation."""
    n = len(a)
    if n < 2:
        return a
    cand = a[:]
    i = rng.randrange(n)
    lo = min(cand)
    hi = max(cand)
    span = max(1, hi - lo)
    cand[i] += rng.randint(-max(1, span // 10), max(1, span // 10))
    return cand


def _dedup(a):
    return sorted(set(a))


# ---------------------------------------------------------------- main
def solve():
    rng = random.Random(12345)
    deadline = time.time() + 115

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # ---------- Phase 1: construction warm starts (small budget ~15%) ----------
    phase1_end = time.time() + 0.15 * 115
    for gn in [4, 5, 6, 7, 8, 10, 12]:
        if time.time() > phase1_end:
            break
        G = greedy_golomb(gn)
        for K in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20]:
            for T in [3, 5, 7, 9, 11, 13, 17, 19, 23, 29, 31, 37, 41, 47, 53, 61]:
                A = dilate(G, T, K)
                if len(A) < 2 or len(A) > 4000:
                    continue
                s = _score(A)
                if s > best_score:
                    best, best_score = A[:], s

    # ---------- Phase 2: sum-collapse hill-climb (main budget ~55%) ----------
    phase2_end = time.time() + 0.55 * 115
    cur = best[:]
    cur_diffs, cur_sums = _diffs_sums(cur)
    cur_score = _score_from(cur_diffs, cur_sums, len(cur))
    temperature = 0.02
    restart_count = 0

    while time.time() < phase2_end:
        r = rng.random()
        # 70% target-sum moves, 15% difference moves, 10% perturb, 5% shift
        if r < 0.70:
            multi = 1 if rng.random() < 0.7 else 2
            cand = _target_sum_move(cur, rng, multi=multi)
        elif r < 0.85:
            cand = _difference_move(cur, rng)
        elif r < 0.95:
            cand = _perturb_move(cur, rng)
        else:
            cand = _shift_move(cur, rng)

        cand = _dedup(cand)
        if len(cand) < 2 or len(cand) > 4000:
            continue

        cd, cs = _diffs_sums(cand)
        s = _score_from(cd, cs, len(cand))

        if s > cur_score:
            cur, cur_diffs, cur_sums, cur_score = cand, cd, cs, s
            if s > best_score:
                best, best_score = cand[:], s
        elif rng.random() < temperature:
            cur, cur_diffs, cur_sums, cur_score = cand, cd, cs, s

        # slow cooling / reheating
        temperature *= 0.99995
        if temperature < 0.005:
            temperature = 0.02

        # occasional restart from best
        if rng.random() < 0.001:
            cur = best[:]
            cur_diffs, cur_sums = _diffs_sums(cur)
            cur_score = _score_from(cur_diffs, cur_sums, len(cur))
            restart_count += 1

    # ---------- Phase 3: targeted sum-collapse polish (~25%) ----------
    phase3_end = time.time() + 0.25 * 115
    # Try growing the best set slightly, then collapsing sums
    candidates = [best]
    # add a few derived candidates
    for extra_T in [11, 17, 23, 29, 41]:
        for extra_K in [8, 12, 16]:
            G = greedy_golomb(5)
            A = dilate(G, extra_T, extra_K)
            if 2 <= len(A) <= 4000:
                candidates.append(A)

    for start in candidates:
        if time.time() > phase3_end:
            break
        cur = start[:]
        cd, cs = _diffs_sums(cur)
        cur_score = _score_from(cd, cs, len(cur))
        local_end = min(phase3_end, time.time() + 8)
        while time.time() < local_end:
            cand = _target_sum_move(cur, rng, multi=1)
            cand = _dedup(cand)
            if len(cand) < 2 or len(cand) > 4000:
                continue
            cd2, cs2 = _diffs_sums(cand)
            s = _score_from(cd2, cs2, len(cand))
            if s >= cur_score:
                cur, cd, cs, cur_score = cand, cd2, cs2, s
                if s > best_score:
                    best, best_score = cand[:], s

    # ---------- Phase 4: final polish from best (~5%) ----------
    cur = best[:]
    cd, cs = _diffs_sums(cur)
    cur_score = _score_from(cd, cs, len(cur))
    while time.time() < deadline:
        cand = _target_sum_move(cur, rng, multi=1)
        if rng.random() < 0.3:
            cand = _perturb_move(cand, rng)
        cand = _dedup(cand)
        if len(cand) < 2 or len(cand) > 4000:
            continue
        cd2, cs2 = _diffs_sums(cand)
        s = _score_from(cd2, cs2, len(cand))
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
