# EVOLVE-BLOCK-START
"""Cauchy–Davenport style construction: wide difference set, narrow sum set."""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build_base(n, modulus):
    """Residue-class base: choose n residues mod `modulus` that are spread out."""
    residues = []
    step = modulus // n if n else 1
    if step < 1:
        step = 1
    for i in range(n):
        r = (i * step) % modulus
        residues.append(r)
    return residues


def _filter_sum_band(base, scale, band):
    """Keep elements whose pairwise sums fall within a narrow band."""
    elems = sorted(base)
    kept = []
    for x in elems:
        ok = True
        for y in kept:
            if abs((x + y) - band) > scale:
                ok = False
                break
        if ok:
            kept.append(x)
    return kept


def _expand_geometric(base, levels, factor):
    """Expand a base set by geometric scaling to multiply differences."""
    result = set(base)
    cur = set(base)
    for _ in range(levels):
        nxt = set()
        for v in cur:
            nxt.add(v * factor)
        result |= nxt
        cur = nxt
    return sorted(result)


def _greedy_refine(A, budget):
    """Greedy pass: try adding/removing elements to improve the ratio."""
    A = list(set(A))
    best = A[:]
    best_score = _score(best)
    deadline = time.time() + budget
    while time.time() < deadline:
        improved = False
        # try adding candidates near the extremes
        lo = min(best) if best else 0
        hi = max(best) if best else 0
        span = (hi - lo) if hi > lo else 1
        for delta in (span // 3, span // 2, span, -span // 3, -span // 2):
            cand = best + [hi + delta] if delta >= 0 else best + [lo + delta]
            cand = sorted(set(cand))
            s = _score(cand)
            if s > best_score:
                best, best_score = cand, s
                improved = True
                break
        if not improved:
            # try removing the least useful element
            for i in range(len(best)):
                cand = best[:i] + best[i + 1:]
                s = _score(cand)
                if s > best_score:
                    best, best_score = cand, s
                    improved = True
                    break
        if not improved:
            break
    return best


def solve():
    """Return a list of distinct integers A maximising log|A-A|/log|A+A|."""
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Stage 1: try several small-n Cauchy–Davenport style bases
    for n in range(4, 10):
        modulus = max(53, n * 7 + 1)
        base = _build_base(n, modulus)
        # map residues into a small integer window
        base = [r - modulus // 2 for r in base]
        # Stage 2: expand geometrically
        for levels in (1, 2, 3):
            for factor in (2, 3, 5):
                expanded = _expand_geometric(base, levels, factor)
                if len(expanded) < 2 or len(expanded) > 4000:
                    continue
                s = _score(expanded)
                if s > best_score:
                    best, best_score = expanded[:], s

    # Stage 3: try a symmetric "arithmetic + geometric" hybrid
    for k in range(3, 8):
        arith = list(range(-k, k + 1))
        for factor in (2, 3, 4):
            hybrid = sorted(set(arith + [v * factor for v in arith]))
            if len(hybrid) > 4000:
                continue
            s = _score(hybrid)
            if s > best_score:
                best, best_score = hybrid[:], s

    # Stage 4: greedy refinement on the current best
    refined = _greedy_refine(best, budget=8)
    rs = _score(refined)
    if rs > best_score:
        best, best_score = refined, rs

    # Stage 5: final short random-walk polish
    import random
    deadline = time.time() + 4
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-2, 2)
        if random.random() < 0.05 and len(cand) < 4000:
            cand.append(cand[random.randrange(len(cand))] + random.randint(-5, 5))
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.1:
            cur = best[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
