# EVOLVE-BLOCK-START
"""Structured construction + tabu search with diversity-preserving elite pool."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


# Near-optimal Golomb rulers used as Sidon-like building blocks.
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 106, 110, 113],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 106, 110, 113, 121, 125, 128],
]


def _symmetric_seed(n, rng):
    """Build A = (-G) ∪ {0} ∪ G from a Golomb ruler G.
    This creates heavy sum symmetry (a+(-a)=0) while differences from the
    Sidon structure remain distinct."""
    k = max(2, (n - 1) // 2)
    k = min(k, len(_GOLOMB))
    G = _GOLOMB[k - 1]
    scale = rng.choice([1, 2, 3, 5])
    shift = rng.randint(-20, 20)
    Gs = [g * scale + shift for g in G]
    A = set()
    for g in Gs:
        A.add(g)
        A.add(-g)
    A.add(0)
    A = list(A)
    # pad if needed
    while len(A) < n:
        v = rng.randint(-scale * 100, scale * 100)
        if v not in A:
            A.append(v)
    return A[:n] if len(A) > n else A


def _golomb_seed(n, rng):
    k = min(max(2, n), len(_GOLOMB))
    G = _GOLOMB[k - 1]
    scale = rng.choice([1, 2, 3, 5, 8])
    shift = rng.randint(-30, 30)
    A = [g * scale + shift + rng.randint(-1, 1) for g in G]
    A = list(set(A))
    while len(A) < n:
        v = rng.randint(-scale * 100, scale * 100)
        if v not in A:
            A.append(v)
    return A


def _tabu_search(seed, deadline, rng, tabu_tenure=7, max_iters=100000):
    """Steepest-ascent / tabu search over single-element moves."""
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    tabu = {}  # (index_value_key) -> expiry iteration
    iter_no = 0
    no_improve = 0

    while time.time() < deadline and iter_no < max_iters:
        iter_no += 1
        if not cur:
            break
        # Determine a reasonable step size for this set
        span = max(cur) - min(cur) if len(cur) > 1 else 1
        step_cap = max(1, span // 4)

        # Candidate moves: perturb one element, or add/remove
        candidates = []
        # perturb each element by a few step sizes
        for i in range(len(cur)):
            for step in (1, -1, 2, -2, 3, -3):
                cand = cur[:]
                cand[i] += step
                if cand[i] in cand[:i] + cand[i+1:]:
                    continue
                candidates.append(cand)
        # add a new element near boundary
        if len(cur) < 60:
            lo, hi = min(cur), max(cur)
            for _ in range(3):
                v = rng.randint(lo - span, hi + span)
                if v not in cur:
                    candidates.append(cur + [v])
        # remove an element
        if len(cur) > 4:
            for _ in range(2):
                i = rng.randrange(len(cur))
                candidates.append(cur[:i] + cur[i+1:])

        if not candidates:
            break

        rng.shuffle(candidates)
        # Evaluate a bounded number of candidates for speed
        eval_cap = 200
        best_move = None
        best_move_score = -1e18
        for cand in candidates[:eval_cap]:
            key = (len(cand), frozenset(cand))
            s = _score(cand)
            is_tabu = tabu.get(key, -1) > iter_no
            if is_tabu and s <= best_score:
                continue
            if s > best_move_score:
                best_move_score = s
                best_move = cand

        if best_move is None:
            # All moves tabu: pick a random non-tabu one
            for cand in candidates:
                key = (len(cand), frozenset(cand))
                if tabu.get(key, -1) <= iter_no:
                    best_move = cand
                    best_move_score = _score(cand)
                    break
            if best_move is None:
                break

        key = (len(best_move), frozenset(best_move))
        tabu[key] = iter_no + tabu_tenure + rng.randint(0, 3)
        # prune tabu occasionally
        if iter_no % 500 == 0:
            tabu = {k: v for k, v in tabu.items() if v > iter_no}
        cur = best_move
        cur_score = best_move_score
        if cur_score > best_score + 1e-12:
            best = cur[:]
            best_score = cur_score
            no_improve = 0
        else:
            no_improve += 1
            if no_improve > 300:
                # diversify: perturb randomly
                cur = cur[:]
                i = rng.randrange(len(cur))
                cur[i] += rng.randint(-step_cap, step_cap)
                cur = list(set(cur))
                cur_score = _score(cur)
                no_improve = 0

    return best, best_score


def _jaccard(a, b):
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    return len(sa & sb) / max(1, len(sa | sb))


def solve():
    rng = random.Random(20240517)
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Diversity-preserving elite pool
    elite = [(best[:], best_score)]
    ELITE_CAP = 12
    JACCARD_MIN = 0.3

    def try_add_elite(sol, sc):
        for _, es in elite:
            if _jaccard(sol, es) > JACCARD_MIN:
                return False
        elite.append((sol[:], sc))
        elite.sort(key=lambda x: -x[1])
        if len(elite) > ELITE_CAP:
            elite.pop()
        return True

    # Build seed list
    seeds = []
    for n in range(5, 22):
        seeds.append(('sym', n))
        seeds.append(('gol', n))
    rng.shuffle(seeds)

    idx = 0
    while time.time() < deadline:
        remaining = deadline - time.time()
        if remaining <= 0:
            break
        if idx < len(seeds):
            kind, n = seeds[idx]
            idx += 1
            if kind == 'sym':
                seed = _symmetric_seed(n, rng)
            else:
                seed = _golomb_seed(n, rng)
        else:
            # restart from a random elite member (diversified) or fresh
            if elite and rng.random() < 0.7:
                src = rng.choice(elite)[0]
                seed = src[:]
                # mutate to diversify
                for _ in range(rng.randint(1, 3)):
                    if seed:
                        i = rng.randrange(len(seed))
                        seed[i] += rng.randint(-5, 5)
                seed = list(set(seed))
            else:
                n = rng.randint(5, 20)
                seed = _symmetric_seed(n, rng) if rng.random() < 0.5 else _golomb_seed(n, rng)

        slice_end = time.time() + max(0.5, remaining / 10)
        cand, s = _tabu_search(seed, slice_end, rng,
                               tabu_tenure=rng.randint(5, 12))
        if s > best_score:
            best, best_score = cand[:], s
        try_add_elite(cand, s)

        # Occasionally intensify on the best
        if time.time() < deadline and rng.random() < 0.5:
            slice_end = time.time() + max(0.5, (deadline - time.time()) / 8)
            cand2, s2 = _tabu_search(best[:], slice_end, rng,
                                     tabu_tenure=rng.randint(3, 8))
            if s2 > best_score:
                best, best_score = cand2[:], s2
            try_add_elite(cand2, s2)

    return sorted(set(best))
# EVOLVE-BLOCK-END