# EVOLVE-BLOCK-START
"""Constructive search: build near-perfect Golomb rulers (max difference set)
with minimum possible span (min sum set), then repair for sum-collisions.

Key fact: for A with all pairwise differences distinct, |A-A| = n(n-1)+1 (maximum).
If A ⊂ [0, m], then |A+A| ≤ 2m+1. So minimizing the span m of a Golomb ruler
of size n directly minimizes |A+A| and hence maximizes the ratio.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


# Known optimal Golomb rulers (minimum length for each size). These give the
# maximum possible |A-A| = n(n-1)+1 for each n with minimal span -> minimal |A+A|.
_OPTIMAL_RULERS = {
    2:  [0, 1],
    3:  [0, 1, 3],
    4:  [0, 1, 4, 6],
    5:  [0, 1, 4, 9, 11],
    6:  [0, 1, 4, 10, 12, 17],
    7:  [0, 1, 4, 10, 18, 23, 25],
    8:  [0, 1, 4, 9, 15, 22, 32, 34],
    9:  [0, 1, 5, 12, 25, 27, 35, 41, 44],
    10: [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    11: [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    12: [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],  # len 13 (12 not exact)
    13: [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    14: [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    16: [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111],
}


def _is_golomb(ruler):
    """Check all pairwise differences are distinct."""
    diffs = set()
    n = len(ruler)
    for i in range(n):
        for j in range(i + 1, n):
            d = ruler[j] - ruler[i]
            if d in diffs:
                return False
            diffs.add(d)
    return True


def _greedy_golomb(n, rng, deadline, tries=200):
    """Greedy randomized construction of a Golomb ruler of size n.
    Start with {0,1}, repeatedly add the smallest valid value (with random
    restarts). Stop early if deadline exceeded."""
    best = None
    best_span = None
    attempt = 0
    while attempt < tries and time.time() < deadline:
        attempt += 1
        ruler = [0, 1]
        diffs = {1}
        ok = True
        while len(ruler) < n:
            # candidate extensions: try small values first, randomized among
            # the smallest few valid options
            last = ruler[-1]
            candidates = []
            start = last + 1
            # search up to some bound
            for v in range(start, start + 4 * n * n + 50):
                good = True
                for x in ruler:
                    d = v - x
                    if d in diffs:
                        good = False
                        break
                if good:
                    candidates.append(v)
                    if len(candidates) >= 6:
                        break
            if not candidates:
                ok = False
                break
            # randomized greedy: pick among first few
            v = rng.choice(candidates[:min(3, len(candidates))])
            for x in ruler:
                diffs.add(v - x)
            ruler.append(v)
        if ok and _is_golomb(ruler):
            span = ruler[-1]
            if best_span is None or span < best_span:
                best_span = span
                best = ruler[:]
    return best


def _repair_sumset(ruler, deadline, rng):
    """Try to reduce the span (and hence |A+A|) by moving the largest element
    inward while preserving the Golomb property. Also try shifting/reflecting
    and small pairwise sum-collision moves that keep |A-A| maximal."""
    cur = list(ruler)
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    n = len(cur)
    while time.time() < deadline:
        cand = cur[:]
        # Move the largest element inward as much as possible.
        idx = max(range(n), key=lambda i: cand[i])
        # Try to decrement the largest element while keeping Golomb.
        moved = False
        v = cand[idx]
        for nv in range(v - 1, max(cand) - 1 - n * n, -1):
            if nv in cand:
                continue
            trial = cand[:]
            trial[idx] = nv
            if _is_golomb(trial):
                cand = trial
                moved = True
                break
        if not moved:
            # Try a random swap / small perturbation to escape
            i = rng.randrange(n)
            j = rng.randrange(n)
            if i != j:
                cand[i], cand[j] = cand[j], cand[i]
                if not _is_golomb(cand):
                    cand = cur[:]
        cand = sorted(set(cand))
        s = _score(cand)
        if s >= cur_score or rng.random() < 0.05:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    rng = random.Random(20240607)
    deadline = time.time() + 118
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Phase 1: evaluate all known optimal rulers (max |A-A|, min span).
    for n, ruler in _OPTIMAL_RULERS.items():
        s = _score(ruler)
        if s > best_score:
            best, best_score = ruler[:], s

    # Phase 2: for each size n, build the best Golomb ruler we can and score it.
    # Larger n is favored by the (1 - 1/|A|)/100 bonus, but the ratio tends to
    # decrease with n, so we sweep a range of sizes.
    for n in range(2, 26):
        if time.time() >= deadline:
            break
        ruler = None
        if n in _OPTIMAL_RULERS:
            ruler = _OPTIMAL_RULERS[n][:]
        else:
            ruler = _greedy_golomb(n, rng, min(deadline, time.time() + 4.0),
                                   tries=300)
        if ruler is None:
            continue
        s = _score(ruler)
        if s > best_score:
            best, best_score = ruler[:], s

    # Phase 3: repair the best rulers to shrink the sum set further.
    while time.time() < deadline:
        # Pick a promising ruler to repair.
        n = rng.choice([8, 9, 10, 11, 12, 13, 14, 16, 18, 20])
        ruler = _OPTIMAL_RULERS.get(n)
        if ruler is None:
            ruler = _greedy_golomb(n, rng, min(deadline, time.time() + 3.0),
                                   tries=150)
        if ruler is None:
            continue
        slice_end = time.time() + max(0.5, (deadline - time.time()) / 12)
        cand, s = _repair_sumset(ruler, slice_end, rng)
        if s > best_score:
            best, best_score = cand[:], s

    # Phase 4: final polish on the best set — try small integer perturbations
    # that keep the difference set maximal (Golomb property) but shrink sums.
    if time.time() < deadline:
        cur = best[:]
        cur_score = best_score
        while time.time() < deadline:
            cand = cur[:]
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-2, -1, 1, 2])
            if len(set(cand)) != len(cand):
                continue
            if _is_golomb(cand):
                s = _score(cand)
                if s >= cur_score:
                    cur, cur_score = cand, s
                    if s > best_score:
                        best, best_score = cand[:], s
            else:
                # allow non-Golomb if the ratio still improves (rare)
                s = _score(cand)
                if s > best_score:
                    best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
