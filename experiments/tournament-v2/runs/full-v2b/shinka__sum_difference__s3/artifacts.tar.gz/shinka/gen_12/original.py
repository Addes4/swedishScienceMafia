# EVOLVE-BLOCK-START
"""Multi-seed adaptive simulated annealing with Golomb/Sidon seeds and a polish phase."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


# Extended Golomb rulers (perfect / near-perfect) used as structured seeds.
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    # larger near-perfect rulers (Sidon-like) used for bigger n
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111, 120, 126],
]


def _seed_set(n, scale, shift, jitter, rng):
    """Build a seed from a Golomb ruler of size ~n, scaled and jittered."""
    base = _GOLOMB[min(n, len(_GOLOMB)) - 1]
    a = []
    for x in base:
        v = int(round(x * scale)) + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    # pad up to n with random distinct values if requested larger
    while len(a) < n:
        v = rng.randint(-scale * 100, scale * 100)
        if v not in a:
            a.append(v)
    return a


def _local_search(seed, deadline, rng, temp0=3.0, temp_min=0.001,
                  cool=0.99995, jump_prob=0.05):
    """Simulated annealing with adaptive operators and a score cache."""
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    cache = {}
    cache_key = tuple(sorted(cur))
    cache[cache_key] = cur_score

    while time.time() < deadline:
        temp = max(temp_min, temp * cool)
        cand = cur[:]
        r = rng.random()
        # Operator mix: scalar mutation, jump, insertion, deletion
        if r < 0.55 and cand:
            i = rng.randrange(len(cand))
            step = max(1, int(abs(rng.gauss(0, temp * 40))))
            if rng.random() < 0.5:
                step = -step
            cand[i] += step
        elif r < 0.70 and cand:
            # large jump
            i = rng.randrange(len(cand))
            step = rng.randint(-1000, 1000)
            cand[i] += step
        elif r < 0.88:
            # insert
            if cand:
                lo = min(cand)
                hi = max(cand)
                span = max(1, hi - lo)
                v = rng.randint(lo - span, hi + span)
            else:
                v = rng.randint(-50, 50)
            if v not in cand:
                cand.append(v)
        else:
            # delete (keep at least 4)
            if len(cand) > 4:
                del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        key = tuple(sorted(cand))
        if key in cache:
            s = cache[key]
        else:
            s = _score(cand)
            cache[key] = s
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def _polish(seed, deadline, rng):
    """Low-temperature fine polishing of a promising set."""
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = 0.3
    while time.time() < deadline:
        temp = max(0.0005, temp * 0.99999)
        cand = cur[:]
        i = rng.randrange(len(cand))
        step = max(1, int(abs(rng.gauss(0, temp * 20))))
        if rng.random() < 0.5:
            step = -step
        cand[i] += step
        cand = list(set(cand))
        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    # Multi-seed portfolio for robustness (different random streams).
    seeds = [12345, 777, 2024, 314159, 424242, 999983]
    rng = random.Random(seeds[0])
    deadline = time.time() + 118  # leave a little slack
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Build a richer trial list: sizes and scale factors (including fractional).
    trials = []
    for n in range(5, 18):
        for scale in (1, 1.5, 2, 2.5, 3, 4, 5, 7, 8, 11, 13, 17):
            trials.append((n, scale))
    rng.shuffle(trials)

    idx = 0
    slice_count = 10
    while time.time() < deadline:
        if idx < len(trials):
            n, scale = trials[idx]
            idx += 1
            shift = rng.randint(int(-scale * 30), int(scale * 30))
            jitter = rng.choice([0, 0, 1, 2, 3])
            seed = _seed_set(n, scale, shift, jitter, rng)
        else:
            # random restart around best
            n = rng.randint(5, 17)
            scale = rng.choice([1, 1.5, 2, 3, 5, 8, 13])
            seed = _seed_set(n, scale, rng.randint(-200, 200), 1, rng)

        remaining = deadline - time.time()
        if remaining <= 0:
            break
        # Adaptive slice length: shorter when many trials remain.
        slice_end = time.time() + max(0.3, remaining / slice_count)
        temp0 = rng.uniform(2.0, 8.0)
        cool = rng.uniform(0.99990, 0.99999)
        cand, s = _local_search(seed, slice_end, rng,
                                temp0=temp0, temp_min=0.001,
                                cool=cool,
                                jump_prob=rng.uniform(0.02, 0.12))
        if s > best_score:
            best, best_score = cand[:], s
            slice_count = max(6, slice_count - 1)  # exploit good region
        else:
            slice_count = min(24, slice_count + 1)  # explore more

        # Occasionally polish the best found so far.
        if time.time() < deadline and rng.random() < 0.25:
            polish_end = time.time() + max(0.5, (deadline - time.time()) / 8)
            cand, s = _polish(best[:], polish_end, rng)
            if s > best_score:
                best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
