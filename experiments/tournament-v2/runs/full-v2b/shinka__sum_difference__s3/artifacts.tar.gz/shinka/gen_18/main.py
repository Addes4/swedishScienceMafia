# EVOLVE-BLOCK-START
"""Adaptive-budget multi-seed SA with Golomb/Sidon seeds and temperature-aware operators."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _cheap_score(a):
    """Fast O(n^2) proxy: ratio of estimated distinct diffs to distinct sums."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    # scale by 2 for off-diagonal duplicates
    d = len(diffs) * 2
    s = len(sums) * 2
    if s < 2:
        return 0.0
    return math.log(max(2, d)) / math.log(max(2, s)) + (1 - 1 / n) / 100


# Extended Golomb rulers (perfect / near-perfect) used as structured seeds.
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111, 120, 126],
    # larger near-perfect rulers
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111, 120, 126,
     133, 138, 145, 152, 158],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111, 120, 126,
     133, 138, 145, 152, 158, 165, 171, 178, 185, 191],
]


def _greedy_sidon(limit, target_size, rng):
    """Build a greedy Sidon set in [0, limit] with up to target_size elements."""
    S = [0]
    used_diffs = {0}
    candidates = list(range(1, limit + 1))
    rng.shuffle(candidates)
    for c in candidates:
        if len(S) >= target_size:
            break
        new_diffs = {c - s for s in S} | {s - c for s in S}
        if new_diffs & used_diffs:
            continue
        S.append(c)
        used_diffs |= new_diffs
    return S


def _seed_set(n, scale, shift, jitter, rng):
    """Build a seed from a Golomb ruler of size ~n, scaled and jittered."""
    if n <= len(_GOLOMB):
        base = _GOLOMB[n - 1]
    else:
        # grow a Sidon set heuristically
        base = _greedy_sidon(int(n * 3.5), n, rng)
    a = []
    for x in base:
        v = int(round(x * scale)) + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    while len(a) < n:
        v = rng.randint(-scale * 100, scale * 100)
        if v not in a:
            a.append(v)
    return a


def _local_search(seed, deadline, rng, temp0=3.0, temp_min=0.001,
                  cool=0.99995, cache=None):
    """Temperature-aware SA. Operator mix adapts to current temperature."""
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    if cache is None:
        cache = {}
    cache[tuple(sorted(cur))] = cur_score

    while time.time() < deadline:
        temp = max(temp_min, temp * cool)
        cand = cur[:]
        r = rng.random()
        # Temperature-aware operator mix: hot -> structural (insert/delete/jump),
        # cold -> fine scalar mutations.
        hot = temp > 0.5
        if hot:
            if r < 0.40 and cand:
                i = rng.randrange(len(cand))
                step = max(1, int(abs(rng.gauss(0, temp * 30))))
                if rng.random() < 0.5:
                    step = -step
                cand[i] += step
            elif r < 0.60 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-500, 500)
            elif r < 0.90:
                if cand:
                    lo, hi = min(cand), max(cand)
                    span = max(1, hi - lo)
                    v = rng.randint(lo - span, hi + span)
                else:
                    v = rng.randint(-50, 50)
                if v not in cand:
                    cand.append(v)
            else:
                if len(cand) > 4:
                    del cand[rng.randrange(len(cand))]
        else:
            if r < 0.85 and cand:
                i = rng.randrange(len(cand))
                step = max(1, int(abs(rng.gauss(0, temp * 15))))
                if rng.random() < 0.5:
                    step = -step
                cand[i] += step
            elif r < 0.95:
                if cand:
                    lo, hi = min(cand), max(cand)
                    span = max(1, hi - lo)
                    v = rng.randint(lo - span, hi + span)
                else:
                    v = rng.randint(-50, 50)
                if v not in cand:
                    cand.append(v)
            else:
                if len(cand) > 4:
                    del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        key = tuple(sorted(cand))
        if key in cache:
            s = cache[key]
        else:
            s = _score(cand)
            cache[key] = s
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def _polish(seed, deadline, rng):
    """Low-temperature fine polishing of a promising set."""
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = 0.3
    while time.time() < deadline:
        temp = max(0.0005, temp * 0.99999)
        cand = cur[:]
        i = rng.randrange(len(cand))
        step = max(1, int(abs(rng.gauss(0, temp * 20))))
        if rng.random() < 0.5:
            step = -step
        cand[i] += step
        cand = list(set(cand))
        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    rng = random.Random(20240607)
    deadline = time.time() + 116
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    cache = {}

    # Build a trial list with emphasis on larger n (bonus grows with |A|).
    trials = []
    for n in range(4, 31):
        for scale in (1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 11, 13, 17, 21):
            trials.append((n, scale))
    rng.shuffle(trials)

    # Pre-screen seeds cheaply and allocate time proportionally to seed score.
    # We only need to do this once; afterwards we run SA with adaptive slices.
    # Cap the number of screened seeds so pre-screening is fast.
    pre_screen_count = min(len(trials), 120)
    seeds = []
    for k in range(pre_screen_count):
        n, scale = trials[k]
        shift = rng.randint(int(-scale * 30), int(scale * 30))
        jitter = rng.choice([0, 0, 1, 2, 3])
        seed = _seed_set(n, scale, shift, jitter, rng)
        sc = _cheap_score(seed)
        seeds.append((sc, seed, n, scale))

    # Sort descending by cheap score; keep top few as primary, rest as fallback.
    seeds.sort(key=lambda t: -t[0])
    alpha = 2.0
    weights = [max(1e-6, s[0]) ** alpha for s in seeds]
    total_w = sum(weights)

    idx = 0
    while time.time() < deadline and idx < len(seeds):
        remaining = deadline - time.time()
        if remaining <= 0.05:
            break
        # Adaptive slice proportional to seed quality.
        w = weights[idx]
        slice_len = remaining * (w / total_w) if total_w > 0 else remaining / 8
        # Ensure a minimum slice so we don't starve strong seeds.
        slice_len = max(0.4, min(slice_len, remaining * 0.6))
        _, seed, n, scale = seeds[idx]
        idx += 1
        # Recompute remaining weights (drop used one).
        total_w = max(1e-9, total_w - w)

        slice_end = time.time() + slice_len
        temp0 = rng.uniform(2.0, 9.0)
        cool = rng.uniform(0.99990, 0.99998)
        cand, s = _local_search(seed, slice_end, rng,
                                temp0=temp0, temp_min=0.001,
                                cool=cool, cache=cache)
        if s > best_score:
            best, best_score = cand[:], s
            # Immediately polish improvements for a quick local boost.
            polish_end = min(deadline, time.time() + max(0.5, slice_len * 0.3))
            cand2, s2 = _polish(best[:], polish_end, rng)
            if s2 > best_score:
                best, best_score = cand2[:], s2

    # Final polish on best.
    if time.time() < deadline:
        cand, s = _polish(best[:], deadline, rng)
        if s > best_score:
            best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
