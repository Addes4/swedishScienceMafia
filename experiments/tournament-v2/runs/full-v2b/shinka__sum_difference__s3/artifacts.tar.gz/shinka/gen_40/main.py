# EVOLVE-BLOCK-START
"""Improved solver: greedy Sidon construction + local search for sum-difference ratio."""
import math
import random
import time


def _score(a):
    """Compute log|A-A| / log|A+A| + small bonus for larger |A|."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _greedy_sidon(limit, target_size):
    """Build a greedy Sidon set in [0, limit] with up to target_size elements."""
    S = [0]
    used_diffs = {0}
    candidates = list(range(1, limit + 1))
    random.shuffle(candidates)
    for c in candidates:
        if len(S) >= target_size:
            break
        new_diffs = {c - s for s in S}
        if new_diffs & used_diffs:
            continue
        new_diffs |= {s - c for s in S}
        if new_diffs & used_diffs:
            continue
        S.append(c)
        used_diffs |= new_diffs
    return S


def _jaccard(A, B):
    """Jaccard distance between two integer sets (0 = identical, 1 = disjoint)."""
    sa, sb = set(A), set(B)
    if not sa and not sb:
        return 0.0
    inter = len(sa & sb)
    union = len(sa | sb)
    return 1.0 - (inter / union if union else 0.0)


def _admit_elite(pool, cand, sc, max_size=8, min_dist=0.3):
    """Admit `cand` into a diversity-preserving elite pool (list of (score, set)).

    A candidate is admitted only if its Jaccard distance from every existing
    member exceeds `min_dist`.  If the pool is full, the most similar existing
    member is evicted to make room (provided the candidate is at least as good).
    Returns True if the pool was modified.
    """
    cs = set(cand)
    # If far enough from every member, admit directly.
    far = all(_jaccard(cs, m[1]) > min_dist for m in pool)
    if far:
        pool.append((sc, cs))
    else:
        if len(pool) < max_size:
            return False
        # Pool full: find the pair (member, candidate) with smallest distance.
        dists = [(_jaccard(cs, m[1]), i) for i, m in enumerate(pool)]
        d, idx = min(dists)
        if sc > pool[idx][0]:
            pool[idx] = (sc, cs)
        else:
            return False
    # Keep only the top `max_size` by score.
    pool.sort(key=lambda t: t[0], reverse=True)
    del pool[max_size:]
    return True


def _local_search(seed, deadline, elite_pool=None):
    """Simulated-annealing local search with temperature-proportional step.

    The perturbation magnitude is drawn from a Gaussian whose scale tracks a
    geometrically decaying temperature.  When hot, large geometric jumps let
    the search escape plateaus; as it cools the step shrinks toward +/-1 for
    fine refinement.  A low temperature floor (0.001) avoids the premature
    freeze that plagued earlier fixed-step hill climbers.

    If `elite_pool` is provided, personal-best solutions are admitted into it
    (diversity-preserving) and restarts source from a random elite member so
    that re-heat phases explore distinct basins.
    """
    rng = random.Random(20240607)
    best = list(set(seed))
    best_score = _score(best)
    if elite_pool is not None:
        _admit_elite(elite_pool, best, best_score)
    cur = best[:]
    cur_score = best_score

    t_start = time.time()
    total = max(1e-6, deadline - t_start)
    temp_max = 1.0
    temp_min = 0.001
    since_improve = 0

    while time.time() < deadline:
        # Geometric cooling from temp_max down to temp_min over the budget.
        frac = min(1.0, max(0.0, (time.time() - t_start) / total))
        temp = temp_max * (temp_min / temp_max) ** frac

        cand = cur[:]
        r = rng.random()
        if r < 0.6 and len(cand) > 2:
            i = rng.randrange(len(cand))
            # Temperature-proportional Gaussian step, with occasional
            # geometric jumps so low-temperature phases can still escape.
            step = max(1, int(round(abs(rng.gauss(0, temp * 50)))))
            if rng.random() < 0.2:
                step *= 2 ** rng.randint(0, 3)
            cand[i] += rng.choice([-1, 1]) * step
        elif r < 0.85:
            span = max(20, int(100 * (1.0 + temp)))
            cand.append(rng.randint(-span, span))
        elif len(cand) > 3:
            i = rng.randrange(len(cand))
            del cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(1e-6, temp * 0.01)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
                since_improve = 0
                if elite_pool is not None:
                    _admit_elite(elite_pool, best, best_score)
            else:
                since_improve += 1
        else:
            since_improve += 1

        # Stagnation-triggered fresh-basin restart: when the best score has
        # not improved for many iterations, abandon the current elite basin
        # entirely and start from an unrelated random Golomb-scale seed.
        if since_improve > 25:
            since_improve = 0
            if elite_pool is not None:
                elite_pool.clear()
            # Fresh, structurally unrelated basin: random Golomb scale/shift.
            scale = rng.randint(4, 40)
            shift = rng.randint(-3 * scale, 3 * scale)
            n_seed = rng.randint(5, max(6, len(best)))
            fresh = set()
            used = set()
            fresh.add(shift)
            used.add(0)
            attempt = 0
            while len(fresh) < n_seed and attempt < 200:
                attempt += 1
                c = shift + rng.randint(1, scale * n_seed) + rng.randint(-2, 2)
                if c in fresh:
                    continue
                new_d = {c - s for s in fresh}
                if new_d & used:
                    continue
                new_d |= {s - c for s in fresh}
                if new_d & used:
                    continue
                fresh.add(c)
                used |= new_d
            cur = list(fresh)
            cur_score = _score(cur)
            if cur_score > best_score:
                best, best_score = cur[:], cur_score
                if elite_pool is not None:
                    _admit_elite(elite_pool, best, best_score)
            continue

        # Rare restart: source from a random elite member so that re-heat
        # phases explore distinct basins rather than the same local optimum.
        if rng.random() < 0.01:
            if elite_pool:
                src = rng.choice(elite_pool)
                cur = list(src[1])
                cur_score = src[0]
            else:
                cur, cur_score = best[:], best_score
    return best, best_score


def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 100  # leave margin within 120s
    elite_pool = []  # list of (score, set) with enforced diversity

    # Phase 1: multiple greedy Sidon constructions with different limits
    for limit, target in [(200, 20), (500, 30), (1000, 40), (2000, 50)]:
        for _ in range(3):
            S = _greedy_sidon(limit, target)
            if len(S) < 2:
                continue
            # Shift to center around 0
            S = [x - limit // 2 for x in S]
            sc = _score(S)
            _admit_elite(elite_pool, S, sc)

    # Phase 2: local search seeded from each elite member so far, sourcing
    # restarts from the diverse pool to explore distinct basins.
    if elite_pool:
        seeds = [list(m[1]) for m in elite_pool]
        for i, sd in enumerate(seeds):
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            slice_end = time.time() + max(0.5, remaining / max(1, len(seeds) - i))
            _local_search(sd, slice_end, elite_pool=elite_pool)

    # Phase 3: try a few known good structured sets
    # Arithmetic progression with a few gaps (small sum set, large diff set)
    for n in [10, 15, 20, 25, 30]:
        base = list(range(n))
        # Add a Sidon perturbation
        for _ in range(5):
            pert = base[:]
            for _ in range(3):
                i = random.randrange(len(pert))
                pert[i] += random.randint(-2, 2)
            pert = list(set(pert))
            sc = _score(pert)
            _admit_elite(elite_pool, pert, sc)

    # Phase 4: final polish with small perturbations from the best elite member
    if elite_pool:
        top = list(elite_pool[0][1])
        cand, sc = _local_search(top, min(time.time() + 10, deadline),
                                 elite_pool=elite_pool)

    # Select the best elite member.
    if elite_pool:
        best = sorted(elite_pool[0][1])
    else:
        best = [0, 1, 2, 4, 8, 13]
    if len(best) < 2:
        best = [0, 1, 2, 4, 8, 13]
    return sorted(set(best))
# EVOLVE-BLOCK-END