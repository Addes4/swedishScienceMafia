# EVOLVE-BLOCK-START
"""Adaptive-step annealed Golomb/Sidon search maximizing log|A-A|/log|A+A|."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ls = len(sums)
    if ls < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def _stats(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


# Known optimal/near-optimal Golomb rulers.
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111,
     120, 126],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111,
     120, 126, 132, 140],
]


def _seed_golomb(n, scale, shift, jitter, rng, affine_b=0):
    base = _GOLOMB[min(n, len(_GOLOMB)) - 1]
    a = []
    for x in base:
        v = int(round(x * scale)) + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    while len(a) < n:
        v = rng.randint(-scale * 80, scale * 80) + shift
        if v not in a:
            a.append(v)
    if affine_b:
        a = [x + affine_b for x in a]
    return a


def _local_search(seed, deadline, rng, temp0=4.0, temp_min=0.001,
                  cool=0.99997, best_score_global=0.0):
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    cache = {tuple(sorted(cur)): cur_score}
    stagnate = 0

    while time.time() < deadline:
        # Temperature-proportional minimum tied to score gap.
        gap = max(0.0, best_score_global - best_score)
        tmin = max(temp_min, 0.005 * gap)
        temp = max(tmin, temp * cool)
        cand = cur[:]
        r = rng.random()
        if r < 0.50 and cand:
            i = rng.randrange(len(cand))
            step = max(1, int(round(abs(rng.gauss(0, temp * 50)))))
            if rng.random() < 0.35:
                step *= (2 ** rng.randint(0, 3))
            if rng.random() < 0.5:
                step = -step
            cand[i] += step
        elif r < 0.68 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-500, 500)
        elif r < 0.86:
            if cand:
                lo, hi = min(cand), max(cand)
                span = max(1, hi - lo)
                v = rng.randint(lo - span, hi + span)
            else:
                v = rng.randint(-50, 50)
            if v not in cand:
                cand.append(v)
        else:
            if len(cand) > 4:
                del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        key = tuple(sorted(cand))
        s = cache.get(key)
        if s is None:
            s = _score(cand)
            if len(cache) > 200000:
                cache.clear()
            cache[key] = s
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
                stagnate = 0
            else:
                stagnate += 1
        else:
            stagnate += 1
        # Force a big jump if stagnated.
        if stagnate > 4000:
            if cur:
                i = rng.randrange(len(cur))
                cur[i] += rng.choice([-1, 1]) * (2 ** rng.randint(4, 10))
                cur = list(set(cur))
                cur_score = _score(cur)
                if cur_score > best_score:
                    best, best_score = cur[:], cur_score
            stagnate = 0
    return best, best_score


def _repair_sums(seed, deadline, rng):
    """Targeted move: break duplicate sums by nudging one element,
    with best-of-K candidate selection."""
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    while time.time() < deadline:
        n = len(cur)
        if n < 4:
            break
        sums = {}
        dup = None
        for i in range(n):
            for j in range(i, n):
                s = cur[i] + cur[j]
                if s in sums:
                    dup = (sums[s], (i, j))
                    break
                sums[s] = (i, j)
            if dup:
                break
        if dup is None:
            # No duplicate sums: try a random small perturbation to improve.
            k = rng.randrange(n)
            cand = cur[:]
            cand[k] += rng.choice([-2, -1, 1, 2])
            cand = list(set(cand))
            s = _score(cand)
            if s >= cur_score:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
            continue
        (i0, j0), (i1, j1) = dup
        # Try each of the four involved indices with best-of-K.
        candidates_idx = [i0, j0, i1, j1]
        rng.shuffle(candidates_idx)
        improved = False
        for k in candidates_idx[:2]:
            old = cur[k]
            best_local = None
            best_local_s = cur_score
            for _ in range(10):
                cand = cur[:]
                if rng.random() < 0.7:
                    d = rng.choice([-6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6])
                else:
                    d = rng.choice([-1, 1]) * (2 ** rng.randint(2, 8))
                cand[k] = old + d
                cand = list(set(cand))
                s = _score(cand)
                if s > best_local_s:
                    best_local_s = s
                    best_local = cand
            if best_local is not None:
                cur, cur_score = best_local, best_local_s
                if cur_score > best_score:
                    best, best_score = cur[:], cur_score
                improved = True
                break
        if not improved:
            k = rng.choice(candidates_idx)
            cand = cur[:]
            cand[k] += rng.randint(-50, 50)
            cand = list(set(cand))
            s = _score(cand)
            if s >= cur_score or rng.random() < 0.05:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
    return best, best_score


def solve():
    rng = random.Random(0xBEEFCAFE)
    deadline = time.time() + 118
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Elite pool of distinct solutions.
    elites = [(best[:], best_score)]

    trials = []
    for n in range(5, 17):
        for scale in (1, 2, 3, 5, 8, 13, 21, 34):
            trials.append((n, scale))
    rng.shuffle(trials)

    idx = 0
    slice_count = 8
    while time.time() < deadline:
        if idx < len(trials):
            n, scale = trials[idx]
            idx += 1
            shift = rng.randint(-scale * 20, scale * 20)
            jitter = rng.choice([0, 0, 1, 2])
            affine_b = rng.choice([0, 0, 0, rng.randint(-scale * 10, scale * 10)])
            seed = _seed_golomb(n, scale, shift, jitter, rng, affine_b)
        elif elites and rng.random() < 0.45:
            # Restart from a random elite with fresh temperature.
            e, _ = rng.choice(elites)
            seed = e[:]
            if rng.random() < 0.5:
                i = rng.randrange(len(seed))
                seed[i] += rng.randint(-200, 200)
        else:
            n = rng.randint(5, 17)
            scale = rng.choice([1, 2, 3, 5, 8, 13, 21])
            seed = _seed_golomb(n, scale, rng.randint(-200, 200), 1, rng)

        remaining = deadline - time.time()
        if remaining <= 0:
            break
        slice_end = time.time() + max(0.3, remaining / slice_count)
        temp0 = rng.uniform(2.0, 10.0)
        cool = rng.uniform(0.99990, 0.99999)
        cand, s = _local_search(seed, slice_end, rng,
                                temp0=temp0, temp_min=0.001, cool=cool,
                                best_score_global=best_score)
        if s > best_score:
            best, best_score = cand[:], s
            slice_count = max(5, slice_count - 1)
        else:
            slice_count = min(20, slice_count + 1)

        # Maintain elite pool (top 3 distinct).
        if s > 0:
            key = tuple(sorted(cand))
            if all(tuple(sorted(e)) != key for e, _ in elites):
                elites.append((cand[:], s))
                elites.sort(key=lambda t: -t[1])
                elites = elites[:3]

        if time.time() < deadline and rng.random() < 0.40:
            rep_end = time.time() + max(0.4, (deadline - time.time()) / 10)
            cand, s = _repair_sums(best[:], rep_end, rng)
            if s > best_score:
                best, best_score = cand[:], s

    # Final targeted repair pass on the best solution.
    if time.time() < deadline:
        cand, s = _repair_sums(best[:], deadline, rng)
        if s > best_score:
            best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
