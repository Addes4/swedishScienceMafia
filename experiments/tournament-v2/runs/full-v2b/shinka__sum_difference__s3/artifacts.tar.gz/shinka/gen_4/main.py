# EVOLVE-BLOCK-START
"""Singer difference set construction with sum-set minimization."""
import math
import time

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True

def _next_prime(n):
    while not _is_prime(n):
        n += 1
    return n

def _primitive_root(p):
    """Find a primitive root modulo prime p."""
    if p == 2:
        return 1
    # factor p-1
    factors = []
    n = p - 1
    d = 2
    while d * d <= n:
        if n % d == 0:
            factors.append(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        factors.append(n)
    for g in range(2, p):
        ok = True
        for f in factors:
            if pow(g, (p - 1) // f, p) == 1:
                ok = False
                break
        if ok:
            return g
    return 2

def _singer_difference_set(q):
    """Construct a Singer difference set in Z_{q^2+q+1}.
    Uses the standard construction via GF(q^3) projectivization when q is a prime power.
    For simplicity, we use the (p^2+p+1, p+1, 1) difference set from projective plane of order p.
    We build it via the cyclotomic approach for prime p."""
    if q < 2:
        return None
    p = q  # assume prime
    v = p * p + p + 1
    # Find primitive root of v? Not always prime. Use the multiplicative group construction.
    # The standard Singer difference set: take GF(p^3), let w be primitive element.
    # The set {i : Tr(w^i) = 0} gives a difference set in Z_{v}.
    # Implementing full GF(p^3) arithmetic is heavy; instead use known small constructions.
    # Fallback: use a quadratic residue based construction for p ≡ 3 mod 4:
    # The set of quadratic residues mod p forms a difference set with parameters (p, (p-1)/2, (p-3)/4).
    # This gives |A| = (p-1)/2, |A-A| = p, |A+A| up to p. Not as good.
    return None

def _singer_via_field(p):
    """Construct Singer difference set using GF(p^3) trace map.
    Elements of GF(p^3) represented as polynomials a + b*x + c*x^2 mod irreducible cubic over F_p.
    We find a primitive element w, compute trace Tr(w^i) = w^i + w^{ip} + w^{ip^2} in GF(p^3),
    and collect indices i where trace is zero (in GF(p^3), trace is an element of F_p).
    The resulting index set mod (p^3-1)/(p-1) = p^2+p+1 is a difference set."""
    if p < 2:
        return None
    # Find irreducible cubic x^3 - r*x - s or use x^3 = x + 1 style.
    # We'll search for an irreducible polynomial x^3 + a*x + b over F_p.
    poly = None
    for a in range(p):
        for b in range(p):
            if b == 0:
                continue
            # check irreducibility: no root in F_p and not reducible
            has_root = False
            for x in range(p):
                if (x*x*x + a*x + b) % p == 0:
                    has_root = True
                    break
            if not has_root:
                # also need it to be irreducible (degree 3, no roots => irreducible)
                poly = (a, b)
                break
        if poly:
            break
    if poly is None:
        return None
    a, b = poly
    # Represent element as (c0, c1, c2) for c0 + c1*x + c2*x^2
    # Multiplication: x^3 = -a*x - b
    def mul(u, v):
        # (u0+u1 x+u2 x^2)(v0+v1 x+v2 x^2)
        r0 = u[0]*v[0]
        r1 = u[0]*v[1] + u[1]*v[0]
        r2 = u[0]*v[2] + u[1]*v[1] + u[2]*v[0]
        r3 = u[1]*v[2] + u[2]*v[1]
        r4 = u[2]*v[2]
        # reduce r3*x^3 + r4*x^4
        # x^3 = -a*x - b
        # x^4 = x*x^3 = -a*x^2 - b*x
        r0 = (r0 - b*r3) % p
        r1 = (r1 - a*r3 - b*r4) % p
        r2 = (r2 - a*r4) % p
        return (r0, r1, r2)
    def add(u, v):
        return ((u[0]+v[0])%p, (u[1]+v[1])%p, (u[2]+v[2])%p)
    def frob(u):
        # Frobenius: (c0,c1,c2) -> (c0^p, c1^p, c2^p) but p prime so same coeffs
        # Actually Frobenius maps x -> x^p = x (since coeffs in F_p), so it's identity on F_p.
        # For GF(p^3), Frobenius: element -> element^p. Compute via repeated mul.
        # Simpler: compute u^p using fast exponentiation.
        result = (1,0,0)
        base = u
        e = p
        while e > 0:
            if e & 1:
                result = mul(result, base)
            base = mul(base, base)
            e >>= 1
        return result
    # Find primitive element: element of order p^3-1
    order = p**3 - 1
    # factor order
    factors = set()
    n = order
    d = 2
    while d*d <= n:
        if n % d == 0:
            factors.add(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        factors.add(n)
    prim = None
    for c0 in range(p):
        for c1 in range(p):
            for c2 in range(p):
                if (c0, c1, c2) == (0,0,0):
                    continue
                # check order
                ok = True
                for f in factors:
                    # compute element^(order/f)
                    e = order // f
                    r = (1,0,0)
                    base = (c0,c1,c2)
                    while e > 0:
                        if e & 1:
                            r = mul(r, base)
                        base = mul(base, base)
                        e >>= 1
                    if r == (1,0,0):
                        ok = False
                        break
                if ok:
                    prim = (c0,c1,c2)
                    break
            if prim:
                break
        if prim:
            break
    if prim is None:
        return None
    # Now compute trace of w^i for i=0..order-1, collect indices where trace=0
    # Trace to F_p: Tr(u) = u + u^p + u^{p^2}
    # We need u^p and u^{p^2}
    # Precompute powers of w
    powers = [(1,0,0)]
    cur = (1,0,0)
    for i in range(order):
        cur = mul(cur, prim)
        powers.append(cur)
    # For each i, compute trace(powers[i]) = powers[i] + powers[i]^p + powers[i]^{p^2}
    # trace is in F_p: coefficient c1 and c2 should be zero (since trace is in F_p embedded as constant)
    indices = []
    for i in range(order):
        u = powers[i]
        u_p = frob(u)
        u_p2 = frob(u_p)
        tr = add(add(u, u_p), u_p2)
        # trace should be (t, 0, 0) for t in F_p
        if tr[1] == 0 and tr[2] == 0:
            indices.append(i)
    # The Singer difference set is indices mod v where v = p^2+p+1
    v = p*p + p + 1
    # The multiplicative group of GF(p^3) has order p^3-1 = (p-1)*v
    # The kernel of norm map is cyclic of order v, generated by w^(p-1)
    # Our indices need to be reduced mod v appropriately.
    # Standard: the set D = {i mod v : Tr(w^i) = 0} is a (v, p+1, 1) difference set.
    # But we collected i in 0..order-1. We should take i mod v, but need to be careful.
    # Actually the Singer difference set: take coset representatives.
    # Let's just take indices mod v and deduplicate.
    D = set()
    for i in indices:
        D.add(i % v)
    if len(D) < 2:
        return None
    return sorted(D)

def _build_set(p):
    """Build integer set from Singer difference set mod v."""
    D = _singer_via_field(p)
    if D is None or len(D) < 2:
        return None
    v = p*p + p + 1
    # Map D to integers: use multiplier k to spread differences but keep sums small
    # Try several multipliers and pick best
    best = None
    best_sc = -1
    for k in [1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]:
        for offset in [0, 1, -1]:
            A = [k * d + offset for d in D]
            sc = _score(A)
            if sc > best_sc:
                best_sc = sc
                best = A
    return best

def _greedy_refine(A, time_limit):
    """Greedy refinement: try to shrink sum set by shifting elements while keeping differences."""
    A = sorted(set(A))
    best = A[:]
    best_sc = _score(best)
    deadline = time.time() + time_limit
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for i in range(len(A)):
            orig = A[i]
            # try shifting element to reduce sum set size
            for delta in [-1, 1, -2, 2, -3, 3, -5, 5]:
                A[i] = orig + delta
                sc = _score(A)
                if sc > best_sc:
                    best_sc = sc
                    best = A[:]
                    improved = True
                    orig = A[i]
                else:
                    A[i] = orig
            A[i] = orig
        A = best[:]
    return best

def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    deadline = time.time() + 100
    best = [7, 15, 18, 22, -3, -2]
    best_sc = _score(best)
    
    # Try Singer constructions for various primes
    for p in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]:
        if time.time() > deadline:
            break
        try:
            A = _build_set(p)
            if A is not None:
                sc = _score(A)
                if sc > best_sc:
                    best_sc = sc
                    best = A[:]
        except Exception:
            pass
    
    # Also try quadratic residue difference sets for larger primes
    for p in [103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199]:
        if time.time() > deadline:
            break
        if p % 4 == 3:
            Q = [i*i % p for i in range(1, p)]
            Q = sorted(set(Q))
            for k in [1, 2, 3, 5, 7]:
                A = [k*q for q in Q]
                sc = _score(A)
                if sc > best_sc:
                    best_sc = sc
                    best = A[:]
    
    # Greedy refinement on the best found
    remaining = deadline - time.time()
    if remaining > 1:
        refined = _greedy_refine(best, min(remaining, 30))
        sc = _score(refined)
        if sc > best_sc:
            best = refined
    
    return sorted(set(best))
# EVOLVE-BLOCK-END
