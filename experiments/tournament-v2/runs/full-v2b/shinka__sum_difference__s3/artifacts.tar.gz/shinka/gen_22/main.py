# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


# Known good Golomb rulers (near-optimal) used as structured seeds.
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 106, 110, 113],
]


def _seed_set(n, scale, shift, jitter, rng):
    """Build a seed from a Golomb ruler of size ~n, scaled and jittered."""
    base = _GOLOMB[min(n, len(_GOLOMB)) - 1]
    a = []
    for x in base:
        v = x * scale + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    while len(a) < n:
        v = rng.randint(-scale * 100, scale * 100)
        if v not in a:
            a.append(v)
    return a


def _anneal(seed, deadline, rng, temp0=3.0, temp_min=None):
    cur = seed[:]
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    while time.time() < deadline:
        # Adaptive temperature floor: proportional to the score gap so the
        # search stays hot when far from the best-so-far and cools when close.
        gap = max(best_score - cur_score, 1e-3)
        t_floor = 0.001 * gap
        temp = max(t_floor, temp * 0.99995)
        cand = cur[:]
        r = rng.random()
        if r < 0.75 and cand:
            i = rng.randrange(len(cand))
            T = max(temp, 1e-6)
            step = max(1, int(round(abs(rng.gauss(0, T * 50)))))
            # Occasional large geometric jump to escape shared local optima.
            if rng.random() < 0.2:
                step *= 2 ** rng.randint(0, 3)
            if rng.random() < 0.5:
                step = -step
            cand[i] += step
        elif r < 0.90:
            if cand:
                lo = min(cand)
                hi = max(cand)
                span = max(1, hi - lo)
                v = rng.randint(lo - span, hi + span)
            else:
                v = rng.randint(-50, 50)
            if v not in cand:
                cand.append(v)
        else:
            if len(cand) > 4:
                del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-6)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    rng = random.Random(987654321)
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Build a shuffled list of (n, scale) trials covering useful seed sizes.
    trials = []
    for n in range(5, 17):
        for scale in (1, 2, 3, 5, 8, 13, 21):
            trials.append((n, scale))
    rng.shuffle(trials)

    idx = 0
    while time.time() < deadline:
        if idx < len(trials):
            n, scale = trials[idx]
            idx += 1
            shift = rng.randint(-scale * 20, scale * 20)
            jitter = rng.choice([0, 0, 1, 2])
            seed = _seed_set(n, scale, shift, jitter, rng)
        else:
            n = rng.randint(5, 17)
            scale = rng.choice([1, 2, 3, 5, 8, 13])
            seed = _seed_set(n, scale, rng.randint(-200, 200), 1, rng)
        remaining = deadline - time.time()
        if remaining <= 0:
            break
        slice_end = time.time() + max(0.5, remaining / 8)
        cand, s = _anneal(seed, slice_end, rng,
                          temp0=rng.uniform(1.5, 5.0))
        if s > best_score:
            best, best_score = cand[:], s
        if time.time() < deadline and rng.random() < 0.4:
            slice_end = time.time() + max(0.5, (deadline - time.time()) / 6)
            cand, s = _anneal(best[:], slice_end, rng, temp0=1.0)
            if s > best_score:
                best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END