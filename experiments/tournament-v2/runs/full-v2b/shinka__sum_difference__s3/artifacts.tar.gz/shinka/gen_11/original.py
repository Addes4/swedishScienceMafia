# EVOLVE-BLOCK-START
"""Golomb/Sidon seeded multi-restart simulated annealing for sum-difference ratio."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


# Near-perfect / optimal Golomb rulers (Sidon-like, minimize sum-set collisions).
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111,
     120, 126],
]


def _seed_from_golomb(n, scale, shift, jitter, rng):
    base = _GOLOMB[min(n, len(_GOLOMB)) - 1]
    a = []
    for x in base:
        v = int(round(x * scale)) + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    while len(a) < n:
        v = rng.randint(-scale * 80, scale * 80) + shift
        if v not in a:
            a.append(v)
    return a


def _local_search(seed, deadline, rng, temp0=4.0, temp_min=0.0005,
                  cool=0.99995):
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    cache = {tuple(sorted(cur)): cur_score}

    while time.time() < deadline:
        temp = max(temp_min, temp * cool)
        cand = cur[:]
        r = rng.random()
        if r < 0.55 and cand:
            i = rng.randrange(len(cand))
            step = max(1, int(abs(rng.gauss(0, temp * 30))))
            if rng.random() < 0.5:
                step = -step
            cand[i] += step
        elif r < 0.72 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-500, 500)
        elif r < 0.88:
            if cand:
                lo, hi = min(cand), max(cand)
                span = max(1, hi - lo)
                v = rng.randint(lo - span, hi + span)
            else:
                v = rng.randint(-50, 50)
            if v not in cand:
                cand.append(v)
        else:
            if len(cand) > 4:
                del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        key = tuple(sorted(cand))
        s = cache.get(key)
        if s is None:
            s = _score(cand)
            cache[key] = s
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def _polish(seed, deadline, rng):
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = 0.3
    while time.time() < deadline:
        temp = max(0.0005, temp * 0.99999)
        cand = cur[:]
        i = rng.randrange(len(cand))
        step = max(1, int(abs(rng.gauss(0, temp * 20))))
        if rng.random() < 0.5:
            step = -step
        cand[i] += step
        cand = list(set(cand))
        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 118
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    trials = []
    for n in range(5, 15):
        for scale in (1, 2, 3, 5, 8, 13, 21):
            trials.append((n, scale))
    rng.shuffle(trials)

    idx = 0
    slice_count = 10
    while time.time() < deadline:
        if idx < len(trials):
            n, scale = trials[idx]
            idx += 1
            shift = rng.randint(-scale * 20, scale * 20)
            jitter = rng.choice([0, 0, 1, 2])
            seed = _seed_from_golomb(n, scale, shift, jitter, rng)
        else:
            n = rng.randint(5, 14)
            scale = rng.choice([1, 2, 3, 5, 8, 13])
            seed = _seed_from_golomb(n, scale, rng.randint(-100, 100), 1, rng)

        remaining = deadline - time.time()
        if remaining <= 0:
            break
        slice_end = time.time() + max(0.3, remaining / slice_count)
        temp0 = rng.uniform(2.0, 8.0)
        cool = rng.uniform(0.99990, 0.99999)
        cand, s = _local_search(seed, slice_end, rng,
                                temp0=temp0, temp_min=0.0005, cool=cool)
        if s > best_score:
            best, best_score = cand[:], s
            slice_count = max(6, slice_count - 1)
        else:
            slice_count = min(24, slice_count + 1)

        if time.time() < deadline and rng.random() < 0.2:
            polish_end = time.time() + max(0.4, (deadline - time.time()) / 8)
            cand, s = _polish(best[:], polish_end, rng)
            if s > best_score:
                best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
