# EVOLVE-BLOCK-START
"""Search for integer sets with large difference set A-A and small sum set A+A.

The theoretical maximum of log|A-A|/log|A+A| is 4/3 (Ruzsa: |A-A| <= |A+A|^2/|A|),
so the goal is to make |A+A| as small as possible relative to |A-A|. We build a
library of structured seeds that already have this property (geometric progressions,
modular parabolas, Singer perfect difference sets, unions of geometric progressions)
and then run simulated annealing to polish the best one.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _seeds():
    seeds = []
    # Geometric progressions: |A-A| = n(n-1)+1, |A+A| = n(n+1)/2.
    for n in range(3, 25):
        seeds.append([2 ** i for i in range(n)])
    # Shifted geometric progressions.
    for n in range(3, 15):
        seeds.append([2 ** i + 1 for i in range(n)])
    # Modular parabolas: |A-A| = p^2.
    for p in (5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47):
        seeds.append([x + p * (x * x % p) for x in range(p)])
    # Singer perfect difference sets (small hardcoded instances).
    for D in ([0, 1, 3],
              [0, 1, 3, 9],
              [0, 1, 4, 14, 16],
              [0, 1, 3, 8, 12, 18],
              [0, 1, 3, 13, 32, 36, 43, 52]):
        seeds.append(list(D))
    # Unions of two geometric progressions.
    for n in range(3, 10):
        seeds.append([2 ** i for i in range(n)] + [2 ** i + 2 ** n for i in range(n)])
    return seeds


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    best = None
    best_score = -1.0
    for s in _seeds():
        sc = _score(s)
        if sc > best_score:
            best_score = sc
            best = list(s)

    random.seed(12345)
    deadline = time.time() + 100
    cur = list(best)
    cur_score = best_score
    T = 0.08
    step = 0
    while time.time() < deadline:
        step += 1
        cand = list(cur)
        r = random.random()
        if r < 0.5 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, 2)
        elif r < 0.7:
            cand.append(random.randint(-30, 30))
        elif r < 0.85 and len(cand) > 3:
            del cand[random.randrange(len(cand))]
        elif cand:
            i = random.randrange(len(cand))
            cand[i] = random.randint(-60, 60)
        if len(cand) < 3:
            continue
        s = _score(cand)
        if s >= cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = list(cand), s
        if step % 3000 == 0:
            T = max(T * 0.93, 1e-4)
            if cur_score < best_score - 0.01:
                cur, cur_score = list(best), best_score
    return sorted(set(best))
# EVOLVE-BLOCK-END