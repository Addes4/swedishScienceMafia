# EVOLVE-BLOCK-START
"""Golomb-seeded sum-collision search for sets with large |A-A| and small |A+A|."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _stats(a):
    a = set(a)
    n = len(a)
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums), n


# Perfect / near-perfect Golomb rulers, normalized to start at 0.
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111,
     120, 126],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111,
     120, 126, 132, 140],
]


def _make_golomb(n, scale, shift, jitter, rng):
    """Return a scaled Golomb-ruler seed of size n."""
    base = _GOLOMB[min(n, len(_GOLOMB)) - 1]
    a = []
    for x in base:
        v = int(round(x * scale)) + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    # pad if n exceeds the largest known ruler
    while len(a) < n:
        v = rng.randint(-scale * 200, scale * 200) + shift
        if v not in a:
            a.append(v)
    return list(set(a))


def _sum_collision_move(a, rng):
    """Pick a random pair and force their sum to collide with an existing sum.

    We replace the larger element of the pair with s - smaller, where s is an
    existing sum of some other pair. This directly shaves |A+A|."""
    n = len(a)
    if n < 3:
        return None
    # collect all sums
    sums = {}
    for i in range(n):
        for j in range(i, n):
            s = a[i] + a[j]
            sums.setdefault(s, []).append((i, j))
    # pick a pair whose sum has a unique representation (target to break)
    unique_pairs = [(i, j) for i in range(n) for j in range(i, n)
                    if len(sums[a[i] + a[j]]) == 1]
    if not unique_pairs:
        return None
    i, j = rng.choice(unique_pairs)
    # pick a target sum from another pair
    other = [(k, l) for k in range(n) for l in range(k, n)
             if (k, l) != (i, j)]
    if not other:
        return None
    k, l = rng.choice(other)
    target = a[k] + a[l]
    # replace the larger of a[i], a[j] with target - smaller
    if a[i] >= a[j]:
        new_val = target - a[j]
        if new_val in a:
            return None
        cand = a[:]
        cand[i] = new_val
    else:
        new_val = target - a[i]
        if new_val in a:
            return None
        cand = a[:]
        cand[j] = new_val
    return list(set(cand))


def _difference_preserving_repair(a, rng, tries=30):
    """Try small random perturbations that don't hurt |A-A|."""
    cur = list(set(a))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    for _ in range(tries):
        i = rng.randrange(len(cur))
        cand = cur[:]
        cand[i] += rng.choice([-2, -1, 1, 2])
        cand = list(set(cand))
        s = _score(cand)
        if s > best_score:
            best, best_score = cand, s
    return best, best_score


def _anneal(seed, deadline, rng, temp0=2.0, temp_min=0.02):
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    cache = {tuple(sorted(cur)): cur_score}
    while time.time() < deadline:
        temp = max(temp_min, temp * 0.99992)
        r = rng.random()
        cand = None
        if r < 0.45:
            cand = _sum_collision_move(cur, rng)
        elif r < 0.75:
            cand = cur[:]
            i = rng.randrange(len(cand))
            step = max(1, int(abs(rng.gauss(0, temp * 40))))
            if rng.random() < 0.5:
                step = -step
            cand[i] += step
            cand = list(set(cand))
        elif r < 0.90:
            cand = cur[:]
            lo, hi = min(cand), max(cand)
            span = max(1, hi - lo)
            v = rng.randint(lo - span, hi + span)
            if v not in cand:
                cand.append(v)
        else:
            if len(cur) > 4:
                cand = cur[:]
                del cand[rng.randrange(len(cand))]
        if cand is None:
            continue
        cand = list(set(cand))
        key = tuple(sorted(cand))
        s = cache.get(key)
        if s is None:
            s = _score(cand)
            if len(cache) > 100000:
                cache.clear()
            cache[key] = s
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    rng = random.Random(0xC0FFEE)
    deadline = time.time() + 118
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Build a rich trial list over (n, scale, shift, jitter).
    trials = []
    for n in range(5, 18):
        for scale in (1, 1, 2, 2, 3, 4, 5, 8, 13):
            trials.append((n, scale))
    rng.shuffle(trials)

    idx = 0
    while time.time() < deadline:
        if idx < len(trials):
            n, scale = trials[idx]
            idx += 1
            shift = rng.randint(-scale * 30, scale * 30)
            jitter = rng.choice([0, 0, 1, 1, 2])
            seed = _make_golomb(n, scale, shift, jitter, rng)
        else:
            # restart from best with fresh perturbation
            seed = best[:]
            if seed and rng.random() < 0.6:
                i = rng.randrange(len(seed))
                seed[i] += rng.randint(-50, 50)
            else:
                n = rng.randint(5, 16)
                scale = rng.choice([1, 2, 3, 5, 8])
                seed = _make_golomb(n, scale, rng.randint(-100, 100), 1, rng)

        remaining = deadline - time.time()
        if remaining <= 0:
            break
        slice_end = time.time() + max(0.3, remaining / 12)
        cand, s = _anneal(seed, slice_end, rng,
                          temp0=rng.uniform(1.5, 5.0),
                          temp_min=0.01)

        # targeted repair on the candidate
        if time.time() < deadline:
            cand2, s2 = _difference_preserving_repair(cand, rng, tries=20)
            if s2 > s:
                cand, s = cand2, s2

        if s > best_score:
            best, best_score = cand[:], s

        # occasionally refine the current best with a longer anneal
        if time.time() < deadline and rng.random() < 0.25:
            slice_end = time.time() + max(0.4, (deadline - time.time()) / 10)
            cand, s = _anneal(best[:], slice_end, rng,
                              temp0=1.0, temp_min=0.005)
            if s > best_score:
                best, best_score = cand[:], s

    # Final polish: repeated sum-collision moves on best.
    if time.time() < deadline:
        cur = best[:]
        cur_score = best_score
        while time.time() < deadline:
            cand = _sum_collision_move(cur, rng)
            if cand is None:
                break
            s = _score(cand)
            if s >= cur_score:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
            else:
                # accept small losses with low probability
                if rng.random() < 0.02:
                    cur, cur_score = cand, s

    return sorted(set(best))
# EVOLVE-BLOCK-END