# EVOLVE-BLOCK-START
"""Search for integer sets with large |A-A| and small |A+A|.

Hybrid crossover strategy:
1. Build a rich library of structured seeds (Golomb rulers, Singer perfect
   difference sets, geometric progressions, modular parabolas, nonlinear maps,
   unions of geometric progressions).
2. Score every seed cheaply, then generate a small number of affine variants
   only for the strongest seeds (pre-filter to detect strong basins).
3. Allocate the remaining time budget to the top seeds proportionally to
   score**3, giving each a deep simulated-annealing polish with reheating and
   structure-preserving moves.
4. Finish with a global polish on the best candidate found so far.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


# ---------- Known optimal / near-optimal Golomb rulers ----------
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 2, 6, 24, 29, 40, 43, 55, 68, 75, 76, 85],
    [0, 2, 5, 25, 37, 43, 59, 70, 85, 89, 98, 99, 106],
    [0, 7, 11, 20, 27, 38, 42, 62, 76, 87, 96, 99, 107, 115],
    [0, 4, 12, 20, 26, 40, 46, 57, 66, 79, 87, 96, 103, 110, 116],
    [0, 4, 12, 20, 26, 40, 46, 57, 66, 79, 87, 96, 103, 110, 116, 121],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205, 215],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205, 215, 226],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205, 215, 226, 238],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205, 215, 226, 238, 251],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205, 215, 226, 238, 251, 265],
]

# Small Singer perfect difference sets
_SINGER = [
    [0, 1, 3],
    [0, 1, 3, 9],
    [0, 1, 4, 14, 16],
    [0, 1, 3, 8, 12, 18],
    [0, 1, 3, 13, 32, 36, 43, 52],
]


def _seeds():
    seeds = []
    # Geometric progressions
    for n in range(3, 25):
        seeds.append([2 ** i for i in range(n)])
    # Shifted geometric progressions
    for n in range(3, 15):
        seeds.append([2 ** i + 1 for i in range(n)])
    # Modular parabolas
    for p in (5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47):
        seeds.append([x + p * (x * x % p) for x in range(p)])
    # Golomb rulers
    for g in _GOLOMB:
        if len(g) >= 3:
            seeds.append(list(g))
    # Singer
    for D in _SINGER:
        seeds.append(list(D))
    # Unions of two geometric progressions
    for n in range(3, 10):
        seeds.append([2 ** i for i in range(n)] + [2 ** i + 2 ** n for i in range(n)])
    # Nonlinear maps on Golomb rulers (cheap exploration of transformed basins)
    for g in _GOLOMB:
        if len(g) < 4:
            continue
        for scale in (1, 2, 3, 5):
            seeds.append([int(round((x ** 1.3) * scale)) for x in g])
        for k in (3, 5, 7, 11, 13):
            p = max(g) + k + 1
            seeds.append([(x * k) % p for x in g])
    return seeds


def _affine_variants(seed, n_random=2):
    """Yield a small set of affine transforms of seed: scale, shift, jitter."""
    out = []
    base = list(seed)
    for scale in (1, 2, 3, 5, 7):
        for shift in (0, 1, -1, 2, -2):
            out.append([scale * x + shift for x in base])
    for _ in range(n_random):
        out.append([x + random.randint(-2, 2) for x in base])
    return out


def _local_search(seed, time_budget, best_global, best_global_score):
    """Run SA on `seed` for up to `time_budget` seconds. Returns (best, score)."""
    cur = sorted(set(seed))
    if len(cur) < 3:
        return best_global, best_global_score
    cur_score = _score(cur)
    best = list(cur)
    best_score = cur_score

    T = 0.05
    T_min = 1e-4
    step = 0
    last_improve = 0
    start = time.time()

    while time.time() - start < time_budget:
        step += 1
        cand = list(cur)
        r = random.random()
        if r < 0.45 and cand:
            # local jitter
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, 2)
        elif r < 0.60:
            # structure-preserving scale/shift
            if random.random() < 0.5:
                scale = random.choice([2, 3, 5, 7])
                cand = [scale * x for x in cand]
            else:
                shift = random.choice([-3, -2, -1, 1, 2, 3])
                cand = [x + shift for x in cand]
        elif r < 0.72 and cand:
            # random element perturbation
            i = random.randrange(len(cand))
            cand[i] = cand[i] + random.randint(-50, 50)
        elif r < 0.82:
            # append
            cand.append(random.randint(-200, 200))
        elif r < 0.92 and len(cand) > 3:
            # delete
            del cand[random.randrange(len(cand))]
        elif cand:
            # full replacement of one element
            i = random.randrange(len(cand))
            cand[i] = random.randint(-300, 300)

        cand = sorted(set(cand))
        if len(cand) < 3:
            continue
        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or random.random() < math.exp(delta / max(T, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = list(cand), s
                last_improve = step

        # Adaptive reheating on stagnation
        if step % 3000 == 0:
            if step - last_improve > 6000:
                T = min(T * 1.8, 0.1)  # reheat
                last_improve = step
            else:
                T = max(T * 0.96, T_min)
            if cur_score < best_score - 0.005:
                cur, cur_score = list(best), best_score

    if best_score > best_global_score:
        return best, best_score
    return best_global, best_global_score


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    random.seed(20240617)
    deadline = time.time() + 100

    # Phase 1: cheap single-pass seed scoring.
    seeds = _seeds()
    scored = []
    for s in seeds:
        s = sorted(set(s))
        if len(s) < 3:
            continue
        sc = _score(s)
        scored.append((sc, s))

    if not scored:
        return [0, 1, 3]

    scored.sort(key=lambda t: -t[0])

    # Phase 1b: affine pre-filter on the strongest seeds only.
    # This detects stronger basins without paying the cost of sweeping all
    # variants of all seeds.
    top_for_affine = scored[:25]
    extra = []
    for sc, s in top_for_affine:
        for v in _affine_variants(s, n_random=2):
            v = sorted(set(v))
            if len(v) < 3:
                continue
            sv = _score(v)
            extra.append((sv, v))
    scored.extend(extra)
    scored.sort(key=lambda t: -t[0])

    best, best_score = list(scored[0][1]), scored[0][0]

    # Phase 2: allocate remaining budget to top seeds proportionally to
    # score**3, with a floor to guarantee meaningful SA depth.
    top = scored[:16]
    total = sum(max(sc, 0.001) ** 3 for sc, _ in top)
    remaining = deadline - time.time()
    for sc, s in top:
        if time.time() >= deadline:
            break
        share = (max(sc, 0.001) ** 3) / total
        budget = max(2.0, remaining / 3.0 * share)
        best, best_score = _local_search(s, budget, best, best_score)

    # Phase 3: leftover time on a global polish of the best found so far.
    while time.time() < deadline:
        best, best_score = _local_search(best, min(8.0, deadline - time.time()),
                                         best, best_score)

    return sorted(set(best))
# EVOLVE-BLOCK-END