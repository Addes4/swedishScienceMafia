# EVOLVE-BLOCK-START
"""Search for integer sets with large difference set A-A and small sum set A+A.

Strategy:
1. Build a rich library of structured seeds:
   - Geometric progressions.
   - Modular parabolas.
   - Known optimal Golomb rulers (sizes 3..25).
   - Singer perfect difference sets (small hardcoded).
   - Nonlinear maps: v -> round(x**1.3 * scale), modular permutations (x*k)%p.
2. Apply affine transformations (scale, shift, jitter) to each seed.
3. Run a short simulated annealing polish on the best candidate.

The theoretical maximum of log|A-A|/log|A+A| is 4/3 (Ruzsa),
so we want |A+A| as small as possible relative to |A-A|.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


# ---------- Known optimal Golomb rulers (marks) ----------
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 2, 6, 24, 29, 40, 43, 55, 68, 75, 76, 85],
    [0, 2, 5, 25, 37, 43, 59, 70, 85, 89, 98, 99, 106],
    [0, 7, 11, 20, 27, 38, 42, 62, 76, 87, 96, 99, 107, 115],
    [0, 4, 12, 20, 26, 40, 46, 57, 66, 79, 87, 96, 103, 110, 116],
    [0, 4, 12, 20, 26, 40, 46, 57, 66, 79, 87, 96, 103, 110, 116, 121],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205, 215],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205, 215, 226],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205, 215, 226, 238],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205, 215, 226, 238, 251],
    [0, 1, 4, 11, 26, 32, 56, 68, 76, 115, 117, 134, 150, 163, 168, 177, 181, 188, 196, 205, 215, 226, 238, 251, 265],
]

# Small Singer perfect difference sets
_SINGER = [
    [0, 1, 3],
    [0, 1, 3, 9],
    [0, 1, 4, 14, 16],
    [0, 1, 3, 8, 12, 18],
    [0, 1, 3, 13, 32, 36, 43, 52],
]


def _seeds():
    seeds = []
    # Geometric progressions
    for n in range(3, 25):
        seeds.append([2 ** i for i in range(n)])
    # Shifted geometric progressions
    for n in range(3, 15):
        seeds.append([2 ** i + 1 for i in range(n)])
    # Modular parabolas
    for p in (5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47):
        seeds.append([x + p * (x * x % p) for x in range(p)])
    # Golomb rulers
    for g in _GOLOMB:
        if len(g) >= 3:
            seeds.append(list(g))
    # Singer
    for D in _SINGER:
        seeds.append(list(D))
    # Unions of two geometric progressions
    for n in range(3, 10):
        seeds.append([2 ** i for i in range(n)] + [2 ** i + 2 ** n for i in range(n)])
    # Nonlinear maps on Golomb rulers
    for g in _GOLOMB:
        if len(g) < 4:
            continue
        for scale in (1, 2, 3, 5):
            seeds.append([int(round((x ** 1.3) * scale)) for x in g])
        for k in (3, 5, 7, 11, 13):
            p = max(g) + k + 1
            seeds.append([(x * k) % p for x in g])
    # Additional nonlinear maps: quadratic and cubic on Golomb rulers
    for g in _GOLOMB:
        if len(g) < 5:
            continue
        seeds.append([x * x for x in g])
        seeds.append([x * x + x for x in g])
        seeds.append([x * x * x for x in g])
    # Modular permutations of geometric progressions
    for n in range(4, 12):
        gp = [2 ** i for i in range(n)]
        for k in (3, 5, 7, 11, 13, 17):
            p = 2 ** n + k
            seeds.append([(x * k) % p for x in gp])
    # Beatty-like sequences (floor(i*alpha)) for irrational-ish alpha
    for alpha_num, alpha_den in ((3, 2), (5, 3), (7, 4), (8, 5), (11, 7)):
        for n in range(4, 16):
            seeds.append([(i * alpha_num) // alpha_den for i in range(n)])
    return seeds


def _affine_variants(seed):
    """Yield affine transforms of seed: scale, shift, jitter."""
    out = []
    base = list(seed)
    for scale in (1, 2, 3, 5, 7):
        for shift in (0, 1, -1, 2, -2):
            out.append([scale * x + shift for x in base])
    # jittered versions
    for _ in range(3):
        out.append([x + random.randint(-2, 2) for x in base])
    return out


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    random.seed(987654321)
    deadline = time.time() + 100

    best = None
    best_score = -1.0

    # Phase 1: sweep seeds with affine variants
    seeds = _seeds()
    for s in seeds:
        if time.time() > deadline:
            break
        variants = [s] + _affine_variants(s)
        for v in variants:
            v = sorted(set(v))
            if len(v) < 3:
                continue
            sc = _score(v)
            if sc > best_score:
                best_score = sc
                best = list(v)

    # Phase 2: short simulated annealing polish with multiple restarts
    if best is None:
        best = [0, 1, 3]
        best_score = _score(best)

    # Keep a small elite pool to allow restarts from diverse basins
    elite = [list(best)]
    cur = list(best)
    cur_score = best_score
    T = 0.05
    step = 0
    since_improve = 0
    while time.time() < deadline:
        step += 1
        since_improve += 1
        cand = list(cur)
        r = random.random()
        if r < 0.45 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, 4)
        elif r < 0.60:
            # add with magnitude proportional to current spread
            span = max(cand) - min(cand) if cand else 1
            cand.append(random.randint(-span, span))
        elif r < 0.72 and len(cand) > 3:
            del cand[random.randrange(len(cand))]
        elif r < 0.88 and cand:
            i = random.randrange(len(cand))
            span = max(cand) - min(cand) if cand else 1
            cand[i] = random.randint(-span, span)
        elif cand:
            # swap two elements (structural move)
            i, j = random.randrange(len(cand)), random.randrange(len(cand))
            cand[i], cand[j] = cand[j], cand[i]
        if len(cand) < 3:
            continue
        s = _score(cand)
        if s >= cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = list(cand), s
                since_improve = 0
                elite.append(list(best))
                if len(elite) > 8:
                    elite.pop(0)
        if step % 3000 == 0:
            T = max(T * 0.9, 1e-5)
        # restart from a random elite member if stagnated
        if since_improve > 8000 and elite:
            cur = list(random.choice(elite))
            cur_score = _score(cur)
            T = max(T, 0.02)
            since_improve = 0

    return sorted(set(best))
# EVOLVE-BLOCK-END