# EVOLVE-BLOCK-START
"""Solver maximizing log|A-A|/log|A+A| via Golomb seeds + sum-collision Metropolis search."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


# Near-optimal Golomb rulers used as structured seeds (large difference set).
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 106, 110, 113],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 106, 110, 113, 121, 133, 137],
]


def _seed_set(n, scale, shift, jitter, rng):
    base = _GOLOMB[min(n, len(_GOLOMB)) - 1]
    a = []
    for x in base:
        v = x * scale + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    while len(a) < n:
        v = rng.randint(-scale * 100, scale * 100)
        if v not in a:
            a.append(v)
    return a


def _mian_chowla_seed(n, start, rng):
    """Greedy B_2-style seed: add smallest new element not creating a duplicate sum.

    This is the Mian-Chowla construction, which yields sets where |A+A| is
    close to n(n+1)/2 (all pairwise sums distinct) -- the key structural
    property that minimizes the denominator of the ratio.
    """
    a = [start]
    sums = {start + start}
    while len(a) < n:
        cand = a[-1] + 1
        # scan upward for the smallest candidate whose sums are all new
        found = False
        limit = a[-1] + 1 + 200 * n
        # Random starting offset occasionally to diversify.
        if rng.random() < 0.15:
            cand = a[-1] + 1 + rng.randint(0, n)
        while cand <= limit:
            if cand in a:
                cand += 1
                continue
            ok = True
            for x in a:
                if x + cand in sums:
                    ok = False
                    break
            if ok:
                found = True
                break
            cand += 1
        if not found:
            break
        a.append(cand)
        for x in a:
            sums.add(x + cand)
    return a


def _sum_collision_move(cand, rng):
    """Replace an element by x+y-z where z in A, forcing a sum collision (shrinks |A+A|)."""
    n = len(cand)
    if n < 3:
        return None
    # pick pair (x,y) and existing z
    i = rng.randrange(n)
    j = rng.randrange(n)
    k = rng.randrange(n)
    if i == j:
        return None
    x, y, z = cand[i], cand[j], cand[k]
    new_val = x + y - z
    # avoid trivial duplication and self
    if new_val == z and k != i and k != j:
        return None
    # choose index to replace: preferably one not in {i,j,k}, else j
    replace_idx = None
    for _ in range(4):
        t = rng.randrange(n)
        if t != i and t != j and t != k:
            replace_idx = t
            break
    if replace_idx is None:
        replace_idx = j
    new_cand = cand[:]
    new_cand[replace_idx] = new_val
    if len(set(new_cand)) < len(cand):
        return None
    return new_cand
=======
def _sum_collision_move(cand, rng):
    """Replace an element by x+y-z where z in A, forcing a sum collision (shrinks |A+A|)."""
    n = len(cand)
    if n < 3:
        return None
    # pick pair (x,y) and existing z
    i = rng.randrange(n)
    j = rng.randrange(n)
    k = rng.randrange(n)
    if i == j:
        return None
    x, y, z = cand[i], cand[j], cand[k]
    new_val = x + y - z
    # avoid trivial duplication and self
    if new_val == z and k != i and k != j:
        return None
    # choose index to replace: preferably one not in {i,j,k}, else j
    replace_idx = None
    for _ in range(4):
        t = rng.randrange(n)
        if t != i and t != j and t != k:
            replace_idx = t
            break
    if replace_idx is None:
        replace_idx = j
    new_cand = cand[:]
    new_cand[replace_idx] = new_val
    if len(set(new_cand)) < len(cand):
        return None
    return new_cand


def _sum_preserving_move(cand, rng):
    """Replace x by a+b-c-d+e: a linear combination of 5 existing elements.

    Moves into the additive span of A tend to preserve many existing sums
    while changing differences, which is exactly what we want.  This is
    inspired by the classical Freiman/Balog-Szemeredi intuition that small
    sum sets are highly structured.
    """
    n = len(cand)
    if n < 5:
        return None
    idxs = rng.sample(range(n), 5)
    a, b, c, d, e = (cand[t] for t in idxs)
    new_val = a + b - c - d + e
    # replace an element not among the 5 used
    replace_idx = None
    for _ in range(6):
        t = rng.randrange(n)
        if t not in idxs:
            replace_idx = t
            break
    if replace_idx is None:
        return None
    new_cand = cand[:]
    new_cand[replace_idx] = new_val
    if len(set(new_cand)) < len(cand):
        return None
    return new_cand


def _sum_collision_move(cand, rng):
    """Replace an element by x+y-z where z in A, forcing a sum collision (shrinks |A+A|)."""
    n = len(cand)
    if n < 3:
        return None
    # pick pair (x,y) and existing z
    i = rng.randrange(n)
    j = rng.randrange(n)
    k = rng.randrange(n)
    if i == j:
        return None
    x, y, z = cand[i], cand[j], cand[k]
    new_val = x + y - z
    # avoid trivial duplication and self
    if new_val == z and k != i and k != j:
        return None
    # choose index to replace: preferably one not in {i,j,k}, else j
    replace_idx = None
    for _ in range(4):
        t = rng.randrange(n)
        if t != i and t != j and t != k:
            replace_idx = t
            break
    if replace_idx is None:
        replace_idx = j
    new_cand = cand[:]
    new_cand[replace_idx] = new_val
    if len(set(new_cand)) < len(cand):
        return None
    return new_cand


def _anneal(seed, deadline, rng, temp0=2.5, temp_min=0.01):
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    stall = 0
    while time.time() < deadline:
        temp = max(temp_min, temp * 0.99992)
        r = rng.random()
        cand = None
        if r < 0.12:
            # dedicated sum-collision move (shrinks |A+A|)
            cand = _sum_collision_move(cur, rng)
        elif r < 0.28:
            # sum-preserving linear-combination move (keeps |A+A| small)
            cand = _sum_preserving_move(cur, rng)
        elif r < 0.70 and cur:
            cand = cur[:]
            i = rng.randrange(len(cand))
            step = max(1, int(abs(rng.gauss(0, temp * 25))))
            if rng.random() < 0.5:
                step = -step
            cand[i] += step
        elif r < 0.88:
            cand = cur[:]
            if cand:
                lo = min(cand)
                hi = max(cand)
                span = max(1, hi - lo)
                v = rng.randint(lo - span, hi + span)
            else:
                v = rng.randint(-50, 50)
            if v not in cand:
                cand.append(v)
        else:
            if len(cur) > 4:
                cand = cur[:]
                del cand[rng.randrange(len(cand))]
        if cand is None:
            continue
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-6)):
            if s > cur_score:
                stall = 0
            else:
                stall += 1
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        else:
            stall += 1
        # Plateau restart: jump back to best and reheat
        if stall > 4000:
            cur = best[:]
            cur_score = best_score
            temp = max(temp, temp0 * 0.6)
            stall = 0
    return best, best_score


def solve():
    rng = random.Random(0xC0FFEE)
    deadline = time.time() + 112
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Phase 1 (first ~35s): Mian-Chowla seeds of many sizes -- these directly
    # minimize |A+A| via the B_2 property, which is the denominator we need small.
    mc_deadline = time.time() + 35.0
    for n in range(5, 40):
        if time.time() >= mc_deadline:
            break
        for start in (-2, 0, 1, 3, 5, 7):
            if time.time() >= mc_deadline:
                break
            seed = _mian_chowla_seed(n, start, rng)
            s = _score(seed)
            if s > best_score:
                best, best_score = seed[:], s
            # short refine
            slice_end = time.time() + 0.3
            cand, s2 = _anneal(seed, slice_end, rng, temp0=0.6, temp_min=0.005)
            if s2 > best_score:
                best, best_score = cand[:], s2

    # Phase 2: Golomb-seeded annealing as before.
    trials = []
    for n in range(5, 21):
        for scale in (1, 2, 3, 5, 8, 13, 21, 34):
            trials.append((n, scale))
    rng.shuffle(trials)

    idx = 0
    while time.time() < deadline:
        if idx < len(trials):
            n, scale = trials[idx]
            idx += 1
            shift = rng.randint(-scale * 20, scale * 20)
            jitter = rng.choice([0, 0, 1, 2])
            seed = _seed_set(n, scale, shift, jitter, rng)
        else:
            # Occasionally seed from a fresh Mian-Chowla set for diversity.
            if rng.random() < 0.3:
                n = rng.randint(5, 30)
                seed = _mian_chowla_seed(n, rng.randint(-5, 5), rng)
            else:
                n = rng.randint(5, 21)
                scale = rng.choice([1, 2, 3, 5, 8, 13])
                seed = _seed_set(n, scale, rng.randint(-300, 300), 1, rng)
        remaining = deadline - time.time()
        if remaining <= 0:
            break
        slice_end = time.time() + max(0.4, remaining / 10)
        cand, s = _anneal(seed, slice_end, rng,
                          temp0=rng.uniform(1.2, 4.5), temp_min=0.01)
        if s > best_score:
            best, best_score = cand[:], s
        # Intensify around the best with a shorter, cooler run
        if time.time() < deadline and rng.random() < 0.5:
            slice_end = time.time() + max(0.4, (deadline - time.time()) / 8)
            cand, s = _anneal(best[:], slice_end, rng, temp0=0.8, temp_min=0.005)
            if s > best_score:
                best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END