# EVOLVE-BLOCK-START
"""Greedy incremental construction + sum-collision repair for large |A-A|, small |A+A|."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ls = len(sums)
    if ls < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def _diff_sum_counts(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _incremental_gain(a, v):
    """Return (delta_diffs, delta_sums) if we add v to set a (as sets)."""
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        diffs.add(x - x)
        diffs.add(x - v)
        diffs.add(v - x)
        sums.add(x + x)
        sums.add(x + v)
        sums.add(v + x)
    # count how many of the new diffs/sums are actually new
    old_diffs = set()
    old_sums = set()
    for i in range(len(a)):
        for j in range(len(a)):
            old_diffs.add(a[i] - a[j])
            old_sums.add(a[i] + a[j])
    new_diffs = len(diffs - old_diffs)
    new_sums = len(sums - old_sums)
    return new_diffs, new_sums


def _greedy_build(seed, target_n, deadline, rng, candidate_span):
    """Greedily add elements to maximize log|A-A|/log|A+A|."""
    cur = list(set(seed))
    cur_score = _score(cur)
    while len(cur) < target_n and time.time() < deadline:
        lo, hi = min(cur), max(cur)
        span = max(1, hi - lo)
        # candidate pool: nearby integers + scaled offsets
        cands = set()
        for _ in range(40):
            cands.add(rng.randint(lo - candidate_span, hi + candidate_span))
        for _ in range(20):
            v = rng.randint(lo - span, hi + span)
            cands.add(v)
        cands.discard(0)
        cands -= set(cur)
        if not cands:
            break
        best_v = None
        best_s = cur_score
        # sample a subset for speed
        cand_list = list(cands)
        rng.shuffle(cand_list)
        for v in cand_list[:60]:
            trial = cur + [v]
            s = _score(trial)
            if s > best_s:
                best_s = s
                best_v = v
        if best_v is None:
            # random accept to escape
            v = rng.choice(cand_list)
            cur.append(v)
            cur_score = _score(cur)
        else:
            cur.append(best_v)
            cur_score = best_s
    return cur, cur_score


def _repair_sums(a, deadline, rng, tries=4000):
    """Attack |A+A| directly: find duplicated sums and try to break them
    by swapping one element to a nearby value, accepting only if score improves."""
    cur = list(set(a))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    it = 0
    while time.time() < deadline and it < tries:
        it += 1
        n = len(cur)
        if n < 4:
            break
        # find duplicated sums
        sums = {}
        dup = None
        for i in range(n):
            for j in range(i, n):
                s = cur[i] + cur[j]
                if s in sums:
                    dup = (sums[s], (i, j))
                    break
                sums[s] = (i, j)
            if dup:
                break
        if dup is None:
            break
        (i0, j0), (i1, j1) = dup
        k = rng.choice([i0, j0, i1, j1])
        old = cur[k]
        improved = False
        for delta in (1, -1, 2, -2, 3, -3, 5, -5, 8, -8):
            cand = cur[:]
            cand[k] = old + delta
            if cand[k] in cand[:k] + cand[k+1:]:
                continue
            s = _score(cand)
            if s > cur_score:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
                improved = True
                break
        if not improved:
            # random walk on a random element
            k = rng.randrange(n)
            cand = cur[:]
            cand[k] += rng.randint(-15, 15)
            cand = list(set(cand))
            s = _score(cand)
            if s >= cur_score or rng.random() < 0.03:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
    return best, best_score


# Small Golomb rulers (max distinct differences) as structured seeds.
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
]


def _seed_golomb(n, scale, shift, jitter, rng):
    base = _GOLOMB[min(n, len(_GOLOMB)) - 1]
    a = []
    for x in base:
        v = int(round(x * scale)) + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    return a


def solve():
    rng = random.Random(0xBEEF)
    deadline = time.time() + 115
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Phase 1: greedy incremental builds from various seeds
    phase1_end = time.time() + 45
    trials = []
    for n in range(5, 13):
        for scale in (1, 2, 3, 5, 8, 13):
            trials.append((n, scale))
    rng.shuffle(trials)

    idx = 0
    while time.time() < phase1_end and time.time() < deadline:
        if idx < len(trials):
            n, scale = trials[idx]
            idx += 1
            shift = rng.randint(-scale * 15, scale * 15)
            jitter = rng.choice([0, 0, 1])
            seed = _seed_golomb(n, scale, shift, jitter, rng)
        else:
            n = rng.randint(4, 9)
            scale = rng.choice([1, 2, 3, 5, 8])
            seed = _seed_golomb(n, scale, rng.randint(-100, 100), 1, rng)

        target_n = rng.randint(max(6, len(seed)), 14)
        span = rng.choice([3, 5, 10, 20])
        cand, s = _greedy_build(seed, target_n,
                                min(phase1_end, deadline), rng, span)
        if s > best_score:
            best, best_score = cand[:], s

    # Phase 2: sum-collision repair on the best found so far
    phase2_end = time.time() + 40
    while time.time() < phase2_end and time.time() < deadline:
        work = best[:]
        # occasionally perturb before repair
        if rng.random() < 0.5:
            work = best[:]
            k = rng.randrange(len(work))
            work[k] += rng.randint(-10, 10)
            work = list(set(work))
        cand, s = _repair_sums(work, min(phase2_end, deadline), rng, tries=3000)
        if s > best_score:
            best, best_score = cand[:], s

    # Phase 3: more greedy builds seeded from best
    while time.time() < deadline:
        seed = best[:]
        if rng.random() < 0.7:
            # perturb
            for _ in range(rng.randint(1, 3)):
                k = rng.randrange(len(seed))
                seed[k] += rng.randint(-8, 8)
            seed = list(set(seed))
        target_n = rng.randint(max(6, len(seed)), 15)
        span = rng.choice([2, 3, 5, 10])
        cand, s = _greedy_build(seed, target_n, deadline, rng, span)
        if s > best_score:
            best, best_score = cand[:], s
        if time.time() < deadline and rng.random() < 0.5:
            cand, s = _repair_sums(best[:], deadline, rng, tries=1500)
            if s > best_score:
                best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
