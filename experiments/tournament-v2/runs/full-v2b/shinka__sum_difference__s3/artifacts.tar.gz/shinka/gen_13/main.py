# EVOLVE-BLOCK-START
"""Hybrid Golomb/Sidon-seeded simulated annealing search with targeted sum repair
for sets with large difference set and small sum set."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ls = len(sums)
    if ls < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def _stats(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


# Known good Golomb rulers (perfect/near-perfect) used as structured seeds.
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111,
     120, 126],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111,
     120, 126, 132, 140],
]


def _seed_golomb(n, scale, shift, jitter, rng):
    """Build a seed from a Golomb ruler of size ~n, scaled and jittered."""
    base = _GOLOMB[min(n, len(_GOLOMB)) - 1]
    a = []
    for x in base:
        v = int(round(x * scale)) + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    while len(a) < n:
        v = rng.randint(-scale * 100, scale * 100) + shift
        if v not in a:
            a.append(v)
    return a


def _local_search(seed, deadline, rng, temp0=4.0, temp_min=0.0005,
                  cool=0.99995):
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    cache = {tuple(sorted(cur)): cur_score}

    while time.time() < deadline:
        temp = max(temp_min, temp * cool)
        cand = cur[:]
        r = rng.random()
        if r < 0.45 and cand:
            # temperature-scaled Gaussian step
            i = rng.randrange(len(cand))
            step = max(1, int(abs(rng.gauss(0, temp * 30))))
            if rng.random() < 0.5:
                step = -step
            cand[i] += step
        elif r < 0.58 and cand:
            # small uniform step
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-500, 500)
        elif r < 0.70 and len(cand) >= 2:
            # reflect one element about the current mid-point (Sidon trick):
            # preserves many differences while creating sum collisions.
            lo = min(cand)
            hi = max(cand)
            center2 = lo + hi
            i = rng.randrange(len(cand))
            cand[i] = center2 - cand[i]
        elif r < 0.80 and len(cand) >= 2:
            # force a sum collision: pick two elements a,b and an existing sum s,
            # then set a <- s - b.
            sums = [x + y for x in cand for y in cand]
            if sums:
                s_existing = rng.choice(sums)
                i, j = rng.sample(range(len(cand)), 2)
                cand[i] = s_existing - cand[j]
        elif r < 0.90:
            # add a new element near the current range
            if cand:
                lo = min(cand)
                hi = max(cand)
                span = max(1, hi - lo)
                v = rng.randint(lo - span, hi + span)
            else:
                v = rng.randint(-50, 50)
            if v not in cand:
                cand.append(v)
        else:
            # remove an element (keep at least 4)
            if len(cand) > 4:
                del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        key = tuple(sorted(cand))
        s = cache.get(key)
        if s is None:
            s = _score(cand)
            cache[key] = s
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def _repair_sums(seed, deadline, rng):
    """Targeted move: find duplicate sum pairs and try to break them
    by nudging one element while preserving distinctness of differences."""
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    while time.time() < deadline:
        n = len(cur)
        if n < 4:
            break
        # find a duplicated sum
        sums = {}
        dup = None
        for i in range(n):
            for j in range(i, n):
                s = cur[i] + cur[j]
                if s in sums:
                    dup = (sums[s], (i, j))
                    break
                sums[s] = (i, j)
            if dup:
                break
        if dup is None:
            break
        (i0, j0), (i1, j1) = dup
        k = rng.choice([i0, j0, i1, j1])
        old = cur[k]
        for _ in range(8):
            cand = cur[:]
            cand[k] = old + rng.choice([-3, -2, -1, 1, 2, 3])
            cand = list(set(cand))
            s = _score(cand)
            if s >= cur_score:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
                break
        else:
            # random walk
            cand = cur[:]
            cand[k] = old + rng.randint(-20, 20)
            cand = list(set(cand))
            s = _score(cand)
            if s >= cur_score or rng.random() < 0.05:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
    return best, best_score


def solve():
    rng = random.Random(0xC0FFEE)
    deadline = time.time() + 118
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Wider trial grid biased toward larger n (bonus) and small scales
    # (keeps sums tightly packed, reducing |A+A|).
    trials = []
    for n in range(5, 21):
        for scale in (1, 1, 2, 2, 3, 5, 8, 13, 21):
            trials.append((n, scale))
    rng.shuffle(trials)

    idx = 0
    slice_count = 10
    while time.time() < deadline:
        if idx < len(trials):
            n, scale = trials[idx]
            idx += 1
            shift = rng.randint(-scale * 20, scale * 20)
            jitter = rng.choice([0, 0, 1, 2])
            seed = _seed_golomb(n, scale, shift, jitter, rng)
        else:
            n = rng.randint(5, 20)
            scale = rng.choice([1, 2, 3, 5, 8, 13, 21])
            seed = _seed_golomb(n, scale, rng.randint(-200, 200), 1, rng)

        remaining = deadline - time.time()
        if remaining <= 0:
            break
        slice_end = time.time() + max(0.3, remaining / slice_count)
        temp0 = rng.uniform(2.0, 8.0)
        cool = rng.uniform(0.99990, 0.99999)
        cand, s = _local_search(seed, slice_end, rng,
                                temp0=temp0, temp_min=0.0005, cool=cool)
        if s > best_score:
            best, best_score = cand[:], s
            slice_count = max(6, slice_count - 1)
        else:
            slice_count = min(24, slice_count + 1)

        # Occasionally refine the current best with targeted sum repair
        if time.time() < deadline and rng.random() < 0.35:
            rep_end = time.time() + max(0.4, (deadline - time.time()) / 10)
            cand, s = _repair_sums(best[:], rep_end, rng)
            if s > best_score:
                best, best_score = cand[:], s

    # Final targeted repair pass on the best solution.
    if time.time() < deadline:
        cand, s = _repair_sums(best[:], deadline, rng)
        if s > best_score:
            best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END