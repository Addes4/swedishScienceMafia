# EVOLVE-BLOCK-START
"""Improved solver: greedy Sidon construction + local search for sum-difference ratio."""
import math
import random
import time


def _score(a):
    """Compute log|A-A| / log|A+A| + small bonus for larger |A|."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _greedy_sidon(limit, target_size):
    """Build a greedy Sidon set in [0, limit] with up to target_size elements."""
    S = [0]
    used_diffs = {0}
    candidates = list(range(1, limit + 1))
    random.shuffle(candidates)
    for c in candidates:
        if len(S) >= target_size:
            break
        new_diffs = {c - s for s in S}
        if new_diffs & used_diffs:
            continue
        new_diffs |= {s - c for s in S}
        if new_diffs & used_diffs:
            continue
        S.append(c)
        used_diffs |= new_diffs
    return S


def _local_search(seed, deadline):
    """Hill-climb from a seed set to improve the score."""
    best = list(set(seed))
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    step = 0
    while time.time() < deadline:
        step += 1
        cand = cur[:]
        # Perturb one element or add/remove
        r = random.random()
        if r < 0.6 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif r < 0.85:
            cand.append(random.randint(-100, 100))
        elif len(cand) > 3:
            i = random.randrange(len(cand))
            del cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur, cur_score = best[:], best_score
    return best, best_score


def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 100  # leave margin within 120s
    best = None
    best_score = -1.0

    # Phase 1: multiple greedy Sidon constructions with different limits
    for limit, target in [(200, 20), (500, 30), (1000, 40), (2000, 50)]:
        for _ in range(3):
            S = _greedy_sidon(limit, target)
            if len(S) < 2:
                continue
            # Shift to center around 0
            S = [x - limit // 2 for x in S]
            sc = _score(S)
            if sc > best_score:
                best, best_score = S[:], sc

    # Phase 2: local search from best found so far
    if best is not None:
        cand, sc = _local_search(best, deadline)
        if sc > best_score:
            best, best_score = cand, sc

    # Phase 3: try a few known good structured sets
    # Arithmetic progression with a few gaps (small sum set, large diff set)
    for n in [10, 15, 20, 25, 30]:
        base = list(range(n))
        # Add a Sidon perturbation
        for _ in range(5):
            pert = base[:]
            for _ in range(3):
                i = random.randrange(len(pert))
                pert[i] += random.randint(-2, 2)
            pert = list(set(pert))
            sc = _score(pert)
            if sc > best_score:
                best, best_score = pert, sc

    # Phase 4: final polish with small perturbations
    if best is not None:
        cand, sc = _local_search(best, min(time.time() + 10, deadline))
        if sc > best_score:
            best, best_score = cand, sc

    if best is None or len(best) < 2:
        best = [0, 1, 2, 4, 8, 13]
    return sorted(set(best))
# EVOLVE-BLOCK-END