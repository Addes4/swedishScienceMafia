# EVOLVE-BLOCK-START
"""Hybrid Golomb/Sidon-seeded simulated annealing search for sets with large difference set and small sum set."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


# Known good Golomb rulers (perfect/near-perfect) used as structured seeds.
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
]


def _seed_set(n, scale, shift, jitter, rng):
    """Build a seed from a Golomb ruler of size ~n, scaled and jittered."""
    base = _GOLOMB[min(n, len(_GOLOMB)) - 1]
    a = []
    for x in base:
        v = x * scale + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    # pad up to n with random distinct values if requested larger
    while len(a) < n:
        v = rng.randint(-scale * 100, scale * 100)
        if v not in a:
            a.append(v)
    return a


def _local_search(seed, deadline, rng, temp0=3.0, temp_min=0.05):
    cur = seed[:]
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    while time.time() < deadline:
        temp = max(temp_min, temp * 0.99995)
        cand = cur[:]
        r = rng.random()
        if r < 0.75 and cand:
            # mutate one element with temperature-scaled step
            i = rng.randrange(len(cand))
            step = max(1, int(abs(rng.gauss(0, temp * 30))))
            if rng.random() < 0.5:
                step = -step
            cand[i] += step
        elif r < 0.90:
            # add a new element near the current range
            if cand:
                lo = min(cand)
                hi = max(cand)
                span = max(1, hi - lo)
                v = rng.randint(lo - span, hi + span)
            else:
                v = rng.randint(-50, 50)
            if v not in cand:
                cand.append(v)
        else:
            # remove an element (keep at least 4)
            if len(cand) > 4:
                del cand[rng.randrange(len(cand))]
        # dedupe
        cand = list(set(cand))
        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-6)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try a range of sizes and scalings; Golomb-like seeds give strong starts.
    trials = []
    for n in range(5, 16):
        for scale in (1, 2, 3, 5, 8, 13):
            trials.append((n, scale))
    rng.shuffle(trials)

    idx = 0
    while time.time() < deadline:
        if idx < len(trials):
            n, scale = trials[idx]
            idx += 1
            shift = rng.randint(-scale * 20, scale * 20)
            jitter = rng.choice([0, 0, 1, 2])
            seed = _seed_set(n, scale, shift, jitter, rng)
        else:
            # random restart around best
            n = rng.randint(5, 15)
            scale = rng.choice([1, 2, 3, 5, 8])
            seed = _seed_set(n, scale, rng.randint(-100, 100), 1, rng)
        # allocate remaining time slice per restart
        remaining = deadline - time.time()
        if remaining <= 0:
            break
        slice_end = time.time() + max(0.5, remaining / 8)
        cand, s = _local_search(seed, slice_end, rng,
                                temp0=rng.uniform(1.5, 5.0),
                                temp_min=0.02)
        if s > best_score:
            best, best_score = cand[:], s
        # also refine the current best occasionally
        if time.time() < deadline and rng.random() < 0.3:
            slice_end = time.time() + max(0.5, (deadline - time.time()) / 6)
            cand, s = _local_search(best[:], slice_end, rng,
                                    temp0=1.0, temp_min=0.01)
            if s > best_score:
                best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
