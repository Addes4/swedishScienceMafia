# EVOLVE-BLOCK-START
"""Diversity-preserving elite annealing for large |A-A| / small |A+A|.

Architecture:
    seeds -> explore_anneal -> diversified_elite_pool -> exploit_anneal -> output
"""
import math
import random
import time


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------
_SCORE_CACHE = {}


def _score(a):
    key = tuple(sorted(set(a)))
    v = _SCORE_CACHE.get(key)
    if v is not None:
        return v
    a = list(key)
    n = len(a)
    if n < 2:
        _SCORE_CACHE[key] = 0.0
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ls = len(sums)
    if ls < 2:
        _SCORE_CACHE[key] = 0.0
        return 0.0
    v = math.log(len(diffs)) / math.log(ls) + (1.0 - 1.0 / n) / 100.0
    if len(_SCORE_CACHE) > 400000:
        _SCORE_CACHE.clear()
    _SCORE_CACHE[key] = v
    return v


def _stats(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


# ---------------------------------------------------------------------------
# Seeds
# ---------------------------------------------------------------------------
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 5, 12, 25, 27, 35, 41, 44],
    [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111,
     120, 126],
    [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 75, 79, 81, 90, 94, 97, 105, 111,
     120, 126, 132, 140],
]


def _seed_golomb(n, scale, shift, jitter, rng, affine_b=0):
    base = _GOLOMB[min(n, len(_GOLOMB)) - 1]
    a = []
    for x in base:
        v = int(round(x * scale)) + shift
        if jitter:
            v += rng.randint(-jitter, jitter)
        a.append(v)
    while len(a) < n:
        v = rng.randint(-scale * 80, scale * 80) + shift
        if v not in a:
            a.append(v)
    if affine_b:
        a = [x + affine_b for x in a]
    return a


# ---------------------------------------------------------------------------
# Moves
# ---------------------------------------------------------------------------
def _sum_collision_move(a, rng):
    """Force a duplicate sum by replacing one element, targeting |A+A|."""
    n = len(a)
    if n < 3:
        return None
    sums = {}
    for i in range(n):
        for j in range(i, n):
            sums.setdefault(a[i] + a[j], []).append((i, j))
    unique_pairs = [(i, j) for i in range(n) for j in range(i, n)
                    if len(sums[a[i] + a[j]]) == 1]
    if not unique_pairs:
        return None
    i, j = rng.choice(unique_pairs)
    others = [(k, l) for k in range(n) for l in range(k, n)
              if (k, l) != (i, j)]
    if not others:
        return None
    k, l = rng.choice(others)
    target = a[k] + a[l]
    if a[i] >= a[j]:
        new_val = target - a[j]
        if new_val in a:
            return None
        cand = a[:]
        cand[i] = new_val
    else:
        new_val = target - a[i]
        if new_val in a:
            return None
        cand = a[:]
        cand[j] = new_val
    return list(set(cand))


def _perturb(cand, rng, temp):
    """Random structural perturbation."""
    r = rng.random()
    if r < 0.55 and cand:
        i = rng.randrange(len(cand))
        step = max(1, int(round(abs(rng.gauss(0, temp * 50)))))
        if rng.random() < 0.35:
            step *= (2 ** rng.randint(0, 3))
        if rng.random() < 0.5:
            step = -step
        cand[i] += step
    elif r < 0.72 and cand:
        i = rng.randrange(len(cand))
        cand[i] += rng.randint(-500, 500)
    elif r < 0.90:
        if cand:
            lo, hi = min(cand), max(cand)
            span = max(1, hi - lo)
            v = rng.randint(lo - span, hi + span)
        else:
            v = rng.randint(-50, 50)
        if v not in cand:
            cand.append(v)
    else:
        if len(cand) > 4:
            del cand[rng.randrange(len(cand))]
    return cand


# ---------------------------------------------------------------------------
# Explore phase (fast, aggressive)
# ---------------------------------------------------------------------------
def explore_anneal(seed, deadline, rng, temp0=6.0, temp_min=0.005,
                   cool=0.99996, target=0.0):
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    stagnate = 0

    while time.time() < deadline:
        gap = max(0.0, target - best_score)
        tmin = max(temp_min, 0.005 * gap)
        temp = max(tmin, temp * cool)
        cand = cur[:]
        r = rng.random()
        if r < 0.45:
            sc = _sum_collision_move(cur, rng)
            if sc is not None:
                cand = sc
            else:
                cand = _perturb(cand, rng, temp)
        else:
            cand = _perturb(cand, rng, temp)
        cand = list(set(cand))
        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
                stagnate = 0
            else:
                stagnate += 1
        else:
            stagnate += 1
        if stagnate > 3500:
            if cur:
                i = rng.randrange(len(cur))
                cur[i] += rng.choice([-1, 1]) * (2 ** rng.randint(4, 11))
                cur = list(set(cur))
                cur_score = _score(cur)
                if cur_score > best_score:
                    best, best_score = cur[:], cur_score
            stagnate = 0
    return best, best_score


# ---------------------------------------------------------------------------
# Exploit phase (targeted sum-collision repair)
# ---------------------------------------------------------------------------
def exploit_anneal(seed, deadline, rng, temp0=2.0, temp_min=0.001,
                   cool=0.99997):
    cur = list(set(seed))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = temp0
    while time.time() < deadline:
        temp = max(temp_min, temp * cool)
        cand = None
        r = rng.random()
        if r < 0.55:
            cand = _sum_collision_move(cur, rng)
        if cand is None:
            cand = cur[:]
            if cand and rng.random() < 0.7:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-3, -2, -1, 1, 2, 3])
            else:
                cand = _perturb(cand, rng, temp)
        cand = list(set(cand))
        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


# ---------------------------------------------------------------------------
# Diversity-preserving elite pool
# ---------------------------------------------------------------------------
def _elem_set(a):
    return frozenset(a)


def _jaccard(s1, s2):
    if not s1 and not s2:
        return 1.0
    inter = len(s1 & s2)
    union = len(s1 | s2)
    return inter / union if union else 0.0


class ElitePool:
    """Keeps a pool of high-scoring solutions that are mutually diverse."""
    def __init__(self, max_size=8, min_jaccard=0.30):
        self.max_size = max_size
        self.min_jaccard = min_jaccard
        self.items = []  # list of (list_a, score, frozenset)

    def _too_similar(self, es):
        for _, _, es2 in self.items:
            if _jaccard(es, es2) > 1.0 - self.min_jaccard:
                return True
        return False

    def offer(self, a, score):
        if score <= 0:
            return False
        es = _elem_set(a)
        # exact duplicate -> skip
        for _, _, es2 in self.items:
            if es == es2:
                return False
        if self._too_similar(es) and len(self.items) >= self.max_size:
            # replace the most similar existing item if the new one is better
            worst_idx = -1
            worst_sim = -1.0
            for idx, (_, s2, es2) in enumerate(self.items):
                sim = _jaccard(es, es2)
                if sim > worst_sim:
                    worst_sim = sim
                    worst_idx = idx
            if worst_idx >= 0 and score > self.items[worst_idx][1]:
                self.items[worst_idx] = (list(a), score, es)
                return True
            return False
        self.items.append((list(a), score, es))
        self.items.sort(key=lambda t: -t[1])
        if len(self.items) > self.max_size:
            self.items = self.items[:self.max_size]
        return True

    def best(self):
        if not self.items:
            return None, 0.0
        return self.items[0][0], self.items[0][1]

    def most_distant_from(self, a):
        """Return elite element-set most distant (low Jaccard) from a."""
        es = _elem_set(a)
        if not self.items:
            return None
        best = None
        best_d = 2.0
        for item_a, _, es2 in self.items:
            d = _jaccard(es, es2)
            if d < best_d:
                best_d = d
                best = item_a
        return best

    def random_member(self, rng):
        if not self.items:
            return None
        return rng.choice(self.items)[0]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def solve():
    rng = random.Random(0xD1CEB00B)
    deadline = time.time() + 118
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    pool = ElitePool(max_size=8, min_jaccard=0.30)
    pool.offer(best, best_score)

    # Seed schedule
    trials = []
    for n in range(5, 18):
        for scale in (1, 2, 3, 5, 8, 13, 21, 34):
            trials.append((n, scale))
    rng.shuffle(trials)

    idx = 0
    since_improve = 0
    slice_budget = 10

    while time.time() < deadline:
        # ---- Pick a seed ------------------------------------------------
        if idx < len(trials):
            n, scale = trials[idx]
            idx += 1
            shift = rng.randint(-scale * 20, scale * 20)
            jitter = rng.choice([0, 0, 1, 2])
            affine_b = rng.choice([0, 0, 0, rng.randint(-scale * 10, scale * 10)])
            seed = _seed_golomb(n, scale, shift, jitter, rng, affine_b)
        elif since_improve > 8000 and pool.items:
            # Re-heat from the *most diverse* elite member to escape basin
            base_a = pool.random_member(rng)
            far = pool.most_distant_from(base_a) if base_a else None
            src = far if far is not None else base_a
            seed = list(src)
            if seed and rng.random() < 0.6:
                i = rng.randrange(len(seed))
                seed[i] += rng.randint(-300, 300)
            since_improve = 0
        else:
            # Mostly restart from a diverse elite
            if pool.items and rng.random() < 0.55:
                seed = list(pool.random_member(rng))
                if seed and rng.random() < 0.5:
                    i = rng.randrange(len(seed))
                    seed[i] += rng.randint(-150, 150)
            else:
                n = rng.randint(5, 18)
                scale = rng.choice([1, 2, 3, 5, 8, 13, 21])
                seed = _seed_golomb(n, scale, rng.randint(-200, 200), 1, rng)

        remaining = deadline - time.time()
        if remaining <= 0:
            break

        # ---- Explore phase ---------------------------------------------
        expl_end = time.time() + max(0.3, remaining / slice_budget)
        t0 = rng.uniform(3.0, 12.0)
        cool = rng.uniform(0.99990, 0.99999)
        cand, s = explore_anneal(seed, expl_end, rng,
                                 temp0=t0, temp_min=0.005, cool=cool,
                                 target=best_score)

        if s > best_score:
            best, best_score = cand[:], s
            since_improve = 0
            slice_budget = max(5, slice_budget - 1)
        else:
            since_improve += 1
            slice_budget = min(20, slice_budget + 1)

        # ---- Exploit phase (sum-collision repair) ----------------------
        if time.time() < deadline:
            exp_end = time.time() + max(0.3, (deadline - time.time()) / 12)
            cand2, s2 = exploit_anneal(cand, exp_end, rng,
                                       temp0=rng.uniform(1.0, 3.0),
                                       temp_min=0.001)
            if s2 > s:
                cand, s = cand2, s2
                if s > best_score:
                    best, best_score = cand[:], s
                    since_improve = 0

        # ---- Diversified elite pool gets first look --------------------
        pool.offer(cand, s)

        # ---- Occasionally exploit the current global best --------------
        if time.time() < deadline and rng.random() < 0.30:
            exp_end = time.time() + max(0.4, (deadline - time.time()) / 10)
            cand3, s3 = exploit_anneal(best[:], exp_end, rng,
                                       temp0=1.0, temp_min=0.0005)
            if s3 > best_score:
                best, best_score = cand3[:], s3
                pool.offer(best, best_score)

    # ---- Final polish: greedy sum-collision on best --------------------
    if time.time() < deadline:
        cur = best[:]
        cur_score = best_score
        while time.time() < deadline:
            cand = _sum_collision_move(cur, rng)
            if cand is None:
                # try a small nudge
                cand = cur[:]
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-2, -1, 1, 2])
                cand = list(set(cand))
            s = _score(cand)
            if s >= cur_score:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
            elif rng.random() < 0.01:
                cur, cur_score = cand, s

    return sorted(set(best))
# EVOLVE-BLOCK-END
