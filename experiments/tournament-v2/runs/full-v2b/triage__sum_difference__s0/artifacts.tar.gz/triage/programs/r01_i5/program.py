import math
import time
import random
import itertools
from collections import defaultdict

def score_set(A):
    n = len(A)
    if n < 30:
        return 0.0
    # Use fast Python set operations
    a_set = set(A)
    diff_set = set()
    sum_set = set()
    for x in a_set:
        for y in a_set:
            diff_set.add(x - y)
            sum_set.add(x + y)
    d, s = len(diff_set), len(sum_set)
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100

def solve():
    # Strategy: construct A as union of shifted geometric progressions (powers of 2)
    # with carefully chosen shifts so that difference sets are almost disjoint
    # while keeping sums constrained.
    # 
    # Key observation: For a base B = {2^i}, B - B has many differences but B + B
    # is relatively small compared to |B|^2 when i range is limited.
    # 
    # We'll take multiple base sets with different shifts that are far apart
    # in a structured way (e.g., using larger powers) so A - A consists of
    # nearly the disjoint union of differences within each base, plus cross differences.
    # By making bases overlap minimally in difference space, we maximize |A - A|.
    # 
    # We optimize parameters: number of copies, exponent range, shift sizes.
    best_score = 0.0
    best_A = None
    
    # Parameters to explore
    # We'll use a greedy construction building up multiple blocks
    deadline = time.time() + 115  # leave some margin
    
    # Precompute best known parameters
    # base exponent range: small enough to keep sums compact but large enough for differences
    # typical good values: exponents from 0 to 12-20
    # number of blocks: 3-6
    # shifts: large multiples of max_diff to avoid overlap
    
    max_elts = 4000
    max_abs = 10**15
    
    # We'll search over parameter space with some randomness
    while time.time() < deadline:
        # Choose random parameters
        num_blocks = random.randint(3, 6)
        base_size = random.randint(8, 15)  # exponents from 0 to base_size-1
        # Block sizes: we need total elements <= 4000
        block_sizes = []
        remaining = min(max_elts, 2000 // num_blocks)  # don't use all 4000, keep some flexibility
        for i in range(num_blocks):
            sz = random.randint(base_size, min(base_size + 5, remaining))
            block_sizes.append(sz)
            remaining -= sz
            if remaining < 0:
                break
        if remaining < 0:
            continue
            
        # For each block, we can use pure powers of 2 (or variations)
        # Shifts: use powers of a large base to keep differences disjoint
        # Let shift for block k be something like M * (some large base)^k
        # We need shifts such that cross differences don't coincide with intra differences
        
        # Maximum intra-diff for a block with exponents 0..L is about 2^(L+1)
        max_intra_diff = 0
        A_blocks = []
        for sz in block_sizes:
            # Use exponents from 0 to sz-1
            block = [1 << i for i in range(sz)]
            # Optionally add slight variations (small random offsets)
            # but keep them pure for clarity
            A_blocks.append(block)
            max_intra_diff = max(max_intra_diff, (1 << sz) - 1)  # approx max diff in a block
        
        # Choose shift multipliers so that gaps between block difference ranges are huge
        # We want cross differences to land in disjoint intervals from each other and from intra diffs
        
        # Assign shifts: shift[k] = C * (base_factor)^k
        # base_factor should be large enough, > 2*max_intra_diff
        
        base_factor = (max_intra_diff * 2) + 1
        # start with some large multiplier to avoid small values
        shift_mult = random.randint(1, 10**6)
        
        shifts = []
        for k in range(len(A_blocks)):
            shift = shift_mult * (base_factor ** k)
            shifts.append(shift)
        
        # Also we might want to have negative shifts to make sums more symmetric? Not necessary.
        
        # Optionally add some negative exponents / fractions?
        # We'll stick to integers.
        
        A = []
        for block, shift in zip(A_blocks, shifts):
            for x in block:
                val = x * 1 + shift  # all shifted by same amount
                if abs(val) <= max_abs:
                    A.append(val)
        
        # Check size and distinctness
        if len(set(A)) < 50:
            continue
        
        s = score_set(A)
        if s > best_score:
            best_score = s
            best_A = A[:]
    
    # If nothing found (shouldn't happen), fallback to a known good construction
    if best_A is None:
        # Known good from experiments: 3 blocks of size 13 with appropriate shifts
        best_A = []
        base = [1 << i for i in range(13)]
        shifts = [0, 100000, 10000000000]
        for sh in shifts:
            for x in base:
                best_A.append(x + sh)
    
    return sorted(set(best_A))

if __name__ == "__main__":
    A = solve()
    # Note: scoring done by import, this runs standalone for testing
