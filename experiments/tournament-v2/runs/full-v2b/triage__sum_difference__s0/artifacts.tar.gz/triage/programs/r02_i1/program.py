# EVOLVE-BLOCK-START
"""Genetic Algorithm with crossover, mutation, and promising number pool for sum-difference set optimization."""
import math
import random
import time


def _compute_metrics(a):
    """Compute |A-A|, |A+A|, and |A| for a set A."""
    a = set(a)
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums), len(a)


def _score(a):
    """Compute the optimization objective score."""
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs, sums, size = _compute_metrics(a)
    result = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
    return result


def _unique_sort(lst):
    """Return sorted list of unique elements."""
    return sorted(set(lst))


def generate_initial_population(num_sets):
    """Generate initial candidate sets using structured patterns."""
    pop = []
    base_values = [random.randint(1, 500) for _ in range(10)]
    base_values = sorted(list(set(base_values)))
    
    for _ in range(num_sets):
        # Try various structured patterns
        pattern_choice = random.choice(['arithmetic', 'dense', 'sparse', 'mixed'])
        
        if pattern_choice == 'arithmetic':
            start = random.randint(1, 100)
            step = random.randint(2, 20)
            size = random.randint(5, 15)
            values = [start + i * step for i in range(size)]
        elif pattern_choice == 'dense':
            range_start = random.randint(1, 800)
            range_size = random.randint(30, 60)
            values = list(range(range_start, range_start + range_size))
        elif pattern_choice == 'sparse':
            values = [random.randint(1, 1000) for _ in range(random.randint(6, 16))]
        else:  # mixed
            values = [random.randint(1, 1000) for _ in range(random.randint(5, 15))]
        
        pop.append(_unique_sort(values))
    
    return pop


def crossover(parent1, parent2):
    """Combine subset from each parent, maintain distinct integers."""
    s1 = set(parent1)
    s2 = set(parent2)
    
    # Allow some portions from each
    subset1_size = random.randint(len(s1) // 3, len(s1) // 2)
    subset2_size = random.randint(len(s2) // 3, len(s2) // 2)
    
    if s1:
        indices1 = random.sample(range(len(parent1)), min(subset1_size, len(s1)))
        subset1 = [parent1[i] for i in indices1]
    else:
        subset1 = []
    
    if s2:
        indices2 = random.sample(range(len(parent2)), min(subset2_size, len(s2)))
        subset2 = [parent2[i] for i in indices2]
    else:
        subset2 = []
    
    # Combine with slight perturbation
    result = subset1 + subset2
    if random.random() < 0.3 and result:
        idx = random.randint(0, len(result) - 1)
        result[idx] += random.randint(-10, 10)
    
    return _unique_sort(result)


def mutation(chromosome, mutation_pool=None):
    """Mutate the chromosome by adding/removing elements."""
    new_chrom = chromosome[:]
    
    if not chromosome:
        new_chrom = []
    
    # Random insertions/deletions
    if random.random() < 0.4 and len(new_chrom) < 30:
        new_val = random.randint(1, 5000)
        if new_val not in set(new_chrom):
            new_chrom.append(new_val)
    
    if random.random() < 0.3 and len(new_chrom) > 3:
        idx = random.randint(0, len(new_chrom) - 1)
        new_chrom.pop(idx)
    
    # Small perturbations
    if random.random() < 0.5 and len(new_chrom) > 3:
        idx = random.randint(0, len(new_chrom) - 1)
        adjustment = random.randint(-10, 10)
        if adjustment != 0 and new_chrom[idx] != new_chrom[idx] - adjustment:
            new_chrom[idx] = new_chrom[idx] + adjustment
    
    return _unique_sort(new_chrom)


def _gen_number_pool(start_idx, num_numbers):
    """Generate a pool of candidate numbers for mutation."""
    pool = set()
    base = [random.randint(1, 100) for _ in range(30)]
    for _ in range(num_numbers):
        trial_base = [b * random.randint(1, 5) + random.randint(0, 3) for b in base]
        pool.update(trial_base)
    return sorted(list(set(pool))) + [1000, 1500, 2000, 2500, 3000]


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    best = None
    best_score = 0.0
    deadline = time.time() + 120
    
    pool = _gen_number_pool(0, 50)
    
    # Initialize population
    population = generate_initial_population(10)
    
    while time.time() < deadline:
        # Evaluate current population
        indices = list(range(len(population)))
        scores = []
        for i, chom in enumerate(population):
            chom = _unique_sort(chom)
            sc = _score(chom)
            scores.append((sc, chom[:]))
        
        # Keep best
        scores.sort(key=lambda x: x[0], reverse=True)
        best_score = max(best_score, scores[0][0])
        if scores[0][0] > best_score:
            best = list(scores[0][1])
        
        if not monthly_tail():
            break
        
        # Generate new population
        new_population = []
        
        # Elitism: keep top 3
        for i in range(min(3, len(scores))):
            new_population.append(list(scores[i][1]))
        
        # Crossover + mutation
        while len(new_population) < 20:
            p1, p2 = random.sample(indices, 2)
            child = crossover(population[p1], population[p2])
            child = mutation(child, pool)
            new_population.append(child)
        
        # Add promising single elements
        for val in pool[:5]:
            cand = [val] + [random.randint(1, 100) for _ in range(random.randint(2, 4))]
            if len(_unique_sort(cand)) < 15:
                new_population.append(_unique_sort(cand))
        
        population = new_population
        
        # Probabilistic replacement if not improving
        if time.time() - deadline > 0:
            continue
        
        if random.random() < 0.01 and len(population) > 20:
            population = random.sample(population, 20)
    
    return _unique_sort(best) if best else []


def monthly_tail():
    """Check if we should continue iterating."""
    return time.time() < time.time() + 120


solve()
# EVOLVE-BLOCK-END
