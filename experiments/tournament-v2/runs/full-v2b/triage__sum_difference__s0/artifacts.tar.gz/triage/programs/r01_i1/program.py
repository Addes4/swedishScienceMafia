# EVOLVE-BLOCK-START
"""Simulated annealing over integer sets targeting |A-A| large, |A+A| small.

The key structural trick used here (in addition to simulated annealing) is the
classical asymmetric construction: take A as an arithmetic progression so that
A+A is a (dense) arithmetic progression with few elements, while A-A is a longer
arithmetic progression; then perturb elements to break collisions in A+A
without creating too many new sums, while maximising the count of distinct
differences.  Simulated annealing explores add/drop/swap/move moves with an
adaptive temperature schedule over the full budget.
"""
import math
import random
import time

import numpy as np


def _fast_counts(a):
    """Return (|A-A|, |A+A|) for a sorted list/tuple a using numpy."""
    arr = np.asarray(a, dtype=np.int64)
    n = arr.size
    # differences
    d = arr[:, None] - arr[None, :]
    diff_count = int(np.unique(d).size)
    # sums
    s = arr[:, None] + arr[None, :]
    sum_count = int(np.unique(s).size)
    return diff_count, sum_count


def _score_from_counts(dc, sc, n):
    if sc <= 1 or n < 2:
        return 0.0
    return math.log(dc) / math.log(sc) + (1 - 1 / n) / 100


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    dc, sc = _fast_counts(a)
    return _score_from_counts(dc, sc, n), dc, sc


def _initial_set():
    """A good asymmetric start: arithmetic progression plus a twist."""
    # Arithmetic progression: A+A is an AP of length 2m-1, A-A an AP of length 2m-1
    # but with distinct step it gives many differences.
    base = [i for i in range(10)]
    # add some half-step offsets to enrich differences while limiting sums
    extra = [2 * i + 1 for i in range(5)]
    a = sorted(set(base + extra))
    return a


def solve():
    random.seed(12345)
    np.random.seed(12345)

    deadline = time.time() + 115.0

    best = _initial_set()
    best_score, best_dc, best_sc = _score(best)
    best_list = best[:]

    # Current state
    cur = best[:]
    cur_dc, cur_sc = best_dc, best_sc

    # Simulated annealing parameters
    T0 = 0.35
    T1 = 0.005
    # We'll adapt temperature based on elapsed time
    start = time.time()

    def temperature():
        frac = (time.time() - start) / max(1e-9, (deadline - start))
        frac = min(1.0, max(0.0, frac))
        # exponential cooling
        return T0 * (T1 / T0) ** frac

    cur_score = best_score
    cur_len = len(cur)

    iters = 0
    last_improve = time.time()

    while time.time() < deadline:
        iters += 1
        T = temperature()

        move = random.random()
        cand = cur[:]
        changed = False

        if move < 0.40:
            # perturb one element
            i = random.randrange(len(cand))
            step = random.choice([-2, -1, 1, 2, -3, 3])
            cand[i] += step
            changed = True
        elif move < 0.60:
            # add a new element near existing range
            lo = min(cand)
            hi = max(cand)
            span = max(1, hi - lo)
            val = random.randint(lo - span // 4 - 1, hi + span // 4 + 1)
            if val not in cand:
                cand.append(val)
                changed = True
        elif move < 0.75:
            # drop an element
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
                changed = True
        elif move < 0.90:
            # swap: replace a random element with a nearby new integer
            if len(cand) >= 3:
                i = random.randrange(len(cand))
                lo = min(cand)
                hi = max(cand)
                span = max(1, hi - lo)
                val = random.randint(lo - span // 4 - 1, hi + span // 4 + 1)
                if val not in cand:
                    cand[i] = val
                    changed = True
        else:
            # shift whole set (translation invariance: useless, so perturb a block)
            i = random.randrange(len(cand))
            cand[i] += random.choice([-4, -3, 3, 4])
            changed = True

        if not changed:
            continue

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        n = len(cand)
        dc, sc = _fast_counts(cand)
        s = _score_from_counts(dc, sc, n)

        delta = s - cur_score
        if delta >= 0 or random.random() < math.exp(delta / max(T, 1e-9)):
            cur = cand
            cur_score = s
            cur_dc, cur_sc = dc, sc
            cur_len = n
            if s > best_score:
                best_score = s
                best_list = cand[:]
                best_dc, best_sc = dc, sc
                last_improve = time.time()

        # Restart from best if stuck for a long time (rare)
        if time.time() - last_improve > 25.0:
            cur = best_list[:]
            cur_score = best_score
            last_improve = time.time()

    # Local polish: hill-climb from best with small perturbations
    cur = best_list[:]
    cur_score, cur_dc, cur_sc = _score(cur)
    end = time.time() + max(0.0, deadline - time.time())
    # allow a bit more time if available
    polish_deadline = min(deadline + 3.0, time.time() + 5.0)
    while time.time() < polish_deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice([-1, 1, -2, 2])
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        dc, sc = _fast_counts(cand)
        s = _score_from_counts(dc, sc, len(cand))
        if s >= cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best_list = cand[:]

    return sorted(set(best_list))
# EVOLVE-BLOCK-END
