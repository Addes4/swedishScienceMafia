import math
import time
from itertools import product
import random

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def construct_digit_set(p, S, num_blocks, block_size):
    valid_blocks = []
    for digits in product(range(p), repeat=block_size):
        if sum(digits) in S:
            val = sum(d * (p ** j) for j, d in enumerate(digits))
            valid_blocks.append((val, sum(digits)))
        if len(valid_blocks) > 100000000:
            break

    if not valid_blocks:
        return []

    max_block_val = max(block for block, _ in valid_blocks)
    separation = p ** (block_size + 1)

    result = []
    for block_combo in product(valid_blocks, repeat=num_blocks):
        val = 0
        for block_idx, (block_val, _) in enumerate(block_combo):
            val += block_val * (separation ** block_idx)
        result.append(val)
    return result

def score_convolution_improvement(p, S, num_blocks, block_size, seed=None):
    random.seed(seed)
    if seed is None:
        seed = random.randint(0, 2**31)
    try:
        from scipy.optimize import minimize
        import numpy as np
    except:
        return 0.0

    best_set = list(construct_digit_set(p, S, num_blocks, block_size))

    if len(best_set) < 10:
        return 0.0
    s = score_set(best_set)
    if s > 0.0:
        return s
    best_local = best_set[:]
    best_local_score = s
    deadline = time.time() + time.time() + 50
    for iteration in range(int((-time.time() + 50) / 1)):
        try:
            if time.time() > deadline - 30:
                break
            for k in range(1, min(6, 10)):
                for S in [{1}, {2}, {3}, {1, 2}, {2, 3}, {1, 2, 3}]:
                    config_set = construct_digit_set(k, S, k, 3)
                    if not config_set:
                        continue
                    s_config = score_set(config_set)
                    if s_config > best_local_score:
                        best_local_score = s_config
                        best_local = list(config_set)
            for delta in range(-1, 2):
                cand = list(best_local)
                for i in range(min(2000, len(cand))):
                    cand[i] += delta
                    s_cand = score_set(cand)
                    if s_cand > best_local_score:
                        best_local_score = s_cand
                        best_local = cand[:]
                        break
            if best_local_score > best_local_score:
                break
        except:
            continue
    if len(best_local) > 4000:
        best_local = sorted(set(best_local))[:4000]
    return best_local

def solve():
    deadline = time.time() + 119
    best_overall = []
    best_overall_score = 0

    attempts = []
    for p in [3, 5, 7, 11, 13]:
        for num_blocks in range(1, 6):
            for block_size in range(1, 5):
                if time.time() > deadline - 50:
                    break
                for S in [{1}, {2}, {3}, {1, 2}, {2, 3}, {1, 2, 3}, {2, 3, 4}]:
                    if time.time() > deadline - 50:
                        break
                    A = construct_digit_set(p, S, num_blocks, block_size)
                    if not A:
                        continue
                    try:
                        A = set(A)
                        if len(A) <= 10:
                            continue
                        if len(A) > 4000:
                            A = sorted(A)[:4000]
                        A = list(A)
                        if len(A) < 10:
                            continue
                        s = score_set(A)
                        if s > best_overall_score:
                            best_overall_score = s
                            best_overall = list(A)
                    except:
                        continue
            if best_overall_score > 1.20:
                break
    return best_overall

A = solve()
A = sorted(set(A))


if __name__ == "__main__":
    print(len(A))
    print(A[:20])
    print(A[-20:])
    print(score_set(A))
    

