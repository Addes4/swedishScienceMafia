import math
import time
import random
from itertools import combinations, product
from functools import lru_cache

def compute_score(A):
    """Compute the objective score for a set A."""
    n = len(A)
    if n < 2:
        return 0.0
    diff_set = set()
    sum_set = set()
    for x in A:
        for y in A:
            diff_set.add(x - y)
            sum_set.add(x + y)
    log_ratio = math.log(len(diff_set)) / math.log(len(sum_set))
    return log_ratio + (1 - 1/n) / 100

def score_from_counts(n, ndiff, nsum):
    """Score given set size, diff count, sum count."""
    return math.log(ndiff) / math.log(nsum) + (1 - 1/n) / 100

def search_small_sets(max_size=12, search_range=15, time_budget=30):
    """Exhaustive-ish search for small sets with high score."""
    deadline = time.time() + time_budget
    best_seeds = []  # (set_tuple, score, ndiff, nsum)
    
    # Use integers from -search_range to +search_range
    base_pool = list(range(-search_range, search_range+1))
    
    # We'll use heuristic search since exhaustive is too large
    # Start with random picks and local search
    
    for target_size in range(4, min(max_size+1, 13)):
        if time.time() > deadline:
            break
        
        # Generate some random candidates
        for _ in range(20000):
            if time.time() > deadline:
                break
            cand = sorted(random.sample(base_pool, min(target_size, len(base_pool))))
            if len(set(cand)) < target_size:
                continue
            
            # Compute exact counts
            diffs = set()
            sums = set()
            for i in range(target_size):
                for j in range(target_size):
                    diffs.add(cand[i] - cand[j])
                    sums.add(cand[i] + cand[j])
            s = score_from_counts(target_size, len(diffs), len(sums))
            
            keep = False
            if len(best_seeds) < 100:
                keep = True
            elif s > best_seeds[-1][1]:
                keep = True
            
            if keep:
                best_seeds.append((tuple(cand), s, len(diffs), len(sums)))
                best_seeds.sort(key=lambda x: x[1], reverse=True)
                best_seeds = best_seeds[:200]
    
    # Now do local search on the best ones
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for idx in range(min(30, len(best_seeds))):
            if time.time() > deadline:
                break
            cand = list(best_seeds[idx][0])
            n = len(cand)
            
            for pos in range(n):
                for delta in [-2, -1, 1, 2]:
                    old_val = cand[pos]
                    new_val = old_val + delta
                    if new_val in cand:
                        continue
                    cand[pos] = new_val
                    
                    # Quick score check
                    diffs = set()
                    sums = set()
                    for i in range(n):
                        for j in range(n):
                            diffs.add(cand[i] - cand[j])
                            sums.add(cand[i] + cand[j])
                    s = score_from_counts(n, len(diffs), len(sums))
                    
                    if s > best_seeds[idx][1]:
                        best_seeds[idx] = (tuple(cand), s, len(diffs), len(sums))
                        improved = True
                    
                    cand[pos] = old_val
    
    return best_seeds

def is_good_modulus(seed, p):
    """Check if modulo p, the seed's differences remain large and sums small."""
    n = len(seed)
    seed_mod = [x % p for x in seed]
    if len(set(seed_mod)) != n:
        return False, 0, 0
    
    diffs_mod = set()
    sums_mod = set()
    for i in range(n):
        for j in range(n):
            diffs_mod.add((seed[i] - seed[j]) % p)
            sums_mod.add((seed[i] + seed[j]) % p)
    
    return True, len(diffs_mod), len(sums_mod)

def generate_primes(n_primes=6, start=10**9):
    """Generate large primes for Chinese remainder construction."""
    # Use deterministic primes
    primes_list = [
        1000000007, 1000000009, 1000000021, 1000000033, 1000000087,
        1000000093, 1000000097, 1000000103, 1000000123, 1000000181,
        1000000207, 1000000223, 1000000241, 1000000271, 1000000289,
        1000000297, 1000000321, 1000000349, 1000000363, 1000000403
    ]
    return primes_list[:n_primes]

def chinese_remainder(residues, moduli):
    """Solve x = residues[i] mod moduli[i] for all i."""
    x = 0
    M = 1
    for r, m in zip(residues, moduli):
        M *= m
    for r, m in zip(residues, moduli):
        Mi = M // m
        # Find inverse of Mi mod m
        inv = pow(Mi, -1, m)
        x = (x + r * Mi * inv) % M
    return x

def construct_from_seeds(seed_list, mix_count=3, size_limit=4000):
    """Use CRT to combine different seeds."""
    # Pick best few seeds
    seeds = seed_list[:mix_count]
    moduli = generate_primes(len(seeds))
    
    # Each element will be a tuple (c1, c2, ..., ck) indicating which element from each seed
    # Total size = product of seed sizes
    seed_sizes = [len(s[0]) for s in seeds]
    total_size = 1
    for sz in seed_sizes:
        total_size *= sz
        if total_size > size_limit * 4:  # too large
            # Reduce number of seeds
            while total_size > size_limit * 4 and len(seed_sizes) > 1:
                seeds.pop()
                moduli.pop()
                seed_sizes.pop()
                total_size = 1
                for sz in seed_sizes:
                    total_size *= sz
    
    # If still too large, limit to first two seeds only
    if total_size > size_limit:
        seeds = seeds[:2]
        moduli = moduli[:2]
        seed_sizes = [len(s[0]) for s in seeds]
        total_size = 1
        for sz in seed_sizes:
            total_size *= sz
    
    if total_size > size_limit:
        # Just use largest seed
        seeds = seeds[:1]
        moduli = moduli[:1]
        seed_sizes = [len(s[0]) for s in seeds]
        total_size = seed_sizes[0]
    
    # Generate all combinations of residues
    seed_values = [[x for x in s[0]] for s in seeds]
    
    result = []
    for combo in product(*seed_values):
        residues = [combo[i] % moduli[i] for i in range(len(seeds))]
        val = chinese_remainder(residues, moduli)
        result.append(val)
    
    return result

def solve():
    deadline = time.time() + 115
    
    # Phase 1: Find excellent small seed sets
    small_seeds = search_small_sets(max_size=12, search_range=20, time_budget=25)
    
    if not small_seeds:
        # Fallback
        return [-3, -2, 0, 1, 4, 6, 7, 11]
    
    # Phase 2: Try CRT constructions with different numbers of seeds
    best_A = list(small_seeds[0][0])
    best_score = small_seeds[0][1]
    
    for mix_count in range(1, min(5, len(small_seeds)+1)):
        if time.time() > deadline - 10:
            break
        
        try:
            A = construct_from_seeds(small_seeds, mix_count, 4000)
            if len(A) <= 4000 and len(set(A)) == len(A) and len(A) >= 2:
                s = compute_score(A)
                if s > best_score:
                    best_score = s
                    best_A = A
        except:
            continue
    
    # Phase 3: Try some variations with different moduli
    if time.time() < deadline - 5:
        # Use the best seed with k copies (generalized set addition)
        best_seed = list(small_seeds[0][0])
        n_seed = len(best_seed)
        
        # Try product-like construction with different shifts
        # A = B * X + Y where X, Y are from the seed
        max_val = max(abs(x) for x in best_seed)
        
        for multiplier in [50, 100, 200, 500]:
            if time.time() > deadline - 5:
                break
            A = []
            base = 2 * max_val + 10
            actual_mult = base * multiplier
            for x in best_seed:
                for y in best_seed:
                    val = actual_mult * x + y
                    A.append(val)
            if len(A) <= 4000 and len(set(A)) == len(A):
                s = compute_score(A)
                if s > best_score:
                    best_score = s
                    best_A = A
        
        # Try 3-way product
        if n_seed ** 3 <= 4000:
            actual_mult1 = base * 200
            actual_mult2 = base
            A = []
            for x in best_seed:
                for y in best_seed:
                    for z in best_seed:
                        val = actual_mult1 * x + actual_mult2 * y + z
                        A.append(val)
            if len(A) <= 4000 and len(set(A)) == len(A):
                s = compute_score(A)
                if s > best_score:
                    best_score = s
                    best_A = A
    
    # Ensure within bounds
    A = sorted(set(best_A))[:4000]
    max_allowed = 10**15
    if max(abs(x) for x in A) > max_allowed:
        # Scale down if needed (shouldn't happen often)
        scale = max_allowed / max(abs(x) for x in A)
        A = [int(x * scale) for x in A]
        A = sorted(set(A))[:4000]
    
    return A

if __name__ == '__main__':
    # For testing
    result = solve()
    print(f"Set size: {len(result)}")
    print(f"Score: {compute_score(result)}")
    print(f"Max abs value: {max(abs(x) for x in result)}")
