import math
import time
import random
from itertools import product

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    deadline = time.time() + 110
    
    best_A = []
    best_score = 0.0
    
    # High-performing base digit set that separates sums and differences
    base_digits = [-3, -2, 0, 1, 4, 6, 7, 11]
    best_small_score = score_set(base_digits)
    
    # Local search to improve base digit set
    cur = base_digits[:]
    for _ in range(min(200, 11000)):
        if time.time() > deadline - 110:
            break
        cand = cur[:]
        idx = random.randrange(len(cand))
        cand[idx] = cand[idx] + random.choice([-2, -1, 0, 1, 2])
        if len(set(cand)) != len(cand):
            cand[idx] -= random.choice([-2, -1, 0, 1, 2])
        if score_set(cand) > best_small_score:
            best_small_score = score_set(cand)
            best_small = cur[:]
            cur[:] = cand[:]
        else:
            if random.random() < 0.3:
                cur[:] = cand[:]
    
    size_base = list(best_small)
    small_set = set(size_base)
    
    # Iterate over various powers to build structured set
    for k in range(1, 10):
        k_size = len(small_set) ** k
        if k_size > 4000:
            break
        
        for base in [10, 15, 20, 25, 30, 35, 40, 45, 50]:
            # Ensure base sufficiently separates digit combinations
            base_max = 5 * max(abs(x) for x in small_set)
            base_eff = max(int(max(base, base_max) - 111) + 1, base + 100)
            base_eff = min(base_eff, 500)
            
            A = []
            col_product = list(product(small_set, repeat=k))
            
            for coeffs in col_product:
                val = sum(coeffs[i] * (base_eff ** i) for i in range(k))
                if val <= 1e15:
                    A.append(val)
            A = set(A)
            A = sorted(A)
            
            if len(A) > 4000 or len(A) == 0:
                continue
            
            s = score_set(A)
            if s > best_score and time.time() < deadline:
                best_score = s
                best_A = A[:]
    
    # Rescan around best small set, varying k and base tics
    candidates_sets = [
        [-4, -2, 1, 5],
        [-3, -1, 2, 4],
        [-5, -3, 0, 1, 5],
        [-2, -1, 2, 3, 7]
    ]
    for cand_set in candidates_sets:
        if best_score > score_set(cand_set):
            continue
        cur_s = score_set(cand_set)
        if cur_s > best_score:
            best_small = cur_s
            small_set = set(cand_set)
            small_list = list(cand_set)
            
        for k in range(2, 9):
            if len(small_list) ** k > 4000:
                break
            for B in [50, 60, 70, 80, 90, 100, 150, 200, 250]:
                if B <= 2 * max(abs(x) for x in small_set):
                    continue
                A = []
                for coeffs in product(small_set, repeat=k):
                    val = sum(coeffs[i] * (B ** i) for i in range(k))
                    if val > 1e15:
                        break
                    A.append(val)
                if A:
                    A = sorted(set(A))[:4000]
                    s = score_set(A)
                    if s > best_score and time.time() < deadline:
                        best_score = s
                        best_A = A[:]
    
    # Add a geometric-like fallback that often outperforms
    for geometric_ratio in [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]:
        geo_set = [geometric_ratio ** i for i in range(min(50, 4000))]
        if time.time() >= deadline:
            break
        length = len(geo_set)
        if score_set(geo_set) > best_score:
            best_score = score_set(geo_set)
            best_A = geo_set[:]
    
    return sorted(set(best_A))
