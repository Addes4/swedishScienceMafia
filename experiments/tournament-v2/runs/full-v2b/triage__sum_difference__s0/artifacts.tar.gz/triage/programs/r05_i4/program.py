import math
import time
from itertools import combinations

def score_set(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    deadline = time.time() + 110

    best_A = None
    best_score = -1

    # Try Hamming-weight-restricted subsets of hypercube using lexicographic mapping.
    # For each weight interval [w1, w2], list all binary strings of length d with weight in that range.
    # Map to integers via binary value. The difference set can be huge, sum set can be confined.

    # We want |A| <= 4000 and values <= 1e15.

    candidates = []

    # Strategy: d up to ~26 so that 2^d fits in 1e15.
    # But we don't want all strings — we want weight restriction.

    def binom(n, k):
        if k < 0 or k > n:
            return 0
        return math.comb(n, k)

    # For each (d, w1, w2), compute count.
    d_max = 30  # 2^30 ~ 1e9, fine
    # Let's search configurations
    configs = []
    for d in range(10, 27):
        for w in range(0, d + 1):
            cnt = binom(d, w)
            if 50 <= cnt <= 4000:
                configs.append((d, w, w, cnt))
    for d in range(10, 27):
        for w1 in range(0, d + 1):
            for w2 in range(w1 + 1, min(w1 + 4, d + 1)):
                cnt = sum(binom(d, w) for w in range(w1, w2 + 1))
                if 100 <= cnt <= 4000:
                    configs.append((d, w1, w2, cnt))

    # Generate candidate sets
    for (d, w1, w2, cnt) in configs:
        if time.time() > deadline - 20:
            break
        A = []
        for x in range(1 << d):
            if w1 <= bin(x).count('1') <= w2:
                A.append(x)
        if len(A) < 2 or len(A) > 4000:
            continue
        try:
            s = score_set(A)
        except Exception:
            continue
        if s > best_score:
            best_score = s
            best_A = A[:]

    # Also try Gray code mapping: element i -> gray(i), then select those with weight in range.
    # Gray code difference structure can differ from plain binary.
    if time.time() < deadline - 20:
        for (d, w1, w2, cnt) in configs[:200]:
            if time.time() > deadline - 15:
                break
            A = []
            for x in range(1 << d):
                g = x ^ (x >> 1)
                if w1 <= g.bit_count() <= w2:
                    A.append(g)
            A = list(set(A))
            if len(A) < 2 or len(A) > 4000:
                continue
            try:
                s = score_set(A)
            except Exception:
                continue
            if s > best_score:
                best_score = s
                best_A = A[:]

    # Additional idea: use restriction on weight AND on another coordinate structure.
    # Try sets of the form: all binary strings where weight in [w-w0, w+w0] and top bits fixed?
    # Extend dimensions with additional filter to boost difference set while capping sum set.

    if time.time() < deadline - 15:
        # Try: take hypercube subset with weight range but scale/shift to make sums sparse.
        # Combined with weight-window of small width to keep sum set narrow.
        for d in range(14, 26):
            if time.time() > deadline - 10:
                break
            for w1 in range(0, d + 1):
                w2 = w1
                cnt = binom(d, w1)
                if cnt < 200 or cnt > 4000:
                    continue
                A = [x for x in range(1 << d) if bin(x).count('1') == w1]
                if len(A) > 4000:
                    continue
                try:
                    s = score_set(A)
                except Exception:
                    continue
                if s > best_score:
                    best_score = s
                    best_A = A[:]

    if best_A is None:
        # fallback
        best_A = list(range(4000))
    # Deduplicate and constrain size
    best_A = sorted(set(best_A))[:4000]
    return best_A
