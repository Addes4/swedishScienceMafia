# EVOLVE-BLOCK-START
"""
Model the problem as a structured greedy search with binary implicit selection.
We will:
1. Generate candidate ground sets (e.g., structured sequences of integers)
2. Use binary embeddings of selections to approximate ILP behavior
3. Enforce cardinality constraints to limit sum collisions
4. Use GAP-like thin-difference structures to ensure large difference sets
"""
import math
import random
import time
from typing import List, Set, Tuple

def score_set(a: List[int]) -> float:
    s = set(a)
    if len(s) < 2:
        return 0.0
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(s)) / 100

def solve():
    best_a = None
    best_score = 0.0
    
    # Use a symmetry-breaking base structure to encourage many differences, few sums
    # Modified short Sidon-like set but inverted
    # Try several ground constructions:
    
    length = min(35, 120 * (2009 - 1990 + 1) / 128)  # controlled size
    target_size = 120
    
    deadline = time.time() + 120
    best_sc = score_set([0, 10, 20, 100, 200])
    
    # 1) Try arithmetic-like sequences (controlled sum)
    for r in range(1, 50):
        for a in range(1, min(1500, 2**10)):
            if abs(a) < 100:
                continue
            cand = [r*i + a for i in range(1, 51)]
            s = set(cand)
            if len(s) > 35:
                continue
            sc = score_set(list(s))
            if sc > best_score:
                best_score = sc
                best_a = list(s)
    
    # 2) Try geometric progression style (good for differences)
    for base in [2, 3, 5, 7, 11, 13, 17, 19]:
        for exp in range(1, 15):
            cand = [base**i for i in range(1, exp+1)]
            s = set(cand)
            if len(s) > 30:
                continue
            sc = score_set(list(s))
            if sc > best_score:
                best_score = sc
                best_a = list(s)
    
    # 3) Try near-geometric (sum collisions)
    k = 5
    for shift in range(0, 100, 5):
        for base in [3, 4, 5, 6]:
            try:
                cand = [int(shift + base**i) for i in range(1, 12)]
            except:
                continue
            s = set(cand)
            if len(s) > 35:
                continue
            sc = score_set(list(s))
            if sc > best_score:
                best_score = sc
                best_a = list(s)
    
    # 4) Random search with structure: biased towards small sum sets (dense structure)
    for _ in range(3000):
        start = random.randint(-10000, 10000)
        step = random.randint(3, 8)
        cand = [start + i * step for i in range(1, 20)]
        # Perturb to introduce non-linear differences
        perturb = 0
        for i in range(len(cand)):
            if random.random() < 0.1:
                cand[i] += random.choice([-2, -1, 0, 1, 2])
                perturb += 1
        s = set(cand)
        if len(s) < 10:
            continue
        sc = score_set(list(s))
        if sc > best_score:
            best_score = sc
            best_a = list(s)
    
    # 5) ILP-style greedy: constraint satisfaction on sum collisions
    # Use implicit binary selection (1/0) for positions in a range
    for L in [500, 1000, 2000]:
        rng = random.Random(time.time())
        # Binary-like ILP relaxation approximation
        chosen: Set[int] = set()
        max_it = 1500
        
        for _ in range(max_it):
            if len(chosen) >= 400:
                break
            x_rand = rng.randint(-L, L)
            if x_rand in chosen:
                continue
            # Quick heuristic check before commit
            tentative = chosen | {x_rand}
            D = {a - b for a in tentative for b in tentative}
            S = {a + b for a in tentative for b in tentative}
            mc = math.log(len(D)) / math.log(len(S)) + (1 - 1 / len(tentative)) / 100
            if mc < best_score:
                continue
            chosen.add(x_rand)
        if len(chosen) > 10:
            sc = score_set(list(chosen))
            if sc > best_score:
                best_score = sc
                best_a = list(chosen)
    
    # 6) Use sorted + remove collisions strategy
    # Structured with negative/positive pairs to cancel sums
    for offset in [0, 100, 200, 500, 1000]:
        for base in range(1, 9):
            cand = [offset + base*i for i in range(1, 30)]
            s = set(cand)
            if len(s) < 60:
                continue
            sc = score_set(list(s))
            if sc > best_score:
                best_score = sc
                best_a = list(s)
    
    # 7) Large-set bias in range [-N, N] + small perturbations
    if best_a is None:
        best_a = [0, 10, 20, 100, 200]
    
        # Bias toward difference expansion
        diff_expansion = set(best_a)
        main_offset = 0
        
        for _ in range(1000):
            if len(diff_expansion) > 350:
                break
            bal = sum(best_a) // len(best_a)
            next_v = bal + random.randint(-5000, 5000)
            if next_v in best_a:
                continue
            big = set(diff_expansion) | {next_v}
            sc = score_set(list(big))
            if sc < best_score:
                continue
            diff_expansion = big
            best_score = 0
            best_a = list(diff_expansion) if sc > score_set(list(best_a)) else best_a
    
    # Final candidate selection
    best_a = [x for x in best_a if -1e15 <= x <= 1e15]
    best_a = sorted(list(set(best_a)))[:4000]
    
    return best_a
# EVOLVE-BLOCK-END
