import math
import time
from itertools import product

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    deadline = time.time() + 110  # leave some margin
    
    # Start with a very good small set from known constructions
    # This set has excellent difference/sum ratio
    base_set = [-3, -2, 0, 1, 4, 6, 7, 11]
    
    # Try to find a better small set first (quick search)
    best_small = base_set[:]
    best_small_score = score_set(best_small)
    
    # Quick local search on small set
    cur = best_small[:]
    while time.time() < deadline and time.time() < deadline - 100:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-2, 2)
        if len(set(cand)) == len(cand):
            s = score_set(cand)
            if s > best_small_score:
                best_small = cand[:]
                best_small_score = s
                cur = cand[:]
            elif random.random() < 0.2:
                cur = cand[:]
    
    # Now use the base-B expansion technique
    # We want A = {sum x_i * B^i : x_i in small_set} for i=0..k-1
    # The base B should be much larger than max(|x|) of small_set
    # This makes the sums stay relatively separated (few collisions)
    # while differences multiply nicely.
    
    small = best_small
    max_abs = max(abs(x) for x in small)
    m = len(small)
    
    # We want A size <= 4000
    # Size of product set is m^k, so choose k such that m^k <= 4000
    # But we can also try different k and B to maximize score
    # Actually, difference set size grows like (|D|)^k for some D related to small set's diff set
    # sum set size grows moderately because of base separation
    
    best_A = small[:]
    best_score = best_small_score
    
    # Test various k and base sizes
    for k in range(2, 8):
        if m**k > 4000:
            break
        
        # For good separation, base B should be > 2 * max_abs * k + 1
        # But larger base makes sum set a bit larger (more possible sums)
        # There's a trade-off: too small base causes sum collisions (bad for ratio)
        # too large base makes sum set grow unnecessarily
        
        # We'll try a few base sizes
        for base_factor in [2.5, 3.0, 4.0, 5.0]:
            B = int(2 * max_abs * k * base_factor) + 1
            if B > 1e15:
                continue
            
            # Generate A via cartesian product
            # Each tuple of length k from small set
            A = []
            for coeffs in product(small, repeat=k):
                val = sum(c * (B ** i) for i, c in enumerate(coeffs))
                A.append(val)
            
            if len(A) > 4000:
                continue
            
            # Check distinctness (should be distinct due to base representation)
            if len(set(A)) != len(A):
                continue
            
            s = score_set(A)
            if s > best_score:
                best_score = s
                best_A = A
    
    # Also try moderate-sized sets not as product but directly useful
    # If best score is still low, fall back to some known constructions
    if best_score < 1.2:
        # Try a larger ad-hoc construction
        pass
    
    return sorted(set(best_A))[:4000]

# For the import
import random
