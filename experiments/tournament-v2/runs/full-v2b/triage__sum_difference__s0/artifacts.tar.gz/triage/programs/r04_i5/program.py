import math
import time
import random

def score_set(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    deadline = time.time() + 110
    random.seed(12345)
    
    best_A = [0, 1]
    best_score = score_set(best_A)
    
    # ---- Part 1: find good small base set via hill climbing ----
    # A small set with few sums and many differences.
    def local_search_small(seed, n_tries=20000):
        nonlocal best_A, best_score
        cur = seed[:]
        cur_score = score_set(cur)
        for _ in range(n_tries):
            if time.time() > deadline:
                break
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2])
            if len(set(cand)) != len(cand):
                continue
            s = score_set(cand)
            if s > cur_score:
                cur = cand
                cur_score = s
                if s > best_score:
                    best_score = s
                    best_A = cand[:]
            elif random.random() < 0.05:
                cur = cand
                cur_score = s
        return cur, cur_score

    small_seeds = [
        [0, 1, 3, 7],
        [0, 1, 4, 6],
        [-3, -2, 0, 1, 4, 6],
        [0, 1, 3, 7, 12, 20],
        [0, 1, 4, 10, 12, 17],
    ]
    smalls = []
    for sd in small_seeds:
        if time.time() > deadline:
            break
        c, s = local_search_small(sd, 3000)
        smalls.append((c, s))
    
    # keep top small sets
    smalls.sort(key=lambda t: -t[1])
    smalls = smalls[:4]
    
    # ---- Part 2: base-B product expansion ----
    for small, ssmall in smalls:
        if time.time() > deadline:
            break
        small = sorted(set(small))
        max_abs = max(abs(x) for x in small)
        m = len(small)
        if m < 2:
            continue
        for k in range(1, 9):
            if m ** k > 4000:
                break
            for bf in [1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 6.0, 10.0]:
                B = int(2 * max_abs * k * bf) + 1
                if B < 2:
                    B = 2
                if B > 10**15:
                    continue
                # build via iterative product
                A = [0]
                p = 1
                ok = True
                for i in range(k):
                    newA = []
                    for a in A:
                        for c in small:
                            v = a + c * p
                            newA.append(v)
                    A = newA
                    p *= B
                if len(A) > 4000:
                    continue
                if len(set(A)) != len(A):
                    continue
                sc = score_set(A)
                if sc > best_score:
                    best_score = sc
                    best_A = A[:]
    
    # ---- Part 3: greedy independent-set style augmentation on top of best ----
    # Try to add candidates that increase diffs more than sums.
    if time.time() < deadline:
        cur = set(best_A)
        cur_diffs = {x - y for x in cur for y in cur}
        cur_sums = {x + y for x in cur for y in cur}
        cur_score = best_score
        
        # candidates: perturbations/additions
        max_abs_cur = max(abs(x) for x in cur) if cur else 1
        for _ in range(200000):
            if time.time() > deadline:
                break
            if len(cur) >= 3999:
                break
            # candidate new element
            base = random.choice(list(cur))
            c = base + random.randint(-3 * max(1, max_abs_cur // 10 + 1), 3 * max(1, max_abs_cur // 10 + 1))
            if c in cur:
                continue
            # compute deltas
            nd = set(cur_diffs)
            ns = set(cur_sums)
            for x in cur:
                nd.add(c - x); nd.add(x - c)
                ns.add(c + x); ns.add(x + c)
            nd.add(0); ns.add(2 * c)
            new_len = len(cur) + 1
            sc = math.log(len(nd)) / math.log(len(ns)) + (1 - 1 / new_len) / 100
            if sc > cur_score:
                cur.add(c)
                cur_diffs = nd
                cur_sums = ns
                cur_score = sc
                if sc > best_score:
                    best_score = sc
                    best_A = list(cur)
                max_abs_cur = max(abs(x) for x in cur)
    
    # ---- Part 4: swap-based local search on the full set (keep size) ----
    if time.time() < deadline:
        cur = list(best_A)
        cur_score = score_set(cur)
        for _ in range(5000):
            if time.time() > deadline:
                break
            cand = cur[:]
            i = random.randrange(len(cand))
            delta = random.choice([-3, -2, -1, 1, 2, 3])
            cand[i] += delta
            if len(set(cand)) != len(cand):
                continue
            s = score_set(cand)
            if s > cur_score:
                cur = cand
                cur_score = s
                if s > best_score:
                    best_score = s
                    best_A = cand[:]
            elif random.random() < 0.02:
                cur = cand
                cur_score = s
    
    # ensure constraints
    res = sorted(set(int(x) for x in best_A))
    res = [x for x in res if abs(x) <= 10**15]
    return res[:4000]
