import math
import time
from itertools import product

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def blocks_with_k_ones(n_bits, k_ones):
    """Generate all n-bit integers with exactly k_ones set bits."""
    result = []
    for mask in range(1 << n_bits):
        if bin(mask).count('1') == k_ones:
            result.append(mask)
    return result

def make_binary_restricted_set(num_blocks, ones_per_block, bit_width=50):
    """
    Construct a set using blocks of bits with fixed Hamming weight (ones count).
    Each block uses bit_width bits; apart one block from the next with zeros.
    This limits carry propagation in sums while differences explode from borrows.
    """
    blocks = []
    for _ in range(num_blocks):
        bits_matrix = blocks_with_k_ones(bit_width, ones_per_block)
        bits_matrix = list(bits_matrix)[:16]  # cap block size
        blocks.append(bits_matrix)
    
    result = []
    for combo in product(*blocks):
        val = 0
        for i, block in enumerate(combo):
            val |= (block << (i * (bit_width + 7)))
        result.append(val)
    
    return result

def solve():
    deadline = time.time() + 115
    best_set = None
    best_score = -float('inf')
    
    # Config: small blocks with high ones ratio gives good separation
    configs = [
        (3, 2, 5),
        (3, 1, 5),
        (2, 1, 6),
        (2, 2, 5),
        (4, 3, 6),
        (4, 2, 7),
        (5, 3, 7),
        (5, 2, 6),
        (3, 2, 6),
        (2, 2, 8),
    ]
    
    for num_blocks, ones, width in configs:
        if time.time() > deadline - 4:
            break
        
        s = make_binary_restricted_set(num_blocks, ones, width)
        if len(s) == 0 or len(s) > 4000:
            continue
        
        top = best_score
        s_val = score_set(s)
        if s_val > best_score:
            best_score = s_val
            best_set = s[:]
    
    if len(best_set) >= 4000:
        best_set = sorted(best_set)[:4000]
    
    # Expanded set search
    for nb in [4, 5]:
        for ones in [1, 2, 3]:
            for w in [6, 7]:
                if time.time() > deadline:
                    break
                if score_set(best_set) > 1.24:
                    break
                if time.time() > deadline - 4:
                    break
                s = make_binary_restricted_set(nb, ones, w)
                if len(s) >= 4000:
                    s = sorted(s)[:4000]
                else:
                    s = list(s)
                if len(s) < 2:
                    continue
                if score_set(s) > best_score:
                    best_score = score_set(s)
                    best_set = s[:]
    
    return sorted(best_set)[:4000] if best_set else list(range(100))
