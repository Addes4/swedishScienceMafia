import math
import random
from itertools import product
from time import time

def score_set(A):
    A = set(A)
    n = len(A)
    if n < 2:
        return 0.0
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/n) / 100

def solve():
    deadline = time() + 118  # 118s + 2s margin
    best_score = 0.0
    best_A = None
    best_params = None

    # Base sets to try with strong separation properties
    base_sets = [
        [-2, -1, 0, 1],
        [0, 1, 3],
        [0, 2, -2],
        [0, 1, 2, 4],
        [-1, 0, 1, -2, 2],
        [-3, -1, 0, 1, 3],
        [-1, -1, 0, 1, 1],  [0, 1, 2, 5],
        [-2, -1, 0, 1, 2, 3],
        [0, 2, 4, 6],
        [-1, 1],  [0, 1],
        [-3, 0, 3],
        [-2, 0, 2],
        [-2, -1, 1, 2],
        [-2, 0, 3],
    ]
    
    for k in range(2, 7):
        if deadline - time() < 3:
            break
        for base_mult in [2.5, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 15.0, 20.0]:
            if deadline - time() < 0.5:
                break
            for small_set in base_sets:
                m = len(small_set)
                if m ** k > 4000:
                    continue
                max_abs = max(abs(x) for x in small_set)
                B = int(base_mult * max_abs * k * 5) + 1
                if B > 1e15:
                    continue
                deadline_after = time() + max(0, min(55, deadline - time()))
                A = []
                for coeffs in product(small_set, repeat=k):
                    val = sum(c * (B ** i) for i, c in enumerate(coeffs))
                    A.append(val)
                if deadline_after > time():
                    s = score_set(A)
                    if s > best_score:
                        best_score = s
                        best_A = sorted(A)
                        best_params = (small_set, k, B)
                        if s > 1.3:
                            break
                time.sleep(0.05)
    
    if best_A is None:
        best_A = [-3, -2, 0, 1, 4, 6, 7, 11]
    return best_A[:4000]

if __name__ == "__main__":
    solve()
