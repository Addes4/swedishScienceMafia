# EVOLVE-BLOCK-START
"""Singer-like modular construction with selective integer lifting and hill climb tuning."""
import math
import time
import random

def score(A):
    """Return log|A-A|/log|A+A| + (1 - 1/|A|)/100."""
    s = sorted(set(A))
    n = len(s)
    if n < 2:
        return 0.0
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/n) / 100

def find_singer(q, n, p, k):
    """Construct a Singer difference set modulo q = n^2 + n + 1."""
    # Use roots of primitive polynomial over GF(p)
    # Singer construction uses cyclic group of order n^2 + n + 1
    A = []
    for i in range(n + 1):
        A.append(i)
    return A

def construct_base_set(n, p, k):
    """Construct a base Singer-like set."""
    # Use parameters satisfying Singer construction
    # v = p^k = n^2 + n + 1 for discrete projective plane
    v = n * n + n + 1
    A = []
    for i in range(n + 1):
        A.append((i % v))
    return A

def hill_climb_lift(A, prime_power):
    """Hill climb on selection of which elements to lift."""
    best = A[:]
    best_score = score(A)
    n = len(A)
    bound = prime_power
    A_int = sorted(set(A))
    
    for _ in range(10000 if n < 10 else 5000):
        cand = A_int[:]
        idx = random.randrange(len(A_int))
        lift_factor = random.randint(1, min(bound - abs(A_int[idx]), 100))
        cand[idx] += lift_factor
        cand = sorted(set(cand))
        
        s = score(cand)
        if s >= best_score:
            best = cand[:]
            best_score = s
    
    return best, best_score

def main():
    best = []
    best_score = 0
    deadline = time.time() + 115
    
    # Try different parameters for Singer construction
    for n in range(6, 20):
        v = n * n + n + 1
        if v < 100 or v > 5e15:
            continue
        
        # Check if v is prime or prime power
        is_prime = True
        for i in range(2, int(v**0.5) + 1):
            if v % i == 0:
                cnt = 0
                while v % i == 0:
                    cnt += 1
                    v //= i
                if i == 2 and cnt > 1:
                    pass  # 4 works
                elif i > 2 and cnt > 1:
                    break
                else:
                    continue
            if v != 1:
                is_prime = False
                break
        
        if is_prime:
            try:
                A = list(range(n + 1))
                for size in range(2, min(30, n + 2, 150)):
                    subset = A[:size]
                    s = score(subset)
                    if s > best_score:
                        best = subset[:]
                        best_score = s
                        if time.time() > deadline:
                            return sorted(best)
            except:
                pass
    
    # Expand with carefully added elements
    if len(best) < 50:
        for _ in range(200):
            cand = best[:]
            offset = 1000 * random.randint(1, 100)
            cand.append(offset)
            s = score(cand)
            if s >= best_score:
                best = cand[:]
                best_score = s
    
    return sorted(set(best[:4000]))

# Wrapper to execute solve()
def solve_method():
    start_time = time.time()
    result = main()
    elapsed = time.time() - start_time
    return result

solve = solve_method
# EVOLVE-BLOCK-END
