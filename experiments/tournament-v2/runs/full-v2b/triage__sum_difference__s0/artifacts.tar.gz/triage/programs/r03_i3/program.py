import math
import time
import random
from itertools import product

def score_set(A):
    A_set = set(A)
    n = len(A_set)
    if n < 2:
        return 0.0
    sums = {x + y for x in A_set for y in A_set}
    diffs = {x - y for x in A_set for y in A_set}
    score = math.log(len(diffs)/2) / math.log(len(sums)/2) + (1 - 1/n) / 100
    return score

def solve():
    start_time = time.time()
    deadline = start_time + 110
    
    # Known good small base set with proven structure
    base_sets = [
        [-3, -2, 0, 1, 4, 6, 7, 11],           # Original base
        [0, 1, 4, 9],                           # Squares base
        [0, 3, 5, 9],                           # Another small set
        [0, 2, 3, 5, 8],                        # 5-element set
        [-5, -3, -1, 1, 3, 5],                  # Symmetric odd
        [-2, 0, 2, 4, 6, 8]                      # Even spaced
    ]
    
    # Converted base to base expansions with optimized B
    best_A = None
    best_score = 0
    
    # Ensure all small sets are distinct
    for small in base_sets:
        u_set = set(small)
        if len(u_set) != len(small):
            continue
            
        max_abs = max(abs(x) for x in u_set)
        m = len(u_set)
        
        # Try different dimensions for product construction
        for k in range(2, 7):
            if m ** k > 4000:
                break
            
            # Different base scales to find optimal separation
            for scale in [5, 10, 15, 20, 25, 30]:
                B = int((2 * max_abs * k + 1) * scale)
                if B > 1e15 or B < 5 * m:
                    break
                    
                # Generate candidate product set
                try:
                    A_candidates = []
                    for coeffs in product(u_set, repeat=k):
                        val = sum(c * (B ** i) for i, c in enumerate(coeffs))
                        A_candidates.append(val)
                    
                    if len(A_candidates) > 4000:
                        continue
                    if len(A_candidates) < 10:
                        continue
                        
                    # Score without iteration first
                    test_score = score_set(A_candidates)
                    if test_score > best_score:
                        best_score = test_score
                        best_A = A_candidates[:]
                        
                    # Local hill climbing to improve score
                    if time.time() - start_time > 85:
                        break
                        
                    local_best = A_candidates[:]
                    local_best_score = test_score
                    
                    for _ in range(20):
                        improved = False
                        for i in range(20):
                            for j in range(20):
                                old_val = local_best[i]
                                # Modify B-positions: swap with similar values
                                if random.random() < 0.3:
                                    B_val = sum(c * (B ** j) for c, c_idx in (x * (B ** k) for k, x in enumerate(u_set)) if x != local_best[i])
                                    new_val = (old_val - sum(local_best[i] * (B ** i) for i in range(k) if i != 0))
                                    if i < len(local_best):
                                        new_val = (local_best[i] - sum(old_val * (B ** i) for i in range(k) if i != 0))
                                if i < len(local_best):
                                    new_val = old_val
                                    try:
                                        for t in [-B, B, -1, 1]:
                                            modified = old_val + t
                                            if modified in [v for v in range(-1e14, 1e14)]:
                                                cand = local_best[:]
                                                cand[i] = modified
                                                if len(set(cand)) == len(cand):
                                                    s = score_set(cand)
                                                    if s > local_best_score:
                                                        local_best_score = s
                                                        local_best = cand[:]
                                                        improved = True
                                                        break
                                    except:
                                        pass
                            
                    if time.time() - start_time > 95:
                        break
                        
                except:
                    pass
    
    # Try direct construction without base expansion for diversity
    if time.time() - start_time < 100:
        # Greedy construction: add elements that minimize sum collisions
        A_greedy = [0]
        candidates = set()
        for i in range(1, 5000):
            candidates.add(i)
            candidates.add(-i)
            
        while len(A_greedy) < 400 and time.time() - start_time < 100:
            best_add = None
            best_gain = -1e15
            
            for c in candidates:
                if c in A_greedy:
                    continue
                    
                # Estimate gain: modify A and compute new score
                A_test = A_greedy + [c]
                try:
                    g = score_set(A_test)
                    if g > best_gain:
                        best_gain = g
                        best_add = c
                except:
                    
            if best_add is not None and best_add > -1e14:
                A_greedy.remove(A_greedy[-1])
                A_greedy.append(best_add)
                candidates.discard(best_add)
            else:
                break
                
    # Final computation for best candidate
    if best_A:
        try:
            s_final = score_set(best_A)
            best_A = sorted(set(best_A))
        except:
            pass
    
    if best_score < 0.8:
        # Fallback to simpler set
        best_A = [-100*i for i in range(1, 400)]
        best_score = score_set(best_A)
    
    return sorted(set(best_A))[:4000]
