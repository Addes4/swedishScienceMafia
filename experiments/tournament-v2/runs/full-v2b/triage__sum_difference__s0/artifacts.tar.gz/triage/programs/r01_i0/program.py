import math
import random
import time
from math import gcd

def bose_chowla(q, k):
    """Bose-Chowla construction for B2 set: yields k integers mod (q^2-1) 
       where q is a prime power. Returns list of residues."""
    # Find primitive root modulo q
    def primitive_root(p):
        if p == 2:
            return 1
        phi = p - 1
        factors = []
        n = phi
        d = 2
        while d * d <= n:
            if n % d == 0:
                factors.append(d)
                while n % d == 0:
                    n //= d
            d += 1
        if n > 1:
            factors.append(n)
        for g in range(2, p):
            ok = True
            for f in factors:
                if pow(g, phi // f, p) == 1:
                    ok = False
                    break
            if ok:
                return g
        return -1
    
    # Find a prime >= q
    p = q
    while True:
        # simple primality test
        if p < 2:
            p = 2
        if p == 2:
            is_prime = True
        elif p % 2 == 0:
            is_prime = False
        else:
            is_prime = True
            d = 3
            while d * d <= p:
                if p % d == 0:
                    is_prime = False
                    break
                d += 2
        if is_prime:
            break
        p += 1
    
    if p - 1 < k:
        # Need larger prime
        p = k + 1
        while True:
            if p < 2:
                p = 2
            if p == 2:
                is_prime = True
            elif p % 2 == 0:
                is_prime = False
            else:
                is_prime = True
                d = 3
                while d * d <= p:
                    if p % d == 0:
                        is_prime = False
                        break
                    d += 2
            if is_prime:
                break
            p += 1
    
    g = primitive_root(p)
    modulus = p * p - 1
    residues = []
    for i in range(k):
        residues.append(p * i + pow(g, i, p))
    return residues, modulus

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    best_set = None
    best_score = 0.0
    deadline = time.time() + 118
    
    # Try various parameters for Bose-Chowla
    for q in [101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199]:
        if time.time() > deadline:
            break
        for k_factor in range(80, 101, 2):
            if time.time() > deadline:
                break
            k = int(q * k_factor / 100)
            if k < 10 or k > q - 1:
                continue
            try:
                residues, modulus = bose_chowla(q, k)
                # Scale residues to spread them out
                scale = 1000 + random.randint(-200, 200)
                shift = random.randint(-1000000, 1000000)
                
                a = [r * scale + shift for r in residues]
                a = sorted(set(a))
                
                sc = score_set(a)
                if sc > best_score:
                    best_score = sc
                    best_set = a[:]
            except:
                continue
    
    # Try arithmetic progression subsets
    for N in [200, 300, 400, 500, 600, 700, 800]:
        if time.time() > deadline:
            break
        for step in [1, 2, 3, 5, 7, 11, 13, 17, 19, 23]:
            if time.time() > deadline:
                break
            # Greedy Sidon-like set from arithmetic progression
            base = list(range(0, N))
            a = []
            sums_set = set()
            for x in base:
                ok = True
                for y in a:
                    if x + y in sums_set:
                        ok = False
                        break
                if ok:
                    a.append(x)
                    for y in a[:-1]:
                        sums_set.add(x + y)
            
            if len(a) < 10:
                continue
            
            a = [x * step for x in a]
            a = sorted(set(a))
            sc = score_set(a)
            if sc > best_score:
                best_score = sc
                best_set = a[:]
    
    # Local search on best found
    if best_set is not None and len(best_set) > 5:
        cur = best_set[:]
        cur_score = best_score
        local_deadline = time.time() + 30
        while time.time() < local_deadline and time.time() < deadline:
            cand = cur[:]
            # Mutation operations
            op = random.random()
            if op < 0.3 and len(cand) > 2:
                # Modify an element
                i = random.randrange(len(cand))
                old = cand[i]
                cand[i] += random.randint(-100, 100)
                if cand[i] == old:
                    cand[i] += 1
            elif op < 0.5:
                # Add element
                val = random.randint(-1000000, 1000000)
                if val not in cand:
                    cand.append(val)
            elif op < 0.7 and len(cand) > 2:
                # Remove element
                i = random.randrange(len(cand))
                cand.pop(i)
            else:
                # Swap element
                i = random.randrange(len(cand))
                cand[i] = random.randint(-1000000, 1000000)
            
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            
            sc = score_set(cand)
            if sc > cur_score:
                cur = cand[:]
                cur_score = sc
                if sc > best_score:
                    best_score = sc
                    best_set = cand[:]
            elif random.random() < 0.05:
                cur = best_set[:]
                cur_score = best_score
    
    # Ensure within bounds: at most 4000 elements, each with abs <= 1e15
    if best_set is not None:
        best_set = sorted(set(best_set))
        if len(best_set) > 4000:
            best_set = best_set[:4000]
        # clip to absolute value bounds
        best_set = [x for x in best_set if abs(x) <= 10**15]
        if len(best_set) < 2:
            best_set = [0, 1, 3, 7, 12, 20, 30, 44, 65]
    
    if best_set is None or len(best_set) < 2:
        best_set = [0, 1, 3, 7, 12, 20, 30, 44, 65]
    
    return sorted(set(best_set))
