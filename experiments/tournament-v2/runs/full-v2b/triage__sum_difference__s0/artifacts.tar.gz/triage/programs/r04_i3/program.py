import math
import time
from itertools import product, combinations
import random

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def generate_set(p, S, num_blocks, block_size, base_multiplier=1):
    """Generate set using digit-sum restriction.
    
    Each number has num_blocks blocks of block_size digits in base p.
    For each block, the sum of digits must be in S.
    Blocks are separated by a large multiplier to avoid cross-block interference.
    """
    # Precompute all valid blocks (sequences of block_size digits with digit sum in S)
    valid_blocks = []
    for digits in product(range(p), repeat=block_size):
        if sum(digits) in S:
            valid_blocks.append(list(digits))
    
    if not valid_blocks:
        return []
    
    # The multiplier between blocks should be larger than max possible block value
    # to keep blocks independent
    max_block_val = sum((p-1) * (p**i) for i in range(block_size))
    # Use p**(block_size + 1) as separation to ensure no carry between blocks for sums
    # But for differences we want interaction - actually we want separation for sum control
    separation = p ** (block_size + 1)
    
    # Generate all combinations of blocks
    result = []
    for block_combo in product(valid_blocks, repeat=num_blocks):
        val = 0
        for i, block in enumerate(block_combo):
            block_val = sum(d * (p**j) for j, d in enumerate(block))
            val += block_val * (separation ** i)
        result.append(val)
    
    return result

def solve():
    deadline = time.time() + 110
    
    best_overall = None
    best_overall_score = 0
    
    # Try different parameters
    # Base p: prime works well for digit-sum constraints
    # S: subset of allowed digit sums
    # block_size: digits per block
    # num_blocks: number of blocks
    
    param_configs = []
    
    # Config 1: p=5, S={2} - this gives good ratio
    param_configs.append((5, {2}, 3, 5))
    
    # Config 2: p=5, S={1,2}
    param_configs.append((5, {1, 2}, 3, 5))
    
    # Config 3: p=7, S={3}
    param_configs.append((7, {3}, 3, 4))
    
    # Config 4: p=5, S={0,1,2} with more blocks
    param_configs.append((5, {0, 1, 2}, 4, 4))
    
    # Config 5: p=7, S={2,3,4}
    param_configs.append((7, {2, 3, 4}, 3, 4))
    
    # Config 6: p=11, S={5}
    param_configs.append((11, {5}, 3, 3))
    
    # Config 7: p=3, S={1} - small but many blocks
    param_configs.append((3, {1}, 6, 3))
    
    for p, S, num_blocks, block_size in param_configs:
        if time.time() > deadline - 5:
            break
        
        try:
            A = generate_set(p, S, num_blocks, block_size)
            if len(A) > 4000 or len(A) < 10:
                # Try reducing blocks
                for nb in range(num_blocks - 1, 1, -1):
                    A = generate_set(p, S, nb, block_size)
                    if 10 <= len(A) <= 4000:
                        break
                else:
                    continue
            
            if len(A) > 4000:
                # Subsample carefully - take first 4000
                A = sorted(A)[:4000]
            
            if len(A) < 2:
                continue
            
            s = score_set(A)
            if s > best_overall_score:
                best_overall_score = s
                best_overall = A[:]
        except:
            continue
    
    # If we found something good, return it
    if best_overall and best_overall_score > 1.15:
        return sorted(set(best_overall))[:4000]
    
    # Fallback: try a known good construction with base expansion
    # Use a small set with good properties and expand via base representation
    small_set = [-3, -2, 0, 1, 4, 6, 7, 11]
    m = len(small_set)
    
    for k in range(2, 7):
        if m**k > 4000:
            break
        
        B = 10 * max(abs(x) for x in small_set) * k + 1
        if B > 1e14:
            continue
        
        A = []
        for coeffs in product(small_set, repeat=k):
            val = sum(c * (B ** i) for i, c in enumerate(coeffs))
            A.append(val)
        
        if len(A) > 4000:
            continue
            
        s = score_set(A)
        if s > best_overall_score:
            best_overall_score = s
            best_overall = A[:]
    
    # Last resort: known excellent set
    if not best_overall:
        # Use a carefully constructed set that's known to work well
        p = 5
        S = {1, 2, 3}
        for nb in [6, 5, 4, 3]:
            A = generate_set(p, S, nb, 3)
            if 10 <= len(A) <= 4000:
                best_overall = A
                break
    
    return sorted(set(best_overall))[:4000] if best_overall else list(range(100))
