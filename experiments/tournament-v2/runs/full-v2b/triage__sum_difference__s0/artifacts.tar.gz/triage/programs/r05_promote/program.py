import math
import time
from itertools import product
import random

def score_set(a):
    a = set(a)
    M = len(a)
    if M < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / M) / 100

def generate_digit_sum_set(base, digit_sums, min_digits, max_digits):
    """Generate numbers where digit sum (in given base) belongs to digit_sums."""
    result = []
    for d in range(min_digits, max_digits + 1):
        for coeffs in product(range(base), repeat=d):
            if sum(coeffs) in digit_sums:
                val = sum(c * (base ** i) for i, c in enumerate(coeffs))
                result.append(val)
    return result

def generate_two_block_set(base, block_sums1, block_sums2, digits):
    """Numbers with d=2k digits, each half having restricted digit sum."""
    result = []
    k = digits // 2
    if digits % 2 != 0:
        return result
    # Precompute all numbers with k digits and given digit sums
    nums1 = {s: [] for s in block_sums1}
    nums2 = {s: [] for s in block_sums2}
    for coeffs in product(range(base), repeat=k):
        s = sum(coeffs)
        val_low = sum(c * (base ** i) for i, c in enumerate(coeffs))
        if s in block_sums1:
            nums1[s].append(val_low)
        if s in block_sums2:
            nums2[s].append(val_low)
    # Combine low and high parts (shifted by base^k)
    shift = base ** k
    for s1 in block_sums1:
        for low in nums1[s1]:
            for s2 in block_sums2:
                for high in nums2[s2]:
                    result.append(low + high * shift)
    return result

def generate_multiplicative_set(dim, primes, offsets):
    """Generate set using Chinese remainder: A = numbers with fixed residues mod primes."""
    # primes are small primes, offsets are lists of allowed residues modulo each prime
    # This yields a product set in Z_{p1} x ... x Z_{pk}, approximate additive structure.
    result = []
    bases = []
    moduli = []
    for p, off_list in zip(primes, offsets):
        bases.append(off_list)
        moduli.append(p)
    
    # Recursively build numbers via CRT
    if not moduli:
        return []
    
    # Precompute for efficiency: work with factor groups
    # Simple approach: generate all combinations if size manageable
    total = 1
    limit = 5000
    for off_list in bases:
        total *= len(off_list)
        if total > limit:
            break
    
    if total <= limit:
        # Direct CRT
        from itertools import product as i_product
        modulo = 1
        for p in moduli:
            modulo *= p
        for combo in i_product(*bases):
            # CRT to get number in [0, modulo-1]
            val = 0
            for residue, p in zip(combo, moduli):
                # Simple CRT for pairwise coprime moduli
                val = (val * p + residue) % modulo  # this is wrong, need proper CRT
            # Better: standard CRT incremental
        # This is getting complex, do differently:
    
    # Instead, use digit expansion method with controlled sums
    return result

def solve():
    deadline = time.time() + 110
    
    best_A = None
    best_score = 0.0
    
    # Strategy 1: Classical product-like construction I + m*J where I, J large
    # Make I and J have controlled digit structures to boost differences.
    for base in [4, 5, 7, 8, 9, 11]:
        for d1 in range(3, 7):
            for d2 in range(3, 7):
                if time.time() > deadline - 20:
                    break
                # Build I as numbers with digit sum = floor(base/2) in base representation (length d1)
                digit_sum_target = base // 2
                I = []
                for coeffs in product(range(base), repeat=d1):
                    if sum(coeffs) == digit_sum_target:
                        val = sum(c * (base ** i) for i, c in enumerate(coeffs))
                        I.append(val)
                if len(I) < 5 or len(I) > 400:
                    continue
                
                # Build J similarly with different length
                J = []
                for coeffs in product(range(base), repeat=d2):
                    if sum(coeffs) == digit_sum_target:
                        val = sum(c * (base ** i) for i, c in enumerate(coeffs))
                        J.append(val)
                if len(J) < 5 or len(J) > 400:
                    continue
                
                # Spacing: m = base^max(d1,d2) ensures no overlaps in addition
                m = base ** max(d1, d2)
                A = [i + m * j for i in I for j in J]
                if len(A) > 4000:
                    A = A[:4000]
                if len(A) < 30:
                    continue
                
                A = sorted(set(A))
                score = score_set(A)
                if score > best_score:
                    best_score = score
                    best_A = A[:]
    
    # Strategy 2: Three-component construction A = I + m1*J + m2*K
    # Use three digit-length groups to increase difference dimension
    if time.time() < deadline - 30:
        for base in [3, 4, 5, 6]:
            for d1, d2, d3 in [(3,3,3), (3,3,4), (3,4,4), (4,4,4), (3,3,5), (3,4,5)]:
                if time.time() > deadline - 25:
                    break
                I, J, K = [], [], []
                for coeffs in product(range(base), repeat=d1):
                    if sum(coeffs) == 1:
                        I.append(sum(c*(base**i) for i,c in enumerate(coeffs)))
                for coeffs in product(range(base), repeat=d2):
                    if sum(coeffs) == 1:
                        J.append(sum(c*(base**i) for i,c in enumerate(coeffs)))
                for coeffs in product(range(base), repeat=d3):
                    if sum(coeffs) == 1:
                        K.append(sum(c*(base**i) for i,c in enumerate(coeffs)))
                
                if not I or not J or not K:
                    continue
                m1 = base ** max(d1, d2, d3) + 1
                m2 = m1 * (base ** max(d1, d2, d3) + 1)
                A = [i + m1*j + m2*k for i in I for j in J for k in K]
                if len(A) > 4000:
                    A = A[:4000]
                if len(A) < 30:
                    continue
                
                A = sorted(set(A))
                score = score_set(A)
                if score > best_score:
                    best_score = score
                    best_A = A[:]
    
    # Strategy 3: Direct digit-sum restricted sets with large base
    if time.time() < deadline - 15:
        for base in [7, 9, 11, 13, 16, 17, 19, 23]:
            for target_sum in range(1, base):
                for digits in range(4, 8):
                    if time.time() > deadline - 12:
                        break
                    A = []
                    for coeffs in product(range(base), repeat=digits):
                        if sum(coeffs) == target_sum:
                            A.append(sum(c*(base**i) for i,c in enumerate(coeffs)))
                    if len(A) > 4000:
                        A = A[:4000]
                    if len(A) < 30:
                        continue
                    A = sorted(set(A))
                    score = score_set(A)
                    if score > best_score:
                        best_score = score
                        best_A = A[:]
    
    # Strategy 4: Multiple digit sum targets to increase size
    if time.time() < deadline - 5:
        for base in [5, 7, 9, 11]:
            for digits in range(5, 8):
                target_sums = {base//2, base//2 + 1} if base % 2 == 0 else {base//2}
                if base == 7:
                    target_sums = {3, 4}
                if base == 9:
                    target_sums = {4, 5}
                if base == 11:
                    target_sums = {5, 6}
                A = []
                for coeffs in product(range(base), repeat=digits):
                    if sum(coeffs) in target_sums:
                        A.append(sum(c*(base**i) for i,c in enumerate(coeffs)))
                if len(A) > 4000:
                    A = A[:4000]
                if len(A) < 40:
                    continue
                A = sorted(set(A))
                score = score_set(A)
                if score > best_score:
                    best_score = score
                    best_A = A[:]
    
    # Strategy 5: Two-block structure with independent digit sum restrictions per block
    if time.time() < deadline - 10:
        for base in [5, 7, 9]:
            for k in [3, 4]:
                block_sums1 = {base//2}
                block_sums2 = {base//2}
                if base == 7:
                    block_sums1 = {3}
                    block_sums2 = {4}
                digits = 2 * k
                A = generate_two_block_set(base, block_sums1, block_sums2, digits)
                if len(A) > 4000:
                    A = A[:4000]
                if len(A) < 30:
                    continue
                A = sorted(set(A))
                score = score_set(A)
                if score > best_score:
                    best_score = score
                    best_A = A[:]
    
    # Strategy 6: Full search in smaller space with refined parameters
    if time.time() < deadline - 3 and best_A is None:
        # Fallback: simple arithmetic progression
        for n in [1000, 5000, 10000, 50000]:
            A = [i * n for i in range(100)]
            A += [i * n + 1 for i in range(100)]
            A = sorted(set(A))[:4000]
            score = score_set(A)
            if score > best_score:
                best_score = score
                best_A = A[:]
    
    return sorted(set(best_A))[:4000] if best_A else []

