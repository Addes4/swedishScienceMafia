import math
import time
from itertools import product

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def generate_crt_set(primes, subsets, max_size=4000):
    """
    Generate set A using Chinese Remainder Theorem construction.
    
    For each prime p_i, we pick a subset S_i of residues modulo p_i.
    A number is in A if for all i, its residue mod p_i is in S_i.
    The set size is product(|S_i|). We take all such numbers up to max_size,
    or use a complete residue system modulo P = prod(p_i).
    """
    P = 1
    for p in primes:
        P *= p
    
    # Generate all residue combinations
    sizes = [len(s) for s in subsets]
    total_size = 1
    for sz in sizes:
        total_size *= sz
    
    if total_size > max_size * 2:
        # If total is too large, we need to randomly sample or take prefix
        # For better structure, we'll take first max_size numbers in natural order
        # But natural order won't preserve structure well. Instead, we'll use
        # a fixed set of residues modulo P and then take the first max_size
        # representations.
        # Actually, for any fixed set of allowed residues, the numbers are
        # arithmetic progressions modulo P, so we can take the first max_size
        # smallest positive representatives.
        pass
    
    # Precompute allowed residues modulo each prime
    allowed_mods = []
    for p, subset in zip(primes, subsets):
        allowed_mods.append(sorted(subset))
    
    A = []
    # Use a systematic enumeration of all residue combinations
    for residues in product(*allowed_mods):
        # Solve CRT: find x such that x ≡ residues[i] (mod primes[i])
        # We can use Garner's algorithm or simple search for small P
        x = 0
        for i, (p, r) in enumerate(zip(primes, residues)):
            # Find the contribution using CRT
            # x ≡ r (mod p) and x ≡ 0 (mod other primes) ... wait no
            # Standard CRT reconstruction
            pass
        
        # Simpler: since P is not huge for our purposes (at most product of small primes)
        # We'll precompute CRT solutions for each residue vector.
        # But product of primes could be large. Let's do it properly.
    
    # Alternative: generate numbers in range [0, P-1] that satisfy the conditions
    # For small P we can just enumerate all 0..P-1
    if P <= 1000000:  # reasonable to enumerate
        A = []
        for x in range(P):
            ok = True
            for p, allowed in zip(primes, allowed_mods):
                if (x % p) not in allowed:
                    ok = False
                    break
            if ok:
                A.append(x)
    else:
        # Use CRT to generate all combinations directly
        # We'll compute base contributions for each prime
        # For each i, let M_i = P // p_i, and inv_i = modular inverse of M_i mod p_i
        # Then the CRT solution for residues (r_0, r_1, ...) is
        # sum(r_i * M_i * inv_i) mod P
        M = []
        inv = []
        for i, p in enumerate(primes):
            Mi = P // p
            M.append(Mi)
            # Find modular inverse of Mi mod p
            inv_i = pow(Mi, -1, p)
            inv.append(inv_i)
        
        for residues in product(*allowed_mods):
            x = sum(r * M[i] * inv[i] for i, r in enumerate(residues)) % P
            A.append(x)
    
    return sorted(A)[:max_size]

def solve():
    deadline = time.time() + 110
    best_overall = None
    best_score = 0
    
    # Try various CRT constructions with different prime subsets
    # We want primes where allowed subsets give good difference/sum ratios
    # The difference set size tends to be product of sizes of (S_i - S_i)
    # The sum set size is product of sizes of (S_i + S_i) modulo p_i
    # but with possible interactions? Actually for CRT, if we use all residues modulo P,
    # the sum set is exactly the set of numbers congruent to S_i+S_i mod p_i for all i.
    # So |A+A| = product(|S_i + S_i|) and |A-A| = product(|S_i - S_i|)
    # provided the sets are "full" modulo P (i.e., we take all CRT combinations).
    # Thus we want to choose S_i to maximize ratio of products.
    
    # Strategy: for each prime p, find subset S that maximizes log|S-S|/log|S+S|
    # Then combine best primes into a CRT product.
    
    def subset_score(p, S):
        S_set = set(S)
        diff_mod_p = set()
        sum_mod_p = set()
        for a in S_set:
            for b in S_set:
                diff_mod_p.add((a - b) % p)
                sum_mod_p.add((a + b) % p)
        if len(sum_mod_p) == 1:
            return 0
        return math.log(len(diff_mod_p)) / math.log(len(sum_mod_p))
    
    def find_best_subset(p, max_subset_size=5):
        """Brute force search for best subset of Z_p of size up to max_subset_size."""
        best_subset = None
        best_score = 0
        from itertools import combinations
        
        for k in range(2, min(p, max_subset_size) + 1):
            for subset_tuple in combinations(range(p), k):
                S = set(subset_tuple)
                sc = subset_score(p, S)
                if sc > best_score:
                    best_score = sc
                    best_subset = S
        return best_subset, best_score
    
    # We'll use small primes only to keep product manageable
    # Primes up to 97 or so
    small_primes = [p for p in range(2, 100) if all(p % d != 0 for d in range(2, int(p**0.5)+1))]
    
    # For each prime, compute best subset
    prime_best_subsets = {}
    prime_scores = {}
    for p in small_primes:
        S, sc = find_best_subset(p, max_subset_size=4)  # limit subset size to keep total manageable
        if S is not None:
            prime_best_subsets[p] = S
            prime_scores[p] = sc
    
    # Sort primes by score
    sorted_primes = sorted(prime_scores.keys(), key=lambda p: prime_scores[p], reverse=True)
    
    # Now construct CRT sets using top primes
    # We'll combine primes to get total set size up to 4000
    # We want the product of subset sizes to be as high as possible up to 4000
    
    # Greedy: add primes while total size <= 4000
    for i in range(len(sorted_primes)):
        if time.time() > deadline - 5:
            break
        
        used_primes = sorted_primes[:i+1]
        subsets = [prime_best_subsets[p] for p in used_primes]
        
        # Check total size
        total_size = 1
        for s in subsets:
            total_size *= len(s)
            if total_size > 4000:
                break
        
        if total_size > 4000:
            continue
        if total_size < 10:
            continue
        
        try:
            A = generate_crt_set(used_primes, subsets, max_size=4000)
            if len(A) < 10:
                continue
            
            sc = score_set(A)
            if sc > best_score:
                best_score = sc
                best_overall = A[:]
        except Exception as e:
            continue
    
    # Also try some manually crafted subsets known to work well
    # For p=11, subset {0,1,2,3} might be good
    manual_configs = [
        ([11, 13], [{0,1,2,3}, {0,1,2,3}]),
        ([11, 17], [{0,1,2,3}, {0,1,2,3}]),
        ([13, 17], [{0,1,2,3}, {0,1,2,3}]),
        ([11, 13, 17], [{0,2,3}, {0,2,3}, {0,2,3}]),
        ([7, 11, 13], [{0,1,2}, {0,1,2}, {0,1,2}]),
    ]
    
    for primes_list, subsets_list in manual_configs:
        if time.time() > deadline - 2:
            break
        try:
            A = generate_crt_set(primes_list, subsets_list, max_size=4000)
            if len(A) >= 10:
                sc = score_set(A)
                if sc > best_score:
                    best_score = sc
                    best_overall = A[:]
        except:
            continue
    
    # If nothing worked, use a known good small set
    if not best_overall:
        # Simple but effective: use numbers with base-5 representation having digit sum exactly 2
        # block construction from previous approach
        def generate_digit_sum_set(base, target_sum, num_digits):
            valid = []
            for digits in product(range(base), repeat=num_digits):
                if sum(digits) == target_sum:
                    val = sum(d * (base ** i) for i, d in enumerate(digits))
                    valid.append(val)
            return valid
        
        for base in [5, 7, 11]:
            for nd in [3, 4, 5, 6]:
                for ts in [1, 2, 3]:
                    A = generate_digit_sum_set(base, ts, nd)
                    if 10 <= len(A) <= 4000:
                        sc = score_set(A)
                        if sc > best_score:
                            best_score = sc
                            best_overall = A[:]
                    if len(A) > 4000:
                        break
                if best_overall and len(best_overall) >= 400:
                    break
            if best_overall and len(best_overall) >= 400:
                break
    
    return sorted(set(best_overall))[:4000] if best_overall else list(range(100))
