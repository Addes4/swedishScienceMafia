import math
import time
from itertools import product

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def valid(A):
    return (2 <= len(A) <= 4000 and len(set(A)) == len(A)
            and all(abs(x) <= 10**15 for x in A))

def solve():
    deadline = time.time() + 110
    best_A = None
    best_score = -1.0

    def consider(A):
        nonlocal best_A, best_score
        if not valid(A):
            return
        s = score_set(A)
        if s > best_score:
            best_score = s
            best_A = A[:]

    # Construction 1: quadratic A = {x^2 + p*x}
    for N in range(30, 130):
        for p in [1009, 10007, 100003, 10**6 + 3, 10**9 + 7]:
            A = [x * x + p * x for x in range(N)]
            consider(A)
        if time.time() > deadline:
            break

    # Construction 2: A = {f(x) + p*x : x in F_q}
    for q in [11, 13, 17, 19, 23, 29, 31, 37, 41, 43]:
        if time.time() > deadline:
            break
        rng = range(q)
        for a in [1, 2, 3]:
            if a >= q:
                continue
            for b in rng:
                fvals = [(a * x * x + b * x) % q for x in rng]
                for mult in [10**6, 10**12]:
                    p = q * mult + 1
                    if p > 10**14:
                        continue
                    A = [fvals[x] + p * x for x in rng]
                    consider(A)

    # Construction 3: base-B amplification of good small sets
    for base in [[-3, -2, 0, 1, 4, 6, 7, 11], [0, 1, 3, 7], [-1, 0, 1, 2, 5]]:
        if time.time() > deadline:
            break
        m = len(base)
        maxabs = max(abs(x) for x in base)
        for k in range(2, 7):
            if m ** k > 4000:
                break
            for mult in [3, 10, 1000, 10**6]:
                B = 2 * maxabs * k * mult + 1
                if B > 10**15:
                    continue
                if B ** (k - 1) * maxabs > 10**15:
                    continue
                A = []
                ok = True
                for coeffs in product(base, repeat=k):
                    v = 0
                    pw = 1
                    for c in coeffs:
                        v += c * pw
                        pw *= B
                        if abs(v) > 10**15:
                            ok = False
                            break
                    if not ok:
                        break
                    A.append(v)
                if ok:
                    consider(A)

    if best_A is None:
        best_A = [-3, -2, 0, 1, 4, 6, 7, 11]

    return sorted(set(best_A))[:4000]
