import math
import time
import random
from itertools import product
import numpy as np
from scipy import ndimage

def score_set(a):
    """Compute the objective function for a set of integers."""
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    
    if not diffs or not sums:
        return 0.0
    
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def solve():
    deadline = time.time() + 110
    
    best_A = None
    best_score = 0.0
    
    # Stage 1: Try known high-quality base sets
    known_sets = [
        [-3, -2, 0, 1, 4, 6, 7, 11],
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        [-4, -3, -1, 0, 1, 2, 3, 4, 5, 6],
        [-5, -3, -1, 1, 3, 5],
    ]
    
    for base_set in known_sets:
        A = sorted(base_set)
        s = score_set(A)
        if s > best_score:
            best_score = s
            best_A = A[:]
    
    # Stage 2: Apply base-B expansion technique
    small = [-3, 0, 2, 4]  # Excellent small set for base expansion
    m = len(small)
    
    k_range = range(2, 8)
    for k in k_range:
        if m ** k > 4000:
            break
        
        max_abs = max(abs(x) for x in small)
        
        # Try different base factors for base-B expansion
        for base_mult in [3.0, 4.0, 5.0, 6.0]:
            B = int(2 * max_abs * k * base_mult) + 1
            if B > 1e15:
                continue
            
            A_list = []
            for coeffs in product(small, repeat=k):
                val = sum(c * pow(B, i) for i, c in enumerate(coeffs))
                A_list.append(val)
            
            A = sorted(set(A_list))
            if len(A) > 4000:
                A = A[:4000]
            
            s = score_set(A)
            if s > best_score:
                best_score = s
                best_A = A[:]
    
    # Stage 3: Fine-tune via local search (simulated annealing approach)
    cur_A = best_A[:]
    T = 20.0  # Initial temperature
    
    while time.time() < deadline:
        # Try random modifications
        if len(cur_A) < 10:
            break
        
        prev_score = score_set(cur_A)
        
        mods = []
        for i in range(len(cur_A)):
            delta = random.choice([-1e9, -1e7, -1e6, -1e5, -1e4, 
                                  -1e3, -1e2, -1e1, -1e6, 
                                  1e6, 1e7, 1e9, 1e3, 1e2, 10, 1, 500])
            prod = random.randint(-5000, 5000)
            shifts = [prod]
            mods.extend([(i, d) for d in shifts])
        
        for i, delta in mods:
            if delta == 0:
                continue
            
            new_A = cur_A[:]
            try:
                new_A[i] = new_A[i] + delta
            except (IndexError, ValueError):
                continue
            
            if len(new_A) != len(set(new_A)):
                continue
            
            s = score_set(new_A)
            
            if s > best_score:
                best_score = s
                cur_A = new_A[:]
                
                # Decrease temperature on good progress
                if s > prev_score * 1.01:
                    T *= 0.9
            
            if random.random() < math.exp((s - prev_score) / T):
                cur_A = new_A[:]
            
            if s > best_score:
                best_score = s
    
    # Stage 4: Additional random restarts for robustness
    for _ in range(5):
        if time.time() > deadline - 30:
            break
        
        # Small random shift near best set
        shift = random.randint(-2000, 2000)
        for i in range(len(cur_A)):
            val = cur_A[i] + shift
            
            if i > 0 and val == cur_A[i-1]:
                continue
            if i < len(cur_A) - 1 and val == cur_A[i+1]:
                continue
            
            candidate = cur_A[:]
            candidate[i] = val
            
            s = score_set(candidate)
            if s > best_score:
                best_score = s
                cur_A = candidate[:]
    
    return sorted(set(cur_A))[:4000]


def solve():
    deadline = time.time() + 110
    
    best_A = None
    best_score = 0.0
    
    # Known high-quality sets
    known_sets = [
        [-3, -2, 0, 1, 4, 6, 7, 11],
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        [-4, -3, -1, 0, 1, 2, 3, 4, 5, 6],
        [-5, -3, -1]
    ]
    
    for base_set in known_sets:
        A = sorted(set(base_set))
        if score_set(A) > best_score:
            best_score = score_set(A)  
            best_A = A[:]
    
    # Key small set for expansion
    expansion_base = [-3, 0, 2, 4]
    m = len(expansion_base)
    
    # Stage 2: Base-B expansion
    k = 4
    max_abs = max(abs(x) for x in expansion_base)
    B = int(4 * max_abs * 50) + 1
    
    A_list = []
    for coeffs in product(expansion_base, repeat=k):
        val = sum(c * pow(B, i) for i, c in enumerate(coeffs))
        A_list.append(val)
    
    A = sorted(set(A_list))
    if len(A) > 4000:
        A = A[:4000]
    
    if score_set(A) > best_score:
        best_score = score_set(A)
        best_A = A[:]
    
    # Stage 3: Fine-tuning with random shifts
    cur = best_A[:]
    T = 20.0
    
    for _ in range(500):
        if len(cur) < 2:
            break
        
        i = random.randint(0, len(cur) - 1)
        delta = random.choice([-5000, -2000, -500, -50, -1, 1, 50, 500, 2000])
        
        new_val = cur[i] + delta
        
        # Ensure uniqueness
        if new_val in cur:
            continue
        
        candidate = cur[:]
        candidate[i] = new_val
        
        if score_set(candidate) > best_score:
            best_score = score_set(candidate)
            cur = candidate[:]
    
    return sorted(set(cur))[:4000]
