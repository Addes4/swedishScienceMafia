import math
import time
from itertools import combinations

def solve():
    deadline = time.time() + 110  # leave some margin

    # ---------- helper: exact score of a set (small sets only, for tuning) ----------
    def exact_score(A):
        A = list(A)
        if len(A) < 2:
            return -1.0
        diffs = set()
        sums = set()
        for i, x in enumerate(A):
            for j, y in enumerate(A):
                diffs.add(x - y)
                sums.add(x + y)
        return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(A)) / 100

    # ---------- helper: construct Sidon set in [0, L] greedily ----------
    def sidon_set(L, max_size=None):
        # Greedy: pick numbers so no repeated differences
        seen_diffs = set()
        S = []
        # try to start from a good seed
        for x in range(0, L + 1):
            ok = True
            new_diffs = []
            for y in S:
                d = x - y
                if d in seen_diffs:
                    ok = False
                    break
                new_diffs.append(d)
            if not ok:
                continue
            # also need y - x unique; but since we check x - y for y < x,
            # and future elements z > x will check z - x, symmetric differences
            # need to be unique too: check negatives
            for y in S:
                d = y - x
                if d in seen_diffs:
                    ok = False
                    break
                new_diffs.append(d)
            if not ok:
                continue
            S.append(x)
            for d in new_diffs:
                seen_diffs.add(d)
            if max_size and len(S) >= max_size:
                break
        return S

    # Precompute a few good Sidon sets
    sidon_cache = {}
    def get_sidon(L, max_size):
        key = (L, max_size)
        if key not in sidon_cache:
            sidon_cache[key] = sidon_set(L, max_size)
        return sidon_cache[key]

    # ---------- small base sets (good difference/sum ratio) ----------
    # Some known good small sets
    small_candidates = [
        [-3, -2, 0, 1, 4, 6, 7, 11],
        [-3, -1, 0, 1, 3, 6, 8, 9],
        [-2, -1, 0, 1, 3, 5, 7, 8],
        [-4, -2, -1, 0, 2, 5, 7, 9],
        [-5, -2, 0, 1, 3, 6, 8, 10],
        [-3, -2, -1, 0, 2, 4, 6, 9],
        [-4, -1, 0, 1, 4, 5, 8, 9],
        [-6, -3, -1, 0, 2, 5, 7, 10],
        [-3, -1, 1, 2, 4, 6, 9, 12],
        [-2, 0, 1, 3, 5, 7, 10, 11],
    ]

    best_A = small_candidates[0][:]
    best_score = exact_score(best_A)
    best_len = len(best_A)

    # ---------- try to combine with product construction using Sidon layer ----------
    # A = { a + M * b : a in small_set, b in Sidon }
    # Size = |small| * |Sidon|
    # We want cross differences disjoint: M large enough that residues mod M separate
    # Sums cancellation: use additive structure of small_set for sums

    max_total = 4000

    # Search over small sets and Sidon sets
    for small in small_candidates:
        m = len(small)
        max_abs_small = max(abs(x) for x in small)
        # For the two-layer sum A+A = small+small + M*(sidon+sidon)
        # We want small+small range < M so that no wraparound in sums
        range_small_sum = 2 * max_abs_small
        # difference A-A = (small-small) + M*(sidon-sidon)
        # We want cross terms: (small1-small2) + M*(b1-b2) = 0 only if both zero
        # suffic: M > 2*max_abs_small ensures unique representation
        # Actually need M > range of small-small differences
        range_small_diff = 2 * max_abs_small

        # target Sidon size s such that m*s <= 4000
        max_sidon_size = max_total // m
        if max_sidon_size < 2:
            continue

        # Try different L values for Sidon
        for target_s in range(2, min(max_sidon_size, 200) + 1):
            # rough estimate: Sidon set in [0,L] has size ~ sqrt(L)
            # so L ~ target_s^2 * const
            for L_factor in [0.8, 1.0, 1.2, 1.5, 2.0]:
                L = int(target_s * target_s * L_factor) + 2
                if L < target_s:
                    continue
                S = get_sidon(L, target_s)
                if len(S) < 2:
                    continue
                if m * len(S) > max_total:
                    continue
                # choose M: must be > range_small_diff, and also large enough
                # so that different b give different sums, but we want sums to have
                # some collisions via small+small additive structure
                # M should be at least range of small sums + 1 to avoid sum collisions
                # but we can allow some overlap? Let's try a range of M
                for M in [range_small_sum + 1, range_small_sum + 2, range_small_sum + 3,
                          range_small_sum + 5, 2 * range_small_sum + 1,
                          range_small_sum * 2 + 3]:
                    if M <= 0:
                        continue
                    # Build A
                    A_set = set()
                    for a in small:
                        for b in S:
                            A_set.add(a + M * b)
                    if len(A_set) != m * len(S):
                        continue
                    if len(A_set) > max_total:
                        continue
                    # Evaluate exactly only if small enough; else approximate
                    sz = len(A_set)
                    if sz <= 400:
                        sc = exact_score(list(A_set))
                        if sc > best_score:
                            best_score = sc
                            best_A = list(A_set)
                            best_len = sz
                    else:
                        # approximate via counting differences and sums
                        # count diffs: (small-small) + M*(S-S)
                        # small-small has at most m^2 values; S-S has |S|*(|S|-1)+1 values
                        # if M > max|small-small|, then representation is unique
                        # so |A-A| = |small-small| * |(S-S) distinct| (with some care)
                        # Sums: |A+A| approximately = |(small+small) + M*(S+S)|
                        # For Sidon S, S+S can have size up to |S|^2 but actually
                        # Sidon means differences unique, sums may collide
                        # We'll do exact for sizes up to a few hundred
                        pass

    # ---------- refine: local search on best set by shifting/scaling ----------
    # Try scaling: A -> k*A for odd k? Scaling doesn't change ratio
    # Try translating: A -> A + t, ratio unchanged (translation invariant)

    # ---------- try larger direct construction: two-layer with bigger small set ----------
    # Use a moderate-size base with good ratio and multiply
    # Try A = {a + M*b : a in good_small, b in Sidon} with larger good_small

    # Also try: A = union of scaled copies: A = S1 + M*S2 where S1, S2 both small Sidon-like
    # This is the same as above

    # ---------- try exact greedy build for medium size then product ----------
    # Greedy: start with good small set, add numbers maximizing difference growth
    if time.time() < deadline - 60:
        # Use a few good base sets directly and try scaling product with itself
        for small in small_candidates:
            m = len(small)
            if m < 2:
                continue
            max_abs = max(abs(x) for x in small)
            # A = small + M * small (product with itself)
            for M in [2*max_abs + 1, 2*max_abs + 2, 2*max_abs + 3, 4*max_abs + 1]:
                A_set = set()
                for a in small:
                    for b in small:
                        A_set.add(a + M * b)
                if len(A_set) < 2 or len(A_set) > max_total:
                    continue
                sc = exact_score(list(A_set))
                if sc > best_score:
                    best_score = sc
                    best_A = list(A_set)
                    best_len = len(A_set)

    # ---------- try three-layer product ----------
    if time.time() < deadline - 40:
        for small in small_candidates[:4]:
            m = len(small)
            if m < 2 or m**3 > max_total:
                continue
            max_abs = max(abs(x) for x in small)
            for M1 in [2*max_abs + 1, 3*max_abs + 1, 4*max_abs + 1]:
                for M2 in [M1*m + 1, M1*m*2 + 1, M1*(2*max_abs+1) + 1]:
                    if M1 <= 0 or M2 <= 0:
                        continue
                    A_set = set()
                    for a in small:
                        for b in small:
                            for c in small:
                                A_set.add(a + M1 * b + M1 * M2 * c)
                    if len(A_set) < 2 or len(A_set) > max_total:
                        continue
                    if len(A_set) <= 500:
                        sc = exact_score(list(A_set))
                        if sc > best_score:
                            best_score = sc
                            best_A = list(A_set)
                            best_len = len(A_set)

    # ---------- If we have time, do a careful greedy extension ----------
    if time.time() < deadline - 20:
        # Start from best_A and try to add a few elements to improve ratio
        # Only if best_A is moderately sized
        A = list(best_A)
        # Compute current diffs and sums counts (approximate for large)
        if len(A) <= 2000:
            # Try adding elements that increase difference set a lot while
            # keeping sum set growth small
            # This is expensive; skip for large sets
            pass

    return sorted(set(best_A))[:4000]
