# EVOLVE-BLOCK-START
"""
Find optimal sum-difference set using hierarchical construction.
Uses powers of 2 with controlled perturbations to maximize differences while keeping sums clustered.
"""
import math
import random
import time

def compute_score(a):
    """Compute objective function: log|A-A|/log|A+A| + (1-1/|A|)/100 bonus."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    
    diffs = set()
    sums = set()
    for i in range(n):
        for j in range(n):
            diffs.add(a[i] - a[j])
            sums.add(a[i] + a[j])
    
    if len(diffs) < 1 or len(sums) < 1:
        return 0.0
    
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def solve():
    base_time = time.time()
    deadline = base_time + 115
    
    best_a = []
    best_score = -1
    
    def build_power2_set(num_powers, stride):
        """Build initial set: powers of 2 with stride separation."""
        a = []
        for k in range(num_powers):
            a.append(10 ** stride * (2 ** k))
        return a
    
    def optimize_with_perturb(a):
        """Greedy optimization with small perturbations."""
        cur = a[:]
        score_cur = compute_score(cur)
        
        for _ in range(2000):
            i = random.randint(0, len(cur) - 1)
            if len(cur) == 1: continue
            
            delta = random.randint(-500, 500)
            new_val = cur[i] + delta
            
            if new_val in cur: continue
            if abs(new_val) > 1e15: continue
            
            cand = cur[:]
            cand[i] = new_val
            score_cand = compute_score(cand)
            cur, score_cur = cand, score_cand
            
            if score_cand < score_cur:
                if i < len(cur) // 2:
                    cur = a[:]
                    break
        
        return cur
    
    # Try different power-of-2 constructions
    for power_count in range(10, 25):
        for stride in range(6, 11):
            a = build_power2_set(power_count, stride)
            a = optimize_with_perturb(a)
            ptr = compute_score(a)
            if ptr > best_score:
                best_score, best_a = ptr, a[:]
    
    # Interleaved construction with gaps
    for num_blocks in range(3, 7):
        for gap in range(10 ** 6, 10 ** 8):
            block_mods = [i for i in range(min(num_blocks, 8))]
            a = []
            for block in range(num_blocks):
                base = (13 ** block) * gap
                for mod in block_mods:
                    a.append(base + mod * 3)
            a = optimize_with_perturb(a)
            ptr = compute_score(a)
            if ptr > best_score:
                best_score, best_a = ptr, a[:]
    
    # Large sparse array with additive offsets
    for power in range(12, 18):
        base_scale = 2 ** power * 1000
        base_construction = []
        for k in range(8):
            offsets = [random.randint(-10, 10) for _ in range(3)]
            for i in range(3):
                base_construction.append(base_scale * (2 ** k) + offsets[i])
        a = optimize_with_perturb(base_construction)
        ptr = compute_score(a)
        if ptr > best_score:
            best_score, best_a = ptr, a[:]
    
    # Ensure unique sorted result
    best_a = sorted(set(best_a))
    
    end_time = time.time()
    return best_a[:4000]
# EVOLVE-BLOCK-END
