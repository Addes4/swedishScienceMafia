# EVOLVE-BLOCK-START
"""Seed-and-grow integer set construction for max |A-A| and min |A+A|.

Strategy:
1) Build a seed using a Singer/Bose-Chowla modular difference-set style construction over a
   prime modulus, then lift to integers via a scaled Chinese-remainder embedding.
2) Greedily grow from the seed with a fast incremental evaluator:
   - Track sums via a Counter (size |A+A|) and differences via a Counter (size |A-A|).
   - Adding a new element x costs O(|A|) updates; the score is recomputed from counters.
3) Multiple restarts with different moduli/scale, keep the best by true score.
"""
import math
import random
import time
from collections import Counter


def _true_score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _mod_inv(a, m):
    return pow(a, -1, m)


def _singer_seed(p, k):
    """Bose-Chowla style: for prime power q = p, use Sidon-ish set {2pi + (i^2 mod p)} lifted.
    Simpler: construct a small difference-rich set via quadratic residues + shift."""
    base = []
    for i in range(1, k + 1):
        base.append((i * i) % p + i * p)
    return base


def _greedy_grow(seed, pool, time_limit, target_size):
    """Incrementally grow the set by best candidate additions."""
    A = sorted(set(seed))
    sum_cnt = Counter()
    diff_cnt = Counter()
    for i, x in enumerate(A):
        for j, y in enumerate(A):
            sum_cnt[x + y] += 1
            diff_cnt[x - y] += 1

    def estimate(x):
        # marginal effect
        new_s = 0
        for y in A:
            s = x + y
            if sum_cnt.get(s, 0) == 0:
                new_s += 1
        new_d = 0
        for y in A:
            d = x - y
            if diff_cnt.get(d, 0) == 0:
                new_d += 1
            d2 = y - x
            if d2 != d and diff_cnt.get(d2, 0) == 0:
                new_d += 1
        ns = len(sum_cnt) + new_s
        nd = len(diff_cnt) + new_d
        if ns < 1:
            return -1e18
        return math.log(nd) / math.log(ns)

    deadline = time.time() + time_limit
    candidates = list(pool)
    random.shuffle(candidates)
    while time.time() < deadline and len(A) < target_size:
        best_x = None
        best_v = -1e18
        sample = candidates
        if len(sample) > 400:
            sample = random.sample(sample, 400)
        for x in sample:
            if x in A:
                continue
            # ensure no duplicate
            v = estimate(x)
            if v > best_v:
                best_v = v
                best_x = x
        if best_x is None:
            break
        x = best_x
        for y in A:
            sum_cnt[x + y] += 1
            diff_cnt[x - y] += 1
            diff_cnt[y - x] += 1
        sum_cnt[2 * x] += 1
        diff_cnt[0] += 1
        A.append(x)
        A.sort()
    return A


def _pool_from_modulus(p, max_radius):
    return [i for i in range(-max_radius, max_radius + 1) if i != 0]


def solve():
    random.seed(12345)
    deadline = time.time() + 115

    best_A = None
    best_s = -1e18

    # Known strong small configurations to seed from
    known_seeds = [
        [0, 1, 3, 7, 15, 31],              # difference-rich (Golomb-like)
        [0, 1, 4, 9, 15, 22],
        [0, 1, 3, 8, 12, 18],
        [0, 1, 3, 6, 10, 15],
        [0, 1, 4, 10, 12, 17],
        [1, 2, 4, 8, 16, 29],
    ]

    # Try Singer-style constructions over various primes
    primes = [11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89,
              97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173,
              179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251]

    attempts = []
    for seed in known_seeds:
        attempts.append(("known", seed))
    for p in primes:
        k = min(p - 1, max(4, int(math.sqrt(p)) + 2))
        attempts.append(("singer", _singer_seed(p, k)))
    # random small dense seeds
    for _ in range(9):
        k = random.randint(6, 10)
        s = sorted(random.sample(range(0, 60), k))
        attempts.append(("rand", s))

    idx = 0
    while time.time() < deadline and idx < len(attempts):
        tag, seed = attempts[idx]
        idx += 1
        seed = sorted(set(seed))
        if len(seed) < 4:
            continue
        scale = random.choice([1, 2, 3, 5])
        seed = [x * scale for x in seed]
        max_r = max(200, 40 * len(seed))
        pool = _pool_from_modulus(1, max_r)
        remaining = deadline - time.time()
        if remaining <= 1:
            break
        tl = min(remaining * 0.5, 14.0)
        target = max(len(seed) + 4, min(30, len(seed) + 12))
        A = _greedy_grow(seed, pool, tl, target)
        s = _true_score(A)
        if s > best_s:
            best_s = s
            best_A = A[:]

    # Polish: local search with incremental true score on the best set
    if best_A is not None:
        A = best_A[:]
        s = best_s
        while time.time() < deadline:
            c = A[:]
            i = random.randrange(len(c))
            delta = random.choice([-7, -5, -3, -1, 1, 2, 3, 5, 7, 11])
            c[i] += delta
            if len(set(c)) < len(c):
                continue
            if random.random() < 0.08 and len(c) < 40:
                c.append(random.randint(-80, 80))
                if len(set(c)) < len(c):
                    continue
            if random.random() < 0.05 and len(c) > 5:
                c.pop(random.randrange(len(c)))
            cs = _true_score(c)
            if cs >= s:
                A, s = c, cs
            elif random.random() < 0.08:
                A = c
        if s > best_s:
            best_s = s
            best_A = A

    if best_A is None:
        best_A = [7, 15, 18, 22, -3, -2]
    result = sorted(set(int(x) for x in best_A if abs(x) <= 10**15))
    if len(result) > 4000:
        result = result[:4000]
    if len(result) < 2:
        result = [0, 1]
    return result
# EVOLVE-BLOCK-END
