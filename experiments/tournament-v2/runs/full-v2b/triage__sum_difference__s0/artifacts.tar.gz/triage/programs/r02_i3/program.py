# EVOLVE-BLOCK-START
"""Merge small high-ratio sets, translated far apart, into one large set."""
import math
import random
import time
from itertools import combinations

DEADLINE_GLOBAL = time.time() + 115.0


def _diff_count(a):
    return len({x - y for x in a for x in a})


def _sum_count(a):
    return len({x + y for x in a for y in a})


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    d = _diff_count(a)
    s = _sum_count(a)
    if s == 0:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


# ---------- small local search (basin-hopping style) ----------

def _local_search_small(seed, rng, time_budget):
    """Improve a small set (<=~22 elements) maximizing log|D|/log|S|."""
    cur = list(set(seed))
    cur_score, _, _ = _score(cur)
    best = cur[:]
    best_score = cur_score
    t0 = time.time()
    steps = 0
    while time.time() - t0 < time_budget:
        steps += 1
        cand = cur[:]
        mode = rng.random()
        if mode < 0.55:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-3, 3)
        elif mode < 0.80:
            cand.append(rng.randint(-30, 30))
        elif mode < 0.90 and len(cand) > 5:
            del cand[rng.randrange(len(cand))]
        else:
            # shift a contiguous chunk
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-8, -5, 5, 8, 13, -13])
        if len(cand) > 22:
            continue
        cand = list(set(cand))
        if len(cand) < 4:
            continue
        sc, _, _ = _score(cand)
        if sc >= cur_score or rng.random() < 0.08:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc
    return best


def make_pool(rng, pool_size, time_budget):
    pool = []
    t0 = time.time()
    bases = [
        [0, 1, 4, 10, 12],
        [7, 15, 18, 22, -3, -2],
        [0, 1, 3, 7, 12, 20],
        [0, 1, 4, 9, 15, 22, 26],
    ]
    i = 0
    while len(pool) < pool_size and time.time() - t0 < time_budget:
        if i < len(bases):
            seed = [x + rng.randint(-2, 2) for x in bases[i]]
        else:
            n = rng.randint(8, 16)
            seed = [rng.randint(-25, 25) for _ in range(n)]
        cand = _local_search_small(seed, rng, time_budget / max(1, pool_size))
        cand = list(set(cand))
        if 5 <= len(cand) <= 22:
            pool.append(cand)
        i += 1
    return pool


def _norm(a, lo=None):
    """Normalize differences by subtracting min and scaling."""
    if lo is None:
        lo = min(a)
    return [x - lo for x in a]


def _translate_far(a, offset):
    return [x + offset for x in a]


def merge(a, b):
    """Try merging two small sets by translating b far from a."""
    if not a:
        return b[:]
    if not b:
        return a[:]
    a = sorted(set(a))
    b = sorted(set(b))
    base = max(a) - min(a) + max(b) - min(b) + 5
    best = a + [x + base for x in b]
    return best


def greedy_merge(pool, rng, time_budget, max_size=4000, target_span=10**13):
    """
    Greedily merge pool entries, translating each copy far away so that
    difference sets remain (mostly) disjoint while sum sets overlap.
    """
    t0 = time.time()
    # sort pool by score descending
    scored = []
    for s in pool:
        sc, d, ss = _score(s)
        scored.append((sc, len(s), s))
    scored.sort(key=lambda t: -t[0])
    pool_sorted = [s for _, _, s in scored]

    # build result greedily
    result = pool_sorted[0][:]
    used = 1
    # current useful stats
    cur_d, cur_s = _diff_count(result), _sum_count(result)

    # candidate offsets that maximize overlap of sums while avoiding diff overlap
    i = 1
    while i < len(pool_sorted):
        if time.time() - t0 > time_budget:
            break
        cand_block = pool_sorted[i]
        i += 1
        if len(result) + len(cand_block) > max_size:
            continue

        # Try multiple translations
        span = max(result) - min(result)
        # estimate difference range of result
        try_best = None
        try_best_sc = -1.0
        # offsets to try: align so that b's sum-set overlaps with result's
        # choose offset so that 2*offset is near some value in result's sum set
        rs = sorted({x + y for x in result[:60] for y in result[:60]})
        sample_sums = rs[::max(1, len(rs) // 40)]

        offsets = set()
        # far but controlled translations
        for _ in range(6):
            offsets.add(rng.randint(span + 3, span + 2 * span + 5))
        # offsets that push 2*offset into result's sum range for sum overlap
        for smp in sample_sums[:12]:
            off = rng.randint(1, 5) + smp // 2 - (min(cand_block))
            if off > span + 2:
                offsets.add(off)
        # ensure difference range doesn't collide: add big padding offsets
        for mult in (1, 2, 3):
            offsets.add(mult * (2 * span + max(cand_block) - min(cand_block) + 7))

        for off in list(offsets)[:24]:
            if off <= 0:
                continue
            block = [x + off for x in cand_block]
            if min(block) <= max(result):
                # ensure blocks don't interleave in a bad way; still allowed but check
                pass
            combo = result + block
            if len(combo) > max_size:
                continue
            sc, d, s = _score(combo)
            if sc > try_best_sc:
                try_best_sc = sc
                try_best = combo
        if try_best is not None:
            # accept if not much worse per-element (score stays similar or better)
            cur_sc, cur_d, cur_s = _score(result)
            if try_best_sc >= cur_sc - 1e-9 or rng.random() < 0.35:
                result = try_best

    return result


def greedy_merge_bisect(pool, rng, time_budget, max_size=4000):
    """
    Merge sets in a balanced binary fashion: combine pairs,
    translating one copy far away. Each merge is checked by score.
    """
    t0 = time.time()
    scored = []
    for s in pool:
        sc, d, ss = _score(s)
        scored.append((sc, s))
    scored.sort(key=lambda t: -t[0])
    level = [s for _, s in scored]

    while len(level) > 1 and time.time() - t0 < time_budget:
        nxt = []
        for j in range(0, len(level) - 1, 2):
            a, b = level[j], level[j + 1]
            if len(a) + len(b) > max_size:
                nxt.append(a)
                nxt.append(b)
                continue
            # try a variety of offsets
            best = None
            best_sc = -1.0
            span = max(a) - min(a)
            bspan = max(b) - min(b)
            base_offsets = []
            for k in range(1, 12):
                base_offsets.append(k * (span + bspan + 5) + rng.randint(0, 7))
            for off in base_offsets:
                combo = a + [x + off for x in b]
                if len(combo) > max_size:
                    continue
                sc, d, s = _score(combo)
                if sc > best_sc:
                    best_sc = sc
                    best = combo
            if best is None:
                best = a + [x + (span + bspan + 5) for x in b]
            nxt.append(best)
        if len(nxt) == len(level) and all(len(x) == len(y) for x, y in zip(nxt, level)):
            break
        level = nxt
        if len(level) > 200:
            # prune weakly scored large sets occasionally
            level.sort(key=lambda s: -_score(s)[0])
            level = level[:200]

    if not level:
        return []
    level.sort(key=lambda s: -_score(s)[0])
    return level[0]


def solve():
    rng = random.Random(12345)
    start = time.time()
    total = DEADLINE_GLOBAL - start
    if total <= 0:
        total = 1.0

    # 1. Build a pool of high-ratio small sets via local search.
    pool_budget = min(total * 0.55, 60.0)
    pool = make_pool(rng, pool_size=120, time_budget=pool_budget)
    if not pool:
        pool = [[7, 15, 18, 22, -3, -2]]

    # Normalize each small set: shift to start at 0 so translations are clean
    norm_pool = []
    for s in pool:
        s = sorted(set(s))
        lo = min(s)
        norm_pool.append([x - lo for x in s])

    # 2. Merge via balanced binary approach
    remain = DEADLINE_GLOBAL - time.time()
    if remain < 1.0:
        remain = 1.0
    cand1 = greedy_merge_bisect(norm_pool[:], rng, remain * 0.6, max_size=4000)

    # 3. Alternative: greedy incremental merging
    remain = DEADLINE_GLOBAL - time.time()
    if remain < 1.0:
        remain = 1.0
    cand2 = greedy_merge(norm_pool[:], rng, remain * 0.7, max_size=4000)

    # 4. Also try merging with a small offset strategy to force sum overlaps:
    #    translate blocks so that there's a chance sums coincide.
    remain = DEADLINE_GLOBAL - time.time()
    if remain < 1.0:
        remain = 1.0
    cand3 = greedy_merge(norm_pool[:], rng, remain * 0.6, max_size=4000)

    candidates = [cand1, cand2, cand3]
    best = None
    best_score = -1.0
    for c in candidates:
        if not c:
            continue
        c = sorted(set(c))
        sc, d, s = _score(c)
        if sc > best_score:
            best_score = sc
            best = c

    # 5. Final polish: try trimming extreme outliers that hurt sum set size
    if best is not None and len(best) > 4:
        remain = DEADLINE_GLOBAL - time.time()
        if remain > 2.0:
            t0 = time.time()
            cur = best[:]
            cur_score, _, _ = _score(cur)
            while time.time() - t0 < remain * 0.9:
                cand = cur[:]
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-2, 2)
                sc, _, _ = _score(cand)
                if sc > cur_score:
                    cur, cur_score = cand, sc
            if cur_score > best_score:
                best = cur
                best_score = cur_score

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # Final safety: distinct ints within limits
    out = []
    seen = set()
    for x in best:
        x = int(x)
        if x in seen:
            continue
        if abs(x) > 10**15:
            continue
        seen.add(x)
        out.append(x)
    if len(out) > 4000:
        out = out[:4000]
    if len(out) < 2:
        out = [0, 1]
    return out
# EVOLVE-BLOCK-END
