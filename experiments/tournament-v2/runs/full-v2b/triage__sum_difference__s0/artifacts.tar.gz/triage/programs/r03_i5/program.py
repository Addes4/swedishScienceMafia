import math
import time
import random
from itertools import product

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    la = list(a)
    for x in la:
        for y in la:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def small_score_components(a):
    """Return (|D|, |S|, |A|) quickly."""
    a = list(set(a))
    la = a
    diffs = set()
    sums = set()
    for x in la:
        for y in la:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)

def solve():
    deadline = time.time() + 110
    best_A = None
    best_score = -1.0

    # ---- Phase 1: find good small base sets via random search ----
    # We want small sets with large difference set and small sum set.
    # Good constructions have the form of a "Sidon-like" / arithmetic-progression-heavy
    # structure where sums collide often but differences are spread out.
    #
    # Known good patterns: sets with many elements concentrated so sums collide,
    # but the structure gives large diff set.

    def eval_small(a):
        a = list(set(a))
        if len(a) < 2:
            return -1.0
        d, s, n = small_score_components(a)
        if s <= 1:
            return -1.0
        return math.log(d) / math.log(s) + (1 - 1 / n) / 100

    # Seed candidates
    seeds = [
        [-3, -2, 0, 1, 4, 6, 7, 11],
        list(range(8)),
        [0,1,2,3,4,5,6,7,8,9,10,11,12],
        [0,1,2,4,5,8,9,10],
        [-1,0,1,2,5,7,8,12],
    ]

    best_small = None
    best_small_sc = -1.0
    for sd in seeds:
        sc = eval_small(sd)
        if sc > best_small_sc:
            best_small_sc = sc
            best_small = sd[:]

    # random local search on small sets
    end_p1 = min(deadline - 70, time.time() + 20)
    while time.time() < end_p1:
        n = random.randint(6, 12)
        # random set from a small window
        span = random.randint(n - 1, n + 8)
        vals = random.sample(range(-span, span + 1), n)
        sc = eval_small(vals)
        if sc > best_small_sc:
            best_small_sc = sc
            best_small = vals[:]
        # local hill-climb
        cur = best_small[:]
        cursc = best_small_sc
        for _ in range(300):
            if time.time() >= end_p1:
                break
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2,-1,1,2])
            if len(set(cand)) == len(cand):
                s = eval_small(cand)
                if s > cursc:
                    cursc = s
                    cur = cand
        if cursc > best_small_sc:
            best_small_sc = cursc
            best_small = cur[:]

    # ---- Phase 2: base-B product construction ----
    # A = { sum_i x_i * B^i }   with v in small on k digits
    # Difference set size ~ (|D_small|)^k roughly, but many collisions;
    # Sum set gains structure because sums can be reduced.
    # The val = sum_i x_i B^i, digits in small. Sums differ by carries.

    def build_from_small(small, k, B):
        max_abs = max(abs(x) for x in small)
        if max_abs * (B ** (k-1)) > 1e15:
            return None
        A = []
        for coeffs in product(small, repeat=k):
            val = 0
            for i in range(k):
                val += coeffs[i] * (B ** i)
            A.append(val)
        if len(set(A)) != len(A):
            return None
        return A

    small = best_small
    m = len(small)
    max_abs = max(abs(x) for x in small)

    candidates = []
    for k in range(2, 9):
        if m ** k > 4000:
            break
        for bf in [1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0]:
            B = int(2 * max_abs * bf) + 1
            if B < 2:
                B = 2
            if max_abs * (B ** (k-1)) > 1e15:
                continue
            A = build_from_small(small, k, B)
            if A is None:
                continue
            if len(A) > 4000:
                continue
            candidates.append(A)

    # Evaluate candidates
    for A in candidates:
        if time.time() > deadline:
            break
        sc = score_set(A)
        if sc > best_score:
            best_score = sc
            best_A = A

    # ---- Phase 3: mixed radix / shifted digits ----
    # Instead of all digits in same small set, we could use different digit sets,
    # but keep product form for speed. Try shifting the small set to have nonneg digits.
    if time.time() < deadline:
        small2 = [x - min(small) for x in small]
        m2 = len(small2)
        max_abs2 = max(abs(x) for x in small2)
        for k in range(2, 9):
            if m2 ** k > 4000:
                break
            for bf in [1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 14.0, 20.0]:
                B = int(2 * max_abs2 * bf) + 1
                if B < 2:
                    B = 2
                if max_abs2 * (B ** (k-1)) > 1e15:
                    continue
                A = build_from_small(small2, k, B)
                if A is None or len(A) > 4000:
                    continue
                if time.time() > deadline:
                    break
                sc = score_set(A)
                if sc > best_score:
                    best_score = sc
                    best_A = A

    # ---- Phase 4: try to improve by tweaking base to reduce sum collisions ----
    # The sum set under base-B: (x+y) per digit, with carries. To minimize sum set
    # we want digits x_i + y_i to collide a lot. Smaller digit range helps.
    # Try scaling small set so digit sums are concentrated.

    if time.time() < deadline and best_A is not None:
        # local search: try shifting whole set by constant (doesn't change score)
        # try small perturbations of the base construction
        pass

    # ---- Phase 5: direct greedy hook onto best_A to enlarge ----
    # Try adding elements that keep diffs large but sums small.
    if time.time() < deadline and best_A is not None and len(best_A) < 4000:
        cur = set(best_A)
        d0, s0, n0 = small_score_components(list(cur))
        # sample candidate additions from a range related to current set
        end_p5 = deadline
        tries = 0
        while time.time() < end_p5 and len(cur) < 4000 and tries < 200000:
            tries += 1
            if tries % 5000 == 0 and time.time() > end_p5:
                break
            base = random.choice(list(cur))
            offset = random.randint(-100, 100)
            cand = base + offset
            if cand in cur:
                continue
            new_set = cur | {cand}
            lns = list(new_set)
            d, s, n = small_score_components(lns)
            if s <= 0:
                continue
            newsc = math.log(d)/math.log(s) + (1 - 1/n)/100
            cursc = math.log(d0)/math.log(s0) + (1-1/n0)/100 if s0>1 else -1
            if newsc > cursc:
                cur = new_set
                d0, s0, n0 = d, s, n
        if math.log(d0)/math.log(s0) + (1-1/n0)/100 > best_score and s0 > 1:
            best_score = math.log(d0)/math.log(s0) + (1-1/n0)/100
            best_A = list(cur)

    if best_A is None:
        return list(range(1, 100))
    return sorted(set(best_A))[:4000]
