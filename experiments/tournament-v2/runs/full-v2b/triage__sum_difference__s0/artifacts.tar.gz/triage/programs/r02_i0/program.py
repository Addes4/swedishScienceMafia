import math
import time
import itertools
import numpy as np

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    best_A = None
    best_score = 0.0
    deadline = time.time() + 115

    # Modulus selection: we want R+R to be narrow, R-R to be wide.
    # For modulus M, residues in a short interval [a,b] give narrow R+R (size ~2(b-a)+1)
    # while R-R covers roughly all differences in that interval (size ~2(b-a)+1 as well, but full interval width).
    # However, to make R-R wide and R+R narrow, we can use arithmetic progressions or specific sets.
    # Key idea: R = {0, d, 2d, ..., (k-1)d} mod M
    # Then R+R = {0, d, ..., 2(k-1)d} mod M -> size 2k-1
    # R-R = { -(k-1)d, ..., (k-1)d } mod M -> size 2k-1 as well, not better.
    # Better: choose residues forming a generalized Sidon set with small sumset.
    # Use small sets from literature: e.g., Mersenne–Twister? Let's brute force small M and residue choices.

    # We'll search for small residue sets (up to ~15 elements) mod M, M up to ~1000,
    # maximizing log|R-R|/log|R+R|. Then lift them with disjoint multipliers.
    
    def residues_score(R, M):
        R_set = set(R)
        k = len(R_set)
        if k < 2:
            return 0.0
        sums = set()
        diffs = set()
        for a in R_set:
            for b in R_set:
                sums.add((a + b) % M)
                diffs.add((a - b) % M)
        if len(sums) <= 1 or len(diffs) <= 1:
            return 0.0
        return math.log(len(diffs)) / math.log(len(sums))
    
    best_residues = None
    best_residue_score = 0.0
    best_M = 1
    
    # Search small moduli and sets using heuristic search
    for M in range(3, 200):  # limited due to time
        if time.time() > deadline:
            break
        # try arithmetic progressions with different step sizes and lengths
        for step in range(1, M):
            for start in range(M):
                max_len = min(20, M // step + 1)
                for length in range(2, max_len + 1):
                    R = [(start + i * step) % M for i in range(length)]
                    sc = residues_score(R, M)
                    if sc > best_residue_score:
                        best_residue_score = sc
                        best_residues = R
                        best_M = M
        # try random subsets
        for _ in range(100):
            k = np.random.randint(2, min(15, M))
            R = list(np.random.choice(M, k, replace=False))
            sc = residues_score(R, M)
            if sc > best_residue_score:
                best_residue_score = sc
                best_residues = R
                best_M = M
    
    # If residue search didn't find good enough, fallback to known good construction
    if best_residues is None or best_residue_score < 0.5:
        # Known: R = {0,1,3} mod 7 gives R+R size 5, R-R size 7, score ~ log7/log5=1.209
        best_M = 7
        best_residues = [0, 1, 3]
        best_residue_score = residues_score(best_residues, best_M)

    M = best_M
    R = list(set(best_residues))
    k_R = len(R)
    
    # Now lift residues to disjoint cosets by choosing multipliers.
    # Let A = { r + t*M : r in R, t in T } where T is a set of "shifts".
    # To keep sumset small: A+A subset of { r1+r2 + (t1+t2)*M }.
    # Size of A+A <= |R+R| * |T+T|. So we want T+T small.
    # For difference set: A-A = { r1-r2 + (t1-t2)*M }. Since M is chosen such that 
    # residues differences are distinct mod M? Not necessarily, but we can separate 
    # difference sets from different (t1-t2) shifts by making the multiples large enough?
    # Actually, A-A size = sum over d in T-T of |(R-R)_d| where overlap possible.
    # To maximize |A-A|, we should ensure differences from distinct d stay distinct.
    # This happens if max difference in R-R < M and T chosen with gaps > max R-R.
    # But max R-R < M since modulo M. So if we choose T as arithmetic progression with step > 1?
    # Wait: r1-r2 is in (-M, M). t1-t2 are integers. If T elements are spaced by at least M,
    # then shifts don't overlap: (t1-t2)*M + (r1-r2) uniquely determines (t1-t2) since |r1-r2| < M.
    # But then T+T size grows as 2|T|-1. That's okay.
    
    # So plan: choose T = {0, M, 2M, 3M, ..., (n_T-1)*M} (multipliers = 0,1,2,...? Actually shift = t*M)
    # Then shifts are 0, M, 2M,... which are spaced by M.
    # Then difference (t_i - t_j)*M has absolute value up to (n_T-1)*M.
    # To avoid overlap: require |r_i - r_j| < M, which is true.
    # Then |A-A| = (2 n_T - 1) * |R-R|, because for each d in {-(n_T-1),..,n_T-1}, contributions are exactly R-R shifted by d*M, all disjoint.
    # |A+A| = (2 n_T - 1) * |R+R|? Actually T+T = {0, M, 2M, ..., 2(n_T-1)M} size 2n_T-1. Sums: r1+r2 + (t1+t2)*M. 
    # Since r1+r2 < 2M, and multiples are multiples of M, overlaps could still happen if r1+r2 >= M, then carry to next multiple.
    # This would merge sumset elements, reducing sumset size! That's good.
    # To minimize sumset, we want R+R to be small and such that r1+r2 mod M falls in a small set, so many collisions.
    
    # The residue set we chose already maximizes log|R-R|/log|R+R|.
    # Lifting with T as 0, step, 2*step,... and step = M ensures difference sets disjoint.
    # Sumset A+A: for each s from T+T, we have residues set R+R shifted by s, but with possible carries from adding residues.
    # Actual sum = (t1+t2)*M + (r1+r2). If r1+r2 >= M, then (r1+r2) mod M + M gets added to multiple.
    # This effectively means sumset size could be even smaller than (2n_T-1)*|R+R| because of wrap-around merging.
    # We'll check with actual sets.
    
    # Let's try various sizes n_T up to total elements ~4000
    max_total = 4000
    best_config = None
    best_config_score = 0.0
    
    for n_T in range(1, max_total // k_R + 1):
        if time.time() > deadline:
            break
        T = list(range(n_T))  # multipliers 0..n_T-1
        # Build A
        A = []
        for t in T:
            for r in R:
                A.append(r + t * M)
        A = list(set(A))  # distinct
        if len(A) != k_R * n_T:
            continue  # collision? shouldn't happen
        if len(A) > max_total:
            break
        sc = score_set(A)
        if sc > best_config_score:
            best_config_score = sc
            best_config = A
            best_score = sc
    
    # Also try step larger than 1 for T to further separate, though difference set size formula changes
    for step_mult in [M, 2*M]:
        for n_T in range(1, max_total // k_R + 1):
            if time.time() > deadline:
                break
            T = [i * step_mult for i in range(n_T)]
            A = []
            for t in T:
                for r in R:
                    A.append(r + t)
            A = list(set(A))
            if len(A) != k_R * n_T:
                continue
            if len(A) > max_total:
                break
            sc = score_set(A)
            if sc > best_config_score:
                best_config_score = sc
                best_config = A
                best_score = sc
    
    # If all above fails, local search refinement on best_config
    if best_config is not None:
        cur = sorted(set(best_config))
        cur_score = score_set(cur)
        deadline_local = time.time() + (deadline - time.time())
        while time.time() < deadline_local:
            cand = cur[:]
            i = np.random.randint(len(cand))
            cand[i] += np.random.randint(-3, 3)
            if np.random.random() < 0.05:
                cand.append(np.random.randint(1, M*max_total))
            if np.random.random() < 0.03 and len(cand) > 5:
                cand = cand[1:]
            # keep elements bounded? loosely clip
            cand = [x for x in cand if abs(x) <= 1e15]
            if len(cand) > max_total:
                continue
            sc = score_set(cand)
            if sc >= cur_score:
                cur, cur_score = cand[:], sc
                if sc > best_score:
                    best_score = sc
                    best_config = cand[:]
            elif np.random.random() < 0.1:
                cur = cand[:]
        return sorted(set(best_config))
    
    # if nothing works, return small known good set
    return [0, 1, 3, 7, 12, 20]

