import math
import time
import random
from itertools import product

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    deadline = time.time() + 110
    best_overall = None
    best_overall_score = 0.0
    
    # Try linear recurrence constructions over a large prime
    # x_{n+k} = c_0 x_n + ... + c_{k-1} x_{n+k-1} mod p
    # Take A = orbit, scale by p, add offsets
    
    def try_recurrence(p, k, coeffs, m, seed_vals, scale, max_attempts=50):
        nonlocal best_overall, best_overall_score
        # Generate orbit mod p
        x = list(seed_vals[:k])
        while len(x) < m:
            nxt = 0
            for i, c in enumerate(coeffs):
                nxt += c * x[len(x) - k + i]
            x.append(nxt % p)
        distinct = len(set(x[:m]))
        if distinct < 10:
            return
        # Lift to integers: A = {x_i * scale + offset_i}
        # To control sums, we want sums to be confined to few values.
        # If we use offsets in a set O, then sums = x_i + x_j + o_i + o_j.
        # Since x_i + x_j mod p takes few values, using small distinct offsets
        # per element breaks modular structure while keeping sums varied.
        A = [x[i] * scale + i for i in range(m)]
        if len(A) > 4000:
            A = A[:4000]
        A = list(set(A))
        if len(A) < 10:
            return
        s = score_set(A)
        if s > best_overall_score:
            best_overall_score = s
            best_overall = A[:]
    
    # Parameter search
    primes = [1000003, 1000033, 999983, 500009, 1000000007, 1000036003]
    configs = []
    for p in primes[:3]:
        for k in [2, 3, 4, 5, 6]:
            # Various coefficient patterns
            # Pattern: characteristic polynomial with roots
            configs.append((p, k, [1] + [0]*(k-1), p))  # x_{n+k}=x_n
            configs.append((p, k, [0]*(k-1) + [1], p))  # x_{n+k}=x_{n+k-1}
            configs.append((p, k, [1, 1] + [0]*(k-2), p))  # Fibonacci-like
            if k >= 3:
                configs.append((p, k, [0, 1] + [0]*(k-3) + [1], p))
    
    random.seed(42)
    for attempt in range(200):
        if time.time() > deadline - 2:
            break
        p = random.choice(primes)
        k = random.randint(2, 7)
        coeffs = [random.randint(0, p-1) for _ in range(k)]
        # Make coeffs not all zero
        if all(c == 0 for c in coeffs):
            coeffs[0] = 1
        m = random.randint(500, 3500)
        seed_vals = [random.randint(0, p-1) for _ in range(k)]
        try_recurrence(p, k, coeffs, m, seed_vals, p)
    
    # Try structured constructions
    for attempt in range(200):
        if time.time() > deadline - 2:
            break
        p = random.choice(primes)
        k = random.randint(2, 6)
        # Structured: recurrence with sparse coefficients
        coeffs = [0] * k
        num_terms = random.randint(1, min(3, k))
        for _ in range(num_terms):
            coeffs[random.randint(0, k-1)] = random.randint(1, p-1)
        m = random.randint(1000, 3800)
        seed_vals = [random.randint(0, p-1) for _ in range(k)]
        try_recurrence(p, k, coeffs, m, seed_vals, p)
    
    # Recurrences where x_{n+k} = x_n + x_{n+1} (Fibonacci mod p)
    for p in primes:
        if time.time() > deadline - 2:
            break
        for k, coeffs in [(2, [1, 1]), (3, [1, 1, 0]), (4, [0, 1, 1, 0]), (5, [0, 1, 1, 0, 0])]:
            for m in [1000, 2000, 3000, 3500]:
                for seed in [(0, 1) + tuple([0]*(k-2)), (1, 1) + tuple([0]*(k-2))]:
                    if len(seed) < k:
                        continue
                    try_recurrence(p, k, coeffs, m, list(seed[:k]), p)
    
    # Construction: powers of 2 mod p (or similar), i.e., multiplicative
    for p in primes:
        if time.time() > deadline - 2:
            break
        for g in [2, 3, 5, 7, 11, 13]:
            x = 1
            vals = []
            seen = set()
            for _ in range(3800):
                if x in seen:
                    break
                seen.add(x)
                vals.append(x)
                x = (x * g) % p
            if len(vals) < 50:
                continue
            m = min(len(vals), 3800)
            A = [vals[i] * p + i for i in range(m)]
            A = list(set(A))
            if len(A) < 10:
                continue
            s = score_set(A)
            if s > best_overall_score:
                best_overall_score = s
                best_overall = A[:]
    
    if best_overall is None:
        best_overall = list(range(100))
    
    return sorted(set(best_overall))[:4000]
