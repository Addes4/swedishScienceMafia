# EVOLVE-BLOCK-START
"""Search over sets defined by gap sequences with scaling."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _set_from_gaps(gaps, a0, scale, reflect):
    """Build set from gap sequence: cumulative sums scaled and offset."""
    pts = [0]
    s = 0
    for g in gaps:
        s += g
        pts.append(s)
    A = [a0 + scale * p for p in pts]
    if reflect:
        A = [-x for x in A]
    return A


def _random_gaps(k, pool):
    return [random.choice(pool) for _ in range(k)]


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    deadline = time.time() + 100  # leave time for the low-dim search

    # pool of gap values to draw from
    pool = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 15, 16, 18, 20, 21, 24, 25, 30]

    # try a range of sizes
    for k in range(5, 40):
        # random restarts for this size
        restarts = max(1, 200 // max(1, k))
        for _ in range(restarts):
            if time.time() > deadline:
                return sorted(set(best))
            gaps = _random_gaps(k, pool)
            a0 = random.randint(-50, 50)
            scale = 1
            reflect = random.random() < 0.5
            cur_gaps = gaps[:]
            cur_a0 = a0
            cur_scale = scale
            cur_reflect = reflect
            cur = _set_from_gaps(cur_gaps, cur_a0, cur_scale, cur_reflect)
            cs = _score(cur)
            # local search
            steps = 400
            for _ in range(steps):
                if time.time() > deadline:
                    return sorted(set(best))
                ng = cur_gaps[:]
                op = random.random()
                if op < 0.6 and len(ng) > 0:
                    i = random.randrange(len(ng))
                    ng[i] = random.choice(pool)
                elif op < 0.8:
                    i = random.randrange(len(ng))
                    delta = random.choice([-2, -1, 1, 2, 3])
                    ng[i] = max(1, ng[i] + delta)
                else:
                    # small permutation/swap
                    if len(ng) > 1:
                        i = random.randrange(len(ng))
                        j = random.randrange(len(ng))
                        ng[i], ng[j] = ng[j], ng[i]
                na0 = cur_a0 + random.choice([-1, 1]) if random.random() < 0.3 else cur_a0
                nscale = cur_scale
                if random.random() < 0.2:
                    nscale = cur_scale + random.choice([-1, 1]) * random.choice([1, 2, 5, 10])
                    if nscale < 1:
                        nscale = 1
                nreflect = cur_reflect
                if random.random() < 0.05:
                    nreflect = not nreflect
                cand = _set_from_gaps(ng, na0, nscale, nreflect)
                sc = _score(cand)
                if sc >= cs:
                    cur_gaps, cur_a0, cur_scale, cur_reflect = ng, na0, nscale, nreflect
                    cs = sc
                    if sc > best_score:
                        best, best_score = cand[:], sc
                        # also keep both reflected versions if they differ
                        refl = [-x for x in cand]
                        rs = _score(refl)
                        if rs > best_score:
                            best, best_score = refl[:], rs
                elif random.random() < 0.05:
                    # occasional random restart of parameters
                    cur_gaps = _random_gaps(len(cur_gaps), pool)
                    cur_a0 = random.randint(-50, 50)
                    cur_scale = max(1, cur_scale + random.choice([-5, -1, 1, 5]))
                    cur_reflect = random.random() < 0.5

    # final cleanup: try local improvements on best
    for _ in range(2000):
        if time.time() > deadline:
            break
        cand = best[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice([-2, -1, 1, 2])
        if len(set(cand)) < 2:
            continue
        s = _score(cand)
        if s > best_score:
            best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
