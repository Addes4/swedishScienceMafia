import math
import time
import random

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def greedy_sidon(n, m):
    """Find a large Sidon subset of [0, m-1] using greedy search.
    Returns list of chosen elements."""
    # Sidon set means all pairwise sums are distinct (or equivalently, differences).
    # We want large size, but limited by sqrt(m) approximately.
    chosen = []
    sums_set = set()
    # Shuffle to get different results on multiple runs
    nums = list(range(m))
    random.shuffle(nums)
    for x in nums:
        ok = True
        for y in chosen:
            s = x + y
            if s in sums_set:
                ok = False
                break
        if ok:
            # Add all sums with previous
            for y in chosen:
                sums_set.add(x + y)
            chosen.append(x)
    return chosen

def solve():
    deadline = time.time() + 110
    random.seed(42)
    
    best_A = []
    best_score = 0.0
    
    # Parameters to try
    # We want total set size <= 4000
    # The construction: A = union_{j=0}^{r-1} M^j * S_j, where S_j are Sidon subsets of [0, M-1]
    # We'll try various M and optimize S_j sizes via DP.
    
    for M in [50, 60, 70, 80, 100, 120, 150]:
        # maximum possible size of Sidon set in [0, M-1] is about sqrt(M) + small constant
        # But we can use sets of different sizes across scales.
        max_sidon_size = int(math.sqrt(M)) + 5
        # Try multiple random Sidon sets of each possible size from 1 to max_sidon_size
        # and record their difference and sum set sizes.
        # To save time, we compute Sidon sets for M once.
        
        # Precompute Sidon sets of various sizes for this M.
        sidon_by_size = {}
        for attempt in range(20):
            if time.time() > deadline:
                break
            sidon = greedy_sidon(M, M)
            sz = len(sidon)
            if sz not in sidon_by_size:
                # compute difference and sum set sizes
                sums_s = set()
                diffs_s = set()
                for x in sidon:
                    for y in sidon:
                        sums_s.add(x + y)
                        diffs_s.add(x - y)
                sidon_by_size[sz] = (sidon, len(diffs_s), len(sums_s))
        
        if time.time() > deadline:
            break
        
        # Now we need to choose a sequence of sizes s_0, s_1, ..., s_{r-1} such that total size = product of something? No.
        # In union construction, each element is sum_{j} c_j * M^j with c_j in S_j.
        # The total number of elements = product of sizes? No, that would be cartesian product.
        # Our A is a union: for each scale j we pick elements from M^j * S_j and add them. 
        # But actually to separate sums nicely we need A = sum of independent choices? 
        # Better: A = { sum_{j=0}^{r-1} c_j M^j : c_j in S_j }.
        # That's product set, not union. That gives |A| = prod |S_j|.
        # The problem statement says "union of Sidon sets at different scales", but typical product construction is more powerful.
        # Let's do product construction: A = { ∑ c_j M^j : c_j ∈ S_j } for j=0..r-1.
        # Then |A| = ∏ |S_j|, which must ≤4000.
        # Difference set sizes multiply approximately: |A - A| ≈ ∏ |D_j| where D_j = S_j - S_j.
        # Sum set sizes also multiply: |A + A| ≈ ∏ |P_j| where P_j = S_j + S_j.
        # To maximize ratio we want high d/s per scale.
        # So we need to partition the product 4000 into factors s_j, each supported by a Sidon set S_j.
        # We can use DP to maximize sum of log(|D_j|) - log(|P_j|) over j for a given total log-size = sum log(s_j).
        
        # For each possible size s (from 1 to max_sidon_size) that we have data for, we have ratio improvement
        # r = log(|D|)/log(|P|). Actually the overall log ratio is sum(log|D_j|) / sum(log|P_j|). 
        # We can't simply add, because it's fraction. But we can maximize numerator - lambda * denominator for some lambda,
        # and binary search on lambda. Simpler: try all combinations of sizes that multiply to <=4000.
        
        # Since max_sidon_size is small, we can try all partitions of 4000 into factors ≤ max_sidon_size.
        # We'll restrict r ≤ 6 scales typically.
        max_r = 6
        sizes_available = sorted(sidon_by_size.keys())
        if not sizes_available:
            continue
        
        # DP: dp[used_size] = best (log_diff_sum, log_sum_sum, list of sizes) 
        # used_size is total elements count.
        # We'll allow up to 4000 elements.
        dp = {1: (0.0, 0.0, [])}  # used_size -> (log_diff, log_sum, sizes_list)
        # Initialize with empty product (size 1? no, size 1 means one scale with set of size 1? Not good.)
        # Actually, we need at least one scale. So start with base case: single scale.
        for s in sizes_available:
            _, d, p = sidon_by_size[s]
            if s <= 4000:
                dp[s] = (math.log(d), math.log(p), [s])
        
        # For each additional scale (iteratively), extend
        for _ in range(max_r - 1):
            new_dp = dict(dp)
            for used, (ld, lp, sizes) in dp.items():
                for s in sizes_available:
                    nxt = used * s
                    if nxt > 4000:
                        continue
                    _, d, p = sidon_by_size[s]
                    nld = ld + math.log(d)
                    nlp = lp + math.log(p)
                    # check if better ratio? Actually we want maximize nld/nlp
                    # But we can't easily compare without computing ratio. 
                    # We'll keep Pareto optimal: if new dominates existing at nxt.
                    if nxt not in new_dp or (nld * new_dp[nxt][1] > new_dp[nxt][0] * nlp):  
                        # dominate if log_diff/log_sum is larger
                        new_dp[nxt] = (nld, nlp, sizes + [s])
            dp = new_dp
        
        # Now evaluate each feasible total size
        for total_size, (ld, lp, sizes_list) in dp.items():
            if total_size < 2:
                continue
            # Build A using product of Sidon sets
            # M must be large enough: M > 2 * max(S_j) + 1, but max(S_j) < M.
            # We'll use M as chosen.
            # Build each S_j from sidon_by_size
            S_list = [sidon_by_size[s][0] for s in sizes_list]
            r = len(S_list)
            # Generate all combinations
            from itertools import product
            A = []
            for coefs in product(*S_list):
                val = sum(c * (M ** i) for i, c in enumerate(coefs))
                A.append(val)
            # Check size (should match total_size)
            if len(A) != total_size:
                continue
            s = score_set(A)
            if s > best_score:
                best_score = s
                best_A = A[:]
    
    # If nothing found (unlikely), fall back to something
    if not best_A:
        best_A = list(range(1, 50))
    
    return sorted(set(best_A))[:4000]

if __name__ == "__main__":
    print(solve())
