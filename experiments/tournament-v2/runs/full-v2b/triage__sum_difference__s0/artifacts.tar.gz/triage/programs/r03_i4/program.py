import math
import time
import random
import heapq
from collections import defaultdict

def score_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    deadline = time.time() + 110
    random.seed(42)
    
    # Parameters
    N_TARGET = 4000
    INITIAL_T = 10**9  # Range for initial random set
    
    # Generate initial random set
    # We want a large difference set and small sum set, so symmetric sets around 0 are good
    # But completely symmetric would have sum set also symmetric maybe worse
    # Start with random set biased toward zero to keep sums small
    S = set()
    while len(S) < N_TARGET:
        # Generate numbers with higher density near zero
        x = random.randint(-INITIAL_T, INITIAL_T)
        S.add(x)
    S = list(S)
    
    # Compute initial difference and sum sets
    # We'll maintain multiset counts for sums and differences
    n = len(S)
    sum_counts = defaultdict(int)
    diff_counts = defaultdict(int)
    
    # Build initial counts O(n^2), acceptable for <4000 => ~16M operations
    for i in range(n):
        xi = S[i]
        for j in range(i, n):  # symmetry
            xj = S[j]
            s = xi + xj
            sum_counts[s] += 1 if i == j else 2  # count both orders
            d1 = xi - xj
            d2 = xj - xi
            diff_counts[d1] += 1
            if d1 != d2:
                diff_counts[d2] += 1
    
    # Fast set sizes
    sum_set_size = len(sum_counts)
    diff_set_size = len(diff_counts)
    
    def compute_score():
        return math.log(diff_set_size) / math.log(sum_set_size) + (1 - 1 / len(S)) / 100
    
    best_score = compute_score()
    best_S = S[:]
    
    # Element data for heap
    # For each element, we need removal impact on sum_set_size and diff_set_size
    # We can precompute contribution of each element to unique sums/diffs
    # Unique sum/diff: when count reduces to 0 only if removed element is sole contributor
    
    # We'll maintain for each element the list of sums and diffs it participates in
    # with their current counts. On removal, we decrement counts; if count->0, set size reduces.
    
    def compute_element_impact(idx):
        x = S[idx]
        sum_impact = 0
        diff_impact = 0
        # Sums with all others (including self)
        for j in range(n):
            if j == idx:
                continue
            s = x + S[j]
            if sum_counts[s] == 1:
                sum_impact += 1
        # self sum
        s_self = x + x
        if sum_counts[s_self] == 1:
            sum_impact += 1
            
        # Diffs
        for j in range(n):
            if j == idx:
                continue
            d1 = x - S[j]
            d2 = S[j] - x
            if diff_counts[d1] == 1:
                diff_impact += 1
            if d1 != d2 and diff_counts[d2] == 1:
                diff_impact += 1
        # self diff (zero)
        zero_diff = 0
        if diff_counts[zero_diff] == 1:
            diff_impact += 1
        return sum_impact, diff_impact
    
    # We'll use a priority queue with (priority, idx, random) to break ties
    # Priority: we want to maximize diff_impact vs sum_impact, i.e., minimize sum_impact while...
    # Actually we want to drop elements that maximally reduce |A+A| (high sum_impact)
    # while preserving |A-A| (low diff_impact). So priority = sum_impact - alpha*diff_impact
    # But since we want to preserve diff set size, we can penalize diff_impact heavily.
    # We'll use: score change if removed approx = -log effect, but simpler heuristic:
    # We want sum_impact large (reduce sum set a lot) and diff_impact small (preserve diff set)
    # So priority = -sum_impact + 10 * diff_impact  (higher priority = smaller value)
    # So we can use min-heap with that value.
    
    alpha = 10.0
    
    def get_priority(idx):
        sum_imp, diff_imp = compute_element_impact(idx)
        # We want: remove elements with high sum_imp and low diff_imp
        # So lower priority value = better to remove
        return -sum_imp + alpha * diff_imp
    
    # Initialize heap with all elements
    heap = []
    for i in range(n):
        prio = get_priority(i)
        heap.append((prio, i, random.random()))
    heapq.heapify(heap)
    
    removed_set = set()
    removed_order = []  # stack for possible reinsertion
    
    # Iterative removal
    iteration = 0
    while time.time() < deadline - 5:
        iteration += 1
        if n <= 10:
            break  # stop removing when too small
        
        # Periodically reinsert some elements to escape local minima
        if iteration % 50 == 0 and removed_order:
            # Reinsert last few removed elements with perturbation
            num_reinsert = min(5, len(removed_order))
            for _ in range(num_reinsert):
                if not removed_order:
                    break
                old_x, idx_orig = removed_order.pop()
                # Perturb slightly
                new_x = old_x + random.randint(-5, 5)
                while new_x in S or new_x in removed_set:
                    new_x = old_x + random.randint(-10, 10)
                # Insert into S
                S.append(new_x)
                new_idx = len(S) - 1
                # Update counts
                # Add sums
                for j in range(len(S)-1):
                    s = new_x + S[j]
                    sum_counts[s] += 2
                sum_counts[new_x+new_x] += 1
                # Add diffs
                for j in range(len(S)-1):
                    d1 = new_x - S[j]
                    d2 = S[j] - new_x
                    diff_counts[d1] += 1
                    if d1 != d2:
                        diff_counts[d2] += 1
                diff_counts[0] += 1
                n += 1
                
                # Recompute set sizes
                sum_set_size = len(sum_counts)
                diff_set_size = len(diff_counts)
                # Add to heap
                prio = get_priority(new_idx)
                heapq.heappush(heap, (prio, new_idx, random.random()))
                # Mark as not removed
                removed_set.discard(old_x)
        
        # Extract next element to remove
        if not heap:
            break
        
        # Get best candidate; may be stale (element already removed or idx wrong)
        while heap:
            prio, idx, r = heap[0]
            if idx < n and S[idx] is not None:
                break
            heapq.heappop(heap)
        else:
            break
        
        heapq.heappop(heap)
        x = S[idx]
        
        # Remove element
        S[idx] = None  # placeholder to keep indices; we'll clean later or just skip
        removed_set.add(x)
        removed_order.append((x, idx))
        
        # Update counts
        # Decrement sums
        for j in range(n):
            if S[j] is None or j == idx:
                continue
            s = x + S[j]
            sum_counts[s] -= 2
            if sum_counts[s] == 0:
                del sum_counts[s]
                sum_set_size -= 1
        s_self = x + x
        sum_counts[s_self] -= 1
        if sum_counts[s_self] == 0:
            del sum_counts[s_self]
            sum_set_size -= 1
        
        # Decrement diffs
        for j in range(n):
            if S[j] is None or j == idx:
                continue
            d1 = x - S[j]
            d2 = S[j] - x
            diff_counts[d1] -= 1
            if diff_counts[d1] == 0:
                del diff_counts[d1]
                diff_set_size -= 1
            if d1 != d2:
                diff_counts[d2] -= 1
                if diff_counts[d2] == 0:
                    del diff_counts[d2]
                    diff_set_size -= 1
        # self diff
        diff_counts[0] -= 1
        if diff_counts[0] == 0:
            del diff_counts[0]
            diff_set_size -= 1
        
        n_effective = sum(1 for v in S if v is not None)
        
        # Update score
        current_score = math.log(diff_set_size) / math.log(sum_set_size) + (1 - 1 / n_effective) / 100
        if current_score > best_score:
            best_score = current_score
            best_S = [v for v in S if v is not None]
        
        # Recompute priorities for all remaining elements? Too expensive. Instead,
        # we just recompute for neighbors? For simplicity, we won't update heap.
        # Heap will have stale priorities, but we rely on periodic reinsertion to correct.
        # However, we can occasionally rebuild heap.
        if (iteration % 20 == 0) and heap:
            # Rebuild
            new_heap = []
            for j in range(n):
                if S[j] is not None:
                    prio = get_priority(j)
                    heapq.heappush(new_heap, (prio, j, random.random()))
            heap = new_heap
        
        n = len(S)
    
    # Return best found
    if best_S:
        return sorted(best_S)
    else:
        return sorted(best_S[:4000])

