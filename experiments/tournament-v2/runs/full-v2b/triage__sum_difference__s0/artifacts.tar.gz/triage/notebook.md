# Research notebook: sum_difference

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.887449.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Represent the set A as a subset of a carefully chosen arithmetic progression (e.g., a Sidon set or Bh[2] subset of [0,N] with controlled doubling) and use theor | 0.63 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.887449 |
| 5 | Construct A as a union of multiple shifted copies of a small “base” set with low additive energy (e.g., a geometric progression like {2^i}) placed at positions  | 0.63 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.878919 |
| 3 | Use a “seed and grow” strategy: start from a small known optimal set (from literature, like Singer difference sets or modular analogs), embed it into a larger s | 0.57 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.808408 |
| 1 | Replace the random local search with a simulated annealing approach that maintains a set A, proposes swaps/adds/drops, and uses an energy function that directly | 0.54 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 2 | Exploit the connection to near-optimal sum-difference sets by constructing A as the image of a small set under a linear map with a large “difference expansion”  | 0.52 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 4 | Model the problem as a binary integer linear program: choose indicator variables for a candidate ground set (like [-L, L]) to maximize a lower bound on log/A-A/ | 0.29 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 1: **0.887449** (spent $0.02)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 5 | Take a small set B with excellent ratio, represent it in base B (like b-ary expansion with a large base), and form A = { \sum_{i} x_i B^i : x_i in B } (a cartes | 0.32 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | improved | 0.888153 |
| 0 | Shift focus to constructing A via concatenating “difference-disjoint” cosets of a fixed interval: pick a modulus M and select residues so that the sumset of res | 0.25 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.875491 |
| 2 | Directly search over sets defined by a small number of arithmetic parameters: A = {a_0, a_0 + d_1, a_0 + d_1 + d_2, …, a_0 + S_k} where d_i are positive gaps dr | 0.20 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 3 | Prerender a large candidate pool by solving small independent subproblems: generate many small sets with high local ratio using basin-hopping on 10–20 elements, | 0.11 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 1 | Use a genetic algorithm where the “chromosomes” represent integer sets of varying sizes, with crossover combining subsets from two parent sets under random inse | 0.07 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 4 | Construct A as a “Singer-like” set modulo a prime power q, then lift it to the integers by keeping elements in [0, q-1] and adding multiples of q for a carefull | 0.05 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.887449 |

Best after round 2: **0.888153** (spent $0.04)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Use a "union of Sidon sets at different scales": construct A = ⋃_{j=0}^{r-1} M^j S_j where each S_j is a Sidon subset of [0, M-1] chosen by greedy search, and M | 0.17 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.886308 |
| 4 | Adopt a "difference-set cooling" scheme: start with a large random set of 4000 integers in [-T,T], then repeatedly drop elements whose removal maximally reduces | 0.16 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 2 | Construct A as the image of a low-degree polynomial over a finite field: A = { f(x) + p·x : x ∈ F_q } where f is a quadratic permutation polynomial and p is a l | 0.05 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.884221 |
| 5 | Translate the problem into an integer lattice point packing problem: view A as a subset of Z^2 via (a, a^2 mod m) for a modulus m ≈ 2^20. Then the sum set lives | 0.01 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887919 |
| 3 | Use a "graph bipartition" approach: build a bipartite graph with vertices = candidate integers, edges weighted by estimated marginal ratio gain when adding both | -0.01 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 1 | Leverage the connection to compressed sensing/RIP matrices: treat elements of A as rows of a partial circulant matrix and formulate the problem as maximizing th | -0.02 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 3: **0.888153** (spent $0.07)

## Round 4

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Enumerate small candidate sets of size up to 12 by exhaustive search over bounded intervals, compute their exact diff/sum ratio, cluster them by “shape” to buil | 0.17 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | improved | 0.888405 |
| 3 | Use a quasirandom construction: let A be the set of integers whose base-p digit sum lies in a fixed subset S of {0,…,p−1} across multiple blocks; differences of | 0.12 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | improved | 0.903208 |
| 0 | Directly construct A as all integers of the form a_i + M * b_j where {a_i} is a small optimal set and {b_j} is a Sidon set in [0, L] with L tuned so that cross  | 0.06 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 5 | Recast the problem as a maximum independent set problem on a graph where vertices represent candidate integers and an edge is drawn if adding both would cause a | 0.01 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887919 |
| 4 | Apply a continuous relaxation where A is a subset of a large interval represented by a density function ρ(x); formulate the problem as maximizing ∫log(ρ∗ρ_−) dx | -0.03 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.859340 |
| 2 | Model A as the zero-set of a trigonometric polynomial with few nonzero frequencies, i.e., A = {x ∈ [−N,N] : ∑ c_k e^{2πi k x/M}=0}, where the frequency support  | -0.03 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 4: **0.903208** (spent $0.09)

## Round 5

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Use a multi-layer RSA-like NTT (Number Theoretic Transform) construction: pick distinct primes p_i, define A as all numbers whose vector of residues modulo p_i  | 0.21 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.866199 |
| 1 | Exploit binary representations with bitwise XOR as a structural constraint: let A consist of integers whose binary expansion has exactly k ones in specified non | 0.15 | favourite | Qwen/Qwen3.5-9B:together (swapped) | not_better | 0.888561 |
| 4 | Use a covering code approach: treat A as a subset of the hypercube {0,1}^d under Gray-code ordering, where elements correspond to binary strings with Hamming we | 0.10 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | improved | 0.915403 |
| 3 | Generate A as the evaluation set of a linear recurrence modulo a large prime: fix a linear recurrence relation x_{n+k} = c_0 x_n + ... + c_{k-1} x_{n+k-1} over  | 0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.832210 |
| 5 | Construct A iteratively by solving a sequence of semidefinite programs (SDP) that optimize a spectral surrogate: represent subsets via their characteristic vect | 0.01 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 2 | Construct A via a "difference set of a group ring": embed A as the support of an element in Z[G] for a finite abelian group G (e.g., G = Z_n) with group ring el | -0.04 | long_shot | Qwen/Qwen3.5-9B:together | improved | 0.935001 |

Promotion: Qwen/Qwen3.5-9B:together found an improvement; deepseek-ai/DeepSeek-V4-Pro:deepinfra refined it -> improved (0.927687).

Best after round 5: **0.935001** (spent $0.12)

