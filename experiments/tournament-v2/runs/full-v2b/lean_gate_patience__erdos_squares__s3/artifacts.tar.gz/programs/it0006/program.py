# EVOLVE-BLOCK-START
"""Guillotine packing with a best-of-all-splits recursive search.

For a rectangle and a count of squares we consider every integer grid
r x c (with r*c <= count).  The grid squares get side min(w/c, h/r).
The leftover squares (count - r*c) are then recursively packed into the
remaining L-shaped region, which we split into a right strip and a top
strip (guillotine cut).  We evaluate the total side sum and pick the best
split.  Results are memoized on a quantised (w, h, count) key.
"""
import math


def solve(n):
    if n <= 0:
        return []

    # cache: key (w_q, h_q, count) -> (total_side, list_of_squares)
    cache = {}

    def pack(x0, y0, w, h, count, depth=0):
        """Return (sum_of_sides, [(cx, cy, s), ...]) packing `count`
        axis-aligned squares into [x0,x0+w]x[y0,y0+h]."""
        if count <= 0 or w <= 1e-12 or h <= 1e-12:
            return 0.0, []
        if count == 1:
            s = min(w, h)
            return s, [(x0 + w / 2.0, y0 + h / 2.0, s)]

        # quantise for memoization only when not too deep to avoid key blowup
        if depth < 4:
            key = (round(w, 6), round(h, 6), count)
            hit = cache.get(key)
            if hit is not None:
                tot, templ = hit
                # templ stores squares relative to (0,0); shift
                return tot, [(cx + x0, cy + y0, s) for (cx, cy, s) in templ]

        best_tot = -1.0
        best_list = None

        mm = math.isqrt(count)
        mm = max(mm, 1)
        # iterate grid shapes; also consider full-count grids
        for r in range(1, mm + 1):
            c = count // r
            if c < r:
                continue
            # prune: grid must fit
            if w / c <= 0 or h / r <= 0:
                continue
            s = min(w / c, h / r)
            used = r * c
            gw = c * s
            gh = r * s
            leftover = count - used

            base = used * s
            if leftover == 0:
                tot = base
                if tot > best_tot:
                    best_tot = tot
                    best_list = [(x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, s)
                                 for i in range(c) for j in range(r)]
                continue

            # split leftovers between right strip and top strip.
            # Try all allocations k to right, leftover-k to top.
            rem_w = w - gw
            rem_h = h - gh
            # Also allow cutting the leftover region entirely one way.
            for k in range(0, leftover + 1):
                t1, l1 = (0.0, [])
                if k > 0 and rem_w > 1e-12:
                    t1, l1 = pack(x0 + gw, y0, rem_w, h, k, depth + 1)
                k2 = leftover - k
                t2, l2 = (0.0, [])
                if k2 > 0 and rem_h > 1e-12:
                    t2, l2 = pack(x0, y0 + gh, w, rem_h, k2, depth + 1)
                tot = base + t1 + t2
                if tot > best_tot:
                    best_tot = tot
                    best_list = ([(x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, s)
                                  for i in range(c) for j in range(r)]
                                 + l1 + l2)

            # also try a corresponding transposed grid (r,c) -> (c,r) handled
            # by loop symmetry when possible; explicit alternative:
        # allow one vertical-orientation variant: swap roles if not symmetric
        if best_list is None:
            # fallback: single big square + shrink remaining into leftover
            s = min(w, h)
            best_tot = s
            best_list = [(x0 + w / 2.0, y0 + h / 2.0, s)]
            if count > 1:
                # put rest as points
                for _ in range(count - 1):
                    best_list.append((x0 + w / 2.0, y0 + h / 2.0, 0.0))

        if depth < 4:
            key = (round(w, 6), round(h, 6), count)
            cache[key] = (best_tot,
                          [(cx - x0, cy - y0, s) for (cx, cy, s) in best_list])
        return best_tot, best_list

    _, squares = pack(0.0, 0.0, 1.0, 1.0, n)

    res = []
    for cx, cy, s in squares:
        if s < 0:
            s = 0.0
        if s > 1:
            s = 1.0
        cx = min(max(cx, s / 2), 1 - s / 2) if s <= 1 else 0.5
        cy = min(max(cy, s / 2), 1 - s / 2) if s <= 1 else 0.5
        res.append((cx, cy, 0.0, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
# EVOLVE-BLOCK-END


