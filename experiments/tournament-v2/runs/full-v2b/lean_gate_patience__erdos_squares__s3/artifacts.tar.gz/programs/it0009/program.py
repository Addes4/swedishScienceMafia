# EVOLVE-BLOCK-START
"""Shelf/row packing with greedy decreasing sizes plus a legalising
coordinate-descent refinement.  Works for every n without a table."""
import math


def _separate_axis_aligned(sqs, iters=40, eps=1e-9):
    """Given list of [cx,cy,a,s] (axis-aligned initially), push apart
    overlapping bounding boxes and clamp to unit square.  Returns total side."""
    n = len(sqs)
    for _ in range(iters):
        moved = False
        for i in range(n):
            xi, yi, ai, si = sqs[i]
            if si <= 0:
                continue
            hi = si / 2.0
            # bounds
            if xi - hi < -eps:
                xi = hi
                moved = True
            if xi + hi > 1 + eps:
                xi = 1 - hi
                moved = True
            if yi - hi < -eps:
                yi = hi
                moved = True
            if yi + hi > 1 + eps:
                yi = 1 - hi
                moved = True
            sqs[i][0] = xi
            sqs[i][1] = yi
        for i in range(n):
            xi, yi, ai, si = sqs[i]
            hi = si / 2.0
            if si <= 0:
                continue
            for j in range(i + 1, n):
                xj, yj, aj, sj = sqs[j]
                hj = sj / 2.0
                if sj <= 0:
                    continue
                dx = xj - xi
                dy = yj - yi
                ox = (hi + hj) - abs(dx)
                oy = (hi + hj) - abs(dy)
                if ox > eps and oy > eps:
                    moved = True
                    if ox < oy:
                        shift = ox / 2.0 + eps
                        if dx >= 0:
                            xj += shift
                            xi -= shift
                        else:
                            xj -= shift
                            xi += shift
                    else:
                        shift = oy / 2.0 + eps
                        if dy >= 0:
                            yj += shift
                            yi -= shift
                        else:
                            yj -= shift
                            yi += shift
                    sqs[i][0] = xi
                    sqs[i][1] = yi
                    sqs[j][0] = xj
                    sqs[j][1] = yj
        if not moved:
            break
    # final clamp
    total = 0.0
    for k in range(n):
        cx, cy, a, s = sqs[k]
        if s <= 0:
            sqs[k][0] = 0.5
            sqs[k][1] = 0.5
            continue
        h = s / 2.0
        cx = min(max(cx, h), 1 - h)
        cy = min(max(cy, h), 1 - h)
        sqs[k][0] = cx
        sqs[k][1] = cy
        total += s
    return total


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # --- build a shelf packing -------------------------------------------
    # choose number of rows k, distribute n squares among rows,
    # each row packed with equal-height squares whose side = 1 / max(count)
    best = None
    for rows in range(1, n + 1):
        # distribute counts across rows as evenly as possible
        base = n // rows
        rest = n % rows
        counts = [base + (1 if i < rest else 0) for i in range(rows)]
        counts = [c for c in counts if c > 0]
        if not counts:
            continue
        # each row's square side limited by 1/count in x, and by
        # available height (1/rows) in y
        hcap = 1.0 / len(counts)
        total = 0.0
        feasible = True
        for c in counts:
            s = min(1.0 / c, hcap)
            if s <= 0:
                feasible = False
                break
            total += s * c
        if feasible and (best is None or total > best[0]):
            best = (total, counts)

    _, counts = best
    sqs = []
    y = 0.0
    rh = 1.0 / len(counts)
    for c in counts:
        s = min(1.0 / c, rh)
        s = s * 0.999  # small gap
        for i in range(c):
            sqs.append([(i + 0.5) / c, y + rh / 2.0, 0.0, s])
        y += rh

    # --- refine: try to grow each square a bit, then legalise -----------
    _separate_axis_aligned(sqs)
    for _ in range(3):
        for k in range(len(sqs)):
            sqs[k][3] = min(1.0, sqs[k][3] * 1.15)
        _separate_axis_aligned(sqs)

    res = []
    for cx, cy, a, s in sqs:
        if s < 0:
            s = 0.0
        if s > 1:
            s = 1.0
        h = s / 2.0
        cx = min(max(cx, h), 1 - h)
        cy = min(max(cy, h), 1 - h)
        res.append((cx, cy, 0.0, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
# EVOLVE-BLOCK-END
