# EVOLVE-BLOCK-START
"""Portfolio construction (recursive guillotine + greedy free-rectangle
placement) + randomized local search with exact polygon-overlap rejection,
maximising the sum of square side lengths."""
import math
import random


def _corner(cx, cy, a, s):
    """Return the 4 corners of a square (centre, angle in turns, side)."""
    th = a * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    ax, ay = c * h, sn * h
    bx, by = -sn * h, c * h
    return ((cx + ax + bx, cy + ay + by),
            (cx + ax - bx, cy + ay - by),
            (cx - ax - bx, cy - ay - by),
            (cx - ax + bx, cy - ay + by))


def _overlap(sq1, sq2):
    """Exact separating axis test between two squares (convex polygons)."""
    p1 = _corner(*sq1)
    p2 = _corner(*sq2)
    for poly, other in ((p1, p2), (p2, p1)):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            nx, ny = ey, -ex
            d1 = [px * nx + py * ny for px, py in poly]
            d2 = [px * nx + py * ny for px, py in other]
            if max(d1) <= min(d2) or max(d2) <= min(d1):
                return False
    return True


def _feasible(squares):
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 0.0:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 0.0:
                continue
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _guillotine(rect, count):
    """Recursively split rectangle into `count` cells, return list of rects."""
    x0, y0, x1, y1 = rect
    if count <= 1:
        return [(x0, y0, x1, y1)]
    w = x1 - x0
    h = y1 - y0
    if w >= h:
        c1 = max(1, min(count - 1, int(round(count * w / (w + h)))))
        frac = c1 / count
        xm = x0 + w * frac
        r1 = _guillotine((x0, y0, xm, y1), c1)
        r2 = _guillotine((xm, y0, x1, y1), count - c1)
    else:
        c1 = max(1, min(count - 1, int(round(count * h / (w + h)))))
        frac = c1 / count
        ym = y0 + h * frac
        r1 = _guillotine((x0, y0, x1, ym), c1)
        r2 = _guillotine((x0, ym, x1, y1), count - c1)
    return r1 + r2


def _construct_guillotine(n):
    if n <= 0:
        return []
    rects = _guillotine((0.0, 0.0, 1.0, 1.0), n)
    squares = []
    for (x0, y0, x1, y1) in rects:
        s = min(x1 - x0, y1 - y0)
        cx = (x0 + x1) * 0.5
        cy = (y0 + y1) * 0.5
        squares.append([cx, cy, 0.0, s])
    return squares


def _split_free_rects(free, sq, slack=0.0):
    """Given a placed square [cx,cy,a,s], split every free rect it touches,
    keeping the pieces. Returns the new free-rect list."""
    half = sq[3] * 0.5
    x0 = sq[0] - half
    x1 = sq[0] + half
    y0 = sq[1] - half
    y1 = sq[1] + half
    new = []
    for (a0, b0, a1, b1) in free:
        # no overlap -> keep
        if x1 <= a0 or x0 >= a1 or y1 <= b0 or y0 >= b1:
            new.append((a0, b0, a1, b1))
            continue
        # left strip
        if x0 > a0:
            new.append((a0, b0, min(x0, a1), b1))
        # right strip
        if x1 < a1:
            new.append((max(x1, a0), b0, a1, b1))
        # bottom strip
        if y0 > b0:
            new.append((max(a0, x0), b0, min(a1, x1), min(y0, b1)))
        # top strip
        if y1 < b1:
            new.append((max(a0, x0), max(y1, b0), min(a1, x1), b1))
    return new


def _best_rect(free):
    """Pick the free rect with the largest min(width,height) tie-broken by area."""
    best = None
    bkey = None
    for r in free:
        w = r[2] - r[0]
        h = r[3] - r[1]
        if w <= 1e-12 or h <= 1e-12:
            continue
        key = (min(w, h), w * h)
        if bkey is None or key > bkey:
            bkey = key
            best = r
    return best


def _construct_greedy(n):
    """Greedy: repeatedly place largest axis-aligned square in biggest free rect."""
    if n <= 0:
        return []
    free = [(0.0, 0.0, 1.0, 1.0)]
    squares = []
    for _ in range(n):
        r = _best_rect(free)
        if r is None:
            squares.append([0.5, 0.5, 0.0, 0.0])
            continue
        w = r[2] - r[0]
        h = r[3] - r[1]
        s = min(w, h)
        cx = r[0] + w * 0.5
        cy = r[1] + h * 0.5
        sq = [cx, cy, 0.0, s]
        squares.append(sq)
        free = _split_free_rects(free, sq)
    return squares


def _score(squares):
    return sum(q[3] for q in squares)


def _clamp_square(q):
    cx, cy, a, s = q
    a = a % 1.0
    if s <= 0.0:
        return [min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a, 0.0]
    th = a * 2.0 * math.pi
    c, sn = abs(math.cos(th)), abs(math.sin(th))
    half = s * 0.5 * (c + sn)
    cx = min(1.0 - half, max(half, cx))
    cy = min(1.0 - half, max(half, cy))
    if half * 2 > 1.0 + 1e-12:
        s = 1.0 / (c + sn)
        half = s * 0.5 * (c + sn)
        cx = min(1.0 - half, max(half, cx))
        cy = min(1.0 - half, max(half, cy))
    return [cx, cy, a, s]


def _local_search(squares, n, t_limit):
    import time
    best = [list(q) for q in squares]
    best_score = _score(best)
    t_start = time.time()
    it = 0
    while True:
        if it % 100 == 0 and time.time() - t_start > t_limit:
            break
        it += 1
        cand = [list(q) for q in best]
        i = random.randrange(n)
        mode = random.random()
        cx, cy, a, s = cand[i]
        if mode < 0.5:
            delta = s * (0.02 + 0.3 * random.random()) + 1e-4
            cand[i] = _clamp_square([cx, cy, a, s + delta])
        elif mode < 0.7:
            delta = s * (0.02 + 0.3 * random.random())
            cand[i] = _clamp_square([cx, cy, a, s - delta])
        elif mode < 0.9:
            step = 0.005 + 0.05 * random.random()
            cand[i] = _clamp_square([cx + (random.random() - 0.5) * step,
                                     cy + (random.random() - 0.5) * step, a, s])
        else:
            da = (random.random() - 0.5) * 0.05
            cand[i] = _clamp_square([cx, cy, a + da, s])

        if _feasible(cand):
            sc = _score(cand)
            if sc >= best_score - 1e-12:
                best = cand
                best_score = sc
    return best, best_score


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)

    seeds = []
    seeds.append([_clamp_square(q) for q in _construct_guillotine(n)])
    seeds.append([_clamp_square(q) for q in _construct_greedy(n)])

    best = None
    best_score = -1.0
    # quick evaluation of seeds, then local search spends most time on best
    for sd in seeds:
        sc = _score(sd)
        if sc > best_score:
            best_score = sc
            best = [list(q) for q in sd]

    # polish the best seed
    polished, ps = _local_search(best, n, 7.0)
    if ps > best_score:
        best, best_score = polished, ps

    return [(q[0], q[1], q[2] % 1.0, q[3]) for q in best]
# EVOLVE-BLOCK-END
