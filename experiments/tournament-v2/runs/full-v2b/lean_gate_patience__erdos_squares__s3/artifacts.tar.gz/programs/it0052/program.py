# EVOLVE-BLOCK-START
"""Guillotine constructor + randomized local search for squares in a unit square."""
import math
import random


def _sat_disjoint(c1, c2):
    """Exact separating-axis test for two rotated squares.
    A square is (cx, cy, angle, s). angle is a fraction of a full turn."""
    ax1, ay1, a1, s1 = c1
    ax2, ay2, a2, s2 = c2
    if s1 <= 0.0 or s2 <= 0.0:
        return True
    t1 = a1 * 2.0 * math.pi
    t2 = a2 * 2.0 * math.pi
    u1 = (math.cos(t1), math.sin(t1))
    v1 = (-u1[1], u1[0])
    u2 = (math.cos(t2), math.sin(t2))
    v2 = (-u2[1], u2[0])
    h1 = s1 * 0.5
    h2 = s2 * 0.5
    r1 = (h1 * abs(u1[0]) + h1 * abs(v1[0]), h1 * abs(u1[1]) + h1 * abs(v1[1]))
    r2 = (h2 * abs(u2[0]) + h2 * abs(v2[0]), h2 * abs(u2[1]) + h2 * abs(v2[1]))
    dx = ax2 - ax1
    dy = ay2 - ay1
    # test axes of square 1
    for ux, uy in (u1, v1, u2, v2):
        dist = abs(dx * ux + dy * uy)
        # projected half-extent of each square onto axis
        e1 = h1 * abs(ux * u1[0] + uy * u1[1]) + h1 * abs(ux * v1[0] + uy * v1[1])
        e2 = h2 * abs(ux * u2[0] + uy * u2[1]) + h2 * abs(ux * v2[0] + uy * v2[1])
        if dist >= e1 + e2 - 1e-12:
            return True
    return False


def _all_disjoint(sqs):
    n = len(sqs)
    for i in range(n):
        for j in range(i + 1, n):
            if not _sat_disjoint(sqs[i], sqs[j]):
                return False
    return True


def _in_bounds(c):
    cx, cy, a, s = c
    if s <= 0.0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    t = a * 2.0 * math.pi
    ux, uy = math.cos(t), math.sin(t)
    vx, vy = -uy, ux
    h = s * 0.5
    ex = h * (abs(ux) + abs(vx))
    ey = h * (abs(uy) + abs(vy))
    return (ex <= cx <= 1.0 - ex) and (ey <= cy <= 1.0 - ey)


def _guillotine(rects, n, rng):
    """Return list of (cx, cy, 0.0, side) axis-aligned squares using guillotine splits."""
    out = []
    # each rect: (x0, y0, w, h)
    stack = [(0.0, 0.0, 1.0, 1.0)]
    while len(out) < n and stack:
        # pick the largest-area rect
        best = 0
        bestA = -1.0
        for i, r in enumerate(stack):
            A = r[2] * r[3]
            if A > bestA:
                bestA = A
                best = i
        x0, y0, w, h = stack.pop(best)
        m = n - len(out)
        rem = len(stack)
        # how many squares should this rect hold? proportional to area share
        total_area = w * h + sum(r[2] * r[3] for r in stack)
        share = max(1, int(round(m * (w * h) / total_area))) if total_area > 0 else 1
        share = min(share, m - rem) if m - rem > 0 else 1
        if share <= 1:
            # place one square filling the rect's shorter side length
            s = min(w, h)
            # small random shrink to leave room for siblings
            s *= 1.0
            s = min(s, w, h)
            cx = x0 + w * 0.5
            cy = y0 + h * 0.5
            out.append((cx, cy, 0.0, s))
            # leftover splits into up to 2 rects
            if w > h + 1e-9:
                # horizontal leftover strips
                left_w = w - s
                if left_w > 1e-9:
                    stack.append((x0 + (w - left_w) * 0.5 + s * 0.5 if False else x0 + s + left_w * 0.5, y0, left_w, h))
                # above/below left portion
                if h > s + 1e-9:
                    stack.append((x0 + s * 0.5, y0 + s + (h - s) * 0.5, s, h - s))
            elif h > w + 1e-9:
                bot_h = h - s
                if bot_h > 1e-9:
                    stack.append((x0, y0 + s + bot_h * 0.5, w, bot_h))
                if w > s + 1e-9:
                    stack.append((x0 + s + (w - s) * 0.5, y0 + s * 0.5, w - s, s))
            else:
                # w ~ h, allow a random split for variety
                if rng.random() < 0.5 and w > 1e-9:
                    stack.append((x0 + s * 0.5, y0 + s + (h - s) * 0.5, s, h - s))
                else:
                    stack.append((x0 + s + (w - s) * 0.5, y0 + s * 0.5, w - s, s))
        else:
            # split rect into two, assign shares
            area = w * h
            r = rng.random()
            if r < 0.5:
                # vertical split
                frac = share / m
                frac = min(0.95, max(0.05, frac))
                w1 = w * frac
                stack.append((x0, y0, w1, h))
                stack.append((x0 + w1, y0, w - w1, h))
            else:
                frac = share / m
                frac = min(0.95, max(0.05, frac))
                h1 = h * frac
                stack.append((x0, y0, w, h1))
                stack.append((x0, y0 + h1, w, h - h1))
    # fill remaining with zero-size
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _score(sqs):
    return sum(c[3] for c in sqs)


def solve(n):
    rng = random.Random(12345 + n)
    if n <= 0:
        return []
    # constructive start
    best = _guillotine([], n, rng)
    # normalize: clamp, fix any bounds violations
    fixed = []
    for cx, cy, a, s in best:
        pass
    best = [(c[0], c[1], c[2], c[3]) for c in best]
    best_score = _score(best)

    # local search: try growing squares and small perturbations
    tlimit_iter = 4000
    if n <= 2:
        tlimit_iter = 20000

    cur = list(best)
    cur_score = best_score
    for it in range(tlimit_iter):
        idx = rng.randrange(n)
        cx, cy, a, s = cur[idx]
        op = rng.random()
        if op < 0.6:
            # growth
            factor = 1.0 + rng.random() * 0.08
            ns = s * factor if s > 0 else rng.random() * 0.05
            ns = min(ns, 1.0)
            nc = (cx, cy, a, ns)
        elif op < 0.8:
            # translate
            dx = (rng.random() - 0.5) * 0.08
            dy = (rng.random() - 0.5) * 0.08
            nc = (cx + dx, cy + dy, a, s)
        else:
            # rotate
            na = a + (rng.random() - 0.5) * 0.1
            nc = (cx, cy, na, s)
        if not _in_bounds(nc):
            # try to fix by shrinking or recentering
            ok = False
            for _ in range(4):
                ncx = min(max(nc[0], 0.0), 1.0)
                ncy = min(max(nc[1], 0.0), 1.0)
                cand = (ncx, ncy, nc[2], nc[3])
                if _in_bounds(cand):
                    nc = cand
                    ok = True
                    break
                # shrink
                nc = (nc[0], nc[1], nc[2], nc[3] * 0.97)
            if not ok:
                continue
        # check overlaps with all others
        trial = list(cur)
        trial[idx] = nc
        ok = True
        for j in range(n):
            if j == idx:
                continue
            if not _sat_disjoint(nc, trial[j]):
                ok = False
                break
        if not ok:
            # try pullback toward previous center
            for _ in range(3):
                nc = (nc[0] * 0.5 + cx * 0.5, nc[1] * 0.5 + cy * 0.5, nc[2], nc[3] * 0.98)
                if not _in_bounds(nc):
                    continue
                trial[idx] = nc
                good = True
                for j in range(n):
                    if j == idx:
                        continue
                    if not _sat_disjoint(nc, trial[j]):
                        good = False
                        break
                if good:
                    ok = True
                    break
        if not ok:
            continue
        ns_score = cur_score - s + nc[3]
        if ns_score >= cur_score - 1e-12:
            cur = trial
            cur_score = ns_score
            if cur_score > best_score + 1e-12:
                best = list(cur)
                best_score = cur_score
        else:
            # occasional accept worse to escape local minima
            if rng.random() < 0.02:
                cur = trial
                cur_score = ns_score
    return best[:n]


if __name__ == "__main__":
    for nn in [1, 2, 4, 9, 16]:
        r = solve(nn)
        print(nn, sum(c[3] for c in r), _all_disjoint(r), all(_in_bounds(c) for c in r))
# EVOLVE-BLOCK-END
