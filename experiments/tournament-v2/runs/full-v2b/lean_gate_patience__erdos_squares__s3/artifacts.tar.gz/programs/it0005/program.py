# EVOLVE-BLOCK-START
"""Guillotine packing: split the unit square recursively, using optimal
integer grids for perfect squares and carving a leftover rectangle for the rest.
Then grow squares greedily with push-apart relaxation to squeeze more area."""
import math


def solve(n):
    if n <= 0:
        return []

    squares = []

    def pack_rect(x0, y0, w, h, count):
        if count <= 0 or w <= 0 or h <= 0:
            return
        m = math.isqrt(count)
        m = max(m, 1)
        best = None
        for r in range(1, m + 1):
            c = count // r
            if c < r:
                continue
            s = min(w / c, h / r)
            if s <= 0:
                continue
            used = r * c
            score = (s, used)
            if best is None or score > best[0]:
                best = (score, r, c, s, used)
        if best is None:
            return
        _, r, c, s, used = best
        for i in range(c):
            for j in range(r):
                squares.append([x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, 0.0, s])
        leftover = count - used
        if leftover > 0:
            gw = c * s
            gh = r * s
            rem_w = w - gw
            rem_h = h - gh
            if rem_w >= rem_h:
                if rem_w > 1e-12:
                    pack_rect(x0 + gw, y0, rem_w, h, leftover)
            else:
                if rem_h > 1e-12:
                    pack_rect(x0, y0 + gh, w, rem_h, leftover)

    pack_rect(0.0, 0.0, 1.0, 1.0, n)

    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    squares = squares[:n]

    # ---- greedy grow + push-apart relaxation (axis-aligned, angle ignored) ----
    # Work with half-extents relative to centres; keep everything axis aligned.
    cx = [s[0] for s in squares]
    cy = [s[1] for s in squares]
    hs = [s[3] / 2.0 for s in squares]  # half-side

    def overlaps(i, j, margin=0.0):
        dx = abs(cx[i] - cx[j])
        dy = abs(cy[i] - cy[j])
        return dx < hs[i] + hs[j] + margin and dy < hs[i] + hs[j] + margin

    EPS = 1e-9

    # Try growing squares in order of current size (largest first), pushing
    # neighbours apart horizontally/vertically when a conflict occurs.
    order = sorted(range(n), key=lambda i: -hs[i])
    for it in range(6):
        improved = False
        for i in order:
            target = hs[i]
            # attempt to enlarge i
            grow = 0.01
            newh = min(target + grow, 0.5)
            # find max feasible half-side without overlapping others
            maxh = 0.5
            for j in range(n):
                if j == i:
                    continue
                dx = abs(cx[i] - cx[j])
                dy = abs(cy[i] - cy[j])
                # if already separated in x or y, no constraint
                if dx >= hs[i] + hs[j] or dy >= hs[i] + hs[j]:
                    continue
                # overlapping band -> the binding constraint
                # can we just grow in both? no; limit by the nearer axis gap
                # treat as: need dx >= h_i + h_j OR dy >= h_i + h_j
                hx = dx - hs[j]
                hy = dy - hs[j]
                lim = max(hx, hy)  # can satisfy by separating along that axis
                if lim < maxh:
                    maxh = lim
            # also bounds
            maxh = min(maxh, cx[i], 1 - cx[i], cy[i], 1 - cy[i])
            if maxh > hs[i] + 1e-12:
                hs[i] = maxh
                improved = True
        if not improved:
            break

    # Final push: resolve any residual overlaps by shifting centres slightly
    for _ in range(20):
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                if not overlaps(i, j, margin=-EPS):
                    continue
                dx = cx[i] - cx[j]
                dy = cy[i] - cy[j]
                need_x = hs[i] + hs[j] - abs(dx)
                need_y = hs[i] + hs[j] - abs(dy)
                if need_x <= 0 or need_y <= 0:
                    continue
                # push along the axis with smaller correction need
                if need_x <= need_y:
                    shift = need_x / 2 + 1e-9
                    sgn = 1 if dx >= 0 else -1
                    if dx == 0:
                        sgn = 1
                    cx[i] += sgn * shift
                    cx[j] -= sgn * shift
                else:
                    shift = need_y / 2 + 1e-9
                    sgn = 1 if dy >= 0 else -1
                    if dy == 0:
                        sgn = 1
                    cy[i] += sgn * shift
                    cy[j] -= sgn * shift
                moved = True
        # clamp back into bounds
        for i in range(n):
            if cx[i] - hs[i] < 0:
                cx[i] = hs[i]
            if cx[i] + hs[i] > 1:
                cx[i] = 1 - hs[i]
            if cy[i] - hs[i] < 0:
                cy[i] = hs[i]
            if cy[i] + hs[i] > 1:
                cy[i] = 1 - hs[i]
        if not moved:
            break

    res = []
    for i in range(n):
        h = hs[i] if hs[i] > 0 else 0.0
        h = min(h, 0.5)
        x = min(max(cx[i], h), 1 - h)
        y = min(max(cy[i], h), 1 - h)
        res.append((x, y, 0.0, 2.0 * h))
    return res
# EVOLVE-BLOCK-END
