# EVOLVE-BLOCK-START
"""Shelf packing (rows of equal squares) with a scipy refinement of all squares."""
import math
import numpy as np
from scipy.optimize import minimize


def _sat_overlap(ax, ay, aa, s1, bx, by, ba, s2):
    """Return penetration depth (>0 if overlapping) for two squares."""
    best = 0.0
    for k in range(4):
        ang = (aa + 0.25 * k) * 2 * math.pi
        ux, uy = math.cos(ang), math.sin(ang)
        # projection radii
        r1 = s1 * 0.5 * (abs(ux) + abs(uy))
        ang2 = (ba + 0.25 * k) * 2 * math.pi
        vx, vy = math.cos(ang2), math.sin(ang2)
        r2 = s2 * 0.5 * (abs(vx) + abs(vy))
        d = abs((bx - ax) * ux + (by - ay) * uy)
        pen = r1 + r2 - d
        if pen > best:
            best = pen
    return best


def _penalty(squares):
    p = 0.0
    n = len(squares)
    for x, y, a, s in squares:
        if s > 1.0:
            p += 100.0 * (s - 1.0) ** 2
        # bounding box inside unit square (axis-aligned bbox of rotated square)
        r = s * 0.5 * (abs(math.cos(a * 2 * math.pi)) + abs(math.sin(a * 2 * math.pi)))
        if x - r < 0:
            p += 100.0 * (r - x) ** 2
        if x + r > 1:
            p += 100.0 * (x + r - 1) ** 2
        if y - r < 0:
            p += 100.0 * (r - y) ** 2
        if y + r > 1:
            p += 100.0 * (y + r - 1) ** 2
    for i in range(n):
        xi, yi, ai, si = squares[i]
        for j in range(i + 1, n):
            xj, yj, aj, sj = squares[j]
            pen = _sat_overlap(xi, yi, ai, si, xj, yj, aj, sj)
            if pen > 0:
                p += 200.0 * pen * pen
    return p


def _shelf_best(n):
    """Try shelf packings: m rows, row i has c_i squares of side min(1/c_i, needed)."""
    best = None
    best_val = -1.0
    # distribute n into m rows
    for m in range(1, n + 1):
        # base counts
        base = n // m
        rem = n % m
        counts = [base + 1] * rem + [base] * (m - rem)
        # side for each row = 1/count ; total height = sum 1/count must be <= 1
        total_h = sum(1.0 / c for c in counts)
        if total_h > 1.0 + 1e-12:
            continue
        val = float(n) / base if base > 0 else 0.0
        # each square side = 1/count in its row (rows may differ)
        val = sum(c * (1.0 / c) for c in counts)
        # val = m actually
        val = float(m)
        if val > best_val:
            best_val = val
            best = counts
    if best is None:
        best = [n]
    squares = []
    y = 0.0
    for c in best:
        s = 1.0 / c
        h = s
        for i in range(c):
            squares.append([(i + 0.5) * s, y + h * 0.5, 0.0, s])
        y += h
    return squares, best_val


def solve(n):
    if n <= 0:
        return []
    # baseline grid
    k = math.isqrt(n)
    gs = 1.0 / k
    grid = [[(i + 0.5) * gs, (j + 0.5) * gs, 0.0, gs]
            for i in range(k) for j in range(k)]
    while len(grid) < n:
        grid.append([0.5, 0.5, 0.0, 0.0])

    shelf, _ = _shelf_best(n)

    def val_of(sq):
        return -_penalty(sq) + sum(s for *_, s in sq)

    base = grid if len(grid) == n else shelf
    x0 = np.array(base, dtype=float).flatten()

    def obj(z):
        sq = z.reshape(n, 4)
        return -sum(sq[:, 3]) + _penalty(sq)

    try:
        res = minimize(obj, x0, method="Powell",
                       options={"maxiter": 4000, "xtol": 1e-4, "ftol": 1e-6})
        z = res.x
    except Exception:
        z = x0
    sq = z.reshape(n, 4)
    if _penalty(sq) > 1e-6:
        # fall back to grid / shelf, dropping overlaps
        sq = np.array(base, dtype=float)
    out = []
    for x, y, a, s in sq:
        s = max(0.0, min(1.0, s))
        out.append((float(min(1.0, max(0.0, x))),
                    float(min(1.0, max(0.0, y))),
                    float(a % 1.0), float(s)))
    return out
# EVOLVE-BLOCK-END
