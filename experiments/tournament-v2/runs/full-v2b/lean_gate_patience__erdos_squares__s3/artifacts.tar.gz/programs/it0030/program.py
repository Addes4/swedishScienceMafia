# EVOLVE-BLOCK-START
"""Recursive guillotine construction + randomized local search with exact
polygon-overlap rejection, maximising the sum of square side lengths."""
import math
import random


def _corner(cx, cy, a, s):
    """Return the 4 corners of a square (centre, angle in turns, side)."""
    th = a * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    # axes: (c, sn) and (-sn, c)
    ax, ay = c * h, sn * h
    bx, by = -sn * h, c * h
    return ((cx + ax + bx, cy + ay + by),
            (cx + ax - bx, cy + ay - by),
            (cx - ax - bx, cy - ay - by),
            (cx - ax + bx, cy - ay + by))


def _overlap(sq1, sq2):
    """Exact separating axis test between two squares (convex polygons)."""
    p1 = _corner(*sq1)
    p2 = _corner(*sq2)
    for poly, other in ((p1, p2), (p2, p1)):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # outward normal
            nx, ny = ey, -ex
            # projection of poly onto normal
            d1 = [px * nx + py * ny for px, py in poly]
            d2 = [px * nx + py * ny for px, py in other]
            if max(d1) <= min(d2) or max(d2) <= min(d1):
                return False
    return True


def _feasible(squares):
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 0.0:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 0.0:
                continue
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _inside(sq):
    for x, y in _corner(*sq):
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _guillotine(rect, count):
    """Recursively split rectangle into `count` cells, return list of rects."""
    x0, y0, x1, y1 = rect
    if count <= 1:
        return [(x0, y0, x1, y1)]
    w = x1 - x0
    h = y1 - y0
    # split proportional to count
    if w >= h:
        # vertical split
        c1 = max(1, min(count - 1, int(round(count * w / (w + h)))) if count > 1 else 1)
        c1 = max(1, min(count - 1, c1))
        frac = c1 / count
        xm = x0 + w * frac
        r1 = _guillotine((x0, y0, xm, y1), c1)
        r2 = _guillotine((xm, y0, x1, y1), count - c1)
    else:
        c1 = max(1, min(count - 1, int(round(count * h / (w + h)))) if count > 1 else 1)
        c1 = max(1, min(count - 1, c1))
        frac = c1 / count
        ym = y0 + h * frac
        r1 = _guillotine((x0, y0, x1, ym), c1)
        r2 = _guillotine((x0, ym, x1, y1), count - c1)
    return r1 + r2


def _construct(n):
    if n <= 0:
        return []
    rects = _guillotine((0.0, 0.0, 1.0, 1.0), n)
    squares = []
    for (x0, y0, x1, y1) in rects:
        s = min(x1 - x0, y1 - y0)
        cx = (x0 + x1) * 0.5
        cy = (y0 + y1) * 0.5
        squares.append([cx, cy, 0.0, s])
    return squares


def _score(squares):
    return sum(q[3] for q in squares)


def _clamp_square(q):
    cx, cy, a, s = q
    a = a % 1.0
    if s <= 0.0:
        # keep centre in [0,1]
        return [min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a, 0.0]
    # fit inside unit square: bounding radius = s*|cos|+s*|sin| half-extent
    th = a * 2.0 * math.pi
    c, sn = abs(math.cos(th)), abs(math.sin(th))
    half = s * 0.5 * (c + sn)
    cx = min(1.0 - half, max(half, cx))
    cy = min(1.0 - half, max(half, cy))
    if half * 2 > 1.0 + 1e-12:
        s = 1.0 / (c + sn)
        half = s * 0.5 * (c + sn)
        cx = min(1.0 - half, max(half, cx))
        cy = min(1.0 - half, max(half, cy))
    return [cx, cy, a, s]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)
    squares = _construct(n)
    squares = [_clamp_square(q) for q in squares]

    best = [list(q) for q in squares]
    best_score = _score(best)

    try:
        import time
        t_end = time.time() + 8.0
    except Exception:
        t_end = None

    import time
    t_start = time.time()
    t_limit = 8.0

    it = 0
    while True:
        if it % 200 == 0 and time.time() - t_start > t_limit:
            break
        it += 1
        cand = [list(q) for q in best]
        # pick a random square
        i = random.randrange(n)
        mode = random.random()
        cx, cy, a, s = cand[i]
        if mode < 0.5:
            # grow
            delta = s * (0.02 + 0.3 * random.random()) + 1e-4
            nt = _clamp_square([cx, cy, a, s + delta])
            cand[i] = nt
        elif mode < 0.7:
            # shrink (mostly to escape)
            delta = s * (0.02 + 0.3 * random.random())
            nt = _clamp_square([cx, cy, a, s - delta])
            cand[i] = nt
        elif mode < 0.9:
            # translate
            step = 0.005 + 0.05 * random.random()
            nt = _clamp_square([cx + (random.random() - 0.5) * step,
                                cy + (random.random() - 0.5) * step, a, s])
            cand[i] = nt
        else:
            # rotate
            da = (random.random() - 0.5) * 0.05
            nt = _clamp_square([cx, cy, a + da, s])
            cand[i] = nt

        if _feasible(cand):
            sc = _score(cand)
            if sc >= best_score - 1e-12:
                best = cand
                best_score = sc

    return [(q[0], q[1], q[2] % 1.0, q[3]) for q in best]
# EVOLVE-BLOCK-END
