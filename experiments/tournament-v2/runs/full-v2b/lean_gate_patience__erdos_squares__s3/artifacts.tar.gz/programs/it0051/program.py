# EVOLVE-BLOCK-START
"""Structured multi-start construction plus randomized local search."""
import math
import random


def _corners(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap(c1, c2):
    for pts in (c1, c2):
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            nx, ny = -(y2 - y1), (x2 - x1)
            min1 = max1 = None
            for (px, py) in c1:
                d = px * nx + py * ny
                if min1 is None or d < min1:
                    min1 = d
                if max1 is None or d > max1:
                    max1 = d
            min2 = max2 = None
            for (px, py) in c2:
                d = px * nx + py * ny
                if min2 is None or d < min2:
                    min2 = d
                if max2 is None or d > max2:
                    max2 = d
            if max1 <= min2 or max2 <= min1:
                return False
    return True


def _in_bounds(c):
    for x, y in c:
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _guillotine(n, rng):
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        idx = 0
        best = -1.0
        for i, (x, y, w, h) in enumerate(cells):
            v = min(w, h) * max(w, h)
            if v > best:
                best = v
                idx = i
        x, y, w, h = cells.pop(idx)
        frac = rng.uniform(0.35, 0.65)
        if w >= h:
            w1 = w * frac
            cells.append((x, y, w1, h))
            cells.append((x + w1, y, w - w1, h))
        else:
            h1 = h * frac
            cells.append((x, y, w, h1))
            cells.append((x, y + h1, w, h - h1))
    squares = []
    for (x, y, w, h) in cells:
        s = min(w, h)
        squares.append([x + w * 0.5, y + h * 0.5, 0.0, s])
    return squares


def _grid_layout(n, rows, cols):
    """Axis-aligned grid cells for n squares (some may be empty)."""
    if rows * cols < n:
        return None
    cells = []
    for r in range(rows):
        for c in range(cols):
            w = 1.0 / cols
            h = 1.0 / rows
            x = c * w
            y = r * h
            cells.append((x, y, w, h))
    # trim to n by merging extras into last kept cell
    cells = cells[:n]
    sq = []
    for (x, y, w, h) in cells:
        s = min(w, h)
        sq.append([x + w * 0.5, y + h * 0.5, 0.0, s])
    return sq


def _grid_enlarge(n, rows, cols):
    """Grid with the leftover strip given to the first square."""
    if rows * cols < n:
        return None
    w = 1.0 / cols
    h = 1.0 / rows
    cells = []
    for r in range(n):
        rr = r // cols
        cc = r % cols
        cells.append([cc * w, rr * h, w, h])
    # remaining cells folded into last
    used_rows = (n + cols - 1) // cols
    if used_rows < rows:
        cells[-1][3] = h + (rows - used_rows) * h
    sq = []
    for (x, y, ww, hh) in cells:
        s = min(ww, hh)
        sq.append([x + ww * 0.5, y + hh * 0.5, 0.0, s])
    return sq


def _any_overlap(squares, cand_idx, cand):
    c1 = _corners(*cand)
    if not _in_bounds(c1):
        return True
    for i, sq in enumerate(squares):
        if i == cand_idx:
            continue
        if _overlap(c1, _corners(*sq)):
            return True
    return False


def improve_local(squares, rng, iters=4000):
    n = len(squares)
    if n == 0:
        return

    for _ in range(iters):
        i = rng.randrange(n)
        cx, cy, ang, s = squares[i]
        move = rng.random()

        if move < 0.5:
            factor = 1.0 + rng.uniform(0.01, 0.25)
            ns = s * factor
            best_cand = None
            for _t in range(12):
                if _t == 0:
                    ncx, ncy = cx, cy
                else:
                    ncx = cx + rng.uniform(-0.07, 0.07)
                    ncy = cy + rng.uniform(-0.07, 0.07)
                    ncx = min(max(ncx, 0.0), 1.0)
                    ncy = min(max(ncy, 0.0), 1.0)
                if ns > 1.0:
                    break
                cand = (ncx, ncy, ang, ns)
                if not _any_overlap(squares, i, cand):
                    if best_cand is None or ns > best_cand[3]:
                        best_cand = cand
                    break
            if best_cand is not None and best_cand[3] > s:
                squares[i] = list(best_cand)
        elif move < 0.78:
            ncx = cx + rng.uniform(-0.08, 0.08)
            ncy = cy + rng.uniform(-0.08, 0.08)
            ncx = min(max(ncx, 0.0), 1.0)
            ncy = min(max(ncy, 0.0), 1.0)
            ns = s * (1.0 + rng.uniform(-0.03, 0.12))
            if ns > 1.0:
                ns = 1.0
            cand = (ncx, ncy, ang, ns)
            if not _any_overlap(squares, i, cand):
                squares[i] = list(cand)
        else:
            nang = (ang + rng.uniform(-0.06, 0.06)) % 1.0
            ns = s * (1.0 + rng.uniform(-0.02, 0.06))
            if ns > 1.0:
                ns = 1.0
            cand = (cx, cy, nang, ns)
            if not _any_overlap(squares, i, cand):
                squares[i] = list(cand)


def _seeds(n, rng):
    """Generate many diverse starting configurations."""
    seeds = []
    # grid variants
    for rows in range(1, n + 1):
        for cols in range(1, n + 1):
            g = _grid_layout(n, rows, cols)
            if g is not None and len(g) == n:
                seeds.append(g)
    # grid with enlarged cell
    import math as _m
    base = int(_m.ceil(_m.sqrt(n)))
    for rows in (base - 1, base, base + 1):
        for cols in (base - 1, base, base + 1):
            if rows < 1 or cols < 1:
                continue
            g = _grid_enlarge(n, rows, cols)
            if g is not None and len(g) == n:
                seeds.append(g)
    # guillotine
    for _ in range(4):
        seeds.append(_guillotine(n, rng))
    return seeds


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345)

    best = None
    best_sum = -1.0

    seeds = _seeds(n, rng)
    for si, seed in enumerate(seeds):
        sq = [list(s) for s in seed]
        if len(sq) != n:
            while len(sq) < n:
                sq.append([0.5, 0.5, 0.0, 0.0])
            sq = sq[:n]
        # a couple of local-search restarts per seed
        for rep in range(2):
            work = [list(s) for s in sq]
            improve_local(work, rng, iters=2500)
            tot = sum(s[3] for s in work)
            if tot > best_sum:
                best_sum = tot
                best = [tuple(s) for s in work]
        # also try from current best seed with more iterations occasionally
        if best is not None and si % 3 == 0:
            work = [list(s) for s in best]
            improve_local(work, rng, iters=4000)
            tot = sum(s[3] for s in work)
            if tot > best_sum:
                best_sum = tot
                best = [tuple(s) for s in work]

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    # ensure exactly n entries
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
# EVOLVE-BLOCK-END

