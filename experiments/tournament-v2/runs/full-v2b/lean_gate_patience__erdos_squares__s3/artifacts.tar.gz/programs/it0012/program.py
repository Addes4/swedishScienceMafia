# EVOLVE-BLOCK-START
"""Portfolio packing heuristic for squares in a unit square.

Approach:
1. Build initial layouts two ways: a recursive guillotine subdivision and a
   shelf/row packing, then greedily grow every square in place (monotone in the
   objective) to fill empty space.
2. Improve positions and sizes with randomized coordinate descent: translate,
   grow, rotate, exchange sizes and re-grow, accepting moves that increase the
   total side length while preserving disjoint interiors.
3. A final "re-centre + regrow" pass pushes each square toward extra side
   length using a wider search for a better centre.
4. Check disjointness exactly for rotated squares by separating-axis testing.
"""

import math
import random

_EPS = 1e-12


def _corners(cx, cy, ang, s):
    h = 0.5 * s
    c = math.cos(2.0 * math.pi * ang)
    sn = math.sin(2.0 * math.pi * ang)
    ax, ay = c, sn
    bx, by = -sn, c
    return [
        (cx + h * ax + h * bx, cy + h * ay + h * by),
        (cx + h * ax - h * bx, cy + h * ay - h * by),
        (cx - h * ax + h * bx, cy - h * ay + h * by),
        (cx - h * ax - h * bx, cy - h * ay - h * by),
    ]


def _project(poly, axis):
    d = poly[0][0] * axis[0] + poly[0][1] * axis[1]
    lo = hi = d
    for x, y in poly[1:]:
        d = x * axis[0] + y * axis[1]
        if d < lo:
            lo = d
        elif d > hi:
            hi = d
    return lo, hi


def _overlap_area(a, b):
    pa = _corners(*a)
    pb = _corners(*b)
    for poly in (pa, pb):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            ln = math.hypot(nx, ny)
            if ln < _EPS:
                continue
            nx /= ln
            ny /= ln
            lo1, hi1 = _project(pa, (nx, ny))
            lo2, hi2 = _project(pb, (nx, ny))
            if hi1 <= lo2 + 1e-11 or hi2 <= lo1 + 1e-11:
                return False
    return True


def _inside(cx, cy, ang, s):
    if s <= 0.0:
        return True
    for x, y in _corners(cx, cy, ang, s):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


# ---------------------------------------------------------------------------
# Initial constructions
# ---------------------------------------------------------------------------

def _guillotine(x0, y0, w, h, n, out):
    if n <= 0:
        return
    if n == 1:
        s = min(w, h)
        out.append((x0 + 0.5 * w, y0 + 0.5 * h, 0.0, s))
        return
    if w >= h:
        n1 = max(1, min(n - 1, int(round(n * w / (w + h)))))
        n2 = n - n1
        w1 = w * n1 / n
        w2 = w - w1
        _guillotine(x0, y0, w1, h, n1, out)
        _guillotine(x0 + w1, y0, w2, h, n2, out)
    else:
        n1 = max(1, min(n - 1, int(round(n * h / (w + h)))))
        n2 = n - n1
        h1 = h * n1 / n
        h2 = h - h1
        _guillotine(x0, y0, w, h1, n1, out)
        _guillotine(x0, y0 + h1, w, h2, n2, out)


def _shelf(n, cols, rng):
    """Shelf packing: partition n into rows of ~cols squares."""
    rows = []
    r = max(1, (n + cols - 1) // cols)
    base = n // r
    rem = n % r
    for i in range(r):
        rows.append(base + (1 if i < rem else 0))
    out = []
    y = 0.0
    total_h = 0.0
    heights = []
    for cnt in rows:
        h = 1.0 / cnt  # square fits cnt across width
        heights.append(h)
        total_h += h
    scale = 1.0 / total_h if total_h > 0 else 1.0
    for cnt, h in zip(rows, heights):
        hh = h * scale
        w = hh
        gap = (1.0 - cnt * w) / (cnt + 1) if cnt > 0 else 0.0
        if gap < 0:
            gap = 0.0
        x = gap
        for _ in range(cnt):
            out.append((x + 0.5 * w, y + 0.5 * hh, 0.0, w))
            x += w + gap
        y += hh
    return out


def _initial_guillotine(n):
    out = []
    _guillotine(0.0, 0.0, 1.0, 1.0, n, out)
    return out


# ---------------------------------------------------------------------------
# Greedy grow-in-place (monotone objective improvement)
# ---------------------------------------------------------------------------

def _best_size_at(squares, i, cx, cy, ang, s):
    """Largest feasible side at a fixed centre/angle (>= s)."""
    if _valid_single(squares, i, (cx, cy, ang, s)):
        lo = s
    else:
        return s
    # exponential expansion to find an upper bound
    hi = lo
    for _ in range(20):
        hi2 = hi * 1.6 + 1e-4
        if hi2 > 1.0:
            hi2 = 1.0
        if _valid_single(squares, i, (cx, cy, ang, hi2)):
            lo = hi2
            if hi >= 1.0:
                return 1.0
            hi = hi2
        else:
            hi = hi2
            break
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        if _valid_single(squares, i, (cx, cy, ang, mid)):
            lo = mid
        else:
            hi = mid
    return lo


def _grow_all(squares, rng, rounds=3):
    """Try to grow each square, in random order, without overlaps."""
    n = len(squares)
    for _ in range(rounds):
        order = list(range(n))
        rng.shuffle(order)
        changed = False
        for i in order:
            cx, cy, ang, s = squares[i]
            best_s = _best_size_at(squares, i, cx, cy, ang, s)
            if best_s > s + 1e-12:
                squares[i] = (cx, cy, ang, best_s)
                changed = True
        # re-centring to find free space, then grow there
        for i in order:
            cx, cy, ang, s = squares[i]
            moved = False
            best_cx, best_cy, best_s = cx, cy, s
            for _ in range(8):
                nx = min(max(cx + (rng.random() * 2 - 1) * 0.08, 0.0), 1.0)
                ny = min(max(cy + (rng.random() * 2 - 1) * 0.08, 0.0), 1.0)
                if _valid_single(squares, i, (nx, ny, ang, s)):
                    ls = _best_size_at(squares, i, nx, ny, ang, s)
                    if ls > best_s + 1e-12:
                        best_s = ls
                        best_cx, best_cy = nx, ny
                        moved = True
            if moved:
                squares[i] = (best_cx, best_cy, ang, best_s)
                changed = True
        if not changed:
            break
    return squares


def _valid_single(squares, i, cand):
    if not _inside(*cand):
        return False
    if cand[3] <= 0.0:
        return True
    for j in range(len(squares)):
        if i == j:
            continue
        b = squares[j]
        if b[3] <= 0.0:
            continue
        if _overlap_area(cand, b):
            return False
    return True


def _valid(squares, idx=None):
    m = len(squares)
    idxs = range(m) if idx is None else [idx]
    for i in idxs:
        a = squares[i]
        if not _inside(*a):
            return False
        for j in range(m):
            if i == j:
                continue
            b = squares[j]
            if a[3] <= 0.0 or b[3] <= 0.0:
                continue
            if _overlap_area(a, b):
                return False
    return True


# ---------------------------------------------------------------------------
# Local search
# ---------------------------------------------------------------------------

def _search(n, rng, iters):
    candidates = [_initial_guillotine(n)]
    max_cols = min(n, 14)
    for cols in range(1, max_cols + 1):
        candidates.append(_shelf(n, cols, rng))

    best = None
    best_val = -1.0
    for cand in candidates:
        sq = [tuple(t) for t in cand]
        for i in range(n):
            cx, cy, ang, s = sq[i]
            if not _inside(cx, cy, ang, s):
                sq[i] = (0.5, 0.5, 0.0, 0.0)
        _grow_all(sq, rng, rounds=3)
        val = sum(t[3] for t in sq)
        if val > best_val:
            best_val = val
            best = [tuple(t) for t in sq]

    squares = [tuple(t) for t in best]

    for _ in range(iters):
        i = rng.randrange(n)
        cx, cy, ang, s = squares[i]
        mode = rng.random()

        if mode < 0.5:
            step = 0.03 * rng.random() + 0.002
            nx = cx + (rng.random() * 2 - 1) * step
            ny = cy + (rng.random() * 2 - 1) * step
            cand = (min(max(nx, 0.0), 1.0), min(max(ny, 0.0), 1.0), ang, s)
        elif mode < 0.7:
            factor = 1.0 + (rng.random() - 0.3) * 0.08
            cand = (cx, cy, ang, max(0.0, s * factor))
        elif mode < 0.82:
            nang = (ang + (rng.random() - 0.5) * 0.08) % 1.0
            cand = (cx, cy, nang, s)
        elif mode < 0.92:
            cand = (cx, cy, ang, _best_size_at(squares, i, cx, cy, ang, s))
        else:
            j = rng.randrange(n)
            cj = squares[j]
            s_i, s_j = squares[i][3], cj[3]
            squares[i] = (squares[i][0], squares[i][1], squares[i][2], s_j)
            squares[j] = (cj[0], cj[1], cj[2], s_i)
            if _valid(squares, i) and _valid(squares, j):
                val = sum(t[3] for t in squares)
                if val > best_val:
                    best_val = val
                    best = [tuple(t) for t in squares]
                    _grow_all(squares, rng, rounds=2)
                    val2 = sum(t[3] for t in squares)
                    if val2 > best_val:
                        best_val = val2
                        best = [tuple(t) for t in squares]
            else:
                squares[i] = (squares[i][0], squares[i][1], squares[i][2], s_i)
                squares[j] = (cj[0], cj[1], cj[2], s_j)
            continue

        old = squares[i]
        squares[i] = cand
        if _valid(squares, i):
            val = sum(t[3] for t in squares)
            if val > best_val:
                best_val = val
                best = [tuple(t) for t in squares]
        else:
            squares[i] = old

    return best


# ---------------------------------------------------------------------------
# Public entry
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    rng = random.Random(987 + 31 * n)
    if n <= 20:
        iters = 12000
    elif n <= 40:
        iters = 8000
    elif n <= 150:
        iters = 4500
    else:
        iters = 2000

    squares = _search(n, rng, iters)

    # Final: global regrow / recentre passes on the incumbent best.
    sq = [tuple(t) for t in squares]
    _grow_all(sq, rng, rounds=6)
    val2 = sum(t[3] for t in sq)
    if val2 > sum(t[3] for t in squares):
        squares = sq

    result = []
    for sq in squares[:n]:
        cx, cy, ang, s = sq
        if not _inside(cx, cy, ang, s):
            result.append((0.5, 0.5, 0.0, 0.0))
        else:
            result.append((cx % 1.0, cy % 1.0, ang % 1.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END
