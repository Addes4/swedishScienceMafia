# EVOLVE-BLOCK-START
"""Recursive guillotine packing + randomized local search with SAT overlap checks."""
import math
import random


def _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """True if two squares (centre, angle as fraction of turn, side) have overlapping interiors.
    Returns False if either has side 0 (degenerate point / empty)."""
    if s1 <= 0.0 or s2 <= 0.0:
        return False
    # must be strictly inside [0,1]^2? We only need overlap of interiors here.
    t1 = a1 * 2.0 * math.pi
    t2 = a2 * 2.0 * math.pi
    c1, sn1 = math.cos(t1), math.sin(t1)
    c2, sn2 = math.cos(t2), math.sin(t2)
    # axes: for each square, the two edge normals (unit)
    axes = [(c1, sn1), (-sn1, c1), (c2, sn2), (-sn2, c2)]
    # half-extents projected onto each axis
    # projections of half-edge vectors: axes of square scaled by s/2
    for ax, ay in axes:
        # projection radius of square 1 onto (ax,ay): (s1/2)*(|u1.ax|+... ) -> use corners
        r1 = (s1 * 0.5) * (abs(c1 * ax + sn1 * ay) + abs(-sn1 * ax + c1 * ay))
        r2 = (s2 * 0.5) * (abs(c2 * ax + sn2 * ay) + abs(-sn2 * ax + c2 * ay))
        d = abs((cx1 - cx2) * ax + (cy1 - cy2) * ay)
        if d >= r1 + r2 - 1e-12:
            return False
    return True


def _sat_separated(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    return not _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2)


def _inside_square(cx, cy, ang, s):
    """Check that the square lies (weakly) within the unit square [0,1]^2."""
    if s <= 0.0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    t = ang * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    # four half-diagonal corner offsets
    for ex, ey in ((h, h), (h, -h), (-h, h), (-h, -h)):
        x = cx + c * ex - sn * ey
        y = cy + sn * ex + c * ey
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _construct(n):
    """Recursive guillotine packing of axis-aligned squares."""
    if n <= 0:
        return []
    squares = []
    # stack of rectangles (x, y, w, h) each to be filled with some count
    stack = [(0.0, 0.0, 1.0, 1.0, n)]
    # We want square tile sizes roughly equal to fill area. Use recursive split:
    # each rectangle of area A to hold k squares -> each side sqrt(A/k).
    # We produce a list of (cx, cy, ang, side) and remember leftover room via placement.

    # Because guillotine placements rarely fill perfectly, we instead do the following:
    # repeatedly pick a rectangle to split. Fill one corner with a square whose side is
    # min(w,h)/m for a small integer m, then split the rest.
    # Simpler and robust: recursive subdivision that allocates k squares to a rect.

    # We'll implement an explicit recursive function using an iterative work list of
    # (x, y, w, h, k) tasks. For k==1 place a centered square. For k>1 split along the
    # longer dimension in proportion to counts.

    tasks = [(0.0, 0.0, 1.0, 1.0, n)]
    results = []
    while tasks:
        x, y, w, h, k = tasks.pop()
        if k <= 0:
            continue
        if k == 1:
            side = min(w, h)
            # shrink a touch to leave slack for later growth; place centered
            s = side * 0.999
            results.append([x + w * 0.5, y + h * 0.5, 0.0, s])
            continue
        # split counts roughly proportional to dimensions
        if w >= h:
            # split vertically (along width)
            # choose ratio so that each sub rect has enough room
            r = random.uniform(0.35, 0.65)
            # bias by ideal counts via area
            k1 = max(1, min(k - 1, int(round(k * r))))
            k2 = k - k1
            w1 = w * (k1 / k)
            w2 = w - w1
            tasks.append((x, y, w1, h, k1))
            tasks.append((x + w1, y, w2, h, k2))
        else:
            r = random.uniform(0.35, 0.65)
            k1 = max(1, min(k - 1, int(round(k * r))))
            k2 = k - k1
            h1 = h * (k1 / k)
            h2 = h - h1
            tasks.append((x, y, w, h1, k1))
            tasks.append((x, y + h1, w, h2, k2))
    return results


def _total(squares):
    return sum(s[3] for s in squares)


def _valid(squares, i, cx, cy, ang, s):
    if not _inside_square(cx, cy, ang, s):
        return False
    n = len(squares)
    for j in range(n):
        if j == i:
            continue
        ox, oy, oa, os_ = squares[j]
        if _overlap(cx, cy, ang, s, ox, oy, oa, os_):
            return False
    return True


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    best = None
    best_score = -1.0

    # Multiple restarts of construction + local search
    restarts = 6 if n <= 60 else 3
    for _ in range(restarts):
        squares = _construct_rand(n, rng)
        squares = _local_search(squares, rng, iters=300 + 20 * n)
        sc = _total(squares)
        if sc > best_score:
            best_score = sc
            best = squares

    # final polish
    best = _local_search(best, rng, iters=400 + 30 * n)
    return [(float(cx), float(cy), float(ang), float(s)) for cx, cy, ang, s in best]


def _construct_rand(n, rng):
    tasks = [(0.0, 0.0, 1.0, 1.0, n)]
    results = []
    while tasks:
        x, y, w, h, k = tasks.pop()
        if k <= 0:
            continue
        if k == 1:
            side = min(w, h)
            s = side * rng.uniform(0.97, 0.999)
            results.append([x + w * 0.5, y + h * 0.5, 0.0, s])
            continue
        if w >= h:
            r = rng.uniform(0.33, 0.67)
            k1 = max(1, min(k - 1, int(round(k * r))))
            k2 = k - k1
            w1 = w * (k1 / k)
            w2 = w - w1
            tasks.append((x, y, w1, h, k1))
            tasks.append((x + w1, y, w2, h, k2))
        else:
            r = rng.uniform(0.33, 0.67)
            k1 = max(1, min(k - 1, int(round(k * r))))
            k2 = k - k1
            h1 = h * (k1 / k)
            h2 = h - h1
            tasks.append((x, y, w, h1, k1))
            tasks.append((x, y + h1, w, h2, k2))
    return results


def _local_search(squares, rng, iters=1500):
    n = len(squares)
    if n == 0:
        return squares
    cur = [list(s) for s in squares]
    cur_score = _total(cur)

    for it in range(iters):
        # pick candidate move
        i = rng.randrange(n)
        cx, cy, ang, s = cur[i]
        move = rng.random()
        if move < 0.55:
            # grow attempt
            factor = rng.uniform(1.0, 1.15)
            ns = min(max(s * factor, 0.0), 1.0)
            nc_x, nc_y, nang = cx, cy, ang
        elif move < 0.8:
            # translate
            d = rng.uniform(0.0, 0.08)
            theta = rng.uniform(0.0, 2.0 * math.pi)
            nc_x = cx + d * math.cos(theta)
            nc_y = cy + d * math.sin(theta)
            ns = s
            nang = ang
        elif move < 0.92:
            # rotate
            nang = (ang + rng.choice([-1, 1]) * rng.uniform(0.0, 0.05)) % 1.0
            nc_x, nc_y, ns = cx, cy, s
        else:
            # shrink to try to enable later moves
            ns = s * rng.uniform(0.8, 1.0)
            nc_x, nc_y, nang = cx, cy, ang

        if not _valid(cur, i, nc_x, nc_y, nang, ns):
            # try a small nudge / shrink to make it valid when growing
            if move < 0.55:
                ns2 = s
                if _valid(cur, i, cx, cy, ang, ns2):
                    pass
            continue

        old = cur[i]
        cur[i] = [nc_x, nc_y, nang, ns]
        new_score = cur_score - old[3] + ns
        # greedy accept (score of a single square change; monotone growth mostly)
        if new_score >= cur_score - 1e-12:
            cur_score = new_score
        else:
            cur[i] = old

    return cur
# EVOLVE-BLOCK-END
