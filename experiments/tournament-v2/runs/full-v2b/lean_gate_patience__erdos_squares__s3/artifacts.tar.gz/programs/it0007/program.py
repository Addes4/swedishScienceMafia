# EVOLVE-BLOCK-START
"""Hybrid packer: recursive guillotine seed, then a deterministic
grow/resolve relaxation that increases the sum of side lengths while
keeping squares axis-aligned and non-overlapping."""
import math


def _guillotine(n):
    squares = []

    def pack_rect(x0, y0, w, h, count):
        if count <= 0 or w <= 0 or h <= 0:
            return
        m = max(math.isqrt(count), 1)
        best = None
        for r in range(1, m + 1):
            c = count // r
            if c < r:
                continue
            s = min(w / c, h / r)
            if s <= 0:
                continue
            score = (s * s * (r * c), s)
            if best is None or score > best[0]:
                best = (score, r, c, s, r * c)
        if best is None:
            return
        _, r, c, s, used = best
        for i in range(c):
            for j in range(r):
                squares.append([x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, s])
        leftover = count - used
        if leftover > 0:
            gw, gh = c * s, r * s
            rem_w, rem_h = w - gw, h - gh
            if rem_w >= rem_h:
                if rem_w > 1e-12:
                    pack_rect(x0 + gw, y0, rem_w, h, leftover)
            else:
                if rem_h > 1e-12:
                    pack_rect(x0, y0 + gh, w, rem_h, leftover)

    pack_rect(0.0, 0.0, 1.0, 1.0, n)
    return squares


def _resolve(sqs, rounds=800):
    """Grow sides, then push apart axis-aligned overlaps by shrinking."""
    n = len(sqs)
    for _ in range(rounds):
        # grow phase
        for i in range(n):
            s = sqs[i][2]
            if s <= 0:
                continue
            ns = s * 1.01
            # keep inside
            cx, cy = sqs[i][0], sqs[i][1]
            ns = min(ns, 2 * min(cx, 1 - cx, cy, 1 - cy))
            if ns > s:
                sqs[i][2] = ns
        # resolve overlaps: shrink the smaller of any overlapping pair
        moved = False
        for i in range(n):
            xi, yi, si = sqs[i]
            hi = si / 2
            if si <= 0:
                continue
            for j in range(i + 1, n):
                xj, yj, sj = sqs[j]
                if sj <= 0:
                    continue
                hj = sj / 2
                ox = hi + hj - abs(xi - xj)
                oy = hi + hj - abs(yi - yj)
                if ox > 1e-12 and oy > 1e-12:
                    # overlap; shrink smaller square to remove it
                    if si <= sj:
                        reduce = min(si, (ox if ox < oy else oy))
                        si -= reduce
                        sqs[i][2] = si
                        hi = si / 2
                        moved = True
                        if si <= 0:
                            break
                    else:
                        reduce = min(sj, (ox if ox < oy else oy))
                        sj -= reduce
                        sqs[j][2] = sj
                        hj = sj / 2
                        sqs[j][2] = sj
                        moved = True
        # reclamp inside
        for k in range(n):
            x, y, s = sqs[k]
            if s > 0:
                h = s / 2
                if x < h:
                    sqs[k][0] = h
                elif x > 1 - h:
                    sqs[k][0] = 1 - h
                if y < h:
                    sqs[k][1] = h
                elif y > 1 - h:
                    sqs[k][1] = 1 - h
        if not moved:
            break
    return sqs


def _grow_repair(sqs):
    """Final pass: try to enlarge each square while keeping it disjoint."""
    n = len(sqs)
    order = sorted(range(n), key=lambda i: sqs[i][2])
    for i in order:
        cx, cy, s = sqs[i]
        if s <= 0:
            continue
        best = s
        # binary search the largest feasible side
        lo, hi = s, 2 * min(cx, 1 - cx, cy, 1 - cy)
        for _ in range(40):
            mid = (lo + hi) / 2
            h = mid / 2
            ok = True
            for j in range(n):
                if j == i:
                    continue
                xj, yj, sj = sqs[j]
                if sj <= 0:
                    continue
                hj = sj / 2
                if (h + hj > abs(cx - xj) + 1e-12 and
                        h + hj > abs(cy - yj) + 1e-12):
                    ok = False
                    break
            if ok:
                lo = mid
            else:
                hi = mid
        sqs[i][2] = lo
    return sqs


def solve(n):
    if n <= 0:
        return []
    sqs = _guillotine(n)
    while len(sqs) < n:
        sqs.append([0.5, 0.5, 0.0])

    sqs = _resolve(sqs)
    sqs = _grow_repair(sqs)
    sqs = _resolve(sqs)
    sqs = _grow_repair(sqs)

    res = []
    for cx, cy, s in sqs:
        if s < 0:
            s = 0.0
        if s > 1:
            s = 1.0
        h = s / 2
        cx = min(max(cx, h), 1 - h)
        cy = min(max(cy, h), 1 - h)
        res.append((cx, cy, 0.0, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
# EVOLVE-BLOCK-END
