# EVOLVE-BLOCK-START
"""Guillotine packing: split the unit square recursively, using optimal
integer grids for perfect squares and carving a leftover rectangle for the rest."""
import math


def solve(n):
    if n <= 0:
        return []

    squares = []

    def pack_rect(x0, y0, w, h, count):
        """Pack `count` squares (axis-aligned) into rectangle [x0,x0+w]x[y0,y0+h]."""
        if count <= 0 or w <= 0 or h <= 0:
            return
        m = math.isqrt(count)
        m = max(m, 1)
        # best grid r x c with r*c <= count, r<=c, roughly matching aspect
        best = None
        for r in range(1, m + 1):
            c = count // r
            if c < r:
                continue
            # side limited by width/c and height/r
            s = min(w / c, h / r)
            if s <= 0:
                continue
            used = r * c
            # prefer configurations that leave a usable rectangle for leftovers
            score = (s, used)
            if best is None or score > best[0]:
                best = (score, r, c, s, used)
        if best is None:
            return
        _, r, c, s, used = best
        for i in range(c):
            for j in range(r):
                squares.append((x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, 0.0, s))
        leftover = count - used
        if leftover > 0:
            # carve the largest free strip and recurse
            gw = c * s
            gh = r * s
            rem_w = w - gw
            rem_h = h - gh
            if rem_w >= rem_h:
                if rem_w > 1e-12:
                    pack_rect(x0 + gw, y0, rem_w, h, leftover)
            else:
                if rem_h > 1e-12:
                    pack_rect(x0, y0 + gh, w, rem_h, leftover)

    pack_rect(0.0, 0.0, 1.0, 1.0, n)

    # safety: clamp and fill if we somehow produced too few
    res = []
    for cx, cy, a, s in squares:
        if s < 0:
            s = 0.0
        cx = min(max(cx, s / 2), 1 - s / 2) if s <= 1 else 0.5
        cy = min(max(cy, s / 2), 1 - s / 2) if s <= 1 else 0.5
        res.append((cx, cy, 0.0, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
# EVOLVE-BLOCK-END

