# EVOLVE-BLOCK-START
"""Squares in a square: grid/shelf construction + randomized local search + SLSQP polish."""
import math
import random

import numpy as np
from scipy.optimize import minimize

PI = math.pi


def _corners(cx, cy, ang, s):
    a = ang * 2.0 * PI
    c = math.cos(a)
    sn = math.sin(a)
    h = 0.5 * s
    ux, uy = c * h, sn * h
    vx, vy = -sn * h, c * h
    return [
        (cx + ux + vx, cy + uy + vy),
        (cx + ux - vx, cy + uy - vy),
        (cx - ux - vx, cy - uy - vy),
        (cx - ux + vx, cy - uy + vy),
    ]


def _overlap_pair(c1, c2, eps=1e-12):
    for poly in (c1, c2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            nx, ny = -ey, ex
            nlen = math.hypot(nx, ny)
            if nlen < eps:
                continue
            nx /= nlen
            ny /= nlen
            min1 = min(p[0] * nx + p[1] * ny for p in c1)
            max1 = max(p[0] * nx + p[1] * ny for p in c1)
            min2 = min(p[0] * nx + p[1] * ny for p in c2)
            max2 = max(p[0] * nx + p[1] * ny for p in c2)
            if max1 <= min2 + eps or max2 <= min1 + eps:
                return False
    return True


def _inside_unit(cs, eps=1e-9):
    for x, y in cs:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _valid(squares):
    n = len(squares)
    corners = []
    for (cx, cy, ang, s) in squares:
        cs = _corners(cx, cy, ang, s)
        if not _inside_unit(cs):
            return False
        corners.append(cs)
    for i in range(n):
        if squares[i][3] <= 0.0:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 0.0:
                continue
            if _overlap_pair(corners[i], corners[j]):
                return False
    return True


def _score(squares):
    return sum(sq[3] for sq in squares)


# ---------- constructors ----------

def _grid_pack(n):
    best = None
    best_sc = -1.0
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        w = 1.0 / cols
        h = 1.0 / rows
        s = min(w, h)
        sq = []
        cnt = 0
        for r in range(rows):
            for c in range(cols):
                if cnt >= n:
                    break
                cx = (c + 0.5) * w
                cy = (r + 0.5) * h
                sq.append((cx, cy, 0.0, s))
                cnt += 1
            if cnt >= n:
                break
        sq = sq[:n]
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        if _valid(sq):
            sc = _score(sq)
            if sc > best_sc:
                best_sc = sc
                best = sq
    return best if best is not None else [(0.5, 0.5, 0.0, s) for _ in range(n)]


def _bigrow_shelf(n):
    best = None
    best_sc = -1.0
    for k in range(1, n + 1):
        rem = n - k
        s = 1.0 / k
        if rem == 0:
            h = 0.0
        else:
            c = math.ceil(math.sqrt(rem))
            h = 1.0 / c
        sq = []
        for i in range(k):
            sq.append(((i + 0.5) * s, 0.5 * s, 0.0, s))
        if rem > 0:
            c = math.ceil(math.sqrt(rem))
            rs = min(1.0 / c, h)
            cnt = 0
            for r in range(math.ceil(rem / c)):
                for cc in range(c):
                    if cnt >= rem:
                        break
                    cx = (cc + 0.5) * (1.0 / c)
                    cy = 1.0 - h + (r + 0.5) * h
                    sq.append((cx, cy, 0.0, rs))
                    cnt += 1
                if cnt >= rem:
                    break
        sq = sq[:n]
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        if _valid(sq):
            sc = _score(sq)
            if sc > best_sc:
                best_sc = sc
                best = sq
    return best if best is not None else _grid_pack(n)


def _pack_equal(n, t):
    k = math.isqrt(n)
    if (k * k >= n) and (k * t <= 1.0 + 1e-12):
        sq = []
        cnt = 0
        for r in range(k):
            for c in range(k):
                if cnt >= n:
                    break
                sq.append(((c + 0.5) * t, (r + 0.5) * t, 0.0, t))
                cnt += 1
            if cnt >= n:
                break
        return sq[:n]
    return None


def _maxmin_seed(n):
    lo, hi = 0.0, 1.0
    best = None
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        sq = _pack_equal(n, mid)
        if sq is not None and _valid(sq):
            best = sq
            lo = mid
        else:
            hi = mid
    if best is None:
        return _grid_pack(n)
    return best


# ---------- improvement moves ----------

def _grow_all(squares, passes=60):
    sq = list(squares)
    n = len(sq)
    for _ in range(passes):
        improved = False
        order = list(range(n))
        random.shuffle(order)
        for i in order:
            cx, cy, ang, s = sq[i]
            lo, hi = 0.0, 1.0
            best_s = s
            for _ in range(20):
                mid = 0.5 * (lo + hi)
                trial = list(sq)
                trial[i] = (cx, cy, ang, mid)
                if _valid(trial):
                    lo = mid
                    best_s = mid
                else:
                    hi = mid
            if best_s > s + 1e-9:
                sq[i] = (cx, cy, ang, best_s)
                improved = True
        if not improved:
            break
    return sq


def _local_search(n, squares, iters=20000):
    if n == 0:
        return squares
    best = list(squares)
    best_score = _score(best)
    cur = list(best)
    cur_score = best_score
    no_improve = 0
    for _ in range(iters):
        i = random.randrange(n)
        cx, cy, ang, s = cur[i]
        move = random.random()
        if move < 0.45:
            ds = random.uniform(0.0, 0.03)
            nc = (cx, cy, ang, min(1.0, s + ds))
        elif move < 0.75:
            a = random.random() * 2 * PI
            d = random.uniform(0.0, 0.02)
            nc = (min(1.0, max(0.0, cx + math.cos(a) * d)),
                  min(1.0, max(0.0, cy + math.sin(a) * d)), ang, s)
        elif move < 0.85:
            nc = (cx, cy, (ang + random.uniform(-0.15, 0.15)) % 1.0, s)
        else:
            bx, by = cx, cy
            for _ in range(8):
                tx = random.random()
                ty = random.random()
                trial = list(cur)
                trial[i] = (tx, ty, ang, s)
                if _valid(trial) and _score(trial) >= cur_score:
                    bx, by = tx, ty
                    break
            nc = (bx, by, ang, s)
        old = cur[i]
        cur[i] = nc
        if _valid(cur):
            sc = _score(cur)
            if sc >= cur_score - 1e-12:
                cur_score = sc
                if sc > best_score:
                    best_score = sc
                    best = list(cur)
                no_improve = 0
            elif random.random() < 0.03:
                cur_score = sc
                no_improve += 1
            else:
                cur[i] = old
                no_improve += 1
        else:
            cur[i] = old
            no_improve += 1
        if no_improve > 4000:
            cur = list(best)
            k = random.randrange(n)
            cx, cy, ang, s = cur[k]
            a = random.random() * 2 * PI
            d = random.uniform(0.0, 0.02)
            cur[k] = (min(1.0, max(0.0, cx + math.cos(a) * d)),
                      min(1.0, max(0.0, cy + math.sin(a) * d)), ang, s)
            if not _valid(cur):
                cur = list(best)
            cur_score = _score(cur)
            no_improve = 0
    return best


# ---------- SLSQP polish ----------

def _slsqp_polish(squares, rounds=3, maxiter=200):
    """Joint continuous refinement of centres, angles and sizes.

    Uses a smooth penalty formulation: minimize
      -(sum of sides) + W * penalty
    where penalty accumulates squared violations (overlaps, out-of-bounds).
    Weight W is annealed upward so feasible layouts dominate.
    """
    n = len(squares)
    if n <= 1:
        return squares

    # variables: for each square (cx, cy, ang, s)
    x0 = np.array([v for sq in squares for v in sq], dtype=float)

    # approximate overlap measure via oriented-box separating axis soft penalty.
    # We use: for each pair, approximate penetration = max over axes of (min overlap).
    # Simplify with a smooth surrogate: for each pair, use centres & radii in the
    # direction connecting them plus angle-aware width.

    def unpack(x):
        return x.reshape(n, 4)

    # Precompute per-square rotated half-axis vectors on the fly.

    def penalty(x):
        P = unpack(x)
        pen = 0.0
        # containment: corners inside [0,1]^2
        for i in range(n):
            cx, cy, ang, s = P[i]
            a = ang * 2.0 * PI
            c = math.cos(a)
            sn = math.sin(a)
            h = 0.5 * abs(s)
            ux, uy = c * h, sn * h
            vx, vy = -sn * h, c * h
            for dx, dy in ((ux + vx, uy + vy), (ux - vx, uy - vy),
                           (-ux - vx, -uy - vy), (-ux + vx, -uy + vy)):
                px = cx + dx
                py = cy + dy
                if px < 0.0:
                    pen += px * px
                elif px > 1.0:
                    pen += (px - 1.0) ** 2
                if py < 0.0:
                    pen += py * py
                elif py > 1.0:
                    pen += (py - 1.0) ** 2
        # overlaps via SAT on the two squares' own axes (4 axes per pair)
        for i in range(n):
            cx1, cy1, a1, s1 = P[i]
            ang1 = a1 * 2.0 * PI
            c1 = math.cos(ang1)
            sn1 = math.sin(ang1)
            h1 = 0.5 * abs(s1)
            ax1 = (c1 * h1, sn1 * h1)
            ay1 = (-sn1 * h1, c1 * h1)
            for j in range(i + 1, n):
                cx2, cy2, a2, s2 = P[j]
                ang2 = a2 * 2.0 * PI
                c2 = math.cos(ang2)
                sn2 = math.sin(ang2)
                h2 = 0.5 * abs(s2)
                ax2 = (c2 * h2, sn2 * h2)
                ay2 = (-sn2 * h2, c2 * h2)
                dx = cx2 - cx1
                dy = cy2 - cy1
                # radius of box1 and box2 along each of 4 axes
                axes = (ax1, ay1, ax2, ay2)
                min_overlap = None
                for (ex, ey) in axes:
                    en = math.hypot(ex, ey)
                    if en < 1e-12:
                        continue
                    nx, ny = ex / en, ey / en
                    r1 = abs(ax1[0] * nx + ax1[1] * ny) + abs(ay1[0] * nx + ay1[1] * ny)
                    r2 = abs(ax2[0] * nx + ax2[1] * ny) + abs(ay2[0] * nx + ay2[1] * ny)
                    d = abs(dx * nx + dy * ny)
                    ov = r1 + r2 - d
                    if ov <= 0.0:
                        min_overlap = 0.0
                        break
                    if min_overlap is None or ov < min_overlap:
                        min_overlap = ov
                if min_overlap is None:
                    min_overlap = 0.0
                if min_overlap > 0.0:
                    pen += min_overlap * min_overlap
        return pen

    def objective(x):
        P = unpack(x)
        return -float(np.sum(np.abs(P[:, 3])))

    best_x = x0.copy()
    best_score = _score(squares)
    # feasibility of best known
    for W in (1.0, 5.0, 20.0, 100.0, 500.0, 2000.0):
        def fun(x):
            return objective(x) + W * penalty(x)

        res = minimize(fun, best_x, method='Nelder-Mead',
                       options={'maxiter': maxiter, 'xatol': 1e-6, 'fatol': 1e-8})
        cand_x = res.x
        P = unpack(cand_x)
        cand = []
        for i in range(n):
            cx, cy, ang, s = P[i]
            cx = min(1.0, max(0.0, cx))
            cy = min(1.0, max(0.0, cy))
            ang = ang % 1.0
            s = max(0.0, min(1.0, s))
            cand.append((cx, cy, ang, s))
        # clean overlaps: if invalid, shrink sizes slightly and re-validate
        if _valid(cand):
            sc = _score(cand)
            if sc > best_score + 1e-9:
                best_score = sc
                best_x = cand_x.copy()
        else:
            # try a mild shrink then validate
            shrunk = []
            for (cx, cy, ang, s) in cand:
                shrunk.append((cx, cy, ang, s * 0.995))
            if _valid(shrunk):
                sc = _score(shrunk)
                if sc > best_score + 1e-9:
                    best_score = sc
                    best_x = cand_x.copy()
    P = unpack(best_x)
    result = []
    for i in range(n):
        cx, cy, ang, s = P[i]
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = max(0.0, min(1.0, s))
        result.append((cx, cy, ang, s))
    # final shrink-to-valid pass
    if _valid(result):
        return result
    # fall back: shrink until valid
    for _ in range(200):
        result = [(cx, cy, ang, s * 0.98) for (cx, cy, ang, s) in result]
        if _valid(result):
            return result
    return squares


def _repair(squares):
    """Greedily drop/shrink to guarantee validity."""
    result = []
    for sq in squares:
        cx, cy, ang, s = sq
        trial = result + [(cx, cy, ang, s)]
        if _valid(trial):
            result.append((cx, cy, ang, s))
        else:
            result.append((0.5, 0.5, 0.0, 0.0))
    return result


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = [_grid_pack(n), _bigrow_shelf(n), _maxmin_seed(n)]
    seeds = [c for c in candidates if c is not None and _valid(c)]
    if not seeds:
        seeds = [_grid_pack(n)]

    iters = 6000 if n <= 10 else (12000 if n <= 50 else 8000)
    best = None
    best_sc = -1.0
    random.shuffle(seeds)
    for seed in seeds:
        cand = _grow_all(seed)
        cand = _local_search(n, cand, iters=iters)
        cand = _grow_all(cand)
        if _valid(cand):
            sc = _score(cand)
            if sc > best_sc:
                best_sc = sc
                best = cand
    if best is None:
        best = _grid_pack(n)

    # SLSQP joint polish on the best layout (with a couple of randomized restarts)
    try:
        polished = _slsqp_polish(best, maxiter=300)
        if _valid(polished) and _score(polished) > best_sc:
            best = polished
            best_sc = _score(polished)
        # randomized restarts around best
        for _ in range(2):
            jit = []
            for (cx, cy, ang, s) in best:
                jit.append((min(1.0, max(0.0, cx + random.uniform(-0.01, 0.01))),
                            min(1.0, max(0.0, cy + random.uniform(-0.01, 0.01))),
                            (ang + random.uniform(-0.02, 0.02)) % 1.0,
                            max(0.0, s)))
            if not _valid(jit):
                continue
            p2 = _slsqp_polish(jit, maxiter=300)
            if _valid(p2) and _score(p2) > best_sc:
                best = p2
                best_sc = _score(p2)
    except Exception:
        pass

    if not _valid(best):
        best = _repair(best)
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
# EVOLVE-BLOCK-END
