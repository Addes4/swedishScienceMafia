# EVOLVE-BLOCK-START
"""Portfolio packing heuristic for squares in a unit square.

Approach:
1. Build initial layouts several ways: a recursive guillotine subdivision, a
   shelf/row packing, and a best-of-many uniform grid packer (plus a strip),
   then greedily grow every square in place (monotone in the objective).
2. Improve positions and sizes with randomized coordinate descent: translate,
   grow, rotate, exchange sizes, `relocate-and-regrow`, and a `cluster lift
   and regrow` move that lifts a square together with its closest neighbours
   and re-grows them all at once.  Only moves that increase the total side
   length while preserving disjoint interiors are accepted.
3. Check disjointness exactly for rotated squares by separating-axis testing.
"""

import math
import random

_EPS = 1e-12


def _corners(cx, cy, ang, s):
    h = 0.5 * s
    c = math.cos(2.0 * math.pi * ang)
    sn = math.sin(2.0 * math.pi * ang)
    ax, ay = c, sn
    bx, by = -sn, c
    return [
        (cx + h * ax + h * bx, cy + h * ay + h * by),
        (cx + h * ax - h * bx, cy + h * ay - h * by),
        (cx - h * ax + h * bx, cy - h * ay + h * by),
        (cx - h * ax - h * bx, cy - h * ay - h * by),
    ]


def _project(poly, axis):
    d = poly[0][0] * axis[0] + poly[0][1] * axis[1]
    lo = hi = d
    for x, y in poly[1:]:
        d = x * axis[0] + y * axis[1]
        if d < lo:
            lo = d
        elif d > hi:
            hi = d
    return lo, hi


def _overlap_area(a, b):
    pa = _corners(*a)
    pb = _corners(*b)
    for poly in (pa, pb):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            ln = math.hypot(nx, ny)
            if ln < _EPS:
                continue
            nx /= ln
            ny /= ln
            lo1, hi1 = _project(pa, (nx, ny))
            lo2, hi2 = _project(pb, (nx, ny))
            if hi1 <= lo2 + 1e-11 or hi2 <= lo1 + 1e-11:
                return False
    return True


def _inside(cx, cy, ang, s):
    if s <= 0.0:
        return True
    for x, y in _corners(cx, cy, ang, s):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


# ---------------------------------------------------------------------------
# Initial constructions
# ---------------------------------------------------------------------------

def _guillotine(x0, y0, w, h, n, out):
    if n <= 0:
        return
    if n == 1:
        s = min(w, h)
        out.append((x0 + 0.5 * w, y0 + 0.5 * h, 0.0, s))
        return
    if w >= h:
        n1 = max(1, min(n - 1, int(round(n * w / (w + h)))))
        n2 = n - n1
        w1 = w * n1 / n
        w2 = w - w1
        _guillotine(x0, y0, w1, h, n1, out)
        _guillotine(x0 + w1, y0, w2, h, n2, out)
    else:
        n1 = max(1, min(n - 1, int(round(n * h / (w + h)))))
        n2 = n - n1
        h1 = h * n1 / n
        h2 = h - h1
        _guillotine(x0, y0, w, h1, n1, out)
        _guillotine(x0, y0 + h1, w, h2, n2, out)


def _shelf(n, cols, rng):
    """Shelf packing: partition n into rows of ~cols squares."""
    rows = []
    r = max(1, (n + cols - 1) // cols)
    base = n // r
    rem = n % r
    for i in range(r):
        rows.append(base + (1 if i < rem else 0))
    out = []
    y = 0.0
    total_h = 0.0
    heights = []
    for cnt in rows:
        h = 1.0 / cnt
        heights.append(h)
        total_h += h
    scale = 1.0 / total_h if total_h > 0 else 1.0
    for cnt, h in zip(rows, heights):
        hh = h * scale
        w = hh
        gap = (1.0 - cnt * w) / (cnt + 1) if cnt > 0 else 0.0
        if gap < 0:
            gap = 0.0
        x = gap
        for _ in range(cnt):
            out.append((x + 0.5 * w, y + 0.5 * hh, 0.0, w))
            x += w + gap
        y += hh
    return out


def _grid_pack(n, rows, cols, with_strip):
    """Uniform rows x cols grid of equal squares in [0,1]^2."""
    if rows < 1 or cols < 1:
        return None
    total = rows * cols
    if total < n:
        return None
    out = []
    if with_strip and total > n:
        for rc in range(1, rows + 1):
            for cc in range(1, cols + 1):
                block_total = rc * cc
                if block_total >= n or block_total <= 0:
                    continue
                leftovers = n - block_total
                if leftovers < 1:
                    continue
                s = min(1.0 / cc, 1.0 / rc)
                strip_s = min((1.0 - cc * s), 1.0 / leftovers)
                tmp = []
                for r in range(rc):
                    for c in range(cc):
                        tmp.append((c * s + 0.5 * s, r * s + 0.5 * s, 0.0, s))
                sx = cc * s
                for k in range(leftovers):
                    tmp.append((sx + 0.5 * strip_s,
                                k * strip_s + 0.5 * strip_s, 0.0, strip_s))
                if len(tmp) == n:
                    cov = sum(t[3] for t in tmp)
                    if 0 < sx + strip_s <= 1.0 + 1e-9 and strip_s > 0:
                        out.append((cov, tmp))
        if out:
            out.sort(key=lambda t: -t[0])
            return out[0][1]
        return None
    best = None
    bestcov = -1.0
    for r in range(1, rows + 1):
        for c in range(1, cols + 1):
            if r * c >= n:
                s = min(1.0 / c, 1.0 / r)
                tmp = []
                placed = 0
                for rr in range(r):
                    for cc in range(c):
                        if placed >= n:
                            break
                        tmp.append((cc * s + 0.5 * s, rr * s + 0.5 * s, 0.0, s))
                        placed += 1
                    if placed >= n:
                        break
                if placed < n:
                    continue
                cov = sum(t[3] for t in tmp)
                if cov > bestcov:
                    bestcov = cov
                    best = tmp
    return best


def _initial_guillotine(n):
    out = []
    _guillotine(0.0, 0.0, 1.0, 1.0, n, out)
    return out


def _grid_candidates(n):
    cands = []
    lim = int(math.ceil(math.sqrt(n))) + 2
    for rows in range(1, lim + 1):
        for cols in range(1, lim + 1):
            g = _grid_pack(n, rows, cols, with_strip=False)
            if g is not None:
                cands.append(g)
            g = _grid_pack(n, rows, cols, with_strip=True)
            if g is not None:
                cands.append(g)
    return cands


# ---------------------------------------------------------------------------
# Greedy grow-in-place (monotone objective improvement)
# ---------------------------------------------------------------------------

def _grow_all(squares, rng, rounds=3):
    n = len(squares)
    for _ in range(rounds):
        order = list(range(n))
        rng.shuffle(order)
        changed = False
        for i in order:
            cx, cy, ang, s = squares[i]
            lo, hi = s, max(s, 1.0)
            if _valid_single(squares, i, (cx, cy, ang, hi)):
                best_s = hi
            else:
                for _ in range(24):
                    mid = 0.5 * (lo + hi)
                    if _valid_single(squares, i, (cx, cy, ang, mid)):
                        lo = mid
                    else:
                        hi = mid
                best_s = lo
            if best_s > s + 1e-12:
                squares[i] = (cx, cy, ang, best_s)
                changed = True
        for i in order:
            cx, cy, ang, s = squares[i]
            best = (cx, cy)
            best_s = s
            for _ in range(6):
                nx = min(max(cx + (rng.random() * 2 - 1) * 0.06, 0.0), 1.0)
                ny = min(max(cy + (rng.random() * 2 - 1) * 0.06, 0.0), 1.0)
                if _valid_single(squares, i, (nx, ny, ang, s)):
                    lo, hi = s, 1.0
                    for _ in range(20):
                        mid = 0.5 * (lo + hi)
                        if _valid_single(squares, i, (nx, ny, ang, mid)):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s + 1e-12:
                        best_s = lo
                        best = (nx, ny)
            if best_s > s + 1e-12:
                squares[i] = (best[0], best[1], ang, best_s)
                changed = True
        if not changed:
            break
    return squares


def _valid_single(squares, i, cand):
    if not _inside(*cand):
        return False
    if cand[3] <= 0.0:
        return True
    for j in range(len(squares)):
        if i == j:
            continue
        b = squares[j]
        if b[3] <= 0.0:
            continue
        if _overlap_area(cand, b):
            return False
    return True


def _valid(squares, idx=None):
    m = len(squares)
    idxs = range(m) if idx is None else [idx]
    for i in idxs:
        a = squares[i]
        if not _inside(*a):
            return False
        for j in range(m):
            if i == j:
                continue
            b = squares[j]
            if a[3] <= 0.0 or b[3] <= 0.0:
                continue
            if _overlap_area(a, b):
                return False
    return True


# ---------------------------------------------------------------------------
# Local search
# ---------------------------------------------------------------------------

def _neighbours(squares, i, k):
    """Return indices of the k squares whose centres are nearest to square i."""
    cx, cy = squares[i][0], squares[i][1]
    dists = []
    for j in range(len(squares)):
        if j == i:
            continue
        dj = (squares[j][0] - cx) ** 2 + (squares[j][1] - cy) ** 2
        dists.append((dj, j))
    dists.sort()
    return [j for _, j in dists[:k]]


def _search(n, rng, iters):
    candidates = [_initial_guillotine(n)]
    for cols in range(1, min(n, 12) + 1):
        candidates.append(_shelf(n, cols, rng))
    candidates.extend(_grid_candidates(n))

    best = None
    best_val = -1.0
    grown = []
    for cand in candidates:
        sq = [tuple(t) for t in cand]
        for i in range(n):
            cx, cy, ang, s = sq[i]
            if not _inside(cx, cy, ang, s):
                sq[i] = (0.5, 0.5, 0.0, 0.0)
        _grow_all(sq, rng, rounds=1)
        val = sum(t[3] for t in sq)
        grown.append((val, sq))
        if val > best_val:
            best_val = val
            best = [tuple(t) for t in sq]
    grown.sort(key=lambda t: -t[0])
    for _, sq in grown[:5]:
        sq2 = [tuple(t) for t in sq]
        _grow_all(sq2, rng, rounds=3)
        val = sum(t[3] for t in sq2)
        if val > best_val:
            best_val = val
            best = [tuple(t) for t in sq2]

    squares = [tuple(t) for t in best]

    for _ in range(iters):
        i = rng.randrange(n)
        cx, cy, ang, s = squares[i]
        mode = rng.random()

        if mode < 0.40:
            step = 0.03 * rng.random() + 0.002
            nx = cx + (rng.random() * 2 - 1) * step
            ny = cy + (rng.random() * 2 - 1) * step
            cand = (min(max(nx, 0.0), 1.0), min(max(ny, 0.0), 1.0), ang, s)
        elif mode < 0.56:
            factor = 1.0 + (rng.random() - 0.3) * 0.08
            cand = (cx, cy, ang, max(0.0, s * factor))
        elif mode < 0.68:
            nang = (ang + (rng.random() - 0.5) * 0.08) % 1.0
            cand = (cx, cy, nang, s)
        elif mode < 0.78:
            lo, hi = s, 1.0
            for _ in range(20):
                mid = 0.5 * (lo + hi)
                if _valid_single(squares, i, (cx, cy, ang, mid)):
                    lo = mid
                else:
                    hi = mid
            cand = (cx, cy, ang, lo)
        elif mode < 0.88:
            # Exchange sizes with a random square.
            j = rng.randrange(n)
            cj = squares[j]
            s_i, s_j = squares[i][3], cj[3]
            squares[i] = (squares[i][0], squares[i][1], squares[i][2], s_j)
            squares[j] = (cj[0], cj[1], cj[2], s_i)
            if _valid(squares, i) and _valid(squares, j):
                val = sum(t[3] for t in squares)
                if val > best_val:
                    best_val = val
                    best = [tuple(t) for t in squares]
                    _grow_all(squares, rng, rounds=1)
                    val2 = sum(t[3] for t in squares)
                    if val2 > best_val:
                        best_val = val2
                        best = [tuple(t) for t in squares]
            else:
                squares[i] = (squares[i][0], squares[i][1], squares[i][2], s_i)
                squares[j] = (cj[0], cj[1], cj[2], s_j)
            continue
        elif mode < 0.94:
            # Relocate: lift one square, scan many candidate centres, keep best.
            lifted = squares[i]
            old_s = lifted[3]
            squares[i] = (lifted[0], lifted[1], lifted[2], 0.0)
            bestloc = None
            bestc = old_s
            trials = 40
            for _ in range(trials):
                nx = rng.random()
                ny = rng.random()
                lo, hi = 0.0, 1.0
                if _valid_single(squares, i, (nx, ny, lifted[2], hi)):
                    lo = hi
                else:
                    for _ in range(18):
                        mid = 0.5 * (lo + hi)
                        if _valid_single(squares, i, (nx, ny, lifted[2], mid)):
                            lo = mid
                        else:
                            hi = mid
                if lo > bestc + 1e-12:
                    bestc = lo
                    bestloc = (nx, ny)
            if bestloc is not None:
                squares[i] = (bestloc[0], bestloc[1], lifted[2], bestc)
            else:
                squares[i] = lifted
            val = sum(t[3] for t in squares)
            if val > best_val:
                best_val = val
                best = [tuple(t) for t in squares]
                _grow_all(squares, rng, rounds=1)
                val2 = sum(t[3] for t in squares)
                if val2 > best_val:
                    best_val = val2
                    best = [tuple(t) for t in squares]
            continue
        else:
            # Cluster lift-and-regrow: take square i and its k nearest
            # neighbours, zero them all, then greedily re-grow them from
            # random centres.  Accept only strict improvements.
            k = rng.randint(1, min(4, n - 1))
            cluster = [i] + _neighbours(squares, i, k)
            saved = [tuple(squares[t]) for t in cluster]
            old_val = sum(squares[t][3] for t in cluster)
            for t in cluster:
                squares[t] = (squares[t][0], squares[t][1], squares[t][2], 0.0)
            order = list(cluster)
            rng.shuffle(order)
            for t in order:
                ang_t = squares[t][2]
                bestc = 0.0
                bestloc = (squares[t][0], squares[t][1])
                for _ in range(24):
                    nx = rng.random()
                    ny = rng.random()
                    lo, hi = 0.0, 1.0
                    if _valid_single(squares, t, (nx, ny, ang_t, hi)):
                        lo = hi
                    else:
                        for _ in range(18):
                            mid = 0.5 * (lo + hi)
                            if _valid_single(squares, t, (nx, ny, ang_t, mid)):
                                lo = mid
                            else:
                                hi = mid
                    if lo > bestc + 1e-12:
                        bestc = lo
                        bestloc = (nx, ny)
                squares[t] = (bestloc[0], bestloc[1], ang_t, bestc)
            new_val = sum(squares[t][3] for t in cluster)
            if new_val > old_val + 1e-12:
                val = sum(t[3] for t in squares)
                if val > best_val:
                    best_val = val
                    best = [tuple(t) for t in squares]
                _grow_all(squares, rng, rounds=1)
                val2 = sum(t[3] for t in squares)
                if val2 > best_val:
                    best_val = val2
                    best = [tuple(t) for t in squares]
            else:
                for t, sv in zip(cluster, saved):
                    squares[t] = sv
            continue

        old = squares[i]
        squares[i] = cand
        if _valid(squares, i):
            val = sum(t[3] for t in squares)
            if val > best_val:
                best_val = val
                best = [tuple(t) for t in squares]
        else:
            squares[i] = old

    return best


# ---------------------------------------------------------------------------
# Public entry
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    rng = random.Random(987 + 31 * n)
    iters = 6000 if n <= 40 else (4000 if n <= 150 else 1800)
    squares = _search(n, rng, iters)

    result = []
    for sq in squares[:n]:
        cx, cy, ang, s = sq
        if not _inside(cx, cy, ang, s):
            result.append((0.5, 0.5, 0.0, 0.0))
        else:
            result.append((cx % 1.0, cy % 1.0, ang % 1.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END
