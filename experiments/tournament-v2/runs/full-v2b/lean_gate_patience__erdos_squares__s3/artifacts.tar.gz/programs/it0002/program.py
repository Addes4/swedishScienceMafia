# EVOLVE-BLOCK-START
"""Place n squares in the unit square, maximising the sum of side lengths.

Approach: parametrise n squares by (cx, cy, angle, side).  Start from a feasible
packing (grid).  Then run a penalty-based local search: repeatedly try small
random perturbations of positions, angles and sides, accepting improvements of the
objective  sum(side) - big * total_overlap - big * outside_violation.  Overlap is
computed exactly for convex polygons via the separating-axis test.
"""
import math
import random


def _corners(cx, cy, ang, s):
    """Return the 4 corners of a square (centre, angle fraction of a turn, side)."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    # local corners then rotate
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + ca * x - sa * y, cy + sa * x + ca * y))
    return out


def _proj(pts, ax, ay):
    lo = hi = pts[0][0] * ax + pts[0][1] * ay
    for x, y in pts[1:]:
        d = x * ax + y * ay
        if d < lo:
            lo = d
        elif d > hi:
            hi = d
    return lo, hi


def _overlap(p1, p2, s1, s2):
    """Overlap area approximation for two convex polygons given as corner lists.

    Uses the separating axis theorem to test intersection; when they intersect,
    returns the penetration depth (a cheap proxy for overlap magnitude)."""
    axes = []
    for poly in (p1, p2):
        for i in range(len(poly)):
            x0, y0 = poly[i]
            x1, y1 = poly[(i + 1) % len(poly)]
            ex, ey = x1 - x0, y1 - y0
            L = math.hypot(ex, ey) or 1.0
            axes.append((-ey / L, ex / L))
    best = None
    for ax, ay in axes:
        lo1, hi1 = _proj(p1, ax, ay)
        lo2, hi2 = _proj(p2, ax, ay)
        d = min(hi1, hi2) - max(lo1, lo2)
        if d <= 0:
            return 0.0
        if best is None or d < best:
            best = d
    return best


def _penalty(sqs):
    """Objective: sum of sides minus penalties for overlaps and going outside."""
    total = 0.0
    corners = []
    for cx, cy, ang, s in sqs:
        total += s
        corners.append(_corners(cx, cy, ang, s))
    pen = 0.0
    for i in range(len(sqs)):
        # outside
        for x, y in corners[i]:
            if x < 0.0:
                pen += x * x
            elif x > 1.0:
                pen += (x - 1.0) ** 2
            if y < 0.0:
                pen += y * y
            elif y > 1.0:
                pen += (y - 1.0) ** 2
        for j in range(i + 1, len(sqs)):
            o = _overlap(corners[i], corners[j], sqs[i][3], sqs[j][3])
            if o > 0:
                pen += o * o + o  # encourage full separation
    return total - 50.0 * pen


def solve(n):
    if n == 0:
        return []
    # --- initial feasible packing: greedy grid of floor(sqrt(n)) ---
    k = math.isqrt(n)
    side = 1.0 / k
    sqs = [[(i + 0.5) * side, (j + 0.5) * side, 0.0, side]
           for i in range(k) for j in range(k)]
    while len(sqs) < n:
        sqs.append([0.5, 0.5, 0.0, 0.0])
    sqs = sqs[:n]

    rng = random.Random(12345 + n)
    cur = [list(s) for s in sqs]
    cur_val = _penalty(cur)

    # scale of perturbations shrinks over time
    best = [list(s) for s in cur]
    best_val = cur_val

    steps = 40000
    for t in range(steps):
        frac = t / steps
        scale = (1.0 - frac) ** 2
        # pick a random square and perturb
        i = rng.randrange(n)
        old = cur[i][:]
        cur[i][0] += rng.uniform(-1, 1) * 0.08 * scale
        cur[i][1] += rng.uniform(-1, 1) * 0.08 * scale
        cur[i][2] += rng.uniform(-1, 1) * 0.05 * scale
        cur[i][3] += rng.uniform(-1, 1) * 0.06 * scale
        if cur[i][3] < 0:
            cur[i][3] = 0.0
        # occasionally try to grow the smallest square a lot
        if rng.random() < 0.1:
            i2 = rng.randrange(n)
            cur[i2][3] += 0.02 * scale

        new_val = _penalty(cur)
        if new_val > cur_val or rng.random() < math.exp(min(0.0, (new_val - cur_val) / 0.02)):
            cur_val = new_val
            if new_val > best_val:
                best_val = new_val
                best = [list(s) for s in cur]
        else:
            cur[i] = old

    # clamp to [0,1] and return
    out = []
    for cx, cy, ang, s in best:
        out.append((min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0),
                    min(max(ang, 0.0), 1.0), min(max(s, 0.0), 1.0)))
    return out
# EVOLVE-BLOCK-END
