# EVOLVE-BLOCK-START
"""Many diverse seeds + exact grow-to-max polish + light local refinement."""
import math
import random

# -------------------- exact overlap test for two rotated squares --------------------

def _corners(cx, cy, ang, s):
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    return [
        (cx + c * (-h) - sn * (-h), cy + sn * (-h) + c * (-h)),
        (cx + c * (h) - sn * (-h), cy + sn * (h) + c * (-h)),
        (cx + c * (h) - sn * (h), cy + sn * (h) + c * (h)),
        (cx + c * (-h) - sn * (h), cy + sn * (-h) + c * (h)),
    ]


def _axes(ang):
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    return (c, sn), (-sn, c)


def _project(pts, ax):
    ax_, ay_ = ax
    vals = [p[0] * ax_ + p[1] * ay_ for p in pts]
    return min(vals), max(vals)


def _overlap(a, b):
    ax1 = _axes(a[2])
    ax2 = _axes(b[2])
    pa = _corners(*a)
    pb = _corners(*b)
    EPS = 1e-12
    for ax in (ax1[0], ax1[1], ax2[0], ax2[1]):
        lo1, hi1 = _project(pa, ax)
        lo2, hi2 = _project(pb, ax)
        if hi1 <= lo2 + EPS or hi2 <= lo1 + EPS:
            return False
    return True


def _inside(cx, cy, ang, s):
    for x, y in _corners(cx, cy, ang, s):
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _ok(sq, others):
    for o in others:
        if _overlap(sq, o):
            return False
    return True


def _max_side(cx, cy, ang, others, hi_init=2.0):
    """Binary search the largest side <= hi_init that keeps square inside & disjoint."""
    if not _inside(cx, cy, ang, 0.0):
        return 0.0
    lo, hi = 0.0, hi_init
    if _inside(cx, cy, ang, hi) and _ok((cx, cy, ang, hi), others):
        return hi
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        if _inside(cx, cy, ang, mid) and _ok((cx, cy, ang, mid), others):
            lo = mid
        else:
            hi = mid
    return lo


# -------------------- constructions --------------------

def _guillotine(n, size_seed, rng, jitter=0.0):
    """Recursive guillotine: split rect by count proportion, sizes proportional to rect."""
    squares = []

    def rec(x0, y0, x1, y1, cnt, depth):
        if cnt <= 0:
            return
        w, h = x1 - x0, y1 - y0
        if cnt == 1:
            s = min(w, h) * (0.6 + 0.4 * rng.random()) + jitter * rng.random()
            s = min(s, min(w, h))
            squares.append([(x0 + x1) * 0.5, (y0 + y1) * 0.5, 0.0, max(0.0, s)])
            return
        # decide orientation & split
        horiz = w >= h if rng.random() < 0.5 else h >= w
        k1 = max(1, cnt // 2)
        if rng.random() < 0.5:
            k1 = rng.randint(1, cnt - 1)
        k2 = cnt - k1
        fr = math.sqrt(k1) / (math.sqrt(k1) + math.sqrt(k2))
        fr = min(max(fr + jitter * (rng.random() - 0.5), 0.15), 0.85)
        if horiz:
            xm = x0 + w * fr
            rec(x0, y0, xm, y1, k1, depth + 1)
            rec(xm, y0, x1, y1, k2, depth + 1)
        else:
            ym = y0 + h * fr
            rec(x0, y0, x1, ym, k1, depth + 1)
            rec(x0, ym, x1, y1, k2, depth + 1)

    rec(0.0, 0.0, 1.0, 1.0, n, 0)
    return squares


def _grid_seed(n, rng):
    """Max-min uniform grid of squares."""
    cols = int(math.ceil(math.sqrt(n)))
    rows = int(math.ceil(n / cols))
    s = 1.0 / max(cols, rows)
    squares = []
    k = 0
    for r in range(rows):
        for c in range(cols):
            if k >= n:
                break
            squares.append([(c + 0.5) * s, (r + 0.5) * s, 0.0, s * 0.999])
            k += 1
    return squares


def _spiral_seed(n, rng):
    """Place squares in a spiral from a corner, each sized greedily to fit."""
    S = []
    for i in range(n):
        # sample candidate placements
        best = None
        for _ in range(40):
            s_try = rng.uniform(0.0, 1.0) * (1.0 / max(1, math.isqrt(n)))
            cx = rng.random()
            cy = rng.random()
            ang = rng.choice([0.0, 0.25, 0.125, 0.375])
            if _inside(cx, cy, ang, s_try) and _ok((cx, cy, ang, s_try), S):
                if best is None or s_try > best[3]:
                    best = [cx, cy, ang, s_try]
        if best is None:
            best = [0.5, 0.5, 0.0, 0.0]
        S.append(best)
    return S


# -------------------- polish --------------------

def _polish(squares, n, rng, sweeps=6):
    S = [list(s) for s in squares]
    while len(S) < n:
        S.append([0.5, 0.5, 0.0, 0.0])
    S = S[:n]
    for _ in range(sweeps):
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, _ = S[i]
            others = S[:i] + S[i + 1:]
            ns = _max_side(cx, cy, ang, others)
            S[i] = [cx, cy, ang, ns]
    return S


# -------------------- local search --------------------

def _local_search(squares, n, rng, iters=1500):
    S = [list(s) for s in squares]
    if len(S) < n:
        S += [[0.5, 0.5, 0.0, 0.0]] * (n - len(S))
    S = S[:n]

    for it in range(iters):
        i = rng.randrange(n)
        old = S[i][:]
        mode = rng.random()
        if mode < 0.5:
            factor = rng.uniform(0.9, 1.4)
            cand = [old[0], old[1], old[2], max(0.0, old[3] * factor)]
        elif mode < 0.8:
            d = old[3] * 0.5 + 0.05
            cand = [old[0] + rng.uniform(-d, d), old[1] + rng.uniform(-d, d), old[2], old[3]]
        else:
            cand = [old[0], old[1], (old[2] + rng.uniform(-0.25, 0.25)) % 1.0, old[3]]
        cand[0] = min(max(cand[0], 0.0), 1.0)
        cand[1] = min(max(cand[1], 0.0), 1.0)
        if cand[3] <= 1e-12:
            cand[3] = 0.0
        if not _inside(cand[0], cand[1], cand[2], cand[3]):
            continue
        others = S[:i] + S[i + 1:]
        if not _ok(cand, others):
            continue
        if cand[3] >= old[3] - 1e-12 or rng.random() < 0.02:
            S[i] = cand
    return S


# -------------------- main solve --------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    best = None
    best_score = -1.0

    def consider(seed, r):
        S = _polish(seed, n, r, sweeps=5)
        S = _local_search(S, n, r, iters=800)
        S = _polish(S, n, r, sweeps=3)
        sc = sum(s[3] for s in S)
        return S, sc

    seeds = []
    # grid seed
    seeds.append(_grid_seed(n, rng))
    # spiral seeds
    for _ in range(4):
        seeds.append(_spiral_seed(n, random.Random(rng.randrange(10**9))))
    # guillotine seeds with varied jitter
    for jit in (0.0, 0.05, 0.1, 0.2, 0.3):
        for _ in range(3):
            r = random.Random(rng.randrange(10**9))
            seeds.append(_guillotine(n, None, r, jitter=jit))

    for si, seed in enumerate(seeds):
        r = random.Random(999 + 7 * n + si)
        S, sc = consider(seed, r)
        if sc > best_score:
            best_score = sc
            best = S

    # restarts from best
    for att in range(6):
        r = random.Random(4242 + 17 * n + att)
        S = [list(s) for s in best]
        # perturb
        for _ in range(n):
            i = r.randrange(n)
            S[i][0] = min(max(S[i][0] + r.uniform(-0.05, 0.05), 0.0), 1.0)
            S[i][1] = min(max(S[i][1] + r.uniform(-0.05, 0.05), 0.0), 1.0)
        S, sc = consider(S, r)
        if sc > best_score:
            best_score = sc
            best = S

    # safety repair
    out = []
    for cx, cy, a, s in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        guard = 0
        while not _inside(cx, cy, a, s) and s > 1e-9 and guard < 50:
            s *= 0.9
            guard += 1
        if s < 1e-9:
            s = 0.0
        out.append((cx, cy, a, s))

    changed = True
    guard = 0
    while changed and guard < 200:
        changed = False
        for i in range(len(out)):
            for j in range(i + 1, len(out)):
                if _overlap(out[i], out[j]):
                    a, b = out[i], out[j]
                    if a[3] >= b[3]:
                        out[j] = (b[0], b[1], b[2], b[3] * 0.8)
                    else:
                        out[i] = (a[0], a[1], a[2], a[3] * 0.8)
                    changed = True
        guard += 1

    return out[:n]
# EVOLVE-BLOCK-END
