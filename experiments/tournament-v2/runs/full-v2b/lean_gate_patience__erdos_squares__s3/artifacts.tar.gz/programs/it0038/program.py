# EVOLVE-BLOCK-START
"""Recursive guillotine construction + randomized local search for packing squares.

Approach:
  1. Build a guillotine packing of axis-aligned squares inside the unit square.
     Recursively split a rectangle into two sub-rectangles, assign squares to each
     part proportional to area, always keeping squares axis-aligned first.
  2. Local search: repeatedly pick a square, try to grow it / shift it / rotate it,
     accepting moves that keep sums increasing and interiors disjoint (checked via
     exact separating-axis test on rotated squares).
"""
import math
import random

# -------------------- exact overlap test for two rotated squares --------------------

def _corners(cx, cy, ang, s):
    """Return 4 corners of a square (centre, angle fraction of turn, side)."""
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + c * dx - sn * dy, cy + sn * dx + c * dy))
    return pts


def _axes(ang):
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    return (c, sn), (-sn, c)


def _project(pts, ax):
    ax_, ay_ = ax
    vals = [p[0] * ax_ + p[1] * ay_ for p in pts]
    return min(vals), max(vals)


def _overlap(a, b):
    """True if interiors of two squares (cx,cy,ang,s) overlap. Touching is OK."""
    ax1 = _axes(a[2])
    ax2 = _axes(b[2])
    pa = _corners(*a)
    pb = _corners(*b)
    EPS = 1e-12
    for ax in (ax1[0], ax1[1], ax2[0], ax2[1]):
        lo1, hi1 = _project(pa, ax)
        lo2, hi2 = _project(pb, ax)
        if hi1 <= lo2 + EPS or hi2 <= lo1 + EPS:
            return False
    return True


def _inside(cx, cy, ang, s):
    for x, y in _corners(cx, cy, ang, s):
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _ok(sq, others):
    for o in others:
        if _overlap(sq, o):
            return False
    return True


# -------------------- guillotine construction --------------------

def _guillotine(rects, depths):
    """rects: list of (x0,y0,x1,y1, weight). Returns squares list."""
    # Greedy recursive implicit: sort by target side descending, pack by free-rect stack.
    # Use simple free-rectangle bin method (like a shelf/guillotine hybrid).
    squares = []
    for x0, y0, x1, y1, target in rects:
        w, h = x1 - x0, y1 - y0
        s = min(target, min(w, h))
        if s <= 1e-12:
            continue
        cx = x0 + s * 0.5
        cy = y0 + s * 0.5
        squares.append((cx, cy, 0.0, s))
        # split remaining of this rect: right strip + top strip
        if w - s > 1e-9:
            rects.append((x0 + s, y0, x1, y1, s))  # placeholder, weight handled later
        if h - s > 1e-9:
            rects.append((x0, y0 + s, x0 + s, y1, s))
    return squares


def _construct(n):
    """Build n axis-aligned squares via recursive area-proportional splitting."""
    if n == 0:
        return []
    # Start: overall square. We want sum of sides ~ maximised, so use a
    # recursive scheme: pick a cut position; assign k1 squares to one part,
    # n-k1 to the other; target side for each part ~ sqrt(area/ (k in part))?
    # Simpler: recursive bisection splitting by count, sizes proportional to sqrt area.
    squares = []

    def rec(x0, y0, x1, y1, cnt):
        if cnt <= 0:
            return
        w, h = x1 - x0, y1 - y0
        if cnt == 1:
            s = min(w, h) * 0.98
            squares.append((x0 + w * 0.5, y0 + h * 0.5, 0.0, s))
            return
        # split along longer dimension
        if w >= h:
            # choose k1 ~ half but tuned by aspect
            k1 = max(1, cnt // 2)
            k2 = cnt - k1
            # split proportionally to sqrt(k1)/sqrt(n)
            fr = math.sqrt(k1) / (math.sqrt(k1) + math.sqrt(k2))
            fr = min(max(fr, 0.2), 0.8)
            xm = x0 + w * fr
            rec(x0, y0, xm, y1, k1)
            rec(xm, y0, x1, y1, k2)
        else:
            k1 = max(1, cnt // 2)
            k2 = cnt - k1
            fr = math.sqrt(k1) / (math.sqrt(k1) + math.sqrt(k2))
            fr = min(max(fr, 0.2), 0.8)
            ym = y0 + h * fr
            rec(x0, y0, x1, ym, k1)
            rec(x0, ym, x1, y1, k2)

    rec(0.0, 0.0, 1.0, 1.0, n)
    return squares


# -------------------- local search --------------------

def _local_search(squares, n, rng, iters=4000, time_guard=None):
    # make into list of lists for mutability
    S = [list(s) for s in squares]
    if len(S) < n:
        S += [[0.5, 0.5, 0.0, 0.0]] * (n - len(S))
    S = S[:n]

    def score():
        return sum(s[3] for s in S)

    for it in range(iters):
        i = rng.randrange(n)
        if S[i][3] <= 0 and rng.random() < 0.5:
            # try to seed a zero square somewhere
            cand = [rng.random(), rng.random(), rng.random(), rng.uniform(0.0, 1.0 / max(1, math.isqrt(n)))]
        else:
            old = S[i][:]
            mode = rng.random()
            if mode < 0.5:
                # grow / shrink
                factor = rng.uniform(0.85, 1.6)
                cand = [old[0], old[1], old[2], max(0.0, old[3] * factor)]
            elif mode < 0.8:
                # translate
                d = old[3] * 0.6 + 0.05
                cand = [old[0] + rng.uniform(-d, d),
                        old[1] + rng.uniform(-d, d),
                        old[2], old[3]]
            else:
                # rotate
                cand = [old[0], old[1], (old[2] + rng.uniform(-0.25, 0.25)) % 1.0, old[3]]
        # clamp center
        cand[0] = min(max(cand[0], 0.0), 1.0)
        cand[1] = min(max(cand[1], 0.0), 1.0)
        if cand[3] <= 1e-12:
            cand[3] = 0.0
            cand[0] = min(max(cand[0], 0.0), 1.0)
            cand[1] = min(max(cand[1], 0.0), 1.0)
            if not _inside(cand[0], cand[1], cand[2], cand[3]):
                continue
        else:
            if not _inside(cand[0], cand[1], cand[2], cand[3]):
                continue
        others = S[:i] + S[i + 1:]
        if not _ok(cand, others):
            continue
        old_val = S[i][3]
        new_val = cand[3]
        # accept growth always, otherwise accept with small prob (annealing-lite)
        if new_val >= old_val - 1e-12:
            S[i] = cand
        else:
            if rng.random() < 0.02:
                S[i] = cand

    return [tuple(s) for s in S]


# -------------------- main solve --------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    best = None
    best_score = -1.0
    attempts = 3
    for att in range(attempts):
        base = _construct(n)
        r = random.Random(98765 + 13 * n + att)
        cand = _local_search(base, n, r, iters=3000)
        sc = sum(s[3] for s in cand)
        if sc > best_score:
            best_score = sc
            best = cand

    # final polish: a few more grow passes
    r = random.Random(555 + n)
    best = _local_search(best, n, r, iters=2000)

    # ensure all inside (safety clamp, shrink slightly if needed)
    out = []
    for cx, cy, a, s in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        # shrink if not inside
        guard = 0
        while not _inside(cx, cy, a, s) and s > 1e-9 and guard < 50:
            s *= 0.9
            guard += 1
        if s < 1e-9:
            s = 0.0
        out.append((cx, cy, a, s))

    # final overlap repair: if any overlap, shrink the smaller one
    changed = True
    guard = 0
    while changed and guard < 200:
        changed = False
        for i in range(len(out)):
            for j in range(i + 1, len(out)):
                if _overlap(out[i], out[j]):
                    a, b = out[i], out[j]
                    if a[3] >= b[3]:
                        out[j] = (b[0], b[1], b[2], b[3] * 0.8)
                    else:
                        out[i] = (a[0], a[1], a[2], a[3] * 0.8)
                    changed = True
        guard += 1

    return out[:n]
# EVOLVE-BLOCK-END
