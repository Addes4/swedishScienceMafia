# EVOLVE-BLOCK-START
"""Squares in a square: grid/shelf construction + randomized local search."""
import math
import random

PI = math.pi


def _corners(cx, cy, ang, s):
    a = ang * 2.0 * PI
    c = math.cos(a)
    sn = math.sin(a)
    h = 0.5 * s
    ux, uy = c * h, sn * h
    vx, vy = -sn * h, c * h
    return [
        (cx + ux + vx, cy + uy + vy),
        (cx + ux - vx, cy + uy - vy),
        (cx - ux - vx, cy - uy - vy),
        (cx - ux + vx, cy - uy + vy),
    ]


def _overlap_pair(c1, c2, eps=1e-12):
    for poly in (c1, c2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            nx, ny = -ey, ex
            nlen = math.hypot(nx, ny)
            if nlen < eps:
                continue
            nx /= nlen
            ny /= nlen
            min1 = min(p[0] * nx + p[1] * ny for p in c1)
            max1 = max(p[0] * nx + p[1] * ny for p in c1)
            min2 = min(p[0] * nx + p[1] * ny for p in c2)
            max2 = max(p[0] * nx + p[1] * ny for p in c2)
            if max1 <= min2 + eps or max2 <= min1 + eps:
                return False
    return True


def _inside_unit(cs, eps=1e-9):
    for x, y in cs:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _valid(squares):
    n = len(squares)
    corners = []
    for (cx, cy, ang, s) in squares:
        cs = _corners(cx, cy, ang, s)
        if not _inside_unit(cs):
            return False
        corners.append(cs)
    for i in range(n):
        if squares[i][3] <= 0.0:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 0.0:
                continue
            if _overlap_pair(corners[i], corners[j]):
                return False
    return True


def _score(squares):
    return sum(sq[3] for sq in squares)


def _make_solution():
    return []


# ---------- constructors ----------

def _grid_pack(n):
    """Try all rows x cols grids (axis aligned), keep best score."""
    best = None
    best_sc = -1.0
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        # side limited by cell size
        w = 1.0 / cols
        h = 1.0 / rows
        s = min(w, h)
        # cells filled row-major
        sq = []
        cnt = 0
        for r in range(rows):
            for c in range(cols):
                if cnt >= n:
                    break
                cx = (c + 0.5) * w
                cy = (r + 0.5) * h
                sq.append((cx, cy, 0.0, s))
                cnt += 1
            if cnt >= n:
                break
        sq = sq[:n]
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        if _valid(sq):
            sc = _score(sq)
            if sc > best_sc:
                best_sc = sc
                best = sq
    return best if best is not None else [(0.5, 0.5, 0.0, s) for _ in range(n)]


def _bigrow_shelf(n):
    """k big squares in a row at bottom + shelf strip above for the rest."""
    best = None
    best_sc = -1.0
    for k in range(1, n + 1):
        rem = n - k
        s = 1.0 / k  # side of big squares filling the bottom row
        # shelf height
        if rem == 0:
            h = 0.0
        else:
            # crude: pack rem equal squares in the strip height h; need h*cols
            c = math.ceil(math.sqrt(rem))
            h = 1.0 / c
        sq = []
        for i in range(k):
            sq.append(((i + 0.5) * s, 0.5 * s, 0.0, s))
        if rem > 0:
            c = math.ceil(math.sqrt(rem))
            rs = min(1.0 / c, h)
            cnt = 0
            for r in range(math.ceil(rem / c)):
                for cc in range(c):
                    if cnt >= rem:
                        break
                    cx = (cc + 0.5) * (1.0 / c)
                    cy = 1.0 - h + (r + 0.5) * h
                    sq.append((cx, cy, 0.0, rs))
                    cnt += 1
                if cnt >= rem:
                    break
        sq = sq[:n]
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        if _valid(sq):
            sc = _score(sq)
            if sc > best_sc:
                best_sc = sc
                best = sq
    return best if best is not None else _grid_pack(n)


def _pack_equal(n, t, tries=1):
    """Try to place n equal axis-aligned squares of side t using a grid."""
    # pure grid only works if k*k cells fit t
    k = math.isqrt(n)
    if (k * k >= n) and (k * t <= 1.0 + 1e-12):
        sq = []
        cnt = 0
        for r in range(k):
            for c in range(k):
                if cnt >= n:
                    break
                sq.append(((c + 0.5) * t, (r + 0.5) * t, 0.0, t))
                cnt += 1
            if cnt >= n:
                break
        return sq[:n]
    return None


def _maxmin_seed(n):
    """Binary-search max equal side t for which a grid packing fits n squares."""
    lo, hi = 0.0, 1.0
    best = None
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        sq = _pack_equal(n, mid)
        if sq is not None and _valid(sq):
            best = sq
            lo = mid
        else:
            hi = mid
    if best is None:
        return _grid_pack(n)
    return best


# ---------- improvement moves ----------

def _grow_all(squares, passes=60):
    """Repeatedly try to grow each square in place; keep if valid & better."""
    sq = list(squares)
    n = len(sq)
    for _ in range(passes):
        improved = False
        order = list(range(n))
        random.shuffle(order)
        for i in order:
            cx, cy, ang, s = sq[i]
            cur_sc = _score(sq)
            # exponential search for max grow
            lo, hi = 0.0, 1.0
            best_s = s
            for _ in range(20):
                mid = 0.5 * (lo + hi)
                trial = list(sq)
                trial[i] = (cx, cy, ang, mid)
                if _valid(trial):
                    lo = mid
                    best_s = mid
                else:
                    hi = mid
            if best_s > s + 1e-9:
                sq[i] = (cx, cy, ang, best_s)
                improved = True
        if not improved:
            break
    return sq


def _local_search(n, squares, iters=20000):
    if n == 0:
        return squares
    best = list(squares)
    best_score = _score(best)
    cur = list(best)
    cur_score = best_score
    no_improve = 0
    for _ in range(iters):
        i = random.randrange(n)
        cx, cy, ang, s = cur[i]
        move = random.random()
        if move < 0.45:
            ds = random.uniform(0.0, 0.03)
            nc = (cx, cy, ang, min(1.0, s + ds))
        elif move < 0.75:
            a = random.random() * 2 * PI
            d = random.uniform(0.0, 0.02)
            nc = (min(1.0, max(0.0, cx + math.cos(a) * d)),
                  min(1.0, max(0.0, cy + math.sin(a) * d)), ang, s)
        elif move < 0.85:
            nc = (cx, cy, (ang + random.uniform(-0.15, 0.15)) % 1.0, s)
        else:
            # relocate: try a few random free spots with current size
            bx, by = cx, cy
            bfs = s
            for _ in range(8):
                tx = random.random()
                ty = random.random()
                trial = list(cur)
                trial[i] = (tx, ty, ang, s)
                if _valid(trial) and _score(trial) >= cur_score:
                    bx, by = tx, ty
                    break
            nc = (bx, by, ang, s)
        old = cur[i]
        cur[i] = nc
        if _valid(cur):
            sc = _score(cur)
            if sc >= cur_score - 1e-12:
                cur_score = sc
                if sc > best_score:
                    best_score = sc
                    best = list(cur)
                no_improve = 0
            elif random.random() < 0.03:
                cur_score = sc
                no_improve += 1
            else:
                cur[i] = old
                no_improve += 1
        else:
            cur[i] = old
            no_improve += 1
        if no_improve > 4000:
            cur = list(best)
            k = random.randrange(n)
            cx, cy, ang, s = cur[k]
            a = random.random() * 2 * PI
            d = random.uniform(0.0, 0.02)
            cur[k] = (min(1.0, max(0.0, cx + math.cos(a) * d)),
                      min(1.0, max(0.0, cy + math.sin(a) * d)), ang, s)
            if not _valid(cur):
                cur = list(best)
            cur_score = _score(cur)
            no_improve = 0
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = [_grid_pack(n), _bigrow_shelf(n), _maxmin_seed(n)]
    seeds = [c for c in candidates if c is not None and _valid(c)]
    if not seeds:
        seeds = [_grid_pack(n)]

    iters = 6000 if n <= 10 else (12000 if n <= 50 else 8000)
    best = None
    best_sc = -1.0
    random.shuffle(seeds)
    for seed in seeds:
        cand = _grow_all(seed)
        cand = _local_search(n, cand, iters=iters)
        cand = _grow_all(cand)
        if _valid(cand):
            sc = _score(cand)
            if sc > best_sc:
                best_sc = sc
                best = cand
    if best is None:
        best = _grid_pack(n)

    # final safety
    if not _valid(best):
        result = []
        for sq in best:
            if _valid(result + [sq]):
                result.append(sq)
            else:
                result.append((0.5, 0.5, 0.0, 0.0))
        best = result
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
# EVOLVE-BLOCK-END
