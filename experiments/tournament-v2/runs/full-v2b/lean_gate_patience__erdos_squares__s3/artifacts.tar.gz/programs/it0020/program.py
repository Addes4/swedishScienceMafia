# EVOLVE-BLOCK-START
"""Squares in a square: guillotine construction + randomized local search."""
import math
import random

PI = math.pi


def _corners(cx, cy, ang, s):
    """Return the 4 corners of a square as (x, y) points."""
    a = ang * 2.0 * PI
    c = math.cos(a)
    sn = math.sin(a)
    h = 0.5 * s
    # local axes
    ux, uy = c * h, sn * h
    vx, vy = -sn * h, c * h
    return [
        (cx + ux + vx, cy + uy + vy),
        (cx + ux - vx, cy + uy - vy),
        (cx - ux - vx, cy - uy - vy),
        (cx - ux + vx, cy - uy + vy),
    ]


def _overlap_pair(c1, c2, eps=1e-12):
    """Return True if two convex polygons (lists of points) overlap in positive area."""
    # separating axis theorem
    for poly in (c1, c2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            # normal
            nx, ny = -ey, ex
            nlen = math.hypot(nx, ny)
            if nlen < eps:
                continue
            nx /= nlen
            ny /= nlen
            min1 = min(p[0] * nx + p[1] * ny for p in c1)
            max1 = max(p[0] * nx + p[1] * ny for p in c1)
            min2 = min(p[0] * nx + p[1] * ny for p in c2)
            max2 = max(p[0] * nx + p[1] * ny for p in c2)
            if max1 <= min2 + eps or max2 <= min1 + eps:
                return False
    return True


def _inside_unit(cs, eps=1e-9):
    for x, y in cs:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _valid(squares):
    """Check all squares inside unit square and pairwise non-overlapping."""
    n = len(squares)
    corners = []
    for (cx, cy, ang, s) in squares:
        cs = _corners(cx, cy, ang, s)
        if not _inside_unit(cs):
            return False
        corners.append(cs)
    for i in range(n):
        if squares[i][3] <= 0.0:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 0.0:
                continue
            if _overlap_pair(corners[i], corners[j]):
                return False
    return True


def _guillotine(sizes, x0, y0, w, h, out):
    """Recursively place axis-aligned squares of sizes list into rect (x0,y0,w,h)."""
    if not sizes:
        return
    if len(sizes) == 1:
        s = sizes[0]
        side = min(s, w, h)
        cx = x0 + w / 2.0
        cy = y0 + h / 2.0
        out.append((cx, cy, 0.0, side))
        return
    # choose split that best separates sizes
    sizes = sorted(sizes, reverse=True)
    total = sum(sizes)
    acc = 0.0
    split_idx = 1
    best = None
    for k in range(1, len(sizes)):
        acc += sizes[k - 1]
        frac = acc / total
        # try vertical split at width frac*w
        err = abs(frac * w - max(sizes[:k])) + abs((1 - frac) * w - max(sizes[k:]))
        if best is None or err < best:
            best = err
            split_idx = k
            split_frac = frac
            vertical = True
    for k in range(1, len(sizes)):
        acc2 = sum(sizes[:k]) / total
        err = abs(acc2 * h - max(sizes[:k])) + abs((1 - acc2) * h - max(sizes[k:]))
        if err < best:
            best = err
            split_idx = k
            split_frac = acc2
            vertical = False
    left = sizes[:split_idx]
    right = sizes[split_idx:]
    if vertical:
        wl = split_frac * w
        _guillotine(left, x0, y0, wl, h, out)
        _guillotine(right, x0 + wl, y0, w - wl, h, out)
    else:
        hl = split_frac * h
        _guillotine(left, x0, y0, w, hl, out)
        _guillotine(right, x0, y0 + hl, w, h - hl, out)


def _construct(n):
    """Produce an initial list of n squares via guillotine packing."""
    if n == 0:
        return []
    # start with rough equal squares, use guillotine to pack them
    # estimate side of equal squares
    s = math.sqrt(1.0 / max(n, 1))
    # use slightly varied initial sizes to help guillotine
    base_sizes = [s for _ in range(n)]
    out = []
    _guillotine(base_sizes, 0.0, 0.0, 1.0, 1.0, out)
    # ensure exact count
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _score(squares):
    return sum(sq[3] for sq in squares)


def _random_dir(scale):
    ang = random.random() * 2 * PI
    return math.cos(ang) * scale, math.sin(ang) * scale


def _local_search(n, squares, time_budget_iters=20000):
    best = list(squares)
    best_score = _score(best)
    cur = list(best)
    cur_score = best_score
    it = 0
    no_improve = 0
    # adaptive temperature
    while it < time_budget_iters:
        it += 1
        i = random.randrange(n)
        cx, cy, ang, s = cur[i]
        move = random.random()
        if move < 0.5:
            # grow square
            ds = random.uniform(0.0, 0.02) * (1.0 + random.random())
            ns = s + ds
            # keep inside roughly
            if ns > 1.0:
                ns = 1.0
            nc = (cx, cy, ang, ns)
        elif move < 0.8:
            # translate
            dx, dy = _random_dir(random.uniform(0.0, 0.01))
            nx = min(1.0, max(0.0, cx + dx))
            ny = min(1.0, max(0.0, cy + dy))
            nc = (nx, ny, ang, s)
        else:
            # rotate
            na = (ang + random.uniform(-0.1, 0.1)) % 1.0
            nc = (cx, cy, na, s)
        old = cur[i]
        cur[i] = nc
        if _valid(cur):
            sc = _score(cur)
            if sc > cur_score - 1e-12:
                cur_score = sc
                if sc > best_score:
                    best_score = sc
                    best = list(cur)
                no_improve = 0
            else:
                # accept worse occasionally (simulated annealing style)
                if random.random() < 0.05:
                    cur_score = sc
                else:
                    cur[i] = old
                    no_improve += 1
        else:
            cur[i] = old
            no_improve += 1
        if no_improve > 5000:
            # random restart perturbation
            cur = list(best)
            for _ in range(max(1, n // 5)):
                k = random.randrange(n)
                cx, cy, ang, s = cur[k]
                dx, dy = _random_dir(0.01)
                cur[k] = (min(1.0, max(0.0, cx + dx)), min(1.0, max(0.0, cy + dy)), ang, s)
            if not _valid(cur):
                cur = list(best)
            cur_score = _score(cur)
            no_improve = 0
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    squares = _construct(n)
    if not _valid(squares):
        # fallback: grid layout
        k = math.isqrt(n)
        ss = 1.0 / k
        squares = [((i + 0.5) * ss, (j + 0.5) * ss, 0.0, ss) for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        squares = squares[:n]
    # limit local search effort based on n
    iters = 8000 if n <= 10 else (12000 if n <= 50 else 6000)
    squares = _local_search(n, squares, time_budget_iters=iters)
    if not _valid(squares):
        # ensure valid by zeroing problematic squares
        result = []
        for sq in squares:
            trial = result + [sq]
            if _valid(trial):
                result.append(sq)
            else:
                result.append((0.5, 0.5, 0.0, 0.0))
        squares = result
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
# EVOLVE-BLOCK-END
