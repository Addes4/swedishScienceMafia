# EVOLVE-BLOCK-START
"""Recursive guillotine construction + placement-based local search for squares.

Approach:
  1. Build guillotine packings of axis-aligned squares inside the unit square.
  2. Placement polish: remove the smallest squares and reinsert each at the
     best feasible placement found by a structural candidate set (corners of
     the box and of each other square, plus grid/jitter points) crossed with
     many angle candidates, each evaluated with an exact binary search on the
     feasible side using the SAT overlap test.
  3. Grow-to-max sweeps in random order to convergence.
"""
import math
import random

# -------------------- exact overlap test for two rotated squares --------------------

def _corners(cx, cy, ang, s):
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    return [
        (cx + c * (-h) - sn * (-h), cy + sn * (-h) + c * (-h)),
        (cx + c * ( h) - sn * (-h), cy + sn * ( h) + c * (-h)),
        (cx + c * ( h) - sn * ( h), cy + sn * ( h) + c * ( h)),
        (cx + c * (-h) - sn * ( h), cy + sn * (-h) + c * ( h)),
    ]


def _axes(ang):
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    return (c, sn), (-sn, c)


def _project(pts, ax):
    ax_, ay_ = ax
    vals = [p[0] * ax_ + p[1] * ay_ for p in pts]
    return min(vals), max(vals)


def _overlap(a, b):
    """True if interiors of two squares (cx,cy,ang,s) overlap. Touching is OK."""
    ax1 = _axes(a[2])
    ax2 = _axes(b[2])
    pa = _corners(*a)
    pb = _corners(*b)
    EPS = 1e-12
    for ax in (ax1[0], ax1[1], ax2[0], ax2[1]):
        lo1, hi1 = _project(pa, ax)
        lo2, hi2 = _project(pb, ax)
        if hi1 <= lo2 + EPS or hi2 <= lo1 + EPS:
            return False
    return True


def _inside(cx, cy, ang, s):
    for x, y in _corners(cx, cy, ang, s):
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _ok(sq, others):
    for o in others:
        if _overlap(sq, o):
            return False
    return True


# -------------------- feasible-side helpers --------------------

def _inside_max_side(cx, cy, ang, hi):
    """Largest s <= hi with (cx,cy,ang,s) inside the unit box."""
    if _inside(cx, cy, ang, hi):
        return hi
    l, h = 0.0, hi
    for _ in range(40):
        m = 0.5 * (l + h)
        if _inside(cx, cy, ang, m):
            l = m
        else:
            h = m
    return l


def _max_side_at(cx, cy, ang, others, hi=1.0):
    """Largest s such that square (cx,cy,ang,s) is inside and non-overlapping."""
    hi = _inside_max_side(cx, cy, ang, hi)
    if hi <= 1e-12:
        return 0.0
    if _ok((cx, cy, ang, hi), others):
        return hi
    l, h = 0.0, hi
    for _ in range(40):
        m = 0.5 * (l + h)
        if _ok((cx, cy, ang, m), others):
            l = m
        else:
            h = m
    return l


# -------------------- structural candidate placement search --------------------

_ANGLES = [0.0, 0.25, 0.125, 0.375, 0.5,
           0.0625, 0.1875, 0.3125, 0.4375, 0.5625]


def _structural_candidates(others):
    """Candidate (cx, cy) derived from the box and the corners/edges of others."""
    cands = set()
    # box-related seeds
    for gx in (0.0, 0.25, 0.5, 0.75, 1.0):
        for gy in (0.0, 0.25, 0.5, 0.75, 1.0):
            cands.add((gx, gy))
    for o in others:
        s = o[3]
        if s <= 0:
            continue
        cs = _corners(*o)
        for px, py in cs:
            # slightly inside the corner
            cands.add((min(max(px, 0.0), 1.0), min(max(py, 0.0), 1.0)))
            cands.add((min(max(px - s * 0.5, 0.0), 1.0),
                       min(max(py - s * 0.5, 0.0), 1.0)))
            cands.add((min(max(px + s * 0.5, 0.0), 1.0),
                       min(max(py - s * 0.5, 0.0), 1.0)))
            cands.add((min(max(px - s * 0.5, 0.0), 1.0),
                       min(max(py + s * 0.5, 0.0), 1.0)))
            cands.add((min(max(px + s * 0.5, 0.0), 1.0),
                       min(max(py + s * 0.5, 0.0), 1.0)))
    return list(cands)


def _best_insert(others, rng, tries=40):
    """Find a placement with the largest feasible side."""
    best = None
    best_s = -1.0

    cands = _structural_candidates(others)
    # add random jittered centres
    for _ in range(tries):
        cands.append((rng.random(), rng.random()))

    # angles: structural set
    angles = list(_ANGLES)
    for _ in range(6):
        angles.append(rng.random())

    for cx, cy in cands:
        for ang in angles:
            s = _max_side_at(cx, cy, ang, others)
            if s > best_s:
                best_s = s
                best = (cx, cy, ang, s)
    return best


def _refine_insert(cand, others, rng, iters=60):
    """Coordinate-descent style refinement of (cx,cy,ang) to grow s."""
    cx, cy, ang, s = cand
    step = max(s, 0.02) * 0.3
    for _ in range(iters):
        improved = False
        for dcx, dcy, dang in (
            (step, 0, 0), (-step, 0, 0), (0, step, 0), (0, -step, 0),
            (0, 0, 0.05), (0, 0, -0.05),
            (step, step, 0), (-step, -step, 0),
            (step, -step, 0), (-step, step, 0),
        ):
            ncx = min(max(cx + dcx, 0.0), 1.0)
            ncy = min(max(cy + dcy, 0.0), 1.0)
            nang = (ang + dang) % 1.0
            ns = _max_side_at(ncx, ncy, nang, others)
            if ns > s + 1e-9:
                cx, cy, ang, s = ncx, ncy, nang, ns
                improved = True
        if not improved:
            step *= 0.5
            if step < 1e-5:
                break
    return (cx, cy, ang, s)


def _grow_sweeps(S, rng, passes=4):
    n = len(S)
    for _ in range(passes):
        order = list(range(n))
        rng.shuffle(order)
        changed = False
        for i in order:
            others = S[:i] + S[i + 1:]
            cx, cy, ang, s = S[i]
            ns = _max_side_at(cx, cy, ang, others)
            if ns > s + 1e-12:
                S[i] = [cx, cy, ang, ns]
                changed = True
        if not changed:
            break


def _polish(S, rng, rounds=8):
    n = len(S)
    _grow_sweeps(S, rng, passes=4)
    for _ in range(rounds):
        changed = False
        order = list(range(n))
        order.sort(key=lambda i: S[i][3])
        for i in order[:max(1, (n * 3) // 4)]:
            removed = S[i]
            others = S[:i] + S[i + 1:]
            cand = _best_insert(others, rng)
            if cand is None:
                continue
            cand = _refine_insert(cand, others, rng)
            if cand[3] > removed[3] + 1e-12:
                S[i] = list(cand)
                changed = True
        _grow_sweeps(S, rng, passes=2)
        if not changed:
            break
    # final grow
    _grow_sweeps(S, rng, passes=6)
    return S


# -------------------- guillotine construction --------------------

def _construct(n, rng, area_pow=0.5, shrink=0.99):
    """Build n axis-aligned squares via recursive area-proportional splitting."""
    if n == 0:
        return []
    squares = []

    def rec(x0, y0, x1, y1, cnt):
        if cnt <= 0:
            return
        w, h = x1 - x0, y1 - y0
        if cnt == 1:
            s = min(w, h) * shrink
            squares.append((x0 + w * 0.5, y0 + h * 0.5, 0.0, s))
            return
        if w >= h:
            k1 = max(1, cnt // 2 + rng.randint(-1, 1))
            k1 = min(max(k1, 1), cnt - 1)
            k2 = cnt - k1
            fr = (k1 ** area_pow) / (k1 ** area_pow + k2 ** area_pow)
            fr = min(max(fr, 0.15), 0.85)
            xm = x0 + w * fr
            rec(x0, y0, xm, y1, k1)
            rec(xm, y0, x1, y1, k2)
        else:
            k1 = max(1, cnt // 2 + rng.randint(-1, 1))
            k1 = min(max(k1, 1), cnt - 1)
            k2 = cnt - k1
            fr = (k1 ** area_pow) / (k1 ** area_pow + k2 ** area_pow)
            fr = min(max(fr, 0.15), 0.85)
            ym = y0 + h * fr
            rec(x0, y0, x1, ym, k1)
            rec(x0, ym, x1, y1, k2)

    rec(0.0, 0.0, 1.0, 1.0, n)
    return squares


def _grid_seed(n):
    k = int(math.ceil(math.sqrt(n)))
    s = 1.0 / k
    out = []
    cnt = 0
    for i in range(k):
        for j in range(k):
            if cnt >= n:
                break
            out.append((s * (i + 0.5), s * (j + 0.5), 0.0, s * 0.999))
            cnt += 1
    return out


# -------------------- main solve --------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    seeds = [_grid_seed(n)]
    seeds.append(_construct(n, random.Random(1 + n), 0.5, 0.99))
    for att in range(5):
        r = random.Random(100 + 13 * n + att)
        shrink = 0.985 + 0.014 * r.random()
        ap = 0.4 + 0.2 * r.random()
        seeds.append(_construct(n, r, ap, shrink))

    best = None
    best_score = -1.0
    for att, base in enumerate(seeds):
        r = random.Random(98765 + 13 * n + att)
        S = [list(s) for s in base]
        # initial light grow to normalize
        _grow_sweeps(S, r, passes=3)
        S = _polish(S, r, rounds=6)
        sc = sum(s[3] for s in S)
        if sc > best_score:
            best_score = sc
            best = [list(s) for s in S]

    # final polish rounds on best
    rfin = random.Random(555 + n)
    best = _polish(best, rfin, rounds=10)

    # ensure cleanliness
    out = []
    for cx, cy, a, s in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        guard = 0
        while not _inside(cx, cy, a, s) and s > 1e-9 and guard < 50:
            s *= 0.9
            guard += 1
        if s < 1e-9:
            s = 0.0
        out.append((cx, cy, a, s))

    changed = True
    guard = 0
    while changed and guard < 200:
        changed = False
        for i in range(len(out)):
            for j in range(i + 1, len(out)):
                if _overlap(out[i], out[j]):
                    a, b = out[i], out[j]
                    if a[3] >= b[3]:
                        out[j] = (b[0], b[1], b[2], b[3] * 0.8)
                    else:
                        out[i] = (a[0], a[1], a[2], a[3] * 0.8)
                    changed = True
        guard += 1

    return out[:n]
# EVOLVE-BLOCK-END

