# EVOLVE-BLOCK-START
"""Portfolio packing heuristic for squares in a unit square.

Approach:
1. Build an initial set of squares using a recursive guillotine subdivision of the
   unit square, assigning sizes proportional to region widths/heights.
2. Improve positions and sizes with randomized coordinate descent: repeatedly try
   to translate one square, or exchange sizes between two squares, accepting moves
   that increase the total side length while preserving disjoint interiors.
3. Check disjointness exactly for rotated squares by separating-axis testing.

The method is purely constructive and parameterised by n, so it works for every n.
"""

import math
import random

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

_EPS = 1e-12


def _corners(cx, cy, ang, s):
    """Return the four corners of a square."""
    h = 0.5 * s
    c = math.cos(2.0 * math.pi * ang)
    sn = math.sin(2.0 * math.pi * ang)
    # local axes
    ax, ay = c, sn
    bx, by = -sn, c
    return [
        (cx + h * ax + h * bx, cy + h * ay + h * by),
        (cx + h * ax - h * bx, cy + h * ay - h * by),
        (cx - h * ax + h * bx, cy - h * ay + h * by),
        (cx - h * ax - h * bx, cy - h * ay - h * by),
    ]


def _project(poly, axis):
    d = poly[0][0] * axis[0] + poly[0][1] * axis[1]
    lo = hi = d
    for x, y in poly[1:]:
        d = x * axis[0] + y * axis[1]
        if d < lo:
            lo = d
        elif d > hi:
            hi = d
    return lo, hi


def _overlap_area(a, b):
    """Return True if the interiors of squares a,b overlap.

    Using separating-axis theorem on the two squares' edge normals.
    """
    pa = _corners(*a)
    pb = _corners(*b)
    for poly, other in ((pa, pb), (pb, pa)):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            ln = math.hypot(nx, ny)
            if ln < _EPS:
                continue
            nx /= ln
            ny /= ln
            lo1, hi1 = _project(pa, (nx, ny))
            lo2, hi2 = _project(pb, (nx, ny))
            if hi1 <= lo2 + 1e-11 or hi2 <= lo1 + 1e-11:
                return False
    return True


def _inside(cx, cy, ang, s):
    if s <= 0.0:
        return True
    for x, y in _corners(cx, cy, ang, s):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


# ---------------------------------------------------------------------------
# Guillotine initial construction
# ---------------------------------------------------------------------------

def _guillotine(x0, y0, w, h, n, out):
    """Recursively fill rectangle (x0,y0,w,h) with n axis-aligned squares.

    Sizes are set so that each square is as large as possible within its share
    of the rectangle, using alternating horizontal/vertical cuts.
    """
    if n <= 0:
        return
    if n == 1:
        s = min(w, h)
        out.append((x0 + 0.5 * w, y0 + 0.5 * h, 0.0, s))
        return
    if w >= h:
        # split vertically
        # size roughly proportional to sqrt(n1/n)
        n1 = max(1, min(n - 1, int(round(n * w / (w + h)))))
        n2 = n - n1
        w1 = w * n1 / n
        w2 = w - w1
        _guillotine(x0, y0, w1, h, n1, out)
        _guillotine(x0 + w1, y0, w2, h, n2, out)
    else:
        n1 = max(1, min(n - 1, int(round(n * h / (w + h)))))
        n2 = n - n1
        h1 = h * n1 / n
        h2 = h - h1
        _guillotine(x0, y0, w, h1, n1, out)
        _guillotine(x0, y0 + h1, w, h2, n2, out)


def _initial(n):
    out = []
    _guillotine(0.0, 0.0, 1.0, 1.0, n, out)
    return out


# ---------------------------------------------------------------------------
# Local search
# ---------------------------------------------------------------------------

def _valid(squares, idx=None):
    """Check all squares or only those involving idx are disjoint & inside."""
    m = len(squares)
    if idx is None:
        idxs = range(m)
    else:
        idxs = [idx]
    for i in idxs:
        a = squares[i]
        if not _inside(*a):
            return False
        for j in range(m):
            if i == j:
                continue
            b = squares[j]
            if a[3] <= 0.0 or b[3] <= 0.0:
                continue
            if _overlap_area(a, b):
                return False
    return True


def _search(n, rng, time_budget_iters):
    squares = _initial(n)
    # clean zero/invalid
    for i in range(n):
        cx, cy, ang, s = squares[i]
        if not _inside(cx, cy, ang, s):
            squares[i] = (0.5, 0.5, 0.0, 0.0)

    best = [tuple(s) for s in squares]
    best_val = sum(s[3] for s in best)

    for _ in range(time_budget_iters):
        i = rng.randrange(n)
        cx, cy, ang, s = squares[i]
        mode = rng.random()

        if mode < 0.55:
            # translate
            step = 0.03 * rng.random() + 0.002
            nx = cx + (rng.random() * 2 - 1) * step
            ny = cy + (rng.random() * 2 - 1) * step
            cand = (min(max(nx, 0.0), 1.0), min(max(ny, 0.0), 1.0), ang, s)
        elif mode < 0.75:
            # grow/shrink
            factor = 1.0 + (rng.random() - 0.3) * 0.08
            ns = s * factor
            cand = (cx, cy, ang, max(0.0, ns))
        elif mode < 0.9:
            # rotate slightly
            nang = (ang + (rng.random() - 0.5) * 0.08) % 1.0
            cand = (cx, cy, nang, s)
        else:
            # exchange size with another square
            j = rng.randrange(n)
            cj = squares[j]
            s_i, s_j = squares[i][3], cj[3]
            squares[i] = (squares[i][0], squares[i][1], squares[i][2], s_j)
            squares[j] = (cj[0], cj[1], cj[2], s_i)
            if _valid(squares, i) and _valid(squares, j):
                val = sum(t[3] for t in squares)
                if val > best_val:
                    best_val = val
                    best = [tuple(t) for t in squares]
            else:
                squares[i] = (squares[i][0], squares[i][1], squares[i][2], s_i)
                squares[j] = (cj[0], cj[1], cj[2], s_j)
            continue

        old = squares[i]
        squares[i] = cand
        if _valid(squares, i):
            val = sum(t[3] for t in squares)
            if val > best_val - 1e-15:
                if val > best_val:
                    best_val = val
                    best = [tuple(t) for t in squares]
        else:
            squares[i] = old

    return best


# ---------------------------------------------------------------------------
# Public entry
# ---------------------------------------------------------------------------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square."""
    if n <= 0:
        return []
    rng = random.Random(12345 + n)
    # iteration budget tuned to stay within the 60 second limit
    iters = 4000 if n <= 50 else (2500 if n <= 200 else 1200)
    squares = _search(n, rng, iters)

    # safety pass: zero out anything invalid
    result = []
    for i, sq in enumerate(squares[:n]):
        cx, cy, ang, s = sq
        if not _inside(cx, cy, ang, s):
            result.append((0.5, 0.5, 0.0, 0.0))
        else:
            result.append((cx % 1.0, cy % 1.0, ang % 1.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END
