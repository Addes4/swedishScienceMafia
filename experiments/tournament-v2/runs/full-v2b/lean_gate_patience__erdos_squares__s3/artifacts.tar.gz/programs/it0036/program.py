# EVOLVE-BLOCK-START
"""Portfolio of guillotine/strip/grid/pinwheel seeds + iterated local search
with a binary-search 'grow-to-max' polish and exact polygon-overlap rejection,
maximising the sum of square side lengths."""
import math
import random
import time


def _corner(cx, cy, a, s):
    th = a * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    ax, ay = c * h, sn * h
    bx, by = -sn * h, c * h
    return ((cx + ax + bx, cy + ay + by),
            (cx + ax - bx, cy + ay - by),
            (cx - ax - bx, cy - ay - by),
            (cx - ax + bx, cy - ay + by))


def _overlap_polys(p1, p2):
    for poly, other in ((p1, p2), (p2, p1)):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            nx, ny = ey, -ex
            d1 = [px * nx + py * ny for px, py in poly]
            d2 = [px * nx + py * ny for px, py in other]
            if max(d1) <= min(d2) or max(d2) <= min(d1):
                return False
    return True


def _overlap(sq1, sq2):
    return _overlap_polys(_corner(*sq1), _corner(*sq2))


def _feasible(squares):
    m = len(squares)
    P = [_corner(*q) for q in squares]
    for i in range(m):
        if squares[i][3] <= 0.0:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 0.0:
                continue
            if _overlap_polys(P[i], P[j]):
                return False
    return True


def _clamp_square(q):
    cx, cy, a, s = q
    a = a % 1.0
    if s <= 0.0:
        return [min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a, 0.0]
    th = a * 2.0 * math.pi
    c, sn = abs(math.cos(th)), abs(math.sin(th))
    half = s * 0.5 * (c + sn)
    if half * 2 > 1.0 + 1e-12:
        s = 1.0 / (c + sn)
        half = s * 0.5 * (c + sn)
    cx = min(1.0 - half, max(half, cx))
    cy = min(1.0 - half, max(half, cy))
    return [cx, cy, a, s]


def _score(squares):
    return sum(q[3] for q in squares)


def _max_half_extent(a):
    th = a * 2.0 * math.pi
    return 0.5 * (abs(math.cos(th)) + abs(math.sin(th))) + 1e-12


def _fits_box(cx, cy, a, s):
    if s <= 0.0:
        return (0.0 <= cx <= 1.0) and (0.0 <= cy <= 1.0)
    he = _max_half_extent(a) * s
    return (he <= cx <= 1.0 - he) and (he <= cy <= 1.0 - he)


def _overlap_ok(cand, squares, skip):
    pc = _corner(*cand)
    for j, q in enumerate(squares):
        if j == skip or q[3] <= 0.0 or cand[3] <= 0.0:
            continue
        if _overlap_polys(pc, _corner(*q)):
            return False
    return True


# ----------------------------------------------------------------------------
# Seed generators
# ----------------------------------------------------------------------------

def _seed_grid(n):
    if n <= 0:
        return []
    best = None
    best_sc = -1.0
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols * rows < n:
            continue
        s = min(1.0 / cols, 1.0 / rows)
        sq = []
        for r in range(rows):
            for c in range(cols):
                if len(sq) >= n:
                    break
                cx = (c + 0.5) * (1.0 / cols)
                cy = (r + 0.5) * (1.0 / rows)
                sq.append([cx, cy, 0.0, s])
            if len(sq) >= n:
                break
        sc = _score(sq)
        if sc > best_sc:
            best_sc = sc
            best = sq
    return best if best else []


def _seed_guillotine(rect, count, ratio):
    x0, y0, x1, y1 = rect
    if count <= 1:
        return [(x0, y0, x1, y1)]
    w = x1 - x0
    h = y1 - y0
    if w >= h:
        c1 = max(1, min(count - 1, int(round(count * ratio))))
        xm = x0 + w * (c1 / count)
        return (_seed_guillotine((x0, y0, xm, y1), c1, ratio) +
                _seed_guillotine((xm, y0, x1, y1), count - c1, ratio))
    else:
        c1 = max(1, min(count - 1, int(round(count * ratio))))
        ym = y0 + h * (c1 / count)
        return (_seed_guillotine((x0, y0, x1, ym), c1, ratio) +
                _seed_guillotine((x0, ym, x1, y1), count - c1, ratio))


def _seed_strip_full(n, k, frac, vertical):
    if k <= 0 or k >= n:
        return None
    if vertical:
        s = min(frac, 1.0 / k)
        strip_w = s * k
        sq = [[(i + 0.5) * s, 0.5, 0.0, s] for i in range(k)]
        lw = 1.0 - strip_w
        return sq + _seed_fill(n - k, lw, 1.0, strip_w, 0.0)
    else:
        s = min(frac, 1.0 / k)
        strip_h = s * k
        sq = [[0.5, (i + 0.5) * s, 0.0, s] for i in range(k)]
        lh = 1.0 - strip_h
        return sq + _seed_fill(n - k, 1.0, lh, 0.0, strip_h)


def _seed_fill(count, w, h, ox, oy):
    if count <= 0:
        return []
    best = None
    best_sc = -1.0
    for rows in range(1, count + 1):
        cols = (count + rows - 1) // rows
        s = min(w / cols, h / rows)
        sq = []
        for r in range(rows):
            for c in range(cols):
                if len(sq) >= count:
                    break
                cx = ox + (c + 0.5) * (w / cols)
                cy = oy + (r + 0.5) * (h / rows)
                sq.append([cx, cy, 0.0, s])
            if len(sq) >= count:
                break
        sc = _score(sq)
        if sc > best_sc:
            best_sc = sc
            best = sq
    return best if best else []


def _seed_pinwheel(n):
    if n < 4:
        return None
    best = None
    best_sc = -1.0
    for s in [0.45, 0.4, 0.35, 0.3, 0.5]:
        sq = [
            [0.5 - s * 0.45, 0.5, 0.0, s],
            [0.5 + s * 0.45, 0.5, 0.0, s],
            [0.5, 0.5 - s * 0.45, 0.0, s],
            [0.5, 0.5 + s * 0.45, 0.0, s],
        ]
        if n > 4:
            sub = _seed_fill(n - 4, 1.0, 1.0, 0.0, 0.0)
            for q in sub:
                q[3] *= 0.5
            sq = sq + sub
        sq = sq[:n]
        cs = [_clamp_square(q) for q in sq]
        if _feasible(cs):
            sc = _score(cs)
            if sc > best_sc:
                best_sc = sc
                best = cs
    return best


def _construct_portfolio(n):
    seeds = []
    g = _seed_grid(n)
    if g:
        seeds.append(g)
    for ratio in (0.25, 0.333, 0.5, 0.666, 0.75):
        r = _seed_guillotine((0.0, 0.0, 1.0, 1.0), n, ratio)
        sq = []
        for (x0, y0, x1, y1) in r:
            s = min(x1 - x0, y1 - y0)
            sq.append([(x0 + x1) * 0.5, (y0 + y1) * 0.5, 0.0, s])
        seeds.append(sq)
    for k in range(1, n):
        for frac in (0.25, 0.33, 0.4, 0.5, 0.6, 0.666, 0.75):
            for vertical in (False, True):
                if vertical and frac * k > 1.0:
                    continue
                sq = _seed_strip_full(n, k, frac, vertical)
                if sq is not None and len(sq) == n:
                    seeds.append(sq)
    p = _seed_pinwheel(n)
    if p:
        seeds.append(p)
    return seeds


# ----------------------------------------------------------------------------
# Search core
# ----------------------------------------------------------------------------

def _grow_one(squares, i, n, iters=26):
    """Binary-search the largest side for square i that fits the box and
    doesn't overlap any other square (centre fixed, angle fixed, grow about centre)."""
    cx, cy, a, s = squares[i]
    he = _max_half_extent(a)
    # max allowed by box
    if he > 0:
        bx = min(cx, 1.0 - cx) / he
        by = min(cy, 1.0 - cy) / he
        smax = min(bx, by)
    else:
        smax = 1.0
    if smax > 1.0:
        smax = 1.0
    if smax <= s:
        # try to keep current, it's already at/over box limit
        cand = [cx, cy, a, min(s, 1.0)]
        return cand if _fits_box(cx, cy, a, cand[3]) else [cx, cy, a, s]
    lo, hi = 0.0, smax
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        cand = [cx, cy, a, mid]
        if _overlap_ok(cand, squares, i):
            lo = mid
        else:
            hi = mid
    return [cx, cy, a, lo]


def _grow_polish(squares, n, sweeps=4, rng=None):
    squares = [list(q) for q in squares]
    if rng is None:
        rng = random
    for _ in range(sweeps):
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cand = _grow_one(squares, i, n)
            if cand[3] > squares[i][3] + 1e-15:
                squares[i] = cand
    return squares


def _grow_all_once(squares, n, rng):
    order = list(range(n))
    rng.shuffle(order)
    for i in order:
        cand = _grow_one(squares, i, n)
        if cand[3] > squares[i][3] + 1e-15:
            squares[i] = cand
    return squares


def _perturb(squares, n, rng, strength):
    cand = [list(q) for q in squares]
    # shrink a few squares and jiggle positions, then re-grow
    k = max(1, int(n * strength))
    idxs = rng.sample(range(n), min(k, n))
    for i in idxs:
        cx, cy, a, s = cand[i]
        if s > 0:
            s *= (0.5 + 0.5 * rng.random())
        da = (rng.random() - 0.5) * 0.1
        step = 0.02 + 0.08 * rng.random()
        cand[i] = _clamp_square([cx + (rng.random() - 0.5) * step,
                                 cy + (rng.random() - 0.5) * step,
                                 a + da, s])
    # ensure feasibility
    if not _feasible(cand):
        cand = [list(q) for q in squares]
    return cand


def _iterated_search(seed_sq, n, t_limit, rng):
    best = _grow_polish(seed_sq, n, sweeps=6, rng=rng)
    best_score = _score(best)
    cur = [list(q) for q in best]
    cur_score = best_score
    t0 = time.time()
    it = 0
    stagn = 0
    while time.time() - t0 < t_limit:
        it += 1
        strength = 0.15 + 0.35 * rng.random()
        cand = _perturb(cur, n, rng, strength)
        # a couple of grow sweeps
        cand = _grow_all_once(cand, n, rng)
        cand = _grow_all_once(cand, n, rng)
        if not _feasible(cand):
            continue
        sc = _score(cand)
        if sc > cur_score + 1e-12:
            cur = cand
            cur_score = sc
            stagn = 0
        else:
            stagn += 1
            if stagn > 8:
                cur = [list(q) for q in best]
                cur_score = best_score
                stagn = 0
        if cur_score > best_score + 1e-12:
            best = [list(q) for q in cur]
            best_score = cur_score
            # occasional deep polish
            p = _grow_polish(best, n, sweeps=3, rng=rng)
            ps = _score(p)
            if ps > best_score:
                best = p
                best_score = ps
    return best, best_score


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    seeds = _construct_portfolio(n)

    scored = []
    for sq in seeds:
        cs = [_clamp_square(list(q)) for q in sq]
        if _feasible(cs):
            scored.append((_score(cs), cs))
    if not scored:
        g = [_clamp_square(q) for q in _seed_grid(n)]
        scored.append((_score(g), g))
    scored.sort(key=lambda t: -t[0])

    total_limit = 40.0
    t_start = time.time()

    # Quick polish of every seed isn't needed; polish top few, keep best.
    top = scored[:min(8, len(scored))]

    best = None
    best_score = -1.0
    rng = random.Random(12345 + n * 7919)

    for idx, (sc0, seed_sq) in enumerate(top):
        if time.time() - t_start > total_limit:
            break
        remaining = len(top) - idx
        tl = max(2.0, (total_limit - (time.time() - t_start)) / remaining)
        # always finish within budget
        tl = min(tl, total_limit - (time.time() - t_start))
        if tl <= 0.5:
            break
        res, rsc = _iterated_search(seed_sq, n, tl, rng)
        if rsc > best_score:
            best = res
            best_score = rsc

    if best is None:
        best = top[0][1]

    return [(q[0], q[1], q[2] % 1.0, q[3]) for q in best]
# EVOLVE-BLOCK-END
