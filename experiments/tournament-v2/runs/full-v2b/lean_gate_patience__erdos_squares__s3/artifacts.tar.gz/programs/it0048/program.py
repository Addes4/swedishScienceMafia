# EVOLVE-BLOCK-START
"""Recursive guillotine construction plus randomized local search."""
import math
import random


def _corners(cx, cy, ang, s):
    """Four corners of a square as (x, y) tuples."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap(c1, c2):
    """Exact separating-axis test for two rotated squares (convex)."""
    for pts in (c1, c2):
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            nx, ny = -(y2 - y1), (x2 - x1)
            min1 = max1 = None
            for (px, py) in c1:
                d = px * nx + py * ny
                if min1 is None or d < min1:
                    min1 = d
                if max1 is None or d > max1:
                    max1 = d
            min2 = max2 = None
            for (px, py) in c2:
                d = px * nx + py * ny
                if min2 is None or d < min2:
                    min2 = d
                if max2 is None or d > max2:
                    max2 = d
            if max1 <= min2 or max2 <= min1:
                return False
    return True


def _in_bounds(c):
    for x, y in c:
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _guillotine(n, rng):
    """Recursively split the unit square; place one square in each cell."""
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        idx = 0
        best = -1.0
        for i, (x, y, w, h) in enumerate(cells):
            v = min(w, h) * max(w, h)
            if v > best:
                best = v
                idx = i
        x, y, w, h = cells.pop(idx)
        frac = rng.uniform(0.4, 0.6)
        if w >= h:
            w1 = w * frac
            cells.append((x, y, w1, h))
            cells.append((x + w1, y, w - w1, h))
        else:
            h1 = h * frac
            cells.append((x, y, w, h1))
            cells.append((x, y + h1, w, h - h1))

    squares = []
    for (x, y, w, h) in cells:
        s = min(w, h)
        cx = x + w * 0.5
        cy = y + h * 0.5
        squares.append([cx, cy, 0.0, s])
    return squares


def _any_overlap(squares, cand_idx, cand):
    """Check candidate against all others and bounds."""
    c1 = _corners(*cand)
    if not _in_bounds(c1):
        return True
    for i, sq in enumerate(squares):
        if i == cand_idx:
            continue
        if _overlap(c1, _corners(*sq)):
            return True
    return False


def _max_side_for(squares, idx, cx, cy, ang, lo, hi):
    """Binary search the largest frame side at (cx,cy,ang) that is feasible."""
    best = 0.0
    for _ in range(24):
        mid = 0.5 * (lo + hi)
        cand = (cx, cy, ang, mid)
        if _any_overlap(squares, idx, cand):
            hi = mid
        else:
            best = mid
            lo = mid
    return best


def _grow_all(squares, rounds=3):
    """Deterministically grow each square to its maximum feasible side."""
    n = len(squares)
    if n == 0:
        return
    for _ in range(rounds):
        improved = False
        for i in range(n):
            cx, cy, ang, s = squares[i]
            hi = 1.0
            ms = _max_side_for(squares, i, cx, cy, ang, s, hi)
            if ms > s + 1e-7:
                squares[i] = [cx, cy, ang, ms]
                improved = True
        if not improved:
            break


def improve_local(squares, rng):
    """Randomized grow / shift / rotate moves with exact overlap rejection."""
    n = len(squares)
    if n == 0:
        return

    for _ in range(3000):
        i = rng.randrange(n)
        cx, cy, ang, s = squares[i]
        move = rng.random()

        if move < 0.5:
            factor = 1.0 + rng.uniform(0.01, 0.25)
            ns = s * factor
            for _t in range(12):
                if _t == 0:
                    ncx, ncy = cx, cy
                else:
                    ncx = min(max(cx + rng.uniform(-0.05, 0.05), 0.0), 1.0)
                    ncy = min(max(cy + rng.uniform(-0.05, 0.05), 0.0), 1.0)
                if ns > 1.0:
                    break
                cand = (ncx, ncy, ang, ns)
                if not _any_overlap(squares, i, cand):
                    squares[i] = [ncx, ncy, ang, ns]
                    break
        elif move < 0.78:
            ncx = min(max(cx + rng.uniform(-0.06, 0.06), 0.0), 1.0)
            ncy = min(max(cy + rng.uniform(-0.06, 0.06), 0.0), 1.0)
            ns = s * (1.0 + rng.uniform(-0.03, 0.12))
            if ns > 1.0:
                ns = 1.0
            cand = (ncx, ncy, ang, ns)
            if not _any_overlap(squares, i, cand):
                squares[i] = list(cand)
        else:
            nang = (ang + rng.uniform(-0.06, 0.06)) % 1.0
            ns = s * (1.0 + rng.uniform(-0.02, 0.06))
            if ns > 1.0:
                ns = 1.0
            cand = (cx, cy, nang, ns)
            if not _any_overlap(squares, i, cand):
                squares[i] = list(cand)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345)

    best = None
    best_sum = -1.0

    for trial in range(4):
        sq = _guillotine(n, rng)
        sq = [s for s in sq if s[3] > 1e-9]
        while len(sq) < n:
            sq.append([0.5, 0.5, 0.0, 0.0])

        _grow_all(sq, rounds=4)
        improve_local(sq, rng)
        _grow_all(sq, rounds=2)

        tot = sum(s[3] for s in sq)
        if tot > best_sum:
            best_sum = tot
            best = [tuple(s) for s in sq]

    return best
# EVOLVE-BLOCK-END
