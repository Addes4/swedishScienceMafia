# EVOLVE-BLOCK-START
"""Portfolio of guillotine/strip/grid/pinwheel seeds + randomized local search
with exact polygon-overlap rejection and exact growth polish, maximising the
sum of square side lengths."""
import math
import random
import time


def _corner(cx, cy, a, s):
    th = a * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    ax, ay = c * h, sn * h
    bx, by = -sn * h, c * h
    return ((cx + ax + bx, cy + ay + by),
            (cx + ax - bx, cy + ay - by),
            (cx - ax - bx, cy - ay - by),
            (cx - ax + bx, cy - ay + by))


def _overlap(sq1, sq2):
    p1 = _corner(*sq1)
    p2 = _corner(*sq2)
    for poly, other in ((p1, p2), (p2, p1)):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            nx, ny = ey, -ex
            d1 = [px * nx + py * ny for px, py in poly]
            d2 = [px * nx + py * ny for px, py in other]
            if max(d1) <= min(d2) or max(d2) <= min(d1):
                return False
    return True


def _feasible(squares):
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 0.0:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 0.0:
                continue
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _fits_against(q, squares, skip):
    """Feasibility of square q against all others (index != skip)."""
    if q[3] <= 0.0:
        return True
    for j in range(len(squares)):
        if j == skip:
            continue
        if squares[j][3] <= 0.0:
            continue
        if _overlap(q, squares[j]):
            return False
    return True


def _clamp_square(q):
    cx, cy, a, s = q
    a = a % 1.0
    if s <= 0.0:
        return [min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a, 0.0]
    th = a * 2.0 * math.pi
    c, sn = abs(math.cos(th)), abs(math.sin(th))
    half = s * 0.5 * (c + sn)
    if half * 2 > 1.0 + 1e-12:
        s = 1.0 / (c + sn)
        half = s * 0.5 * (c + sn)
    cx = min(1.0 - half, max(half, cx))
    cy = min(1.0 - half, max(half, cy))
    return [cx, cy, a, s]


def _score(squares):
    return sum(q[3] for q in squares)


def _grow_square(squares, i):
    """Grow square i to its maximum feasible side (binary search), in place."""
    cx, cy, a, s = squares[i]
    saved = squares[i]
    squares[i] = [cx, cy, a, 0.0]
    # upper bound on any side achievable in unit square
    lo = 0.0
    hi = 1.0
    # quick check hi infeasible
    if _fits_against(_clamp_square([cx, cy, a, hi]), squares, i):
        squares[i] = _clamp_square([cx, cy, a, hi])
        return
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        cand = _clamp_square([cx, cy, a, mid])
        if _fits_against(cand, squares, i):
            lo = mid
        else:
            hi = mid
    squares[i] = _clamp_square([cx, cy, a, lo])
    if squares[i][3] < saved[3] - 1e-12:
        # should not happen (saved was feasible), but guard
        squares[i] = saved


def _grow_all(squares, n):
    order = list(range(n))
    for i in order:
        if squares[i][3] <= 0.0:
            continue
        _grow_square(squares, i)
    return squares


# ----------------------------------------------------------------------------
# Seed generators
# ----------------------------------------------------------------------------

def _seed_grid(n):
    if n <= 0:
        return []
    best = None
    best_sc = -1.0
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols * rows < n:
            continue
        s = min(1.0 / cols, 1.0 / rows)
        sq = []
        for r in range(rows):
            for c in range(cols):
                if len(sq) >= n:
                    break
                cx = (c + 0.5) * (1.0 / cols)
                cy = (r + 0.5) * (1.0 / rows)
                sq.append([cx, cy, 0.0, s])
            if len(sq) >= n:
                break
        sc = _score(sq)
        if sc > best_sc:
            best_sc = sc
            best = sq
    return best if best else []


def _seed_guillotine(rect, count, ratio):
    x0, y0, x1, y1 = rect
    if count <= 1:
        return [(x0, y0, x1, y1)]
    w = x1 - x0
    h = y1 - y0
    if w >= h:
        c1 = max(1, min(count - 1, int(round(count * ratio))))
        xm = x0 + w * (c1 / count)
        return (_seed_guillotine((x0, y0, xm, y1), c1, ratio) +
                _seed_guillotine((xm, y0, x1, y1), count - c1, ratio))
    else:
        c1 = max(1, min(count - 1, int(round(count * ratio))))
        ym = y0 + h * (c1 / count)
        return (_seed_guillotine((x0, y0, x1, ym), c1, ratio) +
                _seed_guillotine((x0, ym, x1, y1), count - c1, ratio))


def _seed_strip_full(n, k, frac, vertical, use_grid_rem=True):
    if k <= 0 or k >= n:
        return None
    if vertical:
        s = frac
        if s > 1.0 / k + 1e-12:
            s = 1.0 / k
        strip_w = s * k
        sq = []
        for i in range(k):
            sq.append([(i + 0.5) * s, 0.5, 0.0, s])
        lw = 1.0 - strip_w
        sub = _seed_fill(n - k, lw, 1.0, strip_w, 0.0)
        return sq + sub
    else:
        s = frac
        if s > 1.0 / k + 1e-12:
            s = 1.0 / k
        strip_h = s * k
        sq = []
        for i in range(k):
            sq.append([0.5, (i + 0.5) * s, 0.0, s])
        lh = 1.0 - strip_h
        sub = _seed_fill(n - k, 1.0, lh, 0.0, strip_h)
        return sq + sub


def _seed_fill(count, w, h, ox, oy):
    if count <= 0:
        return []
    best = None
    best_sc = -1.0
    for rows in range(1, count + 1):
        cols = (count + rows - 1) // rows
        s = min(w / cols, h / rows)
        sq = []
        for r in range(rows):
            for c in range(cols):
                if len(sq) >= count:
                    break
                cx = ox + (c + 0.5) * (w / cols)
                cy = oy + (r + 0.5) * (h / rows)
                sq.append([cx, cy, 0.0, s])
            if len(sq) >= count:
                break
        sc = _score(sq)
        if sc > best_sc:
            best_sc = sc
            best = sq
    return best if best else []


def _seed_pinwheel(n):
    if n < 4:
        return None
    best = None
    best_sc = -1.0
    for s in [0.45, 0.4, 0.35, 0.3, 0.5]:
        sq = [
            [0.5 - s * 0.45, 0.5, 0.0, s],
            [0.5 + s * 0.45, 0.5, 0.0, s],
            [0.5, 0.5 - s * 0.45, 0.0, s],
            [0.5, 0.5 + s * 0.45, 0.0, s],
        ]
        if n > 4:
            sub = _seed_fill(n - 4, 1.0, 1.0, 0.0, 0.0)
            for q in sub:
                q[3] *= 0.5
            sq = sq + sub
        sq = sq[:n]
        if _feasible([_clamp_square(q) for q in sq]):
            sc = _score(sq)
            if sc > best_sc:
                best_sc = sc
                best = sq
    return best


def _construct_portfolio(n):
    seeds = []
    g = _seed_grid(n)
    if g:
        seeds.append(g)
    for ratio in (0.25, 0.333, 0.5, 0.666, 0.75):
        r = _seed_guillotine((0.0, 0.0, 1.0, 1.0), n, ratio)
        sq = []
        for (x0, y0, x1, y1) in r:
            s = min(x1 - x0, y1 - y0)
            sq.append([(x0 + x1) * 0.5, (y0 + y1) * 0.5, 0.0, s])
        seeds.append(sq)
    for k in range(1, n):
        for frac in (0.25, 0.33, 0.4, 0.5, 0.6, 0.666, 0.75):
            for vertical in (False, True):
                if vertical and frac * k > 1.0:
                    continue
                sq = _seed_strip_full(n, k, frac, vertical)
                if sq is not None and len(sq) == n:
                    seeds.append(sq)
    p = _seed_pinwheel(n)
    if p:
        seeds.append(p)
    return seeds


def _relocate(squares, n):
    """Move a small square to a fresh random location (reinsertion move)."""
    cand = [list(q) for q in squares]
    # pick a relatively small square
    if n <= 1:
        return cand
    order = sorted(range(n), key=lambda i: squares[i][3])
    i = order[random.randrange(0, max(1, n // 2))]
    cand[i] = _clamp_square([random.random(), random.random(),
                             random.random(), 0.0])
    return cand


def _local_search(squares, n, t_limit, seed):
    random.seed(seed)
    best = [_clamp_square(list(q)) for q in squares]
    if not _feasible(best):
        g = _seed_grid(n)
        if g:
            best = [_clamp_square(list(q)) for q in g]
    _grow_all(best, n)
    best_score = _score(best)
    t_start = time.time()
    it = 0
    since_improve = 0
    while True:
        if it % 100 == 0 and time.time() - t_start > t_limit:
            break
        it += 1
        since_improve += 1
        cand = [list(q) for q in best]
        i = random.randrange(n)
        cx, cy, a, s = cand[i]
        r = random.random()
        if r < 0.45:
            delta = s * (0.02 + 0.3 * random.random()) + 1e-4
            cand[i] = _clamp_square([cx, cy, a, s + delta])
        elif r < 0.60:
            delta = s * (0.02 + 0.3 * random.random())
            cand[i] = _clamp_square([cx, cy, a, s - delta])
        elif r < 0.80:
            step = 0.005 + 0.05 * random.random()
            cand[i] = _clamp_square([cx + (random.random() - 0.5) * step,
                                     cy + (random.random() - 0.5) * step, a, s])
        elif r < 0.90:
            da = (random.random() - 0.5) * 0.05
            cand[i] = _clamp_square([cx, cy, a + da, s])
        else:
            cand = _relocate(best, n)
        if _feasible(cand):
            _grow_square(cand, i if r < 0.90 else 0)
            sc = _score(cand)
            if sc >= best_score - 1e-12:
                best = cand
                best_score = sc
                since_improve = 0
        # periodic full polish to escape dead-ends
        if since_improve > 400:
            cand = [list(q) for q in best]
            _grow_all(cand, n)
            if _feasible(cand):
                sc = _score(cand)
                if sc >= best_score - 1e-12:
                    best = cand
                    best_score = sc
            since_improve = 0
    return best, best_score


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    seeds = _construct_portfolio(n)

    scored = []
    for sq in seeds:
        cs = [_clamp_square(list(q)) for q in sq]
        if _feasible(cs):
            _grow_all(cs, n)
            scored.append((_score(cs), cs))
    if not scored:
        g = [_clamp_square(q) for q in _seed_grid(n)]
        scored.append((_score(g), g))
    scored.sort(key=lambda t: -t[0])

    total_limit = 45.0
    t_start = time.time()
    top = scored[:min(5, len(scored))]

    best = top[0][1]
    best_score = top[0][0]

    remaining = max(1, len(top))
    per = max(3.0, (total_limit - (time.time() - t_start)) / remaining)
    for idx, (sc0, seed_sq) in enumerate(top):
        if time.time() - t_start > total_limit:
            break
        tl = min(per, total_limit - (time.time() - t_start))
        if tl <= 0.5:
            break
        res, rsc = _local_search([list(q) for q in seed_sq], n, tl, 1000 + n * 97 + idx)
        if rsc > best_score:
            best = res
            best_score = rsc

    return [(q[0], q[1], q[2] % 1.0, q[3]) for q in best]
# EVOLVE-BLOCK-END
