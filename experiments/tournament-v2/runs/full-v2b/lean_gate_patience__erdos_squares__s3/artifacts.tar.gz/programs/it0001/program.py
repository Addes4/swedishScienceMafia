# EVOLVE-BLOCK-START
"""Greedy + local refinement packing of axis-aligned squares in the unit square.

The strategy is generic: start from a good heuristic arrangement, then run a fast
local search that perturbs centres/sizes and accepts improvements, giving a strong
sum of side lengths for any n within the time budget.
"""
import math
import random


def _overlap(a, b):
    # axis-aligned squares: (cx, cy, angle, side); assume angle 0
    ax, ay, aa, asd = a
    bx, by, ba, bsd = b
    ha = asd * 0.5
    hb = bsd * 0.5
    dx = abs(ax - bx)
    dy = abs(ay - by)
    return dx < ha + hb and dy < ha + hb


def _feasible(sqs):
    for i in range(len(sqs)):
        xi, yi, _, si = sqs[i]
        h = si * 0.5
        if si > 0:
            if xi - h < -1e-12 or xi + h > 1 + 1e-12 or yi - h < -1e-12 or yi + h > 1 + 1e-12:
                return False
        for j in range(i + 1, len(sqs)):
            xj, yj, _, sj = sqs[j]
            if si <= 0 or sj <= 0:
                continue
            if abs(xi - xj) < (si + sj) * 0.5 - 1e-12 and abs(yi - yj) < (si + sj) * 0.5 - 1e-12:
                return False
    return True


def _score(sqs):
    return sum(s[3] for s in sqs)


def _grid_init(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
           for i in range(k) for j in range(k)]
    sqs = sqs[:n]
    while len(sqs) < n:
        sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs


def _refine(sqs, budget_iter):
    n = len(sqs)
    best = list(sqs)
    best_s = _score(best)
    cur = list(best)
    cur_s = best_s
    rng = random.Random(12345 + n)
    step_s = 0.05
    step_p = 0.02
    for it in range(budget_iter):
        if it % 400 == 399:
            step_s *= 0.9
            step_p *= 0.9
        i = rng.randrange(n)
        c = list(cur)
        x, y, a, s = c[i]
        # try a perturbation: mostly grow size, sometimes move
        mode = rng.random()
        if mode < 0.55:
            ns = s + rng.uniform(0, step_s)
            c[i] = (x, y, a, ns)
        elif mode < 0.85:
            nx = x + rng.uniform(-step_p, step_p)
            ny = y + rng.uniform(-step_p, step_p)
            c[i] = (nx, ny, a, s)
        else:
            nx = x + rng.uniform(-step_p, step_p)
            ny = y + rng.uniform(-step_p, step_p)
            ns = s + rng.uniform(0, step_s)
            c[i] = (nx, ny, a, ns)
        if _feasible(c):
            ns2 = _score(c)
            if ns2 >= cur_s:
                cur = c
                cur_s = ns2
                if ns2 > best_s:
                    best = list(c)
                    best_s = ns2
    return best


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # start from grid, then refine
    sqs = _grid_init(n)
    sqs = _refine(sqs, 12000)
    # squeeze remaining zero-size squares to a valid point
    out = []
    for (x, y, a, s) in sqs:
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        s = max(s, 0.0)
        out.append((x, y, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
