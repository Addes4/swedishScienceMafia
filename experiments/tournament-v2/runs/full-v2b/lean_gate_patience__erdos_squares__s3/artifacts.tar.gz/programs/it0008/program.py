# EVOLVE-BLOCK-START
"""Asymmetric-grid packing with refined leftover handling.

For each n we search over grid splits: choose r rows and c columns, plus
distribute leftover squares into a full extra row or column, using side
= min(1/c, 1/r) for the shared grid and a smaller side for extras placed
in leftover strips. We pick the split maximizing total side length and
always keep axis-aligned (angle=0).
"""
import math


def solve(n):
    if n <= 0:
        return []

    best_squares = None
    best_sum = -1.0

    # helper: place r*c grid of side s, then extras in remaining strip
    def build(r, c, extra_mode):
        s = min(1.0 / c, 1.0 / r)
        if s <= 0:
            return None
        sq = []
        used = r * c
        # main grid: width c*s, height r*s, centered
        gw = c * s
        gh = r * s
        ox = (1.0 - gw) / 2.0
        oy = (1.0 - gh) / 2.0
        for i in range(c):
            for j in range(r):
                sq.append((ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s))
        left = n - used
        if left < 0:
            return None
        if left == 0:
            return sq
        # remaining rectangle(s): right strip (1-gw) x 1 and top strip gw x (1-gh)
        # place leftover squares greedily into the bigger strip(s)
        free = []
        if 1.0 - gw > 1e-12:
            free.append((gw, 0.0, 1.0 - gw, 1.0))
        if 1.0 - gh > 1e-12:
            free.append((0.0, gh, gw, 1.0))
        free.sort(key=lambda t: -(t[2] * t[3]))
        for (fx, fy, fw, fh) in free:
            if left <= 0:
                break
            # fit a sub-grid of leftover squares in this strip
            k = left
            m = max(1, math.isqrt(k))
            for rr in range(1, m + 1):
                cc = k // rr
                if cc < 1:
                    break
                # use all of them in one grid
                ss = min(fw / cc, fh / rr) if cc > 0 and rr > 0 else 0
                if ss <= 1e-12:
                    continue
                take = rr * cc
                for i in range(cc):
                    for j in range(rr):
                        sq.append((fx + (i + 0.5) * ss, fy + (j + 0.5) * ss, 0.0, ss))
                left -= take
                break
        # if still leftover, drop as zero-size points
        while left > 0:
            sq.append((0.5, 0.5, 0.0, 0.0))
            left -= 1
        return sq

    # search over r (rows), c (cols) with r*c <= n and r close to c
    for r in range(1, n + 1):
        for c in range(r, n + 1):
            if r * c > n:
                break
            sq = build(r, c, 0)
            if sq is None:
                continue
            tot = sum(x[3] for x in sq)
            if tot > best_sum:
                best_sum = tot
                best_squares = sq

    if best_squares is None:
        best_squares = [(0.5, 0.5, 0.0, 0.0)] * n

    res = []
    for cx, cy, a, s in best_squares:
        if s < 0:
            s = 0.0
        if s > 1.0:
            s = 1.0
        lo, hi = s / 2, 1 - s / 2
        if lo > hi:
            cx = cy = 0.5
        else:
            cx = min(max(cx, lo), hi)
            cy = min(max(cy, lo), hi)
        res.append((cx, cy, 0.0, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
# EVOLVE-BLOCK-END
