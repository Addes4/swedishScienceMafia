# EVOLVE-BLOCK-START
"""Recursive guillotine construction plus randomized local search."""
import math
import random


def _corners(cx, cy, ang, s):
    """Four corners of a square as (x, y) tuples."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap(c1, c2):
    """Exact separating-axis test for two rotated squares (convex)."""
    for pts in (c1, c2):
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            nx, ny = -(y2 - y1), (x2 - x1)
            min1 = max1 = None
            for (px, py) in c1:
                d = px * nx + py * ny
                if min1 is None or d < min1:
                    min1 = d
                if max1 is None or d > max1:
                    max1 = d
            min2 = max2 = None
            for (px, py) in c2:
                d = px * nx + py * ny
                if min2 is None or d < min2:
                    min2 = d
                if max2 is None or d > max2:
                    max2 = d
            if max1 <= min2 or max2 <= min1:
                return False
    return True


def _in_bounds(c):
    for x, y in c:
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _guillotine(n):
    """Recursively split the unit square; place one square in each cell."""
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        idx = 0
        best = -1.0
        for i, (x, y, w, h) in enumerate(cells):
            v = min(w, h) * max(w, h)
            if v > best:
                best = v
                idx = i
        x, y, w, h = cells.pop(idx)
        frac = random.uniform(0.35, 0.65)
        if w >= h:
            w1 = w * frac
            cells.append((x, y, w1, h))
            cells.append((x + w1, y, w - w1, h))
        else:
            h1 = h * frac
            cells.append((x, y, w, h1))
            cells.append((x, y + h1, w, h - h1))

    squares = []
    for (x, y, w, h) in cells:
        s = min(w, h)
        cx = x + w * 0.5
        cy = y + h * 0.5
        squares.append([cx, cy, 0.0, s])
    return squares


def _any_overlap(squares, cand_idx, cand):
    """Check candidate against all others and bounds."""
    c1 = _corners(*cand)
    if not _in_bounds(c1):
        return True
    for i, sq in enumerate(squares):
        if i == cand_idx:
            continue
        if _overlap(c1, _corners(*sq)):
            return True
    return False


def _free_side(squares, cand_idx, cx, cy, ang, smax=1.0):
    """Binary-search the largest side s<=smax that fits at (cx,cy,ang)."""
    lo, hi = 0.0, smax
    if not _any_overlap_scale(squares, cand_idx, cx, cy, ang, lo):
        return 0.0
    for _ in range(24):
        mid = 0.5 * (lo + hi)
        if _any_overlap_scale(squares, cand_idx, cx, cy, ang, mid):
            lo = mid
        else:
            hi = mid
    return lo


def _any_overlap_scale(squares, cand_idx, cx, cy, ang, s):
    if s <= 0.0:
        return False
    return _any_overlap(squares, cand_idx, (cx, cy, ang, s))


def _best_insert(squares, cand_idx, smax=1.0):
    """Try many (center, angle) candidates; return best (cx,cy,ang,s) or None."""
    others = [sq for i, sq in enumerate(squares) if i != cand_idx]
    cands = []

    # boundary anchors
    for x in (0.0, 1.0):
        for y in (0.0, 1.0):
            cands.append((x, y))
    # corners of other squares and offsets
    for sq in others:
        for (px, py) in _corners(*sq):
            cands.append((px, py))
            cands.append((px + 0.02, py))
            cands.append((px - 0.02, py))
            cands.append((px, py + 0.02))
            cands.append((px, py - 0.02))
    # midpoints of edges
    for sq in others:
        cx0, cy0, ang0, s0 = sq
        for d in (-0.5, 0.0, 0.5):
            cands.append((cx0 + d * s0, cy0))
            cands.append((cx0, cy0 + d * s0))

    angles = [0.0, 0.25, 0.125, 0.375, 0.0625, 0.1875, 0.3125, 0.4375,
              0.5, 0.75, 0.0625, 0.03125, 0.09375]

    best = None
    best_s = -1.0
    for (cx, cy) in cands:
        if cx < 0.0 or cx > 1.0 or cy < 0.0 or cy > 1.0:
            continue
        for ang in angles:
            s = _free_side(squares, cand_idx, cx, cy, ang, smax)
            if s > best_s:
                # local refine center
                rcx, rcy, rs, rang = cx, cy, s, ang
                for _ in range(6):
                    improved = False
                    for dx, dy in ((0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01)):
                        ncx, ncy = rcx + dx, rcy + dy
                        if ncx < 0.0 or ncx > 1.0 or ncy < 0.0 or ncy > 1.0:
                            continue
                        ns = _free_side(squares, cand_idx, ncx, ncy, rang, smax)
                        if ns > rs:
                            rcx, rcy, rs = ncx, ncy, ns
                            improved = True
                    if not improved:
                        break
                if rs > best_s:
                    best_s = rs
                    best = (rcx, rcy, rang, rs)
    return best


def _repair(squares, rng):
    """Repeatedly remove-and-reinsert single squares to improve total."""
    n = len(squares)
    improved = False
    for _ in range(200):
        # choose a target square
        i = rng.randrange(n)
        old = squares[i]
        squares[i] = [0.5, 0.5, 0.0, 0.0]  # effectively removed
        cand = _best_insert(squares, i, smax=1.0)
        if cand is not None and cand[3] > old[3] + 1e-9:
            squares[i] = list(cand)
            improved = True
        else:
            squares[i] = old
    return improved


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345)
    random.seed(12345)

    best = None
    best_sum = -1.0

    for trial in range(5):
        sq = _guillotine(n)
        sq = [s for s in sq if s[3] > 1e-9]
        while len(sq) < n:
            sq.append([0.5, 0.5, 0.0, 0.0])

        improve_local(sq, rng)
        # polish with remove-and-reinsert
        for _ in range(3):
            if not _repair(sq, rng):
                break
            improve_local(sq, rng)

        tot = sum(s[3] for s in sq)
        if tot > best_sum:
            best_sum = tot
            best = [tuple(s) for s in sq]

    return best


def improve_local(squares, rng):
    """Randomized grow / shift / rotate moves with exact overlap rejection."""
    n = len(squares)
    if n == 0:
        return

    for _ in range(4000):
        i = rng.randrange(n)
        cx, cy, ang, s = squares[i]
        move = rng.random()

        if move < 0.5:
            factor = 1.0 + rng.uniform(0.01, 0.25)
            ns = s * factor
            best_cand = None
            for _t in range(12):
                if _t == 0:
                    ncx, ncy = cx, cy
                else:
                    ncx = cx + rng.uniform(-0.05, 0.05)
                    ncy = cy + rng.uniform(-0.05, 0.05)
                    ncx = min(max(ncx, 0.0), 1.0)
                    ncy = min(max(ncy, 0.0), 1.0)
                if ns > 1.0:
                    break
                cand = (ncx, ncy, ang, ns)
                if not _any_overlap(squares, i, cand):
                    if best_cand is None or ns > best_cand[3]:
                        best_cand = cand
                    break
            if best_cand is not None and best_cand[3] > s:
                squares[i] = list(best_cand)
        elif move < 0.78:
            ncx = cx + rng.uniform(-0.06, 0.06)
            ncy = cy + rng.uniform(-0.06, 0.06)
            ncx = min(max(ncx, 0.0), 1.0)
            ncy = min(max(ncy, 0.0), 1.0)
            ns = s * (1.0 + rng.uniform(-0.03, 0.12))
            if ns > 1.0:
                ns = 1.0
            cand = (ncx, ncy, ang, ns)
            if not _any_overlap(squares, i, cand):
                squares[i] = list(cand)
        else:
            nang = (ang + rng.uniform(-0.06, 0.06)) % 1.0
            ns = s * (1.0 + rng.uniform(-0.02, 0.06))
            if ns > 1.0:
                ns = 1.0
            cand = (cx, cy, nang, ns)
            if not _any_overlap(squares, i, cand):
                squares[i] = list(cand)
# EVOLVE-BLOCK-END

