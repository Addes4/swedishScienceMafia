# EVOLVE-BLOCK-START
"""Recursive guillotine construction + dense-placement polish for packing squares.

Approach:
  1. Build guillotine / grid seeds of axis-aligned squares inside the unit square.
  2. Randomized local search with exact SAT overlap tests (grow/shift/rotate).
  3. Deterministic polish: remove the weakest square and reinsert it at its best
     feasible placement found by a DENSE scan over centres x angles (binary
     search of max feasible side at each candidate), interleaved with repeated
     grow-to-max sweeps.
"""
import math
import random

# -------------------- exact overlap test for two rotated squares --------------------

def _corners(cx, cy, ang, s):
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + c * dx - sn * dy, cy + sn * dx + c * dy))
    return pts


def _axes(ang):
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    return (c, sn), (-sn, c)


def _project(pts, ax):
    ax_, ay_ = ax
    vals = [p[0] * ax_ + p[1] * ay_ for p in pts]
    return min(vals), max(vals)


def _overlap(a, b):
    """True if interiors of two squares (cx,cy,ang,s) overlap. Touching is OK."""
    ax1 = _axes(a[2])
    ax2 = _axes(b[2])
    pa = _corners(*a)
    pb = _corners(*b)
    EPS = 1e-12
    for ax in (ax1[0], ax1[1], ax2[0], ax2[1]):
        lo1, hi1 = _project(pa, ax)
        lo2, hi2 = _project(pb, ax)
        if hi1 <= lo2 + EPS or hi2 <= lo1 + EPS:
            return False
    return True


def _inside(cx, cy, ang, s):
    for x, y in _corners(cx, cy, ang, s):
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _ok(sq, others):
    for o in others:
        if _overlap(sq, o):
            return False
    return True


# -------------------- feasible-side helpers --------------------

def _max_side_at(cx, cy, ang, others, hi=1.0):
    """Largest s such that square (cx,cy,ang,s) is inside and non-overlapping."""
    if not _inside(cx, cy, ang, hi):
        h = hi
        l = 0.0
        for _ in range(40):
            m = 0.5 * (l + h)
            if _inside(cx, cy, ang, m):
                l = m
            else:
                h = m
        hi = l
    if hi <= 1e-12:
        return 0.0
    if _ok((cx, cy, ang, hi), others):
        return hi
    l = 0.0
    h = hi
    for _ in range(40):
        m = 0.5 * (l + h)
        if _ok((cx, cy, ang, m), others):
            l = m
        else:
            h = m
    return l


def _dense_insert(others, rng, grid=26, ntries=400):
    """Dense scan for a placement with the largest feasible side.

    Scans a fine grid of centres crossed with structured angle candidates,
    plus random samples, keeping the global best.
    """
    best = None
    best_s = -1.0
    angles = [0.0, 0.25, 0.5, 0.0625, 0.125, 0.1875, 0.3125, 0.375, 0.4375,
              0.5625, 0.625, 0.6875, 0.75, 0.875]
    # structured grid x angles
    for gi in range(grid):
        cx = (gi + 0.5) / grid
        for gj in range(grid):
            cy = (gj + 0.5) / grid
            for a in angles:
                s = _max_side_at(cx, cy, a, others)
                if s > best_s:
                    best_s = s
                    best = (cx, cy, a, s)
    # random sampling for fine tuning
    for _ in range(ntries):
        cx = rng.random()
        cy = rng.random()
        a = rng.random()
        s = _max_side_at(cx, cy, a, others)
        if s > best_s:
            best_s = s
            best = (cx, cy, a, s)
    return best


def _grow_sweeps(S, order, passes=3):
    for _ in range(passes):
        changed = False
        for i in order:
            others = S[:i] + S[i + 1:]
            cx, cy, ang, s = S[i]
            ns = _max_side_at(cx, cy, ang, others)
            if ns > s + 1e-12:
                S[i] = [cx, cy, ang, ns]
                changed = True
        if not changed:
            break


def _polish(S, rng, rounds=6, dense=True):
    """Remove weakest square, reinsert at best (dense) placement + grow sweeps."""
    n = len(S)
    order = list(range(n))
    _grow_sweeps(S, order, passes=3)
    for _ in range(rounds):
        order.sort(key=lambda i: S[i][3])
        prog = False
        for i in order[:max(1, n)]:
            removed = S[i]
            others = S[:i] + S[i + 1:]
            if dense:
                cand = _dense_insert(others, rng)
            else:
                cand = _quick_insert(others, rng)
            if cand is not None and cand[3] > removed[3] + 1e-12:
                S[i] = list(cand)
                prog = True
        _grow_sweeps(S, order, passes=2)
        if not prog:
            break
    return S


def _quick_insert(others, rng, tries=60):
    """Cheaper placement search used during inner rounds."""
    best = None
    best_s = -1.0
    angles = [0.0, 0.25, 0.125, 0.375, 0.5, 0.0625, 0.1875, 0.3125, 0.75]
    for t in range(tries):
        if t < len(angles):
            ang = angles[t]
        else:
            ang = rng.random()
        cx = rng.random()
        cy = rng.random()
        s = _max_side_at(cx, cy, ang, others)
        if s > best_s:
            best_s = s
            best = (cx, cy, ang, s)
    gs = 5
    for gi in range(gs):
        for gj in range(gs):
            cx = (gi + 0.5) / gs
            cy = (gj + 0.5) / gs
            ang = angles[(gi + gj) % len(angles)]
            s = _max_side_at(cx, cy, ang, others)
            if s > best_s:
                best_s = s
                best = (cx, cy, ang, s)
    return best


# -------------------- constructions --------------------

def _construct(n):
    if n == 0:
        return []
    squares = []

    def rec(x0, y0, x1, y1, cnt):
        if cnt <= 0:
            return
        w, h = x1 - x0, y1 - y0
        if cnt == 1:
            s = min(w, h) * 0.995
            squares.append((x0 + w * 0.5, y0 + h * 0.5, 0.0, s))
            return
        k1 = max(1, cnt // 2)
        k2 = cnt - k1
        fr = math.sqrt(k1) / (math.sqrt(k1) + math.sqrt(k2))
        fr = min(max(fr, 0.2), 0.8)
        if w >= h:
            xm = x0 + w * fr
            rec(x0, y0, xm, y1, k1)
            rec(xm, y0, x1, y1, k2)
        else:
            ym = y0 + h * fr
            rec(x0, y0, x1, ym, k1)
            rec(x0, ym, x1, y1, k2)

    rec(0.0, 0.0, 1.0, 1.0, n)
    return squares


def _grid_seed(n):
    k = int(math.ceil(math.sqrt(n)))
    s = 1.0 / k
    out = []
    cnt = 0
    for i in range(k):
        for j in range(k):
            if cnt >= n:
                break
            out.append((s * (i + 0.5), s * (j + 0.5), 0.0, s * 0.999))
            cnt += 1
    return out


# -------------------- local search --------------------

def _local_search(squares, n, rng, iters=3000):
    S = [list(s) for s in squares]
    if len(S) < n:
        S += [[0.5, 0.5, 0.0, 0.0]] * (n - len(S))
    S = S[:n]

    for it in range(iters):
        i = rng.randrange(n)
        old = S[i][:]
        mode = rng.random()
        if mode < 0.5:
            factor = rng.uniform(0.9, 1.5)
            cand = [old[0], old[1], old[2], max(0.0, old[3] * factor)]
        elif mode < 0.8:
            d = old[3] * 0.6 + 0.05
            cand = [old[0] + rng.uniform(-d, d),
                    old[1] + rng.uniform(-d, d),
                    old[2], old[3]]
        else:
            cand = [old[0], old[1], (old[2] + rng.uniform(-0.25, 0.25)) % 1.0, old[3]]
        cand[0] = min(max(cand[0], 0.0), 1.0)
        cand[1] = min(max(cand[1], 0.0), 1.0)
        if cand[3] <= 1e-12:
            cand[3] = 0.0
            continue
        if not _inside(cand[0], cand[1], cand[2], cand[3]):
            continue
        others = S[:i] + S[i + 1:]
        if not _ok(cand, others):
            continue
        if cand[3] >= old[3] - 1e-12 or rng.random() < 0.02:
            S[i] = cand

    return S


# -------------------- main solve --------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    seeds = [_construct(n), _grid_seed(n)]
    for att in range(2):
        seeds.append(_construct(n))

    best = None
    best_score = -1.0
    for att, base in enumerate(seeds):
        r = random.Random(98765 + 13 * n + att)
        cand = _local_search(base, n, r, iters=2000)
        cand = _polish(cand, r, rounds=4, dense=False)
        sc = sum(s[3] for s in cand)
        if sc > best_score:
            best_score = sc
            best = cand

    # final strong polish with dense reinsertion
    r = random.Random(555 + n)
    best = _polish(best, r, rounds=6, dense=True)

    out = []
    for cx, cy, a, s in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        guard = 0
        while not _inside(cx, cy, a, s) and s > 1e-9 and guard < 50:
            s *= 0.9
            guard += 1
        if s < 1e-9:
            s = 0.0
        out.append((cx, cy, a, s))

    changed = True
    guard = 0
    while changed and guard < 200:
        changed = False
        for i in range(len(out)):
            for j in range(i + 1, len(out)):
                if _overlap(out[i], out[j]):
                    a, b = out[i], out[j]
                    if a[3] >= b[3]:
                        out[j] = (b[0], b[1], b[2], b[3] * 0.8)
                    else:
                        out[i] = (a[0], a[1], a[2], a[3] * 0.8)
                    changed = True
        guard += 1

    return out[:n]
# EVOLVE-BLOCK-END
