# EVOLVE-BLOCK-START
"""Recursive guillotine construction plus deterministic grow-to-max polish
and randomized perturbation search."""
import math
import random


def _corners(cx, cy, ang, s):
    """Four corners of a square as (x, y) tuples."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap(c1, c2):
    """Exact separating-axis test for two rotated squares (convex)."""
    for pts in (c1, c2):
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            nx, ny = -(y2 - y1), (x2 - x1)
            min1 = max1 = None
            for (px, py) in c1:
                d = px * nx + py * ny
                if min1 is None or d < min1:
                    min1 = d
                if max1 is None or d > max1:
                    max1 = d
            min2 = max2 = None
            for (px, py) in c2:
                d = px * nx + py * ny
                if min2 is None or d < min2:
                    min2 = d
                if max2 is None or d > max2:
                    max2 = d
            if max1 <= min2 or max2 <= min1:
                return False
    return True


def _in_bounds(c):
    for x, y in c:
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _guillotine(n, rng):
    """Recursively split the unit square; place one square in each cell."""
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        idx = 0
        best = -1.0
        for i, (x, y, w, h) in enumerate(cells):
            v = min(w, h) * max(w, h)
            if v > best:
                best = v
                idx = i
        x, y, w, h = cells.pop(idx)
        frac = rng.uniform(0.3, 0.7)
        if w >= h:
            w1 = w * frac
            cells.append((x, y, w1, h))
            cells.append((x + w1, y, w - w1, h))
        else:
            h1 = h * frac
            cells.append((x, y, w, h1))
            cells.append((x, y + h1, w, h - h1))

    squares = []
    for (x, y, w, h) in cells:
        s = min(w, h)
        cx = x + w * 0.5
        cy = y + h * 0.5
        squares.append([cx, cy, 0.0, s])
    return squares


def _feasible(squares, i, cx, cy, ang, s):
    """Check candidate square i at given placement against bounds and others."""
    cand = (cx, cy, ang, s)
    c1 = _corners(*cand)
    if not _in_bounds(c1):
        return False
    for j, sq in enumerate(squares):
        if j == i:
            continue
        if sq[3] <= 1e-12:
            continue
        if _overlap(c1, _corners(*sq)):
            return False
    return True


def _max_side(squares, i, cx, cy, ang, lo, hi):
    """Binary search max feasible side for square i at (cx,cy,ang), in [lo,hi]."""
    if not _feasible(squares, i, cx, cy, ang, lo):
        return None
    if _feasible(squares, i, cx, cy, ang, hi):
        return hi
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        if _feasible(squares, i, cx, cy, ang, mid):
            lo = mid
        else:
            hi = mid
    return lo


def _grow_polish(squares, rng, sweeps=6):
    """Repeatedly grow each square to its max feasible side at several
    candidate centres/angles, keeping any improvement."""
    n = len(squares)
    for _ in range(sweeps):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            bestc = (cx, cy, ang)
            # candidate placements: current, plus jittered centres and angles
            cands = [(cx, cy, ang)]
            for _t in range(8):
                jx = cx + rng.uniform(-0.12, 0.12)
                jy = cy + rng.uniform(-0.12, 0.12)
                jx = min(max(jx, 0.0), 1.0)
                jy = min(max(jy, 0.0), 1.0)
                ja = (ang + rng.uniform(-0.15, 0.15)) % 1.0
                cands.append((jx, jy, ja))
            for (nx, ny, na) in cands:
                ms = _max_side(squares, i, nx, ny, na, 0.0, 1.0)
                if ms is not None and ms > best + 1e-9:
                    best = ms
                    bestc = (nx, ny, na)
            if best > s + 1e-9:
                squares[i] = [bestc[0], bestc[1], bestc[2], best]
                improved = True
        if not improved:
            break


def _local_perturb(squares, rng, iters=1500):
    """Randomized grow / shift / rotate moves with exact overlap rejection."""
    n = len(squares)
    if n == 0:
        return
    for _ in range(iters):
        i = rng.randrange(n)
        cx, cy, ang, s = squares[i]
        move = rng.random()
        if move < 0.55:
            factor = 1.0 + rng.uniform(0.01, 0.3)
            ns = min(s * factor, 1.0)
            ncx = cx + rng.uniform(-0.04, 0.04)
            ncy = cy + rng.uniform(-0.04, 0.04)
            ncx = min(max(ncx, 0.0), 1.0)
            ncy = min(max(ncy, 0.0), 1.0)
            if _feasible(squares, i, ncx, ncy, ang, ns):
                squares[i] = [ncx, ncy, ang, ns]
        elif move < 0.8:
            ncx = cx + rng.uniform(-0.06, 0.06)
            ncy = cy + rng.uniform(-0.06, 0.06)
            ncx = min(max(ncx, 0.0), 1.0)
            ncy = min(max(ncy, 0.0), 1.0)
            ns = min(s * (1.0 + rng.uniform(-0.03, 0.15)), 1.0)
            if _feasible(squares, i, ncx, ncy, ang, ns):
                squares[i] = [ncx, ncy, ang, ns]
        else:
            nang = (ang + rng.uniform(-0.08, 0.08)) % 1.0
            ns = min(s * (1.0 + rng.uniform(-0.02, 0.08)), 1.0)
            if _feasible(squares, i, cx, cy, nang, ns):
                squares[i] = [cx, cy, nang, ns]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(987654321)
    random.seed(987654321)

    best = None
    best_sum = -1.0

    seeds = []
    for _ in range(10):
        seeds.append(_guillotine(n, rng))

    for seed in seeds:
        sq = [list(s) for s in seed]
        sq = [s for s in sq if s[3] > 1e-9]
        while len(sq) < n:
            sq.append([0.5, 0.5, 0.0, 0.0])
        _grow_polish(sq, rng, sweeps=5)
        _local_perturb(sq, rng, iters=1200)
        _grow_polish(sq, rng, sweeps=3)
        tot = sum(s[3] for s in sq)
        if tot > best_sum:
            best_sum = tot
            best = [tuple(s) for s in sq]

    return best
# EVOLVE-BLOCK-END

