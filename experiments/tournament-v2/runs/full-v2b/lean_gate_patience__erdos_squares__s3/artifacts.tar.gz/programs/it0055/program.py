# EVOLVE-BLOCK-START
"""Recursive guillotine packing + randomized local search with SAT overlap checks."""
import math
import random


def _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    if s1 <= 0.0 or s2 <= 0.0:
        return False
    t1 = a1 * 2.0 * math.pi
    t2 = a2 * 2.0 * math.pi
    c1, sn1 = math.cos(t1), math.sin(t1)
    c2, sn2 = math.cos(t2), math.sin(t2)
    axes = [(c1, sn1), (-sn1, c1), (c2, sn2), (-sn2, c2)]
    for ax, ay in axes:
        r1 = (s1 * 0.5) * (abs(c1 * ax + sn1 * ay) + abs(-sn1 * ax + c1 * ay))
        r2 = (s2 * 0.5) * (abs(c2 * ax + sn2 * ay) + abs(-sn2 * ax + c2 * ay))
        d = abs((cx1 - cx2) * ax + (cy1 - cy2) * ay)
        if d >= r1 + r2 - 1e-12:
            return False
    return True


def _inside_square(cx, cy, ang, s):
    if s <= 0.0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    t = ang * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    for ex, ey in ((h, h), (h, -h), (-h, h), (-h, -h)):
        x = cx + c * ex - sn * ey
        y = cy + sn * ex + c * ey
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _total(squares):
    return sum(s[3] for s in squares)


def _valid(squares, i, cx, cy, ang, s):
    if not _inside_square(cx, cy, ang, s):
        return False
    n = len(squares)
    for j in range(n):
        if j == i:
            continue
        ox, oy, oa, os_ = squares[j]
        if _overlap(cx, cy, ang, s, ox, oy, oa, os_):
            return False
    return True


def _construct_rand(n, rng):
    tasks = [(0.0, 0.0, 1.0, 1.0, n)]
    results = []
    while tasks:
        x, y, w, h, k = tasks.pop()
        if k <= 0:
            continue
        if k == 1:
            side = min(w, h)
            s = side * rng.uniform(0.97, 0.999)
            results.append([x + w * 0.5, y + h * 0.5, 0.0, s])
            continue
        if w >= h:
            r = rng.uniform(0.33, 0.67)
            k1 = max(1, min(k - 1, int(round(k * r))))
            k2 = k - k1
            w1 = w * (k1 / k)
            w2 = w - w1
            tasks.append((x, y, w1, h, k1))
            tasks.append((x + w1, y, w2, h, k2))
        else:
            r = rng.uniform(0.33, 0.67)
            k1 = max(1, min(k - 1, int(round(k * r))))
            k2 = k - k1
            h1 = h * (k1 / k)
            h2 = h - h1
            tasks.append((x, y, w, h1, k1))
            tasks.append((x, y + h1, w, h2, k2))
    return results


def _max_side(squares, i, cx, cy, ang, cap):
    """Binary search largest feasible side for square i (others fixed)."""
    lo, hi = 0.0, cap
    # ensure lo feasible (side 0 basically always ok if center inside)
    if _valid(squares, i, cx, cy, ang, 0.0):
        lo = 0.0
    else:
        return None
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        if _valid(squares, i, cx, cy, ang, mid):
            lo = mid
        else:
            hi = mid
    return lo


def _grow_sweep(squares, rng, passes=3):
    n = len(squares)
    order = list(range(n))
    for _ in range(passes):
        rng.shuffle(order)
        any_change = False
        for i in order:
            cx, cy, ang, s = squares[i]
            cap = min(1.0, 2.0 * min(cx, 1 - cx, cy, 1 - cy) + s + 0.05)
            cap = max(cap, s, 0.99)
            ms = _max_side(squares, i, cx, cy, ang, cap)
            if ms is not None and ms > s + 1e-9:
                squares[i][3] = ms
                any_change = True
        if not any_change:
            break
    return squares


def _local_search(squares, rng, iters=1500):
    n = len(squares)
    if n == 0:
        return squares
    cur = [list(s) for s in squares]
    cur_score = _total(cur)

    for it in range(iters):
        i = rng.randrange(n)
        cx, cy, ang, s = cur[i]
        move = rng.random()
        if move < 0.55:
            factor = rng.uniform(1.0, 1.15)
            ns = min(max(s * factor, 0.0), 1.0)
            nc_x, nc_y, nang = cx, cy, ang
        elif move < 0.8:
            d = rng.uniform(0.0, 0.08)
            theta = rng.uniform(0.0, 2.0 * math.pi)
            nc_x = cx + d * math.cos(theta)
            nc_y = cy + d * math.sin(theta)
            ns = s
            nang = ang
        elif move < 0.92:
            nang = (ang + rng.choice([-1, 1]) * rng.uniform(0.0, 0.05)) % 1.0
            nc_x, nc_y, ns = cx, cy, s
        else:
            ns = s * rng.uniform(0.8, 1.0)
            nc_x, nc_y, nang = cx, cy, ang

        if not _valid(cur, i, nc_x, nc_y, nang, ns):
            continue

        old = cur[i]
        cur[i] = [nc_x, nc_y, nang, ns]
        new_score = cur_score - old[3] + ns
        if new_score >= cur_score - 1e-12:
            cur_score = new_score
        else:
            cur[i] = old

    # grow sweep polish
    cur = _grow_sweep(cur, rng, passes=4)
    return cur


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    best = None
    best_score = -1.0

    restarts = 8 if n <= 60 else 4
    for _ in range(restarts):
        squares = _construct_rand(n, rng)
        squares = _local_search(squares, rng, iters=300 + 20 * n)
        sc = _total(squares)
        if sc > best_score:
            best_score = sc
            best = squares

    # final polish: alternate grow sweep and local search
    for _ in range(3):
        best = _grow_sweep(best, rng, passes=4)
        best = _local_search(best, rng, iters=200 + 15 * n)
    best = _grow_sweep(best, rng, passes=6)
    return [(float(cx), float(cy), float(ang), float(s)) for cx, cy, ang, s in best]
# EVOLVE-BLOCK-END
