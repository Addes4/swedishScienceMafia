# EVOLVE-BLOCK-START
"""Iterated grow-repack packing with exact SAT overlap checks for rotated squares."""
import math
import random


def _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """True if two squares (centre, angle as fraction of turn, side) have overlapping interiors."""
    if s1 <= 0.0 or s2 <= 0.0:
        return False
    t1 = a1 * 2.0 * math.pi
    t2 = a2 * 2.0 * math.pi
    c1, sn1 = math.cos(t1), math.sin(t1)
    c2, sn2 = math.cos(t2), math.sin(t2)
    axes = ((c1, sn1), (-sn1, c1), (c2, sn2), (-sn2, c2))
    for ax, ay in axes:
        r1 = (s1 * 0.5) * (abs(c1 * ax + sn1 * ay) + abs(-sn1 * ax + c1 * ay))
        r2 = (s2 * 0.5) * (abs(c2 * ax + sn2 * ay) + abs(-sn2 * ax + c2 * ay))
        d = abs((cx1 - cx2) * ax + (cy1 - cy2) * ay)
        if d >= r1 + r2 - 1e-12:
            return False
    return True


def _inside(cx, cy, ang, s):
    if s <= 0.0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    t = ang * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    for ex, ey in ((h, h), (h, -h), (-h, h), (-h, -h)):
        x = cx + c * ex - sn * ey
        y = cy + sn * ex + c * ey
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _feasible(squares, i, cx, cy, ang, s):
    if s > 1.0 + 1e-12:
        return False
    if not _inside(cx, cy, ang, s):
        return False
    for j in range(len(squares)):
        if j == i:
            continue
        ox, oy, oa, os_ = squares[j]
        if _overlap(cx, cy, ang, s, ox, oy, oa, os_):
            return False
    return True


def _max_side(squares, i, cx, cy, ang, hi=1.0):
    """Binary search the largest feasible side for square i at (cx,cy,ang)."""
    if not _feasible(squares, i, cx, cy, ang, 0.0):
        return 0.0
    lo = 0.0
    if _feasible(squares, i, cx, cy, ang, hi):
        return hi
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        if _feasible(squares, i, cx, cy, ang, mid):
            lo = mid
        else:
            hi = mid
    return lo


def _construct_grid(n):
    """Axis-aligned grid based on a near-square factorisation, filling [0,1]^2."""
    best = None
    best_sum = -1.0
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        if rows * cols < n:
            continue
        w = 1.0 / cols
        h = 1.0 / rows
        s = min(w, h)
        sq = []
        cnt = 0
        for r in range(rows):
            for c in range(cols):
                if cnt >= n:
                    break
                cx = (c + 0.5) * w
                cy = (r + 0.5) * h
                sq.append([cx, cy, 0.0, s])
                cnt += 1
            if cnt >= n:
                break
        total = sum(x[3] for x in sq)
        # prefer fewer spurious rows but larger side: keep max total
        if total > best_sum:
            best_sum = total
            best = sq
    return best


def _fast_grow(squares):
    """Sequentially grow each square to its max feasible side at its current centre/angle."""
    n = len(squares)
    # temporary shrink so others can be grown into freed space
    for i in range(n):
        cx, cy, ang, s = squares[i]
        ns = _max_side(squares, i, cx, cy, ang, min(1.0, 2.0 * (s + 0.2)))
        if ns > s:
            squares[i] = [cx, cy, ang, ns]
    # second pass in reverse at slightly jittered positions
    for i in range(n - 1, -1, -1):
        cx, cy, ang, s = squares[i]
        ns = _max_side(squares, i, cx, cy, ang, min(1.0, 2.0 * (s + 0.2)))
        if ns > s:
            squares[i] = [cx, cy, ang, ns]
    return squares


def _iterated_repack(n, seed_squares, rng, rounds=40):
    cur = [list(s) for s in seed_squares]
    cur = _fast_grow(cur)
    best = [list(s) for s in cur]
    best_sum = sum(s[3] for s in best)

    for _ in range(rounds):
        # perturb: jitter positions & angles, then regrow
        cand = [list(s) for s in best]
        for i in range(n):
            if rng.random() < 0.6:
                d = rng.uniform(0.0, 0.06)
                th = rng.uniform(0.0, 2.0 * math.pi)
                cx = cand[i][0] + d * math.cos(th)
                cy = cand[i][1] + d * math.sin(th)
                cx = min(max(cx, 0.0), 1.0)
                cy = min(max(cy, 0.0), 1.0)
                cand[i][0] = cx
                cand[i][1] = cy
            if rng.random() < 0.3:
                cand[i][2] = (cand[i][2] + rng.choice([-1, 1]) * rng.uniform(0.0, 0.08)) % 1.0
            if not _inside(cand[i][0], cand[i][1], cand[i][2], cand[i][3]):
                # shrink to restore inside
                cand[i][3] *= 0.98
                if not _inside(cand[i][0], cand[i][1], cand[i][2], cand[i][3]):
                    cand[i][3] = 0.0
        # order by descending size for the grow pass
        order = sorted(range(n), key=lambda k: -cand[k][3])
        reordered = [cand[k] for k in order]
        # individual grow using original indices
        for ii in range(n):
            cx, cy, ang, s = reordered[ii]
            if not _inside(cx, cy, ang, s):
                s = 0.0
                reordered[ii] = [cx, cy, ang, s]
            ns = _max_side_reorder(reordered, ii, cx, cy, ang, min(1.0, s + 0.3))
            if ns > s:
                reordered[ii] = [cx, cy, ang, ns]
        cand = reordered
        ssum = sum(s[3] for s in cand)
        if ssum > best_sum + 1e-9:
            best_sum = ssum
            best = [list(s) for s in cand]
        # mild local translate search to compact
        best = _compact(best, rng, n)
        best_sum = sum(s[3] for s in best)
    return best


def _max_side_reorder(squares, i, cx, cy, ang, hi):
    if hi <= 0.0:
        return 0.0
    if not _feasible(squares, i, cx, cy, ang, 0.0):
        return 0.0
    if _feasible(squares, i, cx, cy, ang, hi):
        return hi
    lo = 0.0
    for _ in range(36):
        mid = 0.5 * (lo + hi)
        if _feasible(squares, i, cx, cy, ang, mid):
            lo = mid
        else:
            hi = mid
    return lo


def _compact(squares, rng, n):
    """Try small translations that keep feasibility and allow regrowth; keep the best scoring."""
    cur = [list(s) for s in squares]
    cur_sum = sum(s[3] for s in cur)
    for _ in range(2 * n + 40):
        i = rng.randrange(n)
        cx, cy, ang, s = cur[i]
        d = rng.uniform(0.0, 0.03)
        th = rng.uniform(0.0, 2.0 * math.pi)
        nx = min(max(cx + d * math.cos(th), 0.0), 1.0)
        ny = min(max(cy + d * math.sin(th), 0.0), 1.0)
        if not _inside(nx, ny, ang, s):
            continue
        if not _feasible(cur, i, nx, ny, ang, s):
            continue
        cur[i] = [nx, ny, ang, s]
        ns = _max_side(cur, i, nx, ny, ang, min(1.0, s + 0.2))
        if ns > s:
            cur[i] = [nx, ny, ang, ns]
        new_sum = sum(q[3] for q in cur)
        if new_sum >= cur_sum - 1e-12:
            cur_sum = new_sum
    return cur


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(20240607 + n)
    best = None
    best_sum = -1.0

    seeds = []
    g = _construct_grid(n)
    if g is not None:
        seeds.append(g)
    for _ in range(2):
        seeds.append(_construct_rand(n, rng))

    for seed in seeds:
        res = _iterated_repack(n, seed, rng, rounds=(30 if n <= 40 else 16))
        s = sum(q[3] for q in res)
        if s > best_sum:
            best_sum = s
            best = res

    # final deterministic grow polish
    best = _fast_grow(best)
    return [(float(cx), float(cy), float(ang), float(s)) for cx, cy, ang, s in best]


def _construct_rand(n, rng):
    tasks = [(0.0, 0.0, 1.0, 1.0, n)]
    results = []
    while tasks:
        x, y, w, h, k = tasks.pop()
        if k <= 0:
            continue
        if k == 1:
            side = min(w, h)
            s = side * rng.uniform(0.97, 0.999)
            results.append([x + w * 0.5, y + h * 0.5, 0.0, s])
            continue
        if w >= h:
            r = rng.uniform(0.33, 0.67)
            k1 = max(1, min(k - 1, int(round(k * r))))
            k2 = k - k1
            w1 = w * (k1 / k)
            w2 = w - w1
            tasks.append((x, y, w1, h, k1))
            tasks.append((x + w1, y, w2, h, k2))
        else:
            r = rng.uniform(0.33, 0.67)
            k1 = max(1, min(k - 1, int(round(k * r))))
            k2 = k - k1
            h1 = h * (k1 / k)
            h2 = h - h1
            tasks.append((x, y, w, h1, k1))
            tasks.append((x, y + h1, w, h2, k2))
    return results
# EVOLVE-BLOCK-END
