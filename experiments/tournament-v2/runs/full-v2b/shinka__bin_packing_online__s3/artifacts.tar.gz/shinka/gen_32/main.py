# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item (int64, >= 0)

    # --- Dominant best-fit key: strictly prefer small residual ---
    BIG = 1000.0
    score = -residual.astype(np.float64) * BIG

    # --- Sub-unit structural tie-breakers (total magnitude strictly < 1.0) ---
    r = residual.astype(np.int64)

    # (1) Exact-fill bonus: closing a bin is very valuable.
    exact = (r == 0).astype(np.float64)

    # (2) Harmonic-style "fill-to-multiple": reward residuals that are exact
    # multiples of the current item size, so a chain of equal items can fill
    # the bin perfectly. Prefer smaller multiples (fewer items to close).
    is_multiple = (r % item == 0).astype(np.float64)
    k = np.where(is_multiple > 0, r // item, 0)
    mult_reward = is_multiple * (1.0 / (1.0 + k))

    # (3) Mild preference to reuse already-used bins so empty bins stay free
    # for large items.
    used = (bins < 100).astype(np.float64)
    small_pref = used * (1.0 / (1.0 + item)) * 0.25

    # (4) Single structural probe: prefer opening a fresh (empty) bin for
    # large items, as a sub-unit tie-breaker. Sweep beta to the low end
    # (0.1) per prior-generation evidence that this coefficient is a free
    # parameter; a smaller signal still preserves best-fit dominance while
    # leaving more magnitude headroom for other tie-breakers.
    beta = 0.1
    empty_large = (r == 100).astype(np.float64) * (item > 50)

    tiebreak = (0.5 * exact
                + 0.35 * mult_reward
                + small_pref
                + 0.5 * beta * empty_large)

    return score + tiebreak
# EVOLVE-BLOCK-END