# EVOLVE-BLOCK-START
"""Best-fit core with an orthogonal, sub-unit residual-composability tiebreaker.

Novel approach: keep strict best-fit ordering as the dominant key, and resolve
ties between equal residuals using an online distribution-aware measure of how
"composable" the leftover residual is (rather than a raw frequency match).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # --- Online statistics of item sizes ---
    if not hasattr(priority, "hist"):
        priority.hist = np.zeros(102, dtype=np.float64)   # counts for sizes 1..101
        priority.count = 0.0
        priority.sum = 0.0

    priority.count += 1.0
    priority.hist[item] += 1.0
    priority.sum += float(item)
    mean_size = priority.sum / priority.count

    residual = bins - item  # capacity left after placing item

    # --- Dominant key: strict best-fit ordering ---
    # Multiply by a large constant so that ANY difference in residual dominates
    # all tiebreak shaping (which stays strictly below this constant).
    BIG = 1000.0
    score = -residual.astype(np.float64) * BIG

    # --- Sub-unit tiebreakers (only matter when residuals are equal) ---
    r = residual.astype(np.float64)

    # (a) Exact fill: eliminating a bin entirely is very valuable.
    exact = (residual == 0).astype(np.float64)

    # (b) Composability of the leftover: reward residuals that are close to an
    # integer multiple of the running mean item size (i.e. likely to be filled
    # exactly by a small number of typical future items). This is a different
    # signal from "residual equals a common size" -- it is a *modular* match.
    # Differentially weighted: small items (item < 50) have more placement
    # flexibility, so reusable residuals matter more for them. The smooth
    # residual-size factor (1 - exp(-r/5)) emphasizes moderate residuals.
    m = max(mean_size, 1.0)
    k = np.maximum(np.round(r / m), 1.0)          # nearest number of items
    gap = np.abs(r - k * m) / m                    # normalized distance to a multiple
    composable = np.exp(-gap * gap)                # in (0, 1]
    size_factor = 1.0 - np.exp(-r / 5.0)           # in (0, 1]
    small_mult = 1.0 + 0.5 * (item < 50)           # 1.5 for small items, 1.0 else
    composable_weighted = 0.35 * size_factor * small_mult * composable

    # (c) Reuse of already-used bins for small items, so empty bins stay free
    # for big items. Sub-unit magnitude.
    used = (bins < 100).astype(np.float64)
    small_pref = used * (1.0 / (1.0 + max(item, 1))) * 0.25

    # Combine tiebreakers, total magnitude strictly < BIG so best-fit ordering
    # between distinct residuals is provably preserved.
    tiebreak = 0.40 * exact + composable_weighted + small_pref

    return score + tiebreak
# EVOLVE-BLOCK-END