# EVOLVE-BLOCK-START
"""Residual dual lookahead: best-fit primary with PMF-overlap tie-break.

Primary ordering is strict best-fit (smallest residual). Ties are broken
by an overlap score between the residual and an online empirical PMF of
item sizes, so that the residual most likely to be filled soon by a future
item wins. A small fresh-bin gate fires only for large items when the
best candidate residual is tiny, avoiding fragmentation of near-full bins.
"""
import numpy as np

# Online histogram of item sizes (1..100), updated each call.
_hist = np.zeros(101, dtype=np.float64)
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities for all fitting bins,
          including unused bins (capacity 100), in bin order.
    """
    global _count
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for all shown bins
    r = residual.astype(np.float64)

    # Dominant best-fit term.
    score = -r

    # ---- PMF-overlap secondary term (magnitude < 0.5) ----
    # Build a normalized histogram of past item sizes (excluding zeros).
    # This is a cheap proxy for the probability that a future item equals
    # the residual size. We use log1p to compress the dynamic range so the
    # term stays bounded and only perturbs near-ties.
    hist = _hist[1:101]
    total = hist.sum()
    if total > 0:
        pmf = hist / total
    else:
        pmf = np.zeros(100, dtype=np.float64)

    # For each residual r_i, look up pmf at index r_i (clipped to 1..100).
    # Residual 0 means bin becomes exactly full -> handled by exact bonus.
    idx = np.clip(residual.astype(np.int64), 1, 100) - 1
    overlap = pmf[idx]
    # Scale to sub-unit magnitude.
    score += 0.4 * overlap

    # ---- Exact-fit bonus (strong, but only as a tie-breaker) ----
    score[residual == 0] += 1e6

    # ---- Fresh-bin gate for large items with tiny residuals ----
    # When the item is large (>= 60) and the best residual among existing
    # bins is very small (<= 3), opening a fresh bin may avoid wasting a
    # nearly-full bin that a future exact match could close. Gated tightly
    # so it only affects the specific fragmentation regime.
    if item >= 60:
        # Check if any non-empty bin exists with very small residual.
        tight = (residual > 0) & (residual <= 3)
        if tight.any():
            # Nudge fresh bins (residual == 100 - item) upward slightly.
            score += 0.25 * (bins == 100).astype(np.float64)

    return score
# EVOLVE-BLOCK-END