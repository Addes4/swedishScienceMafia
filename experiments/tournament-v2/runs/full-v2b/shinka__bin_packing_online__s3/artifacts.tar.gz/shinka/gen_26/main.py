# EVOLVE-BLOCK-START
"""Best-fit with a tiny smooth residual-quality tie-breaker (beta = 0.1).

Primary term is best-fit: prefer the bin with the smallest residual
(remaining capacity minus item). This alone determines the ordering for
essentially all arrivals. A sub-unit smooth secondary term (magnitude < 0.5)
only affects exact ties, nudging toward residuals that are more likely to be
reusable by future items, without introducing piecewise thresholds that might
overfit to particular residual ranges.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown (they all fit the item)

    # Best-fit primary ordering (dominant term).
    score = -residual.astype(np.float64)

    # Smooth residual-quality tie-breaker with tiny magnitude (beta = 0.1).
    # Monotone increasing in residual, bounded in [0, 1): tiny residuals are
    # implicitly penalized, larger residuals rewarded. Magnitude < 0.5 so it
    # only breaks exact ties in the primary best-fit ordering.
    beta = 0.1
    r = residual.astype(np.float64)
    score += beta * (1.0 - np.exp(-r / 20.0))

    return score
# EVOLVE-BLOCK-END
