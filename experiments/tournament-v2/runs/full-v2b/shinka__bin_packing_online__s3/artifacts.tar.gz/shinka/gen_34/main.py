# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item (int64, >= 0)

    # --- Dominant best-fit key: strictly prefer small residual ---
    BIG = 1000.0
    score = -residual.astype(np.float64) * BIG

    # --- Sub-unit structural tie-breakers (total magnitude strictly < 1.0) ---
    r = residual.astype(np.int64)

    # (1) Exact-fill bonus: closing a bin is very valuable.
    exact = (r == 0).astype(np.float64)

    # (2) Harmonic-style "fill-to-multiple": reward residuals that are exact
    # multiples of the current item size, so a chain of equal items can fill
    # the bin perfectly. Prefer smaller multiples (fewer items to close).
    is_multiple = (r % item == 0).astype(np.float64)
    k = np.where(is_multiple > 0, r // item, 0)
    mult_reward = is_multiple * (1.0 / (1.0 + k))

    # (3) Mild preference to reuse already-used bins so empty bins stay free
    # for large items.
    used = (bins < 100).astype(np.float64)
    small_pref = used * (1.0 / (1.0 + item)) * 0.08

    # (4) Single structural probe: prefer opening a fresh (empty) bin for
    # large items, as a sub-unit tie-breaker.
    beta = 0.1
    empty_large = (r == 100).astype(np.float64) * (item > 50)

    # (5) Differential smooth residual-quality term: reward residuals that are
    # neither too tight (risky) nor too loose (wasteful), with a stronger
    # signal for small items since they have more placement flexibility and
    # medium residuals are more reusable for them. Bounded below 0.45 so the
    # best-fit key remains dominant.
    rf = r.astype(np.float64)
    smooth = 0.30 * (1.0 - np.exp(-rf / 20.0)) * (1.0 + 0.5 * (item < 50))

    tiebreak = (0.25 * exact
                + 0.15 * mult_reward
                + small_pref
                + 0.5 * beta * empty_large
                + smooth)

    return score + tiebreak
# EVOLVE-BLOCK-END