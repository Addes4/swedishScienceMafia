# EVOLVE-BLOCK-START
"""Hybrid best-fit: dominant tightness + sub-unit structural & histogram tie-breakers.

Combines:
  * Pure best-fit (prefer tightest residual) as the dominant key.
  * Exact-fill bonus (residual == 0).
  * Harmonic multiple reward: residual is an exact multiple of the current item,
    so a chain of equal items can perfectly close the bin.
  * Dead-residual penalty: residual in (0, min_seen) can never be filled again.
  * Reuse bonus: residual == item means a future identical item closes it exactly.
  * Histogram usefulness: residual matches the most frequent item size seen so far.
  * Mild preference to reuse already-used bins (keep empty bins free for large items).

All tie-breakers are strictly sub-unit, so best-fit ordering is preserved.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    # --- State: running histogram of item sizes + smallest item seen ---
    if not hasattr(priority, "hist"):
        priority.hist = np.zeros(101, dtype=np.float64)
        priority.count = 0
        priority.min_seen = 101

    priority.count += 1
    priority.hist[item] += 1.0
    if item < priority.min_seen:
        priority.min_seen = item

    residual = bins - item           # int64, >= 0
    r = residual.astype(np.int64)

    # --- Dominant best-fit key (scaled so sub-unit terms only break ties) ---
    BIG = 1000.0
    score = -residual.astype(np.float64) * BIG

    # --- Sub-unit structural tie-breakers ---
    # (1) Exact fill.
    exact = (r == 0).astype(np.float64)

    # (2) Harmonic multiple reward (residual divisible by item; prefer fewer chunks).
    is_mult = (r % item == 0).astype(np.float64)
    k = np.where(is_mult > 0, r // item, 0)
    mult_reward = is_mult * (1.0 / (1.0 + k))

    # (3) Dead residual penalty: nonzero but < smallest item ever seen.
    dead = (r > 0) & (r < priority.min_seen)
    dead_penalty = -0.3 * dead.astype(np.float64)

    # (4) Reuse bonus: residual == item (a future identical item closes it).
    reuse_bonus = 0.25 * (r == item).astype(np.float64)

    # (5) Histogram usefulness: reward residuals matching the most frequent
    # item size seen so far (online distribution awareness).
    h = priority.hist[1:101]                       # sizes 1..100
    cdfmax = np.maximum.accumulate(h)              # max freq among sizes 1..s
    r_clip = np.clip(r, 0, 100).astype(np.int64)
    useful = np.where(r_clip > 0, cdfmax[np.maximum(r_clip - 1, 0)], 0.0)
    useful = useful / max(priority.count, 1.0)

    # (6) Mild preference to reuse already-used bins (keep empty bins free).
    used = (bins < 100).astype(np.float64)
    small_pref = used * (1.0 / (1.0 + item)) * 0.08

    tiebreak = (0.25 * exact
                + 0.15 * mult_reward
                + dead_penalty
                + reuse_bonus
                + 50.0 * useful
                + small_pref)

    return score + tiebreak
# EVOLVE-BLOCK-END