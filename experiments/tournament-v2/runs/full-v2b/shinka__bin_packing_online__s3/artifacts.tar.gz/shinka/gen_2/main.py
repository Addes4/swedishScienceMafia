# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Bonus for placing small items into already-used bins, keeping empty bins
    # available for larger items. For items >= 30 the bonus is zero (pure best fit).
    small_bonus = np.maximum(0, 30 - item)
    used_mask = (bins < 100).astype(np.int64)
    return -(residual) + 20 * small_bonus * used_mask
# EVOLVE-BLOCK-END