# EVOLVE-BLOCK-START
"""Tiered best-fit with a single bounded composability tiebreaker.

Architecture:
  1. `_update_stats`   -- online item-size statistics (state on the function).
  2. `_composability`  -- one scalar in [0,1] measuring how likely the leftover
                          residual is to be closed by future typical items.
  3. `priority`        -- dominant strict best-fit key + sub-unit tiebreaker
                          built solely from the composability scalar, so the
                          total secondary magnitude stays strictly below 1.0
                          and best-fit ordering between distinct residuals is
                          preserved exactly.

The tiebreaker is a single bounded term instead of several overlapping masks,
which avoids cross-term interference and keeps the rule easy to reason about.
Small-item residual quality is encoded as a multiplicative weight inside the
composability scalar (per the recommendation), not as an additional additive
term, so the total secondary magnitude remains < 1.0.
"""
import numpy as np


def _update_stats(item):
    """Maintain running item-size statistics on the function object."""
    if not hasattr(_update_stats, "hist"):
        _update_stats.hist = np.zeros(102, dtype=np.float64)
        _update_stats.count = 0.0
        _update_stats.total = 0.0
    _update_stats.count += 1.0
    _update_stats.hist[item] += 1.0
    _update_stats.total += float(item)
    return _update_stats.total / _update_stats.count


def _composability(item, residual, mean_size):
    """Single scalar in [0,1]: how composable the leftover residual is.

    Combines three bounded factors multiplicatively so the result is a single
    sub-unit magnitude:
      * residual-size factor: emphasize moderate residuals, flatten at 0 and
        at very large residuals (1 - exp(-r/20)).
      * modular closeness to a multiple of the running mean item size.
      * small-item conditioning: small items have more placement flexibility,
        so reusable residuals matter more (1 + 0.5 * (item < 50)).
    """
    r = residual.astype(np.float64)
    m = max(mean_size, 1.0)

    # Modular closeness to a multiple of the running mean.
    k = np.maximum(np.round(r / m), 1.0)
    gap = np.abs(r - k * m) / m
    modular = np.exp(-gap * gap)

    # Residual-size factor: 0 at r=0, saturating near 1 for r >> 20.
    size_factor = 1.0 - np.exp(-r / 20.0)

    # Small-item conditioning (multiplicative, bounded).
    small_mult = 1.0 + 0.5 * (item < 50)

    # Combine and bound strictly below 1.0.
    raw = size_factor * modular * small_mult
    return raw / (1.0 + raw)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest
    (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    mean_size = _update_stats(item)

    residual = bins - item  # >= 0 for shown bins

    # --- Dominant key: strict best-fit ordering ---
    BIG = 1000.0
    score = -residual.astype(np.float64) * BIG

    # --- Single bounded sub-unit tiebreaker ---
    comp = _composability(item, residual, mean_size)          # in [0,1)

    # Exact fill: eliminating a bin is very valuable; keep it small and
    # strictly sub-unit so it never competes with the dominant key.
    exact = (residual == 0).astype(np.float64)

    # Reuse already-used bins slightly, so empty bins stay free for large items.
    used = (bins < 100).astype(np.float64)

    # Fresh-bin term conditioned on BOTH empty-bin status and per-bin residual
    # tightness: if the item would otherwise land in a bin it nearly fills
    # (residual <= 5), prefer opening a fresh bin instead, so the near-perfect
    # placement is reserved for a future exactly-sized item. Sub-unit.
    fresh_pref = 0.25 * (bins == 100).astype(np.float64) * (residual <= 5).astype(np.float64)

    tiebreak = 0.35 * exact + 0.35 * comp + 0.01 * used + fresh_pref  # < 1.0 total

    return score + tiebreak
# EVOLVE-BLOCK-END