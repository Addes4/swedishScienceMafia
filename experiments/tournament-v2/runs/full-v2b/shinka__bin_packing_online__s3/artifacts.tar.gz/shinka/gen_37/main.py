# EVOLVE-BLOCK-START
"""Best fit blended with a future-fit reuse estimate.

Primary ordering is best-fit (smallest residual). A bounded secondary term
estimates how reusable the resulting residual is by future items, using a
running empirical PMF of past item sizes (for exact fits) plus a Gaussian
tail (for near-size fits). This is scaled so it only perturbs near-ties.
"""
import numpy as np

# Running statistics over past items (module-level state across calls).
_hist = np.zeros(101, dtype=np.float64)   # histogram of item sizes 1..100
_count = 0
_sum = 0.0
_sumsq = 0.0

_BETA = 0.2  # scale of the reuse term (kept < 1 so best-fit dominates)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _sum, _sumsq

    # Update running statistics with the current item.
    _count += 1
    _sum += item
    _sumsq += item * item
    _hist[item] += 1.0

    mean = _sum / _count
    var = max(_sumsq / _count - mean * mean, 0.0)
    std = var ** 0.5
    sigma = max(std, 5.0)

    residual = bins - item  # >= 0 for all bins shown

    # Primary: best-fit.
    score = -residual.astype(np.float64)

    # Reuse estimate: probability a future item exactly matches the residual
    # (empirical PMF) plus a Gaussian tail for near-size future items.
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    pmf = _hist[r_clip] / _count
    gauss = np.exp(-((residual - mean) ** 2) / (2.0 * sigma * sigma))
    reuse = pmf + 0.25 * gauss
    reuse = np.minimum(reuse, 1.0)

    score += _BETA * reuse

    # Structural tie-breaker: for large items, prefer opening an empty bin
    # rather than consuming a partially-filled bin's residual (which would
    # leave a small, less-reusable residual behind). Bounded well below 1 so
    # it only affects exact best-fit ties.
    score += 0.3 * ((residual == 100) & (item > 50))

    # Strongly prefer bins that become exactly full (genuinely good).
    score[residual == 0] += 1e6

    return score
# EVOLVE-BLOCK-END