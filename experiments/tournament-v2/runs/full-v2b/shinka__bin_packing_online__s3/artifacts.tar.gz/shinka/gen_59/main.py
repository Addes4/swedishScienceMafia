# EVOLVE-BLOCK-START
"""Best-fit with strong exact-fit preference, smooth residual-quality
tie-breaker, and self-consistent fill bonus.

Primary term is best-fit: prefer the bin with the smallest residual
(remaining capacity minus item). Exact fits are strongly rewarded via a
large additive constant, so they always win regardless of tie-breakers.
A tiny secondary term (magnitude < 0.5) only affects exact ties, nudging
toward residuals more likely to be reused and away from wasted slivers.
A bounded self-consistent fill bonus rewards residual == item.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown (they all fit the item)

    # Best-fit primary ordering (negative residual -> smaller residual ranks higher).
    score = -residual.astype(np.float64)

    # Smooth residual-quality tie-breaker (magnitude < 0.5 -> ties only).
    # Monotone increasing in residual, bounded in [0, 0.5): tiny slivers are
    # implicitly penalized, larger reusable leftovers rewarded, without the
    # artificial cutoffs of piecewise masks.
    r = residual.astype(np.float64)
    score += 0.45 * (1.0 - np.exp(-r / 20.0))

    # Self-consistent fill bonus: arriving item exactly matches the leftover.
    # Bounded < 1 so it cannot override a strict best-fit residual difference.
    score += np.where(residual == item, 0.4, 0.0)

    # Strongly prefer bins that become exactly full (dominant signal).
    score[residual == 0] += 1e6

    return score
# EVOLVE-BLOCK-END