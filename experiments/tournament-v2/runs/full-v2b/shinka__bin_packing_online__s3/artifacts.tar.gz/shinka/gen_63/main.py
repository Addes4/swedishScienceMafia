# EVOLVE-BLOCK-START
"""Hybrid harmonic best-fit: strict best-fit dominance plus a smooth exponential
tie-breaker on small residuals and a harmonic 'fill-to-multiple' structural reward.
Combines the sharpest discriminators from prior implementations while keeping the
total tie-breaker magnitude sub-unit so best-fit ordering is never overridden.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # int64, >= 0 for shown bins
    r = residual.astype(np.float64)

    # --- Dominant best-fit ordering (strict) ---
    BIG = 1000.0
    score = -r * BIG

    # --- Narrow-range smooth tie-breaker ---
    # Discriminates sharply only among small residuals (0..~10) and flattens
    # beyond that, targeting genuine near-ties in residual.
    smooth = 0.45 * (1.0 - np.exp(-r / 5.0))

    # --- Harmonic 'fill-to-multiple' structural reward ---
    # Reward residuals that can be closed by a chain of equal items. Gated by
    # residual > 0 (exact fills are already captured by `smooth`) and by the
    # modulo condition. Smooth exponential shape keeps the reward bounded and
    # monotone in residual.
    r_int = residual.astype(np.int64)
    mult_mask = (r_int > 0) & (r_int % item == 0)
    mult_reward = mult_mask.astype(np.float64) * (0.5 * (1.0 - np.exp(-r / 5.0)))

    # --- Mild preference to reuse already-used bins so empty bins stay free
    # for large items. Bounded and small, purely a tie-breaker. ---
    used = (bins < 100).astype(np.float64)
    small_pref = used * (1.0 / (1.0 + item)) * 0.25

    return score + smooth + mult_reward + small_pref
# EVOLVE-BLOCK-END