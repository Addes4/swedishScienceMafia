# EVOLVE-BLOCK-START
"""Residual-spectrum dual bin-packing rule.

Fundamentally different from prior greedy-with-tiebreakers approaches:
this rule uses a *population-level* residual histogram to bias tie-breaking
away from consuming rare residual values (which fragment the bin population)
and toward residuals that are abundant (easy to re-create later).

Architecture:
  1. Online item-size stats (mean) for a composability prior.
  2. Online residual histogram H[r] over the bin population, maintained by
     predicting our own choice each call (we compute the score, know which
     bin wins, and update H accordingly).
  3. priority() returns a score = dominant best-fit key + bounded tiebreak,
     where the tiebreak includes:
        - exact-fill bonus (closing a bin),
        - scarcity penalty: penalize residuals whose count in H is low,
        - composability bonus: residual near a multiple of running mean,
        - reuse bonus: slight preference for already-used bins.

The dominant key uses BIG=1e6 and the tiebreak is strictly bounded in [0,1),
so best-fit ordering across distinct residuals is provably preserved.
"""
import numpy as np


# ---------- module-level state (persists across calls) ----------
_state = {
    "res_hist": None,    # float64 array size 102: count of bins with residual r
    "item_count": 0.0,
    "item_sum": 0.0,
    "initialized": False,
}


def _ensure_init():
    if not _state["initialized"]:
        _state["res_hist"] = np.zeros(102, dtype=np.float64)
        _state["item_count"] = 0.0
        _state["item_sum"] = 0.0
        _state["initialized"] = True


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    _ensure_init()

    # ---- online item statistics ----
    _state["item_count"] += 1.0
    _state["item_sum"] += float(item)
    mean_size = _state["item_sum"] / _state["item_count"]

    residual = bins - item  # residual after placing item; >= 0 for shown bins
    r = residual.astype(np.float64)
    r_int = residual.astype(np.int64)

    # ---- dominant best-fit key ----
    BIG = 1.0e6
    score = -r * BIG

    # ---- tiebreakers, all bounded so their sum is strictly < 1.0 ----
    H = _state["res_hist"]

    # (a) exact-fill bonus: closing a bin is very valuable
    exact = (r_int == 0).astype(np.float64)

    # (b) scarcity penalty: consuming a rare residual removes a rare building
    # block. We penalize bins whose residual count in H is low.
    # Normalize H so the term is sub-unit.
    total_bins = max(H.sum(), 1.0)
    h_r = H[np.clip(r_int, 0, 101)]
    scarcity = 1.0 / (1.0 + h_r)          # in (0, 1]; high when rare
    # We *subtract* scarcity (penalize rare residuals) — but only mildly.
    # Use a small scale so it stays sub-unit.
    scarcity_scale = 0.15

    # (c) composability: residual near a multiple of running mean item size
    m = max(mean_size, 1.0)
    k = np.maximum(np.round(r / m), 1.0)
    gap = np.abs(r - k * m) / m
    composable = np.exp(-gap * gap)                    # (0, 1]
    size_factor = 1.0 - np.exp(-r / 8.0)               # (0, 1]
    composable_w = 0.25 * size_factor * composable

    # (d) reuse: slight preference for already-used bins (keep empty bins free)
    used = (bins < 100).astype(np.float64)
    reuse = 0.02 * used

    # Combine tiebreakers. Max possible sum:
    #   0.5*exact + 0.15*scarcity + 0.25*composable_w + 0.02*reuse
    #   <= 0.5 + 0.15 + 0.25 + 0.02 = 0.92 < 1.0
    tiebreak = (0.5 * exact
                - scarcity_scale * scarcity
                + composable_w
                + reuse)

    # ---- update residual histogram by predicting our own choice ----
    # We predict the harness picks the bin with the highest score (first on ties).
    combined = score + tiebreak
    chosen_idx = int(np.argmax(combined))
    old_res = int(bins[chosen_idx])          # remaining capacity before placing
    new_res = old_res - int(item)            # remaining capacity after placing
    if 0 <= old_res <= 101:
        H[old_res] = max(H[old_res] - 1.0, 0.0)
    if 0 <= new_res <= 101:
        H[new_res] += 1.0

    return combined
# EVOLVE-BLOCK-END