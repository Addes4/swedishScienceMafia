# EVOLVE-BLOCK-START
"""Online best-fit bin packing with a data-driven reuse score.

Architecture (pipeline of small scoring stages, each bounded and disjoint):

    score = bestfit(residual)
          + reuse_potential(residual; online PMF)
          + self_consistent_bonus(residual, item)
          + exact_fill_bonus(residual)

Primary ordering is best-fit (smallest residual). The secondary terms are all
strictly smaller than 1 in total, so they only break exact ties in the
best-fit ordering. The reuse potential combines:
  * a harmonic "reuse potential" curve h(r) = r/(r+5), which is monotone
    increasing and bounded in [0, 0.5); and
  * an online empirical PMF of past item sizes, smoothed over a 1-wide
    neighborhood so residuals close to any observed size get credit.

Module-level state accumulates the empirical item-size histogram across calls;
nothing about future items is used.
"""
import numpy as np

# ---- online state -----------------------------------------------------------
_STATE = {
    "hist": np.zeros(101, dtype=np.float64),  # counts of sizes 1..100
    "count": 0.0,
}


def _update_stats(item):
    """Update the running empirical PMF with the arriving item."""
    _STATE["count"] += 1.0
    _STATE["hist"][item] += 1.0


def _bestfit_term(residual):
    """Primary best-fit ordering: smaller residual -> higher score."""
    return -residual.astype(np.float64)


def _reuse_term(residual, item):
    """Bounded, monotone reuse potential of the resulting residual.

    Combines a harmonic curve h(r) = 0.5 * r/(r+5) (gate r > 0) with a
    neighborhood-smoothed empirical PMF, so residuals near any observed item
    size are rewarded. Total magnitude stays below 0.5.
    """
    r = residual.astype(np.float64)

    # Harmonic reuse curve, gated so residual == 0 is handled by its own bonus.
    harmonic = 0.5 * (r / (r + 5.0))
    harmonic = np.where(residual > 0, harmonic, 0.0)

    # Neighborhood-smoothed empirical PMF: credit residuals close to any
    # observed item size (r-1, r, r+1).
    hist = _STATE["hist"]
    inv = 1.0 / _STATE["count"]
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    lo = np.clip(r_clip - 1, 0, 100)
    hi = np.clip(r_clip + 1, 0, 100)
    pmf = (hist[r_clip] + 0.5 * hist[lo] + 0.5 * hist[hi]) * inv
    pmf = np.clip(pmf, 0.0, 1.0)

    return 0.45 * harmonic + 0.25 * pmf


def _self_consistent_bonus(residual, item):
    """Reward bins whose leftover exactly matches the arriving item."""
    return np.where(residual == item, 0.30, 0.0)


def _exact_fill_bonus(residual):
    """Reward bins that become exactly full."""
    return np.where(residual == 0, 0.25, 0.0)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    _update_stats(item)

    residual = bins - item  # >= 0 for every bin shown

    score = _bestfit_term(residual)
    score = score + _reuse_term(residual, item)
    score = score + _self_consistent_bonus(residual, item)
    score = score + _exact_fill_bonus(residual)

    return score
# EVOLVE-BLOCK-END