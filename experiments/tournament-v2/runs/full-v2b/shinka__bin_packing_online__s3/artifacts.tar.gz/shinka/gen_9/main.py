# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Maintain a running histogram of item sizes (1..100) for online
    # distribution estimation. Initialized lazily on first call.
    if not hasattr(priority, "hist"):
        priority.hist = np.zeros(101, dtype=np.float64)
        priority.count = 0

    priority.count += 1
    priority.hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing item

    # Best-fit base term: prefer small residual.
    score = -residual.astype(np.float64)

    # Usefulness shaping: for each residual r, find the most frequent item size
    # s in [1, r] that could fill that residual. Residuals that match a common
    # item size are more likely to be exactly reusable, so boost them.
    h = priority.hist[1:101]  # frequencies for sizes 1..100
    # cdfmax[s] = max frequency among sizes 1..s
    cdfmax = np.maximum.accumulate(h)
    # For residual r (0..100), useful mass = cdfmax[min(r,100)] (0 if r<=0).
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    useful = np.where(
        r_clip > 0, cdfmax[np.maximum(r_clip - 1, 0)], 0.0
    )

    # Normalize by total count so the bonus is a probability-like quantity.
    useful = useful / max(priority.count, 1.0)

    # Penalize tiny residuals (1-3) that are hard to fill and represent waste.
    tiny_penalty = np.where((r_clip >= 1) & (r_clip <= 3), 1.0, 0.0) * 30.0

    # Bonus for placing small items into already-used bins, keeping empty bins
    # available for larger items.
    small_bonus = np.maximum(0, 30 - item)
    used_mask = (bins < 100).astype(np.float64)

    # Blend: best-fit dominates, usefulness breaks near-ties toward reusable
    # residuals, tiny residuals are discouraged, and small items prefer used bins.
    return score + 50.0 * useful - tiny_penalty + 20.0 * small_bonus * used_mask
# EVOLVE-BLOCK-END