# EVOLVE-BLOCK-START
"""Best-fit with residual-usefulness shaping driven by online item statistics."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Maintain running statistics of item sizes to estimate the distribution online.
    if not hasattr(priority, "count"):
        priority.count = 0
        priority.total = 0.0

    # Update statistics with the current item (we only know the past, but including
    # the current item is a valid online estimate for shaping future placements).
    priority.count += 1
    priority.total += item
    mean_item = priority.total / priority.count

    # Residual capacity after placing the item in each candidate bin.
    residual = bins - item  # int64 array, >= 0 for bins shown

    # Best-fit term: prefer small residual (tight fit).
    tightness = -residual.astype(np.float64)

    # Usefulness term: Gaussian bump centered at the typical item size.
    # Residuals near mean_item are most likely to be reusable.
    sigma = max(mean_item * 0.5, 5.0)
    diff = residual.astype(np.float64) - mean_item
    usefulness = np.exp(-(diff * diff) / (2.0 * sigma * sigma))

    # Blend: best-fit dominates, usefulness shapes the residual.
    alpha = 0.3
    return tightness + alpha * usefulness
# EVOLVE-BLOCK-END