# EVOLVE-BLOCK-START
"""Best-fit with strong exact-fit preference and residual-quality tie-breaker.

Primary term is best-fit: prefer the bin with the smallest residual
(remaining capacity minus item). Exact fits are strongly rewarded.
A tiny secondary term (magnitude < 0.5) only affects exact ties, nudging
toward residuals more likely to be reused and away from wasted slivers.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown (they all fit the item)

    # Best-fit primary ordering.
    score = -residual.astype(np.float64)

    # Strongly prefer bins that become exactly full.
    score[residual == 0] += 1e6

    # Tiny residual-quality tie-breaker (magnitudes < 0.5 -> ties only).
    # Very small leftover (likely wasted): penalize slightly.
    score -= np.where((residual >= 1) & (residual <= 4), 0.45, 0.0)
    # Useful leftovers: reward residuals large enough to fit future items.
    score += np.where((residual >= 15) & (residual <= 85), 0.3, 0.0)
    score += np.where((residual >= 5) & (residual <= 14), 0.1, 0.0)

    return score
# EVOLVE-BLOCK-END