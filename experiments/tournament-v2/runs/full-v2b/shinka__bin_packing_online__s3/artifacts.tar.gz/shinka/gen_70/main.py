# EVOLVE-BLOCK-START
"""Best fit with a small-item-conditioned smooth tie-breaker.

Primary ordering is best-fit (smallest residual). Exact fits receive a large
bonus. A bounded smooth secondary term prefers larger (more reusable)
residuals, and is conditioned on item size so that small items get a slightly
stronger preference for reusable leftovers -- this differentially improves
residual quality for small items without breaking strict best-fit ordering.
A structural term still prefers opening empty bins for large items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown (they all fit the item)
    r = residual.astype(np.float64)

    # Primary: best-fit (smallest residual first).
    score = -r

    # Smooth residual-quality tie-breaker, conditioned on item size.
    # Magnitude bounded at 0.45 * 1.5 = 0.675 < 1.0 so it only perturbs ties.
    small = 1.0 if item < 50 else 0.0
    score += 0.45 * (1.0 - np.exp(-r / 20.0)) * (1.0 + 0.5 * small)

    # Structural tie-breaker: for large items, prefer opening an empty bin
    # rather than consuming a partially-filled bin's residual. Bounded below 1.
    score += 0.3 * ((residual == 100) & (item > 50))

    # Strongly prefer bins that become exactly full.
    score[residual == 0] += 1e6

    return score
# EVOLVE-BLOCK-END