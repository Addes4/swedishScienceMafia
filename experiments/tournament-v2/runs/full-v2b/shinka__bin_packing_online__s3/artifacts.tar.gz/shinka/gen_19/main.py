# EVOLVE-BLOCK-START
"""Best fit with a small residual-quality tie-breaker.

Primary term is best-fit: prefer the bin with the smallest residual
(remaining capacity minus item). A tiny secondary term (magnitude < 0.5,
so it only affects exact ties) nudges the choice toward residuals that are
more likely to be reusable by future items and away from residuals that are
likely to be wasted.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown (they all fit the item)

    # Best-fit primary ordering.
    score = -residual.astype(np.float64)

    # Sub-unit tie-breaker magnitude. Any beta < 1 keeps the primary best-fit
    # ordering strict (a residual difference of 1 still dominates), so this
    # only affects exact ties. Sweeping beta tests whether the tie-breaker
    # magnitude matters at all on this distribution.
    beta = 0.25

    # Perfect fit: reward (largest magnitude, still < 1 so primary dominates).
    score += np.where(residual == 0, beta, 0.0)
    # Very small leftover (likely wasted): penalize.
    score -= np.where((residual >= 1) & (residual <= 4), beta, 0.0)
    # Useful leftovers: reward residuals large enough to fit many future items.
    score += np.where((residual >= 15) & (residual <= 85), 0.6 * beta, 0.0)
    score += np.where((residual >= 5) & (residual <= 14), 0.2 * beta, 0.0)

    return score
# EVOLVE-BLOCK-END