# EVOLVE-BLOCK-START
"""Harmonic-style best-fit: reward residuals that are exact multiples of the
current item size, and strongly reward exact fills. This is a structural rule
(not a statistical estimator), targeting the plateau identified as likely
heuristic-bound. Uses only integer modular arithmetic plus a small reuse term.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # int64, >= 0 for shown bins

    # --- Dominant structural key: harmonic "fill to multiple" ---
    # Reward residuals that are exact multiples of the current item size, so a
    # chain of equal items can fill the bin perfectly. This mirrors harmonic
    # bin packing's class-based packing but applied per decision.
    # Use integer modulo to detect exact multiples.
    r = residual.astype(np.int64)
    is_multiple = (r % item == 0).astype(np.float64)

    # Strength of the multiple: prefer residual == 0 (exact fill) most, then
    # larger multiples that still let equal items fill the bin. We encode this
    # as a decreasing function of the number of equal items needed.
    # k = number of equal items that would exactly fill the residual.
    k = np.where(is_multiple > 0, r // item, 0)
    # Prefer smaller k (fewer items to close the bin), but exact fill (k==0) is best.
    # Use a bounded reward so it stays below the best-fit dominant term.
    mult_reward = is_multiple * (1.0 / (1.0 + k))

    # --- Exact fill is very valuable ---
    exact = (r == 0).astype(np.float64)

    # --- Dominant best-fit ordering (strict) ---
    BIG = 1000.0
    score = -residual.astype(np.float64) * BIG

    # --- Sub-unit tie-breakers (magnitude strictly < 1.0) ---
    # Exact fill bonus, harmonic multiple reward, and a mild preference to
    # reuse already-used bins so empty bins stay free for large items.
    used = (bins < 100).astype(np.float64)
    small_pref = used * (1.0 / (1.0 + item)) * 0.25

    tiebreak = 0.5 * exact + 0.35 * mult_reward + small_pref

    return score + tiebreak
# EVOLVE-BLOCK-END