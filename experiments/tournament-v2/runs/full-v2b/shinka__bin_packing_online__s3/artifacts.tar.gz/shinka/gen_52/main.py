# EVOLVE-BLOCK-START
"""Data-driven best-fit: use an online empirical item-size histogram to score
each candidate bin by how reusable its resulting residual is.

Primary ordering is best-fit (smallest residual). A bounded secondary term
estimates the probability that a future item will exactly fill the residual,
using a running empirical PMF of past item sizes. Two sharp disjoint bonuses
reward self-consistent fills (residual == item) and exact fills (residual == 0).
All secondary magnitudes sum to < 1.0 so best-fit dominance is preserved.
"""
import numpy as np

# Module-level online state across calls.
_hist = np.zeros(101, dtype=np.float64)  # counts of item sizes 1..100
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count

    # Update the empirical PMF with the arriving item BEFORE scoring.
    _count += 1
    _hist[item] += 1.0
    inv = 1.0 / _count

    residual = bins - item  # >= 0 for all shown bins

    # Primary: best-fit ordering.
    score = -residual.astype(np.float64)

    # Secondary: probability that the resulting residual is exactly reusable
    # by a future item, from the online empirical PMF. Bounded in [0,1].
    r_clip = np.clip(residual, 0, 100)
    pmf = _hist[r_clip] * inv
    score += 0.45 * pmf

    # Sharp, disjoint structural bonuses (kept small so they only break ties).
    # Self-consistent fill: residual equals the arriving item size.
    score += np.where(residual == item, 0.30, 0.0)
    # Perfect fill: bin becomes exactly full.
    score += np.where(residual == 0, 0.25, 0.0)

    return score
# EVOLVE-BLOCK-END