# EVOLVE-BLOCK-START
"""Distribution-aware best-fit via online residual closeability estimate.

Different paradigm from prior hand-tuned rules: we estimate, from the running
empirical item-size histogram, the expected cost (number of future items, capped)
to exactly close each residual. This residual-value is blended with the best-fit
backbone so that among near-equal residuals the one that is easiest to close with
typical future items wins. Structural tie-breakers (exact fill, reuse, fresh-bin
conditioning) remain strictly sub-unit.
"""
import numpy as np


def _build_close_table(hist, count, cap=3):
    """close_val[r] in [0,1]: higher = residual r easier to close with <=cap items.

    We compute, for each residual r (0..100), the minimum number of items (<=cap)
    drawn from the empirical distribution that can sum to exactly r, then map to
    a value 1/(1+min_items). Exact (min_items==0) yields 1.0.
    Approximated via convolution of the empirical pmf up to `cap` levels.
    """
    p = hist[1:101].astype(np.float64)
    s = p.sum()
    if s <= 0:
        p = np.ones(100, dtype=np.float64)
        s = 100.0
    p = p / s

    # reach[m] = probability that a sum of exactly m items equals each residual.
    # We only need existence-weighted reachability; approximate with convolutions.
    best = np.full(101, np.inf, dtype=np.float64)
    best[0] = 0.0  # zero items needed for residual 0

    # level 1
    for sz in range(1, 101):
        if p[sz - 1] > 0:
            if best[sz] > 1.0:
                best[sz] = 1.0

    # levels 2..cap via convolution (vectorized per level)
    reach = p.copy()  # reach[m] for sums of 1 item, indexed 1..100
    sums = np.zeros(101, dtype=np.float64)
    sums[1:101] = reach
    for level in range(2, cap + 1):
        # convolve sums with p
        conv = np.convolve(sums, p)  # length up to 200
        new_sums = np.zeros(101, dtype=np.float64)
        L = min(101, conv.shape[0])
        new_sums[:L] = conv[:L]
        # any residual with positive reach at this level gets cost = level (if better)
        mask = (new_sums > 1e-12) & (best > level)
        best[mask] = level
        sums = new_sums

    # convert to value: 1/(1+cost); unreachable (inf) -> small value
    val = np.where(np.isfinite(best), 1.0 / (1.0 + best), 0.0)
    return val


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    # --- online state ---
    if not hasattr(priority, "hist"):
        priority.hist = np.zeros(101, dtype=np.float64)
        priority.count = 0
        priority.close_val = None
        priority.next_rebuild = 0
        priority.min_seen = 101

    priority.count += 1
    priority.hist[item] += 1.0
    if item < priority.min_seen:
        priority.min_seen = item

    # Rebuild closeability table lazily (every 64 items) for speed.
    if priority.close_val is None or priority.count >= priority.next_rebuild:
        priority.close_val = _build_close_table(priority.hist, priority.count, cap=3)
        priority.next_rebuild = priority.count + 64

    residual = bins - item
    r = residual.astype(np.int64)

    # --- Dominant backbone: best-fit (smallest residual preferred) ---
    # To let closeability matter among near-equal residuals, reduce the scale so
    # the structural term can flip decisions only when residuals are close.
    BIG = 100.0
    score = -residual.astype(np.float64) * BIG

    # --- Sub-unit blending: closeability of the resulting residual ---
    r_clip = np.clip(r, 0, 100).astype(np.int64)
    close = priority.close_val[r_clip]  # in [0,1]
    # Scale < 1 so it only breaks ties / near-ties within the BIG backbone.
    score += 0.9 * close

    # --- Structural tie-breakers (strictly sub-unit) ---
    exact = (r == 0).astype(np.float64)
    reuse = (r == item).astype(np.float64)

    # Dead residual: nonzero but smaller than any item ever seen -> unfillable.
    dead = ((r > 0) & (r < priority.min_seen)).astype(np.float64)

    # Fresh-bin conditioning: reward opening a fresh bin only when the item is
    # medium/large and residual elsewhere would be tight (near-perfect).
    fresh = (bins == 100).astype(np.float64)
    residual_tight = ((residual <= 5) & (residual >= 0) & (bins < 100)).astype(np.float64)

    tiebreak = (0.5 * exact
                + 0.3 * reuse
                - 0.4 * dead
                + 0.25 * fresh * (item > 50).astype(np.float64) * residual_tight.max()
                )

    return score + tiebreak
# EVOLVE-BLOCK-END