# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-quality tie-breaker.

Primary term is best-fit: prefer the bin with the smallest residual. A tiny
secondary term (magnitude < 0.5, so it only affects exact ties) nudges the
choice toward residuals that are more likely to be reusable by future items,
using a single smooth monotone function instead of piecewise masks.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown (they all fit the item)

    # Best-fit primary ordering.
    score = -residual.astype(np.float64)

    # Smooth residual-quality tie-breaker (magnitudes < 0.5 -> ties only).
    # Monotone increasing in residual, bounded in [0,1): tiny residuals are
    # implicitly penalized, larger residuals rewarded.
    r = residual.astype(np.float64)
    score += 0.45 * (1.0 - np.exp(-r / 20.0))

    # Strongly prefer bins that become exactly full (genuinely good).
    score += np.where(residual == 0, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END