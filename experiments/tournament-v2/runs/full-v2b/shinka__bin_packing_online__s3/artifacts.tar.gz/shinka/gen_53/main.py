# EVOLVE-BLOCK-START
"""Best fit blended with a future-fit reuse estimate.

Primary ordering is best-fit (smallest residual). A bounded secondary term
estimates how reusable the resulting residual is by future items, using a
running empirical PMF of past item sizes (for exact fits) plus a Gaussian
tail (for near-size fits). This is scaled so it only perturbs near-ties.
"""
import numpy as np

# Running statistics over past items (module-level state across calls).
_hist = np.zeros(101, dtype=np.float64)   # histogram of item sizes 1..100
_count = 0
_sum = 0.0
_sumsq = 0.0

_BETA = 0.5  # scale of the reuse term (kept < 1 so best-fit dominates)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _sum, _sumsq

    # Update running statistics with the current item.
    _count += 1
    _sum += item
    _sumsq += item * item
    _hist[item] += 1.0

    mean = _sum / _count
    var = max(_sumsq / _count - mean * mean, 0.0)
    std = var ** 0.5
    sigma = max(std, 5.0)

    residual = bins - item  # >= 0 for all bins shown

    # Primary: best-fit.
    score = -residual.astype(np.float64)

    r = residual.astype(np.float64)

    # Smooth tie-breaker on a narrow dynamic range: discriminates sharply
    # among small residuals (0..10) and flattens beyond. Trimmed to 0.35 so
    # that combined with the fresh-bin term below, total secondary magnitude
    # stays strictly below 1.0 and best-fit dominance is preserved.
    score += 0.35 * (1.0 - np.exp(-r / 5.0))

    # Fresh-bin term gated on BOTH empty-bin status and residual tightness:
    # when the item would otherwise land in a bin with residual <= 5 (a near
    # perfect fit that best-fit greedily grabs), prefer opening a fresh bin to
    # avoid fragmenting a nearly-full bin that a future exact match could close.
    # Gated by residual <= 5 so it never fires on bins with looser residuals.
    score += 0.25 * (bins == 100).astype(np.float64) * (r <= 5.0)

    # Strongly prefer bins that become exactly full (genuinely good).
    score[residual == 0] += 1e6

    return score
# EVOLVE-BLOCK-END