# EVOLVE-BLOCK-START
"""Crossover: tight best-fit core + cheap dead-residual penalty.

Combines the fast, robust baseline (unified exact-fit family, harmonic
multiple reward, reuse preference, empty-bin probe for large items) with
the current program's cheap online `min_seen` tracker and dead-residual
penalty. The histogram-usefulness term from the current program is dropped
because it added no measurable score but real per-call overhead.

All tie-breakers are strictly sub-unit so best-fit dominance is preserved.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    # --- Cheap online state: smallest item size seen so far ---
    if not hasattr(priority, "min_seen"):
        priority.min_seen = 101
    if item < priority.min_seen:
        priority.min_seen = item

    residual = bins - item           # int64, >= 0
    r = residual.astype(np.int64)

    # --- Dominant best-fit key (scaled so sub-unit terms only break ties) ---
    BIG = 1000.0
    score = -residual.astype(np.float64) * BIG

    # --- Sub-unit structural tie-breakers ---
    # (1) Unified exact-fit family: residual in {0, item}.
    exact_family = ((r == 0) | (r == item)).astype(np.float64)

    # (2) Harmonic multiple reward for k >= 2 (k == 1 covered above).
    is_multiple = (r % item == 0).astype(np.float64)
    is_higher = is_multiple * ((r != 0) & (r != item)).astype(np.float64)
    k = np.where(is_higher > 0, r // item, 0)
    mult_reward = is_higher * (1.0 / (1.0 + k))

    # (3) Dead-residual penalty: nonzero residual smaller than any item ever
    # seen can never be filled again -> avoid stranding it.
    dead = (r > 0) & (r < priority.min_seen)
    dead_penalty = -0.3 * dead.astype(np.float64)

    # (4) Mild preference to reuse already-used bins (keep empty bins free).
    used = (bins < 100).astype(np.float64)
    small_pref = used * (1.0 / (1.0 + item)) * 0.25

    # (5) Prefer opening a fresh (empty) bin for large items.
    beta = 0.25
    empty_large = (r == 100).astype(np.float64) * (item > 50)

    tiebreak = (0.4 * exact_family
                + 0.35 * mult_reward
                + dead_penalty
                + small_pref
                + 0.5 * beta * empty_large)

    return score + tiebreak
# EVOLVE-BLOCK-END