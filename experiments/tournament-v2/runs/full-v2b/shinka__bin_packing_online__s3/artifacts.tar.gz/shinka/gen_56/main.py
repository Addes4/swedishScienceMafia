# EVOLVE-BLOCK-START
"""Compact best-fit with a single bounded smooth multiple-residual signal.

Primary ordering is best-fit (smallest residual). A small secondary term
(magnitude < 0.5, so it only affects exact ties) rewards residuals that are
positive multiples of the current item size, with a smooth exponential decay
in the residual magnitude. This tests whether a canonical bounded-monotone
shape (exponential) inside the multiple-residual family can replace the
harmonic form while preserving the plateau.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown (they all fit the item)

    # Primary: best-fit ordering.
    score = -residual.astype(np.float64)

    # Exact fit: small bounded bonus.
    score += np.where(residual == 0, 0.45, 0.0)

    # Single bounded smooth multiple-residual signal.
    # Reward residuals that are positive multiples of item, decaying smoothly
    # with residual magnitude. Bounded in [0, 0.5) so it only breaks ties.
    mult_mask = (residual > 0) & (residual % item == 0)
    mult_reward = 0.5 * (1.0 - np.exp(-residual.astype(np.float64) / 5.0))
    score += np.where(mult_mask, mult_reward, 0.0)

    # Tiny penalty for very small non-reusable leftovers (1..4) that are not
    # multiples, to slightly discourage wasting capacity. Bounded and secondary.
    small_waste = (residual >= 1) & (residual <= 4) & (residual % item != 0)
    score -= np.where(small_waste, 0.1, 0.0)

    return score
# EVOLVE-BLOCK-END