# EVOLVE-BLOCK-START
"""Adaptive best-fit with a structural empty-bin / tight-residual gate.

Best-fit (smallest residual) is the dominant ordering. On top of it we add a
small set of bounded, smooth tie-breakers whose total magnitude stays strictly
below 1.0, so any residual difference of >= 1 still decides the placement.

The distinctive term here is a structural gate that rewards choosing a fresh
empty bin (residual == 100) only when the item would otherwise land in a bin
with a very tight residual (r <= 5). This probes whether greedy best-fit is
leaving large-item placements on the table.
"""
import numpy as np

# Scale for the empty-large preference (kept small).
_BETA = 0.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # --- Primary term: best-fit. Dominant by construction. ---
    score = -r

    # --- Smooth perfect-fit bump: strongly prefer becoming exactly full. ---
    perfect = np.exp(-0.5 * (r / 1.5) ** 2)
    score += 0.35 * perfect

    # --- Smooth self-consistent bump: residual matches the arriving item. ---
    consistent = np.exp(-0.5 * ((r - item) / 1.5) ** 2)
    score += 0.25 * consistent

    # --- Small preference for reusable mid residuals. ---
    # Residuals that look like plausible future items (broad, gentle).
    mu = 40.0
    sigma = 30.0
    small_pref = np.exp(-0.5 * ((r - mu) / sigma) ** 2)
    score += 0.40 * small_pref

    # --- Empty-large preference: mildly favour fresh bins for large items. ---
    empty_large = (r == 100.0) & (item > 50)
    score += 0.2 * _BETA * empty_large.astype(np.float64)

    # --- Differential large-item fresh-bin gate (disjoint mask). ---
    # Reward opening a fresh empty bin only when the arriving item is large
    # (item >= 60) AND some non-empty bin has a very tight residual (0 < r <= 3).
    # This targets the regime where greedy best-fit may sacrifice future
    # capacity by cramming a large item into a nearly-full bin.
    tight_exists_3 = np.any((r > 0.0) & (r <= 3.0))
    if tight_exists_3 and item >= 60:
        score += 0.30 * (r == 100.0).astype(np.float64)

    # --- Structural gate: fresh bin, but only when item would otherwise
    #     land with a near-perfect residual elsewhere (r <= 5). ---
    tight_exists = np.any((r > 0.0) & (r <= 5.0))
    if tight_exists:
        score += 0.25 * (r == 100.0).astype(np.float64)

    return score
# EVOLVE-BLOCK-END