# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-quality tie-breaker plus a self-consistent
fill bonus (residual == item).

Primary term is best-fit: prefer the bin with the smallest residual. A tiny
secondary term (magnitude < 0.5, so it only affects exact ties) nudges the
choice toward residuals that are more likely to be reusable by future items,
using a single smooth monotone function instead of piecewise masks.

Additionally, a bounded bonus rewards the case where the arriving item exactly
matches a bin's leftover (residual == item). This is a strong "meant for this
item" signal and is disjoint from the perfect-fit term (residual == 0), so the
two bonuses never stack.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown (they all fit the item)

    # Best-fit primary ordering.
    score = -residual.astype(np.float64)

    # Smooth residual-quality tie-breaker (magnitudes < 0.5 -> ties only).
    # Monotone increasing in residual, bounded in [0,1): tiny residuals are
    # implicitly penalized, larger residuals rewarded.
    r = residual.astype(np.float64)
    score += 0.2 * (1.0 - np.exp(-r / 20.0))

    # Prefer bins that become exactly full (genuinely good).
    # Sweep: lowered from 0.3 to 0.05 to test whether the magnitude is
    # load-bearing or a free presence signal.
    score += np.where(residual == 0, 0.05, 0.0)

    # Self-consistent fill bonus: arriving item exactly matches the leftover.
    # Disjoint from the perfect-fit term above, bounded so it cannot override
    # a strict best-fit residual difference of 1.
    score += np.where(residual == item, 0.2, 0.0)

    # Fresh-bin bonus for large items: opening a new bin for a large item
    # avoids fragmenting an almost-full bin that could absorb several small
    # items. Gated to item < 100 so it stays disjoint from the perfect-fit
    # term (residual == 0) and the self-consistent term (residual == item).
    score += np.where((bins == 100) & (item > 50) & (item < 100), 0.3, 0.0)

    return score
# EVOLVE-BLOCK-END