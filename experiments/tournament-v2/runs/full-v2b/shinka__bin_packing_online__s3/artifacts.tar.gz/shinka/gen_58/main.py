# EVOLVE-BLOCK-START
"""Harmonic-style best-fit: reward residuals that are exact multiples of the
current item size, and strongly reward exact fills. This is a structural rule
(not a statistical estimator), targeting the plateau identified as likely
heuristic-bound. Uses only integer modular arithmetic plus a small reuse term.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # int64, >= 0 for shown bins
    r = residual.astype(np.float64)

    # --- Dominant best-fit ordering (strict) ---
    BIG = 1000.0
    score = -r * BIG

    # --- Narrow-range smooth tie-breaker ---
    # Discriminates sharply only among small residuals (0..~10) and flattens
    # beyond that. Weight reduced to leave headroom for structural terms.
    smooth = 0.30 * (1.0 - np.exp(-r / 5.0))

    # --- Structural tie-breakers (total strictly < 1.0) ---
    ri = residual.astype(np.int64)

    # (a) Exact fill: closing a bin is very valuable.
    exact = (ri == 0).astype(np.float64)

    # (b) Harmonic "fill-to-multiple": reward residuals that are exact
    # multiples of the current item size, preferring smaller multiples.
    # Differentially boost for small items (more placement flexibility),
    # bounded so total contribution stays <= 0.35.
    is_multiple = (ri % item == 0).astype(np.float64)
    k = np.where(is_multiple > 0, ri // item, 0)
    base = is_multiple * (1.0 / (1.0 + k))
    boost = 1.0 + 0.5 * (item < 50)
    mult_reward = 0.2333 * base * boost  # max ~0.35

    tiebreak = 0.30 * exact + mult_reward

    return score + smooth + tiebreak
# EVOLVE-BLOCK-END