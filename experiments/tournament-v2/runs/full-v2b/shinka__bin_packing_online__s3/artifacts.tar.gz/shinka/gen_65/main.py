# EVOLVE-BLOCK-START
"""Adaptive best-fit with a structural empty-bin / tight-residual gate.

Best-fit (smallest residual) is the dominant ordering. On top of it we add a
small set of bounded, smooth tie-breakers whose total magnitude stays strictly
below 1.0, so any residual difference of >= 1 still decides the placement.

The distinctive term here is a structural gate that rewards choosing a fresh
empty bin (residual == 100) only when the item would otherwise land in a bin
with a very tight residual (r <= 5). This probes whether greedy best-fit is
leaving large-item placements on the table.
"""
import numpy as np

# Scale for the empty-large preference (kept small).
_BETA = 0.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # --- Primary term: best-fit. Dominant by construction. ---
    score = -r

    # --- Smooth harmonic tie-breaker, gated to residual > 0. ---
    # Bounded in [0, 0.5), monotone increasing in residual, magnitude < 1 so it
    # only affects exact ties in the best-fit ordering. Gated so that a bin
    # becoming exactly full is rewarded only by the exact-fit bonus below,
    # keeping the two terms cleanly separated.
    score += np.where(residual > 0, 0.5 * (r / (r + 5.0)), 0.0)

    # --- Exact-fit bonus: strongly prefer bins that become exactly full. ---
    score += np.where(residual == 0, 1e6, 0.0)

    # --- Self-consistent bonus: residual matches the arriving item, so the
    #     bin could be filled by a future identical item. Sub-unit magnitude
    #     so it only affects near-ties in the best-fit ordering. ---
    score += np.where(residual == item, 0.4, 0.0)

    return score
# EVOLVE-BLOCK-END