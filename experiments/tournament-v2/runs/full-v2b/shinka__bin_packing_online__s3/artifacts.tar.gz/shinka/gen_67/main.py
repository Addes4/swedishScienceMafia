# EVOLVE-BLOCK-START
"""Best-fit core with an orthogonal, sub-unit residual-composability tiebreaker.

Novel approach: keep strict best-fit ordering as the dominant key, and resolve
ties between equal residuals using an online distribution-aware measure of how
"composable" the leftover residual is (rather than a raw frequency match).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # capacity left after placing item

    # --- Dominant key: strict best-fit ordering ---
    # Multiply by a large constant so that ANY difference in residual dominates
    # all tiebreak shaping (which stays strictly below this constant).
    BIG = 1000.0
    score = -residual.astype(np.float64) * BIG

    # --- Sub-unit tiebreakers (only matter when residuals are equal) ---
    r = residual.astype(np.float64)

    # (a) Exact fill: eliminating a bin entirely is very valuable.
    exact = (residual == 0).astype(np.float64)

    # (b) Smooth residual-quality tie-breaker: a monotone, bounded discriminator
    # that sharpens only among small residuals (0..~10) and flattens beyond,
    # targeting genuine near-ties. Harmonic form: r/(r+5) rises faster than the
    # exponential at small r but saturates to 1 similarly, so it is a drop-in
    # bounded monotone replacement. Prior generations showed the smooth
    # tie-breaker's exact shape is interchangeable; this tests the harmonic
    # family directly inside the current three-term structure.
    smooth = 0.5 * (r / (r + 5.0))

    # (c) Reuse of already-used bins for small items, so empty bins stay free
    # for big items. Sub-unit magnitude.
    used = (bins < 100).astype(np.float64)
    small_pref = used * (1.0 / (1.0 + max(item, 1))) * 0.25

    # Combine tiebreakers, total magnitude strictly < BIG so best-fit ordering
    # between distinct residuals is provably preserved.
    tiebreak = 0.40 * exact + smooth + small_pref

    return score + tiebreak
# EVOLVE-BLOCK-END