# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item

    # Best-fit base term: prefer small residual (tight fit).
    score = -residual.astype(np.float64)

    # Hard-coded structural rule: for large items, strongly prefer opening a
    # fresh (empty) bin instead of fragmenting a partially-filled one. Large
    # items are hard to place later, so consuming them into empty bins keeps
    # the partially-filled bins flexible for the many small items, which pack
    # densely into any residual. For small items we leave pure best-fit alone.
    if item > 50:
        score = score + 1000.0 * (residual == 100)

    return score
# EVOLVE-BLOCK-END