# EVOLVE-BLOCK-START
"""Best-fit with smooth residual-shape and reuse matching.

Paradigm: keep best-fit (tightest residual) as the dominant integer ordering by
scaling tightness with a large coefficient, then add bounded, smooth,
item-conditioned perturbations that only affect ties and near-ties:

  * smooth residual reward: exp(-r/20), stronger for small items (more
    placement flexibility -> medium residuals are more reusable).
  * reuse kernel: smooth Gaussian kernel over the online empirical PMF of
    item sizes, so residuals near a common item size get partial credit.
  * exact-fill bonus: residual == 0.
  * dead-residual penalty: 0 < residual < min_seen (unfillable so far).

All perturbations are bounded, and the tightness slope is chosen larger than
their maximum total, so best-fit dominance is provably preserved.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # ---- persistent online state ----
    if not hasattr(priority, "min_seen"):
        priority.min_seen = 101
        priority.hist = np.zeros(101, dtype=np.float64)
        priority.count = 0.0
    if item < priority.min_seen:
        priority.min_seen = item

    # Online histogram of item sizes.
    priority.count += 1.0
    priority.hist[item] += 1.0

    residual = bins - item  # int64, >= 0 for bins shown
    r = residual.astype(np.float64)

    # ---- dominant term: best-fit with a large slope ----
    # Slope 4 keeps integer tightness strictly dominant over total perturbation
    # (which is bounded below by <2 in magnitude).
    tightness = -4.0 * r

    # ---- smooth residual reward (sub-unit), item-conditioned ----
    # Small items (item < 50) get a stronger smooth term because medium
    # residuals are more reusable for them.
    size_gain = 1.0 + 0.5 * (item < 50)
    smooth = 0.45 * (1.0 - np.exp(-r / 20.0)) * size_gain

    # ---- reuse kernel over online PMF (sub-unit) ----
    pmf = priority.hist / priority.count
    # Smooth Gaussian kernel over residual: neighboring sizes get partial credit.
    idx = np.arange(101, dtype=np.float64)
    # For each residual value, kernel weight against every size in 0..100.
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    # Weighted sum: sum_s pmf[s] * exp(-((r - s)^2) / (2*sigma^2))
    sigma = 3.0
    # Compute via broadcasting on the unique residuals to keep it fast.
    diff = idx[None, :] - r_clip[:, None]  # shape (n_bins, 101)
    kernel = np.exp(-(diff * diff) / (2.0 * sigma * sigma))
    reuse = kernel @ pmf  # shape (n_bins,)
    beta = 0.25

    # ---- exact-fill bonus (sub-unit) ----
    exact_bonus = 0.5 * (residual == 0)

    # ---- dead-residual penalty (sub-unit) ----
    dead = (residual > 0) & (residual < priority.min_seen)
    dead_penalty = -0.3 * dead

    return tightness + smooth + beta * reuse + exact_bonus + dead_penalty
# EVOLVE-BLOCK-END