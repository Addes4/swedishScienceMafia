# EVOLVE-BLOCK-START
"""Harmonic-style best-fit: reward residuals that are exact multiples of the
current item size, and strongly reward exact fills. This is a structural rule
(not a statistical estimator), targeting the plateau identified as likely
heuristic-bound. Uses only integer modular arithmetic plus a small reuse term.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # int64, >= 0 for shown bins
    r = residual.astype(np.float64)

    # --- Dominant best-fit ordering (strict) ---
    BIG = 1000.0
    score = -r * BIG

    # --- Narrow-range smooth tie-breaker ---
    # Discriminates sharply only among small residuals (0..~10) and flattens
    # to ~0.45 beyond that. This is a probe for whether the plateau is
    # tie-bound: it only affects genuine near-ties in residual.
    smooth = 0.45 * (1.0 - np.exp(-r / 5.0))

    # --- Multiple-family structural tie-breaker ---
    # Reward residuals that can be closed by a chain of equal items. Gated by
    # residual > 0 (exact fills are already captured by `smooth`) and by the
    # modulo condition. Uses a smooth exponential shape so the reward is a
    # bounded monotone function of residual, matching the rest of the
    # tie-breaker vocabulary.
    mult_mask = (residual > 0) & (residual % item == 0)
    mult_reward = mult_mask.astype(np.float64) * (0.5 * (1.0 - np.exp(-r / 5.0)))

    return score + smooth + mult_reward
# EVOLVE-BLOCK-END