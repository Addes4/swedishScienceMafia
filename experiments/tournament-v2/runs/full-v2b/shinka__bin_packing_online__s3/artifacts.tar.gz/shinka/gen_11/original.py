# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    # Strongly prefer bins that become exactly full.
    score[residual == 0] += 1e6
    # Mildly avoid leaving tiny, hard-to-reuse slivers (residual 1..3),
    # enough to break near-ties but not override a genuinely tighter fit.
    small = (residual >= 1) & (residual <= 3)
    score[small] -= 0.5
    return score
# EVOLVE-BLOCK-END