# EVOLVE-BLOCK-START
"""Best-fit with adaptive sub-unit tie-breaking.

Pure best-fit (tightest residual) is the dominant rule. We add two strictly
sub-unit perturbations that preserve best-fit ordering exactly (since the
tightness term is an integer) but break ties in favor of less fragmented bins:

  * exact-fill bonus: residual == 0 is a perfect packing.
  * dead-residual penalty: residual in (0, min_seen) can never be filled by
    any future item (min_seen is the smallest item observed so far), so it is
    wasted capacity.

Both perturbations have magnitude < 1, so the best-fit ordering is provably
preserved; they only affect ties.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track smallest item seen so far (past + current). Bounded to 100.
    if not hasattr(priority, "min_seen"):
        priority.min_seen = 101
    if item < priority.min_seen:
        priority.min_seen = item

    # Core: best fit (prefer the tightest residual). Integer-valued.
    residual = bins - item  # int64, >= 0 for bins shown
    tightness = -residual.astype(np.float64)

    # Exact-fill bonus (sub-unit).
    exact_bonus = 0.5 * (residual == 0)

    # Dead-residual penalty (sub-unit): residual small but nonzero and
    # impossible to fill with any item seen so far.
    dead = (residual > 0) & (residual < priority.min_seen)
    dead_penalty = -0.3 * dead

    # Future-fit reuse bonus (sub-unit): residual == item means a future
    # identical item would exactly fill this bin, so placing here sets up a
    # perfect chain of equal items. Disjoint from exact-fill (residual == 0).
    reuse_bonus = 0.25 * (residual == item)

    return tightness + exact_bonus + dead_penalty + reuse_bonus
# EVOLVE-BLOCK-END