# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item (int64, >= 0)

    # --- Dominant best-fit key: strictly prefer small residual ---
    BIG = 1000.0
    score = -residual.astype(np.float64) * BIG

    # --- Sub-unit structural tie-breakers (total magnitude strictly < 1.0) ---
    r = residual.astype(np.int64)

    # (1) Unified exact-fit family: reward residuals in {0, item} with a
    # single mask and single magnitude, testing whether the disjointness of
    # the two exact-fit signals is what matters or whether the *presence* of
    # an exact-match reward is sufficient.
    exact_family = ((r == 0) | (r == item)).astype(np.float64)

    # (2) Harmonic-style "fill-to-multiple" for k >= 2 only (k = 1 is now
    # covered by the unified exact-fit term above), keeping terms disjoint so
    # total magnitude stays sub-unit.
    is_multiple = (r % item == 0).astype(np.float64)
    is_higher = is_multiple * ((r != 0) & (r != item)).astype(np.float64)
    k = np.where(is_higher > 0, r // item, 0)
    mult_reward = is_higher * (1.0 / (1.0 + k))

    # (3) Mild preference to reuse already-used bins so empty bins stay free
    # for large items.
    used = (bins < 100).astype(np.float64)
    small_pref = used * (1.0 / (1.0 + item)) * 0.25

    # (4) Single structural probe: prefer opening a fresh (empty) bin for
    # large items, as a sub-unit tie-breaker. beta = 0.25 keeps total shaping
    # magnitude < 0.5, preserving best-fit dominance.
    beta = 0.25
    empty_large = (r == 100).astype(np.float64) * (item > 50)

    tiebreak = (0.4 * exact_family
                + 0.35 * mult_reward
                + small_pref
                + 0.5 * beta * empty_large)

    return score + tiebreak
# EVOLVE-BLOCK-END