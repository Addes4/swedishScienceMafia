# EVOLVE-BLOCK-START
"""Best-fit with small-item preservation and online distribution-aware usefulness shaping."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # --- Online histogram of item sizes (1..100) ---
    if not hasattr(priority, "hist"):
        priority.hist = np.zeros(102, dtype=np.float64)
        priority.count = 0.0

    priority.count += 1.0
    priority.hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing item

    # --- Base term: best fit (prefer smallest residual) ---
    score = -residual.astype(np.float64)

    # --- Small-item bonus: keep empty bins free for big items ---
    # Only applies to items < 30, and only to already-used bins (bins < 100).
    if item < 30:
        used_mask = (bins < 100)
        score += (30 - item) * 20.0 * used_mask

    # --- Mild usefulness shaping: boost residuals that match a common item size ---
    # cdfmax[s] = max frequency among sizes 1..s (for s in 1..100)
    h = priority.hist[1:101]
    cdfmax = np.maximum.accumulate(h)
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    useful = np.where(r_clip > 0, cdfmax[np.maximum(r_clip - 1, 0)], 0.0)
    # Normalize to a probability-like quantity and blend with a small weight.
    useful = useful / priority.count
    score += 5.0 * useful

    return score
# EVOLVE-BLOCK-END