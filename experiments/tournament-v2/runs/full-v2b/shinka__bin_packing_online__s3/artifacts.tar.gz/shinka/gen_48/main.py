# EVOLVE-BLOCK-START
"""Best fit with a hybrid residual-quality + adaptive reuse tie-breaker.

Primary ordering is best-fit (smallest residual). Ties are broken by:
  - static residual-quality bonuses/penalties (perfect fit rewarded, tiny
    leftovers penalized, reusable-size leftovers rewarded), and
  - a small adaptive reuse estimate from a running empirical PMF of past
    item sizes plus a Gaussian tail for near-size future items.

All secondary terms are bounded so they only affect exact ties, never
override the primary best-fit ordering.
"""
import numpy as np

# Running statistics over past items (module-level state across calls).
_hist = np.zeros(101, dtype=np.float64)   # histogram of item sizes 1..100
_count = 0
_sum = 0.0
_sumsq = 0.0

# Adaptive reuse term scale (kept small so it only breaks ties).
_BETA = 0.3


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _sum, _sumsq

    # Update running statistics with the current item.
    _count += 1
    _sum += item
    _sumsq += item * item
    _hist[item] += 1.0

    mean = _sum / _count
    var = max(_sumsq / _count - mean * mean, 0.0)
    std = var ** 0.5
    sigma = max(std, 5.0)

    residual = bins - item  # >= 0 for all bins shown

    # Primary: best-fit.
    score = -residual.astype(np.float64)

    # --- Static residual-quality tie-breaker (magnitudes < 0.5) ---
    # Perfect fit: reward slightly (sweeping the exact-fit coefficient to the
    # untested low end of 0.1 to test whether the 0.4/0.45 magnitude is
    # load-bearing or whether a pure presence signal suffices).
    score += np.where(residual == 0, 0.1, 0.0)
    # Very small leftover (likely wasted): penalize slightly.
    score -= np.where((residual >= 1) & (residual <= 4), 0.1, 0.0)
    # Useful leftovers: reward residuals large enough to fit many future items.
    score += np.where((residual >= 15) & (residual <= 85), 0.3, 0.0)
    score += np.where((residual >= 5) & (residual <= 14), 0.1, 0.0)

    # --- Adaptive reuse estimate (bounded, only breaks ties) ---
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    pmf = _hist[r_clip] / _count
    gauss = np.exp(-((residual - mean) ** 2) / (2.0 * sigma * sigma))
    reuse = np.minimum(pmf + 0.25 * gauss, 1.0)
    score += _BETA * reuse

    return score
# EVOLVE-BLOCK-END