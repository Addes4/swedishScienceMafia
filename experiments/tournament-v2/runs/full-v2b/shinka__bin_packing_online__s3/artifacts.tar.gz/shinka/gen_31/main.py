# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)

    # Strongly prefer bins that become exactly full.
    score[residual == 0] += 1e6

    # Tie-breaker value function v(residual): all magnitudes < 1 so they only
    # affect exact ties and never overturn a strictly tighter fit.
    # Tiny slivers (1..3) are nearly unusable by future items -> penalize.
    score[(residual >= 1) & (residual <= 3)] -= 0.4
    # Small-to-mid leftovers are reusable by medium items -> small bonus.
    score[(residual >= 4) & (residual <= 25)] += 0.3
    # Mid-range leftovers can accept many future items near the mean -> bigger bonus.
    score[(residual >= 26) & (residual <= 70)] += 0.5
    # Very large leftovers on near-empty bins are like opening a new bin;
    # prefer consolidating into tighter fits -> slight penalty.
    score[(residual >= 71) & (residual <= 99)] -= 0.2

    # Conditioned "useful-mid" reward: small items benefit more from leaving a
    # medium residual that future items can reuse. Bounded (0.15) so it only
    # breaks near-ties and never overturns a strict best-fit difference of 1.
    beta = 0.25
    score[(residual >= 15) & (residual <= 85) & (item < 50)] += 0.6 * beta

    return score
# EVOLVE-BLOCK-END