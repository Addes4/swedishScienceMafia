# EVOLVE-BLOCK-START
"""Adaptive best-fit: dominant best-fit ordering plus a single continuous,
item-aware residual-quality tie-breaker.

Insight from prior programs: best-fit is the dominant rule, and small bounded
tie-breakers only matter at exact ties. Instead of stacking piecewise masks,
we use ONE smooth, bounded, item-normalized signal that rewards residuals
which look like plausible future items (mean ~40, Weibull-shaped), and fold
the perfect-fit and self-consistent signals into continuous smooth bumps.

All tie-breaker magnitudes sum to well under 1.0, so best-fit dominance
(residual difference >= 1) is preserved exactly.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # --- Primary term: best-fit. Dominant by construction. ---
    score = -r

    # --- Continuous item-aware residual-quality tie-breaker (< 0.5). ---
    # Reward residuals that resemble a plausible future item size (mean ~40).
    # Smooth bump peaking near r ~ 40, decaying away. Bounded in [0,1).
    mu = 40.0
    sigma = 28.0
    quality = np.exp(-0.5 * ((r - mu) / sigma) ** 2)
    # Also gently reward very small residuals (they keep bins "tight").
    tight = np.exp(-r / 15.0)
    score += 0.30 * quality + 0.10 * tight

    # --- Smooth perfect-fit bump: strongly prefer becoming exactly full. ---
    # Continuous Gaussian centered at r == 0 instead of a hard mask.
    perfect = np.exp(-0.5 * (r / 1.5) ** 2)
    score += 0.45 * perfect

    # --- Smooth self-consistent bump: residual matches the arriving item. ---
    # This is the "meant for this item" signal, folded into the same family.
    consistent = np.exp(-0.5 * ((r - item) / 1.5) ** 2)
    score += 0.35 * consistent

    return score
# EVOLVE-BLOCK-END