# EVOLVE-BLOCK-START
"""Best-fit core with an orthogonal, sub-unit residual-composability tiebreaker.

Novel approach: keep strict best-fit ordering as the dominant key, and resolve
ties between equal residuals using an online distribution-aware measure of how
"composable" the leftover residual is (rather than a raw frequency match).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # --- Online statistics of item sizes ---
    if not hasattr(priority, "hist"):
        priority.hist = np.zeros(102, dtype=np.float64)   # counts for sizes 1..101
        priority.count = 0.0
        priority.sum = 0.0

    priority.count += 1.0
    priority.hist[item] += 1.0
    priority.sum += float(item)
    mean_size = priority.sum / priority.count

    residual = bins - item  # capacity left after placing item

    # --- Dominant key: strict best-fit ordering ---
    # Multiply by a large constant so that ANY difference in residual dominates
    # all tiebreak shaping (which stays strictly below this constant).
    BIG = 1000.0
    score = -residual.astype(np.float64) * BIG

    # --- Sub-unit tiebreakers (only matter when residuals are equal) ---
    r = residual.astype(np.float64)

    # (a) Exact fill: eliminating a bin entirely is very valuable. This is the
    # one non-negotiable piece: closing a bin dominates any residual shaping.
    exact = (residual == 0).astype(np.float64)

    # (b) Single smooth, monotone-consistent residual-quality term. Replaces the
    # prior piecewise/multi-term bucketing (exact / modular-composability /
    # reuse). Bounded in [0, 1), strictly increasing in residual, and implicitly
    # penalizing tiny residuals (sliver avoidance). beta keeps it sub-unit.
    beta = 0.35
    residual_quality = beta * (1.0 - np.exp(-r / 20.0))

    # (c) Tiny reuse preference: favor already-used bins for small items so
    # empty bins stay free for large items. Kept very small to preserve the
    # provable best-fit ordering between distinct residuals.
    used = (bins < 100).astype(np.float64)
    small_pref = used * (1.0 / (1.0 + max(item, 1))) * 0.05

    # Combine tiebreakers, total magnitude strictly < 1.0 so best-fit ordering
    # between distinct residuals is provably preserved.
    tiebreak = 0.45 * exact + residual_quality + small_pref

    return score + tiebreak
# EVOLVE-BLOCK-END