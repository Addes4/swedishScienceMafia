# EVOLVE-BLOCK-START
"""Best-fit with residual-usefulness shaping driven by online item statistics."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Maintain a running histogram of item sizes (1..100) to estimate the
    # distribution online. This lets us detect residuals that match common
    # item sizes and are therefore likely to be exactly refilled later.
    if not hasattr(priority, "hist"):
        priority.hist = np.zeros(101, dtype=np.float64)
        priority.count = 0.0

    priority.count += 1.0
    priority.hist[item] += 1.0

    # Residual capacity after placing the item in each candidate bin.
    residual = bins - item  # int64 array, >= 0 for bins shown

    # Best-fit term: prefer small residual (tight fit).
    tightness = -residual.astype(np.float64)

    # Reuse term: probability that the residual matches a common future item size.
    # A residual equal to a frequently-seen item size can be filled exactly later,
    # which reduces wasted capacity. We normalize the histogram into a PMF.
    pmf = priority.hist / priority.count  # pmf[s] for s in 0..100
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    reuse = pmf[r_clip]  # probability mass at the exact residual size

    # Blend: best-fit dominates; reuse acts as a sub-unit tie-breaker so that
    # among similarly tight bins we pick the one whose residual is more reusable.
    beta = 0.75
    return tightness + beta * reuse
# EVOLVE-BLOCK-END