# EVOLVE-BLOCK-START
"""Best-fit with residual-usefulness shaping driven by online item statistics."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Maintain a running histogram of item sizes (1..100) to estimate the
    # distribution online, and track the smallest item size seen so far.
    if not hasattr(priority, "hist"):
        priority.hist = np.zeros(101, dtype=np.float64)
        priority.count = 0.0
        priority.min_seen = 101

    priority.count += 1.0
    priority.hist[item] += 1.0
    if item < priority.min_seen:
        priority.min_seen = item

    # Residual capacity after placing the item in each candidate bin.
    residual = bins - item  # int64 array, >= 0 for bins shown

    # Best-fit term: prefer small residual (tight fit).
    tightness = -residual.astype(np.float64)

    # Dead-residual correction: a residual in (0, min_seen) can never be filled
    # by any future item, so it is pure wasted capacity. Penalize such bins so
    # best-fit does not create unfillable leftovers when a usable residual is
    # available. An exact fill (residual == 0) is ideal and gets a bonus.
    dead = (residual > 0) & (residual < priority.min_seen)
    dead_penalty = -50.0 * dead.astype(np.float64)
    exact_bonus = 5.0 * (residual == 0).astype(np.float64)

    # Reuse term: probability that the residual matches a common future item size.
    # A residual equal to a frequently-seen item size can be filled exactly later,
    # which reduces wasted capacity. We normalize the histogram into a PMF.
    pmf = priority.hist / priority.count  # pmf[s] for s in 0..100
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    reuse = pmf[r_clip]  # probability mass at the exact residual size

    # Blend: best-fit dominates; dead-residual penalty fixes its main failure
    # mode; reuse acts as a sub-unit tie-breaker among similar tightness bins.
    beta = 0.75
    return tightness + dead_penalty + exact_bonus + beta * reuse
# EVOLVE-BLOCK-END