# EVOLVE-BLOCK-START
"""Value-function online bin packing.

Instead of heuristic scoring, we compute a residual-value function U[r] =
expected remaining items packable in a bin with residual r, under greedy
best-fit against the item-size distribution. Bins are ranked by the marginal
utility U[r] - U[r - item] of placing the arriving item there (larger is
better), with strict best-fit as the dominant tiebreak so that a residual
difference of 1 always wins over any utility noise.

This is a genuinely different paradigm from best-fit + tie-breakers: it ranks
bins by their downstream packing value, not by residual magnitude.
"""
import numpy as np

# ---------------------------------------------------------------------------
# Precompute the residual value function U[r] for r = 0..100.
# Item sizes follow a Weibull-shaped distribution with mean ~40. We approximate
# it with a discretized histogram over 1..100 (integer sizes, since items are
# integers). We use a Weibull(k=2, scale) shape tuned so the mean is ~40.
# ---------------------------------------------------------------------------
_CAP = 100

def _build_size_pmf():
    # Weibull with shape k=2 has mean = scale * Gamma(1 + 1/2) = scale * 0.8862.
    # Choose scale so mean ~ 40 -> scale ~ 45.13. Clip to [1, 100], renormalize.
    k = 2.0
    scale = 40.0 / 0.886226925452758  # Gamma(1.5)
    sizes = np.arange(1, _CAP + 1, dtype=np.float64)
    # Weibull pdf: (k/scale) * (x/scale)^(k-1) * exp(-(x/scale)^k)
    pdf = (k / scale) * (sizes / scale) ** (k - 1.0) * np.exp(-(sizes / scale) ** k)
    pdf = np.maximum(pdf, 1e-12)
    pmf = pdf / pdf.sum()
    return pmf


_PMF = _build_size_pmf()  # length 100, index i corresponds to size i+1


def _build_value_function():
    # U[r] = expected number of future items packable into a bin of residual r
    # under greedy best-fit. We use value iteration with a mild discount so the
    # sum converges and small-item packing is rewarded but bounded.
    gamma = 0.97  # discount per packed item
    U = np.zeros(_CAP + 1, dtype=np.float64)
    for _ in range(200):  # value iteration
        newU = np.zeros_like(U)
        for r in range(_CAP + 1):
            best = 0.0
            for s in range(1, min(r, _CAP) + 1):
                p = _PMF[s - 1]
                if p <= 0.0:
                    continue
                val = p * (1.0 + gamma * U[r - s])
                best += val
            newU[r] = best
        U = newU
    # Normalize so U is O(1)-scale for numeric comfort (not strictly needed).
    return U


_U = _build_value_function()


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # Marginal utility of placing the item here: how much future packability we
    # retain by consuming `item` from this residual.
    r_clipped = np.clip(r, 0, _CAP)
    before = _U[r_clipped]
    after = _U[np.clip(r_clipped - item, 0, _CAP)]
    marginal = before - after  # >= 0; larger means we "spend" less value

    # Primary ordering: strict best-fit dominates. We map best-fit to a large
    # term so any residual difference of 1 beats all utility variation.
    score = -r.astype(np.float64) * 1e6

    # Secondary: value-function marginal utility (bounded, only breaks ties).
    score += marginal * 1.0

    # Hard exact-fit bonus (residual == 0): extremely good, but must not
    # override best-fit dominance (residual 0 is already the best best-fit).
    score += np.where(residual == 0, 1e9, 0.0)

    # Self-consistent bonus: residual exactly equals the arriving item, meaning
    # this bin was "meant" for this item. Small, tiebreak-only.
    score += np.where(residual == item, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END