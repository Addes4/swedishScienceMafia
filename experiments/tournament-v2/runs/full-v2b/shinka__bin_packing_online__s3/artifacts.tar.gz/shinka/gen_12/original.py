# EVOLVE-BLOCK-START
"""Adaptive best-fit: pure best-fit plus an online-mean-driven small-item bonus
that prefers reusing already-used bins for small items, keeping empty bins free."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Online running mean of item sizes (past + current item).
    if not hasattr(priority, "count"):
        priority.count = 0
        priority.total = 0.0
    priority.count += 1
    priority.total += item
    mean_item = priority.total / priority.count

    # Adaptive threshold: small items are those below roughly the mean.
    # Clamped to a reasonable range so it stays useful early on.
    threshold = mean_item
    if threshold < 15.0:
        threshold = 15.0
    elif threshold > 40.0:
        threshold = 40.0

    # Core: best fit (prefer the tightest residual).
    residual = bins - item
    score = -residual.astype(np.int64)

    # Bonus for small items placed into already-used bins (keep empty bins free).
    small_amount = threshold - item
    if small_amount > 0:
        used_mask = (bins < 100)
        # Weight scaled by how small the item is; modest so it only breaks ties.
        weight = 0.5 * small_amount
        score = score + (weight * used_mask).astype(np.int64)

    return score
# EVOLVE-BLOCK-END