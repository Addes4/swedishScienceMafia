# EVOLVE-BLOCK-START
"""Best-fit with a bounded dead-residual penalty and exact-fill bonus.

Pure best-fit (tightest residual) is the strongest simple rule here. We add a
single sub-unit fragmentation-aware term: penalize residuals in (0, min_seen),
which can never be filled by any future item, and reward exact fills. Because
the tightness term is an integer and both perturbations are strictly less than
1 in magnitude, the best-fit ordering is provably preserved; the shaping only
breaks ties.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track the smallest item size seen so far (past + current item).
    if not hasattr(priority, "min_seen"):
        priority.min_seen = 101
    if item < priority.min_seen:
        priority.min_seen = item

    # Core: best fit (prefer the tightest residual).
    residual = bins - item  # int64 array, >= 0 for bins shown
    tightness = -residual.astype(np.float64)

    # Dead-residual penalty: residual in (0, min_seen) can never be filled by
    # any future item, so it is wasted capacity. Penalize it (sub-unit) so that
    # among equal tightness, we prefer residuals that remain fillable.
    dead = (residual > 0) & (residual < priority.min_seen)
    dead_penalty = -0.3 * dead.astype(np.float64)

    # Exact-fill bonus: residual == 0 is ideal (perfect packing), sub-unit.
    exact_bonus = 0.5 * (residual == 0).astype(np.float64)

    # All perturbations are < 1 in magnitude, so best-fit ordering is preserved.
    return tightness + dead_penalty + exact_bonus
# EVOLVE-BLOCK-END