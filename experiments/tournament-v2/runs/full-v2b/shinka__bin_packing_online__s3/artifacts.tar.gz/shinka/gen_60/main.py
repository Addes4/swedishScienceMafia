# EVOLVE-BLOCK-START
"""Best-fit with strong exact-fit preference and residual-quality tie-breaker.

Primary term is best-fit: prefer the bin with the smallest residual
(remaining capacity minus item). Exact fits are strongly rewarded.
A tiny secondary term (magnitude < 0.5) only affects exact ties, nudging
toward residuals more likely to be reused and away from wasted slivers.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown (they all fit the item)

    # Best-fit primary ordering.
    score = -residual.astype(np.float64)

    # Prefer bins that become exactly full. Magnitude is a free parameter
    # (any non-negative value ties); use a small value so the primary
    # best-fit ordering and smooth tie-breaker stay dominant.
    score[residual == 0] += 0.05

    # Smooth residual-quality tie-breaker (magnitude < 0.5 -> ties only).
    # Monotone increasing in residual, bounded in [0, 0.4): tiny slivers are
    # implicitly penalized, larger reusable leftovers rewarded, without the
    # artificial cutoffs of piecewise masks.
    r = residual.astype(np.float64)
    score += 0.4 * (1.0 - np.exp(-r / 20.0))

    return score
# EVOLVE-BLOCK-END