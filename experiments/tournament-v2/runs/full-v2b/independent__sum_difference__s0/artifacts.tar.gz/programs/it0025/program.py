import math
import random
import time


def _stats(a):
    n = len(a)
    if n < 2:
        return 0, 1, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    score = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
    return ld, ls, score


def _stats_fast(a):
    # Faster via sorting-based difference counting? Use set but with dedup.
    n = len(a)
    if n < 2:
        return 0, 1, 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    score = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
    return ld, ls, score


def _greedy_sidon(n, scale=1):
    """Greedy Sidon set (B_2) minimizing difference collisions."""
    a = [0]
    used_diffs = {0}
    x = 0
    while len(a) < n:
        x += 1
        ok = True
        new_diffs = []
        for b in a:
            d1 = x - b
            d2 = b - x
            if d1 in used_diffs or d2 in used_diffs:
                ok = False
                break
            new_diffs.append(d1)
            new_diffs.append(d2)
        if ok:
            for d in new_diffs:
                used_diffs.add(d)
            used_diffs.add(0)
            a.append(x)
    return [v * scale for v in a]


def _make_initial():
    # Try a union of a symmetric set: A = S ∪ (-S) where S is a Sidon-like set.
    # Symmetry makes sums collapse: a+b = 0 often, and differences still rich.
    candidates = []

    for n in [20, 40, 80, 160, 320]:
        s = _greedy_sidon(n)
        # symmetric doubling: S and -S
        a = sorted(set(s + [-x for x in s]))
        candidates.append(a)

    # Singer-ish: differences of a perfect difference set mod m give high diff count
    # Try random dense intervals with symmetric layout
    random.seed(12345)
    for _ in range(20):
        n = random.choice([50, 100, 200, 400, 800])
        base = sorted(random.sample(range(1, 5000), n))
        a = sorted(set(base + [-x for x in base]))
        candidates.append(a)

    best = None
    best_score = -1
    for c in candidates:
        ld, ls, sc = _stats_fast(c)
        if sc > best_score:
            best_score = sc
            best = c
    return best, best_score


def _local_search(best, best_score, deadline):
    cur = best[:]
    cur_score = best_score
    n_cur = len(cur)

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6 and len(cand) > 0:
            i = random.randrange(len(cand))
            delta = random.randint(-5, 5)
            cand[i] += delta
        elif op < 0.85:
            cand.append(random.randint(-5000, 5000))
        elif len(cand) > 10:
            i = random.randrange(len(cand))
            cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        ld, ls, sc = _stats_fast(cand)
        if sc >= cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score
    return best, best_score


def solve():
    random.seed(int(time.time()) & 0xFFFF)
    best, best_score = _make_initial()

    # Structured refinement: symmetric Sidon with more attempts
    for n in [10, 25, 50, 100, 200]:
        s = _greedy_sidon(n)
        a = sorted(set(s + [-x for x in s]))
        ld, ls, sc = _stats_fast(a)
        if sc > best_score:
            best, best_score = a, sc

    deadline = time.time() + 110
    best, best_score = _local_search(best, best_score, deadline)
    return sorted(set(best))
