import math
import random
import time

# We maximize log|A-A|/log|A+A| (+ tiny bonus).
# Key idea: use sets whose pairwise sums are extremely collision-rich, so |A+A| stays
# near |A| while |A-A| is large.  Dragon-like / Sidon-like constructions do the opposite,
# but near-arithmetic / convex combinations can make sums overlap heavily.
#
# Strong practical family: A = { x_i }, where many x_i are chosen from a short interval
# and copied/reflected so that x_i+x_j often lands in a narrow range.
#
# We search in a structured way:
#   1. Start from highly composite arithmetic-center sets.
#   2. Use randomized hill climbing with exact set scoring.
#   3. Periodically restart and keep the best.

MAXN = 4000
LIMIT = 10**15


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e9, None, None, n
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            sums.add(ai + aj)
            diffs.add(ai - aj)
            diffs.add(aj - ai)
    ls = len(sums)
    ld = len(diffs)
    if ls <= 1 or ld <= 1:
        return -1e9, ld, ls, n
    base = math.log(ld) / math.log(ls)
    bonus = (1.0 - 1.0 / n) / 100.0
    return base + bonus, ld, ls, n


def _init_candidates():
    cands = []

    # Small known-good starting points.
    starts = [
        [0, 1, 2, 4, 7, 12, 20, 33, 54, 88],
        [0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 100],
        [0, 2, 3, 7, 11, 19, 25, 38, 56, 79, 105],
        [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144],
        [0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40],
        [0, 1, 2, 3, 4, 6, 8, 10, 14, 18, 24, 30],
    ]
    for s in starts:
        cands.append(s)

    # Geometric-ish sets with many repeated sums.
    for q in [2, 3, 4, 5, 6, 7, 8, 10]:
        a = [0]
        x = 1
        for _ in range(random.randint(20, 80)):
            a.append(x)
            x *= q
            if x > LIMIT:
                break
        cands.append(a)

    # Arithmetic progressions and unions of a few APs give very small sum sets.
    for k in [30, 50, 80, 120, 200, 300]:
        if k <= MAXN:
            cands.append(list(range(k)))

    # Random subsets of [0, T] for modest T.
    for _ in range(20):
        T = random.randint(30, 2000)
        k = random.randint(20, min(300, T + 1))
        cands.append(sorted(random.sample(range(T + 1), k)))

    return cands


def _normalize(a):
    a = sorted(set(int(x) for x in a))
    if not a:
        return a
    base = a[len(a)//2]
    a = [x - base for x in a]
    mx = max(abs(x) for x in a)
    if mx > 10**14:
        scale = max(1, mx // 10**14)
        a = [x // scale for x in a]
        a = sorted(set(a))
    return a


def _local_search(a, deadline):
    a = _normalize(a)
    if len(a) < 2:
        return a
    best = a[:]
    best_score, _, _, _ = _score(best)
    cur = best[:]
    cur_score, _, _, _ = _score(cur)

    while time.time() < deadline:
        n = len(cur)
        cand = cur[:]
        mode = random.random()

        if mode < 0.50:
            # mutate one element slightly
            i = random.randrange(n)
            step = random.choice([-1, 1, -2, 2, -3, 3, -5, 5, -8, 8, -13, 13,
                                  -21, 21, -34, 34, -55, 55])
            cand[i] += step
        elif mode < 0.72:
            # move an element to a new random value, biased near existing sums/diffs
            i = random.randrange(n)
            j = random.randrange(n)
            k = random.randrange(n)
            base = cur[j] + cur[k] - cur[i] if random.random() < 0.5 else cur[j] - cur[k]
            cand[i] = base + random.randint(-3, 3)
        elif mode < 0.86 and n < MAXN:
            # add a new element near an existing sum/difference
            j = random.randrange(n)
            k = random.randrange(n)
            v = cur[j] + cur[k]
            cand.append(v)
        elif n > 5:
            # remove one element
            i = random.randrange(n)
            del cand[i]
        else:
            continue

        cand = _normalize(cand)
        if len(cand) < 2:
            continue
        sc, ld, ls, nn = _score(cand)
        if sc >= cur_score:
            if sc > best_score:
                best, best_score = cand[:], sc
            cur, cur_score = cand, sc
        else:
            # occasional restart from best
            if random.random() < 0.01:
                cur = best[:]
                cur_score, _, _, _ = _score(cur)

    return best


def _greedy_sum_minimize(seed, deadline):
    """Grow a set while trying to keep sums small and differences large."""
    a = _normalize(seed)
    if not a:
        a = [0]
    cur_score, _, _, _ = _score(a)

    while time.time() < deadline and len(a) < MAXN:
        # candidate pool made from existing sums and differences
        pool = set()
        for x in a:
            for y in a:
                for d in (-3, -2, -1, 0, 1, 2, 3):
                    pool.add(x + y + d)
                    pool.add(x - y + d)
        if not pool:
            break
        pool = list(pool)
        random.shuffle(pool)
        best_candidate = None
        best_s = cur_score
        # Try a batch; exact score is O(n^2), so keep batch modest.
        for v in pool[:min(len(pool), 80)]:
            if v in a:
                continue
            b = _normalize(a + [v])
            sc, _, _, _ = _score(b)
            if sc > best_s:
                best_s = sc
                best_candidate = b
        if best_candidate is None:
            # add a random element anyway
            v = random.choice(pool)
            a = _normalize(a + [v])
            cur_score, _, _, _ = _score(a)
        else:
            a = best_candidate
            cur_score = best_s
    return a


def solve():
    deadline = time.time() + 118  # stay within 120s

    candidates = _init_candidates()
    best = None
    best_score = -1e9

    for c in candidates:
        c = _normalize(c)
        if len(c) < 2:
            continue
        sc, _, _, _ = _score(c)
        if sc > best_score:
            best_score = sc
            best = c[:]

    # Targeted local searches, interleaved with greedy growth.
    n_rounds = 0
    while time.time() < deadline:
        n_rounds += 1

        if n_rounds % 3 == 0:
            seed = list(best) if best is not None else [0, 1, 2, 4, 7]
            cand = _greedy_sum_minimize(seed, min(deadline, time.time() + 8))
        else:
            if best is not None and random.random() < 0.7:
                seed = list(best)
            else:
                seed = random.choice(candidates)
                seed = _normalize(seed)
            cand = _local_search(seed, min(deadline, time.time() + 6))

        cand = _normalize(cand)
        if len(cand) < 2:
            continue
        sc, _, _, _ = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]

        # trim / expand around current best occasionally
        if best is not None and random.random() < 0.15 and len(best) < MAXN:
            trial = list(best)
            for _ in range(random.randint(1, 5)):
                j = random.randrange(len(trial))
                k = random.randrange(len(trial))
                trial.append(trial[j] + trial[k] + random.randint(-2, 2))
            trial = _normalize(trial)
            sc, _, _, _ = _score(trial)
            if sc > best_score:
                best_score = sc
                best = trial[:]

    if best is None:
        best = [0, 1, 2, 4, 7, 12, 20, 33]
    best = _normalize(best)

    # Final safety: ensure distinct, size and bounds.
    best = [int(x) for x in sorted(set(best))]
    if len(best) > MAXN:
        best = best[:MAXN]
    mx = max(abs(x) for x in best) if best else 0
    if mx > LIMIT:
        scale = max(1, mx // LIMIT)
        best = sorted(set(x // scale for x in best))
    return best
