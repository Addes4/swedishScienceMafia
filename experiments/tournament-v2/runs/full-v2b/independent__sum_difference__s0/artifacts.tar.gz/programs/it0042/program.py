import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _fast_score_vals(a):
    # approximate score contribution without full recompute
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def solve():
    deadline = time.time() + 110

    # Build candidate: a set where sums collide a lot but differences are many.
    # Idea: A = {p_i} with p_i = base * k^i (geometric) -> sums mostly distinct though.
    # Better: B = powers of 2 (0,1,2,4,...) -> all subset-sums unique but pair sums?
    # Use A = {0,1,2,4,8,...,2^(n-1)} shifted. Pair sums a_i+a_j = 2^i+2^j;
    # distinct unless {i,j} equal -> many collisions since unordered pairs map.
    # Actually 2^i+2^j distinct for i<=j, so |A+A| ~ n(n+1)/2. Not small.
    # 
    # Key: want |A+A| small. A symmetric around 0 helps: sums collapse.
    # Use A = {-M,...,-1,0,1,...,M}? Then sums = all integers -2M..2M -> small |A+A|,
    # but diffs also small. Ratio ~1. Bad.
    #
    # Best known: Sidon-like sets with additive structure. Attempt: A = union of
    # arithmetic progressions with shared differences so sums coincide partially.

    # Heuristic optimization search.
    best = None
    best_score = -1.0

    # Seed candidates
    seeds = []

    # Seed 1: powers of 2 (gives many diffs since unique subset sums, sums also many)
    p2 = [1 << i for i in range(12)]
    seeds.append(p2)

    # Seed 2: geometric with ratio slightly less than 2
    seeds.append([int(round(1.9 ** i)) for i in range(15)])

    # Seed 3: random spread
    seeds.append(sorted(random.sample(range(-1000, 1000), 12)))

    # Seed 4: base-3 style
    seeds.append([3 ** i for i in range(9)])

    # Seed 5: mixed geometric small
    seeds.append([int(round(1.5 ** i)) for i in range(18)])

    # Seed 6: all elements forming a "sum-collapsing" set: A = B ∪ (-B)
    # then A+A = (B+B)∪(B-B)∪(-(B-B))∪... reduces range? not necessarily.
    B = [1 << i for i in range(7)]
    seeds.append(sorted(set(B + [-b for b in B])))

    for s in seeds:
        s = sorted(set(s))
        sc = _score(s)
        if sc > best_score:
            best_score = sc
            best = s[:]

    # Local search
    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.4 and len(cand) > 2:
            # perturb one element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-3, 3)
        elif op < 0.6:
            # add a new element near a random one
            i = random.randrange(len(cand))
            base = cand[i]
            cand.append(base + random.randint(-5, 5))
        elif op < 0.75:
            # add a new element far away to boost diffs
            cand.append(random.randint(-10 ** 6, 10 ** 6))
        elif op < 0.85 and len(cand) > 3:
            # remove element
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # shift magnitude
            i = random.randrange(len(cand))
            cand[i] = cand[i] * random.choice([2, -2]) + random.randint(-2, 2)

        cand = sorted(set(cand))
        if len(cand) > 4000:
            continue
        if any(abs(x) > 10 ** 15 for x in cand):
            continue

        sc = _score(cand)
        if sc > cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc
        elif random.random() < 0.15:
            # restart from best with noise
            cur = best[:]
            if len(cur) > 2:
                i = random.randrange(len(cur))
                cur[i] += random.randint(-2, 2)
            cur_score = _score(cur)

    return sorted(set(best))
