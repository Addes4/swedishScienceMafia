import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) <= 1 or len(diffs) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _greedy_sidon(max_n=160, limit=10**6):
    """Greedy Sidon-like sequence: no two distinct pairs have the same sum."""
    A = [0]
    used_sums = {0}
    x = 1
    while len(A) < max_n and x < limit:
        ok = True
        new_sums = set()
        for a in A:
            s = x + a
            if s in used_sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            new_sums.add(x + x)
            if x + x in used_sums:
                ok = False
        if ok:
            A.append(x)
            used_sums.update(new_sums)
            used_sums.add(x + x)
        x += 1
        if x > 200000:
            break
    return A


def _powers_of_two_set(k):
    return [2 ** i for i in range(k)]


def _optimize_local(A, deadline):
    """Local search over multiplicities/translations/scales and small perturbations."""
    best = list(set(A))
    best_score = _score(best)
    cur = best[:]
    t0 = time.time()
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif op < 0.75:
            if random.random() < 0.5:
                cand.append(random.randint(-20, 20))
            elif len(cand) > 4:
                j = random.randrange(len(cand))
                cand.pop(j)
        else:
            shift = random.randint(-50, 50)
            cand = [x + shift for x in cand]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > best_score:
            best, best_score, cur = cand[:], s, cand
        elif s > best_score - 0.02 and random.random() < 0.3:
            cur = cand[:]
        elif random.random() < 0.05:
            cur = best[:]
    return best, best_score


def solve():
    deadline = time.time() + 110
    candidates = []

    # Nice theoretical family: scale Sidon-like greedy set, then dilate.
    try:
        sed = _greedy_sidon(max_n=220, limit=50000)
        if len(sed) >= 2:
            candidates.append(sed)
            # dilations
            for m in (1, 2, 3, 5, 10, 101, 1000):
                candidates.append([m * x for x in sed[:220]])
    except Exception:
        pass

    # Powers of two: differences unique, sums mostly unique -> strong ratio.
    for k in range(2, 14):
        candidates.append(_powers_of_two_set(k))
        candidates.append([-(2 ** i) for i in range(k)])

    # Translate some power sets to break symmetry.
    for k in range(2, 13):
        base = [2 ** i for i in range(k)]
        for shift in (1, 3, 7, 100, 1000):
            candidates.append([x + shift for x in base])

    # Random small sets.
    for _ in range(200):
        n = random.randint(3, 25)
        cand = [random.randint(-1000, 1000) for _ in range(n)]
        candidates.append(cand)

    best = None
    best_score = -1.0
    for c in candidates:
        c = list(set(c))
        if len(c) < 2:
            continue
        s = _score(c)
        if s > best_score:
            best, best_score = c, s

    # Local search from the best few candidates.
    pool = sorted(candidates, key=lambda z: _score(list(set(z))), reverse=True)[:10]
    per_time = max(1.0, (deadline - time.time()) / max(1, len(pool)))
    for c in pool:
        if time.time() >= deadline:
            break
        sub_deadline = min(deadline, time.time() + per_time)
        A, s = _optimize_local(c, sub_deadline)
        if s > best_score:
            best, best_score = A, s

    if best is None:
        best = [1, 2, 4, 8, 16, 32]

    best = sorted(set(best))
    # Final safety: fit limits.
    best = [x for x in best if -10**15 <= x <= 10**15]
    if len(best) > 4000:
        best = best[:4000]
    return best
