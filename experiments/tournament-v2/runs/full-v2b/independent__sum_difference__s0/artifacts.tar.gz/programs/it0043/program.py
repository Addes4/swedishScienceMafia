import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build_ap_sidon(k_ap, k_sidon, base, step):
    """Build a set that is an arithmetic progression (small sum set) union a Sidon-like set."""
    A = []
    start = base
    for i in range(k_ap):
        A.append(start + i * step)
    # Sidon-like set: use powers-of-2 style gaps to keep differences mostly distinct
    x = 10**6
    used = set(A)
    for i in range(k_sidon):
        x = x + random.randint(1, 5) * (10**7)
        if x not in used:
            A.append(x)
            used.add(x)
    return A


def _random_sidon(n, bound):
    """Random Sidon-ish set via greedy: pick random values, keep if differences mostly new."""
    vals = random.sample(range(-bound, bound), min(n * 3, 2 * bound))
    A = []
    diffs = set()
    for v in vals:
        ok = True
        new_diffs = set()
        for a in A:
            d1 = v - a
            d2 = a - v
            if d1 in diffs and d2 in diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            A.append(v)
            diffs |= new_diffs
        if len(A) >= n:
            break
    return A


def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Strategy 1: union of AP and Sidon-like set
    # AP contributes small sum set, Sidon contributes many differences.
    attempts = 0
    while time.time() < deadline * 0.8 or best is None:
        attempts += 1
        if time.time() > deadline:
            break

        k_ap = random.randint(5, 40)
        k_sidon = random.randint(5, 60)
        if k_ap + k_sidon < 8:
            continue
        base = random.randint(-100, 100)
        step = random.choice([1, 2, 3, 5, 10])
        A = _build_ap_sidon(k_ap, k_sidon, base, step)
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # Strategy 2: random Sidon-like sets, then add AP cluster
    while time.time() < deadline:
        n = random.randint(8, 80)
        bound = max(50, n * 4)
        A = _random_sidon(n, bound)
        if len(A) < 4:
            continue
        # Add small AP cluster
        extra = random.randint(2, 20)
        b = random.randint(-50, 50)
        for i in range(extra):
            A.append(b + i)
        A = list(set(A))
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # Local search refinement focusing on ratio
    cur = best[:]
    cur_score = _score(cur)
    deadline2 = time.time() + max(5, deadline - time.time()) if time.time() < deadline else 0

    # Fast incremental-ish local search
    local_deadline = time.time() + 60
    while time.time() < local_deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.45 and len(cand) > 4:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-5, -3, -2, -1, 1, 2, 3, 5])
        elif op < 0.7:
            cand.append(random.randint(-200, 200))
        elif op < 0.85 and len(cand) > 4:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # shift whole AP part
            i = random.randrange(len(cand))
            cand[i] = random.randint(-1000, 1000)
        cand = list(set(cand))
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s > cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    # clamp values
    best = [max(-10**15, min(10**15, v)) for v in best]
    return best
