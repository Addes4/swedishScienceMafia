import math
import random
import time


def _sets(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return diffs, sums


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs, sums = _sets(a)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _candidate(base, k, block):
    """Powers of base plus a small dense additive block."""
    a = []
    x = 1
    for _ in range(k):
        a.append(x)
        x *= base
    # add a small block near 0 to keep sums small
    for i in range(block):
        a.append(i + 1)
    for i in range(block):
        a.append(-(i + 1))
    return sorted(set(a))


def solve():
    best = None
    best_score = -1.0

    # Start from a few structured guesses.
    guesses = []
    for base in (2, 3, 4, 5, 6, 7, 8, 10):
        for k in range(6, 13):
            for block in range(0, min(6, k) + 1):
                guesses.append(_candidate(base, k, block))

    for g in guesses:
        s = _score(g)
        if s > best_score:
            best_score = s
            best = g[:]

    # Local search: tweak values while preserving reasonable structure.
    cur = best[:]
    deadline = time.time() + 100
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.55 and cand:
            i = random.randrange(len(cand))
            step = random.choice([-3, -2, -1, 1, 2, 3])
            cand[i] += step
        elif op < 0.8:
            cand.append(random.randint(-30, 30))
        elif len(cand) > 6:
            cand.pop(random.randrange(len(cand)))
        else:
            continue

        cand = sorted(set(cand))
        if len(cand) > 4000:
            continue
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]
            cur = cand[:]
        elif random.random() < 0.03:
            cur = best[:]

    return sorted(set(best))
