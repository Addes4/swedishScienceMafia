import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) == 0:
        return 0.0
    ld = len(diffs)
    ls = len(sums)
    if ld < 2 or ls < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _greedy_sidon(limit, target, rng):
    # Build a set where sums collide a lot but differences are mostly distinct.
    # Start from a sparse geometric-like seed, then add numbers that minimize new sums.
    a = [0, 1]
    used = {0, 1}
    sumset = {0, 1, 2}

    while len(a) < target and len(a) < limit:
        best = None
        best_new_sums = None
        best_candidates = []
        # sample candidate shifts relative to existing elements
        trials = 400 if len(a) < 80 else 160
        for _ in range(trials):
            base = rng.choice(a)
            delta = rng.randint(1, max(10, int(1.5 * len(a) + 20)))
            cand = base + delta
            if cand in used:
                continue
            new_sums = 0
            for x in a:
                if cand + x not in sumset:
                    new_sums += 1
            if best_new_sums is None or new_sums < best_new_sums:
                best_new_sums = new_sums
                best_candidates = [cand]
            elif new_sums == best_new_sums:
                best_candidates.append(cand)
        if not best_candidates:
            break
        cand = rng.choice(best_candidates)
        a.append(cand)
        used.add(cand)
        for x in a:
            sumset.add(cand + x)
            sumset.add(x + cand)
        # normalize to keep numbers small
        if rng.random() < 0.02:
            mn = min(a)
            a = [x - mn for x in a]
            used = set(a)
            sumset = {x + y for x in a for y in a}
    return a


def _local_improve(a, deadline, start_score=None):
    a = list(set(a))
    if len(a) < 2:
        return a, 0.0
    cur = a[:]
    cur_score = _score(cur) if start_score is None else start_score
    best = cur[:]
    best_score = cur_score
    n = len(cur)

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6 and len(cand) > 2:
            # tweak an element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-20, 20)
        elif op < 0.85:
            # add an element near an existing element
            base = random.choice(cand)
            cand.append(base + random.randint(1, 200))
        else:
            # remove an element
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur = cand
            cur_score = s
        elif random.random() < 0.01:
            cur = cand
            cur_score = s
        if s > best_score:
            best = cand[:]
            best_score = s
        # occasionally restart from best
        if random.random() < 0.005:
            cur = best[:]
            cur_score = best_score
    return best, best_score


def solve():
    random.seed(123456789)
    deadline = time.time() + 115

    candidates = []

    # seed structural sets
    candidates.append([0, 1])
    candidates.append([0, 1, 3, 7, 12, 20])
    candidates.append([0, 1, 4, 10, 18, 29, 43])
    candidates.append([0, 1, 3, 7, 15, 31, 63, 127])
    candidates.append([0, 1, 3, 8, 18, 38, 78, 158, 318])
    candidates.append([0, 1, 4, 13, 40, 121, 364])
    candidates.append([0, 1, 5, 17, 53, 161, 485, 1457])

    best = None
    best_score = -1.0

    for c in candidates:
        s = _score(c)
        if s > best_score:
            best = c[:]
            best_score = s

    # greedy sidon-ish sets of various sizes
    for target in [10, 20, 40, 80, 150, 300, 600, 1200, 2500, 3900]:
        if time.time() > deadline - 5:
            break
        g = _greedy_sidon(4000, target, random)
        s = _score(g)
        if s > best_score:
            best = g[:]
            best_score = s

    # local search refinement
    remaining_period = max(1, int(deadline - time.time()))
    time_slice = max(1, remaining_period // 6)
    cur_best = best[:]
    cur_best_score = best_score
    for round_idx in range(8):
        if time.time() > deadline:
            break
        sub_deadline = min(deadline, time.time() + time_slice)
        improved, sc = _local_improve(cur_best, sub_deadline, cur_best_score)
        if sc > cur_best_score:
            cur_best = improved
            cur_best_score = sc
        # also try fresh random greedy restarts
        g = _greedy_sidon(4000, random.randint(20, 3900), random)
        s = _score(g)
        if s > cur_best_score:
            cur_best = g
            cur_best_score = s

    # final cleanup
    result = sorted(set(cur_best))
    # ensure at least 2 elements
    if len(result) < 2:
        result = [0, 1]
    return result
