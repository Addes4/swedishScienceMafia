import math
import random
import time
import itertools


def _score_fast(a):
    if len(a) < 2:
        return 0.0
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0


def _construct_hybrid(t, m, spread):
    A = list(range(t))
    base = max(A) + 1
    val = base
    for i in range(m):
        A.append(val)
        val += spread + i * 3 + 1
    return A


def solve():
    best = [0, 1, 3, 7, 12, 20, -5, -11, 30, -20]
    best_score = _score_fast(best)

    deadline = time.time() + 110

    # Phase 1: systematic search over hybrid construction parameters
    for t in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 30, 40, 50]:
        for m in [2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30]:
            if t + m > 200:
                continue
            for spread in [1, 2, 3, 4, 5, 7, 10, 15, 20, 30, 50, 80, 120, 200]:
                cand = _construct_hybrid(t, m, spread)
                s = _score_fast(cand)
                if s > best_score:
                    best_score = s
                    best = cand

    # Phase 2: randomized local search on best
    cur = best[:]
    cur_score = best_score
    no_improve = 0

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()

        if op < 0.35:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-30, 30)
        elif op < 0.55:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, 300)
        elif op < 0.70:
            if len(cand) < 300:
                cand.append(random.randint(-500, 500))
        elif op < 0.80:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
        elif op < 0.90:
            i = random.randrange(len(cand))
            j = random.randrange(len(cand))
            cand[i], cand[j] = cand[j], cand[i]
        else:
            if len(cand) < 100:
                cand.append(max(cand) + random.randint(1, 100))

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score_fast(cand)
        if s >= cur_score:
            cur = cand
            cur_score = s
            no_improve = 0
            if s > best_score:
                best_score = s
                best = cand[:]
        else:
            no_improve += 1
            if no_improve > 200:
                cur = best[:]
                cur_score = best_score
                no_improve = 0

    # Phase 3: greedy refinement - try to add elements that don't increase |sums| much
    improved = True
    rounds = 0
    while improved and time.time() < deadline and rounds < 5:
        improved = False
        rounds += 1
        n = len(best)
        if n < 2:
            break
        sums = set()
        for x in best:
            for y in best:
                sums.add(x + y)
        # candidate additions near current range
        lo = min(best) - 200
        hi = max(best) + 200
        for _ in range(300):
            if time.time() > deadline:
                break
            v = random.randint(lo, hi)
            if v in best:
                continue
            trial = best + [v]
            s = _score_fast(trial)
            if s > best_score:
                best = trial
                best_score = s
                improved = True
                break

    return sorted(set(int(x) for x in best))
