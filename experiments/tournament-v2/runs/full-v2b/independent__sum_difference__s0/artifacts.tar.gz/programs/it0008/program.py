import math
import random
import time


def _sets(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score_vals(nd, ns, n):
    if n < 2 or ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _score(a):
    a = list(set(a))
    nd, ns = _sets(a)
    return _score_vals(nd, ns, len(a))


def _hill(a, deadline):
    a = list(set(a))
    best = a[:]
    best_s = _score(a)
    cur = a[:]
    cur_s = best_s
    step = 1
    while time.time() < deadline:
        n = len(cur)
        cand = cur[:]
        i = random.randrange(n)
        cand[i] += random.choice([-step, step, random.randint(-step, step)])
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_s or random.random() < 0.02:
            cur = cand
            cur_s = s
            if s > best_s:
                best = cand[:]
                best_s = s
        if random.random() < 0.002:
            cur = best[:]
            cur_s = best_s
        if random.random() < 0.01:
            step = random.randint(1, 12)
    return best, best_s


def _extend(a, deadline):
    a = list(set(a))
    best = a[:]
    nd, ns = _sets(best)
    best_s = _score_vals(nd, ns, len(best))
    while time.time() < deadline:
        found = False
        lo = min(best) - 50
        hi = max(best) + 50
        for _ in range(200):
            x = random.randint(lo, hi)
            if x in best:
                continue
            cand = best + [x]
            cnd, cns = _sets(cand)
            cs = _score_vals(cnd, cns, len(cand))
            if cs > best_s:
                best = cand
                nd, ns = cnd, cns
                best_s = cs
                found = True
                break
        if not found:
            break
    return best, best_s


def solve():
    deadline = time.time() + 115.0

    starts = [
        [7, 15, 18, 22, -3, -2],
        [0, 1, 3, 7, 12, 20, 30, 44, 65],
        [1, 2, 5, 10, 16, 23, 31, 40, 50],
        [0, 1, 4, 10, 18, 27, 37, 48, 60, 73],
        [1, 2, 4, 8, 13, 21, 31, 45, 66, 80],
    ]

    best = None
    best_s = -1.0

    for st in starts:
        a, s = _hill(st, min(deadline, time.time() + 8))
        if s > best_s:
            best, best_s = a, s

    while time.time() < deadline - 2:
        a, s = _hill(best, min(deadline - 1, time.time() + 10))
        if s > best_s:
            best, best_s = a, s
        if time.time() > deadline - 2:
            break

    a, s = _extend(best, deadline)
    if s > best_s:
        best, best_s = a, s

    return sorted(set(int(x) for x in best))
