import math
import random
import time


def _score_set(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    d = len(diffs)
    s = len(sums)
    if s <= 1 or d <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _parts(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def solve():
    deadline = time.time() + 110

    # Candidate constructions.

    def make_geometric(k, base=2):
        # {0,1,...,k} scaled? use powers to make many differences
        return [base ** i for i in range(k)]

    def make_mixed(n, spread):
        # random-ish symmetric around 0, dense near 0 to shrink sums
        vals = set()
        vals.add(0)
        for i in range(1, n):
            v = random.randint(-spread, spread)
            vals.add(v)
        return list(vals)

    def make_sidon_like(n, c):
        # greedy Sidon-ish set (B_2) gives distinct sums => large diff maybe not ideal
        s = [0]
        used = {0}
        # We want small sum set: cluster.
        return s

    best = [7, 15, 18, 22, -3, -2]
    bs = _score_set(best)

    # Structured search: build a set with a geometric backbone plus dense small offsets
    # to keep sums bounded while differences expand.
    def build_from_backbone(backbone, offsets):
        A = set()
        for b in backbone:
            for o in offsets:
                A.add(b + o)
        return list(A)

    # Search over union constructions
    def try_candidate(cand):
        nonlocal best, bs
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            return
        if max(abs(x) for x in cand) > 10**15:
            return
        s = _score_set(cand)
        if s > bs:
            best, bs = cand, s

    # Powers of two give many differences; adding symmetric small set keeps sums in check.
    # Baseline: powers 1,2,4,...,2^m together with their negatives and 0.
    for m in range(1, 13):
        back = [2 ** i for i in range(m)]
        A = set()
        for b in back:
            A.add(b)
            A.add(-b)
        A.add(0)
        try_candidate(list(A))
    for m in range(1, 13):
        back = [3 ** i for i in range(m)]
        A = set()
        for b in back:
            A.add(b)
            A.add(-b)
        A.add(0)
        try_candidate(list(A))

    # Union of a few geometric backbones each with small symmetric offsets near 0
    # keeps sumset mostly within [-2M, 2M] band while diffs spread widely.
    for m in range(2, 14):
        back = [2 ** i for i in range(m)]
        A = set(back)
        for b in back:
            A.add(-b)
        A.add(0)
        # add dense small block to increase |A|
        for x in range(-3, 4):
            A.add(x)
        try_candidate(list(A))

    # Mixed sum/difference tuned local search on top of a good structured seed.
    seed = best[:]
    cur = seed[:]
    cur_score = _score_set(cur)

    def full_score(a):
        a = list(set(a))
        if len(a) < 2:
            return 0.0
        if max(abs(x) for x in a) > 10**15:
            return -1e18
        d, s, n = _parts(a)
        if s <= 1 or d <= 1:
            return 0.0
        return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0

    # Perturbation loop around structured seed plus occasional geometric re-seeding.
    while time.time() < deadline:
        r = random.random()
        if r < 0.15:
            # reseed to geometric family with random exponent
            m = random.randint(2, 16)
            base = random.choice([2, 3, 4, 5])
            A = set()
            for i in range(m):
                v = base ** i
                A.add(v)
                A.add(-v)
            A.add(0)
            for _ in range(random.randint(0, 6)):
                A.add(random.randint(-4, 4))
            cur = list(A)
            cur_score = full_score(cur)
            continue

        cand = cur[:]
        op = random.random()
        if op < 0.5 and cand:
            # modify an element multiplicatively near a power of 2 structure
            i = random.randrange(len(cand))
            v = cand[i]
            cand[i] = v + random.randint(-3, 3)
        elif op < 0.8:
            # add a new element near current span edges
            m = max(abs(x) for x in cand) if cand else 1
            cand.append(random.choice([-1, 1]) * random.randint(0, max(1, m)))
        elif op < 0.95 and len(cand) > 4:
            # scale whole set
            f = random.choice([2, 3, -1, 1])
            cand = [x * f for x in cand]
            cand = list(set(cand))
        else and False:
            pass
        cand = list(set(cand))
        cs = full_score(cand)
        if cs >= cur_score:
            cur, cur_score = cand, cs
            if cs > bs:
                best, bs = cand[:], cs
        else:
            if random.random() < 0.05:
                cur, cur_score = best[:], bs

    out = sorted(set(best))
    if not out:
        out = [0, 1]
    # final polish: ensure constraints
    out = [x for x in out if abs(x) <= 10**15][:4000]
    return out
