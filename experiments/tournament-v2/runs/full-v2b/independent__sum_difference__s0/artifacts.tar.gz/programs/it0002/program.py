import math
import random
import time

def _score_stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0, n
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    sc = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
    return sc, ld, ls, n

def _score(a):
    return _score_stats(a)[0]

def solve():
    random.seed(12345)
    deadline = time.time() + 110

    # Build a large Sidon set greedily in [0, M). Sidon => |A-A| = n(n-1)+1 (max possible),
    # while |A+A| is still around ~n^2/2 but we want to minimize it.
    # Classic greedy Sidon set over integers.
    def build_sidon(limit_count, max_val):
        s = []
        used_diff = set()
        x = 0
        # use randomized greedy to get many elements quickly
        # maintain sums too to avoid duplicate sums (B_2 set: distinct sums)
        used_sum = set()
        s = [0]
        used_sum.add(0)
        current = 0
        while len(s) < limit_count and current < max_val:
            current += 1
            ok = True
            new_sums = []
            for y in s:
                sm = current + y
                if sm in used_sum:
                    ok = False
                    break
                new_sums.append(sm)
            if ok:
                s.append(current)
                for sm in new_sums:
                    used_sum.add(sm)
        return s

    # Try building several candidate sets and pick the best by score.
    best = None
    best_score = -1.0

    # Candidate 1: greedy Sidon set (B_2)
    sidon = build_sidon(2000, 60000)
    sc, ld, ls, n = _score_stats(sidon)
    if sc > best_score:
        best_score, best = sc, sidon[:]

    # Candidate 2: sidel' - use larger range to allow more elements
    sidon2 = build_sidon(1500, 200000)
    sc, ld, ls, n = _score_stats(sidon2)
    if sc > best_score:
        best_score, best = sc, sidon2[:]

    if best is None:
        best = [0, 1]

    # Local search: we want to increase |A-A| (near max already for Sidon) and decrease |A+A|.
    # Doing exact set ops is expensive; use incremental approximate scoring via sets.
    cur = best[:]
    cur_sc = _score(cur)

    def full_stats(a):
        return _score_stats(a)

    # time-limited local refinement: shift elements slightly to keep difference structure
    # but reduce collisions in sums. For Sidon sets sums are all distinct already, so
    # |A+A| = n(n+1)/2 exactly (all distinct). Then |A-A| = n(n-1)+1. That's optimal ratio!
    # Score = log(n(n-1)+1)/log(n(n+1)/2). This is maximized by making n as large as possible,
    # since ratio -> 2 as n -> inf. So we simply maximize n (count of Sidon set).

    # Strategy: build the largest possible Sidon set (B_2 set) within value bound <= 1e15.
    # Greedy Sidon sets have asymptotic density ~ sqrt(N). For N=1e15, ~3.16e7 elements -> too many
    # (cap 4000). So with cap 4000, we can use a small range and find exactly 4000-element Sidon sets.

    # Actually a Sidon set of size n needs max element at least ~ n^2/2. For n=4000, need ~8e6.
    # Easy. So aim for exactly 4000 elements.

    target_n = 4000

    # Build B_2 set (Sidon) greedily but efficiently using difference checking via set.
    # For speed, we build incrementally checking differences with all previous elements.
    def build_b2_fast(n_target, max_val):
        s = [0]
        diffs = {0}
        # We'll scan integers, checking if adding x keeps all pairwise differences distinct.
        # new diffs involving x: x - s[i] and s[i] - x. Need all new positive diffs distinct
        # from existing and each other.
        # For B_2 (distinct sums), condition: all x+s[i] distinct and not previously used.
        # Equivalent to Sidon. Use difference condition: x - y all distinct.
        used_pos_diff = set()  # absolute differences
        x = 0
        while len(s) < n_target and x < max_val:
            x += 1
            ok = True
            newd = []
            for y in s:
                d = x - y
                if d == 0 or d in used_pos_diff:
                    ok = False
                    break
                newd.append(d)
            if ok:
                s.append(x)
                for d in newd:
                    used_pos_diff.add(d)
        return s

    # This loop is O(n^2) per candidate -> too slow for n=4000 scanning. Use a faster
    # construction: known Sidon sets from quadratic residues / modular. Use the classic
    # construction: for prime p, {2*p*k + (k^2 mod p)} gives a Sidon set of size p.
    # We can pick p ~ 4000.

    def primes_upto(limit):
        sieve = bytearray([1]) * (limit + 1)
        sieve[0] = sieve[1] = 0
        i = 2
        while i * i <= limit:
            if sieve[i]:
                sieve[i*i::i] = bytearray(len(sieve[i*i::i]))
            i += 1
        return [i for i in range(limit + 1) if sieve[i]]

    primes = primes_upto(50000)

    def sidon_from_prime(p):
        # {2*p*k + (k*k) % p : k=0..p-1} is Sidon
        return [2 * p * k + (k * k) % p for k in range(p)]

    # Find largest prime p <= target_n
    p = max(q for q in primes if q <= target_n)
    cand = sidon_from_prime(p)
    sc, ld, ls, n = _score_stats(cand)
    if sc > best_score:
        best_score, best = sc, cand[:]

    # Try p = 4001 (next prime) if allowed size 4000 -> p must be <= 4000, use 3989 etc.
    # Also try slightly larger range constructions to get exactly 4000.
    # Take best prime near 4000.
    for q in primes:
        if 3000 <= q <= 4000:
            c = sidon_from_prime(q)
            s, _, _, nn = _score_stats(c)
            if nn <= 4000 and s > best_score:
                best_score, best = s, c[:]

    # Now we have a Sidon set with |A-A| maximal for its size and |A+A| = n(n+1)/2.
    # Add extra elements from another Sidon set to push n to 4000 while trying not to
    # create duplicate sums too badly. But B_2 property breaks. Instead, just use the
    # largest prime <= 4000, which gives n=3989. To get 4000, we can try a B_2 set
    # construction over a larger range via randomized greedy.

    # Random greedy B_2 with more elements:
    def build_b2_random(n_target, max_val, seed):
        rng = random.Random(seed)
        s = [0]
        used_sum = {0}
        cands = list(range(1, max_val))
        rng.shuffle(cands)
        for x in cands:
            if len(s) >= n_target:
                break
            ok = True
            newsums = []
            for y in s:
                sm = x + y
                if sm in used_sum:
                    ok = False
                    break
                newsums.append(sm)
            if ok:
                s.append(x)
                used_sum.update(newsums)
        return sorted(s)

    # Not needed if prime construction gives near-optimal. Try a couple of quick randomized
    # attempts with small max_val to fit in time.
    if best_score < 1.99:
        for seed in range(3):
            if time.time() > deadline - 30:
                break
            r = build_b2_random(4000, 5_000_000, seed)
            s, _, _, nn = _score_stats(r)
            if s > best_score:
                best_score, best = s, r[:]

    return sorted(set(best))
