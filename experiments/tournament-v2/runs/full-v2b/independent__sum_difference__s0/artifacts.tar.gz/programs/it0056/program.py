import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100

def _fast_score(a):
    """Fast approximate scoring used in local search."""
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            diffs.add(ai - a[j])
            diffs.add(a[j] - ai)
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100

def solve():
    # Build a large initial set with many differences and few sums.
    # Use mixed radix representation: numbers with digits in small ranges
    # create many distinct differences, while sums have limited carries.
    A = []
    # Base construction: powers of two scaled so sums stay compact
    # Use a Sidon-like set over {0,1,2,...,m-1} with powers 1, m, m^2...
    # Actually better: use numbers of form x + M*y where x in small set, y in small set.
    # Differences = (dx) + M*(dy), many distinct if M > max dx.
    # Sums = (sx) + M*(sy) with limited range, so few distinct.
    
    # Try several constructions and pick best.
    best = None
    best_score = -1.0
    
    # Construction 1: A = {a + b*M} for a in S, b in T
    cands = []
    
    # Small base sets
    for size in [20, 30, 40, 50]:
        S = list(range(size))
        T = list(range(size))
        M = size + 1  # ensures no overlap between dx + M*dy
        A1 = [a + b * M for a in S for b in T]
        cands.append(A1)
    
    # Construction 2: powers of 2
    for k in [6, 7, 8, 9, 10]:
        A2 = [2**i for i in range(k)]
        cands.append(A2)
    
    # Construction 3: {i + j*W} where W chosen optimally
    for n1, n2 in [(16, 16), (20, 20), (25, 25), (10, 20), (20, 10)]:
        M = n1 * 2 + 1
        A3 = [i + j * M for i in range(n1) for j in range(n2)]
        cands.append(A3)
    
    # Construction 4: Sidon-ish via distinct differences
    # A = {2^i} for i in range(k) gives all differences distinct but n only k
    # A = {i * 2^k + j} ...
    
    # Construction 5: scaled sum construction
    for scale in [1, 1000, 1000000]:
        for n in [10, 15, 20, 25, 30]:
            A5 = [scale * i + (i*i) % scale if scale > 1 else i for i in range(n)]
            cands.append(A5)
    
    # Evaluate all candidates
    for c in cands:
        c = list(set(c))
        if len(c) < 2:
            continue
        # trim to 4000
        if len(c) > 4000:
            c = c[:4000]
        sc = _fast_score(c)
        if sc > best_score:
            best_score = sc
            best = c[:]
    
    if best is None:
        best = list(range(100))
    
    # Local improvement: random perturbations
    deadline = time.time() + 100.0
    cur = best[:]
    cur_score = _fast_score(cur)
    
    while time.time() < deadline:
        cand = cur[:]
        n = len(cand)
        # random move: shift one element or add/remove
        r = random.random()
        if r < 0.4:
            i = random.randrange(n)
            cand[i] += random.randint(-10, 10)
        elif r < 0.6:
            cand.append(random.randint(-1000, 1000))
        elif r < 0.75 and n > 5:
            i = random.randrange(n)
            cand.pop(i)
        elif r < 0.9:
            # swap two elements
            i = random.randrange(n)
            j = random.randrange(n)
            cand[i], cand[j] = cand[j], cand[i]
        else:
            # shift all
            d = random.randint(-5, 5)
            cand = [x + d for x in cand]
        
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            cand = cand[:4000]
        
        sc = _fast_score(cand)
        if sc > cur_score or random.random() < 0.001:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = cand[:]
    
    # final polish with exact score on best
    # (optional, just return best)
    best = list(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return sorted(best)
