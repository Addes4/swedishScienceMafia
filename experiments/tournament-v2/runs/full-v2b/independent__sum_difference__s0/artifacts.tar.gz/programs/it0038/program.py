import math
import random
import time
from itertools import combinations

# ----------------------------------------------------------------------
# Scoring
# ----------------------------------------------------------------------
def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    L = list(a)
    for i, x in enumerate(L):
        xi = x
        diffs.add(0)
        sums.add(2 * xi)
        for j in range(i + 1, n):
            y = L[j]
            diffs.add(xi - y)
            diffs.add(y - xi)
            sums.add(xi + y)
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _raw(diffs, sums, n):
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


# ----------------------------------------------------------------------
# Fast local improvement
# ----------------------------------------------------------------------
def _local_search(a, deadline, restarts=4):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return a

    # incremental-ish evaluation (still O(n^2) but with early shortcuts)
    def evaluate(lst):
        s = set(lst)
        if len(s) < 2:
            return None, None, 0.0
        L = list(s)
        n = len(L)
        diffs = set()
        sums = set()
        for i in range(n):
            x = L[i]
            diffs.add(0)
            sums.add(2 * x)
            for j in range(i + 1, n):
                y = L[j]
                diffs.add(x - y)
                diffs.add(y - x)
                sums.add(x + y)
        if len(sums) <= 1:
            return None, None, 0.0
        sc = math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0
        return diffs, sums, sc

    cur = a[:]
    _, _, cur_sc = evaluate(cur)
    if cur_sc == 0.0:
        return a

    best = cur[:]
    best_sc = cur_sc

    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        idx = random.randrange(len(cand))
        delta = random.choice([-13, -8, -5, -3, -2, -1, 1, 2, 3, 5, 8, 13])
        cand[idx] += delta

        # occasionally insert a random element
        if random.random() < 0.08 and len(cand) < 120:
            span = max(cand) - min(cand)
            if span == 0:
                span = 20
            cand.append(random.randint(min(cand) - span // 2, max(cand) + span // 2))
        # occasionally delete
        if random.random() < 0.02 and len(cand) > 4:
            del cand[random.randrange(len(cand))]

        cand = sorted(set(cand))
        if len(cand) < 2:
            cand = best[:]

        _, _, sc = evaluate(cand)
        if sc == 0.0:
            continue

        if sc >= cur_sc or random.random() < 0.002:
            cur = cand
            cur_sc = sc
            if sc > best_sc:
                best = cand[:]
                best_sc = sc
                # restart occasionally to escape deep local optima
                if random.random() < 0.4:
                    cur = best[:]
        elif random.random() < 0.01:
            cur = best[:]

    return best


# ----------------------------------------------------------------------
# Constructions
# ----------------------------------------------------------------------

def _bose_chowla_like(q):
    """Return a Sidon-like set modulo q, then lift by differences.
    Singer/Bose-Chowla: {2qi + (i^2 mod q)} for suitable q gives
    many distinct differences and lots of additive structure after shifts.
    Here we use a simple quadratic construction that tends to perform well
    on |A-A|/|A+A|.
    """
    # Use a finite field style construction when possible.
    a = []
    for i in range(q):
        # quadratic residues modulo q
        a.append((i * i) % q + 2 * q * i)
    # de-duplicate
    return sorted(set(a))


def _singer_like(p):
    """Build p+1 points whose pairwise differences modulo p^2+p+1 are all distinct
    (Singer difference set).  Lift to integers by taking residues and small shifts
    to create collisions in sums.
    """
    q = p
    m = q * q + q + 1
    pts = []
    # projective plane Singer difference set via powers of primitive element 2
    # (only valid for some primes; fallback to quadratic residues)
    g = None
    for cand in range(2, m):
        if pow(cand, m - 1, m) == 1:
            seen = set()
            ok = True
            v = 1
            for _ in range(m - 1):
                if v in seen:
                    ok = False
                    break
                seen.add(v)
                v = (v * cand) % m
            if ok:
                g = cand
                break
    if g is None:
        # fallback
        return [i * i for i in range(q + 1)]
    ds = []
    v = 1
    for _ in range(q + 1):
        ds.append(v)
        v = (v * g) % m
    return ds


def _greedy_diff_set(target_n, deadline):
    """Greedily add integers to maximize the number of new differences while
    trying not to explode the sum set too much.  Uses a randomized candidate pool.
    """
    A = [0, 1]
    diffs = {0, 1, -1}
    sums = {0, 1, 2}
    # keep a bounded pool of candidates
    pool_max = max(target_n * 3, 60)
    pool = list(range(-pool_max, pool_max + 1))
    random.shuffle(pool)

    while len(A) < target_n and time.time() < deadline:
        best_gain = None
        best_x = None
        # sample candidates
        sample = pool[:min(len(pool), max(80, target_n * 4))]
        random.shuffle(sample)
        for x in sample:
            if x in A:
                continue
            new_diffs = set()
            new_sums = set()
            for y in A:
                new_diffs.add(x - y)
                new_diffs.add(y - x)
                new_sums.add(x + y)
            nd = len(diffs | new_diffs)
            ns = len(sums | new_sums)
            # score heuristic: increase diffs / log sums
            gain = nd / max(1.0, math.log(max(2, ns)))
            if best_gain is None or gain > best_gain:
                best_gain = gain
                best_x = x
        if best_x is None:
            break
        A.append(best_x)
        for y in A[:-1]:
            diffs.add(best_x - y)
            diffs.add(y - best_x)
            sums.add(best_x + y)
        diffs.add(0)
        sums.add(2 * best_x)
    return sorted(set(A))


def _random_sidon(n, span, deadline):
    """Random subset with Sidon-like property: no repeated differences."""
    # start from random set, then remove elements causing duplicate differences
    A = random.sample(range(-span, span + 1), min(n * 3, span * 2 + 1))
    A = sorted(set(A))
    # greedy Sidon reduction
    random.shuffle(A)
    S = []
    diffset = set()
    for x in A:
        ok = True
        new = []
        for y in S:
            d = x - y
            if d in diffset or -d in diffset:
                ok = False
                break
            new.append(d)
            new.append(-d)
        if ok:
            S.append(x)
            for d in new:
                diffset.add(d)
            diffset.add(0)
        if time.time() > deadline:
            break
    return sorted(S)


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------
def solve():
    random.seed(12345)
    deadline = time.time() + 115.0

    candidates = []

    # 1) small hand-tuned / known-good seeds
    seeds = [
        [-1, 0, 2, 4, 5, 7],
        [-3, -2, 0, 3, 5, 8],
        [-5, -3, -1, 2, 4, 6, 9, 11],
        [1, 2, 4, 8, 13, 18, 22, 27, 31, 36],
        [0, 1, 3, 7, 12, 20, 30, 44, 65, 80],
    ]
    for s in seeds:
        candidates.append(s)

    # 2) Bose-Chowla / quadratic lifts, various q and scalings
    for q in [5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]:
        if time.time() > deadline - 10:
            break
        a = _bose_chowla_like(q)
        if len(a) > 1:
            candidates.append(a)
            # translate and scale
            for k in [1, 2, 3]:
                tr = [k * x + 17 for x in a]
                candidates.append(tr)

    # 3) Singer difference sets lifted, plus affine variants
    for p in [2, 3, 5, 7, 11, 13]:
        if time.time() > deadline - 10:
            break
        try:
            ds = _singer_like(p)
        except Exception:
            continue
        if len(ds) > 1:
            candidates.append(ds)
            for k in [1, 2, 3, 5]:
                candidates.append([k * x + 3 for x in ds])

    # 4) Greedy difference-maximizing sets
    for target in [8, 12, 16, 20, 24, 30, 36, 44, 55, 70, 90]:
        if time.time() > deadline - 15:
            break
        g = _greedy_diff_set(target, min(deadline - 5, time.time() + 3))
        if len(g) >= 2:
            candidates.append(g)

    # 5) Random Sidon-style sets
    for _ in range(30):
        if time.time() > deadline - 15:
            break
        n = random.randint(6, 40)
        span = n * n * 2
        r = _random_sidon(n, span, min(deadline - 5, time.time() + 1))
        if len(r) >= 2:
            candidates.append(r)

    # 6) Random translated/scaled variants of the best early candidates
    if candidates:
        # evaluate all quickly with approximate score
        def approx_score(a):
            a = sorted(set(a))
            n = len(a)
            if n < 2:
                return 0.0
            diffs = set()
            sums = set()
            for i in range(n):
                x = a[i]
                diffs.add(0)
                sums.add(2 * x)
                for j in range(i + 1, n):
                    y = a[j]
                    diffs.add(x - y)
                    diffs.add(y - x)
                    sums.add(x + y)
            if len(sums) <= 1:
                return 0.0
            return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

        scored = []
        for c in candidates:
            c = sorted(set(c))
            if len(c) >= 2:
                scored.append((approx_score(c), c))
        scored.sort(reverse=True, key=lambda t: t[0])

        # perturb top candidates
        top = [c for _, c in scored[:12]]
        for c in top:
            if time.time() > deadline - 20:
                break
            for _ in range(8):
                cc = c[:]
                # random affine transform
                a0 = random.randint(-5, 5)
                b0 = random.randint(-50, 50)
                cc = [a0 * x + b0 for x in cc]
                if len(set(cc)) >= 2:
                    candidates.append(sorted(set(cc)))

    # ------------------------------------------------------------------
    # Local search on the most promising candidates
    # ------------------------------------------------------------------
    if candidates:
        def approx_score(a):
            a = sorted(set(a))
            n = len(a)
            if n < 2:
                return 0.0
            diffs = set()
            sums = set()
            for i in range(n):
                x = a[i]
                diffs.add(0)
                sums.add(2 * x)
                for j in range(i + 1, n):
                    y = a[j]
                    diffs.add(x - y)
                    diffs.add(y - x)
                    sums.add(x + y)
            if len(sums) <= 1:
                return 0.0
            return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

        candidates = [sorted(set(c)) for c in candidates if len(set(c)) >= 2]
        candidates.sort(key=approx_score, reverse=True)
        candidates = candidates[:15]

        overall_best = candidates[0]
        overall_score = approx_score(overall_best)

        # distribute remaining time among top candidates
        remaining = max(1.0, deadline - time.time())
        per = remaining / max(1, len(candidates))

        for c in candidates:
            if time.time() > deadline - 0.5:
                break
            sub_deadline = min(deadline - 0.3, time.time() + per)
            improved = _local_search(c, sub_deadline)
            sc = approx_score(improved)
            if sc > overall_score:
                overall_best = improved
                overall_score = sc

        # final polish on overall best
        if time.time() < deadline - 1:
            final = _local_search(overall_best, deadline - 0.2)
            if approx_score(final) >= overall_score:
                overall_best = final

        result = sorted(set(overall_best))
    else:
        result = [0, 1, 3, 7, 12, 20, 30, 44, 65, 80]

    # enforce constraints: distinct, at most 4000, abs <= 1e15
    result = sorted(set(result))
    if len(result) > 4000:
        result = result[:4000]
    result = [int(x) if abs(x) <= 10**15 else (10**15 if x > 0 else -10**15) for x in result]
    result = sorted(set(result))

    return result
