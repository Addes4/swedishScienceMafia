import math
import random
import time

def _stats(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    # use sets; values are small enough here
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)

def _score(a):
    return _stats(a)[0]

def _dedup(a):
    return sorted(set(int(x) for x in a))

def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1.0
    best_d = 0
    best_s = 0

    def consider(a):
        nonlocal best, best_score, best_d, best_s
        a = _dedup(a)
        if len(a) < 2:
            return
        sc, d, s = _stats(a)
        if sc > best_score:
            best_score = sc
            best = a[:]
            best_d = d
            best_s = s

    # Deterministic seed constructions based on two clusters.
    # A = {base + i : i in L} union {base + C + j : j in R}
    # Cross differences are base-shifted R-L, cross sums are near constant.
    def two_cluster(L, R, gap):
        L = sorted(set(L))
        R = sorted(set(R))
        A = []
        for x in L:
            A.append(x)
        for y in R:
            A.append(gap + y)
        return A

    seeds = []

    # Sidon-ish low elements and dense high elements in two clusters
    # Cluster 1: few values spread to create many distinct L-L / L-R differences.
    for m1 in range(3, 12):
        for m2 in range(3, 14):
            for gap in (31, 40, 50, 64, 75, 90, 100, 128, 150, 200, 256):
                # low cluster: quadratic-ish spread
                L = [i * i for i in range(m1)]
                # high cluster: arithmetic progression (small sum set)
                R = list(range(m2))
                A = two_cluster(L, R, gap)
                seeds.append(A)

    for A in seeds:
        consider(A)

    # Local search / greedy growth from best two-cluster seeds.
    random.seed(12345)

    def neighborhood(cand):
        n = len(cand)
        res = []
        # tweak a value
        for i in range(n):
            for d in (-3, -2, -1, 1, 2, 3):
                b = cand[:]
                b[i] += d
                res.append(b)
        # add a value near an existing one
        for _ in range(6):
            b = cand[:]
            if b:
                base = random.choice(b)
                b.append(base + random.randint(-8, 8))
            res.append(b)
        # remove a value
        for i in range(n):
            if n > 4:
                b = cand[:]
                del b[i]
                res.append(b)
        return res

    cur = best[:]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        improved = False
        # greedy best improvement among random samples of neighborhood
        for b in random.sample(neighborhood(cur), min(60, max(1, len(neighborhood(cur))))):
            b = _dedup(b)
            if len(b) < 2:
                continue
            s = _score(b)
            if s > cur_score:
                cur = b
                cur_score = s
                improved = True
                consider(b)
                break
        if not improved:
            # perturb or restart from a seed
            if random.random() < 0.3 and best is not None:
                cur = best[:]
                cur_score = best_score
            else:
                cur = _dedup([x + random.randint(-5, 5) for x in cur])
                cur_score = _score(cur) if len(cur) >= 2 else 0.0
                consider(cur)

    # Try a direct greedy extension from best: add integers one at a time
    while time.time() < deadline * 0.98 and best is not None and len(best) < 4000:
        base = best[:]
        found = False
        # candidate new elements: near existing values and in gaps
        cands = set()
        for x in base:
            for d in range(-5, 6):
                if d:
                    cands.add(x + d)
        for _ in range(200):
            cands.add(random.randint(min(base) - 20, max(base) + 20))
        cands = [c for c in cands if c not in set(base)]
        random.shuffle(cands)
        best_local_score = best_score
        best_add = None
        for c in cands[:300]:
            s = _score(base + [c])
            if s > best_local_score:
                best_local_score = s
                best_add = c
                break
        if best_add is not None:
            consider(base + [best_add])
        else:
            break

    return best if best is not None else [0, 1]
