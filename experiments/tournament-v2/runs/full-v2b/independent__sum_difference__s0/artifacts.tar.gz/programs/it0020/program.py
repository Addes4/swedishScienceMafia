import math
import random
import time
from collections import defaultdict


def _exact_score(a):
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / len(a)) / 100.0


def _greedy_grow(seed, target_size, rng, deadline):
    """Incrementally add one element at a time, trying many candidates and keeping
    the exact-score-best addition. Uses incremental dicts for speed."""
    A = sorted(set(seed))
    diff_cnt = defaultdict(int)
    sum_cnt = defaultdict(int)

    for x in A:
        for y in A:
            diff_cnt[x - y] += 1
            sum_cnt[x + y] += 1

    def base_obj(nd, ns, n):
        if ns <= 1:
            return -1e100
        return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0

    cur_score = base_obj(len(diff_cnt), len(sum_cnt), len(A))

    # candidate pool around the current set
    while len(A) < target_size and time.time() < deadline:
        pool = set()
        # nearby perturbed values
        span = max(50, 20 * len(A))
        for _ in range(min(500, 5 + len(A))):
            pool.add(rng.randint(-span, span))
        # differences/sums derived values often help make sums collide but diffs not
        for _ in range(200):
            x = rng.choice(A)
            y = rng.choice(A)
            pool.add(x - y)
            pool.add(x + y)
            pool.add(x + rng.randint(-10, 10))
        if rng.random() < 0.3:
            pool.add(rng.randint(-10**6, 10**6))

        best_cand = None
        best_cand_score = cur_score
        best_cand_dicts = None

        # evaluate a subset of candidates exactly and incrementally
        cands = list(pool)
        rng.shuffle(cands)

        for cand in cands:
            if cand in A:
                continue
            if time.time() > deadline:
                break

            # temporarily add cand
            added_diff = 0
            added_sum = 0
            for x in A:
                d1 = cand - x
                d2 = x - cand
                s = cand + x

                if diff_cnt[d1] == 0:
                    added_diff += 1
                if diff_cnt[d2] == 0:
                    added_diff += 1
                # self d=0, s=2cand handled below
                if sum_cnt[s] == 0:
                    added_sum += 1

            if diff_cnt[0] == 0:
                added_diff += 1  # cand - cand = 0
            if sum_cnt[2 * cand] == 0:
                added_sum += 1

            nd = len(diff_cnt) + added_diff
            ns = len(sum_cnt) + added_sum
            sc = base_obj(nd, ns, len(A) + 1)

            if sc > best_cand_score:
                best_cand_score = sc
                best_cand = cand

        if best_cand is None:
            # force a random candidate to keep progressing
            span = max(100, 50 * len(A))
            tries = 0
            while tries < 10000:
                cand = rng.randint(-span, span)
                if cand not in A:
                    break
                tries += 1
            else:
                cand = max(A) + 1
            best_cand = cand

        cand = best_cand
        # update dicts and score
        for x in A:
            diff_cnt[cand - x] += 1
            diff_cnt[x - cand] += 1
            sum_cnt[cand + x] += 1
        diff_cnt[0] += 1
        sum_cnt[2 * cand] += 1

        A.append(cand)
        cur_score = base_obj(len(diff_cnt), len(sum_cnt), len(A))

    return A


def _sample_initial(rng):
    """Try several structured/random seeds and pick the best exact score."""
    seeds = []

    # small hand seeds that tend to have decent ratios
    base_options = [
        [0, 1, 3, 7, 12],
        [1, 2, 5, 10, 17],
        [0, 1, 4, 10, 18],
        [1, 3, 7, 12, 20],
        [0, 2, 6, 13, 23],
    ]
    seeds.extend(base_options)

    # random small
    for _ in range(40):
        k = rng.randint(4, 9)
        s = set()
        while len(s) < k:
            s.add(rng.randint(-30, 30))
        seeds.append(list(s))

    # additive structured: powers-ish and combinations
    for t in range(20):
        s = set()
        for i in range(rng.randint(4, 8)):
            s.add(rng.randint(-5, 5) * rng.choice([1, 2, 3, 4, 5, 6, 8, 10, 12]))
        if len(s) >= 3:
            seeds.append(list(s))

    best = None
    best_sc = -1.0
    for s in seeds:
        sc = _exact_score(s)
        if sc > best_sc:
            best_sc = sc
            best = s
    return best


def solve():
    rng = random.Random(123456789)
    deadline = time.time() + 110.0

    best_A = None
    best_score = -1.0

    # Try a few independent starting configurations.
    num_restarts = 6
    for r in range(num_restarts):
        if time.time() >= deadline:
            break

        seed = _sample_initial(rng)
        target = 1200 + r * 200
        A = _greedy_grow(seed, target, rng, min(deadline, time.time() + 15.0))

        if A:
            sc = _exact_score(A)
            if sc > best_score:
                best_score = sc
                best_A = A[:]

    if best_A is None:
        best_A = [0, 1, 3, 7, 12]

    # Local refinement / pruning pass: try removing elements that hurt.
    A = sorted(set(best_A))
    improved = True
    while improved and time.time() < deadline:
        improved = False
        cur = _exact_score(A)
        order = list(range(len(A)))
        rng.shuffle(order)
        for idx in order:
            if time.time() >= deadline:
                break
            if len(A) <= 4:
                break
            cand = A[:idx] + A[idx + 1:]
            sc = _exact_score(cand)
            if sc > cur + 1e-15:
                A = cand
                cur = sc
                improved = True
                break

    # Try small random perturbations to escape local optima.
    end = time.time() + 2.0
    while time.time() < end:
        if len(A) < 2:
            break
        cand = A[:]
        i = rng.randrange(len(cand))
        cand[i] += rng.randint(-5, 5)
        if len(set(cand)) != len(cand):
            continue
        sc = _exact_score(cand)
        if sc > _exact_score(A):
            A = cand

    return sorted(set(int(x) for x in A if abs(x) <= 10**15))
