import math
import random
import time

# ------------------------- utilities -------------------------

def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 1, 1, 0.0
    diffs = {x - y for x in a for y in a}
    sums  = {x + y for x in a for y in a}
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0
    return len(diffs), len(sums), score


def _score(a):
    return _stats(a)[2]


# ------------------------- constructions -------------------------

def _golomb_power(n, base=2):
    """Sidon/Golomb-like set: powers of base give mostly distinct differences."""
    a = []
    v = 1
    for _ in range(n):
        a.append(v)
        v = v * base + 1
    return a


def _golomb_from_poly(n):
    """Use values m^2 + something to break multiplicative collisions."""
    a = []
    for i in range(n):
        a.append(i * i * (i + 7) + i)
    return a


def _random_sidon(n, span):
    """Random Sidon-ish set by rejection within [0, span)."""
    chosen = []
    seen_diffs = set()
    attempts = 0
    while len(chosen) < n and attempts < 200000:
        attempts += 1
        c = random.randrange(span)
        ok = True
        for x in chosen:
            d = c - x
            if d in seen_diffs or -d in seen_diffs:
                ok = False
                break
        if ok:
            for x in chosen:
                d = c - x
                seen_diffs.add(d)
                seen_diffs.add(-d)
            chosen.append(c)
    return chosen


def _paired_construction(n):
    """Mix small sums by using an arithmetic block plus a few large elements
    that contribute mostly to differences."""
    if n < 4:
        return list(range(n))
    k = max(2, n // 2)
    small = [i for i in range(k)]
    big_count = n - k
    big = []
    v = k * k + 1
    for i in range(big_count):
        big.append(v + i * (k * k + 3))
        v = v * 3 + 5
    return small + big


# ------------------------- local search -------------------------

def _greedy_improve(a, deadline):
    a = list(set(a))
    n = len(a)
    best = a[:]
    best_score = _score(best)

    while time.time() < deadline:
        cand = best[:]
        op = random.random()
        if op < 0.60:
            # perturb an element
            i = random.randrange(len(cand))
            scale = max(1, abs(cand[i]) // 8 + 1)
            cand[i] += random.randint(-scale, scale)
        elif op < 0.80:
            # shift by a global offset (doesn't change score, but helps escape)
            off = random.randint(-5, 5)
            cand = [x + off for x in cand]
        elif op < 0.95:
            # add an element near an existing one
            i = random.randrange(len(cand))
            base = cand[i]
            cand.append(base + random.randint(-50, 50))
        else:
            # remove an element
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= best_score:
            best_score = s
            best = cand
        elif random.random() < 0.03:
            # accept slightly worse to diversify
            best = cand[:]
            best_score = s
    return best


# ------------------------- main solver -------------------------

def solve():
    deadline = time.time() + 115.0

    candidates = []

    # Several deterministic constructions
    for n in (60, 120, 200, 300, 500):
        candidates.append(_golomb_power(n, 2))
    for n in (100, 200, 400):
        candidates.append(_golomb_from_poly(n))
    for n in (50, 100, 200, 300):
        candidates.append(_paired_construction(n))

    # Random Sidon-ish candidates
    random.seed(12345)
    for _ in range(15):
        n = random.choice([60, 100, 150, 200, 250, 300])
        span = max(4000, n * n * 2)
        candidates.append(_random_sidon(n, span))

    # Quick scoring with trimming to improve log ratio
    best = None
    best_score = -1.0
    for c in candidates:
        c = sorted(set(c))
        if len(c) < 2:
            continue
        s = _score(c)
        if s > best_score:
            best_score = s
            best = c[:]
        # trim: shorter sets often improve ratio
        for cut in (0.9, 0.8, 0.7, 0.6, 0.5):
            m = max(2, int(len(c) * cut))
            sub = c[:m]
            ss = _score(sub)
            if ss > best_score:
                best_score = ss
                best = sub[:]

    if best is None:
        best = [0, 1, 3, 7, 12, 20, 30]
        best_score = _score(best)

    # Local search from the best found
    remaining = deadline - time.time()
    if remaining > 0:
        improved = _greedy_improve(best, deadline)
        si = _score(improved)
        if si > best_score:
            best = improved
            best_score = si

    # Ensure distinct integers and bounds
    best = sorted(set(int(x) for x in best))
    # Clip absolute value (should already be small)
    best = [max(-10**15, min(10**15, x)) for x in best]
    if len(best) > 4000:
        best = best[:4000]
    if len(best) < 2:
        best = [0, 1]
    return best


if __name__ == "__main__":
    a = solve()
    print("n =", len(a))
    print("score =", _score(a))
    print("diffs/sums =", _stats(a)[:2])
