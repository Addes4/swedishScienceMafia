import math
import random
import time

def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def solve():
    random.seed(12345)
    # Try several structured seeds
    seeds = []
    # arithmetic progression
    seeds.append([i for i in range(1, 30)])
    # geometric-ish
    g = [1]
    for i in range(25):
        g.append(g[-1] + random.randint(1, 3))
    seeds.append(g)
    # random small set
    seeds.append(random.sample(range(-50, 50), 20))
    # try a known good small example
    seeds.append([7, 15, 18, 22, -3, -2])
    
    best = None
    best_score = -1
    deadline = time.time() + 100
    
    for seed in seeds:
        cur = list(set(seed))
        s = _score(cur)
        if s > best_score:
            best_score = s
            best = cur[:]
    
    # local search: try modifying elements and adding/removing
    cur = best[:]
    cur_score = best_score
    
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.7 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif op < 0.85:
            cand.append(random.randint(-100, 100))
        elif len(cand) > 3:
            i = random.randrange(len(cand))
            del cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc > cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = cand[:]
        elif random.random() < 0.01:
            cur = cand
            cur_score = sc
    
    # final polish: try to grow set while keeping ratio
    cur = best[:]
    cur_score = best_score
    for _ in range(200):
        if time.time() > deadline:
            break
        cand = cur + [random.randint(-200, 200)]
        cand = list(set(cand))
        sc = _score(cand)
        if sc >= cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = cand[:]
    
    return sorted(set(best))
