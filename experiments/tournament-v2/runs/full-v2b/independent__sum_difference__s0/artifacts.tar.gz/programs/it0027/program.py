import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _score_fast(a):
    # a is a list of distinct ints; compute score using sets
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _golomb_like(n):
    """Build a Sidon (B_2) set using a simple greedy / quadratic construction."""
    # Use the standard construction: for a prime p, {2pk + (k^2 mod p)} is a Sidon set
    # This gives near-perfect difference sets.
    p = 2
    while True:
        # find prime p such that we can get >= n elements
        # classical construction gives p elements
        is_prime = True
        for d in range(2, int(p ** 0.5) + 1):
            if p % d == 0:
                is_prime = False
                break
        if is_prime and p >= n:
            break
        p += 1
    # Use construction giving ~p elements; we take first n
    S = []
    # Erdos-Turan / Singer-like: 2pk + (k^2 mod p)
    for k in range(p):
        S.append(2 * p * k + (k * k) % p)
    S = sorted(set(S))
    # To get exactly n, pick a subset smartly: choose the one with best score among
    # several offsets; but simpler: take all and then trim later in search.
    return S


def _perfect_diff_set(n):
    """Try to construct a Singer difference set giving ~n elements with |A-A| ~ n^2."""
    # For a projective plane of order q, a perfect difference set has q+1 elements
    # with all q^2+q+1 nonzero differences. We approximate for arbitrary n.
    # Find q such that q+1 ~ n
    q = max(2, int(round(n - 1)))
    while True:
        # q+1 elements if q is a prime power
        # test if q is prime power
        def is_prime_power(x):
            if x < 2:
                return False
            for b in range(2, int(x ** 0.5) + 2):
                v = x
                while v % b == 0:
                    v //= b
                if v == 1:
                    return True, b
            return (True, x) if x >= 2 else (False, 0)
        ok, b = is_prime_power(q)
        if ok:
            break
        q += 1
    return q


def _singer_set(q):
    """Construct a Singer difference set in Z_{q^2+q+1} of size q+1 using a
    primitive polynomial / brute log approach."""
    mod = q * q + q + 1
    # Find a primitive element of GF(q^2+q+1) i.e. multiplicative group of GF(q^3)? 
    # Simpler brute force: find a difference set directly by search is too slow.
    # Instead use a known algebraic construction won't be reliable here.
    return None


def _greedy_sidon(n, maxval=None):
    """Greedy construction of a Sidon set (B_2 set): each new element added so that
    all pairwise sums are distinct. Difference set will then be large."""
    A = [0]
    used_sums = {0}
    # We want sums distinct -> |A+A| = n(n+1)/2 minimal, and diffs large.
    # Greedy: maintain set of sums; add smallest x>max(A) such that no collision.
    sums = {0}
    candidate = 1
    while len(A) < n:
        ok = True
        new_sums = set()
        for a in A:
            s = a + candidate
            if s in sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            A.append(candidate)
            sums.add(candidate + candidate)
            for s in new_sums:
                sums.add(s)
        candidate += 1
        if candidate > (maxval if maxval else 10 ** 12):
            break
    return A


def _singer_construction(n):
    """Build a large Sidon-like set via the classical construction:
    For prime p, A = {2*p*k + (k*k mod p) : k=0..p-1} is a Sidon set."""
    # find prime p >= some size; we want len ~ n
    def primes_up_to(limit):
        sieve = bytearray([1]) * (limit + 1)
        sieve[0] = sieve[1] = 0
        for i in range(2, int(limit ** 0.5) + 1):
            if sieve[i]:
                sieve[i * i::i] = b'\x00' * len(sieve[i * i::i])
        return [i for i in range(limit + 1) if sieve[i]]

    # we need p elements; choose p smallest prime >= n
    limit = max(10, n * 2 + 10)
    ps = primes_up_to(limit)
    p = None
    for pr in ps:
        if pr >= n:
            p = pr
            break
    if p is None:
        p = ps[-1]
    A = [2 * p * k + (k * k) % p for k in range(p)]
    return sorted(set(A))


def _local_search(A, deadline, seed_set=None):
    A = sorted(set(A))
    best = A[:]
    best_score = _score_fast(best)
    cur = best[:]
    cur_score = best_score
    rng = random.Random(12345)
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        op = rng.random()
        if op < 0.5:
            # perturb an element
            i = rng.randrange(len(cand))
            delta = rng.randint(-50, 50)
            cand[i] += delta
            if cand[i] in cand[:i] + cand[i + 1:]:
                continue
        elif op < 0.8 and len(cand) < 2000:
            # add element near range
            base = rng.choice(cand)
            cand.append(base + rng.randint(-100, 100))
            if len(set(cand)) != len(cand):
                continue
        else:
            if len(cand) > 4:
                i = rng.randrange(len(cand))
                cand.pop(i)
            else:
                continue
        cs = _score_fast(cand)
        if cs >= cur_score or rng.random() < 0.02:
            cur = cand
            cur_score = cs
            if cs > best_score:
                best = cand[:]
                best_score = cs
        if it % 500 == 0 and rng.random() < 0.3:
            cur = best[:]
            cur_score = best_score
    return best


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    deadline_all = time.time() + 110
    best = None
    best_score = -1.0

    # Strategy 1: Singer / Sidon sets from quadratic construction with various sizes
    for n in [200, 500, 900, 1200, 1600, 2000]:
        if time.time() > deadline_all - 20:
            break
        try:
            A = _singer_construction(n)
        except Exception:
            A = _greedy_sidon(min(n, 300))
        sc = _score_fast(A)
        if sc > best_score:
            best = A[:]
            best_score = sc

    # Strategy 2: greedy Sidon sets of moderate size
    for n in [100, 200, 300, 400]:
        if time.time() > deadline_all - 20:
            break
        try:
            A = _greedy_sidon(n, maxval=10 ** 9)
        except Exception:
            continue
        sc = _score_fast(A)
        if sc > best_score:
            best = A[:]
            best_score = sc

    if best is None:
        best = _singer_construction(500)
        best_score = _score_fast(best)

    # Refine with local search in remaining time
    remaining = deadline_all - time.time()
    if remaining > 5:
        refined = _local_search(best, time.time() + remaining)
        sc = _score_fast(refined)
        if sc > best_score:
            best = refined
            best_score = sc

    best = sorted(set(int(x) for x in best))
    # enforce constraints
    if len(best) > 4000:
        best = best[:4000]
    best = [x for x in best if abs(x) <= 10 ** 15]
    return best
