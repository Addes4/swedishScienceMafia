import math
import random
import time
from itertools import combinations


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    # use bitsets for speed when values are small-ish; fallback to set
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    # For large values bitsets impossible; use Python sets
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for j in range(n):
            y = a[j]
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build_digit_construction(B, num_digits, count):
    """Build a set of numbers in base B with digits from {0,1} or sparse,
    designed so differences are rich and sums collide."""
    # Use numbers whose digit representations are all 0/1 vectors, plus multiples of B^k
    # Actually: choose numbers of the form sum d_i B^i where d_i in {0..B-1}
    # To make sums small, use numbers with digits in a small set so sums overflow predictably.
    # Simple approach: pick random digit vectors with digits in {0,1}
    nums = set()
    tries = 0
    while len(nums) < count and tries < count * 200:
        tries += 1
        v = 0
        for k in range(num_digits):
            if random.random() < 0.5:
                v += B ** k
        if v not in nums:
            nums.add(v)
    return list(nums)


def _local_search(seed, time_limit):
    best = list(set(seed))
    if len(best) < 2:
        best = [1, 2]
    best_score = _score_fast(best)
    cur = best[:]
    deadline = time.time() + time_limit
    
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.4:
            # perturb an element
            i = random.randrange(len(cand))
            step = random.choice([1, 2, 3, 1, -1, -2, -3, 5, -5])
            cand[i] += step
            if abs(cand[i]) > 10**15:
                continue
        elif op < 0.65:
            # add an element
            if len(cand) < 4000:
                base = random.choice(cand) if cand else 0
                cand.append(base + random.randint(-10, 10))
        elif op < 0.8 and len(cand) > 3:
            # remove an element
            idx = random.randrange(len(cand))
            cand.pop(idx)
        else:
            # random restart-ish: replace one element with a fresh one
            i = random.randrange(len(cand))
            cand[i] = random.randint(-100, 100)
        
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue
        s = _score_fast(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]
    return best, best_score


def solve():
    deadline = time.time() + 110
    
    # Try several base-B digit constructions and refine
    best = None
    best_score = -1.0
    
    candidates = []
    
    # Small explicit constructions
    candidates.append([1, 2, 4, 8, 16])
    candidates.append([7, 15, 18, 22, -3, -2])
    candidates.append([0, 1, 3, 7, 15, 31, 63])
    
    # Base-B binary-like constructions
    for B in [2, 3, 4, 5, 6, 7, 8, 10, 12]:
        for nd in [4, 5, 6, 7, 8]:
            for cnt in [5, 8, 12, 16, 20]:
                nums = _build_digit_construction(B, nd, cnt)
                if len(nums) >= 3:
                    candidates.append(nums)
    
    # Geometric-ish sequences
    for r in [2, 3, 4, 5]:
        seq = []
        v = 1
        for _ in range(10):
            seq.append(v)
            v = v * r + 1
        candidates.append(seq)
    
    # Sidon-like sets: greedy choose to maximize differences relative to sums
    for size in [6, 8, 10, 12, 15, 20]:
        S = set()
        cand = 1
        while len(S) < size and cand < 10**6:
            ok = True
            # ensure no duplicate sums too often: just greedy
            S.add(cand)
            cand += 1
        candidates.append(list(S))
    
    # Random small sets
    for _ in range(20):
        n = random.randint(4, 15)
        candidates.append([random.randint(-50, 50) for _ in range(n)])
    
    for c in candidates:
        c = list(set(c))[:4000]
        if len(c) < 2:
            continue
        s = _score_fast(c)
        if s > best_score:
            best_score = s
            best = c[:]
    
    # Local search refinement from best candidates
    pool = []
    for c in candidates:
        c = list(set(c))[:4000]
        if len(c) >= 2:
            s = _score_fast(c)
            pool.append((s, c))
    pool.sort(key=lambda t: -t[0])
    
    time_left = deadline - time.time()
    if time_left > 5:
        # refine top candidates
        top = pool[:min(10, len(pool))]
        per = time_left / max(1, len(top))
        for s0, c0 in top:
            if time.time() > deadline:
                break
            tlim = min(per, deadline - time.time())
            if tlim <= 0:
                break
            b, bs = _local_search(c0, tlim)
            if bs > best_score:
                best_score = bs
                best = b[:]
    
    # final intensive local search on best
    time_left = deadline - time.time()
    if time_left > 1 and best is not None:
        b, bs = _local_search(best, time_left)
        if bs > best_score:
            best = b[:]
    
    if best is None:
        best = [1, 2, 4]
    
    return sorted(set(best))[:4000]
