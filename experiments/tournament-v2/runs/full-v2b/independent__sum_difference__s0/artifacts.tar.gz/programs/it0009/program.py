import math
import random
import time

def _score_parts(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        xi = a[i]
        for j in range(i, n):
            xj = a[j]
            diffs.add(xi - xj)
            diffs.add(xj - xi)
            sums.add(xi + xj)
    d = len(diffs)
    s = len(sums)
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0, d, s

def _score(a):
    return _score_parts(a)[0]

def solve():
    random.seed(12345)
    best = None
    best_score = -1.0

    # Candidate 1: dense interval plus multiplicative Sidon-like tail.
    # Small dense interval gives small sum set; tail gives many differences.
    for L in (80, 120, 160, 220, 300):
        for M in (10**6, 10**7, 10**8, 10**9, 10**10, 10**11, 10**12, 10**13, 10**14):
            k = 32
            base = list(range(-L // 2, L // 2 + 1))
            tail = []
            # Sidon-like: powers of 2 scaled, plus shifted copies
            for t in range(k):
                tail.append((1 << min(t, 50)) * M + t * 7)
            cand = base + tail
            sc, d, s = _score_parts(cand)
            if sc > best_score:
                best_score = sc
                best = cand[:]

    # Candidate 2: near-arithmetic progression with perturbed sparse offsets.
    for L in (60, 100, 140, 200, 280):
        base = list(range(L))
        for scale in (10**6, 10**9, 10**12):
            for num_extra in (20, 30, 40):
                extra = []
                for i in range(num_extra):
                    extra.append(scale * (1 << i if i < 50 else i * i) + random.randint(-5, 5))
                cand = base + extra
                sc, d, s = _score_parts(cand)
                if sc > best_score:
                    best_score = sc
                    best = cand[:]

    # Candidate 3: many copies of a small set scaled by powers of a large base.
    small = [0, 1, 3, 7, 12, 20]
    for B in (10**3, 10**5, 10**7, 10**9, 10**11):
        cand = []
        p = 1
        for _ in range(24):
            for v in small:
                cand.append(p * v)
            p *= B
        sc, d, s = _score_parts(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # Local search refinement
    deadline = time.time() + 105
    cur = best[:]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.45 and cand:
            i = random.randrange(len(cand))
            # small additive perturbation
            delta = random.choice([-2, -1, 1, 2, 3, -3, 5, -5, 10, -10])
            cand[i] += delta
        elif op < 0.65 and cand:
            # multiply one element by small factor-ish adjustment
            i = random.randrange(len(cand))
            cand[i] = cand[i] * 2 + random.randint(-3, 3)
        elif op < 0.85 and len(cand) < 120:
            # add a new element near an existing one or random sparse point
            if random.random() < 0.7 and cand:
                x = random.choice(cand)
                cand.append(x + random.randint(-20, 20))
            else:
                cand.append(random.randint(-10**9, 10**9))
        elif len(cand) > 8:
            # remove one
            i = random.randrange(len(cand))
            del cand[i]

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            cand = cand[:4000]

        sc, d, s = _score_parts(cand)
        if sc > cur_score:
            cur_score = sc
            cur = cand[:]
            if sc > best_score:
                best_score = sc
                best = cand[:]
                # occasionally do a burst around new best
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    # Final polishing: try removing redundant elements that do not hurt much
    improved = True
    while improved and time.time() < deadline:
        improved = False
        a = sorted(set(best))
        base_d = None
        for i in range(len(a)):
            cand = a[:i] + a[i+1:]
            if len(cand) < 2:
                continue
            sc, d, s = _score_parts(cand)
            if sc > best_score:
                best_score = sc
                best = cand[:]
                improved = True
                break

    return sorted(set(int(x) for x in best))
