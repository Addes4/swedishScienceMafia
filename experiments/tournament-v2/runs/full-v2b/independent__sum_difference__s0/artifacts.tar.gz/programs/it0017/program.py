import math
import random
import time

def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    L = list(a)
    diffs = set()
    sums = set()
    for i in range(n):
        xi = L[i]
        for j in range(n):
            diffs.add(xi - L[j])
            sums.add(xi + L[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0

def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        xi = a[i]
        for j in range(i, n):
            xj = a[j]
            diffs.add(xi - xj)
            diffs.add(xj - xi)
            sums.add(xi + xj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0

def _bose_set(n, q):
    # Bose-Chowla construction: A = {2*q*k + (k^2 mod q) : k=0..q-1}
    # gives Sidon-like properties. Subset of size n.
    A = []
    for k in range(q):
        A.append(2 * q * k + (k * k) % q)
    if n <= q:
        return A[:n]
    # need more than q elements; extend by larger modulus
    return A

def _greedy_sidon(target_n, max_val, deadline):
    # Greedy construction of set with large difference set
    A = [0]
    used_diffs = {0}
    used_sums = {0}
    # candidates: prefer values that maximize new diffs
    pool = list(range(-max_val, max_val + 1))
    pool.remove(0)
    random.shuffle(pool)
    while len(A) < target_n and time.time() < deadline:
        best_x = None
        best_gain = -1
        sample = pool[:min(len(pool), 200)]
        for x in sample:
            new_d = set()
            for a in A:
                new_d.add(x - a)
                new_d.add(a - x)
            gain = len(new_d - used_diffs)
            # penalize new sums
            new_s = set()
            for a in A:
                new_s.add(x + a)
            new_s.add(x + x)
            spenalty = len(new_s - used_sums)
            score_gain = gain - 0.5 * spenalty
            if score_gain > best_gain:
                best_gain = score_gain
                best_x = x
        if best_x is None:
            break
        A.append(best_x)
        for a in A[:-1]:
            used_diffs.add(best_x - a)
            used_diffs.add(a - best_x)
            used_sums.add(best_x + a)
        used_sums.add(2 * best_x)
        pool.remove(best_x)
    return A

def _local_search(A, deadline, time_budget):
    best = list(set(A))
    bs = _score_fast(best)
    cur = best[:]
    cs = bs
    n_cur = len(cur)
    end = min(deadline, time.time() + time_budget)
    while time.time() < end:
        cand = cur[:]
        r = random.random()
        if r < 0.6:
            # perturb
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif r < 0.85:
            # add element
            if len(cand) < 4000:
                cand.append(random.randint(-100, 100) * random.randint(1, 10))
        else:
            # remove element
            if len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score_fast(cand)
        if s > cs:
            cur, cs = cand, s
            if s > bs:
                best, bs = cand[:], s
        elif random.random() < 0.02:
            cur, cs = best[:], bs
    return best, bs

def solve():
    deadline = time.time() + 115
    best = None
    best_score = -1

    # Strategy 1: Bose sets for various sizes
    for q in [16, 24, 31, 40, 50, 64, 80, 100, 128, 160, 200, 256, 300, 400]:
        n = q
        A = _bose_set(n, q)
        s = _score_fast(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # Strategy 2: greedy sidon
    for target in [20, 40, 60, 80, 120, 200]:
        if time.time() > deadline - 20:
            break
        A = _greedy_sidon(target, 500, min(deadline, time.time() + 10))
        s = _score_fast(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # Strategy 3: improve Bose with appended tail and local search
    if best is None:
        best = [0, 1]
        best_score = _score_fast(best)

    # Local search from best
    if time.time() < deadline:
        A2, s2 = _local_search(best, deadline, deadline - time.time() - 2)
        if s2 > best_score:
            best, best_score = A2, s2

    # Try combining: take Bose set, append anti-sum elements
    if time.time() < deadline - 5:
        for q in [50, 80, 100, 128]:
            base = _bose_set(q, q)
            # append a few outliers far away to add differences but few sums
            for extra in range(1, 8):
                cand = base + [10**6 + i for i in range(extra)]
                s = _score_fast(cand)
                if s > best_score:
                    best_score = s
                    best = cand[:]
                    break

    res = sorted(set(best))
    return res
