import math
import random
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
            diffs.add(ai - a[j])
            diffs.add(a[j] - ai)
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _fast_stats(a):
    a = sorted(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
            d = ai - a[j]
            diffs.add(d)
            diffs.add(-d)
    return len(diffs), len(sums)


def _local_improve(a, deadline, budget=None):
    a = sorted(set(a))
    best_d, best_s = _fast_stats(a)
    best_score = math.log(best_d) / math.log(best_s) + (1 - 1 / len(a)) / 100
    best = a[:]
    cur = a[:]
    n = len(cur)

    if budget is None:
        budget = 200000

    it = 0
    while time.time() < deadline and it < budget:
        it += 1
        mode = random.random()
        cand = cur[:]
        if mode < 0.55 and n > 2:
            i = random.randrange(n)
            j = random.randrange(n)
            if i != j:
                cand[i] = cand[j]
        elif mode < 0.85:
            i = random.randrange(n)
            delta = random.choice([-1, 1]) * random.randint(1, 5)
            cand[i] += delta
        else:
            i = random.randrange(n)
            extra = cand[i] + random.randint(1, 12)
            cand.append(extra)

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue

        d, s = _fast_stats(cand)
        score = math.log(d) / math.log(s) + (1 - 1 / len(cand)) / 100

        if score >= best_score:
            best_score = score
            best = cand[:]
            cur = cand[:]
        elif score >= math.log(best_d) / math.log(best_s) - 0.05:
            cur = cand[:]

    return best, best_score


def _sidon_greedy(N, target):
    """Greedy construction of Sidon set within [0, N]."""
    S = []
    used_diffs = set()
    candidates = list(range(0, N + 1))
    random.shuffle(candidates)
    for c in candidates:
        ok = True
        new_diffs = set()
        for s in S:
            d = c - s
            if d in used_diffs or -d in used_diffs:
                ok = False
                break
            for dd in (d, -d):
                if dd in new_diffs:
                    ok = False
                    break
            if not ok:
                break
            new_diffs.add(d)
            new_diffs.add(-d)
        if ok:
            for dd in new_diffs:
                used_diffs.add(dd)
            S.append(c)
        if len(S) >= target:
            break
    return S


def solve():
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try several seed constructions and local search.
    attempts = 0
    while time.time() < deadline - 5:
        attempts += 1
        choice = attempts % 4

        if choice == 0:
            seed = [1 << i for i in range(30)]
            if random.random() < 0.5:
                seed = [0] + seed
            seed = _sidon_greedy(4000, 30)
            if not seed:
                seed = [1 << i for i in range(20)]
            center = sum(seed) // max(1, len(seed))
            seed = [x - center for x in seed]
        elif choice == 1:
            # pseudo-random Sidon-ish spacing
            seed = []
            cur = 0
            for i in range(40):
                seed.append(cur)
                cur += random.randint(1, 40)
            center = sum(seed) // len(seed)
            seed = [x - center for x in seed]
        elif choice == 2:
            seed = _sidon_greedy(3000, 45)
            if len(seed) < 2:
                seed = [7, 15, 18, 22, -3, -2]
        else:
            # small perturbation of current best
            seed = best[:]
            for _ in range(random.randint(0, 3)):
                if seed:
                    i = random.randrange(len(seed))
                    seed[i] += random.choice([-1, 1]) * random.randint(1, 6)
            seed = list(set(seed))

        if len(seed) < 2:
            continue

        improved, score = _local_improve(seed, min(deadline, time.time() + 8))
        if score > best_score:
            best_score = score
            best = improved[:]

    # Final polish on best
    improved, score = _local_improve(best, deadline)
    if score > best_score:
        best_score = score
        best = improved[:]

    return sorted(set(best))
