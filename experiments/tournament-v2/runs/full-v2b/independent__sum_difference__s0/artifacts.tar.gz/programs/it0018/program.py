import math
import time


def _score_partial(a):
    """Score as in problem statement."""
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    # Use fast set comprehensions
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    ld = math.log(len(diffs))
    ls = math.log(len(sums))
    if ls == 0:
        return 0.0
    return ld / ls + (1.0 - 1.0 / n) / 100.0


def solve():
    deadline = time.time() + 110.0

    # Candidate: arithmetic progression has |A+A| = |A-A| = 2n-1, ratio = 1.
    # We want |A-A| large relative to |A+A|. A classic way: take A as a set whose
    # pairwise sums collide a lot but differences don't. A "union of short APs"
    # or a set with additive structure helps.

    # Known good construction: numbers of the form x + M*y where x in small set,
    # y in another small set. Additive structure can compress sums.
    #
    # The baseline is a weak ratio around 1. Let's try several structured families
    # and keep the best.

    best = None
    best_score = -1.0

    def consider(cand):
        nonlocal best, best_score
        cand = sorted(set(cand))
        if len(cand) < 2:
            return
        s = _score_partial(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    # Family 1: interval [0, n-1] -> ratio 1
    for n in range(2, 30):
        consider(list(range(n)))

    # Family 2: A = {i + 100*j : 0<=i<I, 0<=j<J}
    # This is essentially an I x J grid with large spacing. Differences along j are
    # multiples of 100 plus small offsets -> many distinct; sums along j are 100*(j1+j2)
    # so they collide. This can make |A+A| smaller than |A-A|.
    for I in range(1, 12):
        for J in range(2, 40):
            if I * J > 3900:
                continue
            M = 1000
            A = [i + M * j for i in range(I) for j in range(J)]
            consider(A)

    # Family 3: union of two intervals of different lengths
    for a in range(1, 10):
        for b in range(2, 30):
            A = list(range(a)) + [1000 + x for x in range(b)]
            consider(A)

    # Family 4: A = {i + 2*i^? } not useful; try quadratic-ish small set search
    # Exhaustively search small sets for high ratio
    import random
    random.seed(12345)

    # Local search starting from grid constructions that look promising
    starts = [
        [i + 1000 * j for i in range(4) for j in range(20)],
        [i + 1000 * j for i in range(3) for j in range(30)],
        [i + 1000 * j for i in range(5) for j in range(20)],
        list(range(50)),
    ]

    for start in starts:
        cur = sorted(set(start))
        cur_score = _score_partial(cur)
        while time.time() < deadline:
            improved = False
            # Try adding/removing/moving elements
            for _ in range(200):
                if time.time() >= deadline:
                    break
                cand = cur[:]
                r = random.random()
                if r < 0.4 and len(cand) < 400:
                    # add
                    cand.append(random.randint(-2000, 20000))
                elif r < 0.7 and len(cand) > 3:
                    # remove
                    idx = random.randrange(len(cand))
                    cand.pop(idx)
                else:
                    idx = random.randrange(len(cand))
                    cand[idx] += random.randint(-50, 50)
                cand = sorted(set(cand))
                if len(cand) < 2:
                    continue
                s = _score_partial(cand)
                if s > cur_score:
                    cur, cur_score = cand, s
                    improved = True
                    if s > best_score:
                        best, best_score = cand[:], s
                    break
            if not improved:
                break

    if best is None:
        best = list(range(100))

    # Final score check
    return best
