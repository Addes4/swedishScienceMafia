import math
import random
import time
from itertools import combinations


def _score_and_sets(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _score(a):
    return _score_and_sets(a)[0]


def perfect_difference_set(q):
    """Return a perfect difference set modulo q^2+q+1 when possible (q a prime power).
    Uses the standard Bose-Chowla construction over GF(q)."""
    n = q * q + q + 1
    # Build GF(q) as integers mod q (q prime here).
    # Primitive element of GF(q^3) represented as polynomials over GF(q)
    # modulo an irreducible cubic. We search for a primitive cubic.
    def poly_mul_mod(a, b, mod):
        res = [0] * 3
        for i in range(3):
            if a[i] == 0:
                continue
            ai = a[i]
            for j in range(3):
                if b[j]:
                    res[(i + j) % 3] = (res[(i + j) % 3] + ai * b[j]) % q
        # reduce using mod: x^3 = -(mod[0] + mod[1]x + mod[2]x^2)
        carry = res[2]
        if carry:
            res[0] = (res[0] - carry * mod[0]) % q
            res[1] = (res[1] - carry * mod[1]) % q
            res[2] = 0
        return res

    def poly_pow(a, e, mod):
        res = [1, 0, 0]
        base = a[:]
        while e:
            if e & 1:
                res = poly_mul_mod(res, base, mod)
            base = poly_mul_mod(base, base, mod)
            e >>= 1
        return res

    # find irreducible cubic: x^3 = c0 + c1 x + c2 x^2 has no roots if no alpha in GF(q) satisfies
    candidates = []
    for c0 in range(q):
        for c1 in range(q):
            for c2 in range(q):
                # polynomial x^3 - c2 x^2 - c1 x - c0 ; check roots
                ok = True
                for x in range(q):
                    if (x * x * x - c2 * x * x - c1 * x - c0) % q == 0:
                        ok = False
                        break
                if ok:
                    candidates.append([c0, c1, c2])
    # To keep time bounded, pick first few irreducibles and test primitivity.
    for mod in candidates:
        # find primitive element: x should often be primitive for suitable mod
        # order of x modulo polynomial must be q^3-1
        order_target = q ** 3 - 1
        # factor order_target enough? just test powers; q small so fine.
        # test if x has full order
        def order(gen):
            o = order_target
            # reduce o using prime factors
            m = order_target
            d = 2
            fac = []
            while d * d <= m:
                if m % d == 0:
                    fac.append(d)
                    while m % d == 0:
                        m //= d
                d += 1
            if m > 1:
                fac.append(m)
            o = order_target
            for p in fac:
                while o % p == 0 and poly_pow(gen, o // p, mod) == [1, 0, 0]:
                    o //= p
            return o
        if order([0, 1, 0]) == order_target:
            gen = [0, 1, 0]
            # Bose-Chowla: D = { i : theta^i = theta + a, a in GF(q) } indices i in [1, n]
            D = []
            for a in range(q):
                target = [a, 1, 0]  # x + a
                # discrete log of target
                val = [1, 0, 0]
                for e in range(order_target + 1):
                    if val == target:
                        D.append(e % n if e != 0 else 0)
                        break
                    val = poly_mul_mod(val, gen, mod)
                else:
                    break
            if len(D) == q:
                return sorted(set(d % n for d in D))
    return None


def siddon_like_set(size):
    """Greedy/Sidon-like construction to keep sums small."""
    # Use a greedy Sidon set in a moderate interval.
    A = [0]
    limit_hi = max(50, size * size * 4)
    forbidden = set()
    x = 1
    while len(A) < size and x <= limit_hi:
        ok = True
        # check if adding x creates duplicate sums with existing
        new_sums = {x + a for a in A}
        if new_sums & forbidden:
            ok = False
        if ok:
            # update forbidden sums
            forbidden |= new_sums
            forbidden.add(2 * x)
            A.append(x)
        x += 1
    return A


def local_polish(A, deadline, base_score):
    A = sorted(set(A))
    best = A[:]
    best_score = base_score
    cur = A[:]

    def eval_set(s):
        return _score(s)

    while time.time() < deadline:
        cand = cur[:]
        idx = random.randrange(len(cand))
        delta = random.randint(-5, 5)
        cand[idx] += delta
        if len(set(cand)) != len(cand):
            continue
        s = eval_set(cand)
        if s > best_score:
            best = cand[:]
            best_score = s
            cur = cand[:]
        elif s > best_score - 0.02:
            cur = cand[:]
        if random.random() < 0.01 and len(cand) < 4000:
            cand2 = cand + [random.randint(-1000, 1000)]
            if len(set(cand2)) == len(cand2):
                s2 = eval_set(cand2)
                if s2 > best_score:
                    best = cand2[:]
                    best_score = s2
                    cur = cand2[:]
    return best, best_score


def solve():
    deadline = time.time() + 110
    best_A = None
    best_score = -1.0

    # Try several prime powers q for perfect difference sets.
    # q=31 gives n=993 elements, q=47 -> 2257, q=53 -> 2863.
    for q in [31, 37, 41, 43, 47, 53, 59, 61]:
        if time.time() > deadline:
            break
        D = perfect_difference_set(q)
        if not D:
            continue
        n = q * q + q + 1
        # Map cyclic group Z_n to integers in a balanced interval.
        half = n // 2
        A_balanced = []
        for d in D:
            v = d if d <= half else d - n
            A_balanced.append(v)
        A_balanced = sorted(set(A_balanced))
        # scale modestly to reduce collinear sum collisions
        sc = 1
        A_scaled = [x * sc for x in A_balanced]
        sc_val, _, _ = _score_and_sets(A_scaled)
        if sc_val > best_score:
            best_score = sc_val
            best_A = A_scaled
        # local polish
        A_pol, sc2 = local_polish(A_scaled, min(deadline, time.time() + 8), sc_val)
        if sc2 > best_score:
            best_score = sc2
            best_A = A_pol

    # Also try a greedy Sidon-like set.
    if time.time() < deadline:
        S = siddon_like_set(500)
        s = _score(S)
        if s > best_score:
            best_score = s
            best_A = S

    if best_A is None:
        best_A = [0, 1]
        best_score = _score(best_A)

    # Final local search on best_A.
    best_A, best_score = local_polish(best_A, deadline, best_score)

    # Normalize: shift so median near 0, and ensure within bounds.
    best_A = sorted(set(best_A))
    if len(best_A) > 4000:
        best_A = best_A[:4000]
    # Clip values to allowed range (shouldn't happen).
    best_A = [max(-10**15, min(10**15, x)) for x in best_A]
    # Remove duplicates possibly introduced by clipping.
    best_A = sorted(set(best_A))

    return best_A
