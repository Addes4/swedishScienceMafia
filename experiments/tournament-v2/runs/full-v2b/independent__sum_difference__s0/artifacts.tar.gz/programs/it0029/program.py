import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
        for j in range(n):
            diffs.add(ai - a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_components(a):
    """Return (num_diffs, num_sums, n)."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, n
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
        for j in range(n):
            diffs.add(ai - a[j])
    return len(diffs), len(sums), n


def _attach_scores(num_diffs, num_sums, n):
    if num_sums < 2 or n < 2:
        return -1e18
    return math.log(num_diffs) / math.log(num_sums) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110

    best = [0, 1, 3, 7, 12, 20]
    best_score = _score(best)

    # Seed with a good Sidon-ish set
    random.seed(12345)

    # Known high-quality constructions: B_2 sets (Sidon).  Try to build a
    # large Sidon set greedily with random restarts, then optimize.
    def build_sidon(target_size, tlimit, offset=0):
        """Greedy randomized Sidon set construction (all sums distinct)."""
        result = [offset]
        # candidate pool
        cands = list(range(offset + 1, offset + target_size * target_size * 4 + 1))
        random.shuffle(cands)
        # maintain set of differences to test Sidon property quickly (sums unique)
        diff_set = set()
        sum_set = set()
        t_end = time.time() + tlimit
        for c in cands:
            if time.time() > t_end:
                break
            if len(result) >= target_size:
                break
            ok = True
            new_sums = set()
            for x in result:
                s = x + c
                if s in sum_set or s in new_sums:
                    ok = False
                    break
                new_sums.add(s)
            if not ok:
                continue
            for x in result:
                sum_set.add(x + c)
            sum_set.add(c + c)
            result.append(c)
        return result

    # Try a few greedy Sidon sets of increasing sizes and score them
    for tsize in [50, 100, 150, 200, 300, 400]:
        if time.time() > deadline:
            break
        s = build_sidon(tsize, 5)
        if len(s) >= 2:
            sc = _score_fast(s)
            if sc > best_score:
                best = s[:]
                best_score = sc

    # Also try arithmetic progressions - they maximize differences
    for n in [50, 100, 200, 300, 400]:
        if time.time() > deadline:
            break
        s = list(range(n))
        sc = _score_fast(s)
        if sc > best_score:
            best = s[:]
            best_score = sc

    # Now local search on the best set
    cur = best[:]
    cur_score = best_score

    def local_search(a, time_limit):
        nonlocal best, best_score
        a = sorted(set(a))
        n = len(a)
        end = time.time() + time_limit
        step = max(1, (max(a) - min(a)) // (n * 4) if n > 1 else 1)
        while time.time() < end:
            # perturbation: move an element
            cand = a[:]
            i = random.randrange(len(cand))
            # try moving to random position within range
            lo = min(a) - step * 10
            hi = max(a) + step * 10
            cand[i] = random.randint(lo, hi)
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            sc = _score_fast(cand)
            if sc > cur_score:
                a = cand
                cur_score = sc
                if sc > best_score:
                    best = cand[:]
                    best_score = sc
                step = max(1, step)
            else:
                # occasionally reset step or accept
                if random.random() < 0.02:
                    step = max(1, step // 2)
        return a, cur_score

    cur, cur_score = local_search(cur, max(0, deadline - time.time()) * 0.5)

    # Second phase: try inserting/removing elements
    if time.time() < deadline:
        rest = deadline - time.time()
        end = time.time() + rest
        a = best[:]
        cur_score = best_score
        while time.time() < end:
            cand = a[:]
            op = random.random()
            if op < 0.4 and len(cand) > 2:
                # remove element
                idx = random.randrange(len(cand))
                cand.pop(idx)
            elif op < 0.8:
                # add new element
                lo = min(cand) - 50
                hi = max(cand) + 50
                cand.append(random.randint(lo, hi))
            else:
                # modify element
                idx = random.randrange(len(cand))
                lo = min(cand) - 50
                hi = max(cand) + 50
                cand[idx] = random.randint(lo, hi)
            if len(cand) < 2:
                continue
            sc = _score_fast(cand)
            if sc > cur_score:
                a = cand
                cur_score = sc
                if sc > best_score:
                    best = cand[:]
                    best_score = sc
        if cur_score > best_score:
            best = a[:]
            best_score = cur_score

    # Final cleanup
    best = sorted(set(best))
    return best
