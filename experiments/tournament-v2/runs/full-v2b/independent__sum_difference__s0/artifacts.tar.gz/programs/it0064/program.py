import math
import random
import time

def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
            if i != j:
                diffs.add(ai - a[j])
                diffs.add(a[j] - ai)
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1 or ld <= 0:
        return -1e9, ld, ls
    sc = math.log(ld) / math.log(ls) + (1 - 1.0 / n) / 100.0
    return sc, ld, ls

# ---------- Structured constructions ----------

def construct_geometric(k, base, spread):
    """A = digits in base `base`, blocks scaled: many distinct differences, clustered sums."""
    A = set()
    # central dense block: consecutive integers
    for i in range(k):
        A.add(i)
    # sparse far blocks (powers of base) each as a short consecutive run
    p = base
    for b in range(spread):
        for j in range(k):
            A.add(p + j)
        p *= base
    return sorted(A)

def construct_mixed(n_small, step_powers, coeffs):
    """A = { sum c_i * b^i } over digit ranges. Differences are many, sums sparse."""
    A = set()
    # small dense part
    for i in range(n_small):
        A.add(i)
    v = 1
    for b, c in zip(coeffs, step_powers):
        A.add(v * c)
        A.add(v * c + 1)
        A.add(v * c + 2)
        v *= b
    return sorted(A)

def construct_sidon_like(rng, n, modulus):
    """Greedy Sidon-like set in Z: many differences, sums concentrated by modular structure."""
    A = [0, 1]
    used_diffs = {1, -1, 0}
    used_sums = {0, 1, 2}
    tries = 0
    while len(A) < n and tries < 20000:
        tries += 1
        x = rng.randrange(modulus)
        if x in A:
            continue
        nd = set()
        ns = set()
        for a in A:
            nd.add(x - a); nd.add(a - x)
            ns.add(x + a)
        if nd & used_diffs:
            # allow some overlap in diffs (we want MANY diffs, so actually allow)
            pass
        # reject if it creates too few new sums
        if len(ns - used_sums) > len(nd) // 2 + 1:
            continue
        A.append(x)
        used_diffs |= nd
        used_sums |= ns
    return sorted(A)

def construct_binary_runs(num_blocks, run_len, gaps):
    """Blocks of consecutive runs separated by gaps chosen to control sum collisions."""
    A = set()
    pos = 0
    for b in range(num_blocks):
        for j in range(run_len):
            A.add(pos + j)
        pos += run_len + gaps[b % len(gaps)]
    return sorted(A)

# ---------- Local search ----------

def has_no_improvement(score_history, window):
    if len(score_history) < window:
        return False
    return score_history[-1] <= max(score_history[-window:-1])

def local_search(A, deadline, rng, eval_limit=None):
    cur = sorted(set(A))
    cur_s, cur_d, cur_sm = _score(cur)
    best = cur[:]
    best_s = cur_s
    evals = 0
    no_imp = 0
    temp = 0.3
    while time.time() < deadline and (eval_limit is None or evals < eval_limit):
        evals += 1
        cand = cur[:]
        op = rng.random()
        if op < 0.6 and len(cand) > 2:
            # move one element
            i = rng.randrange(len(cand))
            scale = max(1, abs(cand[i]) // 10 + 1)
            cand[i] += rng.randint(-scale, scale)
        elif op < 0.8:
            # add element
            if len(cand) < 3500:
                base = rng.choice(cand)
                cand.append(base + rng.randint(-5, 5))
        elif op < 0.95 and len(cand) > 3:
            # remove element
            i = rng.randrange(len(cand))
            del cand[i]
        else:
            # shift a whole suffix (translation to test sum structure)
            if len(cand) > 1:
                i = rng.randrange(len(cand))
                delta = rng.randint(-3, 3)
                for j in range(i, len(cand)):
                    cand[j] += delta
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s, d, sm = _score(cand)
        if s > best_s:
            best, best_s = cand[:], s
            no_imp = 0
        else:
            no_imp += 1
        if s >= cur_s or rng.random() < math.exp((s - cur_s) / max(temp, 1e-9)):
            cur, cur_s = cand, s
        # adaptive temperature
        temp *= 0.999
        if temp < 0.001:
            temp = 0.05
            cur = best[:]
            cur_s = best_s
    return best, best_s

def evaluate_and_pick(candidates, deadline_slice, rng):
    best = None
    best_s = -1e18
    for A in candidates:
        A = sorted(set(A))
        if len(A) < 2:
            continue
        s, _, _ = _score(A)
        if s > best_s:
            best_s, best = s, A
        if time.time() > deadline_slice:
            break
    return best, best_s

def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110
    overall_best = None
    overall_best_s = -1e18

    # Generate a diverse pool of structured candidates
    candidates = []

    # geometric/base constructions
    for k in [3, 4, 5, 6, 8, 10, 12]:
        for base in [3, 4, 5, 6, 7, 8, 10, 13]:
            for spread in [3, 4, 5, 6, 8, 10]:
                if k * spread <= 3500:
                    candidates.append(construct_geometric(k, base, spread))

    # mixed digit constructions
    for n_small in [3, 5, 8, 12, 20]:
        for coeffs in [(3,4,5,7),(4,5,7,9),(3,5,7,11,13),(2,3,5,7,11,13),(5,7,11,13,17)]:
            candidates.append(construct_mixed(n_small, coeffs, coeffs))

    # binary run constructions
    for nb in [5, 8, 10, 15, 20, 30, 50, 80]:
        for rl in [3, 5, 8, 12, 20]:
            for gaps in [[1,2,3],[3,5,8],[5,8,13,21],[8,13,21,34],[13,21,34,55],[2,4,8,16,32],[10,20,40,80]]:
                if nb * rl < 3000:
                    candidates.append(construct_binary_runs(nb, rl, gaps))

    # Sidon-like random ones (various sizes/moduli)
    for n in [20, 40, 60, 100]:
        for m in [200, 400, 800, 1600]:
            candidates.append(construct_sidon_like(rng, n, m))

    # Evaluate pool
    slice_end = time.time() + 20
    pool_best, pool_best_s = evaluate_and_pick(candidates, slice_end, rng)
    if pool_best is not None:
        overall_best, overall_best_s = pool_best[:], pool_best_s

    # Local search from many seeds, interleaving time
    seeds = list(candidates)
    rng.shuffle(seeds)

    # ensure we always have a starting point
    if not seeds:
        seeds = [[7, 15, 18, 22, -3, -2]]

    idx = 0
    while time.time() < deadline:
        seed = seeds[idx % len(seeds)]
        idx += 1
        remaining = deadline - time.time()
        if remaining <= 0:
            break
        # spend a short slice on this seed
        slice_deadline = time.time() + min(3.0, max(0.5, remaining / max(1, (len(seeds) - idx % len(seeds) + 1))))
        B, Bs = local_search(seed, slice_deadline, rng)
        if B is not None and Bs > overall_best_s:
            overall_best, overall_best_s = B[:], Bs
        # also try small perturbations of current best
        if overall_best is not None and time.time() < deadline:
            pert = overall_best[:]
            for _ in range(rng.randint(1, 4)):
                if pert and rng.random() < 0.5:
                    i = rng.randrange(len(pert))
                    pert[i] += rng.randint(-2, 2)
                elif len(pert) < 3500:
                    pert.append(rng.choice(pert) + rng.randint(-3, 3))
            pert = sorted(set(pert))
            slice_deadline = time.time() + min(2.0, max(0.4, (deadline - time.time()) / 4))
            B2, B2s = local_search(pert, slice_deadline, rng)
            if B2 is not None and B2s > overall_best_s:
                overall_best, overall_best_s = B2[:], B2s

    if overall_best is None:
        overall_best = [7, 15, 18, 22, -3, -2]

    # Final polish: quick hill-climb on best
    if overall_best and time.time() < deadline:
        B, Bs = local_search(overall_best, min(deadline, time.time() + 5), rng)
        if B is not None and Bs > _score(overall_best)[0]:
            overall_best = B

    return sorted(set(overall_best))
