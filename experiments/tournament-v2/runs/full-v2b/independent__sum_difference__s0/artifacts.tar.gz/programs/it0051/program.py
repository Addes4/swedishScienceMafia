import math
import random
import time


def _score(a):
    a = sorted(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    # direct O(n^2) is fine for the intended scale (n up to a few thousand)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _fast_metrics(a):
    a = sorted(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score_from_counts(nd, ns, n):
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _random_odd_base(k, rng):
    vals = set()
    while len(vals) < k:
        v = rng.randint(-(1 << 20), 1 << 20)
        if v & 1:
            vals.add(v)
    return sorted(vals)


def _make_bp_like(n, rng):
    # Bose-Chowla / Sidon-like small seed, heavily scaled later.
    # Small exact Sidon set with good difference count and relatively few sums.
    seed = [0, 1, 3, 7]
    if n <= len(seed):
        return seed[:n]
    out = list(seed)
    # Greedily add elements that keep sums reasonably controlled and differences growing.
    used = set(out)
    while len(out) < n:
        best_v = None
        best_gain = -1e100
        trials = []
        for _ in range(80):
            base = rng.randint(-7, 7)
            trials.append(base + 8 * rng.randrange(0, max(1, n)))
        for v in trials:
            if v in used:
                continue
            cand = out + [v]
            nd, ns = _fast_metrics(cand)
            gain = math.log(nd + 1) - 1.15 * math.log(ns + 1)
            if gain > best_gain:
                best_gain = gain
                best_v = v
        if best_v is None:
            best_v = max(used) + 1
        out.append(best_v)
        used.add(best_v)
    return out


def _construct(n, rng):
    mode = rng.randrange(6)

    if mode == 0:
        # Dense interval with holes: many differences, sums limited by narrow span.
        span = max(2, int(1.25 * n))
        base = rng.sample(range(span), min(n, span))
        return sorted(base)

    if mode == 1:
        # Odd-scaled arithmetic progression with perturbations.
        step = 1 << rng.randrange(8, 30)
        base = [i * step for i in range(n)]
        for _ in range(max(1, n // 5)):
            i = rng.randrange(n)
            base[i] += rng.choice([-step, step, -step // 2, step // 2])
        return sorted(set(base))

    if mode == 2:
        # Sidon-ish greedy seed, then scale.
        base = _make_bp_like(min(n, 60), rng)
        if n > len(base):
            extra = rng.sample(range(-100, 100), min(n - len(base), 200))
            base = sorted(set(base + extra))
        return base[:n]

    if mode == 3:
        # Union of a short arithmetic progression and sparse outliers.
        m = max(2, n // 3)
        base = [i for i in range(m)]
        need = n - len(base)
        for _ in range(need):
            if rng.random() < 0.6:
                base.append(rng.randint(-m, 2 * m))
            else:
                base.append(rng.randint(-10 * m, 10 * m))
        return sorted(set(base))[:n]

    if mode == 4:
        # Two/interleaved progressions of different steps.
        a = [2 * i for i in range((n + 1) // 2)]
        b = [2 * i + 1 for i in range(n // 2)]
        base = sorted(set(a + b + [rng.randint(-2 * n, 2 * n) for _ in range(max(1, n // 10))]))
        return base[:n]

    # Near-AP with multiplicative scaling of a small good core.
    core = [0, 1, 4, 6]
    reps = max(1, n // len(core) + 1)
    scale = 1 << rng.randrange(3, 20)
    base = []
    for r in range(reps):
        off = r * scale
        for c in core:
            base.append(off + c * (1 if rng.random() < 0.8 else -1))
    return sorted(set(base))[:n]


def _local_search(a, deadline, rng, init_score=None):
    a = sorted(set(int(x) for x in a))
    if len(a) < 2:
        return a, 0.0
    nd, ns = _fast_metrics(a)
    sc = _score_from_counts(nd, ns, len(a))
    best = a[:]
    best_sc = sc

    # Adaptive temperature and move radius.
    T = 0.03
    max_abs = 10 ** 12
    steps = 0

    while time.time() < deadline:
        steps += 1
        cand = a[:]
        op = rng.random()
        n = len(cand)

        if op < 0.55:
            # move one element
            i = rng.randrange(n)
            span = max(3, min(10 ** 6, int(1 + abs(cand[i]) // 4 + n * n)))
            delta = int(rng.gauss(0, max(1.0, span ** 0.5)))
            if delta == 0:
                delta = rng.choice([-1, 1])
            cand[i] += delta
            if abs(cand[i]) > max_abs:
                cand[i] %= max_abs
        elif op < 0.75 and n > 6:
            # remove one
            i = rng.randrange(n)
            cand.pop(i)
        elif op < 0.92 and n < 4000:
            # add one near an existing point or in the current span
            if n and rng.random() < 0.85:
                anchor = rng.choice(cand)
                span = max(3, min(10 ** 9, int(1 + abs(anchor) // 3 + n * n)))
                v = anchor + int(rng.gauss(0, max(1.0, span ** 0.5)))
            else:
                lo = min(cand)
                hi = max(cand)
                v = rng.randint(lo - 2 * n, hi + 2 * n)
            if abs(v) <= max_abs:
                cand.append(v)
        else:
            # swap two values
            if n >= 2:
                i, j = rng.sample(range(n), 2)
                cand[i], cand[j] = cand[j], cand[i]

        cand = sorted(set(cand))
        if len(cand) < 3:
            continue
        nd2, ns2 = _fast_metrics(cand)
        sc2 = _score_from_counts(nd2, ns2, len(cand))

        if sc2 >= sc or rng.random() < math.exp((sc2 - sc) / max(1e-9, T)):
            a = cand
            sc = sc2
            if sc > best_sc:
                best = cand[:]
                best_sc = sc

        # Reheat occasionally.
        if steps % 2000 == 0:
            T *= 0.995
            if T < 0.002:
                T = 0.02
            if rng.random() < 0.1:
                a = best[:]
                sc = best_sc

    return best, best_sc


def solve():
    """Return a list of distinct integers maximising log|A-A|/log|A+A|."""
    deadline = time.time() + 115.0
    rng = random.Random(123456789)

    best = [7, 15, 18, 22, -3, -2]
    best_sc = _score(best)

    # Try several sizes: bonus favors larger n, ratio often favors moderate n.
    sizes = [6, 8, 10, 14, 20, 30, 45, 70, 110, 170, 260, 400, 650, 1000, 1600, 2500]
    rng.shuffle(sizes)

    # First pass: quick constructive search.
    for n in sizes:
        if time.time() > deadline:
            break
        for _ in range(8):
            cand = _construct(n, rng)
            if len(cand) < 2:
                continue
            local_deadline = min(deadline, time.time() + 1.0)
            cand, sc = _local_search(cand, local_deadline, rng)
            if sc > best_sc:
                best = cand[:]
                best_sc = sc

    # Second pass: allocate remaining time to the most promising region.
    if best:
        n0 = len(best)
        candidates = []
        for n in {max(4, n0 - 3), max(4, n0 - 1), n0, n0 + 1, n0 + 3, n0 + 8, n0 + 20}:
            if n <= 4000:
                candidates.append(n)
        candidates.sort(key=lambda z: abs(z - n0))
        for n in candidates:
            if time.time() > deadline:
                break
            for _ in range(10):
                if time.time() > deadline:
                    break
                if rng.random() < 0.5 and best:
                    seed = best[:]
                    # adjust size
                    while len(seed) > n:
                        seed.pop(rng.randrange(len(seed)))
                    while len(seed) < n:
                        seed.append(rng.randint(min(seed) - n, max(seed) + n))
                else:
                    seed = _construct(n, rng)
                cand, sc = _local_search(seed, deadline, rng)
                if sc > best_sc:
                    best = cand[:]
                    best_sc = sc

    # Final intensive polishing around best.
    while time.time() < deadline:
        cand, sc = _local_search(best, deadline, rng)
        if sc > best_sc:
            best = cand[:]
            best_sc = sc

    return sorted(set(int(x) for x in best))


if __name__ == "__main__":
    ans = solve()
    nd, ns = _fast_metrics(ans)
    print(len(ans), nd, ns, _score(ans))
