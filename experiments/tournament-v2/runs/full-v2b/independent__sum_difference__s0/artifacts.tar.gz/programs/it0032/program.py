import math
import random
import time

def _stats(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0, a
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums), a

def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _construct(seed):
    rnd = random.Random(seed)
    # start from a structured set: quadratic-ish / distinct differences
    n = rnd.randint(20, 80)
    base = 1
    # use a "Golomb-like" construction with spread
    a = []
    x = 0
    for i in range(n):
        x += rnd.randint(1, 40)
        a.append(x)
    return a

def solve():
    best = None
    best_score = -1e18
    deadline = time.time() + 110

    # Try several structured starts
    starts = []
    # arithmetic progression with perturbation
    for base in (1, 2, 3):
        n = 60
        a = [i * base for i in range(n)]
        starts.append(a)
    # quadratic exponent (power set style)
    for n in (20, 30, 40, 60):
        a = [i * i + i for i in range(1, n + 1)]
        starts.append(a)
    # geometric-ish (build via distinct differences greedy)
    for n in (30, 50, 80):
        a = []
        used = set()
        cur = 0
        for _ in range(n):
            step = 1
            while True:
                cand = cur + step
                ok = True
                for x in a:
                    if cand - x in used:
                        ok = False
                        break
                if ok:
                    break
                step += 1
            for x in a:
                used.add(cand - x)
            a.append(cand)
            cur = cand
        starts.append(a)

    # random starts
    for s in range(5):
        starts.append(_construct(s))

    for start in starts:
        cur = sorted(set(start))
        cs = _score_fast(cur)
        if cs > best_score:
            best_score = cs
            best = cur[:]
        # local search
        for _ in range(2000):
            if time.time() > deadline:
                break
            cand = cur[:]
            op = random.random()
            if op < 0.5 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-50, 50)
            elif op < 0.8:
                cand.append(random.randint(-1000, 1000))
            elif len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            s = _score_fast(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_score:
                    best_score = s
                    best = cur[:]
        if time.time() > deadline:
            break

    # final refinement on best with more careful search
    if best is None:
        best = [0, 1]
    cur = best[:]
    cs = best_score
    while time.time() < deadline:
        for _ in range(500):
            cand = cur[:]
            r = random.random()
            if r < 0.6 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-5, 5)
            elif r < 0.8:
                cand.append(random.randint(min(cand)-10, max(cand)+10) if cand else 0)
            elif len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            s = _score_fast(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_score:
                    best_score = s
                    best = cur[:]

    return sorted(set(best))
