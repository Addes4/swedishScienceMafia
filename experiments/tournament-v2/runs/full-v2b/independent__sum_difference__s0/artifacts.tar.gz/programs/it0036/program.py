import math
import random
import time


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            if j >= i:
                sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _score_parts(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)), len(diffs), len(sums)


def _construct(n, p):
    """Build a Sidon-style set using a cubic-ish map mod p."""
    rng = random.Random(12345 + n)
    a = 1
    b = rng.randrange(1, p)
    c = rng.randrange(1, p)
    S = set()
    x = 0
    tries = 0
    while len(S) < n and tries < 20 * n:
        val = (a * x * x * x + b * x) % p
        S.add(val)
        x += 1
        tries += 1
    return sorted(S)


def _hillclimb(a, deadline, target_ratio_weight=1.0):
    n = len(a)
    if n < 2:
        return a
    a = sorted(set(a))
    cur = a[:]
    best = a[:]
    # initial exact score
    best_ratio, best_d, best_s = _score_parts(best)
    best_full = best_ratio + (1.0 - 1.0 / len(best)) / 100.0
    while time.time() < deadline:
        cand = cur[:]
        action = random.random()
        if action < 0.7 and len(cand) > 0:
            i = random.randrange(len(cand))
            span = max(1, abs(cand[i]) // 10 + 1)
            delta = random.randint(-span, span)
            cand[i] += delta
        elif action < 0.85:
            cand.append(random.randint(-10**6, 10**6))
        else:
            if len(cand) > 2:
                i = random.randrange(len(cand))
                del cand[i]
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        ratio, d, s = _score_parts(cand)
        full = ratio + (1.0 - 1.0 / len(cand)) / 100.0
        if full > best_full:
            best_full = full
            best = cand[:]
            cur = cand[:]
        elif random.random() < 0.05:
            cur = cand[:]
        if len(cur) > 4 and random.random() < 0.01:
            cur = best[:]
    return best


def solve():
    deadline = time.time() + 110
    candidates = []
    # Try several prime moduli and sizes
    primes = [1000003, 1000033, 1000037, 2000003, 2000039, 3000017, 5000009]
    sizes = [20, 50, 100, 200, 400, 800]
    for p in primes:
        for n in sizes:
            if time.time() > deadline - 60:
                break
            s = _construct(n, p)
            candidates.append(s)
    # Small exact construction from baseline plus tweaks
    candidates.append([7, 15, 18, 22, -3, -2])
    # choose best initial
    best = None
    best_full = -1
    for c in candidates:
        if len(c) < 2:
            continue
        ratio, d, s = _score_parts(c)
        full = ratio + (1.0 - 1.0 / len(c)) / 100.0
        if full > best_full:
            best_full = full
            best = c[:]
    if best is None:
        best = [1, 2]
    # hillclimb within remaining time
    result = _hillclimb(best, deadline)
    return sorted(set(result))
