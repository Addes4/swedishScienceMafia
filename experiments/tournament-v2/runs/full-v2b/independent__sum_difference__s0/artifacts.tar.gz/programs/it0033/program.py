import math
import random
import time
from itertools import combinations

def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0, 0, 0
    r = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100.0
    return r, len(diffs), len(sums)


def _greedy_from_seed(seed, pool, max_size, deadline):
    """Greedily add elements from pool that raise the score."""
    A = list(seed)
    best_score, _, _ = _score(A)
    changed = True
    while changed and len(A) < max_size:
        changed = False
        if time.time() > deadline:
            break
        best_add = None
        for x in pool:
            if x in A:
                continue
            cand = A + [x]
            s, _, _ = _score(cand)
            if s > best_score:
                best_score = s
                best_add = x
        if best_add is not None:
            A.append(best_add)
            changed = True
    return A, best_score


def _local_search(A, deadline, radius=3, tries=None):
    A = sorted(set(A))
    best = A[:]
    best_score, _, _ = _score(best)
    cur = best[:]
    if tries is None:
        tries = 100000
    t = 0
    while time.time() < deadline and t < tries:
        t += 1
        cand = cur[:]
        op = random.random()
        if op < 0.5 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-radius, radius)
        elif op < 0.75:
            cand.append(random.randint(-200, 200))
        else:
            if len(cand) > 2:
                i = random.randrange(len(cand))
                del cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s, _, _ = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]
    return best, best_score


def _ap_construction():
    """Arithmetic-like structures: {0,1,...,n} scaled give small sum set? 
    Actually {0..n} has sum set size 2n+1 and diff set 2n+1 -> ratio 1. Bad.
    Sidon-like: use powers. Known: geometric {1,2,4,...} has big sums.
    Use Singer/Sidon modular sets mapped to integers."""
    best = []
    best_score = 0.0
    # Try various Sidon-like sets constructed greedily over Z/N
    for N in range(11, 400):
        if time.time() > 100:
            break
        # build Sidon set mod N greedily
        S = []
        used_diffs = set()
        for x in range(N):
            ok = True
            for y in S:
                d1 = (x - y) % N
                d2 = (y - x) % N
                if d1 in used_diffs or d2 in used_diffs or d1 == 0:
                    ok = False
                    break
            if ok:
                for y in S:
                    used_diffs.add((x - y) % N)
                    used_diffs.add((y - x) % N)
                S.append(x)
        if len(S) >= 3:
            s, _, _ = _score(S)
            if s > best_score:
                best_score = s
                best = S[:]
    return best, best_score


def _dfs_small(limit=14, max_size=10, deadline=None):
    """Exhaustive-ish search over small integer sets via DFS with pruning."""
    best = []
    best_score = 0.0
    pool = list(range(-limit, limit + 1))

    # randomized restart greedy
    for _ in range(2000):
        if deadline and time.time() > deadline:
            break
        k = random.randint(4, max_size)
        seed = random.sample(pool, k)
        A, sc = _greedy_from_seed(seed, pool, max_size, deadline or time.time() + 1)
        if sc > best_score:
            best_score = sc
            best = A[:]
    return best, best_score


def solve():
    deadline = time.time() + 100
    global_best = [7, 15, 18, 22, -3, -2]
    global_score, _, _ = _score(global_best)

    # 1. Sidon modular constructions
    A, s = _ap_construction()
    if s > global_score:
        global_best, global_score = A[:], s

    # 2. Randomized DFS over small integers
    A, s = _dfs_small(limit=16, max_size=12, deadline=time.time() + 20)
    if s > global_score:
        global_best, global_score = A[:], s

    # 3. Greedy construction from random seeds plus local search
    pool = list(range(-50, 51))
    for _ in range(3000):
        if time.time() > deadline:
            break
        k = random.randint(3, 8)
        seed = random.sample(pool, k)
        A, sc = _greedy_from_seed(seed, pool, 60, min(time.time() + 0.5, deadline))
        if sc > global_score:
            global_best, global_score = A[:], sc

    # 4. Local search refinement
    while time.time() < deadline:
        A, sc = _local_search(global_best, min(time.time() + 5, deadline))
        if sc > global_score:
            global_best, global_score = A[:], sc

    return sorted(set(global_best))
