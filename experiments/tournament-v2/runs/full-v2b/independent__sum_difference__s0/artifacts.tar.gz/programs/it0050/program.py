import math
import random
import time

def _metrics(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ratio = math.log(len(diffs)) / math.log(len(sums))
    score = ratio + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)

def _score(a):
    return _metrics(a)[0]

def _build_seed():
    # Powers of 2 give few distinct sums but many differences.
    # Add structured perturbations to enlarge A-A.
    cand = []
    # base: powers of 2 from 2^0 to 2^11
    for k in range(12):
        cand.append(1 << k)
    # shifted / scaled copies to enrich differences while keeping sums overlapping
    for k in range(10):
        cand.append((1 << k) * 3)
    for k in range(9):
        cand.append((1 << k) * 5)
    for k in range(8):
        cand.append((1 << k) * 7)
    # small offsets
    for k in range(10):
        cand.append((1 << k) + 1)
    cand = list(dict.fromkeys(cand))
    return cand

def solve():
    random.seed(1234567)
    deadline = time.time() + 110

    seeds = []
    seeds.append(_build_seed())

    # alternative seeds: pure powers of two
    seeds.append([1 << k for k in range(14)])
    # powers plus shifts
    s = []
    for k in range(13):
        s.append(1 << k)
        s.append((1 << k) + 1)
    seeds.append(list(dict.fromkeys(s)))

    best = None
    best_score = -1.0

    for seed in seeds:
        cand = seed[:]
        sc = _score(cand)
        if sc > best_score:
            best, best_score = cand[:], sc

    # local search / simulated-annealing-ish
    cur = best[:]
    cur_score = best_score
    step_limit = 200000
    t = 0
    while time.time() < deadline and t < step_limit:
        t += 1
        cand = cur[:]
        op = random.random()
        if op < 0.55 and len(cand) > 0:
            # perturb an element
            i = random.randrange(len(cand))
            mag = max(1, int(abs(cand[i]) * random.uniform(0.001, 0.02)) + 1)
            cand[i] += random.randint(-mag, mag)
        elif op < 0.80:
            # add an element near an existing one or small
            if len(cand) < 80:
                if cand and random.random() < 0.7:
                    x = random.choice(cand)
                    cand.append(x + random.randint(1, 8))
                else:
                    cand.append(random.randint(1, 1 << 13))
        elif op < 0.92 and len(cand) > 4:
            # remove element
            i = random.randrange(len(cand))
            del cand[i]
        else:
            # mutate two
            for _ in range(2):
                if cand:
                    i = random.randrange(len(cand))
                    cand[i] += random.randint(-3, 3)

        cand = list(dict.fromkeys(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 200:
            continue
        # check bounds
        if any(abs(x) > 10**15 for x in cand):
            continue

        sc, nd, ns = _metrics(cand)
        # accept improvements; sometimes accept worse to escape local optima
        if sc >= cur_score:
            cur, cur_score = cand, sc
        else:
            temp = max(1e-6, 0.02 * (1.0 - t / step_limit))
            if random.random() < math.exp((sc - cur_score) / temp):
                cur, cur_score = cand, sc

        if cur_score > best_score:
            best, best_score = cur[:], cur_score

    # final greedy pruning / polishing
    improved = True
    while improved and time.time() < deadline:
        improved = False
        # try removing each element
        i = 0
        while i < len(best) and time.time() < deadline:
            cand = best[:i] + best[i+1:]
            if len(cand) >= 2:
                sc = _score(cand)
                if sc >= best_score:
                    best = cand
                    best_score = sc
                    improved = True
                else:
                    i += 1
            else:
                i += 1
        # try small perturbations
        for idx in range(len(best)):
            if time.time() >= deadline:
                break
            for delta in (-1, 1, 2, -2, 3, -3):
                cand = best[:]
                cand[idx] += delta
                if abs(cand[idx]) <= 10**15:
                    sc = _score(cand)
                    if sc > best_score:
                        best, best_score = cand, sc
                        improved = True
                        break

    return sorted(set(best))
