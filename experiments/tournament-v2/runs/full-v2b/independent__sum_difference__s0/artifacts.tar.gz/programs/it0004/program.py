import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _build_initial():
    # Large Sidon-like set built greedily on a sparse integer grid.
    # Use multiples of a large step to separate differences, then shift blocks
    # so that sums collide more often.
    random.seed(12345)
    N = 700
    step = 10 ** 11
    A = []
    used = set()
    # First construct a Sidon set modulo a prime-ish range, then scale.
    # Simple greedy Sidon construction on bounded integers.
    sidon = []
    sidon_set = set()
    m = 2000
    for x in range(1, m + 1):
        ok = True
        for y in sidon:
            s = x + y
            if s in sidon_set:
                ok = False
                break
        if ok:
            sidon.append(x)
            sidon_set.add(x + x)
            for y in sidon:
                sidon_set.add(x + y)
        if len(sidon) >= N:
            break
    # Scale and introduce structured blocks to reduce sum set size.
    # A = {step * s + offset_block(s)} with small offsets designed to create
    # many repeated sums.
    offsets = [0, 1, 3, 7, 12, 20, 30, 42]
    A = []
    for i, s in enumerate(sidon[:N]):
        A.append(step * s + offsets[i % len(offsets)])
    return A

def _greedy_improve(A, deadline):
    A = list(set(A))
    best_score = _score(A)
    best = A[:]
    # Maintain difference and sum multisets incrementally where possible.
    # Use local perturbations: move one element, add/remove boundary elements.
    span = max(A) - min(A) if A else 1
    cur = A[:]
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.65 and len(cand) >= 2:
            i = random.randrange(len(cand))
            delta = random.randint(-3, 3)
            if delta == 0:
                delta = 1
            cand[i] += delta
        elif op < 0.85 and len(cand) < 3900:
            base = random.choice(cand) if cand else 0
            cand.append(base + random.randint(-50, 50))
        elif len(cand) > 10:
            i = random.randrange(len(cand))
            cand.pop(i)
        # Deduplicate while preserving small size.
        cand = list(set(cand))
        if len(cand) > 4000:
            cand = cand[:4000]
        if len(cand) < 2:
            continue
        # Quick filter: sums count must be reasonably small.
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]
            cur = cand[:]
        elif random.random() < 0.03:
            cur = best[:]
    return best

def _greedy_add(A, deadline):
    # Add elements one at a time if they improve score.
    A = list(set(A))
    best = A[:]
    best_score = _score(best)
    candidates = []
    lo = min(A) - 1000
    hi = max(A) + 1000
    for _ in range(2000):
        candidates.append(random.randint(lo, hi))
    random.shuffle(candidates)
    for x in candidates:
        if time.time() > deadline:
            break
        if x in best:
            continue
        cand = best + [x]
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s
    return best

def solve():
    deadline = time.time() + 110
    A = _build_initial()
    # Trim / augment using local search.
    A = _greedy_add(A, min(time.time() + 20, deadline))
    A = _greedy_improve(A, min(time.time() + 70, deadline))
    A = _greedy_add(A, deadline)
    # Final local cleanup: try replacing elements with nearby values.
    best = list(set(A))
    best_score = _score(best)
    while time.time() < deadline:
        cand = best[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-2, 2)
        cand = list(set(cand))
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s
    return sorted(set(best))
