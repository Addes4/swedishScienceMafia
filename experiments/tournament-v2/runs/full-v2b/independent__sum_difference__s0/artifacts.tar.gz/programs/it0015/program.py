import math
import random
import time

def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)

def solve():
    best = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    best_score, _, _ = _stats(best)
    cur = best[:]
    deadline = time.time() + 110.0

    # Local search over additive structure.
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-6, 6)
        elif r < 0.80:
            cand.append(random.randint(-40, 40))
        elif r < 0.90 and len(cand) > 3:
            del cand[random.randrange(len(cand))]
        else:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-20, -10, -5, 5, 10, 20])

        cand = sorted(set(cand))
        if not (2 <= len(cand) <= 4000):
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue

        s, _, _ = _stats(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]

    return sorted(set(best))
