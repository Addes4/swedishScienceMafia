import math
import random
import time


def _stats(a):
    n = len(a)
    if n < 2:
        return 1, 1
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for j in range(i, n):
            y = a[j]
            diffs.add(x - y)
            diffs.add(y - x)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score(a):
    n = len(a)
    if n < 2:
        return -1e9
    d, s = _stats(a)
    if s <= 1:
        return -1e9
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _score_fast(a, sample=48):
    n = len(a)
    if n < 2:
        return -1e9
    ds = set()
    ss = set()
    if n <= sample:
        idx = range(n)
    else:
        idx = random.sample(range(n), sample)
    for i in idx:
        x = a[i]
        for j in idx:
            y = a[j]
            ds.add(x - y)
            ss.add(x + y)
    if len(ss) < 2:
        return -1e9
    scale = n / max(1, len(idx))
    return math.log(max(1, len(ds) * scale)) / math.log(max(2, len(ss) * scale)) + (1.0 - 1.0 / n) / 100.0


def _greedy_sidonish(n, limit):
    a = [0, 1]
    used_d = {1, -1, 0}
    used_s = {0, 1, 2}
    x = 2
    while len(a) < n and x <= limit:
        ok = True
        for y in a:
            d1 = x - y
            d2 = y - x
            s1 = x + y
            if d1 in used_d or d2 in used_d or s1 in used_s:
                ok = False
                break
        if ok:
            for y in a:
                used_d.add(x - y)
                used_d.add(y - x)
                used_s.add(x + y)
            used_d.add(0)
            used_s.add(2 * x)
            a.append(x)
        x += 1
    return a


def _residue_set(p, n):
    vals = []
    for x in range(1, p):
        v = (x * x) % p
        if v > p // 2:
            v -= p
        vals.append(v)
    vals = sorted(set(vals))
    if len(vals) > n:
        step = len(vals) / n
        vals = [vals[int(i * step)] for i in range(n)]
    return vals


def _local_improve(a, deadline, target_n):
    n = len(a)
    if n < 2:
        return a
    best = a[:]
    best_s = _score(best)
    cur = a[:]
    cur_s = best_s
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.55 and len(cand) >= 2:
            i = random.randrange(len(cand))
            span = max(1, int(1 + abs(cand[i]) * 0.05))
            cand[i] += random.randint(-span, span)
        elif op < 0.8:
            i = random.randrange(len(cand))
            j = random.randrange(len(cand))
            cand[i], cand[j] = cand[j], cand[i]
        elif op < 0.9 and len(cand) < target_n:
            cand.append(random.randint(-max(1, abs(cand[-1])), max(1, abs(cand[-1]))))
        elif len(cand) > 6:
            cand.pop(random.randrange(len(cand)))
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > target_n:
            cand = cand[:target_n]
        if random.random() < 0.3:
            s = _score_fast(cand)
        else:
            s = _score(cand)
        if s > cur_s or (s == cur_s and random.random() < 0.5):
            cur = cand
            cur_s = s
            if s > best_s:
                best, best_s = cand[:], s
    return best


def solve():
    start = time.time()
    deadline = start + 115

    candidates = []

    # Baseline handcrafted set with good ratio.
    candidates.append([7, 15, 18, 22, -3, -2])

    # Small Sidon-ish greedy sets.
    for n in (8, 12, 16, 20, 24, 30, 40, 60):
        g = _greedy_sidonish(n, 2000)
        if len(g) >= 2:
            candidates.append(g)

    # Quadratic residue sets: often extremely good ratio.
    for p in (101, 211, 401, 809, 1601, 3203, 6421, 12829, 25601, 51203):
        n = min(4000, max(2, p // 2))
        r = _residue_set(p, n)
        if len(r) >= 2:
            candidates.append(r)

    # A few powers/smooth variants.
    for k in (10, 12, 14, 16, 20, 30):
        a = [i * i for i in range(1, k + 1)]
        candidates.append(a)

    best = None
    best_s = -1e9
    for c in candidates:
        if len(c) < 2:
            continue
        c = sorted(set(c))
        s = _score(c)
        if s > best_s:
            best_s = s
            best = c

    # Spend remaining time on local search from several good starting points.
    pool = []
    for c in candidates:
        c = sorted(set(c))
        if len(c) >= 2:
            sc = _score(c) if len(c) <= 400 else _score_fast(c, 80)
            pool.append((sc, c))
    pool.sort(reverse=True)
    pool = [c for _, c in pool[:6]]

    # Add a big residue-based set as a large-n contender.
    big = _residue_set(51203, min(4000, 25601))
    if len(big) >= 2:
        pool.append(big)
    gb = _greedy_sidonish(120, 20000)
    if len(gb) >= 2:
        pool.append(gb)

    t = time.time()
    i = 0
    while t < deadline:
        base = pool[i % len(pool)]
        i += 1
        remain = deadline - time.time()
        if remain <= 0:
            break
        target_n = len(base)
        if random.random() < 0.3:
            target_n = min(4000, max(2, int(target_n * random.uniform(0.8, 1.5))))
        cand = _local_improve(base, min(time.time() + max(0.5, remain / 3.0), deadline), target_n)
        s = _score(cand)
        if s > best_s:
            best_s = s
            best = cand
            pool[i % len(pool)] = cand

    if best is None or len(best) < 2:
        return [0, 1]
    return sorted(set(best))
