import math
import random
import time

def _score(a):
    a_list = list(a)
    n = len(a_list)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a_list:
        for y in a_list:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _score_fast(a_list):
    n = len(a_list)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        x = a_list[i]
        for j in range(n):
            y = a_list[j]
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def geometric_set(k):
    # A = {2^i : i=0..k-1}. Differences all distinct? 2^i - 2^j unique.
    # Sums: 2^i + 2^j, collisions possible but many sums.
    return [1 << i for i in range(k)]

def solve():
    deadline = time.time() + 110
    
    # Try geometric progression - known to have |A+A| ~ k^2/2 and |A-A| ~ k^2
    # Actually for geometric, differences are unique (k^2 values), sums may collide.
    best = None
    best_score = -1.0
    
    # Try powers of 2
    for k in range(2, 60):
        a = geometric_set(k)
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a
    
    # Try other bases
    for base in range(3, 8):
        for k in range(2, 40):
            a = [base ** i for i in range(k)]
            if max(a) > 10**15:
                break
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a
    
    # Local search polish
    if best is None:
        best = [1, 2, 4, 8, 16]
        best_score = _score(best)
    
    cur = best[:]
    
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.4 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-3, 3)
        elif op < 0.6 and len(cand) < 60:
            # add a new element
            cand.append(random.choice(cand) + random.choice(cand))
        elif op < 0.75 and len(cand) > 3:
            # remove
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # perturb multiple
            for _ in range(random.randint(1, 3)):
                if cand:
                    i = random.randrange(len(cand))
                    cand[i] += random.randint(-2, 2)
        
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        if max(abs(x) for x in cand) > 10**15:
            continue
        if len(cand) > 4000:
            continue
        s = _score_fast(cand)
        if s >= best_score:
            best = cand[:]
            best_score = s
            cur = cand
        elif random.random() < 0.05:
            cur = best[:]
    
    return sorted(set(best))
