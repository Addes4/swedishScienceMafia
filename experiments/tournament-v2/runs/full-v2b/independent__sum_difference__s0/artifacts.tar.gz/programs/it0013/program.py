import math

def solve():
    # Geometric progression with ratio 2, largest possible n so that 2^(n-1) <= 1e15.
    # 2^49 ≈ 5.63e14 <= 1e15, so n=50.
    n = 50
    A = [1 << i for i in range(n)]
    return A
