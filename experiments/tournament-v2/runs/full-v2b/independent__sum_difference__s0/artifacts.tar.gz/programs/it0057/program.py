import math
import random
import time
from bisect import bisect_left

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def solve():
    random.seed(12345)
    best = None
    best_score = -1e9

    # Try the powers-of-two-like construction scaled: A = {1,2,4,...} capped size.
    # |A+A| can be reduced by making it "sum-collision" heavy.
    # A very effective family: take a Sidon set S (all diffs distinct) and
    # build A = S. Sidon sets maximize diffs; to shrink sums we want A symmetric-ish.
    # Actually the key: A = {b_i} where differences are many and sums collapse.
    # A classic trick: A with many pairs giving the same sum => A arithmetic-ish,
    # but that kills diffs. The strong known example: {2^0,...,2^(n-1)} gives
    # |diff| = n(n-1)+1, |sum| ~ n(n+1)/2 roughly. ratio ~ 2.

    # Let's just do a strong randomized local search with an efficient scorer.

    def fast_stats(a):
        a = list(a)
        n = len(a)
        ds = set()
        ss = set()
        for i in range(n):
            ai = a[i]
            for j in range(n):
                ds.add(ai - a[j])
                ss.add(ai + a[j])
        return len(ds), len(ss)

    def sc(a):
        n = len(a)
        if n < 2:
            return -1e9, 0, 0
        d, s = fast_stats(a)
        if s == 0:
            return -1e9, d, s
        return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s

    # Seed candidates
    seeds = []
    # powers of two
    for k in range(2, 13):
        seeds.append([2**i for i in range(k)])
    # random dense
    for _ in range(20):
        k = random.randint(4, 9)
        seeds.append(random.sample(range(-30, 31), k))
    # arithmetic
    for k in range(3, 12):
        seeds.append([i * 2 for i in range(k)])

    for s in seeds:
        s = sorted(set(s))
        if len(s) < 2:
            continue
        val, d, sm = sc(s)
        if val > best_score:
            best_score = val
            best = s[:]

    deadline = time.time() + 110

    # Local search with SA, maintaining a current state.
    # To keep it fast, cap sizes.
    MAXN = 60

    def perturb(cur):
        c = cur[:]
        r = random.random()
        if r < 0.5 and c:
            # shift one element
            i = random.randrange(len(c))
            c[i] += random.randint(-5, 5)
        elif r < 0.75:
            # add
            if len(c) < MAXN:
                c.append(random.randint(-60, 60))
        else:
            # remove
            if len(c) > 3:
                i = random.randrange(len(c))
                c.pop(i)
        return c

    cur = best[:]
    cur_val = best_score
    T = 0.5
    it = 0
    while time.time() < deadline:
        it += 1
        cand = perturb(cur)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        v, d, sm = sc(cand)
        if v > cur_val or random.random() < math.exp((v - cur_val) / max(T, 1e-9)):
            cur = cand
            cur_val = v
            if v > best_score:
                best_score = v
                best = cand[:]
        # cool down / reheat cycle
        if it % 3000 == 0:
            T *= 0.85
            if T < 0.01:
                T = 0.5
                # restart from best
                cur = best[:]
                cur_val = best_score
    return sorted(set(best))
