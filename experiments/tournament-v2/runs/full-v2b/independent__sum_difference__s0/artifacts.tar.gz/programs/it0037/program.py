import math
import random
import time

def _diffs(a):
    return {x - y for x in a for y in a}

def _sums(a):
    return {x + y for x in a for y in a}

def _score(a):
    if len(a) < 2:
        return -1e18
    d = len(_diffs(a))
    s = len(_sums(a))
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100

def _full_score(a):
    n = len(a)
    if n < 2:
        return -1e18, 0, 0
    d = len(_diffs(a))
    s = len(_sums(a))
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s

def solve():
    random.seed(12345)
    best = None
    best_score = -1e18
    deadline = time.time() + 110

    # Candidate constructions to seed annealing
    seeds = []

    # Sidon set generators (greedy) over bounded range
    def greedy_sidon(n, bound):
        S = []
        used_diffs = set()
        # also track sums to encourage collision potential: not strictly
        candidates = list(range(0, bound))
        random.shuffle(candidates)
        for c in candidates:
            ok = True
            newd = set()
            for s in S:
                d1 = c - s
                d2 = s - c
                if d1 in used_diffs or d2 in used_diffs:
                    ok = False
                    break
                newd.add(d1)
                newd.add(d2)
            if ok:
                S.append(c)
                used_diffs |= newd
                if len(S) >= n:
                    break
        return S

    for n in range(4, 13):
        for bound in (max(2 * n, 10), 4 * n, 8 * n, 16 * n):
            for _ in range(3):
                seeds.append(greedy_sidon(n, bound))

    # small hand seeds
    seeds.append([0, 1, 3, 8, 12])
    seeds.append([7, 15, 18, 22, -3, -2])
    seeds.append([0, 1, 4, 10, 18])
    seeds.append([0, 1, 4, 9, 15, 22])

    def evaluate(a):
        a = sorted(set(a))
        return a, _full_score(a)

    for seed in seeds:
        a, sc = evaluate(seed)
        if sc[0] > best_score:
            best_score = sc[0]
            best = a[:]

    # Annealing / hill-climb
    neighbors_pool = [-5, -4, -3, -2, -1, 1, 2, 3, 4, 5]

    cur = best[:]
    cur_score = best_score
    t0 = time.time()
    it = 0
    temp = 2.0

    while time.time() < deadline:
        it += 1
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            # perturb element
            i = random.randrange(len(cand))
            cand[i] += random.choice(neighbors_pool)
        elif r < 0.75:
            # add element
            if len(cand) < 4000:
                cand.append(random.randint(-20, 20))
        elif r < 0.9:
            # remove element
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        else:
            # shift whole set
            k = random.randint(-3, 3)
            cand = [x + k for x in cand]

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        # slow cooling, restart occasionally
        T = max(0.001, temp * (1 - (time.time() - t0) / max(1.0, deadline - t0)))
        if sc >= cur_score or random.random() < math.exp((sc - cur_score) / max(T, 1e-6)):
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = cand[:]

        # periodic restart from best with temp reheat
        if it % 20000 == 0:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
