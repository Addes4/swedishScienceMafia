import math
import random
import time
from bisect import bisect_left

def _eval(a):
    n = len(a)
    if n < 2:
        return -1e18, 0, 0
    A = a
    diffs = set()
    sums = set()
    # vectorized-ish loops via local refs
    for i in range(n):
        ai = A[i]
        for j in range(n):
            diffs.add(ai - A[j])
            sums.add(ai + A[j])
    nd, ns = len(diffs), len(sums)
    if ns <= 1:
        return -1e18, nd, ns
    sc = math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0
    return sc, nd, ns

def solve():
    random.seed(123456789)
    deadline = time.time() + 118.0

    best = None
    best_score = -1e18

    # seed candidates
    seeds = []

    # Golomb-like greedy: start from {0}, repeatedly add smallest integer
    # that keeps all pairwise differences mostly unique up to reflection.
    def golomb_like(target_n):
        S = [0]
        used = {0}
        diffset = set()
        while len(S) < target_n and time.time() < deadline:
            # candidate offsets: small positives and also some negatives
            best_c = None
            best_key = None
            # try a range of candidates
            lo = -3 * target_n - 5
            hi = 3 * target_n + 5
            step = 1 if target_n < 40 else 1
            cands = list(range(1, 3 * target_n + 10))
            random.shuffle(cands)
            cands = cands[:200]
            for c in cands:
                if c in used:
                    continue
                newd = set()
                ok = True
                for s in S:
                    d1 = c - s
                    d2 = s - c
                    newd.add(d1)
                    newd.add(d2)
                # count collisions
                coll = 0
                for d in newd:
                    if d in diffset:
                        coll += 1
                key = (coll, abs(c))
                if best_key is None or key < best_key:
                    best_key = key
                    best_c = c
                if coll == 0:
                    break
            if best_c is None:
                break
            S.append(best_c)
            used.add(best_c)
            for s in S[:-1]:
                diffset.add(best_c - s)
                diffset.add(s - best_c)
        return S

    for n in [6, 8, 10, 14, 20, 30, 40, 60, 90]:
        s = golomb_like(n)
        if len(s) >= 2:
            seeds.append(s)

    # random small dense-ish sets with skewed signs
    for _ in range(80):
        n = random.randint(5, 30)
        s = set()
        while len(s) < n:
            s.add(random.randint(-n * 2, n * 2))
        seeds.append(sorted(s))

    # highly compressible-sum constructions:
    # numbers near geometric-ish but with shared magnitudes
    for _ in range(40):
        n = random.randint(6, 25)
        s = set()
        while len(s) < n:
            s.add(random.choice([-1, 1]) * random.randint(0, n * 3))
        seeds.append(sorted(s))

    # Evaluate seeds
    for s in seeds:
        sc, nd, ns = _eval(s)
        if sc > best_score:
            best_score = sc
            best = s[:]

    # Local search: operations add/remove/shift/replace, accept by score
    cur = best[:]
    cur_score = best_score

    def rand_move(a):
        b = a[:]
        op = random.random()
        n = len(b)
        if op < 0.35 and n > 2:
            i = random.randrange(n)
            b[i] += random.choice([-7, -5, -3, -2, -1, 1, 2, 3, 5, 7]) * random.randint(1, 3)
        elif op < 0.6 and n > 2:
            i = random.randrange(n)
            del b[i]
        elif op < 0.9 and n < 400:
            # add near an existing point or in a magnitude range
            if b and random.random() < 0.7:
                x = random.choice(b)
                b.append(x + random.choice([-1, 1]) * random.randint(1, max(2, n)))
            else:
                b.append(random.randint(-n * 3, n * 3))
        else:
            # replace one element
            if n > 0:
                i = random.randrange(n)
                b[i] = random.choice([-1, 1]) * random.randint(0, n * 3)
        # dedupe
        b = list(set(b))
        return b

    no_improve = 0
    while time.time() < deadline:
        cand = rand_move(cur)
        if len(cand) < 2:
            continue
        sc, nd, ns = _eval(cand)
        if sc > cur_score or (random.random() < 0.03):
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
                no_improve = 0
            else:
                no_improve += 1
        else:
            no_improve += 1
        if no_improve > 4000:
            # restart from best with perturbation
            cur = best[:]
            for _ in range(random.randint(1, 3)):
                cur = rand_move(cur)
            cur_score, _, _ = _eval(cur)
            no_improve = 0

    # Final: try appending many shifted copies to grow set while keeping sums small?
    # Use a quick greedy extension maximizing score on top of best.
    improved = True
    while improved and time.time() < deadline:
        improved = False
        # try adding a value near existing span
        base = best[:]
        span = max(base) - min(base) if len(base) > 1 else 1
        for _ in range(200):
            if time.time() >= deadline:
                break
            c = random.choice(base) + random.choice([-1, 1]) * random.randint(1, max(2, span // 2 + 1))
            cand = list(set(base + [c]))
            sc, _, _ = _eval(cand)
            if sc > best_score:
                best = cand
                best_score = sc
                improved = True
                break

    best = sorted(set(best))
    return best
