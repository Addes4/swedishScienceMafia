import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    ds = len(diffs)
    ss = len(sums)
    if ss <= 1 or ds <= 1:
        return -1e9
    return math.log(ds) / math.log(ss) + (1.0 - 1.0 / n) / 100.0


def _full_score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) <= 1:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def solve():
    random.seed(12345)
    deadline = time.time() + 115.0

    # Candidate constructions.  The goal is to have |A-A| near n(n-1)+1 and |A+A| small.
    candidates = []

    # Geometric progression with ratio 2 or 3: differences can collide, but sums are limited.
    for base in (2, 3, 4, 5):
        m = 16
        A = [base ** i for i in range(m)]
        candidates.append(A)

    # Mixed geometric: high base helps differences, but too high base makes sums too numerous.
    A = []
    x = 1
    for i in range(18):
        A.append(x)
        x = x * 2 + 1
    candidates.append(A)

    # Powers of 3 shifted to be centered around 0.
    A = [3 ** i for i in range(17)]
    mn = sum(A) // len(A)
    candidates.append([x - mn for x in A])

    # Base 2 centered.
    A = [2 ** i for i in range(18)]
    mn = sum(A) // len(A)
    candidates.append([x - mn for x in A])

    # A construction with many differences: take rows of a triangular array.
    A = []
    for i in range(1, 18):
        A.append(i)
    candidates.append(A)

    # Sidon-like / greedy difference set: start with powers of 2, then add small shifts.
    best_seed = []
    best_seed_score = -1e9
    for A in candidates:
        s = _full_score(A)
        if s > best_seed_score:
            best_seed_score = s
            best_seed = list(set(A))

    best = list(set(best_seed))
    best_score = _full_score(best)
    cur = best[:]
    cur_score = best_score

    # Randomized local search.  We use incremental shortcuts for speed.
    step = 0
    while time.time() < deadline:
        step += 1
        cand = cur[:]
        r = random.random()
        if r < 0.45:
            # perturb one element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-8, 8)
            if abs(cand[i]) > 10**15:
                cand[i] %= 1000
        elif r < 0.70:
            # perturb two elements
            i = random.randrange(len(cand))
            j = random.randrange(len(cand))
            cand[i] += random.randint(-4, 4)
            cand[j] += random.randint(-4, 4)
        elif r < 0.85:
            # add an element
            if len(cand) < 300:
                base = cand[random.randrange(len(cand))]
                cand.append(base + random.randint(-30, 30))
        else:
            # remove an element
            if len(cand) > 6:
                del cand[random.randrange(len(cand))]

        cand = list(set(cand))
        if len(cand) > 4000:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue

        s = _full_score(cand)
        if s > best_score:
            best = cand[:]
            best_score = s
            cur = cand[:]
            cur_score = s
        elif s > cur_score or random.random() < 0.02:
            cur = cand[:]
            cur_score = s

        # occasional restart from best
        if step % 2000 == 0:
            cur = best[:]
            cur_score = best_score

    # Final polish: try all single-element replacements from a small neighborhood.
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for i in range(len(best)):
            original = best[i]
            base_score = best_score
            for delta in (-5, -4, -3, -2, -1, 1, 2, 3, 4, 5):
                trial = best[:]
                trial[i] = original + delta
                trial = list(set(trial))
                if len(trial) < 2:
                    continue
                s = _full_score(trial)
                if s > best_score:
                    best = trial
                    best_score = s
                    improved = True
                    break
            if improved:
                break

    return sorted(set(best))
