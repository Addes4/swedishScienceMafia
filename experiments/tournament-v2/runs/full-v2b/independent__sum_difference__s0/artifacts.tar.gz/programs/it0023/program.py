import math
import time
import random

# ---------- scoring ----------

def _score_parts(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, 0.0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for j in range(i, n):
            y = a[j]
            diffs.add(y - x)
            if i != j:
                diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls == 0:
        return ld, ls, 0.0
    sc = math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0
    return ld, ls, sc

# ---------- fast bitset difference/sum count for verification only ----------

def _score(a):
    return _score_parts(a)[2]

# ---------- construction: Singer difference sets / B_2 sequences ----------

def _singer_diffset_perfect(q):
    """Return a perfect difference set mod q^2+q+1 when q is a prime power.
    Here q must be a prime power.  Uses the classic Bose-Chowla construction."""
    # Bose-Chowla: take field GF(q^3)?  Simpler: use q prime and the
    # Singer construction via GF(q^3) multiplicative group.
    # We use q prime only for simplicity and reliability.
    n = q * q + q + 1
    # Build GF(q^3) as polynomials over GF(q) modulo an irreducible cubic.
    # Find irreducible cubic by brute force.
    def poly_mul_mod(a, b, mod, q):
        # a,b lists length <=3 (coeffs low->high), mod length 4 monic
        res = [0] * (len(a) + len(b) - 1)
        for i, ai in enumerate(a):
            if ai == 0:
                continue
            for j, bj in enumerate(b):
                res[i + j] = (res[i + j] + ai * bj) % q
        # reduce by mod
        d = len(mod) - 1
        for i in range(len(res) - 1, d - 1, -1):
            c = res[i] % q
            if c:
                res[i] = 0
                for k in range(d + 1):
                    res[i - d + k] = (res[i - d + k] - c * mod[k]) % q
        res = res[:d]
        while len(res) < d:
            res.append(0)
        return res

    def poly_pow(a, e, mod, q):
        r = [1] + [0] * (len(mod) - 2)
        base = a[:]
        while e:
            if e & 1:
                r = poly_mul_mod(r, base, mod, q)
            base = poly_mul_mod(base, base, mod, q)
            e >>= 1
        return r

    # find irreducible monic cubic x^3 + c2 x^2 + c1 x + c0
    mod = None
    for c2 in range(q):
        for c1 in range(q):
            for c0 in range(q):
                cand = [c0, c1, c2, 1]  # monic
                # check irreducible: x^(q^3) == x mod cand and no smaller
                # simplest: no root in GF(q) and not product of linear*quadratic
                # for cubic: irreducible iff no root in GF(q)
                has_root = False
                for r in range(q):
                    val = (r * r * r + c2 * r * r + c1 * r + c0) % q
                    if val == 0:
                        has_root = True
                        break
                if not has_root:
                    mod = cand
                    break
            if mod:
                break
        if mod:
            break
    if mod is None:
        return None

    # primitive element: find generator of GF(q^3)*
    def is_primitive(g, mod, q):
        order = q ** 3 - 1
        # check g^(order/p) != 1 for all prime p | order
        n2 = order
        ps = set()
        d = 2
        while d * d <= n2:
            if n2 % d == 0:
                ps.add(d)
                while n2 % d == 0:
                    n2 //= d
            d += 1
        if n2 > 1:
            ps.add(n2)
        one = [1] + [0] * (len(mod) - 2)
        for p in ps:
            if poly_pow(g, order // p, mod, q) == one:
                return False
        return True

    gen = None
    for a1 in range(q):
        for a0 in range(q):
            g = [a0, a1, 1]  # must be degree 2 element != 0
            if g == [0, 0, 0]:
                continue
            if is_primitive(g, mod, q):
                gen = g
                break
        if gen:
            break
    if gen is None:
        return None

    # powers of gen
    powers = []
    cur = [1] + [0] * (len(mod) - 2)
    for i in range(q ** 3 - 1):
        powers.append(cur[:])
        cur = poly_mul_mod(cur, gen, mod, q)

    # primitive element of GF(q) is gen^((q^3-1)/(q-1))
    idx_base = (q ** 3 - 1) // (q - 1)
    base = powers[idx_base]

    # subgroup H = <base> of order q-1
    H = set()
    cur = [1] + [0] * (len(mod) - 2)
    for i in range(q - 1):
        H.add(tuple(cur))
        cur = poly_mul_mod(cur, base, mod, q)

    # Singer difference set: exponents i s.t. gen^i in coset H+1 ... classic:
    # D = { i : gen^i = base^k + 1 for some k } mod (q^2+q+1)
    # Compute set of (base^k + 1) for k=0..q-2, as field elements, then indices.
    field_index = {}
    for i, p in enumerate(powers):
        field_index[tuple(p)] = i

    one = [1, 0, 0][:len(mod) - 1]
    D = set()
    cur = [1] + [0] * (len(mod) - 2)
    for k in range(q - 1):
        # cur = base^k, add 1
        val = cur[:]
        val[0] = (val[0] + 1) % q
        if tuple(val) in field_index:
            D.add(field_index[tuple(val)])
        cur = poly_mul_mod(cur, base, mod, q)
    return sorted(D), n

def _diffset_seq(q):
    """Perfect difference set in Z_n where n=q^2+q+1.  Return list of integers 0..n-1."""
    if q < 2:
        return [0]
    if q == 2:
        return [0, 1, 3]
    if q == 3:
        return [0, 1, 3, 9]
    if q == 4:
        return [0, 1, 3, 7, 12, 20]  # not perfect; fallback
    if q == 5:
        return [0, 1, 3, 8, 12, 23]  # (5,6,2) not perfect but decent
    res = _singer_diffset_perfect(q)
    if res is None:
        return None
    D, n = res
    return D

# ---------- known / fallback good difference sets ----------

def _golomb_ruler_greedy(n, limit=None):
    m = limit or (n * n + n + 1)
    marks = [0, 1]
    used = {1}
    for _ in range(n - 2):
        best = None
        best_used = None
        for c in range(marks[-1] + 1, m + 1):
            new = {abs(c - x) for x in marks}
            if new & used:
                continue
            nu = used | new
            if best is None or len(nu) > best_used:
                best = c
                best_used = len(nu)
                if best_used == (len(marks) + 2) * (len(marks) + 1) // 2:
                    break
        if best is None:
            break
        marks.append(best)
        used = best_used
    return marks

# ---------- main construction ----------

def _build_candidate():
    """Try several constructions, keep the best by score."""
    cands = []

    # perfect difference sets (Sidon sets mod v):  A = {0,1,...,n-1} mapped to subset
    # We want a real integer set.  Perfect difference set mod v gives all v diffs,
    # but as a subset of [0,v) it has at most v-1 nonzero diffs (since max-min < v)
    # Actually taking D itself gives diffs equal to all of Z_v \ {0} represented
    # as integers => exactly n(n-1) nonzero differences, so |D-D| = n(n-1)+1.
    for q in [2,3,4,5,7,8,9,11,13,16,17,19,23,25,27,29,31,32,37]:
        D = _diffset_seq(q)
        if D:
            cands.append(D)

    # known good small sets
    cands.append([0, 1, 3, 7, 15, 31, 63, 127, 255, 511])          # powers of 2
    cands.append([0, 1, 4, 10, 18, 23, 25])                        # small
    cands.append([0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96, 122, 147, 181, 203, 251, 289, 360, 371, 455, 510])
    cands.append([i * i for i in range(20)])                        # squares
    # Singer-like via quadratic residues
    for p in [7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53]:
        qr = set((i * i) % p for i in range(1, p))
        cands.append(sorted(qr))

    # Golomb ruler
    for n in [8, 10, 12, 14]:
        cands.append(_golomb_ruler_greedy(n))

    # Babcock / known B_2 sets
    cands.append([0, 1, 4, 9, 15, 22, 32, 34])
    cands.append([0, 1, 4, 10, 18, 23, 25, 32])
    cands.append([0, 1, 4, 9, 15, 22, 32, 34, 40])

    return cands

# ---------- shifts / scaling ----------

def _normalize(a):
    a = sorted(set(a))
    if not a:
        return a
    m = a[0]
    return [x - m for x in a]

def _try_scales_and_shifts(a, deadline):
    """Try scaling by k and translation to keep diffs same but sums may change;
    mainly try small perturbations."""
    a = sorted(set(a))
    best = a[:]
    best_sc = _score(best)
    n = len(best)
    if n < 2:
        return best, best_sc
    # small local search: move each element a little
    cur = best[:]
    cur_sc = best_sc
    step = 1
    cnt = 0
    while time.time() < deadline and cnt < 200000:
        cnt += 1
        idx = random.randrange(len(cur))
        old = cur[idx]
        delta = random.choice([-step, step, -2*step, 2*step])
        new = old + delta
        if new in cur:
            continue
        cand = cur[:]
        cand[idx] = new
        s = _score(cand)
        if s > cur_sc:
            cur, cur_sc = cand, s
            if s > best_sc:
                best, best_sc = cand[:], s
        # occasionally remove largest gap element
        if random.random() < 0.005 and len(cur) > 3:
            cand = cur[:]
            cand.pop(random.randrange(len(cand)))
            s = _score(cand)
            if s > best_sc:
                best, best_sc = cand[:], s
        if random.random() < 0.005:
            step = random.choice([1, 1, 1, 2, 3, 5])
    return best, best_sc

def _swap_search(a, deadline):
    """Greedy: try removing an element and/or adding a new one near existing elements."""
    a = sorted(set(a))
    best = a[:]
    best_sc = _score(best)
    improved = True
    while improved and time.time() < deadline:
        improved = False
        n = len(best)
        # try removing
        for i in range(n):
            cand = best[:i] + best[i+1:]
            s = _score(cand)
            if s > best_sc:
                best, best_sc = cand, s
                improved = True
                break
        if improved:
            continue
        # try adding
        lo = best[0] - (best[-1] - best[0]) // 2 - 1
        hi = best[-1] + (best[-1] - best[0]) // 2 + 1
        if hi - lo > 200000:
            cand_pts = random.sample(range(lo, hi), 500)
        else:
            cand_pts = range(lo, hi + 1)
        for c in cand_pts:
            if c in best:
                continue
            cand = sorted(best + [c])
            s = _score(cand)
            if s > best_sc:
                best, best_sc = cand, s
                improved = True
                break
        # try moving
        if not improved:
            w = max(1, (best[-1] - best[0]) // (len(best) + 1))
            for i in range(len(best)):
                for d in (-w, -1, 1, w):
                    cand = best[:]
                    cand[i] += d
                    if len(set(cand)) != len(cand):
                        continue
                    cand = sorted(cand)
                    s = _score(cand)
                    if s > best_sc:
                        best, best_sc = cand, s
                        improved = True
                        break
                if improved:
                    break
    return best, best_sc

def solve():
    deadline = time.time() + 110
    cands = _build_candidate()

    best = None
    best_sc = -1.0

    # score initial candidates
    for c in cands:
        c = _normalize(c)
        if len(c) < 2:
            continue
        s = _score(c)
        if s > best_sc:
            best, best_sc = c[:], s

    # improve best few
    if best is None:
        best = [0, 1, 3, 7, 15, 31, 63, 127, 255, 511]
        best_sc = _score(best)

    pool = []
    for c in cands:
        c = _normalize(c)
        if len(c) >= 2:
            pool.append((_score(c), c))
    pool.sort(key=lambda t: -t[0])
    pool = pool[:12]

    # Also add known large-ish candidates
    import itertools
    for base_list in [
        [0, 1, 3, 7, 12, 20],
        [0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047],
    ]:
        pool.append((_score(base_list), base_list))

    per = max(1.0, (deadline - time.time()) / max(1, len(pool)))
    for sc0, base in pool:
        if time.time() >= deadline:
            break
        t_end = min(deadline, time.time() + per)
        b1, s1 = _try_scales_and_shifts(base, t_end)
        if s1 > best_sc:
            best, best_sc = b1[:], s1
        if time.time() < deadline:
            t_end2 = min(deadline, time.time() + per * 0.6)
            b2, s2 = _swap_search(b1, t_end2)
            if s2 > best_sc:
                best, best_sc = b2[:], s2

    best = sorted(set(best))
    # final safeguard
    if len(best) < 2:
        best = [0, 1]
    best = [int(x) for x in best]
    # ensure bound
    best = [x for x in best if abs(x) <= 10**15]
    if len(best) < 2:
        best = [0, 1]
    return best
