import math
import random
import time


def _score_parts(a):
    if len(a) < 2:
        return 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score(a):
    d, s = _score_parts(a)
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def solve():
    random.seed(1234567)
    deadline = time.time() + 115

    # Start from a known good construction: large Sidon-like set.
    # Use powers-of-2-ish separated blocks so differences are plentiful
    # but sums stay mostly unique.
    n_target = 900
    base = 1000003  # large base to keep sums mostly distinct

    # Build initial set: modular Sidon construction with perturbation.
    A = set()
    # Core: greedy Sidon-ish sequence with many differences
    q = 2 * n_target + 10
    for i in range(n_target):
        A.add((i * i) % q + i * base)
    # Ensure distinct
    A = list(A)

    # Greedy add points to maximize difference growth while limiting sum growth.
    candidates = list(range(-5000, 5000))
    random.shuffle(candidates)

    def try_add(arr, v):
        if v in arr:
            return None
        new = arr + [v]
        d, s = _score_parts(new)
        return d, s, new

    # Local optimization
    best = A[:]
    bd, bs = _score_parts(best)
    best_score = math.log(bd) / math.log(bs) + (1 - 1 / len(best)) / 100

    cur = best[:]
    cd, cs = bd, bs

    iterations = 0
    while time.time() < deadline:
        iterations += 1
        cand = cur[:]
        op = random.random()

        if op < 0.5 and len(cand) > 2:
            # modify a random element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-50, 50)
        elif op < 0.8:
            # add a new element near existing ones
            if len(cand) < 4000:
                base_el = random.choice(cand)
                cand.append(base_el + random.randint(-2000, 2000))
        else:
            # remove an element
            if len(cand) > 3:
                cand.pop(random.randrange(len(cand)))

        # dedupe
        cand = list(set(cand))
        if len(cand) < 2:
            cur = best[:]
            cd, cs = bd, bs
            continue

        d, s = _score_parts(cand)
        if s <= 1:
            continue
        sc = math.log(d) / math.log(s) + (1 - 1 / len(cand)) / 100

        if sc >= best_score:
            best = cand[:]
            bd, bs = d, s
            best_score = sc
            cur = cand[:]
            cd, cs = d, s
        else:
            # simulated annealing-ish acceptance
            temp = max(0.001, 0.5 * (1 - min(1.0, (time.time() - (deadline - 115)) / 115)))
            if random.random() < math.exp((sc - best_score) / max(temp, 1e-9)):
                cur = cand[:]
                cd, cs = d, s
            if random.random() < 0.02:
                cur = best[:]
                cd, cs = bd, bs

    return sorted(set(best))
