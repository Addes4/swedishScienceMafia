import math
import time
import random

def solve():
    deadline = time.time() + 100.0

    # ---------- scoring helpers (only for search; final answer scored externally) ----------
    def score(A):
        if len(A) < 2:
            return -1e9
        s = set(A)
        n = len(A)
        # sums
        sumset = set()
        for i in range(n):
            ai = A[i]
            for j in range(i, n):
                sumset.add(ai + A[j])
        diffset = set()
        for i in range(n):
            ai = A[i]
            for j in range(n):
                diffset.add(ai - A[j])
        ls, ld = len(sumset), len(diffset)
        if ls <= 1 or ld <= 1:
            return -1e9
        return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0

    # ---------- candidate constructions ----------

    def make_sidon(k):
        # Classic greedy Sidon set: a_1=1, a_n = smallest > a_{n-1} with all pair sums distinct.
        S = [0]
        sums = {0}
        x = 0
        while len(S) < k:
            x += 1
            ok = True
            new_sums = []
            for s in S:
                t = x + s
                if t in sums:
                    ok = False
                    break
                new_sums.append(t)
            if ok:
                # also ensure x+x not conflicting (x+x = 2x)
                if 2 * x in sums:
                    ok = False
                if ok:
                    for t in new_sums:
                        sums.add(t)
                    sums.add(2 * x)
                    S.append(x)
        return S

    def make_sidon_fast(k):
        # Use the Singer/Bose-Chowla style from powers of 2 mod p approx? Use simple randomized greedy.
        # Fall back to a fast greedy using bit arrays via sets but skipping eagerly.
        S = [0]
        sums = {0}
        x = 0
        while len(S) < k:
            x += 1
            # Check x with S
            conflict = False
            for s in S:
                if (x + s) in sums:
                    conflict = True
                    break
            if conflict:
                continue
            if (2 * x) in sums:
                continue
            for s in S:
                sums.add(x + s)
            sums.add(2 * x)
            S.append(x)
        return S

    def build_ap_plus_sidon(m, k, gap):
        # A = S + {0, gap, 2*gap, ..., (k-1)*gap}
        S = make_sidon_fast(m) if m <= 60 else make_sidon_fast(min(m, 45))
        A = []
        for s in S:
            for t in range(k):
                A.append(s + t * gap)
        A = list(set(A))
        return A

    # Greedy construction: start from AP, add elements to enlarge difference set cheaply
    def greedy_expand(seed, target_n, time_limit):
        A = list(set(seed))
        end = time.time() + time_limit
        # maintain sum/diff sets incrementally
        sumset = set()
        diffset = set()
        n = len(A)
        for i in range(n):
            ai = A[i]
            for j in range(i, n):
                sumset.add(ai + A[j])
            for j in range(n):
                diffset.add(ai - A[j])

        # candidate new elements: multiples/certain pattern depending on structure
        # try random candidates, prefer those that add many diffs and few sums
        tries = 0
        best_local = A[:]
        while time.time() < end and len(A) < target_n:
            tries += 1
            # propose candidate
            if random.random() < 0.7 and A:
                base = random.choice(A)
                cand = base + random.randint(-5, 5)
                if cand in A:
                    continue
            else:
                cand = random.randint(-200, 200)
                if cand in A:
                    continue
            new_diffs = 0
            for a in A:
                if (cand - a) not in diffset:
                    new_diffs += 1
                if (a - cand) not in diffset:
                    new_diffs += 1
            new_sums = 0
            for a in A:
                if (cand + a) not in sumset:
                    new_sums += 1
                if (a + cand) not in sumset:
                    new_sums += 1
            if 2 * cand not in sumset:
                new_sums += 1
            # potential gain in ratio (log scale): accept if improves rough estimate
            old_ls = len(sumset)
            old_ld = len(diffset)
            new_ls = old_ls + new_sums
            new_ld = old_ld + new_diffs
            if new_ls <= 1 or new_ld <= 1:
                continue
            # local ratio + tiny size bonus
            old_n = len(A)
            new_n = old_n + 1
            old_val = math.log(max(old_ld, 2)) / math.log(max(old_ls, 2)) + (1.0 - 1.0 / old_n) / 100.0
            new_val = math.log(max(new_ld, 2)) / math.log(max(new_ls, 2)) + (1.0 - 1.0 / new_n) / 100.0
            if new_val > old_val:
                # add
                for a in A:
                    diffset.add(cand - a)
                    diffset.add(a - cand)
                    sumset.add(cand + a)
                sumset.add(2 * cand)
                A.append(cand)

        return A

    # ---------- try a few parameter combos quickly, pick best ----------

    best = None
    best_val = -1e18

    def consider(A):
        nonlocal best, best_val
        if not A:
            return
        A = list(set(A))
        v = score(A) if len(A) <= 400 else None
        if v is None:
            # fast approximate for large
            n = len(A)
            sumset = set()
            for i in range(n):
                ai = A[i]
                for j in range(i, n):
                    sumset.add(ai + A[j])
            diffset = set()
            for i in range(n):
                ai = A[i]
                for j in range(n):
                    diffset.add(ai - A[j])
            ls, ld = len(sumset), len(diffset)
            if ls <= 1 or ld <= 1:
                return
            v = math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0
        if v > best_val:
            best_val = v
            best = A[:]

    # AP + Sidon with gap chosen to avoid overlaps
    for m, k in [(5, 30), (7, 25), (8, 20), (10, 15), (12, 12), (15, 10), (18, 8), (20, 7), (25, 6), (30, 5), (40, 4), (50, 4)]:
        gap = 10 * m  # big enough likely
        try:
            A = build_ap_plus_sidon(m, k, gap)
            consider(A)
        except Exception:
            pass
        if time.time() > deadline - 75:
            break

    # pure AP (small sumset)
    for n in [5, 10, 20, 40, 80, 160]:
        A = list(range(n))
        consider(A)
        A = [2 * i for i in range(n)]
        consider(A)

    # dense interval with holes: consecutive integers, very good diff set (|A-A|=2n-1) but sumset 2n-1 too ratio ~1
    # AP has ratio ~1, need structure.

    # Greedy from AP + a few scattered points
    seed = list(range(0, 20))
    seed += [random.randint(-500, 500) for _ in range(10)]
    seed = list(set(seed))
    if time.time() < deadline - 60:
        A = greedy_expand(seed, 200, min(30.0, deadline - time.time() - 30))
        consider(A)

    # Greedy from Sidon+AP seed
    seed = build_ap_plus_sidon(8, 10, 80)
    if time.time() < deadline - 50:
        A = greedy_expand(seed, 300, min(25.0, deadline - time.time() - 20))
        consider(A)

    # Random restart greedy
    while time.time() < deadline - 15:
        seed = [random.randint(-100, 100) for _ in range(15)]
        seed = list(set(seed))
        A = greedy_expand(seed, 150, min(10.0, deadline - time.time() - 5))
        consider(A)

    # small local search on best
    if best is None:
        best = [0, 1, 3, 7, 12, 20, 30, 44]

    A = list(best)
    cur_val = score(A) if len(A) <= 300 else best_val
    end = time.time() + 5.0
    while time.time() < end:
        cand = A[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice([-2, -1, 1, 2, -10, 10])
        cand = list(set(cand))
        if len(cand) > 4000:
            continue
        v = score(cand) if len(cand) <= 300 else None
        if v is not None and v > cur_val:
            A, cur_val = cand, v

    # final: try to minimise sumset by shifting best into AP-like while keeping diffs
    res = list(set(A))
    res = [x for x in res if -10**15 <= x <= 10**15]
    if len(res) < 2:
        res = [0, 1]
    return res
