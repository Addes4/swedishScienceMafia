import math
import random
import time
from functools import lru_cache


def _diff_count(a):
    a = list(a)
    n = len(a)
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    return len(diffs)


def _sum_count(a):
    a = list(a)
    n = len(a)
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    return len(sums)


def _score_ratio(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    d = _diff_count(a)
    s = _sum_count(a)
    if s <= 1 or d <= 1:
        return 0.0
    return math.log(d) / math.log(s)


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    d = _diff_count(a)
    s = _sum_count(a)
    if s <= 1 or d <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _fast_score_pair(a):
    """Return (log|D|, log|S|) for a sorted list a."""
    n = len(a)
    a = list(a)
    # compute diff count efficiently with sorting trick
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    return math.log(len(diffs)), math.log(len(sums))


def _construct_geometric():
    """Try bases that give structured sums."""
    best = None
    best_score = -1
    candidates_bases = [2, 3, 4, 5, 6, 7, 8, 9, 10]
    for base in candidates_bases:
        for n in range(2, 30):
            a = [base ** i for i in range(n)]
            # remove duplicates
            a = list(set(a))
            if len(a) != n:
                continue
            sc = _score(a)
            if sc > best_score:
                best_score = sc
                best = a[:]
            # try shifted version
            a2 = [x - (base ** n) // 2 for x in a]
            sc2 = _score(a2)
            if sc2 > best_score:
                best_score = sc2
                best = a2[:]
    return best, best_score


def _greedy_extend(seed, time_limit):
    """Greedily add elements near the convex hull / scaled versions to improve ratio."""
    best = sorted(set(seed))
    best_score = _score(best)
    deadline = time.time() + time_limit
    a = best[:]
    # candidate pool: scaled versions of current elements plus small perturbations
    while time.time() < deadline:
        improved = False
        # Generate candidates from current set
        cand_pool = set()
        maxv = max(abs(x) for x in a) if a else 1
        # try adding scaled copies
        for x in a:
            for mult in [2, 3, -1, -2, -3]:
                v = x * mult
                if abs(v) <= 10**15:
                    cand_pool.add(v)
        # try sums and differences of pairs (may create structured new elements)
        m = len(a)
        for i in range(m):
            for j in range(i + 1, m):
                cand_pool.add(a[i] + a[j])
                cand_pool.add(a[i] - a[j])
                if len(cand_pool) > 500:
                    break
            if len(cand_pool) > 500:
                break
        # small perturbations
        for x in a:
            for delta in [-3, -2, -1, 1, 2, 3]:
                cand_pool.add(x + delta)
        cand_pool = [c for c in cand_pool if abs(c) <= 10**15 and c not in set(a)]
        random.shuffle(cand_pool)
        cand_pool = cand_pool[:200]
        local_best = best_score
        local_a = a[:]
        for c in cand_pool:
            if time.time() > deadline:
                break
            trial = a + [c]
            if len(trial) > 4000:
                break
            sc = _score(trial)
            if sc > local_best:
                local_best = sc
                local_a = trial
        if local_best > best_score:
            best_score = local_best
            best = local_a[:]
            a = local_a[:]
            improved = True
        if not improved:
            # try swapping: replace worst-contributing element with a new one
            # identify element whose removal least hurts
            if len(a) > 3:
                worst_remove = None
                worst_drop = float('inf')
                for idx in range(len(a)):
                    trial = a[:idx] + a[idx+1:]
                    sc = _score(trial)
                    drop = best_score - sc
                    if drop < worst_drop:
                        worst_drop = drop
                        worst_remove = idx
                # try replace with candidate
                for c in cand_pool:
                    if time.time() > deadline:
                        break
                    trial = a[:worst_remove] + [c]
                    sc = _score(trial)
                    if sc > best_score:
                        best_score = sc
                        best = trial[:]
                        a = trial[:]
                        improved = True
                        break
        if not improved:
            break
    return best, best_score


def _local_search_perturb(seed, time_limit):
    """Random local search on top of seed."""
    best = sorted(set(seed))
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    deadline = time.time() + time_limit
    maxv = 10**15
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5:
            # mutate an element
            i = random.randrange(len(cand))
            scale = max(1, abs(cand[i]) // 10)
            delta = random.randint(-scale - 1, scale + 1)
            if delta == 0:
                delta = 1
            newval = cand[i] + delta
            if abs(newval) <= maxv:
                cand[i] = newval
        elif op < 0.8:
            # add an element
            if len(cand) < 4000:
                # add near an existing element or a scaled version
                base = random.choice(cand)
                mult = random.choice([1, 2, 3, -1, -2, -3])
                v = base * mult + random.randint(-2, 2)
                if abs(v) <= maxv and v not in set(cand):
                    cand.append(v)
        else:
            # remove an element
            if len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
        # dedupe
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc > cur_score or random.random() < 0.01:
            cur = cand
            cur_score = sc
        if sc > best_score:
            best = cand[:]
            best_score = sc
    return best, best_score


def solve():
    deadline = time.time() + 115

    # Phase 1: construct geometric-like sets
    best, best_score = _construct_geometric()

    # also try some hand-crafted structured sets
    hand_crafted = [
        [3**i for i in range(1, 15)],
        [2**i for i in range(1, 20)],
        list(range(1, 21)),
        [i * i for i in range(1, 21)],
        [i * i * i for i in range(1, 15)],
    ]
    for hc in hand_crafted:
        hc = sorted(set(hc))
        sc = _score(hc)
        if sc > best_score:
            best_score = sc
            best = hc[:]

    # Phase 2: greedy extension
    t_remaining = deadline - time.time()
    if t_remaining > 10:
        g, gs = _greedy_extend(best, min(t_remaining * 0.4, 40))
        if gs > best_score:
            best, best_score = g, gs

    # Phase 3: local search with perturbations
    t_remaining = deadline - time.time()
    if t_remaining > 5:
        ls, lss = _local_search_perturb(best, min(t_remaining - 2, 60))
        if lss > best_score:
            best, best_score = ls, lss

    # Final cleanup
    best = sorted(set(best))
    return best
