import math
import random
import time

# We build A as a union of small integer translates / dilates of a compact set.
# Key idea: if A is nearly an arithmetic progression, A+A is small (~2n-1)
# but A-A is also small (~2n-1). To get a large ratio, one wants A-A close
# to n^2 while A+A close to n-1. Perfectly that means a Sidon-ish set for
# differences but an arithmetic progression for sums; impossible in full
# generality, so we search.

def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0
    s = set()
    d = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            s.add(ai + aj)
            d.add(ai - aj)
    if len(s) == 0:
        return 0, 0
    return len(d), len(s)

def _score(a):
    d, s = _stats(a)
    if s == 0 or d == 0:
        return -1e9
    n = len(set(a))
    return math.log(d) / math.log(s) + (1 - 1.0 / n) / 100.0

# ---------- candidate constructors ----------

def make_ap_plus_holes(n, span, seed):
    rnd = random.Random(seed)
    vals = list(range(span))
    if span > n:
        vals = sorted(rnd.sample(vals, n))
    return vals

def make_shift_union(base, shifts, scale):
    A = set()
    for t in shifts:
        for x in base:
            A.add(scale * x + t)
    return sorted(A)

def make_cantor_like(n, levels, vanilla=False):
    # Build using sums of distinct digits in base b, with controlled products.
    # Try a multiplicative structure for differences and additive for sums.
    b = 3
    if levels <= 0:
        return [0]
    elems = [0]
    step = 1
    for _ in range(levels):
        new = []
        for x in elems:
            for c in range(b):
                new.append(x + c * step)
        elems = sorted(set(new))
        step *= b
        if len(elems) > n:
            break
    return elems[:n]

def make_sidon_base(n, bound, seed):
    # greedy Sidon set: all pairwise sums distinct (very good for differences)
    rnd = random.Random(seed)
    A = []
    sums = set()
    cands = list(range(bound))
    rnd.shuffle(cands)
    for x in cands:
        ok = True
        for y in A:
            if x + y in sums:
                ok = False
                break
        if ok:
            for y in A:
                sums.add(x + y)
            sums.add(2 * x)
            A.append(x)
            if len(A) >= n:
                break
    return sorted(A)

def make_b_ary_symmetric(n, b, levels):
    # numbers composed of digits {0,...,b-1} times increasing powers
    elems = [0]
    step = 1
    for _ in range(levels):
        new = []
        for x in elems:
            for c in range(b):
                new.append(x + c * step)
        elems = sorted(set(new))
        step *= b
        if len(elems) > n:
            break
    return elems[:n]

def make_moser_base():
    # Moser-de Bruijn sequence-ish: sums of distinct powers of 4
    elems = [0]
    p = 1
    for _ in range(8):
        elems = elems + [x + p for x in elems]
        p *= 4
    return elems

def make_union_dilated(base, m):
    return sorted(set(m * x for x in base) | set(x for x in base))

# ---------- local search ----------

def local_search(a, time_budget, seed):
    rnd = random.Random(seed)
    a = sorted(set(a))
    best = a[:]
    d, s = _stats(best)
    best_score = math.log(d) / math.log(s) + (1 - 1.0 / len(best)) / 100.0 if s > 0 else -1e9
    t0 = time.time()
    max_val = 10**12
    while time.time() - t0 < time_budget:
        cand = best[:]
        mode = rnd.random()
        if mode < 0.45 and len(cand) > 2:
            # tweak one element
            i = rnd.randrange(len(cand))
            delta = rnd.choice([-3, -2, -1, 1, 2, 3, 5, -5, 10, -10,
                                rnd.randint(-100, 100), rnd.randint(-1000, 1000)])
            cand[i] += delta
            if abs(cand[i]) > max_val:
                cand[i] = best[i]
        elif mode < 0.65:
            # insert a new element
            if len(cand) < 3999:
                base = rnd.choice(cand)
                off = rnd.choice([1, -1, 2, -2, 3, -3, 5, -5, 10, -10,
                                  rnd.randint(-1000, 1000)])
                v = base + off
                if abs(v) <= max_val and v not in cand:
                    cand.append(v)
        elif mode < 0.8 and len(cand) > 2:
            # delete an element
            i = rnd.randrange(len(cand))
            del cand[i]
        else:
            # shift / translate all (invariant for diff/sum sizes)
            # instead do symmetric pairing tweak: move two elems
            if len(cand) >= 2:
                i, j = rnd.randrange(len(cand)), rnd.randrange(len(cand))
                cand[i] += rnd.randint(-20, 20)
                cand[j] += rnd.randint(-20, 20)
                cand = [x for x in cand if abs(x) <= max_val]
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        d2, s2 = _stats(cand)
        if s2 == 0:
            continue
        sc = math.log(d2) / math.log(s2) + (1 - 1.0 / len(cand)) / 100.0
        if sc > best_score or (sc == best_score and len(cand) > len(best)):
            best = cand[:]
            best_score = sc
    return best, best_score

def solve():
    best = None
    best_score = -1e9
    deadline = time.time() + 118  # leave margin
    t_start = time.time()

    # Stage 1: cheap constructive seeds, evaluate them.
    seeds = []

    # Small known-ish dense ratio sets
    seeds.append([0, 1, 2, 4, 8, 16])  # powers of two: differences many, sums fewer
    seeds.append([0, 1, 3, 7, 15, 31, 63])
    seeds.append([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])  # AP
    p = [1]
    for _ in range(11):
        p.append(p[-1] * 2)
    seeds.append([0] + p)  # 0 and powers of two: doubles differences

    # Moser base
    try:
        seeds.append(make_moser_base())
    except Exception:
        pass

    # b-ary symmetric
    for b in [2, 3, 4, 5]:
        for lv in [4, 5, 6, 7]:
            try:
                c = make_b_ary_symmetric(4096, b, lv)
                if len(c) <= 4000:
                    seeds.append(c)
            except Exception:
                pass

    # cantor-like
    for lv in [4, 5, 6]:
        try:
            c = make_cantor_like(4000, lv)
            if len(c) <= 4000:
                seeds.append(c)
        except Exception:
            pass

    # Sidon base (small)
    for n in [8, 12, 16, 20]:
        for sd in range(3):
            try:
                c = make_sidon_base(n, 300, sd)
                seeds.append(c)
            except Exception:
                pass

    # Union dilated structures: differences grow, sums stay bounded-ish
    for base in [[0, 1, 2, 4, 8, 16], [0, 1, 3, 7, 15, 31], [0, 1, 2, 3, 5, 8, 13]]:
        for m in [3, 5, 7, 11, 13, 17, 19, 23, 31]:
            try:
                c = make_union_dilated(base, m)
                if len(c) <= 4000:
                    seeds.append(c)
            except Exception:
                pass

    # Shift unions: base + translates; sum-set controlled by translation spread
    bases = [
        [0, 1, 3, 7, 15],
        [0, 1, 2, 4, 8, 16],
        [0, 1, 3, 9, 27],
    ]
    for base in bases:
        for scale in [1, 2, 3, 5, 7]:
            for k in [2, 3, 4, 5]:
                shifts = [i * (scale * (max(base) + 1) + 1) for i in range(k)]
                try:
                    c = make_shift_union(base, shifts, scale)
                    if 2 <= len(c) <= 4000:
                        seeds.append(c)
                except Exception:
                    pass

    # Deduplicate seeds by frozenset
    uniq = {}
    for s in seeds:
        if not s:
            continue
        s = sorted(set(s))
        if len(s) < 2 or len(s) > 4000:
            continue
        key = tuple(s)
        if key not in uniq:
            uniq[key] = s
    seed_list = list(uniq.values())

    # Evaluate all seeds, keep top ones
    scored = []
    for s in seed_list:
        try:
            d, sm = _stats(s)
            if sm > 0 and d > 0:
                sc = math.log(d) / math.log(sm) + (1 - 1.0 / len(s)) / 100.0
                scored.append((sc, s))
        except Exception:
            pass
    scored.sort(key=lambda t: -t[0])

    for sc, s in scored[:20]:
        if sc > best_score:
            best_score = sc
            best = s[:]

    if best is None:
        best = [0, 1, 2, 4, 8, 16]
        best_score = _score(best)

    # Stage 2: local search from top seeds with time allocation
    remaining = deadline - time.time()
    if remaining > 0 and scored:
        top = [s for _, s in scored[:8]]
        if best not in top:
            top.append(best)
        per = max(1.0, remaining / (len(top) + 1))
        for s in top:
            if time.time() >= deadline:
                break
            tb = min(per, deadline - time.time())
            if tb <= 0:
                break
            cand, sc = local_search(s, tb, random.randrange(10**9))
            if sc > best_score or (abs(sc - best_score) < 1e-15 and len(cand) > len(best or [])):
                best = cand[:]
                best_score = sc

    # Stage 3: final polish on best within remaining time
    remaining = deadline - time.time()
    if remaining > 0 and best is not None:
        for _ in range(3):
            if time.time() >= deadline:
                break
            tb = min(remaining / 3.0, deadline - time.time())
            if tb <= 0:
                break
            cand, sc = local_search(best, tb, random.randrange(10**9))
            if sc > best_score or (abs(sc - best_score) < 1e-15 and len(cand) > len(best)):
                best = cand[:]
                best_score = sc

    if best is None:
        best = [0, 1, 2, 4, 8]
    best = sorted(set(best))
    # Safety: ensure within constraints
    best = [x for x in best if abs(x) <= 10**15]
    if len(best) > 4000:
        best = best[:4000]
    if len(best) < 2:
        best = [0, 1]
    return best
