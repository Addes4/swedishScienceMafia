import math
import random
import time

def _stats(a):
    # Use lists and local vars for speed; caller guarantees len>=2, distinct ints.
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)

def _score(a):
    if len(a) < 2:
        return 0.0
    nd, ns = _stats(a)
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100

def _candidate_pool(seed=12345, n=32):
    """Build a few deterministic candidate sets known to have good sum/difference tradeoffs."""
    rnd = random.Random(seed)
    cands = []

    # 1) Geometric-style / Powers-ish sets (difference rich).  Multiplicative scaling increases
    #    spread (large difference count) but sums tend to collide less than randomly if superincreasing.
    for _ in range(4):
        b = rnd.randint(2, 3)
        s = set()
        v = 1
        while len(s) < n:
            s.add(v)
            v = v * b + rnd.randint(0, 1)
        cands.append(sorted(s))

    # 2) Golomb ruler-ish: greedy B_2-like (Sidon) construction - large difference set, sums collide a lot but
    #    often |A+A| stays small enough.
    for _ in range(4):
        start = rnd.randint(0, 5)
        A = [start]
        used = {start}
        # greedy Sidon:  a+b = c+d only if {a,b}={c,d}
        def sidon_ok(A, x):
            sums = {}
            for i in range(len(A)):
                for j in range(i, len(A)):
                    sums.setdefault(A[i]+A[j], 0)
                    sums[A[i]+A[j]] += 1
            for a in A:
                k = a + x
                if k in sums:
                    # adding x creates new pair (a,x) plus maybe (x,a) - allow at most one existing for k
                    if sums[k] >= 2:
                        return False
            return True
        t = start + 1
        while len(A) < n and t < 2000:
            if t not in used and sidon_ok(A, t):
                A.append(t)
                used.add(t)
            t += 1
        if len(A) >= 6:
            cands.append(sorted(A))

    # 3) Arithmetic-like with perturbations: small sum set is obtained from AP, perturb to add differences.
    for _ in range(4):
        d = rnd.randint(1, 3)
        A = [i*d for i in range(n)]
        for _ in range(n):
            i = rnd.randrange(n)
            A[i] += rnd.randint(-d, d)
        A = sorted(set(A))
        if len(A) >= 6:
            cands.append(A)

    # 4) The classic {2^i} shifted to include negatives balancing sums
    for _ in range(3):
        A = [2**i for i in range(min(n, 20))]
        if A:
            m = A[-1] // 2
            A = [x - m for x in A]
        cands.append(sorted(set(A)))

    return cands

def solve():
    deadline = time.time() + 110
    rnd = random.Random(987654321)

    best = None
    best_score = -1.0

    # Evaluate candidate pool.
    pool = _candidate_pool(n=36)
    for c in pool:
        c = sorted(set(c))
        if len(c) < 2:
            continue
        s = _score(c)
        if s > best_score:
            best_score = s
            best = c[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # Local search: hill-climb with occasional restarts / perturbation.  We keep n around 30-60,
    # because the bonus term (1-1/|A|)/100 saturates and the logarithmic ratio is what matters.
    cur = best[:]
    cur_score = best_score

    # Precompute possible "target sizes" to try bigger n.
    size_options = [30, 40, 50, 60]

    while time.time() < deadline:
        # Mix: sometimes start fresh from a pool candidate, sometimes from best, sometimes from cur.
        mode = rnd.random()
        if mode < 0.15:
            cand = sorted(set(pool[rnd.randrange(len(pool))]))
        elif mode < 0.55:
            cand = best[:]
        else:
            cand = cur[:]

        if len(cand) < 2:
            cand = best[:]

        # Add a few elements sometimes.
        if rnd.random() < 0.35 and len(cand) < 60:
            target = rnd.choice(size_options)
            while len(cand) < target and time.time() < deadline:
                # Try to add a value that's far from existing (to boost difference count) but keeps sums small.
                base = rnd.choice(cand)
                delta = rnd.randint(1, max(2, base // 2 + 1))
                newv = base + delta if rnd.random() < 0.5 else base - delta
                if newv not in cand:
                    cand.append(newv)

        # A few mutation steps.
        steps = rnd.randint(1, 6)
        for _ in range(steps):
            if time.time() >= deadline:
                break
            if len(cand) < 2:
                cand = best[:]
                break
            op = rnd.random()
            if op < 0.7:
                i = rnd.randrange(len(cand))
                # Scale of perturbation depends on current magnitude; keep ints bounded.
                mag = max(1, abs(cand[i]) // 4)
                mag = min(mag, 10**6)
                cand[i] += rnd.randint(-mag, mag)
                cand = sorted(set(cand))
                if len(cand) < 2:
                    cand = best[:]
            elif op < 0.85 and len(cand) > 4:
                # Remove a random element.
                i = rnd.randrange(len(cand))
                del cand[i]
            else:
                # Insert a new element near an existing one or random.
                if cand:
                    base = rnd.choice(cand)
                    delta = rnd.randint(1, max(2, abs(base) // 2 + 1))
                    newv = base + delta if rnd.random() < 0.5 else base - delta
                else:
                    newv = rnd.randint(-100, 100)
                if newv not in cand and len(cand) < 80:
                    cand.append(newv)
                    cand = sorted(set(cand))

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue

        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]
            cur = cand[:]
            cur_score = s
        elif s > cur_score or rnd.random() < 0.05:
            cur = cand[:]
            cur_score = s

        # Aggressive perturbation restart every so often to escape local optima.
        if rnd.random() < 0.01:
            cur = best[:]
            # Bigger jump.
            if len(cur) >= 2:
                for _ in range(rnd.randint(1, 3)):
                    i = rnd.randrange(len(cur))
                    cur[i] += rnd.randint(-1000, 1000)
                cur = sorted(set(cur))
            cur_score = _score(cur) if len(cur) >= 2 else -1.0

    return sorted(set(best))
