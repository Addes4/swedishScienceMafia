import math
import random
import time


def _score_stats(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    al = sorted(a)
    for i in range(n):
        xi = al[i]
        for j in range(n):
            xj = al[j]
            diffs.add(xi - xj)
            sums.add(xi + xj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _score(a):
    s, _, _ = _score_stats(a)
    return s


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    # Candidate constructions.

    # Construction 1: large positive prefix + small negative block.
    # Differences inside positive block go up to ~N, sums range ~0..2N;
    # the negative block creates large-magnitude differences with positives.
    def cand1(N, M, seed):
        rnd = random.Random(seed)
        A = list(range(1, N + 1))
        negs = set()
        while len(negs) < M:
            negs.add(-rnd.randint(N + 1, 3 * N))
        A += list(negs)
        return A

    # Construction 2: sparse random range with a wide span (more distinct diffs).
    def cand2(N, seed):
        rnd = random.Random(seed)
        span = max(4 * N, 200)
        A = rnd.sample(range(-span, span + 1), N)
        return A

    # Construction 3: geometric-ish: integers whose base-2 digit pattern is fixed-weight
    # (creates collisions in sums via symmetric structure but keeps diffs many).
    def cand3(k, seed):
        rnd = random.Random(seed)
        # take all numbers <= 2^k that are sum of exactly w distinct powers
        vals = set()
        # random subset approach
        base = [1 << i for i in range(k)]
        for _ in range(4000):
            # pick random subset
            v = 0
            for b in base:
                if rnd.random() < 0.5:
                    v += b
            vals.add(v)
        return list(vals)

    candidates = []
    for N in (60, 100, 150, 200, 300, 400, 600, 800):
        for M in (0, 3, 6, 10, 20, 40):
            if M < N:
                candidates.append(cand1(N, M, N * 100 + M))
    for N in (50, 100, 200, 400, 800, 1200):
        candidates.append(cand2(N, N))
    for k in (8, 10, 12, 14):
        candidates.append(cand3(k, k))

    best = None
    best_score = -1.0
    best_d = best_s = 0
    for c in candidates:
        c = sorted(set(c))
        if not (2 <= len(c) <= 4000):
            continue
        # limit to 4000
        if len(c) > 4000:
            c = c[:4000]
        try:
            s, d, sm = _score_stats(c)
        except Exception:
            continue
        if s > best_score:
            best_score = s
            best = c
            best_d, best_s = d, sm

    # Local search: try to add/remove/perturb one element, optimizing score.
    cur = best[:]
    cur_score = best_score

    def quick_score(a):
        return _score(a)

    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.4 and len(cand) < 4000:
            # add an element
            mx = max(abs(x) for x in cand)
            cand.append(random.randint(-2 * mx - 2, 2 * mx + 2))
        elif r < 0.6 and len(cand) > 2:
            # remove
            cand.pop(random.randrange(len(cand)))
        elif r < 0.9:
            # perturb
            i = random.randrange(len(cand))
            mx = max(abs(x) for x in cand) or 1
            cand[i] += random.randint(-mx // 4 - 1, mx // 4 + 1)
        else:
            # tweak by shifting a small block
            i = random.randrange(len(cand))
            shift = random.randint(-3, 3)
            cand[i] += shift

        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        # bound abs value
        if any(abs(x) > 10**15 for x in cand):
            continue

        # For speed, if set is large, use incremental estimate by full score anyway
        # but cap n by subsampling if huge
        try:
            s = quick_score(cand)
        except Exception:
            continue

        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best_score = s
                best = cand[:]
        elif random.random() < 0.02:
            cur, cur_score = best[:], best_score

    # Final cleanup
    b = sorted(set(best))
    if len(b) > 4000:
        b = b[:4000]
    return b
