import math, random, time

def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/len(a))/100

def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0
    # Candidate algebraic constructions
    candidates = []
    # base-B powers (geometric)
    for n in range(2, 30):
        for B in (2, 3, 4):
            candidates.append([B**i for i in range(n)])
    # subset-sum style: digits 0/1 in base B -> Cantor-like
    for n in range(2, 20):
        for B in (2, 3, 4, 8):
            s = set()
            for mask in range(min(1 << n, 4000)):
                v = 0
                m = mask
                i = 0
                while m:
                    if m & 1:
                        v += B**i
                    m >>= 1
                    i += 1
                s.add(v)
            if len(s) >= 2:
                candidates.append(sorted(s))
    # random small perturbations around geo
    for n in range(3, 40):
        candidates.append([2**i for i in range(n)])
    # evaluate
    for c in candidates:
        c = list(set(c))
        if len(c) > 4000:
            c = c[:4000]
        sc = _score(c)
        if sc > best_score:
            best_score = sc
            best = c[:]
    # local search
    cur = best[:]
    cur_score = best_score
    temp = 0.05
    step_count = 0
    while time.time() < deadline:
        step_count += 1
        cand = cur[:]
        r = random.random()
        if r < 0.5 and len(cand) < 4000:
            # add a small element or big one
            if random.random() < 0.5:
                cand.append(random.randint(-1000, 1000))
            else:
                cand.append(random.randint(-10**6, 10**6))
        elif r < 0.75 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif r < 0.9 and len(cand) > 3:
            # swap
            i = random.randrange(len(cand))
            cand[i] = random.choice(cur) + random.randint(-50, 50)
        else:
            # remove
            if len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        if len(cand) > 4000:
            continue
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc >= cur_score or random.random() < math.exp((sc - cur_score)/max(temp,1e-9)):
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
        if step_count % 2000 == 0:
            temp *= 0.99
            if temp < 1e-6:
                temp = 0.01
    return sorted(set(best))

if __name__ == "__main__":
    print(solve())
