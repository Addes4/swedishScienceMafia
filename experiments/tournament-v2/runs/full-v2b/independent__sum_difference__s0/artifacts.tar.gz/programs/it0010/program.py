import math
import random
import time


def _score_val(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        return -1.0, ld, ls
    bonus = (1.0 - 1.0 / n) / 100.0
    return math.log(ld) / math.log(ls) + bonus, ld, ls


def _score(a):
    return _score_val(a)[0]


def _random_perturb(a, rng, maxabs, nmax):
    b = set(a)
    op = rng.random()
    if op < 0.45:
        if b:
            x = rng.choice(list(b))
            b.discard(x)
            if 2 <= len(b) <= nmax:
                pass
    elif op < 0.80:
        for _ in range(rng.randint(1, 3)):
            if len(b) < nmax:
                b.add(rng.randint(-maxabs, maxabs))
    else:
        if len(b) >= 2:
            vals = list(b)
            i = rng.randrange(len(vals))
            old = vals[i]
            b.discard(old)
            b.add(rng.randint(-maxabs, maxabs))
    return sorted(b)


def _local_search(seed, deadline, nmax=4000, maxabs=10**15):
    rng = random.Random(12345)
    best = sorted(set(seed))
    best_s, _, _ = _score_val(best)
    cur = best[:]
    cur_s = best_s
    steps = 0
    while time.time() < deadline:
        steps += 1
        cand = _random_perturb(cur, rng, maxabs, nmax)
        if len(cand) < 2:
            continue
        s, ld, ls = _score_val(cand)
        if s > cur_s or (s == cur_s and rng.random() < 0.3):
            cur = cand
            cur_s = s
        if s > best_s:
            best = cand[:]
            best_s = s
        if steps % 2000 == 0:
            # restart
            cur = best[:]
            cur_s = best_s
    return best, best_s


def _greedy_sidon(n, maxabs):
    # greedy B_2 / Sidon-like set to maximize differences
    A = [0]
    used = {0}
    x = 1
    while len(A) < n and x <= maxabs:
        ok = True
        for a in A:
            for b in A:
                if a + b == x:
                    ok = False
                    break
            if not ok:
                break
        if ok:
            A.append(x)
        x += 1
    return A


def _symmetric_seed(n):
    # Build a set symmetric about 0: A = {-x : x in B} u B, differences rich,
    # sums have special structure: sums are differences of B shifted.
    half = max(2, n // 2)
    B = [0]
    for k in range(1, half):
        B.append(3 * k * k + 5 * k + 7)
    A = set()
    for b in B:
        A.add(b)
        A.add(-b)
    return sorted(A)


def _constructor_search(deadline):
    best = None
    best_s = -1.0
    maxabs = 10**15

    seeds = []

    # Seed 1: small careful hand-tuned
    seeds.append([7, 15, 18, 22, -3, -2, -12, -20])

    # Seed 2: powers-ish
    s2 = set()
    x = 0
    for k in range(12):
        s2.add(x)
        x = x * 2 + 1
    seeds.append(sorted(s2))

    # Seed 3: symmetric quadratic mod
    seeds.append(_symmetric_seed(20))

    # Seed 4: greedy Sidon
    seeds.append(_greedy_sidon(14, 5000))

    # Seed 5: arithmetic progression around offset to reduce sums
    seeds.append(sorted([i * 5 + (i * i) % 11 for i in range(16)]))

    # Seed 6: random small
    rng = random.Random(999)
    seeds.append(sorted(set(rng.randint(-100, 100) for _ in range(12))))

    for seed in seeds:
        s, ld, ls = _score_val(seed)
        if s > best_s:
            best_s = s
            best = sorted(set(seed))

    # Multi-seed local search with restarts
    while time.time() < deadline:
        seed = random.choice(seeds)
        improved, s = _local_search(seed, min(deadline, time.time() + 6))
        if s > best_s:
            best_s = s
            best = improved

    return best, best_s


def _refine_differences(A, deadline):
    # try to expand difference set without growing sum set too much
    A = sorted(set(A))
    best = A[:]
    best_s, best_ld, best_ls = _score_val(A)
    rng = random.Random(777)
    maxabs = 10**15
    while time.time() < deadline:
        cand = A[:]
        op = rng.random()
        if op < 0.5 and len(cand) < 4000:
            # insert new element chosen to add new differences
            s_cand = set(cand)
            # prefer element creating new differences relative to current set
            for _ in range(5):
                x = rng.randint(-maxabs, maxabs)
                if x not in s_cand:
                    break
            cand.append(x)
        elif len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        else:
            continue
        cand = sorted(set(cand))
        s, ld, ls = _score_val(cand)
        if s > best_s:
            best_s = s
            best = cand
            best_ld = ld
            best_ls = ls
            A = cand
        elif rng.random() < 0.05:
            A = best[:]
    return best, best_s


def solve():
    deadline = time.time() + 115

    # Phase 1: constructor search
    best, best_s = _constructor_search(deadline - 25)

    # Phase 2: refine differences
    best2, best_s2 = _refine_differences(best, deadline)

    if best_s2 > best_s:
        best, best_s = best2, best_s2

    # Final safety: ensure valid
    best = sorted(set(int(x) for x in best))
    if len(best) < 2:
        best = [0, 1]

    # clip to allowed ranges
    res = []
    seen = set()
    for x in best:
        if x < -10**15:
            x = -10**15
        if x > 10**15:
            x = 10**15
        if x not in seen:
            seen.add(x)
            res.append(x)
        if len(res) >= 4000:
            break
    if len(res) < 2:
        res = [0, 1]
    return res
