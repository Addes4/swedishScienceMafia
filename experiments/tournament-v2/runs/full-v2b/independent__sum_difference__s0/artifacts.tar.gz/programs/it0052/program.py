import math
import random
import time
from functools import lru_cache


def _diffs(a):
    a = list(a)
    return {x - y for x in a for y in a}


def _sums(a):
    a = list(a)
    return {x + y for x in a for y in a}


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd = len(_diffs(a))
    ns = len(_sums(a))
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _greedy_sidon(n, limit):
    """Greedy Sidon-like set: all pairwise sums distinct (mod free)."""
    s = []
    sums = set()
    x = 0
    while len(s) < n and x < limit:
        ok = True
        new_sums = set()
        for y in s:
            v = x + y
            if v in sums or v in new_sums:
                ok = False
                break
            new_sums.add(v)
        if ok:
            s.append(x)
            sums |= new_sums
        x += 1
    return s


def _greedy_b2(n):
    """Greedy B_2 set with small max value (Sidon)."""
    s = []
    sums = set()
    for x in range(0, 10 ** 7):
        ds = set()
        good = True
        for y in s:
            v = x + y
            if v in sums or v in ds:
                good = False
                break
            ds.add(v)
        if good:
            s.append(x)
            sums |= ds
            if len(s) >= n:
                break
    return s


def _modular_sidon(n):
    """Use the classical construction: for prime p, {2*p*k + (k^2 mod p)} is Sidon."""
    # pick p just above n, p prime
    def is_prime(x):
        if x < 2:
            return False
        i = 2
        while i * i <= x:
            if x % i == 0:
                return False
            i += 1
        return True

    p = max(n, 3)
    while not is_prime(p):
        p += 1
    s = []
    for k in range(p):
        s.append(2 * p * k + (k * k) % p)
        if len(s) >= n:
            break
    return s


def solve():
    """Return a list of distinct integers A with large |A-A|, small |A+A|."""
    deadline = time.time() + 110

    N = 3800  # comfortably below 4000

    # --- Candidate 1: modular Sidon set (small sums, full differences) ---
    cands = []
    try:
        m = _modular_sidon(N)
        if len(m) >= 2:
            cands.append(m[:N])
    except Exception:
        pass

    # --- Candidate 2: greedy Sidon (B_2) with small values ---
    try:
        g = _greedy_b2(min(N, 1500))
        if len(g) >= 2:
            # replicate via scaling to get more elements
            base = g
            for shift in range(0, 3):
                extra = [x + (max(base) + 10) * (shift + 1) for x in base]
                cands.append(base + extra)
    except Exception:
        pass

    # --- Candidate 3: arithmetic progression with one perturbation ---
    ap = [i * 1000003 for i in range(N)]
    cands.append(ap)

    best = None
    best_score = -1.0
    for c in cands:
        c = sorted(set(c))[:N]
        if len(c) < 2:
            continue
        # Quick prune: local search on this candidate
        cur = c[:]
        s = _score(cur)
        if s > best_score:
            best_score = s
            best = cur[:]

    # --- Multi-scale local search ---
    # Take best candidate, then produce improved variants.
    if best is None:
        best = [0, 1]
        best_score = _score(best)

    cur = best[:]

    def perturb(c, k):
        c = c[:]
        for _ in range(k):
            i = random.randrange(len(c))
            c[i] += random.choice([-1, 1]) * random.randint(1, 1000000)
        return sorted(set(c))

    # Hill-climb from modular Sidon: perturb elements
    base = None
    for c in cands:
        cc = sorted(set(c))[:N]
        if len(cc) >= 2:
            base = cc
            break
    if base is None:
        base = best[:]

    improved = True
    step = 0
    while time.time() < deadline:
        step += 1
        # occasionally re-seed from modular Sidon
        if step % 200 == 0:
            cur = base[:]
            s = _score(cur)
            if s > best_score:
                best_score = s
                best = cur[:]

        cand = cur[:]
        t = step
        # choose perturbation size adaptively
        if t % 5 == 0:
            # swap-style: replace random element with new huge value
            i = random.randrange(len(cand))
            cand[i] = random.randint(1, 10 ** 15) * random.choice([-1, 1])
        elif t % 5 == 1:
            # nudge
            i = random.randrange(len(cand))
            cand[i] += random.randint(-10, 10) * random.randint(1, 100000)
        elif t % 5 == 2:
            # add element
            if len(cand) < N:
                cand.append(random.randint(1, 10 ** 15))
        elif t % 5 == 3:
            # perturb many elements (larger move)
            cand = perturb(cand, max(1, len(cand) // 50))
        else:
            # move whole set by constant (no change to score, but allows re-anchor)
            i = random.randrange(len(cand))
            cand[i] += random.randint(-3, 3)

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > N:
            # drop smallest (or random)
            cand = cand[:N]

        sc = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]
            cur = cand[:]
        elif random.random() < 0.05:
            cur = cand[:]

    return sorted(set(best))
