import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _diff_sum_counts(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def solve():
    deadline = time.time() + 110

    # Start from a strong seed: a known small near-optimal-ish configuration.
    best = [0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96]
    best_score = _score(best)
    best_d = best[:]

    # Also seed with a simple Sidon-ish / B_h construction on small integers.
    seeds = []
    seeds.append([0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96])

    # Golomb-ruler-like seed
    gr = [0, 1, 4, 10, 18, 23, 25]
    seeds.append(gr)

    # Power-ish seed
    pw = [1]
    x = 1
    for _ in range(14):
        x = x * 2 + random.randint(0, 3)
        pw.append(x)
    seeds.append(pw)

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score = sc
            best = s[:]

    cur = best[:]
    cur_score = best_score
    n_target = 40

    # Randomized greedy construction: add elements to maximize diff count per sum count.
    for _ in range(30):
        A = [0, 1]
        while len(A) < n_target and time.time() < deadline:
            # sample candidates
            base = max(A)
            cand_vals = set()
            for _ in range(60):
                cand_vals.add(random.randint(-base - 50, base + 50))
            best_c = None
            best_val = -1.0
            for c in cand_vals:
                if c in A:
                    continue
                B = A + [c]
                d, s = _diff_sum_counts(B)
                if s > 0:
                    val = math.log(max(d, 1)) / math.log(max(s, 1)) + random.random() * 0.01
                    if val > best_val:
                        best_val = val
                        best_c = c
            if best_c is None:
                break
            A.append(best_c)
        sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A[:]
            cur = A[:]
            cur_score = sc

    # Local search with swaps / mutations.
    while time.time() < deadline:
        cand = cur[:]

        r = random.random()
        if r < 0.5:
            # mutate one element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-20, 20)
        elif r < 0.75:
            # swap an element for a new one
            i = random.randrange(len(cand))
            base = max(cand) - min(cand) + 10
            cand[i] = random.randint(min(cand) - base, max(cand) + base)
        else:
            # add or remove
            if len(cand) < 400 and random.random() < 0.7:
                base = max(cand) - min(cand) + 10
                cand.append(random.randint(min(cand) - base, max(cand) + base))
            elif len(cand) > 5:
                i = random.randrange(len(cand))
                cand.pop(i)

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc >= cur_score or random.random() < 0.02:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc

        # occasional restart from best
        if random.random() < 0.005:
            cur = best[:]
            cur_score = best_score

    # Small extra hill-climb for final polish
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for i in range(len(best)):
            orig = best[i]
            for delta in (-3, -2, -1, 1, 2, 3, 5, -5, 10, -10):
                cand = best[:]
                cand[i] = orig + delta
                cand = list(set(cand))
                if len(cand) < 2:
                    continue
                sc = _score(cand)
                if sc > best_score:
                    best = cand
                    best_score = sc
                    improved = True

    return sorted(set(best))
