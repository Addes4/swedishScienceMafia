import math
import random
import time

# Optional numpy for speed; fallback if unavailable
try:
    import numpy as np
except Exception:
    np = None


def _score(a):
    n = len(a)
    if n < 2:
        return -1e18
    # Remove duplicates while preserving ability to score actual set
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e18

    if np is not None:
        arr = np.array(a, dtype=np.int64)
        # differences: all pairwise differences
        diffs = np.unique(arr[:, None] - arr[None, :])
        sums = np.unique(arr[:, None] + arr[None, :])
        return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0
    else:
        diffs = set()
        sums = set()
        for x in a:
            for y in a:
                diffs.add(x - y)
                sums.add(x + y)
        return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _fast_score_parts(a):
    """Return (n, |diffs|, |sums|) possibly using numpy."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return n, 0, 0
    if np is not None:
        arr = np.array(a, dtype=np.int64)
        diffs = np.unique(arr[:, None] - arr[None, :])
        sums = np.unique(arr[:, None] + arr[None, :])
        return n, len(diffs), len(sums)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return n, len(diffs), len(sums)


def _score_from_parts(n, nd, ns):
    if n < 2 or ns <= 1 or nd <= 1:
        return -1e18
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _make_sidon_like(base, k):
    """Greedy Sidon-like sequence modulo/bounded with many differences."""
    a = []
    used_diffs = set()
    x = 0
    step = 1
    # Greedy construction that tries to maximize new differences
    while len(a) < k:
        best_x = None
        best_new = -1
        for cand in range(x, x + 5000):
            new_d = 0
            ok = True
            ld = []
            for y in a:
                d = cand - y
                if d in used_diffs:
                    pass
                else:
                    new_d += 1
                ld.append(d)
            # also forward differences to later elements don't exist yet
            if new_d > best_new:
                best_new = new_d
                best_x = cand
            if best_new >= len(a):
                break
        if best_x is None:
            best_x = x
        a.append(best_x)
        for y in a:
            used_diffs.add(best_x - y)
        x = best_x + 1
    return a


def _greedy_large_diff_small_sum(k, max_val):
    """Greedy: add numbers keeping sums in a small interval while maximizing new differences."""
    a = [0]
    sums = {0}
    diffs = {0}
    for _ in range(k - 1):
        best_x = None
        best_score_local = -1e18
        # Try candidates near current range; prefer those adding many diffs and few sums
        span = max_val // max(1, k)
        lo = min(a) - span
        hi = max(a) + span
        # random sample if range is huge
        if hi - lo > 20000:
            cands = [random.randint(lo, hi) for _ in range(3000)]
        else:
            cands = range(lo, hi + 1)
        for x in cands:
            if x in a:
                continue
            new_d = 0
            for y in a:
                if (x - y) not in diffs:
                    new_d += 1
                if (y - x) not in diffs:
                    new_d += 1
            new_s = 0
            for y in a:
                if (x + y) not in sums:
                    new_s += 1
            # heuristic score
            val = new_d - 2.5 * new_s
            if val > best_score_local:
                best_score_local = val
                best_x = x
        if best_x is None:
            best_x = random.randint(lo, hi)
        a.append(best_x)
        for y in a:
            diffs.add(best_x - y)
            diffs.add(y - best_x)
            sums.add(best_x + y)
            sums.add(y + best_x)
    return sorted(set(a))


def _local_search(start, deadline, max_steps=None):
    a = sorted(set(start))
    n = len(a)
    if n < 2:
        return a
    cur = a[:]
    nd, ns = _fast_score_parts(cur)[1:]
    cur_score = _score_from_parts(len(cur), nd, ns)
    best = cur[:]
    best_score = cur_score

    steps = 0
    while time.time() < deadline:
        if max_steps is not None and steps >= max_steps:
            break
        steps += 1
        cand = cur[:]
        r = random.random()
        if r < 0.65:
            # perturb one element
            i = random.randrange(len(cand))
            # adaptive step
            scale = 1
            if random.random() < 0.3:
                scale = random.randint(1, 50)
            if random.random() < 0.1:
                scale = random.randint(1, 5000)
            cand[i] += random.choice([-1, 1]) * scale
        elif r < 0.85:
            # add element
            if len(cand) < 4000:
                lo = min(cand) - 200
                hi = max(cand) + 200
                cand.append(random.randint(lo, hi))
        else:
            # remove element
            if len(cand) > 2:
                del cand[random.randrange(len(cand))]

        # enforce distinct and limits
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue

        n2, nd2, ns2 = _fast_score_parts(cand)
        s2 = _score_from_parts(n2, nd2, ns2)
        if s2 >= cur_score:
            cur = cand
            cur_score = s2
            nd, ns = nd2, ns2
            if s2 > best_score:
                best = cand[:]
                best_score = s2
        else:
            # sometimes accept worse to escape local optima
            T = max(1e-6, 0.002 * (1.0 - steps / 500000.0))
            if random.random() < math.exp((s2 - cur_score) / T):
                cur = cand
                cur_score = s2
                nd, ns = nd2, ns2
    return sorted(best)


def solve():
    start_time = time.time()
    deadline = start_time + 115.0  # leave margin
    candidates = []

    # Candidate 1: small baseline construction from problem
    candidates.append([7, 15, 18, 22, -3, -2])

    # Candidate 2: Sidon-like / greedy large differences
    random.seed(12345)
    for k in [20, 40, 80, 120, 200]:
        try:
            candidates.append(_greedy_large_diff_small_sum(k, 10**6))
        except Exception:
            pass

    # Candidate 3: arithmetic progression with gaps (sumset small, differences moderate)
    for k in [50, 100, 200, 400]:
        # A = {0, d, 2d, ..., (k-1)d} plus irregular shifts to boost differences
        base = [i * 1000 for i in range(k)]
        # add some perturbations
        for _ in range(max(1, k // 10)):
            i = random.randrange(k)
            base[i] += random.randint(-500, 500)
        candidates.append(base)

    # Candidate 4: union of short AP and Sidon set
    for k in [30, 60, 100]:
        sid = _make_sidon_like(0, k)
        ap = [i * 7 for i in range(k)]
        candidates.append(sid + ap)

    # Evaluate and pick best
    best = None
    best_score = -1e18
    for c in candidates:
        if len(c) < 2:
            continue
        n, nd, ns = _fast_score_parts(c)
        s = _score_from_parts(n, nd, ns)
        if s > best_score:
            best_score = s
            best = c[:]

    if best is None:
        best = [0, 1]

    # Local search from best candidate with remaining time
    remaining = deadline - time.time()
    if remaining > 0.5:
        # Run a few restarts of local search within time budget
        num_restarts = 4
        per_restart = remaining / num_restarts
        overall_best = best[:]
        overall_best_score = _score(best)
        for r in range(num_restarts):
            t_end = min(deadline, time.time() + per_restart)
            start_cand = best[:]
            if r > 0:
                # perturb start
                start_cand = best[:]
                for _ in range(max(1, len(start_cand) // 20)):
                    if not start_cand:
                        break
                    i = random.randrange(len(start_cand))
                    start_cand[i] += random.randint(-100, 100)
                start_cand = list(set(start_cand))
            cand_res = _local_search(start_cand, t_end)
            if len(cand_res) >= 2:
                n, nd, ns = _fast_score_parts(cand_res)
                s = _score_from_parts(n, nd, ns)
                if s > overall_best_score:
                    overall_best_score = s
                    overall_best = cand_res[:]
        best = overall_best

    # Final sanity: distinct, limits
    best = [int(x) for x in set(best) if abs(int(x)) <= 10**15]
    if len(best) < 2:
        best = [0, 1]
    return sorted(best)
