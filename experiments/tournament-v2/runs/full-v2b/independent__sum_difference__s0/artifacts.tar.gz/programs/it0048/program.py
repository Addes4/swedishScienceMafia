import math
import random
import time

# We build a large set with small sumset by taking a dense "perfect difference set"-like
# construction: a Singer/quadratic-residue-like set over a prime, lifted to the integers.
# A Singer difference set in Z_{q^2+q+1} has all nonzero differences exactly once (|D-D| = q^2+q+1),
# giving a near-optimal ratio. But its sumset is large, and it's a cyclic set requiring modular arithmetic.
# Empirically, a better integer strategy is to use a "B_2 sequence gone dense": take a block of
# integers whose pairwise differences are as distinct as possible while their sums collapse.
#
# A strong practical family: A = { i * m + r_i } where m is a base and r_i is a small Sidon seed,
# i.e. a "sum-combined" set. But the simplest high-scoring structure is just a long arithmetic
# progression perturbed so sums cluster (small spread) while differences stay many. For an AP,
# |A+A| = 2|A|-1 (tiny) and |A-A| = 2|A|-1 (tiny too), ratio ~ 1, bad.
# We need |A-A| large: use a set with distinct pairwise differences (Sidon/B_2) => |A-A| ~ n^2/2.
# To make |A+A| small, values must be tightly clustered, but Sidon sets with small diameter are hard.
# A good compromise is a "modular Sidon set lifted": take a Sidon set in Z_M (Singer), map to integers.
# That gives distinct differences mod M; actual integer differences may collide but rarely.
# The sumset stays limited because integer values lie in [0, M).


def _singer_set(p):
    """Return a Sidon set (differences all distinct mod M) in [0, M) for M = p^2 + p + 1,
    using the quadratic residue construction when applicable."""
    M = p * p + p + 1
    # Singer difference set: {x : x^2 + x + 1 is a square mod M} style doesn't always work.
    # Use the standard construction: in GF(p^3) with generator g of norm 1 subgroup of size M.
    # Simpler: use the multiplicative construction on Z_{M}.
    # The classic Singer (perfect difference) set is:
    #   D = { i in [0,M) : i is in the image of a certain map }
    # We'll use the well-known: for prime power q, let M=q^2+q+1, take a primitive element x of GF(q^3)
    # and D = { i : x^i in the subfield-like coset }. Implementing full GF(q^3) for prime q is doable.
    # Here we implement GF(p^3) as polynomials mod an irreducible cubic, tracking x^i as triple.
    pass
    return None


def _greedy_b2(limit, count):
    """Greedy B_2 (Sidon) sequence: each new element must not create duplicate pair sums.
    Returns list of 'count' elements <= limit. This gives |A-A| ~ n(n-1)+1 (all differences distinct)."""
    a = [0]
    sums = {0}
    x = 0
    while len(a) < count and x < limit:
        x += 1
        ok = True
        new = []
        for y in a:
            s = x + y
            if s in sums or s in new:
                ok = False
                break
            new.append(s)
        if ok:
            a.append(x)
            for s in new:
                sums.add(s)
    return a


def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    if len(sums) <= 1:
        return 0.0, 0
    val = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return val, len(diffs)


def _build_seed():
    """Build a strong starting set: a dilated Sidon set combined with a small AP core.
    The key trick: A = B + C where B is Sidon and C is small; sums collapse due to C but differences
    stay large due to B."""
    # Use greedy B_2 sequence for distinct differences.
    n_target = 300
    B = _greedy_b2(200000, n_target)
    # Dilate to spread differences, but that increases sums. Instead use as-is; it's already minimal-ish.
    return B


def solve():
    deadline = time.time() + 110

    # Start from a greedy Sidon/B_2 sequence (maximizes |A-A|).
    # Then do local search to reduce |A+A| by compressing gaps / adding clustered elements.
    best = _build_seed()
    best_set = sorted(set(best))
    best_score, best_d = _score_fast(best_set)
    cur = best_set[:]

    # local search with occasional growth/pruning and coordinate perturbation
    it = 0
    while time.time() < deadline:
        it += 1
        if it % 2000 == 0:
            # rebuild from best occasionally to escape
            cur = best_set[:]

        cand = cur[:]
        r = random.random()
        if r < 0.6 and len(cand) >= 2:
            # perturb an element (small shift to reduce sums or keep diffs)
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
            cand = sorted(set(cand))
        elif r < 0.85:
            # insert element near an existing one (helps sums cluster, may add diff)
            if len(cand) < 4000:
                i = random.randrange(len(cand))
                base = cand[i]
                cand.append(base + random.randint(-4, 4))
                cand = sorted(set(cand))
        else:
            # delete an element (rebuild diversity)
            if len(cand) > 5:
                i = random.randrange(len(cand))
                del cand[i]

        if len(cand) < 2 or len(cand) > 4000:
            continue
        if max(abs(v) for v in cand) > 10**15:
            continue

        s, d = _score_fast(cand)
        if s >= best_score:
            best_score, best_set, cur = s, cand[:], cand[:]
        elif random.random() < 0.05:
            cur = cand[:]

    return sorted(set(best_set))
