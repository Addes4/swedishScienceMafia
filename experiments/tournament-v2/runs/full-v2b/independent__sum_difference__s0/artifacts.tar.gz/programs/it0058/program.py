import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            if ai != aj:
                diffs.add(aj - ai)
            sums.add(ai + aj)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _sidon_like(n, scale):
    # A construction with many differences and few sums:
    # take {2^i} type structure is too sparse for sums; use modular-style near-Sidon set.
    # Simple high-quality seed: {0,1,3,7,12,...} Sidon sequence scaled.
    sidon = [0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96, 122, 147, 181, 203, 251, 289, 360, 372, 400]
    if n <= len(sidon):
        base = sidon[:n]
    else:
        base = sidon[:]
        x = base[-1] + 1
        while len(base) < n:
            ok = True
            cand = x
            for i in range(len(base)):
                for j in range(i + 1, len(base)):
                    s1 = base[i] + base[j]
                    if cand == s1 - cand or cand == s1 - base[i] or cand == s1 - base[j]:
                        ok = False
                        break
                if not ok:
                    break
            if ok:
                base.append(cand)
            x += 1
    return [x * scale for x in base]


def _greedy_small_sums(limit_n, deadline):
    # Build a set greedily trying to keep sumset small.
    a = [0, 1, 3]
    sums = {0, 1, 2, 3, 4, 6}
    diffs = {0, 1, 2, 3, -1, -2, -3}
    x = 4
    while len(a) < limit_n and time.time() < deadline:
        best_x = None
        best_gain = -1e18
        for cand in range(x, x + 200):
            new_sums = sums | {cand + b for b in a} | {2 * cand}
            new_diffs = diffs | {cand - b for b in a} | {b - cand for b in a}
            if len(new_sums) == 0:
                continue
            gain = math.log(len(new_diffs) + 1) - math.log(len(new_sums)) * 1.5
            if gain > best_gain:
                best_gain = gain
                best_x = cand
        if best_x is None:
            best_x = x
        a.append(best_x)
        sums |= {best_x + b for b in a} | {2 * best_x}
        diffs |= {best_x - b for b in a} | {b - best_x for b in a}
        x = best_x + 1
    return a


def solve():
    deadline = time.time() + 110

    candidates = []

    # Seed 1: small Sidon-like constructions.
    for n in [6, 8, 10, 14, 18, 24, 30, 40, 60, 100, 200, 400]:
        for scale in [1, 2, 3, 5, 10, 100]:
            try:
                candidates.append(_sidon_like(n, scale))
            except Exception:
                pass

    # Seed 2: known good small pattern.
    candidates.append([7, 15, 18, 22, -3, -2])
    candidates.append([0, 1, 3, 7, 12, 20, 30, 44])
    candidates.append([0, 1, 3, 8, 12])

    # Seed 3: geometric-ish but with few sums.
    for n in [6, 10, 15, 20, 30, 50, 80, 120]:
        a = [0]
        v = 1
        for _ in range(n - 1):
            a.append(v)
            v = v * 3 + 1
        candidates.append(a)

    best = []
    best_score = -1e18

    for c in candidates:
        c = sorted(set(int(x) for x in c if abs(x) <= 10**15))
        if len(c) < 2:
            continue
        s = _score_fast(c)
        if s > best_score:
            best_score = s
            best = c[:]

    # Greedy construction as another strong seed.
    try:
        g = _greedy_small_sums(min(300, int(deadline - time.time())), time.time() + 5)
        if len(g) >= 2:
            s = _score_fast(g)
            if s > best_score:
                best_score = s
                best = g[:]
    except Exception:
        pass

    # Local search phase.
    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        r = random.random()

        if r < 0.35 and len(cand) >= 2:
            # Modify an element, biasing to preserve small sums.
            i = random.randrange(len(cand))
            step = random.choice([-10, -5, -3, -2, -1, 1, 2, 3, 5, 10, -20, 20, -50, 50])
            cand[i] += step
        elif r < 0.65 and len(cand) < 4000:
            # Add a new element near existing ones to avoid large sums.
            base = random.choice(cand)
            cand.append(base + random.randint(1, 50) * random.choice([1, -1]))
        elif r < 0.80 and len(cand) > 5:
            # Remove an element.
            del cand[random.randrange(len(cand))]
        elif r < 0.95 and len(cand) >= 3:
            # Swap an element for a nearby value.
            i = random.randrange(len(cand))
            cand[i] = random.choice(cand) + random.randint(1, 30) * random.choice([1, -1])
        else:
            # Perturb several elements.
            for _ in range(random.randint(1, 3)):
                if cand:
                    i = random.randrange(len(cand))
                    cand[i] += random.randint(-5, 5)

        cand = sorted(set(int(x) for x in cand if abs(x) <= 10**15))
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            cand = cand[:4000]

        s = _score_fast(cand)

        if s > cur_score or (random.random() < 0.02 and s > cur_score - 0.05):
            cur = cand[:]
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s

        if time.time() > deadline - 1:
            break

    return sorted(best)
