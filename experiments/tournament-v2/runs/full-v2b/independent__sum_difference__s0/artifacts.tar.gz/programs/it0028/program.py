import math
import random
import time

LIMIT_N = 4000
LIMIT_ABS = 10**15


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    d = len(diffs)
    s = len(sums)
    if d <= 1 or s <= 0:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _score_fast(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    d = len(diffs)
    s = len(sums)
    if d <= 1 or s <= 0:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _greedy_sidon(n, seed=0):
    # Build a Sidon-like set greedily: choose integers so that most differences are unique.
    rng = random.Random(seed)
    a = [0]
    used_diffs = {0}
    candidates = list(range(-3 * n, 3 * n + 1))
    rng.shuffle(candidates)
    target = n
    # try to extend
    while len(a) < target and candidates:
        best_c = None
        best_gain = -1
        trials = 0
        for c in candidates:
            if c in a:
                continue
            new_diffs = [c - x for x in a] + [x - c for x in a]
            collisions = 0
            for dd in new_diffs:
                if dd in used_diffs:
                    collisions += 1
            gain = len(new_diffs) - 2 * collisions
            if gain > best_gain:
                best_gain = gain
                best_c = c
            trials += 1
            if trials > 300:
                break
        if best_c is None:
            break
        for x in a:
            used_diffs.add(best_c - x)
            used_diffs.add(x - best_c)
        used_diffs.add(0)
        a.append(best_c)
        candidates = [c for c in candidates if c != best_c]
    return a


def _shift_symmetric(a):
    # Shift so mean is near 0 => many sum collisions from symmetry.
    if not a:
        return a
    m = sum(a) // len(a)
    return [x - m for x in a]


def _local_search(a, deadline):
    a = list(set(a))
    best = a[:]
    best_score = _score(best)
    cur = a[:]
    cur_score = best_score
    n = len(cur)
    while time.time() < deadline:
        op = random.random()
        cand = cur[:]
        if op < 0.5 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif op < 0.75:
            cand.append(random.randint(-50, 50))
        elif len(cand) > 2:
            idx = random.randrange(len(cand))
            del cand[idx]
        cand = list(set(cand))
        if len(cand) > LIMIT_N:
            continue
        if any(abs(x) > LIMIT_ABS for x in cand):
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.02:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score
    return best


def solve():
    deadline = time.time() + 110
    # Try several geometric/Sidon constructions and keep best.
    best = None
    best_score = -1.0

    # Construction 1: symmetric around 0, using distinct powers-ish (Sidon-like) offsets.
    constructions = []

    # Sidon greedy with different seeds & sizes
    for n in (20, 40, 80, 160, 300):
        for seed in range(3):
            constructions.append(_greedy_sidon(n, seed))

    # Geometric-ish: powers of 2 (difference-rich) with symmetry
    for k in (10, 16, 20, 24):
        s = [2 ** i for i in range(k)]
        constructions.append(s + [-x for x in s])

    # Beatty-like / Sidon known small
    constructions.append([0, 1, 4, 10, 18, 23, 25])
    constructions.append([0, 2, 7, 13, 22, 34, 41])
    constructions.append([3, 5, 12, 18, 21, 29, 40, 47])

    for c in constructions:
        c = list(set(c))
        if len(c) < 2:
            continue
        c = _shift_symmetric(c)
        sc = _score(c)
        if sc > best_score:
            best_score = sc
            best = c[:]

    # Local search from best
    per_round_deadline = min(deadline, time.time() + 100)
    cand = _local_search(best, per_round_deadline)
    sc = _score(cand)
    if sc > best_score:
        best = cand
        best_score = sc

    # Extra: try local search from a few more constructions briefly
    for c in constructions[:10]:
        if time.time() > deadline - 2:
            break
        c = _shift_symmetric(list(set(c)))
        c2 = _local_search(c, min(deadline, time.time() + 3))
        sc = _score(c2)
        if sc > best_score:
            best = c2
            best_score = sc

    # final cleanup
    best = sorted(set(best))
    if len(best) < 2:
        best = [0, 1]
    return best
