"""High-scoring set construction for large |A-A| and small |A+A|.

Key idea:
- A purely random/Sidon-like set tends to have |A-A| ~ n^2 and |A+A| ~ n^2.
- To make sums small while differences large, use a set with many internal
  translations of a compact pattern, so sums concentrate while differences
  spread out.  A strong practical construction is a union of a few affine
  translates of a Sidon block, followed by local search on the actual score.

We build several candidates and locally optimize the exact ratio.
"""

import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), n


def _score(a):
    nd, ns, n = _stats(a)
    if n < 2 or ns == 0:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _greedy_add(a, candidates, timeout, rng):
    """Greedily add elements that improve the score, with incremental delta checks."""
    a = list(dict.fromkeys(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    best_score = math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / len(a)) / 100.0 if len(sums) > 1 else 0.0

    start = time.time()
    improved = True
    while improved and time.time() - start < timeout:
        improved = False
        rng.shuffle(candidates)
        for z in candidates:
            if z in a:
                continue
            # incremental new differences and sums
            new_d = set()
            new_s = set()
            for x in a:
                new_d.add(z - x)
                new_d.add(x - z)
                new_s.add(z + x)
            new_d.add(0)
            new_s.add(2 * z)
            nd = len(diffs | new_d)
            ns = len(sums | new_s)
            if ns == 0:
                continue
            sc = math.log(nd) / math.log(ns) + (1.0 - 1.0 / (len(a) + 1)) / 100.0
            if sc > best_score:
                a.append(z)
                diffs |= new_d
                sums |= new_s
                best_score = sc
                improved = True
                if len(a) >= 4000:
                    return a
        if not improved:
            break
    return a


def _local_search(a, timeout, rng):
    """Local search flipping/perturbing elements to improve the ratio."""
    a = list(dict.fromkeys(a))
    if len(a) < 3:
        return a

    def full_score(arr):
        d = set()
        s = set()
        for x in arr:
            for y in arr:
                d.add(x - y)
                s.add(x + y)
        if len(s) < 2:
            return -1.0
        return math.log(len(d)) / math.log(len(s)) + (1.0 - 1.0 / len(arr)) / 100.0

    best = a[:]
    best_score = full_score(best)
    cur = best[:]
    cur_score = best_score
    start = time.time()
    step = 1
    while time.time() - start < timeout:
        cand = cur[:]
        mode = rng.random()
        if mode < 0.55:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-step, step)
        elif mode < 0.75:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-step * 5, step * 5)
        elif mode < 0.9 and len(cand) < 4000:
            cand.append(rng.randint(-50, 50))
        elif len(cand) > 3:
            i = rng.randrange(len(cand))
            del cand[i]
        cand = list(dict.fromkeys(cand))
        if len(cand) < 3:
            continue
        s = full_score(cand)
        if s > cur_score or (s == cur_score and rng.random() < 0.3):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
                step = max(1, step - 1)
        else:
            step = min(step + 1, 50)
            if rng.random() < 0.05:
                cur, cur_score = best[:], best_score
    return best


def _candidate_patterns(rng):
    """Generate structured candidate sets."""
    out = []

    # 1. Dense Sidon-ish block around 0
    for _ in range(6):
        n = rng.randint(20, 60)
        vals = set()
        base = rng.randint(0, 5)
        while len(vals) < n:
            vals.add(rng.randint(-base - 4 * n, base + 4 * n))
        out.append(sorted(vals))

    # 2. Affine translates: A = union of translates of a small block
    for _ in range(8):
        block = sorted(rng.sample(range(-20, 21), rng.randint(4, 10)))
        num_tr = rng.randint(2, 6)
        shifts = sorted(rng.sample(range(-60, 61), num_tr))
        a = set()
        for sh in shifts:
            for b in block:
                a.add(b + sh)
        out.append(sorted(a))

    # 3. Sidon-like via powers/golomb ruler approximation
    for _ in range(5):
        k = rng.randint(6, 12)
        marks = [0]
        used = {0}
        for _ in range(k - 1):
            cand = rng.randint(1, 200)
            d = {abs(cand - m) for m in marks}
            if d.isdisjoint(used - {0}):
                marks.append(cand)
                used |= d
        out.append(sorted(marks))

    # 4. Arithmetic-ish clusters with varied gaps
    for _ in range(5):
        n = rng.randint(15, 40)
        a = []
        x = 0
        for _ in range(n):
            a.append(x)
            x += rng.randint(1, 6)
        out.append(a)

    # 5. Baseline structure
    out.append([7, 15, 18, 22, -3, -2])
    return out


def solve():
    rng = random.Random(1234567)
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Phase 1: evaluate structured candidates and improve them
    cands = _candidate_patterns(rng)
    time_per = max(1.0, (deadline - time.time()) / max(1, len(cands) * 2))
    for a in cands:
        if time.time() > deadline - 2:
            break
        # quick local search first
        a2 = _local_search(a, time_per * 0.4, rng)
        s = _score(a2)
        if s > best_score:
            best, best_score = a2[:], s
        # greedy additions
        pool = list(range(-120, 121))
        a3 = _greedy_add(a2, pool, time_per * 0.6, rng)
        s = _score(a3)
        if s > best_score:
            best, best_score = a3[:], s

    # Phase 2: intensively polish the best
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    while time.time() < deadline - 1:
        cur = best[:]
        # perturb
        for _ in range(rng.randint(1, 4)):
            if not cur:
                break
            i = rng.randrange(len(cur))
            if rng.random() < 0.5:
                cur[i] += rng.randint(-5, 5)
            else:
                cur[i] += rng.randint(-30, 30)
        cur = list(dict.fromkeys(cur))
        cand = _local_search(cur, min(4.0, max(0.5, deadline - time.time())), rng)
        s = _score(cand)
        if s > best_score:
            best, best_score = cand[:], s
        else:
            # occasionally greedy-expand best
            if rng.random() < 0.35 and time.time() < deadline - 3:
                pool = list(range(-100, 101))
                a3 = _greedy_add(best, pool, 1.5, rng)
                s3 = _score(a3)
                if s3 > best_score:
                    best, best_score = a3[:], s3

    return sorted(set(best))
