import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _exact_score(a):
    a = list(a)
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _powers_of_two(n):
    # A = {2^0, 2^1, ..., 2^(n-1)}
    # differences: all sums of consecutive powers, unique for each pair -> 2n-1 distinct nonzero
    # sums: for i<j, 2^i+2^j is unique; also 2^{i+1} collides with 2^i+2^i for i<j?
    # 2^i + 2^i = 2^{i+1} which equals 2^(i+1) in the set. So sums have collisions.
    return [1 << i for i in range(n)]


def _random_offset_mix(n, offset_count, rng):
    base = _powers_of_two(n)
    offsets = sorted(rng.sample(range(1, 10**15), offset_count))
    return base + offsets


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _exact_score(best)
    deadline = time.time() + 110

    rng = random.Random(12345)

    # Try powers of two with various sizes, with scaling and offsets
    for n in range(2, 60):
        if time.time() > deadline:
            break
        base = _powers_of_two(n)
        s = _exact_score(base)
        if s > best_score:
            best_score, best = s, base[:]

    # Powers of two with large random offsets appended
    for trial in range(2000):
        if time.time() > deadline:
            break
        n = rng.randint(2, 50)
        k = rng.randint(0, 10)
        cand = _random_offset_mix(n, k, rng)
        s = _exact_score(cand)
        if s > best_score:
            best_score, best = s, cand[:]

    # Powers of two shifted by a constant (doesn't change differences/sums shape)
    for n in range(2, 60):
        if time.time() > deadline:
            break
        for shift in [rng.randint(-10**14, 10**14) for _ in range(5)]:
            base = [shift + (1 << i) for i in range(n)]
            s = _exact_score(base)
            if s > best_score:
                best_score, best = s, base[:]

    # Powers of two with a small common scaling factor
    for n in range(2, 60):
        if time.time() > deadline:
            break
        for scale in [rng.randint(1, 1000) for _ in range(5)]:
            base = [scale * (1 << i) for i in range(n)]
            s = _exact_score(base)
            if s > best_score:
                best_score, best = s, base[:]

    # Pure powers of two, largest useful n
    # For powers of two {1,2,4,...,2^{n-1}}:
    #   differences: all 2^k - 2^j = 2^j(2^{k-j}-1), which are unique -> 2n-1 distinct
    #   sums: 2^i + 2^j = 2^i(1+2^{j-i}) for i<=j. 2^i+2^i=2^{i+1} collides with element.
    # Let's just directly optimize n.
    best_n = 2
    best_n_score = -1
    for n in range(2, 2000):
        base = [(1 << i) for i in range(n)]
        s = _exact_score(base)
        if s > best_n_score:
            best_n_score = s
            best_n = n
        if time.time() > deadline:
            break
    base = [(1 << i) for i in range(best_n)]
    if best_n_score > best_score:
        best_score, best = best_n_score, base[:]

    # Some more refinement: append offsets optimized by local search
    cur = best[:]
    cur_set = set(cur)
    step = 10**14
    while time.time() < deadline:
        cand = cur[:]
        i = rng.randrange(len(cand))
        cand[i] = rng.randint(-10**15, 10**15)
        if len(set(cand)) < len(cand):
            continue
        s = _exact_score(cand)
        if s > best_score:
            best_score, best = s, cand[:]
            cur = cand[:]
        elif s > best_score * 0.999:
            cur = cand[:]
        # occasionally try appending
        if rng.random() < 0.01 and len(cand) < 2000:
            cand = cur + [rng.randint(-10**15, 10**15)]
            if len(set(cand)) == len(cand):
                s = _exact_score(cand)
                if s > best_score:
                    best_score, best = s, cand[:]
                    cur = cand[:]

    # Try powers of 2 with some negative values mixed (shifts), then optimize
    for n in range(2, 100):
        if time.time() > deadline:
            break
        base = [(1 << i) for i in range(n)]
        base = [x - base[n // 2] for x in base]
        s = _exact_score(base)
        if s > best_score:
            best_score, best = s, base[:]

    # Final local search around the best powers-of-two construction
    best_base = best[:]
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        i = rng.randrange(len(cand))
        delta = rng.choice([-1, 1]) * (10**rng.randint(0, 12))
        cand[i] += delta
        if len(set(cand)) < len(cand):
            continue
        s = _exact_score(cand)
        if s > best_score:
            best_score, best = s, cand[:]
            cur = cand[:]
        elif s > best_score * 0.9995:
            cur = cand[:]
        else:
            cur = best[:]

    # last check: ensure valid
    return sorted(set(int(x) for x in best))
