import math, random, time

def _diffs(a):
    return {x - y for x in a for y in a}

def _sums(a):
    return {x + y for x in a for y in a}

def _score_sets(d, s, n):
    if n < 2:
        return 0.0
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / n) / 100

def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    return _score_sets(_diffs(a), _sums(a), n)

def _rand_geo(rng):
    """Construct a set that tends to have many differences but few sums."""
    # Pick number of blocks
    k = rng.randint(2, 6)
    blocks = []
    # Each block is a short arithmetic-like cluster
    scale = 1
    offset = 0
    used = set()
    for _ in range(k):
        m = rng.randint(2, 6)
        step = rng.randint(1, 5)
        blk = [offset + scale * (i * step) for i in range(m)]
        blk = [x for x in blk if x not in used]
        for x in blk:
            used.add(x)
        blocks.extend(blk)
        offset += scale * (m * step + rng.randint(1, 10))
        scale = scale * rng.choice([1, 1, 2, 2, 3]) + rng.randint(0, 3)
    return blocks

def _mutate(a, rng):
    a = a[:]
    r = rng.random()
    if r < 0.55 and a:
        i = rng.randrange(len(a))
        a[i] += rng.randint(-4, 4)
    elif r < 0.8 and a:
        i = rng.randrange(len(a))
        del a[i]
    else:
        a.append(rng.randint(-40, 40))
    return a

def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110

    # Seed pool
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    pool = [best[:]]

    # Try known good structural ideas: geometric blocks
    for _ in range(30):
        cand = _rand_geo(rng)
        s = _score(cand)
        if s > best_score:
            best, best_score = cand[:], s
        pool.append(sorted(set(cand)))

    # Local search
    cur = best[:]
    cur_score = best_score
    start = time.time()
    it = 0
    while time.time() < deadline:
        it += 1
        cand = _mutate(cur, rng)
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif rng.random() < 0.08:
            # restart from a pool member or fresh geo
            if rng.random() < 0.5 and pool:
                cur = rng.choice(pool)[:]
            else:
                cur = _rand_geo(rng)
            cur_score = _score(cur)
    return best
