import math
import random
import time

def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    lst = list(a)
    for i in range(n):
        ai = lst[i]
        for j in range(n):
            diffs.add(ai - lst[j])
            sums.add(ai + lst[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            sums.add(ai + aj)
            diffs.add(ai - aj)
            diffs.add(aj - ai)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _greedy_sidon(n):
    """Greedy construction of a set with many distinct differences relative to sums."""
    A = [0]
    used_diffs = set()
    used_sums = set()
    for _ in range(1, n):
        best_x = None
        best_ratio = -1
        # candidates near next powers to avoid too many sums
        cands = set()
        top = A[-1]
        for k in range(1, 4 * n + 5):
            cands.add(top + k)
        for x in cands:
            if x in used_sums:
                continue
            d_add = 0
            s_add = 0
            new_d = set()
            new_s = set()
            for y in A:
                new_d.add(x - y)
                new_d.add(y - x)
                new_s.add(x + y)
            nd = len(new_d - used_diffs)
            ns = len(new_s - used_sums)
            # cells used
            if ns == 0:
                continue
            ratio = (nd + len(A)) / ns if ns else 0
            if ratio > best_ratio:
                best_ratio = ratio
                best_x = x
        if best_x is None:
            best_x = A[-1] + 1
        A.append(best_x)
        for y in A[:-1]:
            used_diffs.add(best_x - y)
            used_diffs.add(y - best_x)
            used_sums.add(best_x + y)
        used_sums.add(best_x + best_x)
    return A


def solve():
    deadline = time.time() + 100

    # Try several sizes; larger n gives bigger bonus and more diffs but sums grow too.
    best = None
    best_score = -1.0

    # Start from greedy Sidon set
    for n in (500, 1000, 1500, 2000, 2500):
        A = _greedy_sidon(n)
        s = _score_fast(A)
        if s > best_score:
            best_score = s
            best = A[:]
        if time.time() > deadline - 40:
            break

    if best is None:
        best = [0]
        best_score = -1.0

    # Local search: try to reduce number of sums by translating/clustering
    n = len(best)
    cur = sorted(set(best))
    random.seed(12345)
    while time.time() < deadline:
        cand = cur[:]
        # move a random element
        i = random.randrange(len(cand))
        delta = random.choice([-2, -1, 1, 2, -10, 10, -100, 100])
        cand[i] += delta
        if len(set(cand)) != len(cand):
            continue
        s = _score_fast(cand)
        if s >= best_score:
            best_score = s
            best = cand[:]
            cur = cand
        elif random.random() < 0.02:
            cur = best[:]

    # Final refinement: try to add elements that help
    return sorted(set(best))
