"""Sets with many differences and few sums.

Construction idea
-----------------
We want |A - A| large and |A + A| small.

Take A to be a "Sidon-like" set built from powers of two with controlled
offsets.  For a generic integer set, both |A-A| and |A+A| are about n^2,
so the ratio is about 1.  To get a ratio close to 2 we need the sumset to
collapse roughly by a factor of two relative to the difference set.

A clean family that does this: pick a rapidly growing base (powers of 2)
and place elements so that distinct pairs rarely produce equal sums, but
sums are naturally symmetric (a+b = b+a) and also collisions
a+b = c+d with {a,b} != {c,d} are forced when the set is symmetric about
a center.

Simplest strong family: A = { x : x in [0, 2^m) with exactly k odd... }
Rather than rely on a fragile theoretical family, we run a fast local
search / simulated annealing over structured candidate sets, evaluating
the true objective exactly, and keep the best.

The baseline builds small random sets.  We improve it by:
  * using several strong structured starting families,
  * exact fast scoring,
  * a hill climber with restarts and a time budget well inside 120s.
"""

import math
import random
import time

MAX_N = 4000
LIMIT = 10**15


def _diff_sum_sizes(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, n
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _score_from_counts(nd, ns, n):
    if ns <= 1 or n < 2:
        return -1e9
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _score(a):
    nd, ns, n = _diff_sum_sizes(a)
    return _score_from_counts(nd, ns, n)


def _candidate_powers(base, n):
    """Powers of `base`."""
    a = []
    v = 1
    for _ in range(n):
        a.append(v)
        v *= base
    return a


def _candidate_sidon_like(n):
    """Greedy Sidon set in [1, ...] scaled to keep size."""
    a = []
    used = set()
    x = 1
    # B_2 greedy: no two pairs share the same sum
    while len(a) < n and x < LIMIT:
        ok = True
        for u in a:
            for v in a:
                if u + v == 2 * x or u + x == v + x:
                    pass
        # Check that x + a and a + b collisions do not arise
        s = set()
        collision = False
        for i in range(len(a)):
            for j in range(i, len(a)):
                s.add(a[i] + a[j])
        newsums = set()
        for u in a:
            t = u + x
            if t in s or t in newsums:
                collision = True
                break
            newsums.add(t)
        if not collision:
            a.append(x)
        x += 1
    return a


def _candidate_geometric(base, n, shift):
    return [base ** i + shift for i in range(n)]


def _candidate_symmetric(n):
    """Symmetric about 0: A = -A.  Then sums collide heavily."""
    half = n // 2
    a = []
    v = 1
    for _ in range(half):
        a.append(v)
        a.append(-v)
        v *= 3
    if len(a) < n:
        a.append(0)
    return a


def _candidate_random_structured(n, rng):
    """Random subset of a geometric progression."""
    base = rng.choice([2, 3, 4])
    vals = []
    v = 1
    while len(vals) < min(4 * n, 20000) and v <= LIMIT:
        vals.append(v)
        v *= base
        v += rng.randint(0, 1)
    if len(vals) <= n:
        return vals
    return rng.sample(vals, n)


def _local_search(start, deadline, rng, best_global):
    a = sorted(set(start))
    if len(a) < 2:
        return best_global
    nd, ns, n = _diff_sum_sizes(a)
    cur_score = _score_from_counts(nd, ns, n)

    if cur_score > best_global[0]:
        best_global = (cur_score, a[:])

    step_scale = max(1, (max(a) - min(a)) // 20) if len(a) > 1 else 1
    while time.time() < deadline:
        cand = a[:]
        op = rng.random()
        if op < 0.55:
            # perturb one element
            i = rng.randrange(len(cand))
            delta = rng.randint(-step_scale, step_scale)
            if delta == 0:
                delta = 1
            cand[i] += delta
        elif op < 0.75:
            # move one element to a random new value
            i = rng.randrange(len(cand))
            cand[i] = rng.randint(1, max(2, max(cand) + step_scale))
        elif op < 0.88:
            # add an element
            if len(cand) < MAX_N:
                cand.append(rng.randint(1, max(2, max(cand) + step_scale)))
        else:
            # remove an element
            if len(cand) > 4:
                i = rng.randrange(len(cand))
                cand.pop(i)

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        if cand[0] < -LIMIT or cand[-1] > LIMIT:
            continue

        cnd, cns, cn = _diff_sum_sizes(cand)
        sc = _score_from_counts(cnd, cns, cn)

        if sc >= cur_score:
            a = cand
            cur_score = sc
            if sc > best_global[0]:
                best_global = (sc, a[:])
                step_scale = max(1, (max(a) - min(a)) // 20)
        else:
            # occasional restart-ish jump
            if rng.random() < 0.02:
                a = cand
                cur_score = sc
    return best_global


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 100.0

    best = (float("-inf"), [7, 15, 18, 22, -3, -2])

    starts = []
    # Strong structured starts
    starts.append([2 ** i for i in range(12)])
    starts.append([2 ** i for i in range(13)])
    starts.append([3 ** i for i in range(10)])
    starts.append([2 ** i - 1 for i in range(12)])
    starts.append([(2 ** i) for i in range(11)] + [-(2 ** i) for i in range(11)])
    # Singer-like / perfect difference set style: powers of 2 plus small offsets
    starts.append([2 ** i + (i % 3) for i in range(12)])
    starts.append([2 ** i + i for i in range(12)])
    starts.append([i * (i + 1) // 2 for i in range(1, 14)])

    for s in starts:
        best = _local_search(s, min(deadline, time.time() + 8), rng, best)

    # Random structured restarts until budget is nearly gone
    while time.time() < deadline - 3:
        n = rng.randint(8, 40)
        mode = rng.random()
        if mode < 0.3:
            start = _candidate_geometric(rng.choice([2, 3]), n, rng.randint(0, 3))
        elif mode < 0.6:
            start = _candidate_random_structured(n, rng)
        elif mode < 0.8:
            start = _candidate_symmetric(n)
        else:
            base = [2 ** i for i in range(n)]
            start = [b + rng.randint(-1, 1) for b in base]
        best = _local_search(start, min(deadline, time.time() + 4), rng, best)

    result = sorted(set(best[1]))
    result = [x for x in result if -LIMIT <= x <= LIMIT][:MAX_N]
    if len(result) < 2:
        result = [0, 1]
    return result
