import math
import random
import time

def _score_components(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls < 2 or ld < 2:
        return ld, ls, 0.0
    score = math.log(ld) / math.log(ls) + (1 - 1.0 / n) / 100
    return ld, ls, score

def _score(a):
    return _score_components(a)[2]

def _greedy_improve(a, deadline):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return a
    ld, ls, best_score = _score_components(a)
    best = a[:]
    improved = True
    while improved and time.time() < deadline:
        improved = False
        order = list(range(n))
        random.shuffle(order)
        for idx in order:
            if time.time() >= deadline:
                break
            orig = a[idx]
            cur_ld, cur_ls, cur_score = _score_components(a)
            best_delta = None
            best_val = orig
            trials = []
            step = max(1, abs(orig) if orig != 0 else 1)
            for mult in (1, 2, 4, 8):
                for s in (1, -1):
                    trials.append(orig + s * step // mult if step // mult > 0 else orig + s)
            trials.extend([orig + s for s in range(-3, 4)])
            trials.append(random.randint(-1000, 1000))
            for v in trials:
                if v == orig:
                    continue
                a[idx] = v
                nld, nls, nsc = _score_components(a)
                if nsc > best_score:
                    best_score = nsc
                    best_val = v
                    best_delta = True
            a[idx] = best_val
            if best_delta:
                improved = True
                best = a[:]
    return best

def solve():
    start_time = time.time()
    deadline = start_time + 110

    candidates = []

    # Candidate 1: geometric-ish set (sum-poor)
    A = []
    x = 1
    while len(A) < 200:
        A.append(x)
        x *= 2
    candidates.append(A)

    # Candidate 2: union of geometric blocks
    A = []
    x = 1
    for _ in range(50):
        A.append(x)
        x *= 3
    for k in range(1, 30):
        for b in A[:20]:
            A.append(b * (2 ** k) + k)
    candidates.append(list(set(A)))

    # Candidate 3: highly difference-rich set: take many elements with unique pairwise sums via construction
    A = []
    base = 1
    for i in range(120):
        A.append(base + i * i)
    candidates.append(A)

    # Candidate 4: near  arithmetic progression with unique shifts
    A = []
    for i in range(150):
        A.append(i * 1000 + i * i)
    candidates.append(A)

    # Candidate 5: random sparse large values
    random.seed(12345)
    A = random.sample(range(-(10**6), 10**6), 200)
    candidates.append(A)

    # Candidate 6: powers of 2 plus small perturbations
    A = []
    for i in range(300):
        A.append(2 ** i + (i * 7) % 13)
    candidates.append(list(set(A))[:300])

    # Candidate 7: Sidon-like via greedy
    A = [0]
    used = set([0])
    s = [0]
    diffs_used = set()
    v = 1
    while len(A) < 250 and v < 10**7:
        ok = True
        nd = set()
        for a in A:
            nd.add(v - a)
            nd.add(a - v)
        if not (nd & diffs_used):
            A.append(v)
            for d in nd:
                diffs_used.add(d)
        v += 1
    candidates.append(A)

    best = None
    best_score = -1e18
    for c in candidates:
        c = sorted(set(c))
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_score:
            best_score = sc
            best = c

    # Local search on best
    best = _greedy_improve(best, deadline - 10)

    # Try adding/removing elements greedily
    improved = True
    while improved and time.time() < deadline - 5:
        improved = False
        cur_ld, cur_ls, cur_sc = _score_components(best)
        # try merging with another candidate
        for c in candidates:
            c = sorted(set(c))
            if len(c) < 2:
                continue
            merged = sorted(set(best) | set(c))
            if len(merged) <= 4000:
                msc = _score(merged)
                if msc > cur_sc:
                    best = merged
                    cur_sc = msc
                    improved = True
        # try removing each element
        for i in range(len(best)):
            if time.time() >= deadline - 5:
                break
            cand = best[:i] + best[i+1:]
            if len(cand) < 2:
                continue
            sc = _score(cand)
            if sc > cur_sc:
                best = cand
                cur_sc = sc
                improved = True
                break
        # try adding random elements
        for _ in range(20):
            if time.time() >= deadline - 5:
                break
            cand = best + [random.randint(-(10**8), 10**8)]
            cand = sorted(set(cand))
            if len(cand) > 4000:
                continue
            sc = _score(cand)
            if sc > cur_sc:
                best = cand
                cur_sc = sc
                improved = True

    best = _greedy_improve(best, deadline)
    best = sorted(set(best))
    return best
