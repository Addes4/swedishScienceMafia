"""Search for integer sets maximizing log|A-A|/log|A+A| (with size bonus)."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _stats(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _greedy_extend(base, max_n, deadline):
    """Greedily add elements to maximize score-ish objective."""
    a = list(set(base))
    while len(a) < max_n and time.time() < deadline:
        best_add = None
        best_val = None
        # candidate new elements: near existing ones plus powers
        cands = set()
        for x in a:
            for d in (1, 2, 3, -1, -2, -3):
                cands.add(x + d)
        # add some larger values
        m = max(a)
        for k in range(1, 6):
            cands.add(m + 2 * k)
            cands.add(m + 3 * k)
        cands = [c for c in cands if c not in set(a)]
        random.shuffle(cands)
        for c in cands:
            trial = a + [c]
            d, s, _ = _stats(trial)
            if s == 0:
                continue
            val = math.log(d) / math.log(s)
            if best_val is None or val > best_val:
                best_val = val
                best_add = c
        if best_add is None:
            break
        a.append(best_add)
    return a


def solve():
    deadline = time.time() + 110.0
    random.seed(12345)
    best = None
    best_score = -1.0

    # Candidate seeds
    seeds = []

    # 1) Geometric-like: powers of 2 scaled
    seeds.append([1, 2, 4, 8, 16, 32, 64])
    # 2) Mixed near-geometric
    seeds.append([0, 1, 2, 4, 7, 12, 20, 33])
    # 3) Consecutive block (many diffs)
    seeds.append(list(range(30)))
    # 4) Baseline
    seeds.append([7, 15, 18, 22, -3, -2])
    # 5) Random spread
    for _ in range(3):
        seeds.append(sorted(random.sample(range(-200, 200), 12)))

    for seed in seeds:
        if time.time() > deadline:
            break
        a = _greedy_extend(seed, 60, deadline)
        sc = _score(a)
        if sc > best_score:
            best_score = sc
            best = a[:]

    # Local search refinement
    if best is None:
        best = [1, 2, 4, 8]
    cur = best[:]
    cur_score = _score(cur)

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-3, -2, -1, 1, 2, 3, 5, -5, 10, -10])
        elif op < 0.75:
            cand.append(random.randint(-500, 500))
        elif len(cand) > 3:
            i = random.randrange(len(cand))
            cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            continue
        sc = _score(cand)
        if sc > cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    # Try greedy extend on best
    if time.time() < deadline:
        ext = _greedy_extend(best, 80, deadline)
        sc = _score(ext)
        if sc > best_score:
            best = ext
            best_score = sc

    return sorted(set(int(x) for x in best))
