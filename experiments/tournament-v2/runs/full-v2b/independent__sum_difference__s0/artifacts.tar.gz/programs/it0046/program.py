import math
import random
import time

# EVOLVE-BLOCK-START
"""Local search with structured initialization for maximizing |A-A| / |A+A|."""


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            s = ai + aj
            if s in sums:
                pass
            else:
                sums.add(s)
        for j in range(n):
            d = ai - a[j]
            if d not in diffs:
                diffs.add(d)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _fast_score(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    a = list(s)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        return 0.0, ld, ls
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100, ld, ls


def solve():
    random.seed(12345)
    deadline = time.time() + 115.0

    best = None
    best_score = -1.0

    # structured candidates: consecutive block + scaled copy to spread differences
    candidates = []

    # A block of consecutive ints, plus a sparse set
    def make_block(n, start=0, step=1):
        return [start + step * i for i in range(n)]

    # Goldbach-like: {2i} union {odd small}
    for n1 in [40, 60, 80, 100, 150, 200]:
        A = list(range(n1))
        candidates.append(A)

    # scaled copy: consecutive block plus shifted far-away block
    for n1 in [30, 50, 80, 120]:
        A = list(range(n1))
        shift = 1000
        A2 = [shift + 3 * i for i in range(n1 // 2)]
        candidates.append(A + A2)

    # Sidon-ish random part + consecutive block
    for n1 in [50, 100, 150]:
        base = list(range(n1))
        extra = random.sample(range(10000, 50000), n1)
        A = list(set(base + extra))
        candidates.append(A)

    # pure random sparse sets
    for n1 in [50, 100, 200, 400]:
        A = random.sample(range(1, 10 * n1), n1)
        candidates.append(A)

    # Bentley-like: {1..n} plus powers of 2 scaled
    for n1 in [50, 80, 120]:
        A = list(range(1, n1 + 1))
        for k in range(1, 15):
            A.append((1 << k) * n1)
        A = list(set(A))
        candidates.append(A)

    for A in candidates:
        A = list(set(A))
        if len(A) < 2:
            continue
        sc, _, _ = _fast_score(A)
        if sc > best_score:
            best_score = sc
            best = A[:]

    if best is None:
        best = list(range(100))
        best_score, _, _ = _fast_score(best)

    cur = best[:]
    cur_score = best_score

    # local search
    iteration = 0
    while time.time() < deadline:
        iteration += 1
        cand = cur[:]
        op = random.random()

        if op < 0.45:
            # mutate an element
            i = random.randrange(len(cand))
            delta = random.choice([1, -1, 2, -2, 3, -3, 5, -5, 10, -10])
            cand[i] += delta
        elif op < 0.70:
            # add a new element near the set
            m = max(abs(x) for x in cand)
            newv = random.randint(-2 * m - 10, 2 * m + 10)
            cand.append(newv)
        elif op < 0.85 and len(cand) > 3:
            # remove an element
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # swap element with random
            i = random.randrange(len(cand))
            m = max(abs(x) for x in cand)
            cand[i] = random.randint(-2 * m - 10, 2 * m + 10)

        cand = list(set(cand))
        if len(cand) > 4000:
            continue
        if len(cand) < 2:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue

        sc, ld, ls = _fast_score(cand)
        n = len(cand)
        if sc > cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
                print(f"iter {iteration}: n={n} |A-A|={ld} |A+A|={ls} score={sc:.6f}",
                      flush=True)
        elif random.random() < 0.02:
            cur = cand
            cur_score = sc
        # occasional restart from best
        if iteration % 5000 == 0:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))


if __name__ == "__main__":
    A = solve()
    print("result size", len(A))
    print("score", _score(A))
# EVOLVE-BLOCK-END
