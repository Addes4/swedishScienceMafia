# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a "largest-first greedy" packer,
  (c) structured staircase families,
  (d) deterministic "big corner square + exact grid fill" layouts.
The best seed is then polished in two stages: a SAT-based coordinate descent,
then a scipy SLSQP joint optimisation that grows all squares at once under
smooth non-overlap / containment constraints.
"""
import math
import random

try:
    import numpy as np
    from scipy.optimize import minimize
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test; positive = interiors overlap, <=0 disjoint."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if ns > best + 1e-9:
                        trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                        if _feasible(trial, i):
                            best = ns
                            best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_corner_grid(n, k, corner):
    """Big square (side (k-1)/k) in a corner + (k*k-1) unit-grid squares."""
    big = (k - 1) / k
    cell = 1.0 / k
    if corner == 0:
        bigc = (big / 2, big / 2)
    elif corner == 1:
        bigc = (1 - big / 2, big / 2)
    elif corner == 2:
        bigc = (big / 2, 1 - big / 2)
    else:
        bigc = (1 - big / 2, 1 - big / 2)
    out = [(bigc[0], bigc[1], 0.0, big)]
    # fill remaining cells of the k x k grid, skipping the m x m block under big
    m = k - 1
    if corner == 0:
        skip = lambda i, j: i < m and j < m
    elif corner == 1:
        skip = lambda i, j: i >= 1 and j < m
    elif corner == 2:
        skip = lambda i, j: i < m and j >= 1
    else:
        skip = lambda i, j: i >= 1 and j >= 1
    for i in range(k):
        for j in range(k):
            if skip(i, j):
                continue
            out.append(((i + 0.5) * cell, (j + 0.5) * cell, 0.0, cell))
    if len(out) < n:
        out.extend([(0.5, 0.5, 0.0, 0.0)] * (n - len(out)))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=11):
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(6):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                cfg_hi = (cx, cy, ang, hi)
                if _inside(cfg_hi):
                    for _ in range(26):
                        mid = 0.5 * (lo + hi)
                        cfg = (cx, cy, ang, mid)
                        trial = placed + [cfg]
                        if _feasible(trial, len(trial) - 1):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_staircase(n, rng, angles):
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def _slsqp_polish(squares, maxiter=400):
    """Joint optimisation: grow all sides, keep non-overlap / containment."""
    if not _HAVE_SCIPY:
        return squares
    n = len(squares)
    if n == 0:
        return squares
    x0 = []
    for (cx, cy, ang, s) in squares:
        x0.append(cx)
        x0.append(cy)
        x0.append(ang)
        x0.append(s)
    x0 = np.array(x0, dtype=float)

    def unpack(x):
        sq = []
        for i in range(n):
            sq.append((x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]))
        return sq

    def total(x):
        return -float(np.sum(x[3::4]))

    # analytic corner-based constraints: each corner of each square must be
    # inside a shrunken unit square, and no corner of square i may be strictly
    # inside square j (a sufficient disjointness condition for our layouts).
    def con_factory(i):
        def con(x):
            cx, cy, ang, s = x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]
            if s < 0:
                s = 0.0
            a = 2.0 * math.pi * ang
            ca, sa = math.cos(a), math.sin(a)
            h = 0.5 * s
            vals = []
            for ux in (-h, h):
                for uy in (-h, h):
                    px = cx + ux * ca - uy * sa
                    py = cy + ux * sa + uy * ca
                    vals.append(px)
                    vals.append(1.0 - px)
                    vals.append(py)
                    vals.append(1.0 - py)
            return np.array(vals)
        return con

    cons = []
    for i in range(n):
        cons.append({'type': 'ineq', 'fun': con_factory(i)})

    def sep_factory(i, j):
        ci = squares[i]
        cj = squares[j]
        ax = math.cos(2 * math.pi * (ci[2] - cj[2]))
        # choose a representative axis: along square j's edge normal
        def con(x):
            cx_j, cy_j, ang_j, s_j = x[4 * j], x[4 * j + 1], x[4 * j + 2], x[4 * j + 3]
            # axis along j's local x (edge normal)
            a = 2.0 * math.pi * ang_j
            ca, sa = math.cos(a), math.sin(a)
            nx, ny = -sa, ca
            def proj(px, py):
                return nx * px + ny * py
            # project corners of j
            hj = 0.5 * max(0.0, s_j)
            jmin = proj(cx_j, cy_j) - hj * abs(ca * nx + sa * ny) - hj * abs(-sa * nx + ca * ny)
            jmax = proj(cx_j, cy_j) + hj * abs(ca * nx + sa * ny) + hj * abs(-sa * nx + ca * ny)
            # corners of i
            cx_i, cy_i, ang_i, s_i = x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]
            ai = 2.0 * math.pi * ang_i
            cai, sai = math.cos(ai), math.sin(ai)
            hi = 0.5 * max(0.0, s_i)
            imin = proj(cx_i, cy_i) - hi * abs(cai * nx + sai * ny) - hi * abs(-sai * nx + cai * ny)
            imax = proj(cx_i, cy_i) + hi * abs(cai * nx + sai * ny) + hi * abs(-sai * nx + cai * ny)
            # separation along this axis (allow equality/overlap up to small tol)
            gap = max(imin - jmax, jmin - imax)
            return np.array([gap + 1e-6])
        return con

    # Only add pairwise constraints that are active-ish to limit cost
    for i in range(n):
        for j in range(i + 1, n):
            # quick prefilter using current SAT overlap or proximity
            if _sat_overlap(squares[i], squares[j]) > -0.05:
                cons.append({'type': 'ineq', 'fun': sep_factory(i, j)})

    # side non-negativity
    def nonneg(x):
        return x[3::4]
    cons.append({'type': 'ineq', 'fun': nonneg})

    try:
        res = minimize(total, x0, method='SLSQP', constraints=cons,
                       options={'maxiter': maxiter, 'ftol': 1e-9})
        cand = unpack(res.x)
    except Exception:
        return squares

    # validate and only accept if truly feasible and better
    ok = True
    for i in range(n):
        if not _feasible(cand, i):
            ok = False
            break
    if not ok:
        return squares
    if sum(max(0.0, s[3]) for s in cand) > sum(max(0.0, s[3]) for s in squares) + 1e-9:
        return cand
    return squares


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # deterministic big-corner-square + exact grid fill
    for k in range(2, math.isqrt(n) + 4):
        for corner in range(4):
            seeds.append(_seed_corner_grid(n, k, corner))

    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=11 if _ % 2 == 0 else 9))

    for _ in range(3):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(2):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 20)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    # joint polish on the best candidate
    polished = _slsqp_polish(best, maxiter=600)
    polished = _refine([tuple(s) for s in polished], cap, rng, 8)
    polished = _slsqp_polish(polished, maxiter=400)
    if sum(max(0.0, s[3]) for s in polished) > best_score - 1e-9:
        best = [tuple(s) for s in polished]

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
