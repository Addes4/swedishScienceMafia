# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a "largest-first greedy" packer,
  (c) structured staircase families,
  (d) column-split families: a big square filling a full-height band plus a grid
      of the remainder (targets the moderate-n optima 1 + k*(fraction)),
and each seed is polished by a coordinate-descent that enlarges squares one at a
time.  Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(24):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(3):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_colsplit(n, band, vert=True):
    """One big square filling a full-height/-width band of width `band`;
    tile the remaining rectangle with a near-uniform grid."""
    band = min(max(band, 0.05), 0.95)
    rest = 1.0 - band
    out = []
    if vert:
        out.append((band / 2, 0.5, 0.0, band))
    else:
        out.append((0.5, band / 2, 0.0, band))
    m = n - 1
    if m <= 0:
        return out
    # choose grid for the remaining rectangle (rest x 1 or 1 x rest)
    best_g = None
    best_area = -1.0
    for cols in range(1, m + 2):
        rows = math.ceil(m / cols)
        side = min(rest / cols, 1.0 / rows)
        if side > best_area:
            best_area = side
            best_g = (cols, rows, side)
    cols, rows, side = best_g
    placed = 0
    for r in range(rows):
        for c in range(cols):
            if placed >= m:
                break
            if vert:
                x = band + (c + 0.5) * (rest / cols)
                y = (r + 0.5) * (1.0 / rows)
            else:
                x = (r + 0.5) * (1.0 / rows)
                y = band + (c + 0.5) * (rest / cols)
            out.append((min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0), 0.0, side))
            placed += 1
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=9):
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(5):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                cfg_hi = (cx, cy, ang, hi)
                if _inside(cfg_hi):
                    for _ in range(22):
                        mid = 0.5 * (lo + hi)
                        cfg = (cx, cy, ang, mid)
                        trial = placed + [cfg]
                        if _feasible(trial, len(trial) - 1):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_staircase(n, rng, angles):
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    k0 = max(1, math.isqrt(n))
    for k in range(max(1, k0 - 1), k0 + 2):
        seeds.append(_seed_grid(n, k))

    # Column-split families: big full-height band + tiled remainder (key for
    # the moderate-n optima of the form 1 + k*fraction).
    for band_i in range(20):
        band = 0.2 + 0.6 * band_i / 19.0
        seeds.append(_seed_colsplit(n, band, vert=True))
        seeds.append(_seed_colsplit(n, band, vert=False))

    # structured greedy seeds
    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=9 if _ % 2 == 0 else 7))

    for _ in range(3):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    # one-big-square seeds
    for _ in range(3):
        big = rng.uniform(0.45, 0.65)
        cx = rng.choice([big / 2, 1 - big / 2])
        cy = rng.choice([big / 2, 1 - big / 2])
        cfg = [(cx, cy, 0.0, big)]
        kk = max(1, math.ceil(math.sqrt(n)))
        side = 1.0 / kk
        i = 0
        while len(cfg) < n:
            i += 1
            x = (i % kk + 0.5) * side
            y = (i // kk + 0.5) * side
            cfg.append((x, y, 0.0, side * 0.8))
        seeds.append(cfg[:n])

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 20)
        squares = _refine(squares, cap, rng, 12)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
