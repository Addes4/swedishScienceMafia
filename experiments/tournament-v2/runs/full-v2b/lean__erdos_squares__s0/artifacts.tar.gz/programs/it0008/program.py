# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start coordinate descent.  We generate several structured
starting configurations (k x k grids, grids with a big square removed, staircase
patterns), then repeatedly try to enlarge one square at a time at its current
place (and at a few candidate angles), accepting any enlargement that keeps the
whole configuration interior-disjoint with a small safety margin, plus small
translations of a square to make room.  For small n we add a joint perturbation
search that can escape grid local optima.  Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test for two (possibly rotated) squares."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _all_feasible(squares):
    n = len(squares)
    for i in range(n):
        if not _inside(squares[i]):
            return False
        for j in range(i + 1, n):
            if _sat_overlap(squares[i], squares[j]) > 0.0:
                return False
    return True


def _total(squares):
    return sum(max(0.0, sq[3]) for sq in squares)


def _max_side_at(squares, idx, cx, cy, ang, cap):
    lo, hi = 0.0, cap
    if _feasible(squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:], idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _joint_search(squares, rng, trials, sigma0):
    """Random-restart joint perturbation search on all coords/sizes."""
    n = len(squares)
    best = [tuple(s) for s in squares]
    best_val = _total(best)
    sigma = sigma0
    for t in range(trials):
        cand = []
        for i in range(n):
            cx, cy, ang, s = best[i]
            ncx = min(1.0, max(0.0, cx + rng.gauss(0.0, sigma)))
            ncy = min(1.0, max(0.0, cy + rng.gauss(0.0, sigma)))
            nang = (ang + rng.gauss(0.0, sigma * 0.5)) % 1.0
            ns = min(1.0, max(0.0, s + rng.gauss(0.0, sigma * 0.7)))
            cand.append((ncx, ncy, nang, ns))
        if not _all_feasible(cand):
            continue
        # refine locally then evaluate
        refined = _refine([tuple(c) for c in cand], 1.0, rng, 6)
        if not _all_feasible(refined):
            continue
        val = _total(refined)
        if val > best_val + 1e-9:
            best = refined
            best_val = val
        if t % 40 == 39:
            sigma *= 0.7
            if sigma < 1e-3:
                sigma = sigma0
    return best


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_big(n, rng):
    out = []
    big = rng.uniform(0.4, 0.6)
    cx = rng.choice([big / 2, 1 - big / 2])
    cy = rng.choice([big / 2, 1 - big / 2])
    out.append((cx, cy, 0.0, big))
    k = max(1, math.ceil(math.sqrt(n)))
    side = 1.0 / k
    i = 0
    while len(out) < n:
        i += 1
        x = (i % k + 0.5) * side
        y = (i // k + 0.5) * side
        out.append((x, y, 0.0, side * 0.8))
    return out[:n]


def _seed_staircase(n, rng):
    """Decreasing squares along a diagonal, alternating near edges."""
    out = []
    total_w = 0.0
    sizes = []
    r = rng.uniform(0.8, 1.0)
    for i in range(n):
        sizes.append(r ** i)
    tot = sum(sizes)
    sizes = [s / tot for s in sizes]
    # place along zigzag from one corner
    x = 0.0
    y = 0.0
    for i, s in enumerate(sizes):
        cx = min(1.0 - s / 2, max(s / 2, x + s / 2))
        cy = min(1.0 - s / 2, max(s / 2, y + s / 2))
        out.append((cx, cy, 0.0, s))
        if i % 2 == 0:
            x += s * 0.6
            y += s * 0.6
        else:
            x += s * 0.3
    return out[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(2024 + n)
    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))
    for _ in range(4):
        seeds.append(_seed_big(n, rng))
    for _ in range(4):
        seeds.append(_seed_staircase(n, rng))

    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(4):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 25)
        for _ in range(2):
            squares = _refine(squares, cap, rng, 15)
        if not _all_feasible(squares):
            continue
        total = _total(squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        best = _seed_grid(n, max(1, math.isqrt(n)))
        best_score = _total(best)

    # joint perturbation search, more effort for small n where grid optima
    # are especially suboptimal vs. known staircase packings.
    if n <= 8:
        best = _joint_search(best, rng, 800, 0.12)
    elif n <= 16:
        best = _joint_search(best, rng, 400, 0.08)
    else:
        best = _joint_search(best, rng, 200, 0.05)

    # final cleanup / clamp
    out = []
    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        out.append((cx, cy, ang % 1.0, max(0.0, min(s, 1.0))))
    return out
# EVOLVE-BLOCK-END
