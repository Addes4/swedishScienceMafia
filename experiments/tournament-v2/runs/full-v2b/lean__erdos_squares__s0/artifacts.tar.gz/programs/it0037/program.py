# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a deterministic "big corner square + shelf strip" family that targets the
      known optima for moderate n (one large square in a corner, the L-shaped
      remainder filled with decreasing shelf rows),
  (c) a "largest-first greedy" packer,
  (d) structured staircase families.
Each seed is polished by a feasibility-checked coordinate descent that enlarges
squares one at a time.  Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test; positive = interiors overlap, <=0 disjoint."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(24):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(3):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_corner_shelf(n, big, corner):
    """One big square in a corner; fill the L-shaped remainder with shelf rows.

    corner: 0=bl(0,0) 1=br(1,0) 2=tl(0,1) 3=tr(1,1).
    The remainder is a 1-D strip; we fill it with rows whose squares exactly
    span each shelf, choosing sizes to maximise the count/sum balance.
    """
    out = []
    if corner == 0:
        bcx, bcy = big / 2, big / 2
        # horizontal shelf: y in [0,big], x in [big,1]
        hx, hy = big, 0.0
        w = 1.0 - big
        h = big
        # vertical shelf: x in [0,big], y in [big,1]
        vx, vy = 0.0, big
        vw, vh = big, 1.0 - big
    elif corner == 1:
        bcx, bcy = 1 - big / 2, big / 2
        hx, hy = 0.0, 0.0
        w = 1.0 - big
        h = big
        vx, vy = 1 - big, big
        vw, vh = big, 1.0 - big
    elif corner == 2:
        bcx, bcy = big / 2, 1 - big / 2
        hx, hy = big, 1 - big
        w = 1.0 - big
        h = big
        vx, vy = 0.0, 0.0
        vw, vh = big, 1.0 - big
    else:
        bcx, bcy = 1 - big / 2, 1 - big / 2
        hx, hy = 0.0, 1 - big
        w = 1.0 - big
        h = big
        vx, vy = 1 - big, 0.0
        vw, vh = big, 1.0 - big

    out.append((bcx, bcy, 0.0, big))
    remaining = n - 1

    # Greedily distribute squares between the two shelves, sized to fit height.
    # Shelf A (horizontal): can host floor(w/h) squares of side h, plus fill.
    def fill_shelf(x0, y0, ww, hh, count):
        res = []
        if count <= 0 or ww <= 0 or hh <= 0:
            return res
        s = min(hh, ww / max(1, count))
        # try to use as few rows as possible: place `count` squares each of side s
        for i in range(count):
            cxx = x0 + (i + 0.5) * s
            cyy = y0 + 0.5 * s
            if cxx + s / 2 > 1 + 1e-9 or cyy + s / 2 > 1 + 1e-9:
                break
            res.append((cxx, cyy, 0.0, s))
        return res

    # Decide split: shelf with larger area gets proportionally more squares.
    areaA = w * h
    areaB = vw * vh
    tot = areaA + areaB
    if tot <= 0:
        cntA = remaining
        cntB = 0
    else:
        cntA = int(round(remaining * areaA / tot))
        cntA = max(0, min(remaining, cntA))
        cntB = remaining - cntA

    # Shelf A orientation must allow side up to h; B up to vw/... just use fill
    out.extend(fill_shelf(hx, hy, w, h, cntA))
    out.extend(fill_shelf(vx, vy, vw, vh, cntB))

    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=9):
    placed = []
    for _k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(4):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                if not _inside((cx, cy, ang, hi)):
                    continue
                for _ in range(22):
                    mid = 0.5 * (lo + hi)
                    cfg = (cx, cy, ang, mid)
                    trial = placed + [cfg]
                    if _feasible(trial, len(trial) - 1):
                        lo = mid
                    else:
                        hi = mid
                if lo > best_s:
                    best_s = lo
                    best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_staircase(n, rng, angles):
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # deterministic big-corner + shelf family (cheap, targeted)
    if n >= 4:
        for corner in range(4):
            for big in (0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75):
                seeds.append(_seed_corner_shelf(n, big, corner))

    # greedy largest-first seedings
    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=9 if _ % 2 == 0 else 7))

    # staircase seedings
    for _ in range(3):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    # perturbed-grid seeds
    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(2):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    cap = 1.0
    best = None
    best_score = -1.0

    # Budget refinement: refine every seed lightly, keep the best, then deepen.
    ranked = []
    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 6)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        ranked.append((total, squares, sd))

    ranked.sort(key=lambda t: -t[0])

    for _, squares, _sd in ranked[:6]:
        sq = [tuple(x) for x in squares]
        sq = _refine(sq, cap, rng, 30)
        ok = True
        for i in range(n):
            if not _feasible(sq, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, s[3]) for s in sq)
        if total > best_score:
            best_score = total
            best = [tuple(s) for s in sq]

    if best is None:
        # fall back to whichever feasible seed we have
        for _, squares, _sd in ranked:
            best = [tuple(s) for s in squares]
            break
    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
