# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a "largest-first greedy" packer,
  (c) structured staircase families along the main diagonal (geometric sizes),
  (d) corner-big-square + L-remainder families.
Each seed is polished by a coordinate descent that enlarges squares one at a
time.  Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                    if _feasible(trial, i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=11):
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        cand_pts.append((0.5, 0.5))
        for _ in range(5):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                cfg_hi = (cx, cy, ang, hi)
                if not _inside(cfg_hi):
                    continue
                for _ in range(24):
                    mid = 0.5 * (lo + hi)
                    cfg = (cx, cy, ang, mid)
                    trial = placed + [cfg]
                    if _feasible(trial, len(trial) - 1):
                        lo = mid
                    else:
                        hi = mid
                if lo > best_s:
                    best_s = lo
                    best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_diag_stair(n, rng, angles, gap, ratio, start_side, jitter):
    """Squares of geometrically decreasing size, stepped along a diagonal path.

    gap controls how far apart consecutive squares are (relative to sizes);
    ratio is the size decay factor; start_side the first square's side.
    """
    out = []
    s = start_side
    # path direction
    dirx = 1.0
    diry = 1.0
    x, y = s / 2.0, s / 2.0
    for i in range(n):
        si = max(0.0, min(1.0, s))
        ang = angles[i % len(angles)]
        out.append((min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0), ang, si))
        step = si * (1.0 + gap)
        nx = x + step * dirx + (rng.uniform(-jitter, jitter) if jitter else 0.0)
        ny = y + step * diry * 0.85 + (rng.uniform(-jitter, jitter) if jitter else 0.0)
        # bounce within the unit square
        if nx - si / 2 < 0.0 or nx + si / 2 > 1.0:
            dirx = -dirx
            nx = x + step * dirx
        if ny - si / 2 < 0.0 or ny + si / 2 > 1.0:
            diry = -diry
            ny = y + step * diry * 0.85
        x, y = min(max(nx, 0.05), 0.95), min(max(ny, 0.05), 0.95)
        s *= ratio
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # greedy largest-first seedings
    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=10 if _ % 2 == 0 else 8))

    # diagonal staircase with geometric decay -- the key structured family
    stair_angles = [0.0, 0.25, 0.125]
    for ri, ratio in enumerate([0.6, 0.7, 0.8, 0.85, 0.9, 0.95]):
        for gap in (0.0, 0.05, 0.15):
            for start in (1.0 / math.sqrt(n) * 1.3,
                          1.0 / math.sqrt(n) * 1.7,
                          min(0.6, 1.0)):
                own_rng = random.Random(999 + n * 31 + ri * 7 + int(gap * 100) + int(start * 100))
                seeds.append(_seed_diag_stair(n, own_rng, stair_angles, gap, ratio,
                                              min(1.0, start), 0.0))
    # jittered variants around random parameters
    for _ in range(6):
        ratio = rng.uniform(0.55, 0.95)
        gap = rng.uniform(0.0, 0.25)
        start = min(1.0, rng.uniform(0.4, 1.0))
        seeds.append(_seed_diag_stair(n, rng, stair_angles, gap, ratio, start, 0.01))

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 20)
        squares = _refine(squares, cap, rng, 12)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
