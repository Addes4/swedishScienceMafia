# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a "largest-first greedy" packer,
  (c) structured staircase families along the main diagonal,
  (d) a deterministic "big corner square + shelf fill of the L-shaped remainder",
  (e) a deterministic "centered big square + border strip" family.
Each seed is polished by a coordinate-descent that enlarges squares one at a
time.  Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test; positive = interiors overlap, <=0 disjoint."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(26):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                    if _feasible(trial, i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=11):
    """Largest-first greedy: repeatedly place the biggest findable square."""
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(6):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                cfg_hi = (cx, cy, ang, hi)
                if _inside(cfg_hi):
                    lo = 0.0
                    for _ in range(24):
                        mid = 0.5 * (lo + hi)
                        cfg = (cx, cy, ang, mid)
                        trial = placed + [cfg]
                        if _feasible(trial, len(trial) - 1):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_staircase(n, rng, angles):
    """Place squares of decreasing size along a diagonal-ish path."""
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def _seed_corner_shelf(n, s_big, corner):
    """Big axis-aligned square in a corner; fill remaining L-region with shelves.

    For each shelf (row or column of the L), take the max equal square that fits.
    """
    sqs = []
    if corner in ('bl', 'br', 'tl', 'tr'):
        bx = 0.0 if corner in ('bl', 'tl') else 1.0 - s_big
        by = 0.0 if corner in ('bl', 'br') else 1.0 - s_big
    else:
        bx = by = 0.0
    sqs.append((bx + s_big / 2, by + s_big / 2, 0.0, s_big))
    # Remaining region: union of a vertical strip and a horizontal strip.
    # Two regimes depending on corner; fill greedily by rows.
    remaining = n - 1
    if remaining <= 0:
        return sqs
    # Determine the L region rectangles that are free.
    if corner in ('bl', 'tr'):
        # vertical strip on the far side, horizontal strip along the other
        rects = []
        if corner == 'bl':
            rects.append((s_big, 0.0, 1.0, 1.0 - s_big))  # top strip (x: s_big..1)
            rects.append((0.0, s_big, s_big, 1.0))         # right strip within y<s_big? no
        # Simpler: recompute generically below
        rects = None
    rects = None
    # Generic approach: rows of the L region.
    # Vertical strip: x in [s_big, 1] (or [0,1-s_big]), y in [0,1].
    # Horizontal strip: the complement of the big square in the other band.
    # We just tile with rows across the free x-range for y>s_big plus rows for
    # the free x band of the y<s_big region.
    if corner == 'bl':
        vx0, vx1 = s_big, 1.0
        hx0, hx1 = 0.0, s_big
        hy0, hy1 = s_big, 1.0
    elif corner == 'br':
        vx0, vx1 = 0.0, 1.0 - s_big
        hx0, hx1 = 1.0 - s_big, 1.0
        hy0, hy1 = s_big, 1.0
    elif corner == 'tl':
        vx0, vx1 = s_big, 1.0
        hx0, hx1 = 0.0, s_big
        hy0, hy1 = 0.0, 1.0 - s_big
    else:  # tr
        vx0, vx1 = 0.0, 1.0 - s_big
        hx0, hx1 = 1.0 - s_big, 1.0
        hy0, hy1 = 0.0, 1.0 - s_big

    def pack_rect(x0, x1, y0, y1, count, vertical):
        """Place `count` equal squares filling a rectangle via shelves."""
        out = []
        w = x1 - x0
        h = y1 - y0
        if count <= 0 or w <= 0 or h <= 0:
            return out, 0
        # shelf packing: choose number of rows/cols
        # Try to balance: rows r, cols c with r*c >= count
        best = None
        worst = 2 * (w + h)
        for r in range(1, count + 1):
            c = (count + r - 1) // r
            # square side determined by both dims
            sh = h / r
            sw = w / c
            s = min(sh, sw)
            if s > 1e-9:
                # waste metric
                waste = (w - c * s) + (h - r * s)
                if waste < worst - 1e-12:
                    worst = waste
                    best = (r, c, s)
        if best is None:
            return out, 0
        r, c, s = best
        # center shelf block
        offx = x0 + (w - c * s) / 2.0
        offy = y0 + (h - r * s) / 2.0
        placed = 0
        for i in range(r):
            for j in range(c):
                if placed >= count:
                    break
                cx = offx + (j + 0.5) * s
                cy = offy + (i + 0.5) * s
                out.append((cx, cy, 0.0, s))
                placed += 1
        return out, placed

    # Fill vertical strip then horizontal strip.
    # Vertical strip area
    got = 0
    if vx1 - vx0 > 1e-9 and 1.0 > 1e-9:
        # decide count for vertical strip by proportion of area
        area_v = (vx1 - vx0) * 1.0
        area_h = (hx1 - hx0) * (hy1 - hy0)
        tot = area_v + area_h
        cnt_v = remaining if tot <= 0 else int(round(remaining * area_v / tot))
        cnt_v = max(0, min(remaining, cnt_v))
        cnt_h = remaining - cnt_v
        pv, _ = pack_rect(vx0, vx1, 0.0, 1.0, cnt_v, True)
        ph, _ = pack_rect(hx0, hx1, hy0, hy1, cnt_h, False)
        sqs.extend(pv)
        sqs.extend(ph)
        got = len(pv) + len(ph)
    while got < remaining:
        sqs.append((0.5, 0.5, 0.0, 0.0))
        got += 1
    return sqs[:n]


def _seed_corner_shelf_family(n, rng):
    seeds = []
    if n < 2:
        return seeds
    corners = ['bl', 'br', 'tl', 'tr']
    # Sweep big square side.
    steps = 24
    for corner in corners:
        for i in range(steps):
            s_big = 0.30 + (0.680 - 0.30) * (i / max(1, steps - 1))
            try:
                seeds.append(_seed_corner_shelf(n, s_big, corner))
            except Exception:
                pass
    return seeds


def _seed_center_border(n, s_big):
    """One centered big square, remaining squares tiled in the four border strips."""
    sqs = [(0.5, 0.5, 0.0, s_big)]
    remaining = n - 1
    if remaining <= 0:
        return sqs
    b = (1.0 - s_big) / 2.0  # border width
    # Four strips: top, bottom, left, right (corners double-counted; use exact rects)
    strips = [
        (0.0, 1.0, 0.0, b),            # bottom
        (0.0, 1.0, 1.0 - b, 1.0),      # top
        (0.0, b, b, 1.0 - b),          # left (between)
        (1.0 - b, 1.0, b, 1.0 - b),    # right
    ]
    out = [sqs[0]]

    def pack_rect(x0, x1, y0, y1, count):
        w = x1 - x0
        h = y1 - y0
        res = []
        if count <= 0 or w <= 1e-9 or h <= 1e-9:
            return res
        best = None
        worst = 2 * (w + h)
        for r in range(1, count + 1):
            c = (count + r - 1) // r
            s = min(h / r, w / c)
            if s > 1e-9:
                waste = (w - c * s) + (h - r * s)
                if waste < worst - 1e-12:
                    worst = waste
                    best = (r, c, s)
        if best is None:
            return res
        r, c, s = best
        offx = x0 + (w - c * s) / 2.0
        offy = y0 + (h - r * s) / 2.0
        placed = 0
        for i in range(r):
            for j in range(c):
                if placed >= count:
                    break
                res.append((offx + (j + 0.5) * s, offy + (i + 0.5) * s, 0.0, s))
                placed += 1
        return res

    areas = [max(0.0, (x1 - x0) * (y1 - y0)) for (x0, x1, y0, y1) in strips]
    tot = sum(areas) if sum(areas) > 0 else 1.0
    counts = []
    acc = 0
    for a in areas:
        c = int(round(remaining * a / tot))
        counts.append(c)
        acc += c
    counts[-1] += remaining - acc
    got = 0
    for (rect, cnt) in zip(strips, counts):
        cnt = max(0, min(remaining - got, cnt))
        pr = pack_rect(rect[0], rect[1], rect[2], rect[3], cnt)
        out.extend(pr)
        got += len(pr)
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_center_border_family(n, rng):
    seeds = []
    if n < 2:
        return seeds
    steps = 20
    for i in range(steps):
        s_big = 0.25 + (0.75 - 0.25) * (i / max(1, steps - 1))
        try:
            seeds.append(_seed_center_border(n, s_big))
        except Exception:
            pass
    return seeds


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []

    # 1. structured deterministic seeds (fast, promising for medium n)
    struct = []
    struct.extend(_seed_corner_shelf_family(n, rng))
    struct.extend(_seed_center_border_family(n, rng))

    # 2. grids
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        struct.append(_seed_grid(n, k))

    # Polishing budget is limited; refine structured seeds hard first.
    best = None
    best_score = -1.0

    # Sort structured seeds by initial sum (cheap heuristic) and refine top ones.
    def init_sum(sd):
        return sum(max(0.0, sq[3]) for sq in sd)

    struct.sort(key=init_sum, reverse=True)
    n_struct_refine = min(len(struct), 14)
    for sd in struct[:n_struct_refine]:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, 1.0, rng, 22)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    # 3. stochastic seeds if time/budget allows
    stoch = []
    for _ in range(2):
        angles = base_angles if _ % 2 == 0 else [0.0]
        stoch.append(_seed_greedy(n, rng, angles, grid=9))
    for _ in range(2):
        angles = [0.0] if _ % 2 == 0 else base_angles
        stoch.append(_seed_staircase(n, rng, angles))

    for sd in stoch:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, 1.0, rng, 10)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is not None and best_score > 0:
        # try harder on the best
        more = _refine([tuple(x) for x in best], 1.0, rng, 12)
        ok = True
        for i in range(n):
            if not _feasible(more, i):
                ok = False
                break
        if ok:
            total = sum(max(0.0, sq[3]) for sq in more)
            if total > best_score:
                best = more

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
