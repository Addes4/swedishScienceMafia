# EVOLVE-BLOCK-START
"""Greedy largest-square packing plus local refinement.

Strategy:
1. Place squares one at a time. For each new square, search over candidate
   centres on a grid (and a few orientations) for the placement maximising the
   side length subject to non-overlap with already placed squares.
2. Refine all squares with coordinate descent: nudge each square's centre and
   side, keeping the configuration overlap free.
3. Remaining squares (if any couldn't grow) are placed as points.

Overlap test between two rotated squares is done via the Separating Axis
Theorem (SAT) on the unit box, which is exact for convex polygons.
"""
import math

SQRT2 = math.sqrt(2.0)


def _corners(cx, cy, ang, s):
    """Return the 4 corners of a square as a list of (x, y)."""
    h = s * 0.5
    c, si = math.cos(ang), math.sin(ang)
    # local corners (+-h, +-h)
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for lx, ly in pts:
        out.append((cx + lx * c - ly * si, cy + lx * si + ly * c))
    return out


def _axes(ang):
    c, si = math.cos(ang), math.sin(ang)
    return [(c, si), (-si, c)]


def _overlap(a, b):
    """True if the interiors of two squares a, b overlap (a=(cx,cy,ang,s))."""
    if a[3] <= 1e-12 or b[3] <= 1e-12:
        return False
    ca = _corners(*a)
    cb = _corners(*b)
    for ang in (a[2], b[2]):
        for ax, ay in _axes(ang):
            pa = [p[0] * ax + p[1] * ay for p in ca]
            pb = [p[0] * ax + p[1] * ay for p in cb]
            if max(pa) <= min(pb) + 1e-12 or max(pb) <= min(pa) + 1e-12:
                return False
    return True


def _inside(cx, cy, ang, s):
    """True if the square lies inside the unit square."""
    if s <= 1e-12:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    for x, y in _corners(cx, cy, ang, s):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(cx, cy, ang, s, placed):
    if not _inside(cx, cy, ang, s):
        return False
    cand = (cx, cy, ang, s)
    for p in placed:
        if _overlap(cand, p):
            return False
    return True


def _best_placement(placed, grid, angles):
    """Find (cx, cy, ang, s) maximising s among grid centres and angles."""
    best = None
    bs = 0.0
    n = len(placed)
    for ang in angles:
        for gi in range(grid + 1):
            cx = gi / grid
            for gj in range(grid + 1):
                cy = gj / grid
                # max possible side limited by distance to border
                lim = min(cx, 1 - cx, cy, 1 - cy)
                if lim <= bs:
                    continue
                # binary search largest feasible side at this (cx,cy,ang)
                lo, hi = 0.0, min(1.0, lim * SQRT2)
                if not _feasible(cx, cy, ang, hi, placed):
                    # shrink hi to something feasible
                    hi = min(hi, _max_side_here(cx, cy, ang, placed))
                if hi <= bs:
                    continue
                best = (cx, cy, ang, hi)
                bs = hi
    return best


def _max_side_here(cx, cy, ang, placed):
    """Binary search the largest feasible side at fixed centre/angle."""
    lo, hi = 0.0, min(1.0, min(cx, 1 - cx, cy, 1 - cy) * SQRT2)
    if hi <= 0:
        return 0.0
    if not _feasible(cx, cy, ang, hi, placed):
        hi = 1.0
        for _ in range(40):
            hi *= 0.5
            if _feasible(cx, cy, ang, hi, placed):
                break
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        if _feasible(cx, cy, ang, mid, placed):
            lo = mid
        else:
            hi = mid
    return lo


def _greedy(n):
    placed = []
    angles = [0.0, 0.25, 0.5, 0.75]
    for _ in range(n):
        grid = 12 if len(placed) < 4 else 10
        bp = _best_placement(placed, grid, angles)
        if bp is None or bp[3] <= 1e-9:
            placed.append((0.5, 0.5, 0.0, 0.0))
        else:
            cx, cy, ang, s = bp
            placed.append((cx, cy, ang, _max_side_here(cx, cy, ang, placed)))
    return placed


def _refine(placed):
    """Coordinate descent: try to grow/nudge each square."""
    placed = [list(p) for p in placed]
    for _ in range(6):
        improved = False
        for i in range(len(placed)):
            cur = placed[i]
            best = list(cur)
            # try shifts
            for dx in (-0.02, -0.01, 0.0, 0.01, 0.02):
                for dy in (-0.02, -0.01, 0.0, 0.01, 0.02):
                    nc = [cur[0] + dx, cur[1] + dy, cur[2], cur[3]]
                    if _ok(nc, placed, i):
                        # try to grow
                        g = _grow(nc, placed, i)
                        if g > best[3] + 1e-9:
                            best = [nc[0], nc[1], nc[2], g]
                            improved = True
            placed[i] = best
        if not improved:
            break
    return placed


def _ok(c, placed, idx):
    if not _inside(c[0], c[1], c[2], c[3]):
        return False
    for j, p in enumerate(placed):
        if j == idx:
            continue
        if _overlap(tuple(c), tuple(p)):
            return False
    return True


def _grow(c, placed, idx):
    lo, hi = c[3], min(1.0, 0.5 * SQRT2)
    for _ in range(25):
        mid = 0.5 * (lo + hi)
        nc = [c[0], c[1], c[2], mid]
        if _ok(nc, placed, idx):
            lo = mid
        else:
            hi = mid
    return lo


def solve(n):
    if n <= 0:
        return []
    placed = _greedy(n)
    try:
        placed = _refine(placed)
    except Exception:
        pass
    out = []
    for cx, cy, ang, s in placed:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, ang, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
