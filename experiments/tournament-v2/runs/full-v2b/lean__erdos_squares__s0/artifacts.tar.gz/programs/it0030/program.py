# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start with structured seeds that reproduce the known-optimal
"one big corner square + decreasing staircase" layouts, plus grids and greedy
seedings, all polished by a coordinate-descent that enlarges squares one at a
time (binary search on side, scanning candidate centres/angles).
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test; positive = interiors overlap, <=0 disjoint."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.04
            for _ in range(5):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375, -0.125):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=11):
    """Largest-first greedy: repeatedly place the biggest findable square."""
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(6):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                cfg_hi = (cx, cy, ang, hi)
                if _inside(cfg_hi):
                    lo = 0.0
                    for _ in range(24):
                        mid = 0.5 * (lo + hi)
                        cfg = (cx, cy, ang, mid)
                        trial = placed + [cfg]
                        if _feasible(trial, len(trial) - 1):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _staircase_chain(n, s0, r, x0, y0, corner):
    """Build n squares: first (big) at a corner, rest decreasing along an L.

    corner in {'bl','br','tl','tr'}; s0 = big square side.  Remaining squares
    are placed corner-to-corner with geometrically decreasing sides.
    """
    out = []
    big = min(s0, 1.0)
    if corner == 'bl':
        out.append((0.5 * big, 0.5 * big, 0.0, big))
        # chain runs along the top edge of the big square then up the right side
        # region: x in [big,1], plus y in [big,1] strip.  Use a folded path.
        x, y = big, 0.0
    elif corner == 'tr':
        out.append((1 - 0.5 * big, 1 - 0.5 * big, 0.0, big))
        x, y = 1 - big, 1.0
    elif corner == 'br':
        out.append((1 - 0.5 * big, 0.5 * big, 0.0, big))
        x, y = 1 - big, 0.0
    else:  # tl
        out.append((0.5 * big, 1 - 0.5 * big, 0.0, big))
        x, y = 0.0, 1 - big

    s = big
    # Folded staircase into the remaining L region.
    dirs = [(1, 0), (0, 1)]
    d = 0
    while len(out) < n:
        s = s * r
        if s <= 1e-9:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        dx, dy = dirs[d % 2]
        if corner == 'bl':
            nx, ny = x + dx * s, y + dy * s
        elif corner == 'tr':
            nx, ny = x - dx * s, y - dy * s
        elif corner == 'br':
            nx, ny = x - dx * s, y + dy * s
        else:
            nx, ny = x + dx * s, y - dy * s
        cx = min(max(nx + 0.5 * s * (1 if corner in ('bl', 'tl') else -1), 0.001), 0.999)
        cy = min(max(ny + 0.5 * s * (1 if corner in ('bl', 'br') else -1), 0.001), 0.999)
        out.append((cx, cy, 0.0, s))
        x, y = nx, ny
        d += 1
        if x < -0.2 or x > 1.2 or y < -0.2 or y > 1.2:
            # reset to a fresh strip
            if corner == 'bl':
                x, y = big, big
            elif corner == 'tr':
                x, y = 1 - big, 1 - big
            elif corner == 'br':
                x, y = 1 - big, big
            else:
                x, y = big, 1 - big
    return out[:n]


def _staircase_sweep(n):
    """Deterministic seeds: big corner square + decreasing chain, many params."""
    seeds = []
    corners = ['bl', 'br', 'tl', 'tr']
    rs = [0.55, 0.62, 0.7, 0.78, 0.85, 0.9, 0.95]
    # candidate big-square sides
    if n <= 20:
        s0s = [round(0.30 + 0.03 * i, 4) for i in range(14)]
    else:
        s0s = [round(0.2 + 0.05 * i, 4) for i in range(10)]
    for corner in corners:
        for s0 in s0s:
            for r in rs:
                seeds.append(_staircase_chain(n, s0, r, 0, 0, corner))
    return seeds


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    # Cheap structured seeds first (big-corner + staircase).
    seeds = _staircase_sweep(n)

    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=11 if _ % 2 == 0 else 9))

    cap = 1.0
    best = None
    best_score = -1.0

    # Polish structured seeds cheaply, keep the best few for deeper work.
    scored = []
    for sd in seeds:
        squares = [tuple(x) for x in sd]
        for i in range(n):
            if not _feasible(squares, i):
                # drop infeasible seed
                squares = None
                break
        if squares is None:
            continue
        squares = _refine(squares, cap, rng, 8)
        total = sum(max(0.0, sq[3]) for sq in squares)
        scored.append((total, squares))

    if not scored:
        return _seed_grid(n, max(1, math.isqrt(n)))

    scored.sort(key=lambda t: -t[0])
    # Deep polish on the best candidates.
    deep = scored[:6]
    for total, squares in deep:
        for _ in range(3):
            squares = _refine(squares, cap, rng, 20)
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        best = scored[0][1]

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
