# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start coordinate descent with a "grow-shrink" repair step.
Structured starts (k x k grids, big-square + grid, staircase patterns) are
refined by repeatedly enlarging one square at a time; when a square is blocked,
its blocking neighbours are temporarily shrunk so the target can grow, then
re-expanded.  Exact separating-axis overlap tests with a small margin keep the
configuration interior-disjoint.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test; returns overlap depth (>0 overlapping)."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    if _feasible(squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:], idx):
        return hi
    for _ in range(26):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _total(squares):
    return sum(max(0.0, sq[3]) for sq in squares)


def _refine(squares, cap, rng, iters):
    """Coordinate descent: enlarge each square, with jitter."""
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.05
            for _ in range(5):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if ns > best + 1e-9 and _feasible(
                            squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:], i):
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _grow_shrink(squares, rng, rounds=6):
    """Repair pass: shrink squares blocking a target, grow target, re-expand."""
    n = len(squares)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            cx, cy, ang, s = squares[i]
            # candidate target configs
            best_conf = None
            best_delta = 1e-9
            cands = []
            for ddx, ddy in ((0, 0), (0.02, 0), (-0.02, 0), (0, 0.02), (0, -0.02),
                             (0.03, 0.03), (-0.03, 0.03), (0.03, -0.03), (-0.03, -0.03)):
                ncx = min(1.0, max(0.0, cx + ddx))
                ncy = min(1.0, max(0.0, cy + ddy))
                for da in (0.0, 0.25, 0.125):
                    cands.append((ncx, ncy, (ang + da) % 1.0))
            for (ncx, ncy, na) in cands:
                # find which squares overlap a tentative bigger i
                tgt = (ncx, ncy, na, max(s, 1e-3) + 0.2)
                blocked = []
                for j in range(n):
                    if j == i:
                        continue
                    if _sat_overlap(tgt, squares[j]) > 0.0:
                        blocked.append(j)
                if not blocked:
                    continue
                saved = [(j, squares[j]) for j in blocked]
                # shrink blockers to fit
                feasible_blockers = True
                for (j, _sq) in saved:
                    shrunk = list(squares[j])
                    # binary search shrink that removes overlap with tgt
                    lo, hi = 0.0, shrunk[3]
                    jj = j
                    for _ in range(20):
                        mid = 0.5 * (lo + hi)
                        trial = list(squares[jj])
                        trial[3] = mid
                        if _sat_overlap(tgt, tuple(trial)) > 0.0:
                            hi = mid
                        else:
                            lo = mid
                    shrunk[3] = lo
                    squares[jj] = tuple(shrunk)
                # now grow i as far as possible
                ns = _max_side_at(squares, i, ncx, ncy, na, 1.0)
                old_sum = sum(max(0.0, sq[3]) for sq in saved) + s
                new_sum = sum(max(0.0, sq[3]) for _, sq in [(j, squares[j]) for j, _ in saved]) + ns
                # re-expand blockers greedily
                for (j, _sq) in saved:
                    js = squares[j]
                    nsj = _max_side_at(squares, j, js[0], js[1], js[2], 1.0)
                    squares[j] = (js[0], js[1], js[2], nsj)
                    new_sum += nsj - js[3]
                if new_sum > old_sum + best_delta and _feasible(
                        squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:], i):
                    best_delta = new_sum - old_sum
                    best_conf = (ncx, ncy, na, ns)
                    # commit the blocker shrink + target grow
                    for (j, _sq) in saved:
                        pass
                else:
                    # revert blockers
                    for (j, sq) in saved:
                        squares[j] = sq
            if best_conf is not None:
                ncx, ncy, na, ns = best_conf
                # recompute blockers consistently: just try to set and re-expand
                squares[i] = (ncx, ncy, na, ns)
                # safe measure: if infeasible, revert handled below
                if _feasible(squares, i):
                    improved = True
                else:
                    squares[i] = (cx, cy, ang, s)
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_staircase(n, rng):
    """A sequence of decreasing squares placed corner to corner (zig-zag)."""
    # side lengths from a geometric-ish decreasing sequence
    base = rng.uniform(0.5, 0.75) if n > 1 else 1.0
    ratio = rng.uniform(0.55, 0.9)
    sides = [base * (ratio ** i) for i in range(n)]
    out = []
    x, y = 0.0, 0.0
    for i, s in enumerate(sides):
        # place square touching left or bottom, stepping along
        if i % 2 == 0:
            out.append((min(1.0, s / 2), min(1.0, 1.0 - s / 2), 0.0, s))
        else:
            out.append((min(1.0, 1.0 - s / 2), min(1.0, s / 2), 0.0, s))
    # jitter
    res = []
    for (cx, cy, ang, s) in out:
        res.append((min(1.0, max(0.0, cx + rng.uniform(-0.02, 0.02))),
                    min(1.0, max(0.0, cy + rng.uniform(-0.02, 0.02))),
                    ang, s))
    return res


def _seed_big(n, rng):
    out = []
    big = rng.uniform(0.45, 0.6)
    cx = rng.choice([big / 2, 1 - big / 2])
    cy = rng.choice([big / 2, 1 - big / 2])
    out.append((cx, cy, 0.0, big))
    k = max(1, math.ceil(math.sqrt(n)))
    side = 1.0 / k
    i = 0
    while len(out) < n:
        i += 1
        x = (i % k + 0.5) * side
        y = (i // k + 0.5) * side
        out.append((x, y, 0.0, side * 0.8))
    return out[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))
    for _ in range(3):
        seeds.append(_seed_big(n, rng))
    for _ in range(4):
        seeds.append(_seed_staircase(n, rng))

    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(3):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 25)
        squares = _grow_shrink(squares, rng, rounds=4)
        squares = _refine(squares, cap, rng, 20)
        squares = _grow_shrink(squares, rng, rounds=3)
        squares = _refine(squares, cap, rng, 15)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = _total(squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
