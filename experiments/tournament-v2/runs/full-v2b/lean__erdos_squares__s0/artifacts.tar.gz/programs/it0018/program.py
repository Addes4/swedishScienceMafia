# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a "largest-first greedy" packer,
  (c) structured staircase families along the main diagonal (dominant for n>=6),
  (d) a parametric diagonal staircase with side ratio swept for maximum objective.
Each seed is polished by a SAT-based coordinate descent that enlarges squares one
at a time.  Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test; positive = interiors overlap, <=0 disjoint."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                    if _feasible(trial, i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_staircase(n, rng, angles):
    """Place squares of decreasing size along a diagonal-ish path."""
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def _diag_staircase(n, r):
    """Place n axis-aligned squares corner-to-corner along main diagonal.

    Square i has side s_i = S * r^i.  Greedily place each square in the tightest
    feasible position that keeps the whole chain inside the unit square and packs
    tight.  Returns config or None if not fit.  r in (0, 1].
    """
    # total length requirement: sum s_i <= 1 along each axis if stacked corner-to-corner
    # choose S so that chain exactly spans [0,1]
    # sum_{i} S r^i = S (1-r^n)/(1-r) = 1  -> S = (1-r)/(1-r^n)
    if abs(r - 1.0) < 1e-9:
        S = 1.0 / n
    else:
        S = (1.0 - r) / (1.0 - r ** n)
    if S <= 0:
        return None
    sizes = [S * (r ** i) for i in range(n)]
    # Check diagonal feasibility: each square i occupies [x_i, x_i+s_i] x [y_i, y_i+s_i]
    # with x_{i+1} = x_i + s_i - overlap handling.  Simplest: stair-step.
    # Place corner-to-corner: square i at origin (x_i, y_i), next at (x_i+s_i, y_i)
    # then step down.  We use a simple diagonal monotone layout.
    out = []
    x, y = 0.0, 0.0
    for i in range(n):
        si = sizes[i]
        if x + si > 1.0 + 1e-9 or y + si > 1.0 + 1e-9:
            return None
        out.append((x + si / 2, y + si / 2, 0.0, si))
        # advance along the diagonal: move right and up by the side
        x += si
        y += si
    return out


def _diag_staircase_alt(n, r):
    """Alternate diagonal: squares touch, each new square placed so its top-left
    corner touches the previous square's bottom-right corner (zigzag)."""
    if abs(r - 1.0) < 1e-9:
        S = 1.0 / n
    else:
        S = (1.0 - r) / (1.0 - r ** n)
    if S <= 0:
        return None
    sizes = [S * (r ** i) for i in range(n)]
    out = []
    x, y = 0.0, 0.0
    # place along anti-diagonal in a staircase so it spans the square
    for i in range(n):
        si = sizes[i]
        cx = x + si / 2
        cy = y + si / 2
        if cx < 0 or cx > 1 or cy < 0 or cy > 1:
            return None
        if x < -1e-9 or y < -1e-9 or x + si > 1 + 1e-9 or y + si > 1 + 1e-9:
            return None
        out.append((cx, cy, 0.0, si))
        x += si
        if (i % 2 == 0):
            y += si
        else:
            y = max(0.0, y - si * 0.5)
    return out


def _best_diag_seed(n, angles, rng):
    """Sweep ratio r for the diagonal staircase family; return best-scoring seed."""
    best = None
    best_score = -1.0
    rs = []
    if n > 1:
        for k in range(1, 201):
            rs.append(k / 200.0)
        rs += [0.98, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6]
    for r in rs:
        cfg = _diag_staircase(n, r)
        if cfg is not None:
            sc = sum(s[3] for s in cfg)
            if sc > best_score:
                best_score = sc
                best = cfg
        cfg = _diag_staircase_alt(n, r)
        if cfg is not None:
            sc = sum(s[3] for s in cfg)
            if sc > best_score:
                best_score = sc
                best = cfg
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # staircase seedings
    for _ in range(6):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    # parametric diagonal staircase (strong for n>=5)
    diag = _best_diag_seed(n, base_angles, rng)
    if diag is not None:
        seeds.append(diag)
        # also seed rotated variants
        for da in (0.0, 0.125, 0.0625, -0.0625):
            pass

    # "one big square + grid" seeds
    for _ in range(3):
        big = rng.uniform(0.45, 0.62)
        cx = rng.choice([big / 2, 1 - big / 2])
        cy = rng.choice([big / 2, 1 - big / 2])
        cfg = [(cx, cy, 0.0, big)]
        k = max(1, math.ceil(math.sqrt(n)))
        side = 1.0 / k
        i = 0
        while len(cfg) < n:
            i += 1
            x = (i % k + 0.5) * side
            y = (i // k + 0.5) * side
            cfg.append((x, y, 0.0, side * 0.8))
        seeds.append(cfg[:n])

    # perturbed-grid seeds
    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(3):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 25)
        for _ in range(2):
            squares = _refine(squares, cap, rng, 15)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
