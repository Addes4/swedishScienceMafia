# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a "largest-first greedy" packer that repeatedly places the biggest square
      it can find (scanning a fine grid of candidate centres and several angles
      against the already-placed squares),
  (c) structured staircase families along the main diagonal,
  (d) a "big square in a corner + decreasing staircase fill" family that targets
      the optimal structure for moderate n,
  (e) "one big square + remainder grid" families.
Each seed is polished by a coordinate-descent that enlarges squares one at a time.
Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test; positive = interiors overlap, <=0 disjoint."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                    if _feasible(trial, i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=11):
    """Largest-first greedy: repeatedly place the biggest findable square."""
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(6):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                cfg_hi = (cx, cy, ang, hi)
                if _inside(cfg_hi):
                    lo = 0.0
                    for _ in range(26):
                        mid = 0.5 * (lo + hi)
                        cfg = (cx, cy, ang, mid)
                        trial = placed + [cfg]
                        if _feasible(trial, len(trial) - 1):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_cfg = (cx, cy, ang, lo)
        if best_s <= 0.0:
            placed.append((0.5, 0.5, 0.0, 0.0))
        else:
            placed.append(best_cfg)
    return placed


def _seed_staircase(n, rng, angles):
    """Place squares of decreasing size along a diagonal-ish path."""
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def _seed_big_corner_staircase(n, big, ratio, corner):
    """One big square in a corner + decreasing staircase in the leftover L."""
    parts = []
    # big square occupies the given corner
    hb = big / 2.0
    if corner == 0:
        bcx, bcy = hb, hb
    elif corner == 1:
        bcx, bcy = 1.0 - hb, hb
    elif corner == 2:
        bcx, bcy = hb, 1.0 - hb
    else:
        bcx, bcy = 1.0 - hb, 1.0 - hb
    parts.append((bcx, bcy, 0.0, big))
    # remaining square sizes as a geometric-ish staircase summing to leftover
    rem = n - 1
    if rem <= 0:
        return parts[:n]
    # Put sizes decreasing along a path that snakes
    sizes = []
    s = big * 0.9
    for i in range(rem):
        sizes.append(max(1e-4, s))
        s *= ratio
    # place them greedily-along a staircase avoiding the big square region
    x, y = 0.0, 0.0
    for i in range(rem):
        si = sizes[i]
        # choose center avoiding big square (keep packing simple: walk from opposite corner)
        px = x + si / 2
        py = y + si / 2
        px = min(1.0 - si / 2, max(si / 2, px))
        py = min(1.0 - si / 2, max(si / 2, py))
        parts.append((px, py, 0.0, si))
        x += si
        if x + si > 1.0:
            x = 0.0
            y += si
    return parts[:n]


def _seed_big_remainder(n, big, k):
    cfg = []
    hb = big / 2.0
    cfg.append((hb, hb, 0.0, big))
    side = (1.0 - big) / k if k > 0 else 0.0
    i = 0
    while len(cfg) < n:
        i += 1
        x = big + (i % k + 0.5) * side
        y = (i // k + 0.5) * side
        if x > 1.0:
            break
        cfg.append((x, y, 0.0, side))
    while len(cfg) < n:
        cfg.append((0.5, 0.5, 0.0, 0.0))
    return cfg[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # greedy largest-first seedings
    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=9 if _ % 2 == 0 else 7))

    # staircase seedings
    for _ in range(3):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    # big corner + staircase family (deterministic sweep)
    for corner in range(4):
        for big in (0.45, 0.5, 0.55, 0.6, 0.65):
            for ratio in (0.7, 0.8, 0.9):
                seeds.append(_seed_big_corner_staircase(n, big, ratio, corner))

    # big square + remainder grid
    for big in (0.4, 0.48, 0.52, 0.6):
        for k in range(1, max(2, math.isqrt(n) + 2)):
            seeds.append(_seed_big_remainder(n, big, k))

    # perturbed-grid seeds
    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(3):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    cap = 1.0
    best = None
    best_score = -1.0

    # limit number of polished seeds for time safety
    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 12)
        squares = _refine(squares, cap, rng, 8)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
