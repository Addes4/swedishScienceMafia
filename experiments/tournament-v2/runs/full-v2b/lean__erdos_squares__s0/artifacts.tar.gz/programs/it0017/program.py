# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths."""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _perturb(squares, rng, mag):
    out = []
    for (cx, cy, ang, s) in squares:
        ncx = min(1.0, max(0.0, cx + rng.uniform(-mag, mag)))
        ncy = min(1.0, max(0.0, cy + rng.uniform(-mag, mag)))
        na = (ang + rng.uniform(-mag, mag)) % 1.0
        out.append((ncx, ncy, na, s))
    return out


def _refine(squares, cap, rng, iters, spread=0.03):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-spread, spread))),
                                          min(1.0, max(0.0, cy + rng.uniform(-spread, spread)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                    if _feasible(trial, i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _grow_seed(squares, cap, rng, rounds=3):
    """Joint enlargement: scale all squares about a few anchor points, keep if feasible."""
    n = len(squares)
    best = [tuple(sq) for sq in squares]
    best_total = sum(sq[3] for sq in best)

    anchors = [(0.5, 0.5), (0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0),
               (0.25, 0.25), (0.75, 0.75)]
    for _ in range(rounds):
        progressed = False
        for (ax, ay) in anchors:
            for _ in range(3):
                # scale up all squares about anchor
                f = 1.0 + 0.02
                cand = []
                for (cx, cy, ang, s) in best:
                    ns = min(cap, s * f)
                    ncx = ax + (cx - ax) * f
                    ncy = ay + (cy - ay) * f
                    cand.append((min(1.0, max(0.0, ncx)),
                                 min(1.0, max(0.0, ncy)), ang, ns))
                ok = True
                for i in range(n):
                    if not _feasible(cand, i):
                        ok = False
                        break
                if ok:
                    tot = sum(sq[3] for sq in cand)
                    if tot > best_total + 1e-9:
                        best = cand
                        best_total = tot
                        progressed = True
                    else:
                        break
                else:
                    # partial: allow shrink to fix then re-grow via refine
                    break
        if not progressed:
            break
    return best


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_big_corner(n, rng, k):
    """One large square in a corner, remainder tiled by an (k) grid clipped to L."""
    big = 1.0
    for _ in range(6):
        big = rng.uniform(0.4, 0.65)
        break
    side = (1.0 - big) / max(1, k) if k > 0 else 0.0
    sq = float(big)
    corner = rng.randint(0, 3)
    if corner == 0:
        config = [(sq / 2, sq / 2, 0.0, sq)]
        x0, y0 = 0.0, 0.0
    elif corner == 1:
        config = [(1 - sq / 2, sq / 2, 0.0, sq)]
        x0, y0 = 1.0 - big, 0.0
    elif corner == 2:
        config = [(sq / 2, 1 - sq / 2, 0.0, sq)]
        x0, y0 = 0.0, 1.0 - big
    else:
        config = [(1 - sq / 2, 1 - sq / 2, 0.0, sq)]
        x0, y0 = 1.0 - big, 1.0 - big
    # fill remainder with equal squares
    cell = (1.0 - big) / max(1, k)
    placed = [config[0]]
    i = 0
    while len(placed) < n:
        i += 1
        # tile the two strips
        gx = (i - 1) % max(1, k)
        gy = (i - 1) // max(1, k)
        cx = gx * cell + cell / 2
        cy = gy * cell + cell / 2
        placed.append((min(0.999, max(0.001, cx)), min(0.999, max(0.001, cy)), 0.0, cell * 0.95))
    return placed[:n]


def _seed_greedy(n, rng, angles, grid=11):
    placed = []
    step = 1.0 / (grid - 1)
    cand_pts = []
    for gi in range(grid):
        for gj in range(grid):
            cand_pts.append((gi * step, gj * step))
    for _ in range(6):
        cand_pts.append((rng.random(), rng.random()))
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        for (cx, cy) in cand_pts:
            for ang in angles:
                cfg_hi = (cx, cy, ang, 1.0)
                if not _inside(cfg_hi):
                    continue
                lo, hi = 0.0, 1.0
                for _ in range(24):
                    mid = 0.5 * (lo + hi)
                    cfg = (cx, cy, ang, mid)
                    trial = placed + [cfg]
                    if _feasible(trial, len(trial) - 1):
                        lo = mid
                    else:
                        hi = mid
                if lo > best_s:
                    best_s = lo
                    best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(98765 + n)
    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # greedy largest-first seedings
    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=10 if _ % 2 == 0 else 8))

    # big-corner family
    for bb in range(6):
        rng2 = random.Random(bb * 131 + n)
        seeds.append(_seed_big_corner(n, rng2, max(1, math.isqrt(n))))

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 25)
        squares = _grow_seed(squares, cap, rng, rounds=2)
        squares = _refine(squares, cap, rng, 20)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
