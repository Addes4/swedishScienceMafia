# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a fast parametric "big square in a corner + L-shaped strip grid" family
      that matches the structure of the best known packings,
  (c) a "largest-first greedy" packer,
  (d) structured staircase families along the main diagonal.
Each seed is polished by a coordinate-descent that enlarges squares one at a
time.  Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test; positive = interiors overlap, <=0 disjoint."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                    if _feasible(trial, i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _fill_rect(out, x0, y0, x1, y1, count):
    """Tile rectangle with `count` equal-ish squares, appending to out."""
    w = x1 - x0
    h = y1 - y0
    if count <= 0:
        return
    # choose a column count that best balances the cells
    best = None
    best_waste = None
    for cols in range(1, count + 1):
        rows = (count + cols - 1) // cols
        if cols * rows < count:
            continue
        cw = w / cols
        ch = h / rows
        side = min(cw, ch)
        # unused cells up to count
        waste = cols * rows - count
        score = -side + waste * 1e-4
        if best_waste is None or score < best_waste:
            best_waste = score
            best = (cols, rows, cw, ch)
    if best is None:
        return
    cols, rows, cw, ch = best
    side = min(cw, ch)
    made = 0
    for r in range(rows):
        for c in range(cols):
            if made >= count:
                break
            cx = x0 + (c + 0.5) * cw
            cy = y0 + (r + 0.5) * ch
            out.append((cx, cy, 0.0, side))
            made += 1
    while made < count:
        out.append((x0 + w * 0.5, y0 + h * 0.5, 0.0, 0.0))
        made += 1


def _seed_corner_L(n, rng, angles, sweep=40):
    """One big square in a corner + L-shaped remainder tiled with small squares."""
    seeds = []
    k = max(1, math.isqrt(n))
    for corner in [(0, 0), (1, 0), (0, 1), (1, 1)]:
        for t in range(sweep):
            big = 0.30 + (0.65 - 0.30) * (t / max(1, sweep - 1))
            rem = n - 1
            if rem < 0:
                continue
            cx = big / 2 if corner[0] == 0 else 1 - big / 2
            cy = big / 2 if corner[1] == 0 else 1 - big / 2
            out = [(cx, cy, 0.0, big)]
            # L-shaped remainder: two rectangles
            if corner == (0, 0):
                # right strip: x in [big,1], y in [0,1]; top strip: x in [0,big], y in [big,1]
                strip_a = (1.0 - big) * 1.0
                strip_b = big * (1.0 - big)
            elif corner == (1, 0):
                strip_a = big * 1.0
                strip_b = (1.0 - big) * (1.0 - big)
            elif corner == (0, 1):
                strip_a = big * 1.0
                strip_b = (1.0 - big) * (1.0 - big)
            else:
                strip_a = (1.0 - big) * 1.0
                strip_b = big * (1.0 - big)
            # split remainder roughly proportional to capacity
            ca = strip_a
            cb = strip_b
            tot = ca + cb if (ca + cb) > 0 else 1.0
            na = int(round(rem * ca / tot))
            na = max(0, min(rem, na))
            nb = rem - na
            # rectangle A (vertical strip / left block) and rectangle B
            if corner == (0, 0):
                _fill_rect(out, big, 0.0, 1.0, 1.0, na)
                _fill_rect(out, 0.0, big, big, 1.0, nb)
            elif corner == (1, 0):
                _fill_rect(out, 0.0, 0.0, 1.0 - big, 1.0, na)
                _fill_rect(out, 1.0 - big, big, 1.0, 1.0, nb)
            elif corner == (0, 1):
                _fill_rect(out, 0.0, 0.0, 1.0, 1.0 - big, na)
                _fill_rect(out, big, 1.0 - big, 1.0, 1.0, nb)
            else:
                _fill_rect(out, 0.0, 0.0, 1.0, 1.0, na) if False else _fill_rect(out, 0.0, 0.0, 1.0, 1.0 - big, na)
                _fill_rect(out, 0.0, 1.0 - big, 1.0 - big, 1.0, nb)
            while len(out) < n:
                out.append((0.5, 0.5, 0.0, 0.0))
            seeds.append(out[:n])
    return seeds


def _seed_greedy(n, rng, angles, grid=9):
    """Largest-first greedy: repeatedly place the biggest findable square."""
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(4):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                cfg_hi = (cx, cy, ang, hi)
                if _inside(cfg_hi):
                    lo = 0.0
                    for _ in range(24):
                        mid = 0.5 * (lo + hi)
                        cfg = (cx, cy, ang, mid)
                        trial = placed + [cfg]
                        if _feasible(trial, len(trial) - 1):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_staircase(n, rng, angles):
    """Place squares of decreasing size along a diagonal-ish path."""
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.5, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]

    rng = random.Random(12345 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # Fast parametric corner big-square + L-strip seeds (the key ingredient)
    seeds.extend(_seed_corner_L(n, rng, base_angles, sweep=28))

    # greedy largest-first seedings
    for _ in range(2):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_greedy(n, rng, angles, grid=9))

    # staircase seedings
    for _ in range(3):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    # perturbed-grid seeds
    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(2):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    # "one big square" seeds of mixed sizes
    for _ in range(2):
        big = rng.uniform(0.45, 0.62)
        cx = rng.choice([big / 2, 1 - big / 2])
        cy = rng.choice([big / 2, 1 - big / 2])
        cfg = [(cx, cy, 0.0, big)]
        k = max(1, math.ceil(math.sqrt(n)))
        side = 1.0 / k
        i = 0
        while len(cfg) < n:
            i += 1
            x = (i % k + 0.5) * side
            y = (i // k + 0.5) * side
            cfg.append((x, y, 0.0, side * 0.8))
        seeds.append(cfg[:n])

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 18)
        for _ in range(2):
            squares = _refine(squares, cap, rng, 10)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END

