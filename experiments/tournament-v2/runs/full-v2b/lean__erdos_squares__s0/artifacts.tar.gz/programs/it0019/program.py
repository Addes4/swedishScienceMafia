# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: deterministic parametric seed families targeting the known-optimal
asymmetric structures (staircases of decreasing squares, and one-big-square +
remainder strips), followed by a SAT-based coordinate-descent polish with a
global scale-up attempt.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test; positive = interiors overlap, <=0 disjoint."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(24):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _scale_up(squares, cap=1.08):
    """Try to scale the whole packing about its bbox centre to fit; return best."""
    best = [tuple(sq) for sq in squares]
    best_tot = sum(sq[3] for sq in best)
    cx = sum(sq[0] for sq in squares) / len(squares)
    cy = sum(sq[1] for sq in squares) / len(squares)
    lo, hi = 1.0, 1.0
    # find max factor via bisection on feasibility
    hi = cap
    for _ in range(24):
        mid = 0.5 * (lo + hi)
        trial = []
        for (x, y, a, s) in squares:
            nx = cx + (x - cx) * mid
            ny = cy + (y - cy) * mid
            trial.append((nx, ny, a, s * mid))
        ok = True
        for i in range(len(trial)):
            if not _feasible(trial, i):
                ok = False
                break
        if ok:
            lo = mid
        else:
            hi = mid
    trial = []
    for (x, y, a, s) in squares:
        nx = cx + (x - cx) * lo
        ny = cy + (y - cy) * lo
        trial.append((nx, ny, a, s * lo))
    ok = True
    for i in range(len(trial)):
        if not _feasible(trial, i):
            ok = False
            break
    if ok:
        tot = sum(sq[3] for sq in trial)
        if tot > best_tot:
            best = trial
            best_tot = tot
    return best, best_tot


def _seed_staircase(n, ratio, ang):
    """Squares of geometrically decreasing side along the main diagonal."""
    out = []
    total = sum(ratio ** i for i in range(n))
    s0 = 1.0 / total
    x, y = 0.0, 0.0
    for i in range(n):
        si = s0 * (ratio ** i)
        if si <= 0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        out.append((x + si / 2, y + si / 2, ang, si))
        x += si
        y += si
    return out


def _seed_big_corner_grid(n, big, k):
    """One big square in corner + grid of small squares in L region."""
    side = 1.0 / k
    small = min(side, (1.0 - big))
    out = [(big / 2, big / 2, 0.0, big)]
    # fill L: right strip and top strip
    i = 0
    for yy in range(k):
        if len(out) >= n:
            break
        cy = (yy + 0.5) * small
        if cy + small / 2 <= big + 1e-9:
            cx = big + small / 2
        else:
            cx = small / 2
        out.append((cx, cy, 0.0, small))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.375]

    seeds = []

    # Staircase seeds: sweep ratio and angle.
    for ratio in (0.55, 0.62, 0.68, 0.75, 0.80, 0.85, 0.90, 0.94, 0.97):
        for ang in ([0.0] if n <= 8 else base_angles):
            seeds.append(_seed_staircase(n, ratio, ang))

    # Big-square + grid seeds
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        for big in (0.4, 0.5, 0.55, 0.6, 0.65):
            if big <= 1.0:
                seeds.append(_seed_big_corner_grid(n, big, k))

    # Grid seeds
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # Random staircase perturbations
    for _ in range(6):
        ratio = rng.uniform(0.5, 0.98)
        ang = rng.choice(base_angles)
        s = _seed_staircase(n, ratio, ang)
        ss = []
        for (x, y, a, sz) in s:
            ss.append((min(0.999, max(0.001, x + rng.uniform(-0.02, 0.02))),
                       min(0.999, max(0.001, y + rng.uniform(-0.02, 0.02))),
                       a, sz))
        seeds.append(ss)

    cap = 1.0
    best = None
    best_score = -1.0

    # Deduplicate roughly
    seen = 0
    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 20)
        squares, tot = _scale_up(squares)
        squares = _refine(squares, cap, rng, 12)
        squares, tot2 = _scale_up(squares)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]
        seen += 1
        if seen > 60:
            break

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    # Final heavy polish on the best
    best = _refine(best, cap, rng, 30)
    best, _ = _scale_up(best)

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END

