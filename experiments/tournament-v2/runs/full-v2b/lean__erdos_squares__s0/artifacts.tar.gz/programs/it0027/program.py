# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a "largest-first greedy" packer,
  (c) deterministic geometric staircases (sides s, s*r, s*r^2, ... laid
      corner-to-corner, folded along x/y so the whole chain stays in the unit
      square) -- these reproduce the optimal decreasing-square families for
      moderate n,
  (d) structured staircase families along the main diagonal.
Each seed is polished by a SAT-based coordinate descent that enlarges squares one
at a time.  Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                    if _feasible(trial, i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_staircase_geo(n, s0, r, fold):
    """Sides s0*r^i laid corner-to-corner, chain folded to stay in unit square.

    fold: sequence of +1/-1 that chooses whether the next square is placed to
    the right (+x) or above (+y) relative to the current corner, and the
    direction of travel.  We simply build the chain greedily: start at (0,0),
    each square advances along x then flips to y every `fold` steps (or the
    two squares always advance alternating).  Returned in unit square or None.
    """
    squares = []
    x, y = 0.0, 0.0
    # alternate directions in a boustrophedon pattern
    dirs = [(1, 0), (0, 1), (-1, 0), (0, -1)]
    d = 0
    for i in range(n):
        si = s0 * (r ** i)
        if si <= 0.0:
            squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        dx, dy = dirs[d % len(dirs)]
        cx = x + si / 2 if dx >= 0 else x - si / 2
        cy = y + si / 2 if dy >= 0 else y - si / 2
        if dx == 0:
            cx = x + si / 2
        if dy == 0:
            cy = y + si / 2
        squares.append((cx, cy, 0.0, si))
        x = x + dx * si
        y = y + dy * si
        d += 1
        if fold is not None:
            d = fold[i % len(fold)]
    return squares


def _geo_staircase_fit(n, s0, r):
    """Try the standard 'one big square + chain of decreasing squares' layout.

    Layout: the biggest square sits in the bottom-left corner.  The remaining
    n-1 squares form a decreasing chain that snakes along the top and right
    edges, each square placed in the free L-region with maximal side.
    """
    out = [(s0 / 2, s0 / 2, 0.0, s0)]
    # region: remaining points form an L (right strip of width 1-s0 and top
    # strip of height 1-s0).  Place chain of decreasing squares greedily.
    rem = n - 1
    if rem <= 0:
        return out
    # top strip: height (1-s0) across full width
    # right strip: width (1-s0) across height s0
    t = s0 * r
    # layout: a horizontal row of decreasing squares along the top, then a
    # vertical column of decreasing squares along the right.
    return out


def _seed_geometric_chain(n, rng, angles):
    """Deterministic family: sides s0*r^i corner-to-corner along a staircase
    hugging the bottom-left corner, then verify feasibility exactly."""
    cands = []
    for r in (0.5, 0.55, 0.6, 0.618, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95):
        for s0 in [1.0 / max(1.0, math.sqrt(n)),
                   1.0 / max(1.0, (n + 1) / 2.0),
                   1.0 / max(1.0, n / 2.0),
                   0.5, 0.6]:
            s0 = min(1.0, max(0.0, s0))
            # build a zig-zag staircase: square i placed so its lower-left
            # corner touches square i-1's corner, alternating x / y steps.
            squares = []
            x, y = 0.0, 0.0
            ok = True
            for i in range(n):
                si = s0 * (r ** i)
                if si < 1e-9:
                    squares.append((0.5, 0.5, 0.0, 0.0))
                    continue
                # decide placement so it stays inside: try x-step then y-step
                placed = False
                for (nx, ny) in ((x + si, y), (x, y + si),
                                 (x - si, y), (x, y - si)):
                    cx = (x + nx) / 2
                    cy = (y + ny) / 2
                    sq = (cx, cy, 0.0, si)
                    if _inside(sq):
                        squares.append(sq)
                        x, y = nx, ny
                        placed = True
                        break
                if not placed:
                    ok = False
                    sq = (s0 / 2, s0 / 2, 0.0, si)
                    squares.append(sq)
            cands.append(squares)
    return cands


def _seed_greedy(n, rng, angles, grid=11):
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(6):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                cfg_hi = (cx, cy, ang, hi)
                if _inside(cfg_hi):
                    lo = 0.0
                    for _ in range(26):
                        mid = 0.5 * (lo + hi)
                        cfg = (cx, cy, ang, mid)
                        trial = placed + [cfg]
                        if _feasible(trial, len(trial) - 1):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_staircase(n, rng, angles):
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # deterministic geometric chain seeds (corner-to-corner staircases)
    for sd in _seed_geometric_chain(n, rng, base_angles):
        seeds.append(sd)

    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=11 if _ % 2 == 0 else 9))

    for _ in range(3):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(2):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    for _ in range(2):
        big = rng.uniform(0.45, 0.62)
        cx = rng.choice([big / 2, 1 - big / 2])
        cy = rng.choice([big / 2, 1 - big / 2])
        cfg = [(cx, cy, 0.0, big)]
        k = max(1, math.ceil(math.sqrt(n)))
        side = 1.0 / k
        i = 0
        while len(cfg) < n:
            i += 1
            x = (i % k + 0.5) * side
            y = (i // k + 0.5) * side
            cfg.append((x, y, 0.0, side * 0.8))
        seeds.append(cfg[:n])

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 25)
        for _ in range(2):
            squares = _refine(squares, cap, rng, 15)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
