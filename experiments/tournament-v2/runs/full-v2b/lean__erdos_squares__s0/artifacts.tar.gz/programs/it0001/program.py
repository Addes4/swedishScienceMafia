# EVOLVE-BLOCK-START
"""Grid seeding + local optimization of square positions, angles, and sizes."""
import math
import random

random.seed(12345)


def corners(cx, cy, a, s):
    """Return the 4 corners of a square with centre (cx,cy), angle a (turns), side s."""
    t = 2.0 * math.pi * a
    ca, sa = math.cos(t), math.sin(t)
    h = s * 0.5
    # local corners (+-h, +-h) rotated
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        px = cx + ca * dx - sa * dy
        py = cy + sa * dx + ca * dy
        pts.append((px, py))
    return pts


def inside(cx, cy, a, s):
    for x, y in corners(cx, cy, a, s):
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def overlap_amount(s1, s2):
    """Positive if the two squares' interiors overlap; use SAT."""
    c1 = corners(*s1)
    c2 = corners(*s2)
    for poly in (c1, c2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            nx, ny = -ey, ex
            # project both
            proj1 = [nx * px + ny * py for px, py in c1]
            proj2 = [nx * px + ny * py for px, py in c2]
            if max(proj1) <= min(proj2) + 1e-12 or max(proj2) <= min(proj1) + 1e-12:
                return 0.0
    # compute overlap area via clipping (Sutherland-Hodgman)
    def clip(subject, clip_poly):
        out = subject
        n = len(clip_poly)
        for i in range(n):
            if not out:
                return []
            ax, ay = clip_poly[i]
            bx, by = clip_poly[(i + 1) % n]
            ex, ey = bx - ax, by - ay
            # inside test: cross >= 0 (counter-clockwise clip)
            def inside_p(px, py):
                return ex * (py - ay) - ey * (px - ax) >= -1e-12
            new = []
            m = len(out)
            for j in range(m):
                px, py = out[j]
                qx, qy = out[(j + 1) % m]
                pin = inside_p(px, py)
                qin = inside_p(qx, qy)
                if pin:
                    new.append((px, py))
                if pin != qin:
                    dx, dy = qx - px, qy - py
                    denom = ex * dy - ey * dx
                    if abs(denom) > 1e-15:
                        t = (ex * (py - ay) - ey * (px - ax)) / denom
                        new.append((px + t * dx, py + t * dy))
            out = new
        return out
    # ensure both polygons counter-clockwise
    def ccw(poly):
        area = 0.0
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            area += x1 * y2 - x2 * y1
        return poly if area >= 0 else poly[::-1]
    poly = clip(ccw(c1), ccw(c2))
    if len(poly) < 3:
        return 0.0
    area = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def total_penalty(squares):
    pen = 0.0
    m = len(squares)
    for i in range(m):
        if not inside(*squares[i]):
            pen += 10.0
        for j in range(i + 1, m):
            ov = overlap_amount(squares[i], squares[j])
            if ov > 0:
                pen += ov * 50.0
    return pen


def objective(squares):
    return sum(s[3] for s in squares) - total_penalty(squares)


def grid_seed(n, cols):
    rows = (n + cols - 1) // cols
    squares = []
    used = 0
    for r in range(rows):
        for c in range(cols):
            if used >= n:
                break
            cx = (c + 0.5) / cols
            cy = (r + 0.5) / rows
            s = min(1.0 / cols, 1.0 / rows)
            squares.append([cx, cy, 0.0, s])
            used += 1
    return squares[:n]


def repair(squares):
    """Shrink overlapping / out-of-bounds squares until feasible."""
    for _ in range(200):
        changed = False
        m = len(squares)
        for i in range(m):
            cx, cy, a, s = squares[i]
            if not inside(cx, cy, a, s):
                squares[i][3] *= 0.999
                changed = True
        for i in range(m):
            for j in range(i + 1, m):
                if overlap_amount(squares[i], squares[j]) > 1e-12:
                    squares[i][3] *= 0.999
                    squares[j][3] *= 0.999
                    changed = True
        if not changed:
            break
    return squares


def local_opt(squares, iters=4000):
    squares = [list(s) for s in squares]
    m = len(squares)
    best = objective(squares)
    step = 0.02
    for it in range(iters):
        if it % 400 == 0 and it > 0:
            step *= 0.7
        if step < 1e-4:
            break
        idx = random.randrange(m)
        old = squares[idx][:]
        # perturb a random component
        comp = random.randrange(4)
        if comp == 3:
            squares[idx][3] = max(0.0, old[3] + random.uniform(-step, step))
        elif comp == 2:
            squares[idx][2] = old[2] + random.uniform(-step, step)
        else:
            squares[idx][comp] = min(1.0, max(0.0, old[comp] + random.uniform(-step, step)))
        newval = objective(squares)
        if newval > best:
            best = newval
        else:
            squares[idx] = old
    return squares


def solve(n):
    if n == 0:
        return []
    candidates = []
    best = None
    best_score = -1e18
    # try a range of column counts and initial sizes
    col_opts = set()
    for c in range(1, n + 1):
        col_opts.add(c)
    for cols in sorted(col_opts):
        seed = grid_seed(n, cols)
        # try shrinking seed a bit to allow optimization room
        for shrink in (1.0, 0.95):
            sq = [[x, y, a, s * shrink] for (x, y, a, s) in seed]
            sq = local_opt(sq, iters=2000)
            sq = repair(sq)
            val = sum(s[3] for s in sq)
            if val > best_score:
                best_score = val
                best = sq
    # final cleanup
    best = repair(best)
    return [tuple(s) for s in best]
# EVOLVE-BLOCK-END
