# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a "largest-first greedy" packer,
  (c) structured staircase families along the main diagonal,
  (d) a deterministic "big square in a corner + regular grid of the L-shaped
      remainder" family (sweeping the big side finely) -- this targets the
      n=6..15 optima (k-1 unit-grid squares + one enlarged square).
Each seed is polished by coordinate descent that enlarges squares one at a time.
Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(24):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(3):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if ns > best + 1e-9:
                        trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                        if _feasible(trial, i):
                            best = ns
                            best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_big_corner(n, a, corner):
    """One square of side a in a corner, remainder filled with a regular grid."""
    rem = n - 1
    if rem <= 0:
        cx = 0.5 if corner in (0, 3) else 0.5
        return [(0.5, 0.5, 0.0, a)]
    # choose k so that k*k >= rem, and grid side fits the L region
    k = max(1, math.ceil(math.sqrt(rem)))
    gs = 1.0 / k
    out = []
    # big square anchored at the chosen corner
    if corner == 0:      # bottom-left
        out.append((a / 2, a / 2, 0.0, a))
    elif corner == 1:    # bottom-right
        out.append((1 - a / 2, a / 2, 0.0, a))
    elif corner == 2:    # top-left
        out.append((a / 2, 1 - a / 2, 0.0, a))
    else:                # top-right
        out.append((1 - a / 2, 1 - a / 2, 0.0, a))
    # fill the rest with grid squares of side gs, skipping those that hit the big
    cnt = 1
    # iterate over grid cells of size gs across [0,1]
    kk = k
    cells = []
    for gi in range(kk):
        for gj in range(kk):
            x0, y0 = gi * gs, gj * gs
            x1, y1 = x0 + gs, y0 + gs
            cells.append((x0 + gs / 2, y0 + gs / 2))
    for (gx, gy) in cells:
        if cnt >= n:
            break
        out.append((gx, gy, 0.0, gs))
        cnt += 1
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_staircase(n, rng, angles):
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    seeds = []
    # regular grids
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # BIG deterministic family: big corner square + regular grid remainder.
    # Sweep the big side finely; this directly produces the n=6..15 optima shape.
    for corner in range(4):
        a = 0.05
        while a <= 0.96:
            seeds.append(_seed_big_corner(n, a, corner))
            a += 0.01

    # staircase seeds
    for _ in range(3):
        angles = [0.0] if _ % 2 == 0 else [0.0, 0.25, 0.125]
        seeds.append(_seed_staircase(n, rng, angles))

    # "one big square centered" seeds
    for _ in range(2):
        big = rng.uniform(0.45, 0.62)
        cx = rng.choice([big / 2, 1 - big / 2])
        cy = rng.choice([big / 2, 1 - big / 2])
        cfg = [(cx, cy, 0.0, big)]
        k = max(1, math.ceil(math.sqrt(n)))
        side = 1.0 / k
        i = 0
        while len(cfg) < n:
            i += 1
            x = (i % k + 0.5) * side
            y = (i // k + 0.5) * side
            cfg.append((x, y, 0.0, side * 0.8))
        seeds.append(cfg[:n])

    cap = 1.0
    best = None
    best_score = -1.0

    # keep the seed count bounded so we finish in time
    max_seeds = 90
    if len(seeds) > max_seeds:
        # prioritize grids + a subsample of the big-corner family + others
        grids = seeds[:max(1, math.isqrt(n) + 2 - max(1, math.isqrt(n) - 1))]
        big = seeds[len(grids):len(grids) + max_seeds - len(grids) - 5]
        step = max(1, len(big) // max(1, max_seeds - len(grids) - 5))
        big = big[::step]
        rest = seeds[len(grids) + len(big):]
        seeds = grids + big + rest[:5]
    seeds = seeds[:max_seeds]

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, cap, rng, 12)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    # final polish of the best solution
    best = _refine([tuple(s) for s in best], cap, rng, 25)

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
