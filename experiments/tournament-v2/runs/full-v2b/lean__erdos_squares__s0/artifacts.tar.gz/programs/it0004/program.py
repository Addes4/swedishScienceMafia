# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start coordinate descent.  We generate several structured
starting configurations (k x k grids, grids with a big square removed, staircase
patterns), then repeatedly try to enlarge one square at a time at its current
place (and at a few candidate angles), accepting any enlargement that keeps the
whole configuration interior-disjoint with a small safety margin, plus small
translations of a square to make room.  Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    # local corners (+-h, +-h) rotated
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Exact-ish separating axis test for two (possibly rotated) squares.

    Returns the overlap depth (positive means interiors overlap); <=0 means
    disjoint (touching allowed).
    """
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    if not _feasible(squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:], idx):
        # binary search between 0 and hi
        for _ in range(28):
            mid = 0.5 * (lo + hi)
            trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
            if _feasible(trial, idx):
                lo = mid
            else:
                hi = mid
        return lo
    return hi


def _refine(squares, cap, rng, iters):
    """Coordinate descent: for each square try to enlarge, then jitter."""
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            # candidate enlargements at current spot / nearby spots, few angles
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if _feasible(squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:], i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_big(n, rng):
    """One large square in a corner plus a grid in the remainder."""
    out = []
    big = rng.uniform(0.45, 0.6)
    cx = rng.choice([big / 2, 1 - big / 2])
    cy = rng.choice([big / 2, 1 - big / 2])
    out.append((cx, cy, 0.0, big))
    # fill rest roughly with a grid over the whole unit square, small squares
    k = max(1, math.ceil(math.sqrt(n)))
    side = 1.0 / k
    i = 0
    while len(out) < n:
        i += 1
        x = (i % k + 0.5) * side
        y = (i // k + 0.5) * side
        out.append((x, y, 0.0, side * 0.8))
    return out[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    seeds = []
    # k x k-ish grids of several sizes
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))
    for _ in range(3):
        seeds.append(_seed_big(n, rng))

    # single big square heuristic: largest s such that remaining n-1 posts fit?
    # just add a few random-ish seeds
    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(3):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        # refine in a few passes with caps
        squares = _refine(squares, cap, rng, 25)
        # a couple of escalating sweeps
        for _ in range(2):
            squares = _refine(squares, cap, rng, 15)
        # validate
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    # final cleanup: shrink tiny overlaps (safety)
    for i in range(n):
        cx, cy, ang, s = best[i]
        # enforce strictly inside by clamping
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
