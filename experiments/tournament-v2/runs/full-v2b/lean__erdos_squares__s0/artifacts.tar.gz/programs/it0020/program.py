# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start + joint local search.
  Seeds: k x k grids, largest-first greedy packers, structured staircases along
  the diagonal, perturbed grids, and "one big square plus remainder" layouts.
  Each seed is polished by (a) a single-square growing coordinate descent, and
  (b) a *joint* search that perturbs every square at once (sizes, centres,
  angles) and accepts whenever the total side sum grows.  The joint pass is what
  lets grid-like seeds slide into the asymmetric staircase packings that beat
  uniform grids for n >= 6.  Best-of-restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Separating axis test; positive = interiors overlap, <=0 disjoint."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _all_feasible(squares):
    n = len(squares)
    for i in range(n):
        if not _inside(squares[i]):
            return False
        for j in range(i + 1, n):
            if _sat_overlap(squares[i], squares[j]) > 0.0:
                return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                    if _feasible(trial, i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _grow_global(squares, i, cap):
    """Grow square i in place; return gained amount."""
    cx, cy, ang, s = squares[i]
    ns = _max_side_at(squares, i, cx, cy, ang, cap)
    if ns > s + 1e-9:
        squares[i] = (cx, cy, ang, ns)
        return ns - s
    return 0.0


def _joint_search(squares, rng, rounds, n):
    """Joint local search: perturb all squares at once, accept if sum grows.

    Uses a feasibility-preserving move: apply random small perturbations to
    every square, then shrink any square that has become infeasible.  Accept
    the perturbed configuration when the resulting total is larger.
    """
    cur = [tuple(s) for s in squares]
    cur_total = sum(max(0.0, s[3]) for s in cur)

    for rnd in range(rounds):
        scale = 0.06 * (0.75 ** (rnd // 6))
        cand = []
        for (cx, cy, ang, s) in cur:
            ncx = min(1.0, max(0.0, cx + rng.uniform(-scale, scale)))
            ncy = min(1.0, max(0.0, cy + rng.uniform(-scale, scale)))
            na = ang + rng.uniform(-0.12, 0.12)
            ns = max(0.0, s * (1.0 + rng.uniform(-scale, scale)))
            cand.append((ncx, ncy, na % 1.0, min(ns, 1.0)))

        # repair: repeatedly shrink offending squares until all feasible
        for _ in range(40):
            bad = -1
            for i in range(n):
                if not _inside(cand[i]):
                    bad = i
                    break
                for j in range(i + 1, n):
                    if _sat_overlap(cand[i], cand[j]) > 0.0:
                        bad = i
                        break
                if bad >= 0:
                    break
            if bad < 0:
                break
            cx, cy, ang, s = cand[bad]
            if s <= 1e-6:
                # nudge inward instead
                cx = min(0.999, max(0.001, cx + rng.uniform(-0.02, 0.02)))
                cy = min(0.999, max(0.001, cy + rng.uniform(-0.02, 0.02)))
                cand[bad] = (cx, cy, ang, s)
            else:
                cand[bad] = (cx, cy, ang, s * 0.92)
        else:
            continue

        # strict growth pass: each square re-grows being the only one moving
        for i in range(n):
            _grow_global(cand, i, 1.0)

        cand_total = sum(max(0.0, s[3]) for s in cand)
        if cand_total > cur_total + 1e-9:
            cur = cand
            cur_total = cand_total
        else:
            # random restart tail: accept sideways occasionally early on
            if rnd < rounds // 3 and cand_total > cur_total - 1e-3:
                cur = cand
                cur_total = cand_total

    return cur, cur_total


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=11):
    """Largest-first greedy: repeatedly place the biggest findable square."""
    placed = []
    step = 1.0 / (grid - 1)
    cand_pts = [(gi * step, gj * step) for gi in range(grid) for gj in range(grid)]
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        pts = list(cand_pts)
        for _ in range(6):
            pts.append((rng.random(), rng.random()))
        for (cx, cy) in pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                for _ in range(26):
                    mid = 0.5 * (lo + hi)
                    cfg = (cx, cy, ang, mid)
                    trial = placed + [cfg]
                    if _feasible(trial, len(trial) - 1):
                        lo = mid
                    else:
                        hi = mid
                if lo > best_s:
                    best_s = lo
                    best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_staircase(n, rng, angles):
    """Place squares of decreasing size along a diagonal-ish path."""
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def _seed_diag_staircase(n, ratio):
    """Deterministic corner-to-corner staircase of geometrically shrinking
    axis-aligned squares running from the bottom-left to the top-right corner.
    Sizes chosen so each square sits in the remaining corner gap."""
    out = []
    x, y = 0.0, 0.0
    s = 1.0
    for i in range(n):
        si = s
        if x + si > 1.0 or y + si > 1.0:
            si = min(1.0 - x, 1.0 - y)
        si = max(0.0, si)
        cx = min(1.0, x + si / 2)
        cy = min(1.0, y + si / 2)
        out.append((cx, cy, 0.0, si))
        x += si
        y += si * ratio
        s *= ratio
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(98765 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=11 if _ % 2 == 0 else 9))

    for _ in range(4):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    # deterministic diagonal staircases across ratios
    for ratio in (0.95, 0.9, 0.85, 0.8, 0.7, 0.6):
        seeds.append(_seed_diag_staircase(n, ratio))

    # perturbed-grid seeds
    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(3):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    # "one big square + remainder" seeds
    for _ in range(3):
        big = rng.uniform(0.45, 0.62)
        cx = rng.choice([big / 2, 1 - big / 2])
        cy = rng.choice([big / 2, 1 - big / 2])
        cfg = [(cx, cy, 0.0, big)]
        k = max(1, math.ceil(math.sqrt(n)))
        side = 1.0 / k
        i = 0
        while len(cfg) < n:
            i += 1
            x = (i % k + 0.5) * side
            y = (i // k + 0.5) * side
            cfg.append((x, y, 0.0, side * 0.8))
        seeds.append(cfg[:n])

    best = None
    best_score = -1.0
    joint_rounds = max(30, 90 - 2 * n)

    for si, sd in enumerate(seeds):
        squares = [tuple(x) for x in sd]
        squares = _refine(squares, 1.0, rng, 20)

        # joint search on promising seeds only (budget control)
        if si < 14 or best_score < 0:
            squares, total = _joint_search(squares, rng, joint_rounds, n)
            squares = _refine(squares, 1.0, rng, 10)
        else:
            total = sum(max(0.0, s[3]) for s in squares)

        if not _all_feasible(squares):
            continue
        total = sum(max(0.0, s[3]) for s in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
