# EVOLVE-BLOCK-START
"""Grid starts refined by a separating-axis coordinate-descent optimizer."""
import math
import random


def _corners(cx, cy, ang, s):
    """Return the four corners of a rotated square."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for dx, dy in ((h, h), (h, -h), (-h, -h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _axes(ang):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    return (ca, sa), (-sa, ca)


def _overlap(sq1, sq2):
    """True if two squares (cx,cy,ang,s) overlap with positive area."""
    if sq1[3] <= 0.0 or sq2[3] <= 0.0:
        return False
    p1 = _corners(*sq1)
    p2 = _corners(*sq2)
    for pts in (p1, p2):
        for ang in (sq1[2], sq2[2]):
            ax, ay = _axes(ang)
            v = [px * ax + py * ay for px, py in pts]
            lo, hi = min(v), max(v)
            proj = []
            # project the other polygon's corners
        # compute properly below
    return _sat(p1, sq1, p2, sq2) or _sat(p2, sq2, p1, sq1)


def _sat(pA, sqA, pB, sqB):
    for ang in (sqA[2], sqB[2]):
        ax, ay = _axes(ang)
        va = [px * ax + py * ay for px, py in pA]
        vb = [px * ax + py * ay for px, py in pB]
        if max(va) <= min(vb) + 1e-12 or max(vb) <= min(va) + 1e-12:
            return False
    return True


def _feasible(sq):
    """Square inside the unit box."""
    cx, cy, ang, s = sq
    if s <= 0.0:
        return True
    for px, py in _corners(cx, cy, ang, s):
        if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
            return False
    return True


def _total(squares):
    return sum(q[3] for q in squares)


def _valid(squares):
    for q in squares:
        if not _feasible(q):
            return False
    m = len(squares)
    for i in range(m):
        if squares[i][3] == 0.0:
            continue
        for j in range(i + 1, m):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _clip(sq):
    """Clamp a square into the unit box (conservatively shrink if needed)."""
    cx, cy, ang, s = sq
    cx = min(max(cx, 0.0), 1.0)
    cy = min(max(cy, 0.0), 1.0)
    return (cx, cy, ang, s)


def _refine(squares, time_budget):
    best = [tuple(q) for q in squares]
    if not _valid(best):
        return best
    bestval = _total(best)
    steps = [0.05, 0.02, 0.01, 0.005, 0.002, 0.001]
    import time
    t0 = time.time()
    n = len(best)
    for step in steps:
        improved = True
        while improved:
            improved = False
            for i in range(n):
                if time.time() - t0 > time_budget:
                    return best
                cur = best[i]
                # try growth of side length
                for ds in (step, -step):
                    cand = list(best)
                    cand[i] = (cur[0], cur[1], cur[2], max(0.0, cur[3] + ds))
                    if _valid(cand) and _total(cand) > bestval + 1e-12:
                        best = cand
                        bestval = _total(cand)
                        improved = True
                        cur = cand[i]
                        break
                # try shifting centre
                for dx, dy in ((step, 0), (-step, 0), (0, step), (0, -step)):
                    cand = list(best)
                    cand[i] = _clip((cur[0] + dx, cur[1] + dy, cur[2], cur[3]))
                    if _valid(cand) and _total(cand) > bestval + 1e-12:
                        best = cand
                        bestval = _total(cand)
                        improved = True
                        cur = cand[i]
                        break
                # try rotation
                for da in (step, -step):
                    cand = list(best)
                    cand[i] = (cur[0], cur[1], (cur[2] + da) % 1.0, cur[3])
                    if _valid(cand) and _total(cand) > bestval + 1e-12:
                        best = cand
                        bestval = _total(cand)
                        improved = True
                        cur = cand[i]
                        break
    return best


def _grid(k):
    s = 1.0 / k
    return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]


def _starts(n):
    starts = []
    k = math.isqrt(n)
    base = _grid(k)
    base = base[:n] + [(0.5, 0.5, 0.0, 0.0)] * max(0, n - len(base))
    starts.append(base[:n])
    # grid with one big square in a corner region and remainder grid
    for kk in range(1, k + 2):
        if kk * kk > n:
            break
        g = _grid(kk)
        g = g[:n] + [(0.5, 0.5, 0.0, 0.0)] * max(0, n - len(g))
        starts.append(g[:n])
    # a single large square plus small squares
    big = (0.5, 0.5, 0.0, 1.0)
    rest = [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
    starts.append([big] + rest)
    return starts


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    best = None
    bestval = -1.0
    tries = _starts(n)
    for st in tries:
        st = [tuple(q) for q in st]
        r = _refine(st, 5.0)
        v = _total(r)
        if v > bestval:
            bestval = v
            best = r
    return best[:n]
# EVOLVE-BLOCK-END

