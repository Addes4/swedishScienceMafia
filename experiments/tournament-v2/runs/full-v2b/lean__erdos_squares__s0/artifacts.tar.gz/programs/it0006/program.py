# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Strategy: the optimal packings for small/medium n look like "staircases":
a descending chain of squares each touching the previous one along a
perpendicular direction, swimming into a corner.  We build such staircases
parametrically from a decreasing size profile, place them, then run a
coordinate-descent that tries to enlarge every square (positions, angles,
sizes) subject to an exact separating-axis feasibility test.  Best over
several profiles and a few grid seeds is returned.
"""
import math
import random

EPS = 1e-9


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Return overlap depth (>0 means interiors overlap)."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    trial = squares[:idx] + [(cx, cy, ang, cap)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return cap
    lo, hi = 0.0, cap
    for _ in range(24):
        mid = 0.5 * (lo + hi)
        t2 = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(t2, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            centers = [(cx, cy)]
            r = 0.04
            for _ in range(5):
                centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375):
                angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in centers:
                for na in angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if ns > best + 1e-9:
                        t = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                        if _feasible(t, i):
                            best = ns
                            best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _staircase(n, profile, diag):
    """Build a descending staircase from the given size profile.

    profile: list of n positive relative weights, used sorted descending.
    We lay squares alternately stepping right and up by the *previous*
    square's side so consecutive squares just touch.  Sizes are then
    scaled/clipped to the unit square by a computed factor.
    """
    ws = sorted(profile, reverse=True)
    # layout in a normalized coordinate frame, then rescale to fit
    squares = []
    x = y = 0.0
    dirn = 0  # 0 right, 1 up, 2 right, 3 up ...
    for i, w in enumerate(ws):
        s = w
        if i == 0:
            cx, cy = 0.5 * s, 0.5 * s
        else:
            prev_s = squares[-1][3]
            px, py = squares[-1][0], squares[-1][1]
            if dirn == 0:       # step right, bottom aligned with prev
                cx = px + 0.5 * prev_s + 0.5 * s
                cy = py
            elif dirn == 1:     # step up, left aligned with prev
                cx = px
                cy = py + 0.5 * prev_s + 0.5 * s
            elif dirn == 2:
                cx = px
                cy = py + 0.5 * prev_s + 0.5 * s
            else:
                cx = px + 0.5 * prev_s + 0.5 * s
                cy = py
            dirn = (dirn + 1) % 4
        squares.append((cx, cy, 0.0, s))
    # bbox
    minx = min(cx - 0.5 * s for cx, cy, a, s in squares)
    maxx = max(cx + 0.5 * s for cx, cy, a, s in squares)
    miny = min(cy - 0.5 * s for cx, cy, a, s in squares)
    maxy = max(cy + 0.5 * s for cx, cy, a, s in squares)
    w = maxx - minx
    h = maxy - miny
    scale = min(1.0 / w, 1.0 / h) if w > 0 and h > 0 else 1.0
    out = []
    for cx, cy, a, s in squares:
        ncx = (cx - minx) * scale
        ncy = (cy - miny) * scale
        ns = s * scale
        out.append((ncx, ncy, a, ns))
    return out


def _profiles(n):
    """Return a list of candidate size profiles (descending weights)."""
    profs = []
    # geometric decays
    for r in (0.9, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5):
        profs.append([r ** i for i in range(n)])
    # all equal
    profs.append([1.0] * n)
    # two-level
    for a in (0.6, 0.7, 0.8):
        half = n // 2
        profs.append([1.0] * half + [a] * (n - half))
    # slightly varied to break symmetry
    for r in (0.8, 0.7, 0.6):
        profs.append([r ** i * (1.0 + 0.05 * ((i * 7) % 3 - 1)) for i in range(n)])
    return profs


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    cap = 1.0
    seeds = []

    # grid seeds
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # staircase seeds from profiles
    for prof in _profiles(n):
        seeds.append(_staircase(n, prof, 0))

    # perturbed grids
    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(3):
        s = [[x for x in b] for b in base]
        for row in s:
            row[3] *= rng.uniform(0.8, 1.0)
            row[0] = min(1.0, max(0.0, row[0] + rng.uniform(-0.03, 0.03)))
            row[1] = min(1.0, max(0.0, row[1] + rng.uniform(-0.03, 0.03)))
        seeds.append([tuple(r) for r in s])

    best = None
    best_score = -1.0
    for sd in seeds:
        squares = [tuple(x) for x in sd]
        # shrink slightly for safety, then refine
        squares = [(cx, cy, a, s * 0.999) for (cx, cy, a, s) in squares]
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        squares = _refine(squares, cap, rng, 30)
        squares = _refine(squares, cap, rng, 20)
        total = sum(sq[3] for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
