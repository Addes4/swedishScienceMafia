# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start structured seeds (grids, big-square+grid, staircase),
then a greedy coordinate-descent that enlarges one square at a time using the
separating-axis theorem, followed by a joint refinement pass that moves every
centre and side length with a shrinking step to escape deadlocks.  Best of
restarts is returned.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    """Overlap depth via separating-axis test; <=0 means disjoint."""
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _all_feasible(squares):
    n = len(squares)
    for i in range(n):
        if not _inside(squares[i]):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _sat_overlap(squares[i], squares[j]) > 0.0:
                return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    """Largest side (<=cap) that fits a square at (cx, cy, ang)."""
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    if ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _grow_all(squares, cap, rng, iters):
    """Joint pass: try to enlarge every square simultaneously by a factor,
    backing off when infeasible, plus joint small translations."""
    n = len(squares)
    for _ in range(iters):
        step = 0.02
        improved = False
        # try scaling all squares up around their own centers
        while step > 1e-3:
            trial = []
            for (cx, cy, ang, s) in squares:
                trial.append((cx, cy, ang, min(cap, s * (1.0 + step))))
            if _all_feasible(trial):
                squares = trial
                improved = True
                break
            step *= 0.5
        # jitter translation of each square, keeping feasibility
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            for _ in range(3):
                dx = rng.uniform(-0.02, 0.02)
                dy = rng.uniform(-0.02, 0.02)
                nc = (min(1.0, max(0.0, cx + dx)), min(1.0, max(0.0, cy + dy)), ang, s)
                trial = squares[:i] + [nc] + squares[i + 1:]
                if _all_feasible(trial):
                    squares = trial
                    cx, cy = nc[0], nc[1]
                    improved = True
        if not improved:
            break
    return squares


def _polish(squares, rng, iters):
    """Alternate single-square enlargement and joint growth."""
    cap = 1.0
    squares = _refine(squares, cap, rng, 20)
    squares = _grow_all(squares, cap, rng, 15)
    squares = _refine(squares, cap, rng, 40)
    squares = _grow_all(squares, cap, rng, 25)
    squares = _refine(squares, cap, rng, 40)
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_rect(n, rows, cols):
    """rows x cols grid over a sub-rectangle, then cover the rest."""
    side = 1.0 / max(rows, cols)
    out = []
    for i in range(rows):
        for j in range(cols):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_big(n, rng):
    out = []
    big = rng.uniform(0.45, 0.65)
    cx = rng.choice([big / 2, 1 - big / 2])
    cy = rng.choice([big / 2, 1 - big / 2])
    out.append((cx, cy, 0.0, big))
    k = max(1, math.ceil(math.sqrt(max(1, n - 1))))
    side = 1.0 / k
    i = 0
    while len(out) < n:
        i += 1
        x = (i % k + 0.5) * side
        y = (i // k + 0.5) * side
        out.append((x, y, 0.0, side * 0.8))
    return out[:n]


def _seed_staircase(n, rng):
    """A big square bottom-left plus progressively smaller along diagonal."""
    out = []
    x, y = 0.0, 0.0
    remaining = n
    # decreasing sizes packed along the diagonal
    sizes = []
    tot = 0.0
    for i in range(n):
        sizes.append(1.0 / (i + 1.0))
        tot += sizes[-1]
    sizes = [s / max(tot, 1e-9) * 1.4 for s in sizes]
    for i in range(n):
        s = min(0.9, sizes[i]) if i < len(sizes) else 0.05
        out.append((min(1.0 - s / 2, max(s / 2, x + s / 2)),
                    min(1.0 - s / 2, max(s / 2, y + s / 2)), 0.0, s))
        x += 0.15 * s
        y += 0.15 * s
    return out[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    seeds = []

    r = math.isqrt(n)
    for k in range(max(1, r - 1), r + 3):
        seeds.append(_seed_grid(n, k))
    for rows in range(1, r + 3):
        for cols in range(1, r + 3):
            if rows * cols >= n:
                seeds.append(_seed_rect(n, rows, cols))
    for _ in range(6):
        seeds.append(_seed_big(n, rng))
    for _ in range(4):
        seeds.append(_seed_staircase(n, rng))

    base = _seed_grid(n, max(1, r))
    for _ in range(6):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.7, 1.0)
            row[0] = min(1.0, max(0.0, row[0] + rng.uniform(-0.05, 0.05)))
            row[1] = min(1.0, max(0.0, row[1] + rng.uniform(-0.05, 0.05)))
        seeds.append([tuple(x) for x in s])

    # grid with small preset squares
    for _ in range(4):
        s = [list(b) for b in base]
        for row in s:
            row[3] = 0.0
        # distribute small squares randomly
        for row in s:
            row[0] = rng.uniform(0.0, 1.0)
            row[1] = rng.uniform(0.0, 1.0)
            row[3] = 0.0
        seeds.append([tuple(x) for x in s])

    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        squares = _polish(squares, rng, 1)
        if not _all_feasible(squares):
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, r))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END

