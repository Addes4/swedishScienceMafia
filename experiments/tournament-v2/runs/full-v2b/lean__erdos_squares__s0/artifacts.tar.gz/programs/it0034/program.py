# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Key ideas:
  * Exact-ish feasibility via separating-axis test on the 4 corners.
  * Analytic + greedy + grid seedings, including "big corner square plus
    shelf/staircase" layouts that match known optima for moderate n.
  * A fast local optimiser:
      - grow: for a fixed centre & angle take the maximal feasible side
        (closed-form against walls + binary search against neighbours),
      - move: try small centre/angle perturbations to allow larger side,
      - compact: push all squares toward a chosen corner, then re-grow,
    iterated many times.  This escapes the uniform grid plateau.
"""
import math
import random

EPS = 1e-9


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _walls_max(cx, cy, ang):
    """Max side (ignoring neighbours) fitting a square at (cx,cy,ang) in unit box."""
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    best = 1.0
    # half-extent in x and y
    hx = abs(ca) + abs(sa)  # times half side? extent_x = 0.5*s*(|ca|+|sa|)
    hy = abs(sa) + abs(ca)
    exr = 0.5 * (abs(ca) + abs(sa))  # per unit side
    # distance to each wall along each axis:
    # centre must satisfy cx >= 0.5*s*exr etc
    if exr > 0:
        best = min(best, cx / 0.5 / (abs(ca) + abs(sa)) if False else 1.0)
    # proper computation
    sx = (abs(ca) + abs(sa))
    sy = (abs(sa) + abs(ca))
    mx = cx / (0.5 * sx) if sx > 0 else 1.0
    Mx = (1.0 - cx) / (0.5 * sx) if sx > 0 else 1.0
    my = cy / (0.5 * sy) if sy > 0 else 1.0
    My = (1.0 - cy) / (0.5 * sy) if sy > 0 else 1.0
    return max(0.0, min(mx, Mx, my, My))


def _max_side_at(squares, idx, cx, cy, ang, cap):
    lo = 0.0
    hi = min(cap, _walls_max(cx, cy, ang))
    if hi <= 0.0:
        return 0.0
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _grow_pass(squares, rng):
    """Grow every square in place to its maximal side."""
    n = len(squares)
    order = list(range(n))
    rng.shuffle(order)
    changed = False
    for i in order:
        cx, cy, ang, s = squares[i]
        ns = _max_side_at(squares, i, cx, cy, ang, 1.0)
        if ns > s + 1e-9:
            squares[i] = (cx, cy, ang, ns)
            changed = True
    return changed


def _local_opt(squares, rng, rounds=6):
    """Iterate grow + perturb (centre / angle) to enlarge total side."""
    n = len(squares)
    for _ in range(rounds):
        any_improved = _grow_pass(squares, rng)
        for i in range(n):
            cx, cy, ang, s = squares[i]
            best = s
            bestcfg = None
            # angle candidates
            angs = {round(ang, 7)}
            for d in (0.25, 0.125, -0.125, 0.0625, -0.0625, 0.5, 0.375, 0.1875):
                angs.add(round((ang + d) % 1.0, 7))
            # centre candidates: small moves
            for _ in range(3):
                r = 0.02
                ncx = min(1.0, max(0.0, cx + rng.uniform(-r, r)))
                ncy = min(1.0, max(0.0, cy + rng.uniform(-r, r)))
                for na in angs:
                    ns = _max_side_at(squares, i, ncx, ncy, na, 1.0)
                    # nudge centre to a more central allowed spot for this side
                    if ns > best + 1e-9:
                        best = ns
                        bestcfg = (ncx, ncy, na, ns)
            if bestcfg is not None:
                squares[i] = bestcfg
                any_improved = True
        if not any_improved:
            break
    return squares


def _compact(squares, rng, corner):
    """Squeeze all squares toward `corner` then re-grow."""
    # corner: (dirx, diry) in {-1,1} for centre target near 0 or 1
    tx, ty = corner
    n = len(squares)
    for i in range(n):
        cx, cy, ang, s = squares[i]
        # shift centre toward target by shrinking offsets
        # small steps
        for _ in range(3):
            ncx = cx + (tx - cx) * 0.15
            ncy = cy + (ty - cy) * 0.15
            if ncx < 0.0:
                ncx = 0.0
            if ncx > 1.0:
                ncx = 1.0
            if ncy < 0.0:
                ncy = 0.0
            if ncy > 1.0:
                ncy = 1.0
            ns = _max_side_at(squares, i, ncx, ncy, ang, 1.0)
            if ns >= s - 1e-9:
                cx, cy, s = ncx, ncy, ns
            else:
                break
        squares[i] = (cx, cy, ang, s)
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=11):
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(6):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, _walls_max(cx, cy, ang)
                for _ in range(26):
                    mid = 0.5 * (lo + hi)
                    cfg = (cx, cy, ang, mid)
                    trial = placed + [cfg]
                    if _feasible(trial, len(trial) - 1):
                        lo = mid
                    else:
                        hi = mid
                if lo > best_s:
                    best_s = lo
                    best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_corner_shelves(n, rng):
    """Big corner square + fill remaining L-shape with shrinking shelves."""
    out = []
    # sweep big square side
    best = None
    best_total = -1.0
    for big in [x / 100.0 for x in range(40, 75)]:
        for corner in [(0, 0), (1, 0), (0, 1), (1, 1)]:
            cx = big / 2 if corner[0] == 0 else 1 - big / 2
            cy = big / 2 if corner[1] == 0 else 1 - big / 2
            cfg = [(cx, cy, 0.0, big)]
            # remaining L region: right strip and top strip (depends on corner)
            # put squares greedily in a grid over the free region
            rest = n - 1
            if rest <= 0:
                if big > best_total:
                    best_total = big
                    best = cfg
                continue
            # simple: tile free area with equal squares that fit
            # free area ~ (1 - big) on the two sides
            strip = 1.0 - big
            k = rest
            side = strip / max(1, math.ceil(math.sqrt(k)))
            # place along strips
            placed = 0
            # horizontal strip that fits rest squares
            cols = max(1, int(math.ceil(math.sqrt(k))))
            rows = max(1, int(math.ceil(k / cols)))
            s = min(strip, strip)
            # fill leftover region with small squares
            # (refinement will polish)
            xs = []
            for _ in range(rest):
                xs.append((rng.uniform(0, 1), rng.uniform(0, 1), 0.0, 0.0))
            cfg += xs
            total = sum(c[3] for c in cfg)
            if total > best_total:
                best_total = total
                best = cfg
    return best


def _seed_staircase(n, rng, angles):
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(98765 + n)
    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=11 if _ % 2 == 0 else 9))

    for _ in range(3):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    # deterministic corner big-square + shelves
    cs = _seed_corner_shelves(n, rng)
    if cs is not None:
        seeds.append(cs)

    # perturbed grids
    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(3):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        # clean: if any infeasible, grow pass will fix; ensure sides <= walls
        for i in range(len(squares)):
            cx, cy, ang, s = squares[i]
            squares[i] = (min(max(cx, 0.0), 1.0),
                          min(max(cy, 0.0), 1.0),
                          ang % 1.0, max(0.0, min(s, _walls_max(cx, cy, ang))))
        squares = _local_opt(squares, rng, rounds=8)
        for corner in [(0, 0), (1, 1), (0, 1), (1, 0)]:
            squares = _compact(squares, rng, corner)
            squares = _local_opt(squares, rng, rounds=4)
            # also random edge-push compactions
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
