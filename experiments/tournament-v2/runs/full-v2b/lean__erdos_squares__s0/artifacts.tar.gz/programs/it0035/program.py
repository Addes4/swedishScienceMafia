# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths.

Approach: multi-start.  Seeds come from
  (a) k x k grids,
  (b) a "largest-first greedy" packer,
  (c) structured staircase families along the main diagonal,
  (d) a deterministic "big corner square + shelf strip" family (the layouts
      that are optimal for moderate n: one big square in a corner, the rest of
      the L-shaped remainder filled with equal-strip squares).
Each seed is polished by a SAT-based coordinate descent, but the refined result
is only kept if it does not reduce the seed's total, so good structured layouts
survive.
"""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                    if _feasible(trial, i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=11):
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(6):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                cfg_hi = (cx, cy, ang, hi)
                if _inside(cfg_hi):
                    lo = 0.0
                    for _ in range(26):
                        mid = 0.5 * (lo + hi)
                        cfg = (cx, cy, ang, mid)
                        trial = placed + [cfg]
                        if _feasible(trial, len(trial) - 1):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_staircase(n, rng, angles):
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def _seed_corner_shelf(n, big, corner):
    """One big square of side `big` in a corner, remainder (an L-shaped strip of
    width w=1-big along the two far edges) filled by rows/columns of squares
    sized to tile each shelf exactly.  `corner` in {0,1,2,3} selects the corner.
    Returns a feasible list of n squares (largest first) or None if impossible.
    """
    w = 1.0 - big
    if w <= 1e-9:
        return None
    # horizontal shelf (height w, width 1-big) and vertical shelf (width w, height 1-big)
    # Region A: strip of height w along top, x in [0, 1-big]  -> size w_R x (1-big)
    # Region B: strip of width w along right, y in [0, 1]    -> size w x 1
    # We fill A with squares of side a (columns), B with squares of side b.
    out = []
    if corner == 0:      # big at bottom-left, strips top & right
        bx, by = big / 2.0, big / 2.0
        strip_w = 1.0 - big          # width of the right strip
        strip_h = 1.0 - big          # height of the top strip
        # top strip: x in [0, 1-big], y in [1-w, 1]
        # right strip: x in [1-w, 1], y in [0, 1-w]
    elif corner == 1:    # bottom-right
        bx, by = 1.0 - big / 2.0, big / 2.0
        strip_w = 1.0 - big
        strip_h = 1.0 - big
    elif corner == 2:    # top-left
        bx, by = big / 2.0, 1.0 - big / 2.0
        strip_w = 1.0 - big
        strip_h = 1.0 - big
    else:                # top-right
        bx, by = 1.0 - big / 2.0, 1.0 - big / 2.0
        strip_w = 1.0 - big
        strip_h = 1.0 - big

    out.append((bx, by, 0.0, big))

    # Build the L-strip out of equal squares.  Choose a single side t and place
    # as many as fit along the two arms, each arm length (1-big).
    arm = 1.0 - big
    if arm <= 1e-9:
        return out[:n] if n == 1 else None

    # choose t so that the strip (of thickness t) along both arms is tiled
    # We use t = arm / m for integer m, giving m squares per arm; pick m to
    # leave exactly n-1 squares (approx), and thicken strip to t.
    remaining = n - 1
    if remaining <= 0:
        return out[:n]
    best = None
    # try single-arm split: a squares on arm1 of side t=arm/a, b on arm2 of side t=arm/b
    for a in range(1, remaining + 1):
        b = remaining - a
        for (t1, t2) in ((arm / a, arm / b if b > 0 else arm),):
            pass
    # simpler: tile with t = arm / a with a up to remaining, remainder along other arm
    for a in range(1, remaining + 2):
        t = arm / a
        if t <= 1e-9:
            continue
        cnt = a
        # place `a` squares along one arm of thickness t, then fill other arm
        cand = [out[0]]
        # arm1 (top strip for corner 0) : squares side t, thickness t
        ok = True
        # We'll just greedily fill the L-strip as a tiling of `remaining` equal
        # squares of side t where possible.
        tcount = remaining
        # number that fit along an arm of length arm with side t = arm/t = a
        per_arm = int(round(arm / t))
        if per_arm < 1:
            continue
        # Place along arm1 and arm2
        positions = []
        for k in range(remaining):
            if corner == 0:
                # arm1: top strip y in [1-t,1], x from 0; arm2: right strip
                if k < per_arm:
                    x = k * t + t / 2.0
                    y = 1.0 - t / 2.0
                else:
                    j = k - per_arm
                    x = 1.0 - t / 2.0
                    y = (1.0 - t) - j * t - t / 2.0
                    if y - t / 2.0 < -1e-9:
                        ok = False
                        break
            elif corner == 1:
                if k < per_arm:
                    x = 1.0 - k * t - t / 2.0
                    y = 1.0 - t / 2.0
                else:
                    j = k - per_arm
                    x = t / 2.0
                    y = (1.0 - t) - j * t - t / 2.0
                    if y - t / 2.0 < -1e-9:
                        ok = False
                        break
            elif corner == 2:
                if k < per_arm:
                    x = k * t + t / 2.0
                    y = t / 2.0
                else:
                    j = k - per_arm
                    x = 1.0 - t / 2.0
                    y = t + j * t + t / 2.0
                    if y + t / 2.0 > 1.0 + 1e-9:
                        ok = False
                        break
            else:
                if k < per_arm:
                    x = 1.0 - k * t - t / 2.0
                    y = t / 2.0
                else:
                    j = k - per_arm
                    x = t / 2.0
                    y = t + j * t + t / 2.0
                    if y + t / 2.0 > 1.0 + 1e-9:
                        ok = False
                        break
            positions.append((x, y, 0.0, t))
        if not ok:
            continue
        # feasibility check
        cand = [out[0]] + positions
        if len(cand) < n:
            cand = cand + [(0.5, 0.5, 0.0, 0.0)] * (n - len(cand))
        cand = cand[:n]
        good = True
        for i in range(len(cand)):
            if not _feasible(cand, i):
                good = False
                break
        if good:
            total = sum(c[3] for c in cand)
            if best is None or total > best[0]:
                best = (total, cand)
    if best is None:
        return None
    return best[1]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    for _ in range(4):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=11 if _ % 2 == 0 else 9))

    for _ in range(4):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    # deterministic big-corner-square + L-strip shelf family
    for corner in (0, 1, 2, 3):
        for t in range(1, 400):
            big = 0.30 + 0.70 * (t / 400.0)
            sd = _seed_corner_shelf(n, big, corner)
            if sd is not None:
                seeds.append(sd)

    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(3):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    for _ in range(3):
        big = rng.uniform(0.45, 0.62)
        cx = rng.choice([big / 2, 1 - big / 2])
        cy = rng.choice([big / 2, 1 - big / 2])
        cfg = [(cx, cy, 0.0, big)]
        k = max(1, math.ceil(math.sqrt(n)))
        side = 1.0 / k
        i = 0
        while len(cfg) < n:
            i += 1
            x = (i % k + 0.5) * side
            y = (i // k + 0.5) * side
            cfg.append((x, y, 0.0, side * 0.8))
        seeds.append(cfg[:n])

    cap = 1.0
    best = None
    best_score = -1.0

    for sd in seeds:
        squares = [tuple(x) for x in sd]
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        seed_total = sum(max(0.0, sq[3]) for sq in squares) if ok else -1.0

        refined = _refine(squares, cap, rng, 25)
        refined = _refine(refined, cap, rng, 15)
        rok = True
        for i in range(n):
            if not _feasible(refined, i):
                rok = False
                break
        ref_total = sum(max(0.0, sq[3]) for sq in refined) if rok else -1.0

        # keep the better of seed-as-is and refined (so structured seeds survive)
        cand_total = ref_total
        cand = refined
        if seed_total > ref_total:
            cand_total = seed_total
            cand = squares

        if cand_total > best_score:
            best_score = cand_total
            best = [tuple(sq) for sq in cand]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
