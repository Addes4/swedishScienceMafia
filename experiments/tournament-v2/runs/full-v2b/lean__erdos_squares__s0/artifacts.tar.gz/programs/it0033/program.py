# EVOLVE-BLOCK-START
"""Pack n squares in the unit square, maximising the sum of side lengths."""
import math
import random

EPS = 1e-7


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for ux in (-h, h):
        for uy in (-h, h):
            pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _sat_overlap(a, b):
    pa = _corners(a)
    pb = _corners(b)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 0:
                axes.append((-ey / ln, ex / ln))
    mind = float('inf')
    for ax, ay in axes:
        amin = min(ax * x + ay * y for x, y in pa)
        amax = max(ax * x + ay * y for x, y in pa)
        bmin = min(ax * x + ay * y for x, y in pb)
        bmax = max(ax * x + ay * y for x, y in pb)
        d = min(amax, bmax) - max(amin, bmin)
        if d <= 0.0:
            return -1.0
        if d < mind:
            mind = d
    return mind


def _inside(sq):
    for x, y in _corners(sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _feasible(squares, idx):
    if not _inside(squares[idx]):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if _sat_overlap(squares[idx], squares[j]) > 0.0:
            return False
    return True


def _max_side_at(squares, idx, cx, cy, ang, cap):
    lo, hi = 0.0, cap
    trial = squares[:idx] + [(cx, cy, ang, hi)] + squares[idx + 1:]
    if _feasible(trial, idx):
        return hi
    for _ in range(28):
        mid = 0.5 * (lo + hi)
        trial = squares[:idx] + [(cx, cy, ang, mid)] + squares[idx + 1:]
        if _feasible(trial, idx):
            lo = mid
        else:
            hi = mid
    return lo


def _refine(squares, cap, rng, iters):
    n = len(squares)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = squares[i]
            best = s
            best_conf = None
            candidate_centers = [(cx, cy)]
            r = 0.03
            for _ in range(4):
                candidate_centers.append((min(1.0, max(0.0, cx + rng.uniform(-r, r))),
                                          min(1.0, max(0.0, cy + rng.uniform(-r, r)))))
            candidate_angles = {round(ang, 6)}
            for da in (0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5):
                candidate_angles.add(round((ang + da) % 1.0, 6))
            for (ncx, ncy) in candidate_centers:
                for na in candidate_angles:
                    ns = _max_side_at(squares, i, ncx, ncy, na, cap)
                    trial = squares[:i] + [(ncx, ncy, na, ns)] + squares[i + 1:]
                    if _feasible(trial, i) and ns > best + 1e-9:
                        best = ns
                        best_conf = (ncx, ncy, na, ns)
            if best_conf is not None:
                squares[i] = best_conf
                improved = True
        if not improved:
            break
    return squares


def _seed_grid(n, k):
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _seed_greedy(n, rng, angles, grid=11):
    placed = []
    for k in range(n):
        best_s = -1.0
        best_cfg = (0.5, 0.5, 0.0, 0.0)
        cand_pts = []
        step = 1.0 / (grid - 1)
        for gi in range(grid):
            for gj in range(grid):
                cand_pts.append((gi * step, gj * step))
        for _ in range(6):
            cand_pts.append((rng.random(), rng.random()))
        for (cx, cy) in cand_pts:
            for ang in angles:
                lo, hi = 0.0, 1.0
                if not _inside((cx, cy, ang, hi)):
                    lo = 0.0
                    for _ in range(26):
                        mid = 0.5 * (lo + hi)
                        cfg = (cx, cy, ang, mid)
                        if _inside(cfg):
                            lo = mid
                        else:
                            hi = mid
                    hi = lo
                    lo = 0.0
                for _ in range(26):
                    mid = 0.5 * (lo + hi)
                    cfg = (cx, cy, ang, mid)
                    trial = placed + [cfg]
                    if _feasible(trial, len(trial) - 1):
                        lo = mid
                    else:
                        hi = mid
                if lo > best_s:
                    best_s = lo
                    best_cfg = (cx, cy, ang, lo)
        placed.append(best_cfg)
    return placed


def _seed_staircase(n, rng, angles):
    out = []
    s = 1.0 / max(1.0, math.sqrt(n)) * rng.uniform(1.0, 1.6)
    s = min(s, 1.0)
    x, y = 0.0, 0.0
    for i in range(n):
        si = max(0.0, s * (rng.uniform(0.85, 1.0) ** i))
        if si <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = rng.choice(angles)
        out.append((min(0.999, max(0.001, x + si / 2)),
                    min(0.999, max(0.001, y + si / 2)),
                    ang, si))
        x += si * rng.uniform(0.6, 1.0)
        y += si * rng.uniform(0.2, 0.9)
        if x > 0.9 or y > 0.9:
            x = rng.uniform(0.0, 0.2)
            y = rng.uniform(0.0, 0.2)
    return out


def _seed_bigcorner_staircase(n, big, ratio, corner):
    """Big square of side `big` in one corner; remaining n-1 axis-aligned squares
    laid corner-to-corner with geometrically decreasing sides (ratio), snaking
    to fill the L-shaped remainder.  Deterministic and feasible when accepted."""
    out = []
    if corner == 0:
        out.append((big / 2.0, big / 2.0, 0.0, big))
        x, y = 0.0, big  # start on top edge of big square, moving right then up
    elif corner == 1:
        out.append((1.0 - big / 2.0, big / 2.0, 0.0, big))
        x, y = 1.0, big   # start on top-left area, moving left
    elif corner == 2:
        out.append((big / 2.0, 1.0 - big / 2.0, 0.0, big))
        x, y = 0.0, 1.0 - big
    else:
        out.append((1.0 - big / 2.0, 1.0 - big / 2.0, 0.0, big))
        x, y = 1.0, 1.0 - big
    s = big
    horiz = True
    for _ in range(n - 1):
        s *= ratio
        if s <= 1e-6:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        if horiz:
            if corner in (0, 2):
                cx = x + s / 2.0
            else:
                cx = x - s / 2.0
            cy = y + (s / 2.0 if corner in (0, 1) else -s / 2.0)
            out.append((cx, cy, 0.0, s))
            if corner in (0, 2):
                x += s
            else:
                x -= s
            if corner in (0, 1):
                y += s
            else:
                y -= s
        else:
            if corner in (0, 1):
                cy = y + s / 2.0
            else:
                cy = y - s / 2.0
            cx = x + (s / 2.0 if corner in (0, 1) else -s / 2.0)
            out.append((cx, cy, 0.0, s))
            if corner in (0, 1):
                y += s
            else:
                y -= s
        horiz = not horiz
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    base_angles = [0.0, 0.25, 0.125, 0.0625, -0.0625, 0.5, 0.375]

    seeds = []
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        seeds.append(_seed_grid(n, k))

    # deterministic "big corner square + decreasing staircase" family
    big_vals = [k / 100.0 for k in range(35, 66, 2)]
    ratio_vals = [k / 100.0 for k in range(55, 96, 5)]
    for corner in (0, 1, 2, 3):
        for big in big_vals:
            for ratio in ratio_vals:
                seeds.append(_seed_bigcorner_staircase(n, big, ratio, corner))

    for _ in range(3):
        angles = base_angles if _ % 2 == 0 else [0.0]
        seeds.append(_seed_greedy(n, rng, angles, grid=11 if _ % 2 == 0 else 9))

    for _ in range(3):
        angles = [0.0] if _ % 2 == 0 else base_angles
        seeds.append(_seed_staircase(n, rng, angles))

    base = _seed_grid(n, max(1, math.isqrt(n)))
    for _ in range(2):
        s = [list(b) for b in base]
        for row in s:
            row[3] *= rng.uniform(0.85, 1.0)
        seeds.append([tuple(r) for r in s])

    cap = 1.0
    best = None
    best_score = -1.0

    # Score deterministic seeds cheaply first (no refinement), keep the best few.
    scored = []
    for sd in seeds:
        squares = [tuple(x) for x in sd]
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        scored.append((total, squares))

    scored.sort(key=lambda t: -t[0])
    top = scored[:40] if len(scored) > 40 else scored

    for (_, squares) in top:
        squares = [tuple(x) for x in squares]
        squares = _refine(squares, cap, rng, 25)
        for _ in range(2):
            squares = _refine(squares, cap, rng, 15)
        ok = True
        for i in range(n):
            if not _feasible(squares, i):
                ok = False
                break
        if not ok:
            continue
        total = sum(max(0.0, sq[3]) for sq in squares)
        if total > best_score:
            best_score = total
            best = [tuple(sq) for sq in squares]

    if best is None:
        return _seed_grid(n, max(1, math.isqrt(n)))

    for i in range(n):
        cx, cy, ang, s = best[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        best[i] = (cx, cy, ang % 1.0, max(0.0, min(s, 1.0)))
    return best
# EVOLVE-BLOCK-END
