# EVOLVE-BLOCK-START
"""Clean, fast, time-bounded optimisation of log|A-A|/log|A+A|."""
import math
import random
import time

import numpy as np


def _score_counts(d, s, n):
    if s < 2 or n < 2:
        return -1.0, d, s
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0, d, s


def _eval(a):
    """a: sorted list of distinct ints. Returns score and (|A-A|, |A+A|)."""
    arr = np.asarray(a, dtype=np.int64)
    n = arr.size
    if n < 2:
        return -1.0, 0, 0
    d = np.unique(arr[:, None] - arr[None, :]).size
    s = np.unique(arr[:, None] + arr[None, :]).size
    sc, d, s = _score_counts(d, s, n)
    return sc, d, s


def _seeds():
    """Structured seeds that tend to have small sums and large diffs."""
    seeds = []
    # Golomb-like / small Sidon sets
    seeds.append([0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96, 122, 147, 181, 203])
    seeds.append([0, 1, 4, 10, 18, 23, 25])
    seeds.append([0, 1, 3, 7, 12, 20, 30])
    seeds.append([0, 1, 2, 4, 8, 13, 21, 31, 45, 66, 81, 97])
    # small dense near-geometric
    for k in range(2, 20):
        seeds.append([int(round(base)) for base in (1.6 ** i for i in range(k + 1))])
    # consecutive near a power pattern
    for start in range(0, 6):
        seeds.append(list(range(start, start + 8)))
    return seeds


def _random_seed(rng, n):
    a = set([0])
    span = max(4, n * 3)
    while len(a) < n:
        a.add(rng.randint(-span, span))
    return sorted(a)


def _sa_search(a0, deadline, rng):
    """Simulated annealing / descent directly maximising the score."""
    cur = sorted(set(int(x) for x in a0))
    if len(cur) < 2:
        return cur, -1.0
    cs, cd, csum = _eval(cur)
    span = max(1, max(cur) - min(cur))
    temp = 0.02
    it = 0
    n = len(cur)
    while time.time() < deadline:
        it += 1
        # cool periodically
        if it % 400 == 0:
            temp *= 0.995
            if temp < 1e-4:
                temp = 0.02
        cand = cur[:]
        i = rng.randrange(n)
        amp = max(1, span // max(4, n))
        if rng.random() < 0.5:
            cand[i] += rng.randint(-amp, amp)
        else:
            cand[i] += rng.choice([-1, 1])
        cand = sorted(set(cand))
        if len(cand) != n:
            continue
        ns, nd, nsum = _eval(cand)
        if ns < 0:
            continue
        if ns >= cs or (temp > 0 and rng.random() < math.exp((ns - cs) / temp)):
            cur, cs, cd, csum = cand, ns, nd, nsum
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    # Evaluate structured seeds
    for sd in _seeds():
        sc, _, _ = _eval(sorted(set(sd)))
        if sc > best_score:
            best_score = sc
            best = sorted(set(int(x) for x in sd))

    # Multi-start SA over a range of small sizes
    sizes = list(range(6, 30)) + [32, 36, 40, 48]
    start = time.time()
    while time.time() < deadline:
        for n in sizes:
            if time.time() >= deadline:
                break
            # seed choice: mix structured best-scaled and random
            if rng.random() < 0.5 and best is not None:
                base = best[:]
                # adjust to size n
                if len(base) >= n:
                    base = sorted(rng.sample(base, n))
                else:
                    while len(base) < n:
                        base.append(max(base) + rng.randint(1, 10))
                    base = sorted(set(base))
                    while len(base) < n:
                        base.append(min(base) - rng.randint(1, 10))
                    base = sorted(set(base))
                if len(base) < 2:
                    base = _random_seed(rng, n)
            else:
                base = _random_seed(rng, n)
            t_end = min(deadline, time.time() + 1.5)
            pol, ps = _sa_search(base, t_end, rng)
            if ps > best_score:
                best_score = ps
                best = pol[:]
    if best is None:
        best = [0, 1, 3, 7, 12, 20, 30]

    # final polish of the overall best with a longer SA run
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 5.0)
        pol, ps = _sa_search(cur, t_end, rng)
        if ps > cur_score:
            cur = pol[:]
            cur_score = ps
        else:
            # perturb
            arr = sorted(set(int(x) for x in cur))
            for _ in range(max(1, len(arr) // 5)):
                if not arr:
                    break
                j = rng.randrange(len(arr))
                arr[j] += rng.randint(-3, 3)
            cur = sorted(set(arr))
            sc, _, _ = _eval(cur)
            cur_score = sc

    if cur_score > best_score:
        best = cur
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
