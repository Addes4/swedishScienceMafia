# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A| using incremental evaluation."""
import math
import random
import time


def _full_counts(a):
    """Return (n_diff, n_sum) for list a."""
    ds = set()
    ss = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            ds.add(ai - a[j])
            ss.add(ai + a[j])
    return len(ds), len(ss)


def _score(nd, ns):
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns)


def _eval(a):
    nd, ns = _full_counts(a)
    n = len(a)
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


class Inc:
    """Incremental difference/sum multiplicity counters for a sorted list."""

    def __init__(self, a):
        self.a = list(a)
        self.d = {}
        self.s = {}
        n = len(self.a)
        for i in range(n):
            ai = self.a[i]
            for j in range(n):
                aj = self.a[j]
                self.d[ai - aj] = self.d.get(ai - aj, 0) + 1
                self.s[ai + aj] = self.s.get(ai + aj, 0) + 1

    def _dec(self, dic, k):
        c = dic[k] - 1
        if c == 0:
            del dic[k]
        else:
            dic[k] = c

    def _inc(self, dic, k):
        dic[k] = dic.get(k, 0) + 1

    def move(self, i, newval):
        """Move element i to newval. Returns (nd, ns) after move."""
        old = self.a[i]
        if newval == old:
            return len(self.d), len(self.s)
        d = self.d
        s = self.s
        # remove pairs with old
        for j, aj in enumerate(self.a):
            self._dec(d, old - aj)
            self._dec(d, aj - old)
            self._dec(s, old + aj)
            self._dec(s, aj + old)
        # add pairs with newval (include self-pair once)
        for j, aj in enumerate(self.a):
            self._inc(d, newval - aj)
            self._inc(d, aj - newval)
            self._inc(s, newval + aj)
            self._inc(s, aj + newval)
        self.a[i] = newval
        return len(d), len(s)

    def counts(self):
        return len(self.d), len(self.s)


def _seed_sidon(n, rng):
    """Greedy Sidon-like (B_2) set: differences almost all distinct."""
    a = [0]
    used_sums = {0}
    used_diffs = {0}
    x = 0
    while len(a) < n:
        x += 1
        ok = True
        for y in a:
            if (x + y) in used_sums or abs(x - y) in used_diffs:
                ok = False
                break
        if ok:
            for y in a:
                used_sums.add(x + y)
                used_diffs.add(abs(x - y))
            used_sums.add(2 * x)
            used_diffs.add(0)
            a.append(x)
    return a


def _hill(inc, deadline, rng):
    """Incremental hill-climb on single-element moves."""
    a = inc.a
    n = len(a)
    if n < 2:
        return inc.counts()
    cd, cs = inc.counts()
    cur = _score(cd, cs) + (1 - 1 / n) / 100
    lo = a[0]
    hi = a[-1]
    span = max(1, hi - lo)
    while time.time() < deadline:
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        old = a[i]
        newval = old + delta
        # keep sorted implicitly handled by allowing duplicates
        if newval in a:
            continue
        nd, ns = inc.move(i, newval)
        if ns < 2:
            inc.move(i, old)
            continue
        nsc = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
        if nsc >= cur:
            cur = nsc
            if a[0] > a[-1]:
                a.sort()
        else:
            inc.move(i, old)
    a.sort()
    return inc.counts()


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(10, 40)) + [45, 50, 60, 70, 80]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 14:
        n = sizes[idx % len(sizes)]
        idx += 1
        seed = _seed_sidon(n, rng)
        inc = Inc(seed)
        s, _, _ = _eval(seed)
        if s > best_score:
            best_score = s
            best = list(seed)
        t_end = min(deadline - 14, time.time() + 0.8)
        _hill(inc, t_end, rng)
        cd, cs = inc.counts()
        if cs >= 2:
            ps = math.log(cd) / math.log(cs) + (1 - 1 / len(inc.a)) / 100
            if ps > best_score:
                best_score = ps
                best = list(inc.a)
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    # final intensification on best
    inc = Inc(best)
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        _hill(inc, t_end, rng)
        cd, cs = inc.counts()
        if cs >= 2 and len(inc.a) >= 2:
            ps = math.log(cd) / math.log(cs) + (1 - 1 / len(inc.a)) / 100
            if ps > cur_score:
                cur_score = ps
                best = list(inc.a)
            else:
                # perturb
                inc = Inc(sorted(set(best)))
                arr = inc.a
                k = max(1, len(arr) // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(len(arr))
                    arr[j] += rng.randint(-40, 40)
                arr = sorted(set(arr))
                inc = Inc(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
