# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large difference set and small sum set.

Key idea: near-geometric families give |A-A| ~ n^2 (nearly all differences
distinct) while |A+A| stays ~ 2n.  We spend the budget seeding from scaled
geometric / Golomb-like starts and improving them with a fast vectorized
simulated annealing that directly maximises log|A-A|/log|A+A|.
"""
import math
import random
import time

import numpy as np


def _diffs_sums(a):
    n = a.size
    if n < 2:
        return 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return int(d), int(s)


def _score(a):
    n = a.size
    if n < 2:
        return -1.0, 0, 0
    d, s = _diffs_sums(a)
    if s < 2:
        return -1.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _valid_unique(a):
    return np.unique(a).size == a.size


def _anneal(start, deadline, rng, span_hint=None):
    cur = np.array(sorted(set(int(x) for x in start)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, cd, css = _score(cur)
    span = int(cur.max() - cur.min()) if cur.size else 1
    span = max(1, span)
    best = cur.copy()
    bests = cs
    t0 = time.time()
    total = max(1e-6, deadline - t0)
    while True:
        now = time.time()
        if now >= deadline:
            break
        frac = (now - t0) / total
        temp = max(1e-3, 0.5 * (1.0 - frac))  # crude cooling
        step = max(1, int(span * (0.25 * (1.0 - frac) + 0.01)))
        cand = cur.copy()
        i = rng.randrange(cand.size)
        cand[i] += rng.randint(-step, step)
        if not _valid_unique(cand):
            continue
        cand = np.sort(cand)
        ns, nd, nss = _score(cand)
        delta = ns - cs
        if delta >= 0 or rng.random() < math.exp(delta / temp):
            cur = cand
            cs, cd, css = ns, nd, nss
            if ns > bests:
                best = cand.copy()
                bests = ns
    return best, bests


def _geometric_seeds(n, rng):
    seeds = []
    for base in (2, 3, 4, 5):
        a = [base ** i for i in range(n)]
        if a[-1] <= 10 ** 15:
            seeds.append(a)
    # near-geometric: base^i rounded plus small jitter
    for base in (2, 3):
        a = []
        v = 1
        for i in range(n):
            a.append(v)
            v = v * base + rng.randint(0, 2)
        if len(a) == n and a[-1] <= 10 ** 15:
            seeds.append(a)
    return seeds


def _golomb_seed(n):
    # simple greedy Golomb-like: a_i with distinct differences, small values
    a = [0]
    used = {0}
    usedd = set()
    x = 0
    for _ in range(n - 1):
        x += 1
        while True:
            ok = True
            for y in a:
                dd = abs(x - y)
                if dd in usedd or dd == 0:
                    ok = False
                    break
            if ok:
                for y in a:
                    usedd.add(abs(x - y))
                a.append(x)
                break
            x += 1
    return a


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240517)
    best = None
    best_score = -1.0

    # --- Structured seed families ---
    seed_pool = []
    for n in (8, 10, 12, 14, 16, 20, 24, 28):
        for s in _geometric_seeds(n, rng):
            seed_pool.append(s)
    for n in (8, 10, 12, 14, 16, 20):
        g = _golomb_seed(n)
        if g and g[-1] <= 10 ** 15:
            seed_pool.append(g)

    # evaluate seeds
    for s in seed_pool:
        arr = np.array(sorted(set(int(x) for x in s)), dtype=np.int64)
        if arr.size < 2:
            continue
        sc, _, _ = _score(arr)
        if sc > best_score:
            best_score = sc
            best = arr.tolist()

    # --- Anneal from structured starts ---
    phase_end = min(deadline, time.time() + 95)
    idx = 0
    while time.time() < phase_end:
        if not seed_pool:
            break
        s = seed_pool[idx % len(seed_pool)]
        idx += 1
        # perturb the seed a little to diversify
        arr = np.array(sorted(set(int(x) for x in s)), dtype=np.int64).copy()
        for _ in range(rng.randint(0, 3)):
            j = rng.randrange(arr.size)
            arr[j] += rng.randint(-3, 3)
        arr = np.unique(arr)
        if arr.size < 2:
            continue
        t_end = min(phase_end, time.time() + 3.0)
        cur, cs = _anneal(arr, t_end, rng)
        if cs > best_score:
            best_score = cs
            best = cur.tolist()

    if best is None:
        best = [0, 1, 3, 7, 12]

    # --- Final polish: long anneal on best ---
    arr = np.array(sorted(set(int(x) for x in best)), dtype=np.int64)
    cur, cs = _anneal(arr, deadline, rng)
    if cs > best_score:
        best = cur.tolist()
        best_score = cs

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
