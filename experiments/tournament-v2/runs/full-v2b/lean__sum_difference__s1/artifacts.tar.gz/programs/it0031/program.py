# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _grow(n, rng):
    """Greedy: build a by minimizing new sums while maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 24):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:500]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _beatty(n, rng):
    """Beatty sequence floor(k*alpha); sum-poor constructions."""
    alpha = 1.0 + rng.uniform(0.05, 0.6)
    return [int(math.floor(k * alpha)) for k in range(n)]


def _geo(n, rng):
    """Scaled geometric-ish progression."""
    base = rng.choice([2, 3])
    a = [0]
    v = 1
    for _ in range(n - 1):
        a.append(v)
        v = v * base + rng.randint(0, 1)
    return a


def _golomb(n, rng):
    """Greedy Golomb-like ruler (all pairwise diffs distinct)."""
    a = [0]
    used = {0}
    while len(a) < n:
        cand = a[-1] + 1
        while True:
            ok = True
            for x in a:
                if abs(cand - x) in used:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        for x in a:
            used.add(abs(cand - x))
        used.add(0)
        a.append(cand)
    return a


def _steepest(a, deadline, rng, span_hint):
    """Steepest-ascent hill-climb on single-element moves."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    while time.time() < deadline:
        improved = False
        i = rng.randrange(cur.size)
        step = max(1, span_hint // rng.choice([2, 3, 4, 6, 8, 12]))
        best_delta = 0
        best_sc = cs
        for delta in [d for d in range(-step, step + 1) if d]:
            cand = cur.copy()
            cand[i] += delta
            if np.unique(cand).size != cand.size:
                continue
            ns, _, _ = _eval(cand)
            if ns > best_sc:
                best_sc = ns
                best_delta = delta
        if best_delta:
            cur[i] += best_delta
            cur = np.sort(cur)
            cs = best_sc
            improved = True
        if not improved:
            # random kick
            j = rng.randrange(cur.size)
            cur[j] += rng.randint(-span_hint, span_hint) or 1
            cur = np.unique(np.sort(cur))
            if cur.size < 2:
                return cur, -1.0
            cs, _, _ = _eval(cur)
            span_hint = max(1, int(cur.max() - cur.min()))
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    sizes = list(range(8, 26)) + [30, 35, 40, 50]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 12:
        n = sizes[idx % len(sizes)]
        idx += 1
        kind = rng.random()
        if kind < 0.4:
            a = _beatty(n, rng)
        elif kind < 0.6:
            a = _golomb(n, rng)
        elif kind < 0.8:
            a = _geo(n, rng)
        else:
            a = _grow(n, rng)
        a = sorted(set(int(x) for x in a))
        if len(a) < 2:
            continue
        arr = np.array(a, dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        span = max(1, int(arr.max() - arr.min()))
        t_end = min(deadline - 12, time.time() + 0.5)
        pol, ps = _steepest(a, t_end, rng, span)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        span = max(1, int(cur[-1] - cur[0]))
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _steepest(cur, t_end, rng, span)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-30, 30)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
