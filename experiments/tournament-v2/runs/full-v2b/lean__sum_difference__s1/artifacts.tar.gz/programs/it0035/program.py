# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return int(d), int(s)


def _score_fast(a):
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    arr = np.array(a, dtype=np.int64)
    d, s = _counts(arr)
    if s < 2:
        return -1.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _process_one(n, span_lo, span_hi, rng, deadline):
    """Build a dense random set in a small span, then tidy it."""
    best = None
    best_score = -1.0
    while time.time() < deadline:
        span = rng.randint(span_lo, span_hi)
        vals = rng.sample(range(-span // 2, span // 2 + 1), min(n, span + 1))
        vals = sorted(set(vals))
        s, _, _ = _score_fast(vals)
        if s > best_score:
            best_score = s
            best = list(vals)
    return best, best_score


def _climb(a, deadline, rng):
    """Best-of-K steepest ascent on the true score."""
    cur = sorted(set(int(x) for x in a))
    if len(cur) < 2:
        return cur, -1.0
    cs, cd, csum = _score_fast(cur)
    span = max(4, cur[-1] - cur[0])
    stale = 0
    while time.time() < deadline:
        n = len(cur)
        improved = False
        for i in range(n):
            base = cur[i]
            step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
            best_d = 0
            best_s = cs
            deltas = [d for d in range(-step, step + 1) if d]
            rng.shuffle(deltas)
            for d in deltas[:2 * step + 1]:
                x = base + d
                if abs(x) > 10**15:
                    continue
                cand = cur[:i] + [x] + cur[i + 1:]
                if len(set(cand)) != n:
                    continue
                cand = sorted(cand)
                s, nd, ns = _score_fast(cand)
                if s > best_s:
                    best_s = s
                    best_d = d
                    improved = True
            if best_d != 0:
                cur[i] += best_d
                cur = sorted(cur)
                cs = best_s
                span = max(4, cur[-1] - cur[0])
        if not improved:
            stale += 1
            if stale > 2:
                # random restart around the best set
                for _ in range(rng.randint(1, max(1, n // 4))):
                    j = rng.randrange(n)
                    cur[j] += rng.randint(-span, span)
                cur = sorted(set(cur))
                if len(cur) < 2:
                    break
                cs, _, _ = _score_fast(cur)
                span = max(4, cur[-1] - cur[0])
                stale = 0
        else:
            stale = 0
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    # Small dense sets maximize the ratio. Sizes around 20-40 with small spans.
    sizes = [20, 22, 25, 28, 30, 24, 26, 32, 35, 18, 16, 40]
    random.shuffle(sizes)
    idx = 0
    while time.time() < deadline - 20:
        n = sizes[idx % len(sizes)]
        idx += 1
        # A dense set in span ~ 2n..6n tends to have few sums.
        lo = max(n, n)
        hi = 6 * n
        a, s = _process_one(n, lo, hi, rng, min(deadline - 18, time.time() + 0.4))
        if a is None:
            continue
        # local climb
        t_end = min(deadline - 15, time.time() + 1.2)
        pol, ps = _climb(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol

    if best is None:
        best = [0, 1, 3, 7, 12]
        best_score, _, _ = _score_fast(best)

    cur = list(best)
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _climb(cur, t_end, rng)
        if cs > cur_score:
            cur = cand
            cur_score = cs
            best = cand
            best_score = cs
        else:
            cur = list(best)
            cur_score = best_score
            for _ in range(rng.randint(1, max(1, len(cur) // 5))):
                j = rng.randrange(len(cur))
                cur[j] += rng.randint(-30, 30)
            cur = sorted(set(cur))
            cur_score, _, _ = _score_fast(cur)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
