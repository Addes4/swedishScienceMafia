# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A| using an incremental evaluator."""
import math
import random
import time


class Inc:
    """Incrementally maintain difference/sum multiplicities of a set of ints."""

    __slots__ = ("a", "sd_", "ss_", "nd", "ns")

    def __init__(self, a):
        a = sorted(set(int(x) for x in a))
        self.a = a
        n = len(a)
        self.sd_ = {}   # diff value -> count
        self.ss_ = {}   # sum value -> count
        for i in range(n):
            ai = a[i]
            for j in range(n):
                if i == j:
                    continue
                d = ai - a[j]
                self.sd_[d] = self.sd_.get(d, 0) + 1
                if i <= j:
                    s = ai + a[j]
                    self.ss_[s] = self.ss_.get(s, 0) + 1
        # include self-sums (a+a) - sums set is over all i,j so i==j counts too
        for i in range(n):
            s = a[i] + a[i]
            self.ss_[s] = self.ss_.get(s, 0) + 1
        self.nd = len(self.sd_)
        self.ns = len(self.ss_)

    def remove(self, x):
        a = self.a
        sd = self.sd_
        ss = self.ss_
        for y in a:
            if y == x:
                continue
            d = x - y
            c = sd[d] - 1
            if c:
                sd[d] = c
            else:
                del sd[d]
            d2 = y - x
            c = sd[d2] - 1
            if c:
                sd[d2] = c
            else:
                del sd[d2]
            s = x + y
            c = ss[s] - 1
            if c:
                ss[s] = c
            else:
                del ss[s]
        # self sums: x+x counted once (removed), x+a where a==x excluded above
        s = x + x
        c = ss[s] - 1
        if c:
            ss[s] = c
        else:
            del ss[s]

    def add(self, x):
        a = self.a
        sd = self.sd_
        ss = self.ss_
        for y in a:
            d = x - y
            sd[d] = sd.get(d, 0) + 1
            d2 = y - x
            sd[d2] = sd.get(d2, 0) + 1
            s = x + y
            ss[s] = ss.get(s, 0) + 1
        s = x + x
        ss[s] = ss.get(s, 0) + 1

    def move(self, idx, newval):
        """Change a[idx] to newval. Returns True if accepted (distinct)."""
        old = self.a[idx]
        if newval == old:
            return False
        # temporarily remove old
        rest = self.a[:idx] + self.a[idx + 1:]
        if newval in rest:
            return False
        self.a = rest
        self.remove(old)
        self.a = rest
        # insert newval into rest maintaining order
        lo, hi = 0, len(rest)
        while lo < hi:
            mid = (lo + hi) // 2
            if rest[mid] < newval:
                lo = mid + 1
            else:
                hi = mid
        newa = rest[:lo] + [newval] + rest[lo:]
        self.a = newa
        self.add(newval)
        self.nd = len(self.sd_)
        self.ns = len(self.ss_)
        return True

    def score(self):
        if self.ns < 2:
            return -1.0
        n = len(self.a)
        return math.log(self.nd) / math.log(self.ns) + (1 - 1 / n) / 100


def _eval_list(a):
    a = sorted(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return -1.0, 0, 0, a
    d = set()
    s = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            d.add(ai - a[j])
            s.add(ai + a[j])
    nd = len(d)
    ns = len(s)
    if ns < 2:
        return -1.0, nd, ns, a
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns, a


def _construct(n, rng, width):
    """Build a near-Sidon-ish set on a short interval of given width."""
    # Random greedy: pick elements minimizing new sums, maximizing new diffs.
    a = [0]
    used = {0}
    lo = 0
    hi = width
    for _ in range(n - 1):
        cands = [x for x in range(lo, hi + 1) if x not in used]
        rng.shuffle(cands)
        cands = cands[:min(len(cands), 60)]
        best_x = None
        best_val = None
        sd = set()
        ss = set()
        for i in range(len(a)):
            for j in range(len(a)):
                sd.add(a[i] - a[j])
                ss.add(a[i] + a[j])
        for x in cands:
            nd_new = 0
            ns_new = 0
            for y in a:
                if (x - y) not in sd:
                    nd_new += 1
                if (y - x) not in sd:
                    nd_new += 1
                if (x + y) not in ss:
                    ns_new += 1
            val = nd_new - 2.0 * ns_new
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
        used.add(best_x)
    return sorted(a)


def _hill(inc, deadline, rng):
    span = max(1, inc.a[-1] - inc.a[0])
    while time.time() < deadline:
        n = len(inc.a)
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 5, 6, 8, 12, 16]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        old = inc.a[i]
        newval = old + delta
        cur = inc.score()
        if inc.move(i, newval):
            ns = inc.score()
            if ns >= cur:
                continue
            else:
                # revert
                inc.move(i, old)
    return inc


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(10, 40)) + [45, 50, 60, 70, 80]
    widths = [200, 400, 800, 1600, 3200, 6400]

    end_search = deadline - 10

    idx = 0
    while time.time() < end_search:
        n = sizes[idx % len(sizes)]
        w = widths[(idx * 7 + 3) % len(widths)]
        idx += 1
        a = _construct(n, rng, max(w, n * (n - 1) // 2))
        sc, nd, ns, a = _eval_list(a)
        if sc > best_score:
            best_score = sc
            best = a
        inc = Inc(a)
        t_end = min(end_search, time.time() + 0.5)
        _hill(inc, t_end, rng)
        if inc.score() > best_score:
            best_score = inc.score()
            best = list(inc.a)
        if idx % (3 * len(sizes)) == 0:
            rng.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    # final intensive refinement
    cur = sorted(set(int(x) for x in best))
    inc = Inc(cur)
    cur_score = inc.score()
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 2.5)
        _hill(inc, t_end, rng)
        s = inc.score()
        if s > cur_score:
            cur_score = s
            cur = list(inc.a)
        else:
            # perturb
            n = len(inc.a)
            if n > 2:
                for _ in range(rng.randint(1, max(1, n // 8))):
                    i = rng.randrange(n)
                    old = inc.a[i]
                    inc.move(i, old + rng.randint(-40, 40))
            cur_score = inc.score()
            cur = list(inc.a)
            if cur_score < 0:
                inc = Inc(best)
                cur_score = inc.score()

    if inc.score() > best_score:
        best = list(inc.a)
        best_score = inc.score()

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
