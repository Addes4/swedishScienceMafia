# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _eval_fast(a):
    """Score using sorted-array unique counting (no giant broadcast for sums)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    # sums: use pairwise on sorted via broadcasting but on int64 - still ok for n<=4000
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _sidon_grow(n, rng, span_factor=1.0):
    """Greedy near-Sidon: add element minimizing number of new sums, tied-break max new diffs."""
    # work on a short interval to keep sums small:  span ~ n^2/2 (Sidon lower bound)
    span = max(n, int(0.5 * n * n * span_factor))
    a = [0]
    used = {0}
    curd = {0}
    curs = {0}
    while len(a) < n:
        # candidate pool: random points in [0, span], biased near existing
        cands = set()
        for _ in range(300):
            cands.add(rng.randint(0, span))
        for base in a:
            for _ in range(6):
                cands.add(base + rng.randint(1, max(2, span // n)))
                cands.add(base - rng.randint(1, max(2, span // n)))
        best_x = None
        best_key = None
        for x in cands:
            if x in used:
                continue
            news = 0
            newd = 0
            ok = True
            for y in a:
                s1 = x + y
                if s1 not in curs:
                    news += 1
                d1 = x - y
                d2 = y - x
                if d1 not in curd:
                    newd += 1
                if d2 not in curd:
                    newd += 1
                if news > 60:
                    ok = False
                    break
            if not ok:
                continue
            key = news * 1000 - newd
            if best_key is None or key < best_key:
                best_key = key
                best_x = x
        if best_x is None:
            break
        for y in a:
            curs.add(best_x + y)
            curd.add(best_x - y)
            curd.add(y - best_x)
        a.append(best_x)
        used.add(best_x)
    return a


def _hill(a, deadline, rng):
    """Steepest-ascent style: try several deltas per element, accept improvements/ties."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval_fast(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        improved = False
        order = list(range(cur.size))
        rng.shuffle(order)
        for i in order:
            if time.time() >= deadline:
                break
            base = cur[i]
            step = max(1, span // rng.choice([16, 24, 32, 48, 64]))
            best_delta = 0
            best_s = cs
            for _ in range(8):
                delta = rng.randint(-step, step)
                if delta == 0:
                    continue
                cand = cur.copy()
                cand[i] = base + delta
                if np.unique(cand).size != cand.size:
                    continue
                cand = np.sort(cand)
                ns, _, _ = _eval_fast(cand)
                if ns >= best_s:
                    best_s = ns
                    best_delta = delta
            if best_delta != 0 and best_s >= cs:
                cur = np.sort(cur.copy())
                cur[i] = base + best_delta
                cur = np.sort(cur)
                if np.unique(cur).size != cur.size:
                    # revert
                    cur = np.array(sorted(set(cur.tolist())), dtype=np.int64)
                cs = best_s
                improved = True
        if not improved:
            # perturb
            arr = cur.copy()
            for _ in range(max(1, cur.size // 10)):
                j = rng.randrange(arr.size)
                arr[j] += rng.randint(-span // 8 - 1, span // 8 + 1)
            arr = np.unique(np.sort(arr))
            if arr.size < 2:
                break
            cur = arr
            cs, _, _ = _eval_fast(cur)
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(10, 28)) + [30, 34, 38, 44, 50]
    random.shuffle(sizes)
    idx = 0

    # seed a few known-good small sets
    seeds = [[0, 1, 3, 7, 12, 20, 30, 44], [0, 1, 4, 10, 18, 27, 39, 51]]
    for sd in seeds:
        arr = np.array(sorted(set(sd)), dtype=np.int64)
        s, _, _ = _eval_fast(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()

    while time.time() < deadline - 20:
        n = sizes[idx % len(sizes)]
        idx += 1
        sf = rng.choice([0.6, 0.8, 1.0, 1.3, 1.7])
        a = _sidon_grow(n, rng, sf)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval_fast(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 15, time.time() + 1.2)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (3 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
            if cs > best_score:
                best_score = cs
                best = list(cur)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
