# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _seed(n, rng):
    """Dense set on a small interval: tight sums, many differences."""
    # interval length roughly proportional to n but kept small
    span = max(n, int(n * rng.uniform(0.5, 1.2)))
    a = rng.sample(range(span + 1), min(n, span + 1))
    return sorted(a)


def _seed_geo(n, rng):
    """Geometric-like seed with large differences."""
    r = rng.uniform(1.5, 2.5)
    a = [0, 1]
    for _ in range(n - 2):
        a.append(a[-1] + max(1, int(a[-1] * (r - 1)) + rng.randint(0, 2)))
    return sorted(set(a))


def _hill(cur, deadline, rng):
    """Best-of-K steepest-ascent local search maximizing the true score."""
    cur = sorted(set(int(x) for x in cur))
    if len(cur) < 2:
        return np.array(cur, dtype=np.int64), -1.0
    arr = np.array(cur, dtype=np.int64)
    cs, _, _ = _eval(arr)
    n = arr.size
    span = max(1, int(arr.max() - arr.min()))
    steps_pool = [1, 2, 3, 5, 8, 13, 21]
    while time.time() < deadline:
        i = rng.randrange(n)
        improved = False
        # try a bundle of deltas for element i
        base = arr[i]
        deltas = []
        for s in steps_pool:
            d = s * max(1, span // 16)
            deltas.append(d)
            deltas.append(-d)
        rng.shuffle(deltas)
        best_cand = None
        best_s = cs
        for delta in deltas[:10]:
            v = base + delta
            if abs(v) > 10**15:
                continue
            cand = arr.copy()
            cand[i] = v
            if np.unique(cand).size != n:
                continue
            cand = np.sort(cand)
            ns, _, _ = _eval(cand)
            if ns > best_s:
                best_s = ns
                best_cand = cand
        if best_cand is not None:
            arr = best_cand
            cs = best_s
            improved = True
        if not improved:
            # random small perturbation to escape
            j = rng.randrange(n)
            delta = rng.randint(-max(1, span // 8), max(1, span // 8))
            if delta == 0:
                delta = 1
            cand = arr.copy()
            cand[j] += delta
            if np.unique(cand).size == n:
                arr = np.sort(cand)
                cs, _, _ = _eval(arr)
    return arr, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(6, 24)) + [28, 32, 40]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 12:
        n = sizes[idx % len(sizes)]
        idx += 1
        if rng.random() < 0.6:
            a = _seed(n, rng)
        else:
            a = _seed_geo(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 12, time.time() + 0.6)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-30, 30)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
