# EVOLVE-BLOCK-START
"""Fast time-bounded simulated annealing for log|A-A|/log|A+A|, seeded from structured starts."""
import math
import random
import time

import numpy as np


def _score(a):
    """Return (score, |A-A|, |A+A|) for a sorted/unsorted int array."""
    n = a.size
    if n < 2:
        return -1.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return -1.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _score_fast(a):
    """Slightly cheaper: assumes a is unique."""
    n = a.size
    if n < 2:
        return -1.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return -1.0, d, s
    return (math.log(d) / math.log(s)) + (1.0 - 1.0 / n) / 100.0, d, s


def _try_set(cand, cur_score, cur_arr):
    """Return (improved_score, arr) accepting improvements only."""
    if np.unique(cand).size != cand.size:
        return cur_score, cur_arr
    cand = np.sort(cand)
    sc, _, _ = _score_fast(cand)
    if sc > cur_score:
        return sc, cand
    return cur_score, cur_arr


# ---------- structured seeds ----------

def _seed_golomb(n):
    """A Golomb-ruler-like set (large |A-A|)."""
    # known good Golomb rulers (prefixes usable)
    base = [0, 1, 4, 10, 18, 23, 25]
    a = list(base[:min(n, len(base))])
    x = a[-1] + 1 if a else 0
    while len(a) < n:
        # extend by a prime-ish gap to keep distinct diffs
        a.append(a[-1] + x)
        x += 1
    return a


def _seed_geometric(n, r):
    a = [0]
    while len(a) < n:
        a.append(a[-1] + max(1, int(r ** len(a))) if r > 1 else a[-1] + 1)
    return a


def _seed_interval_like(n):
    """Interval with perturbations to shrink |A+A| while adding diffs."""
    a = list(range(n))
    return a


def _seed_binomial_like(n):
    """Sets of the form {i*D + small(i)}."""
    a = [i * (i + 1) // 2 for i in range(n)]
    return a


def _jitter(a, rng, span, k):
    arr = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if arr.size == 0:
        return arr
    for _ in range(k):
        j = rng.randrange(arr.size)
        arr[j] += rng.randint(-span, span)
    return np.unique(np.sort(arr))


def _anneal(start, deadline, rng, warmup_T=2.0, cool=0.9995):
    cur = np.array(sorted(set(int(x) for x in start)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _score_fast(cur)
    best = cur.copy()
    best_s = cs
    T = warmup_T
    span = max(1, int(cur.max() - cur.min()) if cur.size else 1)
    it = 0
    while time.time() < deadline:
        it += 1
        T = warmup_T * (cool ** it)
        if T < 1e-4:
            T = 1e-4
        cand = cur.copy()
        i = rng.randrange(cand.size)
        scale = max(1, int(span * (0.02 + 0.3 * T)))
        cand[i] += rng.randint(-scale, scale)
        if cand[i] == cur[i]:
            continue
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        ns, _, _ = _score_fast(cand)
        if ns >= cs or rng.random() < math.exp((ns - cs) / max(T, 1e-6)):
            cur = cand
            cs = ns
            if ns > best_s:
                best_s = ns
                best = cur.copy()
    return best, best_s


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)

    seeds = []
    for n in range(6, 34):
        seeds.append(_seed_golomb(n))
        seeds.append(_seed_interval_like(n))
        seeds.append(_seed_binomial_like(n))
    for r in (1.1, 1.2, 1.3, 1.5, 2.0):
        for n in range(6, 26):
            seeds.append(_seed_geometric(n, r))
    random.shuffle(seeds)

    best_arr = None
    best_score = -1.0

    # Phase 1: quick screen of seeds
    scored = []
    for s in seeds:
        arr = np.unique(np.sort(np.array(sorted(set(int(x) for x in s)), dtype=np.int64)))
        if arr.size < 2:
            continue
        sc, _, _ = _score_fast(arr)
        scored.append((sc, arr.tolist()))
    scored.sort(key=lambda t: -t[0])
    if scored:
        best_score = scored[0][0]
        best_arr = list(scored[0][1])

    # Phase 2: anneal the top seeds and take the best; restart with jitter over budget
    pool = [s for _, s in scored[:25]] or ([best_arr] if best_arr else [])

    idx = 0
    while time.time() < deadline:
        if pool:
            start = pool[idx % len(pool)]
            idx += 1
        else:
            start = best_arr or [0, 1, 3, 7, 12]
        slice_end = min(deadline, time.time() + 3.0)
        arr, sc = _anneal(start, slice_end, rng)
        if sc > best_score:
            best_score = sc
            best_arr = arr.tolist()
            pool[idx % len(pool) if pool else 0] = best_arr[:] if pool else None
        # occasionally re-seed with a jittered copy of the best
        if pool and best_arr and rng.random() < 0.5:
            span = max(1, max(best_arr) - min(best_arr))
            j = _jitter(best_arr, rng, max(1, span // 20), rng.randint(1, 3))
            if j.size >= 2:
                pool[idx % len(pool)] = j.tolist()

    if best_arr is None:
        best_arr = [0, 1, 3, 7, 12]
    return sorted(set(int(x) for x in best_arr))
# EVOLVE-BLOCK-END
