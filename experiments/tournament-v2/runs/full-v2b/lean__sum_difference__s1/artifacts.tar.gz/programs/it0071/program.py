# EVOLVE-BLOCK-START
"""Bitset-incremental search for large |A-A|, small |A+A|."""
import math
import random
import time


def _score_bits(nd, ns, n):
    if ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


class Bitset:
    """Maintains shifted bitsets for A-A and A+A with popcounts."""
    __slots__ = ("a", "off_d", "off_s", "bd", "bs", "nd", "ns")

    def __init__(self, a):
        self.a = sorted(set(int(x) for x in a))
        self._rebuild()

    def _rebuild(self):
        a = self.a
        n = len(a)
        if n == 0:
            self.off_d = self.off_s = 0
            self.bd = self.bs = 0
            self.nd = self.ns = 0
            return
        dvals = [x - y for x in a for y in a]
        svals = [x + y for x in a for y in a]
        self.off_d = min(dvals)
        self.off_s = min(svals)
        bd = 0
        for v in dvals:
            bd |= 1 << (v - self.off_d)
        bs = 0
        for v in svals:
            bs |= 1 << (v - self.off_s)
        self.bd = bd
        self.bs = bs
        self.nd = bin(bd).count("1")
        self.ns = bin(bs).count("1")

    def add(self, x):
        a = self.a
        bd = self.bd
        bs = self.bs
        od = self.off_d
        os_ = self.off_s
        for y in a:
            v = x - y
            if v < od:
                bd <<= (od - v)
                bd |= 1
                bd |= 1 << (od - v)  # placeholder, fixed below
                od = v
            else:
                bd |= 1 << (v - od)
            v = y - x
            if v < od:
                bd <<= (od - v)
                bd |= 1
                od = v
            else:
                bd |= 1 << (v - od)
            v = x + y
            if v < os_:
                bs <<= (os_ - v)
                bs |= 1
                os_ = v
            else:
                bs |= 1 << (v - os_)
        # new element vs itself
        v = 0
        if v < od:
            bd <<= (od - v)
            bd |= 1
            od = v
        else:
            bd |= 1 << (v - od)
        v = 2 * x
        if v < os_:
            bs <<= (os_ - v)
            bs |= 1
            os_ = v
        else:
            bs |= 1 << (v - os_)
        a.append(x)
        a.sort()
        self.a = a
        self.off_d = od
        self.off_s = os_
        self.bd = bd
        self.bs = bs
        self.nd = bin(bd).count("1")
        self.ns = bin(bs).count("1")

    def try_add(self, x):
        """Return (nd, ns) without mutating permanently."""
        bd = self.bd
        bs = self.bs
        od = self.off_d
        os_ = self.off_s
        for y in self.a:
            v = x - y
            if v < od:
                bd = bd << (od - v)
                bd |= 1
                od = v
            else:
                bd |= 1 << (v - od)
            v = y - x
            if v < od:
                bd = bd << (od - v)
                bd |= 1
                od = v
            else:
                bd |= 1 << (v - od)
            v = x + y
            if v < os_:
                bs = bs << (os_ - v)
                bs |= 1
                os_ = v
            else:
                bs |= 1 << (v - os_)
        v = 0
        if v < od:
            bd = bd << (od - v)
            bd |= 1
            od = v
        else:
            bd |= 1 << (v - od)
        v = 2 * x
        if v < os_:
            bs = bs << (os_ - v)
            bs |= 1
            os_ = v
        else:
            bs |= 1 << (v - os_)
        return bin(bd).count("1"), bin(bs).count("1"), bd, bs, od, os_


def _grow(n, rng, max_span):
    """Greedy: add elements minimizing new sums, maximizing new diffs."""
    a = [0]
    bs = Bitset(a)
    while len(a) < n:
        lo = min(a) - 2 * max_span
        hi = max(a) + 2 * max_span
        cands = set()
        for base in a:
            for d in range(1, 20):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a) and lo <= c <= hi]
        rng.shuffle(cands)
        cands = cands[:300]
        best = None
        best_val = None
        for x in cands:
            nd, ns, *_ = bs.try_add(x)
            newn = len(a) + 1
            val = _score_bits(nd, ns, newn)
            if best_val is None or val > best_val:
                best_val = val
                best = x
        if best is None:
            break
        bs.add(best)
    return bs


def _hill(bs, deadline, rng, span):
    cur_score = _score_bits(bs.nd, bs.ns, len(bs.a))
    while time.time() < deadline:
        a = bs.a
        n = len(a)
        if n < 3:
            return bs, cur_score
        # try removing then re-adding an element elsewhere (move)
        i = rng.randrange(n)
        removed = a[i]
        rest = a[:i] + a[i + 1:]
        nb = Bitset(rest)
        delta = rng.randint(-span, span)
        if delta == 0:
            delta = 1
        x = removed + delta
        if x in set(rest):
            continue
        nd, ns, bd, bsN, od, os_ = nb.try_add(x)
        sc = _score_bits(nd, ns, n)
        if sc >= cur_score:
            nb.a.append(x)
            nb.a.sort()
            nb.bd = bd
            nb.bs = bsN
            nb.off_d = od
            nb.off_s = os_
            nb.nd = nd
            nb.ns = ns
            bs = nb
            cur_score = sc
    return bs, cur_score


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(10, 40)) + [45, 50, 60, 70, 80]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 10:
        n = sizes[idx % len(sizes)]
        idx += 1
        max_span = max(4, n * 3)
        try:
            bs = _grow(n, rng, max_span)
        except MemoryError:
            continue
        if len(bs.a) < 2:
            continue
        sc = _score_bits(bs.nd, bs.ns, len(bs.a))
        if sc > best_score:
            best_score = sc
            best = list(bs.a)
        t_end = min(deadline - 10, time.time() + 0.8)
        bs2, sc2 = _hill(bs, t_end, rng, max(1, max_span))
        if sc2 > best_score:
            best_score = sc2
            best = list(bs2.a)
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    if len(best) >= 3:
        try:
            bs = Bitset(best)
            cur_score = _score_bits(bs.nd, bs.ns, len(bs.a))
            span = max(1, (max(bs.a) - min(bs.a)) // 4)
            while time.time() < deadline:
                t_end = min(deadline, time.time() + 3.0)
                bs, cs = _hill(bs, t_end, rng, span)
                if cs > cur_score:
                    cur_score = cs
                    best = list(bs.a)
                else:
                    # perturb: random restart-ish move
                    a = bs.a
                    if len(a) >= 3:
                        i = rng.randrange(len(a))
                        a = a[:i] + a[i + 1:]
                        a.append(rng.randint(min(a) - span, max(a) + span))
                        a = sorted(set(a))
                        bs = Bitset(a)
                        cur_score = _score_bits(bs.nd, bs.ns, len(bs.a))
        except MemoryError:
            pass

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
