# EVOLVE-BLOCK-START
"""Clean time-bounded search maximising log|A-A|/log|A+A|.

Strategy: small sets (n in ~8..40) with a multiplicative (geometric-like)
structure maximise difference-set size while keeping sum-set size low.
We use a fast exact evaluator plus time-bounded simulated annealing.
"""
import math
import random
import time

import numpy as np


def _diffs_sums(a):
    """Exact |A-A| and |A+A| for a 1-D int64 array."""
    n = a.size
    if n < 2:
        return 1, 1
    d = np.unique(a[:, None] - a[None, :])
    s = np.unique(a[:, None] + a[None, :])
    return int(d.size), int(s.size)


def _score(a):
    n = a.size
    if n < 2:
        return 0.0
    d, s = _diffs_sums(a)
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _geometric_seed(n, base, rng):
    """Scaled geometric progression: large differences, small sums."""
    a = [0]
    v = 1
    vals = [0]
    for _ in range(n - 1):
        v *= base
        vals.append(v)
    return sorted(set(int(x) for x in vals))


def _sidon_like(n, rng):
    """Greedy Sidon-ish set (all pairwise sums distinct -> small sum set)."""
    a = [0, 1]
    seen_sum = {0, 1, 2}
    cand = 2
    tries = 0
    while len(a) < n and tries < 4000:
        tries += 1
        x = cand
        cand += 1
        ok = True
        new_sums = []
        for y in a:
            s = x + y
            if s in seen_sum or s in new_sums:
                ok = False
                break
            new_sums.append(s)
        if ok:
            a.append(x)
            for s in new_sums:
                seen_sum.add(s)
            seen_sum.add(2 * x)
    return a


def _anneal(seed, deadline, rng, room=1e6):
    cur = np.array(sorted(set(int(x) for x in seed)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cur_score = _score(cur)
    best = cur.copy()
    best_score = cur_score
    span = max(1, int(cur.max() - cur.min()))
    T = 0.05
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur.copy()
        i = rng.randrange(cand.size)
        step = max(1, int(span * (0.5 ** rng.randint(0, 6))))
        cand[i] += rng.randint(-step, step)
        if np.unique(cand).size != cand.size:
            continue
        ns = _score(cand)
        if ns >= cur_score or rng.random() < math.exp((ns - cur_score) / max(T, 1e-9)):
            cur = np.sort(cand)
            cur_score = ns
            if ns > best_score:
                best_score = ns
                best = cur.copy()
        if it % 40 == 0:
            T *= 0.97
            if rng.random() < 0.15:
                # occasional restart from best with jitter
                cur = best.copy()
                cur_score = best_score
                T = max(T, 0.02)
    return best, best_score


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    sizes = list(range(8, 41)) + [50, 65, 80, 100, 130]
    seeds = []

    # Build a diverse seed pool.
    for n in sizes:
        for base in (2, 3, 4, 5, 7):
            s = _geometric_seed(n, base, rng)
            if len(s) >= 2:
                seeds.append(s)
        if n <= 40:
            seeds.append(_sidon_like(n, rng))
        # random dense small sets
        if n <= 30:
            for _ in range(3):
                seeds.append(sorted(rng.sample(range(0, n * 4), n)))

    rng.shuffle(seeds)

    # Phase 1: score all seeds, keep the best few.
    scored = []
    for s in seeds:
        arr = np.array(sorted(set(int(x) for x in s)), dtype=np.int64)
        if arr.size < 2:
            continue
        sc = _score(arr)
        scored.append((sc, arr))
        if sc > best_score:
            best_score = sc
            best = arr.tolist()

    if not scored:
        best = [0, 1, 3, 7, 12]
        best_score = _score(np.array(best, dtype=np.int64))

    scored.sort(key=lambda t: -t[0])
    top_seeds = [arr for _, arr in scored[:12]]

    # Phase 2: anneal each top seed until budget is exhausted.
    idx = 0
    while time.time() < deadline:
        seed = top_seeds[idx % len(top_seeds)]
        idx += 1
        # scale the seed a bit so span is meaningful
        arr = np.array(seed, dtype=np.int64)
        t_end = min(deadline, time.time() + 8.0)
        cand, cand_score = _anneal(arr, t_end, rng)
        if cand_score > best_score:
            best_score = cand_score
            best = cand.tolist()
            top_seeds.append(np.array(best, dtype=np.int64))
        if idx % len(top_seeds) == 0:
            rng.shuffle(top_seeds)

    # Final: quick polish on the single best set.
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cand_score = _anneal(np.array(best, dtype=np.int64), t_end, rng)
        if cand_score > best_score:
            best_score = cand_score
            best = cand.tolist()

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
