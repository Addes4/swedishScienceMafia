# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return d, s


def _dense_seed(n, rng):
    """Dense set on a short interval: small |A+A|, large |A-A|."""
    # choose interval length modestly larger than n
    span = int(n * rng.uniform(2.0, 5.0)) + 1
    vals = rng.sample(range(-span, span + 1), min(n, 2 * span + 1))
    return vals


def _beatty_seed(n, rng):
    alpha = rng.uniform(1.3, 2.9)
    return [int(math.floor(k * alpha)) for k in range(1, n + 1)]


def _geo_seed(n, rng):
    r = rng.uniform(1.1, 1.6)
    out = []
    x = 1.0
    for _ in range(n):
        out.append(int(x))
        x *= r
    return out


def _hill(a, deadline, rng):
    """Steepest-ascent hill-climb moving single elements, accepting ties."""
    cur = np.unique(np.array(sorted(set(int(x) for x in a)), dtype=np.int64))
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        improved = False
        order = list(range(cur.size))
        rng.shuffle(order)
        for i in order:
            base = cur.copy()
            best_v = cs
            best_c = None
            for step in (span // 2, span // 4, span // 8, span // 16, 3, 1):
                step = max(1, step)
                for sgn in (1, -1):
                    cand = base.copy()
                    cand[i] += sgn * step
                    if np.unique(cand).size != cand.size:
                        continue
                    cand = np.sort(cand)
                    ns, _, _ = _eval(cand)
                    if ns > best_v + 1e-12:
                        best_v = ns
                        best_c = cand
                    elif ns > cs and best_c is None:
                        best_v = ns
                        best_c = cand
            if best_c is not None:
                cur = best_c
                cs = best_v
                improved = True
        if not improved:
            # random escape
            j = rng.randrange(cur.size)
            cand = cur.copy()
            cand[j] += rng.randint(-max(2, span // 8), max(2, span // 8))
            if np.unique(cand).size == cand.size:
                cur = np.sort(cand)
                cs, _, _ = _eval(cur)
            else:
                break
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240613)
    best = None
    best_score = -1.0

    def consider(arr):
        nonlocal best, best_score
        if arr is None or len(arr) < 2:
            return
        arr = np.unique(np.array(arr, dtype=np.int64))
        if arr.size < 2:
            return
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()

    # Seed with dense short-interval sets across many sizes
    sizes = list(range(6, 26)) + [30, 35, 40, 50, 60, 80]
    for n in sizes:
        consider(_dense_seed(n, rng))
        consider(_beatty_seed(n, rng))
        consider(_geo_seed(n, rng))

    # Short hill-climbs on the most promising seeds
    seeds = list(best) if best else [0, 1, 3, 7]
    polished = _hill(seeds, min(deadline - 5, time.time() + 10.0), rng)
    consider(polished[0].tolist())
    seeds2 = _hill(best, min(deadline - 5, time.time() + 20.0), rng)
    consider(seeds2[0].tolist())

    # Main loop: alternate restart seeds and longer climbs from the best
    while time.time() < deadline - 3:
        n = rng.choice(sizes)
        seed = rng.choice([_dense_seed, _beatty_seed, _geo_seed])(n, rng)
        a = np.unique(np.array(sorted(set(int(x) for x in seed)), dtype=np.int64))
        if a.size >= 2:
            t_end = min(deadline - 3, time.time() + 0.8)
            pol, ps = _hill(a, t_end, rng)
            consider(pol.tolist())
        # intensify around best
        if best:
            t_end = min(deadline - 1, time.time() + 1.5)
            pol, ps = _hill(best, t_end, rng)
            consider(pol.tolist())

    if best is None:
        best = [0, 1, 3, 7, 12]

    # final polish
    t_end = deadline
    pol, ps = _hill(best, t_end, rng)
    consider(pol.tolist())

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
