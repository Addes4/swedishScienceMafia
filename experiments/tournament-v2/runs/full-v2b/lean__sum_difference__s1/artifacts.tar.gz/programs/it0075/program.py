# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    # flattened pairwise arrays then unique
    d = a[:, None] - a[None, :]
    s = a[:, None] + a[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def _greedy_sidon(n, rng, span_hint):
    """Randomized greedy: pick smallest new elements keeping span moderate,
    favouring new differences."""
    a = [0]
    have = {0}
    maxc = max(1, span_hint)
    tries = 0
    while len(a) < n and tries < n * 200:
        tries += 1
        base = a[rng.randrange(len(a))]
        d = rng.randint(1, maxc)
        x = base + (d if rng.random() < 0.5 else -d)
        if x in have:
            continue
        a.append(x)
        have.add(x)
    return a


def _refine_bits(a, deadline, rng):
    """Incremental hill-climb using Python sets of diffs/sums."""
    cur = sorted(set(int(x) for x in a))
    if len(cur) < 2:
        return cur, -1.0
    diffs = set()
    sums = set()
    for i in range(len(cur)):
        for j in range(len(cur)):
            diffs.add(cur[i] - cur[j])
            sums.add(cur[i] + cur[j])
    cs = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(cur)) / 100
    span = max(1, cur[-1] - cur[0])
    while time.time() < deadline:
        i = rng.randrange(len(cur))
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        old = cur[i]
        new = old + delta
        if new in cur:
            continue
        # compute new diff/sum sets incrementally
        nd = set(diffs)
        ns_ = set(sums)
        # remove contributions involving old
        rem_d = set()
        rem_s = set()
        for j in range(len(cur)):
            if j == i:
                continue
            oj = cur[j]
            rem_d.add(old - oj)
            rem_d.add(oj - old)
            rem_s.add(old + oj)
        # careful: build candidate fresh since removing may over-remove shared vals
        cand = cur[:]
        cand[i] = new
        cand.sort()
        cd = set()
        cs2 = set()
        for p in range(len(cand)):
            for q in range(len(cand)):
                cd.add(cand[p] - cand[q])
                cs2.add(cand[q] + cand[p])
        if len(cs2) < 2:
            continue
        ns = math.log(len(cd)) / math.log(len(cs2)) + (1 - 1 / len(cand)) / 100
        if ns >= cs:
            cur = cand
            diffs = cd
            sums = cs2
            cs = ns
            span = max(1, cur[-1] - cur[0])
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(246813579)
    best = None
    best_score = -1.0

    sizes = list(range(8, 26)) + [30, 36, 44, 55]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 14:
        n = sizes[idx % len(sizes)]
        idx += 1
        span_hint = max(4, int(n * (n - 1) / 2 * rng.uniform(0.4, 1.4)))
        a = _greedy_sidon(n, rng, span_hint)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 14, time.time() + 0.8)
        pol, ps = _refine_bits(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _refine_bits(cur, t_end, rng)
        if cs > cur_score:
            cur = cand
            cur_score = cs
        else:
            arr = sorted(set(cur))
            if arr:
                arr = list(arr)
                for _ in range(rng.randint(1, max(1, len(arr) // 8))):
                    j = rng.randrange(len(arr))
                    arr[j] += rng.randint(-40, 40)
                arr = sorted(set(arr))
                cur = arr
                cur_score, _, _ = _eval(np.array(arr, dtype=np.int64))

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
