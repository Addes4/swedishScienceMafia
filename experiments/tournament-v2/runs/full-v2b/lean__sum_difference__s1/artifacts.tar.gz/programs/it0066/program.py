# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A| via Sidon construction + incremental hill-climb."""
import math
import random
import time


def _score_from_counts(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _sets_of(a):
    n = len(a)
    ds = set()
    ss = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            ds.add(ai - a[j])
            ss.add(ai + a[j])
    return ds, ss


def _eval(a):
    nd = len(set(x - y for x in a for y in a))
    ns = len(set(x + y for x in a for y in a))
    return _score_from_counts(nd, ns, len(a)), nd, ns


def _sidon(n, rng):
    """Greedy B_2 set: each new element introduces all-new differences."""
    a = [0]
    diffs = {0}
    trials = 0
    cand = 1
    while len(a) < n and trials < 200000:
        x = cand
        cand += 1
        trials += 1
        ok = True
        newd = []
        for y in a:
            d1 = x - y
            d2 = y - x
            if d1 in diffs or d2 in diffs:
                ok = False
                break
            newd.append(d1)
            newd.append(d2)
        if ok:
            a.append(x)
            diffs.add(x - x)
            for d in newd:
                diffs.add(d)
    return sorted(a)


def _hill(a, deadline, rng):
    """Incremental hill-climb moving single elements; maximize true score."""
    cur = sorted(set(int(x) for x in a))
    if len(cur) < 2:
        return cur, -1.0
    curset = set(cur)
    ds, ss = _sets_of(cur)
    nd, ns = len(ds), len(ss)
    cs = _score_from_counts(nd, ns, len(cur))
    span = max(1, cur[-1] - cur[0])
    n = len(cur)
    while time.time() < deadline:
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 16]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        old = cur[i]
        new = old + delta
        if new in curset:
            continue
        # tentatively remove old, add new
        cur[i] = new
        ds2, ss2 = _sets_of(cur)
        nd2, ns2 = len(ds2), len(ss2)
        s2 = _score_from_counts(nd2, ns2, n)
        if s2 >= cs:
            curset.discard(old)
            curset.add(new)
            ds, ss = ds2, ss2
            nd, ns = nd2, ns2
            cs = s2
        else:
            cur[i] = old
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240917)
    best = None
    best_score = -1.0

    # Try a range of sizes; larger gives the |A-A| ~ n^2 with A+A ~ smaller.
    sizes = list(range(10, 46)) + [50, 55, 60, 70, 80]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 20:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _sidon(n, rng)
        if len(a) < 2:
            continue
        s, _, _ = _eval(a)
        if s > best_score:
            best_score = s
            best = a[:]
        t_end = min(deadline - 20, time.time() + 0.6)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score, best = ps, pol
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand
            cur_score = cs
        else:
            arr = cur[:]
            k = max(1, len(arr) // 8)
            for _ in range(rng.randint(1, k)):
                j = rng.randrange(len(arr))
                arr[j] += rng.randint(-30, 30)
            arr = sorted(set(arr))
            cur = arr
            cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
