# EVOLVE-BLOCK-START
"""Time-bounded search maximizing log|A-A|/log|A+A| for integer sets A."""
import math
import random
import time

import numpy as np


def _stats(a):
    """Return (score, |A-A|, |A+A|) for a 1-D integer numpy array with distinct entries."""
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100.0, d, s


def _stats_sets(a):
    """Return (diffs set, sums set) as python sets."""
    if a.size == 0:
        return set(), set()
    return set(np.unique(a[:, None] - a[None, :]).tolist()), set(
        np.unique(a[:, None] + a[None, :]).tolist()
    )


# ---------- seed families ----------

def _geom_seed(n, rng):
    """Near-geometric / low-sum structured seed."""
    base = []
    x = 0
    r = rng.choice([2, 3, 4])
    for _ in range(n):
        base.append(x)
        x = x * r + rng.randint(1, 3)
    return base


def _golomb_like(n, rng, span):
    """Greedy Sidon/Golomb-like set: add smallest candidate that introduces few new sums."""
    a = [0]
    used_sums = {0}
    cand = 1
    while len(a) < n and cand < span:
        news = 0
        ok = True
        for y in a:
            s = cand + y
            if s not in used_sums:
                news += 1
        # prefer small increases in sum count
        if news <= max(1, len(a) // 2):
            for y in a:
                used_sums.add(cand + y)
            used_sums.add(cand + cand)
            a.append(cand)
        cand += 1
    return a


def _random_seed(n, rng, span):
    vals = rng.sample(range(span), min(n, span))
    return sorted(vals)


# ---------- greedy growth ----------

def _grow_greedy(n, rng, seed=None, w=3.0, sample=400):
    a = [0] if not seed else list(seed)
    while len(a) < n:
        cur = np.array(a, dtype=np.int64)
        curd, curs = _stats_sets(cur)
        cands = set()
        for base in a:
            for dd in range(1, 40):
                cands.add(base + dd)
                cands.add(base - dd)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:sample]
        best_x, best_val = None, None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - w * news
            if best_val is None or val > best_val:
                best_val, best_x = val, x
        if best_x is None:
            break
        a.append(best_x)
    return sorted(set(a))


# ---------- local search ----------

def _hill_climb(a, deadline, rng):
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur.tolist(), -1.0
    cs, _, _ = _stats(cur)
    order = np.argsort(cur)
    cur = cur[order]
    span = max(1, int(cur.max() - cur.min()))
    step = max(1, span // 6)
    start = time.time()
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        center = int(cur[i])
        best = None
        moves = [center + rng.randint(-step, step) for _ in range(8)]
        if rng.random() < 0.3:
            moves.append(center + rng.choice([-1, 1]) * span)
        for nx in moves:
            if nx == center:
                continue
            cand = cur.copy()
            cand[i] = nx
            if np.unique(cand).size != cand.size:
                continue
            cand = np.sort(cand)
            ns, _, _ = _stats(cand)
            if best is None or ns > best[0]:
                best = (ns, cand)
        if best is None:
            step = max(1, step - 1)
            continue
        if best[0] > cs:
            cur = best[1]
            cs = best[0]
        else:
            if rng.random() < 0.02:
                # occasional uphill jitter to escape plateaus
                cur = best[1]
                cs = best[0]
        if time.time() - start > 2.0:
            # periodically re-tune step
            span = max(1, int(cur.max() - cur.min()))
            step = max(1, span // rng.choice([4, 6, 10]))
            start = time.time()
    return cur.tolist(), cs


def solve():
    deadline = time.time() + 112.0
    rng = random.Random(20240817)

    best = [0, 1, 3, 7, 12, 20]
    best_score = _stats(np.array(best, dtype=np.int64))[0]

    sizes = list(range(8, 42)) + [45, 50, 55, 60, 70, 80, 100]
    random.shuffle(sizes)

    # Phase 1: build and improve seeds
    phase1_end = time.time() + 75.0
    idx = 0
    while time.time() < phase1_end:
        n = sizes[idx % len(sizes)]
        idx += 1
        mode = idx % 3
        if mode == 0:
            seed = _geom_seed(n, rng)
        elif mode == 1:
            seed = _random_seed(n, rng, max(n * 4, 50))
        else:
            seed = _golomb_like(n, rng, max(n * 8, 120))
        a = _grow_greedy(n, rng, seed=seed[: max(2, n // 4)], w=rng.choice([2.0, 3.0, 4.0]))
        if len(a) < 2:
            continue
        s = _stats(np.array(a, dtype=np.int64))[0]
        if s > best_score:
            best_score, best = s, a[:]
        # short hill-climb
        t_end = min(phase1_end, time.time() + 0.7)
        cand, cs = _hill_climb(a, t_end, rng)
        if cs > best_score:
            best_score, best = cs, cand[:]
        if idx % len(sizes) == 0:
            random.shuffle(sizes)
            # seed best into an alternate geometric family occasionally
            gb = _geom_seed(len(best), rng)
            gbs = _stats(np.array(gb, dtype=np.int64))[0]
            if gbs > best_score:
                best_score, best = gbs, gb

    # Phase 2: polish best with repeated hill-climb / restarts
    cur, cur_score = best[:], best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 5.0)
        cand, cs = _hill_climb(cur, t_end, rng)
        if cs > cur_score:
            cur, cur_score = cand, cs
        else:
            # perturb to escape local optimum
            arr = np.array(sorted(set(int(x) for x in cur)), dtype=np.int64)
            if arr.size >= 2:
                k = max(1, arr.size // 5)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-max(2, arr.ptp() // 10), max(2, arr.ptp() // 10))
                arr = np.unique(arr)
                if arr.size >= 2:
                    cur_score = _stats(arr)[0]
                    cur = arr.tolist()
    if cur_score > best_score:
        best = cur

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
