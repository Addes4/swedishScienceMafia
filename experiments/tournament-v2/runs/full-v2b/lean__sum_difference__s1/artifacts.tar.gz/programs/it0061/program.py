# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time


def _eval(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    d = len(set(x - y for x in a for y in a))
    s = len(set(x + y for x in a for y in a))
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _greedy_sidon(n, rng):
    """Greedy B_2 (Sidon) set on a short interval."""
    a = [0]
    used = {0}
    diffs = {0}
    sums = {0}
    limit = 4 * n * n + 10
    x = 1
    while len(a) < n and x <= limit:
        ok = True
        nd = set()
        ns = set()
        for y in a:
            d1 = x - y
            d2 = y - x
            if d1 in diffs or d2 in diffs:
                ok = False
                break
            nd.add(d1)
            nd.add(d2)
            s1 = x + y
            ns.add(s1)
        if ok:
            a.append(x)
            diffs |= nd
            sums |= ns
        x += 1
    return a


def _incr_move(a, cd, cs, i, newval):
    """Try moving a[i] to newval; return (delta_score_ok, new cd, cs)."""
    n = len(a)
    old = a[i]
    # counts to decrement: pairs involving i
    # simplicity: recompute contribution of i by subtract then test
    diffs_list = []
    sums_list = []
    for j in range(n):
        if j == i:
            continue
        diffs_list.append(old - a[j])
        diffs_list.append(a[j] - old)
        sums_list.append(old + a[j])
    # temporarily remove
    for v in diffs_list:
        cd[v] -= 1
    for v in sums_list:
        cs[v] -= 1
    cd[old - old] -= 1
    cs[old + old] -= 1
    a[i] = newval
    newdiffs = []
    newsums = []
    for j in range(n):
        if j == i:
            continue
        newdiffs.append(newval - a[j])
        newdiffs.append(a[j] - newval)
        newsums.append(newval + a[j])
    newdiffs.append(newval - newval)
    newsums.append(newval + newval)
    # add
    for v in newdiffs:
        cd[v] = cd.get(v, 0) + 1
    for v in newsums:
        cs[v] = cs.get(v, 0) + 1
    return diffs_list, sums_list, newdiffs, newsums


def _count_nonzero(d):
    cnt = 0
    for v in d.values():
        if v:
            cnt += 1
    return cnt


def _hill(a, deadline, rng):
    a = sorted(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return a, -1.0
    cd = {}
    cs = {}
    for x in a:
        for y in a:
            cd[x - y] = cd.get(x - y, 0) + 1
            cs[x + y] = cs.get(x + y, 0) + 1
    nd = _count_nonzero(cd)
    ns = _count_nonzero(cs)
    if ns < 2:
        return a, -1.0
    cur = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    span = max(1, a[-1] - a[0])
    while time.time() < deadline:
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        newval = a[i] + delta
        if newval in a:
            continue
        diffs_list, sums_list, newdiffs, newsums = _incr_move(a, cd, cs, i, newval)
        newnd = _count_nonzero(cd)
        newns = _count_nonzero(cs)
        if newns >= 2:
            nsc = math.log(newnd) / math.log(newns) + (1 - 1 / n) / 100
        else:
            nsc = -1.0
        if nsc >= cur:
            a = sorted(a)
            cur = nsc
            nd = newnd
            ns = newns
        else:
            # revert
            a[i] = newval  # currently newval; fix by reverting
            for v in newsums:
                cs[v] -= 1
            for v in cd and newdiffs:
                pass
            # manual revert
            for v in newdiffs:
                cd[v] -= 1
            for v in newsums:
                cs[v] += 1
            # re-add old
            for v in diffs_list:
                cd[v] = cd.get(v, 0) + 1
            for v in sums_list:
                cs[v] = cs.get(v, 0) + 1
            cd[a[i] - a[i]] = cd.get(a[i] - a[i], 0) + 1
            cs[a[i] + a[i]] = cs.get(a[i] + a[i], 0) + 1
            a[i] = newval - delta
            cd[a[i] - a[i]] -= 1
            cs[a[i] + a[i]] -= 1
    return a, cur


def _hill2(a, deadline, rng):
    """Simple correct hill-climb with full recompute fallback."""
    a = sorted(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return a, -1.0
    cur, _, _ = _eval(a)
    span = max(1, a[-1] - a[0])
    while time.time() < deadline:
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        cand = a[:]
        cand[i] += delta
        if len(set(cand)) != len(cand):
            continue
        cand.sort()
        ns, _, _ = _eval(cand)
        if ns >= cur:
            a = cand
            cur = ns
            span = max(1, a[-1] - a[0])
    return a, cur


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240607)
    best = None
    best_score = -1.0

    # seed with greedy Sidon sets of various sizes
    for n in list(range(8, 60)) + [70, 90, 120]:
        if time.time() > deadline - 40:
            break
        a = _greedy_sidon(n, rng)
        if len(a) < 2:
            continue
        s, _, _ = _eval(a)
        if s > best_score:
            best_score = s
            best = sorted(set(a))

    if best is None:
        best = [0, 1, 3, 7, 12]
        best_score, _, _ = _eval(best)

    # refine best with hill-climb
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 2.5)
        cand, cs = _hill2(cur, t_end, rng)
        if cs > cur_score:
            cur = cand
            cur_score = cs
            if cs > best_score:
                best_score = cs
                best = cand[:]
        else:
            # random dilation / perturbation of best to escape
            arr = sorted(best)
            scale = rng.choice([1, 1, 2, 3])
            arr = [v * scale for v in arr]
            k = max(1, len(arr) // 6)
            for _ in range(rng.randint(1, k)):
                j = rng.randrange(len(arr))
                arr[j] += rng.randint(-40, 40)
            arr = sorted(set(arr))
            if len(arr) >= 2:
                cur = arr
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
