# EVOLVE-BLOCK-START
"""Structured construction: sidon-like modular sets maximizing |A-A|/|A+A|."""
import math
import random
import time


def _diffs_sums(a):
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return diffs, sums


def _score(a):
    a = sorted(set(a))
    if len(a) < 2:
        return 0.0, 0
    diffs, sums = _diffs_sums(a)
    if len(sums) < 2:
        return 0.0, 0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100, len(diffs)


def _eval(a):
    s, _ = _score(a)
    return s


def _parabola_set(n, B):
    """A = { i + B*i^2 : i in range(n) } — distinct differences often, sums collide.
    B large keeps integers distinct and differences structured."""
    return [i + B * i * i for i in range(n)]


def _mod_parabola(n, p, scale=1, shift=0):
    """Take parabola points mod p, lift small representatives. Combined with linear
    part so that the difference multiset is rich while sums wrap and collide."""
    A = set()
    for i in range(n):
        A.add(scale * ((i * i) % p) + i)
    return sorted(A)


def _greedy_sidon_diff(n, limit=40):
    """Greedily add elements to make differences as distinct as possible while
    reusing sums: prefer elements whose new differences are mostly new and whose
    new sums are mostly already present."""
    a = [0]
    used = {0}
    while len(a) < n:
        best_x = None
        best_val = -1e18
        cands = []
        for base in a:
            for d in range(1, limit):
                cands.append(base + d)
                cands.append(base - d)
        cands = [x for x in set(cands) if x not in used]
        random.shuffle(cands)
        cands = cands[:600]
        dset = set()
        sset = set()
        for i in range(len(a)):
            for j in range(len(a)):
                dset.add(a[i] - a[j])
                sset.add(a[i] + a[j])
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in dset:
                    newd += 1
                if (x + y) not in sset:
                    news += 1
            val = newd - 2.0 * news
            if val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
        used.add(best_x)
    return a


def _polish(a, deadline, iters=100000):
    cur = sorted(set(a))
    cs = _eval(cur)
    best = cur[:]
    bs = cs
    step = 1
    while time.time() < deadline:
        for _ in range(iters):
            if time.time() >= deadline:
                break
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.choice([-step, step, -1, 1, -step * 2, step * 2])
            if len(set(cand)) != len(cand):
                continue
            s = _eval(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > bs:
                    best, bs = cand[:], s
            elif random.random() < 0.002:
                cur, cs = cand, s
        step = max(1, step // 2)
        if step == 1:
            step = 1
    return best, bs


def solve():
    deadline = time.time() + 108
    candidates = []

    # parabola-style families with various bases/scales
    for B in [1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610]:
        for n in [8, 12, 16, 20, 24, 30, 40]:
            candidates.append(_parabola_set(n, B))

    # mod-parabola lifts
    for p in [61, 127, 251, 509, 1021, 2039]:
        for n in [10, 16, 24, 32]:
            if n <= p:
                candidates.append(_mod_parabola(n, p, scale=1000, shift=0))
                candidates.append(_mod_parabola(n, p, scale=1))

    # greedy sidon-ish
    for n in [10, 16, 22, 30, 40]:
        candidates.append(_greedy_sidon_diff(n))

    best = None
    bs = -1
    for c in candidates:
        s = _eval(c)
        if s > bs:
            bs = s
            best = c[:]

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    # polish best candidate and a couple runners-up
    ranked = sorted(candidates, key=lambda c: _eval(c), reverse=True)[:3]
    for c in ranked:
        if time.time() >= deadline:
            break
        sub = time.time() + (deadline - time.time()) / max(1, len(ranked))
        b, s = _polish(c, sub)
        if s > bs:
            bs = s
            best = b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
