# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A| via bitset SA hill-climb."""
import math
import random
import time


def _eval(a):
    """Score of integer list a. Returns (score, ndiff, nsum)."""
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    d = len(diffs)
    s = len(sums)
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _bitsets(a):
    """Return (diff_set_bitmask, sum_set_bitmask, offd, offs) as big ints.

    diff bit k corresponds to value (k - offd); sum bit k to (k - offs)."""
    n = len(a)
    lo_d = min(a) - max(a)
    hi_d = max(a) - min(a)
    offd = lo_d
    width_d = hi_d - lo_d + 1
    lo_s = min(a) + min(a)
    hi_s = max(a) + max(a)
    offs = lo_s
    width_s = hi_s - lo_s + 1

    d = 0
    s = 0
    for i in range(n):
        ai = a[i]
        for j in range(n):
            d |= 1 << (ai - a[j] - offd)
            s |= 1 << (ai + a[j] - offs)
    return d, s, offd, offs, width_d, width_s


def _count(bits):
    return bin(bits).count("1")


def _grow(n, rng):
    """Greedy near-Sidon: build a minimizing new sums, maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = list(a)
        curd = set()
        curs = set()
        for x in cur:
            for y in cur:
                curd.add(x - y)
                curs.add(x + y)
        cands = set()
        for base in cur:
            for d in range(1, 40):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(cur)]
        rng.shuffle(cands)
        cands = cands[:400]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in cur:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _hill(a, deadline, rng):
    """Simulated annealing moving single elements, using bitset counts."""
    cur = sorted(set(int(x) for x in a))
    if len(cur) < 2:
        return cur, -1.0
    d, s, offd, offs, wd, ws = _bitsets(cur)
    nd = _count(d)
    ns = _count(s)
    n = len(cur)
    cs = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100 if ns >= 2 else -1.0
    span = max(1, max(cur) - min(cur))
    temp = 0.02
    it = 0
    while time.time() < deadline:
        it += 1
        if it % 2000 == 0:
            temp *= 0.97
            if temp < 1e-4:
                temp = 1e-4
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        old = cur[i]
        new = old + delta

        # incremental update of bitsets: remove old contributions, add new
        # build local contribution mask for old and new
        # for diff: pairs (old - y) and (y - old) for all y; likewise new
        # Use temporary counts of overlaps by removing then re-adding.
        # We do full remove/add with popcount check via small dict of counts.
        # Simpler: recompute only the affected bit positions.
        # diff values containing old: old - y and y - old for y in cur (incl old->0)
        # To know if a bit is uniquely from old, count occurrences.
        dd = d
        ss = s
        # counts of each value in diff/sum from current set (excluding contribution we track)
        # Instead track per-value multiplicity lazily for the two modified elements.
        # Remove old: for each y, decrement count of (old-y) and (y-old)
        # We need multiplicities -> recompute multiplicity dict for old only is hard.
        # Use a lightweight approach: temporarily build sets excluding old and including new is O(n).
        # That defeats bitset speed but n is small; bitsets still help counting.
        # Build new full bitsets by clearing old bits that won't reappear.
        pass
        # Fallback: rebuild bitsets fully (n is small).
        cand = cur[:]
        cand[i] = new
        if len(set(cand)) != n:
            continue
        cand.sort()
        # rebuild bitsets from scratch
        d2, s2, o2, s2o, w2, w2s = _bitsets(cand)
        nd2 = _count(d2)
        ns2 = _count(s2)
        if ns2 < 2:
            continue
        cs2 = math.log(nd2) / math.log(ns2) + (1 - 1 / n) / 100
        if cs2 >= cs or rng.random() < math.exp((cs2 - cs) / temp):
            cur = cand
            d, s, offd, offs, wd, ws = d2, s2, o2, s2o, w2, w2s
            nd, ns, cs = nd2, ns2, cs2
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240607)
    best = None
    best_score = -1.0

    sizes = list(range(8, 32)) + [36, 42, 50]
    idx = 0

    while time.time() < deadline - 14:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        arr = sorted(set(int(x) for x in a))
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr
        t_end = min(deadline - 14, time.time() + 0.5)
        pol, ps = _hill(arr, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol
        if idx % (3 * len(sizes)) == 0:
            rng.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand
            cur_score = cs
        else:
            arr = list(cur)
            if arr:
                k = max(1, len(arr) // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(len(arr))
                    arr[j] += rng.randint(-40, 40)
                arr = sorted(set(arr))
                cur = arr
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
