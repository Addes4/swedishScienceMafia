# EVOLVE-BLOCK-START
"""Beam search maximizing log|A-A|/log|A+A| with fast incremental evaluation."""
import math
import random
import time


def _eval(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    nd = len(diffs)
    ns = len(sums)
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def _incremental_extend(a, x):
    """Return (newd, news) added by appending x to a."""
    newd = 0
    news = 0
    for y in a:
        d1 = x - y
        d2 = y - x
        s = x + y
        # need membership tests; caller maintains sets
        if d1 not in _D:
            newd += 1
        if d2 not in _D:
            newd += 1
        if s not in _S:
            news += 1
    # self pair handled separately
    return newd, news


def _grow_beam(n, beam_width, cand_per, base_used):
    """Grow sets to size n via beam search; returns best (score, list)."""
    global _D, _S
    # start from seed sets
    beams = []
    for seed in base_used:
        a = list(seed)
        a = sorted(set(a))
        if len(a) < 2:
            continue
        d = set()
        s = set()
        for i in range(len(a)):
            for j in range(len(a)):
                d.add(a[i] - a[j])
                s.add(a[i] + a[j])
        beams.append((a, d, s))

    while True:
        # check if all beams reached n or no candidates
        grown = []
        any_alive = False
        for a, d, s in beams:
            if len(a) >= n:
                grown.append((a, d, s))
                continue
            any_alive = True
            # generate candidate next elements
            maxe = max(a)
            mine = min(a)
            cands = set()
            for base in a:
                for step in range(1, 50):
                    cands.add(base + step)
                    cands.add(base - step)
            cands -= set(a)
            if len(cands) > 300:
                cands = set(random.sample(list(cands), 300))
            scored = []
            for x in cands:
                newd = 0
                news = 0
                for y in a:
                    if (x - y) not in d:
                        newd += 1
                    if (y - x) not in d:
                        newd += 1
                    if (x + y) not in s:
                        news += 1
                if (x - x) not in d:
                    newd += 1
                if (x + x) not in s:
                    news += 1
                scored.append((newd - 3.0 * news, newd, news, x))
            scored.sort(reverse=True)
            top = scored[:cand_per]
            random.shuffle(top)
            top = top[:cand_per]
            for _, _, _, x in top:
                na = a + [x]
                nd = set(d)
                ns = set(s)
                for y in a:
                    nd.add(x - y)
                    nd.add(y - x)
                    ns.add(x + y)
                nd.add(0)
                ns.add(x + x)
                grown.append((na, nd, ns))
        if not any_alive and all(len(g[0]) >= n for g in grown):
            # pick best final
            best = None
            bs = -1
            for a, d, s in grown:
                if len(a) < 2:
                    continue
                sc = _score_from_sizes(len(a), len(d), len(s))
                if sc > bs:
                    bs = sc
                    best = a
            return best, bs
        # prune beam
        pruned = {}
        for a, d, s in grown:
            key = len(a)
            sc = _score_from_sizes(len(a), len(d), len(s))
            if key not in pruned or sc > pruned[key][0]:
                pruned[key] = (sc, a, d, s)
        # keep beam_width per size level
        levels = {}
        for a, d, s in grown:
            levels.setdefault(len(a), []).append((a, d, s))
        new_beams = []
        for lvl, items in levels.items():
            scored = []
            for a, d, s in items:
                sc = _score_from_sizes(len(a), len(d), len(s))
                scored.append((sc, a, d, s))
            scored.sort(key=lambda t: t[0], reverse=True)
            for sc, a, d, s in scored[:beam_width]:
                new_beams.append((a, d, s))
        beams = new_beams
        if not beams:
            return None, -1


def _score_from_sizes(n, nd, ns):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def solve():
    """Maximise log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best = None
    best_score = -1

    # seed sets
    seeds = [
        [0],
        [0, 1],
        [0, 1, 3],
        [-1, 0, 1],
    ]

    ns_to_try = [12, 16, 20, 25, 30, 40, 50, 70, 100, 150, 200, 300, 500, 800, 1200, 2000]
    random.shuffle(ns_to_try)
    for n in ns_to_try:
        if time.time() > deadline:
            break
        try:
            cand, sc = _grow_beam(n, beam_width=6, cand_per=6, base_used=seeds)
        except Exception:
            cand, sc = None, -1
        if cand is not None and sc > best_score:
            best_score = sc
            best = cand[:]
            seeds = [[0], [0, 1], [0, 1, 3], cand[:]]

    # local refine
    if best is not None:
        cur = best[:]
        cur_s = _eval(cur)[0]
        t_end = time.time() + 8
        while time.time() < t_end:
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2, 7, -7])
            if len(set(cand)) != len(cand):
                continue
            s = _eval(cand)[0]
            if s >= cur_s:
                cur, cur_s = cand, s
        if cur_s > best_score:
            best_score = cur_s
            best = cur

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return best
# EVOLVE-BLOCK-END
