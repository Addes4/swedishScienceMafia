# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time


def _sums_diffs(a):
    """Return (set of sums, set of diffs) for list a."""
    s = set()
    d = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            s.add(ai + a[j])
    for i in range(n):
        ai = a[i]
        for j in range(n):
            d.add(ai - a[j])
    return s, d


def _score_from(nsum, ndiff, n):
    if nsum < 2 or n < 2:
        return 0.0
    return math.log(ndiff) / math.log(nsum) + (1 - 1 / n) / 100


def _greedy_sidon(n, rng):
    """Greedy B_2 (Sidon-like) set on a short interval: maximize new diffs,
    minimize new sums."""
    # Try several random orders / starting offsets
    a = [0]
    aset = {0}
    while len(a) < n:
        cur_s, cur_d = _sums_diffs(a)
        # candidate positions near current span
        lo = min(a)
        hi = max(a)
        span = max(1, hi - lo)
        cands = set()
        for base in a:
            for dd in range(1, span + 3):
                cands.add(base + dd)
                cands.add(base - dd)
        cands = [c for c in cands if c not in aset]
        if not cands:
            break
        rng.shuffle(cands)
        cands = cands[:400]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in cur_d or (y - x) not in cur_d:
                    newd += 1
                if (x + y) not in cur_s:
                    news += 1
            # strongly prefer new diffs, penalize new sums
            val = newd - 3.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
        aset.add(best_x)
    return sorted(a)


def _incremental_count(a, i, newval, sums, diffs, cnt_s, cnt_d):
    """Compute delta in unique sum/diff counts when a[i] -> newval.
    Returns (ds, dd) new unique counts (approx via recount of affected)."""
    # We just recount unique counts fully but efficiently using sets built incrementally.
    # For correctness and speed, do a full recount with sets.
    b = list(a)
    b[i] = newval
    s = set()
    d = set()
    n = len(b)
    for p in range(n):
        bp = b[p]
        for q in range(p, n):
            s.add(bp + b[q])
    for p in range(n):
        bp = b[p]
        for q in range(n):
            d.add(bp - b[q])
    return len(s), len(d)


def _hill(a, deadline, rng):
    """Fast hill-climb on single-element moves using true incremental score."""
    cur = sorted(set(int(x) for x in a))
    if len(cur) < 2:
        return cur, -1.0
    s, d = _sums_diffs(cur)
    cs = _score_from(len(s), len(d), len(cur))
    span = max(1, max(cur) - min(cur))
    n = len(cur)
    while time.time() < deadline:
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        old = cur[i]
        nv = old + delta
        if nv in set(cur[:i] + cur[i + 1:]):
            continue
        cand = cur[:]
        cand[i] = nv
        cand.sort()
        ns, nd = _sums_diffs(cand)
        nsc = _score_from(len(ns), len(nd), n)
        if nsc >= cs:
            cur = cand
            s, d = ns, nd
            cs = nsc
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(12, 26)) + [30, 35, 40, 50]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 15:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _greedy_sidon(n, rng)
        if len(a) < 2:
            continue
        s, d = _sums_diffs(a)
        sc = _score_from(len(s), len(d), len(a))
        if sc > best_score:
            best_score = sc
            best = a[:]
        t_end = min(deadline - 15, time.time() + 0.5)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol[:]
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = list(cand)
            cur_score = cs
        else:
            k = max(1, len(cur) // 8)
            for _ in range(rng.randint(1, k)):
                j = rng.randrange(len(cur))
                cur[j] += rng.randint(-25, 25)
            cur = sorted(set(int(x) for x in cur))
            s, d = _sums_diffs(cur)
            cur_score = _score_from(len(s), len(d), len(cur))

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
