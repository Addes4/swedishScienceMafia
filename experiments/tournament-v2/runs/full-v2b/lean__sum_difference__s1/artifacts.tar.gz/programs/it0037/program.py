# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval_list(a):
    """Score of a python list of distinct ints. Returns (score, ndiff, nsum)."""
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    arr = np.array(a, dtype=np.int64)
    d = np.unique(arr[:, None] - arr[None, :]).size
    s = np.unique(arr[:, None] + arr[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _diffs_sums(a):
    arr = np.array(a, dtype=np.int64)
    d = np.unique(arr[:, None] - arr[None, :]).size
    s = np.unique(arr[:, None] + arr[None, :]).size
    return d, s


def _score_from(d, s, n):
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _grow(n, rng, span):
    """Greedy: build a by minimizing new sums while maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        curd = set()
        curs = set()
        for x in a:
            for y in a:
                curd.add(x - y)
                curs.add(x + y)
        base_min = min(a)
        base_max = max(a)
        cands = set()
        for b in a:
            for d in range(1, 12):
                if base_min - span <= b + d <= base_max + span:
                    cands.add(b + d)
                if base_min - span <= b - d <= base_max + span:
                    cands.add(b - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 1.5 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _climb(a, deadline, rng):
    """Steepest-ascent single-element move maximizing true score."""
    cur = sorted(set(int(x) for x in a))
    if len(cur) < 2:
        return cur, -1.0
    n = len(cur)
    cd, cs = _diffs_sums(cur)
    cs_score = _score_from(cd, cs, n)
    span = max(2, (cur[-1] - cur[0]) // 2)
    arr = np.array(cur, dtype=np.int64)
    while time.time() < deadline:
        i = rng.randrange(n)
        best_delta = 0
        best_move = None
        best_val = cs_score
        # scan several candidate deltas around element i
        tried = set()
        mags = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, span]
        for _ in range(14):
            step = rng.choice(mags)
            delta = rng.randint(-step, step)
            if delta == 0 or delta in tried:
                continue
            tried.add(delta)
            cand = cur[:]
            cand[i] += delta
            cand.sort()
            # quick duplicate check
            dup = False
            for k in range(1, n):
                if cand[k] == cand[k - 1]:
                    dup = True
                    break
            if dup:
                continue
            nd, ns = _diffs_sums(cand)
            val = _score_from(nd, ns, n)
            if val > best_val + 1e-12 or (best_move is None and val >= best_val):
                best_val = val
                best_move = cand
        if best_move is not None and best_val >= cs_score:
            cur = best_move
            cs_score = best_val
    return cur, cs_score


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(6, 22)) + [25, 30, 40]
    spans = [8, 12, 16, 24, 32, 48, 64, 96, 128]
    idx = 0

    while time.time() < deadline - 10:
        n = sizes[idx % len(sizes)]
        span = spans[(idx // len(sizes)) % len(spans)]
        idx += 1
        a = _grow(n, rng, span)
        arr = sorted(set(a))
        if len(arr) < 2:
            continue
        s, _, _ = _eval_list(arr)
        if s > best_score:
            best_score = s
            best = arr
        t_end = min(deadline - 10, time.time() + 0.5)
        pol, ps = _climb(arr, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol
        if idx % (3 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _climb(cur, t_end, rng)
        if cs > cur_score:
            cur = cand
            cur_score = cs
        else:
            # perturb to escape local optimum
            k = max(1, len(cur) // 6)
            arr = cur[:]
            for _ in range(rng.randint(1, k)):
                j = rng.randrange(len(arr))
                arr[j] += rng.randint(-20, 20)
            arr = sorted(set(arr))
            if len(arr) >= 2:
                cur = arr
                cur_score, _, _ = _eval_list(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END

