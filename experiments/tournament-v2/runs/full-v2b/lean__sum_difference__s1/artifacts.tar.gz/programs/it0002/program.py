# EVOLVE-BLOCK-START
"""Greedy construction maximizing |A-A|/|A+A| ratio, with local-search polish."""
import math
import random
import time


def _diffs_sums(a):
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return diffs, sums


def _score(a):
    if len(a) < 2:
        return 0.0
    diffs, sums = _diffs_sums(a)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _greedy(n):
    """Greedy: add elements maximizing new differences minus penalty for new sums."""
    a = [0]
    used = {0}
    while len(a) < n:
        best_x = None
        best_val = None
        # candidate offsets
        cands = []
        for base in a:
            for d in range(1, 40):
                cands.append(base + d)
                cands.append(base - d)
        cands = list(set(cands) - used)
        random.shuffle(cands)
        cands = cands[:400]
        for x in cands:
            nd = 0
            ns = 0
            for y in a:
                if (x - y) not in set():
                    pass
            # count new diffs / sums
            news = 0
            newd = 0
            sset = set()
            dset = set()
            for i in range(len(a)):
                for j in range(len(a)):
                    sset.add(a[i] + a[j])
                    dset.add(a[i] - a[j])
            for y in a:
                if (x - y) not in dset:
                    newd += 1
                if (x + y) not in sset:
                    news += 1
            val = newd - 3.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
        used.add(best_x)
    return a


def _random_restart(n, deadline):
    """Structured random construction, keep best."""
    best = None
    best_score = -1
    while time.time() < deadline:
        # build via greedy on randomized ordering
        a = _greedy(random.randint(4, n))
        if a:
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a[:]
        # local search
        cur = a[:]
        cs = _score(cur)
        t_end = time.time() + 1.0
        while time.time() < t_end:
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.randint(-30, 30)
            if len(set(cand)) != len(cand):
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
            else:
                # attempt adding element
                pass
        if cs > best_score:
            best_score = cs
            best = cur[:]
    return best, best_score


def solve():
    """Maximise log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    best, best_score = _random_restart(20, deadline)
    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    return sorted(set(best))
# EVOLVE-BLOCK-END
