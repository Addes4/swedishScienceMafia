# EVOLVE-BLOCK-START
"""Construct A so |A-A| is near-quadratic while |A+A| is kept small.

Strategy: use a Sidon-like 'digit packing' family.  Let g be a large base.
For a set of exponents E, A = { sum_{e in S} g^e : S subset of E } has the property
that differences are largely distinct (digit representations unique) while sums
re-use carries and hence collide.  We pick g and the exponent budget to reach a
good size n, then polish with a cheap local search.  Several candidate families
are evaluated exactly and the best returned.
"""
import math
import time


def _diff_sum_counts(a):
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _score(a):
    if len(a) < 2:
        return 0.0
    nd, ns = _diff_sum_counts(a)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / len(a)) / 100.0


def _subset_sum_set(exps, base):
    """Return A = all subset sums of base**e for e in exps."""
    a = [0]
    for e in exps:
        w = base ** e
        a = a + [x + w for x in a]
    return a


def _powers_of_two_shifted(k, spread):
    """A = {spread * 2**i} -- all differences distinct, sums collide."""
    return [spread * (1 << i) for i in range(k)]


def _candidate_geometric(k, r, shift):
    return [shift + (r ** i) for i in range(k)]


def solve():
    deadline = time.time() + 108.0
    best = None
    best_score = -1.0

    # Candidate 1: pure powers of two scaled -> all differences distinct.
    for k in range(2, 40):
        if time.time() > deadline:
            break
        a = _powers_of_two_shifted(k, 1)
        s = _score(a)
        if s > best_score:
            best_score, best = s, a

    # Candidate 2: geometric with ratio r>2 (superincreasing) scaled.
    for r in range(3, 12):
        for k in range(2, 30):
            if time.time() > deadline:
                break
            a = _candidate_geometric(k, r, 1)
            s = _score(a)
            if s > best_score:
                best_score, best = s, a

    # Candidate 3: subset sums of powers of base g (digit packing).
    # Choose exponents 0..m-1 -> 2^m elements; too big for large m.  Limit by
    # selecting only some exponents / a bounded n.
    for g in (3, 4, 5, 6, 7, 8, 10, 16, 32, 64):
        for m in range(2, 16):
            if time.time() > deadline:
                break
            a = _subset_sum_set(range(m), g)
            if len(a) > 4000:
                break
            s = _score(a)
            if s > best_score:
                best_score, best = s, a

    # Candidate 4: compressed power set -- powers of a base but scaled so that
    # sums collide.  Try base**e with random large gaps removed.
    for g in (2, 3, 5):
        for m in (8, 10, 11, 12):
            if time.time() > deadline:
                break
            # use only the m highest exponents to keep n manageable while
            # preserving distinctness of differences within the block.
            exps = list(range(m))
            a = _subset_sum_set(exps, g)
            if len(a) > 4000:
                a = sorted(a)[:4000]
            s = _score(a)
            if s > best_score:
                best_score, best = s, a

    # Cheap local search polish on the best candidate.
    if best is not None:
        cur = sorted(set(best))
        cs = _score(cur)
        while time.time() < deadline:
            improved = False
            span = max(1, (max(cur) - min(cur)) // (len(cur) * 8) if len(cur) > 1 else 1)
            for idx in range(len(cur)):
                base = cur[idx]
                for delta in (span, -span, 1, -1, span * 3, -span * 3):
                    cand = cur[:]
                    cand[idx] = base + delta
                    if cand[idx] in cand[:idx] + cand[idx + 1:]:
                        continue
                    s = _score(cand)
                    if s > cs:
                        cur, cs = sorted(cand), s
                        improved = True
                        break
                if improved:
                    break
            if not improved:
                break
        if cs > best_score:
            best_score, best = cs, cur

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    return sorted(set(best))
# EVOLVE-BLOCK-END
