# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A|, using
incremental set-based evaluation so we can afford very many moves."""
import math
import random
import time


def _score(d, s, n):
    if s < 2 or n < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _stats(a):
    da = set()
    sa = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            da.add(ai - a[j])
            sa.add(ai + a[j])
    return len(da), len(sa)


def _grow_sidon(n, rng):
    """Greedy B_2 (Sidon) set: near n^2 differences over a small span."""
    a = [0]
    used = {0}
    diffs = {0}
    limit = 4 * n * n + 50
    for _ in range(n - 1):
        found = None
        # candidate range skewed small
        for x in range(1, limit):
            if x in used:
                continue
            ok = True
            for y in a:
                d = abs(x - y)
                if d in diffs:
                    ok = False
                    break
            if ok:
                found = x
                break
        if found is None:
            break
        for y in a:
            diffs.add(abs(found - y))
        diffs.add(0)
        a.append(found)
        used.add(found)
    return sorted(a)


def _hill(a, deadline, rng, max_step=None):
    a = sorted(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return a, -1.0
    da = {}
    sa = {}
    for x in a:
        for y in a:
            da[x - y] = da.get(x - y, 0) + 1
            sa[x + y] = sa.get(x + y, 0) + 1
    nd, ns = len(da), len(sa)
    cs = _score(nd, ns, n)
    span = max(1, a[-1] - a[0])
    if max_step is None:
        max_step = max(1, span // 3)
    aset = set(a)
    while time.time() < deadline:
        i = rng.randrange(n)
        old = a[i]
        delta = rng.randint(-max_step, max_step)
        if delta == 0:
            continue
        new = old + delta
        if new in aset:
            continue
        # incremental: remove old, add new
        dloss = 0
        sloss = 0
        for y in a:
            if y != old:
                k = old - y
                if da[k] == 1:
                    dloss += 1
                k2 = y - old
                if da[k2] == 1:
                    dloss += 1
                k3 = old + y
                if sa[k3] == 1:
                    sloss += 1
        dgain = 0
        s gain = 0
        for y in a:
            if y != old:
                if (new - y) not in da:
                    dgain += 1
                if (y - new) not in da:
                    dgain += 1
                if (new + y) not in sa:
                    sgain += 1
        newnd = nd - dloss + dgain
        newns = ns - sloss + sgain
        if newns >= 2:
            nsc = _score(newnd, newns, n)
            if nsc >= cs:
                # apply move
                for y in a:
                    if y != old:
                        for k in (old - y, y - old):
                            da[k] -= 1
                            if da[k] == 0:
                                del da[k]
                        k3 = old + y
                        sa[k3] -= 1
                        if sa[k3] == 0:
                            del sa[k3]
                for y in a:
                    if y != old:
                        for k in (new - y, y - new):
                            da[k] = da.get(k, 0) + 1
                        k3 = new + y
                        sa[k3] = sa.get(k3, 0) + 1
                a[i] = new
                aset.discard(old)
                aset.add(new)
                nd, ns, cs = newnd, newns, nsc
        if rng.random() < 1e-9:
            a.sort()
    return sorted(a), cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = [12, 16, 20, 24, 28, 32, 40, 48, 60, 80]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 15:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow_sidon(n, rng)
        if len(a) < 2:
            continue
        nd, ns = _stats(a)
        s = _score(nd, ns, len(a))
        if s > best_score:
            best_score = s
            best = list(a)
        t_end = min(deadline - 15, time.time() + 1.2)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = list(pol)
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = list(cand)
            cur_score = cs
        else:
            # perturb: dilate + shift, or jitter
            m = len(cur)
            if m and rng.random() < 0.5:
                f = rng.choice([1, 2, 3, 5])
                sh = rng.randint(-50, 50)
                cur = [x * f + sh for x in cur]
                cur = sorted(set(cur))
            else:
                arr = list(cur)
                k = max(1, m // 8)
                for _ in range(rng.randint(1, k)):
                    if not arr:
                        break
                    j = rng.randrange(len(arr))
                    arr[j] += rng.randint(-30, 30)
                cur = sorted(set(arr))
            if len(cur) >= 2:
                nd, ns = _stats(cur)
                cur_score = _score(nd, ns, len(cur))
            else:
                cur_score = -1.0

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
