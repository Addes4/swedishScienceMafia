# EVOLVE-BLOCK-START
"""Structured construction + local search for large difference set, small sum set."""
import math
import random
import time


def _sets(a):
    a = list(a)
    n = len(a)
    seen = set()
    diffs = 0
    for i in range(n):
        ai = a[i]
        for j in range(n):
            d = ai - a[j]
            if d not in seen:
                seen.add(d)
                diffs += 1
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            sums.add(ai + a[j])
    return diffs, len(sums)


def _score(a):
    n = len(set(a))
    if n < 2:
        return 0.0
    diffs, sums = _sets(a)
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _base(n, mult):
    """Beatty / Sidon-like base: a_i = i + mult * (i*i mod ...) keeps differences rich."""
    # Use a Sidon set over a large modulus, then embed with a big multiplier.
    vals = []
    mod = 4 * n * n + 1
    for i in range(n):
        vals.append(i + mult * ((i * i) % mod))
    return vals


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # Try several structured starts
    for n in (12, 16, 20, 24, 28, 32, 40):
        for mult in (1, 3, 7, 13, 31):
            a = _base(n, mult)
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a[:]

    # Local search: minimize sum-collisions / maximize differences
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    cur = best[:]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.75 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif op < 0.9:
            cand.append(random.randint(-50, 50))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 60:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur, cur_score = best[:], best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
