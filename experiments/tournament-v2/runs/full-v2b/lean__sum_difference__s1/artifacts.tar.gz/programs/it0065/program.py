# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _grow(n, rng):
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique((cur[:, None] - cur[None, :]).ravel()).tolist())
        curs = set(np.unique((cur[:, None] + cur[None, :]).ravel()).tolist())
        cands = set()
        for base in a:
            for d in range(1, 20):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:400]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _score_arr(a):
    n = a.size
    if n < 2:
        return -1.0
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    if s < 2:
        return -1.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _hill(a, deadline, rng, temp_scale=1.0):
    cur = np.unique(np.asarray(a, dtype=np.int64))
    if cur.size < 2:
        return cur, -1.0
    cs = _score_arr(cur)
    span = max(1, int(cur.max() - cur.min()))
    it = 0
    while time.time() < deadline:
        it += 1
        i = rng.randrange(cur.size)
        step = max(1, span // rng.choice([3, 5, 8, 12, 20, 40]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        cand = cur.copy()
        cand[i] += delta
        cand = np.sort(cand)
        if np.unique(cand).size != cand.size:
            continue
        ns = _score_arr(cand)
        temp = temp_scale * 0.002 / math.sqrt(it)
        if ns >= cs or rng.random() < math.exp((ns - cs) / max(temp, 1e-9)):
            cur = cand
            cs = ns
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(15, 35)) + [38, 42, 46, 50, 56, 64, 72]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 25:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        arr = np.unique(np.array(sorted(set(a)), dtype=np.int64))
        s = _score_arr(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 25, time.time() + 0.4)
        pol, ps = _hill(a, t_end, rng, temp_scale=1.0)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = np.unique(np.asarray(best, dtype=np.int64))
    cur_score = best_score
    stall = 0
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng, temp_scale=1.0)
        if cs > cur_score:
            cur = cand
            cur_score = cs
            stall = 0
        else:
            stall += 1
            # restart from a dilated / perturbed version
            k = rng.choice([2, 3, 5, 7])
            arr = cur * k
            if rng.random() < 0.5:
                m = rng.randint(-25, 25)
                arr = arr + m
            for _ in range(max(1, arr.size // 6)):
                j = rng.randrange(arr.size)
                arr[j] += rng.randint(-15, 15)
            arr = np.unique(np.sort(arr))
            ns = _score_arr(arr)
            if ns > cur_score:
                cur = arr
                cur_score = ns

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
