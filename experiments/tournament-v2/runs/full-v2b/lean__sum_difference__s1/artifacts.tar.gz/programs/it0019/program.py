# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets maximizing log|A-A|/log|A+A|.

Strategy: small sets (roughly 8..40 elements) maximize the ratio.  We use a
fast vectorised scorer, a greedy+swap local search seeded from structured
(Golomb / B_h) starts, and a final exhaustive polish phase.  The whole budget
is spent keeping the best set found.
"""
import math
import random
import time

import numpy as np


def _score(np_arr):
    n = np_arr.size
    if n < 2:
        return -1.0, 0, 0
    d = np.unique(np_arr[:, None] - np_arr[None, :]).size
    s = np.unique(np_arr[:, None] + np_arr[None, :]).size
    if s < 2 or d < 2:
        return -1.0, d, s
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0, d, s


def _golomb_seed(n, rng):
    """A simple Sidon-like (B_2) seed via greedy differences."""
    a = [0]
    used = {0}
    x = 1
    while len(a) < n and x < 10 * n * n + 100:
        ok = True
        for y in a:
            if (x - y) in used or (y - x) in used:
                ok = False
                break
        if ok:
            for y in a:
                used.add(x - y)
                used.add(y - x)
            a.append(x)
        x += 1
    return a


def _random_seed(n, rng, span):
    return rng.sample(range(span), n)


def _greedy_grow(n, rng):
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 40):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:800]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.5 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            best_x = max(a) + 1
        a.append(best_x)
    return a


def _swap_search(a, deadline, rng, boost_sums=True):
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, cd, csum = _score(cur)
    span = max(1, int(cur.max() - cur.min()))
    step = max(1, span // 6)
    no_improve = 0
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        center = int(cur[i])
        best_local = None
        for _ in range(8):
            nx = center + rng.randint(-step, step)
            if nx == center:
                continue
            cand = cur.copy()
            cand[i] = nx
            if np.unique(cand).size != cand.size:
                continue
            cand.sort()
            ns, nd, nsm = _score(cand)
            if best_local is None or ns > best_local[0]:
                best_local = (ns, cand, nd, nsm)
        if best_local is not None and best_local[0] >= cs:
            if best_local[0] > cs:
                no_improve = 0
            else:
                no_improve += 1
            cs = best_local[0]
            cur = best_local[1]
            cd = best_local[2]
            csum = best_local[3]
        else:
            no_improve += 1
        if no_improve > 3 * cur.size:
            step = max(1, step // 2)
            no_improve = 0
            if step <= 1:
                break
    return cur, cs


def _polish(a, deadline, rng):
    """Fine move of single elements with small steps, direct score accept."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, cd, csum = _score(cur)
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        center = int(cur[i])
        cand = cur.copy()
        cand[i] = center + rng.choice([-2, -1, 1, 2])
        if np.unique(cand).size != cand.size:
            continue
        cand.sort()
        ns, nd, nsm = _score(cand)
        if ns >= cs:
            cs = ns
            cur = cand
            csum = nsm
    return cur, cs


def _reduce_sums(a, deadline, rng):
    """Accept moves that strictly reduce |A+A| (allowing equal score)."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, cd, csum = _score(cur)
    span = max(1, int(cur.max() - cur.min()))
    step = max(1, span // 8)
    no_improve = 0
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        center = int(cur[i])
        cand = cur.copy()
        cand[i] = center + rng.randint(-step, step)
        if np.unique(cand).size != cand.size:
            continue
        cand.sort()
        ns, nd, nsm = _score(cand)
        improved = (nsm < csum and nd >= cd - max(1, cd // 50)) or ns > cs
        if improved:
            cur = cand
            cs = ns
            cd = nd
            csum = nsm
            no_improve = 0
        else:
            no_improve += 1
            if no_improve > 20 * cur.size:
                step = max(1, step // 2)
                no_improve = 0
                if step <= 1:
                    break
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    sizes = list(range(8, 35)) + [38, 42, 48, 55, 65, 80]

    # Phase 0: seed with Golomb rulers for a range of sizes
    for n in [8, 10, 12, 14, 16, 18, 20, 22, 25, 28, 32]:
        if time.time() > deadline - 95:
            break
        g = _golomb_seed(n, rng)
        if len(g) >= 2:
            s, _, _ = _score(np.array(g, dtype=np.int64))
            if s > best_score:
                best_score = s
                best = g[:]

    # Phase 1: greedy + swap exploration across many sizes
    idx = 0
    phase1_end = deadline - 35
    while time.time() < phase1_end:
        n = sizes[idx % len(sizes)]
        idx += 1
        if rng.random() < 0.4:
            a = _greedy_grow(n, rng)
        else:
            a = _golomb_seed(n, rng)
            if len(a) < n:
                a = _greedy_grow(n, rng)
        if len(a) < 2:
            continue
        spot_end = min(phase1_end, time.time() + 0.6)
        pol, ps = _swap_search(a, spot_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    # Phase 2: alternate sum-reduction and polish from the best set
    cur = sorted(set(int(x) for x in best))
    cur_score, _, _ = _score(np.array(cur, dtype=np.int64))
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cand_score = _reduce_sums(cur, t_end, rng)
        if cand_score > cur_score:
            cur = cand.tolist()
            cur_score = cand_score
        t_end = min(deadline, time.time() + 2.0)
        cand, cand_score = _polish(cur, t_end, rng)
        if cand_score > cur_score:
            cur = cand.tolist()
            cur_score = cand_score
        if cur_score > best_score:
            best_score = cur_score
            best = cur[:]
        # perturb to escape local optimum
        arr = np.array(cur, dtype=np.int64)
        if arr.size:
            for _ in range(rng.randint(1, max(1, arr.size // 8))):
                j = rng.randrange(arr.size)
                arr[j] += rng.randint(-30, 30)
            arr = np.unique(arr)
            if arr.size >= 2:
                cur = arr.tolist()
                cur_score, _, _ = _score(arr)

    if cur_score > best_score:
        best = cur

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
