# EVOLVE-BLOCK-START
"""Construction using a modular parabola lift: A = { C*i + (i^2 mod p) }."""
import math
import random
import time


def _diffs_sums_count(a):
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _score(a):
    if len(a) < 2:
        return 0.0
    d, s = _diffs_sums_count(a)
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _primes(limit):
    sieve = bytearray([1]) * (limit + 1)
    sieve[0] = sieve[1] = 0
    for i in range(2, int(limit ** 0.5) + 1):
        if sieve[i]:
            sieve[i * i::i] = bytearray(len(sieve[i * i::i]))
    return [i for i in range(2, limit + 1) if sieve[i]]


def _construct(p, C):
    """A = { C*i + (i*i mod p) : i in [0,p) } with C multiple of p."""
    return [C * i + (i * i % p) for i in range(p)]


def solve():
    """Maximise log|A-A|/log|A+A| with a modular parabola lift."""
    best = None
    best_score = -1.0
    deadline = time.time() + 110

    # Focus on moderate primes so brute-force scoring is feasible.
    primes = [p for p in _primes(260) if p >= 8]
    random.shuffle(primes)

    for p in primes:
        if time.time() > deadline:
            break
        for mult in (1, 2, 3, 5):
            C = p * mult
            a = _construct(p, C)
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a[:]

    if best is None:
        best = _construct(37, 37)
        best_score = _score(best)

    # Light local-search polish: scale the whole set (preserves ratios) and
    # try small perturbations of the multiplier C.
    cur = best[:]
    cur_score = best_score
    p = len(cur)
    # determine original C from best if possible by trying multipliers again
    deadline2 = time.time() + 5
    while time.time() < deadline2:
        base_p = random.choice([q for q in primes if q <= 127])
        C = base_p * random.randint(1, 8)
        cand = _construct(base_p, C)
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            break
    if cur_score > best_score:
        best, best_score = cur, cur_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
