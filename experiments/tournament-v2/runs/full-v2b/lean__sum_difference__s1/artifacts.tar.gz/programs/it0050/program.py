# EVOLVE-BLOCK-START
"""Fast incremental search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

from collections import defaultdict


def _score(nd, ns, n):
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _diffsum(a):
    """Return (ndistinct_diff, ndistinct_sum)."""
    n = len(a)
    dset = set()
    sset = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            dset.add(ai - aj)
            sset.add(ai + aj)
    return len(dset), len(sset)


class Incr:
    """Incremental distinct-count of differences and sums under single moves."""

    def __init__(self, a):
        self.a = list(a)
        self.dc = defaultdict(int)
        self.sc = defaultdict(int)
        n = len(self.a)
        for i in range(n):
            ai = self.a[i]
            for j in range(n):
                aj = self.a[j]
                self.dc[ai - aj] += 1
                self.sc[ai + aj] += 1
        self.nd = len(self.dc)
        self.ns = len(self.sc)

    def move(self, idx, newval):
        old = self.a[idx]
        if old == newval:
            return False
        n = len(self.a)
        # remove pairs involving old
        for j in range(n):
            if j == idx:
                continue
            aj = self.a[j]
            k = old - aj
            self.dc[k] -= 1
            if self.dc[k] == 0:
                del self.dc[k]
                self.nd -= 1
            k = old + aj
            self.sc[k] -= 1
            if self.sc[k] == 0:
                del self.sc[k]
                self.ns -= 1
        # remove self pairs
        k = 0
        self.dc[k] -= 1
        if self.dc[k] == 0:
            del self.dc[k]
            self.nd -= 1
        k = 2 * old
        self.sc[k] -= 1
        if self.sc[k] == 0:
            del self.sc[k]
            self.ns -= 1
        # add pairs involving newval
        for j in range(n):
            if j == idx:
                continue
            aj = self.a[j]
            k = newval - aj
            if self.dc[k] == 0:
                self.nd += 1
            self.dc[k] += 1
            k = newval + aj
            if self.sc[k] == 0:
                self.ns += 1
            self.sc[k] += 1
        k = 0
        if self.dc[k] == 0:
            self.nd += 1
        self.dc[k] += 1
        k = 2 * newval
        if self.sc[k] == 0:
            self.ns += 1
        self.sc[k] += 1
        self.a[idx] = newval
        return True


def _grow(n, rng, span):
    """Greedy near-Sidon build: keep sums small, differences large."""
    a = [0]
    used_d = {0}
    used_s = {0}
    aset = {0}
    for _ in range(n - 1):
        cands = []
        for base in a[-min(len(a), 30):]:
            for d in range(1, span + 1):
                for x in (base + d, base - d):
                    if x not in aset:
                        cands.append(x)
        if not cands:
            break
        rng.shuffle(cands)
        best_x = None
        best_val = -1e18
        seen = set()
        for x in cands[:400]:
            if x in seen:
                continue
            seen.add(x)
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in used_d:
                    newd += 1
                if (y - x) not in used_d:
                    newd += 1
                if (x + y) not in used_s:
                    news += 1
            val = newd - 2.0 * news
            if val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        for y in a:
            used_d.add(best_x - y)
            used_d.add(y - best_x)
            used_s.add(best_x + y)
        a.append(best_x)
        aset.add(best_x)
    return a


def _hill(inc, deadline, rng, span):
    best_score = _score(inc.nd, inc.ns, len(inc.a))
    n = len(inc.a)
    while time.time() < deadline:
        idx = rng.randrange(n)
        old = inc.a[idx]
        step = rng.randint(1, span)
        newval = old + rng.choice((-step, step))
        if newval == old:
            continue
        # tentative
        inc.move(idx, newval)
        s = _score(inc.nd, inc.ns, n)
        if s >= best_score:
            best_score = s
        else:
            inc.move(idx, old)
    return best_score


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(6, 24)) + [26, 30, 36, 44, 54]
    span = 40
    idx = 0

    while time.time() < deadline - 10:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng, span)
        if len(a) < 2:
            continue
        # normalize
        a = sorted(set(int(x) for x in a))
        inc = Incr(a)
        s = _score(inc.nd, inc.ns, len(inc.a))
        if s > best_score:
            best_score = s
            best = list(inc.a)
        t_end = min(deadline - 10, time.time() + 0.5)
        hs = _hill(inc, t_end, rng, span)
        if hs > best_score:
            best_score = hs
            best = list(inc.a)
        if idx % (3 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]
        best_score = _score(*_diffsum(best), len(best))

    # intensive final refinement with occasional restarts
    cur = sorted(set(int(x) for x in best))
    inc = Incr(cur)
    cur_score = _score(inc.nd, inc.ns, len(inc.a))
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 2.5)
        hs = _hill(inc, t_end, rng, span)
        if hs > cur_score:
            cur_score = hs
            cur = list(inc.a)
        # random perturbation / restart around best
        if rng.random() < 0.5 and best is not None:
            base = list(best)
            n = len(base)
            k = max(1, n // 6)
            for _ in range(rng.randint(1, k)):
                j = rng.randrange(n)
                base[j] += rng.randint(-span, span)
            base = sorted(set(int(x) for x in base))
            inc = Incr(base)
        else:
            base = list(cur)
            n = len(base)
            k = max(1, n // 8)
            for _ in range(rng.randint(1, k)):
                j = rng.randrange(n)
                base[j] += rng.randint(-span, span)
            base = sorted(set(int(x) for x in base))
            inc = Incr(base)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
