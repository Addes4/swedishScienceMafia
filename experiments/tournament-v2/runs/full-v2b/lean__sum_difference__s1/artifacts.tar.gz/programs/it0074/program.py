# EVOLVE-BLOCK-START
"""Fast bitset-based search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _bitsets(a, off):
    """Return (diff_bits, sum_bits) as Python ints, with position off for value 0."""
    db = 0
    sb = 0
    for x in a:
        for y in a:
            db |= 1 << (x - y + off)
            sb |= 1 << (x + y)
    return db, sb


def _score_from_bits(db, sb, n):
    d = bin(db).count("1")
    s = bin(sb).count("1")
    if s < 2 or d < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _eval(a):
    a = [int(x) for x in a]
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    off = max(a) - min(a) + 1
    db, sb = _bitsets(a, off)
    return _score_from_bits(db, sb, n)


def _sidon_grow(n, rng, minstep=1, maxstep=24):
    """Greedy near-Sidon set on a short span: prefer small span, no new equal diffs."""
    a = [0]
    diffs = {0}
    while len(a) < n:
        cands = []
        for base in a:
            for d in range(minstep, maxstep + 1):
                cands.append(base + d)
                cands.append(base - d)
        seen = set(a)
        cands = [c for c in cands if c not in seen]
        rng.shuffle(cands)
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            for y in a:
                if (x - y) not in diffs:
                    newd += 1
                if (y - x) not in diffs:
                    newd += 1
            span = max(max(a), x) - min(min(a), x)
            val = newd - 0.05 * span
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        for y in list(a):
            diffs.add(best_x - y)
            diffs.add(y - best_x)
        a.append(best_x)
    return a


def _hill(cur, deadline, rng):
    """Bitset hill-climb with incremental O(n) single-element moves."""
    cur = sorted(set(int(x) for x in cur))
    n = len(cur)
    if n < 2:
        return cur, -1.0
    lo = min(cur)
    hi = max(cur)
    off = hi - lo + 1
    db = 0
    sb = 0
    for x in cur:
        for y in cur:
            db |= 1 << (x - y + off)
            sb |= 1 << (x + y)
    cs, _, _ = _score_from_bits(db, sb, n)
    span = max(1, hi - lo)
    while time.time() < deadline:
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        old = cur[i]
        new = old + delta
        if new in cur:
            continue
        # quick span/bitset growth check
        nlo = min(lo, new)
        nhi = max(hi, new)
        noff = nhi - nlo + 1
        # build incremental bitsets by removing rows/cols of old, adding new
        ndb = db
        nsb = sb
        ok = True
        for y in cur:
            if y == old:
                continue
            ndb &= ~(1 << (old - y + off))
            ndb &= ~(1 << (y - old + off))
            nsb &= ~(1 << (old + y))
        ndb &= ~(1 << off)  # old-old diff = 0
        nsb &= ~(1 << (2 * old))
        # shift if offset changed
        if noff != off:
            shift = off - noff
            ndb = ndb << shift if shift > 0 else ndb >> (-shift)
        ndb &= ~((1 << (noff + noff + 1)) - 1)  # safety mask low bits (value >= -span)
        for y in cur:
            if y == old:
                continue
            ndb |= 1 << (new - y + noff)
            ndb |= 1 << (y - new + noff)
            nsb |= 1 << (new + y)
        ndb |= 1 << noff
        nsb |= 1 << (2 * new)
        d = bin(ndb).count("1")
        s = bin(nsb).count("1")
        if s < 2:
            continue
        ns = math.log(d) / math.log(s) + (1 - 1 / len(cur)) / 100
        if ns >= cs:
            cur[i] = new
            db, sb, off, lo, hi = ndb, nsb, noff, nlo, nhi
            cs = ns

    return cur, cs


def solve():
    deadline = time.time() + 110
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    sizes = list(range(8, 26)) + [30, 35, 40, 50]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 15:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _sidon_grow(n, rng)
        if len(a) < 2:
            continue
        t_end = min(deadline - 15, time.time() + 0.8)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = [int(x) for x in pol]
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = [int(x) for x in cand]
            cur_score = cs
            if cs > best_score:
                best_score = cs
                best = cur
        else:
            k = max(1, len(cur) // 8)
            for _ in range(rng.randint(1, k)):
                j = rng.randrange(len(cur))
                cur[j] += rng.randint(-30, 30)
            cur = sorted(set(cur))
            cur_score, _, _ = _eval(cur)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
