# EVOLVE-BLOCK-START
"""Construction: A = subset sums of powers of base M = 2b.

For A = {sum of subset of {M^0, M^1, ..., M^(n-1)}}:
  - Differences are (almost) all distinct -> |A-A| near n^2 (actually each
    difference corresponds to a signed digit vector in {-1,0,1}^n, and for
    M = 2b these are very close to injective, giving |A-A| ~ 3^n style growth).
  - Sums correspond to digit vectors in {0,1,2}^n, so |A+A| ~ 3^n as well but
    with many collisions across the smaller base.

We search over base b and size n, score exactly, and return the best set.
"""


def _score_exact(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    nd = len(diffs)
    ns = len(sums)
    if ns < 2 or nd < 2:
        return 0.0
    import math
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _subset_sums(base, n):
    """A = all subset sums of {base^0,...,base^(n-1)}."""
    a = [0]
    p = 1
    for _ in range(n):
        a = a + [x + p for x in a]
        p *= base
    return a


def solve():
    best = None
    best_score = -1.0
    # n is limited so |A| = 2^n <= 4000 -> n <= 11. Try n up to 11.
    for n in range(2, 12):
        for b in range(2, 60):
            a = _subset_sums(2 * b, n)
            if len(a) > 4000:
                continue
            s = _score_exact(a)
            if s > best_score:
                best_score = s
                best = a[:]
    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    # safety clamp
    best = sorted(set(best))[:4000]
    return best
# EVOLVE-BLOCK-END
