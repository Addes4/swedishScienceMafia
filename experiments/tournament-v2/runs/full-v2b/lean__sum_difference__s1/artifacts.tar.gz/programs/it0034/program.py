# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _counts(a):
    """Return (ndiff, nsum) for integer array a."""
    a = np.asarray(a, dtype=np.int64)
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return int(d), int(s)


def _score(ndiff, nsum, n):
    if nsum < 2:
        return 0.0
    return math.log(ndiff) / math.log(nsum) + (1 - 1 / n) / 100


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d, s = _counts(a)
    return _score(d, s, n), d, s


def _seq_score(seq):
    a = np.array(sorted(set(int(x) for x in seq)), dtype=np.int64)
    if a.size < 2:
        return -1.0, None
    sc, d, s = _eval(a)
    return sc, a


def _sturmian(n, alpha):
    return [int(math.floor(k * alpha)) for k in range(n)]


def _sidon_greedy(n, limit):
    """Sidon-like set (all pairwise sums distinct) up to limit."""
    sums = set()
    a = []
    cands = list(range(0, limit))
    idx = 0
    while len(a) < n and idx < len(cands):
        x = cands[idx]
        idx += 1
        ok = True
        for y in a:
            if x + y in sums:
                ok = False
                break
        if ok:
            for y in a:
                sums.add(x + y)
            sums.add(2 * x)
            a.append(x)
    return a


def _grow(n, rng):
    """Greedy build maximizing diffs while minimizing new sums."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 40):
                cands.add(base + d)
                cands.add(base - d)
        curset = set(a)
        cands = [c for c in cands if c not in curset]
        rng.shuffle(cands)
        cands = cands[:400]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _hill(a, deadline, rng):
    """Steepest-ascent single-element move maximizing true score."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        n = cur.size
        i = rng.randrange(n)
        best_cand = None
        best_s = cs
        tried = 0
        for _ in range(6):
            if time.time() >= deadline:
                break
            step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12, 16]))
            delta = rng.randint(-step, step)
            if delta == 0:
                continue
            cand = cur.copy()
            cand[i] += delta
            if np.unique(cand).size != cand.size:
                continue
            cand = np.sort(cand)
            ns, _, _ = _eval(cand)
            tried += 1
            if ns > best_s:
                best_s = ns
                best_cand = cand
        if best_cand is not None:
            cur = best_cand
            cs = best_s
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(123456789)
    best = None
    best_score = -1.0

    def consider(seq):
        nonlocal best, best_score
        sc, arr = _seq_score(seq)
        if arr is not None and sc > best_score:
            best_score = sc
            best = arr.tolist()

    # Seeds
    for n in (6, 7, 8, 9, 10, 11, 12):
        for k in range(1, 12):
            alpha = 1.0 + k * 0.13
            consider(_sturmian(n, alpha))
    for n in (6, 7, 8, 9, 10):
        consider(_sidon_greedy(n, 300))

    sizes = list(range(6, 22)) + [25, 30, 40]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 15:
        n = sizes[idx % len(sizes)]
        idx += 1
        seed_kind = rng.random()
        if seed_kind < 0.4:
            a = _grow(n, rng)
        elif seed_kind < 0.7:
            alpha = 1.0 + rng.randrange(1, 20) * 0.11
            a = _sturmian(n, alpha)
        else:
            a = _sidon_greedy(n, 60 * n + 50)
        consider(a)
        t_end = min(deadline - 15, time.time() + 0.8)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
            if cs > best_score:
                best_score = cs
                best = cur[:]
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 6)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-40, 40)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
