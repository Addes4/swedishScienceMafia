# EVOLVE-BLOCK-START
"""Simulated annealing over integer sets maximizing log|A-A|/log|A+A|."""
import math
import random
import time
import numpy as np


def _eval(a):
    """Return score and (|A-A|, |A+A|) for list a (distinct ints)."""
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    A = np.asarray(a, dtype=np.int64)
    d = np.unique(A[:, None] - A[None, :]).size
    s = np.unique(A[:, None] + A[None, :]).size
    if s < 2:
        return -1.0, d, s
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0, d, s


def _init_random(n, span):
    a = set()
    while len(a) < n:
        a.add(random.randint(-span, span))
    return sorted(a)


def _init_struct(n, D):
    """A = {i*D + i*i} style structured greedy (Golomb-ish, spread out)."""
    a = []
    used = set()
    for i in range(n):
        x = i * D + (i * i) % D
        while x in used:
            x += 1
        used.add(x)
        a.append(x)
    return a


def _sa(a, deadline):
    """Simulated annealing from initial set a."""
    cur = list(a)
    cs, _, _ = _eval(cur)
    n = len(cur)
    used = set(cur)
    best = cur[:]
    bs = cs
    step_scale = max(2, int(abs(max(cur) - min(cur)) / max(1, n)) + 1)
    T = 0.02
    it = 0
    while time.time() < deadline:
        it += 1
        i = random.randrange(n)
        old = cur[i]
        delta = random.randint(-step_scale, step_scale)
        if delta == 0:
            delta = 1
        newv = old + delta
        if newv in used:
            continue
        cur[i] = newv
        ns, _, _ = _eval(cur)
        if ns >= cs or random.random() < math.exp((ns - cs) / T):
            used.remove(old)
            used.add(newv)
            cs = ns
            if ns > bs:
                bs = ns
                best = cur[:]
        else:
            cur[i] = old
        if it % 400 == 0:
            T = max(0.002, T * 0.97)
            if it % 4000 == 0:
                # reheat / perturb
                T = 0.02
                for _ in range(max(1, n // 20)):
                    j = random.randrange(n)
                    ov = cur[j]
                    nv = ov + random.randint(-step_scale * 4, step_scale * 4)
                    if nv not in used:
                        used.remove(ov)
                        used.add(nv)
                        cur[j] = nv
                cs, _, _ = _eval(cur)
    return best, bs


def solve():
    """Maximise log|A-A|/log|A+A| via multi-restart simulated annealing."""
    end = time.time() + 108
    best = None
    bs = -1.0
    sizes = [40, 60, 80, 100, 120]
    # seed a decent structured candidate first
    for n in sizes:
        for D in (3, 5, 8, 13, 21):
            a = _init_struct(n, D)
            s, _, _ = _eval(a)
            if s > bs:
                bs = s
                best = a[:]
    random.seed(12345)
    while time.time() < end:
        n = random.choice(sizes)
        r = random.random()
        if r < 0.5:
            span = random.choice([n // 2, n, 2 * n, 4 * n, 8 * n, n * n])
            a = _init_random(n, span)
        elif r < 0.8:
            a = _init_struct(n, random.choice([3, 5, 8, 13, 21, 34, 55]))
        else:
            a = _init_random(n, 2 * n)
        per = min(6.0, max(1.0, (end - time.time()) / 3.0))
        b, sb = _sa(a, time.time() + per)
        if sb > bs:
            bs = sb
            best = b[:]
        if time.time() >= end:
            break
    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    return sorted(set(best))
# EVOLVE-BLOCK-END
