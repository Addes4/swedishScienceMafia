# EVOLVE-BLOCK-START
"""Structured construction: near-Sidon sets (large |A-A|) with small |A+A|.

Idea: |A-A| is maximised (~n^2) when A is a (near) Sidon/Golomb set,
i.e. all differences distinct. To also keep |A+A| small we want sums to
collide.  A clean family: take A to be a set whose differences are all
distinct but whose sums are forced into a small range by choosing A as a
subset of a short interval that is simultaneously a difference-side Sidon
set.  We evaluate several structured families exactly and keep the best.
"""
import math
import random
import time


def _diffs_sums(a):
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return diffs, sums


def _score(a):
    if len(a) < 2:
        return 0.0
    diffs, sums = _diffs_sums(a)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _golomb(n, seed):
    """Greedy Golomb-ruler-like set: all pairwise differences distinct."""
    rnd = random.Random(seed)
    maxv = 60 * n * n
    a = [0, 1]
    used = {0, 1}
    # forbidden differences set
    diffs = {1, -1}
    while len(a) < n:
        cand = rnd.randrange(a[-1] + 1, a[-1] + maxv)
        ok = True
        newd = set()
        for y in a:
            d = cand - y
            if d in diffs or -d in diffs:
                ok = False
                break
            newd.add(d)
            newd.add(-d)
        if not ok:
            # try small sequential offsets too
            placed = False
            for cand in range(a[-1] + 1, a[-1] + maxv):
                ok = True
                newd = set()
                for y in a:
                    d = cand - y
                    if d in diffs or -d in diffs:
                        ok = False
                        break
                    newd.add(d)
                    newd.add(-d)
                if ok:
                    a.append(cand)
                    diffs |= newd
                    placed = True
                    break
            if not placed:
                break
        else:
            a.append(cand)
            diffs |= newd
    return a


def _near_sidon_interval(n):
    """Best effort: build a set with distinct differences but bunched sums.

    Use a set that is a Sidon set in differences AND lives so that its sums
    lie in a comparatively short interval: scale a Golomb set but place it
    inside an interval of minimal length to reduce |A+A| range (though sums
    collision is what matters, not range).
    """
    a = _golomb(n, random.randrange(10 ** 9))
    return a


def _two_scale(n):
    """Two-scale: A = U + K*V where U small Sidon, V scaling.

    Differences are mostly distinct (large range) while sums collide
    because U+U may overlap.
    """
    # split n ~ |U| * |V|
    rnd = random.Random(random.randrange(10 ** 9))
    half = max(1, int(math.sqrt(n)))
    U = _golomb(half, rnd.randrange(10 ** 9))
    V = _golomb(max(1, n // max(1, len(U))), rnd.randrange(10 ** 9))
    K = 10 ** 9
    A = [u + K * v for u in U for v in V]
    return A[:n]


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    # Candidates: several near-Sidon sets at various sizes.
    sizes = [8, 10, 12, 16, 20, 24, 30, 40]
    for n in sizes:
        for seed in range(6):
            if time.time() > deadline:
                break
            a = _golomb(n, random.randrange(10 ** 9))
            if len(a) != n:
                continue
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a[:]

    # two-scale candidates
    for n in [16, 25, 36, 49, 64]:
        if time.time() > deadline:
            break
        a = _two_scale(n)
        if len(a) < 2:
            continue
        s = _score(a)
        if s > best_score:
            best_score = s
            best = list(set(a))

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    return sorted(set(best))
# EVOLVE-BLOCK-END
