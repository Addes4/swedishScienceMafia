# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _eval_bitset(a):
    """Faster eval using python int bitsets over the shifted coordinate range."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    shift = int(a.max() - a.min()) + 1
    # differences: values in [-(span), span]; represent shifted by span
    dset = 0
    sset = 0
    vals = a.tolist()
    span = int(a.max() - a.min())
    ssum = int(a.max()) + int(a.max())
    for i, x in enumerate(vals):
        for y in vals:
            dset |= 1 << (x - y + span)
            sset |= 1 << (x + y)
    d = bin(dset).count("1")
    s = bin(sset).count("1")
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _grow(n, rng):
    """Greedy: build a by minimizing new sums while maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 24):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:500]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _bose_chowla(q):
    """Bose-Chowla Sidon set on Z_{q^2-1}, size q, using primitive root of GF(q^2)."""
    import itertools
    # find a prime q (q mod 4 not needed). Work over GF(q^2) = GF(q)[x]/(x^2 - g)
    # where g is a non-residue. Moser: use field GF(p^2), p prime, theta primitive.
    p = q
    # find non-residue g
    g = None
    for cand in range(2, p):
        # legendre symbol
        if pow(cand, (p - 1) // 2, p) == p - 1:
            g = cand
            break
    if g is None:
        return None
    # elements of GF(p^2) represented as (a,b) meaning a + b*x, x^2 = g
    # multiply
    def mul(u, v):
        a, b = u
        c, d = v
        return ((a * c + b * d * g) % p, (a * d + b * c) % p)

    def mapelem(u):
        return (u[0] % p, u[1] % p)

    # find primitive element theta
    order = p * p - 1
    # factor order
    fac = []
    m = order
    d = 2
    while d * d <= m:
        if m % d == 0:
            fac.append(d)
            while m % d == 0:
                m //= d
        d += 1
    if m > 1:
        fac.append(m)

    theta = None
    for a in range(p):
        for b in range(p):
            if a == 0 and b == 0:
                continue
            el = (a, b)
            ok = True
            for f in fac:
                # el^(order/f)
                e = order // f
                r = (1, 0)
                base = el
                ee = e
                while ee:
                    if ee & 1:
                        r = mul(r, base)
                    base = mul(base, base)
                    ee >>= 1
                if r == (1, 0):
                    ok = False
                    break
            if ok:
                theta = el
                break
        if theta is not None:
            break
    if theta is None:
        return None

    # coset representatives: {0} U {theta^i : i=0..q-2}
    vals = [0]
    cur = (1, 0)
    for _ in range(p - 1):
        # convert to integer via discrete log base primitive? 
        # Use the "log" mapping: element -> index in GF(p^2)*
        vals.append(None)  # placeholder, resolved below
        cur = mul(cur, theta)
    # Build discrete log table
    dlog = {}
    cur = (1, 0)
    for i in range(order):
        dlog[cur] = i
        cur = mul(cur, theta)

    # Bose-Chowla set: theta in GF(q^2), set { a : theta + a }, a in GF(q) } 
    # gives Sidon set of size q in Z_{q^2-1} via discrete logs.
    s = []
    for a in range(p):
        el = ((1 + 0) % p, 1)  # theta + a  (theta = (0,1)? no)
        # theta here is primitive; use actual element theta + a
        ta = (theta[0] + a, theta[1])
        if ta == (0, 0):
            s.append(0)
        else:
            s.append(dlog[ta])
    return s


def _sidon_seed(rng):
    """Build a Sidon set seed using Bose-Chowla on a chosen prime power."""
    qs = [7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61]
    rng.shuffle(qs)
    for q in qs:
        try:
            s = _bose_chowla(q)
        except Exception:
            s = None
        if s is None:
            continue
        s = sorted(set(int(x) for x in s))
        if len(s) >= 2:
            return s
    return None


def _hill(a, deadline, rng):
    """Fast hill-climb moving single elements, maximizing true score."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        cand = cur.copy()
        cand[i] += delta
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        ns, _, _ = _eval(cand)
        if ns >= cs:
            cur = cand
            cs = ns
    return cur, cs


def _hill_bitset(a, deadline, rng):
    """Hill-climb using the faster bitset evaluator."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2 or cur.size > 120:
        return _hill(a, deadline, rng)
    cs, _, _ = _eval_bitset(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        cand = cur.copy()
        cand[i] += delta
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        ns, _, _ = _eval_bitset(cand)
        if ns >= cs:
            cur = cand
            cs = ns
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    # Phase 1: Sidon seeds (compact span, maximal |A-A|)
    t1 = time.time() + 20
    while time.time() < t1 and time.time() < deadline - 30:
        s = _sidon_seed(rng)
        if s is None:
            break
        arr = np.array(sorted(set(s)), dtype=np.int64)
        sc, _, _ = _eval(arr)
        if sc > best_score:
            best_score = sc
            best = arr.tolist()
        # hill-climb the seed briefly with bitset evaluator
        t_end = min(deadline - 20, time.time() + 2.0)
        pol, ps = _hill_bitset(s, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        # try affine translations/scalings of seed to escape
        if best is not None and rng.random() < 0.5:
            m = rng.choice([1, 2, 3])
            tr = rng.randint(-5, 5)
            s2 = [int(m) * int(x) + tr for x in s]
            arr2 = np.array(sorted(set(s2)), dtype=np.int64)
            sc2, _, _ = _eval(arr2)
            if sc2 > best_score:
                best_score = sc2
                best = arr2.tolist()

    # Phase 2: greedy + hill (proven)
    sizes = list(range(8, 30)) + [35, 40, 50, 60]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 12:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 12, time.time() + 0.6)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-30, 30)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
