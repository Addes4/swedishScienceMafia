# EVOLVE-BLOCK-START
"""Best-first / greedy construction maximizing log|A-A|/log|A+A|."""
import math
import random
import time


def _score_from(a, diffs, sums):
    nd = len(diffs)
    ns = len(sums)
    if len(a) < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100


def _eval(a):
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return diffs, sums


def _score(a):
    d, s = _eval(a)
    return _score_from(a, d, s)


def _grow(a, n, rng, width=60):
    """Greedily grow by scanning candidate deltas relative to existing elements."""
    used = set(a)
    diffs, sums = _eval(a)
    while len(a) < n:
        anchors = list(a)
        rng.shuffle(anchors)
        cands = set()
        for base in anchors[:min(len(anchors), 12)]:
            for d in range(1, 60):
                cands.add(base + d)
                cands.add(base - d)
        cands -= used
        cands = list(cands)
        rng.shuffle(cands)
        # score each candidate incrementally
        best = None
        best_val = None
        ad = list(diffs)
        aus = list(sums)
        for x in cands[:600]:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in diffs:
                    newd += 1
                if (x + y) not in sums:
                    news += 1
            val = newd - 4.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best = x
                if news == 0:
                    break
        if best is None:
            break
        x = best
        for y in a:
            diffs.add(x - y)
            diffs.add(y - x)
            sums.add(x + y)
        diffs.add(0)
        sums.add(2 * x)
        a.append(x)
        used.add(x)
    return a


def solve():
    """Maximise log|A-A|/log|A+A|."""
    deadline = time.time() + 110
    rng = random.Random(12345)
    best = None
    best_score = -1.0
    sizes = [20, 25, 30, 40, 50, 64, 80]
    idx = 0
    while time.time() < deadline:
        n = sizes[idx % len(sizes)]
        idx += 1
        start = [0]
        # add one random small seed
        start.append(rng.randint(1, 5))
        a = _grow(start, n, rng)
        if a:
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a[:]
        # local polish: try shifting one element to improve score
        cur = a[:]
        cs = _score(cur)
        t_end = time.time() + 1.5
        while time.time() < t_end:
            cand = cur[:]
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-50, 50)
            if len(set(cand)) != len(cand):
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
        if cs > best_score:
            best_score = cs
            best = cur[:]
    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    return sorted(set(best))
# EVOLVE-BLOCK-END
