# EVOLVE-BLOCK-START
"""Time-bounded direct optimisation of log|A-A|/log|A+A| with fast incremental evaluation."""
import math
import random
import time

import numpy as np


def _score_arr(a):
    """Score a sorted numpy int array via vectorized diff/sum counting."""
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _diffs(a):
    return np.unique(a[:, None] - a[None, :])


def _sums(a):
    return np.unique(a[:, None] + a[None, :])


def _greedy_grow(n, rng):
    """Grow a set of size n, each step choosing candidate minimizing sums hurt + maximizing diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(_diffs(cur).tolist())
        curs = set(_sums(cur).tolist())
        # candidate offsets from existing elements
        cands = set()
        for base in a:
            for d in range(1, 30):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:600]
        best_x = None
        best_val = None
        an = np.array(a, dtype=np.int64)
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            # want many new diffs, few new sums
            val = newd - 3.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _swap_search(a, deadline, rng):
    """Local search: random element jitter, accept if score non-decreasing."""
    cur = np.array(a, dtype=np.int64)
    cs, _, _ = _score_arr(cur)
    span = max(1, int(cur.max() - cur.min()) if cur.size else 1)
    while time.time() < deadline:
        cand = cur.copy()
        i = rng.randrange(cand.size)
        cand[i] += rng.randint(-max(2, span // 4), max(2, span // 4))
        if np.unique(cand).size != cand.size:
            continue
        ns, _, _ = _score_arr(np.sort(cand))
        if ns >= cs:
            cur = np.sort(cand)
            cs = ns
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(12345)
    best = None
    best_score = -1.0

    # try a range of sizes
    sizes = list(range(6, 40)) + [45, 50, 60, 70, 85, 100]
    random.shuffle(sizes)

    idx = 0
    while time.time() < deadline:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _greedy_grow(n, rng)
        if len(a) < 2:
            continue
        s, _, _ = _score_arr(np.array(a, dtype=np.int64))
        if s > best_score:
            best_score = s
            best = a[:]
        # polish with a short swap search
        t_end = min(deadline, time.time() + 0.5)
        pol, ps = _swap_search(sorted(set(a)), t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % len(sizes) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
