# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _stats(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return d, s


def _score(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return -1.0
    d, s = _stats(a)
    if s < 2 or d < 2:
        return -1.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _grow(n, rng):
    """Greedily add elements maximizing new diffs minus new sums."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        curset = set(a)
        cands = set()
        for base in a:
            for d in range(1, 40):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in curset]
        rng.shuffle(cands)
        cands = cands[:600]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            # fallback: pick farthest unused candidate
            if not cands:
                break
            best_x = max(cands, key=lambda c: min(abs(c - y) for y in a))
        a.append(int(best_x))
        a = sorted(set(a))
    return a


def _climb(a, deadline, rng, max_k=24):
    """Steepest-ascent: for each element, try best delta among K candidates."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs = _score(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        improved = False
        order = list(range(cur.size))
        rng.shuffle(order)
        for i in order:
            if time.time() >= deadline:
                break
            base = int(cur[i])
            best_delta = 0
            best_sc = cs
            tried = set()
            for _ in range(max_k):
                step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
                delta = rng.randint(-step, step)
                if delta == 0 or delta in tried:
                    continue
                tried.add(delta)
                cand = cur.copy()
                cand[i] = base + delta
                if np.unique(cand).size != cand.size:
                    continue
                if np.abs(cand).max() > 10**15:
                    continue
                ns = _score(cand)
                if ns > best_sc:
                    best_sc = ns
                    best_delta = delta
            if best_delta != 0:
                cur[i] = base + best_delta
                cur = np.sort(cur)
                cs = best_sc
                improved = True
        if not improved:
            # random restart-ish perturbation of one element
            i = rng.randrange(cur.size)
            step = max(1, span // rng.choice([4, 8]))
            cand = cur.copy()
            cand[i] += rng.randint(-step, step)
            cand = np.sort(cand)
            if np.unique(cand).size == cand.size and np.abs(cand).max() <= 10**15:
                cur = cand
                cs = _score(cur)
            else:
                break
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240607)
    best = None
    best_score = -1.0

    # seed sizes biased to small n (best ratios)
    sizes = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 24, 30]
    idx = 0

    while time.time() < deadline - 15:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s = _score(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 15, time.time() + 1.2)
        pol, ps = _climb(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _climb(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size >= 2:
                k = max(1, arr.size // 6)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-40, 40)
                arr = np.unique(np.sort(arr))
                if arr.size >= 2:
                    cur = arr.tolist()
                    cur_score = _score(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
