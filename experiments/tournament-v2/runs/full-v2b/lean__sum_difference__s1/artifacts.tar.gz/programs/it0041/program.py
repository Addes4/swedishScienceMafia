# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A| by maximizing the exact ratio."""
import math
import random
import time

import numpy as np


def _counts(a):
    """Return (ndiff, nsum) for int64 array a using numpy outer differences/sums."""
    a = np.asarray(a, dtype=np.int64)
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return d, s


def _score(nd, ns, n):
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d, s = _counts(a)
    return _score(d, s, n), d, s


def _grow(n, rng):
    """Greedy: build a by minimizing new sums while maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 24):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:500]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _ap_seed(n, rng):
    """Dense arithmetic-like seed on a short interval (sum-poor)."""
    # start from an interval of consecutive-ish integers
    start = rng.randint(-20, 20)
    a = list(range(start, start + n))
    # thin out a bit randomly to create difference structure
    return a


def _hill(a, deadline, rng):
    """Hill-climb moving single elements, maximizing true score."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12, 16]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        cand = cur.copy()
        cand[i] += delta
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        ns, _, _ = _eval(cand)
        if ns >= cs:
            cur = cand
            cs = ns
    return cur, cs


def _sum_reduce(a, deadline, rng):
    """Try to reduce the number of sums by shifting elements, keeping diffs high."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    n = cur.size
    maxd = n * (n - 1) + 1
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 8, 16, 32]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        cand = cur.copy()
        cand[i] += delta
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        nd, nsu = _counts(cand)
        # primary objective: reduce sums if diffs stay near max; else use score
        val_now = nd * 10000.0 - nsu
        d_cur, s_cur = _counts(cur)
        val_new = nd * 10000.0 - nsu
        val_cur = d_cur * 10000.0 - s_cur
        if val_new >= val_cur:
            cur = cand
            cs = _score(nd, nsu, n)
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(13571234)
    best = None
    best_score = -1.0

    sizes = list(range(8, 26)) + [30, 35, 40, 50]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 25:
        n = sizes[idx % len(sizes)]
        idx += 1
        mode = idx % 3
        if mode == 0:
            a = _grow(n, rng)
        elif mode == 1:
            a = _ap_seed(n, rng)
        else:
            a = _grow(n, rng)
            if len(a) > 4:
                a = _ap_seed(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 25, time.time() + 0.5)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        # try sum-reduction climb on this seed
        t_end2 = min(deadline - 25, time.time() + 0.4)
        pol2, ps2 = _sum_reduce(a, t_end2, rng)
        if ps2 > best_score:
            best_score = ps2
            best = pol2.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-30, 30)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
