# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _score_from_counts(dc, sc, n):
    d = len(dc)
    s = len(sc)
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _grow(n, rng):
    """Greedy: build a by minimizing new sums while maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 24):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:500]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _build_counts(a):
    """Build difference/sum multiplicity dicts for list a."""
    dc = {}
    sc = {}
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            k = ai - aj
            dc[k] = dc.get(k, 0) + 1
            k2 = ai + aj
            sc[k2] = sc.get(k2, 0) + 1
    return dc, sc


def _remove_pair(dc, sc, x, y):
    k = x - y
    v = dc[k] - 1
    if v:
        dc[k] = v
    else:
        del dc[k]
    k2 = x + y
    v2 = sc[k2] - 1
    if v2:
        sc[k2] = v2
    else:
        del sc[k2]


def _add_pair(dc, sc, x, y):
    dc[x - y] = dc.get(x - y, 0) + 1
    sc[x + y] = sc.get(x + y, 0) + 1


def _replace_element(a, dc, sc, i, newx):
    """Change a[i] to newx, updating counts in place."""
    oldx = a[i]
    n = len(a)
    for j in range(n):
        if j == i:
            continue
        _remove_pair(dc, sc, oldx, a[j])
        _add_pair(dc, sc, newx, a[j])
    # self pairs
    _remove_pair(dc, sc, oldx, oldx)
    _add_pair(dc, sc, newx, newx)
    a[i] = newx


def _hill(a, deadline, rng):
    """Incremental hill-climb on single-element moves using dict counts."""
    cur = sorted(set(int(x) for x in a))
    if len(cur) < 2:
        return cur, -1.0
    n = len(cur)
    dc, sc = _build_counts(cur)
    cs = _score_from_counts(dc, sc, n)
    span = max(1, cur[-1] - cur[0])
    used = set(cur)
    steps = [2, 3, 4, 6, 8]
    while time.time() < deadline:
        i = rng.randrange(n)
        step = max(1, span // rng.choice(steps))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        newx = cur[i] + delta
        if newx in used:
            continue
        oldx = cur[i]
        # incremental update
        for j in range(n):
            if j == i:
                continue
            _remove_pair(dc, sc, oldx, cur[j])
            _add_pair(dc, sc, newx, cur[j])
        _remove_pair(dc, sc, oldx, oldx)
        _add_pair(dc, sc, newx, newx)
        ns = _score_from_counts(dc, sc, n)
        if ns >= cs:
            cur[i] = newx
            used.discard(oldx)
            used.add(newx)
            cs = ns
            cur.sort()
        else:
            # revert
            for j in range(n):
                if j == i:
                    continue
                _remove_pair(dc, sc, newx, cur[j])
                _add_pair(dc, sc, oldx, cur[j])
            _remove_pair(dc, sc, newx, newx)
            _add_pair(dc, sc, oldx, oldx)
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    sizes = list(range(8, 30)) + [35, 40, 50, 60]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 12:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 12, time.time() + 0.6)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-30, 30)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
