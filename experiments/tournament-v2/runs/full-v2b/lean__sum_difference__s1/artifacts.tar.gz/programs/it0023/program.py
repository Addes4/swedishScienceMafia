# EVOLVE-BLOCK-START
"""Fast time-bounded search maximizing log|A-A|/log|A+A|.

Strategy: difference-dominant sets give the best ratio for small n (≈8-40).
We seed from structured low-sum families (scaled geometric-ish and Sidon-like
bases) and run a fast local search that moves single elements to maximize the
actual score, accepting equal-score moves to walk plateaus.
"""
import math
import random
import time

import numpy as np


def _score(a):
    """a: 1D int64 numpy array. Return (score, |D|, |S|)."""
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0, d, s


def _norm(a):
    """Shift so min is 0 and return sorted unique int64 array."""
    a = np.asarray(sorted(set(int(x) for x in a)), dtype=np.int64)
    if a.size:
        a = a - a[0]
    return a


def _seed_sidonlike(n, rng, span_scale=3):
    """Sidon-ish set via greedy: pick each next value to rarely create
    repeated sums (small |A+A|) while keeping spread."""
    a = [0, 1]
    while len(a) < n:
        base = a[-1]
        best_x = None
        best_key = None
        cands = []
        step = max(1, base // 6 if base > 6 else 1)
        for base_el in a[-3:]:
            for d in range(1, 4 * span_scale + 2):
                cands.append(base_el + d * step)
                cands.append(base_el - d * step)
        cands = [c for c in cands if c not in a and c >= 0]
        rng.shuffle(cands)
        cands = cands[:80]
        for x in cands:
            sums = {}
            dup = 0
            for y in a:
                k = x + y
                if k in sums:
                    dup += 1
                else:
                    sums[k] = 1
            diffs = set()
            newd = 0
            for y in a:
                for v in (x - y, y - x):
                    if v not in diffs:
                        diffs.add(v)
                        newd += 1
            key = (dup, -newd)
            if best_key is None or key < best_key:
                best_key = key
                best_x = x
        if best_x is None:
            best_x = a[-1] + rng.randint(1, 5)
        a.append(best_x)
    return a


def _seed_geometric(n, rng):
    a = [0]
    for _ in range(n - 1):
        a.append(a[-1] + max(1, int(a[-1] * 0.6) + rng.randint(1, 3)))
    return a


def _local_search(a, deadline, rng):
    cur = _norm(a)
    if cur.size < 2:
        return cur, -1.0
    cs, cd, css = _score(cur)
    span = max(1, int(cur.max() - cur.min()))
    step = max(2, span // 6)
    it = 0
    while time.time() < deadline:
        it += 1
        i = rng.randrange(cur.size)
        center = int(cur[i])
        # propose a few moves; choose best by (sums, -diffs) then score
        best = None
        for _ in range(5):
            nx = center + rng.randint(-step, step)
            if nx < 0:
                continue
            cand = cur.copy()
            cand[i] = nx
            if np.unique(cand).size != cand.size:
                continue
            cand = np.sort(cand)
            cand = cand - cand[0]
            ns, nd, nsu = _score(cand)
            key = (nsu, -nd)
            if best is None or key < best[0]:
                best = (key, cand, ns, nd, nsu)
        if best is None:
            if step > 2:
                step -= 1
            continue
        key, cand, ns, nd, nsu = best
        # accept if score improves or (equal score, plateau walk) with some prob
        if (nsu < css and cd - nd <= max(1, cd // 15)) or ns > cs or (
            ns >= cs - 1e-12 and nsu <= css and rng.random() < 0.5
        ):
            cur = cand
            cs, cd, css = ns, nd, nsu
        else:
            if rng.random() < 0.05:
                step = max(2, min(span // 3, step + rng.choice([-1, 1])))
            if it % 400 == 0:
                step = max(2, span // 6)
    return cur, cs


def _perturb(a, rng, mag):
    arr = a.copy()
    if arr.size == 0:
        return arr
    k = max(1, arr.size // 8)
    for _ in range(rng.randint(1, k)):
        j = rng.randrange(arr.size)
        arr[j] += rng.randint(-mag, mag)
        if arr[j] < 0:
            arr[j] = rng.randint(0, mag)
    arr = np.unique(np.sort(arr))
    if arr.size:
        arr = arr - arr[0]
    return arr


def solve():
    deadline = time.time() + 110
    rng = random.Random(987654321)

    best_a = None
    best_score = -1.0

    sizes = [8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 40, 50, 64]

    # Phase 1: seed various sizes and locally search briefly
    p1_end = time.time() + 60
    si = 0
    while time.time() < p1_end:
        n = sizes[si % len(sizes)]
        si += 1
        if rng.random() < 0.5:
            seed = _seed_sidonlike(n, rng)
        else:
            seed = _seed_geometric(n, rng)
        t_end = min(p1_end, time.time() + 1.5)
        arr, sc = _local_search(seed, t_end, rng)
        if sc > best_score:
            best_score = sc
            best_a = arr.copy()

    if best_a is None:
        best_a = np.array([0, 1, 3, 7, 12], dtype=np.int64)

    # Phase 2: intensify around best with perturbation restarts
    cur = best_a.copy()
    cur_score = best_score
    span = max(1, int(cur.max() - cur.min())) if cur.size else 1
    while time.time() < deadline:
        mag = max(2, span // 5)
        start = _perturb(cur, rng, mag) if rng.random() < 0.6 else cur.copy()
        t_end = min(deadline, time.time() + 3.0)
        cand, sc = _local_search(start, t_end, rng)
        if sc > cur_score:
            cur = cand
            cur_score = sc
            span = max(1, int(cur.max() - cur.min()))
        if cur_score > best_score:
            best_score = cur_score
            best_a = cur.copy()

    return [int(x) for x in best_a]
# EVOLVE-BLOCK-END
