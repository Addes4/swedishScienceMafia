# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A| via Sidon-like construction + incremental local search."""
import math
import random
import time


def _eval(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    d = len(diffs)
    s = len(sums)
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _build_sidon(n, offset):
    """Build a Sidon (B_2) set greedily on [0, offset) to maximize distinct differences."""
    a = [0]
    diffs = {0}
    sums = {0}
    limit = offset
    x = 1
    while len(a) < n and x < limit:
        ok = True
        # ensure new sums distinct-ish: we allow collisions but limit near-duplicates
        nd = 0
        ns_new = 0
        for y in a:
            if (x - y) not in diffs and (y - x) not in diffs:
                pass
            nd += 1
            if (x + y) not in sums:
                ns_new += 1
        # accept if differences are mostly new (Sidon-ish)
        if nd >= len(a):
            a.append(x)
            for y in a:
                diffs.add(x - y)
                diffs.add(y - x)
                sums.add(x + y)
            sums.add(2 * x)
        x += 1
    return a


def _local_search(a, deadline, rng):
    """Incremental single-element move search using dictionaries of pair counts."""
    a = [int(v) for v in a]
    n = len(a)
    if n < 2:
        return a, -1.0

    diff_cnt = {}
    sum_cnt = {}
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diff_cnt[ai - a[j]] = diff_cnt.get(ai - a[j], 0) + 1
            sum_cnt[ai + a[j]] = sum_cnt.get(ai + a[j], 0) + 1

    def score():
        d = len(diff_cnt)
        s = len(sum_cnt)
        if s < 2:
            return -1.0
        return math.log(d) / math.log(s) + (1 - 1 / n) / 100

    cur = score()
    span = max(1, max(a) - min(a))
    it = 0
    while time.time() < deadline:
        it += 1
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        old = a[i]
        new = old + delta
        if new in a:
            # allow duplicates avoided
            if delta > 0:
                new = old + 1
                if new in a:
                    continue
            else:
                new = old - 1
                if new in a:
                    continue
            delta = new - old
        ai = old
        # remove old pairs
        for j in range(n):
            if j == i:
                continue
            aj = a[j]
            k = ai - aj
            v = diff_cnt.get(k, 0) - 1
            if v <= 0:
                diff_cnt.pop(k, None)
            else:
                diff_cnt[k] = v
            k = aj - ai
            v = diff_cnt.get(k, 0) - 1
            if v <= 0:
                diff_cnt.pop(k, None)
            else:
                diff_cnt[k] = v
            k = ai + aj
            v = sum_cnt.get(k, 0) - 1
            if v <= 0:
                sum_cnt.pop(k, None)
            else:
                sum_cnt[k] = v
        # remove self diff 0 and self sum 2*ai
        v = diff_cnt.get(0, 0) - 1
        if v <= 0:
            diff_cnt.pop(0, None)
        else:
            diff_cnt[0] = v
        k = 2 * ai
        v = sum_cnt.get(k, 0) - 1
        if v <= 0:
            sum_cnt.pop(k, None)
        else:
            sum_cnt[k] = v

        # add new pairs with new value
        for j in range(n):
            if j == i:
                continue
            aj = a[j]
            diff_cnt[new - aj] = diff_cnt.get(new - aj, 0) + 1
            diff_cnt[aj - new] = diff_cnt.get(aj - new, 0) + 1
            sum_cnt[new + aj] = sum_cnt.get(new + aj, 0) + 1
        diff_cnt[0] = diff_cnt.get(0, 0) + 1
        k = 2 * new
        sum_cnt[k] = sum_cnt.get(k, 0) + 1

        ns = score()
        if ns >= cur:
            a[i] = new
            cur = ns
        else:
            # revert
            for j in range(n):
                if j == i:
                    continue
                aj = a[j]
                k = new - aj
                v = diff_cnt.get(k, 0) - 1
                if v <= 0:
                    diff_cnt.pop(k, None)
                else:
                    diff_cnt[k] = v
                k = aj - new
                v = diff_cnt.get(k, 0) - 1
                if v <= 0:
                    diff_cnt.pop(k, None)
                else:
                    diff_cnt[k] = v
                k = new + aj
                v = sum_cnt.get(k, 0) - 1
                if v <= 0:
                    sum_cnt.pop(k, None)
                else:
                    sum_cnt[k] = v
            v = diff_cnt.get(0, 0) - 1
            if v <= 0:
                diff_cnt.pop(0, None)
            else:
                diff_cnt[0] = v
            k = 2 * new
            v = sum_cnt.get(k, 0) - 1
            if v <= 0:
                sum_cnt.pop(k, None)
            else:
                sum_cnt[k] = v
            # re-add old
            for j in range(n):
                if j == i:
                    continue
                aj = a[j]
                diff_cnt[ai - aj] = diff_cnt.get(ai - aj, 0) + 1
                diff_cnt[aj - ai] = diff_cnt.get(aj - ai, 0) + 1
                sum_cnt[ai + aj] = sum_cnt.get(ai + aj, 0) + 1
            diff_cnt[0] = diff_cnt.get(0, 0) + 1
            k = 2 * ai
            sum_cnt[k] = sum_cnt.get(k, 0) + 1
    return a, cur


def solve():
    deadline = time.time() + 112
    rng = random.Random(123456789)
    best = None
    best_score = -1.0

    sizes = list(range(10, 40)) + [45, 50, 60, 70, 80]
    idx = 0
    while time.time() < deadline - 20:
        n = sizes[idx % len(sizes)]
        idx += 1
        # try a few offsets for Sidon-like set
        offset = n * n // 2 + rng.randint(0, n)
        a = _build_sidon(n, max(offset, 2 * n))
        if len(a) < 2:
            continue
        s, _, _ = _eval(a)
        if s > best_score:
            best_score = s
            best = list(a)
        t_end = min(deadline - 20, time.time() + 0.5)
        pol, ps = _local_search(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = list(pol)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _local_search(cur, t_end, rng)
        if cs > cur_score:
            cur = sorted(set(int(x) for x in cand))
            cur_score = cs
        else:
            # perturbation
            arr = list(cur)
            if arr:
                k = max(1, len(arr) // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(len(arr))
                    arr[j] += rng.randint(-30, 30)
                arr = sorted(set(arr))
                cur = arr
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
