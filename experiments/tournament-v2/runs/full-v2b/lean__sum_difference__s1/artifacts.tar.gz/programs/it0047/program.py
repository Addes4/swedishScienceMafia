# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return d, s


def _score_of(n, d, s):
    if s < 2 or n < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _grow(n, rng):
    """Greedy: build a by minimizing new sums while maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 24):
                cands.add(base + d)
                cands.add(base - d)
        a_set = set(a)
        cands = [c for c in cands if c not in a_set]
        rng.shuffle(cands)
        cands = cands[:400]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _digit_set(n, base, planes, rng):
    """Union of digit planes: A = { c + t*base : t in planes } keeps sums small."""
    vals = sorted(set(planes))
    A = []
    for t in vals:
        A.append(1 + t * base)
    # pad to size n using nearby elements that share few sum-residues
    return A


def _block_set(n, width, rng):
    """A = {i + j*M}: sums occupy small band, differences spread out."""
    base = max(2, width)
    A = []
    j = 0
    while len(A) < n:
        off = j * (base) + (j % 3)
        A.append(off)
        j += 1
    return A[:n]


def _hill(a, deadline, rng, tries=None):
    """Fast hill-climb moving single elements, maximizing true score."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12, 20]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        cand = cur.copy()
        cand[i] += delta
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        ns = _eval(cand)[0]
        if ns >= cs:
            cur = cand
            cs = ns
    return cur, cs


def _seeds(n, rng):
    seeds = []
    seeds.append(_grow(n, rng))
    for base in (2, 3, 4, 5):
        planes = list(range(n))
        seeds.append(_digit_set(n, base, planes, rng))
    for width in (2, 3, 4, 5, 6, 7, 8):
        seeds.append(_block_set(n, width, rng))
    return seeds


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    sizes = list(range(8, 30)) + [35, 40, 50, 60]
    random.shuffle(sizes)
    idx = 0

    def consider(arr):
        nonlocal best, best_score
        arr = np.array(sorted(set(int(x) for x in arr)), dtype=np.int64)
        if arr.size < 2:
            return
        s = _eval(arr)[0]
        if s > best_score:
            best_score = s
            best = arr.tolist()

    while time.time() < deadline - 12:
        n = sizes[idx % len(sizes)]
        idx += 1
        for a in _seeds(n, rng):
            if time.time() >= deadline - 12:
                break
            consider(a)
            t_end = min(deadline - 12, time.time() + 0.35)
            pol, ps = _hill(a, t_end, rng)
            if ps > best_score:
                best_score = ps
                best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-30, 30)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score = _eval(arr)[0]

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END

