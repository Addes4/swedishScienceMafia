# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _score_from_counts(nd, ns, n):
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _eval(arr):
    a = np.asarray(arr, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return _score_from_counts(int(d), int(s), n), int(d), int(s)


def _full_counts(a):
    md = {}
    ms = {}
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            md[ai - aj] = md.get(ai - aj, 0) + 1
            ms[ai + aj] = ms.get(ai + aj, 0) + 1
    return md, ms


def _grow(n, rng, max_span):
    a = [0]
    diffs = {0}
    sums = {0}
    for _ in range(n - 1):
        cands = []
        seen = set()
        for base in a:
            for d in range(1, 22):
                for x in (base + d, base - d):
                    if 0 <= x <= max_span and x not in seen:
                        seen.add(x)
                        cands.append(x)
        rng.shuffle(cands)
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in diffs:
                    newd += 1
                if (x + y) not in sums:
                    news += 1
            val = newd - 1.8 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        for y in a:
            diffs.add(best_x - y)
            diffs.add(y - best_x)
            sums.add(best_x + y)
        a.append(best_x)
    return a


def _apply_remove(md, ms, val, a, idx):
    """Remove all pairs involving index idx whose value is val."""
    n = len(a)
    for j in range(n):
        if j == idx:
            continue
        y = a[j]
        k = val - y
        md[k] = md.get(k, 0) - 1
        k2 = y - val
        md[k2] = md.get(k2, 0) - 1
        s = val + y
        ms[s] = ms.get(s, 0) - 1
    # self pair (val,val)
    md[0] = md.get(0, 0) - 1
    ms[2 * val] = ms.get(2 * val, 0) - 1


def _apply_add(md, ms, val, a, idx):
    n = len(a)
    for j in range(n):
        if j == idx:
            continue
        y = a[j]
        md[val - y] = md.get(val - y, 0) + 1
        md[y - val] = md.get(y - val, 0) + 1
        ms[val + y] = ms.get(val + y, 0) + 1
    md[0] = md.get(0, 0) + 1
    ms[2 * val] = ms.get(2 * val, 0) + 1


def _count_nonzero(md):
    c = 0
    for v in md.values():
        if v > 0:
            c += 1
    return c


def _hill_set(a, deadline, rng):
    a = list(a)
    n = len(a)
    if n < 2:
        return a, -1.0
    md, ms = _full_counts(a)
    nd = _count_nonzero(md)
    ns = _count_nonzero(ms)
    cs = _score_from_counts(nd, ns, n)
    span = max(1, max(a) - min(a))
    while time.time() < deadline:
        i = rng.randrange(n)
        old = a[i]
        step = max(1, span // rng.choice([1, 2, 3, 4, 6, 8, 16]))
        new = old + rng.randint(-step, step)
        if new == old or new in a:
            continue
        a[i] = new
        _apply_remove(md, ms, old, a, i)   # uses a[j] which is now new at i, handled by skip
        _apply_add(md, ms, new, a, i)
        # count
        nd2 = _count_nonzero(md)
        ns2 = _count_nonzero(ms)
        cs2 = _score_from_counts(nd2, ns2, n)
        if cs2 >= cs:
            cs = cs2
            nd, ns = nd2, ns2
        else:
            a[i] = old
            _apply_remove(md, ms, new, a, i)
            _apply_add(md, ms, old, a, i)
    return a, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(10, 44)) + [50, 60]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 14:
        n = sizes[idx % len(sizes)]
        idx += 1
        max_span = int(n * rng.uniform(1.4, 3.2))
        a = _grow(n, rng, max_span)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 14, time.time() + 0.8)
        pol, ps = _hill_set(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = sorted(set(pol))
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill_set(cur, t_end, rng)
        cand = sorted(set(cand))
        if cs > cur_score:
            cur = cand
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 6)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-40, 40)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
