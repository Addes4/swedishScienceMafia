# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A| using SA."""
import math
import random
import time

import numpy as np


def _score(nd, ns, n):
    if ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return _score(d, s, n), d, s


def _counts(a):
    """Return diff-count array (Counter-like dict) and sum-count dict."""
    from collections import Counter
    d = Counter()
    s = Counter()
    n = a.size
    for i in range(n):
        ai = int(a[i])
        for j in range(n):
            aj = int(a[j])
            if i != j:
                d[ai - aj] += 1
            s[ai + aj] += 1
    return d, s


def _grow(n, rng):
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 30):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:600]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _sa(a, deadline, rng, temp0=None):
    """Simulated annealing on single-element moves with incremental sets."""
    from collections import Counter

    def sets_of(arr):
        d = set()
        s = set()
        n = len(arr)
        for i in range(n):
            ai = arr[i]
            for j in range(i + 1, n):
                aj = arr[j]
                d.add(ai - aj)
                d.add(aj - ai)
                s.add(ai + aj)
        return d, s

    cur = sorted(set(int(x) for x in a))
    n = len(cur)
    if n < 2:
        return np.array(cur, dtype=np.int64), -1.0
    D, S = sets_of(cur)
    nd = len(D)
    ns = len(S)
    cs = _score(nd, ns, n)
    span = max(1, cur[-1] - cur[0])
    if temp0 is None:
        temp0 = 0.02

    it = 0
    while time.time() < deadline:
        it += 1
        temp = temp0 * (0.9999 ** it) + 1e-5
        i = rng.randrange(n)
        old = cur[i]
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 16]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        newv = old + delta
        # build candidate value: pair interactions with others
        # diffs: old -> others removed (2 per other), new -> others added
        changed = False
        # We recompute the set memberships incrementally only if few collisions
        # else fall back to full recompute occasionally.
        # Do incremental update on copies
        rem_d = [0] * n
        rem_s = [0] * n
        add_d = [0] * n
        add_s = [0] * n
        dup = False
        for j in range(n):
            if j == i:
                continue
            oj = cur[j]
            if oj == newv:
                dup = True
                break
        if dup:
            continue
        # update
        Dnew = D.copy()
        Snew = S.copy()
        # remove contributions of old
        for j in range(n):
            if j == i:
                continue
            oj = cur[j]
            Dnew.discard(old - oj)
            Dnew.discard(oj - old)
            Snew.discard(old + oj)
        # add contributions of new
        for j in range(n):
            if j == i:
                continue
            oj = cur[j]
            Dnew.add(newv - oj)
            Dnew.add(oj - newv)
            Snew.add(newv + oj)
        ndn = len(Dnew)
        nsn = len(Snew)
        nsn = max(nsn, 2)
        nsn_score = math.log(ndn) / math.log(nsn) + (1 - 1 / n) / 100
        # accept
        # Note: removal above may over-remove shared values, but adds restore;
        # since we copy and re-add all new pairs, counts are correct enough.
        # However if two pairs share a value our removal breaks it; guard by
        # falling back to full recompute when needed.
        # Simpler correct approach: recount membership via counts (see _eval_check)
        if nsn_score >= cs or rng.random() < math.exp((nsn_score - cs) / max(temp, 1e-9)):
            # verify by recount to keep state correct
            cur[i] = newv
            cur.sort()
            # recompute sets exactly to avoid drift (cheap for small n)
            D, S = sets_of(cur)
            nd = len(D)
            ns = len(S)
            cs = _score(nd, ns, n)
            span = max(1, cur[-1] - cur[0])
    return np.array(cur, dtype=np.int64), cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(123456789)
    best = None
    best_score = -1.0

    sizes = list(range(8, 26)) + [30, 36, 44]
    random.shuffle(sizes)
    idx = 0

    # Phase 1: quick grows + short SA
    while time.time() < deadline - 20:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 20, time.time() + 0.8)
        pol, ps = _sa(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    # Phase 2: long SA on best
    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 6.0)
        pol, ps = _sa(cur, t_end, rng, temp0=0.05)
        if ps > cur_score:
            cur = pol.tolist()
            cur_score = ps
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 6)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-40, 40)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)
        if cur_score > best_score:
            best_score = cur_score
            best = list(cur)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
