# EVOLVE-BLOCK-START
"""Search for sets with large difference set and small sum set.

Strategy: maintain a candidate set A, and repeatedly try to *reduce* |A+A|
while keeping |A-A| as large as possible, via local moves (shift/perturb one
element).  Evaluate the true objective incrementally.
"""
import math
import random
import time


def _score_parts(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _score_parts(a)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100.0


def _full_norm(a):
    return sorted(set(a))


def _initial_sidon(n):
    """Greedy Sidon set (all pairwise sums distinct) -> |A-A| = n(n-1)+1."""
    a = [0]
    sums = {0}
    diffs = {0}
    x = 0
    while len(a) < n:
        x += 1
        ok = True
        new_s = set()
        new_d = set()
        for y in a:
            s = x + y
            d = x - y
            if s in sums or s in new_s:
                ok = False
                break
            if d in diffs or (-d) in diffs or d in new_d or (-d) in new_d:
                ok = False
                break
            new_s.add(s)
            new_d.add(d)
        if ok:
            a.append(x)
            sums |= new_s
            sums |= {2 * x}
            diffs |= new_d
            diffs |= {-d for d in new_d}
            diffs.add(0)
    return a


def _perturb_search(a, deadline):
    """Try to reduce sum set by tweaking while keeping differences large."""
    cur = a[:]
    cs = _score(cur)
    n = len(cur)
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(n)
        step = random.randint(-50, 50)
        if step == 0:
            step = 1
        cand[i] += step
        cand = _full_norm(cand)
        if len(cand) != n:
            continue
        s = _score(cand)
        if s > cs:
            cur, cs, n = cand, s, len(cand)
    return cur, cs


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0
    trials = 0
    while time.time() < deadline:
        trials += 1
        n = random.randint(8, 22)
        a = _initial_sidon(n)
        a = [2 * v for v in a]
        t_end = min(deadline, time.time() + 3.0)
        cur, cs = _perturb_search(a, t_end)
        if cs > best_score:
            best_score = cs
            best = cur[:]
        if trials % 5 == 0:
            # periodic global probing with a spread-out geometric seed
            n2 = random.randint(6, 16)
            g = [0]
            for k in range(1, n2):
                g.append(g[-1] + random.randint(1, 4))
            t_end2 = min(deadline, time.time() + 2.0)
            cur2, cs2 = _perturb_search(g, t_end2)
            if cs2 > best_score:
                best_score = cs2
                best = cur2[:]
    if best is None:
        best = _initial_sidon(12)
    return sorted(set(best))
# EVOLVE-BLOCK-END
