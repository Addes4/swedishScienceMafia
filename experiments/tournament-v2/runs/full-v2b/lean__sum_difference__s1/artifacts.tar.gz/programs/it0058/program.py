# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


class _Inc:
    """Incremental evaluator: maintain multiplicities of diffs and sums."""

    __slots__ = ("vals", "dcnt", "scnt", "nd", "ns", "n")

    def __init__(self, vals):
        self.vals = list(vals)
        v = self.vals
        self.n = len(v)
        dcnt = {}
        scnt = {}
        for i in range(self.n):
            vi = v[i]
            for j in range(i + 1, self.n):
                vj = v[j]
                d1 = vi - vj
                d2 = -d1
                dcnt[d1] = dcnt.get(d1, 0) + 1
                dcnt[d2] = dcnt.get(d2, 0) + 1
                s = vi + vj
                scnt[s] = scnt.get(s, 0) + 1
        self.dcnt = dcnt
        self.scnt = scnt
        self.nd = len(dcnt) + 1   # +1 for the difference 0 (self-pairs)
        self.ns = len(scnt)

    def _dec_d(self, key):
        c = self.dcnt.get(key)
        if c == 1:
            del self.dcnt[key]
            self.nd -= 1
        else:
            self.dcnt[key] = c - 1

    def _inc_d(self, key):
        c = self.dcnt.get(key)
        if c is None:
            self.dcnt[key] = 1
            self.nd += 1
        else:
            self.dcnt[key] = c + 1

    def _dec_s(self, key):
        c = self.scnt.get(key)
        if c == 1:
            del self.scnt[key]
            self.ns -= 1
        else:
            self.scnt[key] = c - 1

    def _inc_s(self, key):
        c = self.scnt.get(key)
        if c is None:
            self.scnt[key] = 1
            self.ns += 1
        else:
            self.scnt[key] = c + 1

    def try_move(self, i, newval):
        old = self.vals[i]
        if newval == old:
            return False
        v = self.vals
        n = self.n
        # remove old element's relations
        for j in range(n):
            if j == i:
                continue
            vj = v[j]
            self._dec_d(old - vj)
            self._dec_d(vj - old)
            self._dec_s(old + vj)
        # add new element's relations
        for j in range(n):
            if j == i:
                continue
            vj = v[j]
            self._inc_d(newval - vj)
            self._inc_d(vj - newval)
            self._inc_s(newval + vj)
        v[i] = newval
        return True

    def score(self):
        if self.ns < 2:
            return -1.0
        return (math.log(self.nd) / math.log(self.ns)
                + (1 - 1 / self.n) / 100)


def _grow(n, rng):
    """Greedy: build a by minimizing new sums while maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 24):
                cands.add(base + d)
                cands.add(base - d)
        aset = set(a)
        cands = [c for c in cands if c not in aset]
        rng.shuffle(cands)
        cands = cands[:400]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _inc_search(vals, deadline, rng, span):
    """Incremental hill-climb."""
    inc = _Inc(vals)
    cs = inc.score()
    n = inc.n
    while time.time() < deadline:
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        newval = inc.vals[i] + delta
        if newval in inc.vals:
            continue
        old = inc.vals[i]
        inc.try_move(i, newval)
        ns = inc.score()
        if ns >= cs:
            cs = ns
        else:
            inc.try_move(i, old)
    return inc.vals, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    sizes = list(range(8, 30)) + [35, 40, 50, 60]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 12:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        span = max(1, int(arr.max() - arr.min()))
        t_end = min(deadline - 12, time.time() + 0.6)
        pol, ps = _inc_search(list(arr), t_end, rng, span)
        # verify with exact eval
        parr = np.array(sorted(set(int(x) for x in pol)), dtype=np.int64)
        if parr.size >= 2:
            ps2, _, _ = _eval(parr)
            if ps2 > best_score:
                best_score = ps2
                best = parr.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        span = max(1, max(cur) - min(cur))
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _inc_search(cur, t_end, rng, span)
        carr = np.array(sorted(set(int(x) for x in cand)), dtype=np.int64)
        if carr.size >= 2:
            cs2, _, _ = _eval(carr)
            if cs2 > cur_score:
                cur = carr.tolist()
                cur_score = cs2
            else:
                k = max(1, len(cur) // 8)
                arr2 = np.array(cur, dtype=np.int64)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr2.size)
                    arr2[j] += rng.randint(-30, 30)
                arr2 = np.unique(np.sort(arr2))
                if arr2.size >= 2:
                    cur = arr2.tolist()
                    cur_score, _, _ = _eval(arr2)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
