# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval_arr(a):
    """Score of sorted int64 array a. Returns (score, ndiff, nsum)."""
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _eval(a):
    return _eval_arr(np.asarray(a, dtype=np.int64))


def _grow(n, rng):
    """Greedy: build by minimizing new sums while maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 30):
                cands.add(base + d)
                cands.add(base - d)
        present = set(a)
        cands = [c for c in cands if c not in present]
        rng.shuffle(cands)
        cands = cands[:600]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _score_of(cur, cache={}):
    key = tuple(cur)
    v = cache.get(key)
    if v is None:
        v = _eval_arr(np.array(cur, dtype=np.int64))[0]
        if len(cache) > 20000:
            cache.clear()
        cache[key] = v
    return v


def _hill(a, deadline, rng):
    """Best-of-K single-element hill-climb maximizing the true score."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs = _score_of(tuple(cur.tolist()))
    span = max(1, int(cur.max() - cur.min()))

    while time.time() < deadline:
        i = rng.randrange(cur.size)
        base = int(cur[i])
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 16]))
        best_val = None
        best_x = base
        for _ in range(6):
            delta = rng.randint(-step, step)
            x = base + delta
            if x in cur:
                continue
            cand = cur.copy()
            cand[i] = x
            cand = np.sort(cand)
            if np.unique(cand).size != cand.size:
                continue
            sc = _score_of(tuple(cand.tolist()))
            if best_val is None or sc > best_val:
                best_val = sc
                best_x = x
        if best_val is not None and best_val >= cs:
            cur[i] = best_x
            cur = np.sort(cur)
            cs = best_val
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(8, 26)) + [30, 35, 40]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 12:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval_arr(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 12, time.time() + 0.7)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 6)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-40, 40)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score = _score_of(tuple(cur))

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
