# EVOLVE-BLOCK-START
"""Time-bounded direct optimisation of log|A-A|/log|A+A|."""
import math
import random
import time

import numpy as np


def _score_arr(a):
    """Score a sorted int array via vectorized diff/sum counting."""
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _greedy_grow(n, rng):
    """Grow a set of size n; choose candidate maximizing new diffs and minimizing new sums."""
    a = [0]
    curd = set([0])
    curs = set([0])
    for _ in range(n - 1):
        cands = set()
        for base in a:
            for d in range(1, 40):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in curs and (c not in set(a))]
        rng.shuffle(cands)
        cands = cands[:400]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd:
                    newd += 1
                if (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.5 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            # fall back: add element minimizing new sums
            best_x = max(a) + 1
        a.append(best_x)
        for y in a[:-1]:
            curd.add(best_x - y)
            curd.add(y - best_x)
            curs.add(best_x + y)
        curs.add(best_x + best_x)
    return a


def _swap_search(a, deadline, rng):
    """Local search: random element jitter, accept if score non-decreasing."""
    cur = np.array(a, dtype=np.int64)
    cs, _, _ = _score_arr(cur)
    span = max(1, int(cur.max() - cur.min()) if cur.size else 1)
    step = max(1, span // 8)
    while time.time() < deadline:
        cand = cur.copy()
        i = rng.randrange(cand.size)
        cand[i] += rng.randint(-step, step)
        if np.unique(cand).size != cand.size:
            continue
        c2 = np.sort(cand)
        ns, _, _ = _score_arr(c2)
        if ns >= cs:
            cur = c2
            cs = ns
        else:
            step = max(1, step - 1) if rng.random() < 0.01 else step
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240607)
    best = None
    best_score = -1.0

    sizes = list(range(5, 45)) + [50, 60, 75, 90, 110]
    idx = 0
    while time.time() < deadline:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _greedy_grow(n, rng)
        if len(a) < 2:
            continue
        arr = np.sort(np.array(a, dtype=np.int64))
        s, _, _ = _score_arr(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline, time.time() + 0.4)
        pol, ps = _swap_search(arr, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % len(sizes) == 0:
            sizes.sort(key=lambda _: rng.random())

    if best is None:
        best = [0, 1, 3, 7, 12]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END

