# EVOLVE-BLOCK-START
"""Construction + incremental hill-climb for large |A-A|, small |A+A|."""
import math
import random
import time


def _eval(a):
    """Score of integer iterable. Returns (score, ndiff, nsum)."""
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    d = len({x - y for x in a for y in a})
    s = len({x + y for x in a for y in a})
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _sidon(n):
    """A Sidon set of size n via greedy (all pairwise sums distinct)."""
    used_sums = set()
    a = []
    x = 0
    while len(a) < n:
        ok = True
        new_sums = []
        for y in a:
            v = x + y
            if v in used_sums:
                ok = False
                break
            new_sums.append(v)
        if ok:
            # also x+x
            if 2 * x in used_sums:
                ok = False
        if ok:
            a.append(x)
            for v in new_sums:
                used_sums.add(v)
            used_sums.add(2 * x)
        x += 1
        if x > 200000:
            break
    return a


def _shifted_sidon(n, spread):
    """Sidon-like set: base Sidon scaled + placed, plus helpers."""
    base = _sidon(n)
    return [v * spread for v in base]


class _Inc:
    """Incremental difference/sum multiplicity tracker."""

    def __init__(self, a):
        self.a = list(a)
        self.dm = {}
        self.sm = {}
        for x in self.a:
            for y in self.a:
                self.dm[x - y] = self.dm.get(x - y, 0) + 1
                self.sm[x + y] = self.sm.get(x + y, 0) + 1
        self.nd = sum(1 for v in self.dm.values() if v == 1)  # not used
        self.nd = len(self.dm)
        self.ns = len(self.sm)

    def remove(self, x):
        for y in self.a:
            d = x - y
            self.dm[d] -= 1
            if self.dm[d] == 0:
                del self.dm[d]
            d = y - x
            self.dm[d] -= 1
            if self.dm[d] == 0:
                del self.dm[d]
            s = x + y
            self.sm[s] -= 1
            if self.sm[s] == 0:
                del self.sm[s]

    def add(self, x):
        for y in self.a:
            self.dm[x - y] = self.dm.get(x - y, 0) + 1
            self.dm[y - x] = self.dm.get(y - x, 0) + 1
            self.sm[x + y] = self.sm.get(x + y, 0) + 1
        self.dm[0] = self.dm.get(0, 0) + 1
        self.sm[2 * x] = self.sm.get(2 * x, 0) + 1

    def score(self):
        n = len(self.a)
        if n < 2 or self.ns < 2:
            return -1.0
        return math.log(self.nd) / math.log(self.ns) + (1 - 1 / n) / 100


def _hill(inc, deadline, rng, span):
    cur = inc.score()
    a = inc.a
    n = len(a)
    while time.time() < deadline:
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        old = a[i]
        new = old + delta
        if new in set(a):
            continue
        inc.remove(old)
        a[i] = new
        inc.add(new)
        ns = inc.score()
        if ns >= cur:
            cur = ns
        else:
            inc.remove(new)
            a[i] = old
            inc.add(old)
    return inc


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240607)
    best = None
    best_score = -1.0

    # candidate constructions
    trials = []
    for n in range(12, 41):
        base = _sidon(n)
        trials.append(base)
        for spread in (1, 2, 3, 5):
            trials.append([v * spread for v in base])

    for a in trials:
        if time.time() > deadline - 20:
            break
        if len(a) < 2:
            continue
        s, _, _ = _eval(a)
        if s > best_score:
            best_score = s
            best = list(a)

    # refine best with incremental hill-climb
    if best is None:
        best = [0, 1, 3, 7, 12]
        best_score, _, _ = _eval(best)

    cur = sorted(set(int(x) for x in best))
    inc = _Inc(cur)
    cur_score = inc.score()

    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        span = max(1, max(inc.a) - min(inc.a))
        _hill(inc, t_end, rng, span)
        cs = inc.score()
        if cs > cur_score:
            cur_score = cs
            cur = list(inc.a)
        else:
            # restart from a perturbed copy of best-known
            base = sorted(set(int(x) for x in (cur if cur_score > best_score else best)))
            arr = list(base)
            k = max(1, len(arr) // 6)
            for _ in range(rng.randint(1, k)):
                j = rng.randrange(len(arr))
                arr[j] += rng.randint(-40, 40)
            arr = sorted(set(arr))
            if len(arr) >= 2:
                inc = _Inc(arr)
                cur_score = inc.score()

    final = sorted(set(int(x) for x in inc.a))
    fs, _, _ = _eval(final)
    if fs < best_score:
        final = best
    return final
# EVOLVE-BLOCK-END
