# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A| using
incremental (differential) difference/sum set maintenance."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _grow(n, rng):
    """Greedy build: minimize new sums while maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 24):
                cands.add(base + d)
                cands.add(base - d)
        aset = set(a)
        cands = [c for c in cands if c not in aset]
        rng.shuffle(cands)
        cands = cands[:500]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


class State:
    """Maintains multiset counts of differences and sums incrementally."""

    __slots__ = ("vals", "dcnt", "scnt", "nd", "ns")

    def __init__(self, vals):
        self.vals = list(vals)
        self.dcnt = {}
        self.scnt = {}
        self.nd = 0
        self.ns = 0
        self._build()

    def _build(self):
        vs = self.vals
        dc = self.dcnt
        sc = self.scnt
        n = len(vs)
        for i in range(n):
            vi = vs[i]
            for j in range(n):
                vj = vs[j]
                d = vi - vj
                c = dc.get(d, 0)
                dc[d] = c + 1
                if c == 0:
                    self.nd += 1
                s = vi + vj
                c = sc.get(s, 0)
                sc[s] = c + 1
                if c == 0:
                    self.ns += 1

    def score(self):
        n = len(self.vals)
        if n < 2 or self.ns < 2:
            return 0.0
        return math.log(self.nd) / math.log(self.ns) + (1 - 1 / n) / 100

    def _remove(self, x):
        dc = self.dcnt
        sc = self.scnt
        for y in self.vals:
            d = x - y
            c = dc[d] - 1
            if c == 0:
                del dc[d]
                self.nd -= 1
            else:
                dc[d] = c
            d = y - x
            c = dc[d] - 1
            if c == 0:
                del dc[d]
                self.nd -= 1
            else:
                dc[d] = c
            s = x + y
            c = sc[s] - 1
            if c == 0:
                del sc[s]
                self.ns -= 1
            else:
                sc[s] = c
        # self pairs x-x and x+x
        for d in (0,):
            c = dc[d] - 1
            if c == 0:
                del dc[d]
                self.nd -= 1
            else:
                dc[d] = c
        s = x + x
        c = sc[s] - 1
        if c == 0:
            del sc[s]
            self.ns -= 1
        else:
            sc[s] = c

    def _add(self, x):
        dc = self.dcnt
        sc = self.scnt
        for y in self.vals:
            d = x - y
            c = dc.get(d, 0)
            dc[d] = c + 1
            if c == 0:
                self.nd += 1
            d = y - x
            c = dc.get(d, 0)
            dc[d] = c + 1
            if c == 0:
                self.nd += 1
            s = x + y
            c = sc.get(s, 0)
            sc[s] = c + 1
            if c == 0:
                self.ns += 1
        c = dc.get(0, 0)
        dc[0] = c + 1
        if c == 0:
            self.nd += 1
        s = x + x
        c = sc.get(s, 0)
        sc[s] = c + 1
        if c == 0:
            self.ns += 1

    def move(self, i, newx):
        old = self.vals[i]
        if newx == old:
            return False
        if newx in self.vals:
            return False
        self._remove(old)
        self.vals[i] = newx
        self._add(newx)
        return True


def _hill(st, deadline, rng):
    """Hill-climb single-element moves using incremental evaluation."""
    cur_score = st.score()
    span = max(1, max(st.vals) - min(st.vals))
    while time.time() < deadline:
        n = len(st.vals)
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        newx = st.vals[i] + delta
        old = st.vals[i]
        if newx in st.vals:
            continue
        st.move(i, newx)
        ns = st.score()
        if ns >= cur_score:
            cur_score = ns
        else:
            st.move(i, old)
    return st, cur_score


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    sizes = list(range(8, 30)) + [35, 40, 50, 60]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 12:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        st = State(sorted(set(int(x) for x in a)))
        t_end = min(deadline - 12, time.time() + 0.8)
        st, ps = _hill(st, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = sorted(st.vals)
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        st = State(cur)
        t_end = min(deadline, time.time() + 3.0)
        st, cs = _hill(st, t_end, rng)
        if cs > cur_score:
            cur = sorted(st.vals)
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-30, 30)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
