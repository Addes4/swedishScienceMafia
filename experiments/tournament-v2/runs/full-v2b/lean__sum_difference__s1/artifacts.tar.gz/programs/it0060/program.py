# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _score_from_counts(dc, sc, n):
    if sc < 2 or n < 2:
        return 0.0
    return math.log(dc) / math.log(sc) + (1 - 1 / n) / 100


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


class _Inc:
    """Incremental multiplicities of differences and sums."""

    def __init__(self, a):
        self.a = list(a)
        self.d = {}
        self.s = {}
        self._add_all()

    def _add_all(self):
        a = self.a
        n = len(a)
        for i in range(n):
            ai = a[i]
            for j in range(n):
                if i != j:
                    v = ai - a[j]
                    self.d[v] = self.d.get(v, 0) + 1
                v = ai + a[j]
                self.s[v] = self.s.get(v, 0) + 1

    def remove(self, x):
        a = self.a
        d = self.d
        s = self.s
        for y in a:
            if y != x:
                v = x - y
                c = d[v] - 1
                if c:
                    d[v] = c
                else:
                    del d[v]
                v = y - x
                c = d[v] - 1
                if c:
                    d[v] = c
                else:
                    del d[v]
            v = x + y
            c = s[v] - 1
            if c:
                s[v] = c
            else:
                del s[v]

    def add(self, x):
        a = self.a
        d = self.d
        s = self.s
        for y in a:
            if y != x:
                d[x - y] = d.get(x - y, 0) + 1
                d[y - x] = d.get(y - x, 0) + 1
            s[x + y] = s.get(x + y, 0) + 1

    def score(self):
        return _score_from_counts(len(self.d), len(self.s), len(self.a))


def _sidon(n, rng):
    """Build a greedy Sidon-like set on a short interval (dense differences)."""
    a = [0, 1]
    seen_d = {1, -1}
    x = 1
    for _ in range(n - 2):
        found = False
        for step in range(1, 400):
            y = x + step
            new_d = []
            ok = True
            for b in a:
                dd = y - b
                if dd in seen_d or -dd in seen_d:
                    ok = False
                    break
                new_d.append(dd)
            if ok:
                for b in a:
                    seen_d.add(y - b)
                    seen_d.add(b - y)
                a.append(y)
                x = y
                found = True
                break
        if not found:
            x += 1
            a.append(x)
    return a


def _hill(inc, deadline, rng):
    """Incremental single-element hill-climb on true score."""
    t = time.time()
    cs = inc.score()
    a = inc.a
    n = len(a)
    if n < 2:
        return inc, cs
    span = max(1, max(a) - min(a))
    while time.time() < deadline:
        if time.time() - t > 0.05:
            t = time.time()
            span = max(1, max(inc.a) - min(inc.a))
        i = rng.randrange(n)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        old = inc.a[i]
        new = old + delta
        if new in inc.s:  # placeholder, replaced below
            pass
        inc.remove(old)
        # temporarily not in list
        inc.a[i] = new
        inc.add(new)
        ns = inc.score()
        if ns >= cs:
            cs = ns
        else:
            inc.remove(new)
            inc.a[i] = old
            inc.add(old)
    return inc, cs


def _grow(n, rng):
    a = [0]
    for _ in range(n - 1):
        cur = a
        curd = set()
        curs = set()
        for i in range(len(cur)):
            for j in range(len(cur)):
                curd.add(cur[i] - cur[j])
                curs.add(cur[i] + cur[j])
        cands = set()
        for base in a:
            for d in range(1, 24):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in a]
        rng.shuffle(cands)
        cands = cands[:400]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(int(x) for x in a))
        if len(a) < 2:
            return
        s, _, _ = _eval(np.array(a, dtype=np.int64))
        if s > best_score:
            best_score = s
            best = list(a)

    # Seed with scaled Sidon-like sets of various sizes/scales.
    for n in [12, 16, 20, 24, 28, 32, 40, 50]:
        base = _sidon(n, rng)
        span = max(base) if base else 1
        for scale in [1, 2, 3, 5, 8, 13, 21]:
            a = [x * scale for x in base]
            consider(a)
        t_end = min(deadline - 30, time.time() + 1.5)
        inc = _Inc(a)
        inc, _ = _hill(inc, t_end, rng)
        consider(inc.a)
        if time.time() > deadline - 30:
            break

    if best is None:
        best = [0, 1, 3, 7, 12]

    # Refine the best with incremental hill-climb and random dilations.
    while time.time() < deadline - 1:
        cur = list(best)
        n = len(cur)
        if rng.random() < 0.5:
            k = rng.choice([1, 2, 3])
            cur = [x * k for x in cur]
        else:
            for _ in range(rng.randint(1, max(1, n // 6))):
                j = rng.randrange(len(cur))
                cur[j] += rng.randint(-50, 50)
            cur = sorted(set(cur))
        inc = _Inc(cur)
        t_end = min(deadline - 1, time.time() + 4.0)
        inc, cs = _hill(inc, t_end, rng)
        consider(inc.a)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
