# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _seed(idx, rng):
    """Return a candidate integer list for seed type idx."""
    kind = idx % 6
    if kind == 0:
        # geometric-like progression (superincreasing -> many diffs, few sums)
        n = rng.randint(8, 22)
        base = rng.choice([2, 3])
        a, x = [], 0
        cur = 1
        for _ in range(n):
            x += cur
            a.append(x)
            cur *= base
        return a
    if kind == 1:
        # Sturmian / Beatty sequence floor(k*alpha)
        n = rng.randint(10, 40)
        alpha = rng.choice([1.618034, 2.618034, 1.754878, 2.414214, 1.324718])
        return [int(math.floor(k * alpha)) for k in range(n)]
    if kind == 2:
        # Sidon-like greedy: avoid equal sums
        n = rng.randint(8, 25)
        a = [0]
        used = {0}
        x = 0
        while len(a) < n:
            x += rng.randint(1, 5)
            ok = True
            for u in a:
                for v in a:
                    if (x + u) in used:
                        ok = False
                        break
                if not ok:
                    break
            if ok:
                a.append(x)
                for u in a:
                    used.add(x + u)
        return a
    if kind == 3:
        # random distinct small integers, then sorted
        n = rng.randint(8, 25)
        return sorted(rng.sample(range(0, 4 * n), n))
    if kind == 4:
        # Beatty + scaling variants
        n = rng.randint(10, 35)
        alpha = rng.uniform(1.3, 3.0)
        scale = rng.choice([1, 1, 2])
        return sorted(int(math.floor(k * alpha * scale)) for k in range(n))
    # kind 5: arithmetic patches (evenly spaced) to test sparse sums
    n = rng.randint(8, 20)
    step = rng.randint(2, 9)
    return [i * step for i in range(n)]


def _climb(a, deadline, rng):
    """Steepest-ascent hill-climb on integer set, maximizing true score."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        improved = False
        idxs = list(range(cur.size))
        rng.shuffle(idxs)
        for i in idxs:
            if time.time() >= deadline:
                break
            base_i = int(cur[i])
            best_delta = 0
            best_local = cs
            steps = [max(1, span // k) for k in (2, 3, 4, 6, 10)]
            cand_deltas = set()
            for st in steps:
                for s in (st, -st, 1, -1):
                    cand_deltas.add(s)
            cand_deltas.add(0)
            for delta in cand_deltas:
                if delta == 0:
                    continue
                cand = cur.copy()
                cand[i] = base_i + delta
                if np.unique(cand).size != cand.size:
                    continue
                cand = np.sort(cand)
                ns, _, _ = _eval(cand)
                if ns > best_local:
                    best_local = ns
                    best_delta = delta
            if best_delta != 0:
                cur[i] = base_i + best_delta
                cur = np.sort(cur)
                cs = best_local
                span = max(1, int(cur.max() - cur.min()))
                improved = True
        if not improved:
            break
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240517)
    best = None
    best_score = -1.0

    idx = 0
    while time.time() < deadline - 20:
        a = _seed(idx, rng)
        idx += 1
        arr = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
        if arr.size < 2:
            continue
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 20, time.time() + 1.2)
        pol, ps = _climb(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _climb(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            # escape: perturb a few elements
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 6)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-span_adjust(arr), span_adjust(arr))
                arr = np.unique(np.sort(arr))
                if arr.size >= 2:
                    cur = arr.tolist()
                    cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))


def span_adjust(arr):
    r = int(arr.max() - arr.min())
    return max(1, r // 4)
# EVOLVE-BLOCK-END

