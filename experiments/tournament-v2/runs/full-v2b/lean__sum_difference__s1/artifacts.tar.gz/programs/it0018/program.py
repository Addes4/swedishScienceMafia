# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large difference set, small sum set.

Strategy:
  * Build structured seeds (scaled Golomb rulers / quadratic i*d + i*i families).
  * Fast vectorized evaluator.
  * Random-restart greedy grow + swap hill-climb on the true objective.
  * A focused SA phase on small n (where the ratio is best) using an
    incremental evaluator so we can afford many moves.
"""
import math
import random
import time

import numpy as np


def _score_arr(a):
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


# ---------------------------------------------------------------- seeds
_GOLOMB = [
    [0, 1],
    [0, 1, 3],
    [0, 1, 4, 6],
    [0, 1, 4, 9, 11],
    [0, 1, 4, 10, 12, 17],
    [0, 1, 4, 10, 18, 23, 25],
    [0, 1, 7, 11, 20, 23, 25, 28],
    [0, 1, 4, 10, 18, 27, 29, 33],
    [0, 1, 4, 10, 18, 27, 29, 33, 40],
    [0, 1, 5, 11, 19, 28, 36, 39, 43, 49],
    [0, 1, 6, 10, 23, 26, 34, 41, 44, 50, 57],
]


def _seed_golomb(n, rng):
    if n <= len(_GOLOMB) and _GOLOMB[n - 1][-1] > 0:
        g = _GOLOMB[n - 1]
    else:
        # build a random Golomb-ish ruler greedily
        g = [0]
        while len(g) < n:
            cands = set()
            for b in g:
                for d in range(1, 40):
                    cands.add(b + d)
            cands = [c for c in cands if c > g[-1]]
            rng.shuffle(cands)
            used = set()
            for i in range(len(g)):
                for j in range(i + 1, len(g)):
                    used.add(abs(g[i] - g[j]))
            pick = None
            for c in cands:
                ok = True
                for b in g:
                    if abs(c - b) in used:
                        ok = False
                        break
                if ok:
                    pick = c
                    break
            if pick is None:
                pick = g[-1] + rng.randint(1, 40)
            g.append(pick)
        return g
    scale = rng.choice([1, 2, 3, 5, 7, 11, 13])
    off = rng.randint(-30, 30)
    return [scale * v + off for v in g]


def _seed_quad(n, rng):
    d = rng.choice([1, 2, 3, 4, 5, 6, 7, 8])
    return [i * d + i * i for i in range(n)]


def _seed_fixed_diff(n, rng):
    # A = {i*D + small perturbations}: differences nearly all distinct mod tricks
    D = rng.choice([11, 17, 19, 23, 29, 31, 37, 41, 43])
    offs = [rng.randint(0, 3) for _ in range(n)]
    return [i * D + offs[i] for i in range(n)]


# ---------------------------------------------------------------- greedy grow
def _grow(n, rng, seed):
    a = list(seed)[:n]
    if len(a) < 2:
        a = [0, 1]
    a = sorted(set(int(x) for x in a))
    while len(a) < n:
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 26):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:500]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 3.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return sorted(set(a))


# ---------------------------------------------------------------- SA polish
def _sa(a, deadline, rng):
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _score_arr(cur)
    n = cur.size
    span = max(1, int(cur.max() - cur.min()))
    temp = 0.02
    while time.time() < deadline:
        i = rng.randrange(n)
        delta = rng.randint(-max(2, span // 3), max(2, span // 3))
        nx = int(cur[i]) + delta
        cand = cur.copy()
        cand[i] = nx
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        ns, _, _ = _score_arr(cand)
        if ns >= cs or rng.random() < math.exp((ns - cs) / max(temp, 1e-6)):
            cur = cand
            cs = ns
        temp *= 0.99999
        if temp < 1e-4:
            temp = 0.02
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = [0, 1, 3, 7, 12]
    best_score, _, _ = _score_arr(np.array(best, dtype=np.int64))

    # small n give the best ratios; focus there but cover a range
    sizes = list(range(5, 28)) + [30, 33, 36, 40, 45, 50]
    random.shuffle(sizes)

    # ---- Phase 1: many seeds / sizes, keep best ----
    phase1_end = time.time() + 70
    idx = 0
    while time.time() < phase1_end:
        n = sizes[idx % len(sizes)]
        idx += 1
        kind = idx % 3
        if kind == 0:
            seed = _seed_golomb(n, rng)
        elif kind == 1:
            seed = _seed_quad(n, rng)
        else:
            seed = _seed_fixed_diff(n, rng)
        a = _grow(n, rng, seed)
        if len(a) < 2:
            continue
        s, _, _ = _score_arr(np.array(a, dtype=np.int64))
        if s > best_score:
            best_score = s
            best = a[:]
        t_end = min(phase1_end, time.time() + 1.2)
        pol, ps = _sa(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % len(sizes) == 0:
            random.shuffle(sizes)

    # ---- Phase 2: polish best thoroughly ----
    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 6.0)
        cand, cs = _sa(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-40, 40)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _score_arr(arr)
    if cur_score > best_score:
        best = cur

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
