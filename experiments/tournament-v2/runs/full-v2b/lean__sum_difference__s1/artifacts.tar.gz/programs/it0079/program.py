# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A|.

Strategy: build dense Sidon-like sets on a compact interval (so |A-A| is
maximal for the span) and hill-climb single elements on the true score.
Evaluation uses big-integer bitsets for exact incremental counting.
"""
import math
import random
import time

import numpy as np


def _score(nd, ns, n):
    if ns < 2 or n < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _counts(a):
    """Exact |A-A| and |A+A| via numpy."""
    a = np.asarray(a, dtype=np.int64)
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return d, s


def _grow(n, rng):
    """Greedy minimal-span near-Sidon: prefer adding element that keeps the
    sums set small while enlarging the difference set."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = np.unique(cur[:, None] - cur[None, :])
        curs = np.unique(cur[:, None] + cur[None, :])
        curd_s = set(curd.tolist())
        curs_s = set(curs.tolist())
        lo = int(cur.min())
        hi = int(cur.max())
        cands = set()
        # candidates near existing elements and extending the ends
        for base in a:
            for d in range(1, 40):
                cands.add(base + d)
                cands.add(base - d)
        cands.add(hi + 1)
        cands.add(lo - 1)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        best_x = None
        best_val = None
        for x in cands[:400]:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd_s or (y - x) not in curd_s:
                    newd += 1
                if (x + y) not in curs_s:
                    news += 1
            val = newd * 3.0 - news * 2.0
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _hill(a, deadline, rng):
    """Single-element hill-climb on true score using numpy counts."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cd, cs = _counts(cur)
    csc = _score(cd, cs, cur.size)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        cand = cur.copy()
        cand[i] += delta
        if np.unique(cand).size != cand.size:
            continue
        nd, ns = _counts(cand)
        nsc = _score(nd, ns, cand.size)
        if nsc >= csc:
            cur = np.sort(cand)
            csc = nsc
    return cur, csc


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)

    best = None
    best_score = -1.0

    def consider(arr):
        nonlocal best, best_score
        arr = np.unique(np.asarray(arr, dtype=np.int64))
        if arr.size < 2:
            return
        nd, ns = _counts(arr)
        sc = _score(nd, ns, arr.size)
        if sc > best_score:
            best_score = sc
            best = arr.tolist()

    sizes = list(range(10, 40)) + [45, 50, 60, 70]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 10:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        consider(a)
        t_end = min(deadline - 10, time.time() + 0.8)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 6)
                span = max(1, int(arr.max() - arr.min()))
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-max(2, span // 4), max(2, span // 4))
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                if cur and len(cur) >= 2:
                    nd, ns = _counts(np.array(cur, dtype=np.int64))
                    cur_score = _score(nd, ns, len(cur))

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
