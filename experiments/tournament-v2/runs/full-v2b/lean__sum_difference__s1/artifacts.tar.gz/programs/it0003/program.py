# EVOLVE-BLOCK-START
"""Construction based on greedy Sidon-like sets + ratio-direct local search."""
import math
import random
import time


def _diffs_sums(a):
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return diffs, sums


def _score(a):
    if len(a) < 2:
        return 0.0
    diffs, sums = _diffs_sums(a)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _greedy_sidon(n, M):
    """Greedy B_2 set in [0, M): pairwise sums all distinct."""
    S = set()
    A = []
    # candidate pool
    cands = list(range(0, M))
    random.shuffle(cands)
    used_sums = set()
    for x in cands:
        ok = True
        new_sums = []
        for y in A:
            for z in A:
                s = y + z
                if s in used_sums or s in new_sums:
                    pass
        # check x+y and 2x collisions
        seen = set(used_sums)
        for y in A:
            s = x + y
            if s in seen:
                ok = False
                break
            seen.add(s)
        if ok and (2 * x) not in seen:
            for y in A:
                seen.add(x + y)
            seen.add(2 * x)
            used_sums = seen
            A.append(x)
        if len(A) >= n:
            break
    return A


def _greedy_ratio(n):
    """Greedy maximizing new differences minus penalty for new sums."""
    a = [0]
    used = {0}
    while len(a) < n:
        best_x = None
        best_val = None
        cands = []
        for base in a:
            for d in range(1, 40):
                cands.append(base + d)
                cands.append(base - d)
        cands = list(set(cands) - used)
        random.shuffle(cands)
        cands = cands[:300]
        dset = set()
        sset = set()
        for i in range(len(a)):
            for j in range(len(a)):
                sset.add(a[i] + a[j])
                dset.add(a[i] - a[j])
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in dset:
                    newd += 1
                if (x + y) not in sset:
                    news += 1
            val = newd - 3.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
        used.add(best_x)
    return a


def _local_search(a, deadline):
    cur = a[:]
    cs = _score(cur)
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5 and len(cand) > 3:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2, -3, 3, -5, 5, -8, 8])
            if len(set(cand)) != len(cand):
                continue
        else:
            # random offset of a point
            i = random.randrange(len(cand))
            cand[i] += random.randint(-40, 40)
            if len(set(cand)) != len(cand):
                continue
        s = _score(cand)
        if s >= cs:
            cur, cs = cand, s
    return cur, cs


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Strategy 1: greedy ratio constructions of various sizes
    for n in (12, 14, 16, 18, 20, 24, 28, 32):
        a = _greedy_ratio(n)
        if a:
            ls, s = _local_search(a, min(deadline, time.time() + 2.0))
            if s > best_score:
                best_score, best = s, ls[:]

    # Strategy 2: Sidon sets in modulus M then embed
    for n in (10, 12, 14, 16, 18, 20):
        M = 4 * n * n
        a = _greedy_sidon(n, M)
        if len(a) >= 3:
            ls, s = _local_search(a, min(deadline, time.time() + 2.0))
            if s > best_score:
                best_score, best = s, ls[:]

    # Strategy 3: random restarts of greedy ratio
    while time.time() < deadline:
        n = random.randint(8, 30)
        a = _greedy_ratio(n)
        if a:
            ls, s = _local_search(a, min(deadline, time.time() + 0.8))
            if s > best_score:
                best_score, best = s, ls[:]

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    return sorted(set(best))
# EVOLVE-BLOCK-END
