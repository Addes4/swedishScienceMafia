# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _count_sums_diffs(a):
    """Return (ndiff, nsum) for int array a using fast unique."""
    n = a.size
    if n < 1:
        return 0, 0
    diffs = (a[:, None] - a[None, :]).ravel()
    sums = (a[:, None] + a[None, :]).ravel()
    nd = np.unique(diffs).size
    ns = np.unique(sums).size
    return int(nd), int(ns)


def _score(nd, ns, n):
    if ns < 2 or n < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100.0


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return -1.0, 0, 0
    nd, ns = _count_sums_diffs(a)
    return _score(nd, ns, n), nd, ns


def _seed_powers2(n, rng):
    """Powers of 2 give large difference set."""
    return [1 << i for i in range(n)]


def _seed_sidon(n, rng):
    """Greedy Sidon set (all pairwise sums distinct) -> |A+A| = n(n+1)/2."""
    a = [0]
    sums = {0}
    while len(a) < n:
        best_x = None
        best_val = None
        for _ in range(200):
            x = rng.randint(0, 40 * n)
            if x in a:
                continue
            new = 0
            ok = True
            for y in a:
                s = x + y
                if s in sums:
                    ok = False
                    break
            if not ok:
                continue
            val = x
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            best_x = rng.randint(0, 60 * n)
            while best_x in a:
                best_x += 1
        for y in a:
            sums.add(best_x + y)
        sums.add(best_x + best_x)
        a.append(best_x)
    return a


def _seed_dense(n, rng):
    """Dense-ish interval, sums bounded."""
    start = rng.randint(-5, 5)
    return list(range(start, start + n))


def _seed_mixed(n, rng):
    """Powers of 2 scaled down plus small offsets."""
    out = []
    v = 1
    for i in range(n):
        out.append(v)
        v = v * 2 if i % 3 == 2 else v + rng.randint(1, 3)
    return out


def _hill(cur, deadline, rng):
    cur = np.array(sorted(set(int(x) for x in cur)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    ns, _, _ = _eval(cur)
    cs = ns
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        scale = rng.choice([1, 2, 4, 8, 16, max(1, span // 8)])
        delta = rng.randint(-scale, scale)
        if delta == 0:
            delta = 1
        cand = cur.copy()
        cand[i] += delta
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        val, _, _ = _eval(cand)
        if val >= cs:
            cur = cand
            cs = val
    return cur, cs


def solve():
    deadline = time.time() + 110
    rng = random.Random(20240117)
    best = None
    best_score = -1.0

    try:
        seeds = []
        for n in [8, 12, 16, 20, 25, 30, 40, 50]:
            seeds.append(_seed_powers2(n, rng))
            seeds.append(_seed_sidon(n, rng))
            seeds.append(_seed_dense(n, rng))
            seeds.append(_seed_mixed(n, rng))

        # Evaluate all seeds first
        for a in seeds:
            if time.time() > deadline - 20:
                break
            arr = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
            if arr.size < 2:
                continue
            s, _, _ = _eval(arr)
            if s > best_score:
                best_score = s
                best = arr.tolist()

        idx = 0
        while time.time() < deadline - 15:
            a = seeds[idx % len(seeds)]
            idx += 1
            t_end = min(deadline - 15, time.time() + 3.0)
            pol, ps = _hill(a, t_end, rng)
            if ps > best_score:
                best_score = ps
                best = pol.tolist()

        if best is None:
            best = [0, 1, 3, 7, 12, 20]

        cur = sorted(set(int(x) for x in best))
        cur_score = best_score
        while time.time() < deadline:
            t_end = min(deadline, time.time() + 2.0)
            cand, cs = _hill(cur, t_end, rng)
            if cs > cur_score:
                cur = cand.tolist()
                cur_score = cs
            else:
                arr = np.array(cur, dtype=np.int64)
                if arr.size:
                    k = max(1, arr.size // 6)
                    for _ in range(rng.randint(1, k)):
                        j = rng.randrange(arr.size)
                        arr[j] += rng.randint(-20, 20)
                    arr = np.unique(np.sort(arr))
                    cur = arr.tolist()
                    cur_score, _, _ = _eval(arr)
    except Exception:
        pass
    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
