# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A| via Sidon-like two-block sets."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _count(a):
    """Fast (ndiff, nsum) count using numpy unique on 1D arrays."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0, 0
    # differences
    idx = np.arange(n)
    d = a[idx[:, None]] - a[idx[None, :]]
    # sums with i<=j symmetric
    s = a[idx[:, None]] + a[idx[None, :]]
    return np.unique(d).size, np.unique(s).size


def _sidon_greedy(n, rng, limit=None):
    """Build a Sidon-ish set: few repeated sums and differences."""
    a = [0]
    sums = {0}
    diffs = {0}
    span = max(50, n * n * 2)
    if limit is not None:
        span = limit
    for _ in range(n - 1):
        best = None
        best_cost = None
        for _try in range(60):
            x = rng.randint(1, span)
            if x in a:
                continue
            newsum = 0
            newdiff = 0
            for y in a:
                if (x + y) in sums:
                    newsum += 1
                if (x - y) in diffs or (y - x) in diffs:
                    newdiff += 1
            cost = newsum * 3 + newdiff
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best = x
        if best is None:
            break
        x = best
        for y in a:
            sums.add(x + y)
            diffs.add(x - y)
            diffs.add(y - x)
        sums.add(x + x)
        a.append(x)
    a = sorted(set(a))
    return np.array(a, dtype=np.int64)


def _two_block(n, rng):
    """Two copies of a Sidon set offset so cross sums collapse."""
    half = max(2, n // 2)
    base = _sidon_greedy(half, rng)
    if base.size < 2:
        return base
    span = int(base.max() - base.min())
    # offset K a bit larger than span so set is still spread but sums collide
    K = span + rng.randint(1, max(2, span // 2))
    a = np.concatenate([base, base + K])
    a = np.unique(np.sort(a))
    return a


def _hill(a, deadline, rng):
    """Hill-climb moving single elements, maximizing true score."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        step = max(1, span // rng.choice([2, 3, 4, 6, 8]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        cand = cur.copy()
        cand[i] += delta
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        ns, _, _ = _eval(cand)
        if ns >= cs:
            cur = cand
            cs = ns
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240607)
    best = None
    best_score = -1.0

    sizes = list(range(8, 26)) + [30, 35, 40, 48, 56, 64]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 15:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _two_block(n, rng)
        if a.size < 2:
            continue
        s, _, _ = _eval(a)
        if s > best_score:
            best_score = s
            best = a.tolist()
        t_end = min(deadline - 15, time.time() + 0.6)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 3.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-30, 30)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
