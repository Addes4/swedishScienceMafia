# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _counts(a):
    """Distinct difference and sum counts using numpy."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return int(d), int(s)


def _grow(n, rng):
    """Greedy: build a by minimizing new sums while maximizing new diffs."""
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        cands = set()
        for base in a:
            for d in range(1, 24):
                cands.add(base + d)
                cands.add(base - d)
        aset = set(a)
        cands = [c for c in cands if c not in aset]
        rng.shuffle(cands)
        cands = cands[:500]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _hill(a, deadline, rng):
    """Fast hill-climb moving single elements, maximizing true score.

    Uses a cached (ndiff, nsum) and recomputes counts only via _counts,
    but tries multiple candidate deltas per pick to accept more moves.
    """
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    span = max(1, int(cur.max() - cur.min()))
    di, si = _counts(cur)

    while time.time() < deadline:
        i = rng.randrange(cur.size)
        base = int(cur[i])
        step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
        cand_best = None
        cand_best_score = cs
        cand_best_counts = (di, si)
        # try several deltas around the current element
        for _ in range(6):
            delta = rng.randint(-step, step)
            if delta == 0:
                delta = 1
            nb = base + delta
            cand = cur.copy()
            cand[i] = nb
            if np.unique(cand).size != cand.size:
                continue
            cand = np.sort(cand)
            nd, ns = _counts(cand)
            if ns < 2:
                continue
            sc = math.log(nd) / math.log(ns) + (1 - 1 / cand.size) / 100
            if sc >= cand_best_score:
                cand_best_score = sc
                cand_best = cand
                cand_best_counts = (nd, ns)
        if cand_best is not None:
            cur = cand_best
            cs = cand_best_score
            di, si = cand_best_counts
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    sizes = list(range(8, 30)) + [35, 40, 50, 60]
    random.shuffle(sizes)
    idx = 0

    while time.time() < deadline - 12:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _grow(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 12, time.time() + 0.6)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % (2 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    # Long focused climb on the best set found.
    cur = np.array(sorted(set(int(x) for x in best)), dtype=np.int64)
    cur_score, _, _ = _eval(cur)
    if best_score > cur_score:
        cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand
            cur_score = cs
        else:
            # perturb and re-climb (restart diversification)
            arr = cur.copy()
            if arr.size:
                k = max(1, arr.size // 6)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-40, 40)
                arr = np.unique(np.sort(arr))
                if arr.size >= 2:
                    cur = arr
                    cur_score, _, _ = _eval(cur)
        arr = np.asarray(cur, dtype=np.int64)
        if arr.size >= 2:
            sc, _, _ = _eval(arr)
            if sc > best_score:
                best_score = sc
                best = arr.tolist()

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
