# EVOLVE-BLOCK-START
"""Sets with large |A-A| and small |A+A| via Sidon-set construction."""
import math
import random
import time

import numpy as np


def _eval(a):
    """Score of integer array a. Returns (score, ndiff, nsum)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _sidon(n, rng, limit=None):
    """Greedy B_2 set: no a+b=c+d with {a,b}!={c,d}. Returns list."""
    a = []
    sums = set()
    diffs = set()
    start = 0
    if limit is None:
        limit = 4 * n * n
    cands = list(range(start, limit))
    while len(a) < n and cands:
        # try a randomized subset of candidates
        rng.shuffle(cands)
        placed = False
        for x in cands:
            ok = True
            for y in a:
                s = x + y
                if s in sums:
                    ok = False
                    break
                if x - y in diffs or y - x in diffs:
                    ok = False
                    break
            if not ok:
                continue
            # commit
            for y in a:
                sums.add(x + y)
                diffs.add(x - y)
                diffs.add(y - x)
            diffs.add(0)
            a.append(x)
            placed = True
            break
        if not placed:
            break
        cands = [c for c in cands if c != x and c not in a]
        if time.time() > _DEADLINE:
            break
    return a


def _hill_sums(a, deadline, rng):
    """Hill-climb moving single elements, keeping diffs large / sums small."""
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur
    cs, _, _ = _eval(cur)
    span = max(1, int(cur.max() - cur.min()))
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        step = max(1, span // rng.choice([4, 6, 8, 12, 16]))
        delta = rng.randint(-step, step)
        if delta == 0:
            continue
        cand = cur.copy()
        cand[i] += delta
        cand = np.unique(cand)
        if cand.size != cur.size:
            continue
        cand = np.sort(cand)
        ns, _, _ = _eval(cand)
        if ns >= cs:
            cur = cand
            cs = ns
    return cur


_DEADLINE = time.time() + 112


def solve():
    global _DEADLINE
    deadline = time.time() + 112
    _DEADLINE = deadline
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    # Try a range of Sidon sizes and intervals
    plans = []
    for n in [12, 16, 20, 24, 28, 32, 40]:
        for lim in [3 * n * n // 2, 2 * n * n, 3 * n * n]:
            plans.append((n, max(lim, n)))
    rng.shuffle(plans)

    for n, lim in plans:
        if time.time() > deadline - 20:
            break
        a = _sidon(n, rng, limit=lim)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()

    if best is None:
        best = [0, 1, 3, 7, 12]

    # Refine: try to shrink the sum set while keeping differences large
    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline - 2:
        t_end = min(deadline - 1, time.time() + 4.0)
        cand = _hill_sums(cur, t_end, rng)
        cs, _, _ = _eval(cand)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
            if cs > best_score:
                best_score = cs
                best = cur[:]
        else:
            # random restart-ish perturbation
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                j = rng.randrange(arr.size)
                arr[j] += rng.randint(-50, 50)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
