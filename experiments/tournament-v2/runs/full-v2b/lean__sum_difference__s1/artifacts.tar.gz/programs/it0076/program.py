# EVOLVE-BLOCK-START
"""Search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return int(d), int(s)


def _score(d, s, n):
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _eval(a):
    arr = np.asarray(a, dtype=np.int64)
    n = arr.size
    d, s = _counts(arr)
    return _score(d, s, n), d, s


def _grow(n, span, rng):
    """Greedy pick elements from [0, span] maximizing score."""
    avail = list(range(0, span + 1))
    rng.shuffle(avail)
    a = [avail.pop()]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(np.unique(cur[:, None] - cur[None, :]).tolist())
        curs = set(np.unique(cur[:, None] + cur[None, :]).tolist())
        best_x = None
        best_val = None
        cand = avail[: min(len(avail), 60)]
        rng.shuffle(cand)
        for x in cand:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd and (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 2.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
        avail.remove(best_x)
    return sorted(set(a))


def _hill(a, deadline, rng):
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, _, _ = _eval(cur)
    lo = int(cur.min()) - 2
    hi = int(cur.max()) + 2
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        cand = cur.copy()
        cand[i] = rng.randint(lo, hi)
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        ns, _, _ = _eval(cand)
        if ns >= cs:
            cur = cand
            cs = ns
    return cur, cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(13579)
    best = None
    best_score = -1.0

    configs = []
    for n in [12, 16, 20, 25, 30, 40, 50]:
        for span in [n, int(n * 1.3), int(n * 1.8), int(n * 2.5)]:
            configs.append((n, span))
    random.shuffle(configs)
    idx = 0

    while time.time() < deadline - 15:
        n, span = configs[idx % len(configs)]
        idx += 1
        a = _grow(n, span, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 15, time.time() + 0.8)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand.tolist()
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 6)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-20, 20)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
