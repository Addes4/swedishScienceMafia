# EVOLVE-BLOCK-START
"""Time-bounded search for sets with large |A-A| and small |A+A| using bitset evaluation."""
import math
import random
import time

import numpy as np


def solve():
    deadline = time.time() + 112
    rng = random.Random(1357911)

    OFFSET_D = 1 << 20      # shift for difference set (values in [-span, span])
    OFFSET_S = 1 << 20      # shift for sum set (values in [-span, span])
    NEG_MIN = -3000         # assumed min diff / sum coordinate
    def di(x):
        return x + OFFSET_D
    def si(x):
        return x + OFFSET_S

    def eval_sets(a):
        """Return (n_diff, n_sum) using sorted-array unique counts."""
        n = len(a)
        d = len(set(a[i] - a[j] for i in range(n) for j in range(n)))
        s = len(set(a[i] + a[j] for i in range(n) for j in range(n)))
        return d, s

    def score_of(a):
        n = len(a)
        if n < 2:
            return -1.0
        d, s = eval_sets(a)
        if s < 2:
            return -1.0
        return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s

    def bitsets(a):
        dmask = 0
        smask = 0
        for x in a:
            for y in a:
                dmask |= 1 << (x - y + OFFSET_D)
                smask |= 1 << (x + y + OFFSET_S)
        return dmask, smask

    def count(mask):
        return bin(mask).count("1")

    def hill(a, deadline_t, rng):
        a = sorted(set(a))
        n = len(a)
        if n < 2:
            return a, -1.0
        dmask, smask = bitsets(a)
        dc = count(dmask)
        sc = count(smask)
        cur = math.log(dc) / math.log(sc) + (1 - 1 / n) / 100 if sc >= 2 else -1.0
        span = max(1, a[-1] - a[0])
        it = 0
        while True:
            it += 1
            if it % 64 == 0 and time.time() > deadline_t:
                break
            i = rng.randrange(n)
            step = max(1, span // rng.choice([2, 3, 4, 6, 8, 12]))
            delta = rng.randint(-step, step)
            if delta == 0:
                delta = 1
            old = a[i]
            new = old + delta
            if new in a:
                continue
            # compute new diff/sum masks after change (need to recompute because bit masks per element)
            b = a[:]
            b[i] = new
            b.sort()
            dm2, sm2 = bitsets(b)
            dc2 = count(dm2)
            sc2 = count(sm2)
            if sc2 < 2:
                continue
            ns = math.log(dc2) / math.log(sc2) + (1 - 1 / n) / 100
            if ns >= cur:
                a = b
                dmask, smask = dm2, sm2
                dc, sc = dc2, sc2
                cur = ns
                span = max(1, a[-1] - a[0])
        return a, cur

    def grow(n, rng):
        """Greedy Sidon-like affine set on short span."""
        a = [0, 1, 3, 7]
        used = set(a[:2])
        while len(a) < n:
            cand = []
            for base in a[-6:]:
                for d in range(1, 40):
                    for x in (base + d, base - d):
                        if x not in used:
                            cand.append(x)
            rng.shuffle(cand)
            cand = cand[:200]
            best_x = None
            best_key = None
            for x in cand:
                newd = set()
                news = set()
                for y in a:
                    newd.add(x - y)
                    newd.add(y - x)
                    news.add(x + y)
                dq = len(newd - set(x - y for y in a for _ in [0]))  # rough
                # approximate: count new diffs not present in current closed set
                curd = set()
                curs = set()
                for u in a:
                    for v in a:
                        curd.add(u - v)
                        curs.add(u + v)
                nd = len(set([x - y for y in a] + [y - x for y in a]) - curd)
                nsm = len(set([x + y for y in a]) - curs)
                key = nd - 2.0 * nsm
                if best_key is None or key > best_key:
                    best_key = key
                    best_x = x
            if best_x is None:
                break
            a.append(best_x)
            used.add(best_x)
        return sorted(a)

    best = None
    best_score = -1.0

    sizes = list(range(10, 45)) + [50, 60, 80, 100]
    while time.time() < deadline - 15:
        n = rng.choice(sizes)
        a = grow(n, rng)
        if len(a) < 2:
            continue
        s = score_of(a)
        if isinstance(s, tuple):
            sc = s[0]
        else:
            sc = -1.0
        if sc > best_score:
            best_score = sc
            best = a[:]
        t_end = min(deadline - 15, time.time() + 0.5)
        polished, ps = hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = polished[:]

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand[:]
            cur_score = cs
        else:
            b = cur[:]
            k = max(1, len(b) // 8)
            for _ in range(rng.randint(1, k)):
                j = rng.randrange(len(b))
                b[j] += rng.randint(-40, 40)
            b = sorted(set(b))
            if len(b) >= 2:
                res = score_of(b)
                cur = b
                cur_score = res[0] if isinstance(res, tuple) else -1.0

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
