# EVOLVE-BLOCK-START
"""Time-bounded direct optimisation of log|A-A|/log|A+A| with incremental evaluation."""
import math
import random
import time

import numpy as np


def _score_arr(a):
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _dcounts(a):
    """Return (set of diffs, set of sums) as python sets for fast membership tests."""
    n = a.size
    if n == 0:
        return set(), set()
    d = a[:, None] - a[None, :]
    s = a[:, None] + a[None, :]
    return set(np.unique(d).tolist()), set(np.unique(s).tolist())


def _greedy_grow(n, rng):
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(_dcounts(cur)[0])
        curs = set(_dcounts(cur)[1])
        cands = set()
        for base in a:
            for d in range(1, 30):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:600]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 3.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _swap_search(a, deadline, rng):
    cur = np.array(a, dtype=np.int64)
    cs, _, _ = _score_arr(cur)
    span = max(1, int(cur.max() - cur.min()) if cur.size else 1)
    while time.time() < deadline:
        cand = cur.copy()
        i = rng.randrange(cand.size)
        cand[i] += rng.randint(-max(2, span // 4), max(2, span // 4))
        if np.unique(cand).size != cand.size:
            continue
        ns, _, _ = _score_arr(np.sort(cand))
        if ns >= cs:
            cur = np.sort(cand)
            cs = ns
    return cur, cs


def _sum_focus_search(a, deadline, rng):
    """Hill-climb that focuses on reducing |A+A| while keeping |A-A| high.

    Uses exact set membership; tries to move an element to a nearby position
    that removes at least one sum element without destroying too many diffs.
    """
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur, -1.0
    cs, cd, css = _score_arr(cur)
    span = max(1, int(cur.max() - cur.min()) if cur.size else 1)
    step = max(1, span // 8)
    while time.time() < deadline:
        # pick random index to move
        i = rng.randrange(cur.size)
        center = int(cur[i])
        lo = max(2, step // 2)
        moves = [center + rng.randint(-step, step) for _ in range(6)]
        rng.shuffle(moves)
        best_local = None
        for nx in moves:
            if nx == center:
                continue
            cand = cur.copy()
            cand[i] = nx
            if np.unique(cand).size != cand.size:
                continue
            # quick approximate: only evaluate if candidate might help
            ccand = np.sort(cand)
            ns, nd, ns_sum = _score_arr(ccand)
            key = (ns_sum, -nd)
            if best_local is None or key < best_local[0]:
                best_local = (key, ccand, ns)
        if best_local is None:
            step = max(1, step - 1)
            if step == 1:
                step = max(1, span // 8)
            continue
        key, ccand, ns = best_local
        # accept if sums decreased and diffs not much worse, or score improved
        if ns_sum_val(ns) < 0:  # placeholder never fires
            pass
        nsc, nd2, ns2 = _score_arr(ccand)
        if (ns2 < css and cd - nd2 <= max(1, cd // 20)) or nsc > cs:
            cur = ccand
            cs = nsc
            cd = nd2
            css = ns2
        else:
            # occasionally jitter step size
            if rng.random() < 0.1:
                step = max(1, min(span // 4, step + rng.choice([-1, 1])))
    return cur, cs


def ns_sum_val(_):
    return 1


def solve():
    deadline = time.time() + 112
    rng = random.Random(12345)
    best = None
    best_score = -1.0

    sizes = list(range(6, 40)) + [45, 50, 60, 70, 85, 100]
    random.shuffle(sizes)

    idx = 0
    while time.time() < deadline * 0 + (deadline - 108) and False:
        pass

    # Phase 1: greedy + swap exploration
    phase1_end = min(deadline, time.time() + 70)
    while time.time() < phase1_end:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _greedy_grow(n, rng)
        if len(a) < 2:
            continue
        s, _, _ = _score_arr(np.array(a, dtype=np.int64))
        if s > best_score:
            best_score = s
            best = a[:]
        t_end = min(phase1_end, time.time() + 0.5)
        pol, ps = _swap_search(sorted(set(a)), t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % len(sizes) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    # Phase 2: sum-set focused polishing of the best set
    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cand_score = _sum_focus_search(cur, t_end, rng)
        if cand_score > cur_score:
            cur = cand.tolist()
            cur_score = cand_score
        else:
            # restart phase 2 from a slightly perturbed copy
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 10)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-50, 50)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _score_arr(arr)
    if cur_score > best_score:
        best = cur

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
