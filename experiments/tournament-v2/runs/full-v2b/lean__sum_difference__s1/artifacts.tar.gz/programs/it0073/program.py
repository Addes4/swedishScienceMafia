# EVOLVE-BLOCK-START
"""Fast time-bounded search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _bitsets(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    o = a.min()
    a = a - o
    an = a.max()
    # diff: value in [-(an), an] -> shift an
    dm = 0
    sm = 0
    for i in range(n):
        di = a[i] - a  # range [-an, an]
        si = a[i] + a  # range [0, 2an]
        for v in di.tolist():
            dm |= 1 << (v + an)
        for v in si.tolist():
            sm |= 1 << v
    return dm, sm


def _popcount(x):
    return int(x).bit_count()


def _greedy_sidon(n, rng, span_hint=None):
    """Randomized greedy: insert values keeping span small and diffs unique-ish."""
    a = [0]
    aset = {0}
    if span_hint is None:
        span_hint = max(4, int(n * n * 0.35))
    diffs = {0}
    for _ in range(n - 1):
        cands = set()
        for base in a:
            for d in range(1, 40):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in aset]
        if not cands:
            break
        rng.shuffle(cands)
        best_x = None
        best_val = None
        for x in cands[:600]:
            newd = 0
            for y in a:
                if (x - y) not in diffs:
                    newd += 1
                if (y - x) not in diffs:
                    newd += 1
            span = max(abs(x - min(a)), abs(x - max(a)))
            val = newd - 0.15 * span
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
        aset.add(best_x)
        for y in a:
            diffs.add(best_x - y)
            diffs.add(y - best_x)
    return a


def _hill(a, deadline, rng):
    cur = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if cur.size < 2:
        return cur.tolist(), -1.0
    span = int(cur.max() - cur.min())
    cs, _, _ = _eval(cur)
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        step = max(1, span // rng.choice([3, 4, 6, 8, 12]))
        delta = rng.randint(-step, step)
        if delta == 0:
            delta = 1
        cand = cur.copy()
        cand[i] += delta
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        ns, _, _ = _eval(cand)
        if ns >= cs:
            cur = cand
            cs = ns
    return cur.tolist(), cs


def solve():
    deadline = time.time() + 112
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(10, 35)) + [40, 45, 50, 60, 70]
    idx = 0

    while time.time() < deadline - 10:
        n = sizes[idx % len(sizes)]
        idx += 1
        a = _greedy_sidon(n, rng)
        if len(a) < 2:
            continue
        arr = np.array(sorted(set(a)), dtype=np.int64)
        s, _, _ = _eval(arr)
        if s > best_score:
            best_score = s
            best = arr.tolist()
        t_end = min(deadline - 10, time.time() + 0.5)
        pol, ps = _hill(a, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol
        if idx % (3 * len(sizes)) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand
            cur_score = cs
        else:
            arr = np.array(cur, dtype=np.int64)
            if arr.size:
                k = max(1, arr.size // 6)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(arr.size)
                    arr[j] += rng.randint(-40, 40)
                arr = np.unique(np.sort(arr))
                cur = arr.tolist()
                cur_score, _, _ = _eval(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
