# EVOLVE-BLOCK-START
"""Bitset-evaluated search for sets with large |A-A| and small |A+A|."""
import math
import random
import time

import numpy as np


def _eval_bits(a):
    """Exact (score, ndiff, nsum) using shifted big-integer bitsets.

    Coordinates are assumed to be within [lo, hi]; we shift by -lo so that
    the difference set lives in [0, 2*span] and the sum set in [0, 2*span].
    """
    a = np.asarray(sorted(set(int(x) for x in a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    lo = int(a[0])
    hi = int(a[-1])
    span = hi - lo
    # difference set bits: index (d + span) for d in A - A  -> range [0, 2*span]
    D = 0
    # sum set bits: index (s - 2*lo) for s in A + A -> range [0, 2*span]
    S = 0
    lst = a.tolist()
    for x in lst:
        for y in lst:
            D |= 1 << (x - y + span)
            S |= 1 << (x + y - 2 * lo)
    nd = bin(D).count("1")
    ns = bin(S).count("1")
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def _incr_eval(lst, span_lo):
    """Incremental eval from a python list. Returns (score, nd, ns, D, S).

    span_lo is the shift reference (min coordinate). Bitsets sized to fit.
    """
    lo = min(lst)
    hi = max(lst)
    span = hi - lo
    D = 0
    S = 0
    for x in lst:
        for y in lst:
            D |= 1 << (x - y + span)
            S |= 1 << (x + y - 2 * lo)
    nd = bin(D).count("1")
    ns = bin(S).count("1")
    n = len(lst)
    if ns < 2:
        return 0.0, nd, ns, D, S
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns, D, S


def _seed_sidon(n, rng, scale):
    """Randomized greedy near-Sidon set: add elements maximizing new diffs
    relative to new sums, on a bounded span."""
    base = 0
    a = [base]
    dx = {0}
    sx = {base + base}
    for _ in range(n - 1):
        best = None
        best_val = None
        # sample candidate offsets
        cands = set()
        for _t in range(60):
            cands.add(base + rng.randint(1, scale))
        base_cur = list(a)
        for x in cands:
            if x in dx:
                continue
            nd = 0
            ns = 0
            for y in base_cur:
                if (x - y) not in dx and (y - x) not in dx:
                    nd += 1
                if (x + y) not in sx:
                    ns += 1
            val = nd - 1.8 * ns
            if best_val is None or val > best_val:
                best_val = val
                best = x
        if best is None:
            best = base + rng.randint(1, scale)
        for y in a:
            dx.add(best - y)
            dx.add(y - best)
            sx.add(best + y)
        a.append(best)
    return a


def _hill(lst, deadline, rng):
    """Single-element hill climb with anneal, evaluated by bitsets."""
    lst = sorted(set(int(x) for x in lst))
    if len(lst) < 2:
        return lst, -1.0
    cur, nd, ns, D, S = _incr_eval(lst, 0)
    cs = cur
    n = len(lst)
    span = max(lst) - min(lst)
    if span <= 0:
        span = 1
    steps = [1, 2, 3, 5, 8, 13, 21]
    while time.time() < deadline:
        i = rng.randrange(n)
        step = rng.choice(steps) * max(1, span // 40)
        if step < 1:
            step = 1
        delta = rng.randint(-step, step)
        if delta == 0:
            continue
        old = cur[i]
        new = old + delta
        if new in cur:
            continue
        cand = cur[:]
        cand[i] = new
        cand = sorted(set(cand))
        if len(cand) != n:
            continue
        cc, cnd, cns, cD, cS = _incr_eval(cand, 0)
        if cc >= cs or rng.random() < 0.02:
            cur, cs, nd, ns, D, S = cand, cc, cnd, cns, cD, cS
    return cur, cs


def solve():
    deadline = time.time() + 110
    rng = random.Random(1234567)
    best = None
    best_score = -1.0

    sizes = list(range(8, 26)) + [30, 36, 44, 55]
    idx = 0

    while time.time() < deadline - 18:
        n = sizes[idx % len(sizes)]
        idx += 1
        scale = rng.choice([n, 2 * n, 3 * n, 5 * n, 8 * n, 13 * n])
        a = _seed_sidon(n, rng, max(2, scale))
        cand = sorted(set(a))
        if len(cand) < 2:
            continue
        s, _, _ = _eval_bits(cand)
        if s > best_score:
            best_score = s
            best = cand[:]
        t_end = min(deadline - 18, time.time() + 0.8)
        pol, ps = _hill(cand, t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol[:]
        if idx % (2 * len(sizes)) == 0:
            rng.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]

    cur = sorted(set(int(x) for x in best))
    cur_score = best_score
    while time.time() < deadline:
        t_end = min(deadline, time.time() + 4.0)
        cand, cs = _hill(cur, t_end, rng)
        if cs > cur_score:
            cur = cand
            cur_score = cs
        else:
            arr = list(cur)
            if arr:
                k = max(1, len(arr) // 8)
                for _ in range(rng.randint(1, k)):
                    j = rng.randrange(len(arr))
                    arr[j] += rng.randint(-40, 40)
                arr = sorted(set(arr))
                cur = arr
                cur_score, _, _ = _eval_bits(arr)

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
