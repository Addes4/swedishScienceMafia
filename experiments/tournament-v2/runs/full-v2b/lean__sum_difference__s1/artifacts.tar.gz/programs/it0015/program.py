# EVOLVE-BLOCK-START
"""Time-bounded direct optimisation of log|A-A|/log|A+A| with fast incremental evaluation."""
import math
import random
import time

import numpy as np


def _score_arr(a):
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _diffs(a):
    return np.unique(a[:, None] - a[None, :])


def _sums(a):
    return np.unique(a[:, None] + a[None, :])


def _golomb_ruler(n):
    """Simple greedy Golomb ruler: maximize number of distinct differences."""
    a = [0, 1]
    used = {0, 1}
    diffs = {1, -1}
    while len(a) < n:
        x = a[-1] + 1
        while True:
            ok = True
            for y in a:
                dd = abs(x - y)
                if dd in used and dd != 0:
                    ok = False
                    break
            if ok:
                break
            x += 1
        for y in a:
            diffs.add(x - y)
            diffs.add(y - x)
        for y in a:
            used.add(abs(x - y))
        a.append(x)
    return a


def _greedy_grow(n, rng):
    a = [0]
    for _ in range(n - 1):
        cur = np.array(a, dtype=np.int64)
        curd = set(_diffs(cur).tolist())
        curs = set(_sums(cur).tolist())
        cands = set()
        for base in a:
            for d in range(1, 40):
                cands.add(base + d)
                cands.add(base - d)
        cands = [c for c in cands if c not in set(a)]
        rng.shuffle(cands)
        cands = cands[:600]
        best_x = None
        best_val = None
        for x in cands:
            newd = 0
            news = 0
            for y in a:
                if (x - y) not in curd or (y - x) not in curd:
                    newd += 1
                if (x + y) not in curs:
                    news += 1
            val = newd - 3.0 * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            break
        a.append(best_x)
    return a


def _swap_search(a, deadline, rng):
    """Local search directly minimizing |A+A| while keeping |A-A| large."""
    cur = np.sort(np.array(a, dtype=np.int64))
    _, cd, cs = _score_arr(cur)
    span = max(2, int(cur.max() - cur.min()) if cur.size else 2)
    step = max(2, span // 6)
    stall = 0
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        delta = rng.randint(-step, step)
        if delta == 0:
            continue
        cand = cur.copy()
        cand[i] += delta
        if np.unique(cand).size != cand.size:
            continue
        cand = np.sort(cand)
        nd = np.unique(cand[:, None] - cand[None, :]).size
        ns = np.unique(cand[:, None] + cand[None, :]).size
        if ns < 2:
            continue
        # prefer smaller sums; require diffs not to drop much
        if (nd >= cd - 1 and ns <= cs) or (nd > cd and ns <= cs + 1):
            cur, cd, cs = cand, nd, ns
            stall = 0
        else:
            stall += 1
            if stall > 200:
                step = max(2, step // 2) if step > 2 else max(2, span // 4)
                stall = 0
    sc = math.log(cd) / math.log(cs) + (1 - 1 / cur.size) / 100
    return cur, sc


def solve():
    deadline = time.time() + 112
    rng = random.Random(987654321)
    best = None
    best_score = -1.0

    sizes = list(range(6, 45)) + [50, 60, 75, 90, 110, 130]
    random.shuffle(sizes)

    idx = 0
    while time.time() < deadline:
        n = sizes[idx % len(sizes)]
        idx += 1
        mode = idx % 3
        if mode == 0:
            a = _golomb_ruler(n)
        elif mode == 1:
            a = _greedy_grow(n, rng)
        else:
            a = _greedy_grow(n, rng)
        if len(a) < 2:
            continue
        s, _, _ = _score_arr(np.array(a, dtype=np.int64))
        if s > best_score:
            best_score = s
            best = a[:]
        t_end = min(deadline, time.time() + 1.0)
        pol, ps = _swap_search(sorted(set(a)), t_end, rng)
        if ps > best_score:
            best_score = ps
            best = pol.tolist()
        if idx % len(sizes) == 0:
            random.shuffle(sizes)

    if best is None:
        best = [0, 1, 3, 7, 12]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
