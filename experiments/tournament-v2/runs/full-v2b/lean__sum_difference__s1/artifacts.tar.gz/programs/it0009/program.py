# EVOLVE-BLOCK-START
"""Incremental greedy maximizing log|A-A|/log|A+A|, sweeping target sizes."""
import math
import time


def _score(a):
    if len(a) < 2:
        return 0.0
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _grow(n, alpha):
    """Greedy build up to n elements.

    At each step pick x from a candidate pool that maximizes
    (# new differences) - alpha * (# new sums).
    """
    A = [0]
    diffs = {0}
    sums = {0}
    used = {0}
    while len(A) < n:
        # candidate pool: neighbors around existing elements
        pool = set()
        for base in A:
            for d in range(1, 60):
                if (base + d) not in used:
                    pool.add(base + d)
                if (base - d) not in used:
                    pool.add(base - d)
        if not pool:
            break
        best_x = None
        best_val = None
        for x in pool:
            newd = 0
            news = 0
            for y in A:
                if (x - y) not in diffs:
                    newd += 1
                if (x + y) not in sums:
                    news += 1
                if (y - x) not in diffs:
                    newd += 1
            val = newd - alpha * news
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        x = best_x
        for y in A:
            diffs.add(x - y)
            diffs.add(y - x)
            sums.add(x + y)
        diffs.add(0)
        A.append(x)
        used.add(x)
    return A


def solve():
    deadline = time.time() + 105
    best = None
    best_score = -1.0
    n_max = 60
    alphas = [1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0]
    for n in range(3, n_max + 1):
        for alpha in alphas:
            if time.time() > deadline:
                break
            A = _grow(n, alpha)
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A[:]
        if time.time() > deadline:
            break
    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    return sorted(set(best))
# EVOLVE-BLOCK-END
