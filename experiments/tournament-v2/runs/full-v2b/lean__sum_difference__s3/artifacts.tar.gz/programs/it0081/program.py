# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A|.

Small sets give a high ratio, so we combine:
  * a deterministic sweep over structured block families, and
  * a strong simulated-annealer over small arbitrary integer sets,
always keeping the best candidate seen.
"""
import math
import random
import time


def _counts(a):
    n = len(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100.0


def _dedup_sorted(a):
    return sorted(set(a))


def _sweep_blocks():
    """Deterministic sweep: [0,n) union {D + s*i : i in [0,m)}."""
    best = None
    best_s = -1.0
    for n in range(2, 16):
        base = list(range(n))
        for m in range(2, 16):
            for s in (1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64):
                for D in range(n, n + 40):
                    A = _dedup_sorted(base + [D + s * i for i in range(m)])
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score(A)
                    if sc > best_s:
                        best_s = sc
                        best = A
    return best, best_s


def _mutate(cur, rng, hi):
    cand = cur[:]
    r = rng.random()
    n = len(cand)
    if r < 0.45 and n > 2:
        # move an element
        i = rng.randrange(n)
        span = max(1, hi // 3)
        cand[i] += rng.randint(-span, span)
    elif r < 0.75 and n < 80:
        # add an element
        anchor = rng.choice(cand) if cand else 0
        cand.append(anchor + rng.randint(-hi, hi))
    elif r < 0.9 and n > 2:
        # remove an element
        del cand[rng.randrange(n)]
    else:
        # regenerate around a random element
        anchor = rng.choice(cand) if cand else 0
        cand = [anchor + rng.randint(-hi, hi) for _ in range(n if n > 0 else 3)]
    return _dedup_sorted(cand)


def _anneal(start, budget_end, rng, hi):
    cur = _dedup_sorted(start)
    if len(cur) < 2:
        cur = [0, 1]
    cur_s = _score(cur)
    best = cur[:]
    best_s = cur_s
    T = 0.02
    it = 0
    while True:
        it += 1
        if (it & 255) == 0 and time.time() > budget_end:
            break
        cand = _mutate(cur, rng, hi)
        if len(cand) < 2 or len(cand) > 4000:
            continue
        sc = _score(cand)
        if sc >= cur_s or rng.random() < math.exp((sc - cur_s) / max(T, 1e-9)):
            cur, cur_s = cand, sc
            if sc > best_s:
                best, best_s = cand[:], sc
        T *= 0.9997
        if T < 1e-4:
            T = 0.02
    return best, best_s


def solve():
    t0 = time.time()
    deadline = t0 + 112
    rng = random.Random(20240607)

    # starting incumbent
    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # structured deterministic sweep
    sb, ss = _sweep_blocks()
    if sb is not None and ss > best_s:
        best, best_s = sb[:], ss

    # a few more structured seeds
    seeds = [best[:], list(range(2, 12)), [0, 1, 3, 7, 15, 31, 63]]
    for n in (4, 5, 6, 7, 8):
        seeds.append(list(range(n)))
    for _ in range(30):
        n = rng.randint(3, 12)
        seeds.append([rng.randint(-200, 200) for _ in range(n)])

    for s in seeds:
        sc = _score(_dedup_sorted(s))
        if sc > best_s:
            best_s = sc
            best = _dedup_sorted(s)

    # invest remaining time in annealers
    while time.time() < deadline - 1:
        frac = (time.time() - t0) / (deadline - t0)
        if frac < 0.34:
            start = _dedup_sorted([rng.randint(-300, 300) for _ in range(rng.randint(4, 14))])
        elif frac < 0.67:
            start = best[:]
        else:
            n = rng.randint(4, 18)
            start = _dedup_sorted([rng.randint(-2000, 2000) for _ in range(n)])
        hi = max(50, max(abs(x) for x in start) if start else 100)
        cb, cs = _anneal(start, min(deadline, time.time() + 10), rng, hi)
        if cs > best_s:
            best, best_s = cb[:], cs

    return _dedup_sorted(best)
# EVOLVE-BLOCK-END
