# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeding + exact hill-climb."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


# ---------------- Golomb / Sidon block construction ----------------

def _golomb(k, rng=None):
    """Greedy Golomb ruler of order k (all pairwise differences distinct)."""
    marks = [0, 1]
    used = {1}
    while len(marks) < k:
        cand = marks[-1] + 1
        while True:
            ds = set()
            ok = True
            for m in marks:
                d = cand - m
                if d in ds or d in used:
                    ok = False
                    break
                ds.add(d)
            if ok:
                used |= ds
                used.add(cand - 0)
                marks.append(cand)
                break
            cand += 1
    return marks


def _sidon_small(k):
    """Build a small B_2 (Sidon) set of size k by greedy."""
    S = [0]
    used = set()
    while len(S) < k:
        cand = S[-1] + 1
        while True:
            new = set()
            ok = True
            for s in S:
                t = cand + s
                if t in used or t in new:
                    ok = False
                    break
                new.add(t)
            # also cand+cand
            if ok:
                new.add(2 * cand)
                S.append(cand)
                used |= new
                break
            cand += 1
    return S


# ---------------- structured seeds ----------------

def _seed_interval_sidon(rng):
    """A = {0..n-1} union (off + scale * S), S a small Sidon set."""
    n = rng.randint(6, 40)
    k = rng.randint(2, 7)
    S = _sidon_small(k)
    scale = rng.choice([n, 2 * n, 3 * n, 4 * n, 8 * n, 16 * n])
    scale = max(scale, n + 1)
    off = rng.choice([0, n, 2 * n, 4 * n, 10 * n])
    block = [off + scale * s for s in S]
    A = set(range(n)) | set(block)
    return sorted(A)


def _seed_golomb_block(rng):
    n = rng.randint(6, 30)
    k = rng.randint(2, 6)
    G = _golomb(k + max(0, k // 2))
    scale = rng.choice([n, 2 * n, 3 * n, 5 * n, 10 * n])
    scale = max(scale, n + 1)
    off = rng.choice([0, n, 3 * n, 8 * n])
    block = [off + scale * g for g in G[:k]]
    A = set(range(n)) | set(block)
    return sorted(A)


# ---------------- incremental exact scorer ----------------

class Inc:
    __slots__ = ("A", "diff", "s", "su")

    def __init__(self, a):
        self.A = list(a)
        self._rebuild()

    def _rebuild(self):
        A = self.A
        self.diff = {}
        self.su = {}
        for x in A:
            for y in A:
                d = x - y
                self.diff[d] = self.diff.get(d, 0) + 1
                t = x + y
                self.su[t] = self.su.get(t, 0) + 1

    def score(self):
        nd = len(self.diff)
        ns = len(self.su)
        n = len(self.A)
        if ns < 2 or n < 2:
            return 0.0
        return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100

    def _dec(self, d):
        c = self.diff[d]
        if c == 1:
            del self.diff[d]
        else:
            self.diff[d] = c - 1

    def _inc(self, d):
        self.diff[d] = self.diff.get(d, 0) + 1

    def _dec_s(self, t):
        c = self.su[t]
        if c == 1:
            del self.su[t]
        else:
            self.su[t] = c - 1

    def _inc_s(self, t):
        self.su[t] = self.su.get(t, 0) + 1

    def add(self, v):
        for x in self.A:
            self._inc(v - x)
            self._inc(x - v)
            self._inc_s(v + x)
            self._inc_s(x + v)
        self._inc(0)
        self._inc_s(2 * v)
        self.A.append(v)

    def remove(self, i):
        v = self.A[i]
        last = self.A.pop()
        if i != len(self.A):
            self.A[i] = last
        for x in self.A:
            self._dec(v - x)
            self._dec(x - v)
            self._dec_s(v + x)
            self._dec_s(x + v)
        self._dec(0)
        self._dec_s(2 * v)

    def move(self, i, nv):
        self.remove(i)
        self.add(nv)


def _local_polish(start, deadline, rng):
    inc = Inc(sorted(set(start)))
    best = inc.score()
    while time.time() < deadline:
        n = len(inc.A)
        if n < 2:
            break
        hi = max(abs(x) for x in inc.A) or 1
        improved = False
        # try moves on a few elements
        order = list(range(n))
        rng.shuffle(order)
        for i in order[:max(4, n // 2)]:
            if time.time() >= deadline:
                break
            cur = inc.A[i]
            span = max(1, hi // 4)
            for _ in range(6):
                nv = cur + rng.randint(-span, span)
                if nv == cur:
                    continue
                inc.move(i, nv)
                s = inc.score()
                if s > best:
                    best = s
                    improved = True
                    break
                else:
                    inc.move(i, cur)
        # try adding an element
        if n < 200:
            for _ in range(4):
                if time.time() >= deadline:
                    break
                anchor = rng.choice(inc.A)
                nv = anchor + rng.randint(-hi, hi)
                if nv in inc.A:
                    continue
                inc.add(nv)
                s = inc.score()
                if s > best:
                    best = s
                    improved = True
                else:
                    inc.remove(len(inc.A) - 1)
        if not improved:
            break
    return inc.A, best


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    seeds = []
    for n in (6, 10, 14, 20, 30, 40, 60, 80):
        seeds.append(list(range(n)))
    for _ in range(80):
        seeds.append(_seed_interval_sidon(rng))
    for _ in range(80):
        seeds.append(_seed_golomb_block(rng))

    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    attempts = 0
    while time.time() < deadline - 1:
        attempts += 1
        r = attempts % 4
        if r == 0:
            start = _seed_interval_sidon(rng)
        elif r == 1:
            start = _seed_golomb_block(rng)
        elif r == 2 and best:
            start = best[:]
        else:
            start = _seed_interval_sidon(rng)
        cand, cs = _local_polish(start, min(deadline, time.time() + 10), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
