# EVOLVE-BLOCK-START
"""Structured construction plus fast local search: AP core + geometric block."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    L = list(a)
    for x in L:
        for y in L:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build_core_and_geo(ncore, k, base):
    """AP core 0..ncore-1 plus scaled geometric block base*2^i."""
    A = set(range(ncore))
    v = 1
    for i in range(k):
        A.add(base * v)
        v *= 2
    return A


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Evaluate a broad grid of parameter choices for the structured family.
    params = []
    for ncore in [5, 8, 12, 16, 20, 30, 40, 50, 64, 80]:
        for k in [3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 18, 20]:
            for base in [100, 1000, 10000, 100000, 1000000]:
                params.append((ncore, k, base))

    for (ncore, k, base) in params:
        if time.time() > deadline:
            break
        A = _build_core_and_geo(ncore, k, base)
        if len(A) > 4000:
            continue
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A

    if best is None:
        best = set(range(16)) | {1000, 2000, 4000, 8000}
        best_score = _score(best)

    # Local search: try scaling and adding a few extra geometric/mixed points.
    cur = set(best)
    tries = 0
    while time.time() < deadline and tries < 200000:
        tries += 1
        cand = set(cur)
        r = random.random()
        if r < 0.4:
            # add a scaled geometric point
            v = random.choice([1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024])
            base = random.choice([100, 1000, 10000, 100000, 1000000])
            cand.add(base * v)
        elif r < 0.7:
            # add a point near the core
            cand.add(random.randint(0, 200))
        else:
            # random small perturbation from current top elements
            if cur:
                x = random.choice(list(cur))
                cand.add(x + random.randint(-5, 5))
        if len(cand) > 4000:
            continue
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = set(cand)
            cur = set(cand)

    return sorted(best)
# EVOLVE-BLOCK-END
