# EVOLVE-BLOCK-START
"""Construct A as an arithmetic progression core plus a dilated geometric block,
so that |A-A| grows much faster than |A+A|, then refine with a fast local search."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(n_ap, geom_terms, scale):
    """AP 0..n_ap-1 plus a dilated scaled geometric block kept far away.

    The AP gives difference/sum sets of size 2*n_ap-1 (ratio ~1).
    The geometric block {scale * p, 2p, 4p, ...} adds many widely separated
    values: its internal differences and sums are all distinct and far from
    the AP's, so they add ~k^2 to both, but the cross terms with the AP
    add ~2*n_ap*k differences while adding only ~n_ap*k sums.
    """
    a = list(range(n_ap))
    base = n_ap * scale
    p = base
    for _ in range(geom_terms):
        a.append(p)
        p *= 2
    return a


def solve():
    """Maximise log|A-A|/log|A+A|.

    Strategy: build a structured set = small arithmetic progression (tiny
    sumset) plus a far-away dilated geometric block (difference-rich), then
    locally perturb it while tracking the exact score.
    """
    best = None
    best_score = -1.0

    # Try a range of structured constructions.
    for n_ap in (2, 3, 4, 5, 6, 8, 12, 20, 32):
        for geom in (4, 8, 16, 24, 32, 48, 64):
            for scale in (2, 3, 5, 8, 13):
                a = _build(n_ap, geom, scale)
                if len(set(a)) < len(a):
                    continue
                s = _score(a)
                if s > best_score:
                    best_score = s
                    best = a[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # Local search: incremental moves around the current best.
    cur = best[:]
    cur_score = best_score
    deadline = time.time() + 100
    rng = random.Random(12345)
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.55:
            # perturb an existing element
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-1, 1) * rng.choice([1, 2, 3, 10, 100, 1000])
        elif r < 0.85:
            # add a new element (try to enlarge)
            cand.append(rng.choice([rng.randint(0, 64),
                                    cand[rng.randrange(len(cand))] * 2,
                                    cand[rng.randrange(len(cand))] * 2 + 1]))
        else:
            # remove an element
            if len(cand) > 3:
                cand.pop(rng.randrange(len(cand)))
        cand = list(set(cand))
        if len(cand) < 3:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif rng.random() < 0.05:
            cur, cur_score = best[:], best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END

