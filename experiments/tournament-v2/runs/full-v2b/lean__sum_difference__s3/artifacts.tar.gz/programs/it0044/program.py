# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via incremental exact-score hill-climb."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs) + n, len(sums)


def _seed_interval_geometric(rng):
    n = rng.randint(8, 40)
    base = set(range(n))
    k = rng.randint(2, 6)
    scale = rng.choice([n * 2, n * 3, n * 4, n * 8])
    pts = set()
    v = scale
    for _ in range(k):
        pts.add(v)
        v = int(v * rng.uniform(1.5, 2.5)) + rng.randint(0, scale)
    return sorted(base | pts)


def _seed_twoblocks(rng):
    n = rng.randint(6, 30)
    m = rng.randint(3, 20)
    s = rng.randint(n + 1, 6 * (n + m))
    A = set(range(n))
    A |= {s + i for i in range(m)}
    return sorted(A)


def _hill_climb(start, deadline, rng):
    best = list(set(start))
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.5 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 2)
            cand[i] += rng.randint(-span, span)
        elif r < 0.8:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.95 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.08:
            cur, cur_s = best[:], best_s
    return best, best_s


def _score_from_counts(nd, ns, n):
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _incremental_climb(a0, deadline, rng):
    """Maintain diff/sum multiplicities; evaluate add/remove/shift cheaply."""
    A = list(set(a0))
    if len(A) < 2:
        return A, _score(A)
    dcount = {}
    scount = {}
    for x in A:
        for y in A:
            dcount[x - y] = dcount.get(x - y, 0) + 1
            scount[x + y] = scount.get(x + y, 0) + 1
    nd = len(dcount)
    ns = len(scount)
    n = len(A)

    def add_effects(x):
        add_d = 0
        add_s = 0
        for y in A:
            if x - y not in dcount:
                add_d += 1
            if y - x not in dcount:
                add_d += 1
            if x + y not in scount:
                add_s += 1
        if 2 * x not in dcount:
            add_d += 1
        if 2 * x not in scount:
            add_s += 1
        return add_d, add_s

    best = A[:]
    best_s = _score_from_counts(nd, ns, n)
    cur_s = best_s

    while time.time() < deadline:
        r = rng.random()
        if len(A) > 2 and (r < 0.55):
            # try removing an element
            i = rng.randrange(len(A))
            x = A[i]
            rem_d = 0
            rem_s = 0
            # count how many pairs involve x uniquely
            for y in A:
                if x - y in dcount and dcount[x - y] == 1:
                    rem_d += 1
                if y - x in dcount and dcount[y - x] == 1:
                    rem_d += 1
                if x + y in scount and scount[x + y] == 1:
                    rem_s += 1
            if 2 * x in dcount and dcount[2 * x] == 1:
                rem_d += 1
            if 2 * x in scount and scount[2 * x] == 1:
                rem_s += 1
            nnd = nd - rem_d
            nns = ns - rem_s
            if nnd >= 1 and nns >= 2:
                cand_s = _score_from_counts(nnd, nns, n - 1)
                if cand_s >= cur_s:
                    for y in A:
                        dcount[x - y] -= 1
                        dcount[y - x] -= 1
                        scount[x + y] -= 1
                    dcount[2 * x] -= 1
                    scount[2 * x] -= 1
                    del A[i]
                    n -= 1
                    nd, ns = nnd, nns
                    cur_s = cand_s
                    if cand_s > best_s and n >= 2:
                        best, best_s = A[:], cand_s
                    continue
        if r < 0.85:
            # try adding an element
            anchor = rng.choice(A)
            hi = max(1, max(abs(y) for y in A))
            xt = anchor + rng.randint(-hi, hi)
            if xt in A:
                continue
            add_d, add_s = add_effects(xt)
            nnd = nd + add_d
            nns = ns + add_s
            cand_s = _score_from_counts(nnd, nns, n + 1)
            if cand_s >= cur_s and n < 4000:
                for y in A:
                    dcount[xt - y] = dcount.get(xt - y, 0) + 1
                    dcount[y - xt] = dcount.get(y - xt, 0) + 1
                    scount[xt + y] = scount.get(xt + y, 0) + 1
                dcount[2 * xt] = dcount.get(2 * xt, 0) + 1
                scount[2 * xt] = scount.get(2 * xt, 0) + 1
                A.append(xt)
                n += 1
                nd, ns = nnd, nns
                cur_s = cand_s
                if cand_s > best_s:
                    best, best_s = A[:], cand_s
                continue
        # shift an element
        if len(A) >= 2:
            i = rng.randrange(len(A))
            x = A[i]
            hi = max(1, max(abs(y) for y in A))
            nt = x + rng.randint(-hi, hi)
            if nt == x or nt in A:
                continue
            # remove x then add nt
            rem_d = 0
            rem_s = 0
            for y in A:
                if x - y in dcount and dcount[x - y] == 1:
                    rem_d += 1
                if y - x in dcount and dcount[y - x] == 1:
                    rem_d += 1
                if x + y in scount and scount[x + y] == 1:
                    rem_s += 1
            if 2 * x in dcount and dcount[2 * x] == 1:
                rem_d += 1
            if 2 * x in scount and scount[2 * x] == 1:
                rem_s += 1
            nd1 = nd - rem_d
            ns1 = ns - rem_s
            if nd1 < 1 or ns1 < 2:
                continue
            # apply removal
            for y in A:
                dcount[x - y] -= 1
                dcount[y - x] -= 1
                scount[x + y] -= 1
            dcount[2 * x] -= 1
            scount[2 * x] -= 1
            A[i] = nt
            add_d = 0
            add_s = 0
            for y in A:
                k1 = nt - y
                if dcount.get(k1, 0) == 0:
                    add_d += 1
                dcount[k1] = dcount.get(k1, 0) + 1
                k2 = y - nt
                if dcount.get(k2, 0) == 0:
                    add_d += 1
                dcount[k2] = dcount.get(k2, 0) + 1
                k3 = nt + y
                if scount.get(k3, 0) == 0:
                    add_s += 1
                scount[k3] = scount.get(k3, 0) + 1
            if dcount.get(2 * nt, 0) == 0:
                add_d += 1
            dcount[2 * nt] = dcount.get(2 * nt, 0) + 1
            if scount.get(2 * nt, 0) == 0:
                add_s += 1
            scount[2 * nt] = scount.get(2 * nt, 0) + 1
            nnd = nd1 + add_d
            nns = ns1 + add_s
            cand_s = _score_from_counts(nnd, nns, n)
            if cand_s > cur_s:
                nd, ns = nnd, nns
                cur_s = cand_s
                if cand_s > best_s:
                    best, best_s = A[:], cand_s
            else:
                # revert
                for y in A:
                    dcount[nt - y] -= 1
                    dcount[y - nt] -= 1
                    scount[nt + y] -= 1
                dcount[2 * nt] -= 1
                scount[2 * nt] -= 1
                for y in A:
                    dcount[x - y] = dcount.get(x - y, 0) + 1
                    dcount[y - x] = dcount.get(y - x, 0) + 1
                    scount[x + y] = scount.get(x + y, 0) + 1
                dcount[2 * x] = dcount.get(2 * x, 0) + 1
                scount[2 * x] = scount.get(2 * x, 0) + 1
                A[i] = x

    return best, best_s


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    rng = random.Random(99991)
    deadline = time.time() + 115

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    seeds = []
    for n in (10, 20, 40, 80):
        seeds.append(list(range(n)))
    for _ in range(60):
        seeds.append(_seed_interval_geometric(rng))
    for _ in range(60):
        seeds.append(_seed_twoblocks(rng))

    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 4 == 0:
            start = _seed_interval_geometric(rng)
        elif attempts % 4 == 1:
            start = _seed_twoblocks(rng)
        elif attempts % 4 == 2:
            start = list(range(rng.randint(5, 60)))
        else:
            start = best[:]
        remaining = deadline - time.time()
        if remaining <= 0:
            break
        sl = min(remaining, 20.0)
        cand, cs = _incremental_climb(start, time.time() + sl, rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
