# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured family + exact sweep."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _seed_interval_geometric(rng):
    n = rng.randint(8, 40)
    base = set(range(n))
    k = rng.randint(2, 6)
    scale = rng.choice([n * 2, n * 3, n * 4, n * 8])
    pts = set()
    v = scale
    for _ in range(k):
        pts.add(v)
        v = int(v * rng.uniform(1.5, 2.5)) + rng.randint(0, scale)
    return sorted(base | pts)


def _seed_twoblocks(rng):
    n = rng.randint(6, 30)
    m = rng.randint(3, 20)
    s = rng.randint(n + 1, 6 * (n + m))
    A = set(range(n))
    A |= {s + i for i in range(m)}
    return sorted(A)


def _core_sets():
    """Small difference-rich cores B (Sidon / B_2-ish)."""
    cores = []
    # classic small Sidon sets (B_2)
    cores.append([0, 1, 3, 7])          # Sidon
    cores.append([0, 1, 3, 7, 12])      # Sidon
    cores.append([0, 1, 3, 7, 15])      # Sidon-like
    cores.append([0, 1, 4, 9, 15])      # Golomb-ish
    cores.append([0, 1, 3, 8, 12, 18])
    cores.append([0, 1, 3, 7, 12, 20])
    cores.append([0, 1, 4, 10, 12, 17])
    cores.append([0, 1, 3, 7, 12, 20, 30])
    cores.append([0, 1, 3, 8, 14, 22, 30])
    cores.append([0, 1, 3, 7, 12, 20, 30, 44])
    # geometric-ish
    cores.append([0, 1, 2, 4, 8, 16, 32])
    cores.append([0, 1, 2, 4, 8, 16, 32, 64])
    cores.append([0, 1, 3, 6, 12, 24, 48])
    cores.append([0, 1, 3, 7, 15, 31, 63])
    return cores


def _sweep_exact(deadline):
    """Exact deterministic sweep over A = {0..n-1} union (r + s*B)."""
    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)
    cores = _core_sets()

    for B in cores:
        bmax = max(B)
        for n in (6, 8, 10, 12, 16, 20, 25, 32, 40, 50, 64, 80):
            if time.time() > deadline:
                return best, best_s
            base = set(range(n))
            # s scaling factor so far block spans comparable range
            for s in (1, 2, 3, 5, 8, 12, 16, 24, 32):
                span = bmax * s
                # r offsets: just beyond interval, various multiplicities
                for r in (n,
                          n + span,
                          2 * n + span,
                          3 * (n + span),
                          n * 4,
                          8 * n,
                          16 * n,
                          32 * n):
                    if time.time() > deadline:
                        return best, best_s
                    block = {r + s * b for b in B}
                    A = base | block
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score(A)
                    if sc > best_s:
                        best, best_s = sorted(A), sc
    return best, best_s


def _hill_climb(start, deadline, rng):
    best = list(set(start))
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.5 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 2)
            cand[i] += rng.randint(-span, span)
        elif r < 0.8:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.95 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            if cand:
                cand = sorted(set(cand))
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.08:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    rng = random.Random(12345)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Phase 1: deterministic exact sweep over structured family
    best, best_s = _sweep_exact(time.time() + 40)
    if time.time() >= deadline:
        return sorted(set(best))

    # Phase 2: random seeds
    seeds = []
    for n in (10, 20, 40, 80):
        seeds.append(list(range(n)))
    for _ in range(30):
        seeds.append(_seed_interval_geometric(rng))
    for _ in range(30):
        seeds.append(_seed_twoblocks(rng))
    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    # Phase 3: hill climb from best, refreshing
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 2 == 0:
            start = best[:]
        elif attempts % 4 == 1:
            start = _seed_twoblocks(rng)
        else:
            start = _seed_interval_geometric(rng)
        cand, cs = _hill_climb(start, min(deadline, time.time() + 10), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
