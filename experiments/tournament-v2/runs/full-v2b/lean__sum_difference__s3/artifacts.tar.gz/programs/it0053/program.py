# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A|.

Key idea: a long interval {0..n-1} gives |A+A|=2n-1 and |A-A|=2n-1.
Adding a few well-separated points (far apart, roughly geometric) multiplies
the number of differences while adding few new sums.  We search over the
structure A = {0..n-1} union (M + T*scale) plus local refinement.
"""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    """Return (nd, ns, n) without the bonus."""
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    da = diffs.add
    sa = sums.add
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            da(ai - aj)
            sa(ai + aj)
    return len(diffs), len(sums), n


def _full(a):
    nd, ns, n = _score_fast(a)
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _make_interval_geo(n, k, base_gap, ratio):
    """Interval {0..n-1} union geometric block starting at base_gap."""
    A = set(range(n))
    v = float(base_gap) + n
    pts = []
    for _ in range(k):
        p = int(round(v))
        pts.append(p)
        v *= ratio
    A |= set(pts)
    return sorted(A)


def _make_two_blocks(n, m, gap):
    A = set(range(n))
    A |= {gap + i for i in range(m)}
    return sorted(A)


def _incremental_improve(a, deadline, rng):
    """Local search: try moving one element, adding, or removing."""
    cur = list(set(a))
    cur_s = _full(cur)
    best, best_s = cur[:], cur_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        r = rng.random()
        cand = cur[:]
        if r < 0.45 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 3)
            cand[i] += rng.randint(-span, span)
        elif r < 0.75:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.9 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            if len(cand) > 3:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1]) * max(1, abs(cand[i]) // 2)
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _full(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.05:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    rng = random.Random(2024)
    deadline = time.time() + 110

    best = [0, 1, 2, 3, 4, 5, 6, 7]
    best_s = _full(best)

    seeds = []

    # interval + geometric block, sweep parameters
    for n in (4, 6, 8, 12, 16, 24, 32, 48):
        for k in (2, 3, 4, 5, 6, 8):
            for gap in (n * 2, n * 4, n * 8, n * 16, n * 32, n * 64):
                for ratio in (1.5, 1.8, 2.0, 2.5, 3.0):
                    seeds.append(_make_interval_geo(n, k, gap, ratio))

    # two-block sets
    for n in (4, 8, 12, 16, 24, 32):
        for m in (3, 5, 8, 12, 20):
            for gap in (n + m, 2 * n, 3 * n, 4 * (n + m), 8 * (n + m), 16 * (n + m)):
                seeds.append(_make_two_blocks(n, m, gap))

    for s in seeds:
        sc = _full(s)
        if sc > best_s:
            best, best_s = s[:], sc

    # local refinement from the best deterministic seeds
    ranked = sorted(seeds, key=lambda x: _full(x), reverse=True)[:25]
    for s in ranked:
        cand, cs = _incremental_improve(s, min(deadline, time.time() + 3.0), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    while time.time() < deadline:
        if rng.random() < 0.5:
            start = _make_interval_geo(
                rng.randint(4, 40), rng.randint(2, 8),
                rng.choice([8, 16, 32, 64, 128]), rng.uniform(1.4, 3.0))
        else:
            start = _make_two_blocks(
                rng.randint(4, 30), rng.randint(3, 20),
                rng.randint(6, 400))
        cand, cs = _incremental_improve(start, min(deadline, time.time() + 5.0), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
