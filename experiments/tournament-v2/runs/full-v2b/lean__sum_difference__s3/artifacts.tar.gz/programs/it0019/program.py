# EVOLVE-BLOCK-START
"""Construct A = (compact core) union (scaled geometric block) and tune parameters."""
import math
import time


def _stats(a):
    a = set(a)
    if len(a) < 2:
        return 0, 0, 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100
    return len(diffs), len(sums), score


def _candidate(n, k, M, geo_only=False):
    core = list(range(n))
    if geo_only:
        return core
    block = [M * (1 << j) for j in range(k)]
    return core + block


def solve():
    best = [7, 15, 18, 22, -3, -2]
    _, _, best_score = _stats(best)
    deadline = time.time() + 100
    # sweep core size n, geometric block size k, scale M
    for n in [1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 200, 300, 400, 500]:
        for k in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]:
            for M in [10 ** 3, 10 ** 5, 10 ** 7, 10 ** 9, 10 ** 11, 10 ** 13]:
                if time.time() > deadline + 100:
                    break
                cand = _candidate(n, k, M)
                if len(set(cand)) != len(cand):
                    continue
                d, s, sc = _stats(cand)
                if sc > best_score:
                    best, best_score = cand, sc
    # also try pure geometric
    for k in range(2, 26):
        cand = [1 << j for j in range(k)]
        d, s, sc = _stats(cand)
        if sc > best_score:
            best, best_score = cand, sc
    return sorted(set(best))
# EVOLVE-BLOCK-END
