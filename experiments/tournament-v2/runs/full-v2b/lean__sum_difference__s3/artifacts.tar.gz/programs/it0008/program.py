# EVOLVE-BLOCK-START
"""Local search using incremental set updates for fast, targeted optimization.

Idea: An arithmetic progression has a very small sumset but also a small difference
set (differences are multiples of the step). Union in a few large, well-spread
elements (like scaled powers of two) to blow up the difference set with many
distinct cross-differences while keeping the sumset modest. We then hill-climb
around this structured seed with very fast incremental scoring.
"""
import math
import random
import time


def _score_of(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    random.seed(12345)
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score_of(best)

    # Structured seeds: AP core + spread block
    def ap(start, step, k):
        return [start + step * i for i in range(k)]

    seeds = []
    # AP plus scaled powers of two
    for k in (5, 8, 12, 20, 30):
        for step in (1, 2, 3):
            core = ap(0, step, k)
            block = [step * (1 << j) for j in range(1, 8)]
            seeds.append(list(set(core + block)))
    # small AP plus large scattered points
    for k in (6, 10, 15):
        core = ap(0, 1, k)
        scatter = [100000 + 7919 * j for j in range(6)]
        seeds.append(list(set(core + scatter)))

    for s in seeds:
        sc = _score_of(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    cur = best[:]
    cur_score = best_score

    deadline = time.time() + 110
    # Precompute for incremental scoring
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            # perturb an element
            i = random.randrange(len(cand))
            delta = random.choice([-1, 1]) * random.choice([1, 1, 1, 2, 3, 7, 17, 31])
            cand[i] += delta
        elif r < 0.85:
            # add an element
            base = random.choice(cand)
            cand.append(base + random.choice([1, 2, 3, 5, 8, 13, 21, 34, 55, 89,
                                              144, 233, 377, 610, 987, 1597]))
        else:
            # remove an element (keep at least 2)
            if len(cand) > 5:
                del cand[random.randrange(len(cand))]

        cand = list(set(cand))
        if len(cand) < 2:
            cur = best[:]
            cur_score = best_score
            continue
        sc = _score_of(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc
        else:
            # occasional restart from best
            if random.random() < 0.02:
                cur = best[:]
                cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
