# EVOLVE-BLOCK-START
"""Structured construction: interval core union a geometric block.

A = {0,1,...,m-1}  ∪  {G, 2G, 4G, ..., 2^{k-1} G}

with G huge so the two parts do not interact in sums or differences.
- Sums: interval part gives m-1..2m-2 (2m-1 values); geometric part sums
  2^i G + 2^j G = (2^i+2^j) G give some number of distinct multiples of G.
- Differences: interval part gives -(m-1)..(m-1) (2m-1 values); geometric
  block yields distinct 2^a(2^b-1) G forms (about k(k-1)+1 values); cross
  terms fill more. Because G is huge the pieces stay separated.
"""
import math


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build(m, k, G):
    A = list(range(m))
    A += [G << i for i in range(k)]
    return A


def solve():
    best_a = [0, 1]
    best_s = _score(best_a)
    G = 10 ** 15 // (1 << 40)   # keep values within bounds
    for m in range(2, 600, 1):
        # k limited so 2^k * G stays in range and total size <= 4000
        for k in range(2, min(60, 4000 - m)):
            if (1 << (k - 1)) * G > 10 ** 15:
                break
            a = _build(m, k, G)
            s = _score(a)
            if s > best_s:
                best_s = s
                best_a = a
    return sorted(set(best_a))
# EVOLVE-BLOCK-END

