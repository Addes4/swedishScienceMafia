# EVOLVE-BLOCK-START
"""Grow A by a small interval core plus greedily-chosen sparse points that maximize differences per added sum."""
import math
import random
import time


def _dd_ss(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            sums.add(ai + aj)
            diffs.add(ai - aj)
            diffs.add(aj - ai)
    return len(diffs), len(sums)


def solve():
    best = [0, 1, 2, 3, 4, 5]
    best_d, best_s = _dd_ss(best)
    best_score = math.log(best_d) / math.log(best_s) + (1 - 1 / len(best)) / 100

    deadline = time.time() + 100
    rng = random.Random(12345)

    # sweep core sizes
    for n_core in (8, 16, 32, 64, 128, 256):
        if time.time() > deadline:
            break
        core = list(range(n_core))
        base_d, base_s = _dd_ss(core)
        cur = core[:]
        cur_d, cur_s = base_d, base_s
        cur_score = math.log(cur_d) / math.log(cur_s) + (1 - 1 / len(cur)) / 100
        if cur_score > best_score:
            best, best_d, best_s, best_score = cur[:], cur_d, cur_s, cur_score

        span = n_core * 20
        # greedily add sparse far-away points
        for _ in range(400):
            if time.time() > deadline:
                break
            improved = False
            for _try in range(30):
                p = rng.randint(-span, span * 3)
                if p in cur:
                    continue
                cand = cur + [p]
                cd, cs = _dd_ss(cand)
                ns = math.log(cd) / math.log(cs) + (1 - 1 / len(cand)) / 100
                if ns > cur_score:
                    cur, cur_d, cur_s, cur_score = cand, cd, cs, ns
                    improved = True
                    break
            if not improved:
                span = max(n_core, span // 2)
                if span <= 1:
                    break
        if cur_score > best_score:
            best, best_d, best_s, best_score = cur[:], cur_d, cur_s, cur_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
