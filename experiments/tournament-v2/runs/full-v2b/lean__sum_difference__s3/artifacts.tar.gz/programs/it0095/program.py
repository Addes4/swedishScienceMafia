# EVOLVE-BLOCK-START
"""Search for A with large |A-A| and small |A+A| using AP-block structure."""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _score(a):
    d, s, n = _stats(a)
    if n < 2 or s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _build(m, s, extras):
    """A = {s*i : i=0..m-1} union extras."""
    A = set(s * i for i in range(m))
    A |= set(extras)
    return sorted(A)


def solve():
    rng = random.Random(98765)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Deterministic sweep over AP-block family {s*i : i=0..m-1}.
    # For a pure AP with step s, sums all lie on multiples of s ->
    # |A+A| ~ 2m-1 while |A-A| ~ 2m-1 too (ratio ~1). So we want a
    # second structure that breaks sums but adds few diffs.
    # Try AP block + small interval {0..k-1} overlapping in origin.
    for m in range(3, 30):
        for s in list(range(2, 60)) + [100, 1000, 10**6]:
            for k in range(1, m + 2):
                A = set(s * i for i in range(m))
                A |= set(range(k))
                A = sorted(A)
                sc = _score(A)
                if sc > best_s:
                    best, best_s = A, sc
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Randomized local search on top of the best AP-structure found.
    cur = best[:]
    cur_s = best_s
    hi = max(1, max(abs(x) for x in cur))
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.45 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-max(1, hi // 4), max(1, hi // 4))
        elif r < 0.75:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.9 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            # scale-preserving: multiply a random element, keep others small
            if cand:
                i = rng.randrange(len(cand))
                cand[i] *= rng.choice([2, 3, 4])
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        if max(abs(x) for x in cand) > 10**15:
            continue
        sc = _score(cand)
        if sc >= cur_s:
            cur, cur_s = cand, sc
            if sc > best_s:
                best, best_s = cand[:], sc
        elif rng.random() < 0.1:
            cur, cur_s = best[:], best_s

    return sorted(set(best))
# EVOLVE-BLOCK-END
