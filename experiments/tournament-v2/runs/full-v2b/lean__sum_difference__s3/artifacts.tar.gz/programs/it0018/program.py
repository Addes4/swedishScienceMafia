# EVOLVE-BLOCK-START
"""Search for A with large difference set and small sum set.

Idea: keep a dense core (small integer span -> compact sumset) and add a few
sparse, highly spread points whose pairwise differences with everything are
mostly new while their sums overlap the core's sumset as much as possible.
We do a fast greedy/annealing search using hash sets for scoring.
"""
import math
import random
import time


def _stats(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score_from(dc, sc, n):
    if sc < 2 or dc < 2:
        return 0.0
    return math.log(dc) / math.log(sc) + (1 - 1 / n) / 100


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    dc, sc = _stats(a)
    return _score_from(dc, sc, len(a))


def solve():
    random.seed(12345)
    deadline = time.time() + 100

    # Start from a compact core that keeps the sumset small.
    core = list(range(-6, 7))
    best = core[:]
    bd, bs = _stats(best)
    best_score = _score_from(bd, bs, len(best))

    # Sparse points are large and spread; we grow the set greedily.
    # Precompute candidate scales to add.
    cur = best[:]
    cd, cs = bd, bs

    # incremental scoring helpers
    def try_add(a, dc, sc, x):
        n = len(a)
        newdiffs = set()
        newsums = set()
        for y in a:
            newdiffs.add(x - y)
            newdiffs.add(y - x)
            newsums.add(x + y)
        dc2 = dc + len([d for d in newdiffs if d not in _diffs_cache]) if False else dc
        return newdiffs, newsums

    # We'll just do full recomputation but on small sets with few additions.
    step = 1
    scales = [10 ** k for k in range(1, 15)]
    improved = True
    while time.time() < deadline and len(cur) < 4000:
        improved = False
        # Try adding each candidate scale to current set.
        for s in scales:
            for mult in (1, 2, 3, 5, 7, 11, 13):
                x = s * mult
                cand = cur + [x]
                cd2, cs2 = _stats(cand)
                sc2 = _score_from(cd2, cs2, len(cand))
                if sc2 > best_score:
                    best_score = sc2
                    best = cand[:]
                    cur = cand[:]
                    cd, cs = cd2, cs2
                    improved = True
                    break
            if improved:
                break
        if not improved:
            break

    # Refine with local search: perturb large points.
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        delta = random.choice([1, -1, 2, -2, 3, -3, 5, -5, 7, -7,
                               10, -10, 100, -100, 1000, -1000])
        cand[i] += delta
        if len(set(cand)) < len(cand):
            continue
        cd2, cs2 = _stats(cand)
        sc2 = _score_from(cd2, cs2, len(cand))
        if sc2 >= best_score:
            best_score = sc2
            best = cand[:]
            cur = cand[:]
            cd, cs = cd2, cs2

    return sorted(set(best))
# EVOLVE-BLOCK-END
