# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A|.

Structure: A = [0, n) union (M + s*[0, m)).  A dense interval keeps the sum set
tight while the shifted arithmetic block adds many new differences.  We score
with fast integer bitsets (offsets chosen large enough to avoid collisions with
negative differences), sweep the parameter family, then locally refine.
"""
import math
import random
import time


def _build(n, m, M, s):
    """Return sorted list A = [0,n) union (M + s*[0,m))."""
    A = list(range(n))
    A.extend(M + s * i for i in range(m))
    return sorted(set(A))


def _score_bitset(A):
    n = len(A)
    if n < 2:
        return 0.0
    lo = min(A)
    hi = max(A)
    # differences range in [lo-hi, hi-lo]; sums in [2*lo, 2*hi]
    doff = hi - lo
    dsize = 2 * doff + 1
    dbits = bytearray(dsize)
    soff = 2 * lo
    ssize = 2 * (hi - lo) + 1
    sbits = bytearray(ssize)
    for x in A:
        dx = x - lo
        sx = x + lo  # x - lo + ... store x+lo offset base lo
        for y in A:
            dbits[(x - y) + doff] = 1
            sbits[(x + y) - soff] = 1
    nd = sum(dbits)
    ns = sum(sbits)
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _stats(A):
    A = list(set(A))
    n = len(A)
    if n < 2:
        return 0, 0, n
    lo, hi = min(A), max(A)
    doff = hi - lo
    dbits = bytearray(2 * doff + 1)
    soff = 2 * lo
    sbits = bytearray(2 * (hi - lo) + 1)
    for x in A:
        for y in A:
            dbits[(x - y) + doff] = 1
            sbits[(x + y) - soff] = 1
    return sum(dbits), sum(sbits), n


def _score(A):
    return _score_bitset(A)


def _refine(A, deadline, rng, best_s):
    """Greedy local search adjusting n, m, M, s."""
    n = sum(1 for x in A if x < min(a for a in A if a >= 0)) if A else 1
    # recover params approximately: assume A = [0,n) union block starting at M
    A = sorted(set(A))
    # find first gap
    n2 = 1
    while n2 < len(A) and A[n2] == A[n2 - 1] + 1:
        n2 += 1
    n = n2
    block = A[n:]
    if len(block) >= 2:
        M = block[0]
        diffs = [block[i + 1] - block[i] for i in range(len(block) - 1)]
        s = min(diffs) if diffs else 1
        m = len(block)
    elif block:
        M, s, m = block[0], 1, 1
    else:
        M, s, m = n, 1, 0
    cur = _build(n, m, M, s)
    cur_s = _score(cur) if cur == A else _score(A)
    bestA = A[:]
    bestS = best_s
    while time.time() < deadline:
        cand_n = n
        cand_m = m
        cand_M = M
        cand_s = s
        r = rng.random()
        if r < 0.3:
            cand_n = max(2, n + rng.choice([-3, -2, -1, 1, 2, 3]))
        elif r < 0.55:
            cand_m = max(1, m + rng.choice([-3, -2, -1, 1, 2, 3]))
        elif r < 0.8:
            cand_M = M + rng.choice([-1, 1]) * rng.choice([1, 2, 4, 8, 16, 32, 64, n, m])
        else:
            cand_s = max(1, s + rng.choice([-2, -1, 1, 2]))
        if cand_m < 1:
            cand_m = 1
        if cand_M < cand_n:
            cand_M = cand_n
        cand = _build(cand_n, cand_m, cand_M, cand_s)
        if len(cand) < 2 or len(cand) > 4000:
            continue
        cs = _score(cand)
        if cs >= cur_s:
            n, m, M, s = cand_n, cand_m, cand_M, cand_s
            cur, cur_s = cand, cs
            if cs > bestS:
                bestA, bestS = cand[:], cs
        else:
            # occasionally adopt anyway
            if rng.random() < 0.05:
                n, m, M, s = cand_n, cand_m, cand_M, cand_s
                cur, cur_s = cand, cs
    return bestA, bestS


def solve():
    rng = random.Random(20240601)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Systematic sweep over the interval + arithmetic block family.
    for n in list(range(2, 60)) + [70, 80, 100, 120]:
        for m in range(1, 40):
            if n + m > 4000:
                break
            for s in [1, 2, 3, 4, 5]:
                for mult in [1, 2, 3, 4, 6, 8]:
                    M = n * mult + 1
                    A = _build(n, m, M, s)
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score(A)
                    if sc > best_s:
                        best, best_s = A, sc
        if time.time() > deadline * 0.5:
            break

    # Local refinement from several good starts.
    starts = [best]
    for _ in range(8):
        n = rng.randint(10, 50)
        m = rng.randint(5, 30)
        M = n * rng.randint(1, 20) + rng.randint(1, 100)
        s = rng.randint(1, 5)
        starts.append(_build(n, m, M, s))

    i = 0
    while time.time() < deadline:
        start = starts[i % len(starts)] if i < len(starts) else best
        i += 1
        cand, cs = _refine(start, min(deadline, time.time() + 8), rng, best_s)
        if cs > best_s:
            best, best_s = cand, cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
