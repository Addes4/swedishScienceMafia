# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured two-block sweep + exact bitset counter."""
import math
import random
import time

import numpy as np


def _score_set(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    lo = a[0]
    hi = a[-1]
    span = hi - lo + 1
    # use bitsets via numpy bool arrays if span small enough, else python sets
    if span <= 2_000_000:
        off = lo
        vals = np.zeros(span, dtype=bool)
        vals[np.array(a) - off] = True
        # sums bitset
        sum_lo = 2 * lo
        sum_hi = 2 * hi
        sum_span = sum_hi - sum_lo + 1
        sbits = np.zeros(sum_span, dtype=bool)
        idx = np.array(a) - off
        # compute sumset indices: (i+j) -> add offset 2*lo
        # do via outer add on indices
        si = idx[:, None] + idx[None, :]  # values in [0, 2*span)
        sbits[si.ravel()] = True
        num_sums = int(sbits.sum())
        # diff bitset
        d_lo = lo - hi
        d_hi = hi - lo
        d_span = d_hi - d_lo + 1
        dbits = np.zeros(d_span, dtype=bool)
        di = idx[:, None] - idx[None, :] + (hi - lo)  # shift to >=0
        dbits[di.ravel()] = True
        num_diffs = int(dbits.sum())
    else:
        diffs = set()
        sums = set()
        for x in a:
            for y in a:
                diffs.add(x - y)
                sums.add(x + y)
        num_diffs = len(diffs)
        num_sums = len(sums)
    if num_sums < 2:
        return 0.0, num_diffs, num_sums
    sc = math.log(num_diffs) / math.log(num_sums) + (1 - 1 / n) / 100
    return sc, num_diffs, num_sums


def _score(a):
    return _score_set(a)[0]


def _two_block(n, m, s, M):
    A = list(range(n))
    A += [M + s * i for i in range(m)]
    return A


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Deterministic sweep over two-block family: A = [0,n) union {M + s*i}
    # also include negative variants to break symmetry at small sizes
    # Focus on small n, m (small sets give high ratio) but allow larger for bonus.
    results = []

    for n in range(2, 26):
        for m in range(2, 26):
            for s in range(1, 13):
                for M in (n, n + 1, n + 2, n * s, n * s + 1):
                    if M <= n - 1:
                        continue
                    A = _two_block(n, m, s, M)
                    sc, nd, ns = _score_set(A)
                    results.append((sc, nd, ns, tuple(A)))

    # explicit interval + scaled interval: A = [0,n) union {M + s*i}
    # also try A = [0,n) union {M - s*i} (reflect to share 0 region)
    for n in range(2, 20):
        for m in range(2, 20):
            for s in range(1, 10):
                for M in range(n, n + 8):
                    A = list(range(n)) + [M + s * i for i in range(m)]
                    sc, nd, ns = _score_set(A)
                    results.append((sc, nd, ns, tuple(A)))

    results.sort(key=lambda r: r[0], reverse=True)

    for sc, nd, ns, A in results[:50]:
        if sc > best_s:
            best = list(A)
            best_s = sc

    # local hill-climb around best seeds using exact scorer
    def climb(start, tlim):
        cur = list(set(start))
        cur_s = _score(cur)
        hi = max(abs(x) for x in cur) if cur else 1
        while time.time() < tlim:
            cand = cur[:]
            r = rng.random()
            if r < 0.5 and cand:
                i = rng.randrange(len(cand))
                span = max(1, hi // 4)
                cand[i] += rng.randint(-span, span)
            elif r < 0.8:
                anchor = rng.choice(cand) if cand else 0
                cand.append(anchor + rng.randint(-hi, hi))
            elif r < 0.95 and len(cand) > 3:
                del cand[rng.randrange(len(cand))]
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 4000:
                continue
            s = _score(cand)
            if s >= cur_s:
                cur, cur_s = cand, s
        return cur, cur_s

    top_seeds = [list(A) for sc, nd, ns, A in results[:8]]
    top_seeds.append(best[:])
    i = 0
    while time.time() < deadline:
        seed = top_seeds[i % len(top_seeds)]
        i += 1
        cand, cs = climb(seed, min(deadline, time.time() + 8))
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
