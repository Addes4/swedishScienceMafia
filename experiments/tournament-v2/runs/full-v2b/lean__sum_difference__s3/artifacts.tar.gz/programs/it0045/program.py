# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via deterministic structured search."""
import math
import time
from itertools import combinations


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _sidon(k):
    """A small B_2 / Sidon set: all pairwise sums distinct."""
    # greedy Sidon set
    s = [0]
    cand = 1
    while len(s) < k and cand < 10 ** 9:
        ok = True
        sset = set(s)
        for x in s:
            for y in s:
                if x + cand == y + cand:
                    continue
        # check sums with existing stays distinct
        used = set()
        for i in range(len(s)):
            for j in range(i, len(s)):
                used.add(s[i] + s[j])
        good = True
        used_local = set(used)
        for x in s:
            v = x + cand
            if v in used_local:
                good = False
                break
            used_local.add(v)
        if cand + cand in used_local:
            good = False
        if good:
            s.append(cand)
        cand += 1
    return s


def _pure_interval(n):
    return list(range(n))


def _build_interval_plus_block(n, block, offset):
    A = set(range(n))
    for b in block:
        A.add(offset + b)
    return sorted(A)


def solve():
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Precompute Sidon blocks of various sizes
    blocks = {}
    for k in (2, 3, 4, 5, 6, 7, 8):
        blocks[k] = _sidon(k)

    # Deterministic sweep: interval [0,n) plus scaled Sidon block far out
    for n in (8, 12, 16, 20, 25, 30, 40, 50, 60, 80, 100):
        if time.time() > deadline:
            break
        for k in (2, 3, 4, 5, 6):
            base = blocks[k]
            span = max(base) if base else 1
            for mult in (2, 3, 4, 6, 8, 12, 20):
                for off_extra in (0, 1, 2, 3):
                    if time.time() > deadline:
                        break
                    block = [b * mult for b in base]
                    offset = n + off_extra + (max(block) if block else 0) + n
                    # place block well beyond interval to keep sums separated
                    offset = n * (mult + 1) + off_extra
                    cand = _build_interval_plus_block(n, block, offset)
                    if len(cand) > 4000:
                        continue
                    s = _score(cand)
                    if s > best_s:
                        best, best_s = cand, s

    # Also try pure intervals (best for large n baseline)
    for n in (50, 100, 200, 400):
        cand = _pure_interval(n)
        s = _score(cand)
        if s > best_s:
            best, best_s = cand, s

    # Try two Sidon blocks plus interval
    for n in (10, 15, 20, 30):
        if time.time() > deadline:
            break
        for k in (3, 4, 5):
            base = blocks[k]
            for mult in (2, 3, 5, 8):
                block1 = [b * mult for b in base]
                off1 = n * (mult + 1)
                for mult2 in (mult + 1, mult * 2, mult * 3):
                    block2 = [off1 * 2 + b * mult2 for b in base]
                    A = set(range(n)) | set(block1) | set(block2)
                    if len(A) > 4000:
                        continue
                    cand = sorted(A)
                    s = _score(cand)
                    if s > best_s:
                        best, best_s = cand, s

    # Greedy local refinement on best
    if time.time() < deadline:
        cur = list(best)
        cur_s = best_s
        improved = True
        while improved and time.time() < deadline:
            improved = False
            hi = max(abs(x) for x in cur) if cur else 1
            for i in range(len(cur)):
                orig = cur[i]
                for delta in (1, -1, 2, -2, hi // 4, -hi // 4):
                    cur[i] = orig + delta
                    if len(set(cur)) == len(cur):
                        s = _score(cur)
                        if s > cur_s:
                            cur_s = s
                            best, best_s = cur[:], s
                            orig = cur[i]
                            improved = True
                            break
                cur[i] = orig
    return sorted(set(best))
# EVOLVE-BLOCK-END
