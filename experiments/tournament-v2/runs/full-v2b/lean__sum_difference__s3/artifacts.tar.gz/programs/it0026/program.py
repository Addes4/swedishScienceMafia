# EVOLVE-BLOCK-START
"""Construction: two widely-separated compact intervals (a "difference-rich, sum-poor" set)."""
import math


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), n


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small.

    Construction: A = {0,...,n-1} u (M + {0,...,n-1}) with M chosen large enough
    that the two interval copies barely interact additively but their cross
    differences populate a wide band, inflating |A-A| while |A+A| stays near the
    sumset size of two overlapping intervals (~2n).
    """
    best = None
    best_ratio = -1.0
    limit = 4000
    # Try a range of core sizes n and separation M (M kept modest so the two
    # intervals' sumsets overlap and |A+A| stays small).
    for n in range(2, 21):
        for M in (n, n + 1, 2 * n - 1, 2 * n, 3 * n, 4 * n, 8 * n, 16 * n,
                  32 * n, 64 * n, 128 * n, 256 * n):
            A = list(range(n)) + [M + i for i in range(n)]
            A = sorted(set(A))
            if len(A) > limit:
                continue
            nd, ns, na = _stats(A)
            if ns < 2:
                continue
            ratio = math.log(nd) / math.log(ns) + (1 - 1 / na) / 100
            if ratio > best_ratio:
                best_ratio = ratio
                best = A
    if best is None:
        best = [0, 1]
    return best
# EVOLVE-BLOCK-END
