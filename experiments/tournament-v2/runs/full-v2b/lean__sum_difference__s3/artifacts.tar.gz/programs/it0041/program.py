# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via interval + Sidon block + exact hill-climb."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _greedy_sidon(limit_size):
    """Greedy B_2 set: no repeated sums. Small difference-rich core."""
    S = [0]
    sums = {0}
    x = 1
    while len(S) < limit_size:
        ok = True
        new_sums = set()
        for s in S:
            v = x + s
            if v in sums or v in new_sums:
                ok = False
                break
            new_sums.add(v)
        if ok:
            new_sums.add(2 * x)
            sums |= new_sums
            S.append(x)
        x += 1
        if x > 100000:
            break
    return S


def _build_interval_plus_block(n, block, offset, scale):
    A = set(range(n))
    A |= {offset + scale * b for b in block}
    return sorted(A)


def _hill_climb_block(n, block, offset, scale, deadline, rng):
    """Mutate only the block (keep interval fixed)."""
    base = set(range(n))
    block = list(block)
    hi = offset + scale * (max(block) + 1) + 1

    def full(blk, off, sc):
        return base | {off + sc * b for b in blk}

    def sc_of(blk, off, sc):
        return _score(full(blk, off, sc))

    cur = block[:]
    cur_off, cur_sc = offset, scale
    cur_s = sc_of(cur, cur_off, cur_sc)
    best, best_s = cur[:], cur_s
    best_off, best_sc = cur_off, cur_sc

    while time.time() < deadline:
        nb = cur[:]
        noff, nsc = cur_off, cur_sc
        r = rng.random()
        if r < 0.35 and nb:
            i = rng.randrange(len(nb))
            nb[i] = max(0, nb[i] + rng.randint(-3, 3))
        elif r < 0.55:
            nb.append(max(nb) + rng.randint(1, 5) if nb else 0)
        elif r < 0.7 and len(nb) > 1:
            del nb[rng.randrange(len(nb))]
        elif r < 0.85:
            nsc = max(1, cur_sc + rng.choice([-2, -1, 1, 2]))
        else:
            noff = max(n, cur_off + rng.randint(-hi // 4, hi // 4))
        nb = sorted(set(nb))
        if not nb or len(nb) > 300:
            continue
        s = sc_of(nb, noff, nsc)
        if s >= cur_s:
            cur, cur_off, cur_sc, cur_s = nb, noff, nsc, s
            if s > best_s:
                best, best_off, best_sc, best_s = nb[:], noff, nsc, s
        elif rng.random() < 0.05:
            cur, cur_off, cur_sc, cur_s = best[:], best_off, best_sc, best_s
    return best, best_off, best_sc, best_s


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best = [0, 1, 2, 3, 100, 200, 400]
    best_s = _score(best)

    # Build candidate blocks: greedy Sidon sets of various sizes.
    blocks = []
    for k in (3, 4, 5, 6, 7, 8, 10, 12, 16, 20):
        blocks.append(_greedy_sidon(k))

    # Also small difference-rich cores: scaled interval blocks.
    for k in (3, 4, 5, 6, 8):
        blocks.append(list(range(k)))

    # Try deterministic seeds first.
    for n in (10, 20, 40, 60, 80, 120, 160, 200, 300):
        for blk in blocks:
            span = max(blk) if blk else 1
            for scale in (1, 2, 3, 5, 10, 30, 100):
                for off in (n, n * 3, n * 20, n * 200, 10 ** 4, 10 ** 6):
                    A = _build_interval_plus_block(n, blk, off, scale)
                    s = _score(A)
                    if s > best_s:
                        best, best_s = A, s
                    if time.time() > deadline:
                        return sorted(set(best))

    # Random hill-climb restarts over (n, block) configs.
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        n = rng.choice([10, 20, 40, 60, 80, 120, 160, 200, 300, 400])
        blk = rng.choice(blocks)
        scale = rng.choice([1, 2, 3, 5, 10, 30, 100])
        off = n * rng.choice([1, 3, 10, 50, 200, 1000])
        blk2, off2, sc2, s = _hill_climb_block(
            n, blk, off, scale, min(deadline, time.time() + 8), rng)
        if s > best_s:
            best = _build_interval_plus_block(n, blk2, off2, sc2)
            best_s = _score(best)

    return sorted(set(best))
# EVOLVE-BLOCK-END
