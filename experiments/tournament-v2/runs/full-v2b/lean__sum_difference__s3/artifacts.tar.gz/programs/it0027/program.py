# EVOLVE-BLOCK-START
"""Construction: interval core + scaled geometric block, parameter sweep."""
import math
import time


def _counts(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def solve():
    """Return A maximizing log|A-A|/log|A+A|."""
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # core interval C = {0,...,n-1}; geometric block scaled by M
    for n in [1, 2, 4, 8, 16, 20, 24, 28, 32]:
        for k in [4, 5, 6, 7, 8, 9, 10, 12, 14, 16]:
            # geometric block {M * 2^i}
            for M in [1000, 1000000, 10**9]:
                block = [M * (2 ** i) for i in range(k)]
                core = list(range(n))
                a = core + block
                a = sorted(set(a))
                if len(a) < 2:
                    continue
                nd, ns = _counts(a)
                if ns < 2:
                    continue
                score = math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100
                if score > best_score:
                    best_score = score
                    best = a
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    if best is None:
        # fallback
        return list(range(6))
    return best
# EVOLVE-BLOCK-END
