# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A|.

Key idea: |A-A| is maximised by sets that are 'difference-rich' (like intervals
and Sidon-like blocks) while |A+A| stays small.  A good family is
    A = [0, n)  u  {r + s*b : b in B}
where B is a Sidon / difference-rich block placed far from the interval so that
cross differences are mostly distinct while cross sums collide.  We sweep this
family deterministically and then refine exact-scored single-element moves.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _stats_counts(a):
    """Return (|A-A|, |A+A|, n) computed with sets."""
    a = list(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _incr_score(elems, diffs, sums):
    n = len(elems)
    if n < 2:
        return 0.0
    d = len(diffs)
    s = len(sums)
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


class Tracker:
    """Maintains difference and sum multisets for a small integer set."""
    __slots__ = ("elems", "dcount", "scount", "d", "s")

    def __init__(self, elems):
        self.elems = list(dict.fromkeys(elems))
        self.dcount = {}
        self.scount = {}
        for x in self.elems:
            for y in self.elems:
                self._inc(self.dcount, x - y)
                self._inc(self.scount, x + y)
        self.d = len(self.dcount)
        self.s = len(self.scount)

    @staticmethod
    def _inc(dic, k):
        c = dic.get(k, 0)
        if c == 0:
            dic[k] = 1
            return True
        dic[k] = c + 1
        return False

    @staticmethod
    def _dec(dic, k):
        c = dic.get(k, 0)
        if c <= 1:
            del dic[k]
        else:
            dic[k] = c - 1

    def add(self, x):
        e = self.elems
        for y in e:
            self._inc(self.dcount, x - y)
            self._inc(self.dcount, y - x)
            self._inc(self.scount, x + y)
        self._inc(self.dcount, 0)
        self._inc(self.scount, 2 * x)
        e.append(x)
        self.d = len(self.dcount)
        self.s = len(self.scount)

    def remove(self, x):
        e = self.elems
        e.remove(x)
        for y in e:
            self._dec(self.dcount, x - y)
            self._dec(self.dcount, y - x)
            self._dec(self.scount, x + y)
        self._dec(self.dcount, 0)
        self._dec(self.scount, 2 * x)
        self.d = len(self.dcount)
        self.s = len(self.scount)

    def score(self):
        return _incr_score(self.elems, self.dcount, self.scount)

    def snapshot(self):
        return self.elems[:]


def _local_search(tr, deadline, rng):
    best = tr.snapshot()
    best_s = tr.score()
    hi = max((abs(x) for x in tr.elems), default=1)
    while time.time() < deadline:
        r = rng.random()
        if r < 0.55:
            # shift an existing element
            if len(tr.elems) < 2:
                break
            i = rng.randrange(len(tr.elems))
            old = tr.elems[i]
            tr.remove(old)
            span = max(1, hi // 2)
            new = old + rng.randint(-span, span)
            tr.add(new)
            s = tr.score()
            if s >= best_s:
                if s > best_s:
                    best, best_s = tr.snapshot(), s
            elif rng.random() < 0.2:
                tr.remove(new)
                tr.add(old)
        elif r < 0.85:
            # add an element
            anchor = rng.choice(tr.elems) if tr.elems else 0
            new = anchor + rng.randint(-hi, hi)
            if new in tr.elems:
                continue
            tr.add(new)
            s = tr.score()
            if s >= best_s:
                if s > best_s:
                    best, best_s = tr.snapshot(), s
            elif rng.random() < 0.15:
                tr.remove(new)
        else:
            # remove an element (helps shrink |A+A|)
            if len(tr.elems) > 3:
                x = rng.choice(tr.elems)
                tr.remove(x)
                s = tr.score()
                if s >= best_s:
                    if s > best_s:
                        best, best_s = tr.snapshot(), s
                elif rng.random() < 0.15:
                    tr.add(x)
    return best, best_s


def _sidon_block(k, rng):
    """A greedy B_2 (Sidon) set of size k, for difference richness."""
    B = [0]
    used = {0}
    diffs = set()
    cand = 1
    while len(B) < k and cand < 10 * k * k + 50:
        ok = True
        for b in B:
            d = cand - b
            if d in diffs or d == 0:
                ok = False
                break
        if ok:
            for b in B:
                diffs.add(cand - b)
                diffs.add(b - cand)
            B.append(cand)
        cand += 1
    return B


def _build(n, B, r, s):
    A = set(range(n))
    for b in B:
        A.add(r + s * b)
    return sorted(A)


def solve():
    rng = random.Random(20240607)
    deadline = time.time() + 110

    best = [0, 1, 3, 7, 12, 20]
    best_s = _score(best)

    # --- deterministic sweep over interval + scaled Sidon block ---
    blocks = {}
    for k in (3, 4, 5, 6, 7, 8):
        blocks[k] = _sidon_block(k, rng)

    t_sweep = time.time() + 25
    for n in (8, 12, 16, 20, 24, 28, 32, 40, 50, 60, 80, 100):
        for k in (3, 4, 5, 6, 7, 8):
            B = blocks[k]
            maxb = B[-1] if B else 1
            for s in (1, 2, 3, 4, 5, 6, 8):
                for r in range(n + 1, n + 1 + max(6, n * 3), max(1, n // 2 + 1)):
                    if time.time() > t_sweep:
                        break
                    A = _build(n, B, r, s)
                    sc = _score(A)
                    if sc > best_s:
                        best, best_s = A, sc
                if time.time() > t_sweep:
                    break
            if time.time() > t_sweep:
                break
        if time.time() > t_sweep:
            break

    # --- also try random offsets cheaply ---
    while time.time() < t_sweep:
        n = rng.randint(8, 120)
        k = rng.randint(3, 7)
        B = blocks[k]
        s = rng.choice([1, 2, 3, 4, 5, 6, 8, 10])
        r = rng.randint(n + 1, n + 1 + 4 * (n + max(1, B[-1])) + 50)
        A = _build(n, B, r, s)
        sc = _score(A)
        if sc > best_s:
            best, best_s = A, sc

    # --- exact-scored local refinement with incremental tracker ---
    while time.time() < deadline:
        # keep sizes modest so O(n) moves are fast
        base = best[:]
        if len(base) > 300:
            base = base[:300]
        idx = sorted(range(len(base)), key=lambda i: -base[i])[:rng.randint(20, min(len(base), 80))]
        start = sorted(set(base[i] for i in idx) | set(range(rng.randint(4, 12))))
        try:
            tr = Tracker(start)
        except Exception:
            continue
        sl = min(deadline, time.time() + 8)
        cand, cs = _local_search(tr, sl, rng)
        if cs > best_s:
            best, best_s = cand, cs

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
