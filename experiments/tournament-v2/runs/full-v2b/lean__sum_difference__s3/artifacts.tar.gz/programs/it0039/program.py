# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeding + exact hill-climb."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), n


def _seed_interval_geometric(rng):
    """A = {0..n-1} union scaled geometric-ish block well separated."""
    n = rng.randint(8, 40)
    base = set(range(n))
    k = rng.randint(2, 6)
    scale = rng.choice([n * 2, n * 3, n * 4, n * 8])
    pts = set()
    v = scale
    for _ in range(k):
        pts.add(v)
        v = int(v * rng.uniform(1.5, 2.5)) + rng.randint(0, scale)
    return sorted(base | pts)


def _seed_twoblocks(rng):
    """Two intervals: {0..n-1} union {s..s+m-1} with tuned offset."""
    n = rng.randint(6, 30)
    m = rng.randint(3, 20)
    s = rng.randint(n + 1, 6 * (n + m))
    A = set(range(n))
    A |= {s + i for i in range(m)}
    return sorted(A)


def _seed_ap_plus_sidon(rng):
    """Long arithmetic progression with big step plus a difference-rich block
    placed at large multiples of the progression's span.

    A = {i*d : i < n}  union  {C + d*B_j}
    Sums stay ~2n (AP structure) but differences span a huge range because the
    block sits at large offsets, populating many new differences.
    """
    n = rng.randint(6, 60)
    d = rng.randint(1, 64)
    ap = [i * d for i in range(n)]
    span = (n - 1) * d if n > 1 else d
    # difference-rich small block B (greedy Sidon-ish) determined by rng
    k = rng.randint(2, 7)
    B = set()
    while len(B) < k:
        B.add(rng.randint(0, max(1, 2 * k)))
    B = sorted(B)
    # place block at large multiple of span
    mult = rng.choice([1, 2, 3, 5, 8, 13, 21])
    C = span * mult + rng.randint(0, max(1, span))
    block = [C + d * b for b in B]
    return sorted(set(ap) | set(block))


def _hill_climb(start, deadline, rng):
    best = list(set(start))
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.4 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 2)
            cand[i] += rng.randint(-span, span)
        elif r < 0.6:
            # rescale the whole set by a factor then jitter: preserves structure
            factor = rng.choice([2, 3, 5, 7])
            cand = [x * factor for x in cand]
        elif r < 0.75:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.9 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            if cand:
                cand = sorted(set(cand))
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        maxabs = max(abs(x) for x in cand)
        if maxabs > 10 ** 15:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.08:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    rng = random.Random(12345)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    seeds = []
    for n in (10, 20, 40, 80):
        seeds.append(list(range(n)))
    for _ in range(40):
        seeds.append(_seed_interval_geometric(rng))
    for _ in range(40):
        seeds.append(_seed_twoblocks(rng))
    for _ in range(80):
        seeds.append(_seed_ap_plus_sidon(rng))

    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    attempts = 0
    while time.time() < deadline:
        attempts += 1
        m = attempts % 4
        if m == 0:
            start = _seed_interval_geometric(rng)
        elif m == 1:
            start = _seed_twoblocks(rng)
        elif m == 2:
            start = _seed_ap_plus_sidon(rng)
        else:
            start = best[:]
        cand, cs = _hill_climb(start, min(deadline, time.time() + 15), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
