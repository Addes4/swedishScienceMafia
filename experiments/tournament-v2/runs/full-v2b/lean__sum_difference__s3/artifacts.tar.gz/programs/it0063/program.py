# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured families + fast bitmask scorer."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    xmin = min(a); xmax = max(a)
    w = xmax - xmin
    if w <= 0:
        return 0.0
    dsum = set()
    ssum = set()
    base = xmin
    for x in a:
        for y in a:
            dsum.add(x - y)
            ssum.add(x + y - 2 * base)
    return math.log(len(dsum)) / math.log(len(ssum)) + (1 - 1 / n) / 100


def _score_fast(a):
    """Fast scorer using bitmask over difference/sum offsets."""
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    base = a[0]
    w = 2 * (a[-1] - base) + 1
    dmask = 0
    smask = 0
    for x in a:
        bx = x - base
        for y in a:
            by = y - base
            dmask |= 1 << (bx - by + (a[-1] - base))
            smask |= 1 << (bx + by)
    return math.log(bin(dmask).count('1')) / math.log(bin(smask).count('1')) + (1 - 1 / n) / 100, bin(dmask).count('1'), bin(smask).count('1')


def _mask_stats(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, n
    base = a[0]
    hi = a[-1] - base
    dmask = 0
    smask = 0
    for x in a:
        bx = x - base
        for y in a:
            by = y - base
            dmask |= 1 << (bx - by + hi)
            smask |= 1 << (bx + by)
    return bin(dmask).count('1'), bin(smask).count('1'), n


def _ratio(dcount, scount, n):
    if scount < 2 or n < 2:
        return 0.0
    return math.log(dcount) / math.log(scount) + (1 - 1 / n) / 100


def _build(n, m, M, s):
    A = set(range(n))
    A |= {M + s * j for j in range(m)}
    return sorted(A)


def _local_perturb(start, deadline, rng):
    """Hill climb over (n, m, M, s) parameters of interval-union-AP family."""
    a = sorted(set(start))
    dc, sc, n = _mask_stats(a)
    best_s = _ratio(dc, sc, n)
    best = a[:]
    # derive current params roughly: assume form
    params = None
    for n_try in range(len(a), max(0, len(a) - 2), -1):
        pass
    # just do parameter hill-climb directly
    # extract n,m,M,s from structure if possible, else re-seed
    pn = len(a)
    pm = 1
    pM = 0
    ps = 1
    cur = (pn, pm, pM, ps)
    while time.time() < deadline:
        n2, m2, M2, s2 = cur
        r = rng.random()
        if r < 0.35:
            n2 = max(2, n2 + rng.randint(-8, 8))
        elif r < 0.6:
            m2 = max(1, m2 + rng.randint(-4, 4))
        elif r < 0.8:
            M2 = max(n2, M2 + rng.randint(-max(1, M2 // 4), max(1, M2 // 4)))
        else:
            s2 = max(1, s2 + rng.randint(-2, 2))
        if n2 + m2 > 4000 or n2 + m2 < 2:
            continue
        if M2 < n2:
            M2 = n2
        A = _build(n2, m2, M2, s2)
        if len(A) > 4000:
            continue
        dc, sc, nn = _mask_stats(A)
        s_sc = _ratio(dc, sc, nn)
        if s_sc >= best_s:
            best_s = s_sc
            best = A[:]
            cur = (n2, m2, M2, s2)
    return best, best_s


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # deterministic parametric sweep over interval-union-AP family
    seeds = []
    for n in (20, 40, 60, 80, 120, 160, 200):
        for m in (10, 20, 40, 80, 120, 160, 200, 300, 400, 600):
            if n + m > 4000:
                continue
            for f in (1, 2, 3, 4, 6, 8):
                M = n * f
                for s in (1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 24, 32, 48, 64, 96):
                    seeds.append((n, m, M, s))

    for (n, m, M, s) in seeds:
        if time.time() > deadline - 30:
            break
        A = _build(n, m, M, s)
        if len(A) > 4000:
            continue
        dc, sc, nn = _mask_stats(A)
        sc_sc = _ratio(dc, sc, nn)
        if sc_sc > best_s:
            best, best_s = A[:], sc_sc

    # hill-climb refinement from best
    while time.time() < deadline:
        cand, cs = _local_perturb(best, min(deadline, time.time() + 10), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
