# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via exact structured search on small sets."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _twoblock(n, m, D, s):
    """A = [0,n) union (D + s*[0,m))."""
    A = set(range(n))
    for i in range(m):
        A.add(D + s * i)
    return sorted(A)


def solve():
    """Return A with large |A-A| and small |A+A|."""
    rng = random.Random(98765)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    def consider(a):
        nonlocal best, best_s
        a = sorted(set(a))
        if len(a) < 2 or len(a) > 4000:
            return
        s = _score(a)
        if s > best_s:
            best, best_s = a[:], s

    # Deterministic sweep over two-block family.
    for n in range(2, 26):
        for m in range(2, 26):
            nm = n + m
            if nm > 60:
                continue
            for s in range(n + 1, 4 * (n + m) + 2):
                # D chosen so second block sums separate from first's sums
                for D in range(n, 6 * (n + m) + 2):
                    consider(_twoblock(n, m, D, s))
        if time.time() > deadline:
            break

    # Interval + scattered geometric block.
    for n in range(2, 20):
        for k in range(2, 6):
            v = n + 1
            pts = set(range(n))
            cur = n + 1
            for _ in range(k):
                pts.add(cur)
                cur = cur * 2 + n + 1
            consider(pts)

    # Local perturbation search around the best.
    cur = best[:]
    cur_s = best_s
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        hi = max((abs(x) for x in cand), default=1)
        if r < 0.45 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-(hi + 1), hi + 1)
        elif r < 0.8:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi - 1, hi + 1))
        elif len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 200:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.1:
            cur, cur_s = best[:], best_s

    return sorted(set(best))
# EVOLVE-BLOCK-END
