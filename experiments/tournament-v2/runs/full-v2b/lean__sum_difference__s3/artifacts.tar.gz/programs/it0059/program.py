# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via a structured family + exact scorer."""
import math
import itertools


def _stats(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _score(a):
    d, s, n = _stats(a)
    if n < 2 or s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _score_parts(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    n = len(a)
    if n < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(n, m, M, s):
    A = list(range(n))
    A += [M + s * j for j in range(m)]
    return sorted(set(A))


def solve():
    best = None
    best_s = -1.0

    # Sweep the family A = [0,n) U (M + s*[0,m)).
    # Key: n is the interval length; the scaled block gives large spread for differences,
    # while its sums overlap the interval sums to keep |A+A| small.
    n_range = [10, 20, 30, 50, 80, 120, 160, 200, 260]
    m_range = [2, 3, 4, 5, 6, 8, 10, 12, 16, 20]
    for n in n_range:
        for m in m_range:
            span = n + m
            for s in (1, 2, 3, 4, 5, 8, 16):
                # M chosen so the small block starts beyond n (no overlap) but
                # its sums (2M .. 2M+s(m-1)) stay near/just above the interval sums (0..2n-2)
                for M in range(n, max(2 * n + 3 * m, 3 * n) + 1, max(1, n // 4)):
                    A = _build(n, m, M, s)
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score_parts(A)
                    if sc > best_s:
                        best_s = sc
                        best = A

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # Local refinement: try shifting M, s, and small element tweaks.
    def local(A):
        nonlocal best, best_s
        A = list(A)
        improved = True
        # try removing/adding/adjusting single elements greedily (few passes)
        passes = 0
        while improved and passes < 6:
            improved = False
            passes += 1
            cur_s = _score_parts(A)
            base = A[:]
            # try adjusting each element slightly
            for i in range(len(base)):
                for delta in (-2, -1, 1, 2, -3, 3, -5, 5):
                    cand = base[:]
                    cand[i] += delta
                    if len(set(cand)) != len(cand):
                        continue
                    if max(abs(x) for x in cand) > 10**15:
                        continue
                    sc = _score_parts(cand)
                    if sc > cur_s:
                        base = cand
                        cur_s = sc
                        improved = True
            A = base
            if cur_s > best_s:
                best_s = cur_s
                best = A[:]

    local(best)
    # refine several of the top parameter regions
    for n in n_range:
        for m in m_range:
            for s in (1, 2, 3, 4, 5, 8):
                baseM = max(n, 2 * n)
                A = _build(n, m, baseM, s)
                local(A)

    return sorted(set(best))
# EVOLVE-BLOCK-END
