# EVOLVE-BLOCK-START
"""Search A maximizing log|A-A|/log|A+A| via fast bitset scorer + structured sweep."""
import math
import random
import time


def _score_from(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _fast_bitset(a):
    """Return (num_diffs, num_sums) exactly using Python big-int bitmasks.

    Works for any integer set by shifting into a nonnegative window.
    """
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0, 0
    lo = a[0]
    hi = a[-1]
    # difference range: -(hi-lo) .. (hi-lo); sums: 2*lo .. 2*hi
    dmin = lo - hi
    smin = 2 * lo
    # bit i corresponds to value (base + i)
    # differences
    dset = 0
    for x in a:
        # each x generates {-y + x}; use window
        for y in a:
            dset |= 1 << ((x - y) - dmin)
    sset = 0
    for x in a:
        for y in a:
            sset |= 1 << ((x + y) - smin)
    return bin(dset).count("1"), bin(sset).count("1")


def _bitset_score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _fast_bitset(a)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _family_score(n, m, M, s):
    """A = {0..n-1} u {M + s*i : 0<=i<m}. Robust exact scorer via sets (small if m small)."""
    if n < 1 or m < 0:
        return 0.0, None
    A = set(range(n))
    for i in range(m):
        A.add(M + s * i)
    A = sorted(A)
    if len(A) < 2:
        return 0.0, A
    # exact using difference/sum counts but efficient via structure:
    return _relaxed_score(A), A


def _relaxed_score(A):
    a = list(set(A))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _sweep(deadline, rng):
    best = list(range(6))
    best_s = _relaxed_score(best)

    # Deterministic structured sweep over [0,n) u (M + s*[0,m))
    ns = [8, 12, 20, 30, 50, 80, 120, 200, 300, 500, 800, 1200]
    ms = [2, 3, 4, 6, 8, 12, 16, 24, 40, 80, 160]
    for n in ns:
        if time.time() > deadline:
            break
        for m in ms:
            if time.time() > deadline:
                break
            # candidate offsets M: just above n (block separated), and larger factors
            for k in (1, 2, 3, 5, 8, 13):
                M = n * k + rng.randint(1, max(1, n))
                for s in (1, 2, 3, n, n + 1, 2 * n, n // 2 + 1):
                    if s < 1:
                        continue
                    A = set(range(n))
                    for i in range(m):
                        A.add(M + s * i)
                    A = sorted(A)
                    if len(A) > 4000:
                        continue
                    sc = _relaxed_score(A)
                    if sc > best_s:
                        best, best_s = A, sc
                    if time.time() > deadline:
                        break
                if time.time() > deadline:
                    break
    return best, best_s


def _hill(start, deadline, rng):
    best = list(set(start))
    best_s = _relaxed_score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(1, max(abs(x) for x in cur))
    steps = 0
    while time.time() < deadline:
        steps += 1
        cand = cur[:]
        r = rng.random()
        if r < 0.45 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 4)
            cand[i] += rng.randint(-span, span)
        elif r < 0.7:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.85 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            # scale the whole far block
            f = rng.uniform(0.5, 2.0)
            cand = [int(x * f) for x in cand]
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _relaxed_score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.05:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 112

    best, best_s = _sweep(deadline, rng)

    # local refinement from the best structured configuration, plus a few seeds
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        start = best[:]
        if attempts % 4 == 0:
            # random structured restart
            n = rng.randint(10, 400)
            m = rng.randint(2, 60)
            M = n * rng.randint(1, 8) + rng.randint(1, n)
            s = rng.choice([1, 2, 3, max(1, n // 2), n, 2 * n])
            A = set(range(n))
            for i in range(m):
                A.add(M + s * i)
            start = sorted(A)
        cand, cs = _hill(start, min(deadline, time.time() + 8), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
