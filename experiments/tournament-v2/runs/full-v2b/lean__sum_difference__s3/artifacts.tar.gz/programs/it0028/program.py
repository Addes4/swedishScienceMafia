# EVOLVE-BLOCK-START
"""Constructive search over interval + scaled geometric block."""
import math


def _stats(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score(a):
    d, s = _stats(a)
    if s == 0:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def solve():
    best = None
    best_score = -1.0

    # Try interval core + scaled geometric block.
    # A = {0..n-1} union (M + {0} union {2^j : j=1..k-1})
    # Sumset: interval+interval = 0..2n-2 (2n-1 values)
    # geometric+geometric = sums of two powers (many collisions)
    # difference set: interval-interval = -(n-1)..(n-1) (2n-1 values)
    #                 geo-geo = rich set of 2^a - 2^b scaled by M (>= k(k-1)/2 distinct)
    total_budget = 4000
    max_abs = 10**15

    for n in [1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2000, 2500, 3000, 3500, 3999]:
        for k in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]:
            geo = [0] + [2 ** j for j in range(k - 1)]
            if n + len(geo) > total_budget:
                continue
            # choose M so interval and geo are well separated; large M grows abs values.
            span = max(geo) if geo else 1
            # keep max abs <= 1e15; need M*span + (n-1) <= 1e15
            maxM = (max_abs - (n - 1)) // max(span, 1)
            for M in [maxM, maxM // 2, 10 ** 12, 10 ** 10, 10 ** 8, 10 ** 6, 10 ** 4, 10 ** 3, 10 ** 2, span + n + 1]:
                if M < 1:
                    continue
                if M * span + (n - 1) > max_abs:
                    continue
                a = list(range(n)) + [M * g for g in geo]
                a = list(set(a))
                if len(a) < 2:
                    continue
                sc = _score(a)
                if sc > best_score:
                    best_score = sc
                    best = a

    # Also try pure scaled geometric with dense lower powers overlapping an interval.
    # And try the "Sidon-ish" concatenation: interval + shifted copy.
    for n in [500, 1000, 1500, 1999]:
        # A = {0..n-1} union {M..M+n-1} with M chosen so sumsets are clean
        M = (2 * n - 1) + 1
        a = list(range(n)) + [M + i for i in range(n)]
        if M + n - 1 <= max_abs:
            sc = _score(a)
            if sc > best_score:
                best_score = sc
                best = a

    if best is None:
        best = [0, 1]
    return sorted(set(best))
# EVOLVE-BLOCK-END
