# EVOLVE-BLOCK-START
"""Deterministic construction A = {0..n-1} U {M + s*j : j=0..m-1} tuned by sweep."""
import math
import time

try:
    import numpy as np
    _HAS_NP = True
except Exception:
    _HAS_NP = False


def _score_np(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0
    d = np.unique(a[:, None] - a[None, :])
    s = np.unique(a[:, None] + a[None, :])
    if s.size < 2:
        return 0.0
    return math.log(d.size) / math.log(s.size) + (1 - 1 / n) / 100.0


def _score_py(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    d = {x - y for x in a for y in a}
    s = {x + y for x in a for y in a}
    if len(s) < 2:
        return 0.0
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / n) / 100.0


def _score(a):
    if _HAS_NP and len(a) <= 1200:
        try:
            return _score_np(a)
        except Exception:
            pass
    return _score_py(a)


def _build(n, m, M, s):
    A = list(range(n))
    A.extend(M + s * j for j in range(m))
    return sorted(set(A))


def solve():
    deadline = time.time() + 110

    best = [0, 1, 2, 3, 5, 8, 13, 21, 40, 41, 42, 43]
    try:
        best_s = _score(best)
    except Exception:
        best_s = 0.0

    # Candidate scale factors for the second block.
    scales = set()
    for v in (1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 96, 128):
        scales.add(v)
    scales = sorted(scales)

    # Parametric sweep. Keep work bounded so we never time out.
    checked = 0
    # Limit total candidate evaluations for safety.
    MAX_CHECKS = 400000

    # Sweep n (interval length) and m (block length), with tuned M, s.
    for n in range(2, 161):
        if time.time() > deadline:
            break
        for m in range(1, 161):
            if time.time() > deadline:
                break
            # M must push block above the interval; s controls spread.
            for s in scales:
                if time.time() > deadline:
                    break
                # A few offsets for M relative to n and structure.
                baseM = n
                for M in (baseM, baseM + n, baseM + s, baseM + n * s,
                          baseM + n + s, baseM + 2 * n + s, baseM + 3 * n):
                    if M <= n - 1:
                        M = n
                    A = _build(n, m, M, s)
                    if len(A) < 2:
                        continue
                    checked += 1
                    sc = _score(A)
                    if sc > best_s:
                        best_s = sc
                        best = A
                    if checked >= MAX_CHECKS:
                        break
                if checked >= MAX_CHECKS:
                    break
            if checked >= MAX_CHECKS:
                break
        if checked >= MAX_CHECKS:
            break

    # A focused refinement pass around the best found structure.
    if time.time() < deadline:
        bi = list(best)
        n_best = len(bi)
        # try small perturbations to M, s, and swapping block members
        for extra in range(0, 4000):
            if time.time() > deadline:
                break
            # Perturb: append a single element near the block's top.
            cand = bi[:]
            hi = max(cand)
            cand.append(hi + 1 + (extra % 17))
            sc = _score(cand)
            if sc > best_s:
                best_s = sc
                best = cand
                bi = cand

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
