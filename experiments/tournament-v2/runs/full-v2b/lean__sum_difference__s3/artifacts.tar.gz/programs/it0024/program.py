# EVOLVE-BLOCK-START
"""Compact interval core + scaled geometric block, improved by incremental local search."""
import math
import time


def _sets(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _score(a):
    d, s, n = _sets(a)
    if n < 2 or s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 100

    # Core candidates: interval {0..n-1} union scaled geometric block.
    # Build several and pick best.
    best = None
    best_score = -1.0

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2:
            return
        sc = _score(a)
        if sc > best_score:
            best_score = sc
            best = a[:]

    # interval core sizes and geometric block sizes / scales
    for n in (30, 60, 100, 150, 200, 300):
        core = list(range(n))
        for k in (8, 10, 12, 14, 16):
            for shift in (n, n * 4, n * 16):
                block = [(1 << i) for i in range(k)]
                # scale block so its smallest element ~ shift
                base = block[:]
                A = core + [shift + b for b in base]
                consider(A)
                # dilate the block further
                for mul in (2, 3, 5, 8):
                    A = core + [shift + mul * b for b in base]
                    consider(A)
                if time.time() > deadline - 40:
                    break

    # Incremental local search from best seed.
    if best is None:
        best = [0, 1, 2, 3, 4, 6, 8, 16, 32]

    cur = best[:]
    d, s, n = _sets(cur)
    cur_score = math.log(d) / math.log(s) + (1 - 1 / n) / 100

    import random
    random.seed(12345)
    while time.time() < deadline:
        cand = cur[:]
        # try: append a geometric-style new point, or perturb an existing one
        r = random.random()
        if r < 0.6:
            # append new large point
            base_new = random.choice([1 << random.randint(8, 22),
                                       (1 << random.randint(8, 18)) * random.randint(1, 3) + random.randint(0, 5)])
            cand.append(base_new + random.randint(0, 50))
        elif r < 0.9:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1, -2, 2, -5, 5, -50, 50, random.randint(-10, 10)])
        else:
            if len(cand) > 6:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        nd, ns, nn = _sets(cand)
        if ns < 2:
            continue
        nsc = math.log(nd) / math.log(ns) + (1 - 1 / nn) / 100
        if nsc >= cur_score:
            cur, cur_score = cand, nsc
            if nsc > best_score:
                best, best_score = cand[:], nsc
        elif random.random() < 0.05:
            cur, cur_score = best[:], best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
