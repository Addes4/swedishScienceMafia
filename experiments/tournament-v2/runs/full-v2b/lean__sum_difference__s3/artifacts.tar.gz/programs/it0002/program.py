# EVOLVE-BLOCK-START
"""AP (small sumset) + powers-of-two block (many cross-differences), tuned."""
import math
import time


def _score(a):
    A = list(set(a))
    n = len(A)
    if n < 2:
        return 0.0
    s = set()
    for x in A:
        for y in A:
            s.add(x + y)
    ns = len(s)
    d = set()
    for x in A:
        for y in A:
            d.add(x - y)
    nd = len(d)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 100

    def build(m, d, k, gap, off):
        # AP: 0, d, 2d, ..., (m-1)d  -> sums: 0..2(m-1)d, only ~2m-1 values
        A = [i * d for i in range(m)]
        # geometric block: off + gap * 2^i, i=0..k-1
        base = (m - 1) * d + off
        for i in range(k):
            A.append(base + gap * (2 ** i))
        return A

    def build_ap2(m, d, k, gap, off):
        # two APs with coprime-ish steps to boost differences while keeping sums small-ish
        A = [i * d for i in range(m)]
        base = (m - 1) * d + off
        for i in range(k):
            A.append(base + gap * (2 ** i))
        A = A[:m] + [x + 0 for x in A[m:]]
        return A

    best = None
    best_score = -1.0

    # coarse sweep
    for m in (20, 40, 80, 150, 300, 600, 1000, 2000):
        for k in (6, 10, 14, 18, 22):
            if m + k > 4000:
                continue
            for gap in (1, 3, 7, 15, 31, 63):
                for off in (gap, gap * 3 + 1):
                    A = build(m, 1, k, gap, off)
                    sc = _score(A)
                    if sc > best_score:
                        best_score, best = sc, A[:]
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # refine around best by rescaling d (AP step) and gap/off
    if best is not None:
        # recover approximate m
        m = 1
        # local perturbations
        for _ in range(300):
            if time.time() > deadline:
                break
            cand = best[:]
            # try appending one AP-like element or shifting params
            import random
            j = random.randrange(len(cand))
            cand[j] += random.randint(-2, 2)
            sc = _score(cand)
            if sc > best_score:
                best_score, best = sc, cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
