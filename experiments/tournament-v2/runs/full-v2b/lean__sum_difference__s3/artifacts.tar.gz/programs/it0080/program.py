# EVOLVE-BLOCK-START
"""Find small A maximizing log|A-A|/log|A+A| via block-family sweep + annealing."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    """Return a small list A of distinct integers with many differences, few sums."""
    rng = random.Random(20240)
    deadline = time.time() + 115

    best = [0, 1, 2, 1000, 1010, 1020]
    best_s = _score(best)

    # 1) Deterministic sweep over the block family A = [0,n) union (M + s*[0,m)).
    #    s > n keeps cross sums spread out; sweeping M lets block sums/differences
    #    merge or stay separated, trading |A+A| against |A-A|.
    for n in range(2, 9):
        base = list(range(n))
        for m in range(2, 9):
            for s in range(1, 41):
                for M in range(0, 81):
                    A = base + [M + s * j for j in range(m)]
                    sc = _score(A)
                    if sc > best_s:
                        best_s = sc
                        best = A[:]
        if time.time() > deadline:
            return sorted(set(best))

    # 2) Annealing / local refinement of small sets (values in a modest range).
    def climb(start, steps):
        cur = list(set(start))
        cs = _score(cur)
        b = cur[:]
        bs = cs
        for _ in range(steps):
            if time.time() > deadline:
                break
            cand = cur[:]
            r = rng.random()
            hi = max(abs(x) for x in cand) + 1
            if r < 0.55 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-3, -2, -1, 1, 2, 3])
            elif r < 0.80:
                cand.append(rng.randint(-6, max(6, hi)))
            elif r < 0.90 and len(cand) > 3:
                cand.remove(rng.choice(cand))
            else:
                if cand:
                    i = rng.randrange(len(cand))
                    cand[i] = (-cand[i]) if cand[i] else 1
            cand = list(set(cand))
            if not (3 <= len(cand) <= 16):
                continue
            sc = _score(cand)
            if sc > cs or rng.random() < 0.04:
                cur, cs = cand, sc
                if sc > bs:
                    b, bs = cand[:], sc
        return b, bs

    restarts = 0
    while time.time() < deadline:
        restarts += 1
        r = rng.random()
        if r < 0.4:
            start = best[:]
        elif r < 0.7:
            # random small set
            k = rng.randint(3, 9)
            start = rng.sample(range(-40, 60), k)
        else:
            # block seed perturbed
            n = rng.randint(2, 7)
            m = rng.randint(2, 7)
            s = rng.randint(2, 30)
            M = rng.randint(0, 60)
            start = list(range(n)) + [M + s * j for j in range(m)]
        cand, cs = climb(start, 4000)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
