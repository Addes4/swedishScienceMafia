# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A|.

Family: A = [0,n) union G, where G is a geometric/Sidon-like block placed far
away (so cross differences dominate) while cross sums overlap with the interval's
sums as little as possible. We use an exact numpy-convolution scorer over a
compacted coordinate range.
"""
import math
import time
import numpy as np


def _score_stats(A):
    A = sorted(set(A))
    n = len(A)
    if n < 2:
        return 0.0, 0, 0, n
    a = np.array(A, dtype=np.int64)
    diffs = a[:, None] - a[None, :]
    sums = a[:, None] + a[None, :]
    nd = len(np.unique(diffs))
    ns = len(np.unique(sums))
    if ns < 2:
        return 0.0, nd, ns, n
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns, n


def _score(A):
    return _score_stats(A)[0]


def _geometric_block(g, scale, k, rng_seed=1):
    """k points forming a near-Sidon geometric-ish set around `scale`."""
    rng = np.random.default_rng(rng_seed)
    pts = []
    v = int(scale)
    for _ in range(k):
        pts.append(v)
        # multiplicative growth with small jitter
        v = int(v * g) + int(rng.integers(0, max(1, scale // 4)))
    return pts


def solve():
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Deterministic sweep over interval + geometric block.
    # Cross differences should be many, cross sums should overlap interval sums.
    results = []
    for n in [10, 15, 20, 25, 30, 40, 50, 60, 80, 100]:
        if time.time() > deadline:
            break
        for k in [2, 3, 4, 5, 6, 8, 10]:
            for gnum, gden in [(3, 2), (2, 1), (5, 2), (3, 1), (4, 1)]:
                g = gnum / gden
                for scale_mult in [1, 2, 4, 8, 16, 32]:
                    if time.time() > deadline:
                        break
                    # place geometric block starting well past n
                    M = n * scale_mult + n + 1
                    G = _geometric_block(g, M, k, rng_seed=k * 7 + scale_mult)
                    A = list(range(n)) + G
                    s, nd, ns, na = _score_stats(A)
                    results.append((s, A[:]))
                    if s > best_s:
                        best, best_s = A[:], s
    results.sort(key=lambda t: -t[0])

    # Local refinement: shift/perturb the second block and tweak n.
    rng = np.random.default_rng(2024)
    top = [A for _, A in results[:30]] + [best]

    def refine(A, budget_end):
        A = sorted(set(A))
        cur_s = _score(A)
        cur = A[:]
        for _ in range(4000):
            if time.time() > budget_end:
                break
            cand = cur[:]
            op = rng.integers(0, 4)
            if op == 0 and len(cand) > 3:
                # shift a random (upper) element by small delta
                i = int(rng.integers(len(cand) // 2, len(cand)))
                span = max(1, abs(cand[i]) // 20)
                cand[i] += int(rng.integers(-span, span + 1))
            elif op == 1:
                # add new element
                anchor = int(rng.choice(cand))
                span = max(1, abs(anchor) // 8)
                cand.append(anchor + int(rng.integers(-span, span + 1)))
            elif op == 2 and len(cand) > 3:
                del cand[int(rng.integers(len(cand) // 2, len(cand)))]
            else:
                # shift whole upper block
                lo = int(rng.integers(len(cand) // 2, len(cand)))
                cand = cand[:lo] + [c + int(rng.integers(-5, 6)) for c in cand[lo:]]
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 4000:
                continue
            if max(abs(x) for x in cand) > 10 ** 15:
                continue
            s = _score(cand)
            if s >= cur_s:
                cur, cur_s = cand, s
        return cur, cur_s

    for A in top:
        if time.time() > deadline:
            break
        cand, cs = refine(A, min(deadline, time.time() + 8))
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
