# EVOLVE-BLOCK-START
"""Constructive search: AP core union a scaled geometric block, tuned by direct evaluation."""
import math
import time


def _stats(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)), len(a)


def _score(a):
    r, n = _stats(a)
    if n == 0:
        return 0.0
    return r + (1 - 1 / n) / 100


def _build(n, k, M):
    A = list(range(n))
    p = 1
    for _ in range(k):
        A.append(M * p)
        p *= 2
    return A


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100
    # Systematic sweep over the AP length n, the geometric block size k and
    # the scaling M.  Use moderate n (sumset small) and enough spread in the
    # geometric block (differences many and distinct).
    Ns = list(range(2, 40)) + list(range(40, 200, 4)) + [256, 300, 360]
    Ks = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    for n in Ns:
        if time.time() > deadline:
            break
        for k in Ks:
            if time.time() > deadline:
                break
            # M must be large enough that the geometric part is "separated"
            # from the AP core so its differences don't collapse into the core.
            for mult in (1, 2, 3, 5, 8):
                M = max(2 * n * mult, 2 ** k)
                A = _build(n, k, M)
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A[:]
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(best))
# EVOLVE-BLOCK-END
