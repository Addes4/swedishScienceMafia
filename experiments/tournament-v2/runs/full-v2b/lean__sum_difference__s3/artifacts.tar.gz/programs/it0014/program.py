# EVOLVE-BLOCK-START
"""Construct A as a union of scaled arithmetic-progression blocks separated geometrically."""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build(m, k, base, gap):
    """m: AP block length; k: number of blocks; base: block offset multiplier."""
    A = []
    for i in range(k):
        off = base * (gap ** i)
        for j in range(m):
            A.append(off + j)
    return A


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    deadline = time.time() + 100

    # Sweep structured families
    cands = []
    for m in [2, 3, 4, 5, 6, 8, 10]:
        for k in [4, 5, 6, 7, 8, 10, 12, 16, 20]:
            for gap in [2, 3, 4, 5, 8, 16, 64, 256]:
                for base in [1, 2, 3]:
                    if m * k > 4000:
                        continue
                    cands.append((m, k, base, gap))

    for (m, k, base, gap) in cands:
        if time.time() > deadline:
            break
        A = _build(m, k, base, gap)
        if len(A) > 4000:
            continue
        s = _score(A)
        if s > best_score:
            best_score, best = s, A

    # Local refinement: also try adding a few negative shifts
    return sorted(set(best))
# EVOLVE-BLOCK-END
