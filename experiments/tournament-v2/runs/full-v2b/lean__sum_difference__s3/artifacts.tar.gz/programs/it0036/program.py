# EVOLVE-BLOCK-START
"""Deterministic sweep over interval + spaced-block families, then exact hill-climb."""
import math
import random
import time


def _counts(a):
    a = list(set(a))
    if len(a) < 2:
        return 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score_counts(nd, ns, na):
    if ns <= 1 or na < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / na) / 100


def _score(a):
    nd, ns = _counts(a)
    return _score_counts(nd, ns, len(set(a)))


def solve():
    """Return a list A with large |A-A| and small |A+A|."""
    best = None
    best_score = -1.0

    # Sweep: interval {0..n-1} union an offset arithmetic block {C + d*i : i<m}.
    # Intervals give small |A+A|; the offset block adds many new differences.
    for n in (5, 8, 12, 20, 30, 50, 80):
        for m in (2, 3, 4, 6, 8, 12):
            for d in (1, 2, 3, 5, 8, 13, 21, 40, 100):
                for C in (n, n + d, n + 3 * d, n * 2 + 5 * d, n * 3, 7 * d):
                    A = list(range(n)) + [C + d * i for i in range(m)]
                    A = sorted(set(A))
                    if len(A) < 2:
                        continue
                    nd, ns = _counts(A)
                    s = _score_counts(nd, ns, len(A))
                    if s > best_score:
                        best_score = s
                        best = A[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # Exact single-element local climb using actual counts (recompute quickly).
    cur = best[:]
    cur_score = best_score
    deadline = time.time() + 90
    while time.time() < deadline:
        improved = False
        base = list(set(cur))
        # Try small perturbations of a random element and occasional add/remove.
        for _ in range(200):
            cand = base[:]
            r = random.random()
            if r < 0.6 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-5, -3, -2, -1, 1, 2, 3, 5,
                                          -13, -21, 13, 21, -100, 100])
            elif r < 0.85:
                cand.append(random.choice([1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233]))
            elif len(cand) > 4:
                del cand[random.randrange(len(cand))]
            cand = list(set(cand))
            if len(cand) < 2:
                continue
            nd, ns = _counts(cand)
            s = _score_counts(nd, ns, len(cand))
            if s > cur_score:
                cur, cur_score = cand, s
                improved = True
                break
        if not improved:
            # diversify a bit
            cur = base[:]
            if len(cur) > 2:
                i = random.randrange(len(cur))
                cur[i] += random.choice([-1, 1, 2, -2, 7, -7])
    if cur_score > best_score:
        best = cur
    return sorted(set(best))
# EVOLVE-BLOCK-END
