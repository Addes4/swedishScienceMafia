# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via exact two-block sweep + local search."""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), n


def _score_counts(nd, ns, n):
    if ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    nd, ns, n = _stats(a)
    return _score_counts(nd, ns, n)


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    def consider(a):
        nonlocal best, best_s
        a = sorted(set(a))
        if len(a) < 2 or len(a) > 4000:
            return
        if max(abs(x) for x in a) > 10**15:
            return
        nd, ns, n = _stats(a)
        s = _score_counts(nd, ns, n)
        if s > best_s:
            best, best_s = a, s

    # Deterministic sweep over the two-block family: A = [0,n) ∪ (M + s*[0,m))
    # Requires the blocks be separated so sumsets overlap minimally.
    # |A-A| ~ 2*n*m (cross terms), |A+A| ~ n*m (cross sums) when tuned.
    tried = 0
    for n in range(2, 60):
        for m in range(2, 60):
            for s in (1, 2, 3, 4, 5, 8, 16, 32, 64, 128, 1000, 10**6, 10**9, 10**12):
                # place block2 far so that sums of block1 don't collide with sums of block2
                # block1 sums range [0, 2n-2]; block2 sums range [2M, 2M+2s(m-1)]
                # cross sums range [M, M + s(m-1) + n-1]
                # choose M so that block2 sums are disjoint from cross sums and block1 sums
                M = 2 * n + max(2, s * m) + 1
                A = list(range(n)) + [M + s * i for i in range(m)]
                consider(A)
                tried += 1
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Interval + scaled quadratic-ish (squares) blocks: A = [0,n) ∪ {M + i*i}
    if time.time() < deadline:
        for n in range(2, 50):
            for k in range(2, 40):
                sq = [i * i for i in range(k)]
                M = 2 * n + (k - 1) * (k - 1) + 2
                A = list(range(n)) + [M + v for v in sq]
                consider(A)

    # Interval + geometric block
    if time.time() < deadline:
        for n in range(2, 50):
            for r in (2, 3, 4, 5, 6, 7, 10):
                vals = [0]
                v = 1
                for _ in range(30):
                    v *= r
                    if v > 10**15:
                        break
                    vals.append(v)
                if len(vals) >= 2:
                    M = max(2 * n + 2, 2)
                    A = list(range(n)) + [M + v for v in vals]
                    consider(A)

    # Exact local search over small arbitrary sets seeded from the best two-block finds.
    def hill(a, end):
        a = sorted(set(a))
        cur = a[:]
        cur_s = _score(cur)
        while time.time() < end:
            cand = cur[:]
            r = rng.random()
            hi = max(abs(x) for x in cand) if cand else 1
            if r < 0.5 and cand:
                i = rng.randrange(len(cand))
                span = max(1, hi // 3)
                cand[i] += rng.randint(-span, span)
            elif r < 0.8:
                anchor = rng.choice(cand) if cand else 0
                cand.append(anchor + rng.randint(-hi, hi))
            elif r < 0.95 and len(cand) > 3:
                del cand[rng.randrange(len(cand))]
            else:
                if cand:
                    cand[rng.randrange(len(cand))] = rng.randint(-hi, hi)
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 60:
                continue
            if max(abs(x) for x in cand) > 10**15:
                continue
            s = _score(cand)
            if s >= cur_s:
                cur, cur_s = cand, s
                if s > best_s:
                    nonlocal_update = cand, s
                if cur_s > best_s:
                    consider(cand)
            elif rng.random() < 0.05:
                cur, cur_s = best[:], best_s if best_s > 0 else cur_s
        return cur

    # local search from current best plus a few structured starts
    starts = [best]
    for n in (3, 4, 5, 6, 8, 10):
        for m in (3, 4, 5, 6, 8):
            M = 2 * n + m + 1
            starts.append(list(range(n)) + [M + i for i in range(m)])
    per = max(1.0, (deadline - time.time()) / max(1, len(starts)))
    for st in starts:
        if time.time() > deadline:
            break
        hill(st, min(deadline, time.time() + per))

    return sorted(set(best))
# EVOLVE-BLOCK-END
