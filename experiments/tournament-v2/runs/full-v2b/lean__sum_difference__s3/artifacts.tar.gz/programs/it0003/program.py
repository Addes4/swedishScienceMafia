# EVOLVE-BLOCK-START
"""Structure: an arithmetic progression (small sumset) plus a greedy set of offsets
chosen to maximize distinct differences relative to new sums, followed by local search."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _greedy_offsets(seed, max_add, low, high):
    """Greedily add offsets from [low, high) maximizing new distinct differences
    relative to the number of new sums created."""
    cur = set(seed)
    diffs = {x - y for x in cur for y in cur}
    sums = {x + y for x in cur for y in cur}
    for _ in range(max_add):
        best_g = None
        best_val = -1.0
        # sample candidate offsets
        for _ in range(60):
            c = random.randint(low, high - 1)
            if c in cur:
                continue
            nd = {c - y for y in cur} | {y - c for y in cur}
            newd = len(nd - diffs)
            ns = {c + y for y in cur}
            news = len(ns - sums)
            val = newd / (1.0 + news)
            if val > best_val:
                best_val = val
                best_g = c
        if best_g is None or best_val <= 0:
            break
        cur.add(best_g)
        diffs |= {best_g - y for y in cur} | {y - best_g for y in cur}
        sums |= {best_g + y for y in cur}
    return list(cur)


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 110

    # Try several structured seeds: an AP scaled plus greedy offsets
    configs = []
    for step in (1, 3, 5, 7, 11, 17, 23):
        for base_len in (4, 5, 6, 8, 10):
            for max_add in (10, 18, 30, 45):
                configs.append((step, base_len, max_add))
    random.shuffle(configs)

    for (step, base_len, max_add) in configs:
        if time.time() > deadline:
            break
        seed = [i * step for i in range(base_len)]
        a = _greedy_offsets(seed, max_add, min(seed) - 40, max(seed) + 40)
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # local improvement on best
    if best is not None:
        cur = best[:]
        end = time.time() + max(0, deadline - time.time())
        while time.time() < end:
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2])
            if len(set(cand)) < len(cand):
                continue
            s = _score(cand)
            if s >= best_score:
                best, best_score, cur = cand[:], s, cand
            elif random.random() < 0.15:
                cur = best[:]

    return sorted(set(best)) if best is not None else [0, 1]
# EVOLVE-BLOCK-END

