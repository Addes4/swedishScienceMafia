# EVOLVE-BLOCK-START
"""Greedy construction: AP core (small sumset) plus greedily added elements that
maximize |A-A| while keeping |A+A| small."""
import math
import random
import time


def _score_from_sets(diffs, sums, n):
    if n < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _full_sets(a):
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return diffs, sums


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs, sums = _full_sets(a)
    return _score_from_sets(diffs, sums, len(a))


def _greedy_build(seed, pool, deadline):
    A = list(dict.fromkeys(seed))
    if len(A) < 2:
        return A
    diffs, sums = _full_sets(A)
    best_extra = []
    # try to grow by greedily adding best candidates
    while time.time() < deadline and len(A) < 4000:
        best_cand = None
        best_val = _score_from_sets(diffs, sums, len(A))
        # sample a subset of candidates for speed
        cands = pool if len(pool) <= 400 else random.sample(pool, 400)
        for c in cands:
            if c in diffs and False:
                pass
            if c in A:
                continue
            n = len(A)
            new_diffs = len(diffs)
            new_sums = len(sums)
            # count new differences c - a and a - c
            added_d = set()
            added_s = set()
            for a in A:
                d1 = c - a
                d2 = a - c
                if d1 not in diffs:
                    added_d.add(d1)
                if d2 not in diffs:
                    added_d.add(d2)
                s1 = c + a
                if s1 not in sums:
                    added_s.add(s1)
            nd = len(diffs) + len(added_d)
            ns = len(sums) + len(added_s)
            if ns <= 1:
                continue
            val = math.log(nd) / math.log(ns) + (1 - 1 / (n + 1)) / 100
            if val > best_val:
                best_val = val
                best_cand = c
        if best_cand is None:
            break
        A.append(best_cand)
        for a in A:
            diffs.add(best_cand - a)
            diffs.add(a - best_cand)
            sums.add(best_cand + a)
        best_extra.append(best_cand)
    return A


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    random.seed(12345)
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Build candidate pool: structured offsets and random values around 0
    pool = set()
    # powers-of-two-ish spacings create many distinct differences
    base = 1
    for i in range(20):
        base *= 2
        for s in (-1, 1):
            pool.add(s * base)
            pool.add(s * base + 1)
            pool.add(s * base - 1)
    # random perturbations
    for _ in range(2000):
        pool.add(random.randint(-5000, 5000))
    # small dense values
    for v in range(-40, 41):
        pool.add(v)
    pool = list(pool)

    # Multiple restarts with AP cores of varying step/length
    restarts = [
        [0, 1, 2, 3],           # AP core
        [0, 2, 4, 6],
        [0, 3, 6, 9, 12],
        [0, 1, 2, 3, 4, 5],
        [0, 5, 10, 15],
        [-2, 0, 2, 4],
        [0, 1, 2, 3, 4, 5, 6, 7],
    ]
    random.shuffle(restarts)
    for core in restarts:
        if time.time() > deadline - 5:
            break
        A = _greedy_build(core, pool, deadline)
        s = _score(A)
        if s > best_score:
            best, best_score = A, s

    # Local improvement on best
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-3, 3)
        if len(cand) < 60 and random.random() < 0.15:
            cand.append(random.choice(pool))
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.1:
            cur = best[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END
