# EVOLVE-BLOCK-START
"""Structured search: AP core + scaled powers of two, plus local refinement."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats(a):
    a = set(a)
    if len(a) < 2:
        return 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums)


def _build(ap_len, ap_step, base, two_count, scale, offset):
    A = [base + ap_step * i for i in range(ap_len)]
    for j in range(two_count):
        A.append(offset + scale * (1 << j))
    return sorted(set(A))


def _refine(A, deadline):
    A = list(set(A))
    best = A[:]
    best_score = _score(A)
    cur = A[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55 and cand:
            i = random.randrange(len(cand))
            span = max(1, abs(cand[i]) // 2 + 1)
            cand[i] += random.randint(-span, span)
        elif r < 0.85:
            cand.append(random.randint(-50, 50))
        elif len(cand) > 3:
            del cand[random.randrange(len(cand))]
        # keep distinct
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score or random.random() < 0.02:
            cur, cur_score = cand, s
        if s > best_score:
            best, best_score = cand[:], s
    return best, best_score


def solve():
    """Return a list A maximizing log|A-A| / log|A+A|."""
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Enumerate structured candidates.
    best_struct = None
    best_struct_score = -1.0
    for ap_len in range(2, 12):
        for ap_step in (1, 2, 3, 5, 7, 12, 20):
            for base in (0, 1, -5):
                for two_count in range(0, 13):
                    for scale in (1, 2, 3, 5, 10, 31):
                        for offset in (0, 5, 17, 50, 100, 300):
                            A = _build(ap_len, ap_step, base, two_count, scale, offset)
                            if len(A) < 2:
                                continue
                            s = _score(A)
                            if s > best_struct_score:
                                best_struct_score = s
                                best_struct = A
    best = best_struct
    best_score = best_struct_score

    # Local refinement on the best structured candidate.
    t0 = time.time()
    share = max(1.0, (deadline - t0) * 0.95)
    A, s = _refine(best, t0 + share)
    if s > best_score:
        best, best_score = A, s

    return sorted(set(best))
# EVOLVE-BLOCK-END
