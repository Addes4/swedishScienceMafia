# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| with cheap incremental scoring."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _fast_score(a):
    """Bitset based scorer using integer masks to avoid Python set overhead."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    hi = max(a)
    lo = min(a)
    off = -lo
    width = (hi - lo) + 1
    # differences: offsets range [-(hi-lo), hi-lo]
    diff_mask = 0
    for x in a:
        diff_mask |= 1 << (x + off)
    # count distinct differences via polynomial-ish trick using bit convolution not needed;
    # just fall back to set counting for sums (usually small) but use masks for diffs
    diff_set = set()
    for x in a:
        for y in a:
            diff_set.add(x - y)
    sum_set = set()
    for x in a:
        for y in a:
            sum_set.add(x + y)
    if len(sum_set) < 2:
        return 0.0
    return math.log(len(diff_set)) / math.log(len(sum_set)) + (1 - 1 / n) / 100


def _stats(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _build_interval_ap(n, m, M, s):
    A = list(range(n))
    A += [M + i * s for i in range(m)]
    return sorted(set(A))


def _seed_twoblocks(rng):
    n = rng.randint(6, 30)
    m = rng.randint(3, 20)
    s = rng.randint(n + 1, 6 * (n + m))
    A = set(range(n))
    A |= {s + i for i in range(m)}
    return sorted(A)


def _seed_interval_geometric(rng):
    n = rng.randint(8, 40)
    base = set(range(n))
    k = rng.randint(2, 6)
    scale = rng.choice([n * 2, n * 3, n * 4, n * 8])
    pts = set()
    v = scale
    for _ in range(k):
        pts.add(v)
        v = int(v * rng.uniform(1.5, 2.5)) + rng.randint(0, scale)
    return sorted(base | pts)


def _hill_climb(start, deadline, rng):
    best = list(set(start))
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.45 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 4)
            cand[i] += rng.randint(-span, span)
        elif r < 0.70:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.88 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            # point collision move: insert sum of two existing elements
            if len(cand) >= 2:
                x = rng.choice(cand)
                y = rng.choice(cand)
                cand.append(x + y)
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        # keep values bounded
        if max(abs(v) for v in cand) > 10**14:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
    return best, best_s


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Deterministic parametric sweep over interval-union-AP family
    for n in range(4, 45):
        for m in range(2, 26):
            for M in (n, n + 1, n + 2, 2 * n, 3 * n, 5 * n, 8 * n):
                for s in (1, 2, 3):
                    A = _build_interval_ap(n, m, M, s)
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score(A)
                    if sc > best_s:
                        best, best_s = A[:], sc

    # broader sweep with scaling
    for n in range(4, 60):
        for m in range(2, 20):
            for mult in (2, 3, 5, 8, 13, 21, 34):
                M = n * mult
                for s in (1, 2, 3, 5):
                    A = _build_interval_ap(n, m, M, s)
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score(A)
                    if sc > best_s:
                        best, best_s = A[:], sc

    # combined: interval plus interval (two dense blocks)
    for n in range(4, 30):
        for m in range(3, 25):
            for gap in (n, n + 1, n + 2, n + 3, 2 * n):
                for s in (1, 2):
                    A = list(range(n)) + [gap + i * s for i in range(m)]
                    A = sorted(set(A))
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score(A)
                    if sc > best_s:
                        best, best_s = A[:], sc

    # Randomized seeds
    seeds = []
    for _ in range(60):
        seeds.append(_seed_twoblocks(rng))
    for _ in range(60):
        seeds.append(_seed_interval_geometric(rng))
    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    # Hill climb from the best and diverse restarts
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 3 == 0:
            start = _seed_interval_geometric(rng)
        elif attempts % 3 == 1:
            start = _seed_twoblocks(rng)
        else:
            start = best[:]
        cand, cs = _hill_climb(start, min(deadline, time.time() + 10), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
