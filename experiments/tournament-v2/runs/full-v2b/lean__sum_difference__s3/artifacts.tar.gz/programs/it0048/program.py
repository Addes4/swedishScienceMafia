# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via fast numpy scoring + structured sweep."""
import math
import random
import time
import numpy as np


def _score(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    d = np.unique(a[:, None] - a[None, :])
    s = np.unique(a[:, None] + a[None, :])
    if len(s) < 2:
        return 0.0
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / n) / 100


def _stats(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = len(a)
    d = np.unique(a[:, None] - a[None, :])
    s = np.unique(a[:, None] + a[None, :])
    return len(d), len(s), n


def _score_from_np(arr):
    arr = np.unique(np.array(arr, dtype=np.int64))
    n = len(arr)
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(arr[:, None] - arr[None, :])
    s = np.unique(arr[:, None] + arr[None, :])
    if len(s) < 2:
        return 0.0, len(d), len(s)
    return (math.log(len(d)) / math.log(len(s)) + (1 - 1 / n) / 100, len(d), len(s))


def _seed_block(rng):
    n = rng.randint(10, 60)
    A = set(range(n))
    m = rng.randint(2, 8)
    s = rng.randint(n + 1, 10 * n)
    step = rng.randint(1, 3)
    v = s
    for _ in range(m):
        A.add(v)
        v += step * rng.randint(1, 4) + rng.randint(0, n)
    return sorted(A)


def _seed_geometric(rng):
    n = rng.randint(8, 40)
    A = set(range(n))
    k = rng.randint(3, 10)
    v = n * rng.choice([2, 3, 4, 5])
    r = rng.uniform(1.3, 2.0)
    for _ in range(k):
        A.add(v)
        v = int(v * r) + rng.randint(0, n)
    return sorted(A)


def _seed_golomb(rng):
    """Interval plus a small Golomb-ruler-like set placed far away."""
    n = rng.randint(6, 40)
    A = set(range(n))
    k = rng.randint(3, 7)
    # build greedy Golomb-ish marks
    marks = [0]
    used = {0}
    limit = 60
    while len(marks) < k:
        c = None
        for cand in range(1, limit):
            ok = True
            for m in marks:
                if abs(cand - m) in used:
                    ok = False
                    break
            if ok:
                c = cand
                break
        if c is None:
            c = limit
            limit += 30
        new = set()
        for m in marks:
            new.add(abs(c - m))
        used |= new
        marks.append(c)
    off = rng.randint(n + 1, 8 * n)
    step = rng.randint(1, 3)
    for m in marks:
        A.add(off + step * m)
    return sorted(A)


def _local_improve(A, deadline, rng):
    A = sorted(set(A))
    best_s, _, _ = _score_from_np(A)
    best = A[:]
    arr = np.array(best, dtype=np.int64)
    hi = int(np.max(np.abs(arr))) if len(arr) else 1
    while time.time() < deadline:
        cand = best[:]
        op = rng.random()
        if op < 0.45 and cand:
            i = rng.randrange(len(cand))
            span = max(2, hi // 4)
            cand[i] += rng.randint(-span, span)
        elif op < 0.7:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif op < 0.85 and len(cand) > 4:
            del cand[rng.randrange(len(cand))]
        else:
            # shift the whole far block
            if len(cand) > 2:
                cand = [c + rng.randint(-hi // 2, hi // 2) for c in cand]
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s, _, _ = _score_from_np(cand)
        if s > best_s:
            best, best_s = cand[:], s
    return best, best_s


def solve():
    rng = random.Random(20240517)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s, _, _ = _score_from_np(best)

    seeds = []
    for n in (10, 20, 40, 80, 120):
        seeds.append(list(range(n)))
    for _ in range(60):
        seeds.append(_seed_block(rng))
    for _ in range(60):
        seeds.append(_seed_geometric(rng))
    for _ in range(60):
        seeds.append(_seed_golomb(rng))

    for seed in seeds:
        s, _, _ = _score_from_np(seed)
        if s > best_s:
            best, best_s = seed[:], s
        if time.time() > deadline - 30:
            break

    # local improvement restarts
    attempts = 0
    while time.time() < deadline - 5:
        attempts += 1
        if attempts % 3 == 0:
            start = _seed_block(rng)
        elif attempts % 3 == 1:
            start = _seed_golomb(rng)
        else:
            start = best[:]
        cand, cs = _local_improve(start, min(deadline - 5, time.time() + 8), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    # final polish on the best
    cand, cs = _local_improve(best, deadline, rng)
    if cs > best_s:
        best, best_s = cand, cs

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
