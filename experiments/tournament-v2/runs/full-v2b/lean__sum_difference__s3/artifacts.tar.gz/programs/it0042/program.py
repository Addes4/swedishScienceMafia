# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeds + exact coordinate descent."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _seed_interval_plus_block(rng, n=None, k=None, gap_factor=None):
    if n is None:
        n = rng.randint(20, 120)
    base = list(range(n))
    if k is None:
        k = rng.randint(2, 8)
    if gap_factor is None:
        gap_factor = rng.choice([1, 1.5, 2, 3, 5])
    offset = int(n * gap_factor) + rng.randint(0, n)
    # geometric-ish block
    block = []
    v = offset
    for _ in range(k):
        block.append(v)
        v = int(v * rng.uniform(1.3, 2.2)) + rng.randint(1, max(1, n))
    return sorted(set(base) | set(block))


def _seed_two_intervals(rng):
    n = rng.randint(10, 60)
    m = rng.randint(5, 40)
    s = rng.randint(n, 4 * (n + m))
    return sorted(set(range(n)) | {s + i for i in range(m)})


def _seed_ap_plus_interval(rng):
    """interval {0..n-1} plus an arithmetic progression with a tuned start."""
    n = rng.randint(20, 80)
    d = rng.randint(n, 5 * n)
    cnt = rng.randint(3, 12)
    start = rng.randint(n, 3 * n)
    extra = {start + i * d for i in range(cnt)}
    return sorted(set(range(n)) | extra)


def _local_descent(start, deadline, rng):
    cur = sorted(set(start))
    cur_s = _score(cur)
    best = cur[:]
    best_s = cur_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        improved = False
        # try shifting each element a bit
        for _ in range(len(cur)):
            i = rng.randrange(len(cur))
            old = cur[i]
            step = max(1, hi // max(2, len(cur)))
            for delta in (rng.randint(-step, step), -old if old != 0 else 1):
                if old + delta in cur and delta != 0:
                    continue
                cand = cur[:]
                cand[i] = old + delta
                cand = sorted(set(cand))
                if len(cand) < 2 or len(cand) > 4000:
                    continue
                s = _score(cand)
                if s > cur_s:
                    cur, cur_s = cand, s
                    improved = True
                    if s > best_s:
                        best, best_s = cand[:], s
                    break
            if time.time() > deadline:
                break
        if not improved:
            # random big jump / add / remove
            r = rng.random()
            if r < 0.4:
                cand = cur[:]
                anchor = rng.choice(cand)
                cand.append(anchor + rng.randint(-hi, hi))
            elif r < 0.7 and len(cur) > 3:
                cand = cur[:]
                del cand[rng.randrange(len(cand))]
            else:
                cand = _seed_interval_plus_block(rng)
            cand = sorted(set(cand))
            if 2 <= len(cand) <= 4000:
                s = _score(cand)
                if s >= cur_s:
                    cur, cur_s = cand, s
                    if s > best_s:
                        best, best_s = cand[:], s
                else:
                    cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 112

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    seeds = []
    for n in (10, 30, 60, 120):
        seeds.append(list(range(n)))
    for _ in range(30):
        seeds.append(_seed_interval_plus_block(rng))
    for _ in range(30):
        seeds.append(_seed_two_intervals(rng))
    for _ in range(30):
        seeds.append(_seed_ap_plus_interval(rng))

    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    attempts = 0
    while time.time() < deadline:
        attempts += 1
        r = attempts % 4
        if r == 0:
            start = _seed_interval_plus_block(rng)
        elif r == 1:
            start = _seed_two_intervals(rng)
        elif r == 2:
            start = _seed_ap_plus_interval(rng)
        else:
            start = best[:]
        cand, cs = _local_descent(start, min(deadline, time.time() + 8), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
