# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via greedy randomized construction."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats(a):
    a = list(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _grow_greedy(seed, deadline, rng, max_add=60):
    """Start from seed; repeatedly add the element maximizing marginal ratio."""
    A = list(set(seed))
    dset = {x - y for x in A for y in A}
    sset = {x + y for x in A for y in A}
    best = A[:]
    best_s = _score(A)
    adds = 0
    while adds < max_add and time.time() < deadline:
        adds += 1
        base = list(A)
        # candidate pool: combos of existing elements (sums -> keeps sumset small)
        cands = set()
        for _ in range(24):
            i = rng.randrange(len(base))
            j = rng.randrange(len(base))
            cands.add(base[i] + base[j])
            cands.add(base[i] - base[j])
            cands.add(base[i] + rng.randint(-3, 3))
        cands = [c for c in cands if abs(c) <= 10**12 and c not in A]

        best_c, best_gain = None, -1e18
        for x in cands:
            nd = set()
            ns = set()
            for a in base:
                nd.add(x - a)
                nd.add(a - x)
                ns.add(x + a)
            gain = len(nd | dset) - (len(ns | sset) - len(sset)) * 0.9
            # ratio-based: prefer many new diffs, few new sums
            score_est = len(nd) - 1.5 * len(ns - sset)
            if score_est > best_gain:
                best_gain = score_est
                best_c = x
        if best_c is None:
            break
        A.append(best_c)
        for a in base:
            dset.add(best_c - a)
            dset.add(a - best_c)
            sset.add(best_c + a)
        dset.add(0)
        sset.add(2 * best_c)
        s = _score(A)
        if s > best_s:
            best, best_s = A[:], s
    return best, best_s


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # candidate seeds
    seeds = []
    for n in (2, 3, 4, 5, 6, 8, 10):
        seeds.append(list(range(n)))
    for _ in range(30):
        seeds.append([0, rng.randint(5, 60)])
    # geometric starters
    for _ in range(15):
        A = [rng.randint(-3, 3)]
        for _ in range(rng.randint(2, 5)):
            A.append(A[-1] + rng.choice([1, 2, 3]))
        seeds.append(A)

    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    # greedy growth restarts
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 2 == 0:
            start = [0, rng.randint(10, 80)]
        else:
            start = best[:]
        cand, cs = _grow_greedy(start, time.time() + 8, rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    # final prune: remove elements that don't add differences
    A = list(set(best))
    improved = True
    while improved and time.time() < deadline:
        improved = False
        base_s = _score(A)
        di, si, _ = _stats(A)
        for i in range(len(A)):
            trial = A[:i] + A[i + 1:]
            if len(trial) < 3:
                continue
            ts = _score(trial)
            if ts >= base_s:
                A = trial
                base_s = ts
                improved = True
                break

    if _score(A) > best_s:
        best = A

    return sorted(set(best))
# EVOLVE-BLOCK-END
