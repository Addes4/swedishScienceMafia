# EVOLVE-BLOCK-START
"""Targeted construction + incremental local search for many differences, few sums."""
import math
import time


def _scores(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)), len(diffs), len(sums)


def _full(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return diffs, sums


def _score_only(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    ls = len(sums)
    if ls < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(ls) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110.0

    # Seed: compact interval core + geometric (powers of 2) block scaled and shifted.
    def build(n_core, exponents, shift):
        A = set(range(n_core))
        base = n_core + shift
        for e in exponents:
            A.add(base * (1 << e))
        return sorted(A)

    seeds = []
    # Try several core sizes and geometric blocks.
    for n_core in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20):
        for k in (2, 3, 4, 5, 6, 7, 8):
            exponents = list(range(k))
            shift = 1
            seeds.append(build(n_core, exponents, shift))
    # Also symmetric / shifted variants.
    seeds.append(sorted(set([0, 1, 2, 3, 4, 8, 16, 32, 64, 128, 256])))
    seeds.append(sorted(set([0, 1, 2, 3, 5, 8, 13, 21, 34, 55])))

    best = None
    best_score = -1.0
    for s in seeds:
        sc = _score_only(s)
        if sc > best_score:
            best_score = sc
            best = s[:]
        if time.time() > deadline:
            break

    # Local search: try replacing an element or appending one; accept improvements.
    A = best[:]
    step_pool = list(range(1, 64)) + [100, 256, 1000, 4096, 65536, 1 << 20, 1 << 30]
    improving = True
    while improving and time.time() < deadline:
        improving = False
        cur_score = _score_only(A)
        # Try single element perturbations.
        for i in range(len(A)):
            orig = A[i]
            for d in step_pool:
                if time.time() > deadline:
                    break
                for sign in (1, -1):
                    A[i] = orig + sign * d
                    if A[i] in A and A[i] != orig:
                        # duplicate: skip quickly
                        A[i] = orig
                        continue
                    if len(set(A)) != len(A):
                        A[i] = orig
                        continue
                    sc = _score_only(A)
                    if sc > cur_score + 1e-12:
                        cur_score = sc
                        orig = A[i]
                        improving = True
                        break
                    else:
                        A[i] = orig
                if improving:
                    break
            if improving:
                break
        if improving:
            continue
        # Try appending an element.
        for d in step_pool:
            if time.time() > deadline:
                break
            for base_add in (max(A) + d, min(A) - d, d):
                if base_add in A:
                    continue
                A.append(base_add)
                sc = _score_only(A)
                if sc > cur_score + 1e-12:
                    cur_score = sc
                    improving = True
                    break
                else:
                    A.pop()
            if improving:
                break
        if improving:
            continue
        # Try removing an element if it helps ratio (small n).
        if len(A) > 3:
            for i in range(len(A)):
                if time.time() > deadline:
                    break
                removed = A.pop(i)
                sc = _score_only(A)
                if sc > cur_score + 1e-12:
                    cur_score = sc
                    improving = True
                    break
                else:
                    A.insert(i, removed)
            if improving:
                continue

    return sorted(set(A))
# EVOLVE-BLOCK-END
