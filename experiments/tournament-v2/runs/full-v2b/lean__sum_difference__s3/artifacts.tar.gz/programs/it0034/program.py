# EVOLVE-BLOCK-START
"""Interval core plus difference-rich tail, optimized by fast exact hill-climb."""
import math
import time


def _counts(a):
    a = sorted(set(a))
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    d, s, _ = _counts(a)
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 100

    # Pure interval: |A-A| = |A+A| = 2n-1, ratio 1.0 exactly.
    # Add a geometric-ish tail scaled so that its sums overlap the interval sum range,
    # increasing |A-A| faster than |A+A|.
    best = None
    best_score = -1.0

    # Base interval size
    for N in (200, 400, 800):
        base = list(range(N))
        s = _score(base)
        if s > best_score:
            best_score = s
            best = base

    # Try adding a scaled structured tail to a base interval.
    for N in (100, 200, 400):
        base = list(range(N))
        # tail: powers of 2 scaled to sit just above the interval span so that
        # differences create many new values but sums mostly land in overlapping ranges.
        for k in (6, 8, 10, 12):
            for M in range(N + 1, N + 40):
                tail = [M * (2 ** i) for i in range(k)]
                cand = base + tail
                if time.time() > deadline:
                    break
                s = _score(cand)
                if s > best_score:
                    best_score = s
                    best = cand[:]
        if time.time() > deadline:
            break

    # Local hill-climb: perturb values, accept improvements.
    cur = best[:] if best else [0, 1]
    cur_score = best_score
    while time.time() < deadline:
        improved = False
        for _ in range(50):
            if time.time() > deadline:
                break
            cand = cur[:]
            idx = len(cand) - 1
            cand[idx] += (1 if (len(cand) + idx) % 2 == 0 else -1)
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            s = _score(cand)
            if s > cur_score:
                cur, cur_score = cand, s
                improved = True
                if s > best_score:
                    best, best_score = cand[:], s
        if not improved:
            # try appending a new element near the top
            cand = cur[:]
            cand.append(max(cur) + 1)
            s = _score(cand)
            if s > cur_score:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
            else:
                break

    return sorted(set(best)) if best else [0, 1]
# EVOLVE-BLOCK-END
