# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via fast numpy exact scoring + structured sweep."""
import math
import time
import numpy as np


def _score_np(a):
    """Exact score using numpy over a compact offset range."""
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    lo = int(a[0])
    hi = int(a[-1])
    # difference range: [-(hi-lo), hi-lo]; sum range: [2*lo, 2*hi]
    dr = hi - lo
    diff = np.zeros(2 * dr + 1, dtype=bool)
    srange = 2 * (hi - lo) + 1
    smin = 2 * lo
    sums = np.zeros(srange, dtype=bool)
    # outer differences/sums via broadcasting (n small in practice)
    d = a[:, None] - a[None, :] + dr
    s = a[:, None] + a[None, :] - smin
    diff[d.ravel()] = True
    sums[s.ravel()] = True
    nd = int(diff.sum())
    ns = int(sums.sum())
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def _score(a):
    return _score_np(a)[0]


def _two_block(n, m, M, s):
    return list(range(n)) + [M + s * i for i in range(m)]


def solve():
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)[0]

    # deterministic sweep over two-block family
    for n in range(1, 30):
        for m in range(1, 30):
            for s in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20):
                if time.time() > deadline:
                    break
                for M in range(n, n + 6 * 40, 3):
                    A = _two_block(n, m, M, s)
                    sc = _score(A)[0]
                    if sc > best_s:
                        best, best_s = A, sc
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # interval + geometric block sweep
    for n in range(1, 20):
        for k in range(1, 6):
            for sc0 in (n * 2, n * 3, n * 4, n * 8, n * 16):
                for ratio in (2, 3, 4):
                    if time.time() > deadline:
                        break
                    pts = []
                    v = sc0
                    for _ in range(k):
                        pts.append(v)
                        v = v * ratio + 1
                    A = list(range(n)) + pts
                    sc = _score(A)[0]
                    if sc > best_s:
                        best, best_s = A, sc
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # local refine best: try nudging M and s slightly
    if best:
        improved = True
        while improved and time.time() < deadline:
            improved = False
            cur = best
            nset = set(cur)
            base = _score(cur)[0]
            for delta in (-2, -1, 1, 2):
                for i in range(len(cur)):
                    cand = cur[:]
                    cand[i] += delta
                    cand = list(set(cand))
                    if len(cand) < 2:
                        continue
                    sc = _score(cand)[0]
                    if sc > best_s:
                        best, best_s = cand, sc
                        improved = True
                        break
                if improved:
                    break

    return sorted(set(best))
# EVOLVE-BLOCK-END
