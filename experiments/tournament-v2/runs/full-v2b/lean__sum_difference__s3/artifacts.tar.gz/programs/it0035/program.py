# EVOLVE-BLOCK-START
"""Deterministic parameter sweep: interval core + scaled geometric block."""
import math
from itertools import product


def _stats(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score_counts(nd, ns, na):
    if na < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / na) / 100


def solve():
    best = None
    best_score = -1.0

    # family: A = {0..n-1} U {base + M*2^i : i<k}
    # sweep n, k, M, base
    for n in [4, 8, 12, 16, 20, 25, 30, 40, 50]:
        core = list(range(n))
        for k in [3, 4, 5, 6]:
            for M in [n, 2 * n, 3 * n, 4 * n, 8 * n, 16 * n, 32 * n]:
                block = [M * (2 ** i) for i in range(k)]
                for base in [0, n, 2 * n, M // 2, M]:
                    a = core + [base + b for b in block]
                    if len(set(a)) != len(a):
                        continue
                    nd, ns = _stats(a)
                    s = _score_counts(nd, ns, len(a))
                    if s > best_score:
                        best_score = s
                        best = a
    return sorted(set(best))
# EVOLVE-BLOCK-END

