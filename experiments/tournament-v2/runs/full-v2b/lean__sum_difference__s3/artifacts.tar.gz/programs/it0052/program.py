# EVOLVE-BLOCK-START
"""Incremental exact hill-climb for max log|A-A| / log|A+A|."""
import math
import random
import time


def _distinct(dc):
    return sum(1 for v in dc.values() if v > 0)


def _score_from_counts(nd, ns, n):
    if n < 2 or ns < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _build_counts(A):
    d = {}
    s = {}
    for x in A:
        for y in A:
            d[x - y] = d.get(x - y, 0) + 1
            s[x + y] = s.get(x + y, 0) + 1
    return d, s


def _add_elem(A, dc, sc, x):
    for y in A:
        k = x - y
        dc[k] = dc.get(k, 0) + 1
        k = y - x
        dc[k] = dc.get(k, 0) + 1
        k = x + y
        sc[k] = sc.get(k, 0) + 1
    dc[0] = dc.get(0, 0) + 1
    sc[x + x] = sc.get(x + x, 0) + 1
    A.append(x)


def _remove_elem(A, dc, sc, idx):
    x = A[idx]
    A[idx] = A[-1]
    A.pop()
    for y in A:
        k = x - y
        dc[k] -= 1
        k = y - x
        dc[k] -= 1
        k = x + y
        sc[k] -= 1
    dc[0] -= 1
    sc[x + x] -= 1


def _hill_climb(start, deadline, rng):
    A = list(set(start))
    if len(A) < 2:
        return A
    dc, sc = _build_counts(A)
    nd = _distinct(dc)
    ns = _distinct(sc)
    cur_s = _score_from_counts(nd, ns, len(A))
    best = A[:]
    best_s = cur_s
    allvals = sorted(set(A))
    hi = max(abs(v) for v in A) if A else 1
    step = max(1, hi // 4)

    while time.time() < deadline:
        r = rng.random()
        n = len(A)
        if r < 0.45:
            # move an element
            i = rng.randrange(n)
            x = A[i]
            delta = rng.randint(-step, step)
            if delta == 0:
                continue
            _remove_elem(A, dc, sc, i)
            _add_elem(A, dc, sc, x + delta)
            nd = _distinct(dc)
            ns = _distinct(sc)
            s = _score_from_counts(nd, ns, len(A))
            if s >= cur_s:
                cur_s = s
                if s > best_s:
                    best_s = s
                    best = A[:]
            else:
                _remove_elem(A, dc, sc, len(A) - 1)
                _add_elem(A, dc, sc, x)
                nd = _distinct(dc)
                ns = _distinct(sc)
        elif r < 0.8 and n < 4000:
            # add element
            anchor = A[rng.randrange(n)]
            newv = anchor + rng.randint(-hi, hi)
            if newv in A:
                continue
            _add_elem(A, dc, sc, newv)
            nd = _distinct(dc)
            ns = _distinct(sc)
            s = _score_from_counts(nd, ns, len(A))
            if s >= cur_s:
                cur_s = s
                if s > best_s:
                    best_s = s
                    best = A[:]
            else:
                _remove_elem(A, dc, sc, len(A) - 1)
                nd = _distinct(dc)
                ns = _distinct(sc)
        elif r < 0.95 and n > 4:
            # remove element
            i = rng.randrange(n)
            x = A[i]
            _remove_elem(A, dc, sc, i)
            nd = _distinct(dc)
            ns = _distinct(sc)
            s = _score_from_counts(nd, ns, len(A))
            if s >= cur_s:
                cur_s = s
                if s > best_s:
                    best_s = s
                    best = A[:]
            else:
                _add_elem(A, dc, sc, x)
                nd = _distinct(dc)
                ns = _distinct(sc)
        else:
            # restart from best
            A = best[:]
            dc, sc = _build_counts(A)
            nd = _distinct(dc)
            ns = _distinct(sc)
            cur_s = best_s
    return best


def _seed_interval_sidon(rng):
    """A = {0..n-1} union (M + scale * Sidon-ish block)."""
    n = rng.randint(10, 60)
    base = set(range(n))
    k = rng.randint(3, 7)
    # greedy Sidon-ish block
    T = [0]
    while len(T) < k:
        v = T[-1] + rng.randint(1, 8)
        cand = {abs(a - b) for a in T + [v] for b in T + [v]
                if a != b}
        if len(cand) == len(T) * (len(T) + 1):
            T.append(v)
        else:
            T[-1] = v
            if T[-1] > 60:
                break
    T = sorted(set(T))
    scale = rng.choice([1, n, 2 * n, 4 * n, 8 * n])
    M = rng.randint(n, 8 * (n + scale * (max(T) + 1)))
    pts = {M + scale * t for t in T}
    return sorted(base | pts)


def solve():
    rng = random.Random(2024)
    deadline = time.time() + 110

    best = [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
    best_s = _score_from_counts(
        len({x - y for x in best for y in best}),
        len({x + y for x in best for y in best}),
        len(best),
    )

    seeds = []
    for n in (10, 20, 40):
        seeds.append(list(range(n)))
    for _ in range(60):
        seeds.append(_seed_interval_sidon(rng))

    for seed in seeds:
        if len(seed) < 2:
            continue
        d, s = _build_counts(seed)
        sc = _score_from_counts(_distinct(d), _distinct(s), len(seed))
        if sc > best_s:
            best, best_s = seed[:], sc

    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 3 == 0:
            start = _seed_interval_sidon(rng)
        elif attempts % 3 == 1:
            start = best[:]
        else:
            start = _seed_interval_sidon(rng)
        cand = _hill_climb(start, min(deadline, time.time() + 10), rng)
        if len(cand) >= 2:
            d, s = _build_counts(cand)
            sc = _score_from_counts(_distinct(d), _distinct(s), len(cand))
            if sc > best_s:
                best, best_s = cand[:], sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
