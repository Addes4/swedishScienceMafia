# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via bitset scorer + parametric sweep."""
import math
import time


def _popcount_set(vals):
    """Number of distinct ints in vals using a Python-int bitset."""
    m = 0
    for v in vals:
        m |= 1 << v
    return bin(m).count("1")


def _score_arrays(diffs_vals, sums_vals, n):
    if n < 2:
        return 0.0
    dd = len(set(diffs_vals))
    ss = len(set(sums_vals))
    if ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss) + (1 - 1 / n) / 100


def _stats(A):
    n = len(A)
    diffs = set()
    sums = set()
    for x in A:
        for y in A:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), n


def _fast_score(A):
    """Exact score using bitsets over shifted non-negative coordinates."""
    A = list(set(A))
    n = len(A)
    if n < 2:
        return 0.0
    lo = min(A)
    A2 = [a - lo for a in A]
    maxv = max(A2)
    # differences: shift by maxv
    diffs = set()
    for x in A2:
        for y in A2:
            diffs.add(x - y)
    sums = set()
    for x in A2:
        for y in A2:
            sums.add(x + y)
    if len(sums) < 2 or len(diffs) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _candidate(n, m, M, s):
    """A = [0,n) union {M + s*j : j in [0,m)}."""
    A = list(range(n))
    A.extend(M + s * j for j in range(m))
    return sorted(set(A))


def solve():
    deadline = time.time() + 110
    best = [0, 1, 2, 3, 5, 8, 13]
    best_s = _fast_score(best)

    # Sanity: pure interval
    for n in (10, 20, 40, 80, 160):
        A = list(range(n))
        s = _fast_score(A)
        if s > best_s:
            best, best_s = A, s

    # Parametric sweep of the interval + scaled-interval family.
    # Keep the second block's width W = s*m moderate so internal differences
    # stay small; place M so sums overlap with [0, 2(n-1)] plus own range.
    ns = [3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 18, 20, 24, 28]
    ms = [1, 2, 3, 4, 5, 6, 8, 10]
    for n in ns:
        if time.time() > deadline:
            break
        for m in ms:
            if n + m > 300:
                continue
            # Widths s*m roughly comparable to n or a bit larger
            for W in range(m, max(2 * n + m, m + 1) + 1):
                if time.time() > deadline:
                    break
                if W % m != 0:
                    continue
                s = W // m
                if s < 1:
                    continue
                # M around n so second block hugs the interval end.
                for M in range(n - 1, n + W + n + 1):
                    A = _candidate(n, m, M, s)
                    sc = _fast_score(A)
                    if sc > best_s:
                        best, best_s = A, sc

    # Random/greedy refinement: adjust individual elements.
    import random
    rng = random.Random(987654321)

    def refine(A, deadline):
        A = list(set(A))
        cs = _fast_score(A)
        hi = max(abs(x) for x in A)
        span = max(1, (hi - min(A)) // 2 + 1)
        while time.time() < deadline:
            improved = False
            now = time.time()
            for _ in range(40):
                if time.time() > deadline:
                    break
                B = A[:]
                i = rng.randrange(len(B))
                B[i] = B[i] + rng.randint(-span, span)
                B = sorted(set(B))
                if len(B) < 2 or len(B) > 4000:
                    continue
                sc = _fast_score(B)
                if sc > cs + 1e-12:
                    A, cs = B, sc
                    improved = True
                    if cs > best_s:
                        break
            if not improved:
                span = max(1, span // 2)
                if span == 1 and not improved:
                    break

    # Refine multiple seeds near the current best structure.
    while time.time() < deadline:
        seed = _candidate(
            rng.randint(8, 25),
            rng.randint(2, 6),
            rng.randint(10, 120),
            rng.randint(1, 8),
        )
        refine(seed, min(deadline, time.time() + 8))
        # also refine the global best occasionally
        if time.time() < deadline:
            refine(best[:], min(deadline, time.time() + 8))

    # Final polish of the current best
    refine(best[:], deadline)

    return sorted(set(best))
# EVOLVE-BLOCK-END
