# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via fast exact bitset scorer + structured sweep."""
import math
import random
import time
from bisect import bisect_left


def _encode(a):
    return a


def _score_fast(a):
    """Exact log|A-A|/log|A+A| using Python sets (n small here)."""
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(len(a)):
        ai = a[i]
        for j in range(len(a)):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _score(a):
    return _score_fast(a)


def _two_block(n, m, s, M):
    return sorted(set(range(n)) | {M + s * i for i in range(m)})


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best = [0, 1, 2, 3, 4, 5, 6, 7]
    best_s = _score(best)

    # Deterministic sweep over two-block family.
    # A = [0,n) union {M + s*i : i<m}
    for n in range(4, 61):
        for m in range(3, 41):
            for s in range(1, 30):
                # tuned offsets spanning plausible separations
                lo = n + 1
                hi = n + 4 * (n + m * s) + 50
                step = max(1, (hi - lo) // 12)
                M = lo
                while M <= hi:
                    A = list(range(n)) + [M + s * i for i in range(m)]
                    A = sorted(set(A))
                    if len(A) < 2:
                        M += step
                        continue
                    sc = _score(A)
                    if sc > best_s:
                        best_s = sc
                        best = A
                    M += step
            if time.time() > deadline - 30:
                break
        if time.time() > deadline - 30:
            break

    # Light randomized local search from the best found.
    cur = best[:]
    cur_s = best_s
    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.4 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-3, 3)
        elif op < 0.7 and cand:
            cand.append(rng.choice(cand) + rng.randint(-20, 20))
        elif len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        sc = _score(cand)
        if sc >= cur_s:
            cur, cur_s = cand, sc
            if sc > best_s:
                best, best_s = cand[:], sc
        elif rng.random() < 0.1:
            cur, cur_s = best[:], best_s

    return best
# EVOLVE-BLOCK-END
