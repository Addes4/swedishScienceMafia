# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeds + fast incremental hill-climb."""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), n


def _score_counts(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    nd, ns, n = _stats(a)
    return _score_counts(nd, ns, n)


def _counts(a):
    diffs = {}
    sums = {}
    for x in a:
        for y in a:
            diffs[x - y] = diffs.get(x - y, 0) + 1
            sums[x + y] = sums.get(x + y, 0) + 1
    return diffs, sums


def _delta_add(a, diffs, sums, v):
    """Delta counts if adding v. Returns (dd, ds)."""
    dd = 1  # v - v = 0 already present since 0 in diffs (any self-diff) -> handle below
    ds = 0
    # v - x and x - v for x in a
    for x in a:
        if diffs.get(v - x, 0) == 0:
            dd += 1
        if diffs.get(x - v, 0) == 0:
            dd += 1
        if sums.get(v + x, 0) == 0:
            ds += 1
    # self terms
    if diffs.get(0, 0) == 0:
        dd += 1
    if sums.get(2 * v, 0) == 0:
        ds += 1
    return dd, ds


def _delta_remove(a, diffs, sums, v):
    """Delta counts if removing v (a currently includes v)."""
    dd = 0
    ds = 0
    for x in a:
        if x == v:
            continue
        if diffs.get(v - x, 0) == 1:
            dd -= 1
        if diffs.get(x - v, 0) == 1:
            dd -= 1
        if sums.get(v + x, 0) == 1:
            ds -= 1
    if diffs.get(0, 0) == 1:
        dd -= 1
    if sums.get(2 * v, 0) == 1:
        ds -= 1
    return dd, ds


def _seed_interval_plus_block(rng, n=None, k=None, scale=None):
    if n is None:
        n = rng.randint(8, 40)
    base = list(range(n))
    if k is None:
        k = rng.randint(2, 5)
    if scale is None:
        scale = rng.choice([n * 2, n * 3, n * 5, n * 8])
    pts = set()
    v = scale
    for _ in range(k):
        pts.add(v)
        v = int(v * rng.uniform(1.6, 2.4)) + rng.randint(0, max(1, scale))
    return sorted(set(base) | pts)


def _seed_twoblocks(rng):
    n = rng.randint(6, 30)
    m = rng.randint(3, 20)
    s = rng.randint(n + 1, 6 * (n + m))
    A = set(range(n))
    A |= {s + i for i in range(m)}
    return sorted(A)


def _incremental_climb(start, deadline, rng):
    a = list(set(start))
    if len(a) < 2:
        return a, _score(a)
    diffs, sums = _counts(a)
    nd = len(diffs)
    ns = len(sums)
    best = a[:]
    best_s = _score_counts(nd, ns, len(a))
    cur_s = best_s
    hi = max(abs(x) for x in a)
    while time.time() < deadline:
        r = rng.random()
        if r < 0.6 and a:
            # shift one element
            i = rng.randrange(len(a))
            old = a[i]
            span = max(1, hi // 3)
            new = old + rng.randint(-span, span)
            if new == old:
                continue
            # compute removal of old
            ddr, dsr = _delta_remove(a, diffs, sums, old)
            # temporarily remove old
            a[i] = new
            # compute add of new given a with new in place is wrong; do proper
            a[i] = old
            # remove old from counts
            nd2 = nd + ddr
            ns2 = ns + dsr
            if ns2 < 2:
                continue
            # build state w/o old
            a2 = a[:i] + a[i + 1:]
            # counts for a2
            d2, s2 = _counts(a2) if len(a2) <= 60 else (diffs, sums)
            # For speed, rebuild only when small; else we approximate via full rebuild fallback
            d2, s2 = _counts(a2)
            dda, dsa = _delta_add(a2, d2, s2, new)
            nnd = len(d2) + dda
            nns = len(s2) + dsa
            s_new = _score_counts(nnd, nns, len(a))
            if s_new >= cur_s or rng.random() < 0.05:
                a = a2
                a.append(new)
                diffs, sums = _counts(a)
                nd = len(diffs)
                ns = len(sums)
                cur_s = s_new
                if s_new > best_s:
                    best, best_s = a[:], s_new
                    hi = max(abs(x) for x in a)
        elif r < 0.85:
            # add new element
            anchor = rng.choice(a) if a else 0
            v = anchor + rng.randint(-hi, hi)
            if v in a:
                continue
            dda, dsa = _delta_add(a, diffs, sums, v)
            nnd = nd + dda
            nns = ns + dsa
            if len(a) >= 4000 or nns < 2:
                continue
            s_new = _score_counts(nnd, nns, len(a) + 1)
            if s_new >= cur_s or rng.random() < 0.05:
                a.append(v)
                diffs, sums = _counts(a)
                nd = len(diffs)
                ns = len(sums)
                cur_s = s_new
                if s_new > best_s:
                    best, best_s = a[:], s_new
                    hi = max(abs(x) for x in a)
        else:
            # remove element
            if len(a) <= 3:
                continue
            i = rng.randrange(len(a))
            v = a[i]
            ddr, dsr = _delta_remove(a, diffs, sums, v)
            del a[i]
            diffs, sums = _counts(a)
            nd = len(diffs)
            ns = len(sums)
            cur_s = _score_counts(nd, ns, len(a))
    return best, best_s


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    seeds = []
    for n in (10, 20, 40, 80, 120):
        seeds.append(list(range(n)))
    for _ in range(30):
        seeds.append(_seed_interval_plus_block(rng))
    for _ in range(30):
        seeds.append(_seed_twoblocks(rng))

    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 3 == 0:
            start = _seed_interval_plus_block(rng)
        elif attempts % 3 == 1:
            start = _seed_twoblocks(rng)
        else:
            start = best[:]
        cand, cs = _incremental_climb(start, min(deadline, time.time() + 10), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
