# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via fast exact scorer + simulated annealing."""
import math
import random
import time

import numpy as np


def _counts(a):
    """Return (|A-A|, |A+A|, n) using numpy bitsets over compact range."""
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0, 0, n
    diff = np.subtract.outer(a, a).ravel()
    ssum = np.add.outer(a, a).ravel()
    dmin, dmax = diff.min(), diff.max()
    smin, smax = ssum.min(), ssum.max()
    # counts via unique on sorted arrays is O(k log k) but fine for small n
    nd = int(np.unique(diff).size)
    ns = int(np.unique(ssum).size)
    return nd, ns, n


def _score(a):
    nd, ns, n = _counts(a)
    if ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _seed_twoblocks(rng):
    """A = [0,n) union (M + s*[0,m)) with s large relative to n."""
    n = rng.randint(3, 12)
    m = rng.randint(3, 12)
    s = rng.randint(n + 1, 4 * (n + m))
    M = rng.randint(s * max(1, s), max(s * s, n + m + 1))
    A = set(range(n))
    A |= {M + s * i for i in range(m)}
    return sorted(A)


def _seed_interval_geom(rng):
    n = rng.randint(3, 15)
    k = rng.randint(3, 8)
    scale = rng.choice([n * 2 + 1, n * 3, n * 5, n * 8])
    A = set(range(n))
    v = scale
    for _ in range(k):
        A.add(v)
        v = int(v * rng.uniform(1.7, 3.0)) + rng.randint(0, scale + 1)
    return sorted(A)


def _anneal(start, deadline, rng):
    cur = list(set(start))
    cur_s = _score(cur)
    best, best_s = cur[:], cur_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.55 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi)
            cand[i] += rng.randint(-span, span)
        elif r < 0.80:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-2 * hi, 2 * hi))
        elif r < 0.92 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            cand = [x - cand[0] if cand else 0 for x in cand]
        cand = list(set(int(x) for x in cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.05:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best = [0, 1, 2, 3, 10000, 10001, 10002]
    best_s = _score(best)

    # deterministic structured seeds
    for n in range(3, 10):
        for m in range(3, 10):
            for s in range(n + 1, n + m + 10):
                M = s * s
                A = list(range(n)) + [M + s * i for i in range(m)]
                sc = _score(A)
                if sc > best_s:
                    best, best_s = A, sc

    # anneal from many restarts
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        r = attempts % 3
        if r == 0:
            start = _seed_twoblocks(rng)
        elif r == 1:
            start = _seed_interval_geom(rng)
        else:
            start = best[:]
        cand, cs = _anneal(start, min(deadline, time.time() + 10), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
