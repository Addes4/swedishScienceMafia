# EVOLVE-BLOCK-START
"""Simulated annealing + best-of-restarts search for sets with many differences, few sums."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return 0.0
    ds = set()
    ss = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            ds.add(ai - aj)
            ss.add(ai + aj)
    return math.log(len(ds)) / math.log(len(ss)) + (1 - 1 / n) / 100


def _build_geometric(n):
    # power-of-two block: very difference-rich
    return [1 << i for i in range(n)]


def _build_ap_block(k, step):
    return [i * step for i in range(1, k + 1)]


def _build_mixed():
    # geometric block plus AP core
    A = set()
    for i in range(11):
        A.add(1 << i)
    for i in range(1, 8):
        A.add(i)
    return list(A)


def _anneal(seed, deadline):
    cur = list(set(seed))
    cur_score = _score_fast(cur)
    best = cur[:]
    best_score = cur_score
    scale = 40.0
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.55 and len(cand) > 3:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-scale, scale)
            cand[i] = int(cand[i])
        elif op < 0.8:
            cand.append(random.randint(-200, 200))
        elif len(cand) > 4:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            continue
        cand = list(set(cand))
        if any(abs(x) > 10**15 for x in cand):
            continue
        s = _score_fast(cand)
        if s >= cur_score or random.random() < math.exp((s - cur_score) * 20):
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
    return best, best_score


def solve():
    deadline = time.time() + 110
    best = _build_mixed()
    best_score = _score(best)
    seeds = [
        _build_mixed(),
        _build_geometric(12),
        _build_geometric(11) + list(range(1, 9)),
        _build_ap_block(9, 1) + [100, 400, 900, 1600, 2500],
        list(range(1, 10)) + [64, 128, 256, 512, 1024, 2048, 4096],
    ]
    idx = 0
    while time.time() < deadline:
        seed = seeds[idx % len(seeds)]
        idx += 1
        local_deadline = min(deadline, time.time() + 6)
        cand, s = _anneal(seed, local_deadline)
        cand = list(set(cand))
        if s > best_score:
            best, best_score = cand, s
        # perturb seed for next round
        seeds.append([x + random.randint(-30, 30) for x in cand])
    return sorted(set(best))
# EVOLVE-BLOCK-END
