# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via interval + far block
plus an exact incremental local search (cheap diff/sum multiplicity updates)."""
import math
import random
import time
from collections import defaultdict

RNG = random.Random(98765)
DEADLINE = None


def _stats_full(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score_vals(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100.0


def _score(a):
    a = list(set(a))
    nd, ns = _stats_full(a)
    return _score_vals(nd, ns, len(a))


def _seed(rng):
    """interval {0..n-1} union a far block with tuned spacing."""
    n = rng.randint(10, 60)
    A = set(range(n))
    k = rng.randint(2, 8)
    # far block placed at large offset so sums with interval are new but
    # internal block differences many
    off = rng.choice([n, 2 * n, 4 * n, 10 * n, 50 * n, 200 * n])
    mode = rng.random()
    if mode < 0.5:
        # scaled copy near off
        scale = rng.choice([1, 2, 3, off // max(1, n)])
        scale = max(1, scale)
        for i in range(k):
            A.add(off + i * scale)
    else:
        # geometric-ish sparse block
        v = off + 1
        for _ in range(k):
            A.add(v)
            v = int(v * rng.uniform(1.3, 2.2)) + rng.randint(0, max(1, n))
    return sorted(A)


class Incremental:
    """Maintain multiset of diffs and sums for a set A with cheap single moves."""

    __slots__ = ("A", "dcount", "scount", "nd", "ns")

    def __init__(self, A):
        self.A = list(dict.fromkeys(A))
        self.dcount = defaultdict(int)
        self.scount = defaultdict(int)
        nd = 0
        ns = 0
        A = self.A
        for i, x in enumerate(A):
            for j, y in enumerate(A):
                d = x - y
                if self.dcount[d] == 0:
                    nd += 1
                self.dcount[d] += 1
                s = x + y
                if self.scount[s] == 0:
                    ns += 1
                self.scount[s] += 1
        self.nd = nd
        self.ns = ns

    def _add_contrib(self, x):
        """new distinct diffs/sums contributed by adding x (before adding)."""
        nd0 = 0
        ns0 = 0
        for y in self.A:
            d = x - y
            if self.dcount[d] == 0:
                nd0 += 1
            d2 = y - x
            if d2 != d and self.dcount[d2] == 0:
                nd0 += 1
            s = x + y
            if self.scount[s] == 0:
                ns0 += 1
        # self pair x-x, x+x
        if self.dcount[0] == 0:
            nd0 += 1
        if self.scount[2 * x] == 0:
            ns0 += 1
        return nd0, ns0

    def add(self, x):
        if x in self.A:
            return
        nd0, ns0 = self._add_contrib(x)
        for y in self.A:
            self.dcount[x - y] += 1
            self.dcount[y - x] += 1
            self.scount[x + y] += 1
        self.dcount[0] += 1
        self.scount[2 * x] += 1
        self.nd += nd0
        self.ns += ns0
        self.A.append(x)

    def _remove_contrib(self, x):
        """distinct diffs/sums lost by removing x."""
        nd0 = 0
        ns0 = 0
        for y in self.A:
            if y == x:
                continue
            d = x - y
            if self.dcount[d] == 1:
                nd0 += 1
            d2 = y - x
            if d2 != d and self.dcount[d2] == 1:
                nd0 += 1
            s = x + y
            if self.scount[s] == 1:
                ns0 += 1
        if self.dcount[0] == 1:
            nd0 += 1
        if self.scount[2 * x] == 1:
            ns0 += 1
        return nd0, ns0

    def remove(self, x):
        if x not in self.A:
            return
        nd0, ns0 = self._remove_contrib(x)
        for y in self.A:
            if y == x:
                continue
            self.dcount[x - y] -= 1
            self.dcount[y - x] -= 1
            self.scount[x + y] -= 1
        self.dcount[0] -= 1
        self.scount[2 * x] -= 1
        self.A.remove(x)
        self.nd -= nd0
        self.ns -= ns0

    def replace(self, old, new):
        if new in self.A and new != old:
            return None
        # remove then add; exact
        self.remove(old)
        self.add(new)

    def score(self):
        return _score_vals(self.nd, self.ns, len(self.A))


def _local_search(inc, deadline, rng):
    best_score = inc.score()
    best_A = inc.A[:]
    hi = max(abs(x) for x in inc.A) if inc.A else 1
    span = max(1, hi // 2)
    while time.time() < deadline:
        cand = inc.A[:]
        r = rng.random()
        if r < 0.45 and cand:
            # perturb one element
            i = rng.randrange(len(cand))
            trial = cand[:]
            trial[i] += rng.randint(-span, span)
            if len(set(trial)) != len(trial):
                continue
            # evaluate by remove+add on copy
            snap_A = inc.A[:]
            snap_d = dict(inc.dcount)
            snap_s = dict(inc.scount)
            snap_nd = inc.nd
            snap_ns = inc.ns
            inc.remove(cand[i])
            if trial[i] in inc.A:
                inc.A = snap_A
                inc.dcount = defaultdict(int, snap_d)
                inc.scount = defaultdict(int, snap_s)
                inc.nd = snap_nd
                inc.ns = snap_ns
                continue
            inc.add(trial[i])
            s = inc.score()
            if s >= best_score:
                if s > best_score:
                    best_score = s
                    best_A = inc.A[:]
            else:
                inc.A = snap_A
                inc.dcount = defaultdict(int, snap_d)
                inc.scount = defaultdict(int, snap_s)
                inc.nd = snap_nd
                inc.ns = snap_ns
        elif r < 0.75:
            # add a new element near structure (favor far block offsets)
            if inc.A:
                anchor = rng.choice(inc.A)
                newv = anchor + rng.randint(-span, span)
            else:
                newv = 0
            if newv in inc.A:
                continue
            snap_A = inc.A[:]
            snap_d = dict(inc.dcount)
            snap_s = dict(inc.scount)
            snap_nd = inc.nd
            snap_ns = inc.ns
            inc.add(newv)
            s = inc.score()
            if s >= best_score:
                if s > best_score:
                    best_score = s
                    best_A = inc.A[:]
            else:
                inc.A = snap_A
                inc.dcount = defaultdict(int, snap_d)
                inc.scount = defaultdict(int, snap_s)
                inc.nd = snap_nd
                inc.ns = snap_ns
        elif r < 0.9 and len(inc.A) > 3:
            x = rng.choice(inc.A)
            snap_A = inc.A[:]
            snap_d = dict(inc.dcount)
            snap_s = dict(inc.scount)
            snap_nd = inc.nd
            snap_ns = inc.ns
            inc.remove(x)
            s = inc.score()
            if s >= best_score:
                if s > best_score:
                    best_score = s
                    best_A = inc.A[:]
            else:
                inc.A = snap_A
                inc.dcount = defaultdict(int, snap_d)
                inc.scount = defaultdict(int, snap_s)
                inc.nd = snap_nd
                inc.ns = snap_ns
        else:
            # replace element
            if not inc.A:
                continue
            x = rng.choice(inc.A)
            newv = x + rng.randint(-span, span)
            if newv in inc.A:
                continue
            snap_A = inc.A[:]
            snap_d = dict(inc.dcount)
            snap_s = dict(inc.scount)
            snap_nd = inc.nd
            snap_ns = inc.ns
            inc.remove(x)
            inc.add(newv)
            s = inc.score()
            if s >= best_score:
                if s > best_score:
                    best_score = s
                    best_A = inc.A[:]
            else:
                inc.A = snap_A
                inc.dcount = defaultdict(int, snap_d)
                inc.scount = defaultdict(int, snap_s)
                inc.nd = snap_nd
                inc.ns = snap_ns
    return best_A, best_score


def solve():
    global DEADLINE
    rng = RNG
    deadline = time.time() + 110
    DEADLINE = deadline

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # deterministic seeds
    for n in (10, 20, 40, 80):
        s = _score(list(range(n)))
        if s > best_s:
            best, best_s = list(range(n)), s

    for _ in range(60):
        seed = _seed(rng)
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    # multi-restart incremental local search
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 2 == 0:
            start = _seed(rng)
        else:
            start = best[:]
        inc = Incremental(start)
        s0 = inc.score()
        if s0 > best_s:
            best, best_s = inc.A[:], s0
        slot = min(deadline, time.time() + 15)
        cand, cs = _local_search(inc, slot, rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
