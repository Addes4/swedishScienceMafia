# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A|.

Targeted family: A = [0, n)  ∪  (M + s*[0, m))
Exact counts via offset-indexed boolean arrays over a bounded window.
"""
import math
import time


def _counts_from_sorted(a):
    """Exact |A-A|, |A+A| for a sorted list of distinct ints, using booleans."""
    n = len(a)
    if n < 2:
        return 0, 0, n
    # differences range in [a[0]-a[-1], a[-1]-a[0]]
    dmin = a[0] - a[-1]
    dmax = a[-1] - a[0]
    dsz = dmax - dmin + 1
    # sums range in [a[0]+a[0], a[-1]+a[-1]]
    smin = a[0] + a[0]
    smax = a[-1] + a[-1]
    ssz = smax - smin + 1
    diffs = bytearray(dsz)
    sums = bytearray(ssz)
    for i in range(n):
        ai = a[i]
        di = ai - dmin
        si = ai - smin
        for j in range(n):
            diffs[ai - a[j] - dmin] = 1
            sums[si + a[j]] = 1
    return sum(diffs), sum(sums), n


def _score(a):
    a = sorted(set(a))
    if len(a) < 2:
        return 0.0
    dc, sc, n = _counts_from_sorted(a)
    if sc < 2:
        return 0.0
    return math.log(dc) / math.log(sc) + (1 - 1 / n) / 100


def _build(n, m, M, s):
    A = set(range(n))
    A |= {M + s * i for i in range(m)}
    return sorted(A)


def solve():
    deadline = time.time() + 100
    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Sweep the structured family with exact scoring.
    for n in range(2, 46):
        if time.time() > deadline:
            break
        for m in range(2, 40):
            for M in range(n, 8 * (n + m), max(1, (n + m) // 2)):
                for s in (1, 2, 3, 4, 5, 6, 8, 10, 12, 16):
                    A = _build(n, m, M, s)
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score(A)
                    if sc > best_s:
                        best, best_s = A, sc
            if time.time() > deadline:
                break

    # Greedy refinement: shift/scale/translate the second block and tweak n,m.
    A = best[:]
    improved = True
    while improved and time.time() < deadline:
        improved = False
        n0 = len(A)
        # try removing each element
        for i in range(len(A)):
            cand = A[:i] + A[i + 1:]
            if len(cand) < 2:
                continue
            sc = _score(cand)
            if sc > best_s:
                best, best_s = cand, sc
                A = cand
                improved = True
                break
        if improved:
            continue
        # try shifting each element a little
        span = max(1, (A[-1] - A[0]) // 4) if len(A) > 1 else 1
        for i in range(len(A)):
            for d in (-span, -span // 2, -2, -1, 1, 2, span // 2, span):
                cand = A[:]
                cand[i] += d
                cand = sorted(set(cand))
                if len(cand) < 2 or len(cand) > 4000:
                    continue
                sc = _score(cand)
                if sc > best_s:
                    best, best_s = cand, sc
                    A = cand
                    improved = True
                    break
            if improved:
                break

    return sorted(set(best))
# EVOLVE-BLOCK-END
