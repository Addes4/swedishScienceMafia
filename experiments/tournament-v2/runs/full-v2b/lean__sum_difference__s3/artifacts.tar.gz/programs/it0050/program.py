# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeds + numpy-vectorised hill-climb."""
import math
import random
import time

import numpy as np


def _stats_np(arr):
    n = arr.shape[0]
    if n < 2:
        return 0, 0, n
    diffs = np.subtract.outer(arr, arr).ravel()
    sums = np.add.outer(arr, arr).ravel()
    return np.unique(diffs).size, np.unique(sums).size, n


def _score_arr(arr):
    nd, ns, n = _stats_np(arr)
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    if len(a) < 2:
        return 0.0
    return _score_arr(np.array(sorted(set(a)), dtype=np.int64))


def _golomb(limit, seed):
    """Greedy Sidon-like (Golomb ruler) core: distinct pairwise sums."""
    rng = random.Random(seed)
    marks = [0]
    used = {0}
    for _ in range(limit):
        cand = marks[-1] + 1
        found = False
        for _try in range(20000):
            ok = True
            for m in marks:
                d = cand - m
                if d in used:
                    ok = False
                    break
            if ok:
                marks.append(cand)
                for m in marks:
                    used.add(cand - m)
                found = True
                break
            cand += 1
        if not found:
            break
    return marks


def _build_interval_block(n, core, scale, offset):
    A = list(range(n))
    A += [offset + scale * c for c in core]
    return np.array(sorted(set(A)), dtype=np.int64)


def _hclimb(arr, deadline, rng, hi):
    best = arr.copy()
    best_s = _score_arr(best)
    cur = best.copy()
    cur_s = best_s
    while time.time() < deadline:
        cand = cur.copy()
        r = rng.random()
        if r < 0.55 and cand.size > 1:
            i = rng.randrange(cand.size)
            span = max(1, hi // 2)
            cand[i] += rng.randint(-span, span)
        elif r < 0.8:
            anchor = int(cand[rng.randrange(cand.size)])
            newv = anchor + rng.randint(-hi, hi)
            cand = np.append(cand, newv)
        elif r < 0.93 and cand.size > 3:
            i = rng.randrange(cand.size)
            cand = np.delete(cand, i)
        else:
            i = rng.randrange(cand.size)
            cand[i] += rng.choice([-1, 1]) * rng.randint(1, max(1, hi))
        cand = np.unique(cand)
        if cand.size < 2 or cand.size > 4000:
            continue
        s = _score_arr(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand.copy(), s
                hi = max(hi, int(np.max(np.abs(best))) or 1)
        elif rng.random() < 0.05:
            cur, cur_s = best.copy(), best_s
    return best, best_s


def solve():
    rng = random.Random(2024)
    deadline = time.time() + 110

    best = np.array([7, 15, 18, 22, -3, -2], dtype=np.int64)
    best_s = _score_arr(best)

    cores = {}
    for k in (6, 8, 10, 12, 14, 16, 20, 24):
        cores[k] = _golomb(k, k)

    # deterministic sweep over interval + scaled Sidon block
    for n in (8, 12, 16, 20, 25, 30, 40, 50, 60, 80):
        for k, core in cores.items():
            base_max = max(core) if core else 1
            span = base_max * max(1, n)
            for scale in (1, 2, 3, 5, 8, 13):
                for off_mult in (1, 2, 3, 4):
                    offset = n + off_mult * span
                    A = _build_interval_block(n, core, scale, offset)
                    if A.size < 2 or A.size > 4000:
                        continue
                    s = _score_arr(A)
                    if s > best_s:
                        best, best_s = A.copy(), s
        if time.time() > deadline:
            break

    # some random structured seeds then numpy hill climb
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        n = rng.randint(8, 60)
        k = rng.choice([6, 8, 10, 12, 16, 20])
        core = cores[k]
        base_max = max(core) if core else 1
        scale = rng.choice([1, 2, 3, 5, 8, 13])
        offset = n + rng.randint(1, 4) * base_max * max(1, n) + rng.randint(0, n)
        start = _build_interval_block(n, core, scale, offset)
        if attempts % 2 == 0:
            start = best.copy()
        hi = max(int(np.max(np.abs(start))) or 1, 1)
        cand, cs = _hclimb(start, min(deadline, time.time() + 10), rng, hi)
        if cs > best_s:
            best, best_s = cand.copy(), cs

    return sorted(int(x) for x in best)
# EVOLVE-BLOCK-END
