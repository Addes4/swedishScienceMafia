# EVOLVE-BLOCK-START
"""Constructive: compact AP core plus a far-shifted copy to grow differences without growing sums much."""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build(n, M):
    # core C = {0..n-1}, plus shifted copy C+M
    core = list(range(n))
    return core + [x + M for x in core]


def solve():
    """Return A with large |A-A| and small |A+A|."""
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    deadline = time.time() + 110

    # Sweep n and gap M for the two-block construction.
    checked = 0
    for n in range(2, 200):
        if time.time() > deadline:
            break
        # M large enough that the two blocks barely interact in sums,
        # but differences between blocks are fresh.
        for M in range(n, 6 * n + 5, max(1, n // 3)):
            if time.time() > deadline:
                break
            a = _build(n, M)
            if len(a) < 2 or len(a) > 4000:
                continue
            s = _score(a)
            checked += 1
            if s > best_score:
                best, best_score = a[:], s
    # also try 3 blocks
    for n in range(2, 120):
        if time.time() > deadline:
            break
        for M in range(n, 4 * n + 3, max(1, n // 3)):
            if time.time() > deadline:
                break
            a = list(range(n)) + [x + M for x in range(n)] + [x + 2 * M for x in range(n)]
            if len(a) < 2 or len(a) > 4000:
                continue
            s = _score(a)
            if s > best_score:
                best, best_score = a[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
