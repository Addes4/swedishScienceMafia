# EVOLVE-BLOCK-START
import math
import random
import time


def _counts(a):
    a = sorted(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score_counts(nd, ns, k):
    if k < 2 or ns <= 1 or nd <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / k) / 100


def _score(a):
    a = list(set(a))
    nd, ns = _counts(a)
    return _score_counts(nd, ns, len(a))


def solve():
    random.seed(12345)
    best = None
    best_score = -1.0
    deadline = time.time() + 110

    # Build several structured starting points and hill-climb each.
    def evaluate(a):
        a = sorted(set(a))
        nd, ns = _counts(a)
        return _score_counts(nd, ns, len(a)), a

    starts = []

    # Interval + geometric block variants
    for n in [30, 60, 100, 200]:
        base = list(range(n))
        for k in [6, 8, 10, 12]:
            for M in [2, 3]:
                geom = []
                v = 1
                for i in range(k):
                    geom.append(v)
                    v *= M
                # offset so geom sits above interval
                off = n
                starts.append(base + [off + g for g in geom])

    # Interval + powers of two shifted
    for n in [40, 80, 150]:
        base = list(range(n))
        for k in [8, 10, 12]:
            g = [n + (1 << i) for i in range(k)]
            starts.append(base + g)

    # Pure greedy B2-ish extensions from an interval
    for n in [40, 80, 120, 200]:
        starts.append(list(range(n)))

    for st in starts:
        if time.time() > deadline:
            break
        cur = sorted(set(st))
        cur_score, cur = evaluate(cur)
        # local search: try moving/adding/removing elements
        improved = True
        it = 0
        while improved and it < 200 and time.time() < deadline:
            improved = False
            it += 1
            # try adding small offsets
            maxv = max(cur)
            minv = min(cur)
            cand_moves = []
            for i in range(len(cur)):
                for d in (-2, -1, 1, 2, 3):
                    cand_moves.append((i, d))
            random.shuffle(cand_moves)
            for (i, d) in cand_moves:
                if time.time() > deadline:
                    break
                newa = cur[:]
                newa[i] += d
                if len(set(newa)) < len(newa):
                    continue
                s, newa2 = evaluate(newa)
                if s > cur_score + 1e-12:
                    cur = newa2
                    cur_score = s
                    improved = True
                    break
            if improved:
                continue
            # try adding an element
            for trial in range(40):
                if time.time() > deadline:
                    break
                if random.random() < 0.5:
                    v = random.randint(minv - 5, maxv + 5)
                else:
                    v = random.randint(minv, maxv + 50)
                if v in cur:
                    continue
                newa = cur + [v]
                s, newa2 = evaluate(newa)
                if s > cur_score + 1e-12:
                    cur = newa2
                    cur_score = s
                    improved = True
                    break
            if improved:
                continue
            # try removing an element
            if len(cur) > 6:
                for i in range(len(cur)):
                    if time.time() > deadline:
                        break
                    newa = cur[:i] + cur[i + 1:]
                    s, newa2 = evaluate(newa)
                    if s > cur_score + 1e-12:
                        cur = newa2
                        cur_score = s
                        improved = True
                        break
        if cur_score > best_score:
            best_score = cur_score
            best = cur

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(best))
# EVOLVE-BLOCK-END
