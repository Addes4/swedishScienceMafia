# EVOLVE-BLOCK-START
"""Few sums, many differences: interval core plus a shifted scaled block, refined by fast local search."""
import math
import random
import time


def _sizes(a):
    diff = set()
    s = set()
    for x in a:
        for y in a:
            diff.add(x - y)
            s.add(x + y)
    return len(diff), len(s)


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    ld, ls = _sizes(a)
    return math.log(ld) / math.log(ls) + (1 - 1 / len(a)) / 100


def _score_sizes(a):
    if len(a) < 2:
        return 0.0
    ld, ls = _sizes(a)
    if ls <= 1:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 100.0

    # Seeded structured constructions: compact interval core + shifted scaled block.
    seeds = []

    # interval + far-shifted interval (few sums: union of two AP sumsets)
    for n in (10, 14, 18, 22, 28, 36):
        for m in (2, 5, 10, 20):
            for shift in (n * m * 3, n * m * 6):
                A = list(range(n)) + [shift + i * m for i in range(n)]
                seeds.append(A)

    # interval + scaled geometric-like block (many diffs)
    for n in (12, 18, 24, 32):
        for k in (4, 6, 8, 10):
            for M in (1, 3, 7, 15):
                base = [M * (2 ** i) for i in range(k)]
                A = list(range(n)) + [x + n * 2 * M * (2 ** k) for x in base]
                seeds.append(A)

    # single interval (control)
    for n in (20, 40, 80):
        seeds.append(list(range(n)))

    best = None
    best_score = -1.0

    for A in seeds:
        if time.time() > deadline:
            break
        cand = list(dict.fromkeys(A))
        if len(cand) < 2:
            continue
        s = _score_sizes(cand)
        if s > best_score:
            best, best_score = cand[:], s

    # Local search: perturb one element; occasionally add/remove.
    cur = best[:] if best else [7, 15, 18, 22, -3, -2]
    cur_score = best_score if best else _score(cur)
    span = max(abs(x) for x in cur) + 1

    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.80:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-span // 4 - 1, span // 4 + 1)
        elif r < 0.93 or len(cand) < 3:
            cand.append(cand[random.randrange(len(cand))] + random.choice([-1, 1]))
        else:
            del cand[random.randrange(len(cand))]
        cand = list(dict.fromkeys(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        if any(abs(x) > 10 ** 15 for x in cand):
            continue
        s = _score_sizes(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
                span = max(abs(x) for x in best) + 1
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
