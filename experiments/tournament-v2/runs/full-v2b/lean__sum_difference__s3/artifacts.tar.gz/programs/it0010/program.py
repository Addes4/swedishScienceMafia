# EVOLVE-BLOCK-START
"""Structured construction: a dense interval plus a scaled sparse block to blow up differences while keeping sums small."""
import math


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build(n, m, base):
    """Block1: 0..n-1 (small sumset). Block2: base + i*step for i in 0..m-1 with large step."""
    A = list(range(n))
    step = base // max(1, m)
    if step < 1:
        step = 1
    for i in range(m):
        A.append(base + i * step)
    return A


def solve():
    best = None
    best_score = -1.0
    # Try a variety of dense-interval sizes and sparse scaled blocks.
    for n in [40, 80, 120, 160, 200, 260, 320, 400, 500]:
        for m in [5, 10, 20, 40, 60, 80, 120]:
            for base in [n * 100, n * 1000, n * 10000, 10**9, 10**12]:
                A = _build(n, m, base)
                if len(set(A)) < 2:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A
    return sorted(set(best))
# EVOLVE-BLOCK-END
