# EVOLVE-BLOCK-START
"""Local search starting from a compact core + scaled geometric block seed."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _seed():
    # compact interval core -> |C+C| = 2n-1 (minimal sums)
    n = 60
    core = list(range(n))
    # scaled geometric block far away: pairs of block differences are distinct
    M = 10 ** 6 * (n + 1)
    block = [M * (2 ** i) for i in range(9)]
    return core + block


def _delta(a, add):
    # compute marginal gains for adding point `add`
    da = a + [add]
    old = (len({x - y for x in a for y in a}),
           len({x + y for x in a for y in a}))
    new = (len({x - y for x in da for x in da}),
           len({x + y for x in da for x in da}))
    return new[0] - old[0], new[1] - old[1]


def solve():
    random.seed(12345)
    best = _seed()
    best_score = _score(best)
    deadline = time.time() + 110

    # try a few seed variations
    seeds = [best]
    for n in (30, 45, 75, 90, 120):
        for k in (6, 8, 10, 12):
            M = 10 ** 7 * (n + 1)
            s = list(range(n)) + [M * (2 ** i) for i in range(k)]
            seeds.append(s)
    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best, best_score = s[:], sc

    core_n = len([x for x in best if abs(x) < 10 ** 6])
    core_hi = max([x for x in best if abs(x) < 10 ** 6], default=0)

    while time.time() < deadline:
        cur = best[:]
        cur_score = best_score
        # greedy point-addition phase
        improved = True
        while improved and time.time() < deadline:
            improved = False
            cands = []
            # candidate new points near block scale
            for _ in range(60):
                cands.append(random.randint(core_hi + 1, max(best) * 3 + 10))
            for c in cands:
                dd, ds = _delta(cur, c)
                if ds <= 0:
                    continue
                # marginal ratio improvement estimate
                gain = dd / ds
                if gain > 1.0:
                    cur.append(c)
                    cur_score = _score(cur)
                    improved = True
                    break
        if cur_score > best_score:
            best, best_score = cur[:], cur_score
    return sorted(set(best))
# EVOLVE-BLOCK-END
