# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeding + exact hill-climb."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _fast_stats(A):
    """Exact |A-A|,|A+A| using offset bitmasks over a compact window."""
    lo = min(A)
    hi = max(A)
    off = lo
    span = hi - lo + 1
    dif = 0
    for x in A:
        m = 0
        base = x - off
        for y in A:
            m |= 1 << (base - (y - off))
        dif |= m
    dc = bin(dif).count("1")
    # sums
    lo2 = 2 * lo
    span2 = 2 * (hi - lo) + 1
    sc = 0
    if span2 <= 200000:
        sm = 0
        for x in A:
            for y in A:
                sm |= 1 << (x + y - lo2)
        sc = bin(sm).count("1")
    else:
        sc = len({x + y for x in A for y in A})
    return dc, sc


def _score_fast(A):
    if len(set(A)) < 2:
        return 0.0
    A = sorted(set(A))
    dc, sc = _fast_stats(A)
    if sc < 2:
        return 0.0
    return math.log(dc) / math.log(sc) + (1 - 1 / len(A)) / 100


def _family(n, m, M, s):
    A = set(range(n))
    A |= {M + s * i for i in range(m)}
    return sorted(A)


def _seed_interval_geometric(rng):
    n = rng.randint(8, 40)
    base = set(range(n))
    k = rng.randint(2, 6)
    scale = rng.choice([n * 2, n * 3, n * 4, n * 8])
    pts = set()
    v = scale
    for _ in range(k):
        pts.add(v)
        v = int(v * rng.uniform(1.5, 2.5)) + rng.randint(0, scale)
    return sorted(base | pts)


def _seed_twoblocks(rng):
    n = rng.randint(6, 30)
    m = rng.randint(3, 20)
    s = rng.randint(n + 1, 6 * (n + m))
    A = set(range(n))
    A |= {s + i for i in range(m)}
    return sorted(A)


def _hill_climb(start, deadline, rng):
    best = list(set(start))
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.5 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 2)
            cand[i] += rng.randint(-span, span)
        elif r < 0.8:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.95 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            cand = sorted(set(cand))
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.08:
            cur, cur_s = best[:], best_s
    return best, best_s


def _family_sweep(best, best_s, deadline):
    """Sweep the interval-union-AP family with a cheap true scorer."""
    ns = list(range(4, 60)) + [64, 72, 80, 96, 112, 128]
    ms = list(range(2, 40)) + [48, 56, 64, 80, 96]
    candidates = []
    for n in ns:
        for m in ms:
            for M in (n, n + 1, 2 * n, 3 * n, 4 * n, n * m, 2 * n * m,
                      n + m, 2 * (n + m), 5 * n, 8 * n):
                for s in (1, 2, 3, 4, 5, 8, 10, 16, 32):
                    candidates.append((n, m, M, s))
    rng = random.Random(7)
    rng.shuffle(candidates)
    checked = 0
    for (n, m, M, s) in candidates:
        if time.time() > deadline:
            break
        A = _family(n, m, M, s)
        if len(set(A)) < 2:
            continue
        checked += 1
        sc = _score_fast(A)
        if sc > best_s:
            best_s = sc
            best = A
    return best, best_s


def _grow_core(best, best_s, deadline, rng):
    """Greedy growth of a dense core combined with a far AP block."""
    A = list(best)
    while time.time() < deadline:
        cand = A[:]
        op = rng.random()
        if op < 0.5:
            # try growing an arithmetic structure: insert x near center span
            lo = min(cand); hi = max(cand)
            x = rng.randint(lo, hi)
            if x not in cand:
                cand.append(x)
        else:
            anchor = rng.choice(cand)
            cand.append(anchor + rng.randint(-5, 5))
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        sc = _score_fast(cand)
        if sc > best_s:
            best_s = sc
            A = cand
            best = cand[:]
        elif rng.random() < 0.02:
            A = best[:]
    return best, best_s


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    seeds = []
    for n in (10, 20, 40, 80):
        seeds.append(list(range(n)))
    for _ in range(20):
        seeds.append(_seed_interval_geometric(rng))
    for _ in range(20):
        seeds.append(_seed_twoblocks(rng))

    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    # Deterministic structural sweep (fast, exact scoring, small candidates)
    best, best_s = _family_sweep(best, best_s, time.time() + 30)

    # Greedy core growth around the best structural candidate
    best, best_s = _grow_core(best, best_s, time.time() + 60, rng)

    # Final random hill-climb to polish
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 3 == 0:
            start = _seed_interval_geometric(rng)
        elif attempts % 3 == 1:
            start = _seed_twoblocks(rng)
        else:
            start = best[:]
        cand, cs = _hill_climb(start, min(deadline, time.time() + 8), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
