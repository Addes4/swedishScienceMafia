# EVOLVE-BLOCK-START
"""Hybrid: structured seed (AP ∪ powers of two) plus greedy local search."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _seed():
    # Arithmetic progression gives a tiny sumset; powers of two add many
    # distinct (large) cross-differences with the progression.
    m = 20
    A = list(range(m))
    p = 1
    for _ in range(12):
        A.append(p)
        p = -p * 2 if p > 0 else -p * 2
        p = p * 2 if p > 0 else p * 2
    # simpler: powers of two with signs
    A = list(range(m))
    for i in range(12):
        A.append((1 << i))
        A.append(-(1 << i))
    return A


def solve():
    best = _seed()
    best_score = _score(best)
    cur = best[:]
    deadline = time.time() + 100
    span = 1 << 12
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.6 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-8, 8)
        elif r < 0.8:
            cand.append(random.randint(-span, span))
        elif r < 0.95 and len(cand) > 3:
            del cand[random.randrange(len(cand))]
        else:
            if cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(-span, span)
        cand = list(set(cand))
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END
