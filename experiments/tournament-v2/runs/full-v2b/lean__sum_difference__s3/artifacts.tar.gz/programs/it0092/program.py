# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A|.

Strategy:
  * fast exact bitset-based difference/sum counters
  * broad deterministic sweep over the proven two-block family
    A = [0, n) union {M + s*i : i=0..m-1}, which yields many differences
    (dense lattice) but few sums (gcd-limited structure)
  * local refinement around the best structured candidates
  * a randomized hill-climb fallback with a time budget
"""
import math
import random
import time

try:
    import numpy as np
    _HAVE_NP = True
except Exception:
    _HAVE_NP = False


def _score_from_counts(nd, ns, n):
    if ns < 2 or nd < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _stats_plain(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), n


def _score(a):
    nd, ns, n = _stats_plain(a)
    return _score_from_counts(nd, ns, n)


def _stats_bitset(a):
    """Fast exact count of |A-A| and |A+A| using numpy bitsets."""
    a = sorted(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0, 0, n
    lo = min(a)
    hi = max(a)
    span = hi - lo
    # difference values live in [-span, span]; sums in [2lo, 2hi]
    dsize = 2 * span + 1
    ssize = 2 * (hi - lo) + 1
    if _HAVE_NP and dsize <= 4_000_00 and ssize <= 4_000_00:
        off = lo
        idx = np.array(a, dtype=np.int64) - off  # in [0, span]
        d = np.zeros(dsize, dtype=bool)
        s = np.zeros(ssize, dtype=bool)
        # differences: for each x, mark x - y for all y
        # sums: for each x, mark x + y - 2*off
        # do it via broadcasting in chunks to bound memory
        base = idx
        for x in base:
            d[x - base + span] = True
            s[x + base] = True
        return int(d.sum()), int(s.sum()), n
    return _stats_plain(a)


def _score_fast(a):
    nd, ns, n = _stats_bitset(a)
    return _score_from_counts(nd, ns, n)


def _twoblock(n, m, s, M):
    A = list(range(n))
    A.extend(M + s * i for i in range(m))
    return sorted(set(A))


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 108

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # ---- deterministic sweep over the two-block family ----
    # n: dense interval length, m: AP length, s: AP step, M: offset
    for n in range(3, 41):
        for m in range(2, 41):
            for s in (1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 32, 40, 50):
                for M in range(n + 1, n + 1 + 6 * (n + m), max(1, (n + m) // 2)):
                    A = _twoblock(n, m, s, M)
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score_fast(A)
                    if sc > best_s:
                        best, best_s = A, sc
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # ---- local refinement around the best structured candidate ----
    def refine(A, budget):
        A = sorted(set(A))
        cur = A[:]
        cur_s = _score_fast(cur)
        hi = max(abs(x) for x in cur) if cur else 1
        end = time.time() + budget
        while time.time() < end:
            cand = cur[:]
            r = rng.random()
            if r < 0.55 and cand:
                i = rng.randrange(len(cand))
                span = max(1, hi // 2)
                cand[i] += rng.randint(-span, span)
            elif r < 0.8:
                anchor = rng.choice(cand) if cand else 0
                cand.append(anchor + rng.randint(-hi, hi))
            elif r < 0.93 and len(cand) > 3:
                del cand[rng.randrange(len(cand))]
            else:
                if cand:
                    cand.append(cand[-1] + rng.randint(1, 4))
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 4000:
                continue
            sc = _score_fast(cand)
            if sc >= cur_s:
                cur, cur_s = cand, sc
            elif rng.random() < 0.1:
                cur, cur_s = best[:], best_s
        return cur, cur_s

    while time.time() < deadline:
        c, cs = refine(best, min(10, deadline - time.time()))
        if cs > best_s:
            best, best_s = c, cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
