# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| using a fast exact numpy bitset
scorer and a broad deterministic sweep over the proven two-block family
A = [0,n) union {M + s*i : i=0..m-1} plus related structured seeds."""
import math
import numpy as np


def _counts(A):
    """Exact |A-A| and |A+A| using dense numpy boolean arrays."""
    a = np.array(sorted(set(A)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0, 0
    # differences range [min-min, max-max]
    dmin = a[0] - a[-1]
    dmax = a[-1] - a[0]
    dsize = dmax - dmin + 1
    diffs = np.zeros(dsize, dtype=bool)
    for x in a:
        idx = x - a - dmin
        diffs[idx] = True
    nd = int(diffs.sum())
    smin = a[0] + a[0]
    smax = a[-1] + a[-1]
    ssize = smax - smin + 1
    sums = np.zeros(ssize, dtype=bool)
    for x in a:
        idx = x + a - smin
        sums[idx] = True
    ns = int(sums.sum())
    return nd, ns


def _score_counts(nd, ns, n):
    if ns < 2 or nd < 1 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(A):
    nd, ns = _counts(A)
    return _score_counts(nd, ns, len(set(A)))


def solve():
    best = None
    best_s = 0.0

    def consider(A):
        nonlocal best, best_s
        A = sorted(set(A))
        n = len(A)
        if n < 2 or n > 4000:
            return
        if max(abs(x) for x in A) > 10**15:
            return
        nd, ns = _counts(A)
        s = _score_counts(nd, ns, n)
        if s > best_s:
            best_s = s
            best = A

    # Fast structural sweep: A = [0,n) union {M + s*i : i=0..m-1}
    # Need M > n-1 to avoid overlap; s large so blocks separate well.
    for n in range(2, 26):
        for m in range(2, 26):
            for s in range(1, 80):
                # offset: place second block just past first, parameterized
                for M in (n, n + 1, n + 2, n * 2, n * 3, s, s + 1):
                    if M <= n - 1:
                        continue
                    A = list(range(n)) + [M + s * i for i in range(m)]
                    consider(A)

    # Even better: allow arbitrary gap between blocks by scanning M in a range
    for n in range(2, 20):
        for m in range(2, 20):
            for s in range(1, 40):
                base = list(range(n))
                # scan M in a neighbourhood to exploit cross-sum collisions
                for M in range(n, n + 6 * (n + m) + 2):
                    A = base + [M + s * i for i in range(m)]
                    consider(A)

    # Interval + scaled interval (two AP-blocks with step = 1 scaled differently)
    for n in range(2, 30):
        for m in range(2, 30):
            for t in range(2, 40):
                A = list(range(n)) + [n + t * (i + 1) for i in range(m)]
                consider(A)

    if best is None:
        best = [0, 1, 1000, 1001]
    return best
# EVOLVE-BLOCK-END
