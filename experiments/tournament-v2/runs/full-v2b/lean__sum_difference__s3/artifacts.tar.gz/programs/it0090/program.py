# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured two-block family sweep."""
import math
import time
import numpy as np


def _score_sets(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0, len(diffs), len(sums)
    s = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return s, len(diffs), len(sums)


def _score_fast(a):
    """Exact score using numpy bitset counting."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    arr = np.array(a, dtype=np.int64)
    # differences range up to max-min
    diffs = arr[:, None] - arr[None, :]
    sums = arr[:, None] + arr[None, :]
    dmin, dmax = diffs.min(), diffs.max()
    smin, smax = sums.min(), sums.max()
    dsize = int(dmax - dmin) + 1
    ssize = int(smax - smin) + 1
    if dsize <= 0 or ssize <= 0 or dsize > 2_000_000 or ssize > 2_000_000:
        s, _, _ = _score_sets(a)
        return s
    dbits = np.zeros(dsize, dtype=bool)
    sbits = np.zeros(ssize, dtype=bool)
    dbits[(diffs - dmin).ravel()] = True
    sbits[(sums - smin).ravel()] = True
    nd = int(dbits.sum())
    ns = int(sbits.sum())
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def solve():
    best = [7, 15, 18, 22, -3, -2]
    bs, _, _ = _score_sets(best)
    deadline = time.time() + 110

    # Deterministic sweep over two-block family A = [0,n) union {M + s*i}
    # Also allow pure intervals and interval+AP variants.
    for n in range(3, 45):
        base = list(range(n))
        for m in range(2, 30):
            # scale/holes for AP block
            for s in (1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 16):
                for M in (n, n + 1, n * 2, n * 2 + 1, n * 3, n * 4,
                          n * s + 1, n + s, 2 * n + s):
                    if time.time() > deadline:
                        return sorted(set(best))
                    M = int(M)
                    if m * s + M > 10**7:
                        continue
                    A = base + [M + s * i for i in range(m)]
                    sc = _score_fast(A)
                    if sc > bs:
                        bs = sc
                        best = list(A)

    # broader AP block with varying step and offset
    for n in range(2, 30):
        base = list(range(n))
        for m in range(2, 25):
            for M in range(n, 40 * n + 5, max(1, n // 2)):
                for s in range(1, 20):
                    if time.time() > deadline:
                        return sorted(set(best))
                    A = base + [M + s * i for i in range(m)]
                    sc = _score_fast(A)
                    if sc > bs:
                        bs = sc
                        best = list(A)

    # pure interval and simple sets
    for n in range(2, 200):
        if time.time() > deadline:
            break
        A = list(range(n))
        sc = _score_fast(A)
        if sc > bs:
            bs = sc
            best = list(A)

    return sorted(set(best))
# EVOLVE-BLOCK-END
