# EVOLVE-BLOCK-START
"""Deterministic construction: interval U shifted Sidon block, exactly tuned."""
import math
import time


def _stats(a):
    s = set(a)
    diffs = set()
    sums = set()
    L = list(s)
    for x in L:
        for y in L:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(s)


def _score_list(a):
    d, s, n = _stats(a)
    if n < 2 or s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _sidon(n):
    """Greedy Sidon set (all pairwise sums distinct) inside [0, ~n^2]."""
    S = []
    used = set()
    x = 0
    while len(S) < n:
        ok = True
        for a in S:
            for b in S:
                if a + b + x in used or a + b == x:
                    ok = True
        # proper greedy: check all new sums distinct
        new = set()
        good = True
        for a in S:
            v = a + x
            if v in used or v in new:
                good = False
                break
            new.add(v)
            v2 = 2 * x
        if good and (2 * x) not in used and (2 * x) not in new:
            for a in S:
                used.add(a + x)
            used.add(2 * x)
            S.append(x)
            x += 1
        else:
            x += 1
            if x > 200000:
                break
    return S


def _build(n, B, M):
    """A = {0..n-1} U {M*0 + b, M*1 + b, ... } scaled Sidon block."""
    A = list(range(n))
    for b in B:
        for j in range(1):
            pass
    return A


def solve():
    deadline = time.time() + 110

    best = [0, 1]
    best_s = _score_list(best)

    # Fixed rich block first
    for n in range(4, 60):
        A0 = list(range(n))
        s0 = _score_list(A0)
        if s0 > best_s:
            best, best_s = A0, s0

    # interval + scaled Sidon-like block
    for nb in (2, 3, 4, 5):
        B = _sidon(nb)
        for n in (6, 8, 10, 12, 16, 20, 24, 30, 36, 44, 55):
            span = max(B) if B else 0
            for mult in (2, 3, 4, 6, 8, 12, 16, 24, 32):
                M = n * mult
                if M <= span:
                    continue
                A = set(range(n))
                for b in B:
                    A.add(M + b * max(1, (M // (span + 1) if span else 1)))
                A = sorted(A)
                if len(A) < 2 or len(A) > 4000:
                    continue
                sc = _score_list(A)
                if sc > best_s:
                    best, best_s = A, sc

    # interval + several scaled blocks (geometric-ish separation)
    for n in (8, 12, 16, 20, 24, 30, 40, 55):
        for k in (1, 2, 3, 4, 5, 6):
            for base_mult in (2, 3, 4, 6, 8, 12):
                v = n * base_mult
                A = set(range(n))
                step = max(1, v)
                cur = v
                for _ in range(k):
                    A.add(cur)
                    cur = cur * 2 + n
                A = sorted(A)
                if len(A) < 2 or len(A) > 4000:
                    continue
                sc = _score_list(A)
                if sc > best_s:
                    best, best_s = A, sc
                if time.time() > deadline:
                    return best

    # local refinement: try moving each large element
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for i in range(len(best)):
            base = best[i]
            if base < min(60, max(best)):
                pass
            for d in (-3, -2, -1, 1, 2, 3, 5, 8, 13, 21, -8, -13, -21):
                cand = best[:]
                cand[i] = base + d
                cand = sorted(set(cand))
                if len(cand) < 2 or len(cand) > 4000:
                    continue
                sc = _score_list(cand)
                if sc > best_s:
                    best, best_s = cand, sc
                    improved = True
                    break
            if improved:
                break

    return sorted(set(best))
# EVOLVE-BLOCK-END
