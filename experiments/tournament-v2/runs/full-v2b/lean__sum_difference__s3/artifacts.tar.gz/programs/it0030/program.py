# EVOLVE-BLOCK-START
"""Construction: compact interval core plus a dilated/shifted block, parameter-swept."""
import math


def _sizes(A):
    a = sorted(set(A))
    n = len(a)
    if n < 2:
        return 1, 1, n
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def solve():
    """Return A with large A-A and small A+A."""
    best = None
    best_ratio = -1.0

    candidates = []

    # Family 1: interval core {0..N-1} plus shifted dilated block
    for N in [50, 80, 100, 150, 200, 300]:
        for M in [300, 500, 800, 1000, 2000, 5000]:
            for k in [5, 8, 12, 20, 30]:
                # block: shift = N (adjacent) up to large; steps = M * i
                for d in [1, M]:
                    blk = [N + M * i for i in range(k)]
                    A = list(range(N)) + blk
                    candidates.append(A)

    # Family 2: pure geometric block (differences huge, sums limited)
    for k in [15, 20, 25, 30, 40]:
        for M in [1, 2, 3, 5]:
            blk = [M * (2 ** i) for i in range(k)]
            candidates.append(blk)
            # with interval offset
            candidates.append(list(range(min(30, k))) + [3 * 10**6 + x for x in blk])

    # Family 3: interval + large-spread AP with big gaps
    for N in [40, 70, 100]:
        for step in [1000, 5000, 20000, 100000]:
            for k in [10, 15, 20]:
                blk = [10 * 10**6 + step * i for i in range(k)]
                candidates.append(list(range(N)) + blk)

    for A in candidates:
        if len(A) > 4000 or max(abs(x) for x in A) > 10**15:
            continue
        dd, ds, n = _sizes(A)
        if ds < 2 or dd < 2:
            continue
        ratio = math.log(dd) / math.log(ds) + (1 - 1 / n) / 100
        if ratio > best_ratio:
            best_ratio = ratio
            best = A

    return sorted(set(best))
# EVOLVE-BLOCK-END
