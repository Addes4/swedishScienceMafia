# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeds + exact numpy scorer."""
import math
import random
import time
import numpy as np


def _stats(A):
    """Exact |A-A| and |A+A| using numpy boolean convolutions over a compact range."""
    A = list(set(int(x) for x in A))
    n = len(A)
    if n < 2:
        return 0, 0, n
    mn, mx = min(A), max(A)
    # differences in [mn-mx, mx-mn]
    dlo, dhi = mn - mx, mx - mn
    dsize = dhi - dlo + 1
    if dsize > 4_000_000:
        # fallback set-based (should be rare)
        diffs = set()
        sums = set()
        for x in A:
            for y in A:
                diffs.add(x - y)
                sums.add(x + y)
        return len(diffs), len(sums), n
    dcnt = np.zeros(dsize, dtype=np.int64)
    aset = np.array(A, dtype=np.int64)
    # histogram of A shifted so min->0
    shifted = aset - mn
    hist = np.bincount(shifted, minlength=(mx - mn + 1))
    # |A-A| count: convolution of hist with reversed hist
    conv_d = np.convolve(hist, hist[::-1])
    # conv_d index k corresponds to difference (k - (mx-mn)); value count
    ndiff = int(np.count_nonzero(conv_d))

    slo, shi = 2 * mn, 2 * mx
    ssize = shi - slo + 1
    if ssize > 4_000_000:
        sums = set()
        for x in A:
            for y in A:
                sums.add(x + y)
        return ndiff, len(sums), n
    hist2 = np.bincount(shifted, minlength=(mx - mn + 1))
    conv_s = np.convolve(hist2, hist2)
    nsum = int(np.count_nonzero(conv_s))
    return ndiff, nsum, n


def _score(A):
    a = set(int(x) for x in A)
    if len(a) < 2:
        return 0.0
    nd, ns, n = _stats(a)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _structured(n, m, M, s):
    """A = [0,n) union (M + s*[0,m))."""
    A = set(range(n))
    for i in range(m):
        A.add(M + s * i)
    return sorted(A)


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 112

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # deterministic sweep over structured family
    ns = [20, 40, 80, 160, 240, 320, 400]
    ms = [2, 3, 4, 6, 8, 12, 16, 24, 32, 48]
    for n in ns:
        for m in ms:
            for mult in (1, 2, 3, 4, 5, 8, 12, 16):
                for s in (1, mult):
                    # place second block far away so sums don't collide with [0,2n)
                    # M chosen so sums of block sit above 2n and are sparse
                    M = n * mult + rng.randint(1, max(1, n))
                    A = _structured(n, m, M, s)
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score(A)
                    if sc > best_s:
                        best, best_s = A, sc
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # also try scaled blocks: A = [0,n) union (M + s*[0,m)) with s>1 to stretch sums
    for _ in range(3000):
        if time.time() > deadline:
            break
        n = rng.randint(10, 350)
        m = rng.randint(2, 40)
        mult = rng.choice([1, 2, 3, 4, 5, 6, 8, 10, 16, 24, 32])
        s = rng.choice([1, 1, 1, 2, 3, 4])
        M = n * mult + rng.randint(1, max(1, n * 2))
        cand = _structured(n, m, M, s)
        if len(cand) > 4000:
            continue
        sc = _score(cand)
        if sc > best_s:
            best, best_s = cand, sc

    # local refinement: tweak n, m, M, s and single-element perturbations
    cur = best[:]
    cur_s = best_s
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        r = rng.random()
        if r < 0.35:
            # tweak an element
            i = rng.randrange(len(cand))
            hi = max(abs(x) for x in cand)
            cand[i] += rng.randint(-max(1, hi // 4), max(1, hi // 4))
            cand = sorted(set(cand))
        elif r < 0.6:
            anchor = rng.choice(cand)
            hi = max(abs(x) for x in cand)
            cand.append(anchor + rng.randint(-hi, hi))
            cand = sorted(set(cand))
        elif r < 0.75 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            # rebuild a structured candidate around current best
            n = max(5, len(cand) // 2 + rng.randint(-10, 10))
            m = rng.randint(2, 30)
            M = n * rng.choice([1, 2, 3, 4, 8]) + rng.randint(1, max(1, n * 2))
            s = rng.choice([1, 1, 2, 3])
            cand = _structured(n, m, M, s)
        if len(cand) < 2 or len(cand) > 4000:
            continue
        sc = _score(cand)
        if sc >= cur_s:
            cur, cur_s = cand, sc
            if sc > best_s:
                best, best_s = cand[:], sc
        elif rng.random() < 0.1:
            cur, cur_s = best[:], best_s

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
