# EVOLVE-BLOCK-START
"""Geometric-progression construction: A = {c * b^i} for i in 0..k-1.
Sums of powers (times c) collide far more often than differences, giving a
large difference-sum ratio."""
import math


def _counts(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        for j in range(n):
            diffs.add(a[i] - a[j])
            sums.add(a[i] + a[j])
    return len(diffs), len(sums)


def _score_ratio(a):
    if len(set(a)) < 2:
        return 0.0
    d, s = _counts(a)
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(set(a))) / 100


def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    best = None
    best_score = -1.0
    # Scan bases and sizes for geometric progressions.
    for base in (2, 3, 4, 5, 6, 7, 8, 9, 10):
        for k in range(2, 60):
            a = [base ** i for i in range(k)]
            if max(a) > 10 ** 15:
                break
            sc = _score_ratio(a)
            if sc > best_score:
                best_score = sc
                best = a[:]
        # also try a shifted/scaled variant to reduce sum collisions
    # Try reversed-order / two-sided geometric: include negative powers side
    for base in (2, 3, 4):
        for k in range(2, 40):
            a = [base ** i for i in range(k)]
            full = a + [-x for x in a if x != 1]
            if max(abs(x) for x in full) > 10 ** 15:
                break
            sc = _score_ratio(full)
            if sc > best_score:
                best_score = sc
                best = full[:]
    return sorted(set(best)) if best else [1, 2, 4, 8, 16]

# EVOLVE-BLOCK-END
