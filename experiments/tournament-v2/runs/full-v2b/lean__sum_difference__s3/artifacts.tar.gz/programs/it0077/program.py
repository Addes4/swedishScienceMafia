# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured family + fast bitset scorer."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats_fast(a):
    """Exact |A-A| and |A+A| using Python int bitsets (no numpy needed)."""
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0, 0
    lo = a[0]
    hi = a[-1]
    span = hi - lo

    # differences: values range [-(hi-lo), hi-lo]
    diff_bits = 0
    for x in a:
        # x - y for all y: shift to nonnegative offsets
        for y in a:
            d = x - y
            diff_bits |= 1 << (d + span)
    # sums: values range [2*lo, 2*hi]
    sm_bits = 0
    for x in a:
        for y in a:
            s = x + y
            sm_bits |= 1 << (s - 2 * lo)
    return bin(diff_bits).count("1"), bin(sm_bits).count("1")


def _score_fast(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _stats_fast(a)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _eval_family(n, m, M, s):
    """A = [0,n) union (M + s*[0,m)). M,s ints."""
    A = set(range(n))
    for i in range(m):
        A.add(M + s * i)
    return A


def _bitset_interval_union(n, m, M, s):
    """Compute nd, ns for A=[0,n) U (M+s*[0,m)) directly and quickly."""
    B = list(range(0, n))
    C = [M + s * i for i in range(m)]
    A = B + C
    # brute but only on the small union (n+m elements)
    k = len(A)
    lo = A[0]
    hi = A[-1]
    diff_bits = 0
    for x in A:
        row = 0
        for y in A:
            row |= 1 << (x - y + (hi - lo))
        diff_bits |= row
    sm_bits = 0
    for x in A:
        row = 0
        for y in A:
            row |= 1 << (x + y - 2 * lo)
        sm_bits |= row
    return bin(diff_bits).count("1"), bin(sm_bits).count("1")


def _score_family(n, m, M, s):
    k = n + m
    if k < 2:
        return 0.0, 0, 0
    nd, ns = _bitset_interval_union(n, m, M, s)
    if ns < 2 or nd < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / k) / 100, nd, ns


def solve():
    rng = random.Random(2024)
    deadline = time.time() + 108

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # ---- Phase 1: coarse deterministic sweep of the family [0,n) U (M+s*[0,m)) ----
    # We want sumset to stay nearly an AP: put M just above n-1 so that
    # C+C and B+C overlap with B+B, giving few new sums, and C-C = s*[-(m-1),m-1]
    # which adds m extra differences if s large.
    results = []
    for n in (8, 12, 16, 20, 30, 45, 60, 80, 110, 150, 200, 260, 340):
        for m in (2, 3, 4, 5, 6, 8, 10, 14):
            # M candidates around n so sums overlap
            for M in (n, n + 1, n + 2, n + m, 2 * n, 2 * n + 1, 3 * n):
                for s in (1, 2, 3, 5, 8):
                    if time.time() > deadline:
                        break
                    sc, nd, ns = _score_family(n, m, M, s)
                    if sc > best_s:
                        A = _eval_family(n, m, M, s)
                        # verify with ground-truth scorer
                        gt = _score(A)
                        if gt > best_s:
                            best_s = gt
                            best = sorted(A)

    # ---- Phase 2: local refinement -- grow n and m with tuned M,s ----
    improved = True
    while improved and time.time() < deadline:
        improved = False
        # try enlarging best by extending first interval and adding to second block
        cur = best
        n0 = len(cur)
        # guess parameters from structure (fallback: brute small search around)
        for M in range(2, 4 * n0 + 5):
            if time.time() > deadline:
                break
            for s in (1, 2, 3):
                for m in (2, 3, 4, 5, 6, 8):
                    for dn in (0, 1, 2, 4, 8):
                        n = n0 + dn
                        sc, _, _ = _score_family(n, m, M, s)
                        if sc > best_s:
                            A = _eval_family(n, m, M, s)
                            gt = _score(A)
                            if gt > best_s:
                                best_s = gt
                                best = sorted(A)
                                improved = True
                                break
                    if improved:
                        break
                if improved:
                    break
            if improved:
                break

    # ---- Phase 3: random hill-climb on top of best using exact scorer ----
    def hill_climb(start, tlimit):
        cur = list(set(start))
        cur_s = _score(cur)
        b = cur[:]
        bs = cur_s
        hi = max(abs(x) for x in cur) if cur else 1
        while time.time() < tlimit:
            cand = cur[:]
            r = rng.random()
            if r < 0.5 and cand:
                i = rng.randrange(len(cand))
                span = max(1, hi // 2)
                cand[i] += rng.randint(-span, span)
            elif r < 0.8:
                anchor = rng.choice(cand) if cand else 0
                cand.append(anchor + rng.randint(-hi, hi))
            elif r < 0.95 and len(cand) > 3:
                del cand[rng.randrange(len(cand))]
            cand = list(set(cand))
            if len(cand) < 2 or len(cand) > 4000:
                continue
            s = _score(cand)
            if s >= cur_s:
                cur, cur_s = cand, s
                if s > bs:
                    b, bs = cand[:], s
            elif rng.random() < 0.08:
                cur, cur_s = b[:], bs
        return b, bs

    while time.time() < deadline:
        cand, cs = hill_climb(best, min(deadline, time.time() + 8))
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
