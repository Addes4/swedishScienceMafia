# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A|."""
import math
import random
import time
import numpy as np


def _counts(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0, 0
    # differences
    d = a[:, None] - a[None, :]
    nd = np.unique(d).size
    s = a[:, None] + a[None, :]
    ns = np.unique(s).size
    return nd, ns


def _score(a):
    nd, ns = _counts(a)
    n = len(set(a))
    if ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _sidon_sets():
    sets = [
        [0, 1],
        [0, 1, 3],
        [0, 1, 4, 6],
        [0, 1, 3, 7],
        [0, 1, 4, 9, 11],
        [0, 1, 4, 6, 13, 14],
        [0, 1, 3, 7, 12, 20],
        [0, 1, 4, 10, 12, 17],
        [0, 1, 4, 9, 15, 22, 32],
        [0, 1, 3, 7, 12, 20, 30],
        [0, 1, 4, 10, 18, 23, 25],
    ]
    return sets


def _construction(n, base, M, s):
    A = list(range(n))
    A += [M + s * b for b in base]
    return sorted(set(A))


def solve():
    rng = random.Random(98765)
    deadline = time.time() + 112

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    sidons = _sidon_sets()

    # Initial sweep of parametric family
    for n in range(2, 60):
        for base in sidons:
            m = len(base)
            span = base[-1] if base[-1] > 0 else 1
            for mult in (1, 2, 3, 5, 8, 13):
                s = mult
                Mmax = max(1, 4 * (n + s * span))
                stepM = max(1, Mmax // 40)
                for M in range(n, Mmax + 1, stepM):
                    A = _construction(n, base, M, s)
                    sc = _score(A)
                    if sc > best_s:
                        best_s, best = sc, A

    # Randomized refinement of params
    while time.time() < deadline * 0.5:
        n = rng.randint(2, 120)
        base = rng.choice(sidons)
        s = rng.randint(1, 40)
        span = base[-1] if base[-1] > 0 else 1
        M = rng.randint(n, 8 * (n + s * span + 1))
        A = _construction(n, base, M, s)

        # perturb base
        if rng.random() < 0.5:
            b2 = sorted(set(b + rng.randint(-2, 2) for b in base))
            b2 = [b - min(b2) for b in b2]
            if len(set(b2)) == len(base):
                A = _construction(n, b2, M, s)
        sc = _score(A)
        if sc > best_s:
            best_s, best = sc, A

    # Local refinement: shrink sum set by nudging elements
    cur = list(best)
    hi = max(abs(x) for x in cur) if cur else 1
    span = max(1, hi // 3)
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.6 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-span, span)
        elif r < 0.85:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= best_s:
            best_s, cur = s, cand
            best = cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
