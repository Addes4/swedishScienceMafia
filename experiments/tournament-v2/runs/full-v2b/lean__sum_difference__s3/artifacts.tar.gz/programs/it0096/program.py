# EVOLVE-BLOCK-START
"""Fast exact sweep over the two-block family A=[0,n) ∪ {M+s*i}."""
import math
import numpy as np


def _score_fast(A):
    n = len(A)
    if n < 2:
        return 0.0
    a = np.asarray(A, dtype=np.int64)
    d = (a[:, None] - a[None, :]).ravel()
    s = (a[:, None] + a[None, :]).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_s = _score_fast(best)

    # Two-block family: [0, n) union {M + s*i : i=0..m-1}
    for n in range(2, 41):
        for m in range(2, 41):
            for s in range(1, 25):
                # offset must clear the interval
                base_lo = n
                for M in range(base_lo, n + m * s + 3, max(1, m)):
                    A = list(range(n)) + [M + s * i for i in range(m)]
                    A = sorted(set(A))
                    if len(A) < 2 or len(A) > 4000:
                        continue
                    sc = _score_fast(A)
                    if sc > best_s:
                        best, best_s = A, sc

    # single AP with many terms
    for m in range(2, 60):
        for s in range(1, 40):
            A = [s * i for i in range(m)]
            sc = _score_fast(A)
            if sc > best_s:
                best, best_s = A, sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
