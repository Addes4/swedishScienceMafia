# EVOLVE-BLOCK-START
"""Deterministic search over A = [0,n) union (r + s*[0,m)) maximizing log|A-A|/log|A+A|."""
import math
import time


def _stats(a):
    a = sorted(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        for j in range(i, n):
            diffs.add(a[i] - a[j])
            diffs.add(a[j] - a[i])
            sums.add(a[i] + a[j])
    return len(diffs), len(sums), len(a)


def _score_stats(nd, ns, na):
    if ns < 2 or na < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / na) / 100


def _score(a):
    nd, ns, na = _stats(a)
    return _score_stats(nd, ns, na)


def solve():
    """Interval + far translated short interval, tuned exactly."""
    deadline = time.time() + 115
    best = [0, 1, 3, 7, 12, 20]  # fallback
    best_s = _score(best)

    # For A = [0,n) U {r + s*t : t in [0,m)}, we scan parameters.
    # Key insight: choose s >= 2 and r large enough that cross sums
    # r + s*t + u (u in [0,n)) are all distinct from each other and from
    # the internal sums, keeping |A+A| small, while cross differences give
    # many distinct values.
    n_choices = list(range(20, 200, 4)) + [200, 240, 280, 320]
    m_choices = list(range(2, 60))
    s_choices = [1, 2, 3, 4, 5, 6, 8, 10]
    # r must exceed n so second block is disjoint; scan r range
    for n in n_choices:
        if time.time() > deadline:
            break
        for m in m_choices:
            if time.time() > deadline:
                break
            for s in s_choices:
                if time.time() > deadline:
                    break
                # r range: roughly around (n + m*s) to a few multiples
                lo = n + 1
                hi = n + m * s + 20 * n + 50
                step = max(1, (hi - lo) // 60)
                for r in range(lo, hi + 1, step):
                    A = list(range(n)) + [r + s * t for t in range(m)]
                    if len(set(A)) != n + m:
                        continue
                    sc = _score(A)
                    if sc > best_s:
                        best_s = sc
                        best = A

    # Local refinement on the best found: perturb r, n, m slightly.
    if best:
        base_n = sum(1 for x in best if x < 0 or True)  # placeholder
    return sorted(set(best))
# EVOLVE-BLOCK-END
