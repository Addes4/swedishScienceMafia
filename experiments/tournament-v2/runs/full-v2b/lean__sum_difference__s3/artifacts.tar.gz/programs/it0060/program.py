# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A|.

Key idea: a dense interval [0, n-1] gives |A+A| = 2n-1 (small) while adding a few
elements far out enlarges A-A. The best structures keep most of A inside a short
interval (so sums collide) and push differences apart. We do exact incremental
hill-climbing on that family.
"""
import math
import random
import time


def _score_counts(nd, ns, n):
    if nd < 2 or ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _full_stats(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    nd, ns = _full_stats(a)
    return _score_counts(nd, ns, len(a))


def _build(n, extra):
    """Interval 0..n-1 plus a list of extra offsets."""
    base = set(range(n))
    base |= set(extra)
    return sorted(base)


def _eval(a):
    """Return (score, |A-A|, |A+A|, |A|)."""
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0, n
    nd, ns = _full_stats(a)
    return _score_counts(nd, ns, n), nd, ns, n


def _greedy_extra(n, k, rng, deadline):
    """Grow extras one at a time; each candidate placed to maximize exact score."""
    a = list(range(n))
    best_s, _, _, _ = _eval(a)
    for _ in range(k):
        if time.time() > deadline:
            break
        hi = max(abs(x) for x in a)
        span = max(n, hi)
        cands = set()
        # offsets near existing structure, at several scales
        for _ in range(60):
            cands.add(rng.randint(-2 * span, 3 * span))
        for _ in range(30):
            cands.add(rng.randint(-2 * n, 3 * n))
        best_add = None
        best_val = best_s
        for c in cands:
            if c in a:
                continue
            trial = a + [c]
            s, _, _, _ = _eval(trial)
            if s > best_val:
                best_val = s
                best_add = c
        if best_add is None:
            break
        a.append(best_add)
        a.sort()
        best_s = best_val
    return a, best_s


def _local_perturb(a, deadline, rng):
    """Randomly move/add/remove elements, accepting improvements."""
    a = sorted(set(a))
    cur_s, _, _, _ = _eval(a)
    best = a[:]
    best_s = cur_s
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        hi = max((abs(x) for x in cand), default=1)
        if r < 0.45 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-max(1, hi // 2), max(1, hi // 2))
        elif r < 0.75:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-max(1, hi // 2), max(1, hi // 2)))
        elif r < 0.92 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            if cand:
                cand = sorted(set(cand))
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s, _, _, _ = _eval(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.05:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    rng = random.Random(20240607)
    deadline = time.time() + 108

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Structured sweep: interval base n plus k extras grown greedily.
    starts = []
    for n in (6, 10, 16, 24, 32, 48, 64, 96):
        for k in (2, 4, 6, 8):
            starts.append((n, k))

    for (n, k) in starts:
        if time.time() > deadline:
            break
        a, s = _greedy_extra(n, k, rng, min(deadline, time.time() + 6))
        if s > best_s:
            best, best_s = a[:], s

    # local descent from the best structure and random restarts
    t = time.time()
    while t < deadline:
        if rng.random() < 0.5:
            start = best[:]
        else:
            n = rng.choice([8, 12, 20, 32, 50])
            k = rng.randint(2, 8)
            start = _build(n, [rng.randint(-4 * n, 6 * n) for _ in range(k)])
        a, s = _local_perturb(start, min(deadline, time.time() + 8), rng)
        if s > best_s:
            best, best_s = a[:], s
        t = time.time()

    return sorted(set(best))
# EVOLVE-BLOCK-END
