# EVOLVE-BLOCK-START
"""Deterministic sweep over interval + geometric-block constructions."""
import math
import time


def _ratio(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    A = a
    diffs = set()
    sums = set()
    for x in A:
        for y in A:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _eval(A):
    n = len(A)
    diffs = set()
    sums = set()
    for x in A:
        for y in A:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def solve():
    deadline = time.time() + 100
    best_A = [7, 15, 18, 22, -3, -2]
    best_score = _eval(best_A)[0]

    # Family: interval {0..n-1} union geometric block {shift + M*2^i : i<k}
    # Try grids; stop early if deadline nears.
    for n in [5, 6, 8, 10, 12, 15, 20, 30, 40, 60, 80, 100]:
        if time.time() > deadline:
            break
        inter = list(range(n))
        for k in [2, 3, 4, 5, 6, 7, 8, 10, 12]:
            if time.time() > deadline:
                break
            base = [1 << i for i in range(k)]
            for M in [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 100, 200]:
                # place block far enough above interval but not absurd
                for shift in [n, n + M, n + 2 * M, 2 * n, 3 * n, 0]:
                    if time.time() > deadline:
                        break
                    A = list(set(inter + [shift + M * b for b in base]))
                    if len(A) > 4000:
                        continue
                    if max(abs(x) for x in A) > 10**15:
                        continue
                    sc = _eval(A)[0]
                    if sc > best_score:
                        best_score = sc
                        best_A = A
    return sorted(set(best_A))
# EVOLVE-BLOCK-END
