# EVOLVE-BLOCK-START
"""Simulated annealing + structured construction (B union -B) for large difference / small sum set."""
import math
import random
import time


def _score_set(a):
    n = len(a)
    if n < 2:
        return 0.0
    al = list(a)
    diffs = set()
    sums = set()
    for x in al:
        for y in al:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 100

    # Structured seed: a difference-rich core B (powers of two scaled),
    # symmetrized as A = B ∪ (-B) to roughly double distinct differences
    # while sums stay bounded (cross sums fall into few magnitude classes).
    best = None
    best_score = -1.0

    seeds = []
    sizes = [6, 8, 10, 12, 16, 24, 32]
    for s in sizes:
        # powers of two block
        B = [1 << i for i in range(s)]
        A = B + [-b for b in B]
        seeds.append(A)
        # mixed: powers of two plus small AP core in B
        B2 = [1 << i for i in range(s)] + [1 << (s + 2)] 
        A2 = B2 + [-b for b in B2]
        seeds.append(A2)

    for A in seeds:
        A = sorted(set(A))
        sc = _score_set(A)
        if sc > best_score:
            best_score = sc
            best = A[:]

    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.6:
            # perturb one element
            i = rng.randrange(len(cand))
            if abs(cand[i]) > (1 << 40):
                cand[i] = rng.randint(-(1 << 40), (1 << 40))
            else:
                cand[i] += rng.choice([-1, 1]) * rng.randint(0, max(1, abs(cand[i]) // 4 + 1))
        elif r < 0.75:
            # add a new element
            if len(cand) < 4000:
                e = rng.randint(-(1 << 40), (1 << 40))
                cand.append(e)
        elif r < 0.85:
            # remove an element
            if len(cand) > 3:
                del cand[cand.index(rng.choice(cand))]
        elif r < 0.93:
            # shift whole set (no score change, helps escape)
            d = rng.randint(-1000, 1000)
            cand = [x + d for x in cand]
        else:
            # symmetrize move: ensure -x present
            e = rng.choice(cand)
            if -e not in cand and len(cand) < 4000:
                cand.append(-e)

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score_set(cand)
        if sc >= cur_score or rng.random() < 0.02:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc
        elif rng.random() < 0.05:
            cur, cur_score = best[:], best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
