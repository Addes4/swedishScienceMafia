# EVOLVE-BLOCK-START
"""Interval + scaled B_2 (Sidon-like) block construction with exact hill-climb."""
import math
import time


def _counts(A):
    A = list(A)
    diffs = set()
    sums = set()
    for x in A:
        for y in A:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _ratio(A):
    if len(A) < 2:
        return 0.0
    d, s = _counts(A)
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100


def _greedy_b2(limit, bound):
    """Greedy Sidon/B_2 set: all pairwise sums distinct (or near), size <= limit."""
    B = [0]
    used_sums = {0}
    x = 1
    while len(B) < limit and x < bound:
        ok = True
        new = set()
        for b in B:
            s = b + x
            if s in used_sums or s in new:
                ok = False
                break
            new.add(s)
        if ok:
            B.append(x)
            used_sums |= new
            used_sums.add(2 * x)
        x += 1
    return B


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _ratio(best)
    deadline = time.time() + 110

    # Precompute a few B_2 blocks of varying sizes.
    blocks = {}
    for k in (4, 5, 6, 7, 8, 9, 10, 12):
        blocks[k] = _greedy_b2(k, 100000)

    # Sweep intervals + scaled/offset B_2 block.
    for n in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 30):
        interval = list(range(n))
        for k, B in blocks.items():
            spanB = max(B) if B else 1
            for d in (1, 2, 3, 5, 8, 13, 21, 34, 55, 89):
                for M in (n, 2 * n, 3 * n, n + d * spanB + 1,
                          n + d * spanB + 2, 2 * (n + d * spanB)):
                    A = interval + [M + d * b for b in B]
                    A = sorted(set(A))
                    if len(A) < 2:
                        continue
                    sc = _ratio(A)
                    if sc > best_score:
                        best_score, best = sc, A[:]
                    if time.time() > deadline:
                        return sorted(set(best))

    # Local improvement: shift the block offset and scale slightly.
    cur = best[:]
    improved = True
    while improved and time.time() < deadline:
        improved = False
        n_int = len([x for x in cur if x < 0])
        for delta in (-2, -1, 1, 2, -5, 5, -10, 10, -50, 50):
            cand = cur[:]
            # shift only the block part (elements far from 0)
            thr = max(cur) // 2
            cand = [x + delta if x > thr else x for x in cand]
            sc = _ratio(cand)
            if sc > best_score:
                best_score, best, cur, improved = sc, cand[:], cand, True
                break

    return sorted(set(best))
# EVOLVE-BLOCK-END
