# EVOLVE-BLOCK-START
"""Greedy construction maximizing log|A-A|/log|A+A| with local repair."""
import math
import random
import time


def _ratio(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums))


def solve():
    deadline = time.time() + 110
    random.seed(12345)

    best = None
    best_score = -1.0

    # Try several seeds/cores
    cores = [
        [0, 1, 2, 3, 4],
        [0, 3, 6, 9, 12, 15],
        [0, 1, 2, 4, 8, 16],
        [0, 1, 2, 3, 5, 8, 13],
        [0, 7, 14, 21],
    ]

    pool_base = list(range(-60, 61))

    for core in cores:
        if time.time() > deadline:
            break
        cur = [x - min(core) for x in core]
        cur = list(set(cur))
        cur_ratio = _ratio(cur)
        improved = True
        # Greedy add phase
        while improved and time.time() < deadline:
            improved = False
            offset = random.randint(-30, 30)
            pool = list(range(min(cur) - 40 + offset, max(cur) + 41 + offset))
            random.shuffle(pool)
            best_add = None
            best_add_ratio = cur_ratio
            for c in pool:
                if c in cur:
                    continue
                cand = cur + [c]
                r = _ratio(cand)
                if r > best_add_ratio:
                    best_add_ratio = r
                    best_add = c
            if best_add is not None:
                cur.append(best_add)
                cur_ratio = best_add_ratio
                improved = True
                if cur_ratio > best_score:
                    best_score = cur_ratio
                    best = cur[:]
        # Local repair: try removing an element if it helps
        changed = True
        while changed and time.time() < deadline and len(cur) > 3:
            changed = False
            for i in range(len(cur)):
                cand = cur[:i] + cur[i + 1:]
                r = _ratio(cand)
                if r > cur_ratio:
                    cur = cand
                    cur_ratio = r
                    changed = True
                    break
        if cur_ratio > best_score:
            best_score = cur_ratio
            best = cur[:]

    if best is None:
        best = [0, 1, 2, 3, 4, 5]

    # Convert to distinct sorted ints
    result = sorted(set(int(x) for x in best))
    if len(result) < 2:
        result = [0, 1]
    return result
# EVOLVE-BLOCK-END

