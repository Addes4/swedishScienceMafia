# EVOLVE-BLOCK-START
"""Structured construction + fast incremental local search for large |A-A|, small |A+A|."""
import math
import random
import time


def _score_set(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    al = list(a)
    for i in range(n):
        ai = al[i]
        for j in range(n):
            diffs.add(ai - al[j])
            sums.add(ai + al[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _diffs_count(a):
    s = set()
    for x in a:
        for y in a:
            s.add(x - y)
    return len(s)


def _sums_count(a):
    s = set()
    for x in a:
        for y in a:
            s.add(x + y)
    return len(s)


def _score_fast(a):
    n = len(a)
    if n < 2:
        return 0.0
    d = _diffs_count(a)
    s = _sums_count(a)
    if s < 2 or d < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _seed_geometric(k, base, shift):
    """Powers-of-base geometric block scaled by shift: many distinct differences."""
    vals = []
    v = 0
    for i in range(k):
        vals.append(v * shift + (i % 2))
        v = v * base + 1
    return vals


def _seed_ap(n, step, start):
    return [start + i * step for i in range(n)]


def _seed_mixed(k, ap_len, ap_step):
    """Geometric block + small AP core."""
    g = _seed_geometric(k, 2, 1)
    ap = _seed_ap(ap_len, ap_step, 0)
    return list(set(g) | set(ap))


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    candidates = []
    # Several structured seeds
    for k in (8, 10, 12, 14):
        for ap_len in (2, 3, 4, 6):
            for ap_step in (1, 3, 7):
                s = _seed_mixed(k, ap_len, ap_step)
                if 2 <= len(s) <= 200:
                    candidates.append(s)

    # Random-powers seeds
    for _ in range(20):
        k = random.randint(6, 16)
        base = random.choice([2, 3, 4, 5])
        vals = []
        v = 0
        for i in range(k):
            vals.append(v)
            v = v * base + random.randint(1, 3)
        candidates.append(list(set(vals) | {0, 1}))
        candidates.append(list(set(vals) | {0, 3, 6}))

    best = None
    best_score = -1.0
    for c in candidates:
        c = sorted(set(c))
        if len(c) < 2:
            continue
        sc = _score_fast(c)
        if sc > best_score:
            best_score = sc
            best = c[:]
            print("[seed] len=%d diffs/sums score=%.5f" % (len(c), sc))

    # Local refinement: try add/remove/perturb moves with incremental scoring
    cur = best[:]
    cur_score = best_score
    no_improve = 0
    while time.time() < deadline:
        cand = cur[:]
        move = random.random()
        if move < 0.45 and len(cand) < 400:
            # add a new element from a focused pool
            lo = min(cand)
            hi = max(cand)
            span = max(1, hi - lo)
            if random.random() < 0.5:
                newv = random.randint(lo - 2 * span, hi + 2 * span)
            else:
                newv = random.randint(-3, 3 * span + 3)
            if newv not in cand:
                cand.append(newv)
            else:
                continue
        elif move < 0.75 and len(cand) > 3:
            # remove
            cand.pop(random.randrange(len(cand)))
        else:
            # perturb one element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
            if len(set(cand)) != len(cand):
                continue
        cand = list(set(cand))
        if len(cand) < 3 or len(cand) > 300:
            continue
        sc = _score_fast(cand)
        if sc >= cur_score:
            if sc > best_score:
                best_score = sc
                best = cand[:]
                print("[best] len=%d score=%.5f diffs=%d sums=%d" % (
                    len(cand), sc, _diffs_count(cand), _sums_count(cand)))
            cur = cand[:]
            cur_score = sc
            no_improve = 0
        else:
            no_improve += 1
            # occasional restart toward best
            if no_improve > 400:
                cur = best[:]
                cur_score = best_score
                no_improve = 0

    # Final: ensure distinct, within bounds
    best = sorted(set(best))
    best = [int(x) for x in best][:4000]
    best = [x for x in best if abs(x) <= 10**15]
    return best
# EVOLVE-BLOCK-END
