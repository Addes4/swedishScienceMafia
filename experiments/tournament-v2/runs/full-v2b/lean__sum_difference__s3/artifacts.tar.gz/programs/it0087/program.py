# EVOLVE-BLOCK-START
"""Search for A maximizing log|A-A|/log|A+A| via deterministic AP-family sweep."""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        return 0.0, ld, ls
    s = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
    return s, ld, ls


def solve():
    deadline = time.time() + 110
    best = [0, 1]
    best_s = _score(best)[0]

    # Family: A = {0} ∪ {D + s*i : i=0..m-1}.  Small n, tune D, s, m.
    candidates = []
    # base AP-only around origin
    for m in range(2, 12):
        for s in range(1, 40):
            A = list(range(0, m * s, s))
            candidates.append(A)
    # offset AP plus 0
    for m in range(2, 10):
        for s in range(1, 40):
            for D in range(1, 200):
                A = [0] + [D + s * i for i in range(m)]
                candidates.append(A)

    for A in candidates:
        if len(A) > 4000:
            continue
        s, ld, ls = _score(A)
        if s > best_s:
            best_s = s
            best = A[:]

    # Intersect two intervals / AP + shifted AP variations
    for m in range(2, 9):
        for n in range(2, 9):
            for s in range(1, 30):
                for t in range(1, 30):
                    A = [i for i in range(n)] + [100 * s + t * i for i in range(m)]
                    if len(A) > 4000:
                        continue
                    sc, _, _ = _score(A)
                    if sc > best_s:
                        best_s = sc
                        best = A[:]

    # Local improvement: try adding/removing/moving one element
    improved = True
    cur = best[:]
    cur_s = best_s
    while improved and time.time() < deadline:
        improved = False
        # try single perturbations
        base = list(set(cur))
        hi = max(abs(x) for x in base) + 50 if base else 50
        for i in range(len(base)):
            for delta in (1, -1, 2, -2, 3, -3, 5, -5, 10, -10):
                cand = base[:]
                cand[i] += delta
                sc, _, _ = _score(cand)
                if sc > cur_s:
                    cur_s = sc
                    cur = cand
                    improved = True
                    break
            if improved:
                break
        if not improved and len(base) < 4000:
            for newv in range(-hi, hi + 1, 1):
                if newv in base:
                    continue
                cand = base + [newv]
                sc, _, _ = _score(cand)
                if sc > cur_s:
                    cur_s = sc
                    cur = cand
                    improved = True
                    break
        if cur_s > best_s:
            best_s = cur_s
            best = cur[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END
