# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeding + exact local search."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _twoblock_score(n, m, s, M):
    """Exact |D|, |S| for A = [0,n) ∪ (M + s*[0,m))."""
    A = list(range(n))
    A += [M + s * j for j in range(m)]
    A = sorted(set(A))
    diffs = set()
    sums = set()
    for x in A:
        for y in A:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(A)


def _make(n, m, s, M):
    A = list(range(n))
    A += [M + s * j for j in range(m)]
    return sorted(set(A))


def _local_refine(A, deadline, rng):
    """Fast local search: perturb elements / step sizes keeping two-block shape."""
    A = sorted(set(A))
    best = A[:]
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.6 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 3)
            cand[i] += rng.randint(-span, span)
        elif r < 0.85:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.95 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 2000:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.1:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    rng = random.Random(98765)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Structured family sweep: A = [0,n) ∪ (M + s*[0,m))
    # The interval gives ~3n-2 diffs and ~2n-1 sums; the spaced block adds many
    # large diffs while its sums can be made to land near the interval's sums.
    cands = []
    for n in (30, 60, 120, 200, 320, 500, 700):
        for m in (2, 3, 4, 6, 10, 20, 40):
            for mult in (10, 30, 100, 300, 1000, 10**4, 10**6):
                s = mult
                for frac in (1.0, 1.5, 2.0, 3.0):
                    M = int(n * frac)
                    if M <= 0:
                        continue
                    cands.append((n, m, s, M))

    seen = set()
    for (n, m, s, M) in cands:
        A = _make(n, m, s, M)
        key = tuple(A)
        if key in seen:
            continue
        seen.add(key)
        if len(A) > 2000:
            continue
        sc = _score(A)
        if sc > best_s:
            best, best_s = A, sc
        if time.time() > deadline:
            break

    # Local search seeded from the best structured candidate
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 2 == 0 and best:
            start = best[:]
        else:
            n = rng.choice([30, 60, 120, 200, 320])
            m = rng.choice([2, 3, 4, 6, 10])
            s = rng.choice([10, 30, 100, 300, 1000])
            M = int(n * rng.uniform(0.8, 3.0))
            start = _make(n, m, s, M)
        cand, cs = _local_refine(start, min(deadline, time.time() + 8), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
