# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| with an incremental scorer + annealing."""
import math
import random
import time


def _inc(cnt, v):
    c = cnt.get(v, 0)
    if c == 0:
        cnt[v] = 1
        return 1
    cnt[v] = c + 1
    return 0


def _dec(cnt, v):
    c = cnt[v]
    if c == 1:
        del cnt[v]
        return -1
    cnt[v] = c - 1
    return 0


class State:
    """Maintains |A+A| and |A-A| incrementally under add/remove."""
    __slots__ = ('A', 'Aset', 'sc', 'dc', 'ns', 'nd')

    def __init__(self, A):
        self.A = sorted(set(A))
        self.Aset = set(self.A)
        self.sc = {}
        self.dc = {}
        self.ns = 0
        self.nd = 0
        for x in self.A:
            for y in self.A:
                self.ns += _inc(self.sc, x + y)
                self.nd += _inc(self.dc, x - y)

    def add(self, x):
        A = self.A
        for a in A:
            self.ns += _inc(self.sc, x + a)
            self.nd += _inc(self.dc, x - a)
            self.nd += _inc(self.dc, a - x)
        self.ns += _inc(self.sc, 2 * x)
        A.append(x)
        self.Aset.add(x)

    def remove(self, x):
        A = self.A
        for a in A:
            if a == x:
                continue
            self.ns += _dec(self.sc, x + a)
            self.nd += _dec(self.dc, x - a)
            self.nd += _dec(self.dc, a - x)
        self.ns += _dec(self.sc, 2 * x)
        A.remove(x)
        self.Aset.discard(x)

    def score(self):
        n = len(self.A)
        if n < 2 or self.ns < 2:
            return -1.0
        return math.log(self.nd) / math.log(self.ns) + (1 - 1 / n) / 100


def _seeds(rng):
    seeds = [[7, 15, 18, 22, -3, -2]]
    for n in (6, 10, 20, 40, 80, 160):
        seeds.append(list(range(n)))
    # interval union shifted block
    for _ in range(30):
        n = rng.randint(5, 40)
        m = rng.randint(3, 30)
        M = rng.randint(n, 4 * (n + m))
        seeds.append(list(range(n)) + [M + i for i in range(m)])
    # interval union geometric tail
    for _ in range(30):
        n = rng.randint(5, 30)
        k = rng.randint(2, 7)
        v = n + 1
        pts = set(range(n))
        for _ in range(k):
            pts.add(v)
            v = int(v * rng.uniform(1.5, 3.0)) + 1
        seeds.append(sorted(pts))
    return seeds


def solve():
    rng = random.Random(1234567)
    deadline = time.time() + 115

    best = [0, 1]
    best_s = -1.0
    for sd in _seeds(rng):
        sd = list(set(sd))
        if len(sd) < 2:
            continue
        st = State(sd)
        s = st.score()
        if s > best_s:
            best_s = s
            best = sd[:]

    st = State(best)
    cur_s = st.score()
    T = 0.03

    while time.time() < deadline:
        A = st.A
        n = len(A)
        span = (A[-1] - A[0]) if n >= 2 else 1
        span = max(span, 1)
        r = rng.random()

        if r < 0.55 or n < 4:
            # ADD: half the time a sum-colliding value
            if n >= 2 and rng.random() < 0.5:
                x = rng.choice(A) + rng.choice(A)
            else:
                a = rng.choice(A) if A else 0
                x = a + rng.randint(-span - 3, span + 3)
            if x in st.Aset or len(A) >= 4000:
                continue
            st.add(x)
            s = st.score()
            if s >= cur_s or rng.random() < math.exp((s - cur_s) / T):
                cur_s = s
                if s > best_s:
                    best_s = s
                    best = st.A[:]
            else:
                st.remove(x)

        elif r < 0.80:
            # REMOVE
            x = rng.choice(A)
            st.remove(x)
            s = st.score()
            if s >= cur_s or rng.random() < math.exp((s - cur_s) / T):
                cur_s = s
                if s > best_s:
                    best_s = s
                    best = st.A[:]
            else:
                st.add(x)

        else:
            # SHIFT one element
            if n < 3:
                continue
            x = rng.choice(A)
            a = rng.choice(A)
            y = a + rng.randint(-span - 3, span + 3)
            if y in st.Aset:
                continue
            st.remove(x)
            st.add(y)
            s = st.score()
            if s >= cur_s or rng.random() < math.exp((s - cur_s) / T):
                cur_s = s
                if s > best_s:
                    best_s = s
                    best = st.A[:]
            else:
                st.remove(y)
                st.add(x)

        T *= 0.999995
        if T < 0.0015:
            T = 0.02  # reheat

    return sorted(set(best))
# EVOLVE-BLOCK-END
