# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeding + fast exact hill-climb."""
import math
import random
import time


def _score_from_counts(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _counts(a):
    """Return (diff_counts, sum_counts)."""
    dc = {}
    sc = {}
    for x in a:
        for y in a:
            d = x - y
            dc[d] = dc.get(d, 0) + 1
            s = x + y
            sc[s] = sc.get(s, 0) + 1
    return dc, sc


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    dc, sc = _counts(a)
    return _score_from_counts(len(dc), len(sc), len(a))


def _seed_family(rng):
    """A = {0..n-1} union (M + scale*Sidon-like block)."""
    n = rng.randint(10, 60)
    A = set(range(n))
    k = rng.randint(2, 6)
    # Sidon-like block: near-geometric distinct large values
    S = set()
    v = 1
    for _ in range(k):
        S.add(v)
        v = int(v * rng.uniform(1.4, 2.2)) + rng.randint(1, 4)
    M = rng.choice([n, 2 * n, 3 * n, 5 * n, 10 * n, 20 * n])
    scale = rng.choice([1, 2, 3, n, 2 * n])
    for s in S:
        A.add(M + scale * s)
    return sorted(A)


def _hill_climb(start, deadline, rng):
    """Incremental exact-score hill climb maintaining diff/sum multiplicity counts."""
    cur = sorted(set(start))
    dc, sc = _counts(cur)
    nd, ns, n = len(dc), len(sc), len(cur)
    cur_s = _score_from_counts(nd, ns, n)
    best = cur[:]
    best_s = cur_s

    hi = max((abs(x) for x in cur), default=1)

    def add_val(v):
        # returns (nd, ns, n) after adding v, updating dc, sc
        nonlocal nd, ns, n
        if v in set(cur):
            return None
        for x in cur:
            d = x - v
            if dc.get(d, 0) == 0:
                nd += 1
            dc[d] = dc.get(d, 0) + 1
            d2 = v - x
            if dc.get(d2, 0) == 0:
                nd += 1
            dc[d2] = dc.get(d2, 0) + 1
            s = v + x
            if sc.get(s, 0) == 0:
                ns += 1
            sc[s] = sc.get(s, 0) + 1
        if sc.get(2 * v, 0) == 0:
            ns += 1
        sc[2 * v] = sc.get(2 * v, 0) + 1
        if dc.get(0, 0) == 0:
            nd += 1
        dc[0] = dc.get(0, 0) + 1
        n += 1
        cur.append(v)
        return nd, ns, n

    def remove_val(idx):
        nonlocal nd, ns, n
        v = cur[idx]
        for i, x in enumerate(cur):
            if i == idx:
                continue
            d = x - v
            dc[d] -= 1
            if dc[d] == 0:
                nd -= 1
                del dc[d]
            d2 = v - x
            dc[d2] -= 1
            if dc[d2] == 0:
                nd -= 1
                del dc[d2]
            s = v + x
            sc[s] -= 1
            if sc[s] == 0:
                ns -= 1
                del sc[s]
        sc[2 * v] -= 1
        if sc[2 * v] == 0:
            ns -= 1
            del sc[2 * v]
        dc[0] -= 1
        if dc[0] == 0:
            nd -= 1
            del dc[0]
        n -= 1
        cur.pop(idx)
        return nd, ns, n

    while time.time() < deadline:
        r = rng.random()
        if r < 0.45:
            # try adding a new element (extend interval or shift block)
            anchor = rng.choice(cur) if cur else 0
            v = anchor + rng.randint(-hi, hi)
            if v in set(cur) or len(cur) >= 4000:
                continue
            nd, ns, n = add_val(v)
            s = _score_from_counts(nd, ns, n)
            if s >= cur_s:
                cur_s = s
                if s > best_s:
                    best, best_s = cur[:], s
            else:
                remove_val(len(cur) - 1)
        elif r < 0.8 and len(cur) > 3:
            # move an element
            i = rng.randrange(len(cur))
            old = cur[i]
            remove_val(i)
            anchor = rng.choice(cur) if cur else 0
            v = anchor + rng.randint(-hi, hi)
            if v in set(cur):
                add_val(old)
                continue
            add_val(v)
            s = _score_from_counts(nd, ns, n)
            if s >= cur_s:
                cur_s = s
                if s > best_s:
                    best, best_s = cur[:], s
            else:
                remove_val(len(cur) - 1)
                add_val(old)
        else:
            # try extending the dense interval downward/upward
            lo = min(cur)
            add_val(lo - 1)
            s = _score_from_counts(nd, ns, n)
            if s >= cur_s:
                cur_s = s
                if s > best_s:
                    best, best_s = cur[:], s
            else:
                remove_val(cur.index(lo - 1))
        hi = max((abs(x) for x in cur), default=1) if cur else 1

    return best, best_s


def solve():
    rng = random.Random(20240517)
    deadline = time.time() + 110

    best = [0, 1, 2, 3, 4, 5, 7, 11, 16, 22, 60, 100, 210, 450]
    best = sorted(set(best))
    best_s = _score(best)

    # deterministic seeds
    seeds = []
    for n in (12, 24, 48, 96):
        seeds.append(list(range(n)))
    for _ in range(60):
        seeds.append(_seed_family(rng))

    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 4 == 0:
            start = best[:]
        else:
            start = _seed_family(rng)
        cand, cs = _hill_climb(start, min(deadline, time.time() + 15), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
