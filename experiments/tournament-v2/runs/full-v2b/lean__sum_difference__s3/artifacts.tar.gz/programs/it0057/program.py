# EVOLVE-BLOCK-START
"""Deterministic parametric search over A = interval ∪ scaled AP block."""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _counts(a):
    """Return (num_distinct_diffs, num_distinct_sums) computed via bitset-like sets."""
    s = set(a)
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def solve():
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # Family: A = {0..n-1} union {M + j*s : j=0..m-1}
    # Sweep n, m, s and M, scoring each. M chosen so sums interleave.
    n_list = list(range(2, 41))
    m_list = list(range(1, 41))
    s_list = list(range(1, 31))

    for n in n_list:
        for m in m_list:
            for s in s_list:
                if time.time() > deadline:
                    break
                # Build interval part.
                I = list(range(n))
                # Try several M offsets relative to n and to block span.
                span = (m - 1) * s
                # Candidate base offsets: near the top of interval, plus a gap g.
                g_choices = set()
                base = n
                for g in range(1, 40):
                    g_choices.add(base + g)
                # also offsets so that the block's sums range overlaps interval sums
                # interval sums in [0, 2n-2]; block sums in [2M, 2M+2span]
                # overlapping => M around n
                g_choices.add(n)
                g_choices.add(n - 1)
                g_choices.add(n + 1)
                for M in g_choices:
                    if time.time() > deadline:
                        break
                    B = [M + j * s for j in range(m)]
                    A = I + B
                    if len(set(A)) != n + m:
                        continue
                    d, su = _counts(A)
                    if su < 2:
                        continue
                    sc = math.log(d) / math.log(su) + (1 - 1 / len(A)) / 100
                    if sc > best_s:
                        best_s = sc
                        best = sorted(set(A))
            if time.time() > deadline:
                break

    return best
# EVOLVE-BLOCK-END
