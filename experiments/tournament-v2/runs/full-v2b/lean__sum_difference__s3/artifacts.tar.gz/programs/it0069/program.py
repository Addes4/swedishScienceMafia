# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeding + exact hill-climb."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _seed_interval_geometric(rng):
    n = rng.randint(8, 40)
    base = set(range(n))
    k = rng.randint(2, 6)
    scale = rng.choice([n * 2, n * 3, n * 4, n * 8])
    pts = set()
    v = scale
    for _ in range(k):
        pts.add(v)
        v = int(v * rng.uniform(1.5, 2.5)) + rng.randint(0, scale)
    return sorted(base | pts)


def _seed_twoblocks(rng):
    n = rng.randint(6, 30)
    m = rng.randint(3, 20)
    s = rng.randint(n + 1, 6 * (n + m))
    A = set(range(n))
    A |= {s + i for i in range(m)}
    return sorted(A)


def _seed_union_ap(rng):
    """A = [0,n) union (M + s*[0,m)) : dense low block + scaled AP block.

    The scaled block keeps few sums; placing M so the two blocks' sums overlap
    maximally keeps |A+A| small while the block offset spreads differences.
    """
    n = rng.randint(20, 120)
    m = rng.randint(5, 60)
    s = rng.choice([2, 3, 4, 5, 6, 7, 8, 10])
    # M chosen so that (M + s*i) lands near/within the sum range of the low block
    M = rng.choice([n, n - 1, n // 2, n + m, 2 * n - s * m // 2])
    M = max(M, n)
    A = set(range(n))
    A |= {M + s * i for i in range(m)}
    return sorted(A)


def _hill_climb(start, deadline, rng):
    best = list(set(start))
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.5 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 2)
            cand[i] += rng.randint(-span, span)
        elif r < 0.8:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.95 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            if cand:
                cand = sorted(set(cand))
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.08:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    rng = random.Random(12345)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    seeds = []
    for n in (10, 20, 40, 80):
        seeds.append(list(range(n)))
    for _ in range(40):
        seeds.append(_seed_interval_geometric(rng))
    for _ in range(40):
        seeds.append(_seed_twoblocks(rng))
    # strong structured seeds
    for _ in range(120):
        seeds.append(_seed_union_ap(rng))

    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    attempts = 0
    while time.time() < deadline:
        attempts += 1
        r = attempts % 4
        if r == 0:
            start = _seed_interval_geometric(rng)
        elif r == 1:
            start = _seed_twoblocks(rng)
        elif r == 2:
            start = _seed_union_ap(rng)
        else:
            start = best[:]
        cand, cs = _hill_climb(start, min(deadline, time.time() + 12), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
