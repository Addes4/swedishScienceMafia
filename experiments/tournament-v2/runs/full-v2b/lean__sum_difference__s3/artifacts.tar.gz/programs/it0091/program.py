# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeding + exact hill-climb."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _seed_interval_geometric(rng):
    n = rng.randint(8, 40)
    base = set(range(n))
    k = rng.randint(2, 6)
    scale = rng.choice([n * 2, n * 3, n * 4, n * 8])
    pts = set()
    v = scale
    for _ in range(k):
        pts.add(v)
        v = int(v * rng.uniform(1.5, 2.5)) + rng.randint(0, scale)
    return sorted(base | pts)


def _seed_twoblocks(rng):
    """A = [0,n) union {M + s*i : i=0..m-1}."""
    n = rng.randint(8, 40)
    m = rng.randint(3, 30)
    s = rng.randint(1, 5)
    M = rng.randint(n + s, 8 * (n + m * s))
    A = set(range(n))
    A |= {M + s * i for i in range(m)}
    return sorted(A)


def _hill_climb(start, deadline, rng):
    best = list(set(start))
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.45 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 2)
            cand[i] += rng.randint(-span, span)
        elif r < 0.75:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.9 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            if cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1])
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.1:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # deterministic two-block sweep seeds
    for n in (6, 8, 10, 12, 14, 16, 20, 24, 30, 40):
        for m in (3, 5, 8, 12, 16, 24, 30):
            for s in (1, 2, 3):
                for M in range(n + s, n + s + 40 * (n + m * s) + 1,
                               max(1, (n + m * s))):
                    A = set(range(n))
                    A |= {M + s * i for i in range(m)}
                    A = sorted(A)
                    sc = _score(A)
                    if sc > best_s:
                        best, best_s = A, sc

    seeds = [best[:]]
    for _ in range(60):
        seeds.append(_seed_interval_geometric(rng))
    for _ in range(60):
        seeds.append(_seed_twoblocks(rng))

    for seed in seeds:
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    attempts = 0
    while time.time() < deadline:
        attempts += 1
        r = attempts % 4
        if r == 0:
            start = _seed_twoblocks(rng)
        elif r == 1:
            start = _seed_interval_geometric(rng)
        elif r == 2:
            start = best[:]
        else:
            start = _seed_twoblocks(rng)
        cand, cs = _hill_climb(start, min(deadline, time.time() + 10), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
