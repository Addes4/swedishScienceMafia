# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured seeding + exact hill-climb."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _fast_counts(a):
    """Return (ndiff, nsum) exactly."""
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score_from(nd, ns, n):
    if ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _seed_interval_geometric(rng):
    n = rng.randint(8, 40)
    base = set(range(n))
    k = rng.randint(2, 6)
    scale = rng.choice([n * 2, n * 3, n * 4, n * 8])
    pts = set()
    v = scale
    for _ in range(k):
        pts.add(v)
        v = int(v * rng.uniform(1.5, 2.5)) + rng.randint(0, scale)
    return sorted(base | pts)


def _seed_twoblocks(rng):
    n = rng.randint(6, 30)
    m = rng.randint(3, 20)
    s = rng.randint(n + 1, 6 * (n + m))
    A = set(range(n))
    A |= {s + i for i in range(m)}
    return sorted(A)


def _seed_union_ap(n, m, s, M):
    """A = [0,n) union (M + s*[0,m))."""
    A = set(range(n))
    A |= {M + s * i for i in range(m)}
    return sorted(A)


def _greedy_colliding(seed, deadline, rng, max_add=60):
    """Greedily add elements x = a+b (sums) to maximize diff/sum growth."""
    A = list(set(seed))
    nd, ns = _fast_counts(A)
    n = len(A)
    best_s = _score_from(nd, ns, n)
    for _ in range(max_add):
        if time.time() > deadline:
            break
        aset = set(A)
        # candidate values: pairwise sums of existing elements
        cand_set = set()
        L = list(aset)
        for i in range(len(L)):
            for j in range(i, len(L)):
                cand_set.add(L[i] + L[j])
        # try a random subset of candidates for speed
        cand_list = list(cand_set)
        if len(cand_list) > 120:
            rng.shuffle(cand_list)
            cand_list = cand_list[:120]
        best_local = None
        best_local_s = best_s
        hi = max(abs(x) for x in A)
        for x in cand_list:
            if x in aset:
                continue
            if abs(x) > 10 ** 15:
                continue
            nd2, ns2 = _fast_counts(A + [x])
            s2 = _score_from(nd2, ns2, n + 1)
            if s2 > best_local_s:
                best_local_s = s2
                best_local = x
        if best_local is None:
            break
        A.append(best_local)
        n += 1
        nd, ns = _fast_counts(A)
        best_s = _score_from(nd, ns, n)
        if n >= 200:
            break
    return A, best_s


def _hill_climb(start, deadline, rng):
    best = list(set(start))
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.5 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 2)
            cand[i] += rng.randint(-span, span)
        elif r < 0.8:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.95 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            if cand:
                cand = sorted(set(cand))
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        if max(abs(x) for x in cand) > 10 ** 15:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.08:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    rng = random.Random(12345)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    # structured union-of-AP seeds
    for n in (10, 20, 40, 60, 80):
        for m in (10, 20, 30, 50):
            for s in (1, 2, 3, 5, 10):
                M = n + rng.randint(1, 3)
                seed = _seed_union_ap(n, m, s, M)
                if max(abs(x) for x in seed) > 10 ** 15:
                    continue
                sscore = _score(seed)
                if sscore > best_s:
                    best, best_s = seed[:], sscore

    # greedy colliding constructions from good seeds
    greedy_seeds = [list(range(20)), _seed_twoblocks(rng), _seed_interval_geometric(rng)]
    for gs in greedy_seeds:
        if time.time() > deadline - 20:
            break
        A, s = _greedy_colliding(gs, min(deadline, time.time() + 20), rng)
        if s > best_s:
            best, best_s = A[:], s

    # hill climb from multiple restarts
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts % 4 == 0:
            start = _seed_interval_geometric(rng)
        elif attempts % 4 == 1:
            start = _seed_twoblocks(rng)
        elif attempts % 4 == 2:
            start = _seed_union_ap(rng.randint(8, 50), rng.randint(5, 40),
                                   rng.choice([1, 2, 3, 5]), rng.randint(10, 80))
        else:
            start = best[:]
        try:
            cand, cs = _hill_climb(start, min(deadline, time.time() + 10), rng)
        except Exception:
            continue
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
