# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via structured multi-block seeding + exact hill-climb."""
import math
import random
import time


def _score_counts(d, s, n):
    if s < 2 or n < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for y in a[i:]:
            diffs.add(x - y)
            diffs.add(y - x)
            sums.add(x + y)
    return _score_counts(len(diffs), len(sums), n)


def _counts(a):
    a = list(a)
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for y in a[i:]:
            diffs.add(x - y)
            diffs.add(y - x)
            sums.add(x + y)
    return len(diffs), len(sums), len(a)


def _core(k, rng):
    """Small difference-rich core (greedy B2-ish, spread)."""
    pts = [0]
    used = {0}
    while len(pts) < k:
        cand = rng.randint(1, 40)
        if cand not in used:
            pts.append(cand)
            used.add(cand)
    return sorted(pts)


def _seed_multiblock(rng):
    """Interval {0..n-1} plus several scaled/translated copies of a small core."""
    n = rng.randint(10, 60)
    A = set(range(n))
    nblocks = rng.randint(1, 4)
    span = n
    offset = span
    for _ in range(nblocks):
        k = rng.randint(2, 6)
        core = _core(k, rng)
        scale = rng.randint(1, max(1, offset // max(1, max(core))))
        # place far away
        base = offset + rng.randint(0, span)
        for c in core:
            A.add(base + scale * c)
        span = max(span, max(A) - base + 1) + rng.randint(1, 4 * n)
        offset = max(A) + rng.randint(1, 4 * n)
    return sorted(A)


def _seed_twointerval(rng):
    n = rng.randint(6, 40)
    m = rng.randint(3, 30)
    s = rng.randint(n + 1, 8 * (n + m))
    A = set(range(n))
    A |= {s + i for i in range(m)}
    return sorted(A)


def _greedy_add(A, deadline, best_s):
    """Greedily add elements that improve exact score."""
    A = list(set(A))
    d, s, n = _counts(A)
    improved = True
    while improved and time.time() < deadline:
        improved = False
        hi = max(abs(x) for x in A) + 1
        candidates = []
        for _ in range(8):
            candidates.append(random.randint(-hi, hi * 2))
        for x in candidates:
            if x in A:
                continue
            nd = set()
            ns = set()
            for y in A:
                nd.add(x - y)
                nd.add(y - x)
                ns.add(x + y)
            # estimate new counts
            new_d = d + len(nd)  # rough upper-bound-ish
            new_s = s + len(ns)
            # exact would require recompute; do recompute cheaply for small sets
            B = A + [x]
            dd, ss, nn = _counts(B)
            if _score_counts(dd, ss, nn) > best_s:
                A = B
                d, s, n = dd, ss, nn
                best_s = _score_counts(dd, ss, nn)
                improved = True
                break
    return A, _score_counts(*_counts(A))


def _hill_climb(start, deadline, rng):
    best = list(set(start))
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    hi = max(abs(x) for x in cur) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.4 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 2)
            cand[i] += rng.randint(-span, span)
        elif r < 0.75:
            anchor = rng.choice(cand) if cand else 0
            cand.append(anchor + rng.randint(-hi, hi))
        elif r < 0.9 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.1:
            cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    rng = random.Random(987654321)
    random.seed(987654321)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    for n in (10, 20, 40, 80):
        cand = list(range(n))
        s = _score(cand)
        if s > best_s:
            best, best_s = cand, s

    # structured seeds
    for _ in range(200):
        seed = _seed_multiblock(rng)
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s
    for _ in range(100):
        seed = _seed_twointerval(rng)
        s = _score(seed)
        if s > best_s:
            best, best_s = seed[:], s

    # greedy add from best
    cand, cs = _greedy_add(best, min(deadline, time.time() + 10), best_s)
    if cs > best_s:
        best, best_s = cand, cs

    # hill climb restarts
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        r = attempts % 3
        if r == 0:
            start = _seed_multiblock(rng)
        elif r == 1:
            start = _seed_twointerval(rng)
        else:
            start = best[:]
        cand, cs = _hill_climb(start, min(deadline, time.time() + 10), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
