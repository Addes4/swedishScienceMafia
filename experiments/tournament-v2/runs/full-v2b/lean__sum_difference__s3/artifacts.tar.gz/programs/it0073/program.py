# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A|.

Key construction: A = [0,n) union (M + [0,m)) where the second block is placed
so that A+A is (nearly) a single interval (few sums) while A-A has two
well-separated clusters (many differences).  We score candidates exactly with
fast bitset/offset arithmetic and sweep parameters deterministically.
"""
import math
import random
import time


def _fast_counts(A):
    """Exact (|A-A|, |A+A|) using a compact offset bitset over a window."""
    if len(A) < 2:
        return 0, 0
    lo = min(A)
    hi = max(A)
    span = hi - lo
    # differences range in [-span, span]; sums range in [2*lo, 2*hi]
    size_d = 2 * span + 1
    size_s = (2 * hi) - (2 * lo) + 1
    # use python ints as bitsets for speed
    dmask = 0
    smask = 0
    off_d = span
    off_s = -2 * lo
    for i, x in enumerate(A):
        bi = (x + off_d)
        # differences x - y
        for y in A:
            dmask |= 1 << (x - y + off_d)
            smask |= 1 << (x + y + off_s)
    dc = bin(dmask).count("1")
    sc = bin(smask).count("1")
    return dc, sc


def _score_counts(dc, sc, n):
    if sc < 2 or n < 2:
        return 0.0
    return math.log(dc) / math.log(sc) + (1 - 1 / n) / 100


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    dc, sc = _fast_counts(a)
    return _score_counts(dc, sc, n)


def _two_block(n, m, M):
    """A = [0,n) union (M + [0,m))."""
    A = list(range(n))
    A.extend(M + i for i in range(m))
    return sorted(set(A))


def _eval_two_block(n, m, M):
    A = _two_block(n, m, M)
    if len(A) < 2:
        return None
    dc, sc = _fast_counts(A)
    return _score_counts(dc, sc, len(A)), A, dc, sc


def _sweep(deadline):
    best = None
    best_s = -1.0
    # classical optimized two-block: M ~ n + m and blocks comparable.
    # Sweep n, m and M around the "sum-preserving" region.
    nvals = [8, 12, 16, 20, 25, 30, 40, 50, 60, 80, 100, 128, 160, 200, 256]
    mvals = [4, 6, 8, 12, 16, 20, 25, 30, 40, 50, 64, 80, 100, 128]
    for n in nvals:
        for m in mvals:
            if time.time() > deadline:
                return best, best_s
            # M chosen so that the second block sits just past a copy of [0,n)
            # making A+A an interval: try M = n, n+1, ... and scaled variants
            cands = set()
            cands.add(n)
            cands.add(n + 1)
            cands.add(n + m)
            cands.add(n + m - 1)
            cands.add(2 * n)
            cands.add(2 * n + 1)
            cands.add(n * m // max(1, n) + n)
            # a range scan near n..n+m
            for M in range(n - 2, n + m + 3):
                if M > 0:
                    cands.add(M)
            for M in cands:
                if M <= 0:
                    continue
                r = _eval_two_block(n, m, M)
                if r is None:
                    continue
                s, A, dc, sc = r
                if s > best_s:
                    best_s = s
                    best = A
    return best, best_s


def _local_refine(A, deadline, rng):
    best = list(set(A))
    best_s = _score(best)
    if best_s <= 0:
        return best, best_s
    hi = max(abs(x) for x in best) if best else 1
    cur = best[:]
    cur_s = best_s
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.6 and cand:
            i = rng.randrange(len(cand))
            span = max(1, hi // 4)
            cand[i] += rng.randint(-span, span)
        elif r < 0.85:
            anchor = rng.choice(cand)
            cand.append(anchor + rng.randint(-hi, hi))
        elif len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        if max(abs(x) for x in cand) > 10**15:
            continue
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
    return best, best_s


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best, best_s = _sweep(min(deadline, time.time() + 40))

    # fallback
    if best is None:
        best = [0, 1, 2, 3, 5, 8, 13]
        best_s = _score(best)

    # local refinement around the best structural candidate
    refine_deadline = time.time() + 100
    while time.time() < refine_deadline:
        cand, cs = _local_refine(best, min(refine_deadline, time.time() + 15), rng)
        if cs > best_s:
            best, best_s = cand[:], cs

    return sorted(set(best))
# EVOLVE-BLOCK-END
