# EVOLVE-BLOCK-START
"""Search for A maximising log|A-A|/log|A+A| via exact multi-block sweep + local search."""
import math
import time


def _stats(A):
    A = list(set(A))
    sa = set()
    sb = set()
    for x in A:
        for y in A:
            sa.add(x - y)
            sb.add(x + y)
    return len(sa), len(sb), len(A)


def _score(A):
    d, s, n = _stats(A)
    if n < 2 or s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _best_for_blocks(blocks):
    """blocks: list of (offset, step, count). Build A and score exactly."""
    A = []
    for off, step, cnt in blocks:
        for i in range(cnt):
            A.append(off + step * i)
    A = sorted(set(A))
    if len(A) < 2 or len(A) > 4000:
        return None, -1.0
    mx = max(abs(x) for x in A)
    if mx > 10 ** 15:
        return None, -1.0
    d, s, n = _stats(A)
    if s < 2:
        return None, -1.0
    return A, math.log(d) / math.log(s) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110
    best = [0, 1, 2, 3, 4, 5, 6]
    best_s = _score(best)

    # deterministic sweep over two-block family [0,n) union {M + s*i : i in [0,m)}
    # small sets dominate since |A+A| is the denominator
    cands = []
    for n in range(2, 9):
        for m in range(2, 9):
            for s in range(1, 12):
                for M in range(n, n + 30):
                    cands.append([(0, 1, n), (M, s, m)])
    # interval union scaled interval (scale q)
    for n in range(2, 8):
        for m in range(2, 8):
            for q in range(2, 12):
                for M in range(n, n + 20):
                    cands.append([(0, 1, n), (M, q, m)])
    # three-block
    for n in range(2, 6):
        for m in range(2, 6):
            for k in range(2, 6):
                for s in range(1, 8):
                    for M in range(n, n + 12):
                        cands.append([(0, 1, n), (M, s, m), (M + s * m + 3, s * k, k)])

    for blk in cands:
        if time.time() > deadline:
            break
        A, s = _best_for_blocks(blk)
        if s > best_s:
            best, best_s = A, s

    # local search: perturb the best set by shifting/growing block elements
    import random
    rng = random.Random(7)
    cur = best[:]
    cur_s = best_s
    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.4 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-6, 6)
        elif op < 0.7:
            base = rng.choice(cand)
            cand.append(base + rng.randint(-20, 20))
        elif len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        if max(abs(x) for x in cand) > 10 ** 15:
            continue
        d, s, n = _stats(cand)
        if s < 2:
            continue
        sc = math.log(d) / math.log(s) + (1 - 1 / n) / 100
        if sc >= cur_s:
            cur, cur_s = cand, sc
            if sc > best_s:
                best, best_s = cand[:], sc
        elif rng.random() < 0.05:
            cur, cur_s = best[:], best_s

    return sorted(set(best))
# EVOLVE-BLOCK-END
