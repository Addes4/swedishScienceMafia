# EVOLVE-BLOCK-START
"""Construction maximizing log|A-A|/log|A+A| via a difference-rich, sum-poor set."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _diffs_sums(a):
    return {x - y for x in a for y in a}, {x + y for x in a for y in a}


def solve():
    # Idea: A = integral scaled geometric set gives ~|A|^2 distinct differences.
    # To keep |A+A| small, embed everything on a common lattice with big gaps:
    # take A = { t * b^i } unioned with an interval-like core so sums overlap.
    #
    # Key construction: use A = X + M*Y where X is a Sidon-rich set and
    # M*Y has small sumset after scaling. But the true winner in these
    # problems is A = { base^i * small } giving ~n^2 differences and ~2n sums
    # only if base is huge -> sums are also huge/distinct. So we instead
    # use a "Stanley" style set: an initial interval [0, k) gives 2k-1 sums.
    deadline = time.time() + 100

    best = None
    best_score = -1.0

    # Try several structured seeds, then hill-climb each.
    seeds = []

    # Seed 1: interval [0, n) -- minimal sumset (2n-1), difference set n(n-1)+1.
    # Ratio ~ log(n^2)/log(2n) -> 2 as n grows; bonus favors moderate n here.
    for n in (30, 60, 120, 240, 400):
        seeds.append(list(range(n)))

    # Seed 2: interval plus a few far-out geometric points B*base^j to
    # blow up differences while sums stay near the interval cluster.
    def geo_seed(n, count, base, gap):
        A = list(range(n))
        v = gap
        for j in range(count):
            A.append(v)
            v *= base
        return A

    for n in (20, 40, 80):
        for count in (3, 5, 8):
            for base in (3, 4):
                seeds.append(geo_seed(n, count, base, 1000))

    # Seed 3: symmetric interval [-m, m] to get negative differences too.
    for m in (30, 80, 200):
        seeds.append(list(range(-m, m + 1)))

    random.seed(12345)

    def fast_eval(a):
        return _score(a)

    for seed in seeds:
        A = list(set(seed))
        if len(A) < 2:
            continue
        ds, ss = _diffs_sums(A)
        cur = _score(A)
        if cur > best_score:
            best_score, best = cur, A[:]

        # Simulated annealing / hill climb over add / remove / shift moves.
        local_deadline = time.time() + 6
        T = 0.02
        curA = A[:]
        curDS, curSS = ds, ss
        curSc = cur
        while time.time() < local_deadline and time.time() < deadline:
            T *= 0.999
            move = random.random()
            cand = curA[:]
            if move < 0.4:
                # shift a random element
                i = random.randrange(len(cand))
                cand[i] += random.randint(-50, 50)
            elif move < 0.7:
                # add a new element
                if len(cand) < 4000:
                    cand.append(random.randint(-2000, 2000))
            else:
                # remove an element if big enough
                if len(cand) > 3:
                    i = random.randrange(len(cand))
                    cand.pop(i)
            cand = list(set(cand))
            if len(cand) < 2:
                continue
            s = _score(cand)
            if s >= curSc or random.random() < math.exp((s - curSc) / max(T, 1e-6)):
                curA = cand
                curSc = s
                if s > best_score:
                    best_score, best = s, cand[:]

    if best is None or len(best) < 2:
        best = list(range(100))

    return sorted(set(best))
# EVOLVE-BLOCK-END
