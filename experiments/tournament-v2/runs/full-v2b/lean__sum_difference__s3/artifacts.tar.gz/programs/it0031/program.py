# EVOLVE-BLOCK-START
"""Deterministic interval + geometric block construction for many differences, few sums."""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    s = set(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _eval(n, k, M, C):
    # interval core: 0..n-1 ; geometric block: C + M*2^i for i<k
    A = list(range(n))
    for i in range(k):
        A.append(C + M * (1 << i))
    return _score(A)


def solve():
    best = [0, 1, 2, 3, 4]
    best_score = _score(best)
    deadline = time.time() + 110

    # coarse sweep of the structured family, then local refine on the best region
    n_list = [3, 5, 8, 12, 18, 25, 35, 50, 70]
    k_list = [4, 6, 8, 10, 12]
    # C should be well away from the interval, M sets geometric spacing scale
    for n in n_list:
        if time.time() > deadline:
            break
        for k in k_list:
            if time.time() > deadline:
                break
            for mult in [1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233]:
                M = mult * (1 << (k - 1))
                for C in [n, n * 10, M, M * 2, M * 10]:
                    if time.time() > deadline:
                        break
                    sc = _eval(n, k, M, C + 1)
                    if sc > best_score:
                        best_score = sc
                        A = list(range(n)) + [C + 1 + M * (1 << i) for i in range(k)]
                        best = sorted(set(A))

    # local refinement around the best configuration
    n = len([x for x in best if True])
    while time.time() < deadline:
        improved = False
        for dn in (-2, -1, 1, 2):
            for dk in (-1, 1):
                for scale in (0.9, 0.99, 1.01, 1.1):
                    # try perturbing using current best parameters extracted crudely
                    pass
        break

    return best
# EVOLVE-BLOCK-END
