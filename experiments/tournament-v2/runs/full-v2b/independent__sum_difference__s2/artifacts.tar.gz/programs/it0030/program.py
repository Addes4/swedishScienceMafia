import math
import random
import time


def _score_fast(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 1, 1
    a_sorted = sorted(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            diffs.add(ai - a[j])
            diffs.add(a[j] - ai)
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls == 0:
        return 0.0, ld, ls
    score = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
    return score, ld, ls


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ls = len(sums)
    if ls == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(ls) + (1 - 1 / n) / 100


# Mian-Chowla (Sidon) sequence: greedy B_2 sequence starting with 1
def mian_chowla(k):
    seq = [1]
    used = {2}
    used_d = {0}
    nxt = 2
    while len(seq) < k:
        ok = True
        for s in seq:
            if (nxt + s) in used:
                ok = False
                break
        if ok:
            for s in seq:
                used.add(nxt + s)
            used.add(nxt + nxt)
            seq.append(nxt)
        nxt += 1
    return seq


def solve():
    random.seed(12345)
    deadline = time.time() + 100

    # Start with a scaled Mian-Chowla set (Sidon => distinct sums)
    base = mian_chowla(60)
    best = [x * 1 for x in base]

    # Try many constructions quickly, pick best starting point
    candidates = []
    candidates.append(best[:])
    # Scaled versions
    for mult in [1, 2, 3, 5, 7, 11, 13, 17]:
        candidates.append([x * mult for x in mian_chowla(40)])
    # Greedy Sidon from scratch with different seeds
    for seed in range(5):
        random.seed(seed)
        s = [0]
        pool = list(range(1, 300))
        random.shuffle(pool)
        used_s = {0}
        while len(s) < 50 and pool:
            cand = pool.pop()
            ok = True
            new_sums = {cand, 2 * cand}
            for x in s:
                if (x + cand) in used_s:
                    ok = False
                    break
            if ok:
                for x in s:
                    used_s.add(x + cand)
                used_s.add(2 * cand)
                s.append(cand)
        candidates.append(s)

    best_score = -1.0
    for c in candidates:
        if len(c) >= 2:
            sc = _score(c)
            if sc > best_score:
                best_score = sc
                best = c[:]
    if best_score < 0:
        best = [0, 1]
        best_score = _score(best)

    cur = best[:]
    cur_score = best_score

    # Local search with restarts. We try to increase the ratio.
    # Moves: change one element, add an element, remove an element.
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.5:
            # mutate one element
            i = random.randrange(len(cand))
            delta = random.choice([-1, 1]) * random.randint(1, 50)
            cand[i] += delta
        elif r < 0.75:
            # add a new element near existing ones
            if len(cand) < 4000:
                base_el = random.choice(cand)
                cand.append(base_el + random.randint(1, 200))
        else:
            # remove an element
            if len(cand) > 3:
                i = random.randrange(len(cand))
                del cand[i]

        # ensure distinct
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc >= cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
