import math
import random
import time


def _score_stats(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for j in range(i, n):
            y = a[j]
            diffs.add(x - y)
            diffs.add(y - x)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0, len(diffs), len(sums)


def _score(a):
    return _score_stats(a)[0]


def _greedy_sidon_like(n=4000, span_mod=1000000007):
    # Start from a large arithmetic progression and greedily keep elements
    # while trying to limit the number of distinct sums.
    if n <= 0:
        return []
    # A balanced candidate pool. The actual set size is capped by n.
    pool_size = min(20000, max(n * 4, 1000))
    pool = list(range(1, pool_size + 1))
    random.shuffle(pool)
    chosen = []
    sum_set = set()
    diff_set = set()
    for x in pool:
        if len(chosen) >= n:
            break
        new_sums = {x + y for y in chosen}
        new_sums.add(2 * x)
        new_diffs = {x - y for y in chosen}
        new_diffs.update({y - x for y in chosen})
        new_diffs.add(0)
        if not chosen:
            chosen.append(x)
            sum_set.add(2 * x)
            diff_set.add(0)
            continue
        # Prefer elements that add relatively few new sums compared with new differences.
        ds = len(new_diffs - diff_set)
        ss = len(new_sums - sum_set)
        if ss == 0:
            ss = 1
        if random.random() < 0.92:
            if ds * 1.0 / ss >= 0.75:
                chosen.append(x)
                sum_set |= new_sums
                diff_set |= new_diffs
        else:
            chosen.append(x)
            sum_set |= new_sums
            diff_set |= new_diffs
    return chosen


def _local_search(seed, deadline):
    best = seed[:]
    best_score = _score(best)
    cur = best[:]
    n = len(cur)
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        mode = random.random()
        if mode < 0.55 and cand:
            # Perturb one element.
            i = random.randrange(len(cand))
            cand[i] += random.choice([-3, -2, -1, 1, 2, 3, -5, 5, -10, 10])
        elif mode < 0.75 and len(cand) < 4000:
            # Insert a nearby new element.
            base = random.choice(cand)
            cand.append(base + random.randint(1, 50))
        elif mode < 0.9 and len(cand) > 2:
            # Remove a random element.
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # Swap: remove one and add another.
            if len(cand) > 2:
                i = random.randrange(len(cand))
                cand.pop(i)
            if len(cand) < 4000:
                base = random.choice(cand) if cand else 0
                cand.append(base + random.randint(1, 100))

        cand = sorted(set(cand))
        if len(cand) < 2:
            cur = best[:]
            continue
        if len(cand) > 4000:
            cand = cand[:4000]
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.08:
            cur = best[:]
        else:
            cur = cand
    return best


def _construct_shifted_blocks():
    # Build a set as a union of a small number of shifted small Sidon-like sets.
    # This often gives a strong tradeoff between differences and sums.
    random.seed(12345)
    base_sizes = [31, 47, 61, 79, 101, 127, 151, 179, 211, 251]
    blocks = []
    offset = 0
    for sz in base_sizes:
        # Greedy Sidon construction via powers or intervals.
        b = []
        s = set()
        d = set()
        x = offset + 1
        limit = offset + sz * 30
        while len(b) < sz and x <= limit:
            ok = True
            for y in b:
                a1 = x + y
                a2 = x - y
                a3 = y - x
                if a1 in s or a2 in d or a3 in d:
                    ok = False
                    break
            if ok or len(b) < sz // 3:
                b.append(x)
                for y in b:
                    s.add(x + y)
                    d.add(x - y)
                    d.add(y - x)
            x += 1
        blocks.extend(b)
        offset = max(b) + random.randint(100, 1000)
    return blocks


def solve():
    deadline = time.time() + 116
    seeds = []

    # Seed 1: arithmetic-like / greedy Sidon-like set.
    seeds.append(_greedy_sidon_like(4000))

    # Seed 2: shifted-block construction.
    sb = _construct_shifted_blocks()
    if len(sb) > 4000:
        sb = sb[:4000]
    seeds.append(sb)

    # Seed 3: simple powers of 2 scaled down to avoid huge integers where possible,
    # then trimmed. Powers of 2 maximize differences but sums are also large;
    # use differences of nearby powers for a better ratio.
    p = []
    x = 1
    for i in range(4000):
        p.append(x)
        x += max(1, (i % 7) + 1)
    seeds.append(p)

    # Seed 4: random sparse set.
    random.seed(999)
    rs = sorted(random.sample(range(1, 200000), 4000))
    seeds.append(rs)

    # Score seeds.
    scored = []
    for s in seeds:
        s = sorted(set(s))[:4000]
        if len(s) >= 2:
            sc, nd, ns = _score_stats(s)
            scored.append((sc, s, nd, ns))
    scored.sort(reverse=True, key=lambda t: t[0])

    best = scored[0][1][:]
    best_score = scored[0][0]

    # Run local searches from top seeds, interleaved until deadline.
    tries = 0
    while time.time() < deadline:
        if tries < len(scored):
            seed = scored[tries][1]
        else:
            seed = best[:]
        rem = max(1.0, deadline - time.time())
        cand = _local_search(seed, time.time() + min(20.0, rem * 0.35))
        cand = sorted(set(cand))[:4000]
        if len(cand) >= 2:
            sc = _score(cand)
            if sc > best_score:
                best, best_score = cand[:], sc
        tries += 1

        # Occasionally restart from a fresh random/greedy construction.
        if tries % 4 == 0 and time.time() < deadline - 10:
            rg = _greedy_sidon_like(4000)
            cand = _local_search(rg, time.time() + min(15.0, deadline - time.time()))
            cand = sorted(set(cand))[:4000]
            if len(cand) >= 2:
                sc = _score(cand)
                if sc > best_score:
                    best, best_score = cand[:], sc

    # Ensure all integers are distinct and within bounds.
    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return best
