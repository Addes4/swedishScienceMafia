import math
import random
import time


def _score_parts(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            if i <= j:
                sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        return 0.0, ld, ls
    sc = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
    return sc, ld, ls


def _score(a):
    return _score_parts(a)[0]


def _try_ap(base, step, n, jitter_frac, rng, swaps):
    a = [base + i * step for i in range(n)]
    k = max(1, int(n * jitter_frac))
    idxs = rng.sample(range(n), min(k, n))
    for i in idxs:
        a[i] += rng.randint(-swaps, swaps) * step + rng.randint(-swaps, swaps)
    return sorted(set(a))


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 100

    best = None
    best_score = -1.0

    # Try many arithmetic progressions with perturbed elements
    configs = []
    for n in [10, 15, 20, 30, 40, 60, 80, 120, 160, 200]:
        configs.append((0, 1, n, 0.0, 0))
        for jf in [0.05, 0.1, 0.2, 0.3, 0.5]:
            for sw in [1, 2, 3, 5]:
                configs.append((0, 1, n, jf, sw))

    # Shuffle configs for diversity
    rng.shuffle(configs)

    for (base, step, n, jf, sw) in configs:
        if time.time() > deadline:
            break
        a = _try_ap(base, step, n, jf, sw, rng)
        sc = _score(a)
        if sc > best_score:
            best_score = sc
            best = a[:]

    # Also try APs with widely spaced outliers mixed in
    for n in [20, 40, 60, 100]:
        if time.time() > deadline:
            break
        for extra in range(0, 5):
            a = [i for i in range(n)]
            for e in range(extra):
                a.append(rng.randint(n + 1, n * 3))
            a = sorted(set(a))
            sc = _score(a)
            if sc > best_score:
                best_score = sc
                best = a[:]

    # Local search from the best found
    cur = best[:]
    cur_score = best_score
    step_limit = max(1, len(cur) // 20)

    while time.time() < deadline:
        cand = cur[:]
        choice = rng.random()
        if choice < 0.6 and len(cand) > 1:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-step_limit, step_limit)
        elif choice < 0.8:
            # add an element near the range
            lo, hi = min(cand), max(cand)
            cand.append(rng.randint(lo, hi))
        elif len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        else:
            continue
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        sc = _score(cand)
        if sc > cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = cand[:]
        elif rng.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best)) if best else [7, 15, 18, 22, -3, -2]
