import math
import random
import time


def _score_set(a_set):
    a = list(a_set)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls == 0 or ld == 0:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    deadline = time.time() + 115

    # Start with powers of 2: differences are all distinct (|A-A| = n^2-n+1),
    # while sums collide a lot (sum of two distinct powers is unique but
    # diagonal terms 2*2^k are also unique, still sum set is ~ n^2/2).
    n0 = 14
    base = [1 << k for k in range(n0)]

    best = base[:]
    best_score = _score_set(set(best))

    # Also try a few shifted / scaled variants of powers of two and combined sets.
    candidates = []
    candidates.append([1 << k for k in range(n0)])
    candidates.append([(1 << k) - 1 for k in range(n0)])
    candidates.append([(1 << k) + k for k in range(n0)])
    # Set of form {2^i + small offset}
    random.seed(12345)

    for c in candidates:
        s = _score_set(set(c))
        if s > best_score:
            best, best_score = c[:], s

    cur = best[:]

    # Simulated-annealing style local search using incremental-ish scoring.
    # Cache the score using sets each time (n is small).
    def score(a):
        return _score_set(set(a))

    temp = 0.02
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6:
            # perturb one element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif op < 0.8 and len(cand) < 60:
            # add new element
            cand.append(random.randint(-(1 << n0), (1 << n0)))
        elif op < 0.9 and len(cand) > 4:
            # remove element
            del cand[random.randrange(len(cand))]
        else:
            # shift all elements
            d = random.randint(-10, 10)
            cand = [x + d for x in cand]

        cand = list(set(cand))
        if len(cand) < 3:
            continue

        s = score(cand)
        ds = s - best_score
        if s > best_score:
            best, best_score, cur = cand[:], s, cand
        else:
            # accept with some probability
            if random.random() < math.exp(ds / max(temp, 1e-9)):
                cur = cand
            else:
                if random.random() < 0.05:
                    cur = best[:]
        temp *= 0.99995
        if temp < 1e-4:
            temp = 1e-3

    return sorted(set(best))
