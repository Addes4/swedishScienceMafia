import math
import random
import time


def _counts(A):
    s = list(set(A))
    n = len(s)
    ds = set()
    ss = set()
    for i in range(n):
        xi = s[i]
        for j in range(n):
            ds.add(xi - s[j])
            ss.add(xi + s[j])
    return len(ds), len(ss)


def _score(A):
    if len(A) < 2:
        return -1e18
    d, su = _counts(A)
    if su < 1 or d < 1:
        return -1e18
    return math.log(d) / math.log(su) + (1 - 1.0 / len(A)) / 100.0


def solve():
    random.seed(1234567)
    deadline = time.time() + 112.0

    best = None
    bestsc = -1e18

    def consider(A):
        nonlocal best, bestsc
        A = list(set(A))
        if len(A) < 2:
            return
        sc = _score(A)
        if sc > bestsc:
            bestsc = sc
            best = sorted(A)

    # Seed with geometric / Sidon-like constructions and other ideas.
    seeds = [
        [0, 1, 3, 7, 15, 31],
        [0, 1, 3, 7, 15, 31, 63],
        [0, 1, 3, 7, 15, 31, 63, 127],
        [0, 1, 3, 7, 15],
        [0, 1, 3, 7],
        [0, 1, 2, 4, 8, 16],
        [0, 1, 2, 4, 8, 16, 32],
        [0, 1, 3, 4, 9, 13, 27],
        [0, 1, 2, 3, 7, 15],
        [0, 1, 2, 4, 8, 15, 31],
        [1, 2, 3, 5, 8, 13, 21],
        [0, 1, 4, 9, 16, 25],
        [0, 1, 2, 3],
        [0, 1, 2, 4, 7, 13, 24],
        [0, 2, 3, 7, 15, 31],
    ]
    for s in seeds:
        consider(s)

    for _ in range(500):
        n = random.randint(3, 10)
        consider([random.randint(-30, 30) for _ in range(n)])

    maxN = 45

    while time.time() < deadline:
        if random.random() < 0.75 and best is not None:
            cur = best[:]
        else:
            cur = [random.randint(-25, 25) for _ in range(random.randint(4, 9))]
        cur = list(set(cur))
        if len(cur) < 2:
            continue
        cursc = _score(cur)
        localbest = cursc
        localA = cur[:]
        steps = 0
        maxsteps = 3500
        while time.time() < deadline and steps < maxsteps:
            steps += 1
            T = 0.02 * max(0.01, (1.0 - steps / maxsteps))
            cand = cur[:]
            r = random.random()
            if r < 0.55 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.choice(
                    [-11, -7, -5, -3, -2, -1, 1, 2, 3, 5, 7, 11, 16, 24, 32]
                )
            elif r < 0.8 and len(cand) < maxN:
                cand.append(random.randint(-70, 70))
            elif r < 0.95 and len(cand) > 3:
                del cand[random.randrange(len(cand))]
            else:
                if cand:
                    i = random.randrange(len(cand))
                    cand[i] = random.randint(-70, 70)
            cand = list(set(cand))
            if len(cand) < 2:
                continue
            cs = _score(cand)
            if cs >= cursc or random.random() < math.exp((cs - cursc) / max(T, 1e-9)):
                cur, cursc = cand, cs
                if cs > localbest:
                    localbest = cs
                    localA = cand[:]
        consider(localA)

    # Local polish of the best set.
    if best is not None:
        A = best[:]
        improved = True
        while improved and time.time() < deadline + 6.0:
            improved = False
            bs = _score(A)
            # Single-coordinate shifts.
            for i in range(len(A)):
                for d in (-13, -8, -5, -3, -2, -1, 1, 2, 3, 5, 8, 13):
                    B = A[:]
                    B[i] += d
                    if len(set(B)) < len(B):
                        continue
                    sc = _score(B)
                    if sc > bs:
                        A, bs, improved = B, sc, True
            # Insertions.
            if len(A) < maxN:
                trial_vals = set()
                for x in A:
                    for d in (-16, -13, -8, -5, -3, -2, -1, 1, 2, 3, 5, 8, 13, 16):
                        trial_vals.add(x + d)
                for v in list(trial_vals):
                    if v in A:
                        continue
                    B = A + [v]
                    sc = _score(B)
                    if sc > bs:
                        A, bs, improved = B, sc, True
            # Deletions.
            if len(A) > 3:
                for i in range(len(A)):
                    B = A[:i] + A[i + 1:]
                    sc = _score(B)
                    if sc > bs:
                        A, bs, improved = B, sc, True
        consider(A)

    return best if best is not None else [0, 1, 3, 7, 15, 31]
