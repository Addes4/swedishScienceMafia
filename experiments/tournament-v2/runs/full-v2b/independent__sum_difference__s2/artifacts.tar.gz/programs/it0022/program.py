import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = math.log(len(diffs))
    ls = math.log(len(sums))
    if ls == 0:
        return 0.0
    return ld / ls + (1.0 - 1.0 / n) / 100.0

def _geometric(n, base=2):
    return [base ** i for i in range(n)]

def solve():
    random.seed(42)
    best_set = None
    best_score = -1.0

    # Evaluate geometric progressions for various sizes
    for n in range(2, 31):
        a = _geometric(n, 2)
        s = _score(a)
        if s > best_score:
            best_score = s
            best_set = a[:]
        a3 = _geometric(n, 3)
        s3 = _score(a3)
        if s3 > best_score:
            best_score = s3
            best_set = a3[:]

    # Simulated annealing
    cur = best_set[:]
    cur_score = best_score
    T = 0.1
    deadline = time.time() + 120.0
    iteration = 0

    while time.time() < deadline:
        iteration += 1
        # Cooling
        T = 0.1 * (0.9999 ** iteration)

        cand = cur[:]
        r = random.random()
        if r < 0.45:
            # Mutate one element
            if len(cand) > 0:
                idx = random.randrange(len(cand))
                delta = random.randint(-5, 5)
                if delta == 0:
                    delta = 1
                cand[idx] += delta
        elif r < 0.75:
            # Add an element
            if len(cand) < 200:
                base_val = random.choice(cand) if cand else 0
                cand.append(base_val + random.randint(-20, 20))
        else:
            # Remove an element
            if len(cand) > 3:
                idx = random.randrange(len(cand))
                cand.pop(idx)

        # Deduplicate
        cand = list(set(cand))
        if len(cand) < 3:
            continue

        s = _score(cand)
        delta = s - cur_score
        if delta >= 0 or random.random() < math.exp(delta / T):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best_set = cand[:]

    # Return best found
    if best_set is None:
        best_set = _geometric(7)
    return sorted(best_set)
