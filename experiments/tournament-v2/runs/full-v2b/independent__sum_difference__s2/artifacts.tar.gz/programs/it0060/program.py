import math
import random
import time


def _score_parts(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return 0.0, len(diffs), len(sums)


def _score(a):
    _, d, s = _score_parts(a)
    if s == 0:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(set(a))) / 100


def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1e18

    # Candidate constructions.
    def consider(a):
        nonlocal best, best_score
        a = sorted(set(int(x) for x in a))
        if len(a) < 2:
            return
        sc = _score(a)
        if sc > best_score:
            best_score = sc
            best = a[:]

    # 1) Pure Sidon-like / Golomb ruler via greedy: maximize distinct differences.
    # Use scaled powers / greedy ruler then reverse role: we want many dist diffs.
    def greedy_sidon(n, limit=10**9):
        a = [0, 1]
        used = {0, 1, -1}
        vals = list(range(-limit, limit + 1))
        # instead do bounded greedy
        cur = [0]
        for _ in range(n - 1):
            bestv = None
            bestnew = -1
            tried = set()
            # try candidates around a growing range
            span = max(abs(x) for x in cur) if cur else 0
            for _ in range(40):
                v = random.randint(-10**12, 10**12)
                if v in cur:
                    continue
                newd = 0
                dd = set()
                for x in cur:
                    dd.add(v - x)
                    dd.add(x - v)
                newd = len(dd)
                if newd > bestnew:
                    bestnew = newd
                    bestv = v
            cur.append(bestv)
        return cur

    # 2) Key idea: use sets with multiplicative/additive collision structure.
    # Set A = { i : i in S } where S is Sidon: |A+A| ~ |A|^2 but we want collisions.
    # Try A = base set with translations: A = B + {0, M, 2M, ...} creates difference separation
    # but sums still collide within each block.

    # Strong construction: A = union of intervals placed very far apart.
    # Differences between far blocks are all distinct-ish, sums within blocks collapse.
    def block_set(blocks, gap):
        a = []
        offset = 0
        for (start, size) in blocks:
            for i in range(size):
                a.append(offset + start + i)
            offset += gap
        return a

    # Explore block constructions.
    for _ in range(200):
        nb = random.randint(2, 60)
        gap = random.randint(1, 10**9)
        blocks = []
        for _ in range(nb):
            st = random.randint(-5, 5)
            sz = random.randint(1, 30)
            blocks.append((st, sz))
        a = block_set(blocks, gap)
        if len(a) <= 4000:
            consider(a)

    # 3) Arithmetic-progression-based: A = { i * d + r_i }, r_i small perturbations
    # so sums collide a lot if r structure is additive closed.
    for _ in range(300):
        n = random.randint(5, 300)
        base = [random.randint(-10**9, 10**9) for _ in range(n)]
        consider(base)

    # 4) Set with small sumset: A = arithmetic progression (sumset small)
    # But differences are also small -> bad. Mix AP with far odd-shift copies.
    for _ in range(300):
        m = random.randint(2, 200)
        k = random.randint(2, 20)
        d = random.randint(1, 10**6)
        a = []
        for j in range(k):
            off = random.randint(-10**12, 10**12)
            for i in range(m):
                a.append(off + i * d)
        if len(a) <= 4000:
            consider(a)

    # 5) Local search / simulated annealing using two metrics.
    def local_refine(a0, tlimit):
        a = sorted(set(a0))
        cur_score = _score(a)
        end = time.time() + tlimit
        step = max(1, (max(a) - min(a)) // 1000 if len(a) > 1 else 1)
        while time.time() < end:
            cand = a[:]
            op = random.random()
            if op < 0.6 and len(cand) > 2:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-step, step)
            elif op < 0.8 and len(cand) < 4000:
                cand.append(cand[random.randrange(len(cand))] + random.randint(-step, step))
            else:
                if len(cand) > 2:
                    cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            sc = _score(cand)
            if sc >= cur_score or random.random() < 0.02:
                a = cand
                cur_score = sc
        return a

    # Base good candidates: block sets refined.
    seed_cands = []
    for _ in range(20):
        nb = random.randint(5, 40)
        gap = random.choice([10**3, 10**6, 10**9, 10**12])
        blocks = []
        for _ in range(nb):
            st = random.randint(-3, 3)
            sz = random.randint(3, 40)
            blocks.append((st, sz))
        a = block_set(blocks, gap)
        if len(a) <= 4000:
            seed_cands.append(a)

    # Add scaled greedy sidon small
    for n in [8, 12, 16, 20]:
        try:
            seed_cands.append(greedy_sidon(n, 10**6))
        except Exception:
            pass

    for a0 in seed_cands:
        if time.time() > deadline:
            break
        rem = min(10.0, max(1.0, deadline - time.time()))
        a = local_refine(a0, rem)
        consider(a)

    # Final refinement on best with longer time.
    if best is not None and time.time() < deadline:
        rem = min(40.0, deadline - time.time())
        if rem > 0.5:
            a = local_refine(best, rem)
            consider(a)

    if best is None:
        best = [0, 1]
    return sorted(set(best))
