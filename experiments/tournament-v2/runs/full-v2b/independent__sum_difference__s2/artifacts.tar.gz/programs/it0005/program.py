import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _full_stats(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(a), len(diffs), len(sums)


def _candidate_from_moduli(limit_n, bound, seed):
    rng = random.Random(seed)
    # Build a set with many distinct differences and repeated sums by using
    # a near-arithmetic structure plus a geometric perturbation layer.
    base = []
    # Core arithmetic progression gives many repeated sums.
    step = 1
    m = min(180, max(20, limit_n // 10))
    for i in range(m):
        base.append(i * step)
    # Add carefully chosen shifts to increase difference collisions/variety.
    extra = []
    t = 1
    while len(base) + len(extra) < limit_n and t < 3000:
        v = (t * t + 3 * t + 1) % (2 * bound + 1) - bound
        if v not in base and v not in extra:
            extra.append(v)
        t += 1
        if t % 17 == 0:
            extra.append(rng.randint(-bound, bound))
    cand = list(set(base + extra))
    cand.sort()
    return cand[:limit_n]


def _local_improve(cand, deadline):
    cand = list(set(cand))
    if len(cand) < 2:
        return cand
    best = cand[:]
    best_sc = _score(best)
    n = len(best)
    # exact-ish search but skip full recomputation too often for large n
    while time.time() < deadline:
        improved = False
        # Try a few random single-point and pair mutations.
        for _ in range(80):
            mode = random.randrange(5)
            newc = best[:]
            if mode == 0 and newc:
                i = random.randrange(len(newc))
                newc[i] += random.randint(-25, 25)
            elif mode == 1 and newc:
                i = random.randrange(len(newc))
                newc[i] += random.choice([-1, 1, -2, 2, -3, 3, -5, 5, -10, 10])
            elif mode == 2 and len(newc) < 4000:
                newc.append(random.randint(-1000000, 1000000))
            elif mode == 3 and len(newc) > 2:
                i = random.randrange(len(newc))
                del newc[i]
            else:
                if len(newc) >= 2:
                    i = random.randrange(len(newc))
                    j = random.randrange(len(newc))
                    if i != j:
                        newc[i], newc[j] = newc[j], newc[i]
            newc = sorted(set(newc))
            if len(newc) < 2:
                continue
            sc = _score(newc)
            if sc > best_sc:
                best, best_sc = newc, sc
                improved = True
                break
        if not improved:
            # Refresh with a moderate perturbation.
            if len(best) >= 3:
                kick = best[:]
                for _ in range(max(1, len(kick) // 50)):
                    i = random.randrange(len(kick))
                    kick[i] += random.randint(-100, 100)
                kick = sorted(set(kick))
                sc = _score(kick)
                if sc > best_sc:
                    best, best_sc = kick, sc
                    continue
            break
    return best


def solve():
    random.seed(123456789)
    deadline = time.time() + 115.0
    bound = 10**15

    # Try several structured seeds; keep the best.
    best = None
    best_sc = -1.0

    seeds = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
    sizes = [500, 1000, 2000, 3000, 4000]

    for sz in sizes:
        for seed in seeds:
            if time.time() > deadline - 2:
                break
            cand = _candidate_from_moduli(sz, bound, seed)
            cand = _local_improve(cand, min(time.time() + 10.0, deadline - 0.5))
            sc = _score(cand)
            if sc > best_sc:
                best, best_sc = cand[:], sc

    # Direct greedy expansion from a strong small set.
    base = [0, 1, 3, 7, 12, 20, 30, 44, 65]
    if best is not None:
        base = best[:]
    cur = sorted(set(base))
    cur_sc = _score(cur)

    while time.time() < deadline - 0.2:
        cands = []
        active = cur
        if len(active) < 4000:
            # Add values around the current range to preserve sum collisions.
            mn = min(active)
            mx = max(active)
            span = max(1, mx - mn)
            for _ in range(40):
                v = random.randint(mn - span, mx + span)
                cands.append(sorted(set(active + [v])))
            for _ in range(40):
                v = random.randint(-bound, bound)
                cands.append(sorted(set(active + [v])))
        # Mutations.
        for _ in range(80):
            newc = active[:]
            if not newc:
                continue
            i = random.randrange(len(newc))
            newc[i] += random.randint(-10, 10)
            cands.append(sorted(set(newc)))
        for _ in range(40):
            newc = active[:]
            if len(newc) >= 2:
                i = random.randrange(len(newc))
                j = random.randrange(len(newc))
                if i != j:
                    newc[i] -= 1
                    newc[j] += 1
            cands.append(sorted(set(newc)))
        for newc in cands:
            if len(newc) < 2:
                continue
            sc = _score(newc)
            if sc > cur_sc:
                cur, cur_sc = newc, sc
                if sc > best_sc:
                    best, best_sc = newc[:], sc
                break
        else:
            # No improvement: restart from best with a big jump occasionally.
            if best is not None and random.random() < 0.3:
                cur = best[:]
                for _ in range(random.randint(1, 10)):
                    if cur:
                        i = random.randrange(len(cur))
                        cur[i] += random.randint(-1000, 1000)
                cur = sorted(set(cur))
                cur_sc = _score(cur)
            else:
                break

    if best is None:
        best = [0, 1, 2, 4, 7]
    best = sorted(set(best))
    if len(best) > 4000:
        # Keep the subset with the best score if too large.
        best = best[:4000]
    return best
