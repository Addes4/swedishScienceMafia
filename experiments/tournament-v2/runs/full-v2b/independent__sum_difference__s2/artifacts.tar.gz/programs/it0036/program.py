import math
import random
import time


def _score_exact(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    """
    Construct a set with large difference set and small sum set.

    Strategy: use a modular Sidon-type construction over Z_m packed into
    a narrow integer range, then take A as a scaled/perturbed copy.

    A classic strong family: A = { i*M + r_i } where r_i forms a
    Golomb ruler / Sidon sequence. Differences become ~ |A|^2 distinct
    across the block structure, while sums stay within a bounded span.

    We combine:
      1. A base Sidon set (Bose-Chowla) in Z_q^2-1.
      2. Block decomposition i*M + r_i to force many distinct differences.

    Constraints: |A| <= 4000, |entries| <= 1e15.
    Runtime budget: up to 120s (we use well under).
    """
    random.seed(12345)

    # ---------------------------------------------------------------
    # Primary attempt: Bose-Chowla Sidon set construction.
    #
    # For prime power q, let theta be primitive in GF(q^2).
    # B = { a in Z_{q^2-1} : theta^a - theta in GF(q) } is Sidon.
    # |B| = q.
    #
    # We use a finite field via integers for small prime powers,
    # choosing q around 2000-4000.
    # ---------------------------------------------------------------

    def is_prime(n):
        if n < 2:
            return False
        if n % 2 == 0:
            return n == 2
        d = 3
        while d * d <= n:
            if n % d == 0:
                return False
            d += 2
        return True

    def prime_power_le(limit):
        # largest prime power <= limit for Bose-Chowla (need GF(q^2));
        # but implementing full GF arithmetic is complex, so we
        # simulate with a simpler Sidon family instead.
        best = 2
        for q in range(2, limit + 1):
            if is_prime(q):
                best = q
        return best

    # ---------------------------------------------------------------
    # Simpler robust approach: build a "difference-dense" set directly.
    #
    # Key inequality: |A-A| <= |A|^2, |A+A| >= 2|A|-1.
    # Perfect difference sets (Singer) achieve |A-A| near |A|^2
    # while sums remain O(|A| * range).
    #
    # We use a Singer-type / B_h set built greedily to maximize
    # distinct differences while keeping max element small.
    # ---------------------------------------------------------------

    # Build a Sidon set greedily in [0, R] (Sidon => all pairwise
    # sums distinct, hence all differences mostly distinct).
    # Sidon: a+b=c+d => {a,b}={c,d} (in reals).
    # This gives |A-A| = n^2 - n + 1 (max possible for Sidon).
    # But sums are 2n-1 values only if arithmetic... no, Sidon
    # means sums are distinct: |A+A| = n(n+1)/2. That's BAD for ratio.
    #
    # So we want the opposite: few DISTINCT SUMS. That means many
    # coincidences in sums, i.e., structure like arithmetic progression,
    # which gives few sums but ALSO few differences.
    #
    # The ratio log|D| / log|S|: for AP of size n, |D|=2n-1, |S|=2n-1,
    # ratio ~ 1. We want ratio > 1.
    #
    # Classic example: {0,1,3} differences {0,±1,±2,±3} =7, sums
    # {0,1,2,3,4,6} = 6. ratio log7/log6 ~ 1.086.
    #
    # Known high-ratio sets come from difference bases / perfect
    # difference families. Let's search computationally.
    # ---------------------------------------------------------------

    # Start from a known good small base and extend by block copy.
    # Base: {0,1,3,7,12} -- check.
    candidates = [
        [0, 1, 3, 7, 12],
        [0, 1, 3, 7, 15, 31],
        [0, 1, 4, 9, 15, 22, 26],
        [0, 1, 3, 7, 12, 20, 30, 44],
    ]

    def build_block(base, blocks, label_offset):
        """
        Take base set B and replicate across blocks with large gaps.
        A = union_{k=0}^{blocks-1} (B + k*M)
        Differences within/across copies become distinct due to
        large M; sums get many collisions within copies.
        """
        M = label_offset
        A = []
        for k in range(blocks):
            for b in base:
                A.append(b + k * M)
        return A

    # But block replication multiplies both. Let's just do a strong
    # stochastic search with a good heuristic: maximize diffs, minimize sums.

    def local_score(a):
        a = list(set(a))
        n = len(a)
        if n < 2:
            return -1e18
        # Use sorted-merge for speed on diffs (too slow for big n).
        # For moderate n (<= 300) direct is fine.
        diffs = set()
        sums = set()
        for i in range(n):
            ai = a[i]
            for j in range(i, n):
                aj = a[j]
                sums.add(ai + aj)
                diffs.add(ai - aj)
                diffs.add(aj - ai)
        nd = len(diffs)
        ns = len(sums)
        if ns == 0:
            return -1e18
        return math.log(nd) / math.log(ns)

    def full_score(a):
        return local_score(a) + (1 - 1 / max(1, len(set(a)))) / 100

    best = None
    best_s = -1e18

    deadline = time.time() + 110

    # Seed with candidates
    for c in candidates:
        s = full_score(c)
        if s > best_s:
            best_s = s
            best = c[:]

    # ------------------------------------------------
    # Structured search: parameterized by a base set
    # grown using "add element at position maximizing diffs while
    # keeping sums small".
    # ------------------------------------------------

    # Heuristic: start from {0}, repeatedly add x that maximizes
    # (new diffs) / (new sums contribution delta), i.e., new diffs
    # are many but new sums overlap existing.
    def grow_set(target_n, seed_val=0):
        A = [0, 1, 3]  # good small start
        # Normalize distinct
        A = sorted(set(A))
        while len(A) < target_n:
            cur_diffs = set()
            cur_sums = set()
            for i in range(len(A)):
                for j in range(len(A)):
                    cur_diffs.add(A[i] - A[j])
                    cur_sums.add(A[i] + A[j])
            nd0 = len(cur_diffs)
            ns0 = len(cur_sums)
            best_add = None
            best_gain = -1e18
            # candidate positions
            lo = min(A)
            hi = max(A)
            span = hi - lo
            cands = set()
            for a in A:
                cands.add(a + span // 2 + 1)
                cands.add(a + span + 1)
                cands.add(a - span - 1)
                cands.add(a + 1)
                cands.add(a - 1)
            # also random
            for _ in range(50):
                cands.add(random.randint(lo - 3 * span - 5, hi + 3 * span + 5))
            for x in cands:
                if x in A:
                    continue
                A2 = A + [x]
                nd = set()
                ns = set()
                for i in range(len(A2)):
                    for j in range(len(A2)):
                        nd.add(A2[i] - A2[j])
                        ns.add(A2[i] + A2[j])
                ndn = len(nd)
                nsn = len(ns)
                if nsn == 0:
                    continue
                # gain = increase in log-ratio
                g = math.log(ndn) / math.log(nsn) - math.log(nd0) / math.log(ns0)
                if g > best_gain:
                    best_gain = g
                    best_add = x
            if best_add is None:
                break
            A.append(best_add)
            A = sorted(set(A))
        return A

    # Try growing to moderate sizes
    for target in [8, 12, 16, 20, 25, 30]:
        if time.time() > deadline:
            break
        A = grow_set(target)
        s = full_score(A)
        if s > best_s:
            best_s = s
            best = A[:]

    # ------------------------------------------------
    # Scaling trick: multiply best set by factor to reduce
    # sum collisions? No -- scaling is affine, preserves ratios
    # exactly (diffs and sums scale). So no gain.
    #
    # Translation also preserves everything.
    # ------------------------------------------------

    # ------------------------------------------------
    # Random perturbation local search around best.
    # ------------------------------------------------
    if best is None:
        best = [0, 1, 3]

    cur = best[:]
    cur_s = best_s
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5 and cand:
            i = random.randrange(len(cand))
            delta = random.randint(-5, 5)
            cand[i] += delta
        elif op < 0.75:
            cand.append(random.randint(min(cur) - 10, max(cur) + 10))
        elif op < 0.9 and len(cand) > 3:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # big move: shift an element far
            if cand:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-1, 1]) * random.randint(1, 50)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = full_score(cand)
        if s > cur_s:
            cur = cand
            cur_s = s
            if s > best_s:
                best = cand[:]
                best_s = s
        elif random.random() < 0.05:
            cur = cand
            cur_s = s

    best = sorted(set(best))

    # Enforce constraints
    if len(best) > 4000:
        best = best[:4000]
    best = [x for x in best if abs(x) <= 10**15]
    if len(best) < 2:
        best = [0, 1]

    return best
