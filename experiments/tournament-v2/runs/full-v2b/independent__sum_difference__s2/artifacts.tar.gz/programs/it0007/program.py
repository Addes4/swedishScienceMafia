import math
import random
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls < 2 or ld < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _greedy_sidonlike(n, seed):
    rnd = random.Random(seed)
    # Build set with small sumset by using many powers/structure but
    # start from a Sidon-ish / perfect difference set, then add near-duplicates
    # in a way that sums collide more than differences.
    # A strong practical heuristic: take union of two translated APs with
    # coprime-ish steps so sums overlap a lot.
    base = [0]
    used = {0}
    step = 1
    while len(base) < n:
        # try to add x maximizing (sum collisions) while maintaining distinctness
        best_x = None
        best_val = None
        for _ in range(40):
            x = rnd.randint(-200, 200)
            if x in used:
                continue
            # sum collisions with existing (small sums preferred)
            sc = 0
            ss = set()
            for y in base:
                ss.add(x + y)
            # count collisions induced
            prev = set()
            for y in base:
                for z in base:
                    prev.add(y + z)
            inter = len(ss & prev)
            # diff spread
            nd = set()
            for y in base:
                nd.add(x - y)
                nd.add(y - x)
            val = inter * 10 - len(nd)
            if best_val is None or val > best_val:
                best_val = val
                best_x = x
        if best_x is None:
            best_x = max(used) + 1
        base.append(best_x)
        used.add(best_x)
    return base


def solve():
    deadline = time.time() + 115

    # Candidate constructions
    candidates = []

    # 1) Dense-ish block: small range => many sum collisions
    for n in (30, 40, 50, 60):
        a = list(range(-n // 2, n - n // 2))
        candidates.append(a)

    # 2) Stretched APs with collisions
    for k in (2, 3):
        a = []
        for i in range(20):
            for t in range(k):
                a.append(i * 4 + t * 1)
        candidates.append(list(set(a)))

    # 3) Random perturbations of a block
    rnd = random.Random(12345)
    baseblock = list(range(-15, 15))
    for _ in range(20):
        a = baseblock[:]
        for i in range(len(a)):
            if rnd.random() < 0.3:
                a[i] += rnd.randint(-3, 3)
        candidates.append(list(set(a)))

    best = None
    best_score = -1.0
    for a in candidates:
        if len(a) < 2:
            continue
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    if best is None:
        best = [0, 1]

    # Local search
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.7 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-2, 2)
        elif r < 0.9:
            cand.append(random.randint(-200, 200))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    return sorted(set(int(x) for x in best))
