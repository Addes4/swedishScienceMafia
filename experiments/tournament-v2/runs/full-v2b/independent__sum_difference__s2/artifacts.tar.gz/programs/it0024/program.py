import math
import random
import time

def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0

def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) == 0:
        return 0.0, len(diffs), len(sums)
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0, len(diffs), len(sums)

def solve():
    random.seed(1234567)
    deadline = time.time() + 110.0

    # Candidate sets from several structured families.
    candidates = []

    # Powers of 2 have huge differences and sums, not great ratio, but good local start.
    for k in range(5, 13):
        candidates.append([2 ** i for i in range(k)])

    # Arithmetic progressions have small sums and differences relative to n.
    for k in range(10, 80):
        candidates.append(list(range(k)))

    # Random subsets of a small interval: often decent for moderate n.
    for n in range(8, 60):
        for _ in range(30):
            vals = random.sample(range(-2 * n, 2 * n + 1), n)
            candidates.append(vals)

    # Sets close to a geometric progression with slight perturbation.
    for n in range(8, 45):
        base = [3 ** i for i in range(n)]
        for _ in range(20):
            cand = []
            for x in base:
                cand.append(x + random.randint(-2, 2))
            candidates.append(cand)

    best = []
    best_score = -1.0

    for cand in candidates:
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]
        if time.time() > deadline:
            break

    # Multi-start local search with exact scoring.
    while time.time() < deadline:
        # Start from best, or a fresh structured/random set.
        if random.random() < 0.7 and best:
            cur = best[:]
        else:
            n = random.randint(5, 35)
            kind = random.randrange(4)
            if kind == 0:
                cur = random.sample(range(-5 * n, 5 * n + 1), n)
            elif kind == 1:
                cur = [i * random.randint(1, 5) + random.randint(-3, 3) for i in range(n)]
            elif kind == 2:
                cur = [3 ** i for i in range(n)]
            else:
                cur = [2 ** i for i in range(n)]
                cur = [x + random.randint(-1, 1) for x in cur]
            cur = sorted(set(cur))
            if len(cur) < 2:
                continue

        cur_score = _score(cur)
        local_best = cur[:]
        local_best_score = cur_score

        # Simulated annealing / hill climbing.
        T = 0.02
        steps = 0
        while time.time() < deadline and steps < 4000:
            steps += 1
            if not local_best:
                break
            cand = local_best[:]
            op = random.random()

            if op < 0.55:
                i = random.randrange(len(cand))
                delta = random.choice([-10, -5, -3, -2, -1, 1, 2, 3, 5, 10])
                cand[i] += delta
            elif op < 0.8:
                cand.append(random.randint(-200, 200))
            elif op < 0.93 and len(cand) > 3:
                i = random.randrange(len(cand))
                del cand[i]
            else:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-2, 2)

            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            s = _score(cand)
            # Accept if better, or occasionally accept worse.
            if s >= local_best_score or random.random() < math.exp((s - local_best_score) / max(T, 1e-9)):
                local_best = cand
                local_best_score = s
            T *= 0.999

        if local_best_score > best_score:
            best_score = local_best_score
            best = local_best[:]

    # Final refinement around the best set.
    cur = best[:]
    cur_score = _score(cur)
    while time.time() < deadline:
        improved = False
        for i in range(len(cur)):
            for delta in (-20, -10, -5, -3, -2, -1, 1, 2, 3, 5, 10, 20):
                cand = cur[:]
                cand[i] += delta
                cand = sorted(set(cand))
                if len(cand) < 2:
                    continue
                s = _score(cand)
                if s > cur_score:
                    cur = cand
                    cur_score = s
                    improved = True
                    break
            if improved:
                break
        if not improved:
            break

    if cur_score > best_score:
        best = cur
    return sorted(set(best))
