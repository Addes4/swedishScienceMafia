import math
import random
import time


def _score(a):
    """Objective: log|A-A|/log|A+A| + small size bonus."""
    if len(a) < 2:
        return -1e18
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1:
        return -1e18
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / len(a)) / 100.0


def _diffs_sums(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return diffs, sums


def _score_fast(a):
    if len(a) < 2:
        return -1e18
    diffs, sums = _diffs_sums(a)
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1:
        return -1e18
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / len(a)) / 100.0


# ---------------------------------------------------------------------------
# Construction: Bose-Chowla style Sidon set in Z_p, mapped to integers.
# A Sidon set guarantees |A+A| is close to n(n+1)/2 and |A-A| close to n(n-1).
# ---------------------------------------------------------------------------

def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    d = 3
    while d * d <= n:
        if n % d == 0:
            return False
        d += 2
    return True


def _next_prime(n):
    if n <= 2:
        return 2
    if n % 2 == 0:
        n += 1
    while not _is_prime(n):
        n += 2
    return n


def _bose_sidon(q):
    """Return a Sidon set of size q in Z_{q^2-1} using the Bose construction.

    Build the graph of theta(x) = x^2 over Z_q inside Z_{q^2-1}
    via a primitive element.  We use the standard construction:
    take g a generator of GF(q^2)^* seen as Z_{q^2-1} with the field mult,
    and take A = { a : g^a = x + theta*x ... } - simpler: use known formula.
    """
    # Standard Bose-Chowla: let g be a generator of GF(q^2)^*.  The set
    # A = { a in [1, q^2-1] : g^a - g in GF(q) (i.e. g^a = g + c, c in GF(q)) }
    # is a Sidon set of size q in Z_{q^2-1}.
    # Build GF(q^2) as polynomials over Z_q mod an irreducible quadratic.
    pass


def build_field(q):
    """Find irreducible x^2 - d over F_q for a non-residue d."""
    for d in range(2, q):
        # check d is a quadratic non-residue mod q
        if pow(d, (q - 1) // 2, q) == q - 1:
            if q % 2 == 1 and _is_prime(q):
                return d
    return None


def bose_chowla_set(q):
    """Bose-Chowla Sidon set of size q in Z_{q^2-1}, returned as sorted ints."""
    m = q * q - 1
    if q == 2:
        return [0, 1]
    # irreducible x^2 - d
    d = None
    for cand in range(2, q):
        if pow(cand, (q - 1) // 2, q) == q - 1:
            d = cand
            break
    if d is None:
        return None

    # Elements are (a + b*x), x^2 = d mod q
    def mul(u, v):
        a, b = u
        c, e = v
        return ((a * c + b * e * d) % q, (a * e + b * c) % q)

    def is_zero(u):
        return u[0] % q == 0 and u[1] % q == 0

    # find generator g of GF(q^2)^* by testing order
    order = q * q - 1
    # factor order enough to find a generator (order is small enough for brute)
    # find prime factors of order
    n = order
    factors = set()
    t = n
    p = 2
    while p * p <= t:
        if t % p == 0:
            factors.add(p)
            while t % p == 0:
                t //= p
        p += 1
    if t > 1:
        factors.add(t)

    def order_of(u):
        o = order
        for f in factors:
            while o % f == 0:
                w = [1, 0]
                e = o // f
                # w = u^e
                base = u
                w = (1, 0)
                while e > 0:
                    if e & 1:
                        w = mul(w, base)
                    base = mul(base, base)
                    e >>= 1
                if is_zero((w[0] - 1) % q, ) if False else (w[0] % q == 1 and w[1] % q == 0):
                    o //= f
                else:
                    break
        return o

    g = None
    for a in range(q):
        for b in range(q):
            if a == 0 and b == 0:
                continue
            if order_of((a, b)) == order:
                g = (a, b)
                break
        if g is not None:
            break
    if g is None:
        return None

    # For each c in GF(q), find exponent e such that g^e = (c, 1)?  
    # Actually take: basis element represented as field element.  The set
    # S = { e in [0, order-1] : g^e = (c, 1) for some c in GF(q) }
    # is a Sidon set.  We can find e by walking powers or discrete log.
    # Build log table by iterating powers.
    logt = {}
    cur = (1, 0)
    for e in range(order):
        logt[cur] = e
        cur = mul(cur, g)

    S = []
    seen = set()
    for c in range(q):
        tgt = (c % q, 1)
        if tgt in logt:
            e = logt[tgt]
            if e not in seen:
                seen.add(e)
                S.append(e)
    return S


def golomb_like(n, span):
    """Greedy Golomb ruler: maximize distinct differences for size n."""
    A = [0]
    used_diffs = {0}
    # candidate offsets, spread out
    candidates = list(range(1, span + 1))
    random.shuffle(candidates)
    candidates.sort()
    while len(A) < n:
        best = None
        best_gain = -1
        for cnd in candidates:
            if cnd in A:
                continue
            gain = 0
            new_diffs = set()
            ok = True
            for x in A:
                dd = abs(cnd - x)
                if dd not in used_diffs:
                    new_diffs.add(dd)
            # gain counts new distinct diffs
            gain = len(new_diffs)
            if gain > best_gain:
                best_gain = gain
                best = cnd
        if best is None:
            break
        for x in A:
            used_diffs.add(abs(best - x))
        A.append(best)
        candidates = [c for c in candidates if c != best]
        if len(candidates) > 4000:
            candidates = candidates[:4000]
    return A


def optimize(a, deadline, target_size):
    """Simulated annealing on the integer set."""
    a = list(dict.fromkeys(a))
    # normalize
    a = sorted(a)
    base = a[0]
    a = [x - base for x in a]

    best = a[:]
    best_score = _score_fast(best)
    cur = a[:]
    cur_score = best_score

    T = 1.0
    steps = 0
    last_improve = time.time()
    while time.time() < deadline:
        steps += 1
        if steps % 200 == 0:
            T *= 0.97
            if T < 0.01:
                T = 0.01
        cand = cur[:]
        r = random.random()
        if r < 0.55 or len(cand) < 2:
            # perturb an element
            i = random.randrange(len(cand))
            # choose a shift; local mostly
            if random.random() < 0.6:
                cand[i] += random.randint(-2, 2)
            else:
                cand[i] += random.randint(-50, 50)
        elif r < 0.85:
            # add a new element near existing
            x = random.choice(cand)
            cand.append(x + random.randint(1, 60))
        elif r < 0.95 and len(cand) > 3:
            # remove
            cand.pop(random.randrange(len(cand)))
        else:
            # swap: move far element
            i = random.randrange(len(cand))
            cand[i] = random.randint(0, 200)

        cand = list(dict.fromkeys(cand))
        if len(cand) < 2 or len(cand) > 300:
            continue

        cs = _score_fast(cand)
        if cs > cur_score or (T > 0 and random.random() < math.exp((cs - cur_score) / max(T, 1e-9))):
            cur = cand
            cur_score = cs
            if cs > best_score:
                best = cand[:]
                best_score = cs
                last_improve = time.time()

        # restart if stuck
        if time.time() - last_improve > 8:
            # rebuild around best with jitter
            cur = best[:]
            for _ in range(random.randint(1, 5)):
                if len(cur) > 2:
                    i = random.randrange(len(cur))
                    cur[i] += random.randint(-10, 10)
                else:
                    cur.append(random.randint(0, 100))
            cur = list(dict.fromkeys(cur))
            cur_score = _score_fast(cur)
            last_improve = time.time()

    return best


def solve():
    deadline = time.time() + 110

    candidates = []

    # 1. Bose-Chowla Sidon sets for various prime powers
    for q in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]:
        try:
            s = bose_chowla_set(q)
            if s:
                candidates.append(s)
        except Exception:
            pass

    # 2. Golomb rulers (greedy)
    for n in [8, 12, 16, 20, 24, 30, 40, 50]:
        span = max(n * n * 2, 200)
        try:
            g = golomb_like(n, span)
            if len(g) >= 2:
                candidates.append(g)
        except Exception:
            pass

    # 3. Some randomized power set constructions
    for _ in range(20):
        k = random.randint(3, 8)
        base = random.randint(2, 6)
        s = set()
        for _ in range(random.randint(8, 40)):
            v = 0
            for i in range(k):
                if random.random() < 0.5:
                    v += base ** i
            s.add(v)
        if len(s) >= 2:
            candidates.append(sorted(s))

    # 4. Baseline from the prompt
    candidates.append([7, 15, 18, 22, -3, -2])
    candidates.append([0, 1, 3, 7, 12, 20, 30, 44])
    candidates.append([0, 1, 4, 10, 18, 23, 25])

    # Evaluate
    best = None
    best_score = -1e18
    for c in candidates:
        c = sorted(set(x for x in c if abs(x) <= 10**15))
        if len(c) < 2:
            continue
        sc = _score_fast(c)
        if sc > best_score:
            best_score = sc
            best = c[:]

    # Also try scaling/normalizing best
    if best is not None:
        base = best[0]
        best = [x - base for x in best]

    # Run optimization
    time_left = deadline - time.time()
    if time_left > 1:
        opt = optimize(best if best else [0, 1, 3, 7], deadline, len(best) if best else 10)
        sc = _score_fast(opt)
        if sc > best_score:
            best = opt
            best_score = sc

    if best is None:
        best = [0, 1]

    # Ensure constraints
    best = sorted(set(int(x) for x in best if abs(int(x)) <= 10**15))
    if len(best) < 2:
        best = [0, 1]
    if len(best) > 4000:
        best = best[:4000]
    return best
