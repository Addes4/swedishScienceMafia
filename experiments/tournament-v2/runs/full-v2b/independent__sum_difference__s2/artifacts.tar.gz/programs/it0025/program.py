import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls == 0 or ld == 0:
        return 0.0, ld, ls
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100, ld, ls


def _score_fast(a, prev_ld=0, prev_ls=0):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls == 0 or ld == 0:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _golomb_ruler(n, seed=0):
    """Greedy Golomb-like ruler: distinct pairwise differences."""
    marks = [0]
    used = set()
    candidates = list(range(1, 200 * n + 200))
    rng = random.Random(seed)
    if seed:
        rng.shuffle(candidates)
    for _ in range(n - 1):
        best_c = None
        best_added = None
        for c in candidates:
            if c in used:
                continue
            new_diffs = {abs(c - m) for m in marks}
            if new_diffs & used:
                continue
            added = len(new_diffs)
            if best_added is None or added < best_added:
                best_added = added
                best_c = c
        if best_c is None:
            # fallback: any
            for c in candidates:
                if c not in used and c > marks[-1]:
                    best_c = c
                    break
        marks.append(best_c)
        used.update({abs(best_c - m) for m in marks})
    return marks


def _bh_construction(n, h=2):
    """Approximate B_h set: subsum set of a Golomb ruler (small sum set)."""
    # Use a greedy ruler-like construction to control sum set too.
    # Build via 'modular Sidon' heuristic: pick elements from a Bose-Chowla style set.
    p = 2
    while p * p < n * 4:
        p += 1
    # find prime p with p^2 - 1 >= n
    def is_prime(x):
        if x < 2:
            return False
        if x % 2 == 0:
            return x == 2
        i = 3
        while i * i <= x:
            if x % i == 0:
                return False
            i += 2
        return True
    while not is_prime(p):
        p += 1
    while p * p - 1 < n - 1:
        p += 1
        while not is_prime(p):
            p += 1
    # Bose-Chowla Sidon set in Z_{p^2-1}: {i : g^i} mapped. Simpler: use Singer diff set.
    g = None
    order = p * p - 1
    # find primitive root mod p
    def factorize(x):
        f = set()
        d = 2
        while d * d <= x:
            while x % d == 0:
                f.add(d)
                x //= d
            d += 1
        if x > 1:
            f.add(x)
        return f
    factors = factorize(p - 1)
    for cand in range(2, p):
        if all(pow(cand, (p - 1) // f, p) != 1 for f in factors):
            g = cand
            break
    if g is None:
        g = 2
    # Bose-Chowla: {(i, g^i)} -> integer in Z_{p^2-1}
    sidon = []
    for i in range(p):
        val = (i * p + pow(g, i, p)) % (p * p - 1) if p > 1 else 0
        sidon.append(val)
    sidon = sorted(set(sidon))
    return sidon[:n]


def solve():
    deadline = time.time() + 110

    # Start with a known good small set
    candidates_best = None
    best_score = -1.0

    # Try several constructions
    seeds = [0, 1, 2, 3, 4]
    n_sizes = [40, 60, 80, 120, 200]

    # Random search for a good base set that minimizes sums relative to diffs
    for n in n_sizes:
        if time.time() > deadline - 90:
            break
        for seed in seeds:
            mid = deadline - 80
            if time.time() > mid:
                break
            a = _golomb_ruler(n, seed)
            # scale and shift
            scale = 1
            a = [x * scale for x in a]
            s = _score_fast(a)
            if s > best_score:
                best_score = s
                candidates_best = a[:]

    # Also try Bose-Chowla
    for n in n_sizes:
        if time.time() > deadline - 80:
            break
        try:
            a = _bh_construction(n)
            s = _score_fast(a)
            if s > best_score:
                best_score = s
                candidates_best = a[:]
        except Exception:
            pass

    if candidates_best is None:
        candidates_best = list(range(40))

    # Local search: hill climbing / simulated annealing on the actual score
    best = list(set(candidates_best))
    best_score = _score_fast(best)[0]
    cur = best[:]
    cur_score = best_score

    rng = random.Random(12345)
    T0 = 0.05
    while time.time() < deadline:
        # propose modification
        cand = cur[:]
        op = rng.random()
        if op < 0.6 and len(cand) > 3:
            # shift a random element
            i = rng.randrange(len(cand))
            spread = max(1, int(rng.expovariate(1.0 / 4.0)))
            cand[i] += rng.randint(-spread, spread)
        elif op < 0.8:
            # add an element
            if len(cand) < 500:
                m = max(cand)
                mn = min(cand)
                newv = rng.randint(mn, m + 5)
                if newv not in cand:
                    cand.append(newv)
        else:
            # remove an element
            if len(cand) > 4:
                cand.pop(rng.randrange(len(cand)))

        if len(set(cand)) < 2:
            continue

        s = _score_fast(cand)
        if s > cur_score or rng.random() < 0.02:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s

    return sorted(set(best))
