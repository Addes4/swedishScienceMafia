import math
import random
import time


def _score_parts(a):
    n = len(a)
    if n < 2:
        return 0.0, 0.0, 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    ld = len(diffs)
    ls = len(sums)
    if ld < 2 or ls < 2:
        return 0.0, 0.0, 0.0
    sc = math.log(ld) / math.log(ls)
    sc += (1.0 - 1.0 / n) / 100.0
    return sc, ld, ls


def _score(a):
    return _score_parts(a)[0]


def _polish(a, deadline):
    a = sorted(set(a))
    if len(a) < 2:
        return a, _score(a)
    best = a[:]
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    steps = 0
    while time.time() < deadline:
        steps += 1
        cand = cur[:]
        mode = random.random()
        if mode < 0.55 and len(cand) > 2:
            i = random.randrange(len(cand))
            shift = random.choice([-3, -2, -1, 1, 2, 3])
            cand[i] += shift
        elif mode < 0.8:
            cand.append(random.randint(-30, 30))
        elif len(cand) > 3:
            i = random.randrange(len(cand))
            del cand[i]
        cand = sorted(set(cand))
        if len(cand) > 4000:
            continue
        s, _, _ = _score_parts(cand)
        if s > cur_score or (s == cur_score and random.random() < 0.2):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.02:
            cur, cur_score = best[:], best_score
    return best, best_score


def _construct(rng):
    # Many closely-spaced small integers plus a few larger ones create many sums
    # while differences remain plentiful. Shift/scale gives diversity.
    mode = rng.random()
    n = rng.randint(8, 45)
    if mode < 0.35:
        base = rng.randint(1, 7)
        a = [rng.randint(-10, 10) for _ in range(n)]
        a = [x * base for x in a]
    elif mode < 0.7:
        span = rng.randint(5, 60)
        a = rng.sample(range(-span, span + 1), min(n, 2 * span + 1))
    else:
        a = [rng.randint(-40, 40) for _ in range(n)]
    a = sorted(set(a))
    if len(a) < 2:
        a = [0, 1]
    return a


def solve():
    random.seed(123456789)
    start = time.time()
    total_deadline = start + 115.0

    # Known strong seed patterns.
    seeds = [
        [7, 15, 18, 22, -3, -2],
        [0, 1, 2, 3, 4, 5, 6],
        [0, 1, 2, 4, 7, 11, 16],
        [-2, -1, 0, 1, 2, 3, 4],
        [0, 1, 3, 4, 6, 7, 9],
        [-10, -9, -8, -7, -6, -5, -4, 0, 1, 2],
    ]

    best = seeds[0][:]
    best_score, _, _ = _score_parts(best)

    for s in seeds:
        sc, _, _ = _score_parts(s)
        if sc > best_score:
            best, best_score = s[:], sc

    rng = random.Random(987654321)

    # First phase: polish good seeds.
    phase1_end = min(total_deadline, time.time() + 20)
    for s in seeds:
        if time.time() >= phase1_end:
            break
        cand, sc = _polish(s, phase1_end)
        if sc > best_score:
            best, best_score = cand, sc

    # Second phase: randomized construction + polish.
    while time.time() < total_deadline:
        cand = _construct(rng)
        remaining = total_deadline - time.time()
        if remaining <= 0:
            break
        budget = min(remaining, max(0.5, remaining / 3.0))
        cand, sc = _polish(cand, time.time() + budget)
        if sc > best_score:
            best, best_score = cand, sc
        # Occasionally intensify around current best.
        if random.random() < 0.3 and time.time() < total_deadline:
            rem2 = total_deadline - time.time()
            if rem2 > 0:
                cand2, sc2 = _polish(best, time.time() + min(rem2, 2.0))
                if sc2 > best_score:
                    best, best_score = cand2, sc2

    return sorted(set(best))
