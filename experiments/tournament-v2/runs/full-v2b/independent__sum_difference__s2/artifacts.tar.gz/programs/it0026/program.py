import math
import random
import time


def _score_parts(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns <= 1:
        return 0.0, nd, ns
    s = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return s, nd, ns


def _score(a):
    return _score_parts(a)[0]


def _make_ap_like(k, base, step):
    # dense block: many additive collisions
    return [base + i * step for i in range(k)]


def _make_sidon_tail(k, offset, gap):
    # spread values to increase difference set, few sums overlap maybe
    return [offset + i * gap + (i * i) for i in range(k)]


def _candidate_structures():
    cands = []
    # Pure arithmetic progressions: |A+A| ~ 2n, |A-A| ~ 2n -> ratio ~1
    # Need differences larger than sums in log terms.
    # Use union of two APs with different steps to expand differences while
    # keeping sums somewhat constrained.
    for n1 in (20, 40, 80, 120, 200):
        for n2 in (20, 40, 80, 120):
            for s1, s2 in ((1, 7), (1, 13), (2, 17), (3, 29), (1, 101)):
                A = [i * s1 for i in range(n1)]
                A += [1000000 + i * s2 for i in range(n2)]
                cands.append(A)
    for n1 in (20, 40, 80, 120, 200):
        for n2 in (20, 40, 80):
            for s in (1, 3, 7):
                for g in (17, 53, 149):
                    A = [i * s for i in range(n1)]
                    A += [500000 + i * g + i * i for i in range(n2)]
                    cands.append(A)
    # scaled near-AP with a multiplicative offset
    for n in (50, 100, 200, 400, 800):
        for s in (1, 2, 3):
            A = [i * s for i in range(n)]
            cands.append(A)
    return cands


def _local_search(best, deadline):
    best = list(set(best))
    best_score, _, _ = _score_parts(best)
    if not best:
        best = [0, 1]
        best_score, _, _ = _score_parts(best)
    cur = best[:]
    step = max(1, len(best) // 10)
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.7 and cand:
            i = random.randrange(len(cand))
            delta = random.randint(-step, step)
            if delta != 0:
                cand[i] += delta
        elif op < 0.85:
            cand.append(random.randint(-10**6, 10**6))
        elif len(cand) > 2:
            i = random.randrange(len(cand))
            cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s, nd, ns = _score_parts(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]
    return best


def solve():
    deadline = time.time() + 115
    best = None
    best_score = -1.0
    for A in _candidate_structures():
        if time.time() > deadline - 30:
            break
        s, _, _ = _score_parts(A)
        if s > best_score:
            best_score = s
            best = A
    if best is None:
        best = [0, 1, 2, 4, 8, 16]
        best_score = _score(best)
    # refine top candidate(s)
    improved = _local_search(best, deadline)
    s2 = _score(improved)
    if s2 > best_score:
        best = improved
    best = sorted(set(best))
    # final sanity: ensure distinct, within bounds, <=4000
    best = [x for x in best if abs(x) <= 10**15][:4000]
    if len(best) < 2:
        best = [0, 1]
    return best
