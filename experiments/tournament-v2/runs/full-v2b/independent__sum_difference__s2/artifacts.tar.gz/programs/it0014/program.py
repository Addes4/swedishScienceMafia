import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    asc = sorted(a)
    # Differences via convolution-free set construction
    diffs = set()
    for x in asc:
        for y in asc:
            diffs.add(x - y)
    sums = set()
    for x in asc:
        for y in asc:
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0

def _fast_parts(a):
    a = sorted(set(a))
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return diffs, sums

def solve():
    deadline = time.time() + 110.0

    # Candidate seeds: several known good structures.
    candidates = []

    # 1) Arithmetic-like / dense set with few sums, many distinct diffs.
    # Mix of small AP with a large shift to boost differences without too much sum collapse.
    base = list(range(0, 22))
    candidates.append(base)
    candidates.append([3 * i for i in range(20)])
    candidates.append([i * i for i in range(16)])
    candidates.append([i * (i + 1) // 2 for i in range(20)])  # triangular numbers

    # 2) A "B_h" style greedy difference-maximizing set, checked for score.
    def build_greedy(n_target, limit, rng, score_weight=True):
        S = [0]
        used_diffs = {0}
        t = 0
        while len(S) < n_target and len(S) < limit and time.time() < deadline:
            best_x = None
            best_val = -1e18
            # try candidates from random offsets
            for _ in range(80):
                x = rng.randint(-200, 200)
                if x in S:
                    continue
                newd = len({x - s for s in S} | {s - x for s in S} | used_diffs)
                # estimate score contribution using fast lower-bound heuristic
                if score_weight:
                    val = newd * 1.0 - abs(len(S) - n_target) * 0.01
                else:
                    val = newd
                if val > best_val:
                    best_val = val
                    best_x = x
            if best_x is None:
                break
            S.append(best_x)
            used_diffs |= {best_x - s for s in S} | {s - best_x for s in S}
            t += 1
            if t > 5000:
                break
        return sorted(S)

    rng = random.Random(12345)
    for nt in (30, 60, 120, 200):
        for _ in range(3):
            candidates.append(build_greedy(nt, nt + 20, rng))

    # 3) Geometric-ish progression: powers of 2 scaled plus dense prefix
    for k in (8, 12, 16):
        geo = [2 ** i for i in range(k)]
        candidates.append(sorted(geo))
        mixed = list(range(2 * k)) + [100 * (2 ** i) for i in range(k)]
        candidates.append(sorted(mixed))

    # 4) Union construction: start from dense block, append random large shifts to increase diffs
    for blk in (10, 20, 30):
        for m in (5, 10, 15, 20):
            A = list(range(blk))
            off = 1000
            for _ in range(m):
                A.append(off + rng.randint(0, 5))
                off += rng.randint(50, 500)
            candidates.append(sorted(set(A)))

    # Evaluate seeds
    best = None
    best_score = -1e18
    for c in candidates:
        c = list(set(c))
        if len(c) < 2:
            continue
        s = _score(c)
        if s > best_score:
            best_score = s
            best = c[:]

    if best is None:
        best = [0, 1, 2, 4, 8, 16]
        best_score = _score(best)

    cur = best[:]
    cur_score = best_score

    # Local search: mutations on positions + range scaling + occasional additions.
    # Use a geometric schedule for step size.
    iter_count = 0
    while time.time() < deadline:
        iter_count += 1
        # adaptive step size
        frac = (deadline - time.time()) / 110.0
        step = max(1, int(30 * frac))
        cand = cur[:]
        n = len(cand)

        op = random.random()
        if op < 0.55 and n > 2:
            # mutate one element
            i = random.randrange(n)
            cand[i] += random.randint(-step, step)
        elif op < 0.75:
            # shift a contiguous block
            i = random.randrange(n)
            j = min(n, i + random.randint(1, max(1, n // 3)))
            delta = random.randint(-step, step)
            for k in range(i, j):
                cand[k] += delta
        elif op < 0.85:
            # scale subset
            i = random.randrange(n)
            factor = random.choice([-2, -1, 2, 3])
            cand[i] *= factor if cand[i] != 0 else 1
        elif op < 0.93:
            # add new element near an existing one or random tail
            if n < 4000:
                if random.random() < 0.7:
                    base_x = random.choice(cand)
                    cand.append(base_x + random.randint(-step, step))
                else:
                    cand.append(random.randint(-10000, 10000))
        else:
            # remove element if large enough
            if n > 3:
                i = random.randrange(n)
                cand.pop(i)

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        # score with fast pruning: if lengths suggest bad, skip
        s = _score(cand)
        if s > cur_score or (random.random() < 0.02 and s > cur_score - 0.05):
            if s >= cur_score:
                cur = cand
                cur_score = s
                if s > best_score:
                    best = cand[:]
                    best_score = s
            else:
                cur = cand
                cur_score = s
        # occasional restart from best
        if iter_count % 4000 == 0:
            cur = best[:]
            cur_score = best_score

    # Final polish: try small perturbations around best greedily
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for _ in range(200):
            cand = best[:]
            n = len(cand)
            i = random.randrange(n)
            cand[i] += random.randint(-2, 2)
            cand = list(set(cand))
            s = _score(cand)
            if s > best_score:
                best = cand
                best_score = s
                improved = True
                break

    return sorted(set(best))
