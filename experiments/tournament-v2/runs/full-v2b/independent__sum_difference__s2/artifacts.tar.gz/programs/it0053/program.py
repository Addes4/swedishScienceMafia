import math
import random
import time

def _score_stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    d = len(diffs)
    s = len(sums)
    if s <= 1:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0, d, s

def solve():
    best_A = [7, 15, 18, 22, -3, -2]
    best_score, _, _ = _score_stats(best_A)
    deadline = time.time() + 115

    # Candidate constructions from finite projective planes / Singer difference sets:
    # For prime power q, there is a (q^2+q+1, q+1, 1) difference set in Z_v.
    # Differences in the cyclic group are almost all v-1 values; sums tend to be
    # controlled if we center the set.  We try several small q and then locally search.
    def singer_diff_set(q):
        v = q * q + q + 1
        # Multiplicative generator of F_{q^3}^* acting on projective line is complex;
        # use a known construction via powers of a primitive element in GF(q^3).
        # Simpler: use quadratic residues / planar difference set via Pell-like search
        # when q is small by brute force over small v using known formulas won't fit.
        return None

    def make_projective_plane_set(q):
        # Build a (q^2+q+1, q+1, 1) difference set for prime q via the standard
        # "Singer" trace construction using GF(q^3) arithmetic.
        v = q * q + q + 1
        # Represent GF(q^3) as polynomials modulo an irreducible cubic over GF(q).
        # Find an irreducible cubic by brute force.
        def is_irreducible(cubic):
            # cubic = (a,b,c) meaning x^3 + a x^2 + b x + c over F_q
            a, b, c = cubic
            # Check no roots in F_q
            for x in range(q):
                val = ((x + a) * x + b) * x + c
                if val % q == 0:
                    return False
            return True

        cubic = None
        for a in range(q):
            for b in range(q):
                for c in range(q):
                    if is_irreducible((a, b, c)):
                        cubic = (a, b, c)
                        break
                if cubic:
                    break
            if cubic:
                break
        if cubic is None:
            return None
        a3, b3, c3 = cubic

        def mul(u, v):
            # u, v are 3-vectors over F_q, multiply modulo x^3 + a3 x^2 + b3 x + c3
            r = [0, 0, 0, 0, 0]
            for i in range(3):
                for j in range(3):
                    r[i + j] = (r[i + j] + u[i] * v[j]) % q
            # reduce degree 4 -> use x^3 = -(a3 x^2 + b3 x + c3)
            for d in (4, 3):
                coef = r[d]
                if coef:
                    r[d] = 0
                    r[d - 1] = (r[d - 1] - coef * a3) % q
                    r[d - 2] = (r[d - 2] - coef * b3) % q
                    r[d - 3] = (r[d - 3] - coef * c3) % q
            return r[:3]

        # Find a generator of GF(q^3)^*
        def order(x):
            # q^3 - 1
            n = q * q * q - 1
            # factor n? small enough to just count
            o = 1
            y = x[:]
            one = [1, 0, 0]
            while y != one:
                y = mul(y, x)
                o += 1
                if o > n:
                    return -1
            return o

        gen = None
        for i in range(1, q):
            for j in range(q):
                for k in range(q):
                    if i == 0 and j == 0 and k == 0:
                        continue
                    x = [i, j, k]
                    if order(x) == q * q * q - 1:
                        gen = x
                        break
                if gen:
                    break
            if gen:
                break
        if gen is None:
            return None

        # Projective points: equivalence classes of nonzero vectors over GF(q)
        points = []
        for i in range(q):
            for j in range(q):
                for k in range(q):
                    if i or j or k:
                        points.append((i, j, k))
        # Normalize: first nonzero coordinate = 1
        seen = set()
        classes = []
        for p in points:
            # find first nonzero
            if p[0] != 0:
                inv = pow(p[0], q - 2, q) if q > 1 else 1
                rep = (1, (p[1] * inv) % q, (p[2] * inv) % q)
            elif p[1] != 0:
                inv = pow(p[1], q - 2, q) if q > 1 else 1
                rep = (0, 1, (p[2] * inv) % q)
            else:
                rep = (0, 0, 1)
            if rep not in seen:
                seen.add(rep)
                classes.append(rep)
        # map: point -> index
        idx = {rep: i for i, rep in enumerate(classes)}
        v = len(classes)
        # orbit of a line under multiplication by gen: gives difference set
        # Take the point (1,0,0); multiply repeatedly by gen; the set of exponents
        # where the result lies in the line x2 = 0 (i.e., third coord = 0) is a
        # difference set in Z_v.
        # Actually classic construction: D = { i : g^i in H }, H a hyperplane.
        # We'll use the line at infinity: points with k = 0.
        D = []
        cur = [1, 0, 0]
        for i in range(v):
            if cur[2] == 0:
                D.append(i)
            cur = mul(cur, gen)
        # D subset of Z_v, |D| = q+1 typically
        return D, v

    candidates = []
    for q in (2, 3, 5, 7, 11):
        try:
            res = make_projective_plane_set(q)
            if res:
                D, v = res
                candidates.append((D, v))
        except Exception:
            pass

    for D, v in candidates:
        # Convert to integer set: center around zero, try several multipliers/offsets
        for mult in (1, 2, 3, 5):
            for offset in range(v):
                A = [((d - offset) * mult) % v for d in D]
                A = sorted(set(A))
                if len(A) < 2:
                    continue
                sc, _, _ = _score_stats(A)
                if sc > best_score:
                    best_score = sc
                    best_A = A[:]
                    cur = A[:]

    # Local search from best
    cur = best_A[:]
    cur_score = best_score
    start = time.time()
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-3, 3)
        elif op < 0.8:
            cand.append(random.randint(-20, 20))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue
        sc, _, _ = _score_stats(cand)
        if sc >= cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best_A = cand[:]
        elif random.random() < 0.05:
            cur = best_A[:]
            cur_score = best_score
        # occasionally try a full restart with a random small set
        if random.random() < 0.002:
            n = random.randint(5, 30)
            cur = sorted(set(random.randint(-50, 50) for _ in range(n)))
            cur_score, _, _ = _score_stats(cur)

    # One more refinement: try shifting best_A to reduce sum set collisions
    for shift in range(-2, 3):
        if shift == 0:
            continue
        A = [x + shift for x in best_A]
        sc, _, _ = _score_stats(A)
        if sc > best_score:
            best_score = sc
            best_A = A

    return sorted(set(best_A))
