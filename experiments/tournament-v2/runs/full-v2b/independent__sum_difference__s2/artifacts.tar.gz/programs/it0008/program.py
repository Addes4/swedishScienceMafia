import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _greedy_modular(n, mod):
    """Greedy Sidon-like set modulo mod, mapped to integers."""
    chosen = []
    used_sums = set()
    used_diffs = set()
    candidates = list(range(mod))
    random.shuffle(candidates)
    for c in candidates:
        if len(chosen) >= n:
            break
        ok = True
        new_sums = set()
        new_diffs = set()
        for x in chosen:
            s = (c + x) % mod
            d1 = (c - x) % mod
            d2 = (x - c) % mod
            if s in used_sums or s in new_sums:
                ok = False
                break
            if d1 in used_diffs or d2 in used_diffs or d1 in new_diffs or d2 in new_diffs:
                ok = False
                break
            new_sums.add(s)
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            chosen.append(c)
            used_sums |= new_sums
            used_diffs |= new_diffs
    return chosen


def _build_structured(n, spread):
    """Build a set with many differences and few sums by combining scales."""
    base = _greedy_modular(n, spread)
    if len(base) < 2:
        base = random.sample(range(spread), min(n, spread // 2))
    return base


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    deadline = time.time() + 110

    # Phase 1: try structured constructions
    n_try = 250
    for spread_mult in [1.5, 2.0, 2.5, 3.0, 4.0]:
        spread = int(n_try * spread_mult) + 500
        s = _build_structured(n_try, spread)
        if len(s) >= 2:
            sc = _score(s)
            if sc > best_score:
                best, best_score = s[:], sc

    # Phase 2: hill-climb to improve
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6:
            # perturb an element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif op < 0.85:
            # add a new element near existing ones
            x = random.choice(cand)
            cand.append(x + random.randint(-100, 100))
        else:
            # shift whole set slightly (translation invariant score)
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-1000, 1000)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            continue
        if max(abs(x) for x in cand) > 10**15:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = cand[:]
        else:
            cur = best[:]

    return sorted(set(best))
