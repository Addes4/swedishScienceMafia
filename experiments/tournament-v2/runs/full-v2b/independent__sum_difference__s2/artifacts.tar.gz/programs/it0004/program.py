import math
import random
import time

def _diffs_sums(a):
    n = len(a)
    ds = set()
    ss = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            ds.add(ai - aj)
            ss.add(ai + aj)
    return len(ds), len(ss)

def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0, 1, 1
    ld, ls = _diffs_sums(a)
    if ls <= 1:
        return 0.0, ld, ls
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / len(a)) / 100.0, ld, ls

def _incremental_scores(a):
    return _score(a)

def _try_constructs():
    best = None
    bests = -1.0

    # Candidate constructions

    # 1) powers of 2 plus small perturbations
    A = [2**i for i in range(12)]
    s, _, _ = _score(A)
    if s > bests:
        bests = s; best = A[:]

    # 2) Sidon-ish: A = {i + i^2 for small i}
    A = [i + i*i for i in range(1, 60)]
    s, _, _ = _score(A)
    if s > bests:
        bests = s; best = A[:]

    # 3) shifted powers: A = {2^i + c}
    for c in range(-5, 6):
        A = [2**i + c for i in range(12)]
        s, _, _ = _score(A)
        if s > bests:
            bests = s; best = A[:]

    # 4) Golomb ruler-like via i^2
    A = [(i*i) for i in range(1, 80)]
    s, _, _ = _score(A)
    if s > bests:
        bests = s; best = A[:]

    # 5) mixed: some APs concatenated
    A = []
    base = 0
    for k in range(1, 8):
        for j in range(1, k+2):
            A.append(base + j*k*k)
        base += 1000 * k

    s, _, _ = _score(A)
    if s > bests:
        bests = s; best = A[:]

    return best, bests

def solve():
    random.seed(12345)
    start = time.time()
    deadline = start + 110.0

    best, bests = _try_constructs()
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        bests, _, _ = _score(best)

    # Keep a pool of decent sets
    pool = []
    for _ in range(40):
        n = random.randint(8, 30)
        A = sorted(random.sample(range(-100, 100), n))
        s, _, _ = _score(A)
        pool.append((s, A))
        if s > bests:
            bests = s
            best = A[:]

    pool.sort(reverse=True)
    pool = pool[:20]

    # Local search with multiple restarts
    cur = best[:]
    cur_score = bests
    no_improve = 0

    while time.time() < deadline:
        # choose move type
        r = random.random()
        cand = cur[:]
        n = len(cand)

        if r < 0.45:
            # perturb one element
            i = random.randrange(n)
            scale = random.choice([1, 1, 2, 3, 5, 10, 100])
            cand[i] += random.randint(-scale, scale)
        elif r < 0.65:
            # add element
            if n < 4000:
                lo = min(cand) - 50
                hi = max(cand) + 50
                cand.append(random.randint(lo, hi))
        elif r < 0.80:
            # remove element
            if n > 3:
                i = random.randrange(n)
                cand.pop(i)
        elif r < 0.92:
            # shift whole set
            d = random.randint(-10, 10)
            cand = [x + d for x in cand]
        else:
            # combine two from pool
            if len(pool) >= 2:
                a = random.choice(pool)[1]
                b = random.choice(pool)[1]
                cand = list(set(a + b[:len(b)//2]))
                if len(cand) < 3:
                    cand = a[:]

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            cand = cand[:4000]

        s, _, _ = _score(cand)

        if s >= cur_score:
            cur = cand
            cur_score = s
            no_improve = 0
            if s > bests:
                bests = s
                best = cand[:]
        else:
            no_improve += 1
            if no_improve > 200 or random.random() < 0.02:
                # restart from best or pool
                if random.random() < 0.6:
                    cur = best[:]
                else:
                    cur = random.choice(pool)[1][:]
                cur_score, _, _ = _score(cur)
                no_improve = 0

        # occasionally inject to pool
        if len(pool) < 20 or s > pool[-1][0]:
            pool.append((s, cand[:]))
            pool.sort(reverse=True)
            pool = pool[:20]

    return sorted(set(int(x) for x in best))
