import math
import random
import time
from itertools import combinations


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    L = list(a)
    for x in L:
        for y in L:
            diffs.add(x - y)
            sums.add(x + y)
    val = math.log(len(diffs)) / math.log(len(sums))
    return val + (1 - 1 / len(a)) / 100


def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    d = len(diffs)
    s = len(sums)
    val = math.log(d) / math.log(s) + (1 - 1 / n) / 100
    return val, d, s


def solve():
    """Use a Sidon-like / multiplicative construction to maximize log|A-A|/log|A+A|."""
    best = None
    best_score = -1.0

    # Construction 1: powers of 2 (differences all distinct -> |A-A| ~ n^2, |A+A| ~ n^2/2 + n)
    # Actually sums of distinct pairs are unique too (binary rep), but pairs (i,i) collide.
    # A = {2^i} for i = 0..k-1: |A-A| = n^2 - (n-1)? differences 2^i - 2^j = 2^j(2^{i-j}-1),
    # unique by binary representation when i>j; and negatives. So |A-A| = 2*(n choose 2)+1 = n^2-n+1.
    # |A+A| = 2^i+2^j unique for i<j (binary), plus 2*2^i = 2^{i+1} which collides with 2^{i+1}+0? 0 not in A.
    # sums 2^i+2^j for i<=j: 2^i+2^i = 2^{i+1} which equals 2^{i+1}+? no. But 2^i+2^j (i<j) all distinct.
    # diagonal sums 2^{i+1} are distinct from off-diagonal unless 2^{i+1}=2^j+2^k. Binary: 2^{i+1} has one bit,
    # 2^j+2^k has two bits (for j<k), so distinct. So |A+A| = n(n+1)/2.
    # Ratio = log(n^2-n+1)/log(n(n+1)/2). For large n, ~ 2log n / (2 log n - log 2) > 1.

    for k in range(2, 41):
        A = [1 << i for i in range(k)]
        sc, d, s = _score_fast(A)
        if sc > best_score:
            best_score = sc
            best = A[:]

    # Construction 2: base-b representation Sidon-like: A = {i + i^2 * B} maybe.
    # Try A = {i * B + i*i mod ...} not needed.

    # Construction 3: A = {i*M + (i*i mod p)} - generalized Sidon set in integers
    # Better approach: search among subsets of powers-of-2-based sets to boost ratio a bit.
    # Also try shifting by adding constant to reduce sum collisions? Shifting changes both equally.

    # Local search around powers of 2 to nudge ratio (small changes only, since structure is key).
    deadline = time.time() + 100.0

    if best is None:
        best = [1, 2, 4, 8, 16]
        best_score = _score(best)

    cur = best[:]
    n = len(cur)

    # Perturbation: try replacing some element with a nearby value to gain ratio,
    # but do it rarely since exact power-of-2 optimal for distinctness.
    tries = 0
    while time.time() < deadline and tries < 200000:
        tries += 1
        cand = cur[:]
        op = random.random()
        if op < 0.6:
            # shift one element slightly
            i = random.randrange(len(cand))
            delta = random.choice([-2, -1, 1, 2])
            old = cand[i]
            cand[i] = old + delta
            if cand[i] == 0:
                cand[i] = old
            if len(set(cand)) != len(cand):
                continue
        elif op < 0.85 and n < 40:
            # extend length
            cand.append(1 << n)
            n2 = len(cand)
        else:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
            else:
                continue

        sc, d, s = _score_fast(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]
            cur = cand[:]
        elif random.random() < 0.02:
            cur = best[:]

    # Re-check the pure power-of-2 family for the best length once more.
    for k in range(2, 41):
        A = [1 << i for i in range(k)]
        sc, d, s = _score_fast(A)
        if sc > best_score:
            best_score = sc
            best = A[:]

    return sorted(set(best))
