import math
import random
import time


def _stats(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _factor(a):
    a = sorted(set(a))
    n = len(a)
    if n < 3:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs) / (n * n), len(sums) / (n * n)


def solve():
    deadline = time.time() + 110.0

    # --- seed constructions ---

    seeds = []

    # 1) Sidon-like set built greedily: small sum set, nearly all differences distinct.
    def greedy_sidon(nmax, limit=100000):
        A = [0]
        while len(A) < nmax:
            bestv = None
            bestscore = -1
            # try many candidates
            for _ in range(200):
                cand = random.randint(-limit, limit)
                trial = A + [cand]
                sd = {x - y for x in trial for y in trial}
                ss = {x + y for x in trial for y in trial}
                if len(ss) == 0:
                    continue
                sc = len(sd) / len(ss)
                if sc > bestscore:
                    bestscore = sc
                    bestv = cand
            A.append(bestv)
        return A

    for n in [20, 50, 80, 120]:
        seeds.append(greedy_sidon(n, 200))

    # 2) Bose-Chowla / base set: {2ik + i^2} mod p for prime p, adjusted values
    def bose_chowla(p, k):
        # yields a Sidon-ish set in Z_{p^2-1}; map into integers via modular lifting
        vals = []
        for i in range(1, k + 1):
            vals.append((2 * p * i + (i * i)) % (p * p - 1))
        return vals

    for p in [11, 13, 17, 19]:
        for k in range(3, min(p, 12)):
            seeds.append(bose_chowla(p, k))

    # 3) intervals / arithmetic progressions with holes
    for n in [40, 80, 160]:
        A = list(range(1, n + 1))
        # randomly thin
        if n > 60:
            A = [x for x in A if random.random() < 0.8]
        seeds.append(A)

    # 4) scaled geometric-ish sets
    for n in [30, 60]:
        A = [0]
        v = 1
        for _ in range(n - 1):
            v += random.randint(1, 3)
            A.append(v)
        seeds.append(A)

    best = None
    best_score = -1.0
    for s in seeds:
        s = sorted(set(s))
        sc = _score(s)
        if sc > best_score:
            best_score = sc
            best = s

    # --- local search ---

    def local_search(start, t_end):
        cur = start[:]
        cur_score = _score(cur)
        bestloc = cur[:]
        bestloc_score = cur_score
        n_iter = 0
        last_improve = time.time()
        T = 0.05
        while time.time() < t_end:
            n_iter += 1
            cand = cur[:]
            op = random.random()

            if op < 0.45 and len(cand) > 3:
                i = random.randrange(len(cand))
                step = random.randint(-2, 2)
                if step == 0:
                    step = 1
                cand[i] += step
            elif op < 0.8:
                base = random.choice(cand)
                cand.append(base + random.randint(-10, 10))
                if len(cand) > 3800:
                    cand = cand[:3800]
            elif op < 0.95 and len(cand) > 4:
                i = random.randrange(len(cand))
                del cand[i]
            else:
                # large perturbation
                cand = [x + random.randint(-3, 3) for x in cand]

            cand = list(set(cand))
            if len(cand) < 3:
                continue
            if time.time() > t_end:
                break

            s = _score(cand)
            if s >= cur_score:
                cur, cur_score = cand, s
                if s > bestloc_score:
                    bestloc, bestloc_score = cand[:], s
                    last_improve = time.time()
            else:
                # simulated-annealing style acceptance with occasional restarts
                if random.random() < 0.02:
                    cur, cur_score = cand, s

            if time.time() - last_improve > 25:
                # restart from best with big perturbation
                cur = bestloc[:]
                for _ in range(max(1, len(cur) // 10)):
                    i = random.randrange(len(cur))
                    cur[i] += random.randint(-20, 20)
                cur = list(set(cur))
                cur_score = _score(cur)
                last_improve = time.time()
        return bestloc, bestloc_score

    remaining = deadline - time.time()
    # We'll run several local searches with decreasing budgets, always keeping the global best.
    starts = [best]
    for s in seeds:
        s = sorted(set(s))
        starts.append(s)
    random.shuffle(starts)

    if not starts:
        starts = [best]

    per_time = max(2.0, (deadline - time.time()) / max(1, len(starts)))
    for st in starts:
        if time.time() > deadline - 1.0:
            break
        t_end = min(deadline, time.time() + per_time)
        res, rsc = local_search(st, t_end)
        if rsc > best_score:
            best, best_score = res, rsc

    # final polish: try to squeeze out a bit more
    while time.time() < deadline - 0.5:
        res, rsc = local_search(best, min(deadline, time.time() + 3.0))
        if rsc > best_score:
            best, best_score = res, rsc

    # ensure constraints
    best = sorted(set(best))
    best = [x if abs(x) <= 10**15 else max(-10**15, min(10**15, x)) for x in best]
    best = sorted(set(best))
    return best
