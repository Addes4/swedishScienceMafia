import math
import random
import time

def _score(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return 0.0
    diffs = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
    sums = set()
    for x in s:
        for y in s:
            sums.add(x + y)
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0

def solve():
    deadline = time.time() + 110

    # Candidate constructions. Geometric progressions A = {sum c_i * 2^{k_i}} type sets.
    # Use a "step-set" S of small integers, then A = {s * 2^j : s in S, j in range(J)}
    # This is like a sumset A = S + B where B = {0,1,2,...,J-1} scaled by 2^j doubling.
    # Actually use A = union of {base_i * 2^k} with varying base_i.

    best = None
    best_score = -1.0

    # Try many random interval/digit structures.
    candidates = []

    # 1) pure geometric progression scaled by small odd offsets
    for base in [1, 2, 3, 4, 5, 6, 7, 9, 11, 13]:
        for J in range(6, 22):
            A = [base * (1 << k) for k in range(J)]
            candidates.append(A)

    # 2) A = {a + b : a in small set S, b in geometric B}
    small_sets = [
        [0], [0, 1], [0, 1, 2], [0, 1, 3], [0, 2, 3],
        [0, 1, 2, 3], [0, 1, 2, 4], [0, 1, 3, 4], [0, 1, 2, 3, 4],
        [0, 1, 2, 3, 5], [0, 1, 2, 4, 8], [0, 1, 3, 9], [0, 2, 4, 6],
        [0, 1, 2, 3, 4, 5], [0, 1, 2, 4, 8, 16],
    ]
    for S in small_sets:
        for J in range(6, 22):
            A = []
            for s in S:
                for k in range(J):
                    A.append(s + (s + 1) * ((1 << k) - 1) if False else s + (1 << k))
            # Better: A = { s*2^k } style
            A2 = []
            for s in S:
                for k in range(J):
                    A2.append(s * (1 << k))
            if A2:
                candidates.append(A2)

    # 3) A = {2^k} together with some nearby values
    for J in range(6, 22):
        A = [1 << k for k in range(J)]
        # add small perturbations
        for k in range(J):
            A.append((1 << k) + 1)
            A.append((1 << k) - 1)
        candidates.append(A)

    # Deduplicate & score
    seen = set()
    for A in candidates:
        A = sorted(set(A))
        key = tuple(A)
        if key in seen:
            continue
        seen.add(key)
        if time.time() > deadline:
            break
        n = len(A)
        if n > 4000 or n < 2:
            continue
        if any(abs(x) > 10**15 for x in A):
            continue
        sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A

    # If nothing good found, fallback
    if best is None:
        best = [1 << k for k in range(16)]
        best_score = _score(best)

    # Local improvement: try adding points that increase diffs more than sums
    # But careful: adding points to A usually increases both.
    # The ratio is key. We try to add many points from 2A-ish structure.

    # Refinement: take best and try to add "doubling" points
    def try_add(A):
        A = set(A)
        n = len(A)
        if n < 2:
            return A
        # compute current stats approximately
        # Try adding points that are far from existing ones to maximize new diffs
        # But sumset grows too. Since ratio near 2, every new diff helps.
        bests = None
        bestloc = -1
        base_A = sorted(A)
        lo = min(base_A)
        hi = max(base_A)
        tried = set()
        # candidate new points: from scaling
        for x in base_A[:min(len(base_A), 50)]:
            for m in [2, 3, -2, -3]:
                cand = x * m
                if cand not in A and cand not in tried and abs(cand) <= 10**15:
                    tried.add(cand)
                    B = A | {cand}
                    sc = _score(list(B))
                    if sc > best_score * 0.9999:
                        return B
        return A

    # Try a targeted search: extend the best geometric-like set
    # Use the structure A = base * {2^k} plus shifts

    def measure(A):
        s = set(A)
        if len(s) < 2:
            return 0, 0
        diffs = set()
        for x in s:
            for y in s:
                diffs.add(x - y)
        sums = set()
        for x in s:
            for y in s:
                sums.add(x + y)
        return len(diffs), len(sums)

    # Hill-climb on the best structure by adding points
    if best is not None:
        cur = sorted(set(best))
        cur_score = _score(cur)
        improved = True
        rounds = 0
        while improved and time.time() < deadline and rounds < 200:
            improved = False
            rounds += 1
            n = len(cur)
            # generate candidate additions
            cands = set()
            # If cur is a geometric progression, next natural point:
            mx = max(cur)
            mn = min(cur)
            cands.add(2 * mx)
            cands.add(-2 * mn)
            cands.add(mx + mn)
            cands.add(mx - mn)
            # powers of two near max
            p = 1
            while p <= mx * 4:
                cands.add(p)
                cands.add(-p)
                p *= 2
            for c in list(cands):
                if c in set(cur) or abs(c) > 10**15:
                    cands.discard(c)
            best_c = None
            best_cs = cur_score
            for c in sorted(cands)[:200]:
                if time.time() > deadline:
                    break
                B = cur + [c]
                sB = _score(B)
                if sB > best_cs:
                    best_cs = sB
                    best_c = B
            if best_c is not None:
                cur = best_c
                cur_score = best_cs
                improved = True
        if cur_score > best_score:
            best = cur
            best_score = cur_score

    # Final: try to build a large set from the structure that maximizes ratio
    # Use a set S with minimal sumset, then scale by powers of 2.
    # A = { s + t : s in S0, t in T } where T is a Sidon-like or geometric set.
    # A - A contains (S0-S0) + (T-T), A + A contains (S0+S0) + (T+T).

    # For T = {2^0, 2^1, ..., 2^{J-1}}, |T+T| ~ J(J+1)/2 distinct sums if all distinct.
    # |T-T| is also large. The scaling by powers of 2 makes collisions rare.

    # Actually the best known: use A = {sum_{i=1}^{k} a_i 2^{i-1} : a_i in {0,1}} = all subsets sums = 0..2^k-1 (all integers), no.

    # Let's try another known construction: A = { 2^i : i=0..n-1 } has |A-A| ~ n^2 (all distinct mostly)
    # and |A+A| ~ n(n+1)/2 (all distinct sums mostly since binary). Ratio ~ 2.
    # To do better: A = { 2^i } U { -2^i }? Then |A-A| has more but |A+A| also.

    # Try A = Minkowski-like: A = B + C where B = powers of 2, C small.
    # B = {2^i}, C = {0,1,...,c-1}. Then A = {2^i + j}. |A| = n*c.
    # A - A = (B-B) + (C-C). |B-B| ~ n^2, |C-C| ~ 2c-1, so ~ 2 c n^2.
    # A + A = (B+B) + (C+C), |B+B| ~ n^2/2? Actually B+B = {2^i + 2^j} ~ n(n+1)/2 distinct.
    # |C+C| = 2c-1. So |A+A| ~ (n(n+1)/2)*(2c-1) roughly if no collisions.
    # Ratio ~ log(2 c n^2)/log(c n^2) ~ 1 + log2/log(c n^2), decreasing. Not better.

    # Best: maximize |A-A| relative to |A+A|. Can get close to 2? Known: |A-A| >= |A+A|? Actually |A-A| >= |A+A| - 1.
    # For A = geometric, ratio tends to log(n^2)/log(n^2/2) -> slightly > 1? Wait log(n^2)/log(n^2/2) = 2log n/(2 log n - log2) > 1.
    # As n -> inf, ratio -> 1. Hmm but we want high ratio.
    # Actually |A-A| max is n(n-1)+1, |A+A| min is 2n-1 (arithmetic progression).
    # So ideal ratio: log(n^2)/log(2n) ~ 2. So we want |A+A| as small as possible, i.e., A close to arithmetic progression.
    # But then |A-A| = 2n-1 too, ratio = 1. Trade-off.

    # Compromise: A = union of short arithmetic progressions with large offsets.
    # A = { i : i in 0..m-1 } U { i + D : i in 0..m-1 } with D large.
    # |A| = 2m. A+A = {0..2m-2} U {D..D+2m-2} U {D..D+2m-2} same shifted. Actually A+A = sums from both parts:
    # {0..2m-2}, {D..D+2m-2}, {D..D+2m-2} (cross). So |A+A| = (2m-1) + (2m-1) + (2m-1) if separated.
    # |A-A| = differences: {-(m-1)..m-1} (2m-1), {D-(m-1)..D+(m-1)} (2m-1), {D-(m-1)..D+(m-1)} same.
    # Actually A-A = {a-b}. From same group: 2m-1 values. From cross: D + (i - j), range D-(m-1) to D+(m-1): 2m-1 values.
    # So |A-A| ~ 4m, |A+A| ~ 6m if separated. Ratio log(4m)/log(6m) < 1. Bad.

    # Use many groups: A = union_{k=1}^{g} {k*D + i : i in 0..m-1}.
    # |A| = g*m.
    # A+A = {(k1+k2)*D + i+j}: for k1+k2 = s, range s*D + [0, 2m-2]. If D > 2m, these are separated.
    # s ranges 2..2g (if k from 1 to g), so 2g-1 values of s. |A+A| = (2g-1)*(2m-1).
    # A-A = {(k1-k2)*D + i-j}: k1-k2 ranges -(g-1)..(g-1): 2g-1 values. Range |i-j| <= m-1, so offset range -(m-1)..(m-1).
    # If D > 2m, these are separated. |A-A| = (2g-1)*(2m-1). Same! Ratio = 1. Hmm.

    # The trick: make sums collide more than diffs.
    # E.g., many pairs (k1,i),(k2,j) giving same sum but distinct diff.
    # Symmetric structure: A = {x} U {-x}. Then sum x + (-x) = 0, many collisions!
    # A+A has many zeros.
    # Let's try A = S U -S where S = geometric progression.
    # |A| = 2n (if 0 not in S). A+A = (S+S) U (S-S) U (-S-S). Actually elements: s1+s2, s1-s2, -s1-s2, -s1+s2.
    # = (S+S) U (S-S) U -(S+S). |S+S| ~ n^2/2? |S-S| ~ n^2. So |A+A| ~ n^2 + n^2 = 2n^2.
    # A-A = (S-S) U (S+(-S)) ... A-A = {a-b}. a,b in S or -S.
    # = (S-S) U (S-(-S)) U (-S-S) U (-S-(-S)) = (S-S) U (S+S) U -(S+S) U (S-S) = same as A+A?
    # No: (S-S) U (S+S) U -(S+S) U -(S-S). |S-S| ~ n^2, |S+S| ~ n^2/2, so |A-A| ~ 3n^2?
    # Hmm not clearly better.

    # Known result: There exist sets with |A+A| = |A|^2/4 and |A-A| = |A|^2. But ratio -> 1.

    # To get ratio > 1, need |A-A| > |A+A|, which is typical.
    # For random set in [1,N], |A-A| ~ N, |A+A| ~ N, ratio ~ 1.
    # Best known lower bound for ratio is around 1.5? Actually the ratio log|A-A|/log|A+A| can be at most 2.

    # Let's just search numerically to find good sets, starting from known good ones.

    # A good candidate: A = {0,1,3,7,15,...} (Sylow?)
    # A = {2^i - 1}.

    # Try A = {2^i - 1 : i=1..n}: 1,3,7,15,31. |A| = n.
    # A+A = {2^i+2^j-2} = 2*(2^{i-1}+2^{j-1}-1). Number of distinct values ~ n^2/2 (i<=j).
    # A-A = {2^i - 2^j} = 2^j*(2^{i-j}-1). Distinct count?
    # Could be more or less. Let's just compute and trust search.

    # Try A = {2^i + i}
    # Do a random search over families and parameters, pick best.

    random.seed(12345)

    # Parameters for structured families
    families = []

    # Family F1: A = {a_i} with a_i = c * 2^i, i in range(n)
    for c in [1, 2, 3, 4, 5, 6, 7, 9, 11, 13, 15, 17, 19, 21, 23]:
        pass

    # Family F2: A = {2^i - 1}
    for n in range(6, 24):
        A = [(1 << i) - 1 for i in range(1, n + 1)]
        families.append(A)

    # Family F3: A = {2^i + 1}
    for n in range(6, 24):
        A = [(1 << i) + 1 for i in range(1, n + 1)]
        families.append(A)

    # Family F4: A = {2^i, -2^i}
    for n in range(4, 18):
        A = []
        for i in range(n):
            A.append(1 << i)
            A.append(-(1 << i))
        families.append(A)

    # Family F5: A = {2^i} U {0}
    for n in range(2, 22):
        A = [0] + [(1 << i) for i in range(n)]
        families.append(A)

    # Family F6: A = {2^i - 1} U {0}
    for n in range(2, 22):
        A = [0] + [(1 << i) - 1 for i in range(1, n + 1)]
        families.append(A)

    # Family F7: A = {2^i * 3^j}? too big
    # Family F8: A = {2^i + 2^j for i < j}: |A| ~ n^2/2, maybe too many
    # skip

    # Family F9: A = {a * 2^i + b : i=0..n-1} for small a,b
    for a in [1, 2, 3]:
        for b in [-2, -1, 0, 1, 2]:
            for n in range(6, 20):
                A = [a * (1 << i) + b for i in range(n)]
                families.append(A)

    # Family F10: A = {a*2^i} U {b*2^i} for small a,b
    for a in [1, 2, 3, 5]:
        for b in [1, 2, 3, 5, 7]:
            if a == b:
                continue
            for n in range(4, 16):
                A = [a * (1 << i) for i in range(n)] + [b * (1 << i) for i in range(n)]
                families.append(A)

    # Family F11: A = {2^i} U {2^i + 1} U {2^i + 2}
    for n in range(4, 16):
        A = []
        for i in range(n):
            for j in range(3):
                A.append((1 << i) + j)
        families.append(A)

    # Family F12: A = {2^i - c : i, c small}
    for c in [1, 2, 3]:
        for n in range(4, 18):
            A = []
            for i in range(n):
                for j in range(c):
                    A.append((1 << i) - j)
            families.append(A)

    best_fam_score = -1.0
    best_fam = None
    for A in families:
        if time.time() > deadline:
            break
        A = sorted(set(A))
        if len(A) < 2 or len(A) > 4000:
            continue
        if any(abs(x) > 10**15 for x in A):
            continue
        sc = _score(A)
        if sc > best_fam_score:
            best_fam_score = sc
            best_fam = A

    if best_fam is not None and best_fam_score > best_score:
        best = best_fam
        best_score = best_fam_score

    # Random local search to polish
    if best is not None:
        cur = best[:]
        cur_score = _score(cur)
        start = time.time()
        # hill climb with random mutations
        while time.time() < deadline - 2:
            cand = cur[:]
            op = random.random()
            if op < 0.4:
                # change an element
                i = random.randrange(len(cand))
                cand[i] += random.choice([-2, -1, 1, 2, -3, 3, -4, 4])
            elif op < 0.7:
                # add a point near max
                cand.append(max(cand) * 2)
            else:
                # add a point from doubling
                if len(cand) > 0:
                    cand.append(-max(cand) * 2)
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 4000:
                continue
            if any(abs(x) > 10**15 for x in cand):
                continue
            sc = _score(cand)
            if sc > cur_score:
                cur = cand
                cur_score = sc
                if sc > best_score:
                    best = cand[:]
                    best_score = sc

    return sorted(set(best))


if __name__ == "__main__":
    print(solve()[:50])
