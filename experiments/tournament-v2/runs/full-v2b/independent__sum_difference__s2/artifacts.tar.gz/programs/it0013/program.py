import math, random, time

def _counts(a):
    # a: list of ints, return (|A-A|, |A+A|) exactly using sorted-based counting
    s = sorted(a)
    diffs = size_diff(s)
    sums = size_sum(s)
    return diffs, sums

def size_diff(s):
    # count distinct differences a-b for sorted s, via convolution-ish: use set of pairwise for moderate n
    n = len(s)
    if n <= 1200:
        d = set()
        for i in range(n):
            si = s[i]
            for j in range(n):
                d.add(si - s[j])
        return len(d)
    # for large n, differences likely many; use bitset-ish via set (could be big) - fallback
    d = set()
    for i in range(n):
        si = s[i]
        for j in range(n):
            d.add(si - s[j])
    return len(d)

def size_sum(s):
    n = len(s)
    d = set()
    for i in range(n):
        si = s[i]
        for j in range(n):
            d.add(si + s[j])
    return len(d)

def _score_vals(nd, ns, n):
    if ns <= 1 or nd <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / max(n,2)) / 100

def _make(n):
    # base arithmetic progression
    a = list(range(n))
    return a

def solve():
    random.seed(12345)
    deadline = time.time() + 110.0
    best = None
    best_sc = -1.0
    # try several constructions quickly with moderate n
    def eval_set(a):
        dd = set()
        ss = set()
        for x in a:
            for y in a:
                dd.add(x - y)
                ss.add(x + y)
        sc = _score_vals(len(dd), len(ss), len(a))
        return sc, len(dd), len(ss)

    # Construction family: A = {i for i in 0..n-1} shifted blocks far apart
    # i.e. block j placed at offset C*j, but with C large the sums still collide modestly.
    # Actually intervals far apart give |A+A| ~ 2 * sum of block pair sums.
    # We'll instead do greedy: start AP, then add outlier points that maximize ratio.

    def ratio_of(a):
        dd = set(); ss = set()
        for x in a:
            for y in a:
                dd.add(x - y); ss.add(x + y)
        if len(ss) < 2: return 0.0, len(dd), len(ss)
        return math.log(len(dd))/math.log(len(ss)), len(dd), len(ss)

    # base candidates
    for n in [6, 8, 10, 12, 15, 20, 25, 30, 40]:
        a = list(range(n))
        # spread: push each element by growing gap to increase diffs without exploding sums
        # use geometric-ish gaps but then sums blow up; instead use modular-like spread
        sc, nd, ns = ratio_of(a)
        base_sc = sc + (1 - 1/n)/100
        if base_sc > best_sc:
            best_sc = base_sc; best = a[:]
        # try randomized perturbations
        for _ in range(200):
            cand = list(range(n))
            for i in range(n):
                cand[i] += random.randint(-2, 2)
            cand = sorted(set(cand))
            if len(cand) < 2: continue
            sc2, nd2, ns2 = ratio_of(cand)
            sc2 += (1 - 1/len(cand))/100
            if sc2 > best_sc:
                best_sc = sc2; best = cand[:]
            if time.time() > deadline: break
        if time.time() > deadline: break

    # local search: modify best
    cur = best[:]
    cur_sc = best_sc
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.55:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1,1,-2,2,-3,3])
            cand = sorted(set(cand))
        elif op < 0.8:
            cand.append(random.randint(-len(cand)*4, len(cand)*4))
            cand = sorted(set(cand))
        else:
            if len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue
        sc, nd, ns = ratio_of(cand)
        sc += (1 - 1/len(cand))/100
        if sc > cur_sc or random.random() < 0.005:
            cur = cand[:]
            cur_sc = sc
            if sc > best_sc:
                best_sc = sc; best = cand[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(int(x) for x in best))
