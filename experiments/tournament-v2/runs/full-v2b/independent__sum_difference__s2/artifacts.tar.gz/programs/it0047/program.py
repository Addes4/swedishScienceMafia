import math
import random
import time


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0, 0, 0
    s = set(a)
    diffs = len({x - y for x in s for y in s})
    sums = len({x + y for x in s for y in s})
    if sums == 0:
        return 0.0, diffs, sums
    return math.log(diffs) / math.log(sums), diffs, sums


def _bonus(n):
    return (1 - 1.0 / n) / 100.0 if n > 0 else 0.0


def solve():
    random.seed(12345)
    deadline = time.time() + 115

    # Start from a strong known construction: powers times a factor.
    # A "geometric-ish" set with base ~ 3 gives |A+A| ~ n^2/2, |A-A| ~ n^2.
    best = None
    best_val = -1.0

    candidates = []

    # Candidate 1: powers of 2 scaled
    for n in [10, 14, 18, 22, 26, 30, 34, 40]:
        a = [1 << i for i in range(n)]
        candidates.append(a)

    # Candidate 2: powers of 3
    for n in [8, 11, 14, 17, 20, 24]:
        a = [3 ** i for i in range(n)]
        candidates.append(a)

    # Candidate 3: {0} U powers of m
    for m in [4, 5, 6]:
        for n in [8, 11, 14, 17, 20]:
            a = [0] + [m ** i for i in range(n)]
            candidates.append(a)

    # Candidate 4: base b with subset-sum style (small multipliers on powers)
    for m in [3, 4, 5]:
        n = 16
        a = [sum(m ** j for j in range(k + 1)) for k in range(n)]
        candidates.append(a)

    # Candidate 5: random subset of powers scaled to sum-free-ish via base
    for trial in range(20):
        m = random.choice([3, 4, 5, 6])
        n = random.randint(10, 20)
        a = set()
        for i in range(n):
            a.add(random.randint(1, m) * (m ** i))
        candidates.append(list(a))

    for a in candidates:
        a = sorted(set(a))
        v = _score(a)[0] + _bonus(len(a))
        if v > best_val:
            best_val = v
            best = a[:]

    # Local search / simulated annealing
    cur = best[:]
    cur_val = _score(cur)[0] + _bonus(len(cur))
    best = cur[:]
    best_val = cur_val

    # Improve by adaptive mutations on integer values
    scale = max(1, max(abs(x) for x in cur) // 10 + 1)
    step_scale = max(1, scale // 100)

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()

        if op < 0.55:
            # perturb one element
            i = random.randrange(len(cand))
            delta = random.randint(-step_scale, step_scale)
            cand[i] += delta
        elif op < 0.75:
            # perturb several elements
            k = random.randint(1, max(1, len(cand) // 4))
            for _ in range(k):
                i = random.randrange(len(cand))
                cand[i] += random.randint(-step_scale, step_scale)
        elif op < 0.85 and len(cand) > 3:
            # remove one
            del cand[random.randrange(len(cand))]
        elif op < 0.95 and len(cand) < 2000:
            # insert one
            if cand:
                base = random.choice(cand)
                cand.append(base + random.randint(-step_scale * 10, step_scale * 10))
            else:
                cand.append(random.randint(1, 1000))
        else:
            # global perturbation
            cand = [x + random.randint(-step_scale * 5, step_scale * 5) for x in cand]

        cand = list(set(cand))
        if not cand:
            continue
        # clamp magnitudes
        cand = [x for x in cand if abs(x) <= 10**15]
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            cand = cand[:4000]

        v = _score(cand)[0] + _bonus(len(cand))
        if v > best_val:
            best_val = v
            best = cand[:]
            cur = cand[:]
        elif v >= cur_val or random.random() < 0.001:
            cur = cand[:]
            cur_val = v
        elif random.random() < 0.05:
            cur = best[:]
            cur_val = best_val

    return sorted(set(best))
