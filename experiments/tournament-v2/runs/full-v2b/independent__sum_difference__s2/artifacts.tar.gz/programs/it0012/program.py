import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 1, 1
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            if i != j:
                diffs.add(ai - a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


def _make_base(length, span):
    # Golomb-ruler-like dense set with many distinct differences and relatively small diameter.
    vals = [0]
    while len(vals) < length:
        best_x = None
        best_new = -1
        best_diam = None
        for _ in range(120):
            x = random.randint(1, span)
            if x in vals:
                continue
            ds = {abs(x - y) for y in vals}
            # favor many new differences per added element, then smaller spread
            newcnt = len(ds - {abs(u - v) for u in vals for v in vals})
            diam = max(max(vals), x) - min(min(vals), x)
            if newcnt > best_new or (newcnt == best_new and (best_diam is None or diam < best_diam)):
                best_new = newcnt
                best_x = x
                best_diam = diam
        if best_x is None:
            best_x = random.randint(1, span)
        vals.append(best_x)
    vals = sorted(set(vals))
    return vals


def _greedy_small_sum_block(n, limit=2000):
    # Build a set whose pairwise sums are as concentrated as possible.
    # A short arithmetic progression is excellent for small sum set, and adding
    # elements near the middle can still create extra differences.
    best = list(range(n))
    best_score = _score(best)
    deadline = time.time() + 35
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.55:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-4, 4)
            cand = sorted(set(cand))
        elif op < 0.8:
            x = random.randint(-limit, limit)
            if x not in cand:
                cand.append(x)
                cand = sorted(set(cand))
        else:
            if len(cand) > 4:
                del cand[random.randrange(len(cand))]
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc >= best_score:
            best, best_score, cur = cand[:], sc, cand
        elif random.random() < 0.12:
            cur = best[:]
    return best


def solve():
    best = [0, 1, 3, 7, 12, 20, 30, 44]
    best_score, _, _ = _stats(best)
    deadline = time.time() + 110

    # Candidate family 1: dense short arithmetic progression plus a few outliers.
    cands = []
    for n in (8, 10, 12, 14, 16, 20, 24, 30, 36, 44, 52, 60, 72, 84):
        base = list(range(n))
        cands.append(base)
        for k in (1, 2, 3):
            b = [x * k for x in base]
            cands.append(b)

    # Candidate family 2: union of arithmetic progression and a far-shifted block.
    for n in (10, 16, 24, 32, 48, 64):
        for shift in (100, 300, 1000, 3000, 10000, 30000, 100000):
            for m in (2, 4, 6, 8, 12):
                cand = list(range(n)) + [shift + 3 * j for j in range(m)]
                cands.append(cand)

    # Candidate family 3: Sidon/Golomb-like sets.
    for n in (10, 16, 24, 32, 48, 64, 96, 128):
        cands.append(_make_base(n, max(20, n * n // 2)))

    for c in cands:
        if len(c) >= 2:
            sc, _, _ = _stats(c)
            if sc > best_score:
                best, best_score = c[:], sc

    # Fast local search on the current best, with two mutation regimes:
    # small local tweaks, and adding/bridging elements to increase differences.
    cur = best[:]
    last_improve = time.time()
    while time.time() < deadline:
        sc_cur, d_cur, s_cur = _stats(cur)
        cand = cur[:]
        r = random.random()
        if r < 0.62:
            i = random.randrange(len(cand))
            step = random.choice([-10, -5, -3, -2, -1, 1, 2, 3, 5, 10])
            cand[i] += step
        elif r < 0.80:
            x = random.randint(-200000, 200000)
            if x not in cand:
                cand.append(x)
        elif r < 0.92:
            if len(cand) > 4:
                del cand[random.randrange(len(cand))]
        else:
            # make a larger structured perturbation: shift a whole subset/block
            if len(cand) >= 4:
                lo = random.randrange(len(cand))
                hi = random.randrange(lo + 1, len(cand) + 1)
                delta = random.choice([-50, -20, -10, -5, 5, 10, 20, 50])
                for i in range(lo, hi):
                    cand[i] += delta
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        sc, _, _ = _stats(cand)
        if sc >= best_score:
            best, best_score, cur = cand[:], sc, cand
            last_improve = time.time()
        elif sc > sc_cur or random.random() < 0.08:
            cur = cand
        if time.time() - last_improve > 24:
            cur = best[:]
            last_improve = time.time()

    # Final aggressive cleanup: try removing elements that barely affect differences
    improved = True
    while improved and time.time() < deadline:
        improved = False
        cur = best[:]
        for i in range(len(cur)):
            if time.time() >= deadline:
                break
            cand = cur[:i] + cur[i + 1:]
            if len(cand) < 2:
                continue
            sc, _, _ = _stats(cand)
            if sc >= best_score:
                best, best_score = cand[:], sc
                improved = True
                break

    return sorted(set(best))
