import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if not diffs or not sums:
        return -1.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def greedy_modular(n, modulus, max_abs=10**15):
    """Greedy construction: pick residues so that differences are all distinct mod m,
    which tends to give large difference sets with small sum sets."""
    if modulus < n:
        modulus = n
    chosen = [0]
    used_diffs = {0}
    # try to add numbers that create new differences mod modulus
    candidates = list(range(1, min(modulus, 2000)))
    random.shuffle(candidates)
    for c in candidates:
        if len(chosen) >= n:
            break
        new_diffs = set()
        ok = True
        for x in chosen:
            d1 = (c - x) % modulus
            d2 = (x - c) % modulus
            if d1 in used_diffs or d2 in used_diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            chosen.append(c)
            used_diffs |= new_diffs
    return chosen


def greedy_interval(n, span=100000):
    """Pick integers with huge spread to maximize distinct differences."""
    a = []
    used = set()
    # Use a Sidon-like greedy: pick x so all x - a_i distinct and x + a_i distinct
    for _ in range(n):
        best_c = None
        best_gain = -1
        for _try in range(200):
            c = random.randint(-span, span)
            if c in used:
                continue
            gain = 0
            new_d = 0
            new_s = 0
            for x in a:
                if (c - x) not in used:
                    new_d += 1
                if (c + x) not in used:
                    new_s += 1
            gain = new_d - 0.5 * new_s
            if gain > best_gain:
                best_gain = gain
                best_c = c
        if best_c is not None:
            a.append(best_c)
            used.add(best_c)
            for x in a:
                used.add(best_c - x)
                used.add(best_c + x)
    return a


def shift_to_positive(a):
    if not a:
        return a
    mn = min(a)
    if mn < 0:
        a = [x - mn for x in a]
    # keep within 1e15
    mx = max(a)
    if mx > 10**15:
        # compress
        scale = 10**15 / mx
        a = [int(x * scale) for x in a]
    return a


def local_search(a, deadline, max_iters=10**7):
    a = list(set(a))
    best = a[:]
    best_score = _score(best)
    cur = a[:]
    cur_score = best_score
    it = 0
    temp = 0.05
    while time.time() < deadline and it < max_iters:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.6 and len(cand) > 3:
            i = random.randrange(len(cand))
            delta = random.randint(-5, 5)
            if delta == 0:
                delta = 1
            cand[i] += delta
        elif op < 0.85:
            cand.append(random.randint(-100, 100))
        elif len(cand) > 3:
            i = random.randrange(len(cand))
            del cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        cs = _score(cand)
        if cs >= cur_score or random.random() < math.exp((cs - cur_score) / max(temp, 1e-9)):
            cur = cand
            cur_score = cs
            if cs > best_score:
                best = cand[:]
                best_score = cs
        if it % 5000 == 0:
            temp *= 0.999
    return best, best_score


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Strategy 1: greedy modular sets
    for n in [50, 100, 200, 400, 800, 1200, 2000]:
        for m in [n * 2, n * 3, n * 5, n * 7, 4000]:
            if time.time() > deadline - 5:
                break
            a = greedy_modular(n, max(m, n + 1))
            if len(a) >= 2:
                a = shift_to_positive(a)
                s = _score(a)
                if s > best_score:
                    best_score = s
                    best = a[:]
        if time.time() > deadline - 5:
            break

    # Strategy 2: greedy interval / Sidon-like
    for n in [30, 60, 100, 200, 400]:
        if time.time() > deadline - 10:
            break
        for _ in range(3):
            a = greedy_interval(n, span=10**6)
            a = shift_to_positive(a)
            if len(a) >= 2:
                s = _score(a)
                if s > best_score:
                    best_score = s
                    best = a[:]

    # Strategy 3: local search refinement
    if best is None:
        best = list(range(1, 30))
        best_score = _score(best)

    # try local search from several seeds
    seeds = [best]
    seeds.append(list(range(1, 200)))
    seeds.append([i * i for i in range(1, 50)])
    seeds.append([2**i for i in range(1, 20)])

    for seed in seeds:
        if time.time() > deadline - 15:
            break
        a, s = local_search(seed, min(deadline, time.time() + 15))
        if s > best_score:
            best_score = s
            best = a[:]

    # final refinement
    if time.time() < deadline - 2:
        a, s = local_search(best, deadline - 1)
        if s > best_score:
            best_score = s
            best = a[:]

    best = list(set(best))
    if len(best) < 2:
        best = [0, 1]

    # ensure bounds
    mn = min(best)
    if mn < 0:
        best = [x - mn for x in best]
    mx = max(best)
    if mx > 10**15:
        scale = (10**15 - 1) / mx
        best = sorted(set(int(x * scale) for x in best))

    return best
