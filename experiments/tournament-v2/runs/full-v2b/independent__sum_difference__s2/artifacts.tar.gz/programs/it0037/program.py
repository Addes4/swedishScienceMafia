import math
import time
import random

def _stats(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return 0.0, len(diffs), len(sums)

def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _score_fast(diffs_n, sums_n, n):
    return math.log(diffs_n) / math.log(sums_n) + (1 - 1 / n) / 100

def solve():
    # Powers of 2 construction: A = {2^0, 2^1, ..., 2^(n-1)}
    # Differences are all distinct (Sidon-like), sums have limited structure.
    best = None
    best_score = -1.0

    # Try various sizes
    n_max = 4000
    # powers of 2 up to 2^49 fits in 1e15 (2^49 ~ 5.6e14)
    max_bits = 50
    candidates = []
    for n in [40, 60, 80, 100, 120, 150, 180, 200, 250, 300, 350, 400, 500, 600, 700, 800, 900, 1000, 1200, 1500, 2000, 2500, 3000, 3500, 4000]:
        n = min(n, max_bits)
        if n < 2:
            continue
        candidates.append([1 << i for i in range(n)])

    for cand in candidates:
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand

    # For powers of 2: differences are all distinct: |A-A| = n^2-n+1
    # sums: 2^i + 2^j for i<=j... actually all sums 2^i+2^j with i<j give distinct binary popcount 2,
    # and 2^(i+1) = 2^i + 2^i. So sums count = C(n,2) + n (diagonal gives n distinct values 2^(i+1))
    # Actually diagonal 2^i+2^i = 2^(i+1) collides with the element 2^(i+1) which is 2^(i+1)+? no.
    # Let's just trust computation.

    # Local search refinement around best
    deadline = time.time() + 100
    cur = best[:]
    cur_set = set(cur)

    def fast_score(a):
        a = set(a)
        n = len(a)
        if n < 2:
            return -1, 0, 0
        sums = set()
        diffs = set()
        la = list(a)
        for i in range(n):
            ai = la[i]
            for j in range(i, n):
                sums.add(ai + la[j])
                diffs.add(ai - la[j])
                diffs.add(la[j] - ai)
        return fast_score_val(len(diffs), len(sums), n), len(diffs), len(sums)

    def fast_score_val(dn, sn, n):
        if sn < 2:
            return -1
        return math.log(dn) / math.log(sn) + (1 - 1 / n) / 100

    # perturbation search on moderate size set
    target_size = min(len(best), 4000)
    cur = best[:]

    # Score current
    def full_score(a):
        a = set(a)
        n = len(a)
        if n < 2:
            return -1.0
        sums = set()
        diffs = set()
        la = list(a)
        for i in range(n):
            ai = la[i]
            for j in range(i, n):
                sums.add(ai + la[j])
                diffs.add(ai - la[j])
                diffs.add(la[j] - ai)
        return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

    cur_score = full_score(cur)
    if cur_score > best_score:
        best_score = cur_score
        best = cur[:]

    # Try large sets with structural tweaks: use powers of 2 but scale/shift
    # Also try Sidon-like sets: A = {2^i} shifted. Already good.

    # Simple local search: modify a few elements
    it = 0
    while time.time() < deadline:
        it += 1
        cand = best[:]
        # random perturbation
        k = random.randint(1, 3)
        for _ in range(k):
            if not cand:
                break
            i = random.randrange(len(cand))
            delta = random.choice([1, -1, 2, -2, 3, -3, 5, -5])
            cand[i] += delta
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = full_score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    return sorted(set(best))
