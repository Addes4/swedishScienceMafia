"""Maximize log|A-A|/log|A+A|.

Key idea: both |A-A| and |A+A| are at most n^2 and at least 2n-1.  The ratio
log|A-A|/log|A+A| is maximized when |A-A| -> n^2 and |A+A| is as small as
possible.  A Sidon set (all pairwise sums distinct, equivalently all pairwise
differences distinct) achieves |A+A| = n(n+1)/2 and |A-A| = n(n-1)+1, both
quadratic, giving ratio -> 2.  To push |A-A| toward n^2 while keeping |A+A|
from growing, we use a Sidon set: differences are as large as possible and
many sums still coincide/shift.  We build a large Sidon set quickly using the
classical greedy construction over a modular/integer range, then trim/keep the
best-scoring variant within the time budget.
"""
import math
import time

# Limit for set size and magnitude
MAXN = 4000
MAXV = 10**15


def _diff_size(a):
    n = len(a)
    d = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            d.add(ai - a[j])
    return len(d)


def _sum_size(a):
    n = len(a)
    s = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            s.add(ai + a[j])
    return len(s)


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    dd = _diff_size(a)
    ss = _sum_size(a)
    if ss < 2:
        ss = 2
    return math.log(dd) / math.log(ss) + (1 - 1 / n) / 100


def _sidon_greedy(limit_n, deadline):
    """Greedy Sidon set: each new element's differences with existing elements
    must be new.  This yields a B_2 set with quadratic difference set."""
    a = [0]
    diff = {0}
    v = 1
    while len(a) < limit_n and time.time() < deadline:
        # try candidate v
        ok = True
        newd = set()
        for x in a:
            d1 = v - x
            d2 = x - v
            if d1 in diff or d1 in newd or d2 in diff or d2 in newd:
                ok = False
                break
            newd.add(d1)
            newd.add(d2)
        if ok:
            a.append(v)
            diff |= newd
        v += 1
        if v > MAXV:
            break
    return a


def _mod_sidon(n, p):
    """A Sidon set in Z_p (each difference at most once) then lift to integers.
    Uses the standard construction {(2pk + k^2) mod p^2} style; here we use a
    Bezout/Singer-like simple quadratic set of size ~sqrt(p)."""
    # Simple: {2*p*i + (i*i) % p} for i in range(n) is often Sidon-like for small n.
    res = []
    seen = set()
    for i in range(n):
        x = i
        y = (i * i) % p
        val = x * p + y
        if val not in seen:
            seen.add(val)
            res.append(val)
    return res


def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # 1) Direct greedy Sidon set up to MAXN (fast for a few thousand).
    a = _sidon_greedy(MAXN, time.time() + 90)
    if len(a) >= 2:
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # 2) Try modular Sidon-style sets of various sizes; centered to reduce sums,
    #    keeping magnitude bounded.
    for n in (500, 1000, 1500, 2000, 2500, 3000, 3500, 4000):
        if time.time() > deadline:
            break
        p = int(math.isqrt(n)) + 1
        if p < 2:
            continue
        cand = _mod_sidon(n, p * p + p)
        # keep distinct, within range
        cand = sorted(set(x for x in cand if abs(x) <= MAXV))[:MAXN]
        if len(cand) < 2:
            continue
        if time.time() > deadline:
            break
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    if best is None:
        best = [0, 1]

    best = sorted(set(best))[:MAXN]
    # Ensure all within bounds
    best = [x for x in best if abs(x) <= MAXV]
    if len(best) < 2:
        best = [0, 1]
    return best
