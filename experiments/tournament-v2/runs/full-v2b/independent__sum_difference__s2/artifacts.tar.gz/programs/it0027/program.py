import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    d = len(diffs)
    s = len(sums)
    if s <= 1:
        return d, s, 0.0
    return d, s, math.log(d) / math.log(s)


def _score(a):
    d, s, r = _stats(a)
    n = len(set(a))
    if n < 2:
        return 0.0
    return r + (1 - 1.0 / n) / 100.0


def _anneal(n, budget, rng):
    # initial set: random distinct integers in a moderate range
    span = max(6, n * 3)
    cur = rng.sample(range(0, span), n)
    d, s, r = _stats(cur)
    if s <= 1:
        return cur, -1.0
    best = cur[:]
    # score without bonus for comparison of ratio; add bonus lightly
    def sc(vals):
        dd, ss, rr = _stats(vals)
        k = len(set(vals))
        if ss <= 1 or k < 2:
            return -1.0
        return math.log(dd) / math.log(ss) + (1 - 1.0 / k) / 100.0

    cur_score = sc(cur)
    best_score = cur_score
    steps = 0
    while steps < budget:
        steps += 1
        cand = cur[:]
        i = rng.randrange(n)
        op = rng.random()
        if op < 0.6:
            cand[i] += rng.randint(-2, 2)
        elif op < 0.85:
            cand[i] = rng.randint(min(cur) - 3, max(cur) + 3)
        else:
            # shift whole set
            shift = rng.randint(-3, 3)
            cand = [x + shift for x in cand]
        cs = sc(cand)
        if cs >= cur_score or rng.random() < 0.02:
            cur = cand
            cur_score = cs
            if cs > best_score:
                best_score = cs
                best = cand[:]
    return best, best_score


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 115.0
    best = [0, 1, 4, 6]
    best_s = _score(best)
    best_has_bonus = best_s

    # structured candidates: Sidon-like construction (Mian-Chowla greedy)
    def mian_chowla(limit):
        s = [1]
        used = {2}
        while len(s) < limit:
            c = s[-1] + 1
            while True:
                ok = True
                for x in s:
                    if c + x in used or c - x in used:
                        ok = False
                        break
                if ok:
                    break
                c += 1
            for x in s:
                used.add(c + x)
                used.add(c - x)
            used.add(2 * c)
            s.append(c)
        return s

    for n in (3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 30, 50, 80):
        try:
            sid = mian_chowla(n)
        except Exception:
            continue
        # normalize
        mn = min(sid)
        cand = sorted(x - mn for x in sid)
        scv = _score(cand)
        if scv > best_has_bonus:
            best_has_bonus = scv
            best = cand

    # main search over sizes
    sizes = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 25, 28, 32]
    idx = 0
    while time.time() < deadline:
        n = sizes[idx % len(sizes)]
        idx += 1
        cand, cscore = _anneal(n, 4000, rng)
        # compute true score with bonus
        d, s, r = _stats(cand)
        k = len(set(cand))
        if s <= 1 or k < 2:
            continue
        val = math.log(d) / math.log(s) + (1 - 1.0 / k) / 100.0
        if val > best_has_bonus:
            best_has_bonus = val
            best = sorted(set(cand))
        if time.time() >= deadline:
            break

    return sorted(set(best))
