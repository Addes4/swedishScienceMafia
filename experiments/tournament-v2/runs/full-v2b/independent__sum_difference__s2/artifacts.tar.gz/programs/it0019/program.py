import math
import time
import random


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small.

    Idea: use an arithmetic progression with a huge common difference d. Then all
    pairwise differences are distinct (|A-A| = n^2 - n + 1), while sums take only
    about 2n-1 distinct values. The ratio approaches log(n^2)/log(2n) -> 2 as n grows,
    and d must be larger than n*max_index to guarantee distinctness of sums tracking.
    """
    deadline = time.time() + 110
    best_score = -1.0
    best = None

    # Base configuration: arithmetic progression a + i*d for i in [0, n-1].
    # n up to 4000. d large enough so differences are all distinct: with indices
    # 0..n-1, differences of indices range in (-(n-1), n-1), scaled by d, so any d>0
    # already makes differences distinct since index differences map bijectively.
    # BUT sums of different index pairs could collide only if same sum of indices:
    # (i+j) -> 2a + (i+j)d. Distinct i+j give distinct sums when d>0. Number of
    # distinct i+j is 2n-1. So |A+A| = 2n-1 always. |A-A| = n^2-n+1. Great.

    candidates = []
    for n in [4000, 3990, 3950, 3900, 3800, 3700, 3600, 3500, 3000, 2500, 2000, 1500, 1000]:
        candidates.append(n)

    for n in candidates:
        if time.time() > deadline:
            break
        # Try to find the optimal n by exact formula plus small perturbation search.
        # |A-A| = n^2 - n + 1, |A+A| = 2n - 1.
        # score = log(n^2-n+1)/log(2n-1) + (1-1/n)/100
        for d in [1, 2, 3]:
            a = [i * d for i in range(n)]
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a

    # Fine local search around best using small perturbations to try to nudge score.
    # Use random offsets added to each element to attempt to break sum collisions
    # further (can't improve ratio much beyond ~2, but try).
    if best is not None:
        cur = best[:]
        cur_score = _score(cur)
        n = len(cur)
        # Compute exact score for the pure AP for max n as theoretical reference.
        it = 0
        while time.time() < deadline:
            it += 1
            cand = cur[:]
            # perturb a few elements by small amounts
            k = random.randint(1, max(2, n // 50))
            for _ in range(k):
                idx = random.randrange(n)
                cand[idx] += random.choice([-2, -1, 1, 2])
            # keep distinct
            if len(set(cand)) != n:
                continue
            s = _score(cand)
            if s > cur_score:
                cur_score = s
                cur = cand
                if s > best_score:
                    best_score = s
                    best = cand[:]
            elif s == cur_score and random.random() < 0.3:
                cur = cand

    # Fallback: ensure valid
    if best is None:
        best = [i * 1000003 for i in range(4000)]
    return sorted(set(best))


if __name__ == "__main__":
    a = solve()
    print(len(a), _score(a))
