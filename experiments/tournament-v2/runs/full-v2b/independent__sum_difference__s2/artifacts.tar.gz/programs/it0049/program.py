import math
import random
import time


def _sets(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 1, 1, n
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums), n


def _score(a):
    d, s, n = _sets(a)
    if s < 2 or n < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _build_sidon(seed, n, span):
    rnd = random.Random(seed)
    # greedy Sidon-like construction on a modular basis, then lift to integers
    p = span
    chosen = []
    forbidden = {}
    tries = 0
    while len(chosen) < n and tries < n * 200:
        tries += 1
        x = rnd.randrange(p)
        ok = True
        for a in chosen:
            if x == a:
                ok = False
                break
        if not ok:
            continue
        # check sidon condition against existing pairs
        pairsums = {}
        bad = False
        for i in range(len(chosen)):
            for j in range(i, len(chosen)):
                pairsums[chosen[i] + chosen[j]] = True
        for a in chosen:
            if (x + a) in pairsums or (2 * x) in pairsums:
                bad = True
                break
        if bad:
            continue
        chosen.append(x)
    return chosen


def _random_ap_union(seed, n):
    rnd = random.Random(seed)
    k = rnd.randint(1, 6)
    blocks = []
    total = 0
    for i in range(k):
        if i == k - 1:
            sz = n - total
        else:
            sz = max(1, rnd.randint(1, n // k + 2))
        if sz <= 0:
            break
        if total + sz > n:
            sz = n - total
        if sz <= 0:
            break
        d = rnd.randint(1, 20)
        start = rnd.randint(-50, 50)
        blocks.append([start + d * t for t in range(sz)])
        total += sz
    return [x for b in blocks for x in b][:n]


def solve():
    deadline = time.time() + 115
    best = [0, 2, 5, 9, 14, 20]
    best_score = _score(best)

    # seed pool
    pool = []
    for s in range(200):
        n = random.Random(s).randint(8, 80)
        pool.append(_build_sidon(s, n, max(n * 3, 30)))
    for s in range(200):
        pool.append(_random_ap_union(s, random.Random(s).randint(8, 60)))

    def eval_local(a):
        return _score(a)

    # try seeds
    for seedset in pool:
        if time.time() > deadline:
            break
        a = sorted(set(seedset))
        if len(a) < 4:
            continue
        sc = eval_local(a)
        if sc > best_score:
            best, best_score = a[:], sc
            cur = a[:]
            cur_score = sc
        else:
            cur = a[:]
            cur_score = sc
        # local search
        temp = 0.05
        steps = 0
        while time.time() < deadline and steps < 3000:
            steps += 1
            cand = cur[:]
            op = random.random()
            if op < 0.6:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-4, 4)
            elif op < 0.8 and len(cand) < 300:
                cand.append(random.randint(-60, 60))
            elif len(cand) > 4:
                del cand[random.randrange(len(cand))]
            else:
                continue
            cand = list(set(cand))
            if len(cand) < 4:
                continue
            s2 = _score(cand)
            if s2 >= cur_score or random.random() < math.exp((s2 - cur_score) / max(temp, 1e-9)):
                cur, cur_score = cand, s2
                if s2 > best_score:
                    best, best_score = cand[:], s2
            # occasional restart from best
            if steps % 800 == 0 and random.random() < 0.5:
                cur = best[:]
                cur_score = best_score

    # final polish
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice([-1, 1, -2, 2, -3, 3])
        cand = list(set(cand))
        s2 = _score(cand)
        if s2 >= cur_score:
            cur, cur_score = cand, s2

    return sorted(set(best))
