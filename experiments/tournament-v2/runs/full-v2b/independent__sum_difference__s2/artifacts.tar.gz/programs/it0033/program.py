import math
import random
import time

def _score_fast(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    # a is sorted
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
            if i != j:
                diffs.add(ai - a[j])
                diffs.add(a[j] - ai)
    # diffs already includes both signs
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/n) / 100

def _score(a):
    a = sorted(set(a))
    return _score_fast(a)

def solve():
    # Deterministic strong construction:
    # Use B = {2^i} for i=0..k-1, then A = B union {sum of all B} shifted?
    # Better: use A such that A+A is small. Classic: arithmetic progression gives
    # |A-A| = 2n-1, |A+A| = 2n-1 ratio=1. Bad.
    # We want A-A large (like Sidon) but A+A small.
    # Idea: A = {2^i} gives |A+A| ~ n^2/2 (all unique), |A-A| ~ n^2. ratio ~ 2. Bad.
    # Idea: A = {i*M + b_i} where b_i in [0,M). Cross sums mostly determined by i+j
    # and low parts b_i+b_j. If M is small enough, sums collide.
    # Take A = {i*K + r_i : i=0..n-1} with r_i small (< K/2).
    # Then a_i+a_j = (i+j)*K + r_i+r_j. Many collisions when i+j same and r_i+r_j close.
    # Differences a_i-a_j = (i-j)*K + (r_i-r_j) - distinctness requires no collisions.
    # For differences to be many, need (i-j, r_i-r_j) mostly unique.
    # Choose r_i = i^2 mod small? Let's try r_i random small.

    best = []
    best_score = -1.0

    # Try several constructions
    constructions = []

    # Construction 1: A = {i*K + (i*i) % L}
    for n in [100, 300, 1000, 2000, 3000, 3999]:
        for K in [10, 20, 50, 100, 200]:
            for L in [K, K//2, K*2]:
                if L < 2:
                    continue
                A = sorted(set(i * K + (i * i) % L for i in range(n)))
                if len(A) >= 2:
                    constructions.append(A)

    # Construction 2: A = {i*K + random small}
    random.seed(42)
    for n in [200, 500, 1000, 2000, 3999]:
        for K in [5, 10, 20, 50]:
            rng = random.Random(n * 100 + K)
            A = sorted(set(i * K + rng.randint(0, K - 1) for i in range(n)))
            if len(A) >= 2:
                constructions.append(A)

    # Construction 3: highly structured: A = {i*K + i}? linear, bad.
    # Construction 4: A = {i + i*i // M}?
    for n in [500, 1000, 2000, 3999]:
        for M in [2, 3, 5, 10, 20]:
            A = sorted(set(i * M + (i * i) % M for i in range(n)))
            if len(A) >= 2:
                constructions.append(A)

    # Construction 5: A = {a_i} built greedily to maximize ratio
    # Start with base like {i*K + small random}, then local search

    for A in constructions:
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # Local search refinement
    deadline = time.time() + 100
    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        n = len(cand)
        if op < 0.5 and n > 2:
            # perturb one element
            i = random.randrange(n)
            cand[i] += random.choice([-3, -2, -1, 1, 2, 3]) * random.randint(1, 5)
        elif op < 0.7:
            # add element
            if n < 4000:
                # insert near existing
                i = random.randrange(n)
                cand.insert(i, cand[i] + random.randint(-4, 4))
        elif op < 0.9 and n > 5:
            # remove element
            i = random.randrange(n)
            del cand[i]
        else:
            # swap: replace with neighbor
            i = random.randrange(n)
            cand[i] = cand[i] + random.randint(-10, 10)

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            cand = cand[:4000]
        cs = _score_fast(cand)
        if cs >= cur_score:
            cur = cand
            cur_score = cs
            if cs > best_score:
                best = cand[:]
                best_score = cs
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
