import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ld < 2 or ls < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100

def _score_parts(a):
    n = len(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), n

def _initial_construction():
    # Try to build a set with many differences and few sums.
    # Use a Sidon-like construction: A = {2^i * s_i} with distinct powers,
    # but scale so sums overlap. Start from random dense subsets of small range.
    best = None
    best_score = -1
    # Try several constructions
    constructions = []
    # 1: arithmetic progression with a twist
    for m in [10, 20, 30, 40, 50]:
        constructions.append(list(range(m)))
    # 2: geometric-ish
    for base in [2, 3]:
        constructions.append([base**i for i in range(12)])
    # 3: random Sidon-like from small range
    for _ in range(50):
        k = random.randint(8, 25)
        vals = random.sample(range(-50, 51), k)
        constructions.append(vals)
    # 4: sparse from [0, 2^k]
    for _ in range(30):
        k = random.randint(10, 30)
        vals = random.sample(range(2**k), min(k, 20))
        constructions.append(vals)
    for c in constructions:
        c = list(set(c))
        if len(c) < 2:
            continue
        s = _score(c)
        if s > best_score:
            best_score = s
            best = c[:]
    return best

def _hill_climb(start, deadline):
    cur = list(set(start))
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    n = len(cur)
    temp = 1.0
    while time.time() < deadline:
        # pick a move type
        r = random.random()
        cand = cur[:]
        if r < 0.35 and len(cand) > 2:
            # perturb one element
            i = random.randrange(len(cand))
            delta = random.choice([-3,-2,-1,1,2,3])
            if random.random() < 0.2:
                delta = random.randint(-10, 10)
            cand[i] += delta
        elif r < 0.55 and len(cand) < 60:
            # add a new element
            lo = min(cand) - 20
            hi = max(cand) + 20
            cand.append(random.randint(lo, hi))
        elif r < 0.7 and len(cand) > 4:
            # remove an element
            i = random.randrange(len(cand))
            cand.pop(i)
        elif r < 0.85:
            # swap: remove one, add one
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
            lo = min(cand) - 20
            hi = max(cand) + 20
            cand.append(random.randint(lo, hi))
        else:
            # shift entire set
            shift = random.randint(-5, 5)
            cand = [x + shift for x in cand]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        # cap size
        if len(cand) > 200:
            cand = random.sample(cand, 200)
        s = _score(cand)
        if s >= cur_score or random.random() < math.exp((s - cur_score) / max(temp, 1e-9)):
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        temp *= 0.99995
        if temp < 1e-6:
            temp = 0.1
    return best, best_score

def _greedy_difference_boost(a, deadline):
    # Try to increase difference count without increasing sum count too much
    a = list(set(a))
    best = a[:]
    best_score = _score(a)
    while time.time() < deadline:
        n = len(a)
        if n < 2:
            break
        # compute counts
        ld, ls, _ = _score_parts(a)
        # try adding element that maximizes difference growth per sum growth
        improved = False
        candidates = []
        for _ in range(50):
            x = random.randint(min(a)-30, max(a)+30)
            if x in a:
                continue
            candidates.append(x)
        for x in candidates:
            b = a + [x]
            ld2, ls2, _ = _score_parts(b)
            sc = math.log(ld2)/math.log(ls2) + (1-1/len(b))/100
            if sc > best_score:
                best = b[:]
                best_score = sc
                improved = True
        if improved:
            a = best[:]
        else:
            break
    return best, best_score

def solve():
    deadline_total = time.time() + 110
    # initial construction
    best = _initial_construction()
    best_score = _score(best)
    
    # multiple restarts of hill climbing
    while time.time() < deadline_total - 10:
        start = best[:] if random.random() < 0.5 else _initial_construction()
        # add some randomness
        if random.random() < 0.3:
            k = random.randint(0, min(5, len(start)))
            for _ in range(k):
                i = random.randrange(len(start))
                start[i] += random.randint(-5, 5)
            start = list(set(start))
        b, sc = _hill_climb(start, min(deadline_total - 5, time.time() + 15))
        if sc > best_score:
            best = b[:]
            best_score = sc
    
    # final greedy boost
    b, sc = _greedy_difference_boost(best, deadline_total)
    if sc > best_score:
        best = b[:]
        best_score = sc
    
    # final polish: local search near best
    for _ in range(200):
        if time.time() > deadline_total:
            break
        cand = best[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-2, 2)
        cand = list(set(cand))
        if _score(cand) > best_score:
            best = cand[:]
            best_score = _score(cand)
    
    return sorted(set(best))

if __name__ == "__main__":
    import time
    t0 = time.time()
    res = solve()
    print("time:", time.time() - t0)
    print("n:", len(res))
    print("score:", _score(res))
    # print(res)
