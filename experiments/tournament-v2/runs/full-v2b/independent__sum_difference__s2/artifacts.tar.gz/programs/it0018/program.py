import math
import random
import time

def _score_parts(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    # compute size of A+A and A-A efficiently
    s = set()
    d = set()
    for i, x in enumerate(a):
        for j in range(i + 1, n):
            y = a[j]
            s.add(x + y)
            d.add(x - y)
            d.add(y - x)
    for x in a:
        s.add(x + x)
        d.add(0)
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / n) / 100, len(d), len(s)

def _score(a):
    sc, _, _ = _score_parts(a)
    return sc

def _candidate_random(n, span):
    return sorted(random.sample(range(-span, span + 1), n))

def _base_good(n):
    # Dense arithmetic progression gives small |A+A| ~ 2*range but small |A-A| too.
    # Add large sparse offsets to enlarge difference set while keeping sums compact.
    if n <= 2:
        return [0, 1][:n]
    base = list(range(n))
    # shift some elements by large multiples of n using a deterministic pattern
    shift = n * n
    for i in range(0, n, max(1, n // 20)):
        base[i] += shift * ((i // max(1, n // 20)) + 1)
    return base

def _local_opt(start, deadline):
    cur = start[:]
    cur_score, cur_d, cur_s = _score_parts(cur)
    best = cur[:]
    best_score = cur_score
    n = len(cur)
    # temperature schedule
    T0 = 0.02
    steps = 0
    last_improve = time.time()
    while time.time() < deadline:
        steps += 1
        cand = cur[:]
        # mostly change one element
        if random.random() < 0.85 or n < 3:
            i = random.randrange(n)
            scale = max(1, abs(cur[i]) // 100 + 1)
            cand[i] += random.randint(-scale, scale)
        else:
            # insert or delete
            if random.random() < 0.5 and n < 3000:
                cand.append(random.choice(cur) + random.randint(-100, 100))
            elif n > 5:
                del cand[random.randrange(n)]
        # keep uniqueness
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc, dsz, ssz = _score_parts(cand)
        if sc >= cur_score or random.random() < math.exp((sc - cur_score) / max(1e-9, T0 * (0.999 ** (steps / 1000)))):
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
                last_improve = time.time()
    return best, best_score

def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Try several structured starts and random starts
    starts = []
    for n in [5, 6, 8, 10, 15, 20, 30, 50, 100, 200, 500, 1000]:
        starts.append(_base_good(n))
    for n in [5, 8, 12, 20, 40, 100]:
        starts.append(_candidate_random(n, 1000))

    for st in starts:
        if time.time() > deadline:
            break
        b, sc = _local_opt(st, min(deadline, time.time() + 15))
        if sc > best_score:
            best, best_score = b, sc

    # Continue local optimization from the best found until deadline
    if best is not None and time.time() < deadline:
        b, sc = _local_opt(best, deadline)
        if sc > best_score:
            best, best_score = b, sc

    if best is None:
        best = [0, 1]
    return sorted(set(best))
