import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    d = len(diffs)
    s = len(sums)
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s


def _powers(base, k):
    return [base ** i for i in range(k)]


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Generate structured candidate families.
    candidates = []

    # Powers of bases; differences huge, sums structured.
    for base in (2, 3, 4, 5, 6, 7, 8, 10, 16):
        for k in range(2, 40):
            v = base ** (k - 1)
            if v > 10 ** 15:
                break
            candidates.append(_powers(base, k))

    # Mixed scales: take a geometric backbone and add small offsets.
    for base in (2, 3, 5, 10):
        for k in range(3, 30):
            top = base ** (k - 1)
            if top > 10 ** 15:
                break
            base_set = _powers(base, k)
            for _ in range(30):
                c = base_set[:]
                for _ in range(random.randint(0, 3)):
                    i = random.randrange(len(c))
                    delta = random.randint(-base, base)
                    nv = c[i] + delta
                    if -10 ** 15 <= nv <= 10 ** 15:
                        c[i] = nv
                # add/remove a couple small elements
                for _ in range(random.randint(0, 2)):
                    c.append(random.randint(1, max(2, base * 3)))
                candidates.append(c)

    # Small dense sets with large difference ratio potential.
    for _ in range(200):
        n = random.randint(6, 25)
        hi = random.randint(n, 3 * n)
        s = set()
        while len(s) < n:
            s.add(random.randint(-hi, hi))
        candidates.append(list(s))

    # Evaluate all candidates quickly, keep the best.
    for c in candidates:
        if time.time() > deadline:
            break
        c = sorted(set(c))
        sc = _score(c)
        if sc > best_score:
            best_score = sc
            best = c

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # Local search around the best candidate.
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-3, 3)
        elif op < 0.85:
            cand.append(random.randint(-50, 50))
        elif len(cand) > 3:
            del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
