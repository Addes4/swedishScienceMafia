import math
import random
import time


def _score_parts(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    score = math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0
    return score, len(diffs), len(sums)


def _score(a):
    return _score_parts(a)[0]


def solve():
    deadline = time.time() + 115.0
    best = None
    best_score = -1.0

    # Candidate 1: quadratic-ish set with many distinct sums? No: we want small sums.
    # Try arithmetic-progression-free / Sidon-ish constructions.

    def consider(cand):
        nonlocal best, best_score
        cand = sorted(set(int(x) for x in cand))
        if len(cand) < 2:
            return
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    # Construction A: greedy Sidon-like set where all pairwise sums are distinct.
    # For |A+A| ~ n(n+1)/2 and |A-A| ~ n(n-1)+1, ratio near log(~n^2)/log(~n^2/2) ~ 1.
    # Not useful. To make ratio big we want |A-A| much larger than |A+A|.
    # If A is a Sidon set (B2), sums are all distinct: |A+A| = n(n+1)/2.
    # Differences may have coincidences, so |A-A| <= n(n-1)+1.
    # Ratio ~ log(n^2)/log(n^2/2) ~ 1 + log2/log(n^2). Small for large n.

    # Better: make A a geometric-like / multiplicative set so additive collisions are huge.
    # If A is {1,2,4,...,2^{n-1}}, then A+A has few distinct values? Actually sums of powers
    # of two are mostly distinct (binary representations). Bad.

    # We want |A+A| small: arithmetic progression gives |A+A| = 2n-1, but |A-A| = 2n-1 too.
    # Ratio 1. Need |A-A| large AND |A+A| small.
    # Take union of a small-sum core plus a large Sidon-like difference component?
    # Differences combine with all, sums also combine. Hard.

    # Key idea: choose A = {1,...,n} union {large random values}? Sums with large values create
    # many distinct sums, increasing |A+A|.

    # Try: A a Sidon set with many elements but then |A+A| ~ n^2/2. Ratio ~1.
    # But maybe choose n small enough that ratio is decent? For n=6, |A-A|~31, |A+A|~21.
    # log(31)/log(21) ~ 1.127. Plus bonus (.833)/100 = 0.0083 -> ~1.135.

    # Try known good examples: sets with |A+A| much smaller than |A-A|.
    # Consider A = {x_i} where x_i are all distinct but x_i+x_j collisions frequent.
    # E.g. symmetric set: A = {0} ∪ {±a_1,...,±a_k}. Then A+A = {0} ∪ {±a_i} ∪ {±(a_i+a_j)}
    # ∪ {±(a_i-a_j)}. |A-A| = {0} ∪ {±2a_i} ∪ {±(a_i±a_j)}. Similar sizes.

    # Try exponentiation-set with rounded values to induce collisions? Let's just search.
    # Start with a good known construction: a Sidon set of size ~20 with small entries.
    # But we want large |A-A| relative to |A+A|. Let's brute-force local search for small n
    # and then scale/stack.

    # Fast random local search for moderate n. Use incremental sets.
    # Since evaluation is O(n^2), we can afford n up to a few hundred with thousands of evals.

    # Strategy: start with a moderately large set (~200-400) built as union of intervals,
    # then local search. But local search with O(n^2) evals is expensive.

    # Simpler: use a set with structure: A = {i*M + r_i} where r_i chosen to make sums collide.
    # Actually for small |A+A|, take A close to arithmetic progression but with differences
    # spread out. Consider A = {a, a+d, a+2d, ..., a+(n-1)d} — too regular.

    # Try random sets of various sizes, keep best.
    random.seed(12345)
    for n in [5, 6, 7, 8, 9, 10, 12, 15, 20, 25, 30, 40, 50, 75, 100, 150, 200]:
        # random contiguous block
        for _ in range(3):
            base = random.randint(-1000, 1000)
            cand = [base + i for i in range(n)]
            consider(cand)
        # random spread
        for _ in range(5):
            cand = random.sample(range(-5000, 5000), n)
            consider(cand)

    # Local search on best
    if best is None:
        best = [0, 1, 2, 3, 4]

    cur = best[:]
    cur_score = _score(cur)
    iters = 0
    while time.time() < deadline:
        iters += 1
        cand = cur[:]
        n = len(cand)
        # pick a move
        r = random.random()
        if r < 0.55 and n > 0:
            i = random.randrange(n)
            cand[i] += random.randint(-5, 5)
        elif r < 0.75:
            i = random.randrange(n)
            cand[i] += random.choice([-1, 1]) * random.randint(1, 50)
        elif r < 0.85 and n < 400:
            cand.append(random.randint(-200, 200))
        elif r < 0.95 and n > 4:
            i = random.randrange(n)
            del cand[i]
        else:
            # swap two entries
            if n >= 2:
                i, j = random.sample(range(n), 2)
                cand[i], cand[j] = cand[j], cand[i]
        cand = sorted(set(cand))
        s = _score(cand)
        if s > cur_score or (s == cur_score and len(cand) > len(cur)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
