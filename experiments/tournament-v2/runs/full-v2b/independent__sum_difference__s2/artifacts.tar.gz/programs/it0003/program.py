import math
import random
import time


def _score(a):
    vals = list(set(a))
    n = len(vals)
    if n < 2:
        return -1e9
    diffs = set()
    sums = set()
    for i in range(n):
        x = vals[i]
        for j in range(n):
            y = vals[j]
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) == 0:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _make_base(nblocks=18, block_len=10, spacing=1, seed=12345):
    rnd = random.Random(seed)
    A = []
    # union of arithmetic blocks; choosing same spacing makes A+A small.
    for b in range(nblocks):
        base = b * (block_len * spacing + 1)
        for i in range(block_len):
            A.append(base + i * spacing)
    # add Sidon-like perturbation to boost differences
    extra = []
    seen = set(A)
    # Add numbers with dense but controlled differences
    for t in range(80):
        v = rnd.randint(-2 * nblocks * block_len, 2 * nblocks * block_len)
        if v not in seen:
            seen.add(v)
            extra.append(v)
    return A + extra


def _reduce_sums(A):
    # Heuristic cleanup: remove elements that contribute many new sums but few new diffs.
    A = list(set(A))
    improved = True
    while improved:
        improved = False
        best = A
        best_score = _score(A)
        # try removing a few candidates
        cand_indices = list(range(len(A)))
        random.shuffle(cand_indices)
        for idx in cand_indices[: min(30, len(A))]:
            if len(A) <= 2:
                break
            B = A[:idx] + A[idx + 1 :]
            s = _score(B)
            if s > best_score:
                best_score = s
                best = B
                improved = True
                break
        A = best
    return A


def solve():
    best = None
    best_score = -1e9
    start = time.time()
    deadline = start + 105

    # Broad multi-start search
    seeds = list(range(1, 41))
    random.shuffle(seeds)

    for sd in seeds:
        if time.time() > deadline:
            break
        rnd = random.Random(sd)
        # randomized multiscale blocks
        nblocks = rnd.randint(8, 22)
        block_len = rnd.randint(6, 16)
        spacing = rnd.choice([1, 2, 3, 4])
        A = _make_base(nblocks, block_len, spacing, seed=sd)

        # local improvements: shifts, additions, removals
        cur = list(set(A))
        cur_score = _score(cur)
        local_deadline = time.time() + 8
        steps = 0
        while time.time() < local_deadline and steps < 8000:
            steps += 1
            cand = cur[:]
            op = rnd.random()
            if op < 0.65 and cand:
                i = rnd.randrange(len(cand))
                cand[i] += rnd.randint(-4, 4)
            elif op < 0.85:
                cand.append(rnd.randint(-200, 200))
            elif len(cand) > 3:
                i = rnd.randrange(len(cand))
                cand.pop(i)
            cand = list(set(cand))
            if len(cand) > 4000:
                cand = cand[:4000]
            s = _score(cand)
            if s >= cur_score:
                cur = cand
                cur_score = s
            elif rnd.random() < 0.02:
                cur = cand
                cur_score = s

            if s > best_score:
                best = cand[:]
                best_score = s

        # cleanup
        cleaned = _reduce_sums(cur)
        cs = _score(cleaned)
        if cs > best_score:
            best = cleaned[:]
            best_score = cs

    # Final polish on best
    if best is None:
        best = [0, 1, 3]
        best_score = _score(best)

    end = time.time() + 10
    cur = best[:]
    cur_score = _score(cur)
    rnd = random.Random(999)
    while time.time() < end:
        cand = cur[:]
        op = rnd.random()
        if op < 0.6 and cand:
            i = rnd.randrange(len(cand))
            cand[i] += rnd.randint(-2, 2)
        elif op < 0.8:
            cand.append(rnd.randint(-300, 300))
        elif len(cand) > 2:
            i = rnd.randrange(len(cand))
            cand.pop(i)
        cand = list(set(cand))
        s = _score(cand)
        if s > cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s

    best = sorted(set(best))
    if len(best) < 2:
        best = [0, 1]
    return best
