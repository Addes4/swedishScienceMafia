import math
import random
import time
from itertools import combinations


def _score_parts(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    diffs = len({x - y for x in a for y in a})
    sums = len({x + y for x in a for y in a})
    if sums <= 1:
        return -1.0, diffs, sums
    ratio = math.log(diffs) / math.log(sums)
    bonus = (1.0 - 1.0 / n) / 100.0
    return ratio + bonus, diffs, sums


def _score(a):
    return _score_parts(a)[0]


def _build_initial():
    # Dense-ish shifted AP gives lots of sum collisions.
    # Add a carefully chosen perturbation pattern to spread differences.
    n = 90
    base = 97
    a = [i * base for i in range(n)]
    # Sidon-like offsets from powers/golomb-ish structure
    offs = [0]
    k = 1
    val = 1
    while len(offs) < n:
        offs.append(val)
        k += 1
        val += k * 3 + 1
    offs = offs[:n]
    # Shuffle offsets onto positions to break symmetry
    rnd = random.Random(12345)
    rnd.shuffle(offs)
    a = [i * base + offs[i] for i in range(n)]
    return a


def _greedy_improve(a, deadline):
    a = list(dict.fromkeys(a))
    best_score, _, _ = _score_parts(a)
    n = len(a)
    if n < 2:
        return a

    # Precompute counts incrementally would be complex; use local search on differences of sums.
    improved = True
    step = 1
    while time.time() < deadline and improved:
        improved = False
        order = list(range(len(a)))
        random.shuffle(order)
        for i in order:
            if time.time() >= deadline:
                break
            cur = a[i]
            best_val = cur
            # try a few candidate replacements
            for delta in (1, -1, 2, -2, 3, -3, 5, -5, 7, -7, 11, -11):
                a[i] = cur + delta
                sc, _, _ = _score_parts(a)
                if sc > best_score + 1e-15:
                    best_score = sc
                    best_val = a[i]
                    improved = True
                else:
                    a[i] = cur
                    continue
                a[i] = best_val
                cur = best_val
        # occasionally try smaller random moves
        if not improved:
            for _ in range(30):
                if time.time() >= deadline:
                    break
                i = random.randrange(len(a))
                old = a[i]
                a[i] += random.randint(-4, 4)
                sc, _, _ = _score_parts(a)
                if sc > best_score:
                    best_score = sc
                    improved = True
                else:
                    a[i] = old
    return a


def _sa(a, deadline):
    a = list(dict.fromkeys(a))
    cur_score, _, _ = _score_parts(a)
    best = a[:]
    best_score = cur_score
    n = len(a)
    T = 0.05
    while time.time() < deadline:
        if random.random() < 0.7:
            i = random.randrange(n)
            old = a[i]
            a[i] += random.randint(-2, 2)
            ns, _, _ = _score_parts(a)
            if ns >= cur_score or random.random() < math.exp((ns - cur_score) / max(T, 1e-9)):
                cur_score = ns
                if ns > best_score:
                    best_score = ns
                    best = a[:]
            else:
                a[i] = old
        else:
            # shift a whole range by small amount
            i = random.randrange(n)
            j = random.randrange(i, n)
            d = random.randint(-1, 1)
            if d == 0:
                continue
            old_vals = a[i:j + 1]
            for k in range(i, j + 1):
                a[k] += d
            ns, _, _ = _score_parts(a)
            if ns >= cur_score or random.random() < math.exp((ns - cur_score) / max(T, 1e-9)):
                cur_score = ns
                if ns > best_score:
                    best_score = ns
                    best = a[:]
            else:
                a[i:j + 1] = old_vals
        T *= 0.99995
        if random.random() < 0.001:
            T = max(T, 0.002)
    return best


def _singer_like():
    # Construct using a quadratic residue / Singer difference set style scaled set.
    # p = 101, use q = p^2 + p + 1 = 10303 cyclic projection, then scale small.
    p = 47
    q = p * p + p + 1
    # Use a small multiplicative subgroup-ish set of residues.
    A = []
    x = 1
    for _ in range(p + 1):
        A.append(x % q)
        x = (x * 2) % q
        if x == 0:
            x = 1
    A = sorted(set(A))
    # scale so sums cluster: use linear map then compress
    return A


def solve():
    deadline = time.time() + 110
    candidates = []

    # Candidate 1: carefully built AP + Sidon offsets
    random.seed(1)
    a1 = _build_initial()
    candidates.append(a1)

    # Candidate 2: Singer-like residues scaled
    try:
        a2 = _singer_like()
        candidates.append(a2)
    except Exception:
        pass

    # Candidate 3: simpler AP with multiplicative perturbation
    a3 = []
    base = 201
    for i in range(60):
        a3.append(i * base + (i * i) % 113)
    candidates.append(a3)

    best = None
    best_score = -1.0
    for c in candidates:
        sc, _, _ = _score_parts(c)
        if sc > best_score:
            best_score = sc
            best = c[:]

    # Greedy improvement phase
    t1 = time.time() + (deadline - time.time()) * 0.4
    best = _greedy_improve(best, t1)
    best_score, _, _ = _score_parts(best)

    # Also try improving other candidates and pick best
    for c in candidates:
        if time.time() >= deadline:
            break
        cc = _greedy_improve(c, min(deadline, time.time() + 8))
        sc, _, _ = _score_parts(cc)
        if sc > best_score:
            best_score = sc
            best = cc

    # SA polishing
    best = _sa(best, deadline)
    best_score, _, _ = _score_parts(best)

    # Final small greedy polish
    best = _greedy_improve(best, deadline)

    best = sorted(set(best))
    # Keep bound constraints
    best = [x for x in best if abs(x) <= 10**15][:4000]
    if len(best) < 2:
        best = [0, 1]
    return best
