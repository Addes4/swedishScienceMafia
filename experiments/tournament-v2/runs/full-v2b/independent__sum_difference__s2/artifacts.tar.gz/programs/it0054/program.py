import math
import random
import time


def _diffs_sums(a):
    n = len(a)
    if n < 2:
        return 0, 0
    D = set()
    S = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            S.add(ai + a[j])
            D.add(ai - a[j])
            D.add(a[j] - ai)
    return len(D), len(S)


def _score(a):
    if len(a) < 2:
        return 0.0
    d, s = _diffs_sums(a)
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100.0


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # candidate constructions
    seeds = []

    # powers-ish / exponential: huge ratio of distinct differences
    for base in (2, 3):
        for k in (8, 12, 16, 20):
            A = [base ** i for i in range(k)]
            if max(abs(x) for x in A) <= 10**15:
                seeds.append(A)

    # Sidon-ish greedy near arithmetic progression with perturbation
    seeds.append([0, 1])
    seeds.append([0, 1, 3])
    seeds.append([0, 1, 3, 7])
    seeds.append(list(range(0, 12)))
    seeds.append([7, 15, 18, 22, -3, -2])

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score = sc
            best = s[:]

    # local search: try to grow set, maximizing ratio
    random.seed(12345)

    def try_improve(A):
        nonlocal best, best_score
        A = sorted(set(A))
        improved = True
        while improved and time.time() < deadline:
            improved = False
            cur, cs = A[:], _score(A)
            if cs > best_score:
                best_score = cs
                best = cur[:]
            # add move: try adding many candidate values
            trials = 0
            for _ in range(60):
                if time.time() > deadline:
                    break
                v = random.choice([random.randint(-100, 100),
                                   max(A) + random.randint(1, 50),
                                   min(A) - random.randint(1, 50),
                                   random.randint(-10**6, 10**6)])
                if v in cur:
                    continue
                cand = sorted(set(cur + [v]))
                sc = _score(cand)
                trials += 1
                if sc > cs:
                    cur, cs = cand, sc
                    improved = True
            # shift/perturb move
            for _ in range(20):
                if time.time() > deadline:
                    break
                cand = cur[:]
                i = random.randrange(len(cand))
                cand[i] += random.randint(-5, 5)
                cand = sorted(set(cand))
                sc = _score(cand)
                if sc > cs:
                    cur, cs = cand, sc
                    improved = True
            A = cur
            if cs > best_score:
                best_score = cs
                best = cur[:]
        return A

    # beam-ish search from several seeds
    pool = [s[:] for s in seeds]
    # also random small starts
    for _ in range(30):
        k = random.randint(3, 8)
        pool.append(sorted(random.sample(range(-40, 40), k)))

    idx = 0
    while time.time() < deadline and pool:
        if idx >= len(pool):
            idx = 0
        A = pool[idx]
        idx += 1
        try_improve(A)

    if best is None:
        best = [0, 1]
    return sorted(set(int(x) for x in best))
