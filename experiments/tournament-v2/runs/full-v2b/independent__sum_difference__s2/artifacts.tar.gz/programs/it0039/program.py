import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for j, y in enumerate(a):
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _exact_counts(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _ratio(a):
    d, s = _exact_counts(a)
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s)


def _bonus(a):
    return (1 - 1 / len(a)) / 100


def _full_score(a):
    d, s = _exact_counts(a)
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + _bonus(a)


def _greedy_construct(n, span):
    # Build a set with many differences and few sums by taking a Sidon-ish
    # base shifted negatively so that sums collapse.
    base = [0]
    used = {0}
    target = max(1, span * 3 // 2)
    attempts = 0
    while len(base) < n and attempts < target * 200:
        attempts += 1
        c = random.randint(-target, target)
        if c in used:
            continue
        # require new differences (Sidon-like) to keep diff set large
        ok = True
        diffs = set()
        for i, x in enumerate(base):
            for j, y in enumerate(base):
                diffs.add(x - y)
        for x in base:
            if c - x in diffs or x - c in diffs:
                ok = False
                break
        if ok:
            base.append(c)
            used.add(c)
        else:
            # allow occasionally
            if random.random() < 0.02:
                base.append(c)
                used.add(c)
    return base


def _neg_shifted_sidon(n):
    # Greedy Sidon set in [0, M), then shift all negatives.
    # Shifting by a constant c changes sums by 2c and differences stay same.
    # So A - A is large; A + A is just shifted sums, so no gain.
    # Instead, use a set symmetric-ish but with multiplicative collapse:
    # powers of 2 give huge differences and huge sums. Not useful.
    # Use a Sidon base B and a shifted copy to collapse sums.
    M = max(64, 4 * n * n)
    B = [0]
    for c in range(1, M):
        if len(B) >= n:
            break
        ok = True
        ds = set()
        for x in B:
            for y in B:
                ds.add(x - y)
        for x in B:
            if c - x in ds or x - c in ds:
                ok = False
                break
        if ok:
            B.append(c)
    return B


def _local_search(a, deadline, seed_best=None):
    a = sorted(set(a))
    best = a[:]
    best_s = _full_score(best)
    cur = a[:]
    cur_s = best_s
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        n = len(cand)
        if n == 0:
            cand = [0]
        r = random.random()
        if r < 0.72:
            # perturb one element
            i = random.randrange(len(cand))
            scale = max(1, int(max(abs(x) for x in cand) // 10 + 1))
            cand[i] += random.randint(-scale, scale)
        elif r < 0.86:
            # add element
            if len(cand) < 4000:
                m = max(abs(x) for x in cand) if cand else 1
                cand.append(random.randint(-m - 1, m + 1))
        elif r < 0.95:
            # remove element
            if len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
        else:
            # swap
            if len(cand) > 0:
                i = random.randrange(len(cand))
                m = max(abs(x) for x in cand) if cand else 1
                cand[i] = random.randint(-m - 1, m + 1)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _full_score(cand)
        if s >= cur_s or random.random() < 0.03:
            cur, cur_s = cand[:], s
        if s >= best_s:
            best, best_s = cand[:], s
        if it % 300 == 0 and random.random() < 0.4:
            cur = best[:]
            cur_s = best_s
        # restart if stuck
        if it % 2000 == 0:
            cur = best[:]
            cur_s = best_s
    return best, best_s


def _structured_block_set(k, m):
    # Build A = {i*m + j : i in [0,k), j in [0,m)} with a twist:
    # Use base B = {i*m : i in [0,k)} union small offsets to boost differences
    # but keep sums small by making many duplicates in sums.
    A = []
    for i in range(k):
        for j in range(m):
            A.append(i * m + j)
    return A


def _asymmetric_set(n):
    # Use half-plane trick: A = B union (-B + c) for a Sidon-ish B.
    # Differences include B-B, (-B+c)-(-B+c)=B-B, and cross terms
    # b - (-b' + c) = b + b' - c. Sums: b + b', (-b+c)+(-b'+c)=-(b+b')+2c,
    # and b + (-b'+c) = b - b' + c. If we choose c large, sums cluster.
    half = max(2, n // 2)
    B = _neg_shifted_sidon(half)
    c = max(B) + max(1, max(B) // 2 + 1) if B else 1
    A = list(B) + [-b + c for b in B]
    return list(set(A))


def solve():
    deadline = time.time() + 110
    n_target = 400

    candidates = []

    # 1) Asymmetric Sidon construction
    for mult in (1, 2, 3):
        A = _asymmetric_set(n_target * mult)
        if len(A) >= 2:
            candidates.append(A)

    # 2) Random Sidon-ish
    random.seed(12345)
    for _ in range(6):
        n = random.choice([80, 150, 250, 400])
        span = random.choice([5, 12, 25, 50])
        A = _greedy_construct(n, span)
        candidates.append(A)

    # 3) Power-of-small-base block sets: A = {sum d_i b^i} with limited digits
    for base in (2, 3):
        A = []
        limit = 6 if base == 2 else 4
        for x in range(limit ** 3):
            v = 0
            t = x
            for _ in range(3):
                v = v * base + (t % limit)
                t //= limit
            A.append(v)
        candidates.append(A)

    # 4) Interval minus a structured set (collapses sums)
    for k in (5, 8, 12):
        A = list(range(0, k)) + [-i * k for i in range(1, k + 1)]
        candidates.append(A)

    # Evaluate all candidates
    best = None
    best_s = -1.0
    for A in candidates:
        A = list(set(A))
        if len(A) < 2 or len(A) > 4000:
            continue
        s = _full_score(A)
        if s > best_s:
            best_s = s
            best = A[:]

    if best is None:
        best = [0, 1]
        best_s = _full_score(best)

    # Local search from best candidates
    pool = []
    for A in candidates:
        A = list(set(A))
        if 2 <= len(A) <= 4000:
            pool.append((_full_score(A), A))
    pool.sort(reverse=True)
    pool = pool[:8]

    remaining = deadline - time.time()
    if remaining > 0:
        per = remaining / max(1, len(pool))
        sub_deadline = time.time() + per
        for s, A in pool:
            if time.time() >= deadline:
                break
            cand_deadline = min(deadline, sub_deadline)
            res, rs = _local_search(A, cand_deadline)
            if rs > best_s:
                best, best_s = res[:], rs
            sub_deadline = min(deadline, max(time.time() + per, sub_deadline))

    # Final refinement on best
    if time.time() < deadline:
        res, rs = _local_search(best, deadline)
        if rs > best_s:
            best, best_s = res[:], rs

    # Sanitize
    best = sorted(set(int(x) for x in best))
    if len(best) < 2:
        best = [0, 1]

    # Trim to at most 4000
    if len(best) > 4000:
        # Keep subset with highest local score contribution roughly
        best = best[:4000]

    # Ensure bounds
    best = [x for x in best if abs(x) <= 10**15]
    if len(best) < 2:
        best = [0, 1]

    return best
