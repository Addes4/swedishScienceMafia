import math, random, time

def _stats(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)

def _greedy_sidon(n, limit):
    # Greedy Sidon set: keep adding smallest x so all pairwise sums distinct
    sums = set()
    A = []
    # seed
    A.append(1)
    sums.add(2)
    candidate = 2
    while len(A) < n and candidate <= limit:
        ok = True
        new_sums = set()
        for a in A:
            s = a + candidate
            if s in sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            sums.add(2*candidate)
            sums |= new_sums
            A.append(candidate)
        candidate += 1
    return A

def _greedy_shift(n):
    # B_2-ish using base growth
    A = [0]
    for i in range(1, n):
        # try to add smallest value whose sums don't collide
        sums = set()
        for x in A:
            for y in A:
                sums.add(x+y)
        c = A[-1] + 1
        while True:
            ok = True
            for a in A:
                if a + c in sums:
                    ok = False
                    break
            if ok:
                A.append(c)
                break
            c += 1
    return A

def solve():
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _stats(best)[0]

    # Try several greedy Sidon seeds of various sizes
    seeds = []
    for n in [60, 100, 150, 220, 300, 420, 600]:
        try:
            seeds.append(_greedy_sidon(n, 500000))
        except Exception:
            pass
    for n in [50, 80, 120, 180, 260, 360]:
        try:
            seeds.append(_greedy_shift(n))
        except Exception:
            pass

    # Also include random-pair based constructions
    for _ in range(5):
        n = random.randint(100, 400)
        # powers of 2-ish: ensures sums unique-ish
        s = [random.randint(1, 5)]
        while len(s) < n:
            s.append(s[-1]*2 + random.randint(0,1))
        seeds.append(s)

    cur_best = None
    for seed in seeds:
        s = seed[:]
        sc = _stats(s)[0]
        if sc > best_score:
            best_score = sc
            best = s[:]
        # local refine
        cur = s[:]
        cur_sc = sc
        fails = 0
        while time.time() < deadline and fails < 400:
            cand = cur[:]
            k = random.randrange(len(cand))
            cand[k] += random.choice([-2,-1,1,2, -3, 3])
            # occasional add/remove
            r = random.random()
            if r < 0.05 and len(cand) < 800:
                cand.append(random.randint(-1000, 1000))
            elif r < 0.08 and len(cand) > 10:
                del cand[random.randrange(len(cand))]
            if len(set(cand)) < len(cand):
                fails += 1
                continue
            cs = _stats(cand)[0]
            if cs >= cur_sc:
                cur, cur_sc = cand, cs
                if cs > best_score:
                    best, best_score = cand[:], cs
                    fails = 0
            else:
                fails += 1
        if time.time() >= deadline:
            break

    # final polish: try removing/adding elements to reduce sum set
    cur = best[:]
    cur_sc = best_score
    no_improve = 0
    while time.time() < deadline and no_improve < 3000:
        cand = cur[:]
        r = random.random()
        if r < 0.4 and len(cand) > 5:
            i = random.randrange(len(cand))
            cand[i] = cand[i] + random.randint(-1, 1)
        elif r < 0.7:
            cand.append(random.randint(-2000, 2000))
        else:
            i = random.randrange(len(cand))
            del cand[i]
        if len(set(cand)) < len(cand) or len(cand) < 5:
            no_improve += 1
            continue
        cs = _stats(cand)[0]
        if cs >= cur_sc:
            cur, cur_sc = cand, cs
            if cs > best_score:
                best, best_score = cand[:], cs
                no_improve = 0
        else:
            no_improve += 1

    return sorted(set(best))
