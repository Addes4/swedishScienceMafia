import math
import random
import time
from typing import List

# ---------- fast scoring ----------
def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    # O(n^2) but n is small
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0

# ---------- greedy / structured constructions ----------
def geometric_base(k):
    # 0,1,3,7,15,...  (Mian-Chowla-ish / powers of 2 minus 1)
    return [ (1 << i) - 1 for i in range(k) ]

def add_random_blocks(base, m, scale, rng):
    A = list(base)
    used = set(A)
    attempts = 0
    while len(A) < m and attempts < 10000:
        attempts += 1
        x = rng.randrange(-2, 3) * scale
        x += rng.randrange(0, scale)
        if x not in used:
            used.add(x)
            A.append(x)
    return A

def local_improve(A, deadline, rng):
    A = list(set(A))
    best = A[:]
    bs = _score(best)
    cur = best[:]
    cs = bs
    grid = [0,1,-1,2,-2,3,-3,4,-4,5,-5,6,-6,7,-7,8,-8,9,-9,10,-10, 100, -100, 1000, -1000]
    while time.time() < deadline:
        cand = cur[:]
        op = rng.randrange(6)
        if op == 0:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice(grid)
        elif op == 1:
            cand.append(rng.choice(grid) + (rng.randrange(-3,4)*1000))
        elif op == 2 and len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        elif op == 3:
            i = rng.randrange(len(cand))
            cand[i] = -cand[i]
        elif op == 4:
            i = rng.randrange(len(cand))
            j = rng.randrange(len(cand))
            cand[i], cand[j] = cand[j], cand[i]
        else:
            cand.append(rng.randrange(-5000, 5001))
        cand = list(set(cand))
        if len(cand) > 4000:
            cand = cand[:4000]
        s = _score(cand)
        if s >= cs * 0.9999:
            if s > cs:
                cs = s
                cur = cand[:]
            if s > bs:
                bs = s
                best = cand[:]
        elif rng.random() < 0.05:
            cur = best[:]
            cs = bs
    return best

# ---------- main ----------
def solve() -> List[int]:
    rng = random.Random(12345)
    deadline = time.time() + 110.0
    candidates = []

    # 1) various geometric bases
    for k in [4,5,6,7,8,9,10,11,12]:
        base = geometric_base(k)
        candidates.append(base)

    # 2) geometric + random blocks
    for k in [5,6,7,8,9]:
        base = geometric_base(k)
        for scale in [16,32,64,128,256,512,1024]:
            A = add_random_blocks(base, min(60, k+25), scale, rng)
            candidates.append(A)

    # 3) baseline random sets
    for _ in range(40):
        n = rng.randrange(8, 40)
        A = [rng.randrange(-200, 201) for _ in range(n)]
        candidates.append(A)

    best = None
    bs = -1.0
    for A in candidates:
        s = _score(A)
        if s > bs:
            bs = s
            best = A[:]

    # local search from several seeds
    seeds = sorted(candidates, key=lambda x: -_score(x))[:8]
    for seed in seeds:
        if time.time() > deadline:
            break
        improved = local_improve(seed, time.time() + 12.0, rng)
        s = _score(improved)
        if s > bs:
            bs = s
            best = improved[:]

    # final polish
    if time.time() < deadline:
        best = local_improve(best, deadline, rng)

    # cleanup: distinct ints in range
    out = []
    seen = set()
    for x in best:
        if x not in seen and abs(x) <= 10**15:
            seen.add(x)
            out.append(int(x))
    while len(out) > 4000:
        out.pop()
    return sorted(out)
