import math
import random
import time

def _fast_score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return (math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100.0,
            len(diffs), len(sums))

def _score_only(a):
    return _fast_score(a)[0]

def solve():
    # Build a structured set: interleaved arithmetic progressions sharing a common step.
    # Let step = 1 -> A is a subset of an interval [0, L].  Then |A+A| <= 2L+1 and
    # |A-A| <= 2L+1. Not good.  Instead use several APs with a large common step d,
    # but bases chosen so differences hit many residues:
    # A = { base_k + d*j : k, j }.  Sums: base_k+base_l + d*(j+m) -> few residue classes mod d,
    # but range large.  Differences similarly many.  Trade-off: choose d ~ n to balance.
    #
    # Known good family: A = {2^i} no (sums huge).  Use A being a "difference-rich /
    # sum-poor" set: an arithmetic progression of length m gives |A-A|=2m-1, |A+A|=2m-1 -> ratio 1.
    # A Sidon set: |A+A| ~ |A|^2 large, |A-A| ~ |A|^2 -> ratio 1.
    # Best ratio near 2 requires a set that is a "perfect difference set" style: take A as a
    # large subset of a lattice where sums collide massively.
    #
    # Construction: A = union of t arithmetic progressions with the SAME difference d,
    # each of length m, with bases b_0<...<b_{t-1} in [0, d).  Then every element = b_k + d*j.
    # sums: b_k+b_l + d*(i+j); residues of sums mod d limited to b_k+b_l (t^2 of them, but
    # values in [0,2d)).  Differences mod d: b_k-b_l -> t^2 residues.  Number of distinct
    # sums ~ (#residues) * (#values of i+j) ~ t^2 * (2m).  Number of distinct differences
    # ~ t^2 * (2m) as well.  Hmm ratio ~1.
    #
    # So to get ratio > 1 we need sum set genuinely smaller. Use bases forming an AP too!
    # If bases are themselves an AP with difference e, then b_k+b_l ranges over 2e*(k+l)
    # => (2t-1) values, while b_k-b_l gives (2t-1) values too.  With d chosen ~ m*e maybe.
    # Actually choose B = bases AP with step e, and full A = {b + d*j}.  Then A is a 2D grid
    # A = {0..} ; distinct sums = (sums of B) + d*(sums of j-range): (2t-1)*(2m-1).
    # distinct diffs = (diffs of B) + d*(diffs of j-range): (2t-1)*(2m-1).  Same.
    #
    # The asymmetry can be obtained when the step in B and step d and lengths interplay so
    # that sum-coordinate collisions exceed difference-coordinate collisions.  If B has
    # small sum set relative to difference set and j-range likewise, then A inherits.
    # A set with |A+A| << |A-A|^? : classic is A = {1,...,n} union something. Actually
    # Freiman: small sum set implies structured, which makes difference set also small.
    # Hence ratio is provably bounded? For sets, |A-A| <= |A+A|^? Not directly.
    #
    # Empirically, best known ratio for this challenge ~ near 1.5-2 using small
    # "sum-poor" sets. Let's just do strong local search seeded with structured sets and
    # pick the best.  We maximize over short structured candidates.
    best_a = None
    best_s = -1.0
    deadline = time.time() + 100

    # Candidate structured sets: several APs sharing step, bases small.
    def try_set(a):
        nonlocal best_a, best_s
        a = sorted(set(a))
        if len(a) < 2:
            return
        s = _score_only(a)
        if s > best_s:
            best_s = s
            best_a = a[:]

    # Seed: short arithmetic progression
    for L in range(2, 40):
        try_set(list(range(L)))

    # Seed: union of APs
    for t in range(1, 6):
        for m in range(2, 12):
            for d in range(m, m * 8 + 1):
                bases = [d * k for k in range(t)]
                a = []
                for b in bases:
                    for j in range(m):
                        a.append(b + d * j)
                try_set(a)

    # Hill climbing from a good structured seed with full pairwise evaluation (small n)
    if best_a is None or len(best_a) < 2:
        best_a = [0, 1, 2]
        best_s = _score_only(best_a)

    cur = best_a[:]
    cur_s = best_s
    start = time.time()
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.5:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-3, -2, -1, 1, 2, 3])
        elif op < 0.8:
            cand.append(random.randint(-50, 50))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score_only(cand)
        if s > cur_s or (s == cur_s):
            cur, cur_s = cand, s
            if s > best_s:
                best_s = s
                best_a = cand[:]
        elif random.random() < 0.05:
            cur = best_a[:]
            cur_s = best_s

    return sorted(set(best_a))
