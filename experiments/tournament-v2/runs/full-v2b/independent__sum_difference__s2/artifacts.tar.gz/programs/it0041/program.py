import math
import random
import time
from itertools import combinations

def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    L = list(a)
    for i in range(n):
        xi = L[i]
        for j in range(i, n):
            xj = L[j]
            sums.add(xi + xj)
            diffs.add(xi - xj)
            diffs.add(xj - xi)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _fast_counts(a):
    a = sorted(set(a))
    n = len(a)
    sums = set()
    diffs = set()
    for i in range(n):
        xi = a[i]
        for j in range(i, n):
            sums.add(xi + a[j])
            diffs.add(xi - a[j])
            diffs.add(a[j] - xi)
    return len(diffs), len(sums)

def _score_fast(a):
    d, s = _fast_counts(a)
    n = len(a)
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100

# --- Bose-Chowla / Singer-style Sidon construction over GF(q) ---
def _gf_mul_tables(q):
    # build GF(q) for prime q only (simpler, valid)
    mul = [[0]*q for _ in range(q)]
    for i in range(q):
        for j in range(q):
            mul[i][j] = (i*j) % q
    return mul

def bose_chowla(p):
    """Sidon set in Z_{p^2-1} using {(a, a^2) -> a*p + b} via Bose construction over GF(p)."""
    # Bose construction: for prime p, set of p elements in Z_{p^2-1}:
    # Use index representation of GF(p^2) = GF(p)[x]/(x^2 - g), primitive element theta.
    # Simpler: use the Singer difference set / Bose set via mapping a in GF(p) -> integer.
    # We'll use the classical "B_2 set" from Bose: choose primitive polynomial x^2 - c x - d.
    # Search small c,d so that x^2 - c x - d is primitive over GF(p) and generate.
    pass

def bose_sidon(p):
    """Return a Sidon set (mod p^2-1) of size p over GF(p) using Bose's construction:
    choose alpha a primitive element of GF(p^2), elements are exponents of (theta - a) for a in GF(p)."""
    # Represent GF(p^2) as pairs (u,v) with x = u + v*theta, theta^2 = t*theta + u0.
    # Find primitive polynomial of degree 2 over GF(p).
    def poly_mul(a, b, t, u0):
        # (a1 + a2 theta)(b1 + b2 theta)
        a1, a2 = a
        b1, b2 = b
        c1 = (a1*b1 + a2*b2*u0) % p
        c2 = (a1*b2 + a2*b1 + a2*b2*t) % p
        return (c1, c2)

    def find_primitive():
        for t in range(p):
            for u0 in range(p):
                if u0 == 0:
                    continue
                # x^2 - t x - u0 should be irreducible: no root r with r^2 = t*r + u0
                has_root = False
                for r in range(p):
                    if (r*r - t*r - u0) % p == 0:
                        has_root = True
                        break
                if has_root:
                    continue
                # check multiplicative order of theta = (0,1) is p^2-1
                order = p*p - 1
                # factor order
                n = order
                facs = []
                d = 2
                while d*d <= n:
                    if n % d == 0:
                        facs.append(d)
                        while n % d == 0:
                            n //= d
                    d += 1
                if n > 1:
                    facs.append(n)
                el = (0, 1)
                ok = True
                for f in facs:
                    e = order // f
                    # compute el^e
                    res = (1, 0)
                    base = el
                    ee = e
                    while ee > 0:
                        if ee & 1:
                            res = poly_mul(res, base, t, u0)
                        base = poly_mul(base, base, t, u0)
                        ee >>= 1
                    if res == (1, 0):
                        ok = False
                        break
                if ok:
                    return t, u0
        return None

    prim = find_primitive()
    if prim is None:
        return None
    t, u0 = prim

    # Build discrete log table: log[g] = e such that g^e = theta^e
    N = p*p - 1
    log = {}
    cur = (1, 0)
    for e in range(N):
        log[cur] = e
        cur = poly_mul(cur, (0, 1), t, u0)

    # Bose set: { log(theta - a) : a in GF(p) }, with theta - a = (-a, 1)
    S = set()
    for a in range(p):
        elem = ((-a) % p, 1)
        if elem in log:
            S.add(log[elem])
    return sorted(S)

def find_best_construction(n_target):
    """Try various p to get size ~n_target and pick one with good ratio."""
    best = None
    best_ratio = -1
    # p near sqrt gives size p, in modulus p^2-1
    p_est = int(math.sqrt(n_target)) + 1
    for p in range(max(3, p_est - 5), p_est + 6):
        # primality check
        if any(p % d == 0 for d in range(2, int(p**0.5)+1)):
            continue
        s = bose_sidon(p)
        if s is None or len(s) < 3:
            continue
        # normalize shift
        mn = min(s)
        s = [x - mn for x in s]
        d, sm = _fast_counts(s)
        if sm <= 1:
            continue
        r = math.log(d) / math.log(sm)
        if r > best_ratio:
            best_ratio = r
            best = s
    return best

def local_search(seed, deadline, budget_scale=1.0):
    a = sorted(set(seed))
    if len(a) < 3:
        return a
    cur_score = _score_fast(a)
    best = a[:]
    best_score = cur_score
    # Candidate moves: tweak elements
    span = max(a) - min(a) if a else 10
    steps = max(1, span // max(1, len(a)//2))
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6:
            i = random.randrange(len(cand))
            delta = random.choice([-1, 1]) * random.randint(1, max(1, steps))
            cand[i] += delta
            if cand[i] in cand[:i] + cand[i+1:]:
                continue
        elif op < 0.8:
            # add near boundary
            lo = min(cand)
            hi = max(cand)
            v = random.randint(lo - steps, hi + steps)
            if v in cand:
                continue
            cand.append(v)
        else:
            if len(cand) <= 3:
                continue
            i = random.randrange(len(cand))
            del cand[i]
        if len(cand) > 4000:
            continue
        s = _score_fast(sorted(cand))
        if s > best_score:
            best = sorted(cand)
            best_score = s
            cur = sorted(cand)
            cur_score = s
        elif s > cur_score or random.random() < 0.05:
            cur = sorted(cand)
            cur_score = s
    return best

def solve():
    best_overall = None
    best_overall_score = -1
    deadline = time.time() + 110

    # Try seed constructions
    for n_target in [40, 60, 80, 100, 120, 150, 200, 250, 300]:
        seed = find_best_construction(n_target)
        if seed is None or len(seed) < 3:
            continue
        # quick local search
        remaining = deadline - time.time()
        if remaining <= 2:
            break
        s = _score_fast(seed)
        if s > best_overall_score:
            best_overall_score = s
            best_overall = seed[:]

    # Now focused local search from best seed
    if best_overall is None:
        # fallback: small example
        best_overall = [0, 1, 3]
        best_overall_score = _score_fast(best_overall)

    # Multi-restart local search
    seeds = [best_overall]
    # Include few variants
    for _ in range(3):
        v = best_overall[:]
        random.shuffle(v)
        seeds.append(v)

    per_seed_time = max(1.0, (deadline - time.time()) / max(1, len(seeds)))
    for sd in seeds:
        remaining = deadline - time.time()
        if remaining <= 0.5:
            break
        sub_deadline = min(deadline, time.time() + per_seed_time)
        res = local_search(sd, sub_deadline)
        sc = _score_fast(res)
        if sc > best_overall_score:
            best_overall = res
            best_overall_score = sc

    return sorted(set(best_overall))
