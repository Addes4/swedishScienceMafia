import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2 or ld < 1:
        return -1e9, ld, ls
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100, ld, ls

def solve():
    rng = random.Random(1234567)
    best = None
    best_score = -1e9

    # Build candidate bases: powers of small integers (geometric progressions)
    candidates = []
    for base in (2, 3, 4, 5, 6, 7, 8, 9, 10):
        for n in (8, 12, 16, 20, 25, 30, 40, 50, 60, 80, 100, 150, 200, 300, 500, 800, 1200):
            if base == 2 and n > 60:
                continue
            vals = []
            v = 1
            ok = True
            for i in range(n):
                vals.append(v)
                v *= base
                if abs(v) > 10**15:
                    ok = False
                    break
            if not ok or len(vals) < 2:
                continue
            candidates.append(vals)

    # also shift/scale variations and random nearby tweaks
    for vals in candidates:
        s, ld, ls = _score(vals)
        if s > best_score:
            best_score = s
            best = vals[:]

    # Local search: adjust individual elements while keeping distinctness
    deadline = time.time() + 100
    # Use a working copy from the best candidate found
    if best is None:
        best = [1, 2, 4, 8, 16, 32, 64, 128]
        best_score, _, _ = _score(best)

    cur = best[:]
    cur_score = best_score

    # Precompute magnitudes for scaling step sizes
    def fast_score(a):
        a = list(set(a))
        n = len(a)
        if n < 2:
            return -1e9, n
        diffs = set()
        sums = set()
        for i in range(n):
            ai = a[i]
            for j in range(i, n):
                sums.add(ai + a[j])
                diffs.add(ai - a[j])
                diffs.add(a[j] - ai)
        ld = len(diffs)
        ls = len(sums)
        if ls < 2:
            return -1e9, n
        return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100, n

    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        n = len(cand)
        # choose an element and perturb it, respecting power-like spacing
        idx = rng.randrange(n)
        old = cand[idx]
        # step based on typical gap at this position
        if n > 1:
            scale = max(1, abs(old))
        else:
            scale = 1
        step = rng.choice([-1, 1]) * rng.randint(1, max(1, scale // 2 + 1))
        cand[idx] = old + step
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s, _ = fast_score(cand)
        if s > cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif rng.random() < 0.02:
            # occasional restart from best
            cur = best[:]
            cur_score = best_score

    return sorted(set(int(x) for x in best))
