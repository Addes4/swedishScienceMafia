import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    if len(sums) == 1:
        return 1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    best = None
    best_score = -1.0
    random.seed(12345)

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2:
            return
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a

    # geometric constructions
    for base in [2, 3, 4, 5]:
        # small perturbation of exact powers to break symmetry
        for n in range(3, 60):
            a = []
            v = 1
            for i in range(n):
                a.append(v)
                v *= base
            consider(a)

    # random affine perturbations around geometric progression
    deadline = time.time() + 100
    while time.time() < deadline:
        n = random.randint(6, 50)
        base = random.choice([2, 3, 4, 5])
        a = []
        v = 1
        for i in range(n):
            a.append(v + random.randint(-3, 3))
            v *= base
        consider(a)

        # mix geometric blocks
        n1 = random.randint(3, 20)
        n2 = random.randint(3, 20)
        a = []
        v = 1
        for i in range(n1):
            a.append(v + random.randint(-2, 2))
            v *= 2
        w = random.choice([-1, 1, 3, 5])
        v = 1
        for i in range(n2):
            a.append(w * v + random.randint(-2, 2))
            v *= random.choice([2, 3])
        consider(a)

    # local search on best so far
    cur = best[:] if best else [1, 2, 4, 8, 16]
    cur_score = _score(cur)
    local_deadline = time.time() + 100
    while time.time() < local_deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 0, 1, 2]) * max(1, abs(cand[i]) // 10)
        elif op < 0.8:
            cand.append(random.choice([2 ** random.randint(1, 50), random.randint(1, 10 ** 6)]))
        else:
            if len(cand) > 6:
                cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur, cur_score = best[:], best_score

    return sorted(set(best)) if best else [1, 2, 4, 8, 16]
