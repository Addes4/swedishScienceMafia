import math, random, time

def _stats(a):
    a = list(set(a))
    if len(a) < 2:
        return 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)

def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return -1e9
    nd, ns = _stats(a)
    return math.log(nd) / math.log(ns) + (1 - 1.0 / len(a)) / 100

def _fast_score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100

def _greedy(n, base):
    # a set with small sum set: interval, plus sparse large values to add differences
    A = list(range(0, n))
    return A

def solve():
    """Return a list of distinct integers A."""
    random.seed(12345)
    best = None
    best_score = -1e9

    # Try several structured constructions
    candidates = []

    # 1) Symmetric-ish sets: [0, n) mostly, but shifted patterns designed to reduce sum collisions
    # A classic trick: numbers of form i * M with a small dense block for small sums.
    # Actually the best ratio comes from Sidon sets on differences but anti-Sidon on sums.
    # Known: A = { 2^i } gives huge differences and also huge sums (ratio ~1). Bad.
    # Sets on a line: interval gives ratio 1. We want differences large, sums small.
    # Idea: take {1,...,n} you get |A+A|=2n-1, |A-A|=2n-1, ratio 1.
    # To increase differences without increasing sums, add a large element L.
    # Sums with L: {L+a} adds ~n new sums. Differences with L: {L-a} and {a-L} adds ~2n.
    # Slight gain. Add many large elements spaced so their pairwise sums collide?

    # Try a "near interval plus scaled copy" construction:
    for n in [20, 40, 60, 80, 120, 200]:
        for L in [10**6, 10**9, 10**12]:
            A = list(range(n))
            A.append(L)
            A.append(L + 1)
            A.append(L + 2)
            candidates.append(A)

    # A set designed so many sums coincide: like {0..n-1} shifted
    # Actually all integers in [a,b] have |A+A|=2(b-a)+1 and |A-A|=2(b-a)+1, ratio 1.

    # For ratio > 1, take A = interval minus midpoint? Hmm.

    # Known optimum for these problems: "weak Sidon" style. Let's just do strong local search
    # starting from medium intervals plus noise.

    for n in [30, 50, 80, 120, 200, 400, 800]:
        A = list(range(n))
        candidates.append(A)

    # try random subsets of ranges
    for _ in range(30):
        n = random.randint(10, 60)
        maxv = random.randint(50, 5000)
        A = sorted(random.sample(range(maxv), n))
        candidates.append(A)

    # Evaluate candidates
    for A in candidates:
        s = _fast_score(A)
        if s > best_score:
            best_score = s
            best = list(A)

    # Local search
    deadline = time.time() + 100
    cur = list(best)
    cur_score = best_score

    while time.time() < deadline:
        cand = list(cur)
        op = random.random()
        if op < 0.5 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-3,-2,-1,1,2,3, -10, 10, -100, 100])
        elif op < 0.75:
            cand.append(random.randint(-10**6, 10**6))
        elif op < 0.9 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # big jump: shift a value
            i = random.randrange(len(cand))
            cand[i] += random.randint(-10000, 10000)

        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _fast_score(cand)
        if s > cur_score or (random.random() < 0.02 and s > cur_score - 0.05):
            cur = cand
            cur_score = s
            if s > best_score:
                best = list(cand)
                best_score = s

        # occasionally restart from best
        if random.random() < 0.005:
            cur = list(best)
            cur_score = best_score

    # Final try: build from interval + sparse points with explicit sum collision
    # Interval [0, m) : sums cover [0, 2m-2], size 2m-1. diffs cover [-(m-1), m-1], size 2m-1.
    # Adding L: sums add {L+a}: [L, L+m-1], size m (plus if overlaps?). diffs add {L-a},{a-L}: ~2m.
    # ratio improves slightly. Add many large close together to overlap their sum-ranges.
    for m in [50, 100, 200, 400, 800]:
        A = list(range(m))
        # add a block far away, spaced so their internal sums are small range
        # block of k consecutive integers at L: internal sums cover [2L, 2L+2k-2] size 2k-1
        # differences with base: [L-m+1, L+m-1] size ~2m
        L = 10**7
        k = m
        A += list(range(L, L + k))
        s = _fast_score(A)
        if s > best_score:
            best_score = s
            best = list(A)

    # If adding block helped, try two blocks and tune
    for m in [100, 200, 400]:
        for gap in [10**6, 10**7, 10**9]:
            A = list(range(m))
            A += list(range(gap, gap + m))
            A += list(range(2*gap, 2*gap + m))
            s = _fast_score(A)
            if s > best_score:
                best_score = s
                best = list(A)

    # refine best with local search adding small perturbations
    cur = list(best)
    cur_score = best_score
    end = time.time() + 10
    while time.time() < end:
        cand = list(cur)
        i = random.randrange(len(cand))
        cand[i] += random.choice([-1, 1, -2, 2])
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _fast_score(cand)
        if s > cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best = list(cand)
                best_score = s

    return sorted(set(int(x) for x in best))
