import math
import random
import time


def _score_stats(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    D = len(diffs)
    S = len(sums)
    score = math.log(D) / math.log(S) + (1 - 1 / n) / 100
    return score, D, S


def _score(a):
    return _score_stats(a)[0]


def _base_set(n):
    # Powers of 2 with slight perturbation: differences are huge and mostly distinct,
    # sums of two distinct powers collapse to few values.
    # A = {2^i} gives |A-A| ~ n^2 (all differences distinct), |A+A|: sums of distinct => all distinct,
    # but with adjustment we can shrink sumset: use {2^i} scaled? Let's instead use a "soft" AP.
    # Key trick: A = {3^i}? differences huge, sums distinct too.
    # Better: use set where A+A is small -> arithmetic progression gives S=2n-1, D=2n-1 ratio 1.
    # Need D large while S small. Consider A = AP union far-spaced copy? 
    # Classic: A = {i, M*i}? Let's do: pick a base AP of size k, and a far-shifted geometric part.
    pass


def _construct():
    # Use A = union of a small AP (to keep sums small) plus a large geometric/spread part
    # that adds many distinct differences.
    # Practical: geometric-like but sums get confined because of structure: use A = {i} * base?
    # Actually best known style: use A = {x_i} where x_i = q^i for small q, but sums explode.
    # Let's just do a strong local search seeded with a good construction.
    return [0]


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Candidate constructions
    cands = []

    # Construction 1: powers of 2 (all diffs distinct, all sums distinct => ratio ~2)
    n = 300
    cands.append([2 ** i for i in range(n) if 2 ** i <= 10 ** 15])

    # Construction 2: {1} u {large powers} shifts: A = {2^i} gives D=n^2, S=n^2 -> ratio ~2.
    # Better: A = AP of length k shifted far apart: A = {i for i in range(k)} union {i+M for i in range(k)}
    # sums confined to two blocks.
    # Try A = {i for i in range(k)} u {M + i for i in range(k)} where M big.
    # D ~ k^2*? , S ~ (2k-1) + (2k-1) values? Let's test.

    def make_two_blocks(k, M):
        a = list(range(k))
        a += [M + i for i in range(k)]
        return a

    for k in [50, 100, 200, 400, 800, 1500]:
        for M in [10 ** 6, 10 ** 9, 10 ** 12]:
            cands.append(make_two_blocks(k, M))

    # Construction 3: several blocks
    def make_blocks(k, num_blocks, gap):
        a = []
        for b in range(num_blocks):
            a += [b * gap + i for i in range(k)]
        return a

    for k in [30, 60, 100, 200]:
        for nb in [3, 4, 5, 8, 12]:
            for gap in [10 ** 4, 10 ** 6, 10 ** 9]:
                if k * nb <= 4000:
                    cands.append(make_blocks(k, nb, gap))

    # Construction 4: geometric with ratio just above 1 (like Beatty / near-AP)
    # A = {round(alpha * i) for i} is basically AP.
    # Try A = {i^2} -> diffs i^2-j^2=(i-j)(i+j), many collisions? sums i^2+j^2
    cands.append([i * i for i in range(1, 1000)])
    # A = {i^3}
    cands.append([i ** 3 for i in range(1, 200)])
    # mixed: i and i^2 -> sums: i+j and i^2+j^2 and i+j^2
    a = list(range(1, 200))
    cands.append(a + [i * i for i in range(1, 100)])

    # Evaluate all
    for c in cands:
        c = sorted(set(c))
        if len(c) < 2:
            continue
        if max(abs(x) for x in c) > 10 ** 15:
            continue
        if len(c) > 4000:
            c = c[:4000]
        sc, D, S = _score_stats(c)
        if sc > best_score:
            best_score = sc
            best = c[:]

    # Also try: A = union of APs with huge gaps, plus a scaled copy (sumset controlled by structure)
    # Two-block with big k is promising. Let's refine best by local search.

    if best is None:
        best = [0, 1]
        best_score = _score(best)

    # Hill climbing / simulated annealing on best
    rng = random.Random(12345)

    def eval_fast(a):
        a = set(a)
        return _score_stats(a)

    cur = best[:]
    cur_score = best_score

    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        op = rng.random()
        if op < 0.6 and len(cand) >= 2:
            i = rng.randrange(len(cand))
            delta = rng.choice([-1, 1]) * rng.randint(1, max(1, abs(cand[i]) // 100 + 1))
            cand[i] += delta
        elif op < 0.8:
            # shift a whole block / add large value
            cand.append(rng.randint(-10 ** 15, 10 ** 15) if rng.random() < 0.5 else rng.choice(cand) * 2 + rng.randint(-2, 2))
        else:
            if len(cand) > 2:
                idx = rng.randrange(len(cand))
                cand.pop(idx)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            continue
        if max(abs(x) for x in cand) > 10 ** 15:
            continue
        sc, D, S = _score_stats(cand)
        if sc > cur_score or rng.random() < 0.005:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc

    return sorted(set(best))
