import math
import time

def solve():
    deadline = time.time() + 110

    def score(a):
        a = list(a)
        n = len(a)
        if n < 2:
            return 0.0
        diffs = set()
        for x in a:
            for y in a:
                diffs.add(x - y)
        sums = set()
        for x in a:
            for y in a:
                sums.add(x + y)
        return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

    # Geometric progression 1,2,4,...,2^(n-1): |A+A| = 2n-1, |A-A| = n(n-1)+1
    # ratio = log(n^2)/log(2n)
    def geo(n, base=2):
        a = [1]
        for _ in range(n - 1):
            a.append(a[-1] * base)
        return a

    # Analyze theoretical best for geometric
    best = None
    best_score = -1.0

    # Try various n and bases within integer limits (|a| <= 1e15)
    # 2^49 ~ 5.6e14 fits. So n up to ~50 for base 2.
    for base in (2,):
        maxpow = int(math.log(1e15) / math.log(base))
        for n in range(2, maxpow + 1):
            a = geo(n, base)
            if max(a) > 10**15:
                continue
            s = score(a)
            if s > best_score:
                best_score = s
                best = a[:]

    # For large n we cannot use pure powers of 2 (overflow).
    # Use a sparse-ish construction: choose numbers as sums of distinct small powers
    # so that sums are limited but differences many.
    # Approach: take a set that is an arithmetic-like near-Sidon in a bounded range.
    # Since sum set small is key: use A = {0} union scaled geometric pieces? 
    # Simpler: build A as union of geometric progressions with large gaps.
    # Actually for max ratio we want |A+A| minimal. Geometric is optimal-ish.

    # Try "shifted geometric in blocks": numbers = sum of coefficients 0/1 over powers of M
    # with small support -> small sums but many diffs.
    # Let's do a randomized/heuristic search: maintain set of distinct integers, minimize |A+A| generally.

    # Direct construction maximizing ratio for larger n using base slightly > 2 to fit more elements?
    # base b: max = b^(n-1) <= 1e15 => n <= 1 + 15*log(10)/log(b).
    # ratio ~ log(n^2)/log(2n). For b larger, n smaller, ratio smaller. So base 2 best.
    # With base 2, n ~ 50 max. Let's push further using "second differences" trick:
    # A = {2^i} gives sums all 2^i+2^j, but 2^i+2^i = 2^(i+1) collapses. |A+A| = n(n+1)/2
    # Wait: sums of distinct pairs: 2^i + 2^j for i<j gives C(n,2) plus doubles 2^(i+1): 
    # distinct count ~ n(n-1)/2 + n = n(n+1)/2? Actually 2^i+2^j >= 2^(j+1) region unique.
    # Let's just compute honestly. We already do via score().

    # Extend beyond 50 elements: use numbers of form i * 2^49? No, sums big but count small?
    # Alternative: use "almost geometric": a_i = round(2^i * (1 + eps_i)) won't help sums.

    # Key insight: To get many elements within 1e15 with small sum set, use Sidon-like in sums:
    # But minimal sum set for n elements is 2n-1 (arithmetic progression), giving diff set 2n-1 too.
    # Geometric gives sum set ~ 2n and diff set ~ n^2. That's the win.

    # To go beyond n=50, use base e.g. 1.5? No, must be integers, sums collapse less.
    # Actually with base b close to 1 (like all small integers), sums collapse more -> bad ratio.
    # The ratio needs |A+A| small relative. For arithmetic progression both are 2n-1, ratio ~1.
    # For geometric, ratio ~ log(n^2)/log(2n) ~ 2. Best with large n.

    # Try large n with a different integer construction: 
    # A = {floor(c * phi^i)}? sums might be smaller set but hard.
    # Let's just try known good: use n up to limited by 1e15 with base 2, plus 
    # try scaling down a larger set: pick 4000 elements as subset of integers whose
    # pairwise sums take few values is impossible beyond n=50 for geometric.

    # Fallback: brute improve the n=50 geometric set with small perturbations.
    if best is None:
        best = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512]

    # Local search to slightly improve sum-collapse while keeping/improving diff
    n = len(best)
    best = best[:]
    best_score = score(best)

    # Perturb: replace largest element region with adjusted values
    import random
    random.seed(12345)
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        delta = random.randint(-2, 2)
        cand[i] += delta
        if cand[i] in cand:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue
        try:
            s = score(cand)
        except Exception:
            continue
        if s >= cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    # Also try "double geometric" concatenation trick to increase n:
    # A = G1 + G2 where G1 = {0,1,2,...}? Not helpful.

    return sorted(set(best))
