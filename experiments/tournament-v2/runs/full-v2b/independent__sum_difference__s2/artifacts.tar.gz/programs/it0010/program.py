import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0

def _build_geometric(n, base=3):
    A = [0]
    v = 1
    for _ in range(n - 1):
        A.append(v)
        v *= base
    return A

def _build_shifted(n, base=3):
    A = _build_geometric(n, base)
    m = (min(A) + max(A)) // 2
    return [x - m for x in A]

def solve():
    random.seed(12345)
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    deadline = time.time() + 115.0

    # Try geometric sets of various sizes and bases
    for n in range(4, 60):
        for base in range(2, 9):
            cand = _build_shifted(n, base)
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s

    # Local search on top of best geometric
    cur = best[:]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.6 and len(cand) > 2:
            i = random.randrange(len(cand))
            mag = max(1, abs(cand[i]) // 10 + 1)
            cand[i] += random.randint(-mag, mag)
        elif op < 0.85:
            if len(cand) < 200:
                v = random.choice(cand) if cand else 0
                cand.append(v + random.randint(-5, 5))
        else:
            if len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        s = _score(cand)
        if s > cur_score:
            best, best_score = cand[:], s
            cur, cur_score = cand[:], s
        elif random.random() < 0.05:
            cur, cur_score = cand[:], s

    return sorted(set(best))
