import math
import random
import time


def _score_stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diff = ai - a[j]
            s = ai + a[j]
            diffs.add(diff)
            sums.add(s)
    d = len(diffs)
    s = len(sums)
    if s < 2:
        return -1.0, d, s
    score = math.log(d) / math.log(s) + (1 - 1 / n) / 100
    return score, d, s


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Try multiple construction strategies
    constructions = []

    # Strategy: scaled Sidon-like sets using powers / greedy Sidon construction
    # Build a Sidon set greedily: numbers such that all pairwise differences distinct
    def greedy_sidon(limit, maxsize):
        s = []
        used_diffs = set()
        x = 0
        while len(s) < maxsize and x <= limit:
            ok = True
            new_diffs = []
            for y in s:
                d1 = x - y
                d2 = y - x
                if d1 in used_diffs or d2 in used_diffs:
                    ok = False
                    break
                new_diffs.append(d1)
                new_diffs.append(d2)
            if ok:
                for d in new_diffs:
                    used_diffs.add(d)
                s.append(x)
            x += 1
        return s

    # Sidon sets of various sizes
    for size in [10, 20, 30, 50, 80, 120, 200, 300, 500, 800, 1200, 2000, 3000]:
        limit = size * size * 2
        sid = greedy_sidon(limit, size)
        if len(sid) >= 2:
            constructions.append(sid)

    # Random Sidon-like via modular construction
    for _ in range(20):
        m = random.randint(50, 2000)
        size = random.randint(10, 200)
        nums = set()
        for _ in range(size * 3):
            nums.add(random.randint(0, m))
        constructions.append(sorted(nums))

    # Base small sets
    constructions.append([7, 15, 18, 22, -3, -2])
    constructions.append([0, 1, 3, 7, 12, 20])

    for cand in constructions:
        cand = list(set(cand))
        if len(cand) >= 2:
            sc, _, _ = _score_stats(cand)
            if sc > best_score:
                best_score = sc
                best = cand[:]

    # Local search: try modifying elements to reduce sum set while keeping diff set large
    def local_search(start, tl):
        cur = start[:]
        cur = list(set(cur))
        cs, cd, css = _score_stats(cur)
        if cs < 0:
            return start, -1.0
        best_local = cur[:]
        bls = cs
        n = len(cur)
        temp = 1.0
        steps = 0
        while time.time() < tl:
            steps += 1
            if steps % 2000 == 0:
                temp *= 0.995
            cand = cur[:]
            op = random.random()
            i = random.randrange(len(cand))
            if op < 0.4:
                # small perturbation
                cand[i] += random.randint(-3, 3)
            elif op < 0.7:
                # larger perturbation
                cand[i] += random.randint(-50, 50)
            elif op < 0.85 and len(cand) < 3800:
                cand.append(random.randint(-100, 100))
            elif len(cand) > 3:
                del cand[i]
            cand = list(set(cand))
            if len(cand) < 2:
                continue
            sc, d, s = _score_stats(cand)
            if s < 2:
                continue
            if sc > bls or random.random() < math.exp((sc - bls) / max(temp, 1e-6)):
                cur = cand
                if sc > bls:
                    bls = sc
                    best_local = cand[:]
        return best_local, bls

    # Run local search on best candidates
    cands_sorted = sorted(constructions, key=lambda c: -_score_stats(list(set(c)))[0])[:5]
    per = max(1.0, (deadline - time.time()) / len(cands_sorted))
    for c in cands_sorted:
        if time.time() >= deadline:
            break
        tl = min(deadline, time.time() + per)
        res, sc = local_search(list(set(c)), tl)
        if sc > best_score:
            best_score = sc
            best = res[:]

    # final refinement near best
    if time.time() < deadline:
        res, sc = local_search(best, deadline)
        if sc > best_score:
            best = res

    best = sorted(set(best))
    return best
