import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    dn = len(diffs)
    sn = len(sums)
    if sn <= 1 or dn <= 0:
        return 0.0, dn, sn
    score = math.log(dn) / math.log(sn) + (1.0 - 1.0 / n) / 100.0
    return score, dn, sn


def _score(a):
    return _stats(a)[0]


def _build_symmetric(n, span):
    # Symmetric set around 0; sums set size ~ n^2/4 roughly, but structure reduces overlap.
    # Use a Sidon-like base union a dense block.
    # Base: powers / geometric-ish spread to maximize distinct differences.
    base = []
    x = 1
    step = 1
    while len(base) < n:
        base.append(x)
        base.append(-x)
        x += step
        step += 0
    base = base[:n]
    if 0 not in base:
        base[0] = 0
    return sorted(set(base))


def _greedy_construct(n, span, deadline, rng):
    # Build set incrementally: add element minimizing increase of sum set size while
    # maximizing increase of difference set.
    chosen = [0]
    # candidate pool
    pool = []
    for i in range(1, span + 1):
        pool.append(i)
        pool.append(-i)
    rng.shuffle(pool)
    pool_iter = iter(pool)

    diff_set = {0}
    sum_set = {0}

    while len(chosen) < n and time.time() < deadline:
        best_el = None
        best_ratio = None
        # sample some candidates
        tries = 0
        max_tries = 60
        while tries < max_tries:
            try:
                c = next(pool_iter)
            except StopIteration:
                break
            tries += 1
            if c in diff_set and c != 0:
                # already present in chosen
                pass
            if c in chosen:
                continue
            # compute new sums/diffs
            new_sums = set()
            new_diffs = set()
            for d in chosen:
                new_sums.add(d + c)
                new_diffs.add(d - c)
                new_diffs.add(c - d)
            add_s = len(new_sums - sum_set)
            add_d = len(new_diffs - diff_set)
            if add_s == 0:
                continue
            ratio = add_d / add_s
            if best_ratio is None or ratio > best_ratio:
                best_ratio = ratio
                best_el = c
                best_new_sums = new_sums
                best_new_diffs = new_diffs
        if best_el is None:
            # fall back: add farthest candidate
            try:
                c = next(pool_iter)
            except StopIteration:
                break
            if c in chosen:
                continue
            best_el = c
            best_new_sums = {d + c for d in chosen}
            best_new_diffs = set()
            for d in chosen:
                best_new_diffs.add(d - c)
                best_new_diffs.add(c - d)
        chosen.append(best_el)
        sum_set |= best_new_sums
        diff_set |= best_new_diffs

    return chosen


def solve():
    deadline_total = time.time() + 110
    rng = random.Random(12345)

    best = [0]
    best_score = -1.0

    candidates_n = [40, 80, 150, 300, 600, 1000, 1500, 2000, 2800, 3500, 3999]
    candidates_span = [50, 100, 200, 400, 800, 1600, 3200, 6400]

    for n in candidates_n:
        if time.time() > deadline_total:
            break
        for span in candidates_span:
            if time.time() > deadline_total:
                break
            if span < n // 2:
                continue
            a = _greedy_construct(n, span, deadline_total, rng)
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a[:]

    # local search refinement
    cur = best[:]
    cur_score = _score(cur)
    n = len(cur)
    if n < 2:
        return [0, 1]

    # Precompute using incremental updates would be ideal but n up to 4000 => O(n^2) per eval.
    # We'll do a bounded number of moves.
    while time.time() < deadline_total:
        cand = cur[:]
        op = rng.random()
        if op < 0.5:
            # perturb an element
            i = rng.randrange(len(cand))
            delta = rng.choice([-100, -10, -3, -1, 1, 3, 10, 100])
            newv = cand[i] + delta
            if abs(newv) > 10**15:
                continue
            cand[i] = newv
        elif op < 0.8:
            # add element
            if len(cand) < 4000:
                newv = rng.randint(-10**6, 10**6)
                cand.append(newv)
        else:
            # remove element
            if len(cand) > 3:
                j = rng.randrange(len(cand))
                cand.pop(j)

        # dedupe
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]
        elif rng.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
