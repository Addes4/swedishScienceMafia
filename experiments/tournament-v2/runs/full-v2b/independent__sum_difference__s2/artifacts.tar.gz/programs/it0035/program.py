import math
import random
import time


def _score(a):
    if len(a) < 2:
        return -1e9, 0, 0

    diffs = set()
    sums = set()

    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)

    nd = len(diffs)
    ns = len(sums)
    if ns <= 1:
        return -1e9, nd, ns

    val = math.log(nd) / math.log(ns) + (1.0 - 1.0 / len(a)) / 100.0
    return val, nd, ns


def _greedy_random(start_values, target_size, seed):
    rng = random.Random(seed)
    A = []
    used = set()

    vals = start_values[:]
    rng.shuffle(vals)

    for v in vals:
        if len(A) >= target_size:
            break
        if v not in used:
            A.append(v)
            used.add(v)

    pool = list(range(-150, 151)) + list(range(-30, 31))
    rng.shuffle(pool)

    while len(A) < target_size and pool:
        if rng.random() < 0.85:
            best_v = None
            best_s = None
            sample = pool[: min(80, len(pool))]
            rng.shuffle(sample)

            for v in sample:
                if v in used:
                    continue
                cand = A + [v]
                s, _, _ = _score(cand)
                if best_s is None or s > best_s:
                    best_s = s
                    best_v = v

            if best_v is not None:
                A.append(best_v)
                used.add(best_v)
                if best_v in pool:
                    pool.remove(best_v)
                continue

        v = pool.pop()
        while v in used and pool:
            v = pool.pop()
        if v not in used:
            A.append(v)
            used.add(v)

    return A


def _local_search(A, deadline):
    A = list(set(A))
    best = A[:]
    best_score, _, _ = _score(best)

    rng = random.Random(12345)

    while time.time() < deadline:
        cand = A[:]
        op = rng.random()

        if op < 0.55:
            i = rng.randrange(len(cand))
            delta = rng.choice([-30, -20, -16, -12, -8, -5, -3, -2, -1, 1, 2, 3, 5, 8, 12, 16, 20, 30])
            cand[i] += delta
        elif op < 0.75:
            if len(cand) > 3:
                j = rng.randrange(len(cand))
                cand.pop(j)
        elif op < 0.9:
            v = rng.randint(-200, 200)
            if v not in cand:
                cand.append(v)
        else:
            i = rng.randrange(len(cand))
            j = rng.randrange(len(cand))
            cand[i], cand[j] = cand[j], cand[i]

        cand = list(set(cand))
        if len(cand) < 2:
            continue

        s, _, _ = _score(cand)

        if s >= best_score:
            A = cand
            if s > best_score:
                best = cand[:]
                best_score = s
        elif rng.random() < 0.02:
            A = best[:]
        elif rng.random() < 0.15:
            A = cand[:]

    return best


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    start = time.time()
    deadline = start + 115

    best = None
    best_score = -1e18

    # Try several constructions, including known good seeds for difference-rich sets.
    seeds = [
        [0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96, 122, 147],
        [1, 2, 5, 10, 16, 27, 38, 51, 66, 83, 102, 123, 147, 172],
        list(range(0, 100, 3)),
        list(range(0, 60)),
        [-(i * i) for i in range(1, 25)] + [(i * i) for i in range(1, 25)],
        [-(i * i * i) for i in range(1, 16)] + [(i * i * i) for i in range(1, 16)],
    ]

    # Build a large base set with good difference/sum behavior, then optimize it.
    for seed_idx, seed in enumerate(seeds):
        if time.time() > deadline - 20:
            break

        for target in [80, 160, 240, 320]:
            if time.time() > deadline - 15:
                break

            A = _greedy_random(seed, target, seed_idx * 1000 + target)

            s, nd, ns = _score(A)
            if s > best_score:
                best = A[:]
                best_score = s

            # A short polishing phase.
            local_deadline = min(deadline, time.time() + 3.0)
            B = _local_search(A, local_deadline)
            sb, ndb, nsb = _score(B)
            if sb > best_score:
                best = B[:]
                best_score = sb

    # Long final local search from the best found set.
    if best is not None and time.time() < deadline:
        best = _local_search(best, deadline)

    # Ensure valid constraints.
    best = list(set(best))
    best = [x for x in best if abs(x) <= 10**15]
    if len(best) > 4000:
        best = best[:4000]
    if len(best) < 2:
        best = [0, 1]

    return sorted(best)
