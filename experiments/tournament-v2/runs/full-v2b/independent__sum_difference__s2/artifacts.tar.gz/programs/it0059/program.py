import math
import random
import time


def _score_a(a):
    n = len(a)
    if n < 2:
        return 0.0
    s = set(a)
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _score_tuple(a):
    return _score_a(a)


def _greedy_improve(a, deadline):
    """Local search improving either diffs or sums by small integer moves."""
    a = sorted(set(a))
    best = a[:]
    best_score = _score_tuple(best)

    while time.time() < deadline:
        improved = False
        # try shifting one element
        for i in range(len(a)):
            base = a[i]
            for delta in (-17, -11, -7, -5, -3, -2, -1, 1, 2, 3, 5, 7, 11, 17):
                cand = a[:]
                cand[i] = base + delta
                if len(set(cand)) != len(cand):
                    continue
                cand = sorted(cand)
                sc = _score_tuple(cand)
                if sc > best_score + 1e-15:
                    best = cand
                    best_score = sc
                    a = cand
                    improved = True
                    break
            if improved:
                break
        if improved:
            continue

        # try replacing an element
        n = len(a)
        for i in range(n):
            for val in (a[i] - 37, a[i] - 23, a[i] - 13, a[i] + 13, a[i] + 23, a[i] + 37):
                cand = a[:]
                cand[i] = val
                if len(set(cand)) != len(cand):
                    continue
                cand = sorted(cand)
                sc = _score_tuple(cand)
                if sc > best_score + 1e-15:
                    best = cand
                    best_score = sc
                    a = cand
                    improved = True
                    break
            if improved:
                break
        if not improved:
            break
    return best


def _construction_from_basis(basis, scale, shift):
    """A = shift + sum of digits*basis powers, digits in {0,1} limited pattern."""
    pts = [shift]
    for b in basis:
        pts = pts + [x + b for x in pts]
    return sorted(set(pts))


def _random_search(n_target, deadline):
    best = [0, 1]
    best_score = _score_tuple(best)

    while time.time() < deadline:
        # random sum-free-like set via greedy random
        a = set()
        a.add(0)
        while len(a) < n_target:
            x = random.randint(-10**6, 10**6)
            a.add(x)
        a = sorted(a)
        sc = _score_tuple(a)
        if sc > best_score:
            best = a
            best_score = sc

        a = _greedy_improve(a, min(deadline, time.time() + 0.5))
        sc = _score_tuple(a)
        if sc > best_score:
            best = a
            best_score = sc
            n_target = min(4000, max(8, len(best) + random.choice([0, 1, 2])))
    return best


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110

    candidates = []

    # 1) classic powers of 2 construction: A = {0,1,2,4,...,2^{k-1}}
    # differences are mostly unique-ish, sums have many collisions
    for k in (10, 12, 14, 16, 18, 20):
        a = [1 << i for i in range(k)]
        candidates.append(a)

    # 2) scaled powers with offsets, sometimes better
    for k in (12, 14, 16, 18):
        for s in (1, 2, 3, 5):
            for t in (0, 1, 2, 3, 5):
                a = [t + s * (1 << i) for i in range(k)]
                candidates.append(a)

    # 3) greedy/base constructions with digit sums in small set
    # use Sylvester-like / Stanley sequences
    def stanley_sequence(length, seed=(0, 1, 3)):
        a = list(seed)
        seen = set(a)
        S = set(x + y for x in a for y in a)
        while len(a) < length:
            x = a[-1] + 1
            while any((x + y) in S for y in a) or x in seen:
                x += 1
            a.append(x)
            seen.add(x)
            for y in a:
                S.add(x + y)
        return a

    for L in (30, 50, 80, 120):
        candidates.append(stanley_sequence(L))

    # 4) modular construction: A = {i + M*f(i)} for a few residues
    # Try numbers congruent to 0 or 1 mod large modulus, within range.
    for m in (3, 4, 5, 7):
        for cnt in (50, 100, 200, 400):
            a = [m * i + (i % 2) for i in range(cnt)]
            candidates.append(a)

    # 5) powers-of-2 plus small perturbations
    for k in (16, 18, 20):
        base = [1 << i for i in range(k)]
        a = base[:]
        for _ in range(4):
            aa = a[:]
            i = random.randrange(len(aa))
            aa[i] += random.randint(-3, 3)
            if len(set(aa)) == len(aa):
                candidates.append(aa)

    best = None
    best_score = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        c = sorted(set(c))
        sc = _score_tuple(c)
        if sc > best_score:
            best_score = sc
            best = c

    # refine the best candidate
    if best is not None and time.time() < deadline:
        best = _greedy_improve(best, deadline)

    # try random searches if there is time
    if time.time() < deadline:
        cand = _random_search(min(200, max(10, len(best) if best else 50)),
                              min(deadline, time.time() + 25))
        sc = _score_tuple(cand)
        if best is None or sc > best_score:
            best = cand
            best_score = sc

    # final safety
    if not best:
        best = [0, 1]

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    if len(best) < 2:
        best = [0, 1]
    if max(abs(x) for x in best) > 10**15:
        # rescale/shift if needed
        pass

    return best
