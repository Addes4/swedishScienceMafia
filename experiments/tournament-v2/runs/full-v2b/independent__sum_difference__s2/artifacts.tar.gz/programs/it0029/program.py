import math
import random
import time


def _score_vals(vals):
    n = len(vals)
    if n < 2:
        return 0.0
    s = set(vals)
    diffs = set()
    sums = set()
    L = list(s)
    for i in range(len(L)):
        xi = L[i]
        for j in range(len(L)):
            xj = L[j]
            diffs.add(xi - xj)
            sums.add(xi + xj)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score_vals(best)

    deadline = time.time() + 100

    # Try geometric progressions with various bases and lengths.
    for base in [2, 3, 4, 5, 6, 7, 8]:
        for n in [4, 5, 6, 7, 8, 9, 10]:
            vals = []
            p = 1
            for _ in range(n):
                vals.append(p)
                p *= base
            sc = _score_vals(vals)
            if sc > best_score:
                best, best_score = vals[:], sc

    # Try random small perturbations / local search around the best structure.
    rng = random.Random(12345)
    cur = best[:]
    cur_score = best_score

    # local search phase: hill climb with random moves
    t_end = deadline
    it = 0
    while time.time() < t_end:
        it += 1
        cand = cur[:]
        # apply a few mutations
        k = rng.randint(1, 3)
        for _ in range(k):
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-2, 2)
        # occasionally add / remove
        if rng.random() < 0.15:
            cand.append(rng.randint(-5, 5))
        if rng.random() < 0.15 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        cand = list(set(cand))  # distinct
        if len(cand) < 3:
            continue
        sc = _score_vals(cand)
        if sc > cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc
        elif rng.random() < 0.05:
            cur, cur_score = best[:], best_score

    return sorted(set(best))
