import math
import random
import time


def _score_components(a):
    a = set(a)
    n = len(a)
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums), n


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _bose_chowla(p, q):
    """Bose-Chowla construction: A = {2*p*k + (k^2 mod p) : 0 <= k < q}, q <= p."""
    return [2 * p * k + (k * k) % p for k in range(q)]


def solve():
    deadline = time.time() + 110.0

    best = None
    best_score = -1.0

    # ---- Phase 1: Bose-Chowla style Sidon sets (near-perfect difference set) ----
    # Primorial-like primes to allow large q while keeping values bounded.
    # For modulus m, A = {2*m*k + (k^2 mod m)} for k=0..q-1.
    # Use prime m to guarantee Sidon property for q <= m.
    # We want to maximize |A| = q while keeping sums small and ints <= 1e15.
    # 2*m*k grows; with q ~ m, max ~ 2*m^2, so m up to ~2e7 (2*m^2 ~ 8e14).
    prime_candidates = [
        19997, 20011, 29989, 30011, 40009, 50021, 60013, 65537,
        80021, 100003, 150001, 200003, 300007, 500009,
        1000003, 2000003, 3000017, 5000011, 10000019,
    ]

    for p in prime_candidates:
        if time.time() > deadline - 30:
            break
        # choose q as large as possible keeping max value <= 1e15 and <= 4000 elements
        # max value ~ 2*p*(q-1) + p ~ 2*p*q
        max_q = min(p, 4000)
        while max_q > 2:
            A = _bose_chowla(p, max_q)
            if abs(A[-1]) > 10**15:
                max_q = int(max_q * 0.9)
                continue
            break
        A = _bose_chowla(p, max_q)
        if abs(max(A, key=abs)) > 10**15:
            continue
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # ---- Phase 2: local search to reduce the sum set ----
    # Try many starts from best Sidon set, doing small perturbations.
    if best is None:
        best = _bose_chowla(100003, 4000)
        best_score = _score(best)

    cur = best[:]
    cur_score = best_score

    iter_count = 0
    while time.time() < deadline:
        iter_count += 1
        cand = cur[:]
        op = random.random()

        if op < 0.5 and len(cand) >= 2:
            # shift an element
            i = random.randrange(len(cand))
            step = random.choice([1, 2, 3, 5, 7, 11])
            cand[i] += random.choice([-1, 1]) * step
        elif op < 0.7 and len(cand) >= 2:
            # swap/tweak a small block
            i = random.randrange(len(cand))
            j = random.randrange(len(cand))
            cand[i] = cand[j] + random.randint(-5, 5)
        elif op < 0.85 and len(cand) < 4000:
            # add an element near the middle
            mid = cand[len(cand) // 2]
            cand.append(mid + random.randint(-20, 20))
        else:
            # replace an element with a nearby new one
            i = random.randrange(len(cand))
            cand[i] = random.randint(-(10**15) // 2, 10**15 // 2)

        if len(set(cand)) != len(cand):
            continue
        if max(abs(x) for x in cand) > 10**15:
            continue

        s = _score(cand)
        if s >= cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif random.random() < 0.05:
            cur = cand
            cur_score = s

        # occasional restart from global best
        if iter_count % 2000 == 0:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
