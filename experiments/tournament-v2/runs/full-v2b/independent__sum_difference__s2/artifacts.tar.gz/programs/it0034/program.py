import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1 or ld <= 1:
        return -1.0
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def _fast_score(a, sample=None):
    """Approximate score using sampling when set is large."""
    n = len(a)
    if n < 2:
        return -1.0
    diffs = set()
    sums = set()
    if n <= 400:
        for i in range(n):
            ai = a[i]
            for j in range(n):
                diffs.add(ai - a[j])
                sums.add(ai + a[j])
    else:
        idx = list(range(n))
        random.shuffle(idx)
        k = min(n, 150)
        idx = idx[:k]
        for i in idx:
            ai = a[i]
            for j in idx:
                diffs.add(ai - a[j])
                sums.add(ai + a[j])
        # scale estimate
        scale = (n * n) / (len(idx) * len(idx))
        ld = len(diffs) * scale
        ls = len(sums) * scale
        if ls <= 1:
            return -1.0
        return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1 or ld <= 1:
        return -1.0
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def solve():
    random.seed(12345)
    deadline = time.time() + 115

    # Start with a Sidon-like / Golomb ruler base: greedy B_2 sequence
    def greedy_sidon(limit_val, target_size):
        s = [0, 1]
        used_diffs = {0, 1, -1}
        cand = 2
        while len(s) < target_size and cand <= limit_val:
            ok = True
            new_diffs = []
            for x in s:
                d1 = cand - x
                d2 = x - cand
                if d1 in used_diffs or d2 in used_diffs:
                    ok = False
                    break
                new_diffs.append(d1)
                new_diffs.append(d2)
            if ok:
                s.append(cand)
                for d in new_diffs:
                    used_diffs.add(d)
            cand += 1
        return s

    base = greedy_sidon(10**9, 300)
    if len(base) < 50:
        base = list(range(1, 201))

    cur = base[:]
    best = cur[:]
    best_score = _score(best)

    # local search: mutate a few elements, accept improvements
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        # mutate: shift some elements
        k = random.randint(1, 5)
        for _ in range(k):
            i = random.randrange(len(cand))
            delta = random.randint(-50, 50)
            cand[i] += delta
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        # cap to 4000
        if len(cand) > 4000:
            cand = cand[:4000]
        s = _fast_score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]
            cur = cand[:]
        elif random.random() < 0.05:
            cur = best[:]

        # occasionally try appending a new element smartly
        if it % 50 == 0 and len(cur) < 1000:
            m = max(cur) + 1
            trial = cur[:] + [m]
            ts = _fast_score(trial)
            if ts > best_score:
                best_score = ts
                best = trial[:]
                cur = trial[:]

    # Final exhaustive scoring on a subset / final candidate
    # If best too large, restrict to a good prefix
    if len(best) > 500:
        # try to keep only the largest 400
        b2 = sorted(best)[:400]
        s2 = _score(b2)
        if s2 > _score(best[:400]):
            best = b2

    return sorted(set(best))
