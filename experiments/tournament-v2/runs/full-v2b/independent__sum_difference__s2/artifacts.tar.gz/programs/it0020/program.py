import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _greedy_sidon(limit, n):
    """Greedy Sidon set (all pairwise sums distinct) in [0, limit]."""
    A = []
    used_sums = set()
    cands = list(range(0, limit + 1))
    random.shuffle(cands)
    for x in cands:
        if len(A) >= n:
            break
        new = set()
        ok = True
        for a in A:
            s = a + x
            if s in used_sums or s in new:
                ok = False
                break
            new.add(s)
        if ok:
            for a in A:
                used_sums.add(a + x)
            used_sums.add(2 * x)
            A.append(x)
    return A


def _local_refine(A, deadline):
    A = A[:]
    best = A[:]
    best_score = _score(A)
    n = len(A)
    if n < 2:
        return best
    lo = min(A)
    hi = max(A)
    span = hi - lo

    while time.time() < deadline:
        cand = best[:]
        # perturb: move a random element within range
        i = random.randrange(len(cand))
        step = random.randint(-max(1, span // 20), max(1, span // 20))
        cand[i] += step
        if len(set(cand)) != len(cand):
            continue
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s
        elif random.random() < 0.02:
            # occasional restart-ish move accepted
            if s > best_score - 0.05:
                best = cand
                best_score = s

    # try shrinking the sum set by compressing the set
    improved = True
    while improved and time.time() < deadline:
        improved = False
        cand = sorted(best)
        # try to shift so more sums coincide (compress around center)
        for _ in range(60):
            if time.time() > deadline:
                break
            c = cand[:]
            i = random.randrange(len(c))
            delta = random.choice([-1, 1])
            c[i] += delta
            if len(set(c)) != len(c):
                continue
            s = _score(c)
            if s > best_score:
                best = c
                best_score = s
                improved = True
    return best


def solve():
    deadline = time.time() + 110
    best = []
    best_score = -1.0

    # Try several span/n combinations. Sidon sets give |A-A| ~ n^2 and |A+A| ~ n^2/2
    for n in (60, 100, 150, 200, 300, 400):
        if time.time() > deadline - 20:
            break
        # Sidon set max size in [0, L] is about sqrt(L). Use limit ~ 1.2*n^2
        limit = int(1.2 * n * n)
        sub_deadline = min(deadline, time.time() + 15)
        A = _greedy_sidon(limit, n)
        if len(A) < 5:
            continue
        A = _local_refine(A, sub_deadline)
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    if not best:
        best = [0, 1, 4, 9, 15, 22, 32]
        best_score = _score(best)

    return sorted(set(int(x) for x in best))
