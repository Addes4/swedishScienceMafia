# EVOLVE-BLOCK-START
"""Residual-matching bin choice with an adaptive empirical item-size histogram."""
import numpy as np

_state = {"counter": 0, "hist": np.zeros(101, dtype=np.float64), "seen": 0.0}

_TARGETS = np.array([0.0, 20.0, 30.0, 40.0, 50.0, 60.0])

_SIGMA = 8.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update the empirical item-size histogram (for adaptive gap valuation).
    _state["hist"][item] += 1.0
    _state["seen"] += 1.0

    residual = (bins - item).astype(np.float64)  # capacity left if placed here

    # Reward residuals that match a typical future item size (usable gaps),
    # with a moderately sharp kernel so the signal is focused on reusable gaps.
    diff = residual[:, None] - _TARGETS[None, :]
    match = np.exp(-(diff * diff) / (2.0 * _SIGMA * _SIGMA))
    score = match.sum(axis=1)

    # Adaptive component: for each candidate residual r, sum the empirical frequency
    # of item sizes near r. A residual that matches currently common item sizes is
    # more likely to be refilled soon, so it is a better place to put the item.
    hist = _state["hist"]
    seen = _state["seen"]
    if seen >= 50.0:
        freq = hist / seen
        # smooth the freq vector slightly to be robust for integer residual sizes
        k = np.array([0.25, 0.5, 0.25])
        smooth = np.convolve(freq, k, mode="same")
        r_idx = np.clip(residual.astype(np.int64), 0, 100)
        adaptive = smooth[r_idx]
        score += 1.5 * adaptive

    # Strong bonus for exact fits (residual 0).
    score += 1.2 * (residual == 0.0)

    # Bonus when the residual exactly equals a typical item size (a clean reusable gap).
    for t in _TARGETS[1:]:
        score += 0.15 * (residual == t)

    # Penalty for creating unusable slivers: small non-zero residuals below the
    # smallest typical item size are hard to reuse and waste capacity.
    sliver = (residual > 0.0) & (residual < 15.0)
    score -= 0.4 * sliver * (1.0 - residual / 15.0)

    # Mild penalty for awkward "medium-low" residuals (15..25): too large to be
    # filled by the smallest items but too small to host a typical item, so they
    # tend to strand capacity. Ramp is small so it only breaks near-ties.
    awkward = (residual >= 15.0) & (residual < 25.0)
    score -= 0.08 * awkward * (1.0 - np.abs(residual - 20.0) / 5.0)

    # Penalty for opening a brand-new bin.
    new_bin = (residual == (100.0 - item)).astype(np.float64)
    score -= 0.35 * new_bin

    # Small cycling perturbation to vary tie-breaking order.
    n = score.shape[0]
    _state["counter"] += 1
    idx = np.arange(n, dtype=np.float64)
    perturb = ((idx * ((_state["counter"] * 2654435761) % 1000003) + _state["counter"]) % 97) * 1e-4
    score += perturb

    return score
# EVOLVE-BLOCK-END

