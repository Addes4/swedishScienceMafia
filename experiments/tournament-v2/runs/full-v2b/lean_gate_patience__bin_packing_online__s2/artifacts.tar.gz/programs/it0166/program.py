import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        self.hist = np.zeros(101, dtype=np.float64)  # counts of item sizes seen
        self.total = 0.0

_state = _State()


def priority(item, bins):
    s = _state
    s.tick += 1

    # update online histogram before scoring (current item counts too)
    s.hist[item] += 1.0
    s.total += 1.0

    # Build a coarse probability table over sizes 1..100 from the histogram.
    # Smooth a bit so rare/absent sizes still get small probability.
    p = (s.hist[1:] + 0.05) / (s.total + 100 * 0.05)

    # For a given residual r (>=0), estimate the fraction of it we can likely fill
    # by greedily assuming future items follow p. Cheap heuristic: probability that
    # r itself is a likely item size, plus probability that r can be split into two
    # likely sizes (approximated by the max over complements).
    # We precompute reward for each possible residual value 0..100 once when possible.
    # To stay fast we compute per-residual on the fly using vectorized numpy.

    residual = bins - item  # >= 0

    # tightness: favor filling bins tightly (large item/bin ratio)
    tightness = item / bins

    # filler bonus: for each residual, how likely is it that this gap gets used?
    r = residual.astype(np.int64)

    # single-item fill probability
    single = p[np.clip(r - 1, 0, 99)]

    # two-item fill probability (max over split point k): p(k)*p(r-k)
    # vectorized: for each residual value compute via convolution-ish lookup.
    # Build lookup lazily with memo dict on unique residuals.
    uniq, inv = np.unique(r, return_inverse=True)
    fill_lookup = np.empty(uniq.shape[0], dtype=np.float64)
    for i, rv in enumerate(uniq):
        if rv <= 0:
            fill_lookup[i] = 1.0  # perfectly full
            continue
        if rv > 100:
            fill_lookup[i] = 0.0
            continue
        # best chance to fill this residual with up to two items
        k = np.arange(1, rv)  # 1..rv-1
        if k.size:
            two = np.max(p[k - 1] * p[rv - k - 1])
        else:
            two = 0.0
        fill_lookup[i] = max(single[i] if rv <= 100 else 0.0, two) if False else max(
            p[rv - 1], two)
    fill_bonus = fill_lookup[inv]

    # busy-bin bonus: slightly prefer already-open bins
    unused = (bins == 100).astype(np.float64)
    busy_bonus = 0.05 * (1.0 - unused)

    # rotating tie-break for determinism across equal scores
    idx = np.arange(bins.shape[0], dtype=np.float64)
    rot = ((idx + s.tick) % bins.shape[0]) * 1e-6

    score = 2.0 * tightness + 0.8 * fill_bonus + busy_bonus + rot
    return score
