"""Best-fit with usage-aware new-bin aversion and mild consolidation."""
import numpy as np

_state = {"counts": np.zeros(101), "calls": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties go to the earliest bin."""
    _state["calls"] += 1
    counts = _state["counts"]

    residual = bins - item  # >= 0 for fitting bins

    # Core: best fit. Prefer the smallest residual.
    # Emphasize tight fits with a slightly superlinear penalty on residual.
    score = -residual.astype(np.float64) * (1.0 + residual * 0.01)

    # Strong reward for a perfect fit (residual 0).
    score += (residual == 0) * 3.0

    # Discourage opening a brand-new bin: penalty grows with item size,
    # since large items are best placed in existing gaps.
    new_bin = bins == 100
    score -= new_bin * (2.0 + item * 0.1)

    # Mild consolidation: slightly prefer bins that are already fuller
    # (smaller remaining capacity), beyond the best-fit residual term.
    score -= bins.astype(np.float64) * 0.01

    counts[item] += 1.0
    return score
