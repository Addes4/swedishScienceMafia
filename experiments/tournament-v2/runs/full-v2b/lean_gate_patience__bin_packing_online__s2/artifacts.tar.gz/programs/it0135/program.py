# EVOLVE-BLOCK-START
"""Best fit plus a static "fillable residual" bonus.

Placing an item leaves a residual r = bins - item. Pure best fit (smallest r) is the
strongest known online rule for this distribution, so it is the dominant term.
The only secondary signal that reliably helps is whether the leftover gap r looks
like a size that will arrive soon: a gap equal to a common item size is valuable,
an awkward gap is wasted space. We use a fixed size prior (mean ~40, Weibull-ish)
blended with a light running histogram of observed item sizes, and give a small
bonus to bins whose residual is a "popular" size. The bonus is normalized and kept
small so it only breaks near-ties rather than overriding fit quality.
"""
import numpy as np

_state = {"n": 0, "hist": None, "total": 0.0}
_CAP = 100.0
_DECAY = 0.9995          # running histogram decay
_BONUS = 3.0             # scale of the fillable-residual bonus (< 1 residual unit)


def _prior():
    # Weibull-ish prior with mean ~40 over sizes 1..100.
    x = np.arange(1, 101, dtype=np.float64)
    k, lam = 1.8, 45.0
    w = (k / lam) * (x / lam) ** (k - 1.0) * np.exp(-((x / lam) ** k))
    w = w / w.sum()
    return w


_PRIOR = _prior()


def priority(item, bins):
    _state["n"] += 1

    # Maintain a light running histogram of observed item sizes.
    if _state["hist"] is None:
        _state["hist"] = _PRIOR.copy() * 50.0
        _state["total"] = 50.0

    residual = (bins - item).astype(np.float64)          # >= 0
    m = bins.shape[0]
    idx = np.arange(m, dtype=np.float64)

    # Dominant term: best fit -> minimize residual.
    score = -residual

    # Secondary: fillable-residual bonus from popularity of residual size r in 1..100.
    r = residual.astype(np.int64)
    valid = (r >= 1) & (r <= 100)
    pop = np.zeros(m, dtype=np.float64)
    pop[valid] = _state["hist"][r[valid] - 1] / max(_state["total"], 1.0)
    score += _BONUS * pop

    # Mild penalty for opening a brand-new bin.
    score -= np.where(bins == _CAP, 0.05, 0.0)

    # Tiny rotating tie-break so no bin index is systematically favored.
    rotate = ((idx + _state["n"]) % m) / m * 1e-6
    score -= rotate

    # Update the histogram with the current item (after scoring).
    h = _state["hist"] * _DECAY
    h[item - 1] += 1.0
    _state["hist"] = h
    _state["total"] = _state["total"] * _DECAY + 1.0

    return score
# EVOLVE-BLOCK-END

