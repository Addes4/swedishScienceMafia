# EVOLVE-BLOCK-START
"""Residual-expectation bin packing: best-fit dominance plus a learned future-fillability bonus."""
import numpy as np


class _State:
    def __init__(self):
        self.ewma = 40.0
        self.count = 0
        self.rot = 0.0


_state = _State()


def priority(item, bins):
    b = np.asarray(bins, dtype=np.float64)
    size = float(item)

    st = _state
    st.count += 1
    alpha = 0.05
    st.ewma = (1.0 - alpha) * st.ewma + alpha * size
    mu = st.ewma if st.ewma > 1.0 else 40.0

    residual = b - size  # remaining capacity after placing the item, >= 0

    # Primary: best-fit tightness -- smaller residual is better.
    tight = -residual

    # Secondary: reward residuals near the running mean (a typical item still fits),
    # penalize residuals much smaller than mu (hard to refill) and near-empty leftovers.
    fill = 1.0 - np.abs(residual - mu) / (mu + 1.0)

    # Busy-bin bonus: prefer used bins over fresh full bins.
    busy = (100.0 - b) / 100.0

    score = 4.0 * tight + 0.25 * fill + 0.4 * busy

    # Rotating tie-break so equally scored bins rotate over time.
    st.rot += 0.6180339887
    idx = np.arange(b.size, dtype=np.float64)
    score = score + 1e-5 * np.sin(st.rot + idx)

    return score
# EVOLVE-BLOCK-END
