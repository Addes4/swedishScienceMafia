# EVOLVE-BLOCK-START
"""Best-fit with a busy-bin preference, using a per-bin usage signal."""
import numpy as np

_state = {"counter": 0}


def priority(item, bins):
    st = _state
    st["counter"] += 1
    ctr = st["counter"]

    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit (smallest residual wins).
    tight = -residual.astype(np.float64)

    # Secondary: prefer bins that are already partially used rather than opening/using
    # near-empty bins, helping pack large items later. Measured by how much capacity
    # is already consumed (bins - residual == used before placing item).
    used = (100.0 - residual.astype(np.float64))
    busy_bonus = 0.002 * used

    # Deterministic tie-break so ties resolve to lowest index consistently.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    offset = -1e-6 * idx

    return tight + busy_bonus + offset
# EVOLVE-BLOCK-END
