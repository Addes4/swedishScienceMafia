# EVOLVE-BLOCK-START
"""Best fit with a fillable-gap bonus and new-bin aversion.

Primary term: minimize the resulting residual (classic best fit) — keeps bins tight.
Secondary term: bonus for leaving a residual equal to a frequently observed item
size (estimated from a running histogram of past items), so gaps tend to be exactly
fillable later. A rotating tie-break spreads equal choices across bin indices.
"""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64), "total": 0.0}

DECAY = 0.9999  # gentle decay so recent sizes matter a bit more


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    n = st["n"]

    # Update running histogram of past item sizes (decay old mass).
    hist = st["hist"]
    hist *= DECAY
    hist[item] += 1.0
    st["total"] = st["total"] * DECAY + 1.0

    residual = bins - item  # >= 0 by contract

    # Primary: best fit -> prefer smallest resulting residual.
    score = -residual.astype(np.float64)

    # Secondary: bonus if resulting residual is a commonly-seen size (fillable gap).
    res = residual.astype(np.int64)
    fill_bonus = np.where(res >= 1, hist[np.clip(res, 0, 100)] / (st["total"] + 1e-9), 0.0)
    score += 3.0 * fill_bonus

    # New-bin aversion: penalize opening a fresh (empty) bin, scaled by item size.
    is_new = (bins == 100) & (residual > 0)
    score -= np.where(is_new, 0.5 + 0.02 * item, 0.0)

    # Rotating tie-break.
    m = bins.shape[0]
    idx = np.arange(m, dtype=np.float64)
    rotate = ((idx + n) % m) / m * 1e-6
    score -= rotate

    return score
# EVOLVE-BLOCK-END
