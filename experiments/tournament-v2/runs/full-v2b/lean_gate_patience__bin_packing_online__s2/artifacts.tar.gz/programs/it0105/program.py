# EVOLVE-BLOCK-START
"""Best-fit with a learned residual-affinity bonus (integer-size aware)."""
import numpy as np


class _State:
    # Frequency of item sizes seen so far (1..100).
    seen = np.zeros(101, dtype=np.float64)
    total = 0.0


def priority(item, bins):
    """Score bins: exact fit >> tightest fit, plus residual-affinity bonus."""
    it = int(item)
    b = bins.astype(np.float64)
    residual = b - it

    # Core: prefer the tightest fit (smallest non-negative residual).
    score = -residual

    # Strong exact-fit bonus (residual 0).
    score += np.where(residual == 0.0, 50.0, 0.0)

    # Residual-affinity: if a bin's residual matches a frequently seen item
    # size, that bin is a good candidate for a future exact pairing -> bonus.
    # residual is integer here; map to bucket index safely.
    r_int = np.rint(residual).astype(np.int64)
    valid = (r_int >= 0) & (r_int <= 100)
    aff = np.zeros_like(residual)
    rr = np.clip(r_int, 0, 100)
    aff[valid] = _State.seen[rr[valid]]

    # Normalize affinity to a modest scale so it never overrides best-fit.
    if _State.total > 0.0:
        aff = aff / _State.total
    score += aff * 2.0

    # Mild preference for already-used bins (avoid opening new bins).
    score += np.where(b < 100.0, 0.15, 0.0)

    # Update item-size statistics.
    _State.seen[it] += 1.0
    _State.total += 1.0

    return score
# EVOLVE-BLOCK-END
