# EVOLVE-BLOCK-START
"""Worst-fit style spreading with fragmentation-aware scoring."""
import numpy as np

_state = {"t": 0}


def priority(item, bins):
    """Score bins preferring those with the most usable remaining space.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["t"] += 1
    t = _state["t"]

    residual = (bins - item).astype(np.float64)  # capacity left after placing

    # Worst-fit: prefer larger residual so gaps stay big enough for future items.
    score = residual.copy()

    # Penalize residuals that are "awkward": too small to fit a typical item
    # (mean ~40) tends to strand space. Reward moderate usable gaps.
    small = residual < 20.0
    score -= 1.5 * small.astype(np.float64)

    # Mild bonus for bins that keep a healthy gap after the item.
    usable = (residual >= 20.0) & (residual <= 60.0)
    score += 0.3 * usable.astype(np.float64)

    # Tiny rotating pseudo-random tie-break to spread equal choices.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    noise = np.sin((idx + 1.0) * (t * 0.6180339887498949)) * 1e-3
    score += noise

    return score
# EVOLVE-BLOCK-END
