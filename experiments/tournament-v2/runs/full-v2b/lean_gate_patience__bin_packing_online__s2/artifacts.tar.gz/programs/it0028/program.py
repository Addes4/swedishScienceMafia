"""Best-fit with a tie-break that prefers the fullest bin among equal fits.

For each bin we compute the residual left after placing the item. The primary
score rewards the smallest residual (best fit). A secondary term, scaled to be
smaller than one unit of residual, rewards bins that are already fuller (smaller
current remaining capacity), so that when several bins leave the same residual
the fullest one is chosen. This is the classic best-fit rule with a consistent,
non-random tie-break, which tends to consolidate items and reduce bin count.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    residual = bins - item                 # leftover capacity if placed here
    # Primary: smallest residual wins.
    score = -residual.astype(np.float64)
    # Secondary: prefer fuller bins (smaller current remaining capacity).
    # Scaled below 1 so it never overrides the primary residual comparison.
    score -= 0.5 * (bins.astype(np.float64) / 100.0)
    return score
