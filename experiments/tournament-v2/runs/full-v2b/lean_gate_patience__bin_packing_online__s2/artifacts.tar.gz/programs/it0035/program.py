# EVOLVE-BLOCK-START
"""Sliver-aware best fit: prefer tight fits but avoid leaving unusable residuals."""
import numpy as np

_state = {"counter": 0}

# Smallest residual we consider still usable by typical future items (mean ~40).
_SLIVER = 15.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = (bins - item).astype(np.float64)  # capacity left if placed here

    # Base: best fit (small residual is good).
    score = -residual

    # Penalize residuals in the unusable sliver band (0, _SLIVER): these gaps are
    # too small for most future items, so wasting capacity there is bad.
    sliver = np.clip(_SLIVER - residual, 0.0, _SLIVER) / _SLIVER  # 0 outside, ~1 near 0
    score -= 30.0 * sliver

    # Strong bonus for exact fits (residual 0): perfect packing uses the bin fully.
    score += 25.0 * (residual == 0.0)

    # Penalty for opening a brand-new bin.
    new_bin = (residual == (100.0 - item)).astype(np.float64)
    score -= 4.0 * new_bin

    # Tiny cycling perturbation to break exact ties deterministically but variedly.
    n = score.shape[0]
    _state["counter"] += 1
    idx = np.arange(n, dtype=np.float64)
    perturb = ((idx * ((_state["counter"] * 2654435761) % 1000003) + _state["counter"]) % 97) * 1e-6
    score += perturb

    return score
# EVOLVE-BLOCK-END
