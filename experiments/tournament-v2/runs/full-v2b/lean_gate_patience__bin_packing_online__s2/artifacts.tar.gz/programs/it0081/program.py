# EVOLVE-BLOCK-START
"""Best-fit augmented with a "reusable leftover" preference.

Track the empirical distribution of past item sizes. When scoring a bin we
prefer the smallest residual (classic best-fit), but break near-ties by how
likely the resulting residual is to be filled by a future item: residuals that
equal a frequently seen item size are the most reusable, so bins leaving such a
gap are slightly preferred.
"""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    bins = np.asarray(bins)
    residual = bins - item  # >= 0 for every bin shown

    counts = _state["counts"]
    total = _state["n"]

    # Base score: strict best fit prefers the smallest residual.
    score = -residual.astype(np.float64)

    # Bonus for bins whose leftover after placement is a commonly seen size
    # (likely reusable by a future item).
    if total > 0:
        r = np.clip(residual, 0, 100).astype(np.int64)
        freq = counts[r] / total
        score += 0.5 * freq
    else:
        score += 0.5 * (residual == 0)

    # Update empirical size distribution with the current item.
    _state["counts"][item] += 1.0
    _state["n"] = total + 1.0

    return score
# EVOLVE-BLOCK-END
