# EVOLVE-BLOCK-START
"""Best-fit with residual-matching tie-break using an item-size histogram."""
import numpy as np

_state = {"hist": np.ones(101, dtype=np.float64)}


def priority(item, bins):
    # Update histogram of past items (exponential-ish forgetting not needed)
    _state["hist"][item] += 1.0
    hist = _state["hist"]

    n = len(bins)
    residual = (bins - item).astype(np.float64)

    # Scores for bins that fit have residual >= 0 (harness only shows fitting bins).
    # Primary: prefer tightest fit -> smaller residual is better.
    # Secondary: prefer leaving a residual that matches a likely future item size,
    # measured by cumulative probability that some future item exactly fills it.
    # We approximate "wasted space avoidance" by preferring residuals that are
    # themselves common item sizes (so they can be filled later).
    resid_int = residual.astype(np.int64)
    resid_int = np.clip(resid_int, 0, 100)
    freq = hist[resid_int]  # how often past items had this exact leftover size

    # Normalize freq influence to a small bonus that never outweighs fit order.
    base = -residual
    bonus = freq * (1.0 / (hist.sum() + 1.0))

    return base + bonus
# EVOLVE-BLOCK-END
