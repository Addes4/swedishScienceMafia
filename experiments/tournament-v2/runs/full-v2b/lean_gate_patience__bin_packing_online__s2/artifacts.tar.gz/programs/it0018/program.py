# EVOLVE-BLOCK-START
"""Best fit with randomized tie-breaking via a cycling state counter."""
import numpy as np

_state = {"c": 0}


def priority(item, bins):
    """Tightest-fit score, with a tiny cycling perturbation to randomize ties."""
    _state["c"] = (_state["c"] + 1) & 0xFFFF
    n = len(bins)
    # residual capacity after placing the item
    residual = bins - item
    # base: prefer smallest residual (tightest fit) -> negative residual
    base = -residual.astype(np.float64)
    # deterministic pseudo-random tie-breaker that varies per call and per bin
    idx = np.arange(n, dtype=np.float64)
    h = np.mod(idx * 2654435761.0 + _state["c"] * 40503.0, 2.0 ** 31)
    return base + h * (1.0 / (2.0 ** 40))
# EVOLVE-BLOCK-END
