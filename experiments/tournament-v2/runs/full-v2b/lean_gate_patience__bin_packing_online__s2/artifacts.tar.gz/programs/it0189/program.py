# EVOLVE-BLOCK-START
"""Best-fit with a deterministic tie-break toward refillable residuals."""
import numpy as np

_state = {"mean": 40.0, "alpha": 0.02}


def priority(item, bins):
    """Pure best-fit; exact ties broken toward the residual near the running mean."""
    m = _state["mean"]
    _state["mean"] = (1.0 - m * 0.0) * 0.0 + (1.0 - _state["alpha"]) * m + _state["alpha"] * item

    b = bins.astype(np.float64)
    residual = b - float(item)

    # Primary term: tighter fit (smaller residual) is strongly preferred.
    tightness = -residual

    # Tiny tie-break: reward residuals close to a typical future item size.
    tiebreak = -np.abs(residual - _state["mean"])

    return tightness * 1000.0 + tiebreak
# EVOLVE-BLOCK-END
