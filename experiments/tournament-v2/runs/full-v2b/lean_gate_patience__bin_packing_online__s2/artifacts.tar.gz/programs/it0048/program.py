"""Adaptive best-fit with randomized tie-breaking and new-bin penalty."""
import numpy as np


class _State:
    def __init__(self):
        self.counter = 0
        self.total_items = 0


_state = _State()


def priority(item, bins):
    """Return a priority per bin; item goes to the highest score (first on ties)."""
    bins = np.asarray(bins)
    n = bins.shape[0]

    residual = bins - item  # residual capacity after placing the item; smaller = tighter

    # Base score: prefer tightest fit.
    score = -residual.astype(np.float64)

    # Randomized tie-break: add a tiny cycling perturbation so equal-tightness
    # bins are ordered differently over time, avoiding early-bin locking.
    _state.counter += 1
    idx = np.arange(n)
    # deterministic pseudo-random-ish permutation via a rotating offset
    offset = (_state.counter * 2654435761) & 0x7FFFFFFF
    perm_score = (idx + offset) % n
    score += perm_score * 1e-6

    # Mild penalty for opening a brand-new bin (residual exactly 100 before placement).
    new_bin_mask = bins >= 100
    score -= new_bin_mask.astype(np.float64) * 0.5

    return score
