# EVOLVE-BLOCK-START
"""Best-fit tightness combined with a smooth residual-desirability bonus,
a busy-bin bonus to discourage opening new bins, and a rotating tie-break."""
import numpy as np

_MEAN = 40.0          # rough mean item size for the distribution
_STATE = {"n": 0, "ewma": 40.0, "rot": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _STATE
    st["n"] += 1
    # overtime EWMA of observed item sizes
    st["ewma"] = 0.995 * st["ewma"] + 0.005 * item
    mean = st["ewma"]
    st["rot"] = (st["rot"] + 1) % 97

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # leftover capacity after placing the item (>= 0, integer)

    # 1) best-fit tightness: prefer small residual
    tight = -residual

    # 2) residual desirability: penalize residuals that are hard to fill (tiny) or
    #    near the mean item size (likely to be left as an awkward leftover).
    tiny_pen = 12.0 * np.exp(-residual / 4.0)                 # small residuals
    mean_pen = 8.0 * np.exp(-((residual - mean) ** 2) / (2.0 * (0.6 * mean) ** 2))
    # mildly reward a comfortable slack that can still absorb smaller items
    slack_bonus = 4.0 * np.sqrt(np.clip(residual, 0.0, None)) / 10.0

    # 3) busy-bin bonus: prefer bins already partly used over opening a fresh bin
    busy = -0.05 * (100.0 - bins)

    # 4) rotating deterministic tie-break offset by bin index
    idx = np.arange(bins.size, dtype=np.float64)
    rot = 1e-3 * ((idx + st["rot"]) % 97)

    return tight - tiny_pen - mean_pen + slack_bonus + busy + rot
# EVOLVE-BLOCK-END
