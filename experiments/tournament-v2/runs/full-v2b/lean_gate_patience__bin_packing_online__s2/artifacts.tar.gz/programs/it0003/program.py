# EVOLVE-BLOCK-START
"""Best fit with a mild fragmentation-aware adjustment for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Classic best fit: larger score == fuller bin that still fits.
    score = -(bins - item)

    # For small items, slightly discourage filling up the very tightest bin when a
    # comparably tight alternative exists, to leave near-full bins open for items
    # that match them better. This is a tiny nudge and preserves best-fit ordering
    # in most cases.
    if item <= 30:
        # bins with small remaining capacity (<= item) are exact-fit-ish; nudge them
        tight = bins - item <= 3
        score = score.astype(np.float64) - 0.05 * tight

    return score
# EVOLVE-BLOCK-END
