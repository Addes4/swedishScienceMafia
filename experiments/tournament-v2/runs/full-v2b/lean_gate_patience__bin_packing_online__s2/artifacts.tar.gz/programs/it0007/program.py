# EVOLVE-BLOCK-START
"""Best-fit with a fragmentation-aware secondary term.

Primary rule: best fit (smallest residual capacity after placing the item), which is a
strong online heuristic.  Secondary tie-break: among bins that leave a similar residual,
prefer the one whose leftover capacity is "usable" -- i.e. close to a typical item size
(the distribution has mean ~40), so the leftover gap is likely to be filled by a future
item rather than becoming dead space.  This is computed purely from the current call and
needs no future information.
"""
import numpy as np

# Typical item size for the Weibull-shaped distribution (mean about 40).
_TYPICAL = 40.0


def priority(item, bins):
    residual = (bins - item).astype(np.float64)

    # Primary: tighter fit is much better => use -residual.
    # Secondary: penalize residuals that are small but non-zero (likely dead space,
    # since few future items are that tiny) and reward residuals near a typical size.
    # Compute a mild usable-gap bonus: how close residual is to a multiple-friendly band.
    # A residual of 0 is perfect; residuals near _TYPICAL are reusable; tiny positive
    # residuals (1..15) are often wasted, so slightly penalize them.
    r = residual
    # small positive residuals are wasteful
    waste_pen = np.where((r > 0) & (r < 15), 0.30, 0.0)
    # residuals near a typical item size get a small bonus (more likely reusable)
    usable_bonus = 0.10 * np.exp(-((r - _TYPICAL) ** 2) / (2.0 * (20.0 ** 2)))
    # residuals close to 0 are strongly preferred already via -r; nothing extra needed.

    return -r + usable_bonus - waste_pen
# EVOLVE-BLOCK-END
