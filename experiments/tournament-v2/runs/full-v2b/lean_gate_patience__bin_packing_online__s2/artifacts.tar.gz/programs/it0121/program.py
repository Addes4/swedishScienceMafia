# EVOLVE-BLOCK-START
"""Size-weighted log best-fit with exact-fit reward and residual-popularity bonus."""
import numpy as np

# Exponential moving histogram of arriving item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
_decay = 0.999
_started = [False]


def priority(item, bins):
    """Rank bins by a size-weighted tightness plus an exact-fit and residual-fit bonus."""
    # Update the running size histogram (probability a future item has size s).
    if not _started[0]:
        _hist[:] = 0.0
        _started[0] = True
    _hist *= _decay
    _hist[item] += 1.0

    residual = (bins - item).astype(np.float64)

    # Base tightness: log-scaled residual, weighted by item size so large items
    # prefer near-exact fits more strongly.
    w = 0.5 + 0.02 * item
    score = -w * np.log1p(residual)

    # Size-scaled bonus for a perfect fill.
    score += np.where(residual <= 0, w * 2.0, 0.0)

    # Residual-popularity: reward leaving a gap that is likely to be matched by
    # a future item size. r=residual index; weight by how common r is.
    r = residual.astype(np.int64)
    r = np.clip(r, 0, 100)
    pop = _hist[r]
    tot = _hist[1:].sum() + 1e-9
    score += 0.5 * (pop / tot)

    # Mild consolidation bonus for partially-used bins.
    score += np.where(bins < 100, 0.02, 0.0)
    return score
# EVOLVE-BLOCK-END
