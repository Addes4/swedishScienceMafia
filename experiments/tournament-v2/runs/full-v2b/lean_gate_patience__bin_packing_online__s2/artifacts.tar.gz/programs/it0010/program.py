# EVOLVE-BLOCK-START
"""Best-fit with a small exact-fit bonus and deterministic tie rotation.

Primary rule is classic best fit: place the item where the leftover capacity is smallest.
We add a small extra bonus for a perfect fill (leftover 0) so the item prefers to complete a
bin, and we break ties among equal residual capacities by rotating through the candidate bins
using a running counter, avoiding always locking into the lowest-index bin.
"""
import numpy as np

_state = {"t": 0}


def priority(item, bins):
    residual = bins - item  # residual >= 0 for all shown bins

    # Exact-fill bonus: strongly prefer leaves-0 residual, then tightest fit.
    exact = (residual == 0).astype(np.float64)

    # Deterministic tie rotation among equal-residual bins.
    _state["t"] += 1
    t = _state["t"]
    idx = np.arange(bins.shape[0], dtype=np.int64)
    key = idx * np.int64(2654435761) + np.int64(t) * np.int64(40503)
    key = (key ^ (key >> np.int64(13))) * np.int64(1274126177)
    key = key ^ (key >> np.int64(16))
    rnd = (key & np.int64(0xFFFFF)).astype(np.float64) / 1048576.0

    # Tightest fit dominant; exact fill a notch better; random only breaks exact ties.
    score = -residual.astype(np.float64) + 0.5 * rnd + 2.0 * exact
    return score
# EVOLVE-BLOCK-END
