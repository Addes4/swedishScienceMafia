# EVOLVE-BLOCK-START
"""Best fit on residual, with tie-break that rewards reusable leftover gaps."""
import numpy as np


_counter = 0

# Likely future item sizes for a Weibull-shaped distribution with mean ~40.
# Dense around the mode/mean region, sparse at extremes.
_LIKELY = np.array(
    [5, 10, 15, 20, 25, 28, 30, 33, 35, 38, 40, 42, 45, 48, 50, 55, 60, 65, 70, 75, 80, 90, 100],
    dtype=np.float64,
)


def _gap_value(res):
    """Smooth reward for a residual that is close to a common item size.

    Values near a likely item size are 'reusable' (can be filled tightly later),
    so they get a small bonus. Distance transform keeps it smooth.
    """
    d = np.abs(res[:, None] - _LIKELY[None, :])
    return -d.min(axis=1)


def priority(item, bins):
    """Score every fitting bin; item goes to the highest-scoring bin."""
    global _counter
    _counter += 1

    residual = (bins - item).astype(np.float64)  # lower = tighter fit

    # Primary: tightest fit dominates.
    score = -residual

    # Secondary: prefer residuals that stay reusable as gaps for future items.
    score += 0.15 * _gap_value(residual)

    # Small penalty for opening brand-new bins.
    score -= (residual == 100.0).astype(np.float64) * 0.3

    return score
# EVOLVE-BLOCK-END
