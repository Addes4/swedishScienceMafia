# EVOLVE-BLOCK-START
"""Least-fillable-first bin packing: prefer residuals unlikely to be reused."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)  # smoothed item-size density
        self.mean = 40.0
        self.count = 0
        self.rot = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    b = np.asarray(bins, dtype=np.float64)
    size = float(item)

    st = _state
    st.count += 1

    # Online item-size distribution with Laplace smoothing.
    st.hist[size] += 1.0
    hist = st.hist + 1.0
    pdf = hist / hist.sum()
    st.mean = (st.count * st.mean + size) / (st.count + 1.0)

    residual = b - size  # capacity left after placing, >= 0

    # Probability that a future item can still fill this bin's residual:
    # sum of pdf over sizes <= residual. Higher means the leftover is reusable.
    cdf = np.cumsum(pdf)  # cdf[r] ~ P(item <= r)
    r_int = np.clip(np.rint(residual).astype(np.int64), 0, 100)
    refill = cdf[r_int]

    # Dominant term: tightest fit (smallest residual) to preserve packing density.
    tight = -residual

    # Secondary: prefer residuals that are unlikely to be reused (low refill prob),
    # so we consume awkward gaps instead of stranding small unusable room.
    score = 1.0 * tight - 2.0 * refill

    # Rotating tie-break so equally scored bins rotate over time.
    st.rot += 0.6180339887
    idx = np.arange(b.size, dtype=np.float64)
    score = score + 1e-6 * np.sin(st.rot + idx)

    return score
# EVOLVE-BLOCK-END
