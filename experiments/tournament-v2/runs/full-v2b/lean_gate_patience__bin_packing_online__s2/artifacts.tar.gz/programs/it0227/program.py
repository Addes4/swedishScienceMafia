# EVOLVE-BLOCK-START
"""Residual-desirability bin packing with an empirical subset-sum fillability estimate."""
import numpy as np

_state = {
    "mean": 40.0,
    "hist": np.ones(101, dtype=np.float64),  # index 1..100 smoothed counts
    "cache_key": None,
    "fill_prob": None,
}


def _fill_probability(hist):
    """Estimate, for each residual r in 0..100, the probability that r can be
    exactly filled by 1..3 future items, using the empirical item-size histogram."""
    density = hist[1:101].copy()
    tot = density.sum()
    if tot <= 0:
        density[:] = 1.0
        tot = density.sum()
    single = density / tot

    p1 = single.copy()
    conv2 = np.convolve(single, single)
    conv3 = np.convolve(conv2, single)

    fp = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        v = p1[r - 1]
        if r <= len(conv2):
            v += 0.55 * conv2[r - 1]
        if r <= len(conv3):
            v += 0.25 * conv3[r - 1]
        fp[r] = v
    m = fp.max()
    if m > 0:
        fp /= m
    return fp


def priority(item, bins):
    S = _state
    it = float(item)

    # Update running mean and empirical histogram with mild exponential decay.
    S["mean"] = 0.98 * S["mean"] + 0.02 * it
    mu = S["mean"]
    h = S["hist"]
    h *= 0.995
    i = int(round(it))
    if 1 <= i <= 100:
        h[i] += 1.0

    b = np.asarray(bins, dtype=np.float64)
    res = b - it

    # Dominant best-fit: exponentially decaying preference for small residual.
    tight = np.exp(-res * 1.5)

    # Rebuild fillability estimate only when the histogram has shifted enough.
    key = int(mu * 4.0)
    if S["cache_key"] != key or S["fill_prob"] is None:
        S["fill_prob"] = _fill_probability(h)
        S["cache_key"] = key
    ri = np.clip(np.round(res).astype(np.int64), 0, 100)
    fill = S["fill_prob"][ri]

    # Sharp exact-fit bonus plus a light typical-next-item match signal.
    exact0 = (res < 0.5).astype(np.float64)
    typical = np.exp(-((res - mu) ** 2) / (2.0 * (0.35 * mu) ** 2))
    match = np.exp(-np.abs(res - np.round(res)) * 4.0) * typical

    score = 12.0 * tight + 1.2 * fill + 0.6 * exact0 + 0.3 * match
    return score
# EVOLVE-BLOCK-END
