"""Adaptive best-fit with distribution-aware residual targeting."""
import numpy as np


class _State:
    def __init__(self):
        self.counter = 0
        # running estimate of typical item size via exponential moving average
        self.mean_item = 40.0
        self.alpha = 0.002


_state = _State()

# Precompute target residual grid (common future item sizes from Weibull-ish dist).
_TARGETS = np.arange(1, 101, dtype=np.float64)
# Weight targets by approximate probability (peaked around 30-45).
_mean = 40.0
_sigma = 22.0
_WEIGHTS = np.exp(-0.5 * ((_TARGETS - _mean) / _sigma) ** 2)
_WEIGHTS /= _WEIGHTS.sum()


def priority(item, bins):
    """Return a priority per bin; item goes to the highest score (first on ties)."""
    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]

    # Update running estimate of item sizes.
    _state.counter += 1
    _state.mean_item += _state.alpha * (item - _state.mean_item)
    mu = _state.mean_item

    residual = bins - item  # remaining capacity after placement; -1 if doesn't fit? harness pre-filters.

    # Base: prefer tightest fit (most negative residual, i.e. smallest residual).
    score = -residual

    # Distribution-aware bonus: reward residuals close to the running mean item size,
    # since leftover capacity near a typical future item allows a clean fit next time.
    diff = residual - mu
    score -= 0.004 * diff * diff

    # Exact-fit strong bonus (residual == 0 leaves a perfectly full bin).
    score -= (residual == 0).astype(np.float64) * 0.0  # placeholder, tight fit already handled

    # Penalize very small residuals (slivers) slightly since they waste capacity.
    sliver = (residual >= 0) & (residual <= 3)
    score -= sliver.astype(np.float64) * 0.05

    # Penalty for opening a brand-new bin.
    new_bin_mask = bins >= 100.0
    score -= new_bin_mask.astype(np.float64) * 0.5

    # Randomized tie-break to avoid early-bin locking.
    idx = np.arange(n)
    offset = (_state.counter * 2654435761) & 0x7FFFFFFF
    score += ((idx + offset) % n) * 1e-6

    return score
