"""Gap-filling harmonic: favor residuals that match common item sizes seen so far."""
import numpy as np

# State kept between calls
_counts = np.zeros(101, dtype=np.float64)  # exponentially weighted size histogram
_total = 0.0


def priority(item, bins):
    global _total
    # Update state with previous items (state used for this decision reflects past items)
    _counts[item] += 1.0
    _total += 1.0
    # decay very lightly to keep it adaptive
    if _total > 2000.0:
        _counts *= 0.5
        _total *= 0.5

    inv_total = 1.0 / _total
    # Probability mass for each residual size 0..100 based on history
    probs = _counts * inv_total  # sums to 1

    # residual after placing item
    residual = bins - item

    # For each bin, estimate how "fillable" the residual is:
    # reward if residual is small (best fit) or if residual corresponds to a common item size.
    # Common-size match: sum over sizes <= residual of probs, weighted toward exact matches.
    # Use a smooth kernel: for each r, favor r near frequently-seen items.
    # Vectorized: for each bin residual r, score = sum_s probs[s] * exp(-((r - s)/sigma)^2)
    sig = 2.5
    # Build kernel matrix efficiently: sizes 0..100
    sizes = np.arange(101, dtype=np.float64)
    # residual values
    r = residual.astype(np.float64)
    # diff: len(bins) x 101
    diff = (r[:, None] - sizes[None, :]) / sig
    kernel = np.exp(-diff * diff)
    match = kernel @ probs  # how well residual aligns to common item sizes (per bin)
    # also weight by probability mass of items <= residual (fillability)
    cum = np.cumsum(probs)  # cum[s] = P(size <= s)
    cum_r = cum[np.clip(r.astype(np.int64), 0, 100)]
    fill = match * (0.30 + 0.70 * cum_r)

    # best-fit tightness: prefer small residual
    tight = -r

    # busy-bin bonus: strongly prefer existing partially-used bins over opening new
    busy = -(bins == 100).astype(np.float64) * 8.0

    # mild bonus for residual == 0
    exact = (r == 0).astype(np.float64) * 6.0

    return tight * 0.6 + fill * 12.0 + busy + exact
# EVOLVE-BLOCK-END
