# EVOLVE-BLOCK-START
"""Best fit unless the tightest fit would strand a tiny, unusable sliver."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for bins shown (item fits)
    r = residual.astype(np.float64)
    # base: prefer tightest fit (smallest residual after placement)
    base = -r
    # penalty for stranding a small, hard-to-reuse sliver:
    # residuals in (0, 30) are likely wasted since mean item ~40.
    # Favor rounding down to exactly 0 or leaving >= ~30.
    sliver = np.clip(r, 0.0, 30.0)          # small => small sliver
    waste = (30.0 - sliver) * ((r > 0) & (r < 30))  # penalty when 0<r<30
    # scale waste modestly so it only breaks near-ties in the main term
    return base - 0.02 * waste
# EVOLVE-BLOCK-END
