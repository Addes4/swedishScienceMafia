"""Best-fit with residual-quality weighting and a preference against new bins.

For every visible bin we score by the residual capacity left after placing the
item (tightest fit -> highest base score).  On top of that we adjust for the
*usefulness* of the resulting residual: residuals that are too small to accept
any typical future item are penalized (they are effectively wasted space),
while near-perfect fits are rewarded.  A moderate penalty against opening a
brand-new empty bin discourages needless bin openings, and a tiny cycling
perturbation breaks exact ties in varying order.
"""
import numpy as np

_state = {"t": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _state["t"] += 1
    t = _state["t"]

    residual = bins - item                     # leftover capacity if item goes here
    score = -residual.astype(np.float64)       # tightest fit = best base score

    # Penalize "dead" slivers: residuals too small to fit a typical future item.
    # Sizes are Weibull-shaped with mean ~40, so residuals below ~15 are rarely usable.
    dead = (residual >= 1) & (residual <= 14)
    score -= 1.5 * dead

    # Reward (near) perfect fits.
    score += 0.5 * (residual == 0)

    # Mild preference against opening a brand-new (empty) bin.
    is_empty = bins == 100
    score -= 1.0 * is_empty

    # Tiny cycling perturbation to break exact ties in varying order.
    n = bins.shape[0]
    idx = np.arange(n)
    noise = ((idx * 2654435761 + t * 40503) % 97) / 97.0
    score += 0.01 * noise

    return score
