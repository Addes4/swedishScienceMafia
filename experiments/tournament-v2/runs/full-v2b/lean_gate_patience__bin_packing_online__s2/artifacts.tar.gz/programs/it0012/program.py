"""Randomized best-fit with reservoir sampling over equally-tight bins.

Strategy:
  * Compute residual capacity after placing the item, r = bins - item.
  * Find the minimal residual (tightest fit). All bins achieving that residual are
    "candidates".
  * Among the candidates, pick one uniformly at random (reservoir sampling driven by
    an internal counter so no RNG dependency is required and behavior is deterministic
    given the call sequence).

Why this helps: pure best-fit (argmax of -(bins-item), ties to first index) always
dumps into the earliest tight bin, which locks early bins into near-full states and
wastes capacity on later mid-size items. Ties are extremely common (many bins share
the same remaining capacity), so randomizing among them spreads the load, giving more
room for the heavy tail of the Weibull distribution.

The returned score array gives the chosen bin score 1 and all others -1, so the
highest (and first-on-tie) bin is exactly our randomized pick.
"""
import numpy as np


def priority(item, bins):
    n = bins.shape[0]
    # Residual capacity if the item were placed here (only bins it fits in are shown).
    residual = bins - item

    # Tightest fit = smallest residual.
    min_res = residual.min()
    # Boolean mask of candidate bins achieving the tightest fit.
    candidates = np.flatnonzero(residual == min_res)

    # Deterministic pseudo-random reservoir pick among candidates.
    # Use a tiny linear-congruential stepper seeded by a module-level counter
    # that advances once per call.
    state = priority._state
    state = (state * 1103515245 + 12345) & 0x7FFFFFFF
    priority._state = state

    pick = candidates[state % candidates.shape[0]]

    # Build the priority vector: chosen bin highest, everything else lowest.
    out = np.full(n, -1.0, dtype=np.float64)
    out[pick] = 1.0
    return out


priority._state = 123456789
