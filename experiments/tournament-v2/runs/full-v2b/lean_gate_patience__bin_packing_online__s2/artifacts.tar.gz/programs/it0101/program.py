"""Best-fit with exact-fit bonus and a narrow near-tie consideration band."""
import numpy as np


class _State:
    def __init__(self):
        self.counter = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.counter += 1

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # >= 0 for all shown bins

    # Primary: smallest residual (tightest fit). Negate residual.
    score = -residual

    # Strong bonus for an exact fill.
    score += np.where(residual == 0.0, 1000.0, 0.0)

    # Prefer existing (partially used) bins over brand-new ones (residual == 100 - item),
    # but only mildly so we don't override genuine fit quality badly.
    score += np.where(bins < 100.0, 0.5, 0.0)

    return score
