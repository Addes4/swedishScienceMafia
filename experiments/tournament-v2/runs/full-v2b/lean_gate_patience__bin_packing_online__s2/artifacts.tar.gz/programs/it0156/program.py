# EVOLVE-BLOCK-START
"""Best-fit plus a recency-weighted 'perfect completion' bonus.

Core idea: best fit (minimize residual) is a strong online rule on its own.
We add a small bonus when the residual *after* placing the item matches a
commonly seen recent item size, so bins tend to be filled exactly by future
items.  The histogram is exponentially weighted so it adapts to the stream.
"""
import numpy as np

# Exponential decay factor for the recency-weighted size histogram.
_DECAY = 0.995
# Number of size buckets (bucket width 5 -> sizes 1..100).
_NB = 20


_state = {
    "counts": None,   # recency-weighted histogram over buckets of width 5
    "total": 0.0,
}


def priority(item, bins):
    st = _state

    # --- update recency-weighted histogram of item sizes ---
    if st["counts"] is None:
        st["counts"] = np.zeros(_NB, dtype=np.float64)
    counts = st["counts"]
    counts *= _DECAY
    st["total"] = st["total"] * _DECAY + 1.0

    b = item // 5
    if b >= _NB:
        b = _NB - 1
    counts[b] += 1.0
    total = st["total"] if st["total"] > 0.0 else 1.0

    residual = bins - item  # >= 0 for bins the item fits in
    res_f = residual.astype(np.float64)

    # --- primary term: best fit (prefer smallest residual) ---
    tight = -res_f

    # --- secondary: reward residuals that equal a common item size ---
    # Map each possible residual to its bucket (residual 0 -> bucket 0 scale).
    # For residual r, the bucket of the future item that would exactly fill it
    # is (r-1)//5, clipped.  We want residuals close to *representative* sizes.
    # Build a per-bucket desirability and evaluate it at the residual's bucket.
    freqs = counts / total                      # length NB
    # value of finishing with residual in bucket k ~ freq of that bucket
    bucket_of_res = np.clip((res_f.astype(np.int64) - 1) // 5, 0, _NB - 1)
    # fractional position inside the bucket for a mild smoothness
    bonus = freqs[bucket_of_res]
    secondary = 0.35 * bonus

    # --- tiny busy-bin preference to avoid opening fresh bins unnecessarily ---
    used_bonus = np.where(res_f < 100.0, 0.02, 0.0)

    # --- deterministic tie-break by bin index ---
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    offset = -1e-6 * idx

    return tight + secondary + used_bonus + offset
# EVOLVE-BLOCK-END
