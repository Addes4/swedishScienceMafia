# EVOLVE-BLOCK-START
"""Best-fit with a small residual-pattern bonus to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since bins are those the item fits in
    # Base: best fit -> prefer smallest residual.
    score = -residual.astype(np.float64)
    # Small bonus when the leftover gap matches a typical future item size,
    # so the bin stays useful rather than becoming a dead small gap.
    # Penalize tiny residuals (dead space) slightly and reward gaps ~ 20-45.
    gap = residual.astype(np.float64)
    bonus = np.zeros_like(gap)
    # reward gaps near the mean item size region, and avoid leaving tiny unusable gaps
    bonus += np.exp(-((gap - 35.0) ** 2) / (2.0 * 15.0 ** 2)) * 2.0
    # small penalty for leaving a very small gap (hard to reuse)
    bonus -= np.exp(-(gap ** 2) / (2.0 * 6.0 ** 2)) * 1.5
    return score + bonus
# EVOLVE-BLOCK-END
