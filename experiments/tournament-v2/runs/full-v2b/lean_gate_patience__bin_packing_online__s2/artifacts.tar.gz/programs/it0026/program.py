"""Residual-matching best fit for online bin packing.

Items follow a Weibull-shaped size distribution (mean ~40).  Rather than just
minimising the leftover capacity (plain best fit), we reward placements whose
post-placement residual is itself close to a "usable" size that a later item can
fill, and penalise leaving either a huge empty gap or an unusable sliver.  A mild
penalty discourages opening brand-new bins, and a small cycling perturbation
breaks ties in varying order to avoid locking early bins.
"""
import numpy as np

_state = {"t": 0}

# A set of "useful" residual sizes we would like to leave behind so later items
# can slot in tightly.  Derived from typical gaps for a mean-40 distribution.
_TARGETS = np.array([0.0, 10.0, 18.0, 25.0, 33.0, 40.0, 50.0, 60.0, 70.0, 80.0])


def priority(item, bins):
    _state["t"] += 1
    t = _state["t"]

    residual = bins - item                      # leftover if placed here
    # Base: plain best fit (smallest residual -> highest score).
    score = -residual.astype(np.float64)

    # Reward residuals that are close to a target usable size (excluding empty bins).
    is_empty = bins == 100
    d = np.abs(residual[:, None] - _TARGETS[None, :]).min(axis=1)
    score -= 0.35 * d                            # closer to a target = better

    # Penalise near-empty residuals (wasted slivers that block the bin).
    score -= 0.25 * ((residual >= 1) & (residual <= 5))

    # Mild preference against opening a brand-new bin.
    score -= 0.75 * is_empty

    # Small cycling pseudo-random perturbation to break ties in varying order.
    idx = np.arange(bins.shape[0])
    noise = ((idx * 2654435761 + t * 40503) % 97) / 97.0
    score += 0.01 * noise

    return score
