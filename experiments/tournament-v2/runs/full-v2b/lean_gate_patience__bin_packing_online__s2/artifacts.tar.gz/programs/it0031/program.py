# EVOLVE-BLOCK-START
"""Residual-matching bin choice: prefer placement that leaves a residual usable by future items."""
import numpy as np

_state = {"counter": 0}

# Typical item sizes for the Weibull-shaped distribution (mean ~40).
_TARGETS = np.array([0.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 100.0])


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = (bins - item).astype(np.float64)  # capacity left if placed here

    # Reward residuals that match a typical future item size (usable gaps),
    # with a special strong bonus for exact fits (residual 0).
    diff = np.abs(residual[:, None] - _TARGETS[None, :])
    match = np.exp(-(diff * diff) / (2.0 * 15.0 * 15.0))
    score = match.max(axis=1)
    score += 0.6 * (residual == 0.0)

    # Mild penalty for opening a brand-new bin (residual == 100 - item).
    new_bin = (residual == (100.0 - item)).astype(np.float64)
    score -= 0.30 * new_bin

    # Small cycling perturbation to vary tie-breaking order.
    n = score.shape[0]
    _state["counter"] += 1
    idx = np.arange(n, dtype=np.float64)
    perturb = ((idx * ((_state["counter"] * 2654435761) % 1000003) + _state["counter"]) % 97) * 1e-4
    score += perturb

    return score
# EVOLVE-BLOCK-END
