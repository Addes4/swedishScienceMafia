# EVOLVE-BLOCK-START
"""Best-fit with a strong busy-bin bias: minimize residual, avoid opening new bins."""
import numpy as np

_hist = []
_offset = 0.0


def priority(item, bins):
    global _hist, _offset

    _hist.append(int(item))
    if len(_hist) > 200:
        _hist.pop(0)

    n = len(bins)
    bins_f = bins.astype(np.float64)

    # Residual remaining after placing item here (lower is better -> tightness)
    resid = bins_f - item
    tightness = -resid / 100.0

    # Strong busy-bin bonus: prefer already-used bins to avoid wasting a fresh bin.
    used = (bins_f < 100.0).astype(np.float64)
    busy_bonus = 0.5 * used

    # Rotating tie-break to spread equally-good choices across bin indices.
    idx = np.arange(n, dtype=np.float64)
    tie = 1e-4 * ((idx + _offset) % 7.0)

    score = tightness + busy_bonus + tie

    _offset += 1.0

    return score
# EVOLVE-BLOCK-END
