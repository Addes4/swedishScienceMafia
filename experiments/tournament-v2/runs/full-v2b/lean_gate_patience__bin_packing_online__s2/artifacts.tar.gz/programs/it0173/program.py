# EVOLVE-BLOCK-START
"""Best-fit with a residual-targeting term: prefer small residual, but bias toward residuals
close to the running mean item size so future items pack tightly."""
import numpy as np

_hist = []
_MEAN = 40.0


def priority(item, bins):
    global _hist

    _hist.append(int(item))
    if len(_hist) > 300:
        _hist.pop(0)

    n = len(bins)
    bins_f = bins.astype(np.float64)
    resid = bins_f - item

    # Online mean item size (simple average; stable and cheap)
    if _hist:
        s = 0.0
        for v in _hist:
            s += v
        mean_size = s / len(_hist)
    else:
        mean_size = _MEAN

    # Base: best fit (prefer smallest residual). Scale so it dominates.
    base = -resid / 100.0

    # Bias: residuals near the typical item size are more likely to be filled later.
    target = 0.15 * np.abs(resid - mean_size) / 100.0

    # Small busy-bin bonus to discourage opening new bins (residual < 100 => used).
    used = (bins_f < 100.0).astype(np.float64)
    busy = 0.02 * used

    score = base - target + busy
    return score
# EVOLVE-BLOCK-END
