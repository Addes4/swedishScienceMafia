# EVOLVE-BLOCK-START
"""Adaptive best-fit with rotating tie-break and a new-bin penalty.

This scores each bin by how tightly the item fits (best fit), but changes the
fixed lowest-index tie-breaking into a stateful pseudo-random rotation so that
equally good bins vary over time.  A small penalty is applied to completely
unused bins (residual capacity 100) to discourage opening unnecessary new bins.
"""
import numpy as np

_state = {"tick": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    residual = bins - item                      # >= 0 for every bin shown

    # Base score: tightly fitting bins get higher scores (best fit).
    # Use a gentle log scale so near-perfect fits are preferred without being
    # overly brittle relative to small differences in residual.
    score = -np.log1p(residual.astype(np.float64))

    # Small penalty for opening a brand-new bin (residual exactly 100 -> unused).
    score -= 0.05 * (residual >= 100 - item + 1) * (bins >= 100)

    # Stateful pseudo-random tie-break: rotate which equal-score bin wins.
    _state["tick"] += 1
    n = bins.shape[0]
    if n > 1:
        phase = _state["tick"] % n
        idx = (np.arange(n) + phase) % n
        score += 1e-6 * (n - idx)

    return score
# EVOLVE-BLOCK-END
