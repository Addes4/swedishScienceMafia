# EVOLVE-BLOCK-START
"""Best-fit core with utilization bonus and adaptive small-gap penalty."""
import numpy as np


# Online estimate of recently observed item sizes (EWMA histogram over 101 buckets)
_hist = np.zeros(101, dtype=np.float64)
_seen = 0
_decay = 0.995


def priority(item, bins):
    """Rank bins: tightest fit, prefer fuller bins, avoid unusable small gaps."""
    global _hist, _seen

    # Update online item-size estimate
    _hist *= _decay
    _hist[item] += 1.0
    _seen += 1

    # Normalized distribution shape (avoid div by zero)
    total = _hist.sum()
    if total <= 0:
        total = 1.0
    p = _hist / total

    resid = (bins - item).astype(np.float64)  # >= 0

    # Core: best-fit -> prefer smaller residual (negative residual is better)
    score = -resid

    # Adaptive penalty: penalize residuals that fall in low-probability size ranges
    # (a leftover gap that future items rarely fit into is wasted capacity).
    # Look up the probability of leaving exactly this residual.
    ri = np.clip(resid.astype(np.int64), 0, 100)
    # Probability mass "near" this residual (items that could roughly fill it)
    # Using the prob of the residual bucket; larger residual -> more likely useful,
    # but we already reward tightness, so only lightly adjust.
    gap_usefulness = p[ri]
    score = score + 30.0 * gap_usefulness

    # Utilized-bins bonus: prefer placing into already-open bins.
    busy_bonus = np.where(bins < 100, 1.0, 0.0)
    score = score + busy_bonus

    # Deterministic tie-break spreading: smaller residual classes get slight nudge
    tie = (ri.astype(np.float64) * -1e-6)
    score = score + tie

    return score
# EVOLVE-BLOCK-END

