# EVOLVE-BLOCK-START
"""Best fit with slight tie-breaking bias toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer smallest remaining capacity after placing (bins - item small).
    # Add a tiny epsilon scaled by fullness to slightly prefer fuller bins,
    # which reduces fragmentation without changing the main best-fit ordering.
    return -(bins - item) + 1e-6 * (100 - bins)
# EVOLVE-BLOCK-END
