# EVOLVE-BLOCK-START
"""Online bin packing: residual-fillability ranking with online size histogram."""
import numpy as np

_state = {
    "fired": 0,
    "phase": 0,
    # Histogram of item sizes (index = size 1..100, ignore 0).
    "size_hist": np.ones(101, dtype=np.float64),
    # EWMA mean as a coarse descriptor.
    "mean": 40.0,
}


def priority(item, bins):
    S = _state
    S["fired"] += 1
    it = float(item)

    # Update online item-size histogram with decay for adaptivity.
    S["size_hist"] *= 0.999
    si = int(it)
    if 1 <= si <= 100:
        S["size_hist"][si] += 1.0
    S["mean"] = 0.98 * S["mean"] + 0.02 * it

    hist = S["size_hist"]
    hmax = hist.max()
    # Normalized probability that a future item equals exactly residual r.
    fill_prob = hist / (hmax + 1e-9)   # length 101

    b = np.asarray(bins, dtype=np.float64)
    res = b - it                       # remaining capacity after placement

    # Strict best-fit tightness: dominates bin choice.
    tight = 1.0 / (1.0 + res ** 1.5)

    # Exact-fillability of the residual: reward residuals equal to (near) common item sizes.
    r_int = np.clip(res.astype(np.int64), 0, 100)
    exact = fill_prob[r_int]

    # Soft fillability: reward residuals that are somewhat likely to be filled by a
    # small item later, penalize residuals that are far from any common size.
    neigh = np.zeros_like(res)
    for d in (-1, 0, 1):
        idx = np.clip(r_int + d, 0, 100)
        neigh = np.maximum(neigh, fill_prob[idx])
    fill_soft = 0.5 * exact + 0.5 * neigh

    # Busy-bin bonus: prefer already-open (more filled) bins.
    busy = (99.0 - res) / 100.0

    # Deterministic rotating tie-break.
    S["phase"] = (S["phase"] + 1) % 8
    phase = S["phase"]
    idx = np.arange(b.shape[0])
    rot = ((idx + phase) % 8).astype(np.float64) * 1e-6

    score = (
        4.0 * tight
        + 0.8 * fill_soft
        + 0.10 * busy
        + rot
    )
    return score
# EVOLVE-BLOCK-END
