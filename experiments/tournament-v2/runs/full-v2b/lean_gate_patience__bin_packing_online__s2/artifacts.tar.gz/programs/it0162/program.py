# EVOLVE-BLOCK-START
"""Best-fit core with a stateful 'usable gap' bonus."""
import numpy as np


_mean = 40.0
_count = 0


def priority(item, bins):
    """Prefer the tightest fit, but slightly reward leaving a typical-sized gap."""
    global _mean, _count
    _count += 1
    # Online running estimate of mean item size.
    _mean += (item - _mean) / _count

    resid = (bins - item).astype(np.float64)  # >= 0

    # Dominant best-fit: smaller residual is better.
    score = -resid

    # Small bonus when the leftover gap is near a typical future item size,
    # so the bin can still be filled usefully later.
    gap_bonus = 0.5 * np.exp(-np.abs(resid - _mean) / 20.0)
    score = score + gap_bonus

    return score
# EVOLVE-BLOCK-END
