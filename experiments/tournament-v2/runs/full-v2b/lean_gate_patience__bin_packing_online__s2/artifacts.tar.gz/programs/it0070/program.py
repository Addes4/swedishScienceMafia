# EVOLVE-BLOCK-START
"""Best-fit with quadratic tightness, new-bin penalty, and rotating tie-break."""
import numpy as np

_state = {"calls": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["calls"] += 1
    n = bins.shape[0]

    residual = bins - item  # capacity left after placing the item (>= 0 for shown bins)

    # Quadratic tightness: strongly prefer small residual, making near-exact fills
    # dominate merely-close fits. Normalize so the term stays ~O(item).
    tightness = -residual.astype(np.float64) ** 2 / 100.0

    # Penalty for opening a brand-new bin (residual would be 100 - item).
    fresh = (bins == 100)
    new_penalty = 2.0 + 1.0 * (item / 100.0)
    penalty = -new_penalty * fresh.astype(np.float64)

    # Rotating deterministic tie-break so exact ties don't always favor low indices.
    idx = np.arange(n, dtype=np.float64)
    phase = (_state["calls"] * 0.6180339887498949) % 1.0
    jitter = 0.010 * np.sin((idx + phase * n) * 0.7)

    return tightness + penalty + jitter
# EVOLVE-BLOCK-END
