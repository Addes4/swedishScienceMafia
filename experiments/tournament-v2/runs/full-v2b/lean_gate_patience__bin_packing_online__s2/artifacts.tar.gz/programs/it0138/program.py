# EVOLVE-BLOCK-START
"""Online bin packing: stateful residual-desirability best fit.

Score each candidate bin by:
  * a tightness term (prefer small residual after placing the item),
  * a desirability term that mildly prefers residuals near values that past items
    have been able to match, avoiding useless "orphan" residuals,
  * a small bonus for already-used bins so we don't open new bins eagerly,
  * a rotating pseudo-random tie-break so equally-tight bins vary over time.
"""
import numpy as np

# Module-level state (persists across calls within an instance).
_cnt = 0
_hist = np.zeros(101, dtype=np.float64)          # counts of past item sizes
_TIE = None                                       # rotating tie-break vector


def _ensure_tie(n):
    global _TIE
    if _TIE is None or len(_TIE) < n:
        rng = np.random.default_rng(12345)
        _TIE = rng.random(max(n, 64)).astype(np.float64)
    return _TIE


def priority(item, bins):
    global _cnt, _hist
    _cnt += 1
    n = len(bins)

    # --- update learned histogram of arrival sizes ---
    # Decay slowly so recent distribution still dominates, then count this item.
    if _cnt % 64 == 0:
        _hist *= 0.95
    _hist[item] += 1.0

    # total mass and a per-size "reachability" weight derived from history
    total = _hist.sum()
    if total <= 0:
        total = 1.0
    # probability-ish weights, smoothed
    w = _hist / total

    # --- compute residual after placing the item in every bin ---
    comp = bins.astype(np.float64)
    resid = comp - item                                  # >= 0 guaranteed by harness

    # --- tightness term: strongly prefer small residuals ---
    # nonlinear: -log(1 + resid) makes near-perfect fits very attractive
    tight = -np.log1p(resid)

    # --- desirability of the *resulting residual* ---
    # A residual r is "good" if future items can likely fill it well.
    # Approximate: reward residuals that are small (finish bins) and penalize
    # residuals in a "dead zone" midrange where many sizes can neither fill
    # nor leave a near-perfect gap.  Use a smooth bump penalty.
    # Build a lookup over integer residuals 0..100 from history.
    idx = np.clip(resid.astype(np.int64), 0, 100)
    # expected best-fill quality of residual r: how close can some item get
    # (from below) to r?  weighted by history.
    sizes = np.arange(1, 101, dtype=np.float64)
    # goodness(r) = max over s<=r of w[s] weighted tightness of leaving r-s
    # Precompute via cumulative ops to stay fast.
    # For each r, compute a cheap proxy: sum over s<=r of w[s] * (1 - (r-s)/100)
    wsum = np.cumsum(w)                                  # prefix sums of weights
    wsum_ex = np.concatenate(([0.0], wsum))              # wsum_ex[r] = sum_{s<=r} w[s]
    # weighted contribution of s to gap (r-s): sum_s w[s]*(r-s)
    s_arr = sizes
    ws = w[1:101]
    # cumulative of w[s]*s
    ws_cum = np.concatenate(([0.0], np.cumsum(ws * s_arr)))
    # For residual r (clip to 100):
    #   sum_{s<=r} w[s]*(r-s) = r*W(r) - sum_{s<=r} w[s]*s
    r_vals = np.arange(0, 101, dtype=np.float64)
    Wr = wsum_ex[np.clip(r_vals.astype(np.int64), 0, 100)]
    SWr = ws_cum[np.clip(r_vals.astype(np.int64), 0, 100)]
    avg_gap = r_vals * Wr - SWr
    # normalize by total weight mass (w sums to 1) -> average gap in [0,100]
    desirability = -avg_gap / 100.0                      # higher is better

    des_term = desirability[idx]

    # --- busy-bin bonus: discourage opening new bins ---
    used_mask = comp < 100.0
    busy = np.where(used_mask, 0.05, 0.0)

    # --- rotating pseudo-random tie-break ---
    tie = _ensure_tie(n)[:n]
    # rotate by call count for determinism-free spread across equal scores
    shift = (_cnt * 7) % n
    tie_rot = np.concatenate((tie[shift:], tie[:shift])) * 0.01

    score = tight * 1.0 + des_term * 0.6 + busy + tie_rot
    return score
# EVOLVE-BLOCK-END
