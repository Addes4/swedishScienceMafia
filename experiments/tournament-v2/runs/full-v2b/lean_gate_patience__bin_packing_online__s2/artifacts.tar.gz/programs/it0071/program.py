# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus, mean-item residual targeting, and new-bin penalty."""
import numpy as np

_state = {"calls": 0, "sum": 0.0, "count": 0}

# Rough model of the item-size distribution (Weibull-shaped, mean ~40).
# Likely single-item completions cluster around the mean with a spread.
_LIKELY = None


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["calls"] += 1
    _state["sum"] += item
    _state["count"] += 1

    residual = bins - item  # capacity left after placing the item (>= 0 for shown bins)

    # Primary: best-fit. Prefer smallest residual; scale so exact fits dominate.
    tightness = -residual.astype(np.float64)

    # Secondary: reward a residual that can still hold a typical future item well,
    # avoiding stranded tiny leftovers; target around the running item-size mean.
    mean_item = _state["sum"] / _state["count"]
    r = residual.astype(np.float64)
    # Bonus peaks when residual is close to mean_item (reusable for one more item).
    reuse = -np.abs(r - mean_item) * 0.15
    # Extra bonus for near-exact fits (residual 0) and very small leftovers.
    nearexact = np.where(r <= 2, 0.5 - 0.25 * r, 0.0)

    # Mild penalty for opening a brand-new bin.
    fresh = (bins == 100)
    new_penalty = 0.9 + 0.8 * (item / 100.0)
    penalty = -new_penalty * fresh.astype(np.float64)

    return tightness + reuse + nearexact + penalty
# EVOLVE-BLOCK-END
