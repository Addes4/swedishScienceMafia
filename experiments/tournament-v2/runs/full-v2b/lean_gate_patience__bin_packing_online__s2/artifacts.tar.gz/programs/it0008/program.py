# EVOLVE-BLOCK-START
"""Best-fit augmented with a deterministic like-sized pairing tie-break.

Pure best-fit (minimize residual after placement) is the strongest simple online rule here.
We keep that as the primary key, but replace the random tie-break with a structured one:
among bins achieving the tightest fit, prefer the bin whose current remaining capacity is
closest to the arriving item's size.  Pairing items with bins that can currently hold a
copy of themselves tends to pack similarly sized items together, leaving fuller, less
fragmented residual gaps, without ever sacrificing the primary best-fit quality.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    m = residual.min()

    # Primary: tightest fit (smaller residual better). Secondary: how close the bin's
    # current free space is to the item size (prefer near-equal), which clusters like sizes.
    closeness = -np.abs(bins - item).astype(np.float64)

    # Exact-tightest-fit bins get a large bonus so they always dominate any looser fit.
    is_tight = (residual == m)
    score = closeness + 1000.0 * is_tight.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

