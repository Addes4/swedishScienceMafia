# EVOLVE-BLOCK-START
"""Harmonic-fit with a stateful complementary-residual preference."""
import numpy as np


class _State:
    call = 0
    recent = np.zeros(0, dtype=np.int64)


def priority(item, bins):
    """Prefer tight fits; reward residuals matching recently seen item sizes; avoid new bins."""
    b = bins.astype(np.int64)
    it = int(item)

    # Update recent history: keep the last 64 items.
    r = _State.recent
    if r.size:
        r = np.concatenate((r, np.array([it], dtype=np.int64)))
        if r.size > 64:
            r = r[-64:]
    else:
        r = np.array([it], dtype=np.int64)
    _State.recent = r

    residual = b - it  # residual after placing
    # Best-fit tightness: smaller residual is better -> negate.
    score = -residual.astype(np.float64)

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 100.0, 0.0)

    # Reward bins whose residual-after equals a recently seen item size
    # (likely to be filled exactly by a future complementary item).
    # Count how many recent items equal each bin's residual.
    match = np.zeros(b.shape[0], dtype=np.float64)
    if r.size:
        # r[i] are item sizes; residual values up to 100.
        counts = np.bincount(r, minlength=101)
        valid = (residual >= 0) & (residual <= 100)
        match[valid] = counts[residual[valid]].astype(np.float64)
    score += 0.5 * match

    # Penalize opening brand-new bins (residual == 100 means bin was empty).
    score -= np.where(b == 100, 5.0, 0.0)

    # Mild bonus for already-used bins.
    score += np.where(b < 100, 0.25, 0.0)

    # Rotating tie-break.
    _State.call += 1
    n = b.shape[0]
    idx = np.arange(n, dtype=np.float64)
    rotate = float((_State.call * 2654435761) % 1000) * 0.002
    score += ((idx + rotate) % 7.0) * 1e-3

    return score
# EVOLVE-BLOCK-END
