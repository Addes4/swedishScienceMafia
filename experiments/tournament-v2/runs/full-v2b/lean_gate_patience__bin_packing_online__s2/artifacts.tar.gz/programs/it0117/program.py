# EVOLVE-BLOCK-START
"""Size-sensitive best-fit with strong exact-fit preference and consolidation."""
import numpy as np


def priority(item, bins):
    """Best-fit whose tightness weight grows with item size; strongly prefer
    exact fits and discourage opening brand-new bins (most for small items)."""
    b = bins.astype(np.int64)
    it = int(item)

    residual = b - it  # residual after placing

    # Tightness weight: super-linear for large items (they should almost always
    # take the tightest fit), mild for small items (they consolidate flexibly).
    if it <= 50:
        w = 0.01 + 0.004 * it
    else:
        w = 0.01 + 0.004 * 50 + 0.012 * (it - 50)
    score = -w * residual.astype(np.float64)

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 140.0, 0.0)

    # Penalize opening brand-new bins; strongest for small items (they consolidate).
    new_bin_pen = 14.0 - 0.1 * it
    score -= np.where(b == 100, new_bin_pen, 0.0)

    # Mild bonus for already-used bins.
    score += np.where(b < 100, 0.25, 0.0)

    return score
# EVOLVE-BLOCK-END
