# EVOLVE-BLOCK-START
"""Online best-fit: prefer smallest residual, break ties by lower bin index."""
import numpy as np


def priority(item, bins):
    """Score each bin: best-fit (smallest leftover) wins, ties to earliest bin."""
    residual = bins - item  # nonnegative
    # Primary: prefer smaller residual. Secondary: tiny preference keeps ordering stable.
    return -(residual.astype(np.float64)) - 1e-6 * np.arange(bins.shape[0], dtype=np.float64)
# EVOLVE-BLOCK-END
