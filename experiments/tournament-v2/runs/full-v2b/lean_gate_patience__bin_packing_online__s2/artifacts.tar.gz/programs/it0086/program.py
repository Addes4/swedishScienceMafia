# EVOLVE-BLOCK-START
"""Best-fit with a smooth, residual-dependent new-bin penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)

    residual = bins - item
    score = -residual.astype(np.float64)

    is_new = bins >= 100
    if is_new.any():
        used_res = residual[~is_new]
        if used_res.size > 0:
            best_used = used_res.min()
            # Penalty grows with how much worse the best existing fit is than a
            # perfect fill, so we open a fresh bin readily when used bins are loose.
            penalty = 0.5 * (best_used / float(item)) if item > 0 else 0.0
        else:
            penalty = 0.0
        score = score - is_new.astype(np.float64) * penalty

    return score
# EVOLVE-BLOCK-END
