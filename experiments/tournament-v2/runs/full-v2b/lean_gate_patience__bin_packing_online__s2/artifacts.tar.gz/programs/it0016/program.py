"""Best-fit with a "avoid fresh bins" tie-break.

Strategy:
  * residual r = bins - item  (only bins the item fits in are shown).
  * Primary key: smallest residual (tightest fit = classic best-fit).
  * Among bins sharing the minimal residual, prefer the largest index, i.e. newer /
    less-used bins, so that early bins don't get prematurely locked into full states.
  * If the best fit is into a completely empty bin (residual == 100) and some used bin
    could also accept the item, prefer the used bin with the smallest residual to avoid
    needless bin openings.

Weights: primary term dominates; index is a small tie-break.
"""
import numpy as np


def priority(item, bins):
    n = bins.shape[0]
    residual = bins - item  # >= 0 for shown bins

    min_res = residual.min()

    # If the tightest fit is a fresh (empty) bin, try to use any used bin instead.
    if min_res == 100:
        used = np.flatnonzero(residual < 100)
        if used.shape[0] > 0:
            used_res = residual[used]
            best_res = used_res.min()
            cand = used[used_res == best_res]
            pick = cand[-1]
            out = np.full(n, -1.0, dtype=np.float64)
            out[pick] = 1.0
            return out

    candidates = np.flatnonzero(residual == min_res)
    pick = candidates[-1]

    out = np.full(n, -1.0, dtype=np.float64)
    out[pick] = 1.0
    return out
