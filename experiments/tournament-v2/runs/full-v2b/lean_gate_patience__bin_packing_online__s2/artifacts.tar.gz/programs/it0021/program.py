# EVOLVE-BLOCK-START
"""Sum-of-squares residual minimization with randomized tie-breaking."""
import numpy as np

_state = {"c": 0}


def priority(item, bins):
    """Prefer the bin whose post-placement residual is smallest in L2 sense."""
    _state["c"] = (_state["c"] + 1) & 0xFFFF
    n = len(bins)
    residual = (bins - item).astype(np.float64)
    # primary: minimize squared residual (tightest leftover)
    base = -(residual * residual)
    # tiny pseudo-random per-call, per-bin perturbation to vary tie order
    idx = np.arange(n, dtype=np.float64)
    h = np.mod(idx * 2654435761.0 + _state["c"] * 40503.0, 2.0 ** 31)
    return base + h * (1.0 / (2.0 ** 40))
# EVOLVE-BLOCK-END

