# EVOLVE-BLOCK-START
"""Hybrid bin-choice: log-tightened best fit with anti-new-bin bonus and rotating tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        self.count = np.zeros(101, dtype=np.int64)


_state = _State()


def priority(item, bins):
    """Score each bin: prefer tight fits, mildly avoid opening new bins, rotate ties."""
    _state.tick += 1

    # Residual capacity after placing the item.
    residual = bins - item  # nonnegative because bins are the fitting bins

    # Log-tightened penalty: small residuals are punished harshly, large ones smoothly.
    # log1p keeps it well-behaved for residual 0 (perfect fit).
    fit_score = -np.log1p(residual.astype(np.float64))

    # Mild bonus for reusing already-open bins (residual < 100), penalty for brand-new bins.
    # (bins is int64; residual==(100-item) means previously empty -> would become brand new.)
    is_new = (residual == (100 - item))
    reuse_bonus = np.where(is_new, -0.35, 0.0)

    # Stateful rotating tie-break: a tiny position-dependent wobble keyed by tick,
    # so equal-quality bins vary across calls instead of always locking onto index 0.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    wobble = 1e-3 * ((idx + _state.tick * 0.6180339887) % 1.0)

    return fit_score + reuse_bonus + wobble
# EVOLVE-BLOCK-END
