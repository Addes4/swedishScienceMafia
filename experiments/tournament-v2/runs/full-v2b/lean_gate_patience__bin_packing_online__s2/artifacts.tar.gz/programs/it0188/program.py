# EVOLVE-BLOCK-START
"""Residual desirability: best-fit with a stateful fillability penalty."""
import numpy as np

_state = {"mean": 40.0, "alpha": 0.02, "count": 0}


def priority(item, bins):
    """Rank bins by tightness and by how fillable their residual will be."""
    # Update a slow exponentially weighted estimate of recent item sizes.
    m = _state["mean"]
    a = _state["alpha"]
    m = (1.0 - a) * m + a * item
    _state["mean"] = m
    _state["count"] += 1

    b = bins.astype(np.float64)
    residual = b - float(item)

    # Primary: best fit (smaller residual is better).
    tightness = -residual

    # Fillability: residuals near the recent mean item size are useful;
    # very small residuals and residuals far from the mean are worse.
    # Smooth concave bonus, scaled down so it only breaks near-ties.
    scale = max(m, 20.0)
    fillability = np.exp(-((residual - m) / scale) ** 2)

    # Mild bonus for bins that are already somewhat used (avoid opening new bins).
    busy = (100.0 - b) / 100.0

    return tightness + 0.6 * fillability + 0.05 * busy
# EVOLVE-BLOCK-END
