# EVOLVE-BLOCK-START
"""Online bin packing: stateful convex-cost best fit with fillable-residual bonus.

For each fitting bin, compute the residual after placing the item, and score it by
  * a convex "waste" cost of the residual (strongly favor near-perfect fits),
  * a bonus when the resulting residual equals a commonly-seen item size (so it
    can be filled by a future item),
  * a penalty for opening a fresh (empty) bin, scaled by item size,
plus a small rotating tie-break.
"""
import numpy as np

_cnt = 0
_hist = np.zeros(101, dtype=np.float64)
_TIE = None


def _ensure_tie(n):
    global _TIE
    if _TIE is None or len(_TIE) < n:
        rng = np.random.default_rng(20240607)
        _TIE = rng.random(max(n, 64)).astype(np.float64)
    return _TIE


def priority(item, bins):
    global _cnt, _hist
    _cnt += 1
    n = len(bins)

    # Learned histogram of arrival sizes (slowly decayed for adaptivity).
    if _cnt % 128 == 0:
        _hist *= 0.97
    _hist[item] += 1.0
    total = _hist.sum()
    if total <= 0:
        total = 1.0
    w = _hist / total

    comp = bins.astype(np.float64)
    resid = comp - item                       # >= 0, integer-valued
    idx = np.clip(resid.astype(np.int64), 0, 100)

    # --- Convex waste cost of resulting residual ---
    # Near-perfect fits (resid 0) are hugely rewarded; large residuals penalized.
    # Use -log1p(resid) plus a small linear term to break far-tie cases.
    tight = -np.log1p(resid) - 0.002 * resid

    # --- Fillable-residual bonus ---
    # Reward residuals equal to common past item sizes (so future items can fill).
    fill = w[idx]

    # --- New-bin (empty) aversion, scaled by item size ---
    fresh = (comp >= 99.999).astype(np.float64)
    new_pen = fresh * (0.02 + 0.003 * item)

    # --- Rotating deterministic tie-break ---
    tie = _ensure_tie(n)[:n]
    shift = (_cnt * 13) % n
    tie_rot = np.concatenate((tie[shift:], tie[:shift])) * 0.005

    score = 1.0 * tight + 0.35 * fill - new_pen + tie_rot
    return score
# EVOLVE-BLOCK-END
