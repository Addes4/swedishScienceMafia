# EVOLVE-BLOCK-START
"""Online bin packing: simple best-fit with busy-bin preference.

Empirically the learned-histogram desirability terms add noise without helping.
A clean, low-variance rule works better: minimize the resulting residual
(strongest best-fit), and mildly prefer already-used bins so we don't open
new bins when a used bin is an equally-tight fit.
"""
import numpy as np

# Module-level state (persists across calls within an instance).
_cnt = 0
_TIE = None


def _ensure_tie(n):
    global _TIE
    if _TIE is None or len(_TIE) < n:
        rng = np.random.default_rng(20240607)
        _TIE = rng.random(max(n, 64)).astype(np.float64)
    return _TIE


def priority(item, bins):
    global _cnt
    _cnt += 1
    n = len(bins)

    comp = bins.astype(np.float64)
    resid = comp - item                      # >= 0 guaranteed

    # Strong best-fit: prefer the smallest residual after placing the item.
    # Use -resid directly so ordering is by tightness.
    score = -resid

    # Mild busy-bin bonus: reward bins that are already in use (not empty),
    # scaled by their current load.  This avoids opening fresh bins when a
    # used bin is an equally-tight fit.
    load = 100.0 - comp
    busy = np.where(comp < 100.0, 1.0 + load * 0.001, 0.0) * 0.01
    score += busy

    # Tiny rotating tie-break to spread ties across equal bins.
    tie = _ensure_tie(n)[:n]
    shift = (_cnt * 13) % n
    tie_rot = np.concatenate((tie[shift:], tie[:shift])) * 0.001
    score += tie_rot
    return score
# EVOLVE-BLOCK-END
