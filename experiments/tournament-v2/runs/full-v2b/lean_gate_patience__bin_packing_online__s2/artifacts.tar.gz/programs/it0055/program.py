# EVOLVE-BLOCK-START
"""Best-fit variant with stronger new-bin penalty and residue awareness."""
import numpy as np

_state = {"t": 0}


def priority(item, bins):
    """Score bins by tightest fit, penalizing brand-new bins and bad residues."""
    _state["t"] += 1
    t = _state["t"]

    residual = bins - item  # remaining capacity after placing (>=0)

    # Primary: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Exact fit bonus: perfect fills are very valuable.
    score += 3.0 * (residual == 0)

    # Penalty for opening a brand-new (still full) bin.
    brand_new = (bins == 100)
    score -= 1.0 * brand_new

    # Slight extra penalty for leaving a tiny unusable residue (1..5).
    tiny = (residual >= 1) & (residual <= 5)
    score -= 0.25 * tiny

    return score
# EVOLVE-BLOCK-END
