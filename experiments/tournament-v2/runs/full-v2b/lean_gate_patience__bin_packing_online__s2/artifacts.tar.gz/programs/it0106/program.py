# EVOLVE-BLOCK-START
"""Harmonic-Fit: prefer bins whose residual can be exactly completed by items
of complementary sizes, using size-class targets and best-fit fallback."""
import numpy as np


class _State:
    # counts of residuals observed (freq of remaining capacities, bucketed)
    res_hist = np.zeros(101, dtype=np.int64)
    call = 0


# Canonical completion targets: packing a bin to exactly 100 using
# complementary residuals from these "nice" values.
_TARGETS = [100, 50, 34, 33, 26, 25, 20, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5]


def priority(item, bins):
    b = bins.astype(np.int64)
    n = b.shape[0]
    it = int(item)

    # The residual that would exactly complement this item to a "nice" total.
    # Prefer placing the item so the resulting residual is a canonical target.
    residual = b - it

    # exact-fit bonus: residual 0 is ideal
    score = -np.abs(residual).astype(np.float64)

    # Strong bonus when we complete the bin exactly.
    score += np.where(residual == 0, 5.0, 0.0)

    # Bonus when the resulting residual is a canonical target
    # (so a complementary item can later complete the bin).
    target_bonus = np.zeros(n, dtype=np.float64)
    for t in _TARGETS:
        target_bonus += np.where(residual == t, 1.0, 0.0)
    score += target_bonus

    # Avoid opening brand-new bins when a used bin can take the item.
    newbin_pen = np.where(b == 100, -1.0, 0.0)
    # scale penalty with item size (small items can use many bins cheaply; big ones shouldn't open new)
    score += newbin_pen * (it / 100.0)

    return score
# EVOLVE-BLOCK-END
