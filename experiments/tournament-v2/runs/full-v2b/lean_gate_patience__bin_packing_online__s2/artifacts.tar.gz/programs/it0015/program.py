"""Best-fit with a slack band for small items.

Idea:
  * For every bin compute residual r = bins - item (>= 0 for bins shown).
  * For "large" items (item > SLACK), use pure best-fit (smallest r): we want to
    close gaps tightly because big items are hard to place later.
  * For "small" items (item <= SLACK), we prefer a bin whose residual is the
    smallest value that is >= item (i.e. after placing, the bin still has room
    for at least one more similar-sized item). This reserves slack for the many
    small items in a Weibull-like stream, reducing fragmentation.

Ties among equally-scoring bins are broken with a deterministic reservoir step so
we don't always lock the earliest bin.
"""
import numpy as np

SLACK = 40


def priority(item, bins):
    n = bins.shape[0]
    residual = bins - item  # >= 0 for the bins we are shown

    state = priority._state
    state = (state * 1103515245 + 12345) & 0x7FFFFFFF
    priority._state = state

    if item > SLACK:
        # Pure best-fit: smallest residual wins.
        target = residual.min()
        candidates = np.flatnonzero(residual == target)
    else:
        # Prefer the smallest residual that is >= item (leave room for another
        # similar item). If none such exists, fall back to smallest residual.
        ok = residual >= item
        if ok.any():
            target = residual[ok].min()
            candidates = np.flatnonzero(residual == target)
        else:
            target = residual.min()
            candidates = np.flatnonzero(residual == target)

    pick = candidates[state % candidates.shape[0]]

    out = np.full(n, -1.0, dtype=np.float64)
    out[pick] = 1.0
    return out


priority._state = 123456789

