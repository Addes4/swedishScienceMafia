# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with small-item new-bin penalty.

The dominant term is best-fit (minimize resulting residual). A mild extra
penalty discourages opening a brand-new bin for a small item, since small
items are better packed into existing gaps and large items will need the
empty bins later. A stateful rotating tie-break avoids systematic bin-0 bias.
"""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0


_S = _State()


def priority(item, bins):
    _S.tick += 1

    remaining = bins.astype(np.float64)
    residual = remaining - float(item)

    # Best-fit tightness: strongly reward small residuals.
    tight = -np.log1p(residual)

    # Mild busy-bin bonus: reward already-used bins to avoid opening new ones.
    used = (remaining < 100.0).astype(np.float64)
    fullness = (100.0 - remaining) / 100.0
    busy_bonus = used * (0.15 + 0.35 * fullness)

    # Small-item new-bin penalty: penalize selecting an empty bin when the
    # incoming item is small (many small items will arrive; save empties for
    # large items).  Only applies to currently-empty candidate bins.
    empty = (remaining >= 100.0).astype(np.float64)
    small_penalty = empty * max(0.0, (50.0 - float(item)) / 50.0) * 0.25

    # Rotating tie-break.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    phase = (_S.tick * 0.6180339887498949) % 1.0
    tiebreak = 1e-3 * ((idx * 0.7548776662466927 + phase) % 1.0)

    return tight + busy_bonus - small_penalty + tiebreak
# EVOLVE-BLOCK-END
