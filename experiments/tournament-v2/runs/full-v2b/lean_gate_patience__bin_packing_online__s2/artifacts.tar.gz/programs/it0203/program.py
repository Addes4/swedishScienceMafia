# EVOLVE-BLOCK-START
"""Strict best-fit as the dominant rule, with a compact histogram-based
tie-break: prefer post-placement residuals near zero, and give a small extra
boost to residuals that match a frequent small item size (likely exactly
fillable by a single future item)."""
import numpy as np

_STATE = {"n": 0, "size_hist": np.zeros(101, dtype=np.float64), "total": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    st = _STATE
    st["n"] += 1

    hist = st["size_hist"]
    hist[item] += 1.0
    st["total"] += 1.0

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # leftover capacity (>= 0, integer)

    # 1) dominant: best-fit tightness (prefer smallest residual)
    tight = -residual

    # 2) tiny bonus for residual near zero (tight packing)
    near0 = 2.0 * np.exp(-residual / 5.0)

    # 3) small bonus if the residual exactly matches a frequent item size,
    #    i.e. the leftover is likely fillable by one future item.
    total = st["total"]
    probs = hist / total
    # residual is integer-valued; clip to 0..100 for lookup
    ridx = np.clip(residual.astype(np.int64), 0, 100)
    fill = probs[ridx]  # probability a future item exactly equals residual
    fill_bonus = 40.0 * fill  # scaled small relative to best-fit step of 1

    return tight + near0 + fill_bonus
# EVOLVE-BLOCK-END
