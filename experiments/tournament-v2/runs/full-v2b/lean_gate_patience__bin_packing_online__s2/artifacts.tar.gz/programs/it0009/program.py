# EVOLVE-BLOCK-START
"""Adaptive best-fit that penalizes leaving tiny wasted slivers.

Classic best-fit places the item into the bin minimizing residual capacity after placement.
This is strong, but it can create bins with a tiny leftover (e.g. 1..3) that no future item
can use, wasting a whole bin.  We keep best-fit as the dominant criterion but add a mild,
strictly subordinate bonus for bins whose resulting residual is either exactly 0 (perfectly
full) or at least a small threshold (>= 8), and a mild penalty for residual in (0, 8).
Because the bonus is bounded well below 1 and residuals are integers, the ordering of distinct
residuals is preserved: best-fit still always wins for strictly tighter fits.
"""
import numpy as np

_state = {"t": 0}

# Residual values considered "wasted slivers" (too small for typical future items).
_SLIVER_HI = 8


def priority(item, bins):
    residual = bins - item  # residual capacity after placing the item

    _state["t"] += 1

    r = residual.astype(np.float64)

    # Subordinate waste term: reward residual == 0 and residual >= _SLIVER_HI,
    # penalize residuals strictly inside (0, _SLIVER_HI).
    waste = np.zeros_like(r)
    sliver = (residual > 0) & (residual < _SLIVER_HI)
    waste[sliver] = -1.0
    waste[residual == 0] = 1.0
    waste[residual >= _SLIVER_HI] = 0.25

    # Primary key dominates (scale 2.0 > max possible waste swing of 2.0), tiebreak by waste.
    score = -(r) * 2.0 + waste
    return score
# EVOLVE-BLOCK-END
