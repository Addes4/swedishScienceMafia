import numpy as np


def priority(item, bins):
    # Residual capacity after placing the item in each bin.
    residual = bins - item

    # Best-fit: smallest residual first. Tie-break deterministically by index
    # (argmax returns the first maximal element, matching the harness tie rule).
    # Primary key: -residual (larger is better => tighter fit).
    # Secondary: prefer bins that still leave room for a typical item (~40)
    # is NOT applied here; pure best-fit is the strongest known simple rule.
    out = -residual.astype(np.float64)
    return out
