# EVOLVE-BLOCK-START
"""Stateful best-fit hybrid.

Score bins by how tightly the item fits, add a small penalty against opening
brand-new (empty, remaining==100) bins, and use a rotating pseudo-random offset
to break ties among equally good bins so selection does not lock onto low indices.
"""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        # deterministic pseudo-random permutation table reused for tie-breaks
        rng = np.random.default_rng(123456789)
        self.noise = rng.random(65536)


_STATE = _State()


def priority(item, bins):
    _STATE.tick += 1
    n = bins.shape[0]

    # Best-fit tightness: smaller residual after placing is better.
    # residual = bins - item; we want small residual (tight fit).
    residual = bins - item  # >= 0 for all shown bins

    # Base score: prefer tight fits. Use negative residual scaled.
    score = -residual.astype(np.float64)

    # Small penalty for opening a brand-new bin (remaining capacity full = 100).
    # This discourages unnecessary new-bin openings without blocking them.
    is_new = (bins == 100)
    score -= is_new.astype(np.float64) * 0.75

    # Stateful rotating pseudo-random tie-break so equal-quality bins vary.
    # Offset rotates each call; noise indexed by (bin index + tick) mod table.
    tick = _STATE.tick
    idx = (np.arange(n) + tick) & 0xFFFF
    score += _STATE.noise[idx] * 1e-3

    return score
# EVOLVE-BLOCK-END
