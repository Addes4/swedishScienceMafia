# EVOLVE-BLOCK-START
"""Size-sensitive best-fit with a stateful complementary-residual preference."""
import numpy as np


class _State:
    call = 0
    recent = np.zeros(0, dtype=np.int64)


def priority(item, bins):
    """Best-fit whose tightness weight grows with item size; prefer exact fits,
    reward residuals matching recently seen item sizes, and discourage new bins
    most strongly for small items."""
    b = bins.astype(np.int64)
    it = int(item)

    # Update recent history: keep the last 64 items.
    r = _State.recent
    if r.size:
        r = np.concatenate((r, np.array([it], dtype=np.int64)))
        if r.size > 64:
            r = r[-64:]
    else:
        r = np.array([it], dtype=np.int64)
    _State.recent = r

    residual = b - it  # residual after placing

    # Tightness weight grows with item size: large items strongly prefer tight fits.
    w = 0.01 + 0.005 * it
    score = -w * residual.astype(np.float64)

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 100.0, 0.0)

    # Reward bins whose residual-after equals a recently seen item size.
    match = np.zeros(b.shape[0], dtype=np.float64)
    if r.size:
        counts = np.bincount(r, minlength=101)
        valid = (residual >= 0) & (residual <= 100)
        match[valid] = counts[residual[valid]].astype(np.float64)
    score += 0.5 * match

    # Penalize opening brand-new bins; strongest for small items (they consolidate).
    new_bin_pen = 14.0 - 0.1 * it  # larger for small items
    score -= np.where(b == 100, new_bin_pen, 0.0)

    # Mild bonus for already-used bins.
    score += np.where(b < 100, 0.25, 0.0)

    # Rotating tie-break.
    _State.call += 1
    n = b.shape[0]
    idx = np.arange(n, dtype=np.float64)
    rotate = float((_State.call * 2654435761) % 1000) * 0.002
    score += ((idx + rotate) % 7.0) * 1e-3

    return score
# EVOLVE-BLOCK-END
