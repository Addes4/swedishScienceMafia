# EVOLVE-BLOCK-START
"""Best fit with a mild convex penalty on the leftover residual."""
import numpy as np


def priority(item, bins):
    """Tightest-fit score, with a small quadratic penalty on the residual."""
    residual = bins - item
    r = residual.astype(np.float64)
    return -r - 0.02 * (r * r) / 100.0
# EVOLVE-BLOCK-END

