# EVOLVE-BLOCK-START
"""Online bin packing via best-fit plus complementary-fit scoring.

The dominant signal is best-fit: place the item where the resulting residual is
smallest.  On top of that we reward bins whose residual after placement matches
a frequently observed item size (so the gap is likely fillable later), and we
mildly prefer already-open bins.  A running histogram of past item sizes is
maintained adaptively; a deterministic rotating tie-break spreads ties.
"""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        # histogram over item sizes 1..100
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_S = _State()


def priority(item, bins):
    """Return priorities for each bin; highest score wins, ties to first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities (fits only, includes unused = 100).
    """
    _S.tick += 1

    remaining = bins.astype(np.float64)
    residual = remaining - float(item)

    # Dominant term: best-fit tightness (small residual is best).
    best_fit = -residual

    # Complementary-fit: reward residuals that equal a commonly observed size,
    # since such a gap is likely to be filled by a future item.
    r = np.clip(residual, 0.0, 100.0)
    ri = np.rint(r).astype(np.int64)
    freq = _S.hist[ri]
    denom = _S.total if _S.total > 0.0 else 1.0
    comp_bonus = 20.0 * (freq / denom)

    # Mild busy-bin bonus: reward already-used bins to discourage new bins.
    used = (remaining < 100.0).astype(np.float64)
    fullness = (100.0 - remaining) / 100.0
    busy_bonus = used * (0.15 + 0.35 * fullness)

    # Deterministic rotating tie-break so equally tight bins rotate over time.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    phase = (_S.tick * 0.6180339887498949) % 1.0
    tiebreak = 1e-3 * ((idx * 0.7548776662466927 + phase) % 1.0)

    # Update histogram with the current item (after scoring, never sees future).
    _S.hist[item] += 1.0
    _S.total += 1.0

    return best_fit + comp_bonus + busy_bonus + tiebreak
# EVOLVE-BLOCK-END
