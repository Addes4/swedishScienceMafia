# EVOLVE-BLOCK-START
"""Harmonic-fit: length-aware tightness with a used-bin bonus and a rotating tie-break."""
import numpy as np


class _State:
    call = 0


def priority(item, bins):
    """Score each bin: prefer tight fits, mildly avoid new bins, rotate ties."""
    b = bins.astype(np.float64)

    # Best-fit tightness: smaller residual after placing is better.
    # Use a length-scale so closeness matters more when the item is small.
    residual = b - float(item)
    tightness = -residual

    # Mild bonus for bins that are already partially used (residual < 100),
    # to discourage opening brand-new bins.
    used_bonus = np.where(b < 100.0, 0.25, 0.0)

    # Rotating pseudo-random tie-break so equally tight bins vary over time.
    n = b.shape[0]
    _State.call += 1
    idx = np.arange(n, dtype=np.float64)
    rotate = float((_State.call * 2654435761) % 1000) * 0.002
    tie = ((idx + rotate) % 7.0) * 1e-3

    return tightness + used_bonus + tie
# EVOLVE-BLOCK-END
