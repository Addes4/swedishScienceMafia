# EVOLVE-BLOCK-START
"""Best-fit among existing bins; unconditionally avoid opening brand-new bins."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; item goes to highest score (first on ties).

    Rule: strongly discourage brand-new (empty) bins so any existing bin that
    fits is preferred; among candidates pick the tightest fit (smallest residual).
    """
    bins = np.asarray(bins)

    # Tightest fit: smaller residual after placing -> higher score.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Unconditionally penalize brand-new bins so existing fits always win.
    is_new = bins >= 100
    if is_new.any() and (~is_new).any():
        score = score - is_new.astype(np.float64) * 200.0

    return score
# EVOLVE-BLOCK-END
