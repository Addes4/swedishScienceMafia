# EVOLVE-BLOCK-START
"""Best-fit with randomized tie-breaking and a mild penalty on opening new bins."""
import numpy as np

_state = {"counter": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity if the item is placed here

    # Base score: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Mild penalty for brand-new bins (residual == 100 means the bin was empty),
    # to avoid opening new bins when a used one can fit acceptably.
    new_bin = (residual == (100 - item)).astype(np.float64)
    score -= 0.35 * new_bin

    # Randomized tie-break: add a small cycling pseudo-random perturbation so that
    # ties among equally-tight bins are broken in varying bin order.
    n = score.shape[0]
    _state["counter"] += 1
    idx = np.arange(n, dtype=np.float64)
    perturb = ((idx * ((_state["counter"] * 2654435761) % 1000003) + _state["counter"]) % 97) * 1e-4
    score += perturb

    return score
# EVOLVE-BLOCK-END
