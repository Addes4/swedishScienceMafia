# EVOLVE-BLOCK-START
"""Best fit with a deterministic reusability-aware tie-break."""
import numpy as np


_ALPHA = 1.0 / 600.0  # weak enough not to override best-fit ordering


def priority(item, bins):
    """Score every fitting bin; item goes to the highest-scoring bin.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (unused bins have 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing; lower is tighter fit

    # Primary: tighter fits score higher.
    score = -residual.astype(np.float64)

    # Secondary (tiny): among near-equal residuals, prefer bins that leave a
    # "reusable" gap. Small stranded gaps (just below ~20) are wasteful, so we
    # nudge their score down slightly; usable gaps get a mild reward. This only
    # matters for ties / near-ties since the primary term dominates.
    r = residual.astype(np.float64)
    # Smooth "usefulness" of the leftover: 0 at r=0 (perfectly full, already best),
    # rising then flat. Use a gentle concave shape that slightly favors larger
    # reusable gaps without ever overriding tightness.
    useful = np.log1p(np.minimum(r, 100.0))
    score += _ALPHA * useful

    return score
# EVOLVE-BLOCK-END
