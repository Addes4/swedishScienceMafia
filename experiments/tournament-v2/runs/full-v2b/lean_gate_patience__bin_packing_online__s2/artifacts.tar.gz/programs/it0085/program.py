# EVOLVE-BLOCK-START
"""Best-fit with a conditional new-bin penalty and stable first-fit tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)

    # Base score: prefer the tightest fit (smallest residual after placing the item).
    residual = bins - item
    score = -residual.astype(np.float64)

    # Penalize opening a brand-new (empty) bin only if some existing bin leaves a
    # reasonably tight residual; otherwise allow using a fresh bin.
    is_new = bins >= 100
    if is_new.any():
        has_tight = (residual[~is_new] < item).any() if (~is_new).any() else False
        penalty = 0.5 if has_tight else 0.0
        score = score - is_new.astype(np.float64) * penalty

    return score
# EVOLVE-BLOCK-END
