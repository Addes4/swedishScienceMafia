# EVOLVE-BLOCK-START
"""Best-fit with nonlinear residual preference and strict new-bin avoidance."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)

    residual = (bins - item).astype(np.float64)

    # Base: prefer tightest fit (smallest residual).
    score = -residual

    # Nonlinear emphasis: strongly reward very tight residuals (near-exact fills),
    # which tend to leave reusable leftovers matching common item sizes.
    score = score - 0.02 * residual * residual

    # Strictly avoid opening a brand-new bin when any fitting existing bin exists.
    is_new = bins >= 100
    score = score - is_new.astype(np.float64) * 200.0

    return score
# EVOLVE-BLOCK-END
