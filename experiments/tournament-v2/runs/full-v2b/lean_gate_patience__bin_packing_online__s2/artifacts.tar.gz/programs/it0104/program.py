# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus, size-frequency memory, and graded new-bin penalty."""
import numpy as np


class _State:
    call = 0
    counts = np.zeros(101, dtype=np.float64)
    total = 0.0


def priority(item, bins):
    """Rank bins: strongly prefer exact fits and recently-useful residuals."""
    b = bins.astype(np.float64)
    it = float(item)

    # Update size-frequency memory (recency-weighted, capped effect).
    if _State.total < 1e6:
        _State.counts[item] += 1.0
        _State.total += 1.0

    residual = b - it

    # Base: prefer tightest fit (smallest residual).
    score = -residual

    # Exact fit: residual == 0 is very valuable (closes a bin perfectly).
    exact = np.where(residual <= 0.5, 1.0, 0.0)
    score = score + exact * 3.0

    # Memory bonus: if residual equals a frequently seen item size,
    # the bin can likely be filled exactly later.
    ri = np.clip(residual, 0, 100).round().astype(np.int64)
    freq = _State.counts[ri] / max(_State.total, 1.0)
    score = score + freq * 1.5

    # Graded new-bin penalty: discourage opening brand-new bins,
    # more strongly for small items (existing bins are plentiful).
    small = 1.0 - it / 100.0
    is_new = np.where(b >= 99.5, 1.0, 0.0)
    score = score - is_new * (0.3 + 1.2 * small)

    # Deterministic tie-break via rotating offset to vary choices over time.
    n = b.shape[0]
    _State.call += 1
    idx = np.arange(n, dtype=np.float64)
    rotate = float((_State.call * 2654435761) % 1000) * 0.002
    tie = ((idx + rotate) % 7.0) * 1e-3

    return score + tie
# EVOLVE-BLOCK-END
