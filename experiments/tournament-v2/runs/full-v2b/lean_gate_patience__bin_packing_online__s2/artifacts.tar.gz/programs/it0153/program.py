# EVOLVE-BLOCK-START
"""Pure best-fit with a mild busy-bin bonus."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item (>= 0)

    # Primary term: best fit -> prefer smallest residual.
    tight = -residual.astype(np.float64)

    # Mild bonus for already-used bins (avoid opening new ones when fits are similar).
    used_bonus = np.where(residual < 100, 0.05, 0.0)

    return tight + used_bonus
# EVOLVE-BLOCK-END
