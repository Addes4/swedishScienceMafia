"""Adaptive best-fit: prefer tightest fit, boost exact fits, mildly penalize new bins."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; item goes to the highest score (first on ties)."""
    bins = np.asarray(bins)
    residual = bins - item  # residual capacity after placing the item

    # Tightest-fit preference: strongly reward small residual.
    score = -residual.astype(np.float64)

    # Extra boost for near-exact fits so full bins are favoured.
    score -= (residual * residual).astype(np.float64) * 0.001

    # Mild penalty for opening a brand-new bin (empty before placement).
    score -= (bins >= 100).astype(np.float64) * 0.05

    return score
