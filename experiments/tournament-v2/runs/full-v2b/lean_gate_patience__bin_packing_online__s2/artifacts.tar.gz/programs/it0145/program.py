# EVOLVE-BLOCK-START
"""Online bin packing via stateful best-fit with residual-utility adjustments.

Score each candidate bin primarily by best-fit tightness (small resulting
residual placed first). Two lightweight, online-adaptive corrections sharpen it:

  * Penalize "unfillable gaps": a resulting residual in (0, min_seen) can never
    be filled by any item observed so far, so it is pure waste -- discourage it.
  * Reward residuals that exactly match a commonly observed item size, since
    such a gap is very likely to be consumable by a single future item.

A rotating tie-break spreads equally-tight choices across bins over time.
"""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        self.min_seen = 100
        self.hist = np.zeros(101, dtype=np.float64)  # counts of item sizes seen
        self.n_seen = 0.0


_S = _State()


def priority(item, bins):
    """Return priorities for each bin; highest score wins, ties to first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities (fits only, includes unused = 100).
    """
    _S.tick += 1

    remaining = bins.astype(np.float64)
    residual = remaining - float(item)

    # Best-fit tightness: strongly reward small residuals.
    tight = -np.log1p(residual)

    # Busy-bin bonus: discourage opening brand new bins, scaled by fullness.
    used = (remaining < 100.0).astype(np.float64)
    fullness = (100.0 - remaining) / 100.0
    busy_bonus = used * (0.15 + 0.35 * fullness)

    # --- online-adaptive residual-utility corrections ---
    min_seen = _S.min_seen
    n_seen = _S.n_seen

    # Penalize tiny nonzero gaps below the smallest item ever seen: unfillable.
    unfillable = 0.0
    if n_seen > 0 and min_seen > 1:
        low = (residual > 0.0) & (residual < float(min_seen))
        unfillable = np.where(low, 0.4, 0.0)

    # Reward residuals that match a common item size (likely single-fill).
    match_bonus = 0.0
    if n_seen > 20:
        freq = _S.hist / n_seen
        r_int = np.rint(residual).astype(np.int64)
        valid = (residual > 0.5) & (r_int >= 1) & (r_int <= 100)
        idx = np.clip(r_int, 0, 100)
        f = freq[idx]
        match_bonus = np.where(valid, 0.5 * f, 0.0)

    # Update statistics AFTER scoring (so we don't leak the current item early
    # in a misleading way; using it is fine but we keep the update here).
    if item < _S.min_seen:
        _S.min_seen = item
    _S.hist[item] += 1.0
    _S.n_seen += 1.0

    # Rotating tie-break so equally tight bins rotate over calls.
    n = bins.shape[0]
    idx2 = np.arange(n, dtype=np.float64)
    phase = (_S.tick * 0.6180339887498949) % 1.0
    tiebreak = 1e-3 * ((idx2 * 0.7548776662466927 + phase) % 1.0)

    return tight + busy_bonus - unfillable + match_bonus + tiebreak
# EVOLVE-BLOCK-END
