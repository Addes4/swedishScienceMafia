# EVOLVE-BLOCK-START
"""Adaptive best-fit with a sharp reciprocal tightness score.

Scores each bin by a strictly decreasing, convex function of the residual
capacity so near-exact fills are strongly preferred, with a mild penalty for
opening a fresh bin and a rotating tie-break for equal scores.
"""
import numpy as np

_state = {"tick": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)   # >= 0 for every bin shown

    # Sharp, strictly decreasing tightness: smallest residual -> highest score.
    score = 1.0 / (1.0 + residual * residual)

    # Mild penalty for opening a brand-new bin (residual 100 -> unused).
    score -= 0.02 * (bins >= 100)

    # Stateful pseudo-random tie-break for equal scores.
    _state["tick"] += 1
    n = bins.shape[0]
    if n > 1:
        phase = _state["tick"] % n
        idx = (np.arange(n) + phase) % n
        score += 1e-9 * (n - idx)

    return score
# EVOLVE-BLOCK-END
