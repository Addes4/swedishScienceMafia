# EVOLVE-BLOCK-START
"""Best-fit with reusable-residual bonus and tiny rotating tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        self.total = 0.0
        self.n = 0
        self.mean = 40.0


_state = _State()


def priority(item, bins):
    """Strictly prefer smallest residual (best fit); mildly reward reusable leftovers."""
    _state.tick += 1
    _state.total += item
    _state.n += 1
    # Running empirical mean of item sizes (used as a proxy for typical future item).
    mu = _state.total / _state.n

    residual = bins - item  # >= 0 for all shown bins

    # Strict best fit: smaller residual -> higher score.
    # Use -residual as primary term; scale kept large relative to bonuses.
    base = -residual.astype(np.float64)

    # Small bonus when the post-placement residual is close to the typical item size,
    # i.e. the bin can likely be perfectly refilled by one more average item.
    diff = np.abs(residual.astype(np.float64) - mu)
    reuse_bonus = 0.05 * np.exp(-diff / mu)

    # Tiny rotating tie-break so identical residuals vary across calls.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    wobble = 1e-4 * ((idx + _state.tick * 0.6180339887) % 1.0)

    return base + reuse_bonus + wobble
# EVOLVE-BLOCK-END
