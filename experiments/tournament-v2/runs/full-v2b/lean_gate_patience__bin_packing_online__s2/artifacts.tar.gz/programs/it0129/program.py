"""Best-fit with a cumulative-popularity gap-quality bonus driven by a running size histogram."""
import numpy as np

_state = {"hist": np.zeros(101), "cum": np.zeros(102), "k": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties go to the earliest bin."""
    hist = _state["hist"]
    _state["k"] += 1

    residual = bins - item  # >= 0 for fitting bins
    res = np.clip(residual, 0, 100).astype(np.int64)

    # Tightness is the dominant factor: prefer the smallest residual (best fit).
    score = -residual.astype(np.float64)

    # Bonus for residuals that are common past item sizes, so the leftover gap
    # is likely to be fillable by a future item. Use the exact-size frequency.
    gap_quality = hist[res]
    score += gap_quality * 0.3

    # Reward a perfect fit more strongly.
    score += (residual == 0) * 1.5

    # Only mildly discourage opening a brand-new bin.
    score -= (bins == 100) * 0.1

    # Record this item's size for future calls.
    hist[item] += 1.0

    return score
