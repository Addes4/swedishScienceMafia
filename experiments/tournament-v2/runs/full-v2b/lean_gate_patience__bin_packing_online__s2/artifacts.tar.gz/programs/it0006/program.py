# EVOLVE-BLOCK-START
"""Best-fit with randomized tie-breaking among the tightest residual capacities.

The idea: classic best fit (minimize residual capacity after placing the item) is a strong
online rule.  However, many bins can have the same residual capacity, and always choosing the
first such bin in index order can lock the algorithm into a poor configuration.  Here we shuffle
the ranking among equally-good bins using a cheap deterministic pseudo-random stream that depends
only on a call counter and the item size, so behavior is reproducible and needs no future info.
"""
import numpy as np

_state = {"t": 0}


def priority(item, bins):
    # Residual capacity after placing the item: smaller is a tighter (better) fit.
    residual = bins - item

    # Identify the minimum residual (tightest fit).
    m = residual.min()

    # Deterministic pseudo-random permutation keyed on a running counter and item size.
    _state["t"] += 1
    t = _state["t"]
    # A simple xorshift-flavoured scramble to derive a per-bin pseudo-random tiebreak value.
    idx = np.arange(bins.shape[0], dtype=np.int64)
    key = (idx * np.int64(2654435761) + np.int64(t) * np.int64(40503) + np.int64(item) * np.int64(97))
    key = (key ^ (key >> np.int64(13))) * np.int64(1274126177)
    key = key ^ (key >> np.int64(16))
    # Normalize to [0,1).
    rnd = (key & np.int64(0xFFFFF)).astype(np.float64) / 1048576.0

    # Score: tighter fit is far more important; random value only breaks exact ties.
    # Encode as: primary = -residual, secondary = small random in [0,1).
    score = -(residual.astype(np.float64)) + 0.5 * rnd
    # Force exact-match bins to strictly dominate slightly-worse fits by separating bands.
    return score - 1e-6 * (residual.astype(np.float64) != m).astype(np.float64)
# EVOLVE-BLOCK-END
