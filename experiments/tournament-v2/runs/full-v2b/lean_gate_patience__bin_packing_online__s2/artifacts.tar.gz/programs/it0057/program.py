# EVOLVE-BLOCK-START
"""Best-fit with reusable-residual bonus and new-bin penalty."""
import numpy as np

# Common item sizes (mean ~40 Weibull); reward residuals that stay reusable.
_RESONANT = np.array(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 15, 16, 18, 20, 22, 24, 25, 26,
     28, 30, 32, 34, 35, 36, 38, 40, 42, 44, 45, 46, 48, 50, 52, 54, 55, 56,
     58, 60, 62, 64, 65, 66, 68, 70, 72, 74, 75, 76, 78, 80, 82, 84, 85, 86,
     88, 90, 92, 94, 95, 96, 98, 100],
    dtype=np.float64,
)


def priority(item, bins):
    """Score bins by tightest residual fit with reuse-friendly leftover."""
    residual = (bins - item).astype(np.float64)  # >= 0

    # Primary: prefer tightest fit (smallest residual).
    score = -residual

    # Bonus for leftovers that are themselves common item sizes (reusable gaps).
    # Use distance to the closest resonant size; small distance => bonus.
    dist = np.abs(residual[:, None] - _RESONANT[None, :]).min(axis=1)
    score += 0.15 * (1.0 / (1.0 + dist))

    # Penalty for opening a brand-new empty bin.
    brand_new = (bins == 100)
    score -= 0.5 * brand_new

    return score
# EVOLVE-BLOCK-END
