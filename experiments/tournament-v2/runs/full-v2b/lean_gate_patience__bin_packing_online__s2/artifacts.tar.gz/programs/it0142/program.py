# EVOLVE-BLOCK-START
"""Online bin packing: best fit with a small new-bin penalty.

Score each candidate bin by preferring the smallest resulting residual
(best fit), with a mild bonus for already-used bins so we do not open a
new bin unless it is meaningfully better.  Keep it simple and low-variance.
"""
import numpy as np


def priority(item, bins):
    comp = bins.astype(np.float64)
    resid = comp - item  # >= 0 guaranteed by harness

    # Best fit: strongly prefer the smallest residual after placing the item.
    score = -resid

    # Mild bonus for already-used bins (comp < 100) to reduce bin openings.
    used = comp < 100.0
    score += np.where(used, 0.2, 0.0)

    return score
# EVOLVE-BLOCK-END
