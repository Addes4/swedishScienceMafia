# EVOLVE-BLOCK-START
"""Load-aware best fit.

Primary goal: minimize bins. Pure best-fit tends to leave many partially filled
bins that can't absorb large items later. To counter this, prefer bins that are
already well-used (high existing load) so packing stays dense, while still
preferring the smallest resulting residual among similar-load bins. A strong
penalty discourages opening brand-new bins. A tiny rotating offset breaks ties.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    _state["n"] += 1
    n = _state["n"]

    residual = bins - item                    # >= 0 for shown bins
    b = bins.astype(np.float64)

    # Existing load fraction: denser bins preferred.
    used = 100.0 - b
    dens = used / 100.0

    # Prefer small residual (best fit), normalized by current remaining capacity
    # so that big bins absorbing an item are not over-penalized.
    denom = np.where(b <= 0, 1.0, b)
    tight = residual.astype(np.float64) / denom

    # Strong penalty for opening a brand-new (empty) bin, scaled by item size.
    is_new = (bins == 100) & (residual > 0)
    new_penalty = np.where(is_new, 0.5 + 0.01 * item, 0.0)

    # Tiny rotating tie-break by index.
    m = bins.shape[0]
    idx = np.arange(m, dtype=np.float64)
    rotate = ((idx + n) % m) / m * 1e-6

    score = dens - 0.05 * tight - new_penalty - rotate
    return score
# EVOLVE-BLOCK-END
