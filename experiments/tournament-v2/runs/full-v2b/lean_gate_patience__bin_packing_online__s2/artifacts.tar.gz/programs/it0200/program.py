"""Best-fit dominant rule with two-item fillability tie-break."""
import numpy as np

_state = {
    "count": 0,
    "hist": np.zeros(101, dtype=np.float64),   # EW histogram of item sizes
    "offset": 0,
}


def priority(item, bins):
    it = float(item)
    c = _state["count"]

    # Update online histogram with decay.
    h = _state["hist"]
    h *= (1.0 - 1.0 / 200.0)
    h[int(item)] += 1.0
    _state["count"] = c + 1
    _state["offset"] = (_state["offset"] + 1) % 1000

    b = bins.astype(np.float64)
    resid = b - it                      # >= 0 leftover after placing

    # Dominant: strict best-fit (smallest residual).
    tight = -resid / 100.0

    # Second-order fillability: probability the residual can be filled by
    # one item (prob[r]) or by two items (prob[r-a]*prob[a] summed).
    total = h.sum() + 1e-9
    prob = h / total
    ri = np.clip(np.round(resid).astype(np.int64), 0, 100)

    # one-item fillability
    one = prob[ri]

    # two-item fillability: integral over first item size a <= r
    # prob_pair[r] = sum_a prob[a] * prob[r-a]
    cc = np.concatenate(([0.0], np.cumsum(prob[1:101])))
    # For each residual r, sum_{a=1..r} prob[a]*prob[r-a]
    # Vectorize by looping over distinct residuals (small array).
    pair = np.empty_like(one)
    for k in range(len(ri)):
        r = ri[k]
        if r <= 1:
            pair[k] = 0.0
        else:
            a = np.arange(1, r, dtype=np.int64)
            pair[k] = np.dot(prob[a], prob[r - a])

    fill = (one + 0.5 * pair) * 0.01

    # Tiny busy-bin bonus and deterministic rotating jitter for ties.
    busy = 0.002 * (100.0 - b) / 100.0
    idx = np.arange(len(b), dtype=np.float64)
    jitter = 1e-7 * ((idx + _state["offset"]) % 7)

    return tight + fill + busy + jitter
