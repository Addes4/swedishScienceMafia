# EVOLVE-BLOCK-START
"""Hybrid gap-targeting rule.

For large items (which are hard to place and benefit from tight packing) use classic best fit:
minimize the residual after placement.  For smaller items, prefer a bin whose residual after
placement is near a target gap (~the distribution mean, 40), so that the leftover space is
large enough to be reused by a typical future item instead of being wasted as unusable slivers.
"""
import numpy as np

TARGET_GAP = 40.0


def priority(item, bins):
    residual = bins - item
    rf = residual.astype(np.float64)

    # Best-fit term: always favor tighter fits (negative residual).
    best_fit_score = -rf

    if item >= 50:
        # Large items: pure best fit (tight packing matters most).
        return best_fit_score

    # Small items: blend best-fit with a preference for residuals near TARGET_GAP.
    # Bins whose residual is close to a reusable gap are slightly favored.
    gap_pref = -np.abs(rf - TARGET_GAP) / 100.0
    return best_fit_score + 0.35 * gap_pref
# EVOLVE-BLOCK-END

