"""Best-fit with a stateful residual-quality bonus: prefer leaving a gap that future items can fill."""
import numpy as np

_state = {"hist": np.zeros(101), "k": 0}
_DECAY = 0.9997


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties go to the earliest bin."""
    hist = _state["hist"]
    _state["k"] += 1

    residual = bins - item  # >= 0 for fitting bins

    # Small exponential decay keeps the histogram focused on recent items.
    hist *= _DECAY

    # Tightness: prefer small residuals. Direct residual works well as a best-fit proxy.
    # Scale residual penalty mildly with item size: big items care more about a tight fit.
    w = 1.0 + item * 0.01
    score = -residual * w

    # Bonus for residuals that are common item sizes in the recent past:
    # a leftover gap that matches a frequent size is likely to be filled later.
    gap_quality = hist[np.clip(residual, 0, 100).astype(np.int64)]
    score += gap_quality * 0.5

    # Strong reward for a perfect fit (residual 0).
    score += (residual == 0) * 2.0

    # Penalize opening a brand-new bin (residual would still be 100-item).
    score -= (bins == 100) * (0.1 + item * 0.02)

    # Record this item's size into the histogram for future calls.
    hist[item] += 1.0

    return score
