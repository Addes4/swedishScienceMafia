# EVOLVE-BLOCK-START
"""Best-fit with a stateful sliver penalty to reduce wasted tiny residuals."""
import numpy as np

_state = {"count": 0, "hist": np.zeros(101, dtype=np.float64), "q20": 10.0}


def priority(item, bins):
    """Rank bins by best-fit tightness, lightly penalizing sliver residuals."""
    # Update an online histogram of item sizes with exponential forgetting.
    h = _state["hist"]
    h *= 0.999
    h[item] += 1.0
    c = _state["count"] + 1
    _state["count"] = c

    # Slow estimate of the ~20th-percentile item size (sliver threshold).
    if c % 25 == 0:
        cum = np.cumsum(h)
        total = cum[-1]
        if total > 0:
            idx = int(np.searchsorted(cum, 0.20 * total))
            _state["q20"] = float(min(max(idx, 5), 60))
    q20 = _state["q20"]

    b = bins.astype(np.float64)
    residual = b - float(item)

    # Primary: best fit (smaller residual is better).
    tightness = -residual

    # Mild penalty: residuals too small to host a typical future item are
    # likely wasted slivers. Penalize only the smallest residuals.
    sliver = np.clip((q20 - residual) / q20, 0.0, 1.0)

    return tightness - 0.3 * sliver
# EVOLVE-BLOCK-END
