# EVOLVE-BLOCK-START
"""Residual-matching bin choice: prefer placement that leaves a residual usable by future items."""
import numpy as np

_state = {"counter": 0}

# Typical item sizes for the Weibull-shaped distribution (mean ~40).
_TARGETS = np.array([20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0])
_WEIGHTS = np.array([0.8, 1.0, 1.3, 1.1, 0.9, 0.7, 0.5])


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = (bins - item).astype(np.float64)  # capacity left if placed here
    res = residual[:, None]

    # Weighted sum of Gaussian kernels: reward residuals that match typical future item sizes.
    diff = res - _TARGETS[None, :]
    match = np.exp(-(diff * diff) / (2.0 * 14.0 * 14.0))
    score = (match * _WEIGHTS[None, :]).sum(axis=1)

    # Strong bonus for exact fits.
    score += 1.0 * (residual == 0.0)

    # Penalize unusable slivers smaller than the smallest typical item.
    sliver = ((residual > 0.0) & (residual < 18.0)).astype(np.float64)
    score -= 0.25 * sliver

    # Mild penalty for opening a brand-new bin.
    new_bin = (residual == (100.0 - item)).astype(np.float64)
    score -= 0.30 * new_bin

    # Small cycling perturbation to vary tie-breaking order.
    n = score.shape[0]
    _state["counter"] += 1
    idx = np.arange(n, dtype=np.float64)
    perturb = ((idx * ((_state["counter"] * 2654435761) % 1000003) + _state["counter"]) % 97) * 1e-4
    score += perturb

    return score
# EVOLVE-BLOCK-END

