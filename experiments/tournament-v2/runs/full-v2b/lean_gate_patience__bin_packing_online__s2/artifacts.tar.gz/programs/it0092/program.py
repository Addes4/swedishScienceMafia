# EVOLVE-BLOCK-START
"""Stateful best-fit with residual-likelihood tie-break.

Pure best-fit is strong for online bin packing. We keep it as the primary
rule (smallest residual after placing wins), but break near-ties using a
stateful histogram of observed item sizes: a bin whose resulting residual is
a commonly-seen item size is preferred, since that leftover is likely to be
filled exactly later. Brand-new (capacity-100) bins get a modest penalty so we
avoid opening fresh bins when a reasonable fit already exists.
"""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        # running estimate of "common sizes" via a smoothed frequency
        self.freq = np.zeros(101, dtype=np.float64)


_STATE = _State()


def priority(item, bins):
    st = _STATE
    n = bins.shape[0]

    # Update state with the current item (online; no future info).
    st.counts[item] += 1.0
    st.total += 1.0
    # Recency-weighted frequency: decay old counts slightly, add new.
    st.freq *= 0.999
    st.freq[item] += 1.0

    residual = bins - item  # >= 0 for all shown bins
    res_f = residual.astype(np.float64)

    # Primary: prefer tight fits (small residual).
    score = -res_f

    # Secondary: reward bins whose resulting residual is a common item size,
    # so the leftover can likely be exactly consumed later.
    # Look up smoothed frequency of each residual (clipped to valid range).
    res_idx = np.clip(residual, 0, 100)
    common = st.freq[res_idx] / (st.freq.max() + 1e-9)
    score += common * 0.6

    # Penalize opening brand-new bins (remaining capacity full = 100).
    is_new = (bins == 100)
    score -= is_new.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
