"""Best-fit with online expected-waste penalty on the residual."""
import numpy as np

_CAP = 100
_state = {
    "count": 0,
    "hist": np.zeros(_CAP + 1, dtype=np.float64),
    "offset": 0,
    "waste": np.zeros(_CAP + 1, dtype=np.float64),  # cached expected waste per residual
    "dirty": True,
}


def _recompute_waste():
    """Estimate expected leftover waste for a bin with residual r.

    Greedy estimate: repeatedly subtract the most probable item size that fits,
    accumulating a small penalty when the residual becomes too small to be useful.
    """
    h = _state["hist"]
    total = h.sum()
    if total < 50:
        # too little data: no penalty yet
        _state["waste"][:] = 0.0
        _state["dirty"] = False
        return
    prob = h / total
    # most probable item size that can fit, for a couple of steps
    sizes = np.arange(1, _CAP + 1)
    p = prob[1:]
    waste = np.zeros(_CAP + 1, dtype=np.float64)
    for r in range(1, _CAP + 1):
        rem = r
        steps = 0
        while steps < 4:
            # most probable size <= rem
            if rem < 1:
                break
            cand = p[:rem]
            if cand.size == 0 or cand.sum() <= 0:
                break
            k = int(np.argmax(cand)) + 1  # size with highest prob <= rem
            if cand[k - 1] <= 1e-9:
                break
            rem -= k
            steps += 1
        # residual that cannot hold even the smallest likely item is wasteful
        waste[r] = rem
    _state["waste"][:] = waste
    _state["dirty"] = False


def priority(item, bins):
    it = float(item)
    c = _state["count"]
    _state["count"] = c + 1

    h = _state["hist"]
    h *= (1.0 - 1.0 / 300.0)
    h[int(item)] += 1.0
    if (c % 25) == 0:
        _state["dirty"] = True

    _state["offset"] = (_state["offset"] + 1) % 1000

    if _state["dirty"]:
        _recompute_waste()
    waste = _state["waste"]

    b = bins.astype(np.float64)
    resid = b - it
    ri = np.clip(np.round(resid).astype(np.int64), 0, _CAP)

    # Dominant: best-fit (min residual).
    tight = -resid / 100.0
    # Mild penalty for large expected future waste in the leftover.
    pen = -0.05 * (waste[ri] / 100.0)
    # Tiny deterministic rotating jitter for ties.
    idx = np.arange(len(b), dtype=np.float64)
    jitter = 1e-7 * ((idx + _state["offset"]) % 7)

    return tight + pen + jitter
