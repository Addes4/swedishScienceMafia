# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a size-aware new-bin penalty.

Core rule: pure best fit on the *resulting residual* (dominant term), so we
always prefer the snuggest gap. On top of that we add a mild, size-aware
penalty for opening a brand-new bin (remaining == 100): the smaller the item,
the larger the penalty. This reserves fresh bins for large items, which are
the ones that cannot squeeze into leftover gaps.
"""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0


_S = _State()


def priority(item, bins):
    """Return priorities for each bin; highest score wins, ties to first bin."""
    _S.tick += 1

    remaining = bins.astype(np.float64)
    residual = remaining - float(item)

    # Dominant term: pure best fit (prefer smallest resulting residual).
    best_fit = -residual

    # Size-aware penalty for opening a fresh, unused bin. Small items should
    # not consume brand-new bins when gaps exist elsewhere.
    is_empty = (remaining >= 99.999).astype(np.float64)
    smallness = (100.0 - float(item)) / 100.0          # 0 for item=100, ~1 for tiny
    new_bin_penalty = is_empty * 0.6 * smallness

    # Tiny deterministic rotating tie-break so exact ties rotate across bins
    # instead of always favoring bin 0.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    phase = (_S.tick * 0.6180339887498949) % 1.0
    tiebreak = 1e-3 * ((idx * 0.7548776662466927 + phase) % 1.0)

    return best_fit - new_bin_penalty + tiebreak
# EVOLVE-BLOCK-END
