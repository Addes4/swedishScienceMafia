"""Best-fit with a small stateful gap-utility bonus to break near-ties towards usable residuals."""
import numpy as np

_state = {"hist": np.zeros(101), "k": 0}
_DECAY = 0.9995


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties go to the earliest bin."""
    hist = _state["hist"]
    _state["k"] += 1

    residual = bins - item  # >= 0 for fitting bins

    # Keep a decaying histogram of recent item sizes.
    hist *= _DECAY

    # Primary rule: best fit -- prefer the smallest residual (tightest remaining gap).
    # Use a size-aware weight: larger items benefit more from a tight fit.
    w = 1.0 + item * 0.005
    score = -residual.astype(np.float64) * w

    # Secondary rule: small bonus when the leftover residual is a common recent item size,
    # so the remaining gap is likely to be filled by a future item. Normalized to [0,1].
    total = hist.sum()
    if total > 1.0:
        gap_quality = hist[np.clip(residual, 0, 100).astype(np.int64)] / total
    else:
        gap_quality = np.zeros(len(bins))
    score += gap_quality * 2.0

    # Small extra reward for using an already-open bin instead of a fresh one.
    score -= (bins == 100) * 0.3

    # Record this item's size into the histogram for future calls.
    hist[item] += 1.0

    return score
