import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        self.count = 0
        # histogram of item sizes (1..100), initialized uniformly
        self.hist = np.ones(101, dtype=np.float64)
        self.hist_sum = 101.0

_state = _State()


def priority(item, bins):
    s = _state
    s.tick += 1

    # update histogram with observed item
    s.hist[item] += 1.0
    s.hist_sum += 1.0

    # normalized probability of each size occurring
    probs = s.hist / s.hist_sum

    n = bins.shape[0]
    residual = bins - item  # >= 0

    # tightness: how full the bin becomes
    tightness = item / bins

    # usability of the residual gap: probability that some future item
    # fits well into the leftover space.  Use the probability mass of
    # item sizes <= residual (a gap is usable if typical items fit).
    # cumulative mass up to residual
    cum = np.cumsum(probs)  # cum[k] = P(size <= k)
    ridx = np.clip(residual.astype(np.int64), 0, 100)
    usability = cum[ridx]

    # busy-bin bonus: prefer already-used bins over opening fresh ones
    unused = (bins == 100).astype(np.float64)
    busy_bonus = 0.2 * (1.0 - unused)

    # deterministic tie-break rotating over time (small)
    idx = np.arange(n, dtype=np.float64)
    rot = ((idx + s.tick) % n) * 1e-7

    # combine: tight fit is primary, usable leftover secondary,
    # strong preference to reuse existing bins
    score = 1.0 * tightness + 0.5 * usability + busy_bonus + rot
    return score
