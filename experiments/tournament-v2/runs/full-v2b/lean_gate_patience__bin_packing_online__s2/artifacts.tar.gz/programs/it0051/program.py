"""Best-fit with sharp tightness, new-bin penalty, and stable random tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.counter = 0


_state = _State()


def priority(item, bins):
    bins = np.asarray(bins)
    n = bins.shape[0]

    residual = bins - item  # smaller = tighter fit

    # Sharp preference for tight fits: penalize large residuals more than linearly.
    score = -residual.astype(np.float64) ** 2 * 0.01

    # Exact-fit bonus.
    score += (residual == 0).astype(np.float64) * 2.0

    # Penalty for opening a brand-new (empty) bin.
    score -= (bins >= 100).astype(np.float64) * 1.0

    # Stable per-bin random tie-break, refreshed each call.
    _state.counter += 1
    idx = np.arange(n)
    offset = (_state.counter * 2654435761) & 0x7FFFFFFF
    score += ((idx + offset) % n) * 1e-6

    return score
