# EVOLVE-BLOCK-START
"""Best-fit bin packing with a mild stateful fillability nudge."""
import numpy as np


class _State:
    def __init__(self):
        self.ewma = 40.0
        self.count = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    b = np.asarray(bins, dtype=np.float64)
    size = float(item)

    st = _state
    st.count += 1
    alpha = 0.05
    st.ewma = (1.0 - alpha) * st.ewma + alpha * size
    mu = st.ewma if st.ewma > 1.0 else 40.0

    residual = b - size  # remaining capacity after placing, >= 0

    # Primary: best-fit tightness (smaller residual better).
    tight = -residual

    # Tiny nudge: mildly prefer residuals near the running mean so bins stay refillable.
    fill = 1.0 - np.abs(residual - mu) / (mu + 1.0)

    score = tight + 0.02 * fill

    return score
# EVOLVE-BLOCK-END
