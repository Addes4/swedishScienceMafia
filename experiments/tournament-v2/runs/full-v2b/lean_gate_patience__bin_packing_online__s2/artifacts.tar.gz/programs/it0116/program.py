# EVOLVE-BLOCK-START
"""Size-sensitive best-fit with a stateful future-fill residual preference."""
import numpy as np


class _State:
    call = 0
    counts = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Best-fit whose tightness weight grows with item size; prefer exact fits,
    reward residuals matching likely future fillers, and discourage new bins
    most strongly for small items."""
    b = bins.astype(np.int64)
    it = int(item)

    # Exponentially-decayed size profile over past items.
    _State.counts *= 0.995
    _State.counts[it] += 1.0
    counts = _State.counts
    # Normalized likelihood that a future item equals each residual value.
    total = counts.sum()
    if total > 0:
        lik = counts / total
    else:
        lik = counts

    residual = b - it  # residual after placing

    # Tightness weight: super-linear for large items (they should almost always
    # take the tightest fit), mild for small items (they consolidate flexibly).
    if it <= 50:
        w = 0.01 + 0.004 * it
    else:
        w = 0.01 + 0.004 * 50 + 0.012 * (it - 50)
    score = -w * residual.astype(np.float64)

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 140.0, 0.0)

    # Reward bins whose residual-after is a value likely to be filled later by
    # a future item size (probability-weighted, favors common residuals).
    valid = (residual >= 0) & (residual <= 100)
    match = np.zeros(b.shape[0], dtype=np.float64)
    match[valid] = lik[residual[valid]]
    score += 120.0 * match * match  # squared -> emphasize very common residuals

    # Penalize opening brand-new bins; strongest for small items (they consolidate).
    new_bin_pen = 14.0 - 0.1 * it  # larger for small items
    score -= np.where(b == 100, new_bin_pen, 0.0)

    # Mild bonus for already-used bins.
    score += np.where(b < 100, 0.25, 0.0)

    # Rotating tie-break.
    _State.call += 1
    n = b.shape[0]
    idx = np.arange(n, dtype=np.float64)
    rotate = float((_State.call * 2654435761) % 1000) * 0.002
    score += ((idx + rotate) % 7.0) * 1e-3

    return score
# EVOLVE-BLOCK-END

