# EVOLVE-BLOCK-START
"""Stateful best-fit hybrid.

Score bins by how tightly the item fits (smallest resulting residual), and
apply a penalty against opening brand-new (empty, remaining==100) bins. The
penalty decreases mildly with item size so large items can open a fresh bin
when warranted, while small items strongly prefer reusing existing bins.
Ties go to the earliest (lowest-index) bin, giving stable deterministic
packing that tends to consolidate items and reduce bin count.
"""
import numpy as np


def priority(item, bins):
    # Best-fit tightness: smaller residual after placing is better.
    residual = bins - item  # >= 0 for all shown bins
    score = -residual.astype(np.float64)

    # Penalty for opening a brand-new bin. Larger items can justify it more,
    # so scale the penalty down as item size grows.
    new_penalty = 30.0 - 0.25 * float(item)  # ~29.75 for size 1, ~5 for size 100
    if new_penalty < 0.0:
        new_penalty = 0.0
    is_new = (bins == 100)
    score -= is_new.astype(np.float64) * new_penalty

    return score
# EVOLVE-BLOCK-END
