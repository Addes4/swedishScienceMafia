"""Online bin packing: pure Best-Fit bin-choice rule."""
import numpy as np


def priority(item, bins):
    """Best-Fit: put the item in the fullest bin that still fits it."""
    bins = np.asarray(bins, dtype=np.float64)
    return -bins
