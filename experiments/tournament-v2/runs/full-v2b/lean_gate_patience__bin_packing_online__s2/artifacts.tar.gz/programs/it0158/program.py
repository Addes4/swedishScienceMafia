# EVOLVE-BLOCK-START
"""Best-fit with a stateful harmonic bonus: reward residuals that match common item sizes."""
import numpy as np


# Exponential moving histogram over item sizes (1..100), updated each call.
_size_weight = np.zeros(101, dtype=np.float64)
_decay = 0.98


def priority(item, bins):
    """Score bins: dominant best-fit tightness plus a bonus for harmonically reusable residuals."""
    # Update the running size histogram with the current item (exponential decay keeps it recent).
    _size_weight[:] *= _decay
    _size_weight[item] += 1.0

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Dominant term: classic best-fit -> prefer the smallest residual.
    # Normalize so scale stays ~ within [-1, 0].
    score = -resid.astype(np.float64) / 100.0

    # Harmonic bonus: if the residual exactly fits sizes that appear often, that gap is
    # likely to be filled later, so favor it. Sum weight of item sizes <= resid is too
    # global; instead reward when a common size equals the residual closely.
    # Use a small band around each residual via the histogram value at that size.
    r = resid.astype(np.int64)
    r_clip = np.clip(r, 0, 100)
    common = _size_weight[r_clip]
    # Normalize the histogram contribution to a tiny magnitude so best-fit stays dominant.
    score = score + 0.002 * common

    # Small busy-bin bonus: mildly prefer already-used bins (bins < 100).
    score = score + np.where(bins < 100, 0.001, 0.0)

    return score
# EVOLVE-BLOCK-END
