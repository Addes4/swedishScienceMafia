# EVOLVE-BLOCK-START
"""Residual-desirability bin packing with a subset-sum fillability estimate."""
import numpy as np

_state = {
    "mean": 40.0,
    "hist": np.ones(21, dtype=np.float64),
    "size_hist": np.ones(101, dtype=np.float64),
    "cache_key": None,
    "fill_prob": None,
}


def _fill_probability(mu, size_hist):
    """Estimate, for each residual r in 0..100, the probability that r can be
    exactly filled by 1..3 future items, using an empirical recency-weighted
    item-size histogram blended with a smooth parametric prior."""
    s = np.arange(1, 101, dtype=np.float64)
    shape_density = (s / mu) * np.exp(-((s / mu) ** (1.0 / 0.8)))
    shape_density /= shape_density.sum()

    emp = size_hist[1:].copy()
    tot = emp.sum()
    if tot > 0:
        emp = emp / tot
    else:
        emp = shape_density.copy()

    single = 0.5 * emp + 0.5 * shape_density
    single = single / single.sum()

    p1 = single.copy()
    conv2 = np.convolve(single, single)
    conv3 = np.convolve(conv2, single)

    fp = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        v = p1[r - 1]
        if r <= len(conv2):
            v += 0.55 * conv2[r - 1]
        if r <= len(conv3):
            v += 0.25 * conv3[r - 1]
        fp[r] = v
    m = fp.max()
    if m > 0:
        fp /= m
    return fp


def priority(item, bins):
    S = _state
    it = float(item)

    S["mean"] = 0.98 * S["mean"] + 0.02 * it
    mu = S["mean"]

    hb = int(it) // 5
    if hb > 20:
        hb = 20
    S["hist"] *= 0.995
    S["hist"][hb] += 1.0

    si = int(it)
    if si < 1:
        si = 1
    if si > 100:
        si = 100
    S["size_hist"] *= 0.997
    S["size_hist"][si] += 1.0

    hist = S["hist"]
    hmax = hist.max() + 1e-9

    b = np.asarray(bins, dtype=np.float64)
    res = b - it

    # Sharper best-fit: exponentially decaying preference for small residual.
    tight = np.exp(-res * 1.5)

    ridx = np.clip((res / 5.0).astype(np.int64), 0, 20)
    desirability = hist[ridx] / hmax

    key = int(mu * 4.0)
    if S["cache_key"] != key or S["fill_prob"] is None:
        S["fill_prob"] = _fill_probability(mu, S["size_hist"])
        S["cache_key"] = key
    ri = np.clip(np.round(res).astype(np.int64), 0, 100)
    fill = S["fill_prob"][ri]

    score = 12.0 * tight + 0.25 * desirability + 1.4 * fill
    return score
# EVOLVE-BLOCK-END
