# EVOLVE-BLOCK-START
"""Strict best-fit with a very small busy-bin bonus as a deterministic
tie-break. Best-fit minimizes leftover capacity; the busy bonus avoids
opening fresh bins in near-tie situations. No histogram or mean terms that
could perturb the dominant best-fit ordering."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; item goes to highest (first on ties)."""
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # leftover capacity (>= 0)

    # Dominant: strict best-fit (prefer smallest residual).
    tight = -residual

    # Tiny busy-bin bonus: prefer already-filling bins in near ties.
    busy = -1e-3 * (100.0 - bins)

    return tight + busy
# EVOLVE-BLOCK-END
