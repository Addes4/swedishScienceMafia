# EVOLVE-BLOCK-START
"""Residual-matching bin choice with cascade over typical future item sizes."""
import numpy as np

_state = {"counter": 0}

# Typical item sizes for the Weibull-shaped distribution (mean ~40).
_TARGETS = np.array([0.0, 15.0, 20.0, 25.0, 30.0, 40.0, 50.0, 60.0])

_SIGMA = 6.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = (bins - item).astype(np.float64)  # capacity left if placed here

    # Reward residuals that match a typical future item size (usable gaps),
    # with a focused kernel so the signal concentrates on reusable gaps.
    diff = residual[:, None] - _TARGETS[None, :]
    match = np.exp(-(diff * diff) / (2.0 * _SIGMA * _SIGMA))
    score = match.sum(axis=1)

    # Strong bonus for exact fits (residual 0): perfect packing.
    score += 1.5 * (residual == 0.0)

    # Cascade bonus: residual exactly equal to a typical item size (clean reusable gap).
    for t in _TARGETS[1:]:
        score += 0.25 * (residual == t)

    # Penalty for opening a brand-new bin.
    new_bin = (residual == (100.0 - item)).astype(np.float64)
    score -= 0.45 * new_bin

    # Small cycling perturbation to vary tie-breaking order.
    n = score.shape[0]
    _state["counter"] += 1
    idx = np.arange(n, dtype=np.float64)
    perturb = ((idx * ((_state["counter"] * 2654435761) % 1000003) + _state["counter"]) % 97) * 1e-4
    score += perturb

    return score
# EVOLVE-BLOCK-END
