# EVOLVE-BLOCK-START
"""Residual-desirability bin packing with an EWMA item-size estimate."""
import numpy as np

_state = {
    "mean": 40.0,
    "fired": 0,
    "phase": 0,
}


def priority(item, bins):
    S = _state
    S["fired"] += 1

    # EWMA estimate of recent item sizes (starts near the prior mean ~40).
    S["mean"] = 0.98 * S["mean"] + 0.02 * float(item)
    mu = S["mean"]

    b = np.asarray(bins, dtype=np.float64)

    # Residual after placing the item.
    res = b - float(item)

    # Best-fit tightness: strongly prefer the smallest nonnegative residual.
    # Nonlinear (power) to sharpen near-perfect fits vs merely good fits.
    tight = 1.0 / (1.0 + res)

    # Fillability: residuals near common item sizes (around mu) are good;
    # residuals much smaller than a typical item are hard to reuse -> penalize.
    # Concave bell-ish reward peaked broadly around mu.
    width = max(mu, 1.0)
    fill = 1.0 / (1.0 + ((res - mu) / width) ** 2)
    # Extra penalty for residuals so small they can't hold many items.
    small_pen = 1.0 / (1.0 + res)

    # Busy-bin bonus: bins already partially used (small residual relative to full)
    # get a mild boost to avoid opening fresh bins.
    busy = (100.0 - res) / 100.0

    # Rotating stateful tie-break offset to diversify ties deterministically.
    S["phase"] = (S["phase"] + 1) % 8
    phase = S["phase"]
    idx = np.arange(b.shape[0])
    rot = ((idx + phase) % 8).astype(np.float64) * 1e-6

    score = (
        3.0 * tight
        + 0.6 * fill
        - 0.4 * small_pen
        + 0.08 * busy
        + rot
    )
    return score
# EVOLVE-BLOCK-END

