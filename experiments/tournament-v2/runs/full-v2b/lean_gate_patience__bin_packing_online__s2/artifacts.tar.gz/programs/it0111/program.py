# EVOLVE-BLOCK-START
"""Size-sensitive best-fit with a stateful residual-demand preference."""
import numpy as np


class _State:
    call = 0
    demand = None  # float array of length 101, counts of residuals left by past placements


def priority(item, bins):
    """Best-fit whose tightness weight grows with item size; prefer exact fits,
    reward residuals that match a frequently-produced residual (encouraging
    future exact fills), and discourage new bins most strongly for small items."""
    b = bins.astype(np.int64)
    it = int(item)

    if _State.demand is None:
        _State.demand = np.zeros(101, dtype=np.float64)
    demand = _State.demand

    residual = b - it  # residual after placing

    # Tightness weight grows with item size: large items strongly prefer tight fits.
    w = 0.01 + 0.005 * it
    score = -w * residual.astype(np.float64)

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 100.0, 0.0)

    # Reward resulting residuals that are frequently left behind (they tend to be
    # filled exactly by upcoming items, keeping bins tight).
    valid = (residual >= 0) & (residual <= 100)
    match = np.zeros(b.shape[0], dtype=np.float64)
    match[valid] = demand[residual[valid]]
    score += 0.5 * match

    # Penalize opening brand-new bins; strongest for small items (they consolidate).
    new_bin_pen = 14.0 - 0.1 * it  # larger for small items
    score -= np.where(b == 100, new_bin_pen, 0.0)

    # Mild bonus for already-used bins.
    score += np.where(b < 100, 0.25, 0.0)

    # Rotating tie-break.
    _State.call += 1
    n = b.shape[0]
    idx = np.arange(n, dtype=np.float64)
    rotate = float((_State.call * 2654435761) % 1000) * 0.002
    score += ((idx + rotate) % 7.0) * 1e-3

    # Update demand with a mild decay, then record the residual of the chosen bin.
    demand *= 0.995
    best = int(np.argmax(score))
    r = int(b[best]) - it
    if 0 <= r <= 100:
        demand[r] += 1.0

    return score
# EVOLVE-BLOCK-END
