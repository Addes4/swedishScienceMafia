# EVOLVE-BLOCK-START
"""Size-weighted deterministic best fit with a new-bin penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    # Tightness weight grows with item size: large items nearly always take the
    # tightest fit (near-optimal), while small items keep a milder preference.
    w = 1.0 + (item / 100.0) ** 1.5
    score = -w * residual
    # Discourage opening a fresh bin.
    score -= np.where(bins >= 100, 0.5, 0.0)
    return score
# EVOLVE-BLOCK-END
