# EVOLVE-BLOCK-START
"""Two-step lookahead best-fit: when placing an item, prefer bins whose
resulting residual is itself likely to be reusable by future items."""
import numpy as np

_counter = 0


def priority(item, bins):
    """Score every fitting bin; item goes to the highest-scoring bin.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (unused bins have 100).
    """
    global _counter
    _counter += 1

    residual = bins - item  # residual left after placing the item

    # Primary: best fit (tighter residual is better).
    score = -residual.astype(np.float64)

    # Secondary: prefer residuals that are themselves "usable" gap sizes.
    # A residual that can still accommodate a typical item (mean ~40) is more
    # valuable than one stranded just below a common size.  We reward residuals
    # that are large enough to fit at least one more ~mean-sized item, and
    # gently penalize tiny residues that would strand the bin.
    r = residual.astype(np.float64)
    # attractiveness: peaks around moderate residuals (~40), fades for tiny or
    # near-zero leftovers which waste a bin's slot.
    attractive = -np.abs(r - 40.0) / 100.0
    score += attractive * 0.05

    # Penalize stranded tiny residuals (< smallest likely next item ~ several units).
    stranded = np.maximum(0.0, 10.0 - r) / 10.0
    score -= stranded * 0.1

    # Small penalty for opening a brand-new bin.
    score -= (residual == 100).astype(np.float64) * 0.3

    return score
# EVOLVE-BLOCK-END
