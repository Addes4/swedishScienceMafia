# EVOLVE-BLOCK-START
"""Best-fit with stateful randomized tie-breaking and a new-bin penalty."""
import numpy as np

_state = {"t": 0}


def priority(item, bins):
    """Score bins by tightest residual fit with randomized tie-break.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["t"] += 1
    t = _state["t"]

    residual = bins - item  # remaining capacity after placing the item (>=0)

    # Primary: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Mild penalty for opening a brand-new empty bin (residual == 100 - item),
    # i.e. the bin still had its full capacity of 100 before the item.
    brand_new = (bins == 100)
    score -= 0.5 * brand_new

    # Randomized tie-break: tiny deterministic pseudo-random perturbation based
    # on a cycling counter so equal-score bins rotate over time.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    noise = np.sin((idx + 1.0) * (t * 0.6180339887498949)) * 1e-3
    score += noise

    return score
# EVOLVE-BLOCK-END
