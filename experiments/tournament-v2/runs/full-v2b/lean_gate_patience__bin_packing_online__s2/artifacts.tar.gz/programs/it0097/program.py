"""Fresh approach: length-scaled best-fit with partial-bin bonus and rotating tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.counter = 0
        # a fixed pseudo-random-ish sequence used for tie-breaking
        self.rng = np.random.default_rng(12345)
        self.noise = self.rng.random(1 << 16)


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    state = _state
    state.counter += 1

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # >= 0 for all shown bins

    # Length-scale-aware fit tightness: strongly prefer small residual,
    # but use a log-scaled penalty so near-perfect fits aren't brittle.
    # Scale by item size so the preference is relative to the arrival scale.
    scale = 1.0 + item
    fit = -np.log1p(residual / scale)

    # Mild bonus for partially-used bins (remaining < 100) to discourage
    # opening brand-new bins, since a fresh bin has residual = 100 - item.
    partial_bonus = np.where(bins < 100, 0.02, 0.0)

    # Rotating pseudo-random tie-break so equally tight bins don't always
    # lock onto the lowest index.
    n = bins.shape[0]
    idx = (np.arange(n) + state.counter) & 0xFFFF
    tie = state.noise[idx] * 1e-4

    return fit + partial_bonus + tie
