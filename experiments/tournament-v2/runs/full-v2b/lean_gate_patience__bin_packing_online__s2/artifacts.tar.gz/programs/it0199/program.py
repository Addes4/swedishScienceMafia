"""Best-fit with harmonic exact-fill residual reward."""
import numpy as np

_state = {
    "mean": 40.0,
    "count": 0,
    "hist": np.zeros(101, dtype=np.float64),
    "offset": 0,
}


def priority(item, bins):
    it = float(item)
    c = _state["count"]

    alpha = 2.0 / (c + 2.0) if c < 200 else 1.0 / 100.0
    _state["mean"] = (1.0 - alpha) * _state["mean"] + alpha * it
    _state["count"] = c + 1

    h = _state["hist"]
    h *= (1.0 - 1.0 / 200.0)
    h[int(item)] += 1.0
    _state["offset"] = (_state["offset"] + 1) % 1000

    b = bins.astype(np.float64)
    resid = b - it

    # Primary: strict best-fit (smallest residual => largest score).
    tight = -resid / 100.0

    # Reward residuals that a likely future item can fill exactly.
    total = h.sum() + 1e-9
    prob = h / total
    ri = np.clip(np.round(resid).astype(np.int64), 0, 100)
    fill = prob[ri] * 0.5

    # Bonus for leaving zero (perfectly full) bins.
    exact = (resid < 1e-6).astype(np.float64) * 0.3

    idx = np.arange(len(b), dtype=np.float64)
    jitter = 1e-7 * ((idx + _state["offset"]) % 7)

    return tight + fill + exact + jitter
