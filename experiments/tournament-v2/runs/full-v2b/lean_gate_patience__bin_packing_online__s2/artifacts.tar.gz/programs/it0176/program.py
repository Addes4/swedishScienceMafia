"""Online bin packing with a stateful residual-desirability bin-choice rule."""
import numpy as np


class _State:
    def __init__(self):
        self.ewma = 40.0          # exponentially weighted mean item size
        self.n = 0
        self.tick = 0
        self.rot = 0


_S = _State()


def _quantile_targets():
    """Return a small set of 'target residual' capacities that tend to be fillable."""
    m = _S.ewma
    # residuals equal to a typical item or a sum of two typical items are nice
    return (m, 2.0 * m)


def priority(item, bins):
    """Score each bin; highest score wins (ties to first)."""
    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]

    # update running estimate of recent item sizes
    _S.n += 1
    a = 2.0 / (min(_S.n, 200) + 1.0)
    _S.ewma += a * (item - _S.ewma)
    _S.tick += 1
    if _S.tick >= 1:
        _S.rot = (_S.rot + 1) % max(n, 1)

    resid_after = bins - item  # remaining capacity after placing item here

    # 1) best-fit tightness: prefer small residual_after
    tight = -resid_after

    # 2) residual desirability: reward residuals that are close to a fillable target,
    #    i.e. multiples of the estimated mean size, and penalize tiny unusable residuals.
    t1, t2 = _quantile_targets()
    d1 = np.abs(resid_after - t1)
    d2 = np.abs(resid_after - t2)
    # smooth bonus: gaussian bumps centered on fillable targets
    sig = 0.35 * _S.ewma
    fill_bonus = np.exp(-(d1 * d1) / (2.0 * sig * sig + 1e-9))
    fill_bonus += 0.6 * np.exp(-(d2 * d2) / (2.0 * sig * sig + 1e-9))

    # penalize residuals that are too small to be useful but nonzero
    tiny_pen = np.where((resid_after > 0) & (resid_after < item * 0.5),
                        1.0, 0.0)

    # 3) busy-bin bonus: mild preference to fill partially used bins (avoid opening new)
    busy = np.where(bins < 100.0, 1.0, 0.0)

    score = 1.0 * tight + 6.0 * fill_bonus - 4.0 * tiny_pen + 2.5 * busy

    # 4) rotating tie-break: tiny, capacity-aware jitter to break exact ties over time
    idx = np.arange(n)
    jitter = 1e-4 * ((idx + _S.rot) % max(n, 1))
    score = score + jitter

    return score
