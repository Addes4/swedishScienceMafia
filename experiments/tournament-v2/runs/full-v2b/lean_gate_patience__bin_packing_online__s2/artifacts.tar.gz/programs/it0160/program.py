# EVOLVE-BLOCK-START
"""Best-fit by fill ratio with busy-bin preference."""
import numpy as np


def priority(item, bins):
    """Score bins to maximize capacity utilization (best-fit) and reuse bins."""
    # Fill ratio: how much of the bin's remaining space this item fills.
    # Larger is a tighter fit -> lower leftover fraction.
    b = bins.astype(np.float64)
    score = item / b

    # Busy-bin bonus: prefer partially used bins over empty ones to avoid
    # opening new bins unnecessarily.
    busy_bonus = np.where(bins < 100, 0.01, 0.0)
    score = score + busy_bonus

    # Deterministic tie-break to spread choices among equal scores.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    tie = (idx * 0.0000001)
    score = score + tie

    return score
# EVOLVE-BLOCK-END
