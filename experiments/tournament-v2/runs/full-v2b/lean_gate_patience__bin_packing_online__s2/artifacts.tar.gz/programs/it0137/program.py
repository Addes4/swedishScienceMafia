# EVOLVE-BLOCK-START
"""Best-fit with fillable-gap bonus and size-scaled new-bin aversion.

Primary rule: minimize the resulting residual (classic best fit). Among near-equal
residuals, prefer leaving a gap that past items can fill (running histogram of seen
item sizes). Strongly penalize opening a brand-new empty bin, scaled by item size,
so fresh bins are opened only when they are clearly the best fit.
"""
import numpy as np

_state = {"n": 0, "hist": None}

CAP = 100.0


def priority(item, bins):
    _state["n"] += 1
    n = _state["n"]

    # Running histogram of past item sizes (1..100).
    hist = _state["hist"]
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        _state["hist"] = hist

    residual = bins - item                      # >= 0 by contract
    res = residual.astype(np.float64)

    # Base: best fit -> smallest residual is best. Primary weight dominates.
    score = -res * 1000.0

    # Fillable-gap bonus: if the resulting residual is a size commonly seen,
    # leaving that gap is more likely to be packed later.
    total = hist.sum()
    if total > 0:
        r = residual
        valid = (r >= 1) & (r <= 100)
        rr = np.where(valid, r, 0).astype(np.int64)
        common = hist[rr] / total
        common = np.where(valid, common, 0.0)
        # Up to ~15 in bonus scale relative to best-fit term (best-fit gaps differ by 1,
        # base contributes 1000). Keep bonus well below one residual unit's weight.
        score = score + common * 15.0

    # New-bin aversion: penalize placing into a completely empty bin (bins == 100),
    # scaled by item size, so we don't open fresh bins lightly. The penalty is large
    # enough to beat a modest best-fit advantage (but not a much tighter fit).
    is_new = (bins == CAP) & (residual > 0)
    new_pen = np.where(is_new, 250.0 + item * 2.0, 0.0)
    score = score - new_pen

    # Tiny rotating tie-break to avoid always favoring the first bin.
    m = bins.shape[0]
    idx = np.arange(m, dtype=np.float64)
    score = score - ((idx + n) % m) * 1e-9

    # Update histogram AFTER scoring (reflect only past items).
    if 1 <= item <= 100:
        hist[item] += 1.0
        if n % 200 == 0:
            hist *= 0.999

    return score
# EVOLVE-BLOCK-END
