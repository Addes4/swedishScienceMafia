import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        self.count = 0
        self.size_sum = 0.0

_state = _State()


def priority(item, bins):
    s = _state
    s.tick += 1
    s.count += 1
    s.size_sum += item
    mean = s.size_sum / s.count

    # remaining capacity after placing the item
    residual = bins - item  # >= 0 for bins passed in

    # tightness: how full the bin becomes (higher = tighter fit)
    tightness = item / bins

    # penalty for residual that is awkward to fill: peaks around residual = mean
    # we prefer residual to be either very small or a good full item size
    # use a smooth "waste" estimate: leftover fraction that may go unused
    waste = residual / 100.0

    # busy-bin bonus: discourage opening fresh bins (residual == 100 means unused)
    unused = (bins == 100).astype(np.float64)
    busy_bonus = 0.15 * (1.0 - unused)

    # rotating tie-break to spread equally-good choices
    idx = np.arange(bins.shape[0], dtype=np.float64)
    rot = ((idx + s.tick) % bins.shape[0]) * 1e-6

    score = 2.0 * tightness + busy_bonus - 0.4 * waste - 0.02 * np.abs(waste - mean / 100.0) + rot
    return score
