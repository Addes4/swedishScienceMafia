"""Best-fit with exact-fit bonus and smooth new-bin avoidance (no randomness)."""
import numpy as np


def priority(item, bins):
    """Score each bin; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # >= 0 for all shown bins

    # Primary: prefer the tightest fit (smallest residual).
    # Scale residual so exact fits dominate ties.
    score = -residual

    # Strong bonus for a perfect fit (leftover exactly 0).
    score += 50.0 * (residual == 0)

    # New-bin avoidance: penalize bins with large remaining space after placement,
    # so a fresh bin (residual = 100 - item) is only chosen when nothing better exists.
    # Penalty grows smoothly with how empty the bin would become.
    score -= 0.05 * residual

    return score
