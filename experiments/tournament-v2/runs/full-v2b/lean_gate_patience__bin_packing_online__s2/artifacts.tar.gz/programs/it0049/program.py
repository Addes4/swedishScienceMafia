"""Adaptive best-fit with LRU-spreading, sliver avoidance and new-bin penalty."""
import numpy as np


class _State:
    def __init__(self):
        self.counter = 0
        self.last_used = {}  # bin index -> last step it received an item


_state = _State()


def priority(item, bins):
    """Return a priority per bin; item goes to the highest score (first on ties)."""
    bins = np.asarray(bins)
    n = bins.shape[0]

    residual = bins - item  # residual capacity after placing; smaller = tighter fit

    # Base score: prefer tightest fit.
    score = -residual.astype(np.float64)

    # Exact-fit bonus: strongly prefer leaving zero residual.
    score += (residual == 0).astype(np.float64) * 2.0

    # Sliver penalty: tiny non-zero residuals are likely unusable leftovers.
    # Penalize residuals in the range of the smallest item sizes.
    sliver = (residual > 0) & (residual <= 5)
    score -= sliver.astype(np.float64) * 1.5

    # Awkward medium-low band penalty.
    awkward = (residual > 5) & (residual <= 12)
    score -= awkward.astype(np.float64) * 0.4

    # Mild penalty for opening a brand-new bin.
    new_bin_mask = bins >= 100
    score -= new_bin_mask.astype(np.float64) * 0.5

    # LRU spreading: slightly disfavor bins used very recently so that
    # equally-tight-fit bins rotate, leaving flexible tight bins open.
    step = _state.counter
    lu = _state.last_used
    lru_term = np.empty(n, dtype=np.float64)
    for i in range(n):
        lru_term[i] = (step - lu.get(i, -1000))
    # normalize to a small perturbation, more recent -> smaller score
    maxage = float(n) + 1.0
    score -= (maxage - np.minimum(lru_term, maxage)) * 1e-3

    _state.counter += 1

    return score
