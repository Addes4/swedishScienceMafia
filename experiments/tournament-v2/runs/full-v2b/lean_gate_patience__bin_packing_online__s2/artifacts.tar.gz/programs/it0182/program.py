# EVOLVE-BLOCK-START
"""Residual-desirability bin packing: best-fit tightness with a smooth fillability bonus."""
import numpy as np


class _State:
    def __init__(self):
        self.ewma = 40.0          # exponentially-weighted estimate of recent item sizes
        self.count = 0
        self.rot = 0.0            # rotating tie-break offset


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = np.asarray(bins, dtype=np.float64)
    size = float(item)

    st = _state
    st.count += 1
    alpha = 0.08
    st.ewma = (1.0 - alpha) * st.ewma + alpha * size
    mu = st.ewma if st.ewma > 1.0 else 40.0

    residual = b - size  # remaining capacity after placing the item, >= 0

    # Primary: best-fit tightness -- smaller residual is better.
    tight = -residual

    # Secondary: reward residuals close to the estimated common item size (fillable),
    # penalize tiny residuals (< mu) that are hard to refill and near-empty leftovers.
    fill = 1.0 - np.abs(residual - mu) / (mu + 1.0)

    # Busy-bin bonus: used bins (residual small) preferred over fresh full bins.
    busy = (100.0 - b) / 100.0

    score = 3.0 * tight + 0.3 * fill + 0.5 * busy

    # Rotating tie-break so equally scored bins rotate over time.
    st.rot += 0.6180339887
    idx = np.arange(b.size, dtype=np.float64)
    score = score + 1e-4 * np.sin(st.rot + idx)

    return score
# EVOLVE-BLOCK-END
