"""Sharper best-fit with randomized tie-breaking and new-bin penalty."""
import numpy as np


class _State:
    def __init__(self):
        self.counter = 0


_state = _State()


def priority(item, bins):
    """Return a priority per bin; item goes to the highest score (first on ties)."""
    bins = np.asarray(bins)
    n = bins.shape[0]

    residual = bins - item  # residual capacity after placing the item; smaller = tighter

    # Sharper best-fit: quadratically favor tighter fits so near-exact fits dominate.
    r = residual.astype(np.float64)
    score = -(r * r)

    _state.counter += 1
    idx = np.arange(n)
    offset = (_state.counter * 2654435761) & 0x7FFFFFFF
    perm_score = (idx + offset) % n
    score += perm_score * 1e-3

    # Penalty for opening a brand-new bin.
    new_bin_mask = bins >= 100
    score -= new_bin_mask.astype(np.float64) * 100.0

    return score
