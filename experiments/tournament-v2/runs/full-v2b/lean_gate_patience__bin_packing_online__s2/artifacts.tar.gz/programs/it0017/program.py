"""Deterministic Best-Fit (tightest fit, ties to lowest index).

Strategy:
  * Compute residual capacity after placing the item, r = bins - item.
  * Choose the bin with the smallest residual (tightest fit), which is the
    classical Best-Fit heuristic. Ties resolve to the lowest bin index because
    the harness takes the first bin with the highest score.

Best-Fit is the standard choice for online bin packing and is known to give
near-optimal results on many distributions. Randomizing among ties (the previous
version) tended to lock fewer bins but also wasted capacity by choosing looser
fits; pure Best-Fit with a stable lowest-index tie-break is a strong baseline.
"""
import numpy as np


def priority(item, bins):
    n = bins.shape[0]
    # Residual capacity if the item were placed here (only bins it fits in are shown).
    residual = bins - item

    # Best-Fit: smallest residual wins. Use a strictly decreasing score in
    # residual so the tightest fit has the highest score; ties go to the lowest
    # index automatically since the harness picks the first maximum.
    return -residual.astype(np.float64)
