"""Online bin packing: stateful future-fillability bin-choice rule."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)  # counts of item sizes 1..100
        self.total = 0.0
        self.tick = 0
        self.rot = 0

    def observe(self, item):
        self.hist[item] += 1.0
        self.total += 1.0
        self.tick += 1


_S = _State()


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]

    _S.observe(item)
    _S.rot = (_S.rot + 1) % max(n, 1)

    resid_after = bins - item  # remaining capacity after placing item here

    # Probability distribution over future item sizes (Laplace-ish smoothing).
    if _S.total > 0:
        probs = (_S.hist + 0.2) / (_S.total + 0.2 * 101.0)
    else:
        probs = np.ones(101) / 101.0

    # Expected "fit value" of a residual r: how well can a future item land close
    # to filling it exactly (single item), scaled by that size's probability.
    # A residual r is good if it can be exactly matched by a likely item size,
    # so that bin closes with zero waste.
    r_vals = resid_after.astype(np.int64)
    r_clip = np.clip(r_vals, 0, 100)

    # exact-match probability (best possible: future item equals residual)
    exact_p = probs[r_clip]
    # near-match: sum probability of item sizes within +-small window of residual,
    # weighted by closeness, capturing that a close-but-not-exact fill wastes little.
    offs = np.arange(-3, 4)  # -3..3
    near = np.zeros(n, dtype=np.float64)
    for o in offs:
        idx = np.clip(r_vals + o, 0, 100)
        w = 1.0 - abs(o) / 4.0
        near += w * probs[idx]
    fit_val = 0.7 * exact_p + 0.3 * near

    # Only residual > 0 matters for future fitting; residual 0 (perfect close) is ideal.
    close_val = np.where(resid_after == 0, 1.5, fit_val)

    # Best-fit tightness: prefer smaller residual after placement (dominant term).
    tight = -resid_after

    # Busy-bin bonus: mild preference to fill partially used bins.
    busy = np.where(bins < 100.0, 1.0, 0.0)

    # Penalize leaving a tiny residual that's smaller than nearly all items.
    tiny_pen = np.where((resid_after > 0) & (resid_after < item), 0.5, 0.0)

    score = 1.0 * tight + 4.0 * close_val + 2.5 * busy - 1.5 * tiny_pen

    # tiny rotating jitter to break exact ties deterministically
    idx = np.arange(n)
    jitter = 1e-4 * ((idx + _S.rot) % max(n, 1))
    score = score + jitter

    return score
