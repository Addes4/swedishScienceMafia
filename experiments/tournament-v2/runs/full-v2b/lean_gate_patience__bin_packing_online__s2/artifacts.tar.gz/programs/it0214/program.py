# EVOLVE-BLOCK-START
"""Residual-desirability bin packing with a fillability estimate."""
import numpy as np

_state = {
    "mean": 40.0,
    "hist": np.ones(21, dtype=np.float64),
}


def priority(item, bins):
    S = _state
    it = float(item)

    S["mean"] = 0.98 * S["mean"] + 0.02 * it
    mu = S["mean"]

    # Histogram of item sizes (bucket width 5, index 0..20).
    hb = int(it) // 5
    if hb > 20:
        hb = 20
    S["hist"] *= 0.995
    S["hist"][hb] += 1.0
    hist = S["hist"]
    hmax = hist.max() + 1e-9

    b = np.asarray(bins, dtype=np.float64)
    res = b - it

    # Best-fit tightness: sharply prefer the smallest nonnegative residual.
    tight = 1.0 / (1.0 + res ** 2.5)

    # Desirability of the resulting residual: reward residuals near common
    # item sizes (easy to fill later).
    ridx = np.clip((res / 5.0).astype(np.int64), 0, 20)
    desirability = hist[ridx] / hmax

    # Fillability: residual close to a small multiple of the typical item
    # size is likely exactly fillable by future items.
    k = np.maximum(1.0, np.round(res / max(mu, 1.0)))
    fill = 1.0 / (1.0 + (res - k * mu) ** 2 / (mu + 1.0))

    score = 8.0 * tight + 0.8 * desirability + 0.15 * fill
    return score
# EVOLVE-BLOCK-END
