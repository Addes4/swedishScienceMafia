"""Best-fit with randomized tie-breaking and a preference against opening new bins.

The rule computes, for every visible bin, a score that favors the tightest fit
(smallest residual capacity after placing the item) while adding a small cycling
pseudo-random perturbation so that ties are broken in varying order.  A mild
penalty is applied to completely empty bins so that existing partially filled
bins are preferred unless an empty bin gives a notably tighter fit, which tends
to reduce the number of opened bins.
"""
import numpy as np

_state = {"t": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _state["t"] += 1
    t = _state["t"]

    residual = bins - item            # leftover capacity if the item goes here
    # Tightest fit = smallest residual -> highest base score.
    score = -residual.astype(np.float64)

    # Mild preference against opening a brand-new bin (residual == 100 - item, i.e. empty bin).
    # Empty bins have residual equal to 100 - item.
    empty_residual = 100 - item
    is_empty = bins == 100
    score -= 0.75 * is_empty

    # Small cycling pseudo-random perturbation to break ties in varying order.
    n = bins.shape[0]
    idx = np.arange(n)
    # deterministic but t-dependent scramble; tiny magnitude so it only breaks ties
    noise = ((idx * 2654435761 + t * 40503) % 97) / 97.0
    score += 0.01 * noise

    return score
