"""Best-fit with exact-fit bonus and new-bin penalty; deterministic tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.counter = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    state = _state
    state.counter += 1

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # >= 0 for all shown bins

    # Primary: best-fit (smaller residual is better).
    score = -residual

    # Strong bonus for an exact fit: residual == 0.
    score += np.where(residual == 0.0, 10.0, 0.0)

    # Small deterministic bonus for reusing partially-used bins over fresh ones.
    score += np.where(bins < 100.0, 0.05, 0.0)

    return score
