# EVOLVE-BLOCK-START
"""Residual-desirability bin packing with an item-size histogram."""
import numpy as np

_state = {
    "mean": 40.0,
    "fired": 0,
    "phase": 0,
    # histogram over residual sizes 0..100 in bins of width 5
    "hist": np.ones(21, dtype=np.float64),
}


def priority(item, bins):
    S = _state
    S["fired"] += 1
    it = float(item)

    S["mean"] = 0.98 * S["mean"] + 0.02 * it
    mu = S["mean"]

    # Update histogram of item sizes (bucket width 5, index 0..20).
    hb = int(it) // 5
    if hb > 20:
        hb = 20
    S["hist"] *= 0.995
    S["hist"][hb] += 1.0
    hist = S["hist"]

    b = np.asarray(bins, dtype=np.float64)
    res = b - it

    # Best-fit tightness: strongly prefer smallest nonnegative residual.
    tight = 1.0 / (1.0 + res ** 2.0)

    # Desirability of the resulting residual: how likely is this exact residual
    # to be fillable by a typical future item? Reward residuals near common
    # item sizes; penalty grows as residual becomes hard to fill.
    ridx = np.clip((res / 5.0).astype(np.int64), 0, 20)
    desirability = hist[ridx] / (hist.max() + 1e-9)

    # Rotating deterministic tie-break.
    S["phase"] = (S["phase"] + 1) % 8
    phase = S["phase"]
    idx = np.arange(b.shape[0])
    rot = ((idx + phase) % 8).astype(np.float64) * 1e-7

    score = (
        8.0 * tight
        + 0.05 * desirability
        + rot
    )
    return score
# EVOLVE-BLOCK-END

