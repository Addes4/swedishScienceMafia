# EVOLVE-BLOCK-START
"""Stateless-ish best-fit with new-bin penalty.

Score bins by how tightly the item fits (smallest resulting residual wins),
add a fixed penalty against opening brand-new bins, and a tiny deterministic
index-based tie-break so selection is stable.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for all shown bins

    # Primary: prefer tight fits (small residual).
    score = -residual.astype(np.float64)

    # Penalty for opening a brand-new (empty) bin.
    score -= (bins == 100).astype(np.float64) * 0.5

    # Tiny deterministic tie-break: prefer lower index among equals.
    n = bins.shape[0]
    score -= np.arange(n) * 1e-9

    return score
# EVOLVE-BLOCK-END
