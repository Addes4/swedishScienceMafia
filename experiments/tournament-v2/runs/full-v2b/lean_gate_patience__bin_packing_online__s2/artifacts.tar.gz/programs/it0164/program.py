import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        self.count = 0
        self.size_sum = 0.0
        self._recent = []

_state = _State()


def priority(item, bins):
    s = _state
    s.tick += 1
    s.count += 1
    s.size_sum += item

    # online running mean of item sizes (cheap, stable)
    mean = s.size_sum / s.count

    # residual left behind after placing this item in each bin
    residual = (bins - item).astype(np.float64)

    # Dominant term: best-fit -> minimize residual (tightest remaining gap).
    # Normalize to (0,1)-ish so the secondary term can tune near-ties.
    core = -residual

    # Secondary term: prefer residuals close to the mean item size, so that
    # the gap left behind is still likely to be filled by a future item.
    # Use a small weight so it only breaks near-ties in the core term.
    target = mean
    harmony = -np.abs(residual - target) / 100.0

    # Slight busy-bin nudge: keep filling already-opened bins when otherwise
    # equal (residual large means bin was unused). Kept tiny.
    unused = (bins == 100).astype(np.float64)
    busy = 0.05 * (1.0 - unused)

    # Deterministic, tiny rotating tie-break to avoid pathological index bias.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    rot = ((idx + s.tick) % n) * 1e-9

    score = 100.0 * core + 0.5 * harmony + busy + rot
    return score
