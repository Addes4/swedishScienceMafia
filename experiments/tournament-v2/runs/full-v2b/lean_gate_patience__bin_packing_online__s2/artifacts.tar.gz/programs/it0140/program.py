# EVOLVE-BLOCK-START
"""Online bin packing: stateful best-fit with two-item fillability bonus.

For every bin the item fits in, score = best-fit tightness + a bonus if the
resulting residual can be (approximately) exactly completed by two typical
future items, estimated from a running histogram of past arrivals, plus a
small bonus for already-used bins and a rotating tie-break.
"""
import numpy as np

# Module-level state (persists across calls within an instance).
_cnt = 0
_hist = np.zeros(101, dtype=np.float64)      # counts of past item sizes
_TIE = None


def _ensure_tie(n):
    global _TIE
    if _TIE is None or len(_TIE) < n:
        rng = np.random.default_rng(987654321)
        _TIE = rng.random(max(n, 64)).astype(np.float64)
    return _TIE


def priority(item, bins):
    global _cnt, _hist
    _cnt += 1
    n = len(bins)

    # --- update running histogram of arrival sizes ---
    if _cnt % 128 == 0:
        _hist *= 0.9
    _hist[item] += 1.0

    total = _hist.sum()
    if total <= 0:
        total = 1.0
    w = _hist / total
    ws = w[1:101]                                 # weight per size 1..100
    sizes = np.arange(1, 101, dtype=np.float64)

    # --- precompute pair-fillability: can residual r be split into a+b==r
    #     by two item sizes with combined weight w[a]*w[b]?  Also single-item
    #     exact fill gets a strong bonus.  Do it over integer residuals 0..100.
    fill0 = np.zeros(101)                          # single item exact fill
    fill0[1:101] = ws

    # pair mass via convolution-like accumulation (O(100^2), cheap per call
    # only when histogram changes meaningfully; recompute every 16 calls).
    global _pair_cache, _pair_stamp
    fill2 = np.zeros(101)
    if (_cnt % 16 == 1) or ('_pair_cache' not in globals()):
        for r in range(2, 101):
            lo = 1
            hi = r - 1
            a = np.arange(lo, hi + 1)
            b = r - a
            valid = (b >= 1) & (b <= 100)
            if valid.any():
                mass = (ws[a[valid] - 1] * ws[b[valid] - 1]).sum()
                fill2[r] = mass
        globals()['_pair_cache'] = fill2
    else:
        fill2 = _pair_cache

    # --- residual after placing item in every bin ---
    comp = bins.astype(np.float64)
    resid = comp - item

    # best-fit tightness
    tight = -np.log1p(resid)

    idx = np.clip(resid.astype(np.int64), 0, 100)

    # fillability bonus: exact single-item fill is best, then pair fill.
    single = fill0[idx]
    pair = fill2[idx]
    fill_bonus = single * 3.0 + pair * 1.5

    # --- busy-bin bonus: discourage opening new bins ---
    used_mask = comp < 100.0
    busy = np.where(used_mask, 0.05, 0.0)

    # --- rotating tie-break ---
    tie = _ensure_tie(n)[:n]
    shift = (_cnt * 7) % n
    tie_rot = np.concatenate((tie[shift:], tie[:shift])) * 0.01

    score = tight * 1.0 + fill_bonus + busy + tie_rot
    return score
# EVOLVE-BLOCK-END
