# EVOLVE-BLOCK-START
"""Best-fit with residual targeting toward the running item mean."""
import numpy as np

_state = {"calls": 0, "sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["calls"] += 1
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # capacity left after placing the item (>= 0)

    r = residual.astype(np.float64)

    # Best-fit primary term: strongly prefer small residual.
    tightness = -r / 100.0

    # Residual-targeting: reward residuals that sit just under a typical item size
    # (those bins are likely to be filled exactly by a future typical item).
    # Distance to the nearest multiple of the running mean, scaled.
    target = mean if mean > 1.0 else 40.0
    frac = np.mod(r, target) / target
    # frac near 1.0 means residual is just below a multiple -> good.
    target_bonus = 0.15 * frac

    # Mild penalty for opening a brand-new bin.
    fresh = (bins == 100)
    penalty = -0.05 * fresh.astype(np.float64)

    # Tiny deterministic tie-break jitter.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    phase = (_state["calls"] * 0.6180339887498949) % 1.0
    jitter = 0.001 * np.sin((idx + phase * idx.size) * 0.7)

    return tightness + target_bonus + penalty + jitter
# EVOLVE-BLOCK-END
