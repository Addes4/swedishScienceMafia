# EVOLVE-BLOCK-START
"""Strict best-fit as the dominant rule, with a stronger smooth tie-break that
prefers post-placement residuals which are close to zero or to frequent small
item sizes, using an online histogram of item sizes."""
import numpy as np

_STATE = {"n": 0, "ewma": 40.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    st = _STATE
    st["n"] += 1
    st["ewma"] = 0.995 * st["ewma"] + 0.005 * item
    st["hist"] *= 0.999
    st["hist"][item] += 1.0
    mean = st["ewma"]
    hist = st["hist"]

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # leftover capacity (>= 0, integer)

    # 1) dominant: best-fit tightness (prefer smallest residual)
    tight = -residual

    # 2) bonus for residuals near zero (tightly packed) — stronger than before.
    near0_bonus = 3.0 * np.exp(-residual / 4.0)

    # 3) bonus for residuals equal (within tolerance) to a frequent item size,
    #    i.e. likely fillable by a single upcoming item.
    #    Evaluate the histogram at each bin's integer residual via interpolation.
    r_int = np.clip(np.round(residual), 0, 100).astype(np.int64)
    freq_bonus = 0.5 * hist[r_int] / (hist.max() + 1e-9)

    # 4) mild busy-bin bonus: avoid opening fresh bins when alternatives exist
    busy = -0.02 * (100.0 - bins)

    # 5) tiny deterministic rotating tie-break
    idx = np.arange(bins.size, dtype=np.float64)
    rot = 1e-4 * ((idx + st["n"]) % 101)

    return tight + near0_bonus + freq_bonus + busy + rot
# EVOLVE-BLOCK-END
