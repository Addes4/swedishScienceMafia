# EVOLVE-BLOCK-START
"""Best-fit with an item-size-scaled new-bin penalty and stable tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)

    # Base score: prefer the tightest fit (smallest residual after placing the item).
    residual = bins - item
    score = -residual.astype(np.float64)

    # Penalize opening a brand-new (empty) bin, but scale the penalty with item size:
    # large items more legitimately need a fresh bin, small items should reuse.
    is_new = bins >= 100
    if is_new.any():
        penalty = 0.25 + 0.75 * (1.0 - item / 100.0)
        score = score - is_new.astype(np.float64) * penalty

    return score
# EVOLVE-BLOCK-END
