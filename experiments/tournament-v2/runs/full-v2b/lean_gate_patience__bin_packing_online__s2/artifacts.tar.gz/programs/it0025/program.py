"""Best-fit variant that penalizes unusable slivers and rewards perfect fits.

For every visible bin we look at the residual capacity left after placing the
item.  The base score favors the tightest fit (smallest residual).  We then add
a term that penalizes residuals too small to hold a typical future item (a
"sliver" of wasted capacity) and reward a residual of exactly zero (a perfect
fit that wastes nothing).  A mild penalty against opening a brand-new bin and a
small cycling perturbation to break ties complete the rule.
"""
import numpy as np

_state = {"t": 0}

# Residuals in [1, SLIVER) are treated as nearly-unusable wasted space.
SLIVER = 15


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _state["t"] += 1
    t = _state["t"]

    residual = bins - item                 # leftover capacity if the item goes here
    rf = residual.astype(np.float64)

    # Base: tightest fit = smallest residual.
    score = -rf

    # Penalize tiny unusable slivers (residual in 1..SLIVER-1): wasted capacity.
    sliver = (residual > 0) & (residual < SLIVER)
    score -= 0.9 * sliver

    # Reward an exact perfect fit (residual == 0): no wasted capacity at all.
    perfect = residual == 0
    score += 0.5 * perfect

    # Mild preference against opening a brand-new bin.
    is_empty = bins == 100
    score -= 0.75 * is_empty

    # Small cycling pseudo-random perturbation to break ties in varying order.
    n = bins.shape[0]
    idx = np.arange(n)
    noise = ((idx * 2654435761 + t * 40503) % 97) / 97.0
    score += 0.01 * noise

    return score
