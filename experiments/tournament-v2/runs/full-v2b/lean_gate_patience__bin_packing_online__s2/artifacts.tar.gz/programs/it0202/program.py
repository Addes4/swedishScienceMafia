# EVOLVE-BLOCK-START
"""Strict best-fit as the dominant rule, with a small smooth tie-break that
prefers post-placement residuals which are close to zero (tightly packed)
combined with a mild busy-bin bonus, using an online EWMA of item sizes."""
import numpy as np

_STATE = {"n": 0, "ewma": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    st = _STATE
    st["n"] += 1
    st["ewma"] = 0.995 * st["ewma"] + 0.005 * item
    mean = st["ewma"]

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # leftover capacity (>= 0, integer)

    # 1) dominant: best-fit tightness (prefer smallest residual)
    tight = -residual

    # 2) small tie-break: reward residuals near zero (tight packing),
    #    penalize residuals near a full item mean (awkward leftover).
    tight_pen = 3.0 * np.exp(-residual / 3.0) * 0.0  # placeholder slot
    near0_bonus = 2.0 * np.exp(-residual / 5.0)
    mean_pen = 2.0 * np.exp(-((residual - mean) ** 2) / (2.0 * (0.7 * mean) ** 2))

    # 3) mild busy-bin bonus: avoid opening fresh bins when alternatives exist
    busy = -0.02 * (100.0 - bins)

    # 4) tiny deterministic rotating tie-break
    idx = np.arange(bins.size, dtype=np.float64)
    rot = 1e-4 * ((idx + st["n"]) % 101)

    return tight + near0_bonus - mean_pen + busy + rot
# EVOLVE-BLOCK-END
