# EVOLVE-BLOCK-START
"""Residual-desirability rule: best fit tightness + smooth penalty for hard-to-fill residual + busy-bin bonus."""
import numpy as np

# State
_hist = []          # recent item sizes
_offset = 0.0       # rotating tie-break offset
_call = 0

_MEAN = 40.0        # prior mean item size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _offset, _call

    _hist.append(int(item))
    if len(_hist) > 200:
        _hist.pop(0)

    n = len(bins)
    bins_f = bins.astype(np.float64)

    # Residual remaining after placing item here
    resid = bins_f - item

    # Base: best-fit tightness (prefer small residual). Normalize to ~[0,1].
    tightness = -(resid) / 100.0

    # Estimate typical recent sizes (exponentially weighted)
    if _hist:
        h = np.asarray(_hist, dtype=np.float64)
        lam = 0.97
        w = lam ** np.arange(len(h) - 1, -1, -1)
        w /= w.sum()
        mean_size = float((h * w).sum())
    else:
        mean_size = _MEAN

    # Penalty for residuals that are hard to fill later:
    # - residual very small (< mean item) risks leaving an unfillable gap
    # - residual near a "half item" also tends to be awkward
    # Smooth penalty rises as resid goes below ~mean_size, and mildly around resid ~= mean_size.
    small = mean_size
    gap_pen = np.clip((small - resid) / max(small, 1.0), 0.0, 1.0)  # 0 if resid>=mean, 1 if resid==0
    # extra soft penalty when residual is close to the awkward zone just under an item
    awkward = np.exp(-((resid - mean_size * 0.5) / max(mean_size, 1.0)) ** 2)
    penalty = 0.25 * gap_pen + 0.06 * awkward

    # Mild busy-bin bonus: prefer already-used bins (residual < 100) to avoid new bins.
    used = (bins_f < 100.0).astype(np.float64)
    busy_bonus = 0.10 * used

    # Stateful rotating tie-break to spread equally-good choices across bin indices.
    idx = np.arange(n, dtype=np.float64)
    tie = 1e-4 * ((idx + _offset) % 7.0)

    score = tightness - penalty + busy_bonus + tie

    _offset += 1.0
    _call += 1

    return score
# EVOLVE-BLOCK-END
