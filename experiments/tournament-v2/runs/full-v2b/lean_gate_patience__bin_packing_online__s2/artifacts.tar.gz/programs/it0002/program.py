# EVOLVE-BLOCK-START
"""Best fit with a mild size-aware bias to limit fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    gap = bins - item  # leftover after placing
    # Primary: tightest fit (smallest leftover) -> maximize -gap.
    # Mild bias: among nearly equal fits, prefer bins whose leftover is
    # "useful" for future items by penalizing leftovers that are either
    # too small (unusable) or exactly item-sized (likely wasted).
    score = -gap.astype(np.float64)
    # Penalize tiny unusable leftovers slightly less/more based on item size.
    small = gap < item
    score -= 0.05 * gap * small
    return score
# EVOLVE-BLOCK-END

