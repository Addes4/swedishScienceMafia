# EVOLVE-BLOCK-START
"""Best-fit with stateful tie-breaking favoring reusable residuals."""
import numpy as np

_state = {"t": 0}

# Precompute a static table of P(future item <= x) for x = 0..100, based on a
# Weibull with mean ~40 (shape ~1.5, scale ~44). Higher value = more likely a
# future item fits in a bin whose residual is x, so a leftover of size x is
# "usable". We use this to prefer residuals that keep the gap productive.
_MEAN = 40.0
_SHAPE = 1.5
_SCALE = _MEAN / 0.9027  # gamma(1+1/1.5) ~ 0.9027


def _cdf_table():
    xs = np.arange(101, dtype=np.float64)
    # Weibull CDF: 1 - exp(-(x/scale)^shape)
    return 1.0 - np.exp(-np.power(np.maximum(xs, 0.0) / _SCALE, _SHAPE))


_CDF = _cdf_table()


def priority(item, bins):
    """Score bins by tightest fit, breaking ties toward reusable residuals."""
    _state["t"] += 1
    t = _state["t"]

    residual = bins - item  # remaining capacity after placing (>= 0)

    # Primary: tightest fit (smallest residual). Multiply by a large constant
    # so this dominates, but keep resolution for tie-breaking below.
    score = -residual.astype(np.float64)

    # Secondary: prefer residuals that are "usable" for future items.
    # A residual r can fit a future item of size <= r; the expected number of
    # future items it can host grows with P(item <= r). Reward that mildly so
    # we favor leaving a sizeable, frequently-fillable gap over a tiny one.
    resid_clip = np.clip(residual, 0, 100)
    usability = _CDF[resid_clip]
    score += 0.3 * usability

    # Mild penalty for opening a brand-new bin (bins == 100 before placing).
    brand_new = (bins == 100)
    score -= 0.5 * brand_new

    # Deterministic pseudo-random tie-break to rotate among equal bins.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    noise = np.sin((idx + 1.0) * (t * 0.6180339887498949)) * 1e-3
    score += noise

    return score
# EVOLVE-BLOCK-END
