# EVOLVE-BLOCK-START
"""Size-sensitive best-fit with stateful size profile for fillable residuals."""
import numpy as np


class _State:
    call = 0
    counts = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Best-fit whose tightness weight grows with item size; prefer exact fits,
    reward residuals that are likely to be fillable by future items, and
    discourage new bins most strongly for small items."""
    b = bins.astype(np.int64)
    it = int(item)

    # Exponentially-decayed size profile over past items.
    _State.counts *= 0.997
    _State.counts[it] += 1.0
    counts = _State.counts

    residual = b - it  # residual after placing

    # Tightness weight: super-linear for large items (they should almost always
    # take the tightest fit), mild for small items (they consolidate flexibly).
    if it <= 50:
        w = 0.01 + 0.004 * it
    else:
        w = 0.01 + 0.004 * 50 + 0.012 * (it - 50)
    score = -w * residual.astype(np.float64)

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 140.0, 0.0)

    # Reward residuals that are likely to be fillable by a future item. Small
    # residuals can be filled by many possible item sizes, so reward them more.
    valid = (residual >= 0) & (residual <= 100)
    match = np.zeros(b.shape[0], dtype=np.float64)
    match[valid] = counts[residual[valid]]
    # Weight by how "closable" the residual is: small residuals are easier.
    closable = np.where(valid, 1.0 / (1.0 + 0.15 * residual.astype(np.float64)), 0.0)
    score += 0.6 * match * closable

    # Penalize opening brand-new bins; strongest for small items (they consolidate).
    new_bin_pen = 14.0 - 0.1 * it  # larger for small items
    score -= np.where(b == 100, new_bin_pen, 0.0)

    # Mild bonus for already-used bins.
    score += np.where(b < 100, 0.25, 0.0)

    return score
# EVOLVE-BLOCK-END
