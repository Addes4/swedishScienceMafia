# EVOLVE-BLOCK-START
"""Size-scaled best fit with modest new-bin penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)  # >= 0 for every shown bin
    s = item / 100.0

    # Tightness: prefer smallest residual, weighted so larger items care more.
    # Using -residual keeps it monotone; scale by (0.5 + s) so big items emphasize fit.
    score = -(0.5 + s) * residual

    # New-bin penalty: discourages opening a fresh bin (residual 100) so we
    # consolidate into partially used bins when the fit is comparable.
    score -= np.where(bins == 100, 8.0, 0.0)

    # Tiny deterministic tie-break toward lower bin index (fuller, older bins).
    n = bins.shape[0]
    score += 1e-6 * (1.0 - np.arange(n, dtype=np.float64) / max(n, 1))
    return score
# EVOLVE-BLOCK-END
