import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)  # count of sizes
        self.count = 0
        self.tick = 0
        self.recompute_at = 0
        self.fillable = None  # fillable[r] = prob residual r is usable

    def update_hist(self, item):
        self.hist[item] += 1.0
        self.count += 1


_state = _State()

# grid of residual values to precompute fillability for
_RES = np.arange(0, 101)


def _compute_fillable(hist, count):
    # probability vector over sizes 1..100
    p = hist / max(count, 1.0)
    # fillable[r]: expected number of items needed to exactly reach r (approx)
    # We approximate "goodness" of a residual r by how close a single future
    # item matches r, OR r minus a typical item matches something common.
    # Build a cheap estimate: goodness = p[r] (exact match) + sum_s p[s] * p[r-s]
    good = np.zeros(101, dtype=np.float64)
    # exact match
    good += p
    # two-item match: convolution p*p
    conv = np.convolve(p, p)
    conv = conv[:101]
    good += conv
    # three-item match
    conv3 = np.convolve(conv, p)[:101]
    good += conv3
    return good


def priority(item, bins):
    s = _state
    s.tick += 1
    s.update_hist(item)

    # periodically recompute fillability estimate
    if s.fillable is None or s.count >= s.recompute_at:
        s.fillable = _compute_fillable(s.hist, s.count)
        s.recompute_at = s.count + 200

    residual = (bins - item).astype(np.int64)  # >= 0
    residual = np.clip(residual, 0, 100)

    # tightness: prefer small residual (best-fit)
    tightness = item / bins

    # fillability of the leftover residual
    fill = s.fillable[residual]

    # busy-bin bonus: strongly discourage opening fresh bins
    unused = (bins == 100).astype(np.float64)
    busy_bonus = 0.30 * (1.0 - unused)

    # deterministic tie-break by bin index
    idx = np.arange(bins.shape[0], dtype=np.float64)
    rot = idx * 1e-6

    score = 3.0 * tightness + 1.5 * fill + busy_bonus + rot
    return score

