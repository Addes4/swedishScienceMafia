# EVOLVE-BLOCK-START
"""Best-fit with a smooth busy-bin preference and rotating tie-break."""
import numpy as np


_state = {"counter": 0}


def priority(item, bins):
    st = _state
    st["counter"] += 1
    ctr = st["counter"]

    residual = bins - item  # remaining capacity after placing the item (>= 0)

    # Primary: pure best fit (prefer smallest residual).
    tight = -residual.astype(np.float64)

    # Secondary: prefer bins that are already partly used (busy bins).
    # Usage fraction before placement = (100 - bins) / 100.
    usage = (100.0 - bins.astype(np.float64)) / 100.0

    # Rotating tie-break offset spreads ties across bins over time.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    offset = 1e-4 * ((idx + ctr) % n)

    return tight + 0.05 * usage + offset
# EVOLVE-BLOCK-END
