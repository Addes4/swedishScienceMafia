# EVOLVE-BLOCK-START
"""Size-sensitive best-fit with stateful complementary-residual preference
and a learned "closeability" value for each leftover residual."""
import numpy as np


class _State:
    call = 0
    counts = np.zeros(101, dtype=np.float64)      # decaying item-size profile
    close_ok = np.zeros(101, dtype=np.float64)    # times a residual r got closed exactly
    close_seen = np.zeros(101, dtype=np.float64)  # times a residual r existed
    open_res = np.zeros(101, dtype=np.float64)    # decaying map of residuals we created


def priority(item, bins):
    """Best-fit whose tightness weight grows with item size; prefer exact fits,
    reward residuals that historically get closed exactly by future items,
    and discourage opening new bins most strongly for small items."""
    b = bins.astype(np.int64)
    it = int(item)

    # Exponentially-decayed size profile over past items.
    _State.counts *= 0.995
    _State.counts[it] += 1.0
    counts = _State.counts

    # Update closeability statistics: this arriving item closes every existing
    # residual equal to it (well, at most, but statistically it's a demand signal).
    _State.close_ok[it] += 1.0
    _State.close_ok *= 0.999
    _State.close_seen *= 0.999
    _State.open_res *= 0.999

    residual = b - it  # residual after placing

    # Tightness weight: super-linear for large items (they should almost always
    # take the tightest fit), mild for small items (they consolidate flexibly).
    if it <= 50:
        w = 0.01 + 0.004 * it
    else:
        w = 0.01 + 0.004 * 50 + 0.012 * (it - 50)
    score = -w * residual.astype(np.float64)

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 140.0, 0.0)

    valid = (residual >= 0) & (residual <= 100)

    # Reward bins whose residual-after matches a commonly seen item size
    # (likely to be filled by a future item exactly).
    match = np.zeros(b.shape[0], dtype=np.float64)
    match[valid] = counts[residual[valid]]
    score += 0.5 * match

    # Closeability: reward residuals whose ratio close_ok/close_seen is high,
    # i.e. leftovers that in the past tended to be exactly completed soon.
    rv = np.where(valid, residual, 0)
    ok = _State.close_ok[rv]
    seen = _State.close_seen[rv] + counts[rv] * 0.3 + 1.0
    ratio = ok / seen
    ratio = np.where(valid, ratio, 0.0)
    score += 12.0 * ratio

    # Register the residuals we are about to create (soft demand signal).
    np.add.at(_State.close_seen, rv[valid], 1.0)
    np.add.at(_State.open_res, rv[valid], 1.0)

    # Penalize opening brand-new bins; strongest for small items.
    new_bin_pen = 14.0 - 0.1 * it
    score -= np.where(b == 100, new_bin_pen, 0.0)

    # Mild bonus for already-used bins.
    score += np.where(b < 100, 0.25, 0.0)

    # Rotating tie-break.
    _State.call += 1
    n = b.shape[0]
    idx = np.arange(n, dtype=np.float64)
    rotate = float((_State.call * 2654435761) % 1000) * 0.002
    score += ((idx + rotate) % 7.0) * 1e-3

    return score
# EVOLVE-BLOCK-END
