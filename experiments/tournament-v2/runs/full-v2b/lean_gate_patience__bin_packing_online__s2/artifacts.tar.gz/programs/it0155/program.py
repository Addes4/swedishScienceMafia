# EVOLVE-BLOCK-START
"""Best-fit with a busy-bin bonus and empty-bin reservation for small items."""
import numpy as np


_state = {
    "n_seen": 0,
    "sum_size": 0.0,
}


def priority(item, bins):
    st = _state
    st["n_seen"] += 1
    st["sum_size"] += item

    residual = bins - item  # remaining capacity after placing the item (>= 0)
    res_f = residual.astype(np.float64)

    # Primary term: pure best fit (prefer smallest residual).
    tight = -res_f

    # Busy-bin bonus: proportional to how full the bin is after placement.
    # Reward using already-opened bins (small residual relative to capacity).
    busy = 0.01 * (100.0 - res_f) / 100.0

    # Empty-bin reservation: mildly discourage opening brand-new bins (residual==100)
    # when the incoming item is small, keeping empty bins free for large items.
    is_empty = (res_f == 100.0)
    small = 1.0 if item <= 40 else 0.0
    reserve = -0.5 * small * is_empty.astype(np.float64)

    # Deterministic tie-break (no counter needed).
    n = bins.shape[0]
    offset = 1e-6 * np.arange(n, dtype=np.float64)

    return tight + busy + reserve + offset
# EVOLVE-BLOCK-END
