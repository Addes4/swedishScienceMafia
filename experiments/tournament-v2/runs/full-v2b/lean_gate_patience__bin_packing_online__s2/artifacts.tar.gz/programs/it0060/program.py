# EVOLVE-BLOCK-START
"""Best fit with adaptive randomized tie-breaking and a new-bin penalty."""
import numpy as np


_counter = 0


def priority(item, bins):
    """Score every fitting bin; item goes to the highest-scoring bin.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (unused bins have 100), in bin order.
    """
    global _counter
    _counter += 1

    residual = bins - item  # remaining capacity after placing the item; lower is tighter fit

    # Base score: tighter fits get higher scores.
    score = -residual.astype(np.float64)

    # Stateful pseudo-random tie-break: perturb by a small cycling value based on
    # bin index and a counter, so equal-tightness bins rotate instead of locking
    # onto the lowest index every time.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    perturb = np.sin((idx + 1.0) * (_counter * 0.61803398875 + 0.1237))
    score += perturb * 0.01

    # Mild penalty for opening brand-new bins (residual exactly 100 after placing),
    # to reduce unnecessary bin openings; small enough not to override tightness.
    score -= (residual == 100).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
