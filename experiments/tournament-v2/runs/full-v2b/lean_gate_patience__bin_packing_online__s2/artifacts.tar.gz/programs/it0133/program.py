# EVOLVE-BLOCK-START
"""Best fit with usage-aware new-bin aversion.

Each arriving item is ranked primarily by the smallest resulting residual
(classic best fit).  Ties and near-ties are broken by preferring bins that are
already in use: an empty bin (remaining capacity 100) carries a penalty that
grows with the item size, so small items are happy to open new bins while
large items strongly prefer squeezing into an existing gap.  A tiny rotating
offset spreads equally-good choices over bin indices and avoids systematically
favoring the earliest bin.
"""
import numpy as np

_state = {"n": 0}

_CAP = 100.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["n"] += 1
    n = _state["n"]

    b = bins.astype(np.float64)
    residual = b - item                      # >= 0 by contract

    # Primary: best fit — smaller residual is better.
    score = -residual

    # Usage bonus: prefer bins that are already partially filled.  usage in [0,1).
    usage = (b - residual) / _CAP            # filled amount / capacity
    score += 0.05 * usage

    # New-bin penalty, proportional to how much of the new bin the item consumes.
    is_new = b >= _CAP
    score -= np.where(is_new, 0.03 * item, 0.0)

    # Rotating tie-break (tiny) to avoid fixed index bias.
    m = b.shape[0]
    idx = np.arange(m, dtype=np.float64)
    score -= ((idx + n) % m) / m * 1e-6

    return score
# EVOLVE-BLOCK-END

