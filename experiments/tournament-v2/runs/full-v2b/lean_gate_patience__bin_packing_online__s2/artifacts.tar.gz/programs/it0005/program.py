# EVOLVE-BLOCK-START
"""Hybrid: harmonic-like size-class aware packing on top of best fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit baseline: tighter fits (smaller leftover) score higher.
    leftover = bins - item

    # Size-class tuning: for mid/large items we prefer leaving a leftover that
    # can still hold another item of a similar class, otherwise pack tightly.
    score = -leftover.astype(np.float64)

    if item >= 51:
        # Large items: few fit alongside; strongly prefer tight packing.
        pass
    elif item >= 34:
        # Prefer leftovers just below 2*item (a second such item won't fit) so
        # we don't waste a bin that could take two smaller ones; approximate by
        # mildly rewarding leftover close to item (i.e., tight).
        score -= 0.05 * np.abs(leftover - item)
    elif item >= 20:
        # Mid items: reward bins that can take ~2 more of this class.
        target = 100 - (item * ((100 // item)))  # leftover after filling with this class
        score -= 0.10 * np.abs(leftover - target)
    else:
        # Small items: prefer to fill bins that already have some residue
        # matching small multiples, avoiding fresh bins.
        score -= 0.02 * leftover

    return score
# EVOLVE-BLOCK-END

