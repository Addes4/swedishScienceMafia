# EVOLVE-BLOCK-START
"""Best-fit with strict residual minimization and a tiny busy-bin tie-break."""
import numpy as np

_state = {"phase": 0}


def priority(item, bins):
    S = _state
    S["phase"] = (S["phase"] + 1) % 8
    phase = S["phase"]

    b = np.asarray(bins, dtype=np.float64)
    it = float(item)

    # Residual after placing the item (>= 0 since bins only include fitting ones).
    res = b - it

    # Dominant term: strict best-fit (smallest residual). This is near-optimal
    # for this distribution; everything else is only a tie-breaker.
    score = -res

    # Tiny deterministic perturbation to break exact ties consistently by index,
    # rotating so we don't systematically bias toward the first bin forever.
    idx = np.arange(b.shape[0])
    rot = ((idx + phase) % 8).astype(np.float64) * 1e-9
    score = score + rot

    return score
# EVOLVE-BLOCK-END
