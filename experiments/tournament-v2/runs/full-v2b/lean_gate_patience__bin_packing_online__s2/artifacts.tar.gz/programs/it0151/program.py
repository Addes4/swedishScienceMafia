# EVOLVE-BLOCK-START
"""Best-fit with an online size-histogram bonus for fillable residuals."""
import numpy as np


_state = {
    "counter": 0,
    "counts": None,      # histogram of item sizes in buckets of width 5 (20 buckets)
    "n_seen": 0,
}


def priority(item, bins):
    st = _state
    st["counter"] += 1
    ctr = st["counter"]

    # Maintain an online histogram of seen item sizes (buckets of width 5 -> 20 bins).
    if st["counts"] is None:
        st["counts"] = np.zeros(20, dtype=np.float64)
    b = item // 5
    if b >= 20:
        b = 19
    st["counts"][b] += 1.0
    st["n_seen"] += 1

    residual = bins - item  # remaining capacity after placing the item (>= 0)

    # Primary term: pure best fit (prefer smallest residual).
    tight = -residual.astype(np.float64)

    # Secondary: reward residuals that can accommodate a commonly-seen future item size.
    # For each bucket, the residual "fits" bucket b if residual >= representative size.
    # Use upper edge of each bucket as representative capacity to be fillable.
    res_f = residual.astype(np.float64)
    # Matrix: shape (bins, 20) boolean whether residual >= bucket upper edge
    edges = np.arange(1, 21, dtype=np.float64) * 5.0  # 5,10,...,100
    # fillable bonus = fraction-weighted count of buckets that fit
    fits = res_f[:, None] >= edges[None, :]          # (n, 20)
    # Normalize counts into frequencies
    counts = st["counts"]
    freqs = counts / max(1.0, st["n_seen"])
    bonus = (fits * freqs[None, :]).sum(axis=1)      # higher when residual can hold common sizes

    # Bias this secondary term small so best-fit still dominates.
    secondary = 0.05 * bonus

    # Mild bonus for already-used bins (residual after placement < 100) to avoid new bins.
    used_bonus = np.where(residual < 100, 0.3, 0.0)

    # Rotating tie-break offset spreads ties across bins over time.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    offset = 1e-4 * ((idx + ctr) % n)

    return tight + secondary + used_bonus + offset
# EVOLVE-BLOCK-END

