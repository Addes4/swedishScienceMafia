# EVOLVE-BLOCK-START
"""Best-fit with a fullness pull and rotating tie-break.

The lower bound for online/bin packing correlates with the "sum of squares"
objective: minimizing the sum of squared free space across bins.  A locally
greedy approximation is to place the item where it produces the smallest
resulting residual, but also to prefer bins that are already relatively full
(which keeps the number of partially empty bins low).  We combine a strict
residual term (best fit) with a small term that rewards fuller bins, plus a
tiny rotating tie-break so equal-score bins do not always lock to index 0.
"""
import numpy as np

_state = {"tick": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score (first on ties) wins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)   # >= 0 for every bin shown

    # Best-fit term: strictly prefer the smallest residual.
    score = -residual

    # Sum-of-squares pull: penalize leaving large free space, i.e. reward fuller
    # bins.  bc = current used capacity of the bin; after placement used+item.
    # Using -(residual^2) is equivalent up to constants to rewarding fullness,
    # but we want best-fit to dominate, so scale it slightly.
    score -= 1e-3 * residual * residual

    # Stateful pseudo-random tie-break to vary which equal-score bin wins.
    _state["tick"] += 1
    n = bins.shape[0]
    if n > 1:
        phase = _state["tick"] % n
        idx = (np.arange(n) + phase) % n
        score += 1e-6 * (n - idx)

    return score
# EVOLVE-BLOCK-END
