# EVOLVE-BLOCK-START
"""Best-fit with size-scaled tightness, residual reusability tie-break, and new-bin penalty."""
import numpy as np

_state = {
    "calls": 0,
    "new_penalty": 0.0,
    "sum": 0.0,        # running sum of item sizes
    "sumsq": 0.0,      # running sum of squared item sizes
    "count": 0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["calls"] += 1
    # Update running statistics (online mean/std of item sizes).
    _state["sum"] += item
    _state["sumsq"] += item * item
    _state["count"] += 1
    c = _state["count"]
    mean = _state["sum"] / c
    var = max(_state["sumsq"] / c - mean * mean, 1.0)
    std = var ** 0.5

    n = bins.shape[0]

    residual = bins - item  # capacity left after placing the item (>= 0 for shown bins)

    # Primary term: best-fit tightness, scaled slightly by item size.
    tightness = -residual.astype(np.float64) * (0.5 + item / 200.0)

    # Reusability term: among near-equal residuals, prefer leaving a gap close to
    # a likely future item size (mean ~40). Reward small distance to the mean.
    dist = np.abs(residual.astype(np.float64) - mean)
    reusability = 0.02 * (1.0 - np.minimum(dist / (std + 1.0), 1.0))

    # Mild penalty for opening a brand-new bin.
    fresh = (bins == 100)
    new_penalty = 0.75 + 0.5 * (item / 100.0)
    penalty = -new_penalty * fresh.astype(np.float64)

    # Rotating pseudo-random tie-break over bin indices.
    idx = np.arange(n, dtype=np.float64)
    phase = (_state["calls"] * 0.6180339887498949) % 1.0
    jitter = 0.010 * np.sin((idx + phase * n) * 0.7)

    return tightness + reusability + penalty + jitter
# EVOLVE-BLOCK-END
