# EVOLVE-BLOCK-START
"""Best-fit with rotating tie-break and new-bin penalty."""
import numpy as np

_state = {"calls": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["calls"] += 1
    n = bins.shape[0]

    residual = bins - item  # capacity left after placing the item (>= 0)

    # Best-fit: prefer the smallest residual.  Use the negative residual as the
    # primary score so the tightest fitting bin wins.
    tightness = -residual.astype(np.float64)

    # Penalty for opening a fresh bin (residual would be 100 - item).
    fresh = (bins == 100)
    penalty = -1.0 * fresh.astype(np.float64)

    # Rotating tiny tie-break so exact ties don't always favor the lowest index.
    idx = np.arange(n, dtype=np.float64)
    phase = (_state["calls"] * 0.6180339887498949) % 1.0
    jitter = 0.001 * np.sin(idx + phase * n)

    return tightness + penalty + jitter
# EVOLVE-BLOCK-END
