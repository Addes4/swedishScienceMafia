# EVOLVE-BLOCK-START
"""Online bin packing: sharpened best fit with fill-quality score.

Rank bins primarily by how well the item fits (prefer resulting residual 0,
then small residuals), using a convex penalty on the residual that strongly
favors near-exact fills. A mild bonus for already-used bins discourages
opening new bins. A tiny deterministic rotating tie-break spreads ties.
"""
import numpy as np

_cnt = 0

# Precomputed convex penalty lookup for residuals 0..100.
_r = np.arange(0, 101, dtype=np.float64)
# Strong for small residual: 100/(1+resid) gives huge jump at resid=0.
_FIT = 100.0 / (1.0 + _r)

# Rotating tie-break vector (deterministic).
_TIE = np.random.default_rng(20240607).random(256).astype(np.float64)


def priority(item, bins):
    global _cnt
    _cnt += 1
    n = len(bins)

    comp = bins.astype(np.float64)
    resid = comp - item
    idx = np.clip(resid.astype(np.int64), 0, 100)

    # Dominant: convex fit quality, prefers near-exact fills strongly.
    fit = _FIT[idx]

    # Busy-bin bonus: prefer reusing already-open bins.
    used = comp < 100.0
    busy = np.where(used, 0.30, 0.0)

    # Small linear tightness tiebreaker.
    tight = -resid * 0.001

    # Rotating tie-break.
    if n <= len(_TIE):
        tie = _TIE[:n]
    else:
        tie = np.resize(_TIE, n)
    shift = (_cnt * 13) % n
    tie_rot = np.concatenate((tie[shift:], tie[:shift])) * 1e-4

    return fit + busy + tight + tie_rot
# EVOLVE-BLOCK-END
