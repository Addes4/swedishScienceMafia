# EVOLVE-BLOCK-START
"""Strict best-fit as the dominant rule, with a busy-bin tie-break that
slightly prefers the most-filled existing bin among near-ties."""
import numpy as np

_STATE = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    st = _STATE
    st["n"] += 1

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # leftover capacity (>= 0, integer)

    # dominant: best-fit tightness (prefer smallest residual)
    tight = -residual

    # tie-break: prefer the most-filled existing bin (smaller current capacity)
    busy = -0.05 * (100.0 - bins)

    # tiny deterministic rotating tie-break to break exact ties
    idx = np.arange(bins.size, dtype=np.float64)
    rot = 1e-4 * ((idx + st["n"]) % 101)

    return tight + busy + rot
# EVOLVE-BLOCK-END

