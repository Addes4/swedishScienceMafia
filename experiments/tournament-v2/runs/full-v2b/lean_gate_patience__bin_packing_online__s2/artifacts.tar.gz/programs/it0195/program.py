"""Best-fit dominant rule with online-histogram fillability tie-break."""
import numpy as np

_state = {
    "mean": 40.0,
    "count": 0,
    "hist": np.zeros(101, dtype=np.float64),   # EW histogram of item sizes
    "offset": 0,
}


def priority(item, bins):
    it = float(item)
    c = _state["count"]

    # EWMA mean item size.
    alpha = 2.0 / (c + 2.0) if c < 200 else 1.0 / 100.0
    _state["mean"] = (1.0 - alpha) * _state["mean"] + alpha * it
    _state["count"] = c + 1

    # Update online histogram with decay.
    h = _state["hist"]
    h *= (1.0 - 1.0 / 200.0)
    h[int(item)] += 1.0

    _state["offset"] = (_state["offset"] + 1) % 1000

    b = bins.astype(np.float64)
    resid = b - it                      # >= 0 leftover after placing

    # Dominant: strict best-fit (smallest residual).
    tight = -resid / 100.0

    # Fillability tie-break: reward residual values that a frequent past item
    # size can fill exactly (residual matches a likely future item).
    total = h.sum() + 1e-9
    prob = h / total
    ri = np.clip(np.round(resid).astype(np.int64), 0, 100)
    fill = prob[ri] * 0.01

    # Tiny busy-bin bonus and deterministic rotating jitter for ties.
    busy = 0.002 * (100.0 - b) / 100.0
    idx = np.arange(len(b), dtype=np.float64)
    jitter = 1e-7 * ((idx + _state["offset"]) % 7)

    return tight + fill + busy + jitter

