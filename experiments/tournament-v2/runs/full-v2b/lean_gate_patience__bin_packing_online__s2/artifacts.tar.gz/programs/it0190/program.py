# EVOLVE-BLOCK-START
"""Best-fit with a fillability nudge based on the running mean item size."""
import numpy as np

_state = {"mean": 40.0, "alpha": 0.01, "count": 0}


def priority(item, bins):
    """Rank bins primarily by best fit, nudged toward refillable residuals."""
    m = _state["mean"]
    a = _state["alpha"]
    m = (1.0 - a) * m + a * item
    _state["mean"] = m
    _state["count"] += 1

    b = bins.astype(np.float64)
    residual = b - float(item)

    # Primary: best fit (smallest residual is best). Strictly dominant.
    tightness = -residual

    # Nudge: residuals near the running mean item size leave reusable space.
    # Bounded in [0, 1], scaled so it only breaks near-ties.
    scale = max(m, 30.0)
    fillability = np.exp(-((residual - m) / scale) ** 2)

    return tightness + 0.02 * fillability
# EVOLVE-BLOCK-END
