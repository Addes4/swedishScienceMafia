# EVOLVE-BLOCK-START
"""Log-scaled residual best fit with new-bin penalty and rotating tie-break."""
import numpy as np

_counter = [0]
_GOLDEN = 0.6180339887498949


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    # Log-scaled penalty: small residuals are strongly preferred but differences
    # among large residuals are softened so a near-exact fit isn't over-valued.
    score = -np.log1p(residual)
    # Mild bonus for partially used bins (residual < 100) to avoid opening new bins.
    score += np.where(bins < 100, 0.02, 0.0)
    # Rotating pseudo-random tie-break so equally tight bins vary over time.
    _counter[0] += 1
    n = bins.shape[0]
    offset = (_counter[0] * _GOLDEN) % 1.0
    idx = np.arange(n, dtype=np.float64)
    score = score + 1e-6 * (((idx / max(n, 1)) + offset) % 1.0)
    return score
# EVOLVE-BLOCK-END
