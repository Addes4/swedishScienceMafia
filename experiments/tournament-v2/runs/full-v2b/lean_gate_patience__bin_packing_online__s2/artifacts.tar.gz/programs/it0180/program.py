"""Online bin packing with a stateful residual-fit bin-choice rule."""
import numpy as np


class _State:
    def __init__(self):
        self.ewma = 40.0      # exponentially weighted mean item size
        self.n = 0
        self.rot = 0


_S = _State()


def priority(item, bins):
    """Score each bin; highest score wins (ties to first)."""
    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]

    # Update running estimate of recent item sizes (bounded adaptation).
    _S.n += 1
    a = 2.0 / (min(_S.n, 200) + 1.0)
    _S.ewma += a * (item - _S.ewma)
    _S.rot = (_S.rot + 1) % max(n, 1)

    resid = bins - item            # capacity left after placing the item here

    # Dominant term: best-fit tightness (prefer smallest non-negative residual).
    tight = -resid

    m = _S.ewma
    sig = 0.30 * m + 1e-9

    # Reward residuals that a single future item can fill tightly.
    d1 = np.abs(resid - m)
    fill1 = np.exp(-(d1 * d1) / (2.0 * sig * sig))

    # Reward residuals that leave a small leftover after a typical item:
    # i.e. residual just above a typical size, so a future item nearly fills it.
    d2 = np.abs(resid - 2.0 * m)
    fill2 = np.exp(-(d2 * d2) / (2.0 * sig * sig))

    # Mild busy-bin bonus to prefer filling existing bins over opening new ones.
    busy = (bins < 100.0).astype(np.float64)

    # Penalize very small unusable leftovers lightly.
    tiny = ((resid > 0) & (resid < 0.5 * item)).astype(np.float64)

    score = 1.0 * tight + 5.0 * fill1 + 2.0 * fill2 + 2.0 * busy - 1.5 * tiny

    # Tiny rotating jitter to break exact ties consistently over time.
    idx = np.arange(n)
    score += 1e-4 * ((idx + _S.rot) % max(n, 1))

    return score
