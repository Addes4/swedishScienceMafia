# EVOLVE-BLOCK-START
"""Residual-desirability best fit with a recent-size estimate and rotating tie-break."""
import numpy as np


# State kept between calls (module-level since the harness calls priority repeatedly).
_state = {
    "counter": 0,
    "mean_item": 40.0,      # exponentially-weighted mean of seen items
    "alpha": 0.02,          # weight for updating the running mean
}


def priority(item, bins):
    """Rank bins by best-fit tightness plus a mild bonus for residuals near a typical item size."""
    st = _state
    st["counter"] += 1
    ctr = st["counter"]

    # Update the running item-size estimate (cheap, stateful).
    st["mean_item"] += st["alpha"] * (item - st["mean_item"])
    typical = st["mean_item"]
    if typical < 1.0:
        typical = 1.0
    elif typical > 100.0:
        typical = 100.0

    residual = bins - item  # remaining capacity after placing the item (>= 0 by construction)

    # Primary term: prefer small residuals (best fit), smooth and monotone.
    tight = -residual.astype(np.float64)

    # Secondary term: small bonus when the leftover space looks like a future item size,
    # so the bin can be closed tightly later.  Gaussian-ish bump around `typical`.
    diff = residual.astype(np.float64) - typical
    bump = -0.01 * (diff * diff)

    # Mild bonus for already-used bins (residual after placement < 100) to avoid new bins.
    used_bonus = np.where(residual < 100, 0.5, 0.0)

    # Rotating tie-break offset spreads ties across bins over time.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    offset = 1e-4 * ((idx + ctr) % n)

    return tight + bump + used_bonus + offset
# EVOLVE-BLOCK-END
