# EVOLVE-BLOCK-START
"""Online bin packing via residual-desirability scoring using an online
histogram of item sizes to estimate how fillable each residual is.

For each candidate bin we look at the residual it would leave. A residual is
"desirable" if it is small (tight best-fit) and if it matches a size that we
see often (so it is likely to be filled later). Already-used bins get a mild
bonus to discourage opening new bins.
"""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        # histogram over sizes 1..100 of past items
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0


_S = _State()


def priority(item, bins):
    """Return priorities for each bin; highest score wins, ties to first bin."""
    _S.tick += 1

    remaining = bins.astype(np.float64)
    residual = remaining - float(item)

    # --- tightness (best-fit): strongly reward small residuals ---
    tight = -np.log1p(residual)

    # --- fillability of the residual by future items ---
    # Probability that a future item can exactly fill this residual, estimated
    # from the running histogram (smoothed).  Residuals of size r>0 are good if
    # r is a commonly-seen size.
    r_int = np.clip(np.round(residual).astype(np.int64), 0, 100)
    if _S.count > 0.0:
        p = (_S.hist + 0.5) / (_S.count + 50.0 + 100.0 * 0.5)
        fillable = p[r_int]
    else:
        fillable = np.zeros_like(residual)
    fill_bonus = 1.5 * fillable

    # residual == 0 (exact fit) is ideal
    exact = np.where(residual == 0.0, 0.5, 0.0)

    # --- busy-bin bonus: prefer already-used bins ---
    used = (remaining < 100.0).astype(np.float64)
    fullness = (100.0 - remaining) / 100.0
    busy_bonus = used * (0.15 + 0.35 * fullness)

    # --- penalize awkward tiny gaps that are hard to fill ---
    awkward = np.where((residual > 0.0) & (residual <= 2.0), 0.05 * residual, 0.0)

    # --- stateful rotating tie-break ---
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    phase = (_S.tick * 0.6180339887498949) % 1.0
    tiebreak = 1e-3 * ((idx * 0.7548776662466927 + phase) % 1.0)

    # update histogram AFTER scoring (state uses only past items)
    _S.hist[item] += 1.0
    _S.count += 1.0

    return tight + fill_bonus + exact + busy_bonus - awkward + tiebreak
# EVOLVE-BLOCK-END
