# EVOLVE-BLOCK-START
"""Hybrid bin-choice: tight-fit with reusable-leftover bonus and rotating tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        self.total = 0.0
        self.count = 0

    def mean(self):
        return self.total / self.count if self.count else 40.0


_state = _State()


def priority(item, bins):
    """Score each bin: prefer tight fits, reward reusable leftovers, rotate ties."""
    _state.tick += 1
    _state.total += item
    _state.count += 1

    residual = bins - item  # nonnegative

    # Primary: prefer tight fits (small residual). Linear is monotone and robust.
    tight = -residual.astype(np.float64)

    # Secondary: reward a leftover close to the typical item size (reusable bin).
    mu = _state.mean()
    reuse = -0.05 * np.abs(residual.astype(np.float64) - mu)

    # Minor penalty for opening a brand-new bin (was empty).
    is_new = (residual == (100 - item))
    new_pen = np.where(is_new, -0.1, 0.0)

    # Rotating tie-break.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    wobble = 1e-3 * ((idx + _state.tick * 0.6180339887) % 1.0)

    return tight + reuse + new_pen + wobble
# EVOLVE-BLOCK-END
