# EVOLVE-BLOCK-START
"""Hybrid best-fit / balanced-residual bin packing with randomized tie-breaking."""
import numpy as np

_state = {"c": 0}


def priority(item, bins):
    """Score bins by a hybrid residual rule with a tiny cycling tie-break."""
    _state["c"] = (_state["c"] + 1) & 0xFFFF
    n = len(bins)
    residual = bins - item  # residual capacity after placing the item

    # Base preference: tightest fit -> negative residual
    base = -residual.astype(np.float64)

    # For medium items, add a mild preference for residuals near 100*(1 - item/100)
    # i.e. avoid leaving either a huge or a tiny gap in a used bin.
    if 25 < item < 45:
        target = 0.5 * (100.0 - item)
        # Penalize deviation from target only among used bins (residual < 100 - item is impossible)
        dev = np.abs(residual.astype(np.float64) - target)
        base = base - 0.15 * dev

    # Tiny pseudo-random tie-breaker varying per call and per bin
    idx = np.arange(n, dtype=np.float64)
    h = np.mod(idx * 2654435761.0 + _state["c"] * 40503.0, 2.0 ** 31)
    return base + h * (1.0 / (2.0 ** 40))
# EVOLVE-BLOCK-END
