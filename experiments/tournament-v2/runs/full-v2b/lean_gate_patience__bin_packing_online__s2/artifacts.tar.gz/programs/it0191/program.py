# EVOLVE-BLOCK-START
"""Best-fit with a stateful low-residual penalty to avoid stranding space."""
import numpy as np

_state = {"mean": 40.0, "alpha": 0.02}


def priority(item, bins):
    """Best-fit primary, tiny penalty for residual below the recent item scale."""
    m = _state["mean"]
    _state["mean"] = (1.0 - m) * 0.0 + (1.0 - _state["alpha"]) * m + _state["alpha"] * item
    m = _state["mean"]

    b = bins.astype(np.float64)
    residual = b - float(item)

    # Primary: best fit (smaller residual better).
    tightness = -residual

    # Penalize residuals that are positive but smaller than a typical future item,
    # since that space is likely to be wasted. Smooth, bounded penalty.
    small = np.maximum(0.0, m * 0.5 - residual)
    waste = small / max(m, 1.0)

    return tightness - 0.4 * waste
# EVOLVE-BLOCK-END
