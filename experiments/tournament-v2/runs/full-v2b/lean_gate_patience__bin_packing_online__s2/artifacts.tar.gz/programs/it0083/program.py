# EVOLVE-BLOCK-START
"""Best-fit with reusable-gap bonus and rotating tie-break.

Prefers the bin leaving the smallest residual (classic best fit), but nudges
the score upward when the leftover residual equals a frequently observed item
size, so the remaining gap stays reusable.  A small penalty discourages
opening brand-new bins and a rotating tie-break varies equal-score choices.
"""
import numpy as np

_state = {"tick": 0, "counts": np.zeros(101, dtype=np.float64), "total": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    residual = bins - item                      # >= 0 for every bin shown

    # Update empirical item-size statistics (decayed counts).
    counts = _state["counts"]
    counts *= 0.999
    counts[int(item)] += 1.0
    _state["total"] += 1.0

    # Reusable-gap bonus: residuals that equal a frequent item size leave a gap
    # likely to be filled later.
    freq = counts[residual] / (counts.sum() + 1e-9)

    # Base score: strongly prefer tightest fit.
    score = -residual.astype(np.float64)

    # Bonus for leaving a reusable residual (matching a common item size).
    score += 1.5 * freq

    # Small penalty for opening a brand-new bin (unused bins have capacity 100).
    score -= 0.5 * (bins >= 100)

    # Stateful pseudo-random tie-break: rotate which equal-score bin wins.
    _state["tick"] += 1
    n = bins.shape[0]
    if n > 1:
        phase = _state["tick"] % n
        idx = (np.arange(n) + phase) % n
        score += 1e-6 * (n - idx)

    return score
# EVOLVE-BLOCK-END
