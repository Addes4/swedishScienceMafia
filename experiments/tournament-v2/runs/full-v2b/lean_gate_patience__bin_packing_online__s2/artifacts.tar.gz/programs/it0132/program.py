# EVOLVE-BLOCK-START
"""Residual-ratio best fit with a stateful rotating tie-break.

Idea: prefer the bin whose residual after placing the item is smallest relative to
the bin's remaining capacity before placement (a normalized tightness). This
naturally turns into best fit for nearly-empty bins but distinguishes among
partially-used bins in a way that avoids fragmenting medium residuals. A tiny
rotating offset breaks ties differently over time so no single bin index is
systematically favored.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["n"] += 1
    n = _state["n"]

    residual = bins - item                       # >= 0 by contract
    # Normalized tightness: small residual relative to bin's pre-fit remaining cap.
    # Add 1 to avoid division by zero for a bin with remaining == item? residual==0 handled.
    denom = bins.astype(np.float64)
    denom = np.where(denom <= 0, 1.0, denom)
    tightness = residual.astype(np.float64) / denom

    # Mild penalty for opening brand-new bins (remaining cap 100 and residual high).
    is_new = (bins == 100) & (residual > 0)
    new_penalty = np.where(is_new, 0.02, 0.0)

    # Rotating tie-break: deterministic, small, bin-index dependent, changing with n.
    m = bins.shape[0]
    idx = np.arange(m, dtype=np.float64)
    rotate = ((idx + n) % m) / m * 1e-6

    score = -tightness - new_penalty - rotate
    return score
# EVOLVE-BLOCK-END
