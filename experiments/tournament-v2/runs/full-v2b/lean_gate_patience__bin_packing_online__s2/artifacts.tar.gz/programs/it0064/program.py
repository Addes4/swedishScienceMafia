# EVOLVE-BLOCK-START
"""Best fit with a small bonus for leaving a likely-reusable residual gap."""
import numpy as np


# Approximate probability weights for item sizes around the Weibull(mean ~40)
# distribution used by the harness. Smooth, broad support so bins whose leftover
# gap matches a common future item are mildly favored over awkward gaps.
_GOOD_SIZES = np.array(
    [10, 20, 30, 40, 50, 60, 70, 80], dtype=np.float64
)
_GOOD_W = np.array(
    [0.5, 0.8, 1.0, 1.0, 0.8, 0.5, 0.3, 0.15], dtype=np.float64
)


def priority(item, bins):
    """Score every fitting bin; item goes to the highest-scoring bin.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (unused bins have 100), in bin order.
    """
    residual = bins - item  # leftover capacity after placing the item; lower is tighter fit

    # Primary: tighter fit scores higher.
    score = -residual.astype(np.float64)

    # Secondary: small bonus when the leftover residual is a size that a future
    # item is likely to match (keeping the gap reusable rather than stranded).
    bonus = np.zeros_like(score)
    for s, w in zip(_GOOD_SIZES, _GOOD_W):
        bonus = np.maximum(bonus, w * np.exp(-((residual - s) ** 2) / (2.0 * 12.0 ** 2)))
    score += bonus * 0.2

    # Mild penalty for opening brand-new bins (residual exactly 100).
    score -= (residual == 100).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
