"""Best-fit with histogram-matched tie-break on complementarity."""
import numpy as np

_state = {
    "count": 0,
    "hist": np.zeros(101, dtype=np.float64),
    "offset": 0,
}


def priority(item, bins):
    it = float(item)
    c = _state["count"]

    h = _state["hist"]
    h *= (1.0 - 1.0 / 300.0)
    h[int(item)] += 1.0
    _state["count"] = c + 1
    _state["offset"] = (_state["offset"] + 1) % 97

    b = bins.astype(np.float64)
    resid = b - it                       # leftover after placing

    # Dominant term: strict best-fit (smallest residual).
    tight = -resid

    # Tie-break: reward residuals that match a frequent past item size exactly
    # (so the leftover chunk can be consumed by a likely future item).
    total = h.sum() + 1e-9
    prob = h / total
    ri = np.clip(np.round(resid).astype(np.int64), 0, 100)
    fill = prob[ri]

    idx = np.arange(len(b), dtype=np.float64)
    jitter = 1e-9 * ((idx + _state["offset"]) % 13)

    return tight + fill + jitter
