# EVOLVE-BLOCK-START
"""Stateful best-fit with size-scaled new-bin penalty.

Score bins by tightness of fit (small residual after placing), subtract a
size-scaled penalty for opening a brand-new bin, and keep a lightweight
rotating pseudo-random tie-break so equal-quality bins don't lock onto low
indices.
"""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        rng = np.random.default_rng(123456789)
        self.noise = rng.random(65536)


_STATE = _State()


def priority(item, bins):
    _STATE.tick += 1
    n = bins.shape[0]

    residual = bins - item  # >= 0

    score = -residual.astype(np.float64)

    # Penalize opening a brand-new bin. Larger items fill new bins efficiently,
    # so penalize them less; small items should reuse existing bins.
    is_new = (bins == 100)
    new_penalty = 0.05 * (100.0 - item)
    score -= is_new.astype(np.float64) * new_penalty

    tick = _STATE.tick
    idx = (np.arange(n) + tick) & 0xFFFF
    score += _STATE.noise[idx] * 1e-4

    return score
# EVOLVE-BLOCK-END
