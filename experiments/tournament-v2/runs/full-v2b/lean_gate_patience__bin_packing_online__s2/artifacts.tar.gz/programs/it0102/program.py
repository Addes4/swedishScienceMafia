"""Best-fit on residual ratio, with residual-matching against recent item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.counter = 0
        # recent item-size histogram (sizes 1..100), decays over time
        self.seen = np.zeros(101, dtype=np.float64)


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    state = _state
    state.counter += 1

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # >= 0 for all shown bins

    # Decay the recent-size histogram, then record this item.
    seen = state.seen
    seen *= 0.999
    seen[item] += 1.0

    # Primary: best-fit via log-scaled tightness (small residual preferred strongly).
    scale = 1.0 + item
    fit = -np.log1p(residual / scale)

    # Secondary: reward a residual that matches a recently-seen item size,
    # so the leftover space is likely to be filled exactly later.
    res_int = residual.astype(np.int64)
    res_int = np.clip(res_int, 0, 100)
    match = seen[res_int] * 0.01

    # Mild bonus for already-partially-used bins over brand-new ones.
    partial_bonus = np.where(bins < 100, 0.02, 0.0)

    return fit + match + partial_bonus
