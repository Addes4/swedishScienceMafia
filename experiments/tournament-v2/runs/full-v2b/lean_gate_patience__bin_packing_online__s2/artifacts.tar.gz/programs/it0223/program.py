# EVOLVE-BLOCK-START
"""Residual-desirability bin packing with an empirical subset-sum fillability estimate."""
import numpy as np

_state = {
    "mean": 40.0,
    "hist": np.ones(101, dtype=np.float64),   # width-1 empirical size histogram
    "cache_key": None,
    "fill_prob": None,
}


def _fill_probability(hist):
    """Estimate, for each residual r in 0..100, the weighted probability that r
    can be exactly filled by 1..3 future items, using the empirical item-size
    histogram. Returns a normalized array indexed by residual 0..100."""
    counts = hist[1:101].astype(np.float64).copy()
    total = counts.sum()
    if total <= 0:
        counts = np.ones(100, dtype=np.float64)
        total = counts.sum()
    single = counts / total

    conv2 = np.convolve(single, single)
    conv3 = np.convolve(conv2, single)

    fp = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        v = single[r - 1]                          # 1 item
        if r >= 2 and r <= len(conv2):
            v += 1.0 * conv2[r - 1]                # 2 items
        if r >= 3 and r <= len(conv3):
            v += 0.5 * conv3[r - 1]                # 3 items
        fp[r] = v
    m = fp.max()
    if m > 0:
        fp /= m
    return fp


def priority(item, bins):
    S = _state
    it = float(item)

    S["mean"] = 0.98 * S["mean"] + 0.02 * it
    mu = S["mean"]

    S["hist"] *= 0.995
    S["hist"][int(it)] += 1.0

    b = np.asarray(bins, dtype=np.float64)
    res = b - it

    # Dominant sharp best-fit.
    tight = np.exp(-res * 1.5)

    # Empirical subset-sum fillability of the residual.
    key = int(mu * 4.0)
    if S["cache_key"] != key or S["fill_prob"] is None:
        S["fill_prob"] = _fill_probability(S["hist"])
        S["cache_key"] = key
    ri = np.clip(np.round(res).astype(np.int64), 0, 100)
    fill = S["fill_prob"][ri]

    score = 12.0 * tight + 1.2 * fill
    return score
# EVOLVE-BLOCK-END
