"""Stateful hybrid: nonlinear tightness + busy-bin bonus + rotating tie-break."""
import numpy as np

_state = {"k": 0}
_PHI = 0.6180339887498949


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["k"] += 1
    k = _state["k"]

    residual = bins - item  # >= 0 for fitting bins

    # Nonlinear tightness: strongly prefer small residuals, but not brittle.
    # Use a smooth decreasing function of residual; scaled so differences are meaningful.
    tight = -np.log1p(residual)

    # Mild bonus for already-used bins (residual < 100) to discourage opening new bins.
    used_bonus = np.where(residual < item, 0.0, 0.0)
    full_mask = (bins == 100)
    busy_bonus = np.where(full_mask, 0.0, 0.25)

    # Rotating pseudo-random tie-break: deterministic per (k, bin index) via golden ratio.
    n = bins.shape[0]
    idx = np.arange(n)
    # use bin's current remaining capacity to identify the bin's identity robustly
    rot = np.sin((idx + k) * _PHI * 6.283185307179586) * 0.3

    return tight + busy_bonus + rot
