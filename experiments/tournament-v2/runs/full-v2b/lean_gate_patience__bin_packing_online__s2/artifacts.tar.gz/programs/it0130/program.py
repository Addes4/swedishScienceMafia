"""Best-fit with a stateful residual-quality bonus: prefer leaving a gap that future items can fill."""
import numpy as np

_state = {"hist": np.zeros(101), "k": 0}
_DECAY = 0.99995


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties go to the earliest bin."""
    hist = _state["hist"]
    _state["k"] += 1

    residual = bins - item  # >= 0 for fitting bins

    # Very slow exponential decay: accumulates a stable estimate of the item-size
    # distribution over the whole stream instead of a noisy recent window.
    hist *= _DECAY

    # Tightness: prefer small residuals. Best-fit is the dominant signal.
    w = 1.0 + item * 0.01
    score = -residual * w

    # Bonus for residuals that are common item sizes in the past: a leftover gap
    # matching a frequent size is likely to be filled by a future item.
    # Normalize by total history mass so the bonus reflects a fill probability.
    gap = np.clip(residual, 0, 100).astype(np.int64)
    total = hist.sum() + 1e-9
    gap_quality = hist[gap] / total
    score += gap_quality * 120.0

    # Strong reward for a perfect fit (residual 0).
    score += (residual == 0) * 2.0

    # Penalize opening a brand-new bin (residual would still be 100-item).
    score -= (bins == 100) * (0.1 + item * 0.02)

    # Record this item's size into the histogram for future calls.
    hist[item] += 1.0

    return score
