# EVOLVE-BLOCK-START
"""Sharp best-fit with a new-bin penalty and rotating tie-break.

Score bins so that the tightest fitting bin (smallest residual capacity) wins.
A small extra penalty is applied to completely unused bins to discourage
opening new bins when an existing one is nearly as tight. A tiny stateful
rotation breaks exact ties so equally tight bins vary across calls.
"""
import numpy as np

_state = {"tick": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    residual = bins - item                      # >= 0 for every bin shown

    # Sharp best-fit: strongly prefer the smallest leftover capacity.
    score = -residual.astype(np.float64)

    # Penalty for opening a brand-new (unused) bin.
    score -= 0.5 * (bins >= 100)

    # Stateful pseudo-random tie-break for exact ties.
    _state["tick"] += 1
    n = bins.shape[0]
    if n > 1:
        phase = _state["tick"] % n
        idx = (np.arange(n) + phase) % n
        score += 1e-6 * (n - idx)

    return score
# EVOLVE-BLOCK-END
