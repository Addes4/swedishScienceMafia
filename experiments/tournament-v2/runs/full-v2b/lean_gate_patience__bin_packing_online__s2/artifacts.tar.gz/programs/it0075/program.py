# EVOLVE-BLOCK-START
"""Hybrid bin-choice: worst-fit among fitting bins with rotating tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0


_state = _State()


def priority(item, bins):
    """Score each bin: prefer the emptiest fitting bin, rotate ties."""
    _state.tick += 1

    # residual = capacity left after placing item (nonnegative for fitting bins)
    residual = bins - item

    # Worst-fit: prefer largest residual (emptiest bin) to keep bins balanced.
    fit_score = residual.astype(np.float64)

    # Tiny rotating tie-break so exact ties vary across calls.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    wobble = 1e-3 * ((idx + _state.tick * 0.6180339887) % 1.0)

    return fit_score + wobble
# EVOLVE-BLOCK-END
