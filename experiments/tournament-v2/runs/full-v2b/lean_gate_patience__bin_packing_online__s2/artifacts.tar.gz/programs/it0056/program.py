# EVOLVE-BLOCK-START
"""Best-fit in a normalized waste metric with unusable-residue penalty."""
import numpy as np

_state = {"t": 0, "hist": None, "n": 0}


def priority(item, bins):
    """Score bins by minimizing waste, penalizing useless tiny residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["t"] += 1
    t = _state["t"]

    residual = bins - item  # remaining capacity after placing the item (>=0)

    # Primary: minimize residual (best fit). Normalize to a bounded range so
    # the secondary terms are comparable regardless of item size.
    score = -residual.astype(np.float64)

    # Penalize leaving a residual too small to fit a common future item.
    # Items average ~40, so residuals in (0, ~10) are mostly wasted space.
    tiny = (residual > 0) & (residual < 10)
    score -= 1.5 * tiny

    # Mild penalty for opening a brand-new empty bin.
    brand_new = (bins == 100)
    score -= 0.5 * brand_new

    # Deterministic pseudo-random tie-break so equal bins rotate.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    noise = np.sin((idx + 1.0) * (t * 0.6180339887498949)) * 1e-3
    score += noise

    return score
# EVOLVE-BLOCK-END
