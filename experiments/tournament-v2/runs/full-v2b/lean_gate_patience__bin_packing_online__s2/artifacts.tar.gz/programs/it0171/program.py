# EVOLVE-BLOCK-START
"""Best-fit with a smooth residual-viability penalty and a busy-bin bonus."""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = len(bins)
    bins_f = bins.astype(np.float64)

    # Residual remaining after placing item here
    resid = bins_f - item

    # Dominant term: best-fit tightness (prefer small residual). Normalize to ~[0,1].
    tightness = -resid / 100.0

    # Penalize leaving a residual smaller than a "typical" item (hard to fill later),
    # smoothly: penalty grows as resid drops below ~mean.
    mean_size = _MEAN
    gap_pen = np.clip((mean_size - resid) / mean_size, 0.0, 1.0)

    # Busy-bin bonus: prefer already-used bins (residual < 100) to avoid opening new bins.
    used = (bins_f < 100.0).astype(np.float64)
    busy_bonus = 0.12 * used

    # Very light rotating tie-break by bin index to spread equally-good choices.
    idx = np.arange(n, dtype=np.float64)
    tie = 1e-4 * (idx % 7.0)

    return tightness - 0.05 * gap_pen + busy_bonus + tie
# EVOLVE-BLOCK-END
