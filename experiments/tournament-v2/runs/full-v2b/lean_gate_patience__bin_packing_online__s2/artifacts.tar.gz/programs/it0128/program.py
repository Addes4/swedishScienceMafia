"""Best-fit with a size-scaled new-bin penalty and a mild gap-utility bonus."""
import numpy as np

_state = {"hist": np.zeros(101), "k": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties go to the earliest bin."""
    hist = _state["hist"]
    _state["k"] += 1

    residual = bins - item  # >= 0 for fitting bins
    res_clipped = np.clip(residual, 0, 100).astype(np.int64)

    # Core: best-fit. Prefer small residuals; scale weight with item size fraction.
    w = 1.0 + item / 100.0
    score = -residual * w

    # Mild gap-utility bonus from the running (non-decayed) item-size histogram:
    # a leftover equal to a frequently seen size is more likely to be useful later.
    total = _state["k"]
    gap_quality = hist[res_clipped] / total
    score += gap_quality * 8.0

    # Exact fit is strongly desirable.
    score += (residual == 0) * 3.0

    # Penalize opening a brand-new bin; bigger items make opening a bin costlier
    # (small items are cheap to pack into existing gaps, so push them to consolidate).
    score -= (bins == 100) * (0.05 + item * 0.03)

    # Record this item's size into the histogram for future calls.
    hist[item] += 1.0

    return score
