# EVOLVE-BLOCK-START
"""Online bin packing via stateful residual-desirability scoring.

Score each candidate bin by how desirable its resulting residual is after
placing the item:
  * strongly prefer a tight fit (small residual),
  * mildly prefer already-used bins (residual < 100) to avoid opening new bins,
  * a stateful rotating tie-break spreads equally-good choices over time.
"""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0


_S = _State()


def priority(item, bins):
    """Return priorities for each bin; highest score wins, ties to first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities (fits only, includes unused = 100).
    """
    _S.tick += 1

    remaining = bins.astype(np.float64)
    residual = remaining - float(item)

    # Best-fit tightness: strongly reward small residuals (leaving a snug gap).
    tight = -np.log1p(residual)

    # Busy-bin bonus: reward already-used bins (remaining < 100) to discourage
    # opening brand new bins, scaled by how full the bin already is.
    used = (remaining < 100.0).astype(np.float64)
    fullness = (100.0 - remaining) / 100.0
    busy_bonus = used * (0.15 + 0.35 * fullness)

    # Mild penalty for residuals that are awkwardly sized (very small nonzero
    # gaps are hard to fill), but exact fits are great.
    awkward = np.where((residual > 0.0) & (residual <= 3.0), 0.05 * residual, 0.0)

    # Stateful rotating tie-break: shift by a pseudo-random offset that varies
    # per call so ties among equally tight bins don't always favor bin 0.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    phase = (_S.tick * 0.6180339887498949) % 1.0
    tiebreak = 1e-3 * ((idx * 0.7548776662466927 + phase) % 1.0)

    return tight + busy_bonus - awkward + tiebreak
# EVOLVE-BLOCK-END
