# EVOLVE-BLOCK-START
"""Hybrid best-fit with size-scaled tightness, rotating tie-break, and new-bin penalty."""
import numpy as np

_state = {"calls": 0, "new_penalty": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["calls"] += 1
    n = bins.shape[0]

    residual = bins - item  # capacity left after placing the item (>= 0 for shown bins)

    # Tightness term: prefer small residual, but scale sensitivity with the item size.
    # Larger items should care more about a snug fit; small items are flexible.
    tightness = -residual.astype(np.float64) * (0.5 + item / 200.0)

    # Mild penalty for opening a brand-new bin (residual would be 100 - item).
    fresh = (bins == 100)
    new_penalty = 0.75 + 0.5 * (item / 100.0)
    penalty = -new_penalty * fresh.astype(np.float64)

    # Rotating pseudo-random tie-break: build a deterministic low-amplitude jitter
    # over bin indices, shifted each call so ties don't always favor low indices.
    idx = np.arange(n, dtype=np.float64)
    phase = (_state["calls"] * 0.6180339887498949) % 1.0
    jitter = 0.010 * np.sin((idx + phase * n) * 0.7)

    return tightness + penalty + jitter
# EVOLVE-BLOCK-END
