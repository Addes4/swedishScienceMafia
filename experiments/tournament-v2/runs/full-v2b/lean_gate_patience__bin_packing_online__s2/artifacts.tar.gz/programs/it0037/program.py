# EVOLVE-BLOCK-START
"""Best-fit bin choice with exact-fit bonus and new-bin penalty."""
import numpy as np

_state = {"counter": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = (bins - item).astype(np.float64)  # capacity left if placed here

    # Primary signal: best fit -> smaller residual is better.
    score = -residual

    # Bonus for exact fits (residual 0): perfectly closes a bin.
    score += 5.0 * (residual == 0.0)

    # Penalty for opening a brand-new bin.
    new_bin = (residual == (100.0 - item)).astype(np.float64)
    score -= 1.0 * new_bin

    # Tiny deterministic tie-break to vary ordering without randomness.
    n = score.shape[0]
    _state["counter"] += 1
    idx = np.arange(n, dtype=np.float64)
    perturb = ((idx * ((_state["counter"] * 2654435761) % 1000003) + _state["counter"]) % 97) * 1e-6
    score += perturb

    return score
# EVOLVE-BLOCK-END
