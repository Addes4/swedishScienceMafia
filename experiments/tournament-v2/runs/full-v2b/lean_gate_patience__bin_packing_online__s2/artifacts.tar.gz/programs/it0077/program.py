# EVOLVE-BLOCK-START
"""Hybrid bin-choice: best-fit with residual-clustering for reusable gaps."""
import numpy as np


class _State:
    def __init__(self):
        self.tick = 0


_state = _State()


def priority(item, bins):
    """Prefer tight fits; among loose fits, prefer leftovers usable by a future item."""
    _state.tick += 1

    residual = bins - item  # >= 0 for fitting bins

    # Primary: strongly prefer small residual (classic best-fit).
    primary = -residual.astype(np.float64)

    # Secondary: tiny preference for residual near 0 modulo a coarse grid, so that
    # equal-ish bins tend to leave gaps aligned with typical item sizes rather than
    # fragmented slivers. Kept very small so best-fit dominates.
    grid = 10.0
    phase = np.abs((residual.astype(np.float64) % grid) - grid / 2.0)
    secondary = -0.01 * phase

    # Deterministic index tie-break (no noise): first index wins exact ties.
    return primary + secondary
# EVOLVE-BLOCK-END
