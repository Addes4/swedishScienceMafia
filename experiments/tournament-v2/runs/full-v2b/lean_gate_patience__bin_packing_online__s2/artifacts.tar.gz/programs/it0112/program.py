# EVOLVE-BLOCK-START
"""Size-sensitive best-fit with a stateful complementary-residual preference."""
import numpy as np


class _State:
    call = 0
    counts = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Best-fit whose tightness weight grows with item size; prefer exact fits,
    reward residuals matching likely future complements, and discourage new bins
    most strongly for small items."""
    b = bins.astype(np.int64)
    it = int(item)

    # Exponentially-decayed size profile over past items.
    _State.counts *= 0.995
    _State.counts[it] += 1.0
    counts = _State.counts

    residual = b - it  # residual after placing

    # Tightness weight grows with item size: large items strongly prefer tight fits.
    w = 0.01 + 0.005 * it
    score = -w * residual.astype(np.float64)

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 100.0, 0.0)

    # Reward bins whose residual-after equals a value that is commonly seen
    # among item sizes (likely to be filled by a future item exactly).
    valid = (residual >= 0) & (residual <= 100)
    match = np.zeros(b.shape[0], dtype=np.float64)
    match[valid] = counts[residual[valid]]
    score += 0.5 * match

    # Penalize opening brand-new bins; strongest for small items (they consolidate).
    new_bin_pen = 14.0 - 0.1 * it  # larger for small items
    score -= np.where(b == 100, new_bin_pen, 0.0)

    # Mild bonus for already-used bins.
    score += np.where(b < 100, 0.25, 0.0)

    # Rotating tie-break.
    _State.call += 1
    n = b.shape[0]
    idx = np.arange(n, dtype=np.float64)
    rotate = float((_State.call * 2654435761) % 1000) * 0.002
    score += ((idx + rotate) % 7.0) * 1e-3

    return score
# EVOLVE-BLOCK-END
