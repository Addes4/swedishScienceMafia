# EVOLVE-BLOCK-START
"""Fresh approach: best-fit with a stateful rotating tie-break and a new-bin penalty."""
import numpy as np

_counter = [0]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)

    # Base score: prefer tightest fit (smallest residual after placing the item).
    residual = bins - item
    score = -residual.astype(np.float64)

    # Small penalty for opening a brand-new (empty) bin to discourage needless openings.
    is_new = bins >= 100
    if is_new.any():
        score = score - is_new.astype(np.float64) * 0.5

    # Stateful rotating tie-break: perturb equally-good bins so selection rotates
    # instead of always locking onto the lowest index.
    _counter[0] += 1
    n = bins.size
    offset = _counter[0] % n
    tie = ((np.arange(n) - offset) % n).astype(np.float64) * 1e-3
    score = score - tie

    return score
# EVOLVE-BLOCK-END
