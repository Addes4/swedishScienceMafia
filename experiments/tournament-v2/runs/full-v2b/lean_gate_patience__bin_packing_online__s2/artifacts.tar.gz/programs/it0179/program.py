"""Online bin packing: tight best-fit with fillable-residual tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.ewma = 40.0
        self.n = 0


_S = _State()


def priority(item, bins):
    """Score each bin; highest score wins (ties to first)."""
    bins = np.asarray(bins, dtype=np.float64)

    # update running estimate of recent item sizes
    _S.n += 1
    a = 2.0 / (min(_S.n, 200) + 1.0)
    _S.ewma += a * (item - _S.ewma)
    m = _S.ewma

    resid_after = bins - item  # remaining capacity after placing item here

    # Dominant term: best-fit tightness (prefer small residual after placement).
    tight = -resid_after

    # Busy-bin bonus: mild preference to fill partially used bins rather than open new.
    busy = np.where(bins < 100.0, 1.0, 0.0)

    # Tie-break: prefer residuals close to the typical item size so the bin stays fillable.
    prox = -np.abs(resid_after - m) / (m + 1e-9)

    score = 10.0 * tight + 2.0 * busy + 0.5 * prox

    return score
