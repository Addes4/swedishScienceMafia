"""Best-fit with a stochastic, slowly-decaying empty-bin penalty.

For each arriving item we compute the residual capacity each visible bin would
have after placing the item, and score bins by the negative residual (tightest
fit first).  Empty bins (remaining capacity 100) receive a penalty that keeps
existing partially-filled bins preferred, but this penalty is jittered slightly
on every call using a cheap stateful pseudo-random generator.  The jitter makes
the rule occasionally accept a slightly looser fit in an open bin or open a
fresh bin when it is a near-perfect fit, which helps escape pathological greedy
decisions without sacrificing the strong average behavior of best-fit.
"""
import numpy as np

_state = {"t": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _state["t"] += 1
    t = _state["t"]

    residual = bins - item                 # leftover if placed here
    score = -residual.astype(np.float64)   # tightest fit preferred

    # Empty bins get a penalty so we prefer using already-open bins.
    is_empty = bins == 100
    # Jitter the penalty magnitude with a cheap LCG-based pseudo-random value.
    r = (t * 1103515245 + 12345) & 0x7FFFFFFF
    jitter = (r % 1000) / 1000.0            # in [0, 1)
    penalty = 0.4 + 0.7 * jitter            # roughly in [0.4, 1.1)
    score -= penalty * is_empty

    return score
