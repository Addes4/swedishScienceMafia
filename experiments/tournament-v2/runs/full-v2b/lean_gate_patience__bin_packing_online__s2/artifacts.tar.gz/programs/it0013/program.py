"""Best-fit with mean-aligned residual preference.

For an arriving item of size s, let r = bins - item be the residual after placement.
Classic best-fit picks minimal r, which for a Weibull workload (mean ~40) tends to
seal bins before their residual lines up with a typical future item. Instead, we
pick the bin whose residual after placement is close to the mean item size (40),
but never let r exceed 100 - s (trivially true) nor fall below the minimum more than
necessary. Concretely we score each candidate bin by
    score = -|min(r, T) - T|  where T = 40,
which encourages leaving ~40 units free so a typical item can still fill it while
strongly preferring tighter fits when residual is already small (worst case = best-fit).
If the item itself is large (s >= T), we fall back to pure best-fit to avoid wasting
space that a large item needs.
"""
import numpy as np

TARGET = 40.0


def priority(item, bins):
    n = bins.shape[0]
    residual = bins - item  # how much is left if placed here

    if item >= TARGET:
        # Large item: use pure best-fit (minimize residual).
        min_res = residual.min()
        candidates = np.flatnonzero(residual == min_res)
        state = priority._state
        state = (state * 1103515245 + 12345) & 0x7FFFFFFF
        priority._state = state
        pick = candidates[state % candidates.shape[0]]
        out = np.full(n, -1.0, dtype=np.float64)
        out[pick] = 1.0
        return out

    # Small item: prefer residual close to TARGET, but cap: never worse than
    # the minimal residual by more than a small margin.
    min_res = residual.min()
    # Penalty: distance from target, but only counting residuals above min_res
    # is disallowed past a margin. Distance below the target is penalized more
    # steeply so we still prefer tight fits when they are already small.
    diff = residual - TARGET
    # asymmetric penalty: overshooting target is cheap, undershooting is expensive
    pen = np.where(diff >= 0, diff, -2.0 * diff)
    # Add a small bias toward the tightest fit so pure best-fit wins in ties.
    pen = pen - 0.01 * (residual - min_res)

    best = pen.min()
    candidates = np.flatnonzero(pen == best)
    state = priority._state
    state = (state * 1103515245 + 12345) & 0x7FFFFFFF
    priority._state = state
    pick = candidates[state % candidates.shape[0]]

    out = np.full(n, -1.0, dtype=np.float64)
    out[pick] = 1.0
    return out


priority._state = 123456789
