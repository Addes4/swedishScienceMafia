# EVOLVE-BLOCK-START
"""Residual-desirability bin packing with an exact-fill bonus."""
import numpy as np

_state = {
    "mean": 40.0,
    "hist": np.ones(101, dtype=np.float64),   # width-1 buckets, index 0..100
    "total": 0.0,
}


def priority(item, bins):
    S = _state
    it = float(item)
    iit = int(it)

    S["mean"] = 0.98 * S["mean"] + 0.02 * it
    mu = S["mean"]

    # Fine-grained histogram of item sizes (width 1, index 0..100).
    incr = 1.0
    S["hist"] *= 0.992
    S["hist"][iit] += incr
    S["total"] = S["total"] * 0.992 + incr
    hist = S["hist"]
    hmax = hist.max() + 1e-9

    b = np.asarray(bins, dtype=np.float64)
    res = b - it
    ri = np.clip(res.astype(np.int64), 0, 100)

    # Dominant best-fit tightness: sharply prefer the smallest nonnegative residual.
    tight = 1.0 / (1.0 + res ** 3.0)

    # Exact-fill bonus: residual exactly matching a common recent item size.
    exact = hist[ri] / hmax

    # Fillability: residual close to a small multiple of the typical item size.
    k = np.maximum(1.0, np.round(res / max(mu, 1.0)))
    fill = 1.0 / (1.0 + (res - k * mu) ** 2 / (mu + 1.0))

    score = 8.0 * tight + 0.6 * exact + 0.12 * fill
    return score
# EVOLVE-BLOCK-END
