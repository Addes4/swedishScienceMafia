"""Direct best-fit with exact-fit reward and graded new-bin penalty."""
import numpy as np


class _State:
    def __init__(self):
        self.counter = 0
        self.rng = np.random.default_rng(98765)
        self.noise = self.rng.random(1 << 16)


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    state = _state
    state.counter += 1

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # >= 0 for all shown bins

    # Primary: prefer the tightest fit (smallest residual).
    score = -residual

    # Reward exact fits so leftover space can be reused perfectly.
    score += np.where(residual == 0.0, 0.5, 0.0)

    # Discourage opening brand-new bins; stronger for small items where
    # existing bins are plentiful. Fresh bin has bins == 100.
    new_bin_penalty = 0.01 * (101 - item)
    score -= np.where(bins >= 100.0, new_bin_penalty, 0.0)

    # Rotating pseudo-random tie-break for equally tight fits.
    n = bins.shape[0]
    idx = (np.arange(n) + state.counter) & 0xFFFF
    score += state.noise[idx] * 1e-4

    return score

