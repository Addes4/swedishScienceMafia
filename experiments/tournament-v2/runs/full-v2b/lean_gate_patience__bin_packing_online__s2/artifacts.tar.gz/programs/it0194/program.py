"""Residual-desirability rule with smooth tightness, fillability bonus, busy-bin bonus, and rotating tie-break."""
import numpy as np

_state = {
    "offset": 0,
    "mean": 40.0,
    "count": 0,
}


def priority(item, bins):
    # Update EWMA of item sizes (stateful estimate).
    c = _state["count"]
    alpha = 2.0 / (c + 2.0) if c < 200 else 1.0 / 100.0
    _state["mean"] = (1.0 - alpha) * _state["mean"] + alpha * float(item)
    _state["count"] = c + 1
    _state["offset"] = (_state["offset"] + 1) % 1000

    b = bins.astype(np.float64)
    resid = b - float(item)          # leftover after placing (>= 0)
    mean = _state["mean"]
    full_cap = 100.0

    # 1. Tightness: prefer minimal residual (best fit). Smooth, scaled to [0,1]-ish.
    tight = -resid / full_cap

    # 2. Fillability bonus: residuals that are hard to fill get penalized.
    #    Tiny residuals below the item size are bad (can't fit another item).
    #    Residuals near the mean item size are mediocre (likely to leave slivers).
    small_pen = np.tanh((float(item) - resid) / 10.0)  # positive when resid < item
    near_mean_pen = np.exp(-((resid - mean) ** 2) / (2.0 * (mean * 0.5 + 1.0) ** 2))
    # Reward residuals that are comfortably large (easy to fill with something).
    room_bonus = np.tanh(resid / 25.0)
    fillability = 0.15 * room_bonus - 0.10 * small_pen - 0.05 * near_mean_pen

    # 3. Busy-bin bonus: mildly prefer fuller bins (avoid opening new bins).
    fullness = (full_cap - b) / full_cap
    busy = 0.02 * fullness

    # 4. Rotating stateful tie-break offset: tiny deterministic jitter by bin index.
    idx = np.arange(len(b), dtype=np.float64)
    jitter = 1e-6 * ((idx + _state["offset"]) % 7)

    return tight + fillability + busy + jitter
