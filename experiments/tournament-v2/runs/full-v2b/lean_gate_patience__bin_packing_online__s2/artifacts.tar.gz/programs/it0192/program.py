# EVOLVE-BLOCK-START
"""Best-fit with mean-residual tie-break."""
import numpy as np

_state = {"mean": 40.0, "alpha": 0.05}


def priority(item, bins):
    """Tightest fit; break ties toward residuals near the running mean item size."""
    m = _state["mean"]
    _state["mean"] = (1.0 - 0.05) * m + 0.05 * item

    b = bins.astype(np.float64)
    residual = b - float(item)

    tightness = -residual
    # Tiny tie-break: prefer residuals closer to the mean item size.
    tie = -np.abs(residual - _state["mean"]) * 1e-6
    return tightness + tie
# EVOLVE-BLOCK-END
