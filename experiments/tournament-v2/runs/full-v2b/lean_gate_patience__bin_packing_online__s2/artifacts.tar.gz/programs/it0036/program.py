# EVOLVE-BLOCK-START
"""Best-fit-with-usable-gap bin choice: minimize residual, but avoid leaving slivers."""
import numpy as np

_state = {"counter": 0}

# Smallest item we expect to see; residuals below this are likely unusable.
_MIN_ITEM = 5.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = (bins - item).astype(np.float64)  # capacity left if placed here

    # Primary: prefer the tightest fit (smallest residual) -> best-fit.
    score = -residual

    # Penalize residuals that fall into the "sliver" band [0, _MIN_ITEM):
    # such gaps are too small for most future items and waste capacity.
    sliver = np.clip(_MIN_ITEM - residual, 0.0, _MIN_ITEM) / _MIN_ITEM
    score -= 8.0 * sliver

    # Strong bonus for exact fits (residual 0): perfect packing.
    score += 12.0 * (residual == 0.0)

    # Modest penalty for opening a brand-new bin.
    new_bin = (residual == (100.0 - item)).astype(np.float64)
    score -= 2.0 * new_bin

    # Tiny cycling perturbation to vary tie-breaking order.
    n = score.shape[0]
    _state["counter"] += 1
    idx = np.arange(n, dtype=np.float64)
    perturb = ((idx * ((_state["counter"] * 2654435761) % 1000003) + _state["counter"]) % 97) * 1e-4
    score += perturb

    return score
# EVOLVE-BLOCK-END
