# EVOLVE-BLOCK-START
"""Size-aware best-fit with new-bin penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    # Strongly prefer the tightest fit (smallest residual) -> best-fit behavior.
    score = -residual
    # Penalize opening new/empty bins a bit more than other placements to consolidate.
    score -= np.where(bins >= 100, 1.5, 0.0)
    # Deterministic tie-break: prefer lower-index (older, more-filled) bins.
    n = bins.shape[0]
    score += (n - np.arange(n, dtype=np.float64)) * 1e-9
    return score
# EVOLVE-BLOCK-END
