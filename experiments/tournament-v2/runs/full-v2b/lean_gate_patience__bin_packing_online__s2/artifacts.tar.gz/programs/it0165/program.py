import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        self.count = 0
        self.size_sum = 0.0

_state = _State()


def priority(item, bins):
    s = _state
    s.tick += 1
    s.count += 1
    s.size_sum += item
    mean = s.size_sum / s.count

    residual = bins - item           # remaining capacity after placing item
    item_f = float(item)

    # Dominant term: best-fit / tightness -- fuller bin is better.
    tightness = item_f / bins

    # Penalize tiny leftover gaps that future items (mean ~ mean) cannot fill.
    # residual < mean is "wasteful"; scale penalty by how unfillable it is.
    tiny = np.clip((mean - residual) / max(mean, 1.0), 0.0, 1.0)

    # Mild busy-bin bonus: prefer reusing already-open bins over fresh ones.
    unused = (bins == 100).astype(np.float64)
    busy_bonus = 0.1 * (1.0 - unused)

    # Deterministic rotating tie-break to spread equal-score choices.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    rot = ((idx + s.tick) % n) * 1e-7

    score = 2.0 * tightness + busy_bonus - 0.3 * tiny + rot
    return score
