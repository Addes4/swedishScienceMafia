# EVOLVE-BLOCK-START
"""Best-fit with reusable-residual preference and size-scaled new-bin penalty."""
import numpy as np

# --- module-level state ---------------------------------------------------
_hist = np.zeros(101, dtype=np.float64)   # smoothed frequency of item sizes seen
_forgetting = 0.99
_recent = np.zeros(101, dtype=np.float64)  # short-term memory of item sizes


def _update_state(item):
    """Decay and record the arriving item's size."""
    _hist *= _forgetting
    _hist[item] += 1.0
    _recent *= 0.90
    _recent[item] += 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    bins = np.asarray(bins)
    _update_state(item)

    residual = bins - item                       # >= 0 for bins the item fits in
    score = -residual.astype(np.float64)         # base: tightest fit first

    is_new = bins >= 100
    any_new = is_new.any()
    non_new = ~is_new
    has_old = non_new.any()

    if has_old:
        # Best tightness achievable among already-used bins.
        old_res = residual[non_new]
        best_old = int(old_res.min())

        # Reward residuals that correspond to a size likely to arrive again.
        # Use long-term and short-term memory, both normalized.
        total = _hist.sum()
        if total > 0:
            freq = _hist / total
            tot_r = _recent.sum()
            rec = (_recent / tot_r) if tot_r > 0 else freq
            reuse = 0.6 * freq + 0.4 * rec
        else:
            reuse = np.zeros(101, dtype=np.float64)

        # For existing bins, add a small bonus if the residual is a re-usable size.
        res_clip = np.clip(residual, 0, 100).astype(np.int64)
        bonus = reuse[res_clip] * 20.0            # scaled so it breaks near-ties
        score = score + np.where(non_new, bonus, 0.0)
    else:
        best_old = 100

    if any_new:
        # Size-scaled new-bin penalty: small items strongly prefer reuse,
        # large items may legitimately need a fresh bin.
        # Larger penalty when an existing bin already gives a tight-ish fit.
        tight_gap = max(0, best_old - 0)         # how tight the best old fit is
        # scale: penalty grows for small items and when a good fit already exists
        base = 1.0 + (100 - item) * 0.02         # ~1.0 for size100 up to ~3.0 for size1
        if has_old and best_old <= item:         # some old bin leaves a very tight fit
            base *= 1.5
        score = score - is_new.astype(np.float64) * base

    return score
# EVOLVE-BLOCK-END
