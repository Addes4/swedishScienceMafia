# EVOLVE-BLOCK-START
"""Best-fit base with a small stateful fill-probability bonus on the residual."""
import numpy as np

# Exponentially-decayed histogram of observed item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
_decay = 0.995
_seen = [0.0]


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    Base rule: classic best-fit (prefer the smallest residual after placement),
    softened by a log so near-exact fits aren't over-brittle.
    Bonus: if the leftover residual matches a size that frequently arrives,
    it is likely to be fillable later, so slightly prefer it.
    """
    residual = (bins - item).astype(np.float64)

    # Base: prefer tightest fit; log keeps large residuals from dominating.
    score = -np.log1p(residual)

    # Small deterministic penalty for opening a brand-new bin.
    score += np.where(bins < 100, 0.01, 0.0)

    # --- stateful fill-probability bonus ---
    # Update decayed histogram with the current item.
    _hist *= _decay
    _seen[0] = _seen[0] * _decay + 1.0
    _hist[item] += 1.0

    # Probability that some future item equals a given size (approx via histogram).
    # Normalize so probabilities are comparable across time.
    prob = _hist / max(_seen[0], 1.0)

    # For each bin, look up the fill probability of its residual size.
    res_idx = np.clip(residual.astype(np.int64), 0, 100)
    fill_bonus = prob[res_idx]

    # Reward residuals that are likely fillable; scale small so it doesn't
    # overpower the tightness ordering.
    score += 2.0 * fill_bonus

    # Extra nudge for an exact fit (residual 0): it is always "complete".
    score += np.where(residual <= 0.5, 0.05, 0.0)

    return score
# EVOLVE-BLOCK-END
