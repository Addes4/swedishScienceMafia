"""Online bin packing: stateful residual-fitness bin-choice rule."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.counts = np.zeros(101, dtype=np.float64)   # observed item-size histogram
        self.ewma = 40.0


_S = _State()


def priority(item, bins):
    """Score each bin; highest score wins (ties to first)."""
    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]

    _S.n += 1
    if item <= 100:
        _S.counts[item] += 1.0
    a = 2.0 / (min(_S.n, 200) + 1.0)
    _S.ewma += a * (item - _S.ewma)

    # fillability of a residual r: probability mass of exact hits / near hits
    total = _S.counts.sum()
    if total > 0:
        p = _S.counts / total
    else:
        p = np.zeros(101, dtype=np.float64)

    # cumulative distribution for "does an item fit in r" reasoning
    cdf = np.cumsum(p)  # cdf[k] = P(size <= k)

    resid = bins - item  # residual after placing item here (>=0 where it fits)

    # map each residual to an integer index for histogram lookup
    ri = np.clip(np.round(resid).astype(np.int64), 0, 100)

    # exact-fill probability: chance a future item exactly matches residual
    exact = p[ri]

    # near-fill: chance the residual is reduced to a small remainder
    # measure mass of items in [resid - slack, resid]
    slack = 3
    lo = np.clip(ri - slack, 0, 100)
    near = cdf[ri] - cdf[lo]  # mass that lands in a small band below residual

    # avoid leaving a tiny unusable residual (positive but smaller than typical small items)
    tiny = ((resid > 0) & (resid < 5)).astype(np.float64)

    # best-fit tightness dominant
    tight = -resid

    # busy-bin mild bonus: prefer partially used bins over opening new ones
    busy = (bins < 100.0).astype(np.float64)

    score = tight + 3.0 * exact + 0.6 * near - 2.0 * tiny + 0.5 * busy

    # capacity-aware tiny deterministic jitter to break exact ties over time
    idx = np.arange(n)
    score = score + 1e-5 * ((idx + _S.n) % max(n, 1))

    return score
