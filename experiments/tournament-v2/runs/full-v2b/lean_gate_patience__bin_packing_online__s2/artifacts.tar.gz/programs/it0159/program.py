# EVOLVE-BLOCK-START
"""Best-fit with a stateful harmonic residual-matching bonus."""
import numpy as np


# Online estimate of recently-seen item sizes, bucketed by size (1..100).
# Exponentially decayed histogram so recent sizes dominate.
_hist = np.zeros(101, dtype=np.float64)
_decay = 0.97
_total = 0.0


def priority(item, bins):
    """Prefer bins whose residual after placement matches a common item size."""
    global _hist, _total

    # Update histogram with the current item (decay then add).
    _hist *= _decay
    _total *= _decay
    _hist[item] += 1.0
    _total += 1.0

    resid = bins - item  # >= 0 where the item fits

    # Base: best-fit tightness -> prefer small residual.
    score = -resid.astype(np.float64)

    # Harmonic bonus: reward residuals that equal a commonly-seen item size,
    # scaled by how common that size is. This helps leave "fillable" gaps.
    bonus = np.zeros(bins.shape[0], dtype=np.float64)
    if _total > 0.0:
        # Probability of each size (small smoothing to avoid zeros).
        prob = (_hist + 0.01) / (_total + 1.01)
        # Residuals are in 0..100 (item >= 1 so resid <= 99 for fitting bins).
        clipped = np.clip(resid, 0, 100)
        freq = prob[clipped]  # frequency-of-item-size equal to this residual
        maxf = prob.max()
        if maxf > 0.0:
            bonus = freq / maxf  # normalized 0..1
    score = score + 3.0 * bonus

    # Tiny deterministic tie-break to spread choices among equal scores.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    score = score + (idx * 2.3283064365386963e-10)

    return score
# EVOLVE-BLOCK-END
