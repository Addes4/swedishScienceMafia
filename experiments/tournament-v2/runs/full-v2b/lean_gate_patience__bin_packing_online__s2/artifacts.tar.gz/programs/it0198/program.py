"""Best-fit with fillable-residual tie-break from online histogram."""
import numpy as np

_state = {
    "mean": 40.0,
    "count": 0,
    "hist": np.zeros(101, dtype=np.float64),
    "offset": 0,
}


def priority(item, bins):
    it = float(item)
    c = _state["count"]

    alpha = 2.0 / (c + 2.0) if c < 200 else 1.0 / 100.0
    _state["mean"] = (1.0 - alpha) * _state["mean"] + alpha * it
    _state["count"] = c + 1

    h = _state["hist"]
    h *= (1.0 - 1.0 / 200.0)
    h[int(item)] += 1.0

    _state["offset"] = (_state["offset"] + 1) % 1000

    b = bins.astype(np.float64)
    resid = b - it

    # Dominant term: strict best-fit (smallest residual wins).
    tight = -resid / 100.0

    # Fillability: reward residuals that a frequent future item size can fill exactly
    # or nearly exactly. Use cumulative histogram around the rounded residual.
    total = h.sum() + 1e-9
    prob = h / total
    ri = np.clip(np.round(resid).astype(np.int64), 0, 100)
    # Average probability mass in a small window around the residual: a residual
    # that can host a common item yields a large leftover of usable space.
    lo = np.clip(ri - 2, 0, 100)
    hi = np.clip(ri + 2, 0, 100)
    csum = np.zeros(101)
    csum[0] = prob[0]
    for k in range(1, 101):
        csum[k] = csum[k - 1] + prob[k]
    window = csum[hi] - (csum[lo - 1] if lo.any() else 0)
    window = np.where(lo > 0, csum[hi] - csum[lo - 1], csum[hi])
    fill = window * 0.005

    busy = 0.001 * (100.0 - b) / 100.0
    idx = np.arange(len(b), dtype=np.float64)
    jitter = 1e-7 * ((idx + _state["offset"]) % 7)

    return tight + fill + busy + jitter
