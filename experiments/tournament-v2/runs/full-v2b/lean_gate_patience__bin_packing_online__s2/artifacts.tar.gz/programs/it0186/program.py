# EVOLVE-BLOCK-START
"""Best-fit tightness, with near-tie breaking toward the running mean residual."""
import numpy as np


class _State:
    def __init__(self):
        self.ewma = 40.0
        self.count = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = np.asarray(bins, dtype=np.float64)
    size = float(item)

    st = _state
    st.count += 1
    alpha = 0.08
    st.ewma = (1.0 - alpha) * st.ewma + alpha * size
    mu = st.ewma if st.ewma > 1.0 else 40.0

    residual = b - size  # remaining capacity after placing the item, >= 0

    # Primary: best-fit tightness -- smaller residual is better. Strictly dominant.
    tight = -residual

    # Near-tie breaker: prefer residual closest to the running mean item size.
    fill = -np.abs(residual - mu) / (mu + 1.0)

    score = 1000.0 * tight + fill

    return score
# EVOLVE-BLOCK-END
