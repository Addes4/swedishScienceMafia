# EVOLVE-BLOCK-START
"""Capacity-weighted waste scoring with busy-bin bonus and rotating tie-break."""
import numpy as np


_call_count = 0


def priority(item, bins):
    """Score bins to minimize wasted capacity fraction; prefer using existing bins."""
    global _call_count
    _call_count += 1

    resid = bins - item  # remaining capacity after placing (>=0 always)

    # Tightness: prefer small residual relative to the bin's original capacity.
    # Original capacity can be estimated: bins are 100 for unused. We use a
    # normalized residual that is smaller when the item fits snugly.
    orig = np.where(bins >= 100, 100.0, np.maximum(bins, 1.0))
    # Fraction of the bin's remaining space left after placement
    waste_frac = resid.astype(np.float64) / orig
    # Lower waste_frac is better -> negate
    score = -waste_frac

    # Mild busy-bin bonus: prefer partially-used bins to discourage opening new ones.
    # bins < 100 means already used.
    busy_bonus = np.where(bins < 100, 0.02, 0.0)
    score = score + busy_bonus

    # Rotating pseudo-random tie-break (deterministic, cheap) to spread choices.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    tie = ((idx * 2654435761.0 + _call_count * 40503.0) % 1000.0) / 1e6
    score = score + tie

    return score
# EVOLVE-BLOCK-END
