# EVOLVE-BLOCK-START
"""Best fit with distribution-aware residual usefulness and new-bin penalty."""
import numpy as np


def priority(item, bins):
    """Score every fitting bin; item goes to the highest-scoring bin.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (unused bins have 100), in bin order.
    """
    residual = bins - item  # capacity left after placing the item

    # Base best-fit: tighter fits (smaller residual) score higher.
    score = -residual.astype(np.float64)

    # Reward bins whose leftover residual is a "usable" size that future items can
    # still fill well. We approximate the item distribution with a Gaussian
    # (mean ~40, sd ~22) and give a small bonus when residual >= ~mean-ish sizes,
    # while penalizing residuals that are too small to fit likely future items.
    r = residual.astype(np.float64)
    # Usability: higher when residual can accommodate a typical item.
    usability = 1.0 - np.exp(-r / 25.0)  # 0 when r=0, saturates for large r
    score += usability * 3.0

    # Penalize opening brand-new bins modestly to avoid unnecessary openings.
    score -= (residual == 100).astype(np.float64) * 1.0

    return score
# EVOLVE-BLOCK-END
