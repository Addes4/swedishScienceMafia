# EVOLVE-BLOCK-START
"""Size-sensitive best-fit with a learned complementary-residual preference."""
import numpy as np


class _State:
    call = 0
    counts = np.zeros(101, dtype=np.float64)   # decaying item-size profile
    resid_fill = np.zeros(101, dtype=np.float64)  # how often residual r got exactly filled


def priority(item, bins):
    """Best-fit whose tightness grows with item size, plus a learned preference
    for residuals that past items have filled exactly (complementary packing)."""
    b = bins.astype(np.int64)
    it = int(item)

    # Exponentially-decayed size profile over past items.
    _State.counts *= 0.995
    _State.counts[it] += 1.0
    counts = _State.counts

    # Decaying profile of which residuals were perfectly filled last time.
    _State.resid_fill *= 0.998
    resid_fill = _State.resid_fill

    residual = b - it  # residual after placing

    # Tightness weight: super-linear for large items (they should almost always
    # take the tightest fit), mild for small items (they consolidate flexibly).
    if it <= 50:
        w = 0.01 + 0.004 * it
    else:
        w = 0.01 + 0.004 * 50 + 0.012 * (it - 50)
    score = -w * residual.astype(np.float64)

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 140.0, 0.0)

    # Reward residuals that are commonly seen as item sizes (likely to be
    # exactly filled by a future item) AND were historically filled exactly.
    valid = (residual >= 0) & (residual <= 100)
    r = np.clip(residual, 0, 100)
    match = np.where(valid, counts[r] + 2.0 * resid_fill[r], 0.0)
    score += 0.5 * match

    # Penalize opening brand-new bins; strongest for small items.
    new_bin_pen = 14.0 - 0.1 * it
    score -= np.where(b == 100, new_bin_pen, 0.0)

    # Mild bonus for already-used bins.
    score += np.where(b < 100, 0.25, 0.0)

    # Rotating tie-break.
    _State.call += 1
    n = b.shape[0]
    idx = np.arange(n, dtype=np.float64)
    rotate = float((_State.call * 2654435761) % 1000) * 0.002
    score += ((idx + rotate) % 7.0) * 1e-3

    # Record into resid_fill for the chosen bin (the argmax bin's residual).
    # We must decide the winner to update the fill profile for next call.
    winner = int(np.argmax(score))
    wr = int(b[winner] - it)
    if 0 <= wr <= 100 and it == b[winner] - 0:
        pass
    if 0 <= wr <= 100:
        # If this placement makes the bin exactly full, mark residual it+wr filled.
        if wr == 0:
            _State.resid_fill[int(b[winner])] += 1.0

    return score
# EVOLVE-BLOCK-END
