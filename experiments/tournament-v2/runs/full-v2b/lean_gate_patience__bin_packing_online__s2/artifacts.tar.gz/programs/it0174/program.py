# EVOLVE-BLOCK-START
"""Residual-fillability rule: dominant best-fit tightness + online-histogram bonus
that rewards residuals matching frequent future item sizes."""
import numpy as np

# Online histogram over item sizes (1..100), with exponential forgetting.
_HIST = np.zeros(101, dtype=np.float64)
_DECAY = 0.995
_seen = 0

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _HIST, _seen

    # Update online histogram with this item (before scoring? it has arrived, fine).
    _HIST *= _DECAY
    _HIST[item] += 1.0
    _seen += 1
    if _seen > 400:
        _seen = 400

    n = len(bins)
    bins_f = bins.astype(np.float64)

    resid = bins_f - int(item)

    # Dominant term: best-fit tightness.
    tightness = -resid / 100.0

    # Busy-bin bonus: avoid opening new bins.
    used = (bins_f < 100.0).astype(np.float64)
    busy_bonus = 0.12 * used

    # Fillability: probability that residual r can be (nearly) exactly filled by
    # a small number of future items drawn from the running distribution.
    # We approximate with: P(exists an item size close to r) + P(two items fit).
    total = _HIST.sum()
    if total > 0:
        p = _HIST / total
    else:
        p = np.zeros(101, dtype=np.float64)

    # Build cumulative probability lookup.
    # Bonus 1: residual matches a frequent single item size.
    # Compute expected probability mass within a small window around resid.
    ri = np.clip(np.round(resid).astype(np.int64), 0, 100)
    single = p[ri]

    # Bonus 2: for larger residuals, fraction of probability mass of item sizes
    # that are <= resid (so the residual can plausibly be partitioned).
    cum = np.cumsum(p)  # cum[k] = P(size <= k)
    cum_r = cum[ri]
    # Smooth the two-bonus signal.
    fill = 0.05 * single + 0.04 * cum_r

    # Rotating small tie-break to spread choices across equal bins.
    idx = np.arange(n, dtype=np.float64)
    tie = 1e-4 * (idx % 7.0)

    score = tightness + busy_bonus + fill + tie
    return score
# EVOLVE-BLOCK-END
