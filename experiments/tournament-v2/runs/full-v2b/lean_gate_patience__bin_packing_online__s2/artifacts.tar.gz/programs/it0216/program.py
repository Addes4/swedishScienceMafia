# EVOLVE-BLOCK-START
"""Residual-desirability bin packing with a fillability estimate."""
import numpy as np

_state = {
    "mean": 40.0,
    "hist": np.ones(101, dtype=np.float64),   # bucket width 1, index 0..100
}


def priority(item, bins):
    S = _state
    it = float(item)

    S["mean"] = 0.98 * S["mean"] + 0.02 * it
    mu = S["mean"]

    # Fine-grained histogram of item sizes (bucket width 1, index 0..100).
    hb = int(it)
    if hb > 100:
        hb = 100
    S["hist"] *= 0.995
    S["hist"][hb] += 1.0
    hist = S["hist"]
    hmax = hist.max() + 1e-9

    b = np.asarray(bins, dtype=np.float64)
    res = b - it

    # Best-fit tightness: sharply prefer the smallest nonnegative residual.
    tight = 1.0 / (1.0 + res ** 2.5)

    # Desirability of the resulting residual: reward residuals that match a
    # common recent item size, which are likely exactly fillable later.
    ridx = np.clip(res.astype(np.int64), 0, 100)
    desirability = hist[ridx] / hmax

    # Fillability: residual close to a small multiple of the typical item
    # size is likely exactly fillable by future items.
    k = np.maximum(1.0, np.round(res / max(mu, 1.0)))
    fill = 1.0 / (1.0 + (res - k * mu) ** 2 / (mu + 1.0))

    score = 8.0 * tight + 1.6 * desirability + 0.15 * fill
    return score
# EVOLVE-BLOCK-END

