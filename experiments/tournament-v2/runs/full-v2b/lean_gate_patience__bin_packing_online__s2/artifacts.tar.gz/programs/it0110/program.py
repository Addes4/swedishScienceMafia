# EVOLVE-BLOCK-START
"""Size-sensitive best-fit with an exponentially-decayed residual-target preference."""
import numpy as np


class _State:
    call = 0
    profile = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Best-fit whose tightness weight grows with item size; prefer exact fits,
    reward residuals matching the historical size distribution, and discourage
    new bins most strongly for small items."""
    b = bins.astype(np.int64)
    it = int(item)

    # Update exponentially-decayed profile of item sizes.
    prof = _State.profile * 0.97
    prof[it] += 1.0
    _State.profile = prof

    residual = b - it  # residual after placing

    # Tightness weight grows with item size: large items strongly prefer tight fits.
    w = 0.01 + 0.005 * it
    score = -w * residual.astype(np.float64)

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 100.0, 0.0)

    # Reward bins whose residual-after equals a common historical item size,
    # so the bin can later be filled to near capacity.
    valid = (residual >= 0) & (residual <= 100)
    match = np.zeros(b.shape[0], dtype=np.float64)
    match[valid] = prof[residual[valid]]
    score += 0.3 * match

    # Penalize opening brand-new bins; strongest for small items (they consolidate).
    new_bin_pen = 13.0 - 0.1 * it
    score -= np.where(b == 100, new_bin_pen, 0.0)

    # Mild bonus for already-used bins.
    score += np.where(b < 100, 0.25, 0.0)

    # Rotating tie-break.
    _State.call += 1
    n = b.shape[0]
    idx = np.arange(n, dtype=np.float64)
    rotate = float((_State.call * 2654435761) % 1000) * 0.002
    score += ((idx + rotate) % 7.0) * 1e-3

    return score
# EVOLVE-BLOCK-END
