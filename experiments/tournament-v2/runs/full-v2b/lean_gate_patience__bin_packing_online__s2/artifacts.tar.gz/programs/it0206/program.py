# EVOLVE-BLOCK-START
"""Strict best-fit dominant, with a near-tie breaker based on the online
probability that the post-placement residual can be exactly filled by a single
future item (estimated from a recency-weighted histogram of item sizes).
Only bins whose residual is very close to the best-fit residual are affected,
so the strong best-fit behavior is preserved and noise is minimized."""
import numpy as np

_STATE = {"n": 0, "hist": np.zeros(101, dtype=np.float64), "decay": 0.995}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    st = _STATE
    st["n"] += 1
    hist = st["hist"]
    # recency-weighted histogram of observed item sizes (for exact-fill prob)
    hist *= st["decay"]
    hist[item] += 1.0

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # leftover capacity (>= 0, integer)

    # Dominant term: strict best-fit (prefer smallest residual).
    tight = -residual

    # Near-tie breaker: reward residuals that can be exactly filled by one item,
    # weighted by how often such a size has recently appeared.
    ri = np.rint(residual).astype(np.int64)
    valid = (ri >= 0) & (ri <= 100)
    exact_fill = np.where(valid, hist[np.clip(ri, 0, 100)], 0.0)
    # normalized so it stays a small tie-break relative to unit residual steps
    scale = hist.sum()
    if scale > 0:
        exact_fill = exact_fill / scale
    fill_score = 0.5 * exact_fill

    # Tiny deterministic rotating tie-break for stability.
    idx = np.arange(bins.size, dtype=np.float64)
    rot = 1e-6 * ((idx + st["n"]) % 101)

    return tight + fill_score + rot
# EVOLVE-BLOCK-END
