# Research notebook: erdos_squares

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.856172.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 5 | Leverage known optimal configurations for small n (e.g., from Erich Friedman's "Squares in Squares" or similar) as seeds, and for larger n generate an arrangeme | 0.63 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 2 | Start with a known optimal arrangement for the nearest triangular number n′ ≤ n, then insert additional squares one by one using a largest-empty-circle / larges | 0.62 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | improved | 0.895977 |
| 4 | Use a greedy "biggest residual square" algorithm: maintain a list of available rectangular free spaces (initially the unit square), repeatedly place the largest | 0.61 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.348486 |
| 0 | Use a physics-inspired packing simulation: initialise n equal-sized axis-aligned squares randomly without overlap, then run a gradient-free optimisation (e.g.,  | 0.61 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.845461 |
| 1 | Recursively subdivide the unit square using a guillotine cut approach: partition the square into a set of non-overlapping rectangles via a binary space partitio | 0.55 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 3 | Formulate the problem as a non-linear programming (NLP) model: treat square centres, rotations, and side lengths as variables, non-overlap as rotated-box separa | 0.52 | long_shot | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.275036 |

Best after round 1: **0.895977** (spent $0.04)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Transform the problem into a circle packing auxiliary problem: approximate each square by its circumscribed circle to get an initial non-overlapping arrangement | 0.21 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.580151 |
| 0 | Pre-partition the unit square into a fixed number of large equal rectangles (e.g., 2×2 grid for n≥4) and then recursively apply the staircase packing inside eac | 0.20 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 5 | Construct a greedy arrangement by repeatedly slicing the largest inscribed square from the remaining empty region of the unit square, using a fast pixel-based o | 0.18 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | improved | 0.957579 |
| 3 | Solve the problem via an evolutionary algorithm that encodes the arrangement as a list of (cx, cy, angle, side) and uses a specialised crossover operator that e | 0.14 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 1 | Formulate the problem as a nonlinear program with exact rotated-square non-overlap constraints expressed via Minkowski sum and no-fit polygons, then solve it us | 0.12 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 2 | Use a packing growth algorithm that starts from a point (side = 0) configuration for all n squares placed at random non-overlapping positions inside the unit sq | 0.06 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Promotion: deepseek-ai/DeepSeek-V4.1-Flash:deepinfra found an improvement; deepseek-ai/DeepSeek-V4-Pro:deepinfra refined it -> not_better (0.111111).

Best after round 2: **0.957579** (spent $0.11)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Use a spectral clustering approach on a dense random sample of candidate placements: generate a large pool of maximal non-overlapping rotated squares using the  | 0.21 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | no_code |  |
| 1 | Implement a “swap and smooth” multi-start perturbation: take the best solution found, selectively remove a few squares (e.g., the smallest ones) and re-pack the | 0.20 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | api_error |  |
| 5 | Precompute a set of high-quality partial packings for small k (k ≤ 8) via exhaustive enumeration and non-linear optimization offline, then when solving for a gi | 0.15 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | api_error |  |
| 3 | Leverage a solution for n−1 and “inject” an additional square by using a stress-minimization spring network: add a zero-size square at a promising spot, then ru | 0.11 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | api_error |  |
| 2 | Design a geometric subdivider that partitions the unit square into convex polygonal cells via a rotated-square Voronoi-like diagram (using a signed-distance fie | 0.07 | long_shot | Qwen/Qwen3.5-9B:together | api_error |  |
| 4 | Encode the arrangement as a combinatorial tree of axis-aligned or 45-degree rotated guillotine cuts, represent squares as leaves, and optimize the tree structur | 0.03 | long_shot | Qwen/Qwen3.5-9B:together | api_error |  |

Best after round 3: **0.957579** (spent $0.13)

