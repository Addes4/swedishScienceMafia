import math
import random
import numpy as np

def _to_poly(center, angle, side):
    """Return 4 corner points of square."""
    cx, cy = center
    d = side / 2.0
    corners = np.array([[-d, -d], [d, -d], [d, d], [-d, d]])
    c = math.cos(angle * 2.0 * math.pi)
    s = math.sin(angle * 2.0 * math.pi)
    rot = np.array([[c, -s], [s, c]])
    return corners @ rot.T + np.array([cx, cy])

def _poly_intersect(poly1, poly2):
    """Check if two convex polygons overlap (strict interior intersection)."""
    for poly in (poly1, poly2):
        n = len(poly)
        for i in range(n):
            p1 = poly[i]
            p2 = poly[(i+1) % n]
            edge = p2 - p1
            normal = np.array([-edge[1], edge[0]])
            proj1 = poly1 @ normal
            proj2 = poly2 @ normal
            if proj1.max() <= proj2.min() + 1e-9 or proj2.max() <= proj1.min() + 1e-9:
                return False
    return True

def _poly_inside_unit(poly):
    return np.all((poly >= -1e-9) & (poly <= 1+1e-9))

def _feasible(squares):
    polys = []
    for (cx, cy, ang, s) in squares:
        if s <= 0:
            polys.append(None)
            continue
        poly = _to_poly((cx, cy), ang, s)
        if not _poly_inside_unit(poly):
            return False
        polys.append(poly)
    n = len(polys)
    for i in range(n):
        if polys[i] is None:
            continue
        for j in range(i+1, n):
            if polys[j] is None:
                continue
            if _poly_intersect(polys[i], polys[j]):
                return False
    return True

def _point_poly_distance(pt, poly):
    """Min distance from point to convex polygon boundary or 0 if inside."""
    px, py = pt
    n = len(poly)
    inside = True
    for i in range(n):
        a = poly[i]
        b = poly[(i+1) % n]
        cross = (b[0]-a[0])*(py-a[1]) - (b[1]-a[1])*(px-a[0])
        if cross < -1e-9:
            inside = False
            break
    if inside:
        return 0.0
    best = float('inf')
    for i in range(n):
        a = poly[i]
        b = poly[(i+1) % n]
        best = min(best, _pt_seg_dist(pt, a, b))
    return best

def _pt_seg_dist(p, a, b):
    ab = b - a
    t = np.dot(p - a, ab) / (np.dot(ab, ab) + 1e-12)
    t = max(0.0, min(1.0, t))
    proj = a + t * ab
    return math.hypot(p[0]-proj[0], p[1]-proj[1])

def _largest_square_at(pos, angle, polys, xmin=0.0, xmax=1.0, ymin=0.0, ymax=1.0):
    """Binary search for largest square at (pos, angle) that fits and doesn't overlap."""
    cx, cy = pos
    # container half-diagonal constraint
    dx = min(cx - xmin, xmax - cx)
    dy = min(cy - ymin, ymax - cy)
    hi = 2.0 * min(dx, dy) / math.sqrt(2)
    if hi <= 0:
        return 0.0

    # tighter upper bound from distance to existing squares
    for p in polys:
        if p is None:
            continue
        d = _point_poly_distance((cx, cy), p)
        # The square's half-diagonal is s*sqrt(2)/2.
        # safe distance: d must be >= s*sqrt(2)/2
        bound = d * math.sqrt(2)
        if bound < hi:
            hi = bound
    if hi <= 0:
        return 0.0

    lo = 0.0
    for _ in range(25):
        mid = (lo + hi) / 2.0
        if mid < 1e-12:
            lo = mid
            continue
        poly_new = _to_poly((cx, cy), angle, mid)
        if not _poly_inside_unit(poly_new):
            hi = mid
            continue
        ok = True
        for p in polys:
            if p is None:
                continue
            if _poly_intersect(poly_new, p):
                ok = False
                break
        if ok:
            lo = mid
        else:
            hi = mid
    return lo

def _staircase(n):
    """Exact optimal for triangular numbers."""
    k = 1
    while k*(k+1)//2 <= n:
        k += 1
    k -= 1
    Tk = k*(k+1)//2
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k - i):
            cx = j*side + side/2
            cy = i*side + side/2
            squares.append((cx, cy, 0.0, side))
    if n > Tk:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - Tk)
    return squares[:n]

def _grid_solution(n, k):
    """Grid of k x k squares."""
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) >= n:
                break
            squares.append(((j+0.5)*side, (i+0.5)*side, 0.0, side))
        if len(squares) >= n:
            break
    return squares[:n]

def _diagonal_shifted(n):
    """Try to pack squares along diagonal with rotations that improve sum."""
    if n <= 2:
        return None
    # For n=3..7 we might do better with rotated packing like n=3: three squares side 0.5
    # Simple heuristic: place big squares in a row/column along diagonal
    squares = []
    k = int(n)
    if k == 3:
        return [(0.25,0.25,0.0,0.5),(0.75,0.25,0.0,0.5),(0.25,0.75,0.0,0.5)]
    if k == 5:
        # best known 2.5? Actually 5 squares can sum to 2.5: side 0.5 each, but that's 5*0.5=2.5.
        # 2x2 grid plus one in corner? Let's use better packing: four in corners plus one center rotated?
        # Actually staircase n=5 gives side 1/3 ~ 0.333 each, sum 1.667. Better is grid 2x2 (side 0.5) + 1 zero -> 2.0.
        return [(0.25,0.25,0.0,0.5),(0.75,0.25,0.0,0.5),(0.25,0.75,0.0,0.5),(0.75,0.75,0.0,0.5),(0.5,0.5,0.0,0.0)]
    return None

def _greedy_slice(n, max_candidates=600, seed=0):
    """Greedy placement using random candidate positions and angles."""
    rng = random.Random(seed)
    squares = []
    polys = []
    # precompute angle candidates
    angles = [0.0, 0.125, 0.25, 0.375, 0.0625, 0.1875, 0.3125, 0.4375]
    for step in range(n):
        best_side = -1.0
        best_sq = (0.5, 0.5, 0.0, 0.0)
        candidates = []
        # grid points
        G = max(2, int(math.sqrt(n)) + 2)
        for ix in range(G):
            for iy in range(G):
                candidates.append(((ix+0.5)/G, (iy+0.5)/G))
        # corners of existing squares
        for p in polys:
            if p is None:
                continue
            for pt in p:
                candidates.append((float(pt[0]), float(pt[1])))
        # random points
        for _ in range(max_candidates):
            candidates.append((rng.random(), rng.random()))
        # shuffle to avoid bias
        rng.shuffle(candidates)
        candidates = candidates[:max_candidates*2]
        for (cx, cy) in candidates:
            for ang in angles:
                s = _largest_square_at((cx, cy), ang, polys)
                if s > best_side:
                    best_side = s
                    best_sq = (cx, cy, ang, s)
        if best_side <= 1e-9:
            squares.append((0.5, 0.5, 0.0, 0.0))
            polys.append(None)
        else:
            squares.append(best_sq)
            polys.append(_to_poly((best_sq[0], best_sq[1]), best_sq[2], best_sq[3]))
    return squares

def _square_valid(squares, idx, new_sq):
    """Check new square valid against all others and container."""
    cx, cy, ang, s = new_sq
    if s < 0:
        return False
    if s == 0:
        return 0 <= cx <= 1 and 0 <= cy <= 1
    poly_new = _to_poly((cx, cy), ang, s)
    if not _poly_inside_unit(poly_new):
        return False
    for k, sq in enumerate(squares):
        if k == idx or sq[3] <= 0:
            continue
        poly_k = _to_poly((sq[0], sq[1]), sq[2], sq[3])
        if _poly_intersect(poly_new, poly_k):
            return False
    return True

def _local_search(squares, iters=3000, seed=0, initial_temp=0.02):
    """Monte Carlo search with simulated annealing."""
    rng = random.Random(seed)
    squares = [list(s) for s in squares]
    cur_sum = sum(s[3] for s in squares)
    best = [list(s) for s in squares]
    best_sum = cur_sum
    n = len(squares)
    temp = initial_temp
    for it in range(iters):
        idx = rng.randrange(n)
        old = list(squares[idx])
        # adaptive step size
        scale = 0.04 * (1 - it/iters) + 0.005
        dx = rng.gauss(0, scale)
        dy = rng.gauss(0, scale)
        da = rng.gauss(0, scale * 0.5)
        ds = rng.gauss(0, scale)
        np_sq = (old[0]+dx, old[1]+dy, (old[2]+da) % 1.0, max(0.0, old[3]+ds))
        # clamp to unit
        np_sq = (max(0.0, min(1.0, np_sq[0])), max(0.0, min(1.0, np_sq[1])), np_sq[2], np_sq[3])
        if not _square_valid(squares, idx, np_sq):
            continue
        old_contrib = old[3]
        new_contrib = np_sq[3]
        delta = new_contrib - old_contrib
        if delta > 0 or rng.random() < math.exp(delta / max(temp, 1e-8)):
            squares[idx] = list(np_sq)
            cur_sum += delta
            if cur_sum > best_sum:
                best_sum = cur_sum
                best = [list(s) for s in squares]
        temp *= 0.9995
        temp = max(temp, 0.0005)
    return [(s[0], s[1], s[2], s[3]) for s in best]

def _grow_all(squares, rounds=25):
    """Try to grow each square incrementally."""
    squares = [list(s) for s in squares]
    for r in range(rounds):
        improved = False
        order = list(range(len(squares)))
        random.shuffle(order)
        for idx in order:
            s = squares[idx][3]
            if s < 1e-9:
                # try placing a small square
                polys = [None if squares[k][3]<=0 else _to_poly((squares[k][0], squares[k][1]), squares[k][2], squares[k][3])
                         for k in range(len(squares)) if k != idx]
                best_s = 0.0
                best_pos = None
                for _ in range(80):
                    cx = random.random()
                    cy = random.random()
                    ang = random.choice([0.0, 0.125, 0.25, 0.375])
                    s_new = _largest_square_at((cx, cy), ang, polys)
                    if s_new > best_s:
                        best_s = s_new
                        best_pos = (cx, cy, ang, s_new)
                if best_s > 1e-6:
                    squares[idx] = list(best_pos)
                    improved = True
                continue
            # try growth amounts
            for amount in [0.02, 0.01, 0.005, 0.002, 0.001]:
                new_s = s + amount
                if new_s > 1.0:
                    continue
                poly_new = _to_poly((squares[idx][0], squares[idx][1]), squares[idx][2], new_s)
                if not _poly_inside_unit(poly_new):
                    continue
                ok = True
                for k, sq in enumerate(squares):
                    if k == idx or sq[3] <= 0:
                        continue
                    if _poly_intersect(poly_new, _to_poly((sq[0], sq[1]), sq[2], sq[3])):
                        ok = False
                        break
                if ok:
                    squares[idx][3] = new_s
                    improved = True
                    break
        if not improved:
            break
    return [(s[0], s[1], s[2], s[3]) for s in squares]

def _post_optimize(squares, iterations=2000):
    """Greedy shrink+expand around each square to maximize sum."""
    squares = [list(s) for s in squares]
    n = len(squares)
    for it in range(iterations):
        idx = random.randrange(n)
        cx, cy, ang, s = squares[idx]
        if s <= 1e-9:
            continue
        # shrink slightly
        shrink = s * 0.98
        squares[idx][3] = shrink
        # find max size at exact position
        polys = [None if k==idx or squares[k][3]<=0 else _to_poly((squares[k][0], squares[k][1]), squares[k][2], squares[k][3])
                 for k in range(n)]
        new_s = _largest_square_at((cx, cy), ang, polys)
        if new_s > shrink:
            squares[idx][3] = new_s
        else:
            squares[idx][3] = s  # revert
    return [(s[0], s[1], s[2], s[3]) for s in squares]

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25,0.25,0.0,0.5),(0.75,0.25,0.0,0.5),(0.25,0.75,0.0,0.5)]
    if n == 4:
        return [(0.25,0.25,0.0,0.5),(0.75,0.25,0.0,0.5),(0.25,0.75,0.0,0.5),(0.75,0.75,0.0,0.5)]

    # Generate multiple candidate solutions
    candidates = []
    
    # 1. Staircase packing (optimal for triangular numbers)
    cand = _staircase(n)
    if len(cand) == n:
        candidates.append(cand)
    
    # 2. Grid packing with different k
    k_sq = math.ceil(math.sqrt(n))
    for k in [k_sq, k_sq-1]:
        if k >= 1:
            cand = _grid_solution(n, k)
            if len(cand) == n:
                candidates.append(cand)
    
    # 3. Greedy slicing with multiple seeds and candidate counts
    for seed in range(4):
        cand = _greedy_slice(n, max_candidates=300, seed=seed)
        if len(cand) == n:
            candidates.append(cand)
    
    # 4. Diagonal shifted variants for small n
    if n <= 10:
        diag = _diagonal_shifted(n)
        if diag is not None and len(diag) == n:
            candidates.append(diag)

    results = []
    for cand in candidates:
        if len(cand) != n:
            continue
        # Ensure basic feasibility
        if not _feasible(cand):
            continue
        # Grow + post-optimize cycle
        grown = _grow_all(cand, rounds=20)
        grown = _post_optimize(grown, iterations=500)
        best = grown
        best_sum = sum(s[3] for s in best)
        # Apply local search multiple times
        for seed in range(3):
            ls = _local_search(best, iters=2500, seed=seed, initial_temp=0.025)
            if not _feasible(ls):
                continue
            ls_sum = sum(s[3] for s in ls)
            if ls_sum > best_sum:
                best = ls
                best_sum = ls_sum
        # Final grow+optimize
        best = _grow_all(best, rounds=15)
        best = _post_optimize(best, iterations=300)
        if _feasible(best):
            results.append((best_sum, best))
    
    if not results:
        # Fallback to best staircase/grid
        fallback = _staircase(n)
        if len(fallback) < n:
            fallback += [(0.5, 0.5, 0.0, 0.0)] * (n - len(fallback))
        return fallback
    
    # Pick best
    results.sort(key=lambda x: -x[0])
    _, best = results[0]
    
    # Final intensive local search with multiple restarts
    for restart in range(2):
        temp = 0.03 * (0.5 ** restart)
        ls = _local_search(best, iters=3500, seed=100+restart, initial_temp=temp)
        if _feasible(ls) and sum(s[3] for s in ls) > sum(s[3] for s in best):
            best = ls
        best = _grow_all(best, rounds=10)
        best = _post_optimize(best, iterations=400)
    
    # Ensure exact length
    best = list(best)[:n]
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    
    # Final validation
    if not _feasible(best):
        # Shrink slightly to get valid
        best = [(cx, cy, ang, s*0.995) for (cx, cy, ang, s) in best]
        if not _feasible(best):
            best = _staircase(n)
            if len(best) < n:
                best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    
    return best
