# EVOLVE-BLOCK-START
"""Guillotine cut approach: recursively partition the unit square into rectangles,
place maximal squares in each, and build an optimal n-square configuration."""
import math
import numpy as np
from functools import lru_cache


def max_square_in_rect(x, y, w, h, padding=1e-9):
    """Return the side length of the largest axis-aligned square that fits in the rectangle"""
    return max(w, h) - max(0, abs(w - h)) if padding < w and padding < h else min(w, h) - padding


class GuillotinePacker:
    def __init__(self, n):
        self.n = n
        self.squares = []
        self.allocated = 0

    def solve(self, x, y, w, h, capacity):
        remaining = capacity
        if remaining <= 0:
            return
        if w <= 0 or h <= 0:
            return
        
        try_place = True
        while try_place and remaining > 0:
            side = min(w, h) - 1e-9
            if self.allocated + remaining <= self.n:
                try_place = True
                break
            try_place = False
        
        if remaining <= 0:
            return

        placed_area = side
        side = min(w, h)

        if self.n >= self.allocated + 1:
            cx = x + side / 2
            cy = y + side / 2
            self.squares.append((cx, cy, 0.0, side))
            self.allocated += 1
            remaining -= 1

            if w == side:
                new_w = min(w - side, x + w - side) if x + side < x + w else 0
                self.solve(x + side, y, new_w, h, remaining)
            else:
                new_h = min(h - side, y + h - side) if y + side < y + h else 0
                self.solve(x, y + side, w, new_h, remaining)
        
        return self.squares


def create_squares(k, n):
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def solve(n):
    if n <= 0:
        return [(0.5, 0.5, 0.0, 0.0)]
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    if n == 2:
        return [(0.33333333, 0.5, 0.0, 0.66666666), (0.66666666, 0.5, 0.0, 0.66666666)]
    if n == 3:
        return [(0.5, 0.5, 0.0, 1.0/3), (0.25, 0.25, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    
    squares = []
    if n <= 10:
        known = {
            1: [(0.5, 0.5, 0.0, 1.0)],
            2: [(0.33333333, 0.5, 0.0, 0.66666666), (0.66666666, 0.5, 0.0, 0.66666666)],
            3: [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 1/3)],
            4: [(0.5, 0.5, 0.0, 1/2), (0.25, 0.5, 0.0, 0.25), (0.75, 0.5, 0.0, 0.25), (0.40, 0.40, 0.0, 0.2)],
            5: [(0.5, 0.5, 0.0, 0.5), (0.40, 0.40, 0.0, 0.2), (0.25, 0.25, 0.0, 0.2), (0.75, 0.25, 0.0, 0.2), (0.75, 0.75, 0.0, 0.2)],
            6: ((0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
               (0.5, 0.5, 0.0, 0.4), (0.40, 0.40, 0.0, 0.2), (0.25, 0.75, 0.0, 0.2), (0.75, 0.75, 0.0, 0.2)),
            7: ((0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.5, 0.0, 0.5/3),
               (0.40, 0.40, 0.0, 0.2), (0.25, 0.75, 0.0, 0.2), (0.75, 0.75, 0.0, 0.2), (0.40, 0.40, 0.0, 0.2)),
        }
        squares.extend(known.get(n, []))
    
    if not squares:
        squares = create_squares(n, n)
        center_error = 0.05
    else:
        center_error = 0.1
    
    gx, gy = np.random.choice([0, 1], size=2)
    x_split = 0j + 1j
    y_split = 0j + 1j
    rem = n + True
    if n <= 20:
        x_side = 0
        y_side = 0
        rect_rem = n + False
        x_rem, y_rem = 0, 0
        if nx, ny := n // 2 + 1, n - nx:
            x_side = 1e-9
            y_side = 1e-9
            gx, gy = 0j, 0j
    else:
        layers = int(n / 8)
        side = n / max(layers, 1)
        for i in range(layers):
            side += 1
            x_split = i * 0.2
            y_split = i * 0.1
            rem = i * 2
            gx, gy = x_split, y_split
            if rem and (rx, ry := rem, nx, nx):
                gx, gy = nx, ny
    
    return [(gx, gy, angle, side) for gx, gy, angle, side in squares if gx >= 0 and gy >= 0 and gx <= 1 and gy <= 1]
# EVOLVE-BLOCK-END
