import math
import itertools
import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint
from scipy.spatial import ConvexHull

# ----------------------------------------------------------------------
#  Geometry helpers
# ----------------------------------------------------------------------
def _to_poly(center, angle, side):
    cx, cy = center
    d = side / 2.0
    corners = np.array([[-d, -d], [d, -d], [d, d], [-d, d]])
    theta = angle * 2.0 * math.pi
    c, s = math.cos(theta), math.sin(theta)
    rot = np.array([[c, -s], [s, c]])
    return corners @ rot.T + np.array([cx, cy])

def _poly_intersect(poly1, poly2):
    for poly in (poly1, poly2):
        for i in range(len(poly)):
            p1, p2 = poly[i], poly[(i + 1) % len(poly)]
            edge = p2 - p1
            normal = np.array([-edge[1], edge[0]])
            proj1 = poly1 @ normal
            proj2 = poly2 @ normal
            if proj1.max() <= proj2.min() + 1e-9 or proj2.max() <= proj1.min() + 1e-9:
                return False
    return True

def _poly_inside_unit(poly):
    return np.all((poly >= -1e-9) & (poly <= 1 + 1e-9))

def _feasible(squares):
    polys = []
    for cx, cy, ang, s in squares:
        if s < 0:
            return False
        if s == 0:
            continue
        p = _to_poly((cx, cy), ang, s)
        if not _poly_inside_unit(p):
            return False
        polys.append(p)
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if _poly_intersect(polys[i], polys[j]):
                return False
    return True

# ----------------------------------------------------------------------
#  Staircase packing inside an arbitrary axis-aligned rectangle
# ----------------------------------------------------------------------
def _staircase_in_rect(n, x0, y0, w, h):
    """
    Place n equal squares in a staircase pattern inside the rectangle
    [x0, x0+w] × [y0, y0+h].  The staircase uses the smallest possible
    side length so that all n squares fit.  Returns list of (cx, cy, angle, side).
    """
    if n <= 0:
        return []
    # The staircase needs k rows, k = ceil((sqrt(8*n+1)-1)/2)
    k = int(math.ceil((math.sqrt(8 * n + 1) - 1) / 2))
    # side length is limited by both width/k and height/k
    side = min(w / k, h / k)
    squares = []
    placed = 0
    for i in range(k):
        for j in range(k - i):
            if placed >= n:
                break
            cx = x0 + j * side + side / 2
            cy = y0 + i * side + side / 2
            squares.append((cx, cy, 0.0, side))
            placed += 1
        if placed >= n:
            break
    # If any squares remain, add them with zero size (should not happen with proper k)
    while len(squares) < n:
        squares.append((x0 + w / 2, y0 + h / 2, 0.0, 0.0))
    return squares

# ----------------------------------------------------------------------
#  Recursive partitioning: dynamic programming
# ----------------------------------------------------------------------
# We precompute the best solution for a rectangle using a 2x2 grid split.
# A rectangle is recursively split into `rows` × `cols` sub-rectangles.
# We restrict to rotated squares?  No, the staircase always uses axis-aligned squares.
# The DP idea: for a given rectangle and a total number of squares N,
# we consider all ways to split N among a fixed grid of sub-rectangles.
# Sub-rectangles are identical and square, so allocation is symmetric.

def _rectangle_solution(n, x0, y0, w, h, memo, max_splits=2):
    """
    Fill the rectangle with n squares, maximising sum of side lengths.
    Uses memoization on (n, w, h).  Splits are 2×2 grid of equal sub-rectangles.
    """
    if n <= 0:
        return []
    key = (n, round(w, 10), round(h, 10))
    if key in memo:
        # return a copy
        return [(cx, cy, a, s) for (cx, cy, a, s) in memo[key]]

    best_sum = -1
    best_sol = None

    # Option 1: put all n into a single staircase inside the whole rectangle
    sol1 = _staircase_in_rect(n, x0, y0, w, h)
    s1 = sum(s for (_, _, _, s) in sol1)
    if s1 > best_sum:
        best_sum = s1
        best_sol = sol1

    # Option 2: split into sub-rectangles (2×2 grid) and solve recursively
    # Only do this if the rectangle is reasonably large and n >= 4
    if max_splits > 0 and n >= 4 and w > 1e-6 and h > 1e-6:
        # 2x2 grid: each sub-rectangle has size w/2 by h/2
        sw, sh = w / 2.0, h / 2.0
        # Try every distribution of n squares among the 4 sub-cells
        # Because of symmetry, we can restrict a bit, but full enumeration is fine for n <= ~30
        # We generate all compositions of n into 4 non-negative parts
        parts_list = []
        for a in range(n + 1):
            for b in range(n + 1 - a):
                for c in range(n + 1 - a - b):
                    d = n - a - b - c
                    # Symmetry reduction: sort parts to avoid redundant computation
                    # but we must map back to actual positions later.
                    parts_list.append((a, b, c, d))
        # Evaluate each partition
        for a, b, c, d in parts_list:
            # Each sub-cell: top-left (a), top-right (b), bottom-left (c), bottom-right (d)
            # but we can exploit symmetry: cells are identical, so we can reuse the same memoized solution
            # for equal allocations.  But we still have to place them at different offsets.
            # Recursively solve for each part
            sol_a = _rectangle_solution(a, x0,       y0 + sh,   sw, sh, memo, max_splits - 1)
            sol_b = _rectangle_solution(b, x0 + sw,   y0 + sh,   sw, sh, memo, max_splits - 1)
            sol_c = _rectangle_solution(c, x0,        y0,        sw, sh, memo, max_splits - 1)
            sol_d = _rectangle_solution(d, x0 + sw,   y0,        sw, sh, memo, max_splits - 1)
            total_sum = sum(s for (_,_,_,s) in sol_a) + sum(s for (_,_,_,s) in sol_b) + \
                        sum(s for (_,_,_,s) in sol_c) + sum(s for (_,_,_,s) in sol_d)
            if total_sum > best_sum:
                best_sum = total_sum
                # offset sub-solutions to global coordinates (they are already in local)
                combined = sol_a + sol_b + sol_c + sol_d
                best_sol = combined

    # store in memo
    memo[key] = best_sol
    return [(cx, cy, a, s) for (cx, cy, a, s) in best_sol]

# ----------------------------------------------------------------------
#  Main solver
# ----------------------------------------------------------------------
def solve(n):
    # Special small n
    if n <= 4:
        k = int(math.isqrt(n))
        if k == 0:
            k = 1
        side = 1.0 / k
        sq = []
        for i in range(k):
            for j in range(k):
                cx = (i + 0.5) * side
                cy = (j + 0.5) * side
                sq.append((cx, cy, 0.0, side))
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        return sq[:n]

    # Use recursive partitioning with DP; we start with the whole unit square.
    memo = {}
    squares = _rectangle_solution(n, 0.0, 0.0, 1.0, 1.0, memo, max_splits=3)

    # Sometimes DP might place zero-size squares if the partition left some parts with too many squares
    # but the composition iterates all possibilities so it should fill everything.
    # Ensure we have exactly n squares.
    if len(squares) > n:
        squares = squares[:n]
    elif len(squares) < n:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))

    # Optional local optimisation to enlarge squares while keeping feasibility.
    # We try to scale up all squares by a small factor while respecting constraints.
    # This is a simple uniform scaling attempt.
    for scale in np.linspace(1.0, 1.5, 20):
        test = []
        for cx, cy, ang, s in squares:
            test.append((cx, cy, ang, s * scale))
        if _feasible(test):
            squares = test
        else:
            break

    return squares


# ----------------------------------------------------------------------
# quick test
if __name__ == "__main__":
    for n in [5,6,7,8,11,12,13,14,15]:
        sol = solve(n)
        print(f"n={n}: sum={sum(s for _,_,_,s in sol):.4f}, feasible={_feasible(sol)}")
