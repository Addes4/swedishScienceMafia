import math
import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint
from scipy.spatial import ConvexHull
import itertools
import random
import time

def _to_poly(cx, cy, angle, side):
    d = side / 2.0
    corners = np.array([[-d, -d], [d, -d], [d, d], [-d, d]])
    c = math.cos(angle * 2.0 * math.pi)
    s = math.sin(angle * 2.0 * math.pi)
    rot = np.array([[c, -s], [s, c]])
    return corners @ rot.T + np.array([cx, cy])

def _poly_intersect(poly1, poly2):
    for poly in (poly1, poly2):
        for i in range(len(poly)):
            p1, p2 = poly[i], poly[(i+1) % len(poly)]
            edge = p2 - p1
            normal = np.array([-edge[1], edge[0]])
            proj1, proj2 = poly1 @ normal, poly2 @ normal
            if proj1.max() <= proj2.min() + 1e-9 or proj2.max() <= proj1.min() + 1e-9:
                return False
    return True

def _poly_inside_unit(poly):
    return np.all((poly >= -1e-12) & (poly <= 1+1e-12))

def _feasible(squares):
    n = len(squares)
    if n == 0:
        return True
    polys = []
    for (cx, cy, ang, s) in squares:
        if s < 0:
            return False
        if s == 0:
            continue
        poly = _to_poly(cx, cy, ang, s)
        if not _poly_inside_unit(poly):
            return False
        polys.append(poly)
    for i in range(len(polys)):
        for j in range(i+1, len(polys)):
            if _poly_intersect(polys[i], polys[j]):
                return False
    return True

def _triangle_number(k):
    return k * (k + 1) // 2

def _staircase_base(n):
    """Return list of side lengths for staircase plus zeros."""
    k = 1
    while _triangle_number(k) <= n:
        k += 1
    k -= 1
    side = 1.0 / k
    cnt = _triangle_number(k)
    sides = [side] * cnt + [0.0] * (n - cnt)
    return sides[:n]

def _circle_initial(n):
    """Place n circles (centers) using a simple force-based method inside unit square."""
    centers = np.random.rand(n, 2) * 0.8 + 0.1
    # run a few iterations of repulsion
    for it in range(50):
        forces = np.zeros_like(centers)
        for i in range(n):
            for j in range(i+1, n):
                d = centers[i] - centers[j]
                dist = np.linalg.norm(d)
                if dist < 1e-6:
                    d = np.random.randn(2) * 1e-4
                    dist = np.linalg.norm(d)
                # repulsion: 1/d^2
                f = d / (dist**3)
                forces[i] += f
                forces[j] -= f
            # wall repulsion
            for coord in (0, 1):
                if centers[i, coord] < 0.05:
                    forces[i, coord] += 5.0
                if centers[i, coord] > 0.95:
                    forces[i, coord] -= 5.0
        centers += 0.01 * forces
        centers = np.clip(centers, 0.0, 1.0)
    return centers

def _solve_cutting_plane_iteration(side_vars, initial_centers, initial_angles, max_iter=20):
    """
    Given target side lengths (side_vars) for n squares,
    try to find centers and angles such that all squares fit.
    
    Uses a cutting-plane approach: maintain linear constraints derived from
    separating axes of any overlapping pair.
    
    Returns (centers, angles, success).
    """
    n = len(side_vars)
    if n == 0:
        return np.zeros((0,2)), np.zeros(0), True
    
    # Variables: cx, cy, angle (in turns) for each square
    # Initial guess
    x0 = np.zeros(3*n)
    for i in range(n):
        x0[3*i] = initial_centers[i, 0]
        x0[3*i+1] = initial_centers[i, 1]
        x0[3*i+2] = initial_angles[i] if i < len(initial_angles) else 0.0

    sides = np.array(side_vars)
    
    # Constraints: all squares inside [0,1]x[0,1] (as box constraints)
    bounds = []
    for i in range(n):
        s = sides[i]
        half = s / 2.0
        bounds.append((half, 1.0 - half))
        bounds.append((half, 1.0 - half))
        bounds.append((0.0, 1.0))
    
    # We'll iteratively add linear constraints for non-overlap
    linear_constraints = []  # each is a tuple (A_i, lb, ub) where A_i is sparse or dense; we'll build dense
    
    # Initial linear constraints: simple axis-aligned bounding boxes for separation
    # For initial circles, just ensure centers are far enough: |ci - cj| >= (si+sj)/sqrt(2)
    # This is a nonconvex constraint, so we linearize at current x.
    
    def _build_overlap_constraints(x):
        """Given current point, find violated separating axes and return linear constraints."""
        new_constraints = []
        polys = []
        for i in range(n):
            cx, cy, ang = x[3*i], x[3*i+1], x[3*i+2]
            poly = _to_poly(cx, cy, ang, sides[i])
            polys.append(poly)
        
        for i in range(n):
            for j in range(i+1, n):
                if sides[i] == 0 or sides[j] == 0:
                    continue
                # Check if they intersect
                poly_i, poly_j = polys[i], polys[j]
                if not _poly_intersect(poly_i, poly_j):
                    continue
                # Find a separating axis from either polygon edges
                best_axis = None
                best_overlap = -np.inf
                for poly in (poly_i, poly_j):
                    for k in range(4):
                        p1 = poly[k]
                        p2 = poly[(k+1)%4]
                        edge = p2 - p1
                        normal = np.array([-edge[1], edge[0]])
                        normal = normal / np.linalg.norm(normal)
                        proj_i = poly_i @ normal
                        proj_j = poly_j @ normal
                        overlap = proj_i.max() - proj_j.min()
                        if overlap > best_overlap:
                            best_overlap = overlap
                            best_axis = normal
                
                if best_axis is None:
                    continue
                
                # Linear approximation of constraint: projection of i_th square onto axis
                # must be <= projection of j_th square.
                # We need gradients of min/max projections w.r.t. x.
                # For square i, its projection interval is [min, max] of its 4 corners.
                # We linearly approximate the "max_i <= min_j" constraint.
                # At current x, find corners that achieve max_i and min_j.
                
                poly_i_vals = poly_i @ best_axis
                poly_j_vals = poly_j @ best_axis
                idx_i_max = np.argmax(poly_i_vals)
                idx_j_min = np.argmin(poly_j_vals)
                
                corner_i = poly_i[idx_i_max]
                corner_j = poly_j[idx_j_min]
                
                # Constraint: corner_i @ axis <= corner_j @ axis
                # Express corner_i as function of cx_i, cy_i, ang_i, side_i
                # corner_i = R(ang_i) * local_corner + [cx_i, cy_i]
                # We'll compute gradient numerically or analytically.
                # For simplicity, use numerical gradient of the function g(x) = corner_i @ axis - corner_j @ axis <= 0
                def g_func(x_local):
                    cx_i, cy_i, ang_i = x_local[3*i], x_local[3*i+1], x_local[3*i+2]
                    cx_j, cy_j, ang_j = x_local[3*j], x_local[3*j+1], x_local[3*j+2]
                    # compute corners
                    def get_corner(cx, cy, ang, side, local_idx):
                        d = side / 2.0
                        corners_local = np.array([[-d, -d], [d, -d], [d, d], [-d, d]])
                        c = math.cos(ang * 2.0 * math.pi)
                        s_ang = math.sin(ang * 2.0 * math.pi)
                        rot = np.array([[c, -s_ang], [s_ang, c]])
                        return rot @ corners_local[local_idx] + np.array([cx, cy])
                    ci = get_corner(cx_i, cy_i, ang_i, sides[i], idx_i_max)
                    cj = get_corner(cx_j, cy_j, ang_j, sides[j], idx_j_min)
                    return ci @ best_axis - cj @ best_axis
                
                # Evaluate gradient at x
                eps = 1e-7
                grad = np.zeros(3*n)
                f0 = g_func(x)
                for var_idx in range(3*n):
                    x_plus = x.copy()
                    x_plus[var_idx] += eps
                    grad[var_idx] = (g_func(x_plus) - f0) / eps
                
                # Constraint: grad @ (y - x) + f0 <= 0  => grad @ y <= grad @ x - f0
                ub = grad @ x - f0
                new_constraints.append((grad, -np.inf, ub))
                
        return new_constraints
    
    # Iterative cutting plane
    x = x0.copy()
    for iteration in range(max_iter):
        # Build all current linear constraints (initial box + accumulated)
        # We'll solve QP: minimize ||x - x0||^2 subject to linear constraints
        # But simpler: use scipy.optimize.minimize with constraints as NonlinearConstraint?
        
        # Since we only have linear constraints, SLSQP or trust-constr can handle.
        # We'll define constraints dynamically.
        
        # Collect all linear constraints
        A_list = []
        lb_list = []
        ub_list = []
        for (grad, lb, ub) in linear_constraints:
            A_list.append(grad)
            lb_list.append(lb)
            ub_list.append(ub)
        
        n_cons = len(A_list)
        
        def objective_f(x_var):
            return np.sum((x_var - x0)**2)  # minimize drift
        
        constraints = []
        if n_cons > 0:
            A_mat = np.vstack(A_list)
            lb_vec = np.array(lb_list)
            ub_vec = np.array(ub_list)
            linear_constraint = NonlinearConstraint(
                lambda x_var: A_mat @ x_var,
                lb_vec,
                ub_vec
            )
            constraints.append(linear_constraint)
        
        # Also ensure bounds
        res = minimize(objective_f, x, method='SLSQP', bounds=bounds, constraints=constraints,
                       options={'maxiter': 100, 'ftol': 1e-9})
        x_new = res.x
        
        # Check if feasible
        polys_new = []
        for i in range(n):
            cx, cy, ang = x_new[3*i], x_new[3*i+1], x_new[3*i+2]
            poly = _to_poly(cx, cy, ang, sides[i])
            if not _poly_inside_unit(poly):
                polys_new = None
                break
            polys_new.append(poly)
        
        feasible = True
        if polys_new is not None:
            for i in range(n):
                for j in range(i+1, n):
                    if sides[i] > 0 and sides[j] > 0:
                        if _poly_intersect(polys_new[i], polys_new[j]):
                            feasible = False
                            break
                if not feasible:
                    break
        else:
            feasible = False
        
        if feasible:
            # success
            centers_out = np.array([[x_new[3*i], x_new[3*i+1]] for i in range(n)])
            angles_out = np.array([x_new[3*i+2] for i in range(n)])
            return centers_out, angles_out, True
        
        # Add violated constraints
        new_cons = _build_overlap_constraints(x_new)
        if not new_cons:
            # stuck, maybe no overlap but bounding box violation?
            # try to fix bounding box via similar linear constraints
            for i in range(n):
                poly = _to_poly(x_new[3*i], x_new[3*i+1], x_new[3*i+2], sides[i])
                for corner in poly:
                    for dim in (0,1):
                        if corner[dim] < 0.0:
                            # require corner >= 0
                            grad = np.zeros(3*n)
                            # numerical gradient of corner coordinate
                            def f_corner(xx, idx, dim_):
                                return _to_poly(xx[3*idx], xx[3*idx+1], xx[3*idx+2], sides[idx])[corner_idx, dim_]
                            # which corner?
                            corner_idx = np.argmin(np.abs(_to_poly(x_new[3*i], x_new[3*i+1], x_new[3*i+2], sides[i]) - corner).sum(axis=1))
                            eps = 1e-7
                            f0 = corner[dim]
                            for k in range(3*n):
                                xp = x_new.copy()
                                xp[k] += eps
                                val = _to_poly(xp[3*i], xp[3*i+1], xp[3*i+2], sides[i])[corner_idx, dim]
                                grad[k] = (val - f0) / eps
                            new_cons.append((grad, 0.0, np.inf))
                        if corner[dim] > 1.0:
                            grad = np.zeros(3*n)
                            corner_idx = np.argmin(np.abs(_to_poly(x_new[3*i], x_new[3*i+1], x_new[3*i+2], sides[i]) - corner).sum(axis=1))
                            eps = 1e-7
                            f0 = corner[dim]
                            for k in range(3*n):
                                xp = x_new.copy()
                                xp[k] += eps
                                val = _to_poly(xp[3*i], xp[3*i+1], xp[3*i+2], sides[i])[corner_idx, dim]
                                grad[k] = (val - f0) / eps
                            new_cons.append((grad, -np.inf, 1.0))
        
        if not new_cons:
            # no progress
            break
        linear_constraints.extend(new_cons)
        x = x_new.copy()
        # remove duplicate constraints to keep size manageable
        if len(linear_constraints) > 100 * n:
            # keep most recent
            linear_constraints = linear_constraints[-50*n:]
    
    return np.zeros((n,2)), np.zeros(n), False

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n <= 4:
        k = int(math.isqrt(n))
        side = 1.0 / k
        sq = []
        for i in range(k):
            for j in range(k):
                cx = (i + 0.5) * side
                cy = (j + 0.5) * side
                sq.append((cx, cy, 0.0, side))
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        return sq[:n]
    
    # Staircase side lengths as target
    sides = _staircase_base(n)
    # Identify nonzero targets
    nonzero_indices = [i for i, s in enumerate(sides) if s > 1e-9]
    num_nonzero = len(nonzero_indices)
    
    if num_nonzero == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    
    # For nonzero squares, we'll try to pack them using circle-inspired initialization
    nonzero_sides = [sides[i] for i in nonzero_indices]
    
    # Place centers via circle packing with radii equal to half-diagonal of square
    radii = [s * np.sqrt(2) / 2.0 for s in nonzero_sides]
    
    # Simple circle packing inside [0,1]^2
    # We'll use force-directed with target radii
    centers_circle = _circle_initial(len(nonzero_sides))
    # Scale so that min distance between centers approximates sum of radii
    for _ in range(30):
        forces = np.zeros_like(centers_circle)
        for i in range(len(centers_circle)):
            for j in range(i+1, len(centers_circle)):
                dvec = centers_circle[i] - centers_circle[j]
                dist = np.linalg.norm(dvec)
                target = radii[i] + radii[j]
                if dist < 1e-6:
                    dist = 1e-4
                    dvec = np.random.randn(2) * 1e-4
                # if distance < target, push apart
                if dist < target:
                    f = (target - dist) / dist * dvec
                    forces[i] += f
                    forces[j] -= f
            # wall repulsion with radius
            for dim in (0,1):
                if centers_circle[i, dim] - radii[i] < 0.0:
                    forces[i, dim] += (radii[i] - centers_circle[i, dim])
                if centers_circle[i, dim] + radii[i] > 1.0:
                    forces[i, dim] -= (centers_circle[i, dim] + radii[i] - 1.0)
        centers_circle += 0.05 * forces
        centers_circle = np.clip(centers_circle, 0.0, 1.0)
    
    # Initial angles: 0
    initial_angles = np.zeros(len(nonzero_sides))
    
    # Attempt to pack the nonzero squares with cutting planes
    centers, angles, success = _solve_cutting_plane_iteration(
        nonzero_sides, centers_circle, initial_angles, max_iter=25
    )
    
    if not success:
        # fallback: try with smaller sides scaled down
        for scale in [0.95, 0.9, 0.8, 0.7]:
            scaled_sides = [s * scale for s in nonzero_sides]
            centers, angles, success = _solve_cutting_plane_iteration(
                scaled_sides, centers_circle, initial_angles, max_iter=15
            )
            if success:
                nonzero_sides = scaled_sides
                break
    
    # If still no success, use simple non-overlapping arrangement: line them up tiny
    if not success:
        tiny_side = 0.9 / len(nonzero_sides)
        tiny_sides = [tiny_side] * len(nonzero_sides)
        centers = np.zeros((len(nonzero_sides), 2))
        for idx, i in enumerate(nonzero_indices):
            centers[idx, 0] = (idx + 0.5) * 0.9 / len(nonzero_sides)
            centers[idx, 1] = 0.5
        angles = np.zeros(len(nonzero_sides))
        nonzero_sides = tiny_sides
        success = True
    
    # Now try to expand squares via binary search on uniform scaling
    current_sides = nonzero_sides.copy()
    current_centers = centers.copy()
    current_angles = angles.copy()
    
    lo_scale = 1.0
    hi_scale = 2.0  # upper bound: can't exceed 1.0 side
    for _ in range(8):
        mid = (lo_scale + hi_scale) / 2.0
        test_sides = [min(s * mid, 1.0) for s in nonzero_sides]
        c_new, a_new, ok = _solve_cutting_plane_iteration(
            test_sides, current_centers, current_angles, max_iter=10
        )
        if ok and all(s <= 1.0 for s in test_sides):
            lo_scale = mid
            current_sides = test_sides
            current_centers = c_new
            current_angles = a_new
        else:
            hi_scale = mid
    
    # Build final solution
    result = []
    nonzero_idx = 0
    for i in range(n):
        if sides[i] > 1e-9:
            cx = current_centers[nonzero_idx, 0]
            cy = current_centers[nonzero_idx, 1]
            ang = current_angles[nonzero_idx] % 1.0
            s = current_sides[nonzero_idx]
            result.append((cx, cy, ang, s))
            nonzero_idx += 1
        else:
            result.append((0.5, 0.5, 0.0, 0.0))
    
    # Final cleanup: ensure feasibility
    if _feasible(result):
        return result
    else:
        # attempt repair by shrinking
        for factor in [0.9, 0.8, 0.5]:
            shrunk = [(cx, cy, ang, s * factor) for (cx, cy, ang, s) in result]
            if _feasible(shrunk):
                return shrunk
        # worst: zeros
        return [(0.5, 0.5, 0.0, 0.0)] * n
