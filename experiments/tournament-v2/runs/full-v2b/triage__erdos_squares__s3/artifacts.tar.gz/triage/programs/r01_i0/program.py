# EVOLVE-BLOCK-START
"""Physics-inspired packing: random start + simulated annealing over (x, y, angle, size)."""
import math
import random


def _overlap_penalty(sq):
    """Return total penetration depth between all pairs plus wall excursions."""
    n = len(sq)
    pen = 0.0
    # squares as (cx, cy, ang, s)
    for i in range(n):
        xi, yi, ai, si = sq[i]
        if si <= 1e-12:
            continue
        ca = math.cos(ai * 2 * math.pi)
        sa = math.sin(ai * 2 * math.pi)
        hi = si * 0.5
        # half-extents projected on axes
        ex = abs(ca) * hi + abs(sa) * hi
        ey = abs(sa) * hi + abs(ca) * hi
        # wall violations
        for v in (ex - xi, xi + ex - 1.0, ey - yi, yi + ey - 1.0):
            if v > 0:
                pen += v * v
        for j in range(i + 1, n):
            xj, yj, aj, sj = sq[j]
            if sj <= 1e-12:
                continue
            cb = math.cos(aj * 2 * math.pi)
            sb = math.sin(aj * 2 * math.pi)
            hj = sj * 0.5
            fx = abs(cb) * hj + abs(sb) * hj
            fy = abs(sb) * hj + abs(cb) * hj
            dx = abs(xi - xj) - (ex + fx)
            dy = abs(yi - yj) - (ey + fy)
            if dx > 0 or dy > 0:
                continue
            # conservative overlap estimate
            ov = min(-dx, -dy)
            pen += ov * ov
    return pen


def _objective(sq):
    return sum(s[3] for s in sq) - 1e3 * _overlap_penalty(sq)


def _initial(n):
    """Greedy random non-overlapping axis-aligned equal squares, leftover size 0."""
    sq = []
    side = 1.0 / math.isqrt(n + 3)
    for _ in range(n):
        best = None
        best_pen = float('inf')
        for _t in range(40):
            x = random.uniform(side * 0.5, 1 - side * 0.5)
            y = random.uniform(side * 0.5, 1 - side * 0.5)
            trial = sq + [(x, y, 0.0, side)]
            p = _overlap_penalty(trial)
            if p < best_pen:
                best_pen = p
                best = (x, y, 0.0, side)
                if p <= 1e-15:
                    break
        sq.append(best if best is not None else (0.5, 0.5, 0.0, 0.0))
    return sq


def solve(n):
    random.seed(12345)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_sq = None
    best_val = -float('inf')

    for restart in range(6):
        sq = _initial(n)
        cur = _objective(sq)
        T = 0.06
        steps = 4000 + 400 * n
        for it in range(steps):
            T = 0.06 * (1.0 - it / steps) + 0.001
            i = random.randrange(n)
            x, y, a, s = sq[i]
            choice = random.random()
            nx, ny, na, ns = x, y, a, s
            if choice < 0.45:
                nx = min(1.0, max(0.0, x + random.gauss(0, 0.03 * T * 20)))
                ny = min(1.0, max(0.0, y + random.gauss(0, 0.03 * T * 20)))
            elif choice < 0.75:
                na = (a + random.gauss(0, 0.05)) % 1.0
            else:
                ns = min(1.0, max(0.0, s + random.gauss(0, 0.02)))
            if ns > 0:
                ns = min(ns, 1.0)
            old = sq[i]
            sq[i] = (nx, ny, na, ns)
            new = _objective(sq)
            if new >= cur or random.random() < math.exp((new - cur) / max(T, 1e-9)):
                cur = new
            else:
                sq[i] = old

        # local greedy polish on sizes
        for _ in range(600):
            i = random.randrange(n)
            x, y, a, s = sq[i]
            ns = min(1.0, s + random.gauss(0, 0.01))
            old = sq[i]
            sq[i] = (x, y, a, ns)
            new = _objective(sq)
            if new >= cur:
                cur = new
            else:
                sq[i] = old

        val = _objective(sq)
        if val > best_val:
            best_val = val
            best_sq = list(sq)

    # final repair: shrink any size-0 leftover problems, ensure result feasible
    sq = best_sq
    pen = _overlap_penalty(sq)
    if pen > 1e-9:
        # shrink all sides slightly and reclamp
        for k in range(30):
            if pen <= 1e-9:
                break
            f = 0.98
            sq = [(x, y, a, s * f) for (x, y, a, s) in sq]
            pen = _overlap_penalty(sq)
    return [(min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), a % 1.0, min(1.0, max(0.0, s)))
            for (x, y, a, s) in sq]
# EVOLVE-BLOCK-END

