import math
import random
import numpy as np
from scipy.optimize import minimize

# ----------------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------------

def _to_poly(center, angle, side):
    """Return 4 corner points of a square (as np.array)."""
    cx, cy = center
    d = side / 2.0
    corners = np.array([[-d, -d], [d, -d], [d, d], [-d, d]])
    c = math.cos(angle * 2.0 * math.pi)
    s = math.sin(angle * 2.0 * math.pi)
    rot = np.array([[c, -s], [s, c]])
    rot_corners = corners @ rot.T
    rot_corners += np.array([cx, cy])
    return rot_corners


def _poly_intersect(poly1, poly2, tol=1e-9):
    """Separating Axis Theorem for convex polygons (strict interior overlap)."""
    for poly in (poly1, poly2):
        n = len(poly)
        for i in range(n):
            p1 = poly[i]
            p2 = poly[(i + 1) % n]
            edge = p2 - p1
            normal = np.array([-edge[1], edge[0]])
            proj1 = poly1 @ normal
            proj2 = poly2 @ normal
            if proj1.max() <= proj2.min() + tol or proj2.max() <= proj1.min() + tol:
                return False
    return True


def _poly_inside_unit(poly, tol=1e-9):
    return np.all((poly >= -tol) & (poly <= 1.0 + tol))


def _feasible(squares, tol=1e-9):
    polys = []
    for (cx, cy, ang, s) in squares:
        if s < -tol:
            return False
        if s <= tol:
            continue
        poly = _to_poly((cx, cy), ang, s)
        if not _poly_inside_unit(poly, tol):
            return False
        polys.append(poly)
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if _poly_intersect(polys[i], polys[j], tol):
                return False
    return True


def _clamp_to_unit(cx, cy, ang, s):
    """Shift square minimally to fit inside unit square; return clamped or None."""
    if s <= 0:
        return (0.5, 0.5, 0.0, 0.0)
    if s > 1.0:
        return None
    # axis-aligned bounding box half-extent of rotated square
    c = math.cos(ang * 2.0 * math.pi)
    si = math.sin(ang * 2.0 * math.pi)
    # rotated square of side s: extents = s/2*(|c|+|s|) along each axis
    extend = (s / 2.0) * (abs(c) + abs(si))
    cx = min(max(cx, extend), 1.0 - extend)
    cy = min(max(cy, extend), 1.0 - extend)
    return (cx, cy, ang % 1.0, s)


# ----------------------------------------------------------------------------
# Staircase construction (optimal for triangular numbers)
# ----------------------------------------------------------------------------

def _triangular(k):
    return k * (k + 1) // 2


def _staircase(n):
    k = 1
    while _triangular(k) <= n:
        k += 1
    k -= 1
    if k < 1:
        k = 1
    Tk = _triangular(k)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k - i):
            cx = j * side + side / 2
            cy = i * side + side / 2
            squares.append((cx, cy, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


# ----------------------------------------------------------------------------
# Greedy packing
# ----------------------------------------------------------------------------

def _poly_bound_radius(s):
    return s * math.sqrt(2) / 2.0


def _largest_free_square(existing, trials=60, rng=None):
    """
    Find (approximately) the largest square that can be added among existing
    squares. Uses random sampling of centres/angles from a distribution that
    is biased towards gaps. Returns (cx, cy, ang, side) or None.
    """
    if rng is None:
        rng = random.Random(0)
    existing_polys = [_to_poly((c[0], c[1]), c[2], c[3]) for c in existing if c[3] > 1e-9]
    best = None
    # Sample candidate centers: random + midpoints between pairs
    candidates = []
    for _ in range(trials):
        candidates.append((rng.uniform(0.05, 0.95), rng.uniform(0.05, 0.95)))
    for i in range(len(existing)):
        for j in range(i + 1, len(existing)):
            candidates.append(((existing[i][0] + existing[j][0]) / 2,
                               (existing[i][1] + existing[j][1]) / 2))
    for k in range(len(existing)):
        candidates.append((existing[k][0], existing[k][1]))
        candidates.append((existing[k][0] + (0.5 - existing[k][0]) * 0.5,
                           existing[k][1] + (0.5 - existing[k][1]) * 0.5))
    candidates.append((0.5, 0.5))
    rng.shuffle(candidates)
    angles = [0.0, 0.125, 0.25, 0.375, 0.0625, 0.1875]

    for (cx, cy) in candidates:
        for ang in angles:
            # Determine upper bound on side
            lo = 0.0
            # A square of side s has bounding half-extent s/2*(|c|+|s|)
            c = math.cos(ang * 2 * math.pi)
            si = math.sin(ang * 2 * math.pi)
            ext_factor = abs(c) + abs(si)
            # fit within unit square
            x_slack = min(cx, 1.0 - cx) * 2.0 / ext_factor
            y_slack = min(cy, 1.0 - cy) * 2.0 / ext_factor
            hi = min(x_slack, y_slack, 1.0)
            if hi <= (best[3] if best else 1e-9):
                continue
            # crude separation bound using existing centers
            for (ox, oy, oang, os) in existing:
                if os <= 1e-9:
                    continue
                d = math.hypot(cx - ox, cy - oy)
                # conservative: no overlap if distance > sum of diagonal halfs
                min_dist = (os + hi) * math.sqrt(2) / 2.0
                if d < min_dist:
                    hi = max(0.0, d * 2.0 / math.sqrt(2) - os)
                    if hi <= (best[3] if best else 1e-9):
                        break
            if hi <= (best[3] if best else 1e-9):
                continue
            # binary search
            for _ in range(20):
                mid = (lo + hi) / 2.0
                if mid <= 1e-9:
                    lo = mid
                    break
                poly = _to_poly((cx, cy), ang, mid)
                ok = _poly_inside_unit(poly)
                if ok:
                    for p in existing_polys:
                        if _poly_intersect(poly, p):
                            ok = False
                            break
                if ok:
                    lo = mid
                else:
                    hi = mid
            if lo > 1e-7:
                if best is None or lo > best[3]:
                    best = (cx, cy, ang, lo)
    return best


def _greedy_solution(n, seed=0):
    rng = random.Random(seed)
    if n <= 0:
        return []
    # start from staircase
    base = _staircase(n)
    squares = [s for s in base if s[3] > 1e-9]
    while len(squares) < n:
        cand = _largest_free_square(squares, trials=48, rng=rng)
        if cand is None or cand[3] < 1e-7:
            squares.append((0.5, 0.5, 0.0, 0.0))
        else:
            squares.append(cand)
    return squares[:n]


# ----------------------------------------------------------------------------
# Repair: given a list of squares (possibly infeasible), shrink overlapping
# ones and shift them, then re-expand.
# ----------------------------------------------------------------------------

def _repair(squares, rng):
    squares = [list(s) for s in squares]
    # first, clamp positions inside unit square by shrinking if necessary
    for i, s in enumerate(squares):
        cx, cy, ang, side = s
        if side <= 1e-12:
            squares[i] = [0.5, 0.5, 0.0, 0.0]
            continue
        c = math.cos(ang * 2 * math.pi)
        si = math.sin(ang * 2 * math.pi)
        ext_factor = (abs(c) + abs(si)) / 2.0
        # max side that fits at this center
        max_side = min(cx, 1 - cx, cy, 1 - cy) / max(ext_factor, 1e-12)
        if side > max_side + 1e-12:
            side = max_side
        squares[i] = [cx, cy, ang % 1.0, max(0.0, side)]

    # iterative separation of overlaps
    for _ in range(50):
        # find worst overlap
        worst = None
        worst_pen = 0.0
        for i in range(len(squares)):
            if squares[i][3] <= 1e-12:
                continue
            pi = _to_poly((squares[i][0], squares[i][1]), squares[i][2], squares[i][3])
            for j in range(i + 1, len(squares)):
                if squares[j][3] <= 1e-12:
                    continue
                pj = _to_poly((squares[j][0], squares[j][1]), squares[j][2], squares[j][3])
                if _poly_intersect(pi, pj):
                    # estimate overlap by center distance
                    d = math.hypot(squares[i][0] - squares[j][0],
                                   squares[i][1] - squares[j][1])
                    need = (squares[i][3] + squares[j][3]) * math.sqrt(2) / 2.0
                    pen = (need - d)
                    if pen > worst_pen:
                        worst_pen = pen
                        worst = (i, j)
        if worst is None:
            break
        i, j = worst
        # separate centres
        xi, yi = squares[i][0], squares[i][1]
        xj, yj = squares[j][0], squares[j][1]
        dx, dy = xi - xj, yi - yj
        d = math.hypot(dx, dy) + 1e-12
        need = (squares[i][3] + squares[j][3]) * math.sqrt(2) / 2.0
        push = (need - d) / 2.0 + 1e-6
        ux, uy = dx / d, dy / d
        squares[i][0] += ux * push
        squares[i][1] += uy * push
        squares[j][0] -= ux * push
        squares[j][1] -= uy * push
        # shrink smaller one a bit
        if squares[i][3] < squares[j][3]:
            squares[i][3] *= 0.995
        else:
            squares[j][3] *= 0.995
        # re-clamp
        for k in (i, j):
            cx, cy, ang, side = squares[k]
            if side <= 1e-12:
                squares[k] = [0.5, 0.5, 0.0, 0.0]
                continue
            c = math.cos(ang * 2 * math.pi)
            si = math.sin(ang * 2 * math.pi)
            ext_factor = (abs(c) + abs(si)) / 2.0
            max_side = min(cx, 1 - cx, cy, 1 - cy) / max(ext_factor, 1e-12)
            if side > max_side:
                side = max_side
            squares[k] = [cx, cy, ang % 1.0, max(0.0, side)]

    # Random perturbation to escape deadlocks
    for k in range(len(squares)):
        if squares[k][3] <= 1e-12:
            continue
        if rng.random() < 0.3:
            squares[k][0] += rng.gauss(0, 0.01)
            squares[k][1] += rng.gauss(0, 0.01)
            cx, cy, ang, side = squares[k]
            c = math.cos(ang * 2 * math.pi)
            si = math.sin(ang * 2 * math.pi)
            ext_factor = (abs(c) + abs(si)) / 2.0
            cx = min(max(cx, ext_factor * side), 1 - ext_factor * side)
            cy = min(max(cy, ext_factor * side), 1 - ext_factor * side)
            squares[k] = [cx, cy, ang, side]

    return [tuple(s) for s in squares]


def _expand_squares(squares, rng, steps=6):
    """
    After repair, try to expand squares. Greedily grow each square when possible.
    """
    squares = [list(s) for s in squares]
    total = sum(s[3] for s in squares)
    improved = True
    it = 0
    while improved and it < steps:
        improved = False
        it += 1
        # try growing each square
        order = list(range(len(squares)))
        rng.shuffle(order)
        for idx in order:
            if squares[idx][3] <= 1e-12:
                continue
            cx, cy, ang, side = squares[idx]
            # binary search on max side at this position
            lo = side
            c = math.cos(ang * 2 * math.pi)
            si = math.sin(ang * 2 * math.pi)
            ext_factor = (abs(c) + abs(si)) / 2.0
            hi = min(cx, 1 - cx, cy, 1 - cy) / max(ext_factor, 1e-12)
            if hi <= lo + 1e-12:
                continue
            best = side
            for _ in range(18):
                mid = (lo + hi) / 2.0
                if mid <= 1e-12:
                    break
                poly = _to_poly((cx, cy), ang, mid)
                ok = _poly_inside_unit(poly)
                if ok:
                    for k, other in enumerate(squares):
                        if k == idx or other[3] <= 1e-12:
                            continue
                        other_poly = _to_poly((other[0], other[1]), other[2], other[3])
                        if _poly_intersect(poly, other_poly):
                            ok = False
                            break
                if ok:
                    best = mid
                    lo = mid
                else:
                    hi = mid
            if best > side + 1e-6:
                squares[idx][3] = best
                improved = True
        # try shifting to gain
        for idx in order:
            if squares[idx][3] <= 1e-12:
                continue
            cx, cy, ang, side = squares[idx]
            best_cx, best_cy = cx, cy
            best_side = side
            for _ in range(4):
                nx = cx + rng.gauss(0, 0.015)
                ny = cy + rng.gauss(0, 0.015)
                c = math.cos(ang * 2 * math.pi)
                si = math.sin(ang * 2 * math.pi)
                ext_factor = (abs(c) + abs(si)) / 2.0
                nx = min(max(nx, ext_factor * side), 1 - ext_factor * side)
                ny = min(max(ny, ext_factor * side), 1 - ext_factor * side)
                hi = min(nx, 1 - nx, ny, 1 - ny) / max(ext_factor, 1e-12)
                if hi <= side + 1e-9:
                    continue
                lo2 = side
                hi2 = hi
                local_best = side
                for _ in range(14):
                    mid = (lo2 + hi2) / 2.0
                    poly = _to_poly((nx, ny), ang, mid)
                    ok = _poly_inside_unit(poly)
                    if ok:
                        for k, other in enumerate(squares):
                            if k == idx or other[3] <= 1e-12:
                                continue
                            other_poly = _to_poly((other[0], other[1]), other[2], other[3])
                            if _poly_intersect(poly, other_poly):
                                ok = False
                                break
                    if ok:
                        local_best = mid
                        lo2 = mid
                    else:
                        hi2 = mid
                if local_best > best_side + 1e-6:
                    best_side = local_best
                    best_cx, best_cy = nx, ny
            if best_side > side + 1e-6:
                squares[idx] = [best_cx, best_cy, ang, best_side]
                improved = True
    return [tuple(s) for s in squares]


# ----------------------------------------------------------------------------
# Crossover: exchange subsets of squares between parents then repair.
# ----------------------------------------------------------------------------

def _crossover(p1, p2, rng):
    n = len(p1)
    if n == 0:
        return []
    # sort each parent by size descending
    idx1 = sorted(range(n), key=lambda i: -p1[i][3])
    idx2 = sorted(range(n), key=lambda i: -p2[i][3])
    # take top-k from p1 and the rest from p2
    k = rng.randint(1, max(1, n - 1))
    child_sq = [p1[i] for i in idx1[:k]]
    # choose remaining from parent 2 (any that are non-zero)
    remaining = [p2[i] for i in idx2[k:]]
    # fill to n
    while len(child_sq) + len(remaining) < n:
        remaining.append((0.5, 0.5, 0.0, 0.0))
    child = child_sq + remaining
    child = child[:n]
    # mutation
    for i in range(len(child)):
        cx, cy, ang, side = child[i]
        if rng.random() < 0.3:
            cx += rng.gauss(0, 0.02)
            cy += rng.gauss(0, 0.02)
        if rng.random() < 0.3:
            ang = (ang + rng.gauss(0, 0.05)) % 1.0
        if rng.random() < 0.3 and side > 0:
            side = max(0.0, side * (1.0 + rng.gauss(0, 0.05)))
        # clamp
        result = _clamp_to_unit(cx, cy, ang, side)
        if result is None:
            result = (0.5, 0.5, ang, min(side, 1.0))
            result = _clamp_to_unit(*result)
            if result is None:
                result = (0.5, 0.5, 0.0, 0.0)
        child[i] = result
    child = _repair(child, rng)
    child = _expand_squares(child, rng)
    child = _repair(child, rng)
    return child


# ----------------------------------------------------------------------------
# Fitness
# ----------------------------------------------------------------------------

def _fitness(squares):
    return sum(s[3] for s in squares)


# ----------------------------------------------------------------------------
# Main evolutionary loop
# ----------------------------------------------------------------------------

def _evolve(n, time_limit_fraction=1.0, seed=0):
    rng = random.Random(seed)
    np.random.seed(seed)

    # initial population
    pop_size = max(12, min(4 * n, 60))
    population = []

    # seed with staircase-based greedy
    base = _staircase(n)
    base = _repair(base, rng)
    base = _expand_squares(base, rng)
    base = _repair(base, rng)
    population.append(base)

    for _ in range(pop_size - 1):
        s = _greedy_solution(n, seed=rng.randint(0, 10 ** 6))
        s = _repair(s, rng)
        s = _expand_squares(s, rng)
        s = _repair(s, rng)
        population.append(s)

    def score(sq):
        return _fitness(sq)

    population.sort(key=score, reverse=True)
    best = population[0]
    best_score = score(best)

    # main loop
    generations = 0
    no_improve = 0
    max_generations = 400
    while generations < max_generations:
        generations += 1
        pop_size = max(12, min(4 * n, 60))
        # selection: tournament
        new_pop = []
        # elitism
        new_pop.append(best)
        new_pop.append(population[0])
        while len(new_pop) < pop_size:
            # tournament
            a = rng.randrange(len(population))
            b = rng.randrange(len(population))
            parent1 = population[a] if score(population[a]) >= score(population[b]) else population[b]
            a = rng.randrange(len(population))
            b = rng.randrange(len(population))
            parent2 = population[a] if score(population[a]) >= score(population[b]) else population[b]
            if rng.random() < 0.9:
                child = _crossover(parent1, parent2, rng)
            else:
                # mutation of one parent
                child = list(parent1)
                child = _repair(child, rng)
                child = _expand_squares(child, rng)
                child = _repair(child, rng)
            new_pop.append(child)
        population = new_pop
        population.sort(key=score, reverse=True)
        if score(population[0]) > best_score + 1e-6:
            best_score = score(population[0])
            best = population[0]
            no_improve = 0
        else:
            no_improve += 1
        if no_improve > 40:
            # restart with fresh individuals
            k = pop_size // 2
            for _ in range(k):
                s = _greedy_solution(n, seed=rng.randint(0, 10 ** 6))
                s = _repair(s, rng)
                s = _expand_squares(s, rng)
                s = _repair(s, rng)
                population[-( _ + 1)] = s
            population.sort(key=score, reverse=True)
            no_improve = 0
    return best


# ----------------------------------------------------------------------------
# Marginal improvement: local search by re-arranging square positions
# ----------------------------------------------------------------------------

def _local_search(squares, rng, iterations=200):
    squares = [list(s) for s in squares]
    best = [list(s) for s in squares]
    best_score = sum(s[3] for s in squares)
    for it in range(iterations):
        cand = [list(s) for s in best]
        # pick a random square and shift / rotate
        i = rng.randrange(len(cand))
        cx, cy, ang, side = cand[i]
        cx += rng.gauss(0, 0.02)
        cy += rng.gauss(0, 0.02)
        ang = (ang + rng.gauss(0, 0.08)) % 1.0
        # clamp
        res = _clamp_to_unit(cx, cy, ang, side)
        if res is None:
            continue
        cand[i] = list(res)
        cand = [list(s) for s in _repair(cand, rng)]
        cand = [list(s) for s in _expand_squares(cand, rng)]
        cand = [list(s) for s in _repair(cand, rng)]
        sc = sum(s[3] for s in cand)
        if sc > best_score + 1e-7:
            best_score = sc
            best = cand
    return [tuple(s) for s in best]


# ----------------------------------------------------------------------------
# Public solve
# ----------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two 0.5 squares side by side (or diagonal), best sum = 1.0
        # actually place side by side: 0.5 each -> sum 1.0
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 2x2 grid without one corner
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s), (0.5, 0.75, 0.0, s)]
    if n == 4:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s),
                (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s)]

    # For larger n, run several seeds of the evolutionary algorithm and
    # take the best.
    best = None
    best_score = -1.0

    # seed deterministic starting solutions
    # Try staircase-based approach if n is triangular
    T = _triangular(int(round((math.sqrt(8 * n + 1) - 1) / 2)))
    if T == n:
        k = int(round((math.sqrt(8 * n + 1) - 1) / 2))
        s = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k - i):
                squares.append((j * s + s / 2, i * s + s / 2, 0.0, s))
        if _feasible(squares):
            sc = _fitness(squares)
            if sc > best_score:
                best_score = sc
                best = squares

    # multiple evolutionary runs with different seeds
    seeds = [0, 1, 2, 3, 4, 5, 7, 11, 13, 17]
    for si, seed in enumerate(seeds):
        rng = random.Random(seed * 12345 + n * 7919)
        result = _evolve(n, seed=seed * 12345 + n * 7919)
        # local search refinement
        result = _local_search(result, rng, iterations=60 + 4 * n)
        result = _expand_squares(result, rng, steps=8)
        result = _repair(result, rng)
        # ensure feasibility
        if not _feasible(result):
            # fall back to repair
            result = _repair(result, rng)
        # final expansion and repair loop
        improved = True
        iters = 0
        while improved and iters < 3:
            iters += 1
            prev = sum(s[3] for s in result)
            result = _expand_squares(result, rng, steps=4)
            result = _repair(result, rng)
            now = sum(s[3] for s in result)
            if now <= prev + 1e-9:
                improved = False
        sc = _fitness(result)
        if sc > best_score:
            best_score = sc
            best = result

    if best is None:
        best = _greedy_solution(n, seed=0)

    # make sure we return exactly n squares
    if len(best) < n:
        best = list(best) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    best = list(best)[:n]

    # final safety check + cleanup
    cleaned = []
    for (cx, cy, ang, side) in best:
        cx = float(min(max(cx, 0.0), 1.0))
        cy = float(min(max(cy, 0.0), 1.0))
        ang = float(ang % 1.0)
        side = float(max(side, 0.0))
        if side > 1e-9:
            res = _clamp_to_unit(cx, cy, ang, side)
            if res is None:
                side = 0.0
            else:
                cx, cy, ang, side = res
        else:
            side = 0.0
        cleaned.append((cx, cy, ang, side))

    if not _feasible(cleaned):
        # reduce sizes until feasible
        for _ in range(200):
            if _feasible(cleaned):
                break
            cleaned = _repair(cleaned, random.Random(0))
    return cleaned


if __name__ == "__main__":
    for n in [5, 6, 7, 8, 11, 12, 13, 14, 15]:
        sol = solve(n)
        print(f"n={n}: sum={sum(s for _, _, _, s in sol):.4f}, feasible={_feasible(sol)}")
