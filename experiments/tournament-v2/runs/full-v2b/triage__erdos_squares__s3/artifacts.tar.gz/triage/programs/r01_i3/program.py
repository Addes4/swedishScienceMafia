import numpy as np
from scipy.optimize import minimize, Bounds
from scipy.spatial import ConvexHull
import random
import math


def get_square_vertices(center_x, center_y, angle, side):
    """Get vertices of a square given center, angle (fraction of full turn), and side length."""
    theta = angle * 2 * math.pi
    half = side / 2.0
    
    # Local coordinates of vertices (before rotation)
    local_verts = np.array([[-half, -half],
                            [half, -half],
                            [half, half],
                            [-half, half]])
    
    # Rotation matrix
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    rot = np.array([[cos_t, -sin_t], [sin_t, cos_t]])
    
    # Transform vertices
    verts = local_verts @ rot.T + np.array([center_x, center_y])
    return verts


def separating_axis_theorem(verts1, verts2):
    """Check if two convex polygons overlap using SAT. Returns overlap distance (negative if separated)."""
    # Check axes from both polygons
    for verts in [verts1, verts2]:
        for i in range(len(verts)):
            # Get edge vector
            edge = verts[(i + 1) % len(verts)] - verts[i]
            # Get perpendicular axis
            axis = np.array([-edge[1], edge[0]])
            axis = axis / np.linalg.norm(axis)
            
            # Project both polygons onto axis
            proj1 = verts1 @ axis
            proj2 = verts2 @ axis
            
            min1, max1 = proj1.min(), proj1.max()
            min2, max2 = proj2.min(), proj2.max()
            
            # Check separation
            if max1 < min2 or max2 < min1:
                # Separated - return negative overlap (positive separation)
                separation = min(abs(min2 - max1), abs(min1 - max2))
                return -separation
    
    # No separating axis found - polygons overlap
    # Calculate overlap depth
    min_overlap = float('inf')
    for verts in [verts1, verts2]:
        for i in range(len(verts)):
            edge = verts[(i + 1) % len(verts)] - verts[i]
            axis = np.array([-edge[1], edge[0]])
            axis = axis / np.linalg.norm(axis)
            
            proj1 = verts1 @ axis
            proj2 = verts2 @ axis
            
            min1, max1 = proj1.min(), proj1.max()
            min2, max2 = proj2.min(), proj2.max()
            
            overlap = min(max1 - min2, max2 - min1)
            if overlap > 0:
                min_overlap = min(min_overlap, overlap)
    
    return min_overlap if min_overlap != float('inf') else -1.0


def squares_in_box_constraint(center_x, center_y, angle, side):
    """Check if square is inside [0,1]x[0,1]. Returns negative if fully inside."""
    verts = get_square_vertices(center_x, center_y, angle, side)
    max_penetration = 0.0
    
    for v in verts:
        # Check bounds
        for coord, low, high in [(v[0], 0.0, 1.0), (v[1], 0.0, 1.0)]:
            if coord < low:
                max_penetration = max(max_penetration, low - coord)
            elif coord > high:
                max_penetration = max(max_penetration, coord - high)
    
    return -max_penetration if max_penetration == 0 else max_penetration


def objective_and_constraints(x, n):
    """Compute objective (negative sum of sides) and constraint violations."""
    squares = []
    for i in range(n):
        cx = x[i*4]
        cy = x[i*4 + 1]
        angle = x[i*4 + 2]
        side = x[i*4 + 3]
        squares.append((cx, cy, angle, side))
    
    # Objective: maximize sum of sides (minimize negative sum)
    obj = -sum(s[3] for s in squares)
    
    # Constraint violations
    violations = []
    
    # Containment constraints
    for i, (cx, cy, angle, side) in enumerate(squares):
        if side > 0:
            viol = squares_in_box_constraint(cx, cy, angle, side)
            violations.append(max(0, viol))
    
    # Non-overlap constraints
    for i in range(n):
        for j in range(i+1, n):
            s1 = squares[i]
            s2 = squares[j]
            if s1[3] > 0 and s2[3] > 0:
                verts1 = get_square_vertices(s1[0], s1[1], s1[2], s1[3])
                verts2 = get_square_vertices(s2[0], s2[1], s2[2], s2[3])
                overlap = separating_axis_theorem(verts1, verts2)
                violations.append(max(0, overlap * 10))  # Scale up overlap penalty
    
    # Penalty for invalid angles and sides
    for i in range(n):
        angle = x[i*4 + 2]
        side = x[i*4 + 3]
        violations.append(max(0, -angle) * 1000)
        violations.append(max(0, angle - 1.0) * 1000)
        violations.append(max(0, -side) * 1000)
    
    return obj, sum(violations)


def objective_func(x, n, penalty_weight=1000.0):
    """Objective function with penalty for constraint violations."""
    obj, viol = objective_and_constraints(x, n)
    return obj + penalty_weight * viol


def create_initial_guess(n, seed=None):
    """Create an initial guess for optimization."""
    if seed is not None:
        np.random.seed(seed)
        random.seed(seed)
    
    # Start with a grid-based layout
    grid_size = math.ceil(math.sqrt(n))
    init_side = 0.8 / grid_size  # Slightly smaller to allow movement
    
    x_init = []
    for i in range(grid_size):
        for j in range(grid_size):
            if len(x_init) // 4 < n:
                # Add some randomness to break symmetry
                cx = (i + 0.5) / grid_size + random.uniform(-0.05, 0.05)
                cy = (j + 0.5) / grid_size + random.uniform(-0.05, 0.05)
                angle = random.uniform(0, 1.0)
                side = init_side * random.uniform(0.8, 1.2)
                
                # Clamp to [0,1]
                cx = max(0.1, min(0.9, cx))
                cy = max(0.1, min(0.9, cy))
                side = max(0.01, min(0.5, side))
                
                x_init.extend([cx, cy, angle, side])
    
    # Pad if necessary
    while len(x_init) // 4 < n:
        x_init.extend([0.5, 0.5, 0.0, 0.01])
    
    return np.array(x_init[:n*4])


def solve_nlp(n, max_attempts=5):
    """Solve the NLP problem with multiple random starts."""
    best_obj = float('inf')
    best_x = None
    
    for attempt in range(max_attempts):
        x0 = create_initial_guess(n, seed=42 * n + attempt * 137)
        
        # Bounds
        bounds = []
        for i in range(n):
            bounds.extend([
                (0.0, 1.0),  # center_x
                (0.0, 1.0),  # center_y
                (0.0, 1.0),  # angle (fraction of full turn)
                (0.0, 1.0)   # side length
            ])
        
        # Use SLSQP for constrained optimization
        try:
            # First attempt: use constraints directly
            constraints = []
            
            # Containment constraints
            for i in range(n):
                constraints.append({
                    'type': 'ineq',
                    'fun': lambda x, idx=i: containment_constraint_single(x, idx)
                })
            
            # Limited constraints for performance
            if n <= 12:  # For small n, include non-overlap constraints
                for i in range(n):
                    for j in range(i+1, n):
                        constraints.append({
                            'type': 'ineq',
                            'fun': lambda x, i=i, j=j: non_overlap_constraint_single(x, i, j)
                        })
            
            # Objective
            def obj_fun(x):
                return -sum(x[i*4 + 3] for i in range(n))
            
            result = minimize(
                obj_fun,
                x0,
                method='SLSQP' if n <= 12 else 'L-BFGS-B',
                bounds=bounds,
                constraints=constraints if n <= 12 else (),
                options={'maxiter': 200, 'ftol': 1e-8, 'disp': False}
            )
            
            if result.success or result.fun < best_obj:
                x_opt = result.x
                
                # Verify solution quality
                obj, viol = objective_and_constraints(x_opt, n)
                if viol < 1e-4 and -obj > -best_obj:
                    best_obj = obj
                    best_x = x_opt.copy()
        
        except Exception as e:
            continue
    
    # If optimization failed, fall back to grid solution
    if best_x is None:
        return solve_grid_fallback(n)
    
    return best_x


def containment_constraint_single(x, idx):
    """Constraint: square i must be inside [0,1]x[0,1]."""
    cx = x[idx*4]
    cy = x[idx*4 + 1]
    angle = x[idx*4 + 2]
    side = x[idx*4 + 3]
    
    if side <= 0:
        return 0
    
    verts = get_square_vertices(cx, cy, angle, side)
    
    # Return minimum distance to boundary (positive if inside)
    min_dist = float('inf')
    for v in verts:
        min_dist = min(min_dist, v[0], v[1], 1 - v[0], 1 - v[1])
    
    return min_dist


def non_overlap_constraint_single(x, i, j):
    """Constraint: squares i and j must not overlap."""
    s1 = (x[i*4], x[i*4+1], x[i*4+2], x[i*4+3])
    s2 = (x[j*4], x[j*4+1], x[j*4+2], x[j*4+3])
    
    if s1[3] <= 0 or s2[3] <= 0:
        return 0
    
    verts1 = get_square_vertices(*s1)
    verts2 = get_square_vertices(*s2)
    
    overlap = separating_axis_theorem(verts1, verts2)
    
    # Return positive if separated, negative if overlapping
    return -overlap


def solve_grid_fallback(n):
    """Fallback: grid-based solution."""
    k = math.isqrt(n)
    side = 1.0 / k
    x_opt = []
    for i in range(k):
        for j in range(k):
            if len(x_opt) // 4 < n:
                x_opt.extend([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    
    while len(x_opt) // 4 < n:
        x_opt.extend([0.5, 0.5, 0.0, 0.0])
    
    return np.array(x_opt[:n*4])


def optimize_local(x_init, n, iterations=10):
    """Local optimization to refine solution."""
    x = x_init.copy()
    
    for _ in range(iterations):
        # Gradient-free local search
        for i in range(n):
            for param in range(3):  # Don't perturb angle initially
                orig = x[i*4 + param]
                for delta in [-0.01, 0.01]:
                    x[i*4 + param] = orig + delta
                    x[i*4 + param] = max(0, min(1, x[i*4 + param]))
                    
                    obj_new, viol_new = objective_and_constraints(x, n)
                    obj_old, viol_old = objective_and_constraints(x_init, n)
                    
                    if viol_new < 1e-6 and obj_new < obj_old:
                        x_init = x.copy()
                    else:
                        x[i*4 + param] = orig
    
    return x


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    
    if n <= 4:
        # For very small n, use simple grid
        side = 1.0 if n == 1 else 0.5
        squares = []
        if n == 1:
            squares.append((0.5, 0.5, 0.0, min(1.0, side)))
        else:
            positions = [(0.25, 0.25), (0.75, 0.25), (0.25, 0.75), (0.75, 0.75)]
            for i in range(n):
                squares.append((positions[i][0], positions[i][1], 0.0, side))
        
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        return squares[:n]
    
    # Solve using NLP
    try:
        x_opt = solve_nlp(n, max_attempts=3 if n > 10 else 5)
        
        # Extract solution
        squares = []
        for i in range(n):
            cx = x_opt[i*4]
            cy = x_opt[i*4 + 1]
            angle = x_opt[i*4 + 2]
            side = x_opt[i*4 + 3]
            
            # Clamp values
            cx = max(0.0, min(1.0, cx))
            cy = max(0.0, min(1.0, cy))
            angle = max(0.0, min(1.0, angle))
            side = max(0.0, min(1.0, side))
            
            squares.append((cx, cy, angle, side))
        
        return squares
        
    except Exception as e:
        # Fallback to grid
        k = math.isqrt(n)
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) 
                   for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        return squares[:n]
