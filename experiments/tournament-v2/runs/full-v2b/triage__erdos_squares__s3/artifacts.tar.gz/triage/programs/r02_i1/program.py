import math
import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint
from scipy.spatial import cKDTree

def square_corners(cx, cy, angle, side):
    """Return 4 corner points of square given center, angle, side."""
    half_diag = side / 2.0 * math.sqrt(2)
    half_side = side / 2.0
    cos_a = math.cos(2 * math.pi * angle)
    sin_a = math.sin(2 * math.pi * angle)
    rx = half_side * cos_a - half_side * sin_a
    ry = half_side * sin_a + half_side * cos_a
    rot_mat = np.array([[cos_a, -sin_a], [sin_a, cos_a]])
    relative = np.array([[-right and -up],
                         [right and -up],
                         [right and up],
                         [-right and up]][2:], _up, _left, _right])
    return np.array([cx+0, cy+0, cx+1, cy+1])
