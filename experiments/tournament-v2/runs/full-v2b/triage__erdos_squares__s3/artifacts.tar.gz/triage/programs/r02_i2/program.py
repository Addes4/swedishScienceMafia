import math
import numpy as np
from scipy.optimize import minimize, Bounds
from scipy.spatial import ConvexHull

def _to_corners(cx, cy, angle, side):
    """Return 4 corner points of square (as np.array)."""
    cx, cy, ang, s = cx, cy, angle, side
    d = s / 2.0
    corners = np.array([[-d, -d], [d, -d], [d, d], [-d, d]])
    c = math.cos(ang * 2 * math.pi)
    s_val = math.sin(ang * 2 * math.pi)
    rot = np.array([[c, -s_val], [s_val, c]])
    return corners @ rot.T + np.array([cx, cy])

def _corners_inside_unit(poly, eps=1e-9):
    """Check if all corners of poly are inside [0,1]x[0,1]."""
    if poly.shape[0] == 0:
        return True
    return np.all((poly[:, 0] >= -eps) & (poly[:, 0] <= 1 + eps))

def _poly_distance(poly1, poly2):
    """Minimum distance between two convex polygons along their bounding boxes."""
    # Simplified: use center to center with half-sum of diagonals
    c1 = np.mean(poly1, axis=0)
    c2 = np.mean(poly2, axis=0)
    return np.linalg.norm(c1 - c2)

def _box_overlap(poly1, poly2):
    """Check if two convex polygons overlap (strict interior intersection)."""
    # Separating axis theorem for convex polygons
    for i in range(len(poly1) + len(poly2)):
        # Get edge normal
        if i < len(poly1):
            p1 = poly1[i]
            p2 = poly1[(i + 1) % len(poly1)]
        else:
            p1 = poly2[i - len(poly1)]
            p2 = poly2[(i - len(poly1) + 1) % len(poly2)]
        
        edge = p2 - p1
        normal = np.array([-edge[1], edge[0]])
        normal = normal / (np.linalg.norm(normal) + 1e-9)
        
        proj1 = poly1 @ normal
        proj2 = poly2 @ normal
        
        # Check separation
        if proj1.max() + 1e-9 <= proj2.min() or proj2.max() + 1e-9 <= proj1.min():
            return False
    return True

def _feasible(squares):
    """Check if all squares are valid and non-overlapping."""
    if not squares:
        return True
    
    polys = []
    for (cx, cy, ang, s) in squares:
        if s < -1e-9:
            return False
        if abs(s) < 1e-12:
            continue
        poly = _to_corners(cx, cy, ang, abs(s))
        if not _corners_inside_unit(poly):
            return False
        polys.append(poly)
    
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if _box_overlap(polys[i], polys[j]):
                return False
    return True

def _object_function(x, n):
    """Objective function for optimization."""
    squares = []
    poly_list = []
    penalty = 0.0
    
    for i in range(n):
        cx, cy, ang, s = x[3*i], x[3*i+1], x[3*i+2], x[3*i+3]
        if abs(s) > 1e-12:
            poly = _to_corners(cx, cy, ang, s)
            if not _corners_inside_unit(poly):
                return 1e10
            poly_list.append(poly)
            squares.append((cx, cy, ang, s))
    
    for i in range(len(poly_list)):
        for j in range(i + 1, len(poly_list)):
            d = _poly_distance(poly_list[i], poly_list[j])
            min_diag = (math.hypot(polys[i][0]-polys[i][1], polys[i][2]-polys[i][3]) + 
                       math.hypot(polys[j][0]-polys[j][1], polys[j][2]-polys[j][3])) / 2
            if d < min_diag:
                penalty += (min_diag - d) ** 2 * 100
    
    penalty += _negative_sum(squares)
    return penalty

def _negative_sum(squares):
    """Negative sum of side lengths for minimization."""
    return -sum(abs(s[3]) for s in squares)

def solve(n):
    """Solve the squares packing problem for given n."""
    if n == 0:
        return []
    
    # Initial random packing with small sides
    angles = [0.0, 0.125, 0.25, 0.375, 0.0]  # Try multiple rotations
    best_squares = None
    best_score = -1e9
    
    for restart in range(min(50, 2 * n)):
        # Initialize random starting positions
        x0 = np.zeros(4 * n)
        for i in range(n):
            angle_ = angles[min(restart % 5, 4) + int((restart // 1) % 3)]
            x0[3*i], x0[3*i+1], x0[3*i+2], x0[3*i+3] = (
                0.5 + np.random.uniform(-0.3, 0.3),
                0.5 + np.random.uniform(-0.3, 0.3),
                angle_,
                0.1
            )
        
        # Bounds for optimization
        bounds = []
        for _ in range(n):
            bounds.extend([(0, 1), (0, 1), (0, 1), (0, 1)])
        
        # Track pool of angles along side length direction
        def gradient_flow(x, base):
            """Produce gradient of objective function with respect to x."""
            sq_list = []
            dens = []
            for i in range(len(base)):
                cx, cy, ang, s = x[3*i], x[3*i+1], x[3*i+2], x[3*i+3]
                sq_list.append((cx, cy, ang, s))
                dens.append(abs(s) ** 2)
            return len(sq_list), dens
        
        attempts = 0
        best_x = None
        best_fun = None
        
        while attempts < 100 and best_x is None:
            res = minimize(_object_function, x0, method='L-BFGS-B', 
                         bounds=bounds, options={'maxiter': 200, 'ftol': 1e-12, 'disp': False})
            if _feasible([tuple(x0[i*4:i*4+4])/1)
            if attempts > 1000:
                break
        
        sq_list = []
        for j in range(n):
            cx, cy, ang, s = x0[3*j], x0[3*j+1], x0[3*j+2], x0[3*j+3]
            sq_list.append((cx, cy, ang, s))
        
        score = sum(abs(s[3]) for s in sq_list)
        if score > best_score:
            best_score = score
            best_squares = sq_list[:]
    
    return best_squares

# Main entry point
if __name__ == "__main__":
    for n in [5, 6, 7, 8]:
        sol = solve(n)
        print(f"n={n}: sum={sum(s[3] for s in sol):.4f}")
