import math
import random
import itertools
import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint
from scipy.spatial import ConvexHull, distance_matrix

def _to_poly(center, angle, side):
    """Return 4 corner points of square (as np.array)."""
    cx, cy = center
    d = side / 2.0
    # corners relative to center (unrotated)
    corners = np.array([[-d, -d], [d, -d], [d, d], [-d, d]])
    c = math.cos(angle * 2.0 * math.pi)
    s = math.sin(angle * 2.0 * math.pi)
    rot = np.array([[c, -s], [s, c]])
    rot_corners = corners @ rot.T
    rot_corners += np.array([cx, cy])
    return rot_corners

def _poly_intersect(poly1, poly2):
    """Check if two convex polygons overlap (strict interior intersection)."""
    # separating axis theorem for convex polygons
    for poly in (poly1, poly2):
        for i in range(len(poly)):
            # edge vector
            p1 = poly[i]
            p2 = poly[(i+1) % len(poly)]
            edge = p2 - p1
            # normal
            normal = np.array([-edge[1], edge[0]])
            # project both polygons
            proj1 = poly1 @ normal
            proj2 = poly2 @ normal
            if proj1.max() <= proj2.min() + 1e-9 or proj2.max() <= proj1.min() + 1e-9:
                return False
    return True

def _poly_contains(poly, point):
    """Ray casting for point in convex polygon."""
    x, y = point
    inside = False
    n = len(poly)
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[(i+1)%n]
        intersect = ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi)
        if intersect:
            inside = not inside
    return inside

def _poly_inside_unit(poly):
    """Check if poly fully inside [0,1]x[0,1]."""
    return np.all((poly >= -1e-12) & (poly <= 1+1e-12))

def _feasible(squares):
    """Check all squares inside unit square and pairwise non-overlapping (interior)."""
    n = len(squares)
    if n == 0:
        return True
    polys = []
    for (cx, cy, ang, s) in squares:
        if s < 0:
            return False
        if s == 0:
            continue
        poly = _to_poly((cx, cy), ang, s)
        if not _poly_inside_unit(poly):
            return False
        polys.append(poly)

    for i in range(len(polys)):
        for j in range(i+1, len(polys)):
            if _poly_intersect(polys[i], polys[j]):
                return False
    return True

def _obj(squares):
    """Sum of side lengths."""
    return sum(s for (_, _, _, s) in squares)

def _pack_squares_in_container(container, sides, initial_placement=None):
    """
    Pack given squares (side lengths) into a given container [xmin, xmax] x [ymin, ymax].
    Returns list of (cx, cy, angle, side) or None.
    Uses optimization with barrier for constraints.
    """
    n = len(sides)
    if n == 0:
        return []
    # container bounds
    xmin, xmax, ymin, ymax = container
    # variables: for each square: cx, cy, angle (in turns), side is fixed
    # We'll use scipy minimize to pack them.
    # Initial positions: grid or random
    if initial_placement is None:
        # simple centered small positions
        scale = 0.01
        init = []
        for i in range(n):
            cx = np.random.uniform(xmin + sides[i]/2, xmax - sides[i]/2)
            cy = np.random.uniform(ymin + sides[i]/2, ymax - sides[i]/2)
            ang = np.random.uniform(0, 1)
            init.extend([cx, cy, ang])
    else:
        init = []
        for (cx, cy, ang, _) in initial_placement:
            init.extend([cx, cy, ang])
        init = np.array(init).tolist()

    # bounds on variables
    bounds = []
    for i in range(n):
        s = sides[i]
        bounds.append((xmin + s/2.0, xmax - s/2.0))
        bounds.append((ymin + s/2.0, ymax - s/2.0))
        bounds.append((0.0, 1.0))  # angle can be anything

    # constraints for non-overlap: we need pairwise separation.
    # we'll use a penalty method via objective function because constraint count is large.
    # Actually we can use nonlinear constraints, but H_p not easy for n>10.
    # Instead we do random search + local optimization using penalty.

    best_penalty = np.inf
    best_x = None

    def penalty(x):
        pen = 0.0
        polys = []
        for i in range(n):
            cx = x[3*i]
            cy = x[3*i+1]
            ang = x[3*i+2]
            s = sides[i]
            poly = _to_poly((cx, cy), ang, s)
            # container penalty
            for point in poly:
                pen += max(0, xmin - point[0])**2
                pen += max(0, point[0] - xmax)**2
                pen += max(0, ymin - point[1])**2
                pen += max(0, point[1] - ymax)**2
            polys.append(poly)
        for i in range(n):
            for j in range(i+1, n):
                # approximate overlap penalty: distance between centers vs sum of half-diagonals
                cxi = x[3*i]; cyi = x[3*i+1]; si = sides[i]
                cxj = x[3*j]; cyj = x[3*j+1]; sj = sides[j]
                d = np.hypot(cxi - cxj, cyi - cyj)
                # minimal distance to avoid any overlap is sum of half-diags
                min_dist = (si + sj) * np.sqrt(2)/2.0
                if d < min_dist:
                    pen += (min_dist - d)**2 * 100.0
        return pen

    def objective(x):
        return penalty(x)

    # multiple random starts
    for trial in range(20):
        x0 = np.array(init)
        if trial > 0:
            # perturb
            x0 = x0 + np.random.normal(0, 0.05, size=len(init))
            # ensure bounds
            for i in range(n):
                s = sides[i]
                x0[3*i] = np.clip(x0[3*i], xmin + s/2, xmax - s/2)
                x0[3*i+1] = np.clip(x0[3*i+1], ymin + s/2, ymax - s/2)
                x0[3*i+2] = x0[3*i+2] % 1.0

        res = minimize(objective, x0, method='L-BFGS-B', bounds=bounds, options={'maxiter': 200, 'ftol': 1e-12})
        if res.fun < best_penalty:
            best_penalty = res.fun
            best_x = res.x

    if best_penalty < 1e-3:
        # reconstruct
        result = []
        for i in range(n):
            cx = best_x[3*i]
            cy = best_x[3*i+1]
            ang = best_x[3*i+2] % 1.0
            result.append((cx, cy, ang, sides[i]))
        if _feasible(result):
            return result
    return None

def _triangular_number(k):
    """k*(k+1)//2"""
    return k * (k + 1) // 2

def _staircase_solution(n):
    """Optimal known for triangular numbers: staircase arrangement.
    Returns list of squares (cx, cy, angle, side)."""
    # Find k such that T_k <= n < T_{k+1}
    k = 1
    while _triangular_number(k) <= n:
        k += 1
    k -= 1
    Tk = _triangular_number(k)
    # Build the staircase: squares of sizes decreasing from 1/k at bottom left
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k - i):
            cx = j * side + side/2
            cy = i * side + side/2
            squares.append((cx, cy, 0.0, side))
    # If n > Tk, we need to add extra squares (size 0 for now)
    if n > Tk:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - Tk)
    return squares[:n]

def solve(n):
    # Use known optimal for triangular numbers plus insertion heuristic.
    # We'll start from staircase for nearest triangular <= n.
    if n <= 4:
        # trivial: grid 2x2 or 1x1
        k = int(math.isqrt(n))
        if k == 0:
            k = 1
        side = 1.0 / k
        sq = []
        for i in range(k):
            for j in range(k):
                cx = (i+0.5)*side
                cy = (j+0.5)*side
                sq.append((cx, cy, 0.0, side))
        sq += [(0.5,0.5,0.0,0.0)] * (n - len(sq))
        return sq[:n]

    squares = _staircase_solution(n)
    # Identify which squares are zero-size (the ones we added as placeholder)
    zero_indices = [i for i, (_, _, _, s) in enumerate(squares) if s == 0.0]

    if not zero_indices:
        return squares

    # For each zero square, replace with a new square inserted via heuristic.
    current_squares = [s for s in squares if s[3] > 0.0]
    # Now we need to insert (n - len(current_squares)) squares.
    num_to_insert = n - len(current_squares)

    for _ in range(num_to_insert):
        # find largest empty rotated square that can be added without overlap.
        # We'll approximate by grid search over center and size.
        best_side = 0.0
        best_cx = 0.5
        best_cy = 0.5
        best_ang = 0.0

        # Use discretized candidates
        grid_size = 30
        angles = [0.0, 0.125, 0.25]  # multiples of 1/8 turn
        for ix in range(grid_size+1):
            for iy in range(grid_size+1):
                cx = ix / grid_size
                cy = iy / grid_size
                for ang in angles:
                    # binary search for max possible side at this position/angle
                    lo = 0.0
                    hi = min(cx, 1-cx, cy, 1-cy) * 2.0  # crude upper bound
                    # ensure no overlap
                    for (cx2, cy2, ang2, s2) in current_squares:
                        # approximate distance constraint
                        d = np.hypot(cx - cx2, cy - cy2)
                        # avoid overlap: sum of half-diagonals
                        hi = min(hi, (d - s2 * np.sqrt(2)/2) * np.sqrt(2) if d > s2*np.sqrt(2)/2 else 0.0)
                    hi = max(0.0, hi)
                    if hi <= best_side:
                        continue
                    # binary search
                    for _ in range(15):
                        mid = (lo + hi) / 2
                        if mid == 0:
                            lo = mid
                            break
                        test_square = (cx, cy, ang, mid)
                        polys = [_to_poly((cx2, cy2), ang2, s2) for (cx2, cy2, ang2, s2) in current_squares]
                        poly_new = _to_poly((cx, cy), ang, mid)
                        ok = True
                        if not _poly_inside_unit(poly_new):
                            ok = False
                        else:
                            for p in polys:
                                if _poly_intersect(poly_new, p):
                                    ok = False
                                    break
                        if ok:
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_side:
                        best_side = lo
                        best_cx = cx
                        best_cy = cy
                        best_ang = ang

        if best_side > 1e-9:
            current_squares.append((best_cx, best_cy, best_ang, best_side))
        else:
            # cannot insert non-zero; add zero square
            current_squares.append((0.5, 0.5, 0.0, 0.0))

    # Now we might have non-optimal placement; run a local optimization to improve.
    # Use pack_squares_in_container to try to increase sum of sides?
    # But we want to maximize sum, not repack fixed sides. Instead, we can scale up all sides uniformly.
    # Actually we can attempt to expand all squares until no more room.
    # We'll run a greedy expansion: increase each square a bit, then re-pack.

    sides = [s for (_, _, _, s) in current_squares]
    # Try uniform scaling up while feasible.
    scale = 1.0
    best_scale = 1.0
    best_sq = list(current_squares)
    for _ in range(10):
        scale += 0.02
        test_sides = [min(s * scale, 1.0) for s in sides]
        # pack them
        packed = _pack_squares_in_container((0.0, 1.0, 0.0, 1.0), test_sides, initial_placement=current_squares)
        if packed is not None and _feasible(packed):
            current_squares = packed
            best_scale = scale
            sides = [s for (_, _, _, s) in packed]
        else:
            break

    # return the best we have
    final = current_squares[:n]
    if len(final) < n:
        final += [(0.5, 0.5, 0.0, 0.0)] * (n - len(final))
    return final

# quick test
if __name__ == "__main__":
    for n in [5,6,7,8,11,12,13,14,15]:
        sol = solve(n)
        print(f"n={n}: sum={sum(s for _,_,_,s in sol):.4f}, feasible={_feasible(sol)}")
