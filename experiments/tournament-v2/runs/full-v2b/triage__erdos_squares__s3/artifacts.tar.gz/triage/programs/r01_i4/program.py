# EVOLVE-BLOCK-START
"""Greedy free-rectangle packing with a local-search improvement pass.

The idea is to keep a list of empty rectangles.  Repeatedly find the free
rectangle that permits the largest inscribed (possibly rotated) square, put the
square there and split the rectangle into the remaining free parts.  At the end
a short randomised local search tries to grow the smallest squares while
keeping all interiors disjoint.
"""

import math
import random


# ----------------------------------------------------------------------
#  geometry helpers
# ----------------------------------------------------------------------

def _corners(cx, cy, ang, s):
    """Return the four corners of a square (angle as a fraction of a turn)."""
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _project(cx, cy, ang, s):
    """Axis aligned bounding box of a square."""
    pts = _corners(cx, cy, ang, s)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _sep_axes(ang):
    """The two unit axes (face normals) of a square with the given angle."""
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    return (c, sn), (-sn, c)


def _interval(cx, cy, ang, s, axis):
    """Projection interval of a square onto `axis`."""
    ux, uy = axis
    h = s * 0.5
    a = abs(ux) * h + abs(uy) * h          # half width in this direction
    p = cx * ux + cy * uy
    return p - a, p + a


def _overlap_area(sq1, sq2):
    """Area of the intersection of two squares (0 if they only touch)."""
    (cx1, cy1, a1, s1) = sq1
    (cx2, cy2, a2, s2) = sq2
    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0
    # use the separating axis theorem on the four face normals
    for ang in (a1, a2):
        for axis in _sep_axes(ang):
            lo1, hi1 = _interval(cx1, cy1, a1, s1, axis)
            lo2, hi2 = _interval(cx2, cy2, a2, s2, axis)
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return 0.0
    # SAT says they overlap; compute the polygon intersection area
    return _poly_area(_clip(sq1, sq2))


def _clip(sq1, sq2):
    """Clip square `sq1` against the four half planes of `sq2` (returns polygon)."""
    poly = _corners(*sq1)
    for ang in (sq2[2],):
        axes = _sep_axes(ang)
        cx, cy, _, s = sq2
        h = s * 0.5
        for ux, uy in axes:
            p = cx * ux + cy * uy
            # keep points with dot(pnt, u) <= p + h
            poly = _clip_half(poly, ux, uy, p + h)
            poly = _clip_half(poly, -ux, -uy, -p + h)
    return poly


def _clip_half(poly, ux, uy, c):
    if not poly:
        return []
    out = []
    m = len(poly)
    for i in range(m):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % m]
        d1 = x1 * ux + y1 * uy - c
        d2 = x2 * ux + y2 * uy - c
        if d1 <= 0:
            out.append((x1, y1))
        if (d1 < 0 < d2) or (d2 < 0 < d1):
            t = d1 / (d1 - d2)
            out.append((x1 + t * (x2 - x1), y1 + t * (y2 - y1)))
    return out


def _poly_area(poly):
    if len(poly) < 3:
        return 0.0
    a = 0.0
    m = len(poly)
    for i in range(m):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % m]
        a += x1 * y2 - x2 * y1
    return abs(a) * 0.5


# ----------------------------------------------------------------------
#  greedy packing
# ----------------------------------------------------------------------

def _best_square_in_rect(rect):
    """Return (cx, cy, side, angle) of a good square inside an axis rectangle.

    `rect` is (x0, y0, x1, y1).  We test a few angles and centres to estimate the
    largest inscribed square.  Returns the side only (centre filled later)."""
    x0, y0, x1, y1 = rect
    w = x1 - x0
    h = y1 - y0
    if w <= 1e-12 or h <= 1e-12:
        return 0.0
    base = min(w, h)
    # try several rotations, keeping the bounding box inside the rectangle
    best = 0.0
    for ang in (0.0, 0.125, 0.25, 0.375, 0.0625, 0.1875, 0.3125, 0.4375,
                0.03125, 0.09375, 0.15625, 0.21875, 0.28125, 0.34375, 0.40625, 0.46875):
        a = ang * 2.0 * math.pi
        c, sn = abs(math.cos(a)), abs(math.sin(a))
        # bounding box of a rotated square of side s is s*(c+sn) in each axis
        scale = c + sn
        s = min(w, h) / scale
        if s > best:
            best = s
    return best


def _split_rect(rect, sq):
    """Split `rect` around `sq`, returning list of remaining rectangles."""
    x0, y0, x1, y1 = rect
    bx0, by0, bx1, by1 = _project(*sq)
    out = []
    if bx0 > x0 + 1e-12:
        out.append((x0, y0, bx0, y1))
    if bx1 < x1 - 1e-12:
        out.append((bx1, y0, x1, y1))
    if by0 > y0 + 1e-12:
        out.append((max(bx0, x0), y0, min(bx1, x1), by0))
    if by1 < y1 - 1e-12:
        out.append((max(bx0, x0), by1, min(bx1, x1), y1))
    return [r for r in out if r[2] - r[0] > 1e-12 and r[3] - r[1] > 1e-12]


def _greedy(n):
    rects = [(0.0, 0.0, 1.0, 1.0)]
    squares = []
    for _ in range(n):
        best_i = -1
        best_s = -1.0
        for i, r in enumerate(rects):
            s = _best_square_in_rect(r)
            if s > best_s:
                best_s = s
                best_i = i
        if best_s <= 1e-12:
            break
        r = rects.pop(best_i)
        # choose the best angle for this rectangle
        x0, y0, x1, y1 = r
        w = x1 - x0
        h = y1 - y0
        best_ang = 0.0
        best_side = 0.0
        for ang in (0.0, 0.125, 0.25, 0.375, 0.0625, 0.1875, 0.3125,
                    0.03125, 0.09375, 0.15625, 0.21875):
            a = ang * 2.0 * math.pi
            c, sn = abs(math.cos(a)), abs(math.sin(a))
            s = min(w, h) / (c + sn)
            if s > best_side:
                best_side = s
                best_ang = ang
        side = best_side
        if side <= 1e-12:
            break
        cx = (x0 + x1) * 0.5
        cy = (y0 + y1) * 0.5
        sq = (cx, cy, best_ang, side)
        squares.append(sq)
        rects.extend(_split_rect(r, sq))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


# ----------------------------------------------------------------------
#  local search
# ----------------------------------------------------------------------

def _valid(squares):
    """Count violations (interior overlaps) and out-of-bounds squares."""
    bad = 0
    m = len(squares)
    for i in range(m):
        cx, cy, ang, s = squares[i]
        if s <= 0.0:
            continue
        x0, y0, x1, y1 = _project(cx, cy, ang, s)
        if x0 < -1e-9 or y0 < -1e-9 or x1 > 1 + 1e-9 or y1 > 1 + 1e-9:
            bad += 1
        for j in range(i + 1, m):
            if _overlap_area(squares[i], squares[j]) > 1e-10:
                bad += 1
    return bad


def _fix(squares):
    """Pull every square back inside the unit square (small translations)."""
    out = []
    for cx, cy, ang, s in squares:
        if s <= 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        x0, y0, x1, y1 = _project(cx, cy, ang, s)
        dx = 0.0
        dy = 0.0
        if x0 < 0:
            dx = -x0
        elif x1 > 1:
            dx = 1 - x1
        if y0 < 0:
            dy = -y0
        elif y1 > 1:
            dy = 1 - y1
        out.append((cx + dx, cy + dy, ang, s))
    return out


def _local_search(squares, seconds_limit, deadline=None):
    import time
    m = len(squares)
    if m == 0:
        return squares
    best = _fix(squares)
    best_bad = _valid(best)
    if best_bad == 0:
        pass
    start = time.time()
    rng = random.Random(12345)
    cur = list(best)
    cur_bad = best_bad
    while time.time() - start < seconds_limit:
        if deadline is not None and time.time() > deadline:
            break
        # pick the smallest square (most valuable to grow)
        idx = min(range(m), key=lambda i: cur[i][3])
        cx, cy, ang, s = cur[idx]
        trial = (cx, cy, ang, s * (1.0 + rng.uniform(0.0, 0.35)))
        cand = list(cur)
        cand[idx] = trial
        cand = _fix(cand)
        bad = _valid(cand)
        if bad <= cur_bad:
            # accept, maybe with a tiny random jitter of the centre
            dx = rng.uniform(-0.02, 0.02)
            dy = rng.uniform(-0.02, 0.02)
            cand[idx] = (trial[0] + dx, trial[1] + dy, trial[2], trial[3])
            cand = _fix(cand)
            bad = _valid(cand)
            if bad <= cur_bad:
                cur = cand
                cur_bad = bad
                if bad == 0:
                    pass
        else:
            # occasionally perturb angles / centres even if not improving
            j = rng.randrange(m)
            cx2, cy2, ang2, s2 = cur[j]
            ang2 = (ang2 + rng.uniform(-0.1, 0.1)) % 1.0
            cx2 += rng.uniform(-0.01, 0.01)
            cy2 += rng.uniform(-0.01, 0.01)
            cand = list(cur)
            cand[j] = (cx2, cy2, ang2, s2)
            cand = _fix(cand)
            bad = _valid(cand)
            if bad <= cur_bad:
                cur = cand
                cur_bad = bad
        if cur_bad == 0 and sum(s for _, _, _, s in cur) > sum(s for _, _, _, s in best):
            best = list(cur)
    return best


def solve(n):
    if n <= 0:
        return []
    squares = _greedy(n)
    # short local search, keeping well inside the time limit
    try:
        import time
        deadline = time.time() + 25.0
        squares = _local_search(squares, 20.0, deadline)
    except Exception:
        squares = _greedy(n)
    squares = _fix(squares)
    # guarantee the right length and unit-cube validity, fill with points
    out = []
    for sq in squares[:n]:
        cx, cy, ang, s = sq
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        out.append((float(cx), float(cy), float(ang), float(max(s, 0.0))))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END

