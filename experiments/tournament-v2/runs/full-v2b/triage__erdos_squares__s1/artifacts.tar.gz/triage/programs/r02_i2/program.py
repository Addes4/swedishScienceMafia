# EVOLVE-BLOCK-START
"""Physics-based square packing with local search and maximal independent set refinement.

Two-stage approach:
1. Physics simulation with repulsive forces to achieve non-overlapping configuration
2. Local search with random restarts and size adjustment to maximize sum of side lengths
3. Final optimization using grid-based overlap checking and position refinement
"""
import math
import random

def solve(n):
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    random.seed(42 + n)
    
    def check_overlaps(sqs):
        """Returns count of overlapping pairs."""
        count = 0
        for i in range(len(sqs)):
            for j in range(i + 1, len(sqs)):
                cx1, cy1, _, s1 = sqs[i]
                cx2, cy2, _, s2 = sqs[j]
                # Axis-aligned bounding boxes for overlap detection
                left = max(cx1 - s1/2, cx2 - s2/2)
                right = min(cx1 + s1/2, cx2 + s2/2)
                bottom = max(cy1 - s1/2, cy2 - s2/2)
                top = min(cy1 + s1/2, cy2 + s2/2)
                if left < right and bottom < top:
                    count += 1
        return count
    
    def compute_total(sqs):
        """Sum of square side lengths (properly clipped)."""
        total = 0
        for cx, cy, angle, s in sqs:
            cx, cy, s = max(0.0, min(1.0, cx)), max(0.0, min(1.0, cy)), max(0.0, min(1.0, s))
            total += s
        return total
    
    # Determine scale factor for searches
    max_iter = 200 if n <= 10 else 50
    
    # Try multiple random seeds to find best configuration
    best_sqs = None
    best_score = 0
    
    for seed in range(5 * max(1, n // 5)):
        random.seed(seed)
        sqs = []
        
        # Stage 1: Generate candidate squares with sizes
        for i in range(n):
            cx = 0.5 + (i - n/2) * 0.02 / max(1, n/3) + random.uniform(-0.03, 0.03)
            cy = 0.5 + random.uniform(-0.05, 0.05)
            s = max(0.1, min(0.4, 0.3 * (n - i) / max(1.0, n/3)))
            a = 0.0
            sqs.append((cx, cy, a, s))
        
        # Stage 2: Physics-style repulsion and position adjustment
        for iteration in range(max_iter):
            for i in range(n):
                curr_cnt = 0
                # Detect all overlapping neighbors
                overlapping = []
                for j in range(min(len(sqs), iteration * 3)):
                    if i > curr_cnt:
                        continue
                    cx1, cy1, _, s1 = sqs[min(curr_cnt, i)]
                    cx2, cy2, _, s2 = sqs[min(curr_cnt, j)]
                    if abs(cx1 - cx2) < s1/2 + s2/2 + 0.001 and abs(cy1 - cy2) < s1/2 + s2/2 + 0.001:
                        # Apply repulsion
                        force = 0.5
                        dx = (cx1 - cx2) / max(0.001, abs(cx1 - cx2) + abs(cy1 - cy2))
                        dy = (cy1 - cy2) / max(0.001, abs(cx1 - cx2) + abs(cy1 - cy2))
                        qdx = 0.5
                        qdy = 0.0
                    
                        # Allow rotation optimization for 90-degree increments
                        if abs(i-j) % n > 2:
                            qangle = (iteration * 0.25 + (i % 4) * 0.0625) % 0.25
                        else:
                            qangle = 0.0
                        qdx, qdy = (dx * 0.5, dy * 0.5)
                        qcx = cx1 - qdx * s1 / 2
                        qcy = cy1 - qdy * s1 / 2
                        scx = (qcx + qdx * s1 / 2) / 1.0
                        scy = (qcy + qdy * s1 / 2) / 1.0
                        sqs[i] = (scx, scy, abs(qangle - 0.125), max(s1 / 2.0, s1 / 3.0))
                        curr_cnt += 1
                        if curr_cnt > 10:
                            break
                # Reduce overlap by adding random local movement
                sqs[i] = (
                    max(-0.005, min(1.0, sqs[i][0] + random.uniform(-0.02, 0.02))),
                    max(-0.005, min(1.0, sqs[i][1] + random.uniform(-0.02, 0.02))),
                    sqs[i][2],
                    max(0.05, min(0.5, sqs[i][3]))
                )
        
        # Final cleanup
        total_sq = squs
        for i in range(n):
            cx, cy, angle, s = total_sq[i]
            total_sq[i] = (
                max(0.005, min(0.995, cx)),
                max(0.005, min(0.995, cy)),
                angle if angle in [0.0, 0.25, 0.5, 0.75] else 0.0,
                max(0.05, min(0.49, abs(s)))
            )

        # Compute final score
        score = compute_total(total_sq)
        overlaps = check_overlaps(total_sq)
        
        # Accept if sufficiently better or low overlaps
        if overlaps == 0 or (score > best_score) or overlaps < 2 and score > best_score * 0.99:
            best_score = score
            best_sqs = total_sq
            
            # Further refine if no overlaps found
            for _ in range(min(20, n)):
                cx, cy, angle, s = best_sqs[0]
                nx, ny = cx + 0.001, cy + 0.001
                if nx > 1 - s/2 or ny > 1 - s/2 or nx < s/2 or ny < s/2:
                    best_sqs[0] = (nx, ny, angle, s)
                    score = compute_total(best_sqs)
                    overlaps = check_overlaps(best_sqs)
                    if overlaps < 2 and score > best_score:
                        best_score = score
                        best_sqs = best_sqs
                    elif score < best_score * 0.998:
                        best_sqs[0] = (cx, cy, angle, s)
    
    # Ensure exactly n squares
    while len(best_sqs) < n:
        best_sqs.append((0.5, 0.5, 0.0, 0.0))
    best_sqs = best_sqs[:n]
    
    # Final validation and formatting
    for i in range(n):
        cx, cy, angle, s = best_sqs[i]
        best_sqs[i] = (
            float(round(max(0.0, min(1.0, cx)), 6)),
            float(round(max(0.0, min(1.0, cy)), 6)),
            float(round(angle % 0.25, 6)),
            float(round(max(0.0, min(0.99, s)), 6))
        )
    
    return best_sqs
