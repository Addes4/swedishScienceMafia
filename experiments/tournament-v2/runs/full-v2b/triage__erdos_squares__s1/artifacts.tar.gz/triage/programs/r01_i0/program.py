# EVOLVE-BLOCK-START
"""Packing squares in a unit square, maximising the sum of side lengths.

Strategy: use a 'shelf/grid' initial solution and improve it with a
force-directed simulated annealing that pushes apart overlapping squares
(by their circumcircles) while the sides are scaled by a common factor and
individual perturbation. A configuration's value is its 'feasibility-scaled'
sum of sides.
"""
import math
import random


def _overlap_penalty(squares):
    """Return total pairwise overlap measure using circumcircles (approx)."""
    penalty = 0.0
    m = len(squares)
    for i in range(m):
        xi, yi, ai, si = squares[i]
        if si <= 0:
            continue
        # circumradius of a square with side s is s*sqrt(2)/2
        ri = si * 0.7071067811865476
        for j in range(i + 1, m):
            xj, yj, aj, sj = squares[j]
            if sj <= 0:
                continue
            rj = sj * 0.7071067811865476
            dx = xi - xj
            dy = yi - yj
            d = math.hypot(dx, dy)
            rr = ri + rj
            if d < rr - 1e-12:
                penalty += (rr - d) ** 2
    return penalty


def _boundary_penalty(squares):
    """Penalty for squares extending outside the unit square (using circumcircle)."""
    penalty = 0.0
    for (x, y, a, s) in squares:
        if s <= 0:
            continue
        r = s * 0.7071067811865476
        if x - r < 0:
            penalty += (r - x) ** 2
        if x + r > 1:
            penalty += (x + r - 1) ** 2
        if y - r < 0:
            penalty += (r - y) ** 2
        if y + r > 1:
            penalty += (y + r - 1) ** 2
    return penalty


def _feasible_sum(squares):
    """Sum of side lengths if all squares fit; otherwise a large negative value."""
    if _overlap_penalty(squares) > 1e-9 or _boundary_penalty(squares) > 1e-9:
        return -1e9
    return sum(s for (_, _, _, s) in squares)


def _scale_and_clear(squares, steps=200, rate=0.85):
    """Given squares, shrink factor so all fits, then push apart overlaps.

    Approach: iteratively scale side lengths down by 'rate' until feasible,
    then nudge centres apart to remove overlap, keeping sizes.
    """
    sq = [list(t) for t in squares]
    m = len(sq)

    def overlaps():
        total = 0.0
        for i in range(m):
            xi, yi, ai, si = sq[i]
            if si <= 0:
                continue
            ri = si * 0.7071067811865476
            for j in range(i + 1, m):
                xj, yj, aj, sj = sq[j]
                if sj <= 0:
                    continue
                rj = sj * 0.7071067811865476
                dx = xi - xj
                dy = yi - yj
                d = math.hypot(dx, dy)
                rr = ri + rj
                if d < rr - 1e-12:
                    total += (rr - d)
        return total

    # scale down until no overlap and fit inside
    for _ in range(steps):
        # boundary: scale check
        scale_ok = True
        for (x, y, a, s) in sq:
            if s <= 0:
                continue
            r = s * 0.7071067811865476
            if x - r < -1e-12 or x + r > 1 + 1e-12 or y - r < -1e-12 or y + r > 1 + 1e-12:
                scale_ok = False
                break
        o = overlaps()
        if scale_ok and o < 1e-9:
            break
        for k in range(m):
            sq[k][3] *= rate
    return [tuple(t) for t in sq]


def _relax(squares, iters=300):
    """Push apart overlapping squares via simple repulsion, keeping sizes."""
    sq = [list(t) for t in squares]
    m = len(sq)
    for _ in range(iters):
        any_overlap = False
        for i in range(m):
            xi, yi, ai, si = sq[i]
            if si <= 0:
                continue
            ri = si * 0.7071067811865476
            for j in range(i + 1, m):
                xj, yj, aj, sj = sq[j]
                if sj <= 0:
                    continue
                rj = sj * 0.7071067811865476
                dx = xi - xj
                dy = yi - yj
                d = math.hypot(dx, dy)
                rr = ri + rj
                if d < rr - 1e-12:
                    any_overlap = True
                    if d < 1e-12:
                        dx, dy, d = 1.0, 0.0, 1.0
                    push = (rr - d) * 0.5
                    nx, ny = dx / d, dy / d
                    sq[i][0] += nx * push
                    sq[i][1] += ny * push
                    sq[j][0] -= nx * push
                    sq[j][1] -= ny * push
        if not any_overlap:
            break
        # clamp inside
        for k in range(m):
            s = sq[k][3]
            if s <= 0:
                continue
            r = s * 0.7071067811865476
            if sq[k][0] - r < 0:
                sq[k][0] = r
            if sq[k][0] + r > 1:
                sq[k][0] = 1 - r
            if sq[k][1] - r < 0:
                sq[k][1] = r
            if sq[k][1] + r > 1:
                sq[k][1] = 1 - r
    return [tuple(t) for t in sq]


def _search(n, seed, time_budget_evals=40000):
    rng = random.Random(seed)

    best = None
    best_value = -1.0

    # Try several k-structures
    ks = []
    k0 = int(math.isqrt(n))
    for k in {k0, k0 - 1, k0 + 1}:
        if 1 <= k <= n:
            ks.append(k)
    ks = list(dict.fromkeys(ks))

    starts = []
    for k in ks:
        # k*k grid squares + extras as tiny/zero at random or centre
        grid = []
        s = 1.0 / k
        for i in range(k):
            for j in range(k):
                grid.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
        extra = n - len(grid)
        # distribute extras by taking some grid cells and splitting
        # Simple: add extras as zero-size at centre
        for _ in range(max(0, extra)):
            grid.append([0.5, 0.5, 0.0, 0.0])
        grid = grid[:n]
        # Give extras a small initial side and random position
        for idx in range(len(grid)):
            if grid[idx][3] == 0.0:
                ss = 0.15
                grid[idx] = [rng.uniform(ss * 0.8, 1 - ss * 0.8),
                             rng.uniform(ss * 0.8, 1 - ss * 0.8),
                             rng.choice([0.0, 0.25, 0.5, 0.75, 0.125, 0.375]),
                             ss]
        starts.append(grid)

    # Also an all-equal start: n squares of side 1/sqrt(n) in grid/random
    s0 = 1.0 / math.sqrt(n)
    eq = []
    cols = int(math.ceil(math.sqrt(n)))
    for idx in range(n):
        r = idx // cols
        c = idx % cols
        eq.append([(c + 0.5) * s0, (r + 0.5) * s0, 0.0, s0])
    starts.append(eq)

    for start in starts:
        cur = _scale_and_clear(start, steps=60, rate=0.9)
        cur = _relax(cur, iters=200)
        val = _feasible_sum(cur)
        if val > best_value:
            best_value = val
            best = cur

    # Simulated annealing / local perturbation
    # Represent: list of [x, y, angle, side]. Moves: perturb x,y,angle,side.
    cur = [list(t) for t in best]
    cur_val = best_value
    m = n

    T = 0.05
    for step in range(time_budget_evals):
        # choose action
        idx = rng.randrange(m)
        new = [row[:] for row in cur]
        act = rng.random()
        if act < 0.35:
            # perturb position
            new[idx][0] = min(1.0, max(0.0, new[idx][0] + rng.gauss(0, T)))
            new[idx][1] = min(1.0, max(0.0, new[idx][1] + rng.gauss(0, T)))
        elif act < 0.6:
            # perturb angle
            new[idx][2] = (new[idx][2] + rng.gauss(0, T * 2)) % 1.0
        elif act < 0.85:
            # perturb side
            delta = rng.gauss(0, T)
            new[idx][3] = max(0.0, new[idx][3] + delta)
        else:
            # shrink all sides slightly toward equal share (redistribute)
            tot = sum(r[3] for r in new)
            target = tot / m if m else 0
            for r in new:
                r[3] += (target - r[3]) * 0.2

        # re-feasibilize: push apart, clamp
        new = _relax(new, iters=30)
        # if still infeasible, try scaling down
        cand_val = _feasible_sum(new)
        if cand_val < -1e8:
            new = _scale_and_clear(new, steps=30, rate=0.92)
            new = _relax(new, iters=40)
            cand_val = _feasible_sum(new)

        # After clearing, we may grow sides back to further improve
        if cand_val > -1e8:
            # grow sides uniformly until infeasible
            lo, hi = 1.0, 3.0
            for _ in range(12):
                mid = (lo + hi) / 2
                test = [r[:] for r in new]
                for r in test:
                    r[3] *= mid
                test = _scale_and_clear(test, steps=20, rate=0.95)
                tv = _feasible_sum(test)
                if tv > -1e8:
                    lo = mid
                else:
                    hi = mid
            # apply a bit less than max to stay feasible
            grow = 0.5 * (lo + hi) * 0.999
            test = [r[:] for r in new]
            for r in test:
                r[3] *= grow
            test = _relax(test, iters=40)
            tv = _feasible_sum(test)
            if tv > -1e8:
                new = test
                cand_val = tv

        if cand_val > cur_val or rng.random() < math.exp((cand_val - cur_val) / max(T, 1e-6)):
            cur = new
            cur_val = cand_val
            if cur_val > best_value:
                best_value = cur_val
                best = [row[:] for row in cur]
        T *= 0.9995
        if T < 1e-4:
            T = 0.01

    # final polish: relax + grow
    out = [list(t) for t in best]
    out = _relax(out, iters=400)
    # grow uniformly greedily
    for _ in range(40):
        test = [r[:] for r in out]
        for r in test:
            r[3] *= 1.005
        test = _relax(test, iters=200)
        tv = _feasible_sum(test)
        if tv > _feasible_sum(out) + 1e-9:
            out = test
        else:
            break
    out = [tuple(t) for t in out]
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # exact grid for perfect squares
    k = math.isqrt(n)
    if k * k == n:
        s = 1.0 / k
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    # run search
    best = None
    best_value = -1.0
    for seed in range(4):
        try:
            res = _search(n, seed)
        except Exception:
            continue
        val = _feasible_sum(res)
        if val > best_value:
            best_value = val
            best = res
    if best is None:
        # fallback grid
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    # clean tiny squares
    out = []
    for (x, y, a, s) in best[:n]:
        if s < 1e-12:
            out.append((0.5, 0.5, 0.0, 0.0))
        else:
            out.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), a % 1.0, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
