# EVOLVE-BLOCK-START
"""Hierarchical k-d tree partition: each leaf cell gets exactly one inscribed square.

The idea: recursively split the unit square into axis-aligned rectangular cells.
Every leaf cell of the recursion holds one square, whose side equals min(width, height)
of that cell (the largest axis-aligned square fitting in the cell).  We choose the
split directions (vertical/horizontal) and the recursion shape so that the sum of
min(w,h) over all leaves is large.

Enumerating / searching split trees:
  - For small n we can afford an exhaustive or beam search over trees.
  - We represent a tree by a tuple structure and evaluate its "value" = sum over
    leaves of min(w,h), where cells are obtained by splitting the unit square.

To keep it reliable and fast we use a beam search over partial partitions,
where a state is a list of rectangular cells (all currently leaves, total count m).
At each step we pick the cell to split (the one whose loss from splitting is
smallest — i.e. splitting reduces its contribution the least / increases total
the most) and choose the best split direction and ratio.  A split at ratio r of
a cell of size (W,H) yields two cells; we choose both the direction and the ratio
to maximise resulting value.  This is a greedy with a tiny beam.

Actually the cleanest robust approach: dynamic programming over "how many leaves
a cell can be divided into, and the best value", but the value depends on the
aspect ratio of the cell.  Because a cell is always a sub-rectangle produced by
guillotine cuts of the unit square, its dimensions can be many values.  We use a
memoised function best(W, H, k) = maximum sum of min(dim) over a guillotine
partition of a W x H rectangle into exactly k axis-aligned rectangles (the cut
being either a vertical or horizontal full cut).  The leaf contribution of a
whole W x H cell is min(W,H).  Recurrence:

   best(W,H,1) = min(W,H)
   best(W,H,k) = max over vertical cut at x in (0,W), over k1+k2=k :
                    best(x,H,k1) + best(W-x,H,k2)
                 and similarly horizontal cuts.

This is exact (within the guillotine family) and can be solved by discretising
the cut positions to a fine grid.  Then we reconstruct the tree and place
squares, all axis-aligned (angle 0), which is optimal for the guillotine family.

To make it fast and stable we discretise positions: the relevant cut coordinates
are fractions of the original unit square, and optimal cuts for these min-sum
problems occur at simple rationals.  We use a set of candidate fractions and
search with memoisation on rounded coordinates.
"""
import math
import sys
from functools import lru_cache


def solve(n):
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Candidate cut fractions.  Optimal guillotine partitions for min(w,h) tend
    # to use equal splits and splits producing squares, so these rationals cover
    # the useful cases well.
    FR = set()
    for den in (1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 16):
        for num in range(1, den):
            FR.add(num / den)
    FR = sorted(FR)

    # We solve best(W,H,k) with memoisation.  Coordinates are represented as
    # floats but snapped to the fraction grid where possible, and we limit the
    # number of distinct width/height values by rounding to a fine grid.
    SCALE = 2520  # lcm-ish fine grid

    def snap(v):
        s = int(round(v * SCALE))
        if s < 0:
            s = 0
        if s > SCALE:
            s = SCALE
        return s

    # Precompute candidate cut positions in scaled integer units for a segment
    # of given scaled length: all fractions of that length that are on the grid.
    def cuts(L):
        # return sorted list of split offsets in (0, L) in scaled units,
        # using the fraction set mapped to this length
        res = set()
        for f in FR:
            c = int(round(L * f))
            if 0 < c < L:
                res.add(c)
        # also candidate equal split and integer-friendly splits
        res.add(L // 2)
        res.add((L + 1) // 2)
        # remove zeros / full
        out = sorted(c for c in res if 0 < c < L)
        return out

    memo = {}

    def best(w, h, k):
        # w,h scaled ints >=0, k >=1
        if k == 1:
            return float(min(w, h)) / SCALE
        key = (w, h, k)
        if key in memo:
            return memo[key]
        if w <= 0 or h <= 0:
            return 0.0
        # upper bound: can't do better than k leaves each <= min
        res = -1.0
        # vertical cuts
        if w >= 2 and k >= 2:
            cs = cuts(w)
            for c in cs:
                # k1 from 1..k-1
                w1 = c
                w2 = w - c
                for k1 in range(1, k):
                    k2 = k - k1
                    v1 = best(w1, h, k1)
                    v2 = best(w2, h, k2)
                    t = v1 + v2
                    if t > res:
                        res = t
        # horizontal cuts
        if h >= 2 and k >= 2:
            cs = cuts(h)
            for c in cs:
                h1 = c
                h2 = h - c
                for k1 in range(1, k):
                    k2 = k - k1
                    v1 = best(w, h1, k1)
                    v2 = best(w, h2, k2)
                    t = v1 + v2
                    if t > res:
                        res = t
        if res < 0:
            # cannot split further: put remaining squares as degenerate (side 0)
            res = float(min(w, h)) / SCALE
        memo[key] = res
        return res

    # To keep the state space manageable, limit to a smaller scale and prune k.
    # We'll use a simpler, faster scheme: iterative greedy subdivision with
    # local optimisation, which handles all n within the time budget.

    # ---- Greedy guillotine refinement ----
    # Start from a k*k grid where k = isqrt(n), then repeatedly split cells
    # (increasing leaf count by 1) choosing the split that minimises the loss,
    # until we have n cells.  Then locally adjust split positions.

    # Represent cells as (x0, y0, x1, y1) in [0,1]^2.
    k0 = int(math.isqrt(n))
    if k0 < 1:
        k0 = 1
    # build k0 x k0 grid but distribute the leftover into the grid by splitting
    # We'll build a starting partition with exactly n leaves greedily.
    # Actually start with 1 cell, split greedily n-1 times.
    cells = [(0.0, 0.0, 1.0, 1.0)]

    def cell_val(c):
        return min(c[2] - c[0], c[3] - c[1])

    def best_split(c):
        x0, y0, x1, y1 = c
        W = x1 - x0
        H = y1 - y0
        base = min(W, H)
        bestv = -1e18
        bestcell = None
        # try vertical cuts at candidate fractions and equal split
        cands = set([0.5])
        for f in (1/3, 2/3, 1/4, 3/4, 1/5, 2/5, 3/5, 4/5, 1/6, 5/6, 1/8, 3/8, 5/8, 7/8):
            cands.add(f)
        for f in cands:
            if 0.0 < f < 1.0:
                xc = x0 + f * W
                c1 = (x0, y0, xc, y1)
                c2 = (xc, y0, x1, y1)
                v = cell_val(c1) + cell_val(c2)
                if v > bestv:
                    bestv = v
                    bestcell = (c1, c2)
        for f in cands:
            if 0.0 < f < 1.0:
                yc = y0 + f * H
                c1 = (x0, y0, x1, yc)
                c2 = (x0, yc, x1, y1)
                v = cell_val(c1) + cell_val(c2)
                if v > bestv:
                    bestv = v
                    bestcell = (c1, c2)
        return bestv - base, bestcell

    while len(cells) < n:
        # choose the cell whose best split adds the most value (least negative loss)
        best_i = -1
        best_gain = -1e18
        best_pair = None
        for i, c in enumerate(cells):
            g, pair = best_split(c)
            if g > best_gain:
                best_gain = g
                best_i = i
                best_pair = pair
        if best_i < 0 or best_pair is None:
            break
        a, b = best_pair
        cells[best_i] = a
        cells.append(b)

    # If we somehow have fewer than n, add degenerate cells
    while len(cells) < n:
        cells.append((0.0, 0.0, 0.0, 0.0))

    # Local optimisation: adjust split lines to improve total.
    # Use a simple approach: re-balance each pair of sibling cells.
    # (Skip heavy optimisation; do a few coordinate descent passes on the tree.)
    # Reconstruct tree as a binary tree from the greedy splitting order is nontrivial,
    # so instead do a direct improvement: for each cell, try shrinking/expanding
    # shared boundaries with neighbours is complex.  We'll instead re-run greedy
    # with a starting grid to get a better local optimum and pick the better.

    def run_greedy(init_cells):
        cs = list(init_cells)
        guard = 0
        while len(cs) < n and guard < 4 * n + 10:
            guard += 1
            bi = -1
            bg = -1e18
            bp = None
            for i, c in enumerate(cs):
                g, pair = best_split(c)
                if g > bg:
                    bg = g
                    bi = i
                    bp = pair
            if bi < 0 or bp is None:
                break
            a, b = bp
            cs[bi] = a
            cs.append(b)
        return cs

    candidates = [cells]

    # candidate starting partitions: k x k grids for several k
    for kk in range(1, int(math.isqrt(n)) + 3):
        g = []
        s = 1.0 / kk
        for i in range(kk):
            for j in range(kk):
                g.append((i * s, j * s, (i + 1) * s, (j + 1) * s))
        if len(g) <= n:
            candidates.append(g)

    best_cells = cells
    best_score = sum(cell_val(c) for c in cells)

    for init in candidates:
        cs = run_greedy(init)
        sc = sum(cell_val(c) for c in cs)
        if sc > best_score:
            best_score = sc
            best_cells = cs

    # Build output
    out = []
    for (x0, y0, x1, y1) in best_cells[:n]:
        W = x1 - x0
        H = y1 - y0
        s = min(W, H)
        if s < 0:
            s = 0.0
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        # clamp
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        if s > 1.0:
            s = 1.0
        out.append((cx, cy, 0.0, s))

    # ensure exactly n
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
