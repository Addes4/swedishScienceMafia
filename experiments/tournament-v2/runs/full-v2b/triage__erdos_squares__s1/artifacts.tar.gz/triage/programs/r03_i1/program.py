import math
import random
import itertools
import numpy as np
from scipy.optimize import minimize, Bounds

def solve(n):
    """
    Place n non-overlapping squares in the unit square to maximize sum of side lengths.
    Uses L∞ Chebyshev distance formulation: each square of side s_i is an L∞ ball of radius s_i/2.
    We optimize positions, sizes, and angles (though for sum of side lengths angles don't matter).
    Uses stochastic optimization with overlap penalty and simulated annealing.
    """
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Parameters
    num_starts = 20 if n <= 20 else 5
    max_iter = 2000 if n <= 20 else 500
    penalty_weight = 10.0
    final_penalty_weight = 1000.0
    
    def linf_distance(c1, s1, c2, s2):
        """L∞ distance between centers of two L∞ balls."""
        return max(abs(c1[0] - c2[0]), abs(c1[1] - c2[1]))
    
    def overlap(c1, s1, c2, s2):
        """Overlap amount in L∞ metric (negative if separated)."""
        return (s1 + s2) / 2.0 - linf_distance(c1, s1, c2, s2)
    
    def total_overlap(centers, sides):
        """Sum of positive overlaps (penalty)."""
        total = 0.0
        for i in range(n):
            for j in range(i+1, n):
                ov = overlap(centers[i], sides[i], centers[j], sides[j])
                if ov > 0:
                    total += ov
        return total
    
    def bounds_violation(centers, sides):
        """Penalty for squares sticking out of unit square."""
        viol = 0.0
        for i in range(n):
            c = centers[i]
            s = sides[i]
            r = s / 2.0
            viol += max(0, -(c[0] - r))  # left
            viol += max(0, (c[0] + r) - 1.0)  # right
            viol += max(0, -(c[1] - r))  # bottom
            viol += max(0, (c[1] + r) - 1.0)  # top
        return viol
    
    def energy(params):
        """Negative sum of sides + penalty * overlap + boundary penalty."""
        centers = [(params[3*i], params[3*i+1]) for i in range(n)]
        sides = params[3*i+2] for i in range(n)]  # No rotation used
        sum_s = sum(sides)
        overlap_pen = total_overlap(centers, sides)
        bound_pen = bounds_violation(centers, sides)
        return -sum_s + penalty_weight * overlap_pen + penalty_weight * bound_pen
    
    def energy_gradient(params):
        """Approximate gradient of the energy function."""
        eps = 1e-5
        grad = np.zeros_like(params)
        for i in range(len(params)):
            orig = params[i]
            params[i] = orig + eps
            e_plus = energy(params)
            params[i] = orig - eps
            e_minus = energy(params)
            grad[i] = (e_plus - e_minus) / (2 * eps)
            params[i] = orig
        return grad

    def random_init():
        """Random initialization with small squares."""
        sides = np.random.uniform(0.1, 0.5, n) * (1.0 / math.sqrt(n))
        centers = np.random.uniform(sides/2.0, 1.0 - sides/2.0, (n, 2))
        params = np.zeros(3 * n)
        for i in range(n):
            params[3*i] = centers[i, 0]
            params[3*i+1] = centers[i, 1]
            params[3*i+2] = sides[i]
        return params
    
    def pack_from_init(params):
        nonlocal penalty_weight
        # Run optimization with L-BFGS-B
        bounds = []
        for _ in range(n):
            bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])
        bnds = Bounds([b[0] for b in bounds], [b[1] for b in bounds])
        
        # Pre-optimization with moderate penalty
        local_penalty = penalty_weight
        for step in range(3):
            res = minimize(energy, params.copy(), method='L-BFGS-B',
                          jac=energy_gradient, bounds=bnds,
                          options={'maxiter': max_iter//3, 'ftol': 1e-8})
            params = res.x
            # Increase penalty
            local_penalty *= 5.0
            penalty_weight = local_penalty
            
        penalty_weight = final_penalty_weight
        res = minimize(energy, params, method='L-BFGS-B',
                       jac=energy_gradient, bounds=bnds,
                       options={'maxiter': max_iter//2, 'ftol': 1e-8})
        params = res.x
        
        # Ensure no overlaps and correct sides
        # Final shrink to exact fit
        centers = [(params[3*i], params[3*i+1]) for i in range(n)]
        sides = [params[3*i+2] for i in range(n)]
        
        # Shrink to remove overlaps
        for _ in range(100):
            moved = False
            for i in range(n):
                for j in range(i+1, n):
                    ov = overlap(centers[i], sides[i], centers[j], sides[j])
                    if ov > 0:
                        # reduce both sides proportionally
                        total_side = sides[i] + sides[j]
                        if total_side > 1e-9:
                            reduce_i = ov * sides[i] / total_side * 1.01
                            reduce_j = ov * sides[j] / total_side * 1.01
                            sides[i] = max(0, sides[i] - reduce_i)
                            sides[j] = max(0, sides[j] - reduce_j)
                            moved = True
                # Also enforce bounds
                c = centers[i]
                s = sides[i]
                r = s / 2.0
                if c[0] - r < 0:
                    sides[i] = 2 * c[0]
                if c[0] + r > 1.0:
                    sides[i] = 2 * (1.0 - c[0])
                if c[1] - r < 0:
                    sides[i] = 2 * c[1]
                if c[1] + r > 1.0:
                    sides[i] = 2 * (1.0 - c[1])
            if not moved:
                break
        
        # Final packing score
        sum_s = sum(sides)
        return sum_s, centers, sides
    
    best_sum = -1
    best_centers = None
    best_sides = None
    
    for start_idx in range(num_starts):
        params = random_init()
        penalty_weight = 1.0
        try:
            s, cent, sides = pack_from_init(params)
            if s > best_sum:
                best_sum = s
                best_centers = cent
                best_sides = sides
        except Exception:
            continue
    
    if best_centers is None:
        # Fallback to grid
        cols = int(math.ceil(math.sqrt(n)))
        side = 1.0 / cols
        best_centers = []
        best_sides = []
        for i in range(n):
            row = i // cols
            col = i % cols
            best_centers.append(((col+0.5)*side, (row+0.5)*side))
            best_sides.append(side)
    
    # Ensure non-negative sides
    best_sides = [max(0, min(1.0, s)) for s in best_sides]
    # Clamp centers
    best_centers = [(max(0, min(1.0, c[0])), max(0, min(1.0, c[1]))) for c in best_centers]
    
    result = []
    for (cx, cy), s in zip(best_centers, best_sides):
        result.append((cx, cy, 0.0, s))  # No rotation
    return result
