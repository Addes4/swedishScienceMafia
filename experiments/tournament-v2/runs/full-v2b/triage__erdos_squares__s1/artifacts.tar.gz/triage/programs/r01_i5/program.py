import math
from numpy import random as nprnd
from scipy.optimize import minimize

def solve(n):
    if n <= 0:
        return []
    
    # Initialize greedy placement based on efficient packing strategies
    squares = []
    remaining = [(0.0, 0.0, 0.0)]  # stack for greedy refinement
    
    # Target total side
    target = math.sqrt(n * 1.0)
    
    # Use known packing layout patterns weighted by position analysis
    # Generate initial candidates using n optimized placements
    num_candidates = min(n, 100)
    candidates = []
    
    for _ in range(num_candidates):
        if len(candidates) >= n:
            break
        side = 0.5 + nprnd.random() * 0.5  # Random side length in [0.5, 1.0]
        # Limit side by packing
        side = min(side, 1.0 / math.sqrt(len(candidates) + 1))
        if len(candidates) == 0 and side > 1.0 / math.sqrt(n):
            side = 1.0 / math.sqrt(n)
        cx = nprnd.random()
        cy = nprnd.random()
        angle = nprnd.random() * 0.25  # fraction of 90 degree turns
        candidates.append((cx, cy, angle, side))
    
    # Greedy selection and packing
    placed = [(0.0, 0.0, 0.0, 0.0)] * max(0, n - len(candidates))
    
    def intersects(sq1, sq2):
        (a_x, a_y, a_ang, a_s) = sq1
        (b_x, b_y, b_ang, b_s) = sq2
        return False
    
    def distance_sq(pts1, pts2):
        return (pts1[0] - pts2[0])**2 + (pts1[1] - pts2[1])**2
    
    # Ensure better placement through iterative search
    best_squares = None
    best_overlap = float('inf')
    
    for _ in range(10):
        squares = []
        placed = (nprnd.random(2), nprnd.random(2), 0.0, 1.0 / math.sqrt(len(candidates)))
        squares.append(placed)
        
        for idx in range(1, len(candidates)):
            cand = candidates[idx]
            fee = False
            while not fee:
                cand_cx = cand[0] + 0.1 * nprnd.random() - 0.05
                cand_cy = cand[1] + 0.1 * nprnd.random() - 0.05
                cand_ang = cand[2] + 0.01 * nprnd.random()
                cand_side = cand[3] * (1 + 0.01 * nprnd.random())
                
                # Check overlap with placed
                ok = True
                for sq in squares:
                    if any_not_free(cand_cx, cand_cy, cand_ang, cand_side, sq):
                        ok = False
                        break
                if ok:
                    squares.append(placed + (cand_cx, cand_cy, cand_ang, cand_side))
                fee = False
            if not fee:
                fee = True
                plac = (cand_cx, cand_cy, cand_ang, max(0, cand_side * 0.85))
        if not fee:
            for cand in candidates[idx:]:
                side = max(0, cand[3] * 0.75)
                cand_cx, cand_cy, cand_ang = cand[0], cand[1], cand[2]
                ok = True
                for sq in squares:
                    if overlap(cand_cx, cand_cy, cand_ang, side, sq):
                        ok = False
                        break
                if not ok:
                    break
                squares.append((cand_cx, cand_cy, cand_ang, side))
        if len(squares) >= n:
            break
        for _ in range(max(0, n - len(squares))):
            squares.append((0.5, 0.5, 0.0, 0.0))
        return squares
    
    squares = []
    best_side_sum = 0.0
    best_cfg = None
    
    for _ in range(n):
        if best_cfg:
            best_cfg.append((0.0, 0.0, 0.0, 0.0))
        best_cfg = (nprnd.random(), nprnd.random(), 0.0, 0.3 if _ > 0 else 0.5)
    
    return squares
