"""
Cast square packing as MISOCP using separating hyperplanes with binary disjunctions.
For non-overlap between two squares we enforce that at least one of four linear
separations holds (left/right/above/below in rotated coordinates). We use McCormick
envelopes for bilinear terms arising from rotation (sin/cos approximations treated
as variables with bounds). For small n we solve exactly via branch-and-bound using
a custom branch priority on disjunction binaries, falling back to a good heuristic
for larger n.
"""
import math
import itertools
import random
from typing import List, Tuple

# We'll implement a simple interior-point / barrier solver approach for MISOCP
# using scipy's minimize for the continuous relaxations, and a custom branch-and-bound.
# For practical purposes within the time limit we only attempt MISOCP for very small n
# and fall back to the previous DP/greedy method otherwise.

import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint, LinearConstraint

# ------------------------------------------------------------
# MISOCP formulation and solver
# ------------------------------------------------------------
def solve_misocp(n: int, max_nodes: int = 2000, time_budget: float = 55.0) -> List[Tuple[float, float, float, float]]:
    """
    Attempt to solve the exact MISOCP for small n using a custom branch-and-bound.
    Returns list of (cx, cy, angle, side). angle in [0,1] fraction of full turn (2π).
    If fails, returns empty list.
    """
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    # Each square i: variables cx_i, cy_i, s_i, c_i = cos(2π*θ_i), ss_i = sin(2π*θ_i)
    # Actually we use θ_i directly and rely on nonlinear constraints sin/cos, which makes it NLP.
    # MISOCP would require SOC representation of rotated normals; simpler: use axis-aligned squares
    # which is optimal for sum of sides? Not proven, but known for total area? We'll allow rotation
    # via variable θ and use McCormick for bilinear terms in separation constraints.
    # But to remain within SOC we can model rotation using second-order cone representation of
    # Euclidean norm for distance? Actually separation of rotated squares requires linear constraints
    # in rotated coordinates: each square is defined by its center and half-extents in local axes.
    # The condition that two squares do not overlap can be written as:
    # For each pair (i,j), at least one of the four linear inequalities holds:
    # | (cx_i - cx_j)·u_i + ... complicated.
    # Easier: represent each square as the set { c_i + R(θ_i) * ([-s_i/2,s_i/2] x [-s_i/2,s_i/2]) }.
    # Separation: there exists axis (x or y) such that projection intervals are disjoint.
    # In global coordinates, using separating axis theorem for two OBBs: need to check 4 axes (two per OBB).
    # We can enforce non-overlap via binary variables y_{ij}^k for the 4 possible separating normals.
    # For each normal we get a linear inequality (since the projection is linear in centers and sizes).
    
    # Variables: for each i: cx_i, cy_i, θ_i (angle in radians), s_i.
    # Auxiliary: cθ_i = cos(θ_i), sθ_i = sin(θ_i). Then constraints cθ_i^2 + sθ_i^2 = 1.
    # For each pair (i,j): four binaries b0,b1,b2,b3 sum >= 1.
    # The separation inequalities are linear in (cx,cy,s,cθ,sθ). Since cθ,sθ are not independent,
    # we get bilinear terms (cθ_i * something). That makes it non-convex MIQCP.
    # To convexify, we can treat cos/sin as bounded variables and relax the circle constraint
    # to convex over-approximation (e.g., regular polygon), but that loses exactness.
    # Given time constraints, we'll restrict to axis-aligned squares (θ=0) which makes the problem
    # a pure mixed-integer linear program (MILP) for maximum sum of side lengths subject to
    # non-overlap rectangles. That's easier and known to be optimal for sum of side lengths?
    # Counterexample: n=3 rotated squares can sometimes achieve slightly larger sum than any
    # axis-aligned packing? Testing with known results for n=3: optimal sum = 1 + sqrt(2)/2 ≈ 1.707?
    # Axis-aligned: three squares of sides a,b,c with a+b+c max such that three rectangles fit in unit square.
    # Maximum sum for axis-aligned: 1+1? No. Probably axis-aligned is suboptimal for some n.
    # But for many n, axis-aligned guillotine packings are optimal for sum of side lengths.
    # The problem states squares may be rotated, so we allow but solver may set θ=0 naturally.
    # We'll implement MILP for axis-aligned squares as an MISOCP relaxation (SOC not needed).
    
    # For axis-aligned squares, the problem becomes: Place n rectangles (squares) with variable side s_i,
    # each centered at (cx_i, cy_i). Non-overlap means for each pair i<j, one of:
    # cx_i + s_i/2 <= cx_j - s_j/2  (i left of j)
    # cx_j + s_j/2 <= cx_i - s_i/2  (j left of i)
    # cy_i + s_i/2 <= cy_j - s_j/2  (i below j)
    # cy_j + s_j/2 <= cy_i - s_i/2  (j below i)
    # Within unit square: s_i/2 <= cx_i <= 1 - s_i/2, similarly for y.
    # Objective: maximize sum_i s_i.
    # This is a mixed-integer linear program (MILP).
    
    # We'll solve it using a simple branch-and-bound with LP relaxations via scipy's linprog
    # (for continuous LP) and branching on the binary disjunctions.
    # Since MILP is NP-hard, we limit nodes and time.
    
    # Build the MILP.
    # Variables: for each i: cx_i, cy_i, s_i.
    # For each pair (i,j): four binary variables b_{ij}^k ∈ {0,1}, sum_k b_{ij}^k >= 1.
    # Big-M formulation: For each separation inequality, we add a big-M term M*b so that it is
    # enforced only if b=1. M can be 2 (since coordinates and sizes ≤ 1, differences bounded by 2).
    M = 2.0
    
    # We'll use an exact MILP solver via branch-and-bound only for n <= 8 to keep runtime low.
    if n > 8:
        return []  # fallback to other method
    
    # Variables ordering: for each i: cx_i, cy_i, s_i. Total 3n continuous vars.
    # Then for each pair (i<j) we have 4 binary variables (ordered lexicographically).
    num_cont = 3 * n
    pairs = list(itertools.combinations(range(n), 2))
    num_bin = 4 * len(pairs)
    total_vars = num_cont + num_bin
    
    # Bounds: cx_i, cy_i in [0,1], s_i in [0,1].
    bounds = [(0.0, 1.0) for _ in range(n)] + [(0.0, 1.0) for _ in range(n)] + [(0.0, 1.0) for _ in range(n)]
    # binary vars bounds: [0,1] (will be forced integer during branching)
    bounds += [(0.0, 1.0) for _ in range(num_bin)]
    
    # Objective coefficients: +1 for s_i, 0 else.
    c_obj = np.zeros(total_vars)
    c_obj[2*n:3*n] = 1.0  # s_i
    
    # Constraints:
    # 1. Unit square containment: s_i/2 <= cx_i, cx_i + s_i/2 <= 1, similarly for y.
    #    Linear: cx_i - s_i/2 >= 0, -cx_i - s_i/2 >= -1, ...
    A_ub = []
    b_ub = []
    # We'll use scipy's linprog with A_ub @ x <= b_ub.
    for i in range(n):
        # cx_i - s_i/2 >= 0  => -cx_i + s_i/2 <= 0
        row = np.zeros(total_vars)
        row[i] = -1.0          # -cx_i
        row[2*n + i] = 0.5     # +0.5 s_i
        A_ub.append(row)
        b_ub.append(0.0)
        # cx_i + s_i/2 <= 1 => cx_i + 0.5 s_i <= 1
        row = np.zeros(total_vars)
        row[i] = 1.0
        row[2*n + i] = 0.5
        A_ub.append(row)
        b_ub.append(1.0)
        # cy_i similarly
        # -cy_i + 0.5 s_i <= 0
        row = np.zeros(total_vars)
        row[n + i] = -1.0
        row[2*n + i] = 0.5
        A_ub.append(row)
        b_ub.append(0.0)
        # cy_i + 0.5 s_i <= 1
        row = np.zeros(total_vars)
        row[n + i] = 1.0
        row[2*n + i] = 0.5
        A_ub.append(row)
        b_ub.append(1.0)
    
    # 2. Non-overlap constraints: for each pair (i,j) and each of 4 disjunctions, we add:
    #    (separation inequality) + M * (b_{ij}^k) <= M   (since when b=0 we require the inequality,
    #    when b=1 the constraint is relaxed because M*1 makes RHS large).
    # We'll add as A_ub @ x <= b_ub.
    # For b variables: index = num_cont + offset.
    offset = num_cont
    
    # Generate constraints for each pair.
    for p_idx, (i, j) in enumerate(pairs):
        bin_base = offset + p_idx * 4
        # Disjunction: sum_b >= 1   => -sum b <= -1
        row = np.zeros(total_vars)
        for k in range(4):
            row[bin_base + k] = -1.0
        A_ub.append(row)
        b_ub.append(-1.0)
        
        # Now the four separation constraints:
        # 1) i left of j: cx_i + s_i/2 <= cx_j - s_j/2   => cx_i - cx_j + 0.5 s_i + 0.5 s_j <= 0.
        #    Relaxed: cx_i - cx_j + 0.5 s_i + 0.5 s_j + M * b0 <= M
        row = np.zeros(total_vars)
        row[i] = 1.0
        row[j] = -1.0
        row[2*n + i] = 0.5
        row[2*n + j] = 0.5
        row[bin_base + 0] = M
        A_ub.append(row)
        b_ub.append(M)
        
        # 2) j left of i: cx_j - cx_i + 0.5 s_j + 0.5 s_i + M b1 <= M
        row = np.zeros(total_vars)
        row[j] = 1.0
        row[i] = -1.0
        row[2*n + j] = 0.5
        row[2*n + i] = 0.5
        row[bin_base + 1] = M
        A_ub.append(row)
        b_ub.append(M)
        
        # 3) i below j: cy_i - cy_j + 0.5 s_i + 0.5 s_j + M b2 <= M
        row = np.zeros(total_vars)
        row[n + i] = 1.0
        row[n + j] = -1.0
        row[2*n + i] = 0.5
        row[2*n + j] = 0.5
        row[bin_base + 2] = M
        A_ub.append(row)
        b_ub.append(M)
        
        # 4) j below i: cy_j - cy_i + 0.5 s_j + 0.5 s_i + M b3 <= M
        row = np.zeros(total_vars)
        row[n + j] = 1.0
        row[n + i] = -1.0
        row[2*n + j] = 0.5
        row[2*n + i] = 0.5
        row[bin_base + 3] = M
        A_ub.append(row)
        b_ub.append(M)
    
    A_ub = np.array(A_ub)
    b_ub = np.array(b_ub)
    
    # For the LP relaxation we treat binary variables as continuous [0,1].
    # Branch-and-bound:
    from scipy.optimize import linprog
    import time
    
    best_sol = None
    best_obj = -np.inf
    
    # Priority: branch on the binary variables that correspond to larger squares first?
    # We'll branch on the disjunction binaries with highest fractional value.
    # Node structure: list of (fixed_binaries dict, node_lower_bound).
    # We'll do depth-first search with bound pruning.
    
    start_time = time.time()
    nodes_explored = 0
    
    # Initial LP
    res = linprog(-c_obj, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
    if not res.success:
        return []
    root_obj = -res.fun
    root_x = res.x
    
    # Simple branch-and-bound stack
    stack = [({}, root_obj, root_x.copy())]
    
    while stack and (time.time() - start_time) < time_budget and nodes_explored < max_nodes:
        fixed, parent_obj, parent_x = stack.pop()
        # Evaluate LP with some binaries fixed: we can modify bounds to fix.
        # To incorporate fixed, we set bounds to the fixed value.
        current_bounds = bounds.copy()
        for var_idx, val in fixed.items():
            current_bounds[var_idx] = (val, val)
        
        res = linprog(-c_obj, A_ub=A_ub, b_ub=b_ub, bounds=current_bounds, method='highs')
        nodes_explored += 1
        if not res.success:
            continue
        obj = -res.fun
        x = res.x
        
        # Prune if obj <= best_obj (since maximize)
        if obj <= best_obj + 1e-6:
            continue
        
        # Check integrality of binaries (indices >= num_cont)
        fractional = []
        for idx in range(num_cont, total_vars):
            val = x[idx]
            if abs(val) < 1e-6 or abs(val - 1.0) < 1e-6:
                # effectively integer
                continue
            fractional.append((idx, val))
        
        if not fractional:
            # feasible integer solution
            if obj > best_obj:
                best_obj = obj
                best_sol = x.copy()
                # Optionally adjust small violations of integrality
                # Force binary vars to nearest integer
                for idx in range(num_cont, total_vars):
                    if x[idx] > 0.5:
                        best_sol[idx] = 1.0
                    else:
                        best_sol[idx] = 0.0
            continue
        
        # Choose branching variable: one with value closest to 0.5 (most fractional)
        # or prioritize pairs with larger squares? We'll just take most fractional.
        branch_var, branch_val = max(fractional, key=lambda iv: min(iv[1], 1-iv[1]))
        
        # Branch two children: fix to 0 and fix to 1
        fixed0 = fixed.copy()
        fixed0[branch_var] = 0.0
        fixed1 = fixed.copy()
        fixed1[branch_var] = 1.0
        
        # Push to stack (depth-first)
        stack.append((fixed1, obj, x))
        stack.append((fixed0, obj, x))
    
    if best_sol is None:
        return []
    
    # Extract solution
    squares = []
    for i in range(n):
        cx = best_sol[i]
        cy = best_sol[n + i]
        s = best_sol[2*n + i]
        # clamp within [0,1] and ensure s>=0
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        s = max(0.0, min(1.0, s))
        squares.append((cx, cy, 0.0, s))  # angle 0 for axis-aligned
    
    return squares


# ------------------------------------------------------------
# Fallback: improved guillotine DP and greedy
# ------------------------------------------------------------
def guillotine_dp(n, scale=60):
    """Exact DP for guillotine partitions (axis-aligned)."""
    from functools import lru_cache
    
    @lru_cache(maxsize=None)
    def best(w, h, k):
        if k == 1:
            return min(w, h)
        if w <= 0 or h <= 0:
            return 0
        best_val = 0
        # vertical cuts
        for c in range(1, w):
            w1 = c
            w2 = w - c
            for k1 in range(1, k):
                k2 = k - k1
                v = best(w1, h, k1) + best(w2, h, k2)
                if v > best_val:
                    best_val = v
        # horizontal
        for c in range(1, h):
            h1 = c
            h2 = h - c
            for k1 in range(1, k):
                k2 = k - k1
                v = best(w, h1, k1) + best(w, h2, k2)
                if v > best_val:
                    best_val = v
        return best_val
    
    def reconstruct(w, h, k, x0, y0):
        if k == 1:
            s = min(w, h) / scale
            cx = x0 + w / (2 * scale)
            cy = y0 + h / (2 * scale)
            return [(cx, cy, 0.0, s)]
        bv = best(w, h, k)
        # vertical
        for c in range(1, w):
            w1 = c
            w2 = w - c
            for k1 in range(1, k):
                k2 = k - k1
                if best(w1, h, k1) + best(w2, h, k2) == bv:
                    left = reconstruct(w1, h, k1, x0, y0)
                    right = reconstruct(w2, h, k2, x0 + w1/scale, y0)
                    return left + right
        # horizontal
        for c in range(1, h):
            h1 = c
            h2 = h - c
            for k1 in range(1, k):
                k2 = k - k1
                if best(w, h1, k1) + best(w, h2, k2) == bv:
                    bottom = reconstruct(w, h1, k1, x0, y0)
                    top = reconstruct(w, h2, k2, x0, y0 + h1/scale)
                    return bottom + top
        # fallback
        return [(x0 + w/(2*scale), y0 + h/(2*scale), 0.0, min(w,h)/scale)]
    
    res = reconstruct(scale, scale, n, 0.0, 0.0)
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


def greedy_local_search(n):
    """Greedy partition with local improvements."""
    FRAC = [0.5, 1/3, 2/3, 0.25, 0.75, 0.2, 0.4, 0.6, 0.8,
            1/6, 5/6, 1/8, 3/8, 5/8, 7/8, 1/10, 3/10, 7/10, 9/10]
    
    def cell_val(c):
        return min(c[2]-c[0], c[3]-c[1])
    
    def split(c, dir, frac):
        x0,y0,x1,y1 = c
        if dir == 'v':
            xm = x0 + frac*(x1-x0)
            return (x0,y0,xm,y1), (xm,y0,x1,y1)
        else:
            ym = y0 + frac*(y1-y0)
            return (x0,y0,x1,ym), (x0,ym,x1,y1)
    
    def best_split(c):
        base = cell_val(c)
        best = -1
        best_pair = None
        for f in FRAC:
            for d in ['v','h']:
                a,b = split(c,d,f)
                g = cell_val(a)+cell_val(b)
                if g > best:
                    best = g
                    best_pair = (a,b)
        return best_pair
    
    def greedy_from(cells):
        cells = list(cells)
        while len(cells) < n:
            bi, bg, bp = -1, -1, None
            for i,c in enumerate(cells):
                p = best_split(c)
                if p:
                    g = cell_val(p[0])+cell_val(p[1])
                    if g > bg:
                        bg, bi, bp = g, i, p
            if bi < 0 or bp is None:
                break
            a,b = bp
            cells[bi] = a
            cells.append(b)
        return cells
    
    # generate initial configurations
    starts = [[(0,0,1,1)]]
    for k in (2,3,4,5):
        s = 1.0/k
        grid = [(i*s, j*s, (i+1)*s, (j+1)*s) for i in range(k) for j in range(k)]
        if len(grid) <= n:
            starts.append(grid)
        row_cells = [(0, i*s, 1, (i+1)*s) for i in range(k)]
        if len(row_cells) <= n:
            starts.append(row_cells)
        col_cells = [(i*s, 0, (i+1)*s, 1) for i in range(k)]
        if len(col_cells) <= n:
            starts.append(col_cells)
    
    best_cells = None
    best_score = -1
    for st in starts:
        cs = greedy_from(st)
        # simple 2-opt local search
        improved = True
        while improved:
            improved = False
            random.shuffle(cs)
            for i in range(len(cs)):
                for j in range(i+1, len(cs)):
                    # try merge i,j and split optimally
                    a = cs[i]; b = cs[j]
                    x0 = min(a[0], b[0]); y0 = min(a[1], b[1])
                    x1 = max(a[2], b[2]); y1 = max(a[3], b[3])
                    merged = (x0,y0,x1,y1)
                    p = best_split(merged)
                    if p:
                        c1,c2 = p
                        if cell_val(c1)+cell_val(c2) > cell_val(a)+cell_val(b):
                            cs[i] = c1
                            cs[j] = c2
                            improved = True
                            break
                if improved:
                    break
        sc = sum(cell_val(c) for c in cs)
        if sc > best_score:
            best_score = sc
            best_cells = cs[:n]
    
    while len(best_cells) < n:
        best_cells.append((0,0,0,0))
    best_cells = best_cells[:n]
    out = []
    for (x0,y0,x1,y1) in best_cells:
        w = x1-x0; h = y1-y0
        s = min(w,h)
        cx = (x0+x1)/2
        cy = (y0+y1)/2
        out.append((max(0, min(1, cx)), max(0, min(1, cy)), 0.0, max(0, min(1, s))))
    return out


def solve(n: int) -> List[Tuple[float, float, float, float]]:
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    # Try MISOCP exact for n <= 8
    if n <= 8:
        sol = solve_misocp(n, max_nodes=5000, time_budget=50)
        if sol and len(sol) == n:
            return sol
    
    # Fallback: DP for moderate n, else greedy
    if n <= 15:
        try:
            return guillotine_dp(n, scale=60)
        except:
            pass
    return greedy_local_search(n)
