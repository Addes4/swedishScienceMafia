# EVOLVE-BLOCK-START
"""Guillotine k-d partition via exact DP on a fine rational grid.

Core idea: the largest axis-aligned square in an axis-aligned rectangle has
side min(w,h); any rectilinear guillotine partition into k rectangles yields
total sum = sum of min(w,h) over leaves. We optimise over guillotine cuts by
DP over rectangle shapes represented on a fine integer grid.

To make DP tractable for n up to ~40 we:
  * Represent widths/heights as integers in [0..G].
  * memoise best(k, w, h) for rectangles only.
  * Prune by symmetry (w <= h) and by the trivial upper bound min(w,h)*k.
  * Use a coarse grid G for large n and a fine grid for small n.
  * Split search only over integer cut positions, exploiting that the
    optimal guillotine partition for the min-sum objective always has cuts
    at positions determined by the squares' sides relative to the bounding
    rectangle; using a fine grid approximates this.

For very large n where DP is infeasible we fall back to a fast hierarchical
greedy that subdivides using a best-split heuristic with local improvement.
"""

import math
import random
from functools import lru_cache
import sys


# ---------------------------------------------------------------------------
# Exact DP on an integer grid
# ---------------------------------------------------------------------------
def _solve_dp(n, G):
    """Return list of cells (x0,y0,x1,y1) in unit coords of a guillotine
    partition of [0,1]^2 into n rectangles maximising sum of min(w,h).

    All coordinates are multiples of 1/G.
    """
    # memo[(k, w, h)] -> best total (in grid units of side length)
    # We exploit symmetry w <= h by swapping.
    memo = {}

    # Upper bound: a rectangle of w x h can hold at most k squares each of
    # side <= min(w,h); also area bound: k * s^2 <= w*h.
    def ub(k, w, h):
        m = w if w < h else h
        s1 = m * k
        # area bound gives s <= sqrt(w*h/k)
        ar = math.sqrt((w * h) / k) if k > 0 else 0.0
        s2 = ar * k
        return min(s1, s2)

    def best(k, w, h):
        if k <= 0:
            return 0.0
        if w <= 0 or h <= 0:
            return 0.0
        if w > h:
            w, h = h, w
        if k == 1:
            return float(w if w < h else h)
        key = (k, w, h)
        v = memo.get(key)
        if v is not None:
            return v
        # trivial lower bound: single block for k-1 cells -> many 0-size,
        # but that is bad; use greedy cut as lower bound fallback later.
        bestval = -1.0
        # Try vertical cuts: split width
        # To reduce branching, only consider cuts that make both sides usable.
        # For each cut c in [1, w-1], split k1.
        # Explore k1 near balanced for speed; but we need optimal so all.
        # Prune using upper bounds.
        wmax = min(w // 2, w - 1)
        for c in range(1, w):
            w1 = c
            w2 = w - c
            # quick check: if even the ub of both sides can't beat bestval, skip
            for k1 in range(1, k):
                k2 = k - k1
                if k1 > w1 * h and k2 > w2 * h:
                    # both overfull (can't give each its own min side) but
                    # still allowed since cells can be zero; skip only if
                    # obviously wasteful
                    pass
                u1 = ub(k1, w1, h)
                u2 = ub(k2, w2, h)
                u = u1 + u2
                if u <= bestval:
                    continue
                v1 = best(k1, w1, h)
                v2 = best(k2, w2, h)
                tot = v1 + v2
                if tot > bestval:
                    bestval = tot
        # horizontal cuts
        for c in range(1, h):
            h1 = c
            h2 = h - c
            for k1 in range(1, k):
                k2 = k - k1
                u1 = ub(k1, w, h1)
                u2 = ub(k2, w, h2)
                u = u1 + u2
                if u <= bestval:
                    continue
                v1 = best(k1, w, h1)
                v2 = best(k2, w, h2)
                tot = v1 + v2
                if tot > bestval:
                    bestval = tot
        # fallback: all k squares in one row/col stacked, each min side
        if bestval < 0:
            bestval = float(w if w < h else h)
        memo[key] = bestval
        return bestval

    # reconstruct
    def reconstruct(k, w, h):
        if k <= 0:
            return []
        if k == 1:
            return [(0, 0, w, h)]
        if w > h:
            w, h = h, w
        target = best(k, w, h)
        # vertical cuts
        for c in range(1, w):
            w1 = c
            w2 = w - c
            for k1 in range(1, k):
                k2 = k - k1
                u1 = ub(k1, w1, h)
                u2 = ub(k2, w2, h)
                if u1 + u2 < target - 1e-9:
                    continue
                if abs(best(k1, w1, h) + best(k2, w2, h) - target) < 1e-9:
                    left = reconstruct(k1, w1, h)
                    right = reconstruct(k2, w2, h)
                    out = []
                    for (a, b, cc, d) in left:
                        out.append((a, b, cc, d))
                    for (a, b, cc, d) in right:
                        out.append((a + w1, b, cc + w1, d))
                    return out
        # horizontal cuts
        for c in range(1, h):
            h1 = c
            h2 = h - c
            for k1 in range(1, k):
                k2 = k - k1
                u1 = ub(k1, w, h1)
                u2 = ub(k2, w, h2)
                if u1 + u2 < target - 1e-9:
                    continue
                if abs(best(k1, w, h1) + best(k2, w, h2) - target) < 1e-9:
                    bot = reconstruct(k1, w, h1)
                    top = reconstruct(k2, w, h2)
                    out = []
                    for (a, b, cc, d) in bot:
                        out.append((a, b, cc, d))
                    for (a, b, cc, d) in top:
                        out.append((a, b + h1, cc, d + h1))
                    return out
        # fallback (should not reach)
        return [(0, 0, w, h)]

    val = best(n, G, G)
    cells_grid = reconstruct(n, G, G)
    # convert to unit coords
    cells = []
    for (x0, y0, x1, y1) in cells_grid:
        cells.append((x0 / G, y0 / G, x1 / G, y1 / G))

    # pad if fewer than n (should not happen). Degenerate rects are fine.
    while len(cells) < n:
        cells.append((0.0, 0.0, 0.0, 0.0))
    return cells[:n]


# ---------------------------------------------------------------------------
# Fast fallback: hierarchical greedy with best-split + local search
# ---------------------------------------------------------------------------
def _solve_fallback(n):
    FRAC = [0.5, 1/3, 2/3, 0.25, 0.75, 0.2, 0.4, 0.6, 0.8,
            1/6, 5/6, 1/8, 3/8, 5/8, 7/8, 1/10, 3/10, 7/10, 9/10,
            0.45, 0.55, 0.35, 0.65, 0.15, 0.85]

    def cval(c):
        return min(c[2] - c[0], c[3] - c[1])

    def split(c, direction, frac):
        x0, y0, x1, y1 = c
        if direction == 'v':
            xc = x0 + frac * (x1 - x0)
            return (x0, y0, xc, y1), (xc, y0, x1, y1)
        else:
            yc = y0 + frac * (y1 - y0)
            return (x0, y0, x1, yc), (x0, yc, x1, y1)

    def best_split(c):
        base = cval(c)
        bg = -1e18
        bp = None
        for f in FRAC:
            c1, c2 = split(c, 'v', f)
            g = cval(c1) + cval(c2) - base
            if g > bg:
                bg = g
                bp = (c1, c2)
            c1, c2 = split(c, 'h', f)
            g = cval(c1) + cval(c2) - base
            if g > bg:
                bg = g
                bp = (c1, c2)
        return bg, bp

    def greedy(init):
        cells = list(init)
        while len(cells) < n:
            bi = -1
            bg = -1e18
            bp = None
            for i, c in enumerate(cells):
                g, p = best_split(c)
                if g > bg:
                    bg = g
                    bi = i
                    bp = p
            if bi < 0 or bp is None:
                break
            a, b = bp
            cells[bi] = a
            cells.append(b)
        return cells

    rng = random.Random(12345)

    starts = []
    starts.append([(0.0, 0.0, 1.0, 1.0)])
    for kk in (2, 3, 4, 5, 6):
        s = 1.0 / kk
        g = [(i * s, j * s, (i + 1) * s, (j + 1) * s)
             for i in range(kk) for j in range(kk)]
        if len(g) <= n:
            starts.append(g)
    for kk in (2, 3, 4, 5, 6, 7):
        s = 1.0 / kk
        g = [(0.0, i * s, 1.0, (i + 1) * s) for i in range(kk)]
        if len(g) <= n:
            starts.append(g)
        g = [(j * s, 0.0, (j + 1) * s, 1.0) for j in range(kk)]
        if len(g) <= n:
            starts.append(g)

    best_cells = None
    best_score = -1.0
    for st in starts:
        cs = greedy(st)
        # local improvement: merge/re-split pairs
        improved = True
        it = 0
        while improved and it < 4:
            improved = False
            it += 1
            m = len(cs)
            for _ in range(min(80, m * 2)):
                i, j = rng.randrange(m), rng.randrange(m)
                if i == j:
                    continue
                a, b = cs[i], cs[j]
                x0 = min(a[0], b[0]); y0 = min(a[1], b[1])
                x1 = max(a[2], b[2]); y1 = max(a[3], b[3])
                orig = cval(a) + cval(b)
                _, pair = best_split((x0, y0, x1, y1))
                if pair is not None:
                    nv = cval(pair[0]) + cval(pair[1])
                    if nv > orig + 1e-12:
                        cs[i], cs[j] = pair
                        improved = True
        sc = sum(cval(c) for c in cs)
        if sc > best_score:
            best_score = sc
            best_cells = cs

    while len(best_cells) < n:
        best_cells.append((0.0, 0.0, 0.0, 0.0))
    best_cells = best_cells[:n]
    return best_cells


# ---------------------------------------------------------------------------
# Convert cells to square placements
# ---------------------------------------------------------------------------
def _cells_to_output(cells):
    out = []
    for (x0, y0, x1, y1) in cells:
        w = x1 - x0
        h = y1 - y0
        s = min(w, h)
        cx = 0.5 * (x0 + x1)
        cy = 0.5 * (y0 + y1)
        if cx < 0: cx = 0.0
        if cx > 1: cx = 1.0
        if cy < 0: cy = 0.0
        if cy > 1: cy = 1.0
        if s < 0: s = 0.0
        if s > 1: s = 1.0
        out.append((cx, cy, 0.0, s))
    return out


# ---------------------------------------------------------------------------
# Main dispatcher
# ---------------------------------------------------------------------------
def solve(n):
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Choose grid size G and method based on n.
    # DP cost grows roughly like G^2 * n^3 (memo per (k,w,h) with cuts*k1).
    # Empirically we can afford:
    #   n <= 6   : G ~ 120
    #   n <= 12  : G ~ 80
    #   n <= 20  : G ~ 50
    #   n <= 30  : G ~ 34
    #   n <= 40  : G ~ 26
    # For larger n we use the DP with a coarse grid if feasible, else fallback.
    if n <= 6:
        G = 120
    elif n <= 9:
        G = 90
    elif n <= 12:
        G = 72
    elif n <= 16:
        G = 56
    elif n <= 20:
        G = 46
    elif n <= 25:
        G = 38
    elif n <= 30:
        G = 32
    elif n <= 40:
        G = 26
    elif n <= 60:
        G = 20
    elif n <= 100:
        G = 14
    else:
        G = 10

    # Attempt DP with a time-aware guard: use a simple heuristic on cost.
    cost = (G * G) * (n * n * n)
    # Threshold tuned empirically; be conservative for very large cost.
    if cost <= 8_000_000 or n <= 8:
        try:
            cells = _solve_dp(n, G)
            return _cells_to_output(cells)
        except (RecursionError, MemoryError):
            pass

    # Fallback
    try:
        cells = _solve_fallback(n)
        return _cells_to_output(cells)
    except Exception:
        # last resort: simple grid
        out = []
        k = int(math.ceil(math.sqrt(n)))
        s = 1.0 / k
        cnt = 0
        for i in range(k):
            for j in range(k):
                if cnt >= n:
                    break
                out.append((i * s + s / 2, j * s + s / 2, 0.0, s))
                cnt += 1
        while len(out) < n:
            out.append((0.0, 0.0, 0.0, 0.0))
        return out[:n]

# EVOLVE-BLOCK-END
