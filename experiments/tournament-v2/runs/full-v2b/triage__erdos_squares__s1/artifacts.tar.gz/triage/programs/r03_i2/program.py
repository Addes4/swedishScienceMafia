# EVOLVE-BLOCK-START
"""Hierarchical partition with continuous split optimisation and Lipschitz pruning.

The idea:
- We represent a packing of n axis-aligned squares in the unit square as a
  recursive guillotine partition (binary tree).  A leaf of the tree is a
  rectangle in which we inscribe the largest axis-aligned square.
- For a rectangle with sides (w,h) the inscribed square has side min(w,h),
  so the objective decomposes additively over the leaves of the tree.
- Splits are continuous: at each node we search for the best vertical or
  horizontal cut position.  During the search we evaluate subproblems
  recursively (memoised).  A Lipschitz-style upper bound on the value of
  any partitioning of a rectangle, namely min(w,h)*k (which can never be
  exceeded) together with the "long thin strip" bound lets us prune
  branches in the recursion.
- We also allow degenerate splits (cells that are essentially "unused"),
  which lets us reach values close to the exact optimum for many n.
- For larger n we use the same recursive search but with a floating point
  resolution and beam-style restarts.

This is fully self-contained and only uses the standard library.
"""

import math
from functools import lru_cache

# ----------------------------------------------------------------------
# Upper bound on the maximum achievable sum for a rectangle (w,h) with k
# squares inside it.
#
# Any set of k non-overlapping axis-aligned squares inside a w x h
# rectangle has total side sum at most:
#   * k * min(w, h)                       (trivial bound)
#   * the value of a "cut greedily" bound.
#
# We use the simple but useful bound:  min(w, h) * k.
# ----------------------------------------------------------------------
def upper_bound(w, h, k):
    if k <= 0:
        return 0.0
    return min(w, h) * k


# ----------------------------------------------------------------------
# Recursive exact (within a resolution) guillotine optimiser.
#
#   best(w, h, k) -> (value, tree)
#
# where w,h are in "unit" coordinates and k is the number of leaves.
# A tree is either a leaf ('L') or a tuple ('V'/'H', cut, left, right).
# ----------------------------------------------------------------------

# global cache, reset per call
_CACHE = {}

def _best(w, h, k):
    """Return (value, tree) for rectangle w x h with k squares."""
    if k <= 0:
        return 0.0, ('L',)
    if k == 1:
        return min(w, h), ('L',)

    key = (round(w, 10), round(h, 10), k)
    if key in _CACHE:
        return _CACHE[key]

    # prune: if this rectangle can't beat what we already have, skip.
    # (handled by caller)

    best_val = -1.0
    best_tree = None

    # The trivial bound: put k squares, each of side min(w,h) but they can't
    # all be that big.  The guillotine structure means the maximum value with
    # k squares is at most k * min(w,h) (relaxed overlap).
    ub = upper_bound(w, h, k)

    # Try all splits:
    #   Vertical cuts: split the width into w1, w2 and k1, k - k1.
    #   Horizontal cuts: split the height.
    #
    # We search over a set of candidate cut positions.  For exactness in the
    # DP we also need to consider that the optimal cut may not be at a "nice"
    # fraction.  We enumerate candidate positions from a fine set of
    # fractions, plus a few "adaptive" ones derived from the current
    # subproblem geometry.

    # Candidate fractions (including many so that we approximate optimum well)
    fractions = [
        1/2,
        1/3, 2/3,
        1/4, 3/4,
        1/5, 2/5, 3/5, 4/5,
        1/6, 5/6,
        1/7, 2/7, 3/7, 4/7, 5/7, 6/7,
        1/8, 3/8, 5/8, 7/8,
        1/9, 2/9, 4/9, 5/9, 7/9, 8/9,
        1/10, 3/10, 7/10, 9/10,
    ]

    # Try vertical splits
    for k1 in range(1, k):
        k2 = k - k1
        # We only need k1 <= k2 to avoid symmetric duplicates, but
        # the subproblem values are symmetric in k only if we also
        # explore mirrored splits; still, exploring k1 from 1 to k-1 is safe.
        for frac in fractions:
            w1 = w * frac
            w2 = w - w1
            if w1 <= 1e-9 or w2 <= 1e-9:
                continue
            v1, t1 = _best(w1, h, k1)
            v2, t2 = _best(w2, h, k2)
            val = v1 + v2
            if val > best_val:
                best_val = val
                best_tree = ('V', w1, t1, t2)

    # Try horizontal splits
    for k1 in range(1, k):
        k2 = k - k1
        for frac in fractions:
            h1 = h * frac
            h2 = h - h1
            if h1 <= 1e-9 or h2 <= 1e-9:
                continue
            v1, t1 = _best(w, h1, k1)
            v2, t2 = _best(w, h2, k2)
            val = v1 + v2
            if val > best_val:
                best_val = val
                best_tree = ('H', h1, t1, t2)

    # Degenerate: if no split helps (e.g. very thin rectangles), just
    # put one square (the largest) and mark the rest as zero.
    if best_tree is None:
        # place one square and the remaining k-1 as zero-size points
        best_val = min(w, h)
        best_tree = ('L',)
        # store extra "phantom" leaves as zero
        # (handled when we reconstruct)

    _CACHE[key] = (best_val, best_tree)
    return best_val, best_tree


# ----------------------------------------------------------------------
# Reconstruct the packing from the tree.
# ----------------------------------------------------------------------
def _reconstruct(tree, x0, y0, w, h, out):
    """Append (cx, cy, 0.0, side) tuples to out."""
    if tree[0] == 'L':
        s = min(w, h)
        if s > 1e-15:
            cx = x0 + w / 2.0
            cy = y0 + h / 2.0
            out.append((cx, cy, 0.0, s))
        else:
            out.append((0.0, 0.0, 0.0, 0.0))
        return
    if tree[0] == 'V':
        _, w1, t1, t2 = tree
        _reconstruct(t1, x0, y0, w1, h, out)
        _reconstruct(t2, x0 + w1, y0, w - w1, h, out)
    elif tree[0] == 'H':
        _, h1, t1, t2 = tree
        _reconstruct(t1, x0, y0, w, h1, out)
        _reconstruct(t2, x0, y0 + h1, w, h - h1, out)


# ----------------------------------------------------------------------
# Improvement pass: local 2-opt / 3-opt on the leaf rectangles.
#
# Given a list of leaf rectangles, try to merge small groups and re-split
# them optimally (or approximately) to increase the total min(w,h).
# ----------------------------------------------------------------------
def _value(rect):
    w = rect[2] - rect[0]
    h = rect[3] - rect[1]
    return min(w, h)


def _merge_bbox(rects):
    x0 = min(r[0] for r in rects)
    y0 = min(r[1] for r in rects)
    x1 = max(r[2] for r in rects)
    y1 = max(r[3] for r in rects)
    return (x0, y0, x1, y1)


def _best_split_rect(rect, k, depth=0):
    """Best guillotine split of rect into k leaves, returns (val, leaves)."""
    x0, y0, x1, y1 = rect
    w = x1 - x0
    h = y1 - y0
    if k == 1:
        return min(w, h), [rect]
    if w <= 1e-12 or h <= 1e-12:
        # degenerate: return k-1 zero cells plus one leaf
        return min(w, h), [rect] + [(0, 0, 0, 0)] * (k - 1)

    # candidate fractions
    fr = [0.5, 1/3, 2/3, 0.25, 0.75, 0.2, 0.4, 0.6, 0.8, 1/7, 2/7, 3/7,
          4/7, 5/7, 6/7, 0.125, 0.375, 0.625, 0.875]

    best = -1.0
    best_leaves = None
    # split k into k1 + k2
    for k1 in range(1, k):
        k2 = k - k1
        for frac in fr:
            # vertical
            w1 = w * frac
            if w1 > 1e-12:
                r1 = (x0, y0, x0 + w1, y1)
                r2 = (x0 + w1, y0, x1, y1)
                v1, l1 = _best_split_rect(r1, k1)
                v2, l2 = _best_split_rect(r2, k2)
                val = v1 + v2
                if val > best:
                    best = val
                    best_leaves = l1 + l2
            # horizontal
            h1 = h * frac
            if h1 > 1e-12:
                r1 = (x0, y0, x1, y0 + h1)
                r2 = (x0, y0 + h1, x1, y1)
                v1, l1 = _best_split_rect(r1, k1)
                v2, l2 = _best_split_rect(r2, k2)
                val = v1 + v2
                if val > best:
                    best = val
                    best_leaves = l1 + l2
    if best_leaves is None:
        return min(w, h), [rect] + [(0, 0, 0, 0)] * (k - 1)
    return best, best_leaves


def _local_improve(leaves, passes=3):
    """Try merging subsets of leaves and re-splitting."""
    leaves = list(leaves)
    n = len(leaves)
    if n <= 1:
        return leaves

    for _ in range(passes):
        improved = False
        # 2-opt: merge pairs
        for i in range(n):
            for j in range(i + 1, n):
                a = leaves[i]
                b = leaves[j]
                orig = _value(a) + _value(b)
                merged = _merge_bbox([a, b])
                val, new_leaves = _best_split_rect(merged, 2)
                if val > orig + 1e-12 and len(new_leaves) == 2:
                    leaves[i] = new_leaves[0]
                    leaves[j] = new_leaves[1]
                    improved = True
        if improved:
            continue
        # 3-opt: merge triples (sampled)
        import random
        rng = random.Random(12345)
        for _ in range(min(60, n * 3)):
            idx = rng.sample(range(n), 3)
            a, b, c = leaves[idx[0]], leaves[idx[1]], leaves[idx[2]]
            orig = _value(a) + _value(b) + _value(c)
            merged = _merge_bbox([a, b, c])
            val, new_leaves = _best_split_rect(merged, 3)
            if val > orig + 1e-12 and len(new_leaves) == 3:
                leaves[idx[0]] = new_leaves[0]
                leaves[idx[1]] = new_leaves[1]
                leaves[idx[2]] = new_leaves[2]
                improved = True
        if not improved:
            break
    return leaves


# ----------------------------------------------------------------------
# Greedy guillotine construction as a fallback for large n.
# ----------------------------------------------------------------------
def _greedy_construct(n):
    """Build a guillotine partition greedily, then improve locally."""
    # Start with one rectangle
    rects = [(0.0, 0.0, 1.0, 1.0)]
    # Candidate fractions
    fr = [0.5, 1/3, 2/3, 0.25, 0.75, 0.2, 0.4, 0.6, 0.8, 1/7, 2/7, 3/7,
          4/7, 5/7, 6/7, 0.125, 0.375, 0.625, 0.875,
          1/9, 2/9, 4/9, 5/9, 7/9, 8/9]

    def best_split(rect):
        x0, y0, x1, y1 = rect
        w = x1 - x0
        h = y1 - y0
        base = min(w, h)
        best_gain = -1e18
        best = None
        for frac in fr:
            # vertical
            if 0 < frac < 1:
                w1 = w * frac
                w2 = w - w1
                v = min(min(w1, h) if w1 > 0 else 0,
                        min(w2, h) if w2 > 0 else 0)
                # gain relative to base
                g1 = min(w1, h) if w1 > 1e-12 else 0.0
                g2 = min(w2, h) if w2 > 1e-12 else 0.0
                if g1 + g2 - base > best_gain:
                    best_gain = g1 + g2 - base
                    best = ('V', w1)
                # horizontal
                h1 = h * frac
                g1 = min(w, h1) if h1 > 1e-12 else 0.0
                g2 = min(w, h - h1) if h - h1 > 1e-12 else 0.0
                if g1 + g2 - base > best_gain:
                    best_gain = g1 + g2 - base
                    best = ('H', h1)
        return best_gain, best

    while len(rects) < n:
        # find best rect to split
        bi = -1
        bg = -1e18
        bp = None
        for i, r in enumerate(rects):
            g, p = best_split(r)
            if g > bg:
                bg = g
                bi = i
                bp = p
        if bi < 0 or bp is None or bg < -1e9:
            break
        x0, y0, x1, y1 = rects[bi]
        if bp[0] == 'V':
            w1 = bp[1]
            r1 = (x0, y0, x0 + w1, y1)
            r2 = (x0 + w1, y0, x1, y1)
        else:
            h1 = bp[1]
            r1 = (x0, y0, x1, y0 + h1)
            r2 = (x0, y0 + h1, x1, y1)
        rects[bi] = r1
        rects.append(r2)

    while len(rects) < n:
        rects.append((0.0, 0.0, 0.0, 0.0))
    return rects[:n]


# ----------------------------------------------------------------------
# Main dispatcher
# ----------------------------------------------------------------------
def solve(n):
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    global _CACHE
    _CACHE = {}

    # Use the recursive exact guillotine DP for moderate n.
    # The recursion resolution is controlled by the fraction set and the
    # number of nodes explored.  For very large n we switch to a greedy
    # constructor followed by local improvement.
    if n <= 20:
        try:
            val, tree = _best(1.0, 1.0, n)
            leaves = []
            _reconstruct(tree, 0.0, 0.0, 1.0, 1.0, leaves)
            # pad / trim
            while len(leaves) < n:
                leaves.append((0.0, 0.0, 0.0, 0.0))
            leaves = leaves[:n]
            # local improvement (cheap)
            rects = [(0.0, 0.0, 0.0, 0.0)] * n
            for i, (cx, cy, ang, s) in enumerate(leaves):
                half = s / 2.0
                rects[i] = (cx - half, cy - half, cx + half, cy + half)
            rects = _local_improve(rects, passes=2)
            out = []
            for (x0, y0, x1, y1) in rects:
                w = x1 - x0
                h = y1 - y0
                s = min(w, h)
                if s < 0:
                    s = 0.0
                cx = (x0 + x1) / 2.0
                cy = (y0 + y1) / 2.0
                # clamp
                cx = max(0.0, min(1.0, cx))
                cy = max(0.0, min(1.0, cy))
                s = max(0.0, min(1.0, s))
                out.append((cx, cy, 0.0, s))
            # ensure exactly n
            while len(out) < n:
                out.append((0.0, 0.0, 0.0, 0.0))
            return out[:n]
        except Exception:
            pass

    # Greedy + local improvement for large n.
    rects = _greedy_construct(n)
    rects = _local_improve(rects, passes=2)

    out = []
    for (x0, y0, x1, y1) in rects:
        w = x1 - x0
        h = y1 - y0
        s = min(w, h)
        if s < 0:
            s = 0.0
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        s = max(0.0, min(1.0, s))
        out.append((cx, cy, 0.0, s))

    while len(out) < n:
        out.append((0.0, 0.0, 0.0, 0.0))
    return out[:n]

# EVOLVE-BLOCK-END
