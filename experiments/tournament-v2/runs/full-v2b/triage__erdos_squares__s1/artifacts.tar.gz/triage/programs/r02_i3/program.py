# EVOLVE-BLOCK-START
"""Genetic algorithm over guillotine partition trees.

Idea:
- Encode a guillotine partition of the unit square as a binary tree.
  Leaves hold a square size (min of cell dimensions); internal nodes
  specify a split direction ('v'/'h') and a split fraction.
- Variable length chromosome = flattened post-order traversal of the tree
  with all n leaves present.
- Decode: recursively subdivide the unit square; each leaf's square has side
  min(w, h) and is centered in its cell. Fitness = sum of leaf sizes.
- Genetic operators:
    * crossover: pick a random subtree pair (respecting leaf count budget)
      by recombining with a cut-and-paste on the flattened representation;
      simpler: uniform crossover on node-level split params plus subtree swap.
    * mutation: perturb a split fraction, flip a direction, or rebalance
      the leaf counts between the two children of a random internal node.
- Seeds: greedy solution's tree is decoded back into a chromosome and
  injected along with random balanced trees and some "grid"-like trees.

The GA is run for a fixed time budget per n; best individual wins.
"""
import math
import random
import time

# ------------------------------------------------------------------
# Chromosome representation
# ------------------------------------------------------------------
# A chromosome is a tuple:
#   ('L',)                      -- a leaf
#   ('N', dir, frac, left, right) -- internal split
# We produce balanced trees by default.
# ------------------------------------------------------------------

def leaf():
    return ('L',)

def node(direction, frac, left, right):
    return ('N', direction, frac, left, right)

def tree_leaves(t):
    if t[0] == 'L':
        return 1
    return tree_leaves(t[3]) + tree_leaves(t[4])

def tree_size(t):
    if t[0] == 'L':
        return 1
    return 1 + tree_size(t[3]) + tree_size(t[4])

def random_balanced_tree(n, rng):
    if n <= 1:
        return leaf()
    k1 = rng.randint(1, n - 1)
    k2 = n - k1
    d = rng.choice('vh')
    f = rng.choice([0.5, 1/3, 2/3, 0.25, 0.75, 0.2, 0.8, 0.4, 0.6])
    return node(d, f, random_balanced_tree(k1, rng),
                random_balanced_tree(k2, rng))

def grid_tree(k, rng):
    """A k x k grid as a guillotine tree (with n = k^2 leaves)."""
    # Build n leaves laid out in grid form via nested splits.
    if k == 1:
        return leaf()
    # split into k columns, each a column of k leaves
    cols = []
    for _ in range(k):
        # column leaf as vertical stack of k leaves
        col = leaf()
        for _ in range(k - 1):
            col = node('h', 1.0 / (tree_leaves(col) + 1), col, leaf())
        # fix: we need balanced build; simpler: recursively build column
        col = build_column(k)
        cols.append(col)
    # merge columns left-to-right
    total_leaves = k * k
    root = cols[0]
    for i in range(1, k):
        # split frac chosen so cell widths are equal
        left_leaves = tree_leaves(root)
        right_leaves = tree_leaves(cols[i])
        f = left_leaves / (left_leaves + right_leaves)
        root = node('v', f, root, cols[i])
    return root

def build_column(k):
    """Vertical stack of k leaves."""
    if k == 1:
        return leaf()
    f = 1.0 / k
    return node('h', f, leaf(), build_column(k - 1))

def build_row(k):
    """Horizontal row of k leaves."""
    if k == 1:
        return leaf()
    f = 1.0 / k
    return node('v', f, leaf(), build_row(k - 1))

# ------------------------------------------------------------------
# Decode tree into (cx, cy, angle, side) list
# ------------------------------------------------------------------
def decode(t, x0=0.0, y0=0.0, x1=1.0, y1=1.0, out=None):
    if out is None:
        out = []
    if t[0] == 'L':
        w = x1 - x0
        h = y1 - y0
        s = min(w, h)
        if s < 0:
            s = 0.0
        cx = (x0 + x1) * 0.5
        cy = (y0 + y1) * 0.5
        # clamp
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        s = max(0.0, min(1.0, s))
        out.append((cx, cy, 0.0, s))
        return out
    _, d, f, L, R = t
    # f is the fraction given to the LEFT child
    f = max(0.001, min(0.999, f))
    if d == 'v':
        xm = x0 + f * (x1 - x0)
        decode(L, x0, y0, xm, y1, out)
        decode(R, xm, y0, x1, y1, out)
    else:
        ym = y0 + f * (y1 - y0)
        decode(L, x0, y0, x1, ym, out)
        decode(R, x0, ym, x1, y1, out)
    return out

def fitness(t):
    pack = decode(t)
    return sum(p[3] for p in pack)

# ------------------------------------------------------------------
# Genetic operators
# ------------------------------------------------------------------
def collect_nodes(t, path=()):
    """Return list of (path, node_tuple) for internal nodes; path is tuple of 0/1 (L=0,R=1)."""
    out = []
    if t[0] == 'L':
        return out
    out.append((path, t))
    out.extend(collect_nodes(t[3], path + (0,)))
    out.extend(collect_nodes(t[4], path + (1,)))
    return out

def get_subtree(t, path):
    cur = t
    for p in path:
        if cur[0] == 'L':
            return cur
        cur = cur[3] if p == 0 else cur[4]
    return cur

def set_subtree(t, path, sub):
    if not path:
        return sub
    d = t[1]; f = t[2]
    if path[0] == 0:
        return node(d, f, set_subtree(t[3], path[1:], sub), t[4])
    else:
        return node(d, f, t[3], set_subtree(t[4], path[1:], sub))

def crossover(a, b, rng):
    """Swap a subtree of a with one of b, keeping leaf counts matched by
    choosing subtree pairs of equal leaf count."""
    na = rng.randint(1, 5)
    nb = rng.randint(1, 5)
    # nodes at depth na in a
    def nodes_at(t, depth, path=()):
        if depth == 0:
            return [(path, t)]
        if t[0] == 'L':
            return []
        r = []
        r.extend(nodes_at(t[3], depth - 1, path + (0,)))
        r.extend(nodes_at(t[4], depth - 1, path + (1,)))
        return r
    An = nodes_at(a, na)
    Bn = nodes_at(b, nb)
    if not An or not Bn:
        return a
    # match on leaf count
    rng.shuffle(An)
    rng.shuffle(Bn)
    for pa, sa in An:
        lc = tree_leaves(sa)
        for pb, sb in Bn:
            if tree_leaves(sb) == lc:
                return set_subtree(a, pa, sb)
    return a

def mutate(t, rng):
    """Apply one of several mutation types."""
    if t[0] == 'L':
        return t
    nodes = collect_nodes(t)
    if not nodes:
        return t
    if rng.random() < 0.45:
        # perturb a split fraction
        _, nnode = rng.choice(nodes)
        path = _
        newf = nnode[2] + rng.gauss(0, 0.08)
        newf = max(0.01, min(0.99, newf))
        sub = node(nnode[1], newf, nnode[3], nnode[4])
        return set_subtree(t, path, sub)
    elif rng.random() < 0.30:
        # flip direction
        path, nnode = rng.choice(nodes)
        newd = 'v' if nnode[1] == 'h' else 'h'
        sub = node(newd, nnode[2], nnode[3], nnode[4])
        return set_subtree(t, path, sub)
    else:
        # random rebalance the split fraction(s) at a random node
        path, nnode = rng.choice(nodes)
        newf = rng.choice([0.5, 1/3, 2/3, 0.25, 0.75, 0.2, 0.8, 0.4, 0.6])
        sub = node(nnode[1], newf, nnode[3], nnode[4])
        return set_subtree(t, path, sub)

# ------------------------------------------------------------------
# Convert a greedy list of cells into a tree (approximately)
# ------------------------------------------------------------------
def cells_to_tree(cells, rng):
    """Build a guillotine tree by recursively splitting a bounding box into
    two halves around a coordinate if a clean split exists; else fall back
    to a balanced tree with the same leaf count."""
    cells = list(cells)
    n = len(cells)
    if n == 1:
        return leaf()
    # find a vertical split value that cleanly separates cells
    xs = sorted(set([c[0] for c in cells] + [c[2] for c in cells]))
    # try each candidate split coordinate and see if it partitions cells
    for s in xs:
        if s <= 0.0 or s >= 1.0:
            continue
        left = [c for c in cells if c[2] <= s + 1e-9]
        right = [c for c in cells if c[0] >= s - 1e-9]
        if len(left) + len(right) == n and left and right and len(left) + len(right) == n:
            if all(c in left + right for c in cells):
                # ensure separation
                ok = True
                for a in left:
                    for b in right:
                        if a[2] > b[0] + 1e-9:
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    f = s
                    # normalize fraction: original width spanned may not be unit,
                    # but tree decode uses f on the current node's width.
                    # To keep it exact we need bounding-box-width fraction.
                    return node('v', s,
                                cells_to_tree(left, rng),
                                cells_to_tree(right, rng))
    # horizontal split
    ys = sorted(set([c[1] for c in cells] + [c[3] for c in cells]))
    for s in ys:
        if s <= 0.0 or s >= 1.0:
            continue
        bot = [c for c in cells if c[3] <= s + 1e-9]
        top = [c for c in cells if c[1] >= s - 1e-9]
        if len(bot) + len(top) == n and bot and top:
            ok = True
            for a in bot:
                for b in top:
                    if a[3] > b[1] + 1e-9:
                        ok = False
                        break
                if not ok:
                    break
            if ok:
                return node('h', s,
                            cells_to_tree(bot, rng),
                            cells_to_tree(top, rng))
    # fallback: balanced tree
    return random_balanced_tree(n, rng)

# ------------------------------------------------------------------
# Simple greedy from the current program, but data-based (cells only)
# ------------------------------------------------------------------
def greedy_cells(n, rng):
    FRAC = [0.5, 1/3, 2/3, 0.25, 0.75, 0.2, 0.4, 0.6, 0.8,
            1/6, 5/6, 1/8, 3/8, 5/8, 7/8]

    def cell_val(c):
        return min(c[2] - c[0], c[3] - c[1])

    def split_cell(c, direction, frac):
        x0, y0, x1, y1 = c
        if direction == 'v':
            xc = x0 + frac * (x1 - x0)
            return (x0, y0, xc, y1), (xc, y0, x1, y1)
        else:
            yc = y0 + frac * (y1 - y0)
            return (x0, y0, x1, yc), (x0, yc, x1, y1)

    def best_split_gain(c):
        base = cell_val(c)
        best_gain = -1e18
        best_pair = None
        for frac in FRAC:
            c1, c2 = split_cell(c, 'v', frac)
            g = cell_val(c1) + cell_val(c2) - base
            if g > best_gain:
                best_gain = g
                best_pair = (c1, c2)
            c1, c2 = split_cell(c, 'h', frac)
            g = cell_val(c1) + cell_val(c2) - base
            if g > best_gain:
                best_gain = g
                best_pair = (c1, c2)
        return best_gain, best_pair

    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        bi = -1
        bg = -1e18
        bp = None
        for i, c in enumerate(cells):
            g, p = best_split_gain(c)
            if g > bg:
                bg = g
                bi = i
                bp = p
        if bi < 0 or bp is None:
            break
        a, b = bp
        cells[bi] = a
        cells.append(b)
    while len(cells) < n:
        cells.append((0.0, 0.0, 0.0, 0.0))
    return cells[:n]

# ------------------------------------------------------------------
# Main GA
# ------------------------------------------------------------------
def solve(n, time_limit=55.0):
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    t0 = time.time()
    deadline = t0 + time_limit

    # --- initial population ---
    pop = []

    # seed 1: current greedy as a tree
    cells = greedy_cells(n, rng)
    try:
        t = cells_to_tree(cells, rng)
        if tree_leaves(t) == n:
            pop.append(t)
    except Exception:
        pass

    # seed 2: balanced tree
    pop.append(random_balanced_tree(n, rng))

    # seed 3: grid-like trees (if n is (nearly) square)
    for k in range(2, int(math.sqrt(n)) + 2):
        import math as _m
        def mk_grid(k):
            # recursive k x k grid as guillotine tree
            def grid(k):
                if k == 1:
                    return leaf()
                # split into k equal columns, each a column
                cols = [build_column(k) for _ in range(k)]
                root = cols[0]
                for i in range(1, k):
                    f = 1.0 / (i + 1)
                    root = node('v', f, root, cols[i])
                return root
            return grid(k)
        if k * k == n:
            pop.append(mk_grid(k))

    # seed 4: row/column splits
    for k in range(2, n + 1):
        if k == n:
            pop.append(build_row(n))
            pop.append(build_column(n))
            break

    # fill remaining with random trees
    while len(pop) < 40:
        pop.append(random_balanced_tree(n, rng))

    # --- run GA ---
    POP_SIZE = 40
    best = None
    best_fit = -1.0
    fit_cache = {}

    def fit(t):
        return fitness(t)

    fits = [fit(t) for t in pop]
    for t, f in zip(pop, fits):
        if f > best_fit:
            best_fit = f
            best = t

    generation = 0
    while time.time() < deadline:
        generation += 1
        # tournament selection
        new_pop = []
        # elitism: keep best
        order = sorted(range(len(pop)), key=lambda i: -fits[i])
        elite_n = max(1, POP_SIZE // 10)
        for i in order[:elite_n]:
            new_pop.append(pop[i])
        while len(new_pop) < POP_SIZE:
            if time.time() >= deadline:
                break
            # selection
            def tour():
                best_i = rng.randrange(len(pop))
                for _ in range(3):
                    j = rng.randrange(len(pop))
                    if fits[j] > fits[best_i]:
                        best_i = j
                return pop[best_i]
            a = tour()
            b = tour()
            child = crossover(a, b, rng)
            # sanity: leaf count must be n
            if tree_leaves(child) != n:
                child = a
            # apply mutation 1-3 times
            for _ in range(rng.randint(1, 3)):
                child = mutate(child, rng)
                if tree_leaves(child) != n:
                    break
            if tree_leaves(child) != n:
                child = a
            new_pop.append(child)
        pop = new_pop
        fits = [fit(t) for t in pop]
        for t, f in zip(pop, fits):
            if f > best_fit:
                best_fit = f
                best = t
        # inject some fresh random individuals occasionally
        if generation % 15 == 0:
            for _ in range(max(2, POP_SIZE // 10)):
                pop[rng.randrange(len(pop))] = random_balanced_tree(n, rng)
            fits = [fit(t) for t in pop]

    # --- final local refinement on best ---
    # Fine-tune split fractions by direct coordinate descent on the best tree.
    def refine(t, budget_iters=200):
        t_best = t
        f_best = fitness(t)
        nodes = collect_nodes(t_best)
        # build a list of (path)
        paths = [p for p, _ in collect_nodes(t_best)]
        rng.shuffle(paths)
        for path in paths:
            if time.time() >= deadline + 3.0:
                break
            cur_node = get_subtree(t_best, path)
            if cur_node[0] == 'L':
                continue
            # try a range of probabilities around current fraction
            base_f = cur_node[2]
            d = cur_node[1]
            best_local = base_f
            best_local_f = f_best
            cands = [base_f]
            for delta in (0.2, 0.1, 0.05, 0.02, 0.01):
                cands.append(base_f + delta)
                cands.append(base_f - delta)
            for f in cands:
                f = max(0.005, min(0.995, f))
                sub = node(d, f, cur_node[3], cur_node[4])
                cand = set_subtree(t_best, path, sub)
                cf = fitness(cand)
                if cf > best_local_f:
                    best_local_f = cf
                    best_local = f
            if best_local != base_f:
                sub = node(d, best_local, cur_node[3], cur_node[4])
                t_best = set_subtree(t_best, path, sub)
                f_best = best_local_f
        return t_best, f_best

    best, best_fit = refine(best, budget_iters=300)

    # decode best
    pack = decode(best)
    # trim / pad to n
    while len(pack) < n:
        pack.append((0.5, 0.5, 0.0, 0.0))
    pack = pack[:n]

    # ensure all numbers in [0, 1]
    fixed = []
    for cx, cy, ang, s in pack:
        cx = max(0.0, min(1.0, float(cx)))
        cy = max(0.0, min(1.0, float(cy)))
        ang = max(0.0, min(1.0, float(ang)))
        s = max(0.0, min(1.0, float(s)))
        fixed.append((cx, cy, ang, s))
    return fixed

# EVOLVE-BLOCK-END

