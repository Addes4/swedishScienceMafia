# EVOLVE-BLOCK-START
"""Direct continuous optimization with L-BFGS + penalty for overlap.

Idea: represent n squares by (cx, cy, angle, side) and maximize sum(side)
subject to all pairs having disjoint interiors and all squares inside the
unit square. We turn this into an unconstrained minimization of

    f = -sum(side) + P_in + P_overlap

where P_in penalizes points/squares outside [0,1]^2 and P_overlap penalizes
overlap between square pairs. We use scipy's L-BFGS-B (bounded) so variables
stay in [0,1], and run from many random starts plus the grid baseline.

Square-square overlap for two OBBs is checked via SAT over 4 axes each.
A smooth-ish penalty based on penetration depth is used.
"""
import math
import random

import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    """Return 4 corners of the square as an array (4,2). angle in turns."""
    theta = 2.0 * math.pi * ang
    c, si = math.cos(theta), math.sin(theta)
    h = 0.5 * s
    pts = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    R = np.array([[c, -si], [si, c]], dtype=float)
    return pts @ R.T + np.array([cx, cy])


def _axes(ang):
    """Two unit axes of the square (edge directions)."""
    theta = 2.0 * math.pi * ang
    c, si = math.cos(theta), math.sin(theta)
    return np.array([[c, si], [-si, c]], dtype=float)


def _overlap_penalty(cx, cy, ang, s):
    """Total penalty from pairwise overlaps and outside-the-box, vectorized-ish."""
    n = len(s)
    if n == 0:
        return 0.0
    # inside penalty: corners outside [0,1]^2 - use min distance to violate
    pen = 0.0
    for i in range(n):
        if s[i] <= 0.0:
            continue
        cs = _corners(cx[i], cy[i], ang[i], s[i])
        mn = cs.min(axis=0)
        mx = cs.max(axis=0)
        # violation amounts
        v = 0.0
        v += max(0.0, -mn[0])
        v += max(0.0, -mn[1])
        v += max(0.0, mx[0] - 1.0)
        v += max(0.0, mx[1] - 1.0)
        pen += v * v
    # pairwise overlap via SAT
    for i in range(n):
        if s[i] <= 0.0:
            continue
        for j in range(i + 1, n):
            if s[j] <= 0.0:
                continue
            # separating axis test (on the two squares' edge normals)
            ov = _pair_overlap_depth(cx[i], cy[i], ang[i], s[i],
                                     cx[j], cy[j], ang[j], s[j])
            pen += ov * ov
    return pen


def _pair_overlap_depth(c1x, c1y, a1, s1, c2x, c2y, a2, s2):
    """Penetration depth (min overlap over candidate axes) for two OBBs.
    Returns 0 if separated."""
    A1 = _axes(a1)
    A2 = _axes(a2)
    # half extents along each axis
    c1 = np.array([c1x, c1y])
    c2 = np.array([c2x, c2y])
    d = c2 - c1
    axes = np.vstack([A1, A2])
    min_ov = float("inf")
    for ax in axes:
        # projection radius of each square onto axis ax
        r1 = 0.5 * s1 * (abs(A1[0] @ ax) + abs(A1[1] @ ax))
        r2 = 0.5 * s2 * (abs(A2[0] @ ax) + abs(A2[1] @ ax))
        dist = abs(d @ ax)
        ov = r1 + r2 - dist
        if ov <= 0.0:
            return 0.0
        if ov < min_ov:
            min_ov = ov
    return min_ov


def _unpack(x, n):
    x = x.reshape(n, 4)
    return x[:, 0].copy(), x[:, 1].copy(), x[:, 2].copy(), np.clip(x[:, 3], 0.0, 1.0)


def _objective(x, n, w_in, w_ov):
    cx, cy, ang, s = _unpack(x, n)
    s = np.clip(s, 0.0, 1.0)
    pen = _overlap_penalty(cx, cy, ang, s)
    return -float(s.sum()) + w_in * pen + w_ov * pen


def _grid_start(n):
    k = math.isqrt(n)
    side = 1.0 / k if k > 0 else 1.0
    xs = []
    for i in range(k):
        for j in range(k):
            xs += [(i + 0.5) * side, (j + 0.5) * side, 0.0, side]
    while len(xs) < 4 * n:
        xs += [0.5, 0.5, 0.0, 0.0]
    return np.array(xs[:4 * n])


def _random_start(n, rng):
    xs = []
    for _ in range(n):
        # random side up to a small value; random center, angle
        xs += [rng.random(), rng.random(), rng.random(), rng.random() * 0.7]
    return np.array(xs)


def _feasible_and_value(cx, cy, ang, s):
    """Check feasibility (no interior overlap, inside unit box) and value."""
    n = len(s)
    for i in range(n):
        if s[i] <= 1e-12:
            continue
        cs = _corners(cx[i], cy[i], ang[i], s[i])
        if cs.min() < -1e-9 or cs.max() > 1.0 + 1e-9:
            return False, 0.0
    for i in range(n):
        if s[i] <= 1e-12:
            continue
        for j in range(i + 1, n):
            if s[j] <= 1e-12:
                continue
            if _pair_overlap_depth(cx[i], cy[i], ang[i], s[i],
                                   cx[j], cy[j], ang[j], s[j]) > 1e-9:
                return False, 0.0
    return True, float(s.sum())


def solve(n):
    if n <= 0:
        return []
    rng = random.Random(12345 + n)
    best_feasible = None
    best_val = -1.0

    # collect candidate starts
    starts = [_grid_start(n)]
    nrand = 12
    for _ in range(nrand):
        starts.append(_random_start(n, rng))

    bounds = [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)] * n

    for st in starts:
        x0 = np.array(st, dtype=float)
        x0 = np.clip(x0, 0.0, 1.0)
        # increase penalty weight in a small continuation scheme
        cur = x0.copy()
        for w in (5.0, 20.0, 60.0, 200.0):
            try:
                res = minimize(
                    _objective, cur, args=(n, w, w),
                    method="L-BFGS-B", bounds=bounds,
                    options={"maxiter": 200, "ftol": 1e-12, "gtol": 1e-10},
                )
                cur = res.x
            except Exception:
                break
        cx, cy, ang, s = _unpack(cur, n)
        ok, val = _feasible_and_value(cx, cy, ang, s)
        if ok and val > best_val:
            best_val = val
            best_feasible = (cx, cy, ang, s)
        elif not ok and best_feasible is None:
            # keep a fallback feasible grid
            pass

    if best_feasible is None:
        # fallback: grid
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 1.0
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        return squares[:n]

    cx, cy, ang, s = best_feasible
    # shrink slightly to guarantee strict feasibility against floating error
    shift = 0.5
    result = []
    for i in range(n):
        si = float(s[i])
        if si > 1e-9:
            si *= 0.999999
        result.append((float(np.clip(cx[i], 0.0, 1.0)),
                       float(np.clip(cy[i], 0.0, 1.0)),
                       float(ang[i] % 1.0 if ang[i] % 1.0 >= 0 else 0.0),
                       si))
    return result
# EVOLVE-BLOCK-END
