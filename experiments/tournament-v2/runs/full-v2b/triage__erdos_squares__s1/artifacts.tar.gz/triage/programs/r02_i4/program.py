# EVOLVE-BLOCK-START
"""Squares in a square: sum of side lengths via topology optimization.

Core method:
1. Generate an initial hierarchical partition of the unit square into n axis-aligned
   rectangles using a fixed set of fractional cuts (a quick greedy).
2. Convert this partition into a fixed binary tree topology with parameterised cut
   coordinates (scalars in [0,1] along the splitting direction).
3. Optimise the cut coordinates continuously using SciPy's Nelder-Mead, maximising
   sum of min(w,h) over the n leaves, with bounds keeping cuts inside [0,1].
4. If any leaf degenerates to zero width or height, we still place zero side square.
5. For larger n we also try multiple initial topologies (from restarts) and keep best.

This approach avoids discrete grid limitations and fine-tunes cuts to maximise the
objective with continuous precision.
"""

import math
import time
import random
from functools import lru_cache
import numpy as np
from scipy.optimize import minimize


def _make_initial_tree_topology(n):
    """Generate a list of topologies by applying greedy splitting with a fixed
    set of fractions to build a full binary tree with n leaves.
    
    Returns a list of trees, each represented as a tuple of lists:
    tree = (node_type, ...) recursive.
    We encode the topology as an ordered list of cut directions and initial cut values
    plus leaf indicators, but we need a fixed structure for optimisation.
    Actually we will parameterize the tree: a binary tree with n leaves has n-1 internal nodes.
    Each internal node has a split direction ('v' or 'h') and a cut coordinate (float 0..1
    relative to the node's bounding box). We'll assign a fixed topology and initial cut values.
    """
    FRAC = [0.5, 1/3, 2/3, 0.25, 0.75, 0.2, 0.4, 0.6, 0.8,
            1/6, 5/6, 1/8, 3/8, 5/8, 7/8, 1/10, 3/10, 7/10, 9/10]
    
    def cell_val(c):
        w = c[2]-c[0]; h = c[3]-c[1]
        return min(w,h)
    
    def split_cell(c, direction, frac):
        x0,y0,x1,y1 = c
        if direction == 'v':
            xc = x0 + frac*(x1-x0)
            return (x0,y0,xc,y1), (xc,y0,x1,y1)
        else:
            yc = y0 + frac*(y1-y0)
            return (x0,y0,x1,yc), (x0,yc,x1,y1)
    
    def best_split(c):
        base = cell_val(c)
        best_gain = -1e18
        best_pair = None
        best_dir = None
        best_frac = None
        for frac in FRAC:
            if 0.0 < frac < 1.0:
                for d in ('v','h'):
                    c1,c2 = split_cell(c, d, frac)
                    gain = cell_val(c1)+cell_val(c2) - base
                    if gain > best_gain:
                        best_gain = gain
                        best_pair = (c1,c2)
                        best_dir = d
                        best_frac = frac
        return best_gain, best_pair, best_dir, best_frac
    
    # initial cells: several starts
    starts = []
    # single unit square
    starts.append([(0.0,0.0,1.0,1.0)])
    # simple grids
    for kk in (2,3,4,5):
        s = 1.0/kk
        g = []
        for i in range(kk):
            for j in range(kk):
                g.append((i*s, j*s, (i+1)*s, (j+1)*s))
        if len(g) <= n:
            starts.append(g)
    for kk in (2,3,4,5):
        if kk <= n:
            g = []
            s = 1.0/kk
            for i in range(kk):
                g.append((0.0, i*s, 1.0, (i+1)*s))
            starts.append(g)
            g = []
            for j in range(kk):
                g.append((j*s, 0.0, (j+1)*s, 1.0))
            starts.append(g)
    
    # Greedy build tree from each start: we record the sequence of splits
    topologies = []
    for start_cells in starts:
        cells = list(start_cells)
        # tree building: we will maintain a list of "nodes", each node either a leaf or an internal
        # We'll create a tree structure:
        # internal node: ("v"/"h", frac, left_child, right_child)
        # leaf: ("leaf", None, None, None) but we also need initial rect?
        # Actually we need a correspondence between leaves and rectangles.
        
        # We'll store the build as a list of splits applied to leaf indices.
        # To build a fixed topology we can record the order and direction of splits.
        splits = []  # each (direction, frac, index of cell to split)
        # We'll start with leaf rectangles list.
        rects = list(cells)
        leaf_to_split_order = []
        while len(rects) < n:
            # find best split among all leaves
            best_idx = -1
            best_gain = -1e18
            best_pair = None
            best_dir = None
            best_frac = None
            for i, rect in enumerate(rects):
                g, p, d, f = best_split(rect)
                if g > best_gain:
                    best_gain = g
                    best_idx = i
                    best_pair = p
                    best_dir = d
                    best_frac = f
            if best_idx < 0:
                break
            # split
            r1, r2 = best_pair
            rects[best_idx] = r1
            rects.append(r2)
            splits.append((best_dir, best_frac, best_idx))
        # Now convert splits into a tree: we'll rebuild starting from leaves.
        # We need a mapping of split operations to tree nodes.
        # Bottom-up: we can create a binary tree where leaves correspond to final rects.
        # We'll number leaves 0..n-1 and internal nodes n..2n-2 (n-1 internal nodes).
        # Each split takes a leaf (which might be already an internal node after previous splits)
        # and replaces it with an internal node whose children are new leaf and the leaf's old node.
        # So we build from original leaf set.
        # We'll have a parent array and node types.
        
        # We'll represent the tree as an array of nodes: for i in 0..n-1 leaves, n..2n-2 internal.
        # Each node: (direction, frac, left_child, right_child) or leaf.
        # But we only need topology and initial cut values.
        # Simpler: encode as a fixed structure where we order internal nodes by a traversal.
        
        # Instead, we'll directly build the tree recursively from the split history by reconstructing.
        # We'll start with n leaves as a list of rects. Each split takes a rect index and replaces it with an internal.
        # At the end, each leaf index corresponds to a node in the final tree.
        # We'll build tree nodes as we go.
        
        # Let's build a node array:
        # nodes[i] = for i in 0..n-1 leaves: None initially; later assigned child indices.
        # internal nodes will be appended.
        # We can do: initially n leaves with rectangles.
        rects = list(start_cells)
        leaf_nodes = [f"leaf{i}" for i in range(len(rects))]  # placeholders
        # We'll simulate splits.
        # After each split, the target leaf index becomes an internal node, and we add a new leaf.
        # We'll maintain a list of nodes (some leaves, some internal) for each rect.
        splits_record = []
        cur_nodes = leaf_nodes[:]
        for d, frac, idx in splits:
            # split cur_nodes[idx] into (internal, new leaf)
            internal_name = f"int{len(splits_record)}"
            left_child = cur_nodes[idx]
            right_child = f"leaf{len(cur_nodes)}"
            cur_nodes[idx] = (d, frac, left_child, right_child)
            cur_nodes.append(right_child)
            splits_record.append((d, frac))
        
        # Now we have cur_nodes with n leaves and n-1 internals.
        # We want to extract a parameter vector: the cut fractions for each internal node, and its direction.
        # The topology is defined by the directions and the tree structure.
        # We'll fix the tree structure (child relations) and directions, and make cut fractions variables.
        
        # Let's traverse to collect internal node order.
        # We can assign each internal node an index by DFS.
        internal_params = []  # list of (direction, initial_frac, left_child_idx, right_child_idx)
        # But we need a consistent numbering of all nodes.
        # We'll map each node to an index.
        node_to_idx = {}
        idx_counter = 0
        
        def assign_idx(node):
            nonlocal idx_counter
            if isinstance(node, tuple):
                # internal
                d, frac, left, right = node
                assign_idx(left)
                assign_idx(right)
                node_to_idx[node] = idx_counter
                idx_counter += 1
            else:
                # leaf
                node_to_idx[node] = idx_counter
                idx_counter += 1
        
        assign_idx(cur_nodes[0])  # root is the first element
        # Now total nodes = 2n-1
        total_nodes = len(node_to_idx)
        # Create arrays: direction fixed as boolean (0 for v, 1 for h), and initial cut value.
        n_internal = n - 1
        init_cuts = np.zeros(n_internal)
        dirs = np.zeros(n_internal, dtype=bool)  # False = v, True = h
        left_children = -np.ones(n_internal, dtype=int)
        right_children = -np.ones(n_internal, dtype=int)
        
        for node, idx in node_to_idx.items():
            if isinstance(node, tuple):
                internal_idx = idx - n  # leaves take indices 0..n-1, internals n..2n-2
                d, frac, left, right = node
                dirs[internal_idx] = (d == 'h')
                init_cuts[internal_idx] = frac
                left_children[internal_idx] = node_to_idx[left]
                right_children[internal_idx] = node_to_idx[right]
        
        # Leaves indices: 0..n-1; internal: n..n+n_internal-1
        # root is the node with index 2n-2 (the last internal assigned)
        # Actually we need to find root: the node that is not child of any internal.
        children_set = set(left_children) | set(right_children)
        root = [i for i in range(total_nodes) if i not in children_set][0]
        
        topology = {
            'n': n,
            'init_cuts': init_cuts,
            'dirs': dirs,
            'left_children': left_children,
            'right_children': right_children,
            'root': root
        }
        topologies.append(topology)
    return topologies


def _evaluate_tree(cuts, dirs, left_children, right_children, root):
    """Compute leaf rectangles given cut parameters in (0,1) for internal nodes.
    Leaves get index 0..n-1, internals n..2n-2.
    Returns list of (x0,y0,x1,y1) for leaves."""
    n_leaves = len(cuts) + 1
    total_nodes = 2 * n_leaves - 1
    # We'll compute bounding boxes bottom-up via recursion.
    # Use a post-order traversal assigning boxes.
    boxes = [None] * total_nodes
    
    def compute(node_idx, x0, y0, x1, y1):
        if node_idx < n_leaves:
            boxes[node_idx] = (x0, y0, x1, y1)
            return
        internal_idx = node_idx - n_leaves
        d = dirs[internal_idx]
        t = cuts[internal_idx]
        # clamp t to (0,1) to avoid degenerate
        t = max(0.001, min(0.999, t))
        left = left_children[internal_idx]
        right = right_children[internal_idx]
        if d == 0:  # vertical split
            xc = x0 + t * (x1 - x0)
            compute(left, x0, y0, xc, y1)
            compute(right, xc, y0, x1, y1)
        else:  # horizontal
            yc = y0 + t * (y1 - y0)
            compute(left, x0, y0, x1, yc)
            compute(right, x0, yc, x1, y1)
    
    compute(root, 0.0, 0.0, 1.0, 1.0)
    leaf_boxes = boxes[:n_leaves]
    return leaf_boxes


def _objective(cuts, dirs, left_children, right_children, root):
    """Return negative sum of min(w,h) for minimization."""
    leaves = _evaluate_tree(cuts, dirs, left_children, right_children, root)
    total = 0.0
    for (x0,y0,x1,y1) in leaves:
        w = max(0, x1-x0)
        h = max(0, y1-y0)
        total += min(w, h)
    return -total


def _optimize_topology(topology, max_time=5):
    """Given a topology dict, run Nelder-Mead to optimise cuts, return best leaves."""
    n = topology['n']
    init_cuts = topology['init_cuts']
    dirs = topology['dirs']
    left = topology['left_children']
    right = topology['right_children']
    root = topology['root']
    
    # Bounds for cuts: avoid 0 and 1 exactly to keep some width for each child.
    bounds = [(0.01, 0.99)] * len(init_cuts)
    
    # initial simplex around init_cuts
    x0 = np.array(init_cuts)
    
    # Objective function wrapper
    def fun(x):
        return _objective(x, dirs, left, right, root)
    
    # Use Nelder-Mead with bounds via transformation? SciPy's minimize with method='Nelder-Mead' doesn't respect bounds natively,
    # but we can use 'L-BFGS-B' with bounded. However L-BFGS-B requires gradient.
    # We'll use a modified approach: we project cuts into [eps, 1-eps] inside the evaluation.
    # The evaluation already clamps inside _evaluate_tree.
    # So we can just pass unconstrained.
    res = minimize(fun, x0, method='Nelder-Mead',
                   options={'maxiter': 2000, 'xatol': 1e-7, 'fatol': 1e-10,
                            'adaptive': True})
    best_cuts = res.x
    best_val = -res.fun
    leaves = _evaluate_tree(best_cuts, dirs, left, right, root)
    # Convert to square placements (axis-aligned)
    out = []
    for (x0,y0,x1,y1) in leaves:
        w = x1-x0
        h = y1-y0
        s = min(w, h)
        cx = (x0+x1)/2.0
        cy = (y0+y1)/2.0
        out.append((cx, cy, 0.0, s))
    return out, best_val


def solve(n):
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    # For n up to 15, the exact DP in original program was good; we can still use continuous
    # optimisation which should be at least as good. For larger n we rely on this method.
    
    # Generate candidate topologies
    topologies = _make_initial_tree_topology(n)
    best_sol = None
    best_score = -1.0
    
    start_time = time.time()
    time_per_topology = max(0.1, min(10, 60.0 / max(1, len(topologies))))
    
    for i, top in enumerate(topologies):
        if time.time() - start_time > 55:
            break
        try:
            leaves, score = _optimize_topology(top, max_time=time_per_topology)
            if score > best_score:
                best_score = score
                best_sol = leaves
        except Exception:
            continue
    
    if best_sol is None:
        # fallback to uniform grid
        cols = int(math.ceil(math.sqrt(n)))
        rows = (n + cols - 1) // cols
        out = []
        dx = 1.0 / cols
        dy = 1.0 / rows
        count = 0
        for i in range(rows):
            for j in range(cols):
                if count >= n:
                    break
                cx = (j+0.5)*dx
                cy = (i+0.5)*dy
                s = min(dx, dy)
                out.append((cx, cy, 0.0, s))
                count += 1
        best_sol = out
    
    # ensure exactly n items
    while len(best_sol) < n:
        best_sol.append((0.5, 0.5, 0.0, 0.0))
    best_sol = best_sol[:n]
    
    # clamp to [0,1]
    out_clamped = []
    for (cx, cy, a, s) in best_sol:
        out_clamped.append((
            max(0.0, min(1.0, cx)),
            max(0.0, min(1.0, cy)),
            0.0,
            max(0.0, min(1.0, s))
        ))
    return out_clamped

# EVOLVE-BLOCK-END
