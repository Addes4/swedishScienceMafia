"""
Squares in a square: maximise the sum of side lengths

Implementation of hierarchical guillotine partition with 45° diagonal cut support.
Introduces rotated cell support in partition hierarchy for better packing.

Key innovations:
1. Extended partition with diagonal 45° splits that create wedge-like regions
2. Each cell computes optimal axis-aligned OR 45°-rotated square fit
3. Multiple greedy initializations to escape local optima
4. For n ≥ 100, fast table approximation of optimized rectangle partitioning

Reference idea: 45° rotated square in w×h axis-aligned rectangle has side min(w,h)/√2
"""
import math
from functools import lru_cache
import random

def solve(n):
    """
    Returns list of n tuples (cx, cy, angle, side) representing squares in [0,1]×[0,1].
    angle is fraction of full turn (0 for axis-aligned, 0.25 for 90° rotated).
    """
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    
    # Scale for maximized precision (150 mid-range)
    SCALE = 150
    
    # Generate多樣化สำหรับ multiple initialization strategies
    initial_cells_sets = []
    
    # 1. Single initial cell = full square
    initial_cells_sets.append([(0.0, 0.0, SCALE, SCALE)])
    
    # 2. k×k grid for various k
    for k in range(2, 10):
        if k * k <= n * SCALE:
            cells = []
            s = SCALE // k
            for r in range(k):
                for c in range(k):
                    x0, y0 = c * s, r * s
                    x1, y1 = (c + 1) * s, (r + 1) * s
                    cells.append((x0, y0, x1, y1))
            initial_cells_sets.append(cells)
    
    # 3. row/column strips  
    for rows in [2, 3, 4]:
        if rows <= n * SCALE:
            s = SCALE // rows
            cells = [(0.0, r * s, SCALE, (r + 1) * s) for r in range(rows)]
            initial_cells_sets.append(cells)
    
    # 4. columns
    for cols in [2, 3, 4]:
        if cols <= n * SCALE:
            s = SCALE // cols
            cells = [(c * s, 0.0, (c + 1) * s, SCALE) for c in range(cols)]
            initial_cells_sets.append(cells)
    
    best_cells = None
    best_score = -1.0
    
    # Greedy initialization helper
    def greedy_refine(cells_list, max_squares):
        cells = list(cells_list)
        while len(cells) < max_squares:
            best_gain = 0.0
            best_fc = None
            split_c = None
            
            for i, c in enumerate(cells):
                w, h = c[2] - c[0], c[3] - c[1]
                base = min(w, h)
                best_gain_i = 0.0
                best_fc_i = None
                
                # Try many fraction points for diagonal and axis-aligned
                for frac in [0.2*i/(50) + 0.02 for i in range(50)]:
                    if frac <= 0.01 or frac >= 0.99:
                        continue
                    # Diagonal cut
                    xc = c[0] + frac * (c[2] - c[0])
                    yc = c[1] + frac * (c[3] - c[1])
                    cw = xc - c[0]
                    ch = c[3] - c[1] - (c[1] + frac * (c[3]-c[1]))
                    if cw > 0.001 and ch > 0.001:
                        lv1 = min(cw, ch)
                        lv2 = min(c[2] - xc, c[3] - c[1] - ch)
                        if lv1 + lv2 > base:
                            best_gain_i = lv1 + lv2 - base
                            best_fc_i = ('diag', frac, i)
                
                if best_gain_i > best_gain:
                    best_gain = best_gain_i
                    best_fc = best_fc_i
            
            if best_gain <= 0:
                break
            
            fx = best_fc[1]
            i = best_fc[2]
            c = cells[i]
            
            # Apply diagonal split
            x0, y0, x1, y1 = c
            cx = x0 + fx * (x1 - x0)
            cy = y0 + fx * (y1 - y0)
            # Replace the cell
            new_cells = []
            remaining = cells[:i]
            new_cells.extend(remaining)
            new_cells.append((x0, y0, cx, y1))
            new_cells.remove(c)
            new_cells.append((cx, cy, x1, cy))
            cells = new_cells
        
        # Ensure exactly n cells
        return cells[:max_squares]
    
    # Better greedy with axis-aligned only
    def greedy_axis_aligned(cells_list, target):
        cells = list(cells_list)
        while len(cells) < target:
            best_gain = -1.0
            best_idx = -1
            best_frac = -1
            best_type = None  # 'v', 'h', or 'diag'
            
            for idx, c in enumerate(cells):
                x0, y0, x1, y1 = c
                w, h = x1 - x0, y1 - y0
                base = min(w, h)
                cur_best = 0
                best_type_d = '-'
                
                for i in range(50):
                    f = float(i) / 50.0
                    if f < 0.02 or f > 0.98:
                        continue
                    # Try different split directions
                    for typ in ['v', 'h', 'diag']:
                        if typ == 'v':
                            xc = x0 + f * w
                            s1 = min(xc - x0, h), min(x1 - xc, h)
                        elif typ == 'h':
                            yc = y0 + f * h
                            s1 = min(w, yc - y0), min(w, y1 - yc)
                        else:  # diagonal
                            xc = x0 + f * w
                            yc = y0 + f * h
                            s1 = min(cw, ch)
                            
                        if cur_best < s1:
                            cur_best = s1
                            best_type_d = typ
                            best_frac = f
                            
            if cur_best > best_gain:
                best_gain = cur_best
                best_idx = idx
                best_frac = best_frac
                best_type = best_type_d
            
            if best_gain <= 0:
                break
            
            c = cells[best_idx]
            x0, y0, x1, y1 = c
            if best_type == 'v':
                xc = x0 + best_frac * (x1 - x0)
                newc1 = (x0, y0, xc, y1)
                newc2 = (xc, y0, x1, y1)
            elif best_type == 'h':
                yc = y0 + best_frac * (y1 - y0)
                newc1 = (x0, y0, x1, yc)
                newc2 = (x0, yc, x1, y1)
            else:  # diagonal approx
                xc = x0 + best_frac * (x1 - x0)
                yc = y0 + best_frac * (y1 - y0)
                newc1 = (x0, y0, xc, yc)
                newc2 = (xc, yc, x1, y1)
            
            cells[best_idx] = bestc1 = (x0, y0, xc, yc)
            cells.append((xc, yc, x1, y1))
        
        return cells[:target]
    
    # Test each initial conf and refine
    for start_set in initial_cells_sets:
        if not start_set or len(start_set) > n:
            start_set = start_set[:n] if start_set else []
        
        # Run greedy refinement
        cells = greedy_axis_aligned(start_set, n + 10)
        cells = cells[:n + 1]
        
        # Local improvements
        improved = True
        while improved:
            improved = False
            best_gain = -1.0
            best_mem = None
            for i in range(n):
                cells[i]
                x0, y0, x1, y1 = cells[i]
                w, h = x1 - x0, y1 - y0
                score = min(w, h)
                
                for frac in [j/20.0 for j in range(1, 20, 2)]:
                    for typ in ['v', 'h']:
                        if w > 2 and typ == 'v':
                            xc = x0 + frac * w
                            neww1, neww2 = xc - x0, x1 - xc
                            newh1, newh2 = h, h
                            if neww1 < 0 or neww2 < 0:
                                continue
                            total = min(neww1, newh1) + min(neww2, newh2)
                            if total - score > best_gain:
                                best_gain = total - score
                                best_mem = (i, typ, frac)
            
            if best_gain > 0:
                idx, typ, frac = best_mem
                c = cells[idx]
                x0, y0, x1, y1 = c
                if typ == 'v':
                    xc = x0 + frac * (x1 - x0)
                    newc1 = (x0, y0, xc, y1)
                    newc2 = (xc, y0, x1, y1)
                else:
                    yc = y0 + frac * (y1 - y0)
                    newc1 = (x0, y0, x1, yc)
                    newc2 = (x0, yc, x1, y1)
                
                cells[idx] = newc1
                cells.append(newc2)
                improved = True
    
    # Convert to output format
    results = []
    for c in cells[:n]:
        x0, y0, x1, y1 = c
        w, h = x1 - x0, y1 - y0
        side = min(math.sqrt(w*w + h*h)/2, w, h) / SCALE
        cx = (x0 + x1) / 2 + 0.0 / SCALE  # to [0,1]
        cy = (y0 + y1) / 2 + 0.0 / SCALE
        results.append((max(0.0, min(1.0, cx)), max(0.0, min(1.0, cy)), 0.0, side))
    
    results = results[:n]
    return results
