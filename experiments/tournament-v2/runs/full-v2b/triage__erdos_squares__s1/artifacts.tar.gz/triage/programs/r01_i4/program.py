"""Optimised packing for n squares: boundary squares in decreasing size plus one central rotated square.
We use a parametric family inspired by known optimal packings for small n, then optimise with scipy."""
import math
import random
import itertools
from typing import List, Tuple

import numpy as np
from scipy.optimize import minimize, Bounds, differential_evolution

# ----------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------
def rotate_point(x, y, cx, cy, angle_frac):
    """Rotate point (x,y) around (cx,cy) by angle_frac full turns."""
    if angle_frac == 0.0:
        return x, y
    a = angle_frac * 2.0 * math.pi
    dx, dy = x - cx, y - cy
    cos_a, sin_a = math.cos(a), math.sin(a)
    rx = cx + dx * cos_a - dy * sin_a
    ry = cy + dx * sin_a + dy * cos_a
    return rx, ry


def square_vertices(cx, cy, angle_frac, side):
    """Return the four vertices of the square in CCW order."""
    h = side / 2.0
    raw = [(-h, -h), (h, -h), (h, h), (-h, h)]
    verts = [rotate_point(cx + dx, cy + dy, cx, cy, angle_frac) for dx, dy in raw]
    return verts


def point_in_unit_square(x, y, eps=1e-9):
    """True if (x,y) is strictly inside unit square."""
    return -eps <= x <= 1.0 + eps and -eps <= y <= 1.0 + eps


def square_in_unit_square(cx, cy, angle_frac, side, eps=1e-9):
    """True if all vertices lie in [0,1]x[0,1]."""
    verts = square_vertices(cx, cy, angle_frac, side)
    return all(point_in_unit_square(vx, vy, eps) for vx, vy in verts)


# ----------------------------------------------------------------------
# Separating Axis Theorem for two convex polygons
# ----------------------------------------------------------------------
def get_axes(poly):
    """Return normalised edge normals for polygon as list of (nx, ny)."""
    axes = []
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        edge = (x2 - x1, y2 - y1)
        normal = (-edge[1], edge[0])  # perpendicular
        length = math.hypot(normal[0], normal[1])
        if length > 1e-12:
            axes.append((normal[0] / length, normal[1] / length))
    return axes


def project(poly, axis):
    """Project polygon onto axis, return (min, max)."""
    dots = [x * axis[0] + y * axis[1] for x, y in poly]
    return min(dots), max(dots)


def polygons_overlap(poly1, poly2, eps=1e-12):
    """True if interiors intersect (strict)."""
    for axis in get_axes(poly1) + get_axes(poly2):
        a_min, a_max = project(poly1, axis)
        b_min, b_max = project(poly2, axis)
        if a_max < b_min - eps or b_max < a_min - eps:
            return False
    return True


# ----------------------------------------------------------------------
# Packing structure
# ----------------------------------------------------------------------
def build_boundary_plus_central(n: int) -> List[Tuple[float, float, float, float]]:
    """
    Heuristic to initialise a pattern:
    - Place squares along the boundary in decreasing size order
    - The largest squares go into corners, smaller ones fill edges
    - One central square, rotated (some optimal angle near 0.125 for many n)
    Returns list of (cx, cy, angle_frac, side)
    """
    squares = []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.5, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5),
                (0.5, 0.5, 0.125, 0.5)]  # not optimal but a start

    # For larger n, we construct a symmetric pattern parametrised by angles/sizes.
    # We'll form a template and let optimiser tune it.
    # Strategy: m = n - 1 (central). Distribute m squares around boundary.
    # Assign them to corners and edges in decreasing size order.
    m = n - 1
    central = (0.5, 0.5, 0.125, 0.2)  # dummy start

    # Determine how many per corner / edge: we want approximate symmetry.
    # Split into 4 corners, 4 edges. Let k = m // 4, r = m % 4.
    # Each corner gets at least 1, edges share rest.
    corner_slots = min(4, m)
    edge_slots = max(0, m - 4)
    # Simplistic: first 4 largest go to corners, rest along edges.
    sizes = [0.5 - 0.02 * i for i in range(m)]  # decreasing sizes
    # Shuffle to make optimiser work: corners first
    idx = 0
    # corners: (0,0), (1,0), (1,1), (0,1) in that order
    corners = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
    for i in range(min(4, m)):
        side = sizes[idx]
        cx, cy = corners[i]
        # push inside by side/2
        if i == 0:
            cx += side / 2
            cy += side / 2
        elif i == 1:
            cx -= side / 2
            cy += side / 2
        elif i == 2:
            cx -= side / 2
            cy -= side / 2
        elif i == 3:
            cx += side / 2
            cy -= side / 2
        squares.append((cx, cy, 0.0, side))
        idx += 1

    # edges: place the rest equally along left, bottom, right, top
    edges = []
    if edge_slots > 0:
        # bottom edge, excluding corners
        for j in range(edge_slots):
            frac = (j + 1) / (edge_slots + 1)
            cx = frac
            cy = 0.0
            side = sizes[idx % len(sizes)] if idx < len(sizes) else 0.1
            cy += side / 2
            squares.append((cx, cy, 0.0, side))
            idx += 1
    # ensure we have exactly m boundary squares (repeat or truncate)
    while len(squares) < m:
        squares.append((0.1, 0.1, 0.0, 0.01))  # dummy
    squares.append(central)
    return squares[:n]


# ----------------------------------------------------------------------
# Parameterisation for the optimiser
# ----------------------------------------------------------------------
def flatten_squares(squares):
    """Convert list of (cx,cy,angle,side) into flat vector."""
    return np.array([v for sq in squares for v in sq], dtype=np.float64)


def unflatten_squares(vec, n):
    """Convert flat vector back into list of squares."""
    vec = np.asarray(vec, dtype=np.float64)
    squares = []
    for i in range(n):
        base = i * 4
        cx, cy, ang, side = vec[base], vec[base + 1], vec[base + 2], vec[base + 3]
        squares.append((cx, cy, ang, side))
    return squares


def constraint_violations(squares, eps=1e-6):
    """Return sum of constraint violations (negative = violation distance).
    0 means all constraints satisfied.
    Checks:
    - squares inside unit square
    - no overlap
    """
    violation_sum = 0.0
    n = len(squares)
    polys = []
    for sq in squares:
        cx, cy, ang, side = sq
        if side < 0:
            violation_sum += -side * 100
            side = 0.0
        verts = square_vertices(cx, cy, ang, side)
        polys.append(verts)
        # inside unit
        for vx, vy in verts:
            if vx < -eps:
                violation_sum += -vx
            if vx > 1.0 + eps:
                violation_sum += vx - 1.0
            if vy < -eps:
                violation_sum += -vy
            if vy > 1.0 + eps:
                violation_sum += vy - 1.0
    # overlaps
    for i in range(n):
        for j in range(i + 1, n):
            if polygons_overlap(polys[i], polys[j], eps):
                # compute penetration depth estimate
                overlap_penalty = 0.01
                violation_sum += overlap_penalty
    return violation_sum


# ----------------------------------------------------------------------
# Objective: maximise sum of sides, penalise violations
# ----------------------------------------------------------------------
def objective(vec, n, penalty_weight=1000.0):
    """Return negative sum of sides plus penalty for constraint violations."""
    squares = unflatten_squares(vec, n)
    side_sum = sum(max(0.0, sq[3]) for sq in squares)
    violations = constraint_violations(squares)
    return -side_sum + penalty_weight * violations


# ----------------------------------------------------------------------
# Optimisation driver
# ----------------------------------------------------------------------
def solve(n: int) -> List[Tuple[float, float, float, float]]:
    """Main entry: returns n squares maximising sum of side lengths."""
    if n <= 0:
        return []
    if n <= 3:
        # simple fixed best known
        if n == 1:
            return [(0.5, 0.5, 0.0, 1.0)]
        if n == 2:
            return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
        if n == 3:
            # best known: 0.5+0.5+0.5*? Actually best is 0.5+0.5+0.5? No, known is 0.5+0.5+0.3535 rotated?
            # but we start with simple
            return [(0.5, 0.25, 0.0, 0.5),
                    (0.5, 0.75, 0.0, 0.5),
                    (0.5, 0.5, 0.125, 0.5)]

    # For larger n, run optimisation
    # Use differential_evolution for global search then local polishing
    initial_guess = build_boundary_plus_central(n)
    x0 = flatten_squares(initial_guess)
    bounds = Bounds([0.0] * (4 * n), [1.0] * (4 * n))
    # angle bounds [0,1), side bounds [0,1]
    # Fix angle bounds
    lb = [0.0] * (4 * n)
    ub = [1.0] * (4 * n)
    for i in range(n):
        lb[4 * i + 2] = 0.0
        ub[4 * i + 2] = 1.0 - 1e-12
        lb[4 * i + 3] = 0.0
        ub[4 * i + 3] = 1.0

    bounds = Bounds(lb, ub)

    # First: run differential evolution with small population
    try:
        result_de = differential_evolution(
            objective,
            bounds=bounds,
            args=(n, 1000.0),
            maxiter=1000,
            popsize=15,
            tol=1e-8,
            mutation=(0.5, 1.5),
            recombination=0.9,
            seed=None,
            disp=False,
            polish=False,
            workers=1,  # avoid multiprocessing issues
            updating='deferred'
        )
        x_opt = result_de.x
    except Exception:
        x_opt = x0

    # Local refinement with L-BFGS-B
    try:
        result_local = minimize(
            objective,
            x_opt,
            args=(n, 10000.0),
            method='L-BFGS-B',
            bounds=bounds,
            options={'maxiter': 5000, 'ftol': 1e-12}
        )
        x_opt = result_local.x
    except Exception:
        pass

    squares = unflatten_squares(x_opt, n)
    # Clean up: zero small violations
    final_squares = []
    for sq in squares:
        cx, cy, ang, side = sq
        side = max(0.0, min(side, 1.0))
        cx = max(0.0, min(cx, 1.0))
        cy = max(0.0, min(cy, 1.0))
        # Ensure square is inside (push inwards if needed)
        for _ in range(10):
            if square_in_unit_square(cx, cy, ang, side, 1e-6):
                break
            side *= 0.999
        if side < 1e-9:
            side = 0.0
        final_squares.append((cx, cy, ang % 1.0, side))

    # Remove zero squares if needed (allowed) but length must be n
    return final_squares


if __name__ == "__main__":
    # quick test
    for n_test in [5, 6, 7, 8, 11, 12, 13, 14, 15]:
        sol = solve(n_test)
        print(f"n={n_test}: sum={sum(s[3] for s in sol):.5f} sides: {[round(s[3],4) for s in sol])}")
