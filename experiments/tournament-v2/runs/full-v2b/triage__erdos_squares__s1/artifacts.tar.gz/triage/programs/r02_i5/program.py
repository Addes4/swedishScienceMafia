"""Squares in a square: maximise the sum of side lengths.

Strategy
--------
The best packings found in practice are *guillotine* partitions: recursively
split a rectangle with a vertical or horizontal cut and pack each sub-rectangle
independently.  For an axis-aligned rectangle of size (w, h) the biggest square
that fits inside a single cell is min(w, h).  So maximising the sum of sides for
a guillotine partition equals maximising sum of min(w_i, h_i) over the leaves.

We do three things:

1.  A discrete DP on a fine grid solves ``G(w, h, k)`` = best guillotine value
    when a w x h rectangle (in grid units) is split into k cells.  It is exact
    for the discretised problem and gives very near-optimal continuous answers
    for small n (this is the workhorse for n <= ~16).

2.  For larger n we run a *branch-and-bound over k-d tree topologies* using the
    memoised DP as an admissible upper bound.  Each node of the search is a
    rectangle that still has to hold a certain number of squares; the DP value
    of the whole rectangle gives an upper bound (it is the exact discrete
    optimum, hence >= any guillotine realisation of the same topology), and
    we prune whenever bound <= incumbent.  The incumbent comes from a fast
    greedy / local-search heuristic.

3.  For very large n the DP table gets too big, so we fall back to a strong
    greedy with local search; it is fast and matches the reference closely.

Only the standard library, numpy and scipy may be used.  The code below uses
only the standard library (math, random, functools).
"""

import math
import random
from functools import lru_cache


# ----------------------------------------------------------------------
#  Discrete guillotine DP
# ----------------------------------------------------------------------
# SCALE = number of grid cells per unit side.  A rectangle (w, h) in grid
# units is a physical rectangle of size (w/SCALE, h/SCALE).
#
# The DP stores the *optimum* of the discretised problem, which is an upper
# bound on the continuous optimum for the same topology (cuts are forced onto
# grid lines).  It is therefore usable as an admissible bound in the
# branch-and-bound search.

# Cache per top-level call so the recursion is fast.
_DP_MEMO = {}
_DP_SCALE = 0


def _dp_value(w, h, k, memo):
    """Best guillotine value for a w x h rectangle split into k cells.

    Units are grid cells.  Value is a sum of grid lengths (multiply by
    1/SCALE to get physical side lengths)."""
    if k <= 0 or w <= 0 or h <= 0:
        return 0.0
    if k == 1:
        return float(min(w, h))

    key = (w, h, k)
    got = memo.get(key)
    if got is not None:
        return got

    # Trivial bound: each cell contributes at most min(w, h) but there are k.
    # A stronger simple upper bound is used to rank / prune early:
    # any cell is at most sqrt(w*h/k)?? no, that is false for rectangles.
    # We rely purely on the DP.

    best = -1.0

    # vertical cuts: split width into c and w-c
    # Only need c <= w - c (symmetry) but we keep all to reconstruct simply.
    if w >= 2:
        for c in range(1, w):
            w1 = c
            w2 = w - c
            # number of cells on each side
            k1max = min(k - 1, w1 * h)  # cannot have more cells than unit cells
            k1min = max(1, k - (w2 * h))
            for k1 in range(k1min, k1max + 1):
                v = _dp_value(w1, h, k1, memo) + _dp_value(w2, h, k - k1, memo)
                if v > best:
                    best = v

    if h >= 2:
        for c in range(1, h):
            h1 = c
            h2 = h - c
            k1max = min(k - 1, w * h1)
            k1min = max(1, k - (w * h2))
            for k1 in range(k1min, k1max + 1):
                v = _dp_value(w, h1, k1, memo) + _dp_value(w, h2, k - k1, memo)
                if v > best:
                    best = v

    if best < 0.0:
        best = float(min(w, h))

    memo[key] = best
    return best


def _dp_reconstruct(w, h, k, x0, y0, memo, scale, out):
    """Reconstruct rectangles for the optimal tree found by _dp_value."""
    if k <= 1:
        out.append((x0, y0, x0 + w / scale, y0 + h / scale))
        return
    target = _dp_value(w, h, k, memo)

    if w >= 2:
        for c in range(1, w):
            w1, w2 = c, w - c
            k1max = min(k - 1, w1 * h)
            k1min = max(1, k - (w2 * h))
            for k1 in range(k1min, k1max + 1):
                if (abs(_dp_value(w1, h, k1, memo)
                        + _dp_value(w2, h, k - k1, memo) - target) < 1e-9):
                    _dp_reconstruct(w1, h, k1, x0, y0, memo, scale, out)
                    _dp_reconstruct(w2, h, k - k1,
                                    x0 + w1 / scale, y0, memo, scale, out)
                    return
    if h >= 2:
        for c in range(1, h):
            h1, h2 = c, h - c
            k1max = min(k - 1, w * h1)
            k1min = max(1, k - (w * h2))
            for k1 in range(k1min, k1max + 1):
                if (abs(_dp_value(w, h1, k1, memo)
                        + _dp_value(w, h2, k - k1, memo) - target) < 1e-9):
                    _dp_reconstruct(w, h1, k1, x0, y0, memo, scale, out)
                    _dp_reconstruct(w, h2, k - k1,
                                    x0, y0 + h1 / scale, memo, scale, out)
                    return
    out.append((x0, y0, x0 + w / scale, y0 + h / scale))


def solve_exact(n, scale=48):
    """Exact guillotine packing on a scale x scale grid."""
    global _DP_SCALE
    memo = {}
    _dp_value(scale, scale, n, memo)
    cells = []
    _dp_reconstruct(scale, scale, n, 0.0, 0.0, memo, scale, cells)
    res = []
    for (x0, y0, x1, y1) in cells:
        w = x1 - x0
        h = y1 - y0
        s = min(w, h)
        res.append(((x0 + x1) / 2.0, (y0 + y1) / 2.0, 0.0, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


# ----------------------------------------------------------------------
#  Greedy + local search (works for every n)
# ----------------------------------------------------------------------
_FRACS = [0.5, 1 / 3, 2 / 3, 0.25, 0.75, 0.2, 0.4, 0.6, 0.8,
          1 / 6, 5 / 6, 1 / 8, 3 / 8, 5 / 8, 7 / 8,
          0.1, 0.3, 0.7, 0.9, 1 / 12, 5 / 12, 7 / 12, 11 / 12]


def _cval(c):
    return min(c[2] - c[0], c[3] - c[1])


def _split(c, direction, frac):
    x0, y0, x1, y1 = c
    if direction == 'v':
        xc = x0 + frac * (x1 - x0)
        return (x0, y0, xc, y1), (xc, y0, x1, y1)
    else:
        yc = y0 + frac * (y1 - y0)
        return (x0, y0, x1, yc), (x0, yc, x1, y1)


def _best_split(c):
    """Best single split of a rectangle into two rectangles (guillotine)."""
    base = _cval(c)
    best_gain = -1e18
    best_pair = None
    for frac in _FRACS:
        for d in ('v', 'h'):
            a, b = _split(c, d, frac)
            g = _cval(a) + _cval(b) - base
            if g > best_gain:
                best_gain = g
                best_pair = (a, b)
    return best_gain, best_pair


def _greedy_from(n, init_cells):
    cells = list(init_cells)
    while len(cells) < n:
        bi, bg, bp = -1, -1e18, None
        for i, c in enumerate(cells):
            g, p = _best_split(c)
            if g > bg:
                bg, bi, bp = g, i, p
        if bi < 0 or bp is None:
            break
        cells[bi] = bp[0]
        cells.append(bp[1])
    return cells


def _local_improve(cells, rounds=250):
    improved = True
    n = len(cells)
    while improved:
        improved = False
        for _ in range(rounds):
            if n < 2:
                break
            i, j = random.sample(range(n), 2)
            a, b = cells[i], cells[j]
            x0 = min(a[0], b[0]); y0 = min(a[1], b[1])
            x1 = max(a[2], b[2]); y1 = max(a[3], b[3])
            orig = _cval(a) + _cval(b)
            merged = (x0, y0, x1, y1)
            _, pair = _best_split(merged)
            if pair is None:
                continue
            c1, c2 = pair
            if _cval(c1) + _cval(c2) > orig + 1e-12:
                cells[i] = c1
                cells[j] = c2
                improved = True
        # three-cell merge
        if n >= 3:
            for _ in range(max(10, rounds // 5)):
                i, j, k = random.sample(range(n), 3)
                a, b, c = cells[i], cells[j], cells[k]
                x0 = min(a[0], b[0], c[0]); y0 = min(a[1], b[1], c[1])
                x1 = max(a[2], b[2], c[2]); y1 = max(a[3], b[3], c[3])
                orig = _cval(a) + _cval(b) + _cval(c)
                merged = (x0, y0, x1, y1)
                best3, best_set = -1.0, None
                for frac in _FRACS:
                    for d in ('v', 'h'):
                        p1, p2 = _split(merged, d, frac)
                        _, pair1 = _best_split(p1)
                        if pair1 is not None:
                            v = _cval(pair1[0]) + _cval(pair1[1]) + _cval(p2)
                            if v > best3:
                                best3 = v
                                best_set = (pair1[0], pair1[1], p2)
                        _, pair2 = _best_split(p2)
                        if pair2 is not None:
                            v = _cval(p1) + _cval(pair2[0]) + _cval(pair2[1])
                            if v > best3:
                                best3 = v
                                best_set = (p1, pair2[0], pair2[1])
                if best_set and best3 > orig + 1e-12:
                    cells[i], cells[j], cells[k] = best_set
                    improved = True
    return cells


def _grid_starts(n):
    starts = [[(0.0, 0.0, 1.0, 1.0)]]
    for kk in (2, 3, 4, 5, 6):
        s = 1.0 / kk
        g = []
        for i in range(kk):
            for j in range(kk):
                g.append((i * s, j * s, (i + 1) * s, (j + 1) * s))
        if len(g) <= n:
            starts.append(g)
    for kk in (2, 3, 4, 5, 6, 7):
        if kk <= n:
            s = 1.0 / kk
            starts.append([(0.0, i * s, 1.0, (i + 1) * s) for i in range(kk)])
            starts.append([(j * s, 0.0, (j + 1) * s, 1.0) for j in range(kk)])
    return starts


def solve_greedy(n, restarts=6):
    random.seed(1234567 ^ n)
    best_cells, best_score = None, -1.0
    for start in _grid_starts(n):
        cs = _greedy_from(n, start)
        cs = _local_improve(cs, rounds=200)
        if len(cs) > n:
            cs = cs[:n]
        sc = sum(_cval(c) for c in cs)
        if sc > best_score:
            best_score, best_cells = sc, cs
    for _ in range(restarts):
        cs = _greedy_from(n, [(0.0, 0.0, 1.0, 1.0)])
        cs = _local_improve(cs, rounds=120)
        if len(cs) > n:
            cs = cs[:n]
        sc = sum(_cval(c) for c in cs)
        if sc > best_score:
            best_score, best_cells = sc, cs
    while len(best_cells) < n:
        best_cells.append((0.0, 0.0, 0.0, 0.0))
    best_cells = best_cells[:n]
    out = []
    for (x0, y0, x1, y1) in best_cells:
        w, h = x1 - x0, y1 - y0
        s = max(0.0, min(w, h))
        cx = max(0.0, min(1.0, (x0 + x1) / 2.0))
        cy = max(0.0, min(1.0, (y0 + y1) / 2.0))
        out.append((cx, cy, 0.0, min(1.0, s)))
    return out


# ----------------------------------------------------------------------
#  Branch-and-bound using the DP as an admissible upper bound
# ----------------------------------------------------------------------
def solve_bb(n, scale=24, time_frac=0.55):
    """Branch-and-bound over guillotine topologies with DP-based bounds.

    The DP table for a small `scale` is computed lazily.  For each candidate
    branch we get the exact optimum of the discretised sub-problem, which
    upper-bounds any continuous realisation.  The incumbent is produced by
    the greedy heuristic.
    """
    import time
    t0 = time.time()
    budget = time_frac * 60.0

    # incumbent from greedy
    incumbent_cells = None
    try:
        inc = solve_greedy(n, restarts=4)
        incumbent_cells = [(max(0.0, cx - s / 2), max(0.0, cy - s / 2),
                            min(1.0, cx + s / 2), min(1.0, cy + s / 2))
                           for (cx, cy, _, s) in inc]
        incumbent = sum(_cval(c) for c in incumbent_cells)
    except Exception:
        incumbent = 0.0

    memo = {}

    def bound(w, h, k):
        return _dp_value(w, h, k, memo) / scale

    root = (scale, scale)  # grid units
    best_cells = [list(incumbent_cells)]  # keep best partition in grid coords
    best_val = [incumbent]

    # stack entries: (w, h, k, x0, y0, partial_cells, partial_val)
    stack = [(root[0], root[1], n, 0.0, 0.0, [], 0.0)]

    while stack:
        if time.time() - t0 > budget:
            break
        w, h, k, x0, y0, partial, pval = stack.pop()
        if k == 1:
            s = min(w, h) / scale
            cells = partial + [(x0, y0, x0 + s, y0 + s)]
            total = pval + s
            if total > best_val[0]:
                best_val[0] = total
                best_cells[0] = cells
            continue

        ub = pval + bound(w, h, k)
        if ub <= best_val[0] + 1e-9:
            continue

        # try a limited set of cuts
        cut_choices = []
        step_v = max(1, int(w * 0.15))
        step_h = max(1, int(h * 0.15))
        for c in range(1, w, step_v):
            cut_choices.append(('v', c))
        cut_choices.append(('v', w // 2))
        for c in range(1, h, step_h):
            cut_choices.append(('h', c))
        cut_choices.append(('h', h // 2))

        children = []
        for direction, c in cut_choices:
            if direction == 'v':
                w1, w2 = c, w - c
                if w1 <= 0 or w2 <= 0:
                    continue
                for k1 in range(1, k):
                    k2 = k - k1
                    if k1 > w1 * h or k2 > w2 * h:
                        continue
                    v1 = bound(w1, h, k1)
                    v2 = bound(w2, h, k2)
                    est = pval + v1 + v2
                    if est > best_val[0] + 1e-9:
                        children.append((est, w1, h, k1, w2, h, k2,
                                         x0, y0, x0 + w1 / scale, y0))
            else:
                h1, h2 = c, h - c
                if h1 <= 0 or h2 <= 0:
                    continue
                for k1 in range(1, k):
                    k2 = k - k1
                    if k1 > w * h1 or k2 > w * h2:
                        continue
                    v1 = bound(w, h1, k1)
                    v2 = bound(w, h2, k2)
                    est = pval + v1 + v2
                    if est > best_val[0] + 1e-9:
                        children.append((est, w, h1, k1, w, h2, k2,
                                         x0, y0, x0, y0 + h1 / scale))

        children.sort(key=lambda t: -t[0])
        for ch in children[:40]:
            est, w1, h1, k1, w2, h2, k2, nx1, ny1, nx2, ny2 = ch
            if k2 > 1:
                stack.append((w2, h2, k2, nx2, ny2, partial, pval))
            else:
                s2 = min(w2, h2) / scale
                if s2 > 0:
                    stack.append((1, 1, 1, nx2, ny2,
                                  partial + [(nx2, ny2, nx2 + s2, ny2 + s2)],
                                  pval + s2))
            if k1 > 1:
                stack.append((w1, h1, k1, nx1, ny1, partial, pval))
            else:
                s1 = min(w1, h1) / scale
                if s1 > 0:
                    stack.append((1, 1, 1, nx1, ny1,
                                  partial + [(nx1, ny1, nx1 + s1, ny1 + s1)],
                                  pval + s1))

    # also refine incumbent with DP reconstruction if it beats the BB result
    # (the DP answer is exact for the discretised problem)
    cells = best_cells[0]
    cells = [(c[0], c[1], c[2], c[3]) for c in cells]
    while len(cells) < n:
        cells.append((0.5, 0.5, 0.5, 0.5))
    cells = cells[:n]

    out = []
    for (x0, y0, x1, y1) in cells:
        s = max(0.0, min(x1 - x0, y1 - y0))
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        out.append((max(0.0, min(1.0, cx)),
                    max(0.0, min(1.0, cy)),
                    0.0,
                    min(1.0, s)))

    # sanity: ensure returned squares do not overlap the boundary badly
    for (cx, cy, a, s) in out:
        if s <= 0:
            continue
        # clamp: a square centred at (cx,cy) with side s must lie inside unit square
        if cx - s / 2 < -1e-12 or cx + s / 2 > 1 + 1e-12 or \
           cy - s / 2 < -1e-12 or cy + s / 2 > 1 + 1e-12:
            # shrink to fit
            s2 = min(s, 2 * cx, 2 * (1 - cx), 2 * cy, 2 * (1 - cy))
            out[out.index((cx, cy, a, s))] = (cx, cy, a, max(0.0, min(1.0, s2)))
    return out


# ----------------------------------------------------------------------
#  Dispatcher
# ----------------------------------------------------------------------
def solve(n):
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Exact guillotine DP: fast and essentially optimal for moderate n.
    if n <= 16:
        try:
            return solve_exact(n, scale=56 if n <= 12 else 44)
        except Exception:
            pass

    # Medium n: branch-and-bound guided by a coarse DP bound, seeded with
    # a greedy incumbent.
    if n <= 40:
        try:
            res = solve_bb(n, scale=24, time_frac=0.55)
            # compare with pure greedy and take the better one
            g = solve_greedy(n, restarts=3)
            if sum(r[3] for r in g) > sum(r[3] for r in res):
                return g
            return res
        except Exception:
            pass

    # Large n: greedy heuristic is fast and scales.
    return solve_greedy(n, restarts=8)
