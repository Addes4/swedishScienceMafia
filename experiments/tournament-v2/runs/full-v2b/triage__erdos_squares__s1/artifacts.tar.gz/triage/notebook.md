# Research notebook: erdos_squares

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.856172.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | For a given n, solve the continuous optimization directly using a quasi-Newton method (L-BFGS) with a penalty/barrier function for the no-overlap constraints, i | 0.61 | favourite | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | not_better | 0.111111 |
| 4 | Exploit the known optimal packings for small n (n≤15) by fitting a parametric family: start with a regular arrangement of squares along the boundary in decreasi | 0.52 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 0 | Instead of using only grid-aligned squares, adapt a greedy circle-packing or force-directed algorithm: treat each square by its circumcircle and run a soft-body | 0.52 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.856172 |
| 2 | Partition the unit square into a fixed set of rectangles via hierarchical recursive subdivision (like a k-d tree) and assign exactly one square to each cell; tr | 0.51 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | improved | 0.936990 |
| 3 | Represent the layout as a finite set of candidate square sizes from an adaptive discretization (e.g., powers of a golden ratio or a set of 100 allowed sizes) an | 0.49 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 5 | Train a policy network via reinforcement learning (e.g., PPO) to produce square parameters autoregressively, where the reward is the total side length minus a h | 0.41 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Promotion: deepseek-ai/DeepSeek-V4.1-Flash:deepinfra found an improvement; deepseek-ai/DeepSeek-V4-Pro:deepinfra refined it -> improved (0.998420).

Best after round 1: **0.998420** (spent $0.04)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Replace the greedy beam search with a dynamic programming over a fixed fine grid of cut positions but allowing each cell to contain either one square or be recu | 0.45 | favourite | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | not_better | 0.111111 |
| 4 | Replace the fixed set of fractional cut positions with a continuous local optimization of cut coordinates: after an initial greedy partitioning, run gradient-fr | 0.41 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.917009 |
| 5 | Precompute optimal guillotine packings for many (w,h,k) using DP at a coarser scale and use them as a lookup table to accelerate a branch-and-bound search over  | 0.30 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.996531 |
| 3 | Apply a genetic algorithm to the partition tree structure directly: encode the sequence of guillotine cuts as a variable-length chromosome, evolve the populatio | 0.22 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.958281 |
| 1 | Instead of axis-aligned only, introduce rotated rectangles at 45° in the partition hierarchy by allowing diagonal cuts; for each cell we compute the largest ins | 0.18 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 2 | Use a combinatorial two-stage approach: first generate a set of candidate square sizes and positions by running a physics-based packing simulation with repulsiv | 0.00 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 2: **0.998420** (spent $0.08)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Cast the problem as a mixed-integer second-order cone program (MISOCP) where each square's center, rotation, and side are continuous variables, non-overlap is e | 0.14 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.977124 |
| 3 | Formulate the pack as placing n squares of equal side s inside the unit square, maximize s, then separately enlarge individual squares via a linear program that | 0.10 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | api_error |  |
| 2 | Use a hierarchical partition based on a quadtree, but instead of always splitting at the midpoint, optimize the split points continuously via a nested bisection | 0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 0 | Generalize the guillotine DP to allow each leaf to be a *rotated* square inscribed in its axis-aligned cell, where the side depends on both width and height and | 0.02 | middle | Qwen/Qwen3.5-9B:together (swapped) | invalid | 0.000000 |
| 1 | Model the problem as a continuous circle packing problem in the Chebyshev (L∞) metric: each square of side s becomes an L∞ ball of radius s/2; use a stochastic  | 0.01 | long_shot | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | invalid | 0.000000 |
| 5 | Use a Monte Carlo tree search where actions are the successive placement of squares: at each step, choose a square size, position, and rotation from a discrete  | 0.01 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.150000 |

Best after round 3: **0.998420** (spent $0.12)

