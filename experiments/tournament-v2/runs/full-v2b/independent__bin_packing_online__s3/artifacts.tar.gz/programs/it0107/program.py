# EVOLVE-BLOCK-START
"""Online bin packing: combination of best-fit residual and small bin-reuse bias."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = bins.astype(np.int64)

    # Fraction of the bin already used: 0 for a fresh bin, larger for more-used bins.
    used = 100 - b

    # Tight-fit preference: smaller residual after placing the item is better.
    residual = b - item

    # Reuse preference: mildly avoid opening a new bin, especially for medium/large
    # items where future fit is less likely to need a completely fresh bin.
    # A tiny amount is enough to break near-ties without hurting tight packing.
    reuse = used * 0.002

    # For very small items, fresh bins are relatively more valuable because they
    # preserve flexibility; for larger items, reuse is somewhat more attractive.
    if item <= 10:
        reuse = -reuse * 0.5
    elif item >= 70:
        reuse = reuse * 1.5

    # Primary term: tighter fit. Secondary term: slight bin-reuse preference.
    return -(residual.astype(np.float64)) + reuse
# EVOLVE-BLOCK-END
