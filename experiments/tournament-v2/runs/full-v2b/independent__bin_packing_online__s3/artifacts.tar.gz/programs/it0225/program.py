import numpy as np

def priority(item, bins):
    """
    Score bins to minimize expected waste. Exact fits are strongly preferred.
    For non-exact fits, penalize leaving very small residuals (which are often wasted),
    and slightly penalize opening a new bin (remaining capacity == 100).
    """
    residual = bins - item
    score = np.zeros(len(bins), dtype=float)
    
    # Exact fit: highest priority
    exact = (residual == 0)
    score[exact] = 1e6
    
    # Non-exact positive residuals: base is -residual (best fit),
    # but add a penalty for residuals below 20 to avoid tiny gaps.
    mask = residual > 0
    if np.any(mask):
        r = residual[mask].astype(float)
        pen = np.maximum(0.0, 20.0 - r) * 5.0
        score[mask] = -r - pen
    
    # Slight penalty for using an empty bin
    empty = (bins == 100)
    score[empty] -= 20.0
    
    return score
