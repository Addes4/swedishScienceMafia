import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "counts": [0] * 101,
    "best_threshold": 100,
    "last_alpha": 1.0,
}

def _estimate_mean():
    n = _state["n"]
    if n <= 0:
        return 40.0
    return _state["sum"] / n

def _update(item):
    _state["n"] += 1
    _state["sum"] += item
    _state["sumsq"] += item * item
    if 1 <= item <= 100:
        _state["counts"][item] += 1

def priority(item, bins):
    _update(item)

    # remaining capacity scores: prefer tight fit (small remaining)
    rem = bins - item  # resulting remaining capacity after placing item

    # dynamic bonus for bins that land in a good residual range
    # target residual around item-dependent size so that future big items can still fit
    # use rolling mean to adapt to distribution
    mean = _estimate_mean()
    # desired leftover window: roughly around half average item
    lo = max(0, int(0.25 * mean))
    hi = max(lo + 1, int(0.75 * mean))

    score = -rem.astype(np.float64)

    # bonus for residual in [lo, hi]
    in_window = (rem >= lo) & (rem <= hi)
    score += in_window.astype(np.float64) * 1e6

    # strong priority to exact fit
    exact = (rem == 0)
    score += exact.astype(np.float64) * 1e12

    return score
