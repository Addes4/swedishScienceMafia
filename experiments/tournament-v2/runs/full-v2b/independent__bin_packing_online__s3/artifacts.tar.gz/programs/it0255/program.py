import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.sum_items = 0
        self.small_seen = 0
        self.small_sum = 0
        self.target = 0.0
        self.bins_seen = 0


_state = _State()


def priority(item, bins):
    st = _state
    st.count += 1
    st.sum_items += item
    st.bins_seen = len(bins)

    if item <= 45:
        st.small_seen += 1
        st.small_sum += item

    # Estimate mean item size; use a slack target based on a quantile-like proxy.
    n = st.count
    mean_item = st.sum_items / n
    if st.small_seen > 0:
        small_mean = st.small_sum / st.small_seen
    else:
        small_mean = mean_item

    # Target remaining slack after placement.  Early on use tight best fit.
    # Later aim to leave roughly the size of a typical "small" item.
    warm = min(1.0, n / 300.0)
    target = warm * small_mean * 0.75

    rem = bins.astype(np.float64, copy=False)
    fit = rem - item

    # Primary: prefer fits closest to the target slack (not always smallest).
    score = -np.abs(fit - target)

    # Tie-break: among equal slack, prefer smaller remaining capacity (best fit).
    score -= 1e-6 * rem

    return score
