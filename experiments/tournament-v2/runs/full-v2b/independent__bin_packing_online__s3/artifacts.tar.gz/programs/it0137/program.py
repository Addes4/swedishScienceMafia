"""Best fit with strong preference against opening new bins."""
import numpy as np


def priority(item, bins):
    # Prefer tighter fits (smaller remaining capacity after placing), i.e. larger bins-item
    score = -np.abs(bins - item)  # best fit: smallest slack
    # Additionally, discourage using completely empty (unused) bins (cap == 100)
    # Penalize them strongly so we pack into existing bins whenever possible.
    penalty = np.where(bins == 100, -1000.0, 0.0)
    return score + penalty
