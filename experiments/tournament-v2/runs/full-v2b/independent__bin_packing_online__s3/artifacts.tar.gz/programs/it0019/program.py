import numpy as np


def priority(item, bins):
    # Best fit: maximize -(remaining - item) = item - remaining.
    # Smaller remaining after placement (i.e. larger item - remaining) is better.
    # Add a tiny preference for fuller bins among equal post-placement leftovers,
    # which helps avoid scattering items across many partially filled bins.
    remaining_after = bins - item
    return -remaining_after.astype(np.float64) - 1e-6 * bins
