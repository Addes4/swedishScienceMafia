import numpy as np

_STATE = {"fits": 0, "items": 0}

def priority(item, bins):
    """
    Best-fit with a small preference for bins that leave a useful residual,
    and a slight bias toward lower-index bins when fits are equally good.
    """
    # Favor tight fits: smaller residual is better.
    residual = bins - item
    # Primary score: negative residual.
    score = -residual.astype(np.float64)

    # Slightly prefer bins that are not completely full if residual is tiny,
    # because leaving capacity 0 can waste opportunity for tiny future items.
    # Only matters for near-exact fits and is tiny.
    score += np.where(residual <= 2, -0.05, 0.0)

    # Very small tie-break toward lower indices (older bins) to pack densely.
    n = len(bins)
    score += (n - np.arange(n)) * 1e-9

    _STATE["fits"] += 1
    return score
