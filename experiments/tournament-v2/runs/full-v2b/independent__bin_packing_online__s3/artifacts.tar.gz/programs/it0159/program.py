import numpy as np

_SMALL_CUTOFF = 40
_TINY_CUTOFF = 12
_small_seen = 0


def priority(item, bins):
    """Best-fit with mild reservation for tiny/small items.

    The item goes to the bin with the highest score; ties go to the first bin.
    """
    global _small_seen

    rem = bins

    # Remaining capacity after putting this item into each bin.
    after = rem - item

    # Base score: pure best fit. Prefer a tight fit, i.e. minimal leftover.
    score = -after.astype(np.float64)

    if item <= _TINY_CUTOFF:
        _small_seen += 1
        # For very small items, if there is a reasonably tight fit, take it;
        # otherwise slightly prefer bins that are not almost full, preserving
        # them for medium/large items.
        # Add a tiny bonus for bins whose leftover after placement is at least item.
        bonus = np.where(after >= item, 0.25, 0.0)
        score += bonus
    elif item <= _SMALL_CUTOFF:
        # For small/medium items, mildly prefer not to consume the very last
        # sliver of an otherwise-full bin unless it is an excellent fit.
        # This acts like best fit but with a small penalty for filling tight.
        score -= np.where(after <= 3, 0.5, 0.0)

    return score
