import numpy as np


def priority(item, bins):
    # Best fit: maximize the used capacity after placing => minimize remaining - item.
    # Ties/near-ties: slightly prefer leaving a larger remaining capacity to keep
    # bins flexible, breaking the common "tiny leftover" waste pattern.
    rem = bins - item  # leftover if placed here; bins only include those that fit
    # Primary: tighter fit (smaller leftover). Secondary: slightly favor larger leftover
    # to avoid creating many nearly-full but unusable bins.
    score = -(rem) - 0.02 * rem
    return score
