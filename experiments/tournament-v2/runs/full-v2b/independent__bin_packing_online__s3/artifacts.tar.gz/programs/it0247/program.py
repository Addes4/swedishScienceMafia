import numpy as np


def priority(item, bins):
    """Rank bins by best fit with a small anti-fragmentation perturbation.

    The item is placed into the bin with the highest score.
    - Primary goal: minimize leftover space after placing the item
      (best fit).
    - Secondary goal: mildly discourage opening brand-new bins when
      an existing bin can accept the item, which helps avoid premature
      consumption of full-capacity bins.
    """
    remaining_after = bins - item

    # Best-fit score: larger is better. Exact-fit gives 0, tight fits
    # give small negative values, loose fits give very negative values.
    score = -remaining_after.astype(np.float64)

    # Slight preference for already-used bins (remaining < 100).
    # This tiny bonus is unlikely to overturn meaningful fit differences
    # but can break near-ties in favor of continuing an open bin.
    score += np.where(bins < 100, 1e-6, 0.0)

    return score
