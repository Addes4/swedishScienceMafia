import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    This combines best-fit (prefer tight placements) with a slight bias toward bins that
    are already substantially filled, which helps avoid wasting large remaining capacities
    on small items.
    """
    # Best-fit component: higher score for bins with less remaining capacity after placing.
    fit_score = -(bins - item)

    # Preference for bins that are already more filled: higher score for smaller remaining
    # capacity before placing. Use a mild weight so it acts as a tie-breaker / slight bias.
    fill_bias = (100.0 - bins.astype(np.float64)) * 0.05

    # For very small items, avoid dumping them into completely empty bins if possible.
    # This is handled implicitly by the fill bias, but we can add a tiny extra penalty
    # for unused bins when the item is small.
    if item <= 20:
        empty_penalty = np.where(bins == 100, -0.5, 0.0)
    else:
        empty_penalty = 0.0

    return fit_score + fill_bias + empty_penalty
