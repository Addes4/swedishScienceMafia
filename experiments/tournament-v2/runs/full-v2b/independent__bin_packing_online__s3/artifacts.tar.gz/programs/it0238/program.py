import numpy as np

# Global state for online heuristics
_bins_used = 0
_closed = None          # boolean mask over bin indices that are closed
_threshold = 15         # do not use bins with remaining < threshold unless forced
_item_count = 0


def priority(item, bins):
    """Score bins so that best-fit is preferred, with closed-bin avoidance."""
    global _bins_used, _closed, _item_count

    n = len(bins)
    _item_count += 1

    # Initialize closed mask lazily
    if _closed is None or len(_closed) != n:
        _closed = np.zeros(n, dtype=bool)

    # Count bins that are not full (remaining < 100) as "used"
    # We track this to know which indices are active bins vs. virgin empty bins.
    active = bins < 100

    # A bin is considered closed if it is active but has too little remaining space
    # and the item doesn't fit (already guaranteed by the harness for bins in view,
    # but we still want to avoid tightly packing small leftovers when possible).
    remaining_after = bins - item

    # Base score: best fit (smallest remaining fitness after placement)
    # i.e., prefer bins where the leftover space is smallest.
    score = -(bins - item).astype(np.float64)

    # Penalty: strongly avoid using virgin empty bins (remaining == 100) unless necessary.
    # This encourages consolidating items into existing partially-filled bins first.
    virgin = (bins == 100)
    score[virgin] -= 5000.0

    # Penalty: avoid very tight leftovers that waste space for future items,
    # unless the item exactly fills the bin (which is always good).
    # exact_fit = (remaining_after == 0)
    # tight = (~exact_fit) & (remaining_after > 0) & (remaining_after < _threshold)
    # score[tight] -= 200.0

    # Avoid already closed bins (shouldn't matter since they're full, but safe)
    score[_closed] -= 1e6

    # If item fits in a non-virgin bin, strongly prefer that over opening a new bin
    non_virgin_fits = (~virgin)
    if np.any(non_virgin_fits):
        score[non_virgin_fits] += 10000.0

    # Among non-virgin bins, prefer best fit (already encoded) and avoid bins
    # that would become too empty to be useful (small remaining).
    # But exact fits are ideal.
    exact = (bins == item)
    score[exact] += 500.0

    return score
