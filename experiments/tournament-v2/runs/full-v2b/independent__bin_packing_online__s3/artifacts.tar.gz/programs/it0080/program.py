import numpy as np


def priority(item, bins):
    """Rank bins for an arriving item.

    The rule blends best-fit with a mild preference for older/open bins:
      - primary: smaller residual capacity after placing the item
      - secondary: prefer bins with lower original-ish remaining capacity
        (i.e. already-used bins) to avoid opening new bins too eagerly.
    """
    residual = bins - item

    # Primary score: tight fit strongly preferred.
    # Secondary tiny tie-break: avoid unused (capacity 100) bins unless necessary.
    # Since unused bins have residual 100 - item, they are already penalized by
    # the primary term, but the extra term helps when item is large.
    return -(residual.astype(np.float64) * 1000.0 + bins.astype(np.float64))
