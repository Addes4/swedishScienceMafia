"""Best fit with consolidation tiebreak.

Score = -(remaining capacity after placing the item) - tiny * (current remaining).
The main term puts the item in the bin it fits most tightly (classic Best Fit).
The tiny term (always < 1, so it cannot override the integer main term) breaks ties
in favor of fuller bins, consolidating items and avoiding fragmentation.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    return -residual.astype(np.float64) - 1e-6 * bins.astype(np.float64)
