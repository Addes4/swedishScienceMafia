import numpy as np

# Tuned constants for Weibull-shaped sizes, mean about 40.
MIN_RESIDUAL = 12     # ignore residual fits below this (likely wasted)
BALANCE = 0.0007      # slight preference for emptier bins on residual ties

def priority(item, bins):
    # Best fit: smaller residual is better, so score = -residual.
    residual = bins - item

    # Penalize very small residuals: those gaps are often unusable later.
    penalty = np.where((residual > 0) & (residual < MIN_RESIDUAL),
                       (MIN_RESIDUAL - residual) * 10.0,
                       0.0)

    # Primary: best fit. Secondary: balance to reduce fragmentation.
    return -residual - penalty + BALANCE * bins
