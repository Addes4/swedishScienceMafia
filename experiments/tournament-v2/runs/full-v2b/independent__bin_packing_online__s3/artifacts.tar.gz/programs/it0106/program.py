import numpy as np

def priority(item, bins):
    r = bins - item
    T = 20
    P = 2.0
    # base score
    # for r == 0: 1e9
    # for r >= T: -r
    # for 0 < r < T: (P-1)*r - P*T
    base = np.where(r == 0, 1e9,
                    np.where(r >= T, -r,
                             (P - 1) * r - P * T))
    # penalty for unused bins (capacity 100) unless perfect fit
    penalty = np.where((bins == 100) & (r > 0), -1e6, 0.0)
    return base + penalty
