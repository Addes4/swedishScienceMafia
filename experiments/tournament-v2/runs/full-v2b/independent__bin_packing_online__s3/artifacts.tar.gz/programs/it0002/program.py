"""Online bin packing: best-fit with adaptive residual-value scoring.

The bin-choice rule scores each candidate bin by how tightly the item fits
(small leftover is good), but also discounts tight fits whose leftover is
unlikely to be usable by future items, and mildly prefers opening/using bins
whose state history suggests good packing.  All statistics are learned online
from the items seen so far, so the rule is distribution-adaptive without
tuning to any single instance.
"""

import numpy as np

# ----------------------------------------------------------------------
# Online statistics of the item stream (shared across all calls).
# ----------------------------------------------------------------------
_COUNTS = np.zeros(101, dtype=np.float64)   # how many items of each size seen
_TOTAL = 0.0                                 # total number of items seen
_SUM = 0.0                                   # sum of item sizes
_CHI = 0.0                                   # capacity used (sum of placed sizes)
_OPEN = 0                                    # number of non-empty bins opened

# Exponential-decay window so the estimate adapts if the distribution drifts.
_DECAY = 0.999
_WSUM = np.zeros(101, dtype=np.float64)
_WTOTAL = 0.0


def _observe(item):
    """Update online item-size statistics (before choosing)."""
    global _TOTAL, _SUM, _WTOTAL
    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _SUM += float(item)
    # windowed counts for robustness
    _WSUM *= _DECAY
    _WSUM[item] += 1.0
    _WTOTAL = _WTOTAL * _DECAY + 1.0


def _fill_prob(room):
    """Empirical probability that some future item has size exactly `room`.

    Uses the windowed distribution; adds a light prior so cold start behaves
    like best-fit.  Returns a value in (0, 1].
    """
    if room <= 0 or room > 100:
        return 0.0
    # Laplace-style smoothing against a uniform prior over 1..100.
    seen = _WSUM[room]
    denom = _WTOTAL + 100.0
    return (seen + 1.0) / denom


def priority(item, bins):
    """Score bins: prefer tight fits whose leftover can still be filled."""
    _observe(item)

    bins = np.asarray(bins)
    # residual room if the item is placed here
    room = bins - item

    # Base best-fit term: smaller room -> larger score.
    # Scale by 1.0 so it dominates, with residual-value bonuses as tie-breakers.
    base = -room.astype(np.float64)

    # Bonus for leftovers that are likely to be consumable by future items.
    fill = np.array([_fill_prob(int(r)) for r in room], dtype=np.float64)
    # A leftover of 0 is perfectly efficient: give it the biggest bonus.
    zero_bonus = (room == 0).astype(np.float64) * 2.0

    # Mild preference for reusing already-open bins (avoid spreading).
    open_bonus = (bins < 100).astype(np.float64) * 0.15

    return base + 1.5 * fill + zero_bonus + open_bonus
