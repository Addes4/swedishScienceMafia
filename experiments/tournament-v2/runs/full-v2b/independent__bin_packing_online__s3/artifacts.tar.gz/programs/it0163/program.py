import numpy as np


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.int64)

    # Best fit: prefer the smallest remaining capacity that still fits.
    residual = bins - item

    # Slight secondary preference for bins that are already somewhat loaded,
    # but not perfectly full, to reduce fragmentation among medium bins.
    # This keeps the ranking stable and cheap.
    load = 100 - bins

    # Main score: strongly favor tight fits, with a weak bonus for fuller bins.
    # The coefficient is small so it does not override best-fit behavior.
    return -residual * 1000 - load
