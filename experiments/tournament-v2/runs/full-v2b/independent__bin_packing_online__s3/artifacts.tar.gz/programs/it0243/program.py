"""Online bin packing heuristic: smart best-fit with fit-preference bias.

Core idea: choose the bin that leaves the smallest remaining capacity (best fit),
but strongly prefer an exact fit (gap == item) and slightly penalize bins whose
resulting leftover equals a size that frequently appears (so we don't strand a
gap that is hard to reuse). Global item statistics are maintained online.
"""
import numpy as np

# Running statistics over observed item sizes (1..100), shared across calls.
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total

    # Update running item-size frequency estimates.
    _counts[item] += 1.0
    _total += 1.0

    # Remaining capacity left if we place the item here.
    leftover = bins - item

    # Base score: best fit -> smaller leftover is better.
    score = -leftover.astype(np.float64)

    # Strong bonus for an exact fit (leftover == 0).
    score += 1000.0 * (leftover == 0)

    # Slight penalty when the leftover capacity matches a commonly seen item
    # size -- such a gap will likely be filled soon, so it isn't wasted, but
    # a gap that is a *rare* size is risky to create. Reward rare-gap leftovers.
    freq = _counts / max(_total, 1.0)
    # leftover can be 0..99; use probabilities as small adjustments.
    left_clip = np.clip(leftover, 0, 100)
    gap_freq = freq[left_clip]
    score += 5.0 * gap_freq  # prefer leaving a gap that gets reused often

    return score
