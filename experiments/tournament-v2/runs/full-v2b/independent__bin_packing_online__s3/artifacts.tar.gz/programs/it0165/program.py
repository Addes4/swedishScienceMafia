import numpy as np


class _PackerState:
    def __init__(self):
        self.counts = {}
        self.total = 0

    def observe(self, item):
        self.counts[item] = self.counts.get(item, 0) + 1
        self.total += 1


_state = _PackerState()


def priority(item, bins):
    """Best fit with a small stateful bias toward reusable residual capacities."""
    _state.observe(item)

    # Pure best-fit component: prefer smaller remaining capacity after placement.
    base = -(bins - item)

    # Bias: if a bin's remaining capacity matches a frequently seen item size,
    # placing this item there tends to create a useful residual later.
    # This is cheap and works as a tie-breaker without hurting normal best fit.
    total = _state.total
    if total < 50:
        return base

    # fav is a small bonus for bins whose current residual is a common item size.
    fav = np.zeros_like(bins, dtype=np.float64)
    for size, cnt in _state.counts.items():
        if cnt >= 2:
            fav += (bins == size) * (cnt / total)

    # Weight small: best fit remains dominant.
    return base + 0.01 * fav
