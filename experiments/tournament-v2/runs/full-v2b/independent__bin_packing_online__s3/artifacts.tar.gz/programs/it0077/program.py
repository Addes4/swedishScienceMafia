import numpy as np


def priority(item, bins):
    """
    Online bin-packing heuristic:
    prefer the tightest fit, with a small preference for later bins on ties.
    """
    fit = bins >= item
    score = np.full(bins.shape, -1e9, dtype=np.float64)

    # Primary: minimize remaining capacity after placement.
    # A smaller remaining capacity is better, so use negative remaining capacity.
    score[fit] = -bins[fit].astype(np.float64)

    # Tiny tie-breaker: prefer later bins very slightly.
    # This can help by filling already-used bins before opening fresh ones.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    score[fit] += 1e-6 * idx[fit]

    return score
