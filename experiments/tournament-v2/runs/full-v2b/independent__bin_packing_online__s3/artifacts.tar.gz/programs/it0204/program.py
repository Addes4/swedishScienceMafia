import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.sumsq = 0.0
        self.hist = np.zeros(101, dtype=np.int64)

    def update(self, item):
        self.n += 1
        self.sum += item
        self.sumsq += item * item
        self.hist[int(item)] += 1

    def mean(self):
        if self.n == 0:
            return 40.0
        return self.sum / self.n

    def var(self):
        if self.n <= 1:
            return 400.0
        m = self.mean()
        v = self.sumsq / self.n - m * m
        return max(v, 1.0)

    def approx_remaining_prob(self, r):
        # Probability that a future item is <= r, estimated by empirical histogram.
        if self.n < 50:
            # fallback to a smooth Weibull-ish estimate with mean ~40
            return min(1.0, max(0.0, 1.0 - np.exp(-((r / 40.0) ** 1.5))))
        total = self.n
        c = np.searchsorted(np.arange(101), r, side='right')
        return float(self.hist[:c].sum()) / total


_STATE = _State()


def priority(item, bins):
    """Rank bins for online bin packing.

    The score combines:
      - best fit (prefer small remaining capacity after placing the item)
      - exact-fit and tight-fit bonuses
      - a mild preference to use already-open bins over creating new ones
      - a stateful estimate of whether a given leftover capacity is likely to be
        useful for future items.
    """
    _STATE.update(item)

    bins = np.asarray(bins, dtype=np.int64)
    if bins.size == 0:
        return np.zeros(0, dtype=np.float64)

    rem_after = bins - int(item)
    # rem_after >= 0 guaranteed by the harness for shown bins.

    # Base best-fit score: smaller leftover is better.
    score = -rem_after.astype(np.float64)

    # Exact fit is very valuable.
    exact = (rem_after == 0)
    score += exact.astype(np.float64) * 1000.0

    # Tight fits (small but positive leftover) get a bonus; these tend to pack well.
    tight = (rem_after > 0) & (rem_after <= 10)
    score += tight.astype(np.float64) * 50.0

    # Prefer not to open a brand new bin if some existing bin can take the item
    # reasonably well. Bins with full remaining capacity 100 are the unused ones.
    is_new = (bins == 100)
    score += (~is_new).astype(np.float64) * 15.0

    # Stateful bonus: estimate probability that the leftover can still fit some
    # future item, which encourages leaving useful gaps rather than dead space.
    # This is applied mildly to avoid overfitting.
    if _STATE.n > 100:
        # Vectorized-ish but simple loop is fine; arrays are small on average.
        p = np.array([_STATE.approx_remaining_prob(int(r)) for r in rem_after],
                     dtype=np.float64)
        score += p * 20.0

    # Numerical safety: replace any NaN/inf with a very low score.
    bad = ~np.isfinite(score)
    if np.any(bad):
        score[bad] = -1e18

    return score
