"""Online bin packing heuristic: adaptive best-fit with new-bin suppression."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0
        self.sq = 0.0
        # count of items seen by rough bucket, used to estimate free-space need
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1
        self.total += item
        self.sq += item * item
        self.hist[item] += 1.0

    def mean(self):
        return self.total / self.n if self.n else 40.0

    def std(self):
        if self.n < 2:
            return 20.0
        m = self.total / self.n
        v = self.sq / self.n - m * m
        if v < 0:
            v = 0.0
        return v ** 0.5


_STATE = _State()


def priority(item, bins):
    _STATE.update(item)
    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    # Bins that already contain something: remaining capacity < 100.
    # Unused bins: remaining capacity == 100.
    # Worst-fit-like leftover: after placing, leftover = bins - item.
    leftover = bins - item  # all bins fit item, so leftover >= 0

    mean = _STATE.mean()
    std = _STATE.std()

    # Threshold: accept a partially filled bin if the resulting leftover is
    # not too large relative to expected future item size.  We prefer tight
    # fits but allow some slack to reduce fragmentation.
    # Small leftover => very tight fit => best.
    # Very large leftover (near 100) means bin is essentially empty; opening
    # a new bin is similar, so we shouldn't strongly prefer reusing an almost
    # empty bin over a fresh one, but reuse is still generally better.
    #
    # Use best-fit score with a mild penalty for large leftovers and a mild
    # bonus for medium leftovers that leave useful room.

    # Base best-fit: prefer smallest leftover.
    # Tune using running stats.
    # Expected item size follows Weibull-ish with mean~40, std~20.
    # A leftover close to the mean wastes little.
    target = mean  # ideal remaining capacity after placing for future items

    # Score: negative distance of leftover from a small value, but
    # tightest fit strongly preferred. Combine linear best-fit with
    # preference for leftover near target.
    # distance from ideal leftover
    dist = np.abs(leftover - target)

    # Unused bins (leftover == 100 - item): give a score based on how full
    # bin would be.  Reusing an empty bin vs opening new: same.  So an
    # unused bin should score like a bin whose leftover would be 100-item.
    # It naturally does, so no special treatment needed.

    # Final score: primary tight fit, secondary closeness to target.
    # tight fit: smaller leftover better => -leftover weight high
    scores = -leftover * 1.0 - dist * 0.05

    # Slight adjustment: heavily prioritize filling bins that are already
    # substantially used (leftover small) to reduce bin count.
    # Penalize using almost-empty bins slightly less than new bins is
    # automatic.

    return scores
