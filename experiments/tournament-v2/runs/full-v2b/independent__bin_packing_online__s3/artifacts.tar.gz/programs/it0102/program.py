import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin whose remaining capacity is just enough for the item.
    # Add a mild penalty for using a completely empty bin (capacity 100), so that
    # fresh bins are conserved for larger items when possible.
    score = -(bins - item)
    score = score - 2.0 * (bins == 100)
    return score
