import numpy as np

_state = {
    "items": [],
    "bins_used": 0,
}

def priority(item, bins):
    # Best-fit: score higher for smaller remaining capacity after placing the item,
    # i.e. prefer bins whose remaining capacity is closest to the item size.
    # Score = -(remaining_cap - item). Smaller leftover -> higher score.
    #
    # Add a tiny secondary term to prefer bins that are already relatively full
    # (smaller remaining capacity overall) to encourage consolidation and reduce
    # fragmentation across many partially-filled bins.
    remaining_after = bins - item
    # Primary: best fit (minimize leftover)
    # Secondary: prefer fuller bins (smaller bins value)
    score = -remaining_after.astype(np.float64) * 1000.0 - bins.astype(np.float64)
    return score
