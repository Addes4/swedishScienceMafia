import numpy as np


def priority(item, bins):
    """Best fit with a tiny deterministic residual-class tie-breaker.

    The item goes into the bin with the smallest residual capacity r = bins - item
    (classic best fit).  Ties are broken toward residuals that are slightly less
    "wasteful" for the common item sizes around the mean (~40), avoiding exact
    zero residuals when an equally tight alternative exists.
    """
    residual = bins - item

    # Base score: prefer smaller residual (negative residual => higher score).
    score = -residual.astype(np.float64)

    # Deterministic tie-breaker.  For equal residual, prefer bins whose residual
    # is not exactly zero if item is large-ish, since 0 residual creates a closed
    # bin that cannot accept any further item, whereas small positive residuals
    # preserve a little flexibility.  This is a nudge of magnitude < 1, so it
    # only affects exact ties in residual.
    tie = np.zeros_like(score)
    # Penalize exact fills a bit when the item is >= 35 (encourages sub-40 packing).
    if item >= 35:
        tie = np.where(residual == 0, -0.25, 0.0)
    else:
        # For small items, exact fill is actually great; weakly reward it.
        tie = np.where(residual == 0, 0.25, 0.0)

    return score + tie
