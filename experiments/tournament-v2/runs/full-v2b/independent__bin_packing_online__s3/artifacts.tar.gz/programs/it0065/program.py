"""Online bin packing with an adaptive best-fit rule."""
import numpy as np

_state = {
    "count": 0,
    "sum": 0.0,
    "alpha": 0.0,
}


def priority(item, bins):
    """Rank bins by fit tightness with a tiny adaptive bias toward fuller bins."""
    s = _state
    s["count"] += 1
    s["sum"] += item
    mean_item = s["sum"] / s["count"]

    # Prefer bins where the leftover after placing the item is smallest.
    leftover = bins - item

    # Small bias toward bins that are already relatively full.
    # Scale is tiny so it only breaks near-ties.
    bias = 1.0 / (100.0 + bins)

    # Adaptive term based on mean item size: when items are large,
    # strongly prefer exact/tight fits; when smaller, still tight but less extreme.
    adapt = 0.02 * (mean_item / 40.0)

    return -(leftover.astype(np.float64)) - adapt * bias
