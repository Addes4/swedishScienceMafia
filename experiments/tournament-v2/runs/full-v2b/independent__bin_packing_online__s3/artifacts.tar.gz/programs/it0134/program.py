import numpy as np


def priority(item, bins):
    """Best fit with tie-break: minimize residual capacity; prefer fuller bins on ties."""
    residual = bins - item
    # Main score: tighter fit has higher priority.
    score = -residual.astype(np.float64)
    # Tiny tie-break: among equal residuals, prefer bins that are less empty
    # (remaining capacity farther from 100), preserving completely empty bins.
    score += 1e-6 * (100.0 - bins.astype(np.float64))
    return score
