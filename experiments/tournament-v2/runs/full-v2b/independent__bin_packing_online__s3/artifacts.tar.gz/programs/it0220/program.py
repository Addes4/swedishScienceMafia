import numpy as np


def priority(item, bins):
    """Score bins: exact fill > best fit (smallest remaining >= item).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities for bins the item fits in.

    Returns a score per bin; highest score wins, ties to first bin.
    """
    # Prefer bins that are exactly filled by this item.
    exact = (bins == item)

    # Best fit: leftover capacity after placing the item. Smaller is better.
    leftover = bins - item

    # Give exact fills an unbeatable boost so they always win.
    # Among non-exact bins, smaller leftover ranks higher.
    return exact.astype(np.float64) * 1e6 - leftover.astype(np.float64)
