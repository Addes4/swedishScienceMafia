import numpy as np

# State kept across calls (per instance process, but harmless if reused).
_CALL_COUNT = 0
_LAST_ITEM = None


def priority(item, bins):
    """Score bins for online bin packing.

    The main rule is best-fit: prefer the bin with the smallest remaining capacity
    that still fits.  We add a small deterministic bias to avoid some pathological
    online choices and to encourage filling bins to useful residual levels.
    """
    global _CALL_COUNT, _LAST_ITEM
    _CALL_COUNT += 1
    _LAST_ITEM = int(item)

    b = bins.astype(np.float64)
    residual = b - float(item)

    # Best fit: highly negative residual is good.
    score = -residual

    # Mild preference for exact/near-exact fits and for preserving just-opened bins.
    # Since items are Weibull-shaped with mean ~40, many residuals around 0..40 matter.
    # This bias is small enough not to dominate best-fit.
    score += 0.02 * np.exp(-residual / 25.0)
    score -= 0.01 * (residual == 100.0 - float(item))

    # Avoid leaving tiny unusable holes when a better choice is available.
    # A residual in (0, 5) is slightly worse than zero or a larger residual.
    tiny = (residual > 0.0) & (residual < 5.0)
    score[tiny] -= 0.03

    return score
