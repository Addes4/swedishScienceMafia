import numpy as np


def priority(item, bins):
    """Rank bins by fit quality.

    Strategy: best-fit with a preference for exact/perfect matches and
    a mild bias toward lower-index bins to reduce fragmentation.
    """
    # Primary: smaller remaining capacity after placing item is better.
    # score = -(bins - item)  => best fit
    scores = -(bins - item).astype(np.float64)

    # Strong bonus for bins that would be exactly filled.
    # This helps avoid leaving awkward small gaps.
    exact = (bins == item)
    if exact.any():
        scores[exact] += 1000.0

    # Mild preference for already-fuller bins (smaller remaining capacity),
    # implemented via best-fit already; skip extra complexity.

    return scores
