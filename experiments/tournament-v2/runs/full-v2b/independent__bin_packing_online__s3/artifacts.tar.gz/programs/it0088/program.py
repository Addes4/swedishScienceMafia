import numpy as np

_small = 0


def priority(item, bins):
    """Best-fit with a tiny preference for partially-used bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    # Primary: prefer the bin whose remaining capacity is closest to the item
    # (smallest leftover after placing). Secondary: among equal leftovers, prefer
    # bins that are already opened (remaining < 100) to avoid opening new bins.
    leftover = bins - item
    opened = (bins < 100)
    return -leftover * 2.0 + opened * 1.0
