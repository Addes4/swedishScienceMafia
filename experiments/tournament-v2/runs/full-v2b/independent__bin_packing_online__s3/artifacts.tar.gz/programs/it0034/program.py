import numpy as np


class _Packer:
    def __init__(self):
        # Histogram of observed item sizes.
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        # Cache for the "goodness" of a leftover capacity.
        self.cache = {}
        self.last_update = -1

    def observe(self, item):
        self.hist[item] += 1.0
        self.total += 1.0

    def value_of_leftover(self, r):
        """How valuable is a bin with remaining capacity r?"""
        if r == 0:
            return 0.0
        # Probability that a future item has exactly this residual, scaled up,
        # plus a tiny preference for leaving uncommon leftovers.
        p = self.hist[r] / self.total if self.total > 0.0 else 0.0
        # Being able to exactly fill with a common item is good.
        return p * 1000.0


_state = _Packer()


def priority(item, bins):
    """Rank bins by best fit modified by distribution-aware leftover value."""
    _state.observe(item)

    # For each candidate bin, the resulting leftover after placing the item.
    leftover = bins - item  # numpy int64 array

    # Base best-fit: prefer smaller leftover (more negative -> higher score after negation).
    scores = -leftover.astype(np.float64)

    # Add a bonus if the leftover equals a frequently seen item size, since that
    # residual can likely be filled exactly by an upcoming item.
    hist = _state.hist
    total = _state.total
    bonus = np.zeros_like(scores)

    if total > 0.0:
        # Gather frequencies for the leftovers that can actually occur.
        # Only compute where leftover is within 1..100.
        mask = (leftover >= 1) & (leftover <= 100)
        if np.any(mask):
            vals = leftover[mask]
            # Use direct indexing into the histogram.
            freq = hist[vals] / total
            # Scale: small bonus relative to capacity differences.
            bonus[mask] = freq * 50.0

    scores = scores + bonus
    return scores
