import numpy as np


def priority(item, bins):
    """Rank bins by a size-aware best-fit rule.

    The main score is tightness: prefer the bin with the smallest remaining
    capacity that still fits.  This is classic best fit, which is strong for
    online bin packing.  To avoid needlessly wasting capacity by creating very
    small leftovers, add a mild penalty for residuals below a threshold and a
    bonus for exact fits.  All operations are vectorized over the numpy array.
    """
    b = bins.astype(np.int64, copy=False)
    residual = b - item

    # Best fit: smaller residual is better.
    score = -residual.astype(np.float64)

    # Exact fit is always attractive.
    score += (residual == 0).astype(np.float64) * 0.25

    # Penalize creating tiny unusable fragments, especially for small items,
    # while still keeping best-fit as the dominant signal.
    small_frag = (residual > 0) & (residual < 10)
    score -= small_frag.astype(np.float64) * (0.02 + 0.001 * (10 - residual))

    return score
