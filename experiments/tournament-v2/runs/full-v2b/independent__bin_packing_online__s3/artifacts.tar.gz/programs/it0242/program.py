import numpy as np


def priority(item, bins):
    """Best fit with a tiny penalty for opening unused bins."""
    # Primary: prefer smallest remaining capacity after placement (best fit).
    # bins - item is minimized when bins is closest to item.
    remaining_after = bins - item

    # Secondary: when fits are equal, slightly prefer already-used bins.
    # An untouched bin has remaining capacity exactly 100, so penalize it a bit.
    unused_penalty = (bins == 100).astype(np.int64)

    # Score is higher for better bins. Best fit => smallest remaining_after.
    # Penalty is small enough to only break exact ties.
    return -(remaining_after * 101 + unused_penalty)
