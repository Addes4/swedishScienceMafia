import numpy as np

# State shared across calls for one instance.
_state = {"calls": 0, "perfect_fits": 0}

def priority(item, bins):
    """Best-fit variant: prefer tight fits and avoid opening new bins unless needed."""
    # `bins` is an int64 numpy array of remaining capacities for bins this item fits in.
    # Score higher = better. Ties go to the first bin.

    _state["calls"] += 1

    # Prefer exact fits strongly. Track if exact fits occur often.
    exact = (bins == item)
    n_exact = int(exact.sum())
    if n_exact:
        _state["perfect_fits"] += 1
        # Exact fit should always win.
        return np.where(exact, 1000, -(bins - item) * 0.001)

    # Otherwise use best fit: the bin with the smallest remaining capacity that fits.
    # Score = -(remaining - item) = item - remaining, so larger = tighter fit.
    # Add a tiny bias against using completely empty bins (capacity 100) when
    # partially filled bins are available, to keep empty bins for large items.
    scores = -(bins - item).astype(np.float64)

    # Penalize full (100) empty bins slightly, but not if everything is empty.
    # This encourages filling partially-used bins first, which tends to reduce bin count.
    empty_mask = (bins == 100)
    n_nonempty = int((~empty_mask).sum())
    if n_nonempty > 0:
        scores = np.where(empty_mask, scores - 50.0, scores)

    return scores
