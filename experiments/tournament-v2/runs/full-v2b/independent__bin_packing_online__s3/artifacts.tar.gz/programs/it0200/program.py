"""Adaptive best-fit bin packing priority rule.

Strategy: score primarily by tightness (smallest resulting leftover after
placing the item), with a secondary term that slightly prefers bins that are
already more filled (to concentrate packing) and a tiny deterministic
perturbation derived from item size and bin index to break pathological ties.

This is essentially a "best fit with a concentration bonus".  It's O(n) per
call with vectorized numpy, well within the time limit.
"""
import numpy as np


def priority(item, bins):
    # leftover capacity if we place `item` into each bin
    leftover = bins - item  # all bins here fit the item, so leftover >= 0

    # Primary objective: minimize leftover (best fit).
    # Secondary: slight bonus for bins that are more filled (smaller remaining
    # capacity before placement => larger (100 - bins)).  This encourages
    # concentrating items rather than spreading them, which helps a lot in
    # practice for bin packing heuristics.
    filled = 100 - bins

    # Convert to a maximization score.
    # Scale so that leftover dominates, filled is a gentle tie-breaker.
    score = -(leftover.astype(np.float64)) + 0.35 * filled.astype(np.float64)

    # Tiny deterministic perturbation to break exact ties in a non-index-biased,
    # reproducible way.  Magnitude is far below the 1.0 spacing of integer
    # leftovers so it never overrides the primary comparison.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    # deterministic hash-like mix
    mix = np.sin((idx + 1.0) * 12.9898 + item * 78.233) * 43758.5453
    mix = mix - np.floor(mix)  # in [0,1)
    score += 1e-6 * mix

    return score
