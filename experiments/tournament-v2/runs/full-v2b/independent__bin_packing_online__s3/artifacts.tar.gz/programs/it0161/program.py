import numpy as np


def priority(item, bins):
    """Best-fit with slight preference for exact-zero slack.

    Score = -(residual slack) - small * (slack != 0)
    Highest score -> smallest positive slack, exact fit preferred.
    """
    slack = bins - item  # >= 0 since only fitting bins are passed
    # Prefer exact fits (slack == 0), then minimum slack.
    return -slack.astype(np.float64) - 1e-6 * (slack != 0)
