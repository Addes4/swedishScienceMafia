import numpy as np


# Tunable constants for the scoring rule.
UNUSED_PENALTY = 2.0          # discourage opening new bins
ALMOST_FULL_LIMIT = 12        # prefer bins that would become nearly full
ALMOST_FULL_BONUS = 0.7
SMALL_LEFTOVER_LIMIT = 8
SMALL_LEFTOVER_BONUS = 0.3


def priority(item, bins):
    """Return a score for every bin; highest score wins (ties to first bin).

    Strategy: best-fit with a mild penalty for unused bins and a bonus for
    leaving a small residual capacity after placement.
    """
    bins = np.asarray(bins, dtype=np.int64)

    # Base best-fit score: smaller remaining capacity is better.
    scores = -(bins - item)

    # Penalize completely unused bins so that opening a new bin is discouraged.
    unused = bins >= 100
    if np.any(unused):
        scores = scores - UNUSED_PENALTY * unused

    # After placing the item, the leftover in a bin would be (bins - item).
    leftover = bins - item

    # Reward placements that make a bin almost full (small positive leftover).
    almost_full = (leftover > 0) & (leftover <= ALMOST_FULL_LIMIT)
    if np.any(almost_full):
        scores = scores + ALMOST_FULL_BONUS * almost_full

    # Mildly reward very small leftovers that are positive (but not exact).
    tiny_left = (leftover > 0) & (leftover <= SMALL_LEFTOVER_LIMIT)
    if np.any(tiny_left):
        scores = scores + SMALL_LEFTOVER_BONUS * tiny_left

    return scores
