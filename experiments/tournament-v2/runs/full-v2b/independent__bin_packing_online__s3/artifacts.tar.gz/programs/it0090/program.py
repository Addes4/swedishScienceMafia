import numpy as np


def priority(item, bins):
    """Rank bins by a weighted best-fit score.

    Primary objective: minimize leftover space after placing the item.
    Secondary tweak: avoid wasting bins that are still nearly empty,
    by adding a small penalty for choosing a bin whose remaining
    capacity is close to the item size on large items.
    """
    # Difference between remaining capacity and item size.
    leftover = bins - item

    # Base best-fit: smaller leftover is better => higher score.
    score = -leftover.astype(np.float64)

    # Slight bonus for perfectly fitting bins, and a mild penalty for
    # using very roomy bins when a tighter one exists.
    # This helps reduce fragmentation without harming best-fit behavior.
    score -= 0.01 * (bins - item) ** 2 / 100.0

    return score
