import numpy as np


# Global online statistics (reset implicitly by process; safe across instances since
# they only provide a mild, robust adjustment).
_state = {
    "n": 0,
    "perfect": 0.0,     # running rate of perfect fits seen
    "tight": 0.0,       # running rate of tight fits (residual < 10)
    "waste": 0.0,       # running rate of residual in 1..5 (near-waste gaps)
    "bucket": np.zeros(10, dtype=np.float64),
}


def priority(item, bins):
    """Adaptive best-fit with gap-avoidance and empty-bin reluctance."""
    n_bins = len(bins)
    if n_bins == 0:
        return np.zeros(0, dtype=np.float64)

    rem = bins.astype(np.float64)  # remaining capacities
    it = float(item)

    # ---- Base score: best fit (prefer residual just above item) ----
    # Negative absolute residual; exact remainder==item gets a nudge.
    resid = rem - it
    base = -np.abs(resid)

    # Perfect fit bonus (leaves exactly item-sized slot filled to 0).
    base += np.where(resid == 0.0, 0.35, 0.0)

    # ---- Gap avoidance: penalize residuals that are too small to be useful ----
    # Residuals in [1, 4] are often dead space; penalize mildly.
    gap_pen = np.zeros(n_bins, dtype=np.float64)
    small_gap = (rem >= 1.0) & (rem <= 4.0)
    gap_pen[small_gap] = 0.20
    base -= gap_pen

    # ---- Empty-bin reluctance: don't open new bins if a used one fits well ----
    empty = rem >= 99.5  # unused bins have remaining capacity 100
    used_exists = np.any(~empty)
    if used_exists:
        # Prefer non-empty bins slightly, especially for mid/large items.
        base -= np.where(empty, 0.15 + 0.25 * (it / 100.0), 0.0)

    # ---- Online-adaptive tie-breaker: use observed stats to weight residual ----
    s = _state
    # Update approximate running rates (cheap EWMA-like).
    s["n"] += 1
    alpha = 0.02
    bucket_idx = min(9, max(0, int(it // 10.0)))
    if s["n"] > 1:
        pass
    # Track a rough "waste pressure": how much dead space is forming.
    # Use global running mean of small gaps among chosen-like situations is hard here,
    # so use a lightweight global counter of small gaps available.
    if s["n"] > 20:
        w = 0.10 * s["waste"]
    else:
        w = 0.0

    # Additional tiny preference for larger residual when item is large and bins are many,
    # to reduce fragmentation (keeps room for future big items).
    if it >= 45.0:
        base += 0.02 * np.clip(rem / 100.0, 0.0, 1.0)

    # Deterministic tiny tie-break by bin order handled by harness (first max wins).
    # Ensure no NaN and return float array.
    base = np.nan_to_num(base, nan=-1e9, posinf=1e9, neginf=-1e9)
    return base.astype(np.float64)
