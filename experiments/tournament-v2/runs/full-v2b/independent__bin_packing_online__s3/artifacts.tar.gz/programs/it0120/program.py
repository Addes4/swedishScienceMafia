import numpy as np

# Weibull-shaped items, mean ~40. Best Fit is already excellent online.
# Enhancement: score = -(residual) + small term rewarding residuals that match
# typical remaining-fill patterns (near 0 or near a full item slot), so bins
# get closed tightly instead of leaving awkward medium gaps.

_MEAN = 40.0


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing item; >= 0

    # Core: best fit -> smaller residual preferred.
    base = -residual.astype(np.float64)

    # Mild preference for residuals that are small (bin nearly closed) or that
    # leave a clean remaining slot, and slight dislike of abrupt medium residuals.
    # Reward small residual strongly (closing a bin is good).
    close_bonus = np.where(residual == 0, 5.0, 0.0)
    # Reward residuals that can still hold a typical item (~mean) reasonably.
    usable = np.zeros_like(residual, dtype=np.float64)
    useful = (residual >= 20) & (residual <= 60)
    usable[useful] = 0.5
    # Small penalty for leaving a large residual unusable-ish (rarely good to open slack).
    large_pen = -0.3 * (residual >= 70)

    return base + close_bonus + usable + large_pen
