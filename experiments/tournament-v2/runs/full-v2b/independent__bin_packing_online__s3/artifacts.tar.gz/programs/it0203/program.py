import numpy as np

# Approximate item size distribution: Weibull-shaped, mean about 40.
# We discretize sizes 1..100 and store an unnormalised weight for each size.
# A Weibull with shape ~1.5 and scale ~45 gives a mean near 40 and a
# decreasing-ish density with a peak at small/medium sizes; this is close
# enough for ranking decisions and is not tuned to any single instance.
_SIZE_PROB = None


def _build_size_prob():
    global _SIZE_PROB
    if _SIZE_PROB is not None:
        return _SIZE_PROB
    w = np.empty(101)
    w[0] = 0.0
    shape = 1.5
    scale = 45.0
    for s in range(1, 101):
        x = s / scale
        # Weibull density f(x) = (shape/scale) * x^(shape-1) * exp(-x^shape)
        # multiplied by a factor to keep values small; use log to avoid overflow.
        logf = (np.log(shape) - np.log(scale) + (shape - 1) * np.log(x + 1e-12) - x ** shape)
        w[s] = np.exp(logf)
    # Convert to cumulative distribution over integer sizes.
    w = np.maximum(w, 0.0)
    total = w.sum()
    if total <= 0:
        w = np.ones(101)
        w[0] = 0.0
        total = w.sum()
    probs = w / total
    _SIZE_PROB = probs
    return probs


def priority(item, bins):
    probs = _build_size_prob()
    # Probability that a future item has size <= remaining capacity.
    # For each bin, remaining r = bins[i] (capacity left after placing item).
    # We want to prefer bins where r is small (tight fit) but also where
    # the remaining gap is likely to be filled by a future item of exactly
    # the right size.  We approximate the expected number of future items
    # that fit in the gap as sum_{s<=r} probs[s] * (r/s) roughly, but
    # simpler: use tight-fit score plus a bonus proportional to
    # prob(a future item fits exactly in the gap).
    #
    # The main ranking should be tight fit: score_bf = -(bins - item)
    # A useful secondary objective: prefer gaps that are themselves
    # plausible item sizes (so they can be consumed later).
    rem = bins - item  # remaining capacity after placement (>=0)
    # Avoid division by zero; also compute exact-fit bonus.
    gap_prob = np.zeros_like(rem, dtype=np.float64)
    # Probability mass at each remaining capacity value.
    # rem values are integers 0..100-ish (could be up to 99).
    safe_rem = np.clip(rem, 0, 100)
    gap_prob = probs[safe_rem]

    # Tight-fit component: smaller rem is better.  Normalise to ~[-1, 0].
    tight = -(rem.astype(np.float64)) / 100.0

    # Exact-fit bonus: if the gap size is a likely item size, we may be
    # able to fill it exactly later.  Weight modestly so best-fit still
    # dominates but ties/close calls improve.
    bonus = 3.0 * gap_prob

    # Slight preference for leaving no gap at all (rem == 0) because that
    # exactly closes a bin (always good).
    closed = (rem == 0).astype(np.float64)

    return tight + bonus + 0.5 * closed
