import numpy as np

# Online bin packing heuristic tuned for Weibull-shaped sizes (mean ~40, capacity 100).
# Fixed order -> tie-break is handled by the harness (first index wins).
# We rank bins by a scalar score; higher is better.

def priority(item, bins):
    # bins: remaining capacities (int64), includes empty bins (capacity 100).
    # Return array of scores, same length.
    #
    # Strategy:
    #  - Best-fit dominates: prefer the bin where the item leaves the least slack.
    #  - For small items, add a slight preference for bins that are already partially
    #    filled (i.e. lower remaining capacity) so empty bins are preserved for large items.
    #  - For large items, add a slight preference for relatively emptier bins so the
    #    resulting slack after placement is more usable, and to avoid fragmenting filled bins.
    #
    # The score is a linear combination of:
    #   1) tightness: -(remaining - item)  [best fit]
    #   2) occupancy bias toward used bins, weighted by how small the item is
    #   3) a small preference for keeping a fully empty bin untouched on large items

    rem = bins.astype(np.int64, copy=False)

    # Slack after placing the item (>= 0 for all shown bins since harness filters).
    slack = rem - item

    # Base best-fit score (higher for smaller slack).
    score = -slack.astype(np.float64)

    # Occupancy of the bin before placing: fraction already used.
    occ = (100.0 - rem.astype(np.float64)) / 100.0

    # Item scale: 0 for tiny items, ~1 for full-size items.
    item_frac = item / 100.0

    # For small items, nudge toward bins that are already used (higher occ).
    # For large items, nudge toward bins that are emptier (lower occ), so the
    # leftover is a big-enough gap for future items.
    # Weight chosen heuristically; small relative to the best-fit term so it only
    # breaks near-ties without overriding good fits.
    small_item = max(0.0, 1.0 - 2.0 * item_frac)   # positive only for item <= 50
    large_item = max(0.0, 2.0 * item_frac - 1.0)   # positive only for item >= 50

    score += 6.0 * small_item * occ
    score -= 6.0 * large_item * occ

    return score
