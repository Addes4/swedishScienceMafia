"""Online bin packing heuristic: adaptive best-fit with residual-class shaping.

The arriving item is placed by maximizing a score over the bins it fits in.  The base
score is best-fit (tightest remaining capacity).  A small online-learned correction is
added based on the residual capacity of the bin: residual classes that have historically
combined well with arriving items are preferred over classes that tend to be wasted.
This keeps the worst-case behavior close to best-fit while often improving utilization.
"""

import numpy as np

_CAP = 100

# State: exponentially weighted statistics about item sizes, used to shape preferences
# for residual bin capacities.  We keep a small table over residual-capacity buckets.
_RES_BUCKETS = 10          # residual capacity classes
_ITEM_BUCKETS = 10         # item size classes
_alpha = 0.92             # EWMA decay

_hist_res = np.zeros(_RES_BUCKETS, dtype=np.float64)
_hist_item = np.zeros(_ITEM_BUCKETS, dtype=np.float64)
_counts = np.zeros(_RES_BUCKETS, dtype=np.float64)

# Compatibility weights: for each residual class r and item class i, estimate how often
# choosing r for an item of class i leads to a good packing outcome.  We only maintain a
# simple online estimate using complementary-fit scoring.
_compat = np.zeros((_RES_BUCKETS, _ITEM_BUCKETS), dtype=np.float64)
_compat_count = np.zeros((_RES_BUCKETS, _ITEM_BUCKETS), dtype=np.float64)


def _item_bucket(item):
    b = int(item * _ITEM_BUCKETS / _CAP)
    if b >= _ITEM_BUCKETS:
        b = _ITEM_BUCKETS - 1
    elif b < 0:
        b = 0
    return b


def _res_bucket(rem):
    # rem from item..100 ; bucket by residual capacity
    b = int(rem * _RES_BUCKETS / (_CAP + 1))
    if b >= _RES_BUCKETS:
        b = _RES_BUCKETS - 1
    elif b < 0:
        b = 0
    return b


def priority(item, bins):
    global _hist_res, _hist_item, _counts, _compat, _compat_count

    item = int(item)
    bins = np.asarray(bins)
    n = bins.shape[0]

    # Bucketize residuals for the candidate bins.
    rb = np.minimum((bins * _RES_BUCKETS) // (_CAP + 1), _RES_BUCKETS - 1).astype(np.int64)
    ib = _item_bucket(item)

    # Best-fit base: higher score for smaller residual (bins sorted ascending residual).
    base = -bins.astype(np.float64)

    # Online learned residual-class preference: prefer residuals that have had high
    # complementarity with items of this class, normalized by observation count.
    compat_col = _compat[:, ib]
    compat_cnt_col = _compat_count[:, ib]
    learned = compat_col / (compat_cnt_col + 8.0)

    # Also lightly favor residuals that closely match historically common item sizes:
    # if a residual is around a typical future item size, it may be reused soon.
    typical = _hist_item / (_hist_item.sum() + 1e-9)
    res_pref = _hist_res / (_counts + 8.0)

    score = base
    score = score + 4.0 * learned[rb]
    score = score + 1.2 * res_pref[rb]

    # A very small tie-breaker favoring earlier bins (stable behaviour).
    score = score - 1e-6 * np.arange(n, dtype=np.float64)

    # Update statistics after scoring (no future information used for this decision).
    # Approximate feedback: items that fit tightly into high-compatibility residuals
    # reinforce those choices.
    _hist_item[ib] = _alpha * _hist_item[ib] + (1.0 - _alpha)
    for r in range(_RES_BUCKETS):
        _hist_res[r] = _alpha * _hist_res[r] + (0.0 if _counts[r] <= 0 else 0.0)
    # Use the set of shown bins: residual classes present get a weak count.
    present = np.bincount(rb, minlength=_RES_BUCKETS).astype(np.float64)
    _counts = _alpha * _counts + present
    _hist_res = _alpha * _hist_res + present

    # Reinforce compatibility for residuals that are good complementary fits for this item.
    # A residual exactly equal to the item is ideal (would close the bin); residual 100 is
    # also favorable for small items because it leaves a fresh bin.  We blend this with
    # the observed present residuals.
    for r in range(_RES_BUCKETS):
        if present[r] > 0:
            mid = (r + 0.5) * (_CAP + 1) / _RES_BUCKETS
            # Quality of residual mid for this item: prefer tight fit.
            q = -abs(mid - item)
            _compat[r, ib] = _alpha * _compat[r, ib] + (1.0 - _alpha) * q
            _compat_count[r, ib] = _alpha * _compat_count[r, ib] + (1.0 - _alpha) * present[r]

    return score
