import numpy as np

class OnlineBinPacking:
    def __init__(self):
        self.freq = np.zeros(101, dtype=np.int64)
        self.total = 0
        self.gamma = 50.0

    def priority(self, item, bins):
        # Update frequency of the current item
        self.freq[item] += 1
        self.total += 1
        # Compute new remaining capacities
        new_remain = bins - item
        # Compute bonus: frequency of the new remaining capacity
        bonus = self.freq[new_remain] / self.total
        # Score: best fit (negative remaining) plus bonus
        score = -(new_remain) + self.gamma * bonus
        return score

# The problem expects a function named priority, not a class.
# We can use a global state via a closure or a list.
_state = {
    'freq': np.zeros(101, dtype=np.int64),
    'total': 0,
    'gamma': 50.0
}

def priority(item, bins):
    _state['freq'][item] += 1
    _state['total'] += 1
    new_remain = bins - item
    bonus = _state['freq'][new_remain] / _state['total']
    score = -(new_remain) + _state['gamma'] * bonus
    return score
