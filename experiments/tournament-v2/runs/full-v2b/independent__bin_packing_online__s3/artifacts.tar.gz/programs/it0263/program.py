import numpy as np

def priority(item, bins):
    # bins is a numpy int64 array of remaining capacities (only bins where item fits).
    # We want to rank bins: highest score wins.
    #
    # Strategy: hybrid of best-fit and "fill tight bins first" with a bonus for
    # bins that will become exactly full (or nearly full) after placing the item,
    # and a slight penalty for brand-new bins (cap 100) to avoid opening new bins
    # unless necessary.

    # Remaining capacity after placing item in each bin:
    rem = bins - item

    # Score: we want to minimize remaining capacity (best fit), but with
    # extra incentive for bins that will be completely filled (rem == 0)
    # and a gradual penalty for empty bins.

    # Base: negative remaining capacity so smaller rem -> higher score.
    score = -rem.astype(np.float64)

    # Strong bonus for perfectly filled bins (rem == 0): close them now.
    score += (rem == 0) * 50.0

    # Mild bonus for bins that become very full (rem small but > 0) to
    # encourage packing tight before opening new bins.
    score += np.where((rem > 0) & (rem <= 5), 5.0, 0.0)

    # Penalty for untouched/empty bins (bins == 100) to delay opening new bins.
    score -= (bins == 100) * 20.0

    # Small deterministic tie-breaker: earlier bins slightly preferred.
    # (already handled by argmax picking first, but we can add tiny epsilon)
    # Not needed; ties go to first bin by default.

    return score
