import numpy as np


def priority(item, bins):
    # Prefer bins whose remaining capacity is just enough for the item.
    # Slightly penalize completely unused bins so they remain available
    # for larger items that arrive later.
    score = -(bins - item).astype(np.float64)
    score[bins == 100] -= 0.5
    return score
