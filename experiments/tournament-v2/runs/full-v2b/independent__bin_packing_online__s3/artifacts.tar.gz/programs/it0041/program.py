import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin that leaves the least remaining capacity.
    # The primary score is -(bins - item). A tiny secondary term favors
    # lower-index bins slightly to keep packing deterministic and stable.
    remaining_after = bins - item
    # Primary term: tighter fit is better, so more negative -> worse; use negative.
    score = -remaining_after.astype(np.float64)
    # Small tie-breaker: prefer earlier bins (lower index).
    score -= np.arange(score.size, dtype=np.float64) * 1e-6
    return score
