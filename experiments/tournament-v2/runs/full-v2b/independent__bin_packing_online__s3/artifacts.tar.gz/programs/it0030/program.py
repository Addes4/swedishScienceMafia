"""Online bin packing: adaptive best-fit with anti-fragmentation tie-breaking."""
import numpy as np


# Running statistics of past items (module-level state)
_state = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running mean/std of item sizes
    _state["n"] += 1
    _state["sum"] += item
    _state["sumsq"] += item * item
    n = _state["n"]
    mean = _state["sum"] / n
    if n > 1:
        var = max(0.0, _state["sumsq"] / n - mean * mean)
        std = var ** 0.5
    else:
        std = 0.0

    b = bins.astype(np.float64)
    leftover = b - item  # remaining capacity after placing item

    # Base: tightly fitting bins get highest score (minimize leftover)
    score = -leftover

    # Strong bonus for exact fill (leave no wasted space)
    score += np.where(leftover == 0, 10.0, 0.0)

    # Anti-fragmentation: prefer bins that are already partially used
    # (remaining < 100), so fewer fresh bins get opened.
    used_bonus = np.where(b < 100.0, 0.6, 0.0)
    score += used_bonus

    # If remaining capacity after placement is very small relative to
    # expected future item size, that's still good (tight pack).
    # Otherwise, mildly prefer bins whose leftover is close to mean
    # (keeps bins in a usable size range).
    if std > 0:
        # preference for leftover being able to hold a typical item
        target = mean
        near = 1.0 - np.abs(leftover - target) / (std + 1e-9)
        score += 0.3 * near

    return score
