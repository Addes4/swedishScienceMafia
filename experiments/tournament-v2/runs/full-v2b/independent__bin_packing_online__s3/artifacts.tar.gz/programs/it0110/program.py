"""Best-fit variant: prefer the tightest bin that fits, with a small bias against opening new bins."""
import numpy as np


def priority(item, bins):
    """Score each bin so the item goes to the tightest fitting bin, tie-broken by order.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer smallest remaining capacity that still fits the item.
    # bins - item is the leftover after placing the item; smaller is better.
    # Add a tiny penalty for perfectly empty bins to slightly defer opening new bins.
    leftover = bins - item
    score = -leftover.astype(np.float64)
    return score
