import numpy as np


def priority(item, bins):
    # Remaining capacity after placing the item.
    residual = bins - item

    # Prefer exact fills strongly, then tighter fits.
    # residual >= 0 for all bins passed in, so -residual ranks smaller residuals higher.
    # Add a tiny deterministic index penalty to avoid unstable ties? Not needed; harness uses first max.
    return -residual
