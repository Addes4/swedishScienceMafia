# EVOLVE-BLOCK-START
"""Best-fit with a mild bias toward filling bins that are already relatively full."""
import numpy as np


def priority(item, bins):
    """Priority = -(bins - item) + alpha * (100 - bins).

    The first term is the standard best-fit score (negative leftover after placing).
    The second term mildly prefers bins with less remaining capacity, i.e. bins that
    are already well used, which tends to close bins earlier and save space for future
    large items.
    """
    alpha = 0.02
    # bins - item is the leftover after placing; we want small leftover -> negative.
    # (100 - bins) is amount already consumed in the bin (smaller remaining = larger).
    return -(bins - item) + alpha * (100.0 - bins.astype(np.float64))
# EVOLVE-BLOCK-END
