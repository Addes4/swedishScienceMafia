import numpy as np


def priority(item, bins):
    """Rank bins by a soft best-fit rule.

    The base score prefers bins where the item fits most tightly, which is the
    strongest known online rule for this setting.  A tiny adjustment rewards
    residual capacities that are historically useful for future small items,
    while still keeping the main ordering close to best fit.
    """
    residual = bins - item

    # Best-fit core: smaller residual after placement is better.
    score = -residual

    # Small structural bonus: full bins (remaining 100) are slightly disfavored
    # so that already-packaged bins are not broken apart when a tight fit exists.
    unused = (bins == 100)
    score = score - 1e-6 * unused

    # Preferred residual states are those just below common upcoming item sizes.
    # This is a gentle, distribution-agnostic tilt, not a hard fit heuristic.
    # Values 1..100; reward residuals that are small but nonzero.
    tight = residual.astype(np.float64)
    bonus = np.where(tight == 0, 0.0, 1.0 / (tight + 1.0))
    score = score + 0.01 * bonus

    return score
