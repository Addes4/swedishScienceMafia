import numpy as np


def priority(item, bins):
    """Best-fit with a slight bias toward filling bins exactly and avoiding new bins.

    The main signal is the remaining capacity after placing the item: smaller residual
    is better.  Exact fits are strongly preferred.  Unused bins (remaining 100) are
    slightly penalized so the item first tries to fit into an already opened bin.
    """
    residual = bins - item
    # Strongly prefer exact fits, then tight fits.  Use a nonlinear decreasing score.
    # A small penalty for using a completely empty bin discourages opening new bins.
    score = -residual.astype(np.float64)

    # Extra reward for exact fit.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Slight penalty for unused bins (remaining capacity 100) to encourage packing
    # into already used bins when possible.
    score -= np.where(bins == 100, 0.5, 0.0)

    return score
