import numpy as np


def priority(item, bins):
    """Score bins so the item goes to a bin using best-fit with useful tie-breaks.

    Highest score wins; ties go to the first bin. We minimize leftover capacity
    after insertion: residual = bins - item. Lower residual is better, so score
    is -residual. To avoid over-fragmenting, we slightly prefer bins that become
    nearly full over introducing brand-new bins when residuals are similar.
    """
    residual = bins - item  # remaining capacity if item placed here
    # Primary: best fit -> smallest residual.
    score = -residual.astype(np.float64)
    # Secondary: prefer bins that end up tightly packed (small residual) explicitly
    # with a smooth bonus; also lightly prefer already-nonempty bins to reduce
    # opening new bins when feasible.
    score += 0.001 / (residual + 1.0)
    # Slight preference against the perfectly empty bin (capacity 100) unless
    # it is the only/best option, to consolidate items.
    score -= 0.0005 * (bins == 100)
    return score
