"""Online bin packing: best-fit with a mild fullness preference.

Rule: for each bin, the item creates residual = bins - item. We rank bins by
residual ascending (best fit). To further encourage consolidation, we add a
small preference for bins that are already in use (not full-capacity 100) when
the resulting residuals are close. Concretely, we score by -residual plus a
tiny tie-break bonus proportional to (100 - residual) i.e. how full the bin
becomes, without overriding the primary best-fit ordering.

Because bins that exactly fit (residual 0) are strictly best, and we avoid
tossing items into fresh bins when existing ones fit well, the number of
opened bins stays small.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for all shown bins, but clip just in case
    residual = np.maximum(residual, 0)
    # Primary: prefer smallest residual (tightest fit).
    # Secondary: prefer bins that end up more full (smaller residual already),
    # but give a slight push to non-pristine bins to avoid opening new ones.
    used = (bins < 100)
    score = -residual.astype(np.float64)
    # Small bonus for already-used bins so ties/near-ties favor consolidation.
    score += used * 0.5
    # Slight extra bonus for exactly filling or nearly filling a bin.
    score += (residual == 0) * 0.25
    return score
