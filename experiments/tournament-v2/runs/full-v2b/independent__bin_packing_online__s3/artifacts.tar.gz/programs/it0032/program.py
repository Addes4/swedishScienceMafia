import numpy as np

_state = {"n": 0, "sum": 0.0, "reserve": 0.0}


def priority(item, bins):
    s = _state
    s["n"] += 1
    s["sum"] += item

    # Adaptive reserve: target a small leftover in the chosen bin, but if items
    # tend to be large, reduce the reserve so we don't force opening too many bins.
    mean_item = s["sum"] / s["n"]
    reserve = 0.0
    if mean_item < 35.0:
        reserve = 2.0
    elif mean_item < 45.0:
        reserve = 1.0

    # Best fit: minimize remaining capacity after placing the item.
    # If the resulting leftover is below the reserve, add a penalty so we prefer
    # bins that end up with either a very small leftover or a comfortably large one.
    leftover = bins - item

    # Score: higher is better. Base is negative leftover (tight fit preferred).
    score = -leftover.astype(np.float64)

    # Penalize bins that would leave a small-but-not-negligible gap.
    if reserve > 0.0:
        penalty = np.where((leftover > 0) & (leftover < reserve), reserve, 0.0)
        score -= penalty

    return score
