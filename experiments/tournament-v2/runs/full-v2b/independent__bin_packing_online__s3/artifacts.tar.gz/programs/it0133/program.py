"""Best fit with a tiny bias toward earlier (older) bins to reduce fragmentation.

The item goes to the bin where placing it leaves the smallest remaining
capacity.  Ties (equal resulting remaining capacity) are broken in favor of
the earlier bin via a tiny index-based bonus, which encourages filling bins
that were opened earlier rather than scattering items across many bins.
"""
import numpy as np


def priority(item, bins):
    # Primary criterion: minimize remaining capacity after placement.
    # Since highest score wins, negate remaining capacity.
    score = -(bins - item)

    # Tiny tie-breaking bonus for earlier bins (smaller index).
    # This is much smaller than 1, so it never overrides the best-fit choice.
    n = bins.shape[0]
    if n:
        idx = np.arange(n, dtype=np.float64)
        score = score.astype(np.float64) + (1.0 - idx / max(n, 1)) * 1e-6

    return score
