import numpy as np


def priority(item, bins):
    """Rank bins by best-fit closeness, with a slight preference for fuller bins.

    The item goes to the bin with the highest score (first on ties).
    Score = -(remaining - item) - epsilon * remaining
    This is best fit (minimize leftover after placing), with a small penalty
    for bins that still have a lot of space left, to encourage consolidation.
    """
    leftover = bins - item
    return -leftover - 1e-6 * bins
