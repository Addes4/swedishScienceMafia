import numpy as np

# Online bin packing learner: adaptive best-fit with empty-bin reservation.
# Keeps a light state across calls to estimate item-size distribution,
# preferring tight fits and preserving empty bins for larger items.

_state = {
    "count": 0,
    "large_frac": 0.0,
}

def priority(item, bins):
    n = bins.size
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Update rough online estimate of large-item frequency.
    _state["count"] += 1
    alpha = 0.02
    is_large = 1.0 if item >= 55 else 0.0
    _state["large_frac"] = (1.0 - alpha) * _state["large_frac"] + alpha * is_large

    rem = bins.astype(np.float64)
    # space left after placing item
    leftover = rem - float(item)

    scores = np.empty(n, dtype=np.float64)

    empty_mask = rem >= 100.0
    used_mask = ~empty_mask

    # Base: best fit -> maximize filled amount, i.e. minimize leftover.
    # Use a strong negative leftover so tighter bins rank higher.
    scores[:] = -leftover * 1000.0

    # Exact fit bonus: leftover == 0 is ideal.
    exact = leftover == 0.0
    scores[exact] += 1e6

    # Small leftover bonus: leftover <= 1 avoids wasting tiny gaps.
    small = (leftover > 0.0) & (leftover <= 1.0)
    scores[small] += 5e5

    # Penalize use of empty bins, but less so when item is large
    # (large items need fresh space) and more so when large items are rare.
    # Empty bins have rem == 100.
    if empty_mask.any():
        large_bias = _state["large_frac"]
        # For large items, empty bins are reasonable. For small items, avoid them.
        # Penalty magnitude grows for smaller items.
        penalty = 3e5 * (1.0 - large_bias) * max(0.0, (55.0 - item) / 55.0)
        scores[empty_mask] -= penalty

        # Slight preference among empty bins: keep earliest (tie goes to first)
        # by making later empty bins marginally worse when many are unused.
        # (only matters when several empty bins exist)
        if empty_mask.sum() > 1:
            idx = np.nonzero(empty_mask)[0]
            # give earliest empty bin a tiny edge
            scores[idx[1:]] -= 1e-3 * np.arange(1, len(idx))

    # Mild preference to keep few near-full bins from becoming completely full
    # unless exact fit: already handled by exact/small bonus.

    return scores
