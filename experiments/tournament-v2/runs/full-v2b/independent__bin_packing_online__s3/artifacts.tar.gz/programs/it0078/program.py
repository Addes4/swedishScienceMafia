import numpy as np


class BucketState:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.int32)
        self.total = 0

    def add(self, x):
        self.hist[x] += 1
        self.total += 1

    def has_exact_match(self, gap):
        return 0 <= gap <= 100 and self.hist[gap] > 0


_state = BucketState()


def priority(item, bins):
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    remaining = bins.astype(np.int64, copy=False)
    leftover = remaining - item

    best_fit = -leftover.astype(np.float64)

    scores[:] = best_fit

    full_penalty = np.where(remaining == 100, -0.25, 0.0)

    if _state.total > 0:
        exact_bonus = np.zeros(n, dtype=np.float64)
        for i in range(n):
            g = int(leftover[i])
            if _state.has_exact_match(g):
                exact_bonus[i] = 0.5 + 0.02 * _state.hist[g]
        scores += exact_bonus

    scores += full_penalty

    return scores


def _record(item):
    _state.add(int(item))
