import numpy as np

_STATE = {
    "n": 0,
    "sum": 0.0,
    "sum2": 0.0,
    "last": 0,
}


def priority(item, bins):
    global _STATE

    # ---- light online statistics of arriving item sizes ----
    n = _STATE["n"] + 1
    s = _STATE["sum"] + float(item)
    s2 = _STATE["sum2"] + float(item) * float(item)
    _STATE["n"] = n
    _STATE["sum"] = s
    _STATE["sum2"] = s2

    mean = s / n
    var = max(0.0, s2 / n - mean * mean)
    std = var ** 0.5

    b = bins.astype(np.float64)
    rem = b - float(item)  # leftover capacity in each bin after placing the item

    # Score: prefer tight fits (small leftover), but be careful with very small
    # items that should not prematurely close otherwise useful bins.
    #
    # Base best-fit score.
    score = -rem

    # Penalize "closing" bins with tiny leftovers.  This reduces fragmentation:
    # leaving a bin with only 1..few units is usually bad if a future small item
    # could have used it, while bin count is the real objective.
    close = np.maximum(0.0, 8.0 - rem)
    score -= 0.35 * close * close

    # If the item is small relative to the observed mean, slightly prefer bins
    # that already have a moderate leftover, preserving exact/tight bins for
    # larger items.  This is a soft avoidance of over-filling on small items.
    if item < mean - 0.5 * std:
        # push away from both extremes (very full and completely empty)
        score -= 0.015 * (b - 100.0) ** 2 / 100.0
        # mild preference for some existing utilization
        score += 0.05 * b
    else:
        # Larger items: strong best-fit behavior; they are hard to place.
        # Break ties toward bins that are not completely empty when possible.
        score -= 0.002 * (b - 100.0) ** 2 / 100.0

    # Slight deterministic jitter based on item size to break exact ties in a
    # stable but less degenerate way across different item sizes.  Tiny enough
    # not to dominate true capacity preferences.
    if n > 1:
        score += (((item * 1103515245 + n * 12345) % 1024) / 1024.0 - 0.5) * 1e-6

    return score
