"""Best fit with slight tie-breaking and stability for online bin packing."""
import numpy as np


def priority(item, bins):
    """Put the item in the bin it fits most tightly (best fit).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities; item is placed in the
          bin with the highest score, ties broken by lower bin index.
    """
    # Primary: minimize remaining capacity after placement.
    residual = bins - item

    # Score: higher is better, so use negative residual.
    # Secondary tie-break: avoid creating small unusable gaps slightly less,
    # implemented as a tiny preference for bins that become exactly full or
    # keep a larger residual after placement for flexibility.
    score = -residual.astype(np.float64)

    # Prefer exact fits strongly (this is already encoded by residual 0),
    # but add a tiny bonus to make exact fits robust against float noise.
    score += (residual == 0).astype(np.float64) * 1e-6

    # Slight preference for bins with larger post-placement residual among
    # near-ties: preserves future flexibility without changing main ranking.
    score += residual.astype(np.float64) * 1e-9

    return score
