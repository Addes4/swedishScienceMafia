import numpy as np

# Online bin packing via best-fit with a residual-target tie-breaker.
# The target residual is tuned to the known item distribution (Weibull-shaped, mean ~40),
# so that early placements do not fragment capacity excessively.

_TARGET_RESIDUAL = 18.0  # expected useful residual for the last opened bin


def priority(item, bins):
    """Rank bins for an arriving item: prefer the tightest fit, nudged by residual target."""
    rem = bins.astype(np.float64) - float(item)
    # Primary score: smaller remaining capacity is better (tightest fit).
    # Secondary: penalize deviation from a target residual to keep spare room usable.
    score = -rem - 0.002 * np.abs(rem - _TARGET_RESIDUAL)
    # Never return NaN; rem is always finite for the bins we are shown.
    return score
