import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.total = 0
        self.mean = 40.0
        self.seen_large = 0
        self.seen_small = 0


_state = _State()


def priority(item, bins):
    """Rank bins for online bin packing.

    Strategy: prefer tight fits (best-fit) but avoid wasting almost-empty bins
    on small items, reserving them for future larger items.
    """
    _state.calls += 1
    _state.total += item
    # Online mean estimate of item size.
    _state.mean = _state.total / _state.calls

    rem = bins.astype(np.float64)
    n = rem.shape[0]

    # How full the bin would be after placing the item.
    # 0 -> would be empty (rem==item), 100 -> would be full.
    new_rem = rem - item

    # Core best-fit signal: smaller resulting remaining capacity is better.
    score = -new_rem

    # discourage using completely empty bins for small items.
    # An unused bin has remaining 100.  Placing a small item there leaves a lot
    # of fragmented space that is often not reusable well.
    empty_mask = (rem >= 100.0)
    if empty_mask.any():
        # penalty grows for smaller items placed into empty bins
        penalty = (100.0 - item) * 0.5
        score = np.where(empty_mask, score - penalty, score)

    # Also mildly penalize bins that are almost full but would become nearly
    # perfect fits only for tiny items; this is already handled by -new_rem.

    # Encourage using bins whose resulting remaining capacity is close to the
    # typical item size, creating potential future perfect fits.
    m = _state.mean
    if m > 0:
        target = m * 0.5
        score -= 0.05 * np.abs(new_rem - target)

    return score
