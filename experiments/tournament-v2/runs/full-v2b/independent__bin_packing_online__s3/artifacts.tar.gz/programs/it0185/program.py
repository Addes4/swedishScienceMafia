# EVOLVE-BLOCK-START
"""Best-fit with empty-bin bias: pack items into the tightest-fitting bin."""
import numpy as np


def priority(item, bins):
    """Score each bin; highest score wins (first bin on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins (bin order).
    """
    # Primary: prefer the bin that ends with the least remaining capacity (best fit).
    # Secondary: slightly avoid opening a brand-new bin (remaining == 100) to
    # reduce fragmentation, since partially used bins should be topped off first.
    leftover = bins - item
    score = -leftover.astype(np.float64)
    score -= (bins == 100) * 0.5
    return score
# EVOLVE-BLOCK-END
