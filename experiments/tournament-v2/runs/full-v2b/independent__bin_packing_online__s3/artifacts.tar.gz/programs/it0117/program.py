"""Online bin packing with a hybrid best-fit / fresh-bin heuristic."""
import numpy as np


def priority(item, bins):
    """Rank bins: best fit primarily, with a small preference for fresh/empty bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    # Best fit: tighter fit = smaller remaining capacity after placing item.
    # Negative residual so highest score = smallest residual.
    residual = bins - item

    # Small bonus for completely empty bins (capacity 100) to encourage
    # opening a new bin instead of cramming into already-nearly-full ones.
    bonus = (bins == 100).astype(np.int64) * 3

    return -residual + bonus
