"""Best fit with a Refined-First-Fit-style class bonus to steer near-ties.

The item goes to the highest-scoring bin; ties go to the first bin. We score
primarily by best fit (smallest remaining capacity after placement), then add a
small class-based bonus so that, among near-ties, the item prefers a bin whose
current load lies in the "ideal" range for its size class (RFF boundaries).
"""

import numpy as np


def priority(item, bins):
    # bins: numpy int64 array of remaining capacities (only bins the item fits in)
    rem = bins.astype(np.float64)
    load = 100.0 - rem

    # Base score: best fit (prefer the bin with the smallest leftover).
    score = -rem

    # Mild class bonus that only breaks near-ties (rem differences <= 1).
    if item > 50.0:
        # Huge items: best fit is already optimal-ish; no extra steering.
        pass
    elif item > 100.0 / 3.0:
        score += ((load > 100.0 / 3.0) & (load <= 50.0)) * 1.0
    elif item > 25.0:
        score += ((load > 25.0) & (load <= 100.0 / 3.0)) * 1.0
    elif item > 20.0:
        score += ((load > 20.0) & (load <= 25.0)) * 1.0
    else:
        score += ((load > 0.0) & (load <= 20.0)) * 0.5

    return score
