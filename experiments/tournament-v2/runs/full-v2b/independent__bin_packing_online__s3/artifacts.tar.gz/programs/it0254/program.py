import numpy as np


def priority(item, bins):
    """Online bin choice: best-fit with a small residual-shaping bias.

    The item is placed in the bin that minimizes remaining capacity after
    placement, with a slight preference against leaving very small residuals.
    """
    nb = len(bins)
    if nb == 0:
        return np.empty(0, dtype=np.float64)

    residual = bins - item  # remaining capacity after putting item here

    # Base score: prefer smaller residual => tighter fit.
    scores = -residual.astype(np.float64)

    # Small secondary bias: discourage leaving tiny but non-zero leftovers
    # that are hard to reuse (e.g. 1..8), unless the bin becomes exactly full.
    # This preserves best-fit behavior for normal cases but slightly reshapes
    # the packing to reduce fragmentation.
    small = (residual > 0) & (residual <= 8)
    scores[small] -= 0.5

    # Slightly prefer exact fits (residual 0) over tiny imperfections.
    exact = residual == 0
    scores[exact] += 0.25

    # Deterministic tie-break toward earlier bins is handled by the harness
    # (ties go to first). Returning a plain list is acceptable.
    return scores
