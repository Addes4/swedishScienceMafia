import numpy as np


def priority(item, bins):
    """
    Best-fit with a small tie-break bonus.

    The item should go to the bin with the smallest remaining capacity after
    insertion, i.e. maximize leftover closeness to zero.  We use:
        tighter residual is better,
        slightly prefer already-used bins over opening a fresh bin,
        exact fit gets an extra tiny bonus.
    """
    residual = bins - item

    # Primary: smaller residual (tighter fit) -> higher score.
    score = -residual.astype(np.float64)

    # Small bonus for exact fit.
    score += (residual == 0) * 1e-3

    # Small bonus for using an already-open bin rather than a fresh 100-capacity bin.
    # A fresh bin has bins == 100; after insertion residual = 100 - item.
    fresh_residual = 100 - item
    score += (residual != fresh_residual) * 1e-4

    return score
