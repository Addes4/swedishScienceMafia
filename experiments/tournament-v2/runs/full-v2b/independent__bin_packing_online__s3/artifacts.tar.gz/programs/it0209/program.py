"""Online bin packing: scored best-fit with a mean-item reserve."""

import numpy as np


MEAN_ITEM = 40.0


def priority(item, bins):
    """Score bins: prefer a tight fit that still leaves room for an average item.

    Bins are remaining capacities (bins with capacity >= item).  Highest score wins.
    """
    # Remaining capacity after placing the item.
    leftover = bins - item

    # Prefer bins that still leave room for a typical future item (>= ~mean item).
    # Among those, prefer the tightest fit (smallest leftover).
    roomy = leftover >= MEAN_ITEM

    # Base score: negative leftover so smaller leftover (tighter fit) scores higher.
    score = -leftover.astype(np.float64)

    # Add a bonus for bins that remain "roomy" after placement, making them rank
    # above bins that would be almost full. This avoids filling medium bins to the
    # brim while large bins stay open, keeping option value for future items.
    score += roomy.astype(np.float64) * 1000.0

    return score
