"""Hybrid best-fit with residual penalty for small unfillable gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score.

    item: integer size 1..100
    bins: numpy int64 array of remaining capacities (item fits in all of them)
    """
    residual = bins - item  # leftover after placing item here

    # Best fit: tighter fit (smaller residual) is better.
    score = -residual.astype(np.float64)

    # Penalize leaving a small residual that is hard to fill later.
    # Common small items exist, so tiny gaps are somewhat okay, but very
    # awkward residuals (like 1..3) often can't be reused. Slightly prefer
    # residuals that are either exactly 0 or at least a moderate size.
    penalty = np.zeros_like(score)
    small = (residual > 0) & (residual < 6)
    penalty[small] = 3.0
    score -= penalty

    # Give exact fits a small extra bonus.
    score += (residual == 0) * 1.0

    return score
