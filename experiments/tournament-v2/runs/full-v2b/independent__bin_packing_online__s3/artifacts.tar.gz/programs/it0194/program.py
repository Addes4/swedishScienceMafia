import numpy as np


class BinPackState:
    def __init__(self):
        self.n = 0
        self.small_threshold = 25
        self.large_threshold = 70

    def update(self, item):
        self.n += 1


_state = BinPackState()


def priority(item, bins):
    """Hybrid best-fit / worst-fit rule for online bin packing.

    The item goes to the highest-scoring bin; ties go to the earliest bin.
    """
    _state.update(item)

    bins = np.asarray(bins, dtype=np.int64)

    # We score bins by a combination of:
    # 1. preference to leave a good residual capacity,
    # 2. avoidance of making very tiny unusable gaps,
    # 3. mild preference for filling bins that are already quite full.

    residual = bins - item

    # Base score: strongly prefer the best fit (smallest residual after placing).
    # Since the item must fit, residual >= 0.
    score = -residual.astype(np.float64)

    # For smaller items, pile them into reasonably full bins to create exact-ish fills.
    # A residual of 0 is ideal; very small residues like 1..5 are often hard to use.
    # Penalize these small residues so they are chosen only if unavoidable.
    gap_penalty = np.zeros_like(score, dtype=np.float64)
    small_res = (residual > 0) & (residual < 8)
    gap_penalty[small_res] = -6.0

    # For medium-sized items, favor bins with residual around 10..40, which leave
    # room for subsequent items while still consolidating.
    medium_res = (residual >= 8) & (residual <= 45)
    gap_penalty[medium_res] = 1.5

    # For larger residual (roomy bins), slightly penalize using them unless needed,
    # to preserve empty bins and medium-empty bins for future items.
    roomy = residual > 60
    gap_penalty[roomy] = -1.0

    # Prefer bins with lower current remaining capacity if they can take the item,
    # i.e. use fuller bins when the residual is acceptable. This is a soft best-fit.
    fullness_bonus = np.zeros_like(score, dtype=np.float64)
    if item <= _state.small_threshold:
        # Small items: strongly prefer fuller bins.
        fullness_bonus = (100 - bins).astype(np.float64) * 0.030
    elif item >= _state.large_threshold:
        # Large items: best-fit dominates, but still lightly favor fuller bins.
        fullness_bonus = (100 - bins).astype(np.float64) * 0.008
    else:
        # Medium items: moderate consolidation.
        fullness_bonus = (100 - bins).astype(np.float64) * 0.015

    score += gap_penalty + fullness_bonus

    # Ensure no NaN and deterministic behavior.
    score = np.nan_to_num(score, nan=-1e9, posinf=-1e9, neginf=-1e9)
    return score
