import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "last_sizes": [],
    "target_fill": 100.0,
}


def priority(item, bins):
    # Update simple online statistics about arriving items.
    _state["n"] += 1
    _state["sum"] += item
    _state["sumsq"] += item * item
    if len(_state["last_sizes"]) < 64:
        _state["last_sizes"].append(item)
    else:
        _state["last_sizes"][_state["n"] % 64] = item

    n = _state["n"]
    mean = _state["sum"] / n
    var = max(0.0, _state["sumsq"] / n - mean * mean)
    sd = var ** 0.5

    # Estimate a good target leftover: smaller items prefer tighter packing,
    # larger items need a bit more slack to avoid fragmentation.
    est_size = 0.7 * mean + 0.3 * item
    # Best-fit residual: prefer bin where remaining after placing item is smallest.
    residual = bins - item

    # Score: strongly prefer tight fits, but slightly prefer bins already filled.
    # The quadratic penalty on leftover discourages wasting large empty bins
    # on small items when tighter bins exist.
    score = -residual.astype(np.float64)

    # Mild bonus for partially used bins (remaining < 100) to consolidate.
    used_mask = bins < 100
    score += used_mask.astype(np.float64) * 0.15

    # If many bins are nearly full, allow small negative residual emphasis.
    # Scale by item size so big items don't get overly penalized.
    penalty = 0.002 * (100.0 - float(item))
    score -= penalty * (residual.astype(np.float64) ** 2) / 100.0

    # Avoid NaNs and guarantee finite values.
    score = np.nan_to_num(score, nan=-1e9, posinf=1e9, neginf=-1e9)
    return score
