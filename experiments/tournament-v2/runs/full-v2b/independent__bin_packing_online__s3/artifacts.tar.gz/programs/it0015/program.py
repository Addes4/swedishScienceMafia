"""Stateful best-fit with a mild anti-fragmentation tie-break.

The core idea is Best Fit (place the item in the bin with the smallest
remaining capacity that still fits).  Best Fit is a strong practical online
heuristic for items averaging around 40% of bin capacity.

We add a very small secondary term based on the *load already in the bin*
(i.e. capacity used), rewarding bins that are already relatively full so that
the algorithm finishes bins rather than spreading items thinly.  The bonus is
kept deliberately tiny so it only breaks situations where best-fit would
otherwise be indifferent or nearly so, and never overrides genuine best fit.
"""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties to first bin."""
    # Primary: best fit -> prefer the smallest remaining capacity that fits.
    # A bin with remaining capacity exactly `item` gets the largest score.
    # We use -remaining so that smaller remaining capacity => higher score.
    fit = -(bins - item)

    # Secondary: mild preference for bins that are already fuller.
    # used = 100 - remaining ; bigger used -> slightly higher score.
    used = 100 - bins

    # Combine.  The scaling factor is tiny (1e-3) so it only nudges near-ties.
    score = fit.astype(np.float64) + 1e-3 * used.astype(np.float64)

    return score
