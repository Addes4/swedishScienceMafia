"""Score the bin-choice rule: best fit, with a tie-breaking boost toward fuller bins
for small items so they backfill leftover space."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin with the smallest remaining capacity that still fits.
    residual = bins - item  # remaining capacity after placing the item

    # For smaller items, nudge toward already-fuller bins to backfill leftovers.
    # Larger items rely purely on best fit to avoid fragmenting capacity.
    if item <= 40:
        # bonus grows as the bin gets fuller (smaller residual)
        return -(residual * 16.0) + (100.0 - residual)
    elif item <= 70:
        return -(residual * 8.0)
    else:
        return -residual.astype(np.float64)
