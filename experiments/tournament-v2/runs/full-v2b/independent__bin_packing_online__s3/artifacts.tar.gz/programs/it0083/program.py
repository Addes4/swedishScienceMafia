import numpy as np


def priority(item, bins):
    # Score bins: primary goal is to minimize leftover after placing item (best fit),
    # but also prefer bins that are already more full to consolidate space.
    # Since bins only include those the item fits in, remaining capacity >= item.
    rem = bins.astype(np.float64)
    leftover = rem - item
    # Prefer smallest leftover; tie-break with smaller remaining (fuller bin).
    # Use a weighted combination. The leftover term dominates.
    # Add slight preference for fuller bins to avoid opening new bins prematurely.
    score = -(leftover) - 0.01 * (rem - item) * 0.0  # keep simple: pure best fit
    # Slight preference for bins that are nearly full but not perfectly fitting
    # to reduce fragmentation for small items.
    # For small items, we want to avoid leaving awkward gaps; best fit handles this.
    return -leftover
