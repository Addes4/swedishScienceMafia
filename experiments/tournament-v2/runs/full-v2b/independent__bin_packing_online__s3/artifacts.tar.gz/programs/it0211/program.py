"""Best-fit bin packing with a fixed anti-fragmentation bias."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, slightly preferring moderate leftover capacity.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    The item goes to the bin with the highest score; ties go to the first bin.
    """
    left = bins - item

    # Base: best fit, i.e. maximize negative leftover.
    score = -left.astype(np.float64)

    # Mild penalty for leftovers near 50, where fragmentation effects are worst,
    # and a small bonus for nearly full or completely empty bins.
    # This shape is symmetric-ish around 50 but keeps perfect fits strong.
    x = left.astype(np.float64) / 100.0
    # Parabola peaking at x = 0.5, scaled to be a gentle tie-breaker.
    penalty = 4.0 * x * (1.0 - x)
    score -= 3.0 * penalty

    # Give unused/empty bins a small extra push so they are preferred over
    # awkward medium-leftover bins when best fit is otherwise close.
    score += 0.02 * (bins == 100.0)

    return score
