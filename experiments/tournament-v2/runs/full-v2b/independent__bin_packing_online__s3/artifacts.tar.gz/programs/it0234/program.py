import numpy as np


def priority(item, bins):
    """Score bins so the item goes to the tightest fit, with a full-bin bonus.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
          Unused bins have remaining capacity 100.
    """
    # Residual capacity after placing the item in each candidate bin.
    residual = bins - item

    # Lower residual is better: negative residual so highest score wins.
    scores = -residual.astype(np.float64)

    # Strong bonus for exactly filling a bin, to preserve larger free spaces.
    scores += (residual == 0) * 50.0

    # Very small penalty for using completely empty bins, encouraging consolidation.
    scores -= (bins == 100) * 0.25

    return scores
