import numpy as np


def priority(item, bins):
    """Online bin choice: strong best-fit with bonus for filling bins exactly.

    Item goes to the highest-scoring bin (first on ties).
    We prefer the bin whose remaining capacity after placing the item is smallest
    (classic best fit).  We add a large bonus when the resulting slack is zero,
    which tends to produce fuller bins and thus fewer bins overall.
    """
    slack = bins - item  # remaining capacity after placing item in each bin
    # Higher score = better.  Primary: smaller slack.  Secondary: exact fit bonus.
    score = -slack.astype(np.float64)
    # Extra reward for exactly filling a bin (slack == 0).
    score += np.where(slack == 0, 1000.0, 0.0)
    return score
