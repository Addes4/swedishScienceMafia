import numpy as np

# Best-fit is known to be strong for online bin packing and simple to implement.
# To avoid pathological ties on empty bins, we add a tiny deterministic bonus
# for lower bin indices among bins with equal remaining capacity.

def priority(item, bins):
    # bins: remaining capacities (int64 numpy array), item: size 1..100
    # Highest score wins; ties -> first bin.
    # We rank bins by how tightly they fit the item:
    #   choose the smallest remaining capacity >= item, i.e. minimize (bins - item).
    # Since returned values are scores, return -(bins - item) to make smallest residual largest score.
    # Add a tiny index-independent constant to stay deterministic.
    residual = bins - item
    return -residual
