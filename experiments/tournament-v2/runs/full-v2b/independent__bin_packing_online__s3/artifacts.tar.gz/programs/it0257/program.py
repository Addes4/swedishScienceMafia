"""Adaptive best-fit bin-choice rule for online bin packing.

Approach: score bins by best fit (smallest remaining capacity that fits), but
add a bias that makes nearly-full bins less attractive when the item is large
relative to what remains, encouraging better packing balance.
"""
import numpy as np


# running statistics (state kept between calls)
_state = {
    "n": 0,
    "sum": 0.0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item

    # Mean item size estimate (starts near the known distribution mean ~40).
    if _state["n"] > 0:
        mean_item = _state["sum"] / _state["n"]
    else:
        mean_item = 40.0

    b = bins.astype(np.float64)

    # Best-fit: prefer smallest remaining capacity that still fits.
    # -(b - item) = item - b, so smaller b => higher score. Use negative leftover.
    fit_score = -(b - item)

    # Penalize nearly-full bins for larger items: if remaining capacity is small
    # relative to a typical item, avoid wasting a snug bin unless the fit is exact.
    # Scale penalty by how "big" this item is compared to the typical item.
    item_rel = item / max(mean_item, 1.0)

    # leftover fraction of remaining capacity
    leftover = b - item

    # A bin with tiny leftover is risky when item is large-ish; add mild penalty.
    # Also gently favor fuller bins overall to reduce bin count (best-fit does this).
    penalty = item_rel * (leftover / 100.0)

    return fit_score - 0.5 * penalty
