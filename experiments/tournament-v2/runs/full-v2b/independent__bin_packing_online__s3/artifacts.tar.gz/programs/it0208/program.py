import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`.

    Highest score = bin whose remaining capacity after placing the item is smallest.
    """
    return -(bins - item)
