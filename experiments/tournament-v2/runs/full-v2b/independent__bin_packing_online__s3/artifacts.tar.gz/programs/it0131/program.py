"""Best fit with a slight preference for already-used bins, plus a tiny residual term."""
import numpy as np


def priority(item, bins):
    """Score each bin: primary best fit, with a small bonus for tighter packing.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities (in bin order).
    """
    residual = bins - item
    # Best fit: smallest residual first. Ties are broken toward lower bin index,
    # but we perturb slightly to favor fully packed bins and reduce waste.
    score = -residual.astype(np.float64)
    # Very small bonus for bins that would be almost exactly filled (residual 0 or close)
    score += 1e-3 * (residual == 0)
    # Also slight preference against leaving a bin exactly empty if not needed,
    # to keep active bins together (helps future fitting).
    score -= 1e-4 * (bins == 100)
    return score
