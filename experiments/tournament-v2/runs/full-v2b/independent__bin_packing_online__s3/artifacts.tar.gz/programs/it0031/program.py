"""Best-fit with a small fill-level preference."""
import numpy as np


def priority(item, bins):
    """Score bins: prefer tight fits, but slightly prefer bins already partly filled."""
    # Best-fit score is simply the smallest remaining capacity that still fits.
    # We can express that as a negative distance from the item size.
    scores = -(bins.astype(np.float64) - item)

    # A tiny nudge toward bins whose remaining capacity is near typical item size.
    # This helps keep bins on roughly the same fill level and reduces fragmentation.
    # Avoid changing the main best-fit ordering.
    scores += 1e-4 * np.minimum(bins, 100 - bins)

    return scores
