import numpy as np


# Online statistics to adapt the rule a little without seeing the future.
_calls = 0
_sum = 0.0
_sumsq = 0.0
_small_count = 0
_large_count = 0


def priority(item, bins):
    """Score bins with a best-fit-like rule plus mild fragmentation control."""
    global _calls, _sum, _sumsq, _small_count, _large_count

    # Update lightweight online statistics.
    _calls += 1
    _sum += item
    _sumsq += item * item
    if item <= 30:
        _small_count += 1
    elif item >= 70:
        _large_count += 1

    # Remaining capacity after placing the item. Lower is generally better.
    remaining = bins - item

    # Perfect fit is very valuable.
    # Otherwise prefer tighter fits, but slightly smooth the scoring to avoid
    # always creating tiny unusable leftovers when many small items are around.
    # The coefficient grows a bit for larger items, which benefit more from exact packing.
    # This is still purely a function of the item and the visible bins.
    if _calls <= 50:
        # Early phase: pure best fit tends to be strong and establishes good bins.
        score = -remaining.astype(np.float64)
    else:
        avg = _sum / _calls
        # Mild adaptive tightness: emphasize exact fit more for large items.
        tightness = 1.0 + 0.35 * (item / 100.0)
        score = -remaining.astype(np.float64) * tightness

        # Strongly reward perfect fits and near-perfect fits.
        score += (remaining == 0) * 1000.0
        score += (remaining == 1) * 30.0
        score += (remaining == 2) * 12.0
        score += (remaining == 3) * 6.0

        # If there are many small items, slightly discourage producing very
        # small residual capacities that may be hard to use, except exact fits.
        if item <= 30 and _small_count > 0.55 * _calls:
            score -= (remaining > 0) * (remaining <= 5) * 2.0

        # If there are many large items, strongly prefer leaving not-too-small
        # spaces for them, so avoid overcrowding bins unless exact fit.
        if item >= 70:
            score += (remaining >= 20) * 1.5

        # Slight global preference for filling bins: lower remaining is better,
        # already encoded, but this helps break ties toward fuller bins.
        score -= 0.01 * remaining.astype(np.float64)

    return score
