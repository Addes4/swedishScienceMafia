import numpy as np

# State kept between calls
_state = {
    "n": 0,
    "sum": 0,
    "sumsq": 0,
}


def priority(item, bins):
    """Score bins for online bin packing: prefer tight fit with a mild fullness bias."""
    n = _state["n"]
    s = _state["sum"]
    sq = _state["sumsq"]

    # Update simple statistics of past items
    _state["n"] = n + 1
    _state["sum"] = s + item
    _state["sumsq"] = sq + item * item

    # Mean and variance estimate
    if n > 0:
        mean = s / n
        var = max(0.0, sq / n - mean * mean)
    else:
        mean = 40.0
        var = 400.0

    # Best fit residual: smaller remaining capacity after placing is better.
    residual = bins - item

    # Mild preference for already fuller bins (lower remaining capacity before placement),
    # controlled by a small constant. This often improves packing by leaving room for large items.
    fullness = 100.0 - bins  # higher for bins that already contain more

    # Adaptive weight: when item variance is high, tight fit matters more;
    # when variance is low, balancing helps avoid many half-full bins.
    w = 0.02 + 0.0005 * min(1.0, var / 400.0)

    # Score: higher is better. Best fit is primary, fullness bonus is secondary.
    score = -residual.astype(np.float64) + w * fullness.astype(np.float64)

    return score
