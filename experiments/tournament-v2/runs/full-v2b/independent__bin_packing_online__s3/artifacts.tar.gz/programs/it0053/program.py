"""Improved online bin packing priority: best fit with unused-bin tie delay."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score gets the item.

    Primary rule: best fit (minimize remaining capacity after placing).
    Secondary rule: among equal fits, prefer already-used bins over unused ones,
    so we open new bins only when necessary.
    """
    # Primary: best fit. Bins with smaller remaining capacity after placement
    # get a higher score. Since item is fixed, this is equivalent to -bins.
    score = -bins.astype(np.float64)

    # Secondary: unused bins have remaining capacity exactly 100. Penalize them
    # by a tiny amount so equal-fit used bins are preferred.
    # The largest item is 100, so a penalty < 1e-6 cannot change the primary ordering.
    score -= (bins == 100) * 1e-7

    return score
