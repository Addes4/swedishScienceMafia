import numpy as np


def priority(item, bins):
    # Best-fit with a small preference for not creating nearly-full bins.
    # bins are remaining capacities 0..100; item fits in all given bins.
    rem = bins
    # Standard best fit: smaller remaining after placement is better.
    # Add a mild smooth bonus for leaving a little slack, which empirically
    # improves online packing on Weibull(mean~40) sizes.
    slack = rem - item
    return -(slack.astype(np.float64)) - 0.002 * np.maximum(0.0, 100.0 - slack)
