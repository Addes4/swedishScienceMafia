import numpy as np


def priority(item, bins):
    """Best Fit: prefer the bin with the smallest remaining capacity that fits."""
    # bins are remaining capacities of bins that can fit the item.
    # Choose the smallest remaining capacity >= item, i.e. maximize -(remaining - item).
    return -(bins - item)
