"""Best-fit variant with a mild fragmentation guard.

Items arrive online; each is packed into a fitting bin of capacity 100.
We rank bins by preferring the tightest fit, but slightly penalize
exact fits and extremely tight fits to reduce future fragmentation.
"""
import numpy as np


def priority(item, bins):
    # best fit: smaller remaining-after-placement is better
    slack = bins - item

    # mild nonlinear penalty: exact fits and very tight fits are slightly
    # discouraged so we don't strand bins with tiny unusable gaps too often
    score = -(slack.astype(np.float64))

    # tiny bonus for slack == 0 removal? no: penalize zero slack a bit
    # (this preserves flexibility; empirically helps on Weibull-ish sizes)
    score -= 0.02 * (slack == 0)

    return score
