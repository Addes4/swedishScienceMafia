import numpy as np


def priority(item, bins):
    """Best-fit: rank bins by remaining capacity after placing `item`.

    Highest score -> smallest leftover capacity. Ties are broken by preferring
    older bins (lower index), which is achieved because ties go to the first bin.
    To encourage exact fills, we subtract a tiny bonus for bins where the item
    fits exactly.
    """
    remaining = bins - item

    # Base score: smaller remaining capacity is better.
    # Use a large negative so that after scaling, the smallest residual wins.
    score = -remaining.astype(np.float64)

    # Tiny bonus for exact fits to prefer filling a bin perfectly.
    # This is small enough not to change the ordering of different residuals,
    # but it can break ties between equal residuals only in favor of exact fits,
    # which is already the smallest residual, so it is harmless.
    exact = (remaining == 0)
    score[exact] += 1e-6

    return score
