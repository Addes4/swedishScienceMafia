import numpy as np

# Global state for adaptive leftover usefulness estimation
_size_counts = np.zeros(101, dtype=np.int64)
_total_items = 0

def priority(item, bins):
    global _total_items, _size_counts
    
    # Update statistics with the arriving item (allowed: we see current item)
    _size_counts[item] += 1
    _total_items += 1
    
    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)
    
    # Estimate probability that a leftover capacity r can accommodate some future item
    # Use empirical distribution so far; early on assume uniform-ish over 1..100
    if _total_items < 50:
        # Best fit with mild gap avoidance
        for i in range(n):
            rem = bins[i] - item
            # Prefer tighter fits (larger bins[i] closer to item => smaller rem)
            s = -float(rem)
            # Slight bonus if leftover can hold typical items (size ~40): 
            # leftover >= 40 is more likely to be reusable
            if rem >= 40:
                s += 0.5
            scores[i] = s
        return scores

    # Build cumulative probability that a random future item fits in leftover r
    # P(fit) ~ sum_{s=1..r} count[s] / total
    cum = np.cumsum(_size_counts) / float(_total_items)  # cum[r] = P(size <= r)
    
    for i in range(n):
        rem = int(bins[i] - item)
        if rem < 0:
            scores[i] = -1e18
            continue
        if rem == 0:
            # Perfect fit, strongly preferred
            scores[i] = 1e9
            continue
        reuse = cum[rem] if rem <= 100 else 1.0
        # Best-fit: prefer smaller rem. Also account for reusability of leftover.
        # Score: tight fit bonus + expected future value of the leftover
        # Normalize: small rem is good, but leave room usable
        s = -float(rem) + 30.0 * reuse
        scores[i] = s
    
    return scores
