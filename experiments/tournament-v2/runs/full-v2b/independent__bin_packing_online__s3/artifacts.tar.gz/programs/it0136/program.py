import numpy as np


def priority(item, bins):
    """Best-fit with a mild preference for profitable leftover capacities.

    The item goes into the bin with the highest score (first on ties).
    We primarily minimize the resulting leftover (best fit), but add a
    small bonus when the leftover equals a size that is common enough to
    be worth preserving for later small items.
    """
    remaining = bins - item

    # Base: strongly prefer small resulting leftover (classic best fit).
    score = -remaining.astype(np.float64)

    # Mild bonus for leftovers that are useful small/medium item sizes.
    # These values are representative of the lower part of the item
    # distribution and help avoid wasting bins that fit future small items.
    for cap in (1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20):
        score += 0.02 * (remaining == cap)

    return score
