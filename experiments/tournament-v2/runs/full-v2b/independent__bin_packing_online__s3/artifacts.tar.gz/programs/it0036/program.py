import numpy as np


def priority(item, bins):
    """Best fit, but strongly prefer not opening a new bin unless it is clearly needed.

    The harness gives all fitting bins, including empty bins with remaining capacity 100.
    A standard best-fit score is -(bins - item), i.e. smaller residual capacity is better.
    To reduce unnecessary bin openings, empty bins are slightly penalized relative to
    any used bin that fits the item. Since integer capacities are in 1..100 and item >= 1,
    adding a fractional penalty keeps all comparisons well-defined.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    score += (bins == 100) * 0.25
    return score
