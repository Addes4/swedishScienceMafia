import numpy as np

def priority(item, bins):
    # bins: remaining capacities, all >= item
    # We prefer bins where the remaining capacity after placing is smallest.
    # To avoid fragmented small residuals when several bins end up similar,
    # we add a slight preference for bins whose residual after placement is
    # not extremely small relative to alternatives, but still favor tight fits.

    residual = bins - item

    # Primary: best fit (smaller residual better)
    score = -residual.astype(np.float64)

    # Secondary: slight penalty for creating a very tiny residual (<= 5)
    # when there are other bins with moderate residual available.
    # This helps avoid many bins with tiny wasted space.
    tiny = (residual <= 5).astype(np.float64)
    score -= 0.02 * tiny * residual

    # Tertiary: prefer bins that will leave residual close to item size,
    # which often keeps capacities usable for future items.
    score -= 0.0001 * np.abs(residual - item)

    return score
