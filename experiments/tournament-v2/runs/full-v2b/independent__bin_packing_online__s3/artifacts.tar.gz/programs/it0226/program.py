import numpy as np


def priority(item, bins):
    """Score bins by best fit, with a slight penalty for unusable leftovers."""
    remaining_after = bins - item
    # Best fit: smaller remaining_after is better.
    # Penalize leftovers in (0, item) that are "wasteful" by adding a small term.
    # Since min item size is 1, leftover 0 is ideal, leftover >= item is good too.
    # We reward bins that become exactly full, then bins with larger leftover.
    waste = np.where((remaining_after > 0) & (remaining_after < item), remaining_after, 0)
    # Primary: minimize remaining_after. Secondary: minimize waste.
    return -(remaining_after.astype(np.float64) + 0.001 * waste)
