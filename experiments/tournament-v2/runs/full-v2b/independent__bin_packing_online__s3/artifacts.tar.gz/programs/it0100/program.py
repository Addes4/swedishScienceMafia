"""Online bin packing with a best-fit-plus-residual-quality heuristic.

The item-size distribution is Weibull-shaped with mean ~40 (integers 1..100).
Plain best fit tends to create tiny unusable gaps. We score each candidate bin
by how tightly the item fits, plus a mild penalty for leaving a residual that
is too small to be filled later and a small bonus for residuals near the
distribution's typical emerging sizes.
"""

import numpy as np

# ---- running statistics (kept across calls) -------------------------------
_count = 0
_mean = 40.0
# Histogram of observed item sizes (1..100) to estimate the distribution.
_hist = np.zeros(101, dtype=np.float64)

# Candidate "typical" residual sizes that are worth leaving room for.
# Small residuals (< 4) are effectively wasted; we penalize them.
_MIN_USEFUL = 4


def _score_bin(item, cap):
    """Score one bin with remaining capacity `cap` (item fits, so cap >= item)."""
    residual = cap - item

    # Best-fit term: strongly prefer tight fits (small residual).
    s = -float(residual)

    # Penalize nearly-wasted tiny residuals.
    if residual < _MIN_USEFUL:
        s -= 1.5 * (_MIN_USEFUL - residual)

    # Mild bonus for residuals close to the running mean item size,
    # since such gaps are likely to be refilled soon.
    s -= 0.02 * abs(residual - _mean)

    return s


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest
    score (first bin wins ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of bins the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _mean

    # Update running statistics from this arriving item (no future info used).
    if 1 <= item <= 100:
        _hist[item] += 1.0
    _count += 1
    # Exponentially-weighted running mean, robust and cheap.
    _mean += (float(item) - _mean) / min(_count, 200.0)

    res = np.asarray(bins, dtype=np.float64) - float(item)
    scores = -res

    # Penalize tiny residuals (wasted space).
    tiny = res < _MIN_USEFUL
    if tiny.any():
        scores[tiny] -= 1.5 * (_MIN_USEFUL - res[tiny])

    # Mild preference for residuals near the running mean item size.
    scores -= 0.02 * np.abs(res - _mean)

    return scores
