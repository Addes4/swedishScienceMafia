import numpy as np

# EVOLVE-BLOCK-START

def priority(item, bins):
    """
    Online bin choice rule.

    Strategy:
    - Prefer best-fit: put item into the bin where leftover after placement is smallest.
    - Slight tie-breaking toward bins that become nearly full.
    - De-prioritize completely empty bins (capacity 100) unless necessary,
      to encourage packing into already-open bins first.
    """
    bins = np.asarray(bins, dtype=np.int64)

    # Leftover if the item is placed in each bin.
    leftover = bins - item

    # Base score: prefer smaller leftover.
    score = -leftover.astype(np.float64)

    # Slightly prefer bins that end up closer to full (leftover near 0).
    # This makes exact-fit / nearly-full bins more attractive without
    # overriding the primary best-fit ordering too strongly.
    score += 0.001 * (100.0 - leftover.astype(np.float64)) / 100.0

    # Penalize completely empty bins a bit so we open new bins only when
    # no partially used bin is reasonably good.
    score -= 0.01 * (bins == 100).astype(np.float64)

    return score

# EVOLVE-BLOCK-END
