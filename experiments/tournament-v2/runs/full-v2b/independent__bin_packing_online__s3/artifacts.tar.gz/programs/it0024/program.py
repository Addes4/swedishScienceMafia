import numpy as np


def priority(item, bins):
    """Rank bins for online bin packing.

    Main idea:
    - Strongly prefer bins that fit the item tightly (best fit).
    - Among similarly tight fits, prefer bins whose resulting leftover is less likely
      to create unusable small gaps.
    - Unused bins (capacity 100) are allowed, but only when they are competitive.
    """
    # Highest score = chosen bin.
    # (bins - item) is the leftover after placing the item.
    # Smaller leftover is better, so use negative leftover.
    leftover = bins - item

    # Basic best-fit term. The coefficient dominates.
    score = -leftover * 1000.0

    # Slight preference for filling partially used bins before opening brand-new ones.
    # This tends to reduce bin count without harming tight-fit behavior too much.
    used_mask = bins < 100
    score += used_mask * 5.0

    # Penalize very small leftovers, because tiny residual capacities are often wasted.
    # This mild penalty encourages packing that leaves more useful space.
    # The factor is small enough not to override the primary best-fit choice.
    small_penalty = np.where((leftover >= 0) & (leftover <= 8), (9 - leftover) * 0.25, 0.0)
    score -= small_penalty

    return score
