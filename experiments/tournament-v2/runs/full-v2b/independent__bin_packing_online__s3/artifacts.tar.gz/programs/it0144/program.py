"""Best-fit-like online bin packing priority rule."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score is chosen.

    Primary rule: smallest remaining capacity after placing the item (best fit).
    Secondary rule: prefer lower remaining capacity now (fuller bins), which gives
    a deterministic and useful tie-break among bins with equal post-placement slack.
    """
    return -(bins - item) * 1000 - bins
