import numpy as np


class Packer:
    def __init__(self):
        self.count = 0
        self.sum_size = 0.0
        self.last_sizes = []
        self.max_last = 50

    def priority(self, item, bins):
        # Track statistics (though not strictly needed for best-fit)
        self.count += 1
        self.sum_size += item
        if len(self.last_sizes) < self.max_last:
            self.last_sizes.append(item)
        else:
            self.last_sizes[self.count % self.max_last] = item

        residuals = bins - item  # remaining capacity after placing item

        # Base: best fit -> smallest residual (most tightly packed)
        score = -residuals.astype(np.float64)

        # Slight penalty for using a completely empty bin (bins == 100)
        # unless the item itself is large (>= 60) or no used bin can take it.
        empty_mask = (bins == 100)
        if empty_mask.any():
            # If the item is small, prefer existing partially filled bins
            if item < 60:
                score[empty_mask] -= 5.0
            else:
                score[empty_mask] += 0.5

        # Slight bonus for perfect fit (residual == 0)
        perfect = (residuals == 0)
        if perfect.any():
            score[perfect] += 10.0

        # Slight bonus for bins that become nearly full (residual <= 5)
        near_full = (residuals > 0) & (residuals <= 5)
        if near_full.any():
            score[near_full] += 2.0

        return score


_packer = Packer()


def priority(item, bins):
    return _packer.priority(item, bins)
