# EVOLVE-BLOCK-START
"""Adaptive best-fit with learned residual penalties for online bin packing."""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.mean = 40.0
        self.m2 = 0.0
        # Histogram of recent item sizes, coarse-grained for speed.
        self.hist = np.zeros(101, dtype=np.float64)
        self.hist_total = 0.0
        self.item_window = 400
        self.seen = []

    def update(self, item):
        # Welford online mean/variance
        self.count += 1
        delta = item - self.mean
        self.mean += delta / self.count
        self.m2 += delta * (item - self.mean)

        # Sliding histogram approximation using a small list.
        self.seen.append(item)
        self.hist[item] += 1.0
        self.hist_total += 1.0
        if len(self.seen) > self.item_window:
            old = self.seen.pop(0)
            self.hist[old] -= 1.0
            self.hist_total -= 1.0

    def useful_size_prob(self, s):
        """Approximate probability that a future item has size <= s."""
        if s <= 0:
            return 0.0
        if s >= 100:
            return 1.0
        if self.hist_total <= 1e-9:
            return min(1.0, s / 100.0)
        # Cumulative mass up to s
        c = float(np.sum(self.hist[: s + 1])) / self.hist_total
        return c


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _state
    _state.update(item)

    bins = np.asarray(bins)
    n = bins.size
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Tighter fits should generally be preferred.
    residual = bins - int(item)

    # Baseline best-fit score: more negative residual => larger score.
    scores = -residual.astype(np.float64)

    # Estimate typical item size from recent history.
    if _state.count > 5:
        mean_item = max(1.0, _state.mean)
    else:
        mean_item = 40.0

    # Penalize residuals that are too small to be likely refilled but still waste capacity,
    # and mildly reward residuals that are large enough to accept another typical item.
    # This is a soft version of "leave room if possible, otherwise pack tight".
    use_thresh = mean_item * 0.6
    fill_thresh = mean_item * 0.9

    for i in range(n):
        r = residual[i]
        if r == 0:
            # Perfect fit: strong bonus.
            scores[i] += 6.0
        elif r <= use_thresh:
            # Small leftover: less attractive unless it is nearly perfect.
            # Penalize increasingly as residual grows toward use_thresh.
            scores[i] -= 1.0 + (r / max(1.0, use_thresh)) * 1.0
        elif r >= fill_thresh:
            # Good room for another item.
            scores[i] += 0.35 * (r / 100.0)
        else:
            # Middle zone: slight penalty, but keep best-fit ordering.
            scores[i] -= 0.15

    # Prefer older bins (lower index) very slightly to avoid spreading items too much,
    # while not overriding fit quality.
    if n > 1:
        scores -= np.arange(n, dtype=np.float64) * 1e-6

    return scores
# EVOLVE-BLOCK-END
