import numpy as np


def priority(item, bins):
    """Best fit: place the item in the fullest bin it still fits in."""
    return -bins
