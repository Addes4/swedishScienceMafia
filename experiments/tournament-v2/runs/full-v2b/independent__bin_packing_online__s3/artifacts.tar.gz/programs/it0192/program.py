import numpy as np

# ---------- basic distribution knowledge ----------
# Items are Weibull-shaped, mean ~40, integer 1..100.  Empirically a shape around 1.4
# and scale around 44 gives a good match to such a mean.  The exact distribution is
# unknown, so the correction below is kept deliberately mild and robust.
#
# The main rule is best fit: choose the bin with the smallest remaining capacity
# after insertion, i.e. smallest (rem - item), equivalently largest rem (but rem < item
# is impossible because bins only contains bins the item fits in).
#
# Ties and near-ties are common in the very early part of an instance when many bins
# have rem == 100.  Best fit alone would then depend on bin index order.  We add a
# tiny deterministic tie-breaker that slightly prefers lower-indexed bins, which is
# harmless and avoids accidentally spreading over all empty bins.

# Precompute a small table for a likely Weibull CDF at integer sizes.  We are not
# required to use it, but it helps break ties in a way that accounts for the item
# distribution.  Use shape k=1.5 and scale lambda=44 (mean = 44*Gamma(1+1/1.5) ~= 39.7).
# Because the true distribution is only approximately known, the influence is scaled tiny.
_SZ = np.arange(0, 102, dtype=np.float64)
try:
    from scipy.stats import weibull_min
    _cdf = weibull_min.cdf(_SZ / 44.0, 1.5)
    _cdf = np.clip(_cdf, 0.0, 1.0)
    # probability mass of an item of size s (approximately)
    _pmf = np.diff(np.concatenate(([0.0], _cdf[:-1])))
    _pmf = np.maximum(_pmf, 1e-9)
except Exception:
    # Fallback: rough decreasing density; not critical.
    _pmf = np.exp(-_SZ / 40.0)
    _pmf = _pmf / _pmf.sum()

# Expected size conditional on being > x, for x in 0..100.  Used to judge whether a
# residual slack is likely to be filled soon (small slack -> maybe future item fits).
_expected_larger = np.zeros(102, dtype=np.float64)
for x in range(102):
    tail = _pmf[x:]
    if tail.sum() > 0:
        vals = np.arange(x, 102, dtype=np.float64)
        _expected_larger[x] = float((vals * tail).sum() / tail.sum())
    else:
        _expected_larger[x] = 100.0

# ---------- state across calls ----------
# A tiny running estimate of average item size, used only to slightly adapt the
# tie-breaking if the real distribution differs from the assumed one.
_state = {"n": 0.0, "mean": 40.0}

def priority(item, bins):
    """Best-fit with a small distribution-aware tie-breaker.

    Primary score: -(bins - item), i.e. tighter fit is better (larger is better).
    Tie-breaker: for equal residual, prefer bins whose remaining capacity is close
    to a typical item size, so that the leftover space is more useable.  Also mildly
    prefer lower-indexed bins among otherwise equivalent choices.
    """
    # Update simple running mean (very cheap, done on every call).
    n = _state["n"] + 1.0
    _state["n"] = n
    m = _state["mean"]
    _state["mean"] = m + (item - m) / n

    # residual capacity after placing the item
    residual = bins - item          # 0..99 (item fits, so residual >= 0)

    # Primary: tighter fit.  Since numpy scores: highest wins, use negative residual.
    score = -residual.astype(np.float64)

    # Tiny tie-breaker based on usefulness of the remaining slack.  A bin leaving
    # 0 slack is already optimal.  For positive slack, we mildly reward slacks that
    # are common future item sizes (likely to be filled later) and mildly penalize
    # awkward slacks.  Weight is small so best-fit remains dominant.
    # Use the estimated mean to scale influence: if observed mean is far from 40,
    # shrink the adjustment.
    adapt = 1.0 / (1.0 + abs(_state["mean"] - 40.0) * 0.02)

    # Probability that some future item exactly fills this residual (rough surrogate):
    # For residual r in 0..99, pmf[r+item]?  We don't know future item sizes exactly,
    # but being near a typical size is good.  Use a smooth kernel around mean and
    # around typical small item sizes.
    r = residual.astype(np.float64)
    mean = max(1.0, _state["mean"])
    usefulness = np.exp(-((r - mean) ** 2) / (2.0 * (0.75 * mean + 5.0) ** 2))
    # Also: a slack of exactly 0 is best and gets a bonus.
    usefulness += 2.0 * (r == 0.0)

    # Mild preference for lower indices only when scores are extremely close.
    # Since exact ties go to first bin anyway, this is mostly unnecessary, but it
    # stabilizes behaviour when floating point differences are negligible.
    tiny_index = -1e-9 * np.arange(bins.size, dtype=np.float64)

    score += 0.002 * adapt * usefulness + tiny_index

    return score
