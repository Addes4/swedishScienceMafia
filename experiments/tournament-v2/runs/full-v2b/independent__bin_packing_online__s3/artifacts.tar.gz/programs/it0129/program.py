"""Best-fit variant: prefer tightest fit, with a mild bias against opening new bins."""
import numpy as np


def priority(item, bins):
    # bins: remaining capacities of all bins the item fits in (including unused bins at 100).
    # Best fit: choose the bin with the smallest remaining capacity that still fits item.
    # score higher for smaller remaining capacity.
    # Slight deferral: unused bins (cap 100) get a tiny penalty so we avoid opening
    # a fresh bin when an existing partially-filled bin fits, but still allow it when needed.
    score = -(bins - item)
    # unused bins have capacity 100; penalize them very slightly relative to used bins
    score = score.astype(np.float64)
    unused = bins == 100
    score[unused] -= 0.5
    return score
