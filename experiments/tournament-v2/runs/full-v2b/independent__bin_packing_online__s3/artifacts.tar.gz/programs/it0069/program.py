import numpy as np

_state = {
    "calls": 0,
    "used_bins": 0,
    "small_tight": 0,
    "large_tight": 0,
}


def priority(item, bins):
    global _state

    _state["calls"] += 1

    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Dynamic preference: use a slight early-bin bias, but make it weaker when
    # many bins are already relatively full (tight packing tends to be better then).
    occupied = np.count_nonzero(bins < 100)
    if occupied == 0:
        fill_ratio = 0.0
    else:
        fill_ratio = 1.0 - float(np.mean(bins[bins < 100])) / 100.0
        fill_ratio = max(0.0, min(1.0, fill_ratio))

    # For smaller items, best-fit is usually very strong. For larger items,
    # early-bin choices help avoid fragmentation. Adapt modestly over time.
    if item <= 25:
        tight_weight = 1.0
        early_weight = 0.02
    elif item <= 50:
        tight_weight = 0.85
        early_weight = 0.08
    else:
        tight_weight = 0.65
        early_weight = 0.18

    # If recent bins are densely filled, favor tight fits more strongly.
    tight_weight += 0.20 * fill_ratio
    early_weight *= 1.0 - 0.35 * fill_ratio

    # Score: exactly fitting bins get a strong bonus; otherwise prefer small slack.
    slack = bins - item

    # Main tight-fit component. Use negative slack, normalized to reduce scale.
    tight_score = -slack.astype(np.float64)

    # Exact/small-slack bonus: the smaller the remaining gap, the more valuable.
    exact_bonus = np.where(slack == 0, 25.0, 0.0)
    small_bonus = np.where((slack > 0) & (slack <= 3), 8.0 - 2.0 * slack, 0.0)

    # Early-bin bias by index: prefer already-used bins slightly more than fresh ones,
    # and among used bins prefer lower indices only weakly.
    idx = np.arange(n, dtype=np.float64)
    used = bins < 100

    early_score = np.zeros(n, dtype=np.float64)
    if np.any(used):
        first_used = int(np.argmax(used))
        denom = max(1.0, float(n - first_used))
        early_score = -((idx - first_used) / denom)

    # Fresh bins get a mild penalty to discourage opening new bins unless useful.
    fresh_penalty = np.where(~used, 3.0, 0.0)

    score = (
        tight_weight * tight_score
        + exact_bonus
        + small_bonus
        + early_weight * early_score
        - fresh_penalty
    )

    # Deterministic tiny index tie-break: lower bin index wins ties, matching harness.
    score = score - idx * 1e-9

    return score
