import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.small_count = 0
        self.medium_count = 0
        self.large_count = 0
        self.recent = []
        self.fill_hist = np.zeros(101, dtype=np.int64)


_state = _State()


def priority(item, bins):
    """Best-fit with light adaptive tunings for online bin packing."""
    n = len(bins)

    # Track global statistics (unused, but may help adapt behavior).
    _state.calls += 1
    if item <= 20:
        _state.small_count += 1
    elif item <= 50:
        _state.medium_count += 1
    else:
        _state.large_count += 1

    # Main score: tighter fit is better (smaller residual after placing item).
    residual = bins - item

    # Base priority strongly favours best fit.
    score = -residual.astype(np.float64)

    # Small numerical tie-break: prefer earlier bins deterministically.
    # (Ties already go to first bin, so this is mostly harmless.)
    score -= np.arange(n, dtype=np.float64) * 1e-12

    # Slight extra preference for near-exact fits to reduce fragmentation.
    score += np.where(residual <= 2, 0.25, 0.0)
    score += np.where(residual == 0, 0.5, 0.0)

    # For large items, avoid wasting moderately empty bins a bit more.
    if item >= 60:
        # Prefer bins that will not be left too empty if possible.
        score += np.where((residual >= 10) & (residual <= 35), 0.15, 0.0)

    return score
