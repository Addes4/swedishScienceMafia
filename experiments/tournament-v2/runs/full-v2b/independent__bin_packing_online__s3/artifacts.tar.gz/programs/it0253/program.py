import numpy as np

# Estimate of the typical item size distribution from given (mean ~ 40, Weibull-shaped).
# We'll assume items are drawn from a Weibull with mean ~40.
# Actually we don't know the shape parameter exactly, but mean 40 and Weibull-shaped.
# A common Weibull for such tasks: shape k=1.5, scale lambda such that mean = lambda*Gamma(1+1/k) = 40.
# Gamma(1+1/1.5) = Gamma(1.6667) ~ 0.9027. So lambda ~ 44.3.
# We'll not hardcode that but instead learn min item size seen so far to decide "tiny leftover".

class BinPacker:
    def __init__(self):
        self.min_item_seen = 100  # will update
        self.item_count = 0
        self.sum_items = 0

    def priority(self, item, bins):
        # Update statistics
        if item < self.min_item_seen:
            self.min_item_seen = item
        self.item_count += 1
        self.sum_items += item

        # Avoid leaving a leftover that is too small to be useful (less than some threshold).
        # Threshold: small items are rare in Weibull with mean 40; leaving capacity < 10 is probably wasted.
        # But if item is very large, we might want to exactly fill if possible.
        # We'll compute two scores:
        # score1: prefer tightest fit (smallest leftover)
        # score2: prefer bins that after placing will be nearly full but not wastefully so.
        # Actually a good online heuristic: worst fit decreasing is bad; best fit is decent.
        # But we can try to avoid leaving < some_min_use capacity.
        # We'll use a dynamic threshold: at least min_item_seen, but also consider that future items might be small.
        # Let's use threshold = max(1, min_item_seen) but also cap at, say, 20.
        # Because if we leave < min_item_seen, that space is wasted (unless item exactly fills).
        # So if leftover < threshold and leftover > 0, penalize.
        leftovers = bins - item
        max_score = np.zeros_like(bins, dtype=float)
        # Base: prefer small leftover (tightest fit) => higher score for smaller leftover.
        # To avoid extreme domination by exact fits, we can use negative leftover.
        # But we want to treat leftover 0 specially? Exact fill is good usually.
        # Let's compute:
        # score = - leftover  (so smaller leftover = higher score, exact fill gets 0)
        # But then add penalty if 0 < leftover < threshold.
        threshold = min(self.min_item_seen, 20)  # heuristic: if leftover smaller than smallest seen so far, it's likely wasted
        if threshold < 1:
            threshold = 1
        # However, if item is large, leaving small leftover might be unavoidable; still penalize.
        # Also, if a bin is completely empty (capacity 100), and item doesn't fit? It fits by definition of bins array.
        # We should also consider that using a fresh bin might be better than wasting space in a partially filled bin.
        # A common improvement: best fit with a "lookahead" penalty for leaving small gaps.
        # Let's design score = -leftover - alpha * penalty(leftover)
        # where penalty = 1 if 0 < leftover < threshold else 0.
        # But absolute magnitude of leftover varies 0..100. We want penalty to be significant.
        # If we set penalty = 100 if 0 < leftover < threshold, then it heavily discourages small gaps.
        # But sometimes we must place item and all bins would leave small gaps; then we still choose smallest leftover.
        # Let's use penalty = 50 if 0 < leftover < threshold else 0.
        # Also, exact fill (leftover 0) gets no penalty.
        # But sometimes exact fill on a nearly full bin might be bad because it uses up a bin that could have taken larger item?
        # Actually filling a bin completely is always good (that bin is done).
        # However, if we fill a bin exactly with a small item, we might have used a bin that could have been filled with larger items later.
        # But online, we don't know. Best fit usually does exact fill when possible.
        # Let's stick with best fit + penalty for small gaps.
        # Also consider bin index order: ties go to first, so bins with same score will go to earliest index, which might be older bins.
        # That's fine.

        # Compute scores
        # Higher score is better.
        # Base: negative leftover, so smaller leftover -> higher score.
        # But leftover can be up to 100; negative leftover is -0..-100.
        # We'll normalize by capacity to keep scales reasonable.
        # Actually we just need relative ordering within this call.
        # So any monotonic transform is fine.
        # Let's use score = -leftovers.astype(float)
        # Then subtract penalty.
        # Penalty: if 0 < leftovers < threshold, subtract large value.
        # But we also might want to prefer bins that are more full (smaller remaining capacity before placing) to concentrate items.
        # Best fit essentially does that. So our base already does that.

        # Let's try a slight twist: sometimes worst fit (largest leftover) is better to keep bins open?
        # No, best fit is known to be better than worst fit for online.
        # But there are better algorithms like "best fit with a reserve".
        # I'll implement a simple version: best fit, but if a bin would be left with a tiny leftover,
        # and there is another bin that would be left with a larger leftover,
        # we might prefer the larger leftover to avoid wasting the small space.
        # So penalty for small leftover.

        # To make penalty robust, we can make it depend on leftover: penalty = (threshold - leftover) if 0 < leftover < threshold else 0.
        # Then score = -leftover - beta * penalty.
        # beta controls trade-off. Choose beta = 1 gives penalty up to threshold.
        # But we want strong effect. Let's set beta = 2.

        # Actually, let's think: if leftover is 1, penalty = threshold-1, beta*penalty ~ 2*(threshold-1).
        # So -1 - 2*(threshold-1) = -1 -2threshold+2 = 1-2threshold. If threshold=20, score ~ -39.
        # A bin with leftover 30 gives score -30. So -30 > -39, so we prefer the larger leftover 30 over tiny leftover 1.
        # That seems reasonable: avoid leaving 1 space that's useless.
        # But what if all bins would leave small leftover? Then the one with smallest leftover still gets highest score (least penalty).
        # Good.

        # But we also need to consider: if item is large, say 80, and bins have capacities 100, 90, 85.
        # leftovers: 20, 10, 5. threshold maybe 20. Penalty for 10 and 5.
        # Scores: -20 (no penalty), -10 - 2*(20-10)= -30, -5 -2*(20-5)= -35. So we prefer the empty bin (leftover 20).
        # That seems good: placing 80 in a bin with 90 leaves 10 (waste), better to use empty bin leaving 20 which might fit a small item later.
        # But wait, if we use empty bin, we open a new bin; if we use 90 bin, we finish it with 10 leftover wasted. Which is better?
        # Using empty bin uses a new bin, but keeps the 90 bin available for a future item that could fit in 90 or less.
        # Actually if we place 80 in 90, leftover 10. That 10 is probably wasted because future items are >= min_item_seen.
        # So we effectively used a bin that could have held up to 90, but now only 10 left. That's bad.
        # So preferring the empty bin (leftover 20) might be better because the 90 bin can still hold items up to 90.
        # This matches the penalty logic.

        # However, if the 90 bin is the only one that can fit a future large item, we might want to save it.
        # Online, we don't know. But this heuristic seems plausible.

        # Let's implement with beta=2 and threshold = min(min_item_seen, 20).
        # Also update min_item_seen only when item is seen. Initially min_item_seen = 100.
        # At start, threshold = 20 (since min(100,20)=20).
        # As we see smaller items, threshold decreases? Actually min_item_seen decreases, so threshold = min(min_item_seen,20) could decrease if min_item_seen < 20.
        # That's fine.

        # Also, we might want to prefer bins that are more full (smaller remaining capacity) even if leftover is larger?
        # Actually that's what best fit does.
        # Our penalty modifies it.

        # Let's code it.

        # Edge case: bins array might be empty? No, it's all bins item fits in, at least one.
        # If item size > all capacities? Then bins array would be empty? But problem says bins is array of remaining capacity of every bin the item fits in.
        # So there is at least one bin.

        # Compute leftovers
        leftover = bins - item
        # Threshold
        thresh = min(self.min_item_seen, 20)
        if thresh < 1:
            thresh = 1
        # Penalty
        penalty = np.where((leftover > 0) & (leftover < thresh), (thresh - leftover).astype(float), 0.0)
        # Base score: negative leftover
        base = -leftover.astype(float)
        # Combine
        score = base - 2.0 * penalty
        return score

# Create a global instance to keep state
_packer = BinPacker()

def priority(item, bins):
    return _packer.priority(item, bins)
