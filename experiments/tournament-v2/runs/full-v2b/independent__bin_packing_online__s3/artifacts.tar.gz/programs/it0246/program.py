import numpy as np


def priority(item, bins):
    """Rank bins: best fit (tightest remaining after placing item), with mild empty-bin penalty.

    Best-fit alone is strong for this distribution, but it tends to open many bins early.
    We add a small, bounded preference for using already-populated bins by penalizing the
    perfectly empty bins slightly.  The exact penalty is tiny so it only breaks near-ties.
    """
    # Remaining capacity after placing `item`; smaller is better -> negative score.
    score = -(bins - item)

    # Slight penalty for opening a completely empty bin: remaining == 100.
    # Only applies when item < 100 (if item==100 empty bins are fine, but rare).
    # Add a small positive amount to empty bins' score so they are chosen a bit less often.
    empty = bins == 100
    if item < 100:
        score[empty] += 1e-6 * item

    return score
