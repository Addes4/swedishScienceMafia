import numpy as np


def priority(item, bins):
    """Rank bins by a blend of best-fit tightness and bin sparing.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit score: prefer the bin that leaves the least remaining capacity
    # after placing the item. This is the classic tightest-fit rule.
    fit_score = -(bins - item)

    # Bias against opening/using empty bins: prefer to fill existing partially
    # filled bins rather than consume a fresh one. This helps reduce bin count
    # because empty bins are a scarce resource that should be saved for items
    # that cannot fit elsewhere.
    # We add a modest penalty for bins with remaining capacity close to 100.
    # The penalty grows for bins that are more empty, but never overrides a
    # much better best-fit placement.
    empty_penalty = np.where(bins >= 100, -0.5, 0.0)

    return fit_score + empty_penalty
