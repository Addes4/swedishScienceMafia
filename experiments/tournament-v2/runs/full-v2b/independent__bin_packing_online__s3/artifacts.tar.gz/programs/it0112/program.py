import numpy as np


def priority(item, bins):
    """Score bins by best-fit with a mild preference against opening new bins.

    The item goes into the bin with the highest score.
    bins: remaining capacity of every bin the item fits in (numpy int64 array).
    """
    # Residual capacity after placing the item in each candidate bin.
    rem = bins - item

    # Primary: tight fit (smaller residual is better).
    score = -rem.astype(np.float64)

    # Mild penalty for using completely empty bins, to conserve fresh bins.
    # This encourages packing into partially filled bins when the fit is close.
    score[bins == 100] -= 0.5

    return score
