import numpy as np

def priority(item, bins):
    # Best-fit with a slight preference against opening a new bin.
    # bins is a copy and contains remaining capacities of bins the item fits in.
    # Higher score is better; ties go to the first bin.
    #
    # Main score: negative leftover capacity after placing the item.
    # This favors bins that become as full as possible (tightest fit).
    #
    # Extra term: discourage using completely empty bins (remaining == 100)
    # unless necessary. Since unused bins have capacity 100 and are included,
    # we subtract a small penalty from them so partially filled bins win ties.
    #
    # The penalty is fixed and small enough not to override genuine tight fits.
    leftover = bins - item  # >= 0 for bins shown
    score = -leftover.astype(np.float64)

    # Slight preference for non-empty bins over unused bins.
    score -= (bins == 100) * 1e-6

    return score
