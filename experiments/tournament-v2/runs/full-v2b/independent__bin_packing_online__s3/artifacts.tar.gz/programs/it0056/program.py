"""Best fit with a penalty for opening brand-new (empty) bins.

Online bin packing heuristic:
  - Among bins the item fits into, prefer the one with the smallest leftover
    capacity (classic best fit), which packs tightly.
  - Add a mild penalty for choosing a completely empty bin (remaining capacity
    == 100) so that already-open bins are preferred when their fit is
    reasonably close.  This delays the opening of new bins and reduces waste,
    which tends to lower the total bin count.
"""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of all fitting bins,
          including unused bins (capacity 100), in fixed bin order.
    """
    residual = bins - item
    # Best fit: smaller residual -> higher priority.
    score = -residual.astype(np.float64)

    # Slight penalty for empty bins so we prefer topping off existing ones.
    # A penalty smaller than one unit keeps ordering within the best-fit
    # residual classes intact; ties then break toward already-open bins.
    empty = (bins >= 100)
    score -= 0.01 * empty

    return score
