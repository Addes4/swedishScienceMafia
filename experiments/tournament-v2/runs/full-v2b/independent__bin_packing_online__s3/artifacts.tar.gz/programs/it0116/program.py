import numpy as np

# Global state for light adaptation (not strictly necessary but may help stability).
_last_items = []

def priority(item, bins):
    """Score bins to pack tightly while encouraging consolidation.

    The item goes to the bin with the highest score (first on ties).
    """
    # Base: prefer tighter fit (larger remaining - item is worse).
    # Using negative residual encourages best fit.
    residual = bins - item

    # Score:
    #   - strongly prefer bins whose remaining capacity is just enough (small residual)
    #   - for larger items, avoid leaving tiny residuals that fragment space
    #   - slightly prefer already-used bins (remaining < 100) to consolidate
    #   - exact fit gets a bonus
    score = -residual.astype(np.float64)

    # Consolidation bonus for used bins (remaining < 100).
    used = bins < 100
    score += used * 0.5

    # Penalize leaving very small residual (fragmentation) more for large items.
    # residual >= 0 since bins only include fitting bins.
    frag_penalty = np.where(residual < 5, (5 - residual) * (item / 100.0) * 2.0, 0.0)
    score -= frag_penalty

    # Exact fit bonus.
    score += (residual == 0) * 3.0

    return score
