import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a mild preference for fuller bins."""
    residual = bins - item
    # Best fit: smallest nonnegative residual gets highest score.
    base = -residual.astype(np.float64)
    # Tiny bias toward bins with less remaining capacity after placement.
    # This is equivalent to best-fit but breaks some near-ties more effectively.
    score = base - 1e-6 * bins.astype(np.float64)
    return score
