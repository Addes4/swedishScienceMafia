import numpy as np

_TINY = 1

def priority(item, bins):
    # Prefer bins whose remaining capacity is just enough for the item.
    # Score decreases with leftover after placing.
    leftover = bins - item
    # Strongly prefer smaller leftover, but avoid leaving capacity that is
    # too small to be useful in the future.
    score = -leftover.astype(np.float64)
    # Slight penalty for leaving a gap smaller than a typical small item,
    # since such space tends to be wasted.
    score -= 0.01 * (leftover < _TINY)
    # Slight preference for unused bins (capacity 100) over partially used
    # ones when leftovers are equal, reducing fragmentation.
    score += 1e-6 * (bins == 100)
    return score
