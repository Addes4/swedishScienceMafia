import numpy as np

def priority(item, bins):
    # Remaining capacity after placing the item
    rem_after = bins - item
    # Best-fit primary: prefer smaller remaining capacity after placement.
    # Secondary: prefer bins that are more filled (less empty after), i.e. penalize rem_after.
    # Use a mild penalty so tight-fit still dominates, but bins with equal rem_after
    # favor fuller ones (older, partially used) over fresh 100-capacity bins.
    score = -(rem_after.astype(np.float64)) - 0.01 * rem_after.astype(np.float64)
    # Slight tie-break towards earlier bins (lower index) is naturally handled by first-on-ties,
    # but add a tiny decreasing index bias for stability.
    n = bins.shape[0]
    idx_bias = -np.arange(n, dtype=np.float64) * 1e-6
    return score + idx_bias
