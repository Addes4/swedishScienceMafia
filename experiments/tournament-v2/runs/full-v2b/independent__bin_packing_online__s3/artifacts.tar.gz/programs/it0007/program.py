import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.sum_sizes = 0
        self.hist = np.zeros(101, dtype=np.int64)
        self.threshold = 60
        self.phase = 0


_state = _State()


def priority(item, bins):
    st = _state
    st.count += 1
    st.sum_sizes += int(item)
    st.hist[int(item)] += 1

    # Occasionally update the preferred residual target from the running mean.
    if st.count % 25 == 0:
        mean = st.sum_sizes / st.count
        # Aim for a residual in a useful mid-range.  Too large wastes space;
        # too small makes future packing rigid.
        st.threshold = int(min(90, max(35, 0.55 * mean + 0.35 * item)))

    # Compute best-fit gap: smallest remaining capacity that still fits the item.
    gap = bins - item

    # Primary score: prefer tight fits (small positive leftover).
    # Add a mild bias toward bins whose leftover is near a target, which
    # encourages filling existing bins before opening new ones.
    target = st.threshold
    score = 1000.0 / (gap + 1.0)

    # Slight preference for residuals close to the target, but never enough
    # to overcome a clearly tighter fit.
    score += 0.015 * (200.0 - np.abs(gap - target))

    # Strongly avoid opening a brand-new bin while there is any usable space.
    # This reduces the number of bins without depending on future items.
    score += (bins == 100).astype(np.float64) * -3.0

    # Deterministic tiny tie-breaker: earlier bins first, matching harness ties.
    score -= np.arange(bins.size, dtype=np.float64) * 1e-9

    return score
