import numpy as np


def priority(item, bins):
    cap = np.asarray(bins)
    is_unused = cap == 100
    # For used bins, prefer smallest remaining capacity (tightest fit).
    # Score = huge bonus for used bins, plus -capacity so smaller capacity wins.
    scores = np.where(is_unused, 0.0, 1e9) - cap.astype(np.float64)
    return scores
