import numpy as np


def priority(item, bins):
    """Score bins to favor tight fits (best fit) with a small bias toward already-used bins.

    The item goes to the highest score.  Unused capacity-100 bins are very slightly
    penalized so that we first try to squeeze items into partial bins, reducing the
    number of opened bins.  This is still essentially best-fit.
    """
    # Primary: best fit -- prefer small remaining capacity that still fits.
    # bins - item is >= 0 for fitting bins. Lower is better => use -(bins - item).
    score = -(bins.astype(np.int64) - item)

    # Small bonus for non-empty bins (remaining < 100), to encourage packing
    # into existing partial bins rather than opening new ones.
    score += (bins < 100) * 0.01

    return score
