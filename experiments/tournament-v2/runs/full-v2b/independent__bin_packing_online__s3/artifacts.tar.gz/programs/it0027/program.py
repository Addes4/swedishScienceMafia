import numpy as np


def priority(item, bins):
    """Best-fit style ranking with an opening penalty for unused bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of fitting bins, in bin order.
    """
    r = bins
    # residual after placing item
    residual = r - item
    # Base score: prefer smallest residual (tightest fit), like best fit.
    score = -residual.astype(np.float64)
    # Slight preference for bins that are already more filled
    # (smaller remaining capacity), reinforcing tight packing.
    score += -0.001 * r.astype(np.float64)
    # Penalize opening fresh bins (remaining == 100) so the optimizer
    # reuses existing bins when reasonable.
    is_unused = (r == 100)
    score -= 15.0 * is_unused.astype(np.float64)
    return score
