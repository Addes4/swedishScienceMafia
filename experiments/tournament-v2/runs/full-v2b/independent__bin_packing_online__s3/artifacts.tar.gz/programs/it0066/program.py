import numpy as np

_CAP = 100

class _State:
    def __init__(self):
        self.count = 0
        self.sum = 0.0
        self.max_seen = 0
        self.big_count = 0
        # running fraction of items that are "large" (>= 60)
        self.big_frac = 0.5

_STATE = _State()

def priority(item, bins):
    st = _STATE
    # update running statistics
    st.count += 1
    st.sum += item
    if item > st.max_seen:
        st.max_seen = item
    if item >= 60:
        st.big_count += 1
    st.big_frac = st.big_count / st.count

    n = bins.shape[0]

    # residual = remaining capacity after placing item
    residual = bins - item

    # Base best fit: prefer smallest residual.
    # Add a bonus for used bins so empty bins (cap 100) are kept for later big items.
    used = bins < _CAP
    bonus = np.where(used, 1.0, 0.0)

    # Slight preference against leaving a residual that is close to item size,
    # to reduce fragmentation toward a future similar item.
    # penalty proportional to |residual - item| normalized.
    frag = -np.abs(residual - item) * 0.02

    # Extra: if many large items expected, penalize filling a bin so that residual < 30
    # which could waste it; if large items rare, encourage tight packing.
    tight_pen = 0.0
    if st.big_frac > 0.3:
        # penalize residuals in (0, 30) mildly to keep some medium space
        small = (residual > 0) & (residual < 30)
        tight_pen = np.where(small, -0.5 * st.big_frac, 0.0)

    score = -residual.astype(np.float64) + bonus + frag + tight_pen
    return score
