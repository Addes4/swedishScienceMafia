import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.sum = 0.0

    def update(self, item):
        self.count += 1
        self.sum += item


_st = _State()


def priority(item, bins):
    _st.update(item)
    n = bins.size

    # Best-fit: prioritize smallest remaining capacity that still fits.
    # Since all bins are >= item, score is lower when remaining cap is closer to item.
    best_fit_score = -(bins - item).astype(np.float64)

    if _st.count <= 1:
        return best_fit_score

    mean = _st.sum / _st.count
    # Estimate typical item size; used to judge whether a bin's leftover is useful.
    typ = max(1.0, mean)

    # Leftover after placing the item.
    leftover = bins - item  # >= 0

    # Reward bins that become nearly full (small leftover relative to typical item size).
    # This encourages packing bins tightly together with the current best-fit choice.
    density_bonus = -leftover / typ

    # Additionally, weakly prefer not to open entirely empty bins when item is small,
    # by penalizing large leftover (already handled above), and slightly reward
    # moderate leftover bins that are unlikely to accept future large items.

    # Penalize bins whose remaining capacity is very small but nonzero, because
    # placing here wastes potential; actually best-fit is already good. Instead,
    # strongly favor bins that are already partly used and can be completed.
    partial = (leftover < typ).astype(np.float64)

    score = best_fit_score + 0.5 * density_bonus + 10.0 * partial
    return score
