"""Best fit with tie-breaking to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: choose the bin with the smallest remaining capacity that still fits
    # Prefer used bins (smaller remaining capacity) to avoid opening new bins.
    # Tie-break by penalizing remaining capacity that is likely to be wasted.
    
    remaining = bins - item  # capacity left after placing item
    
    # Prefer bins with small remaining capacity (best fit), but heavily penalize
    # leaving a tiny remainder that will be hard to fill.
    # Use a score that decreases with remaining capacity, with extra penalty
    # for very small remainders (1-10) which likely waste space.
    
    # Base: negative remaining (smaller remaining = higher priority)
    score = -remaining.astype(np.float64)
    
    # Extra penalty for tiny remainders that are likely wasted
    tiny = (remaining > 0) & (remaining < 15)
    score[tiny] -= 5.0 * (15 - remaining[tiny])
    
    # Slight bonus for exactly filling (remaining == 0) - perfect fit
    score[remaining == 0] += 200.0
    
    return score
