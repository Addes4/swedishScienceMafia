import numpy as np


def priority(item, bins):
    """Best-fit with a mild fill-preference tie-break.

    The main score is the best-fit residual: smaller remaining capacity after placing
    the item is better.  A small bonus for leaving a bin nearly full / avoiding nearly
    empty placements helps reduce fragmentation without looking ahead.
    """
    residual = bins - item

    # Best fit: prefer the smallest residual after placing the item.
    # The primary term dominates; the secondary term only breaks near-ties.
    score = -1000.0 * residual

    # Mild preference for bins that will be more completely filled.
    # This discourages starting too many barely used bins when several bins fit similarly.
    filled = 100 - residual
    score += filled / 100.0

    return score
