import numpy as np


def priority(item, bins):
    """
    Rank bins for online bin packing.

    Main idea: mostly best fit (fill the fullest bin that fits), but avoid
    leaving tiny un-fillable gaps when another bin can take the item almost
    as tightly while leaving a more useful remaining capacity.

    Returns a score for each bin; highest score wins, ties to first bin.
    """
    # Best-fit component: prefer bins with less remaining capacity.
    # bins - item is the leftover after placing the item.
    leftover = bins - item

    # Base score heavily favors tight fitting (small leftover).
    score = -(leftover.astype(np.float64))

    # Penalize leaving very small residual gaps, because they are hard to use
    # later and waste capacity. A residual gap that cannot hold even a size-1
    # item is impossible here only if leftover < 1; but small gaps like 1..5
    # are still often wasted. Penalize increasingly small leftovers.
    small_gap_penalty = np.zeros_like(score)
    mask = leftover < 10
    small_gap_penalty[mask] = (10 - leftover[mask]) * 0.35

    # Slightly prefer not to consume completely empty bins if a used bin fits
    # similarly well, preserving empty bins for future large items.
    empty_penalty = (bins == 100).astype(np.float64) * 0.6

    # For larger items, prefer bins that leave a larger usable gap, because
    # fragmentation from large items is costly.
    large_bonus = np.zeros_like(score)
    if item >= 50:
        # reward larger residual capacity beyond the item's size
        large_bonus = np.maximum(leftover, 0).astype(np.float64) * (item / 100.0) * 0.08

    return score - small_gap_penalty - empty_penalty + large_bonus
