import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum_items = 0.0
        # rough online estimate of the item-size distribution's upper useful threshold
        self.mean = 40.0

    def update(self, item):
        self.n += 1
        self.sum_items += item
        self.mean = self.sum_items / self.n


_state = _State()


def priority(item, bins):
    """Rank bins by a refined best-fit rule.

    Primary objective: place item into a bin whose remaining capacity is close to item
    (minimize leftover waste).  Secondary objective: slightly prefer bins that are
    already less empty, which tends to preserve large unused bins for large future
    items and reduces fragmentation.
    """
    _state.update(item)

    # remaining capacity after placing the item (nonnegative by contract)
    leftover = bins - item

    # Best-fit score: smaller leftover is better.  Using -leftover gives higher score
    # to bins with less remaining space after placement, i.e. tightest fit.
    score = -leftover.astype(np.float64)

    # Mild anti-fragmentation bias.  Bins with less remaining capacity now are more
    # "filled", and using them is usually preferable to opening/using a nearly empty
    # bin.  The coefficient is deliberately small and scale-stable.
    # bins are in 1..100; fullness = (100 - bins) / 100.
    fullness = (100.0 - bins.astype(np.float64)) * 0.01
    score += 0.35 * fullness

    # Very small deterministic tie-breaker toward earlier bins, matching the stated
    # tie rule in case floating-point differences should not override it.
    # Since ties go to the first bin, this term must be negligible but stable.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    score -= idx * 1e-12

    return score
