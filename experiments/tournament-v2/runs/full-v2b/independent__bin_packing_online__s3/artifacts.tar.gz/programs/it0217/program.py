import numpy as np


def priority(item, bins):
    """Score bins for best-fit packing with exact-fit and reuse bonuses."""
    leftover = bins - item  # >= 0 for all bins passed in
    # Higher score wins. Prefer smaller leftover; strongly prefer exact fill.
    score = -leftover.astype(np.float64)
    # Exact fit bonus.
    score[leftover == 0] += 1000.0
    # Prefer nonempty bins (capacity < 100) slightly over opening fresh bins.
    score[bins == 100] -= 0.5
    return score
