import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Compute leftover after placing the item in each bin.
    leftover = bins - item  # non-negative since bins only contain fitting capacities

    # Base: best fit (smaller leftover is better).
    score = -leftover.astype(np.float64)

    # Bonus for perfectly filling a bin (leftover == 0) to close it.
    score += 10.0 * (leftover == 0)

    # Small bonus for nearly filled bins (leftover <= 5) to encourage closing.
    score += 2.0 * (leftover <= 5) * (leftover > 0)

    # Slight preference for bins that are already fairly full,
    # to avoid opening new bins unnecessarily.
    # bins are remaining capacities: smaller means fuller.
    fullness = 100.0 - bins  # higher is more full
    score += 0.05 * fullness

    # Discourage putting items into empty bins (remaining == 100) unless necessary.
    score -= 5.0 * (bins == 100)

    # For very small items, avoid placing into bins that would leave tiny
    # gaps (fragmentation), but that's already covered by best fit.
    # For large items (item >= 70), prefer bins that are already partially filled
    # (first-fit-like) to leave empties for smaller items.
    if item >= 70:
        score += 0.2 * fullness
        # Also penalize using empty bins more strongly for large items.
        score -= 10.0 * (bins == 100)

    return score
