import numpy as np

_state = {"count": 0, "sum": 0.0}


def priority(item, bins):
    s = _state
    s["count"] += 1
    s["sum"] += item
    mean = s["sum"] / s["count"]

    # Best fit: prefer smallest remaining capacity that still fits
    score = item - bins  # since item fixed, equivalent to -bins

    # Small push toward already-used bins (lower remaining capacity), scaled by
    # how tightly the item fits typical demand. Helps avoid opening new bins.
    # Penalize nearly-empty (fresh) bins slightly so they're used last.
    used = 100 - bins
    score = score - used * (item / (mean + 1e-9)) * 0.05

    return score.astype(np.float64)
