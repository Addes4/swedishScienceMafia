"""Online bin packing: best-fit with a mild preference against opening new bins.

Items arrive one at a time. Bins are ranked by the leftover capacity that would
remain after placing the item (smaller is better), with a small penalty applied
to completely empty bins so that existing partially-filled bins are preferred
when their fits are comparable. This reduces fragmentation and tends to open
fewer new bins than pure best-fit.
"""
import numpy as np


def priority(item, bins):
    # Leftover capacity after placing the item (only bins that fit are shown).
    leftover = bins - item

    # Base score: prefer the smallest leftover (best fit).
    score = -leftover.astype(np.float64)

    # Penalize completely empty bins (remaining == 100) slightly, so that a
    # partially-filled bin with a similar fit is chosen first. This keeps bins
    # concentrated, reducing the number of bins opened overall.
    score -= 0.5 * (bins == 100)

    return score
