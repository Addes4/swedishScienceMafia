import numpy as np


def priority(item, bins):
    """Best fit, with a tiny preference for nonempty bins over fresh/empty ones."""
    # Primary: tightest fit => smallest remaining capacity after placing item.
    # score = -(remaining_after_placement) = item - bin_remaining
    rem_after = bins - item

    # Secondary tilt: prefer bins that are not completely empty when fits are close.
    # Empty bins have remaining capacity 100.  Since item >= 1, rem_after <= 99.
    # Add a very small bonus to nonempty bins, not enough to overturn real fits,
    # but enough to break near-ties in favor of filling existing partial bins.
    nonempty_bonus = (bins < 100).astype(np.int64)

    return (-rem_after).astype(np.float64) + 1e-6 * nonempty_bonus
