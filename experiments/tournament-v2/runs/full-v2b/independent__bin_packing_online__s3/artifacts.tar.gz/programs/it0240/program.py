import numpy as np


class BinPackingPolicy:
    def __init__(self):
        self.count = 0
        self.total = 0.0

    def priority(self, item, bins):
        # Primary rule: best fit (smallest remaining capacity that still fits).
        # Secondary tie-break: prefer bins that are already more used, which
        # often delays opening new bins compared with pure best fit.
        self.count += 1
        self.total += item

        # bins are remaining capacities. Smaller remaining after placing is better.
        # Equivalent: larger used capacity is better. We can score as:
        #   -remaining_capacity + small * used_capacity
        # Since item is fixed for all candidate bins, any monotone transform of
        # remaining capacity works for the primary ordering.
        used = 100 - bins
        mean_item = self.total / self.count

        # Slight bias toward fuller bins; coefficient is tiny and only affects
        # near-ties, so it remains essentially best fit.
        alpha = 0.01 * (mean_item / 40.0)
        return used.astype(np.float64) + alpha * used.astype(np.float64)


_policy = BinPackingPolicy()


def priority(item, bins):
    return _policy.priority(item, bins)
