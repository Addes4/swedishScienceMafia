import numpy as np

# Expected item-size distribution is Weibull-like with mean ~40 on 1..100.
# A simple practical rule: combine best-fit with a bias against creating
# awkward small residuals, especially when the item is small.

def priority(item, bins):
    # bins: remaining capacities of feasible bins, as int64 numpy array.
    # Return scores; highest wins, ties by lower index.
    b = bins.astype(np.float64)

    residual = b - float(item)  # >= 0 for all shown bins

    # Best fit favors the smallest residual. Add a mild term encouraging
    # moderate fullness: prefer bins that become reasonably full, but do not
    # over-pack tiny residuals that may strand capacity for future medium items.
    #
    # The following is a smooth tradeoff: score = -residual + alpha * (b/100)
    # This slightly prefers existing fuller bins among equal residuals, which
    # tends to consolidate load and reduce bin count.
    score = -residual + 0.18 * (b / 100.0)

    # For very small items, best-fit can be too greedy about exactly filling
    # leftovers. Shift slightly toward bins with larger remaining capacity so
    # small items use slack rather than consuming useful residual patterns.
    # For large items, keep pure best-fit behavior.
    if item <= 12:
        score += 0.035 * (b / 100.0)

    # Avoid tiny nonzero residuals when an exact fit or a more useful residual
    # is available: add a small penalty for residuals in a range that is often
    # hard to reuse by later items.
    # Penalize residual 1..5 lightly (fragmentation), and boost residual near 0.
    small_res = (residual > 0.5) & (residual < 6.0)
    score -= 0.08 * small_res.astype(np.float64)

    # Exact fit gets a clear bonus.
    score += 0.50 * (residual < 0.5).astype(np.float64)

    return score
