"""Online best-fit bin packing with distribution-aware tie-breaking.

The item goes into the bin with the smallest remaining capacity that still
fits (best fit).  Ties and near-ties are broken using an online estimate of
the arriving item-size distribution: a bin whose residual capacity after the
placement is close to a "typical" future item size is preferred, because that
residual is likely to be reused soon.
"""
import numpy as np


class _Stats:
    """Online estimate of the item-size distribution (mean / histogram)."""

    def __init__(self):
        # Coarse histogram of observed item sizes (bins of width 5 -> 20 buckets).
        self.hist = np.zeros(21, dtype=np.float64)
        self.count = 0.0

    def update(self, item):
        idx = item // 5
        if idx > 20:
            idx = 20
        self.hist[idx] += 1.0
        self.count += 1.0

    def typical(self):
        """Return a representative residual size that is likely to be reused."""
        if self.count < 20:
            # Not enough data: neutral fallback.
            return 50.0
        h = self.hist / self.count
        # Expected size of an item conditional on it being at least ~small.
        # Use the histogram to compute the mean of items in the upper portion.
        sizes = (np.arange(21) * 5 + 2.5)
        w = h * sizes
        s = w.sum()
        if s <= 0:
            return 50.0
        # Weighted mean item size.
        return float(s)


_STATS = _Stats()


def priority(item, bins):
    """Rank bins for the arriving `item`.

    Primary rule: best fit -- prefer bins with the least remaining capacity
    that still fits the item, i.e. smallest (bins - item) >= 0.

    Secondary rule: among bins with similar residual capacity, prefer the one
    whose leftover (bins - item) is closest to the typical future item size,
    so that leftover space is likely to be filled later.
    """
    _STATS.update(item)

    # Residual capacity after placing the item (>= 0 for all shown bins).
    residual = bins - item

    # Best-fit score: larger (less negative) is better.  We negate residual.
    fit_score = -residual.astype(np.float64)

    # Distribution-aware tie breaker: reward residual close to typical size.
    t = _STATS.typical()
    # Width of the tie-breaking window: small enough to act only on near ties.
    window = max(2.0, 0.15 * t)
    tie = -np.minimum(np.abs(residual - t), window * 3.0)

    # Combine: primary dominates, secondary breaks ties.
    return fit_score * 1000.0 + tie
