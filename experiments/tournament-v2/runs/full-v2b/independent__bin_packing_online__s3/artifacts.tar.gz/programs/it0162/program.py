"""Online bin packing policy: quasi-best-fit with empty-bin penalty.

We score each fitting bin primarily by how tightly it fits (best fit), but add a
small penalty for completely empty bins so that, when several bins have the same
slack, we prefer to keep one fresh bin in reserve rather than continuously
opening new ones.  This is a static rule (no future information, no per-instance
tuning) and runs in O(#bins) per call.
"""
import numpy as np


def priority(item, bins):
    # Slack = remaining capacity after placing the item.  Smaller slack is better.
    slack = bins - item

    # Base score: strongly favour smaller slack (quasi best-fit).
    # Multiply by a large constant so primary ordering is exact best-fit.
    score = -1000.0 * slack

    # Tie-breaker: bins that were already non-empty (slack < 100-item) are
    # slightly preferred over completely empty bins, to avoid consuming fresh
    # bins when an existing partial bin would do equally well.
    # Empty-bin indicator: bins == 100 means still untouched.
    score = score - 0.5 * (bins == 100).astype(np.float64)

    return score
