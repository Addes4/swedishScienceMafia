import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    Strategy: best-fit with a tie-break that keeps the number of partially
    filled bins from growing unnecessarily.  The main score is the leftover
    capacity after placing the item (smaller is better).  A tiny bonus is
    added for bins that are already in use so that empty bins (capacity 100)
    are only opened when necessary.
    """
    leftover = bins - item

    # Primary: prefer the tightest fit (smallest leftover).
    # Secondary: prefer already-used bins over unused ones (leftover != 100 - item).
    # Scale so secondary never overrides a genuinely tighter fit.
    used = (bins < 100).astype(np.float64)

    # best fit: -leftover ; used bonus: +0.01 * used
    return (-leftover).astype(np.float64) + 0.01 * used
