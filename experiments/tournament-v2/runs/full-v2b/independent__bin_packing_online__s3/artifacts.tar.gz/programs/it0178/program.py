import numpy as np


def priority(item, bins):
    # bins: remaining capacities of candidate bins (all bins the item fits into)
    # We want to return a score per bin; highest score wins, ties go to first index.

    # Small items: best fit (tightest remaining capacity that still fits).
    # This packs small items into already-partially-filled bins, leaving empty bins for large items.
    if item <= 20:
        # Prefer smallest remaining capacity >= item, i.e. most tightly fitting bin.
        # -bins gives highest score to smallest remaining capacity.
        return -bins

    # Large items: prefer bins that are partially filled but not too empty,
    # so that large items don't fragment empty bins.
    # Use remaining capacity close to item (best fit) but avoid completely empty bins
    # unless no better option exists.
    # We'll use best fit, but demote completely empty bins (remaining == 100) a bit.
    scores = -(bins - item).astype(np.float64)

    # Demote completely empty bins (capacity 100) by subtracting a large penalty.
    # This keeps empty bins available for future large items, but still allows
    # using them if no other bin is available.
    empty_mask = (bins == 100)
    scores[empty_mask] -= 1000.0

    # Also mildly prefer bins with remaining capacity close to item (best fit)
    # which is already captured by -(bins - item).

    return scores
