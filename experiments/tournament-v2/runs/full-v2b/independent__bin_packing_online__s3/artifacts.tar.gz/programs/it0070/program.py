import numpy as np


def priority(item, bins):
    """Score bins so the item goes to a good fit.

    Strategy: prefer best-fit (tightest remaining capacity) but with a slight
    preference for bins that are already partially used, and avoid leaving very
    small residuals when an alternative exists. This combines the packing
    efficiency of best-fit with fragmentation control.
    """
    # Residual capacity left if item goes into each bin.
    residual = bins - item

    # Base score: prefer tight fits (smaller residual -> higher score).
    # Negative residual means it doesn't fit, but harness only shows fitting bins.
    score = -residual.astype(np.float64)

    # Slight bonus for using already-open bins (residual < 100 - item means bin
    # already had something). This reduces number of opened bins.
    used = residual < (100 - item)
    score[used] += 0.5

    # Penalize residuals that are too tiny (1..3): they tend to be hard to fill,
    # so if we can choose a slightly less tight fit that's often better.
    # Only penalize mildly so best-fit still dominates.
    tiny = (residual >= 0) & (residual <= 3)
    score[tiny] -= 0.5

    return score
