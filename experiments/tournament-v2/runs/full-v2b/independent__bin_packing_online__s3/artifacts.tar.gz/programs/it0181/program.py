# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a penalty for consuming too-empty bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Strategy: prefer tightly fitting bins (best fit), but slightly penalize
    bins that have a lot of room left, so that large empty bins are conserved
    for future large items. The item always fits in every bin shown.
    """
    # Exact best-fit signal: smaller leftover is better -> -(bins - item) = item - bins.
    # Add a mild penalty against large remaining capacity to reduce fragmentation.
    # Using a coefficient on remaining capacity keeps large items from scattering.
    score = -(bins - item) - 0.02 * bins
    return score
# EVOLVE-BLOCK-END
