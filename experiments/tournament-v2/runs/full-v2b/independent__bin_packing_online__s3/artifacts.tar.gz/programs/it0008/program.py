import numpy as np


def priority(item, bins):
    # Score bins: prefer exact fit, then tightest fit among used bins,
    # slightly deprioritize opening a fresh bin (remaining capacity 100)
    # to reduce bin count under i.i.d. arrivals.
    remaining = bins - item  # waste if placed here
    # Exact fit gets the highest priority
    score = -remaining.astype(np.float64)
    # Penalize opening a new empty bin (remaining == 100) slightly,
    # but only if it's truly unused; this encourages packing into existing bins.
    # (Bins with remaining==100 but actually used aren't distinguishable,
    #  so we treat capacity-100 bins as unused and apply a mild penalty.)
    empty_mask = (bins == 100)
    score[empty_mask] -= 0.5
    return score
