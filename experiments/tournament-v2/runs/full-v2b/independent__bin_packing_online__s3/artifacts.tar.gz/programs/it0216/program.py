"""Online bin packing: scaled best fit with mild preference against opening new bins."""
import numpy as np


def priority(item, bins):
    # Remaining capacity after placing the item.
    rem = bins.astype(np.float64) - float(item)

    # Primary: prefer tight fits (small rem). Secondary: fill existing bins more.
    # A penalty for completely empty bins avoids opening a fresh bin when a
    # reasonably tight fit already exists, but lets large items use empty bins.
    empty = (bins == 100)
    score = -rem - 0.02 * bins - 0.5 * empty

    return score
