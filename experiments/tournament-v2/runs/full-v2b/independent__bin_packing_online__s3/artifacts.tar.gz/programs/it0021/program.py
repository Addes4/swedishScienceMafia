import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.sum_item = 0.0
        self.count = 0


_state = _State()


def priority(item, bins):
    _state.calls += 1
    _state.sum_item += item
    _state.count += 1

    residual = bins - item

    # Base score: prefer smallest residual (best fit) -> most negative residual highest.
    score = -residual.astype(np.float64)

    # Adaptive average item size estimate.
    avg = _state.sum_item / _state.count if _state.count else 40.0

    # Penalize leaving tiny unusable gaps, especially when residual is small but nonzero.
    # A residual that cannot fit the average item is nearly wasted.
    small = avg * 0.5
    # bins with residual in (0, small) are wasteful; push them down a bit.
    waste_mask = (residual > 0) & (residual < small)
    score[waste_mask] -= 2.0

    # Prefer not to fill bins perfectly when item is large; a perfect fit removes a bin
    # but large items often leave remainder gaps anyway. Slight bonus for nonzero residual.
    exact = residual == 0
    score[exact] += 0.5

    # Slight preference for already-used bins (smaller remaining capacity) over unused 100s,
    # to consolidate and avoid opening new bins.
    unused_mask = bins == 100
    score[unused_mask] -= 0.25

    return score
