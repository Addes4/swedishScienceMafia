import numpy as np

_state = {"last_item": None}

def priority(item, bins):
    bins = np.asarray(bins)
    rem = bins.astype(np.int64)
    # Primary: prefer exact fits (residual == 0 after placement)
    exact = (rem == item)
    # Best-fit score: smaller remaining capacity is better (tightest fit)
    score = -rem.astype(np.float64)
    # Boost exact fits
    score = np.where(exact, score + 1000.0, score)
    return score
