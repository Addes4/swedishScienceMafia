import numpy as np


def priority(item, bins):
    """Adaptive best-fit + fullness preference; reserve some large bins later."""
    # bins: remaining capacities (100 for unused). We prefer bins that leave small leftover.
    leftover = bins - item

    # Prefer tighter fits (lower leftover -> higher score).
    score = -leftover.astype(np.float64)

    # Slight bonus for using already-fuller bins (lower remaining capacity), which helps
    # consolidate small items and keeps emptier bins available for future large items.
    score += 0.05 * (100.0 - bins)

    # As the run progresses, large items become more likely to need large bins.
    # We can't see future items, but we can use our own call history.
    # Use a simple global counter and estimate.
    try:
        priority.calls += 1
    except AttributeError:
        priority.calls = 1
        priority.large_seen = 0

    if item >= 60:
        priority.large_seen += 1

    n = priority.calls
    # After a while, mildly prefer not to fill almost-empty bins (remaining 100)
    # if the current item is small, to save space for large items.
    if n > 500 and item < 40:
        # Penalize completely unused bins a bit so small items don't fragment big empty bins.
        score -= 2.0 * (bins == 100)

    return score
