"""Hybrid best-fit: tightly pack into existing bins, delay opening new ones."""
import numpy as np

# Precompute a small bonus table indexed by remaining capacity (0..100).
# Used to slightly prefer used bins and penalize perfectly empty bins.
_BONUS = np.zeros(101, dtype=np.float64)
for c in range(101):
    if c == 100:
        _BONUS[c] = -0.5      # discourage opening brand-new bins
    elif c <= 2:
        _BONUS[c] = 0.2       # tiny nudge toward already-crowded bins
    else:
        _BONUS[c] = 0.0


def priority(item, bins):
    # negative leftover → higher score for tighter fits
    return -(bins - item) + _BONUS[bins]
