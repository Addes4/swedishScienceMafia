"""Improved online bin packing rule.

The rule combines:
  * best fit (small remaining capacity) to limit fragmentation,
  * worst fit (large remaining capacity) when there is plentiful capacity so
    large future items still have room,
  * a residual-capacity term that discourages exactly emptying a bin, because
    bins with an exact residual of 0-4 are often wasted for the many items of
    size 1..5.
"""
import numpy as np


def priority(item, bins):
    bins = np.asarray(bins)
    rem = bins.astype(np.float64)
    residual = rem - item

    # Best-fit component: prefer small residual.
    best_fit = -residual

    # Worst-fit component: prefer bins with more room, but capped so it does
    # not dominate when there are many bins.
    worst_fit = np.minimum(rem, 100.0)

    # Capacity-aware term.  This distribution has mean ~40, so item sizes
    # cluster below 80.  A bin with residual below item would have been
    # filtered out by the harness; here residual >= 0.
    # Reward residuals that can still accept common medium items and punish
    # nearly-empty bins only mildly.
    reserve = np.zeros_like(residual)

    # Common medium/large item sizes: residual around 40-60 is valuable.
    reserve += 0.10 * np.exp(-((residual - 50.0) ** 2) / (2.0 * 18.0 ** 2))

    # Avoid leaving less than 5 units, which cannot hold the smallest items.
    reserve -= 0.08 * np.exp(-(residual ** 2) / (2.0 * 2.0 ** 2))

    # Number of bins available: with few bins, be more conservative.
    n = bins.shape[0]
    if n == 1:
        # Only one choice: keep the bin as open as possible.
        score = worst_fit
    else:
        # With multiple bins, blend best-fit with worst-fit and reserve.
        # More bins -> more freedom to best-fit.
        w_best = 1.0
        w_worst = 0.02 * np.log1p(n)
        score = w_best * best_fit + w_worst * worst_fit + reserve

    return score
