"""Hybrid best-fit bin-choice rule for online bin packing.

The item goes into the bin with the highest score. We use a weighted best fit:
- strongly prefer bins where the residual after placement is small (tight fit),
- add a mild penalty for leaving very little slack (to avoid wasting a bin's
  capacity on an item that could fit elsewhere, when a perfect fit is near),
- give a bonus for a perfect fill (residual 0),
- for large items, avoid opening a fresh bin if some bin is already fairly full.
Unused bins have remaining capacity 100 and are included; ties go to first bin.
"""

import numpy as np


def priority(item, bins):
    # Residual capacity left in each bin after placing the item.
    residual = bins - item  # bins only contains bins the item fits in, so >= 0

    # Base: tighter fit is better -> smaller residual should score higher.
    # Use negative residual scaled.
    score = -residual.astype(np.float64)

    # Bonus for an exact fill: strongly reward leaving zero residual.
    score += 1e6 * (residual == 0)

    # Mild penalty for leaving an extremely tight (but nonzero) residual,
    # which wastes near-full bins that might better host future similar items.
    tiny = (residual > 0) & (residual <= 3)
    score -= 2.0 * tiny

    # Large items: prefer bins that become rather full (i.e., tighter) but
    # discourage using a fresh empty bin (bins == 100) when a natural fit
    # already exists. We softly penalize placing a big item into an empty bin.
    if item >= 50:
        score -= 0.5 * (bins == 100)

    # Slight preference for bins that are already partly used (avoid opening
    # new bins unnecessarily): less remaining capacity is preferable overall.
    score -= 1e-3 * bins.astype(np.float64)

    return score
