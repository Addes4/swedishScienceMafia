import numpy as np


def priority(item, bins):
    residual = bins - item  # leftover space if item placed here

    # Base: prefer tightest fit (smallest residual)
    score = -residual.astype(np.float64)

    # Bonus for leaving a residual that is a "useful" size (likely fillable later).
    # Residuals that are 0 are perfect. Small nonzero residuals below typical item
    # sizes are nearly wasted, so penalize them mildly relative to larger residuals.
    # We add a tiny preference for residuals that equal common small sizes.
    useful = np.array([0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20], dtype=np.float64)
    is_useful = np.isin(residual, useful.astype(np.int64)).astype(np.float64)

    # Penalize wasted tiny gaps (< min item size already impossible since item>=1,
    # residual could be 0). Emphasize exact fit strongly.
    exact = (residual == 0).astype(np.float64)

    score += 0.5 * exact + 0.1 * is_useful

    # Slight preference to keep one large empty bin from being consumed:
    # discourage placing into a completely full (100) unused bin by a tiny epsilon
    # only when a tighter option isn't available is already handled by base score.
    return score
