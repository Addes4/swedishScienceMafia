import numpy as np

def priority(item, bins):
    """
    Score bins so the item goes to the bin that best fits.
    Prefer:
      - exact fits strongly
      - small resulting residual (best fit)
      - avoid opening new bins unless necessary
    """
    residual = bins - item

    # Base: prefer smallest residual (i.e. best fit)
    score = -residual.astype(np.float64)

    # Strong bonus for exact fit
    score += (residual == 0) * 1000.0

    # Bonus for leaving very small gaps (likely hard to fill later)
    score += (residual == 1) * 50.0
    score += (residual == 2) * 20.0
    score += (residual == 3) * 10.0

    # Penalize using completely empty bins unless it's a very good fit
    # Empty bin has remaining capacity 100 => residual = 100 - item
    empty = (bins == 100)
    # Penalty grows with the residual that would remain in the empty bin
    score -= empty * (residual * 0.5)

    return score
