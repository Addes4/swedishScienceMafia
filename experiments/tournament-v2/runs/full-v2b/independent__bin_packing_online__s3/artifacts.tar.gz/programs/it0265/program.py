import numpy as np


def priority(item, bins):
    """Best fit with a mild bias against opening new bins.

    The item goes to the bin whose remaining capacity after insertion is smallest
    (largest `bins - item`).  Ties are broken slightly in favor of bins that are
    already used, which tends to reduce the number of nonempty bins.
    """
    # Primary score: prefer fuller bins, i.e. smaller remaining capacity after adding item.
    score = -(bins - item).astype(np.float64)

    # Secondary bias: only unused bins have remaining capacity exactly 100.
    # Add a tiny penalty so that, when capacities are otherwise tied, a used bin wins.
    score[bins == 100] -= 1e-6

    return score
