import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        self.mean = 40.0
        self.alpha = 0.02


_state = _State()


def _dist_score(item, bins):
    # Best fit: maximize remaining capacity minus item, i.e. minimize residual.
    # bins is remaining capacity after placing item would be bins - item.
    return -(bins - item)


def priority(item, bins):
    """
    Online bin packing priority.

    Main rule: best fit (tightest residual).  Periodically, when the item size is
    relatively large, prefer bins that leave a residual which is close to a
    common future item size, improving later waste.
    """
    _state.calls += 1
    _state.hist[item] += 1.0
    _state.total += 1.0
    _state.mean += _state.alpha * (item - _state.mean)

    n = bins.shape[0]
    residual = bins - item

    # Base best-fit score.  Higher is better.
    base = -residual.astype(np.float64)

    # After a short warm-up, for larger items, slightly prefer bins whose residual
    # matches a typical remaining item size.  This is a cheap deterministic
    # adjustment that keeps the fast best-fit path for most calls.
    if _state.calls > 200 and item >= 25 and n > 1:
        # A small set of representative future sizes near the running mean.
        m = _state.mean
        targets = (max(1.0, m * 0.55), max(1.0, m * 0.85), max(1.0, m * 1.15), max(1.0, m * 1.45))
        r = residual.astype(np.float64)[:, None]
        t = np.asarray(targets, dtype=np.float64)[None, :]
        # Smaller distance to a future size is better.  The factor is deliberately
        # modest so best-fit remains dominant.
        bonus = -0.08 * np.min(np.abs(r - t), axis=1)
        return base + bonus

    return base
