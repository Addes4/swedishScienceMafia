import numpy as np

# State for slight adaptation (kept minimal, instance-agnostic)
_state = {
    "calls": 0,
}

def priority(item, bins):
    """
    item: int
    bins: np.ndarray int64 of remaining capacities (all bins the item fits into)
    return: np.ndarray of scores, same length as bins
    """
    _state["calls"] += 1

    # residual capacity after putting item in each bin
    rem_after = bins - item

    # Base: best fit => prefer smallest residual (most negative (bins-item) would be worst)
    # score = -rem_after, so smaller rem_after => higher score
    score = -rem_after.astype(np.float64)

    # Strongly reward perfectly filling a bin
    score += 10000.0 * (rem_after == 0)

    # Mildly reward leaving small residuals (tight packing)
    score -= 0.02 * np.abs(rem_after)

    # Slight preference for fuller bins (more likely already-open), encourages consolidation
    score += 0.001 * (100 - bins)

    # Tiny deterministic jitter to stabilize ties across identical capacities
    # Based on bin index order is implicit by first-max; add negligible index-independent term
    score += 1e-6 * (bins % 7)

    return score
