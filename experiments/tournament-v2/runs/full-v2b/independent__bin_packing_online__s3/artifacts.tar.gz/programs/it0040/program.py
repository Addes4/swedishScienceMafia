"""Hybrid best-fit scoring for online bin packing.

The item goes to the bin maximizing:
    score = 1.0 / (bins - item + 0.5)   (best fit, tightest fit)
          + 0.12 * (bins - item)        (leave slightly more room, reduces fragmentation)
          + tiny deterministic tie-break

This is essentially Best Fit with a small preference for putting items into bins
that still leave a usable remainder, which tends to pack Weibull-sized items
more efficiently than pure tightest-fit.
"""
import numpy as np


def priority(item, bins):
    # bins are remaining capacities, all >= item
    rem = bins - item  # remaining after placing item
    # Best-fit primary term: smaller rem -> higher score.
    # Use 1/(rem+1) so rem=0 gives score ~1, rem=99 gives ~0.01.
    best_fit = 1.0 / (rem.astype(np.float64) + 1.0)
    # Secondary: mild preference for leaving some room (avoid tiny slivers).
    spread = 0.12 * rem.astype(np.float64)
    # Deterministic jitter based on bin index to break ties reproducibly.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    jitter = 1e-6 * ((idx * 2654435761.0) % 97.0)
    return best_fit + spread + jitter
