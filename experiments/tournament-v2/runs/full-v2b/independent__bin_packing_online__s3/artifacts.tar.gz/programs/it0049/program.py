"""Adaptive best-fit bin packing priority heuristic.

We only see the item and the current bin remaining capacities.  The heuristic
scores each candidate bin by preferring a tight fit (small leftover), but with a
correction that discourages repeatedly dumping small items into nearly empty
bins and encourages grouping similar-sized residual gaps.

score = -(leftover) + alpha * fullness_signal + small_tiebreak
where fullness_signal rewards placing an item where the resulting bin will be
"filled to a similar level" as typical used bins, reducing fragmentation.
"""
import numpy as np


def priority(item, bins):
    # Remaining capacity after placing the item in each bin.
    leftover = bins - item

    # Fullness of the bin *before* placing the item: 0 (empty) .. 100 (full).
    fullness_before = 100 - bins

    # A simple, distribution-agnostic shaping: prefer tight fits (small leftover)
    # but mildly avoid leaving a tiny fragment unless the bin was already quite full.
    #
    # tight_fit: main negative cost.
    tight = leftover.astype(np.float64)

    # Penalize creating very small leftovers when the bin was not already nearly full.
    # This reduces the chance of stranding unusable slivers.
    small_leftover_penalty = np.where(
        (leftover < item) & (fullness_before < 80),
        (item - leftover) * 0.15,
        0.0,
    )

    # Reward placing into bins that are already fairly full, keeping empties open.
    fullness_reward = np.where(fullness_before >= 60, fullness_before * 0.08, 0.0)

    # Mild deterministic tie-break based on bin index order is implicit (ties keep first),
    # so no extra index term is needed.

    score = -tight - small_leftover_penalty + fullness_reward
    return score
