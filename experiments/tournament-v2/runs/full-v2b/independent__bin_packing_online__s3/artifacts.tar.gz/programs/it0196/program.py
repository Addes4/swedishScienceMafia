import numpy as np


def priority(item, bins):
    # Best-fit score: prefer the bin where remaining capacity after placing is smallest.
    remaining_after = bins - item
    # Base best-fit: smaller remaining_after -> higher score.
    score = -remaining_after.astype(np.float64)

    # Slight preference to place into already-used bins (remaining < 100)
    # over completely empty ones, to reduce bin count.
    used = bins < 100
    score += used * 1e-3

    return score
