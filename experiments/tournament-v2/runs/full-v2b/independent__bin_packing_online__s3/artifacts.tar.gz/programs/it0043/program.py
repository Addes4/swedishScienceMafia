import numpy as np

_state = {
    "total": 0,
    "count": 0,
}


def priority(item, bins):
    """Best-fit with mild anti-new-bin and exact-fill preferences."""
    rem = bins.astype(np.int64)
    # Fitting bins only, but keep a general expression.
    fit = rem >= item

    # Main rule: prefer smallest remaining capacity after placing (best fit).
    # This keeps bins tightly packed and tends to close bins sooner.
    after = rem - item

    # Score is negative of post-placement slack, so best fit gets highest score.
    score = -after.astype(np.float64)

    # Slight bonus for exactly filling a bin: helps close bins without waste.
    score += (after == 0).astype(np.float64) * 2.0

    # Discourage opening completely unused bins when existing partial bins fit.
    # This is the key to using fewer total bins.
    score -= (rem == 100).astype(np.float64) * 1.5

    # If item is large, be a bit more willing to start a new bin rather than
    # squeezing into a bin that will be left with awkward small space.
    if item >= 60:
        score += (rem == 100).astype(np.float64) * 0.5

    # Ensure non-fitting bins are never selected.
    score = np.where(fit, score, -1e18)

    return score
