import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin that leaves the smallest remaining capacity.
    # For equal remaining capacities, prefer the bin with less free space after placing.
    # Since bins is remaining capacity, smaller bins[index] is better.
    # We encode the tie-break by slightly penalizing larger remaining capacity.
    # Also favor using already partly-filled bins over untouched bins when possible.
    remaining = bins - item
    # Primary: tightest fit -> larger score for smaller remaining.
    # Secondary: avoid leaving bins at exactly full capacity? No, exact fill is ideal.
    # Tertiary: prefer bins that are more full before placement (smaller bins[index]).
    score = -remaining.astype(np.float64) - 1e-6 * bins.astype(np.float64)
    return score
