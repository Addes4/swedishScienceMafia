# EVOLVE-BLOCK-START
"""Best fit with a small empty-bin tie-break preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    This is essentially best fit: choose the bin whose remaining capacity is closest to
    the item size.  To reduce needless opening of new bins, a tiny bonus is given to empty
    bins (remaining capacity 100) when their fit difference is negligible.
    """
    leftover = bins - item
    # Prefer smaller leftover (tighter fit). Empty bins get a very small bonus so that
    # among similarly tight choices, an existing empty bin can win.
    score = -leftover.astype(np.float64)
    score += (bins == 100).astype(np.float64) * 1e-6
    return score
# EVOLVE-BLOCK-END
