# EVOLVE-BLOCK-START
"""Best fit with a mild preference against opening fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin with the smallest remaining capacity that still fits.
    # Empty bins have capacity 100 and are deprioritized slightly relative to
    # equally tight used bins, but still remain strong candidates when no used
    # bin fits well.
    score = -(bins - item).astype(np.float64)

    # Penalize full-capacity bins very slightly so that among bins with the same
    # residual after placement, a previously used (non-100) bin is chosen first.
    score[bins == 100] -= 1e-3

    return score
# EVOLVE-BLOCK-END
