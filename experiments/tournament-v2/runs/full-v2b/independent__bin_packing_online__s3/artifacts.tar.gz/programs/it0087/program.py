# EVOLVE-BLOCK-START
"""Best-fit with harmonic-class awareness to reduce bin count."""
import numpy as np


def priority(item, bins):
    """Score each bin. Higher score = preferred.

    The core rule is best-fit (smallest remaining capacity that still fits).
    We add two refinements:

    1. Strongly prefer open bins over unused bins (remaining capacity 100),
       so partially-filled bins get filled before new ones are opened.

    2. If the item is large and the bin's remaining capacity equals the item
       (perfect fit), score it a bit higher to lock in exact fills.

    Because the harness guarantees that bins shown here all fit the item
    (remaining capacity >= item), we can be aggressive.
    """
    remaining = bins.astype(np.int64)
    # Base: best fit -> penalize larger remaining capacity.
    score = -remaining

    # Perfect fit bonus (remaining == item), tie-breaker handled below anyway,
    # but boost to prefer exact matches.
    perfect = (remaining == item)
    score = score + perfect * 1000

    # Prefer non-empty bins (remaining < 100) over untouched bins.
    used = (remaining < 100)
    score = score + used * 50

    return score
# EVOLVE-BLOCK-END
