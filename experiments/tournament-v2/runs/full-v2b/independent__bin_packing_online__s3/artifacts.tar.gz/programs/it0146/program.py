import numpy as np


def priority(item, bins):
    """Score bins by best fit, with a small preference against opening new bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item

    # Best fit: smaller remaining capacity after placement is better.
    # Empty bins have rem = 100 - item and are still allowed.
    # Add a tiny penalty for empty bins so that, when fits are equivalent,
    # an already-open bin is preferred and fewer new bins are opened.
    empty = (bins == 100)
    return -rem - 1e-6 * empty
