import numpy as np


def priority(item, bins):
    """Best fit with a slight preference for reusing nonempty bins over empty ones.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Best-fit score: smaller residual is better.
    # A constant penalty for completely unused bins discourages opening new bins
    # unless the best used-bin choice is clearly worse.
    score = -residual.astype(np.float64)

    # Small preference against empty bins. Keep it tiny so true best-fit still wins
    # when a used bin would waste noticeably more space.
    score[bins == 100] -= 1e-6

    return score
