"""Online bin packing heuristic.

Use best fit with a tiny preference for bins that are already partially used
rather than an empty bin. Because the scoring harness breaks ties in bin order,
this remains deterministic and cheap.
"""
import numpy as np


def priority(item, bins):
    # Residual capacity after placing the item: smaller is better (best fit).
    residual = bins - item

    # Convert to a score where higher is better.
    # Primary criterion: minimize residual.
    score = -residual.astype(np.float64)

    # Secondary criterion: avoid opening empty bins when residuals are close.
    # An unused bin has residual = 100 - item. Penalize it slightly.
    empty_residual = 100 - item
    score[bins == 100] -= 1e-6

    # Tiny deterministic tie-break: prefer earlier bins by adding a negligible
    # decreasing term. (Ties already go to the first bin, so this is mostly
    # redundant, but it guards against floating-point artifacts.)
    n = bins.shape[0]
    if n:
        score += np.arange(n, dtype=np.float64) * (-1e-12)

    return score
