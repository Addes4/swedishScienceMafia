"""Online bin packing: best-fit with residual-utility tie-breaking.

The policy scores bins so that the tightest fit (smallest leftover) is preferred,
but among near-equal fits we reward leftovers that are likely to be matched by
future items of this distribution (Weibull-shaped, mean ~40).  This keeps bins
from being fragmented into unusable small residues while still consolidating
loads aggressively.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest
    (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item  # >= 0 for all shown bins

    # Primary term: strongly prefer the tightest fit (smallest leftover).
    score = -leftover.astype(np.float64)

    # Secondary term: a leftover that equals a plausible future item size is
    # valuable because that bin can later be nearly closed with one item.
    # Reward residues near the typical item size band (~35..55), and especially
    # exact matches.  Small epsilon so it only breaks near-ties.
    utility = np.zeros_like(score)
    good = (leftover >= 30) & (leftover <= 60)
    utility[good] = 1.0
    exact = (leftover == 40) | (leftover == 50) | (leftover == 30) | (leftover == 35) | (leftover == 45)
    utility[exact] = 2.0

    # Very small residues are wasteful; penalize them slightly.
    small = leftover < 8
    utility[small] -= 0.5

    score = score + 0.01 * utility

    return score
