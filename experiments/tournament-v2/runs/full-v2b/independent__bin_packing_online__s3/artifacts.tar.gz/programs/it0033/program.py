import numpy as np


def priority(item, bins):
    rem = bins - item
    # Primary: strongly prefer very small residuals after insertion.
    # Secondary: for similar residuals, prefer bins that leave less total capacity
    # (i.e. more-filled bins), which tends to preserve empty bins for later.
    return -(rem * 1000 + bins)
