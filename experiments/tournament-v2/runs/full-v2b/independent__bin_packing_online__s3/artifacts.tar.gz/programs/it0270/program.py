import numpy as np


def priority(item, bins):
    """Rank bins using an adaptive best-fit rule with fragmentation-aware penalties."""
    # Remaining capacity after placing the item.
    rem_after = bins - item

    # Primary score: prefer bins where the item fits most tightly.
    # Use a strong negative weight so smaller remaining capacity wins.
    score = -rem_after.astype(np.float64)

    # Fragmentation penalty: very low remaining capacities can create hard-to-use holes.
    # Penalize bins that would become nearly full but not completely full.
    # The penalty is strongest when rem_after is small but positive.
    # Avoid penalizing exact fills (rem_after == 0), as those are ideal.
    tight = (rem_after > 0) & (rem_after < 15)
    score[tight] -= 0.5 * (15 - rem_after[tight])

    # Slight preference for bins that are already partially used over completely empty bins
    # when the item does not fill them well, to avoid scattering small items.
    # This helps consolidate medium-size items into fewer bins.
    empty = (bins == 100)
    score[empty] -= 0.01 * item

    return score
