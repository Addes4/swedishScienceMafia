import numpy as np


def priority(item, bins):
    """Best fit, with unused bins kept behind all partially used bins.

    bins contains remaining capacities. A score of the form -(remaining - item)
    ranks tighter fits higher. We also add a tiny preference for earlier bins
    among equal residuals, and an offset that makes unused bins less attractive
    than any used bin that can fit the item.
    """
    n = len(bins)
    # residual capacity after placing the item
    residual = bins - item

    scores = -residual.astype(np.float64)

    # tiny index tie-breaker: lower index gets slightly higher score on ties
    scores -= np.arange(n, dtype=np.float64) * 1e-9

    # Do not open unused bins while a nonempty fit exists.
    # A used bin has remaining capacity < 100. If item fits, residual < 100.
    used = bins < 100
    scores[~used] -= 1e6

    return scores
