"""Online bin packing: best fit with a learned tie-break preference.

Strategy
--------
The dominant rule is best fit: choose the bin that leaves the least remaining
space after the item is placed.  This is known to be very strong for online
bin packing with i.i.d. items.  Pure best fit can be improved slightly by
tie-breaking among bins that give the same residual capacity, and by nudging
the choice toward residuals that tend to align with common item sizes.

Items are drawn from a Weibull-shaped distribution with mean ~40 over 1..100.
We build a static histogram of "useful" residual capacities: residuals that
match common item sizes or complements of common item sizes are slightly
preferred, because they can later be filled exactly or nearly exactly.

The rule is fully online and deterministic given the current bins, so it is
robust across unseen instances.
"""
import numpy as np

# Prior over item sizes for a Weibull-shaped distribution with mean ~40.
# We use a smooth approximation; exact shape is not critical, only the
# qualitative fact that mid/large sizes around 30-55 dominate.
_SIZES = np.arange(1, 101, dtype=np.float64)
_MEAN = 40.0
# Weibull with shape k=1.5 scaled to mean 40, truncated to [1,100].
_K = 1.5
_GAMMA = 0.9026  # Gamma(1 + 1/k) for k=1.5
_SCALE = _MEAN / _GAMMA
_w = (_K / _SCALE) * (_SIZES / _SCALE) ** (_K - 1.0) * np.exp(-(_SIZES / _SCALE) ** _K)
_w = np.clip(_w, 1e-9, None)
_P = _w / _w.sum()

# Benefit of a residual capacity r: how likely it is to be exactly fillable
# by some arriving item, plus how close it is to useful complements.
_benefit = np.zeros(101, dtype=np.float64)
for r in range(0, 101):
    # probability that an item exactly fills residual r
    if 1 <= r <= 100:
        exact = _P[r - 1]
    else:
        exact = 0.0
    # probability that an item leaves a small residual (good packing)
    # residual r means future need is r; small r is good
    tight = np.exp(-r / 25.0)
    _benefit[r] = 2.0 * exact + 0.35 * tight


def priority(item, bins):
    """Best fit, with a tiny learned preference among equal-residual bins.

    Highest score wins; ties go to the first bin.
    """
    # remaining capacity after placing the item
    rem = bins - item
    # base score: strongly prefer smaller remaining capacity (best fit)
    # use large multiplier so best-fit dominates completely
    score = -1000.0 * rem.astype(np.float64)
    # tie-break: prefer residuals that are useful for future items
    # (only matters when two bins give exactly the same rem)
    score += _benefit[np.clip(rem, 0, 100)]
    return score
