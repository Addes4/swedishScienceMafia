"""Improved online bin packing: exact-fit preference plus best fit with end-game bias."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer exact fits, then tightest fit, with slight end-game waste bias.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (only bins that fit the item).
    """
    rem = bins.astype(np.int64, copy=False)
    # Distance from an exact fit
    gap = np.abs(rem - item)
    # Base score: tightest fit (smallest gap), exact fit gets top score
    score = -gap.astype(np.float64)

    # Strongly favor exact fits (avoid creating any leftover waste).
    exact = (rem == item)
    score[exact] += 1000.0

    # Favor bins that are already partially used (smaller remaining capacity = tighter)
    # over entirely empty bins when possible, to consolidate.
    score -= rem.astype(np.float64) * 0.001

    return score
