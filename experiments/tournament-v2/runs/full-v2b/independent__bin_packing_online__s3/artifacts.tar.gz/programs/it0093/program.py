import numpy as np

_state = {
    "obs": 0,
    "sum": 0.0,
}


def priority(item, bins):
    """Score bins for online bin packing.

    The main rule is best fit: prefer the bin with the smallest remaining capacity
    that still fits the item.  A mild adaptive term makes fully empty bins slightly
    less attractive when many prior items were small, and slightly more attractive
    when prior items were large, which helps avoid fragmenting fresh bins too early
    without hurting common Weibull-shaped workloads.
    """
    st = _state
    st["obs"] += 1
    st["sum"] += float(item)

    # Running mean item size.  Clamp to avoid weird early behavior.
    mean = st["sum"] / st["obs"] if st["obs"] else 40.0
    if mean < 1.0:
        mean = 1.0
    elif mean > 100.0:
        mean = 100.0

    # s is high for tight fits.  For capacity c, tightness reward is -(c - item),
    # with a small penalty for opening/using empty bins.
    tight = -(bins - item).astype(np.float64)

    # Normally, an empty bin should not be chosen over a partially used one unless
    # it yields a better fit.  The penalty below is small enough to mainly affect ties.
    empty_penalty = (bins == 100) * 0.15 * (40.0 / mean)

    # Slightly prefer bins whose resulting remainder will be very small or very large.
    # Small remainder means compact packing; large remainder preserves flexibility.
    rem = (bins - item).astype(np.float64)
    rem_bonus = np.where((rem >= 0) & (rem <= 10), 0.10 * (11.0 - rem), 0.0)
    large_bonus = np.where(rem >= 80, 0.05 * (rem - 79.0), 0.0)

    return tight - empty_penalty + rem_bonus + large_bonus
