import numpy as np

# --- small online state ---
_state = {
    "count": 0,
    "sum_item": 0.0,
    "sum_cap_used": 0.0,
    "warmup": 80,
}

# Preferred minimum residual after placing an item.
# Small residuals (< ~10) are often hard to reuse, so penalize them a bit.
_MIN_USEFUL_GAP = 8.0


def priority(item, bins):
    """Score bins for online bin packing.

    The main rule is best-fit: prefer the fullest bin that still fits.
    Small adaptive corrections discourage creating tiny unusable residuals and
    mildly incorporate recent packing efficiency.
    """
    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]

    # Best fit base: smaller residual is better.
    residual = bins - float(item)
    score = -residual

    # Penalize leaving a very small gap, but only when that gap is real
    # (i.e. not the trivial full-bin residual 0).  This helps avoid scattered
    # tiny holes while still preferring exact fits strongly.
    tiny_gap = (residual > 0.0) & (residual < _MIN_USEFUL_GAP)
    if np.any(tiny_gap):
        # A smooth penalty: closer to 0 gap gets smaller penalty; near the
        # threshold gets almost no penalty.
        score -= np.where(tiny_gap, (_MIN_USEFUL_GAP - residual) * 0.45, 0.0)

    # Slight preference for used bins over completely empty bins when residuals
    # are comparable.  Empty bins have residual == 100 - item, so this mainly
    # breaks ties among choices that would otherwise waste an unused bin.
    if item < 100:
        empty_residual = 100.0 - float(item)
        score -= np.where(residual == empty_residual, 0.15, 0.0)

    # Adaptive smoothing based on observed average fill.  This is deliberately
    # very small and acts only as a tie/near-tie adjustment.
    _state["count"] += 1
    _state["sum_item"] += float(item)

    # For bins that are currently in use, favor those whose remaining capacity
    # is closest to the average item size: such bins are more likely to close
    # well with future items.  Again small weight.
    avg_item = _state["sum_item"] / _state["count"]
    avg_gap_target = max(1.0, min(50.0, avg_item * 0.25))
    if n > 0:
        gap_dist = np.abs(residual - avg_gap_target)
        score -= gap_dist * 0.002

    # Ensure no NaNs and return a numpy array.
    if np.any(~np.isfinite(score)):
        score = np.where(np.isfinite(score), score, -1e18)

    return score
