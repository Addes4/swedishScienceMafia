import numpy as np

_state = {"n": 0, "total": 0.0}


def priority(item, bins):
    """Best fit with mild consolidation pressure for small items."""
    # primary: minimize remaining capacity left after placement (best fit)
    leftover = bins - item

    # small extra pressure only for small items, to help pack near-full bins
    s = _state
    s["n"] += 1
    s["total"] += item

    # Prefer bins that become tightly filled, but never worse than pure best-fit ordering.
    # Scale is small enough not to affect tie-breaking among distinct capacities much.
    score = -leftover.astype(np.float64) * 1024.0

    # For small items, slightly prefer bins that were already relatively full
    # (i.e., smaller remaining capacity before insertion), encouraging consolidation.
    if item <= 40:
        score -= bins.astype(np.float64)

    return score
