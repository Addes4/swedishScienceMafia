import numpy as np

# Module-level mutable state (persists across calls, reset implicitly per process/instance).
_state = {
    "n": 0,
    "sum": 0.0,
    "sizes": [],   # recent item sizes
    "cutoff": 50.0,
}


def priority(item, bins):
    """Rank bins by a hybrid best-fit / reserve heuristic."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    if len(st["sizes"]) < 200:
        st["sizes"].append(item)
    else:
        # random-ish replacement to keep a rolling sample
        st["sizes"][st["n"] % 200] = item

    # Estimate a cutoff each call from observed mean (cheap, robust).
    mean_item = st["sum"] / st["n"]
    # Protect bins with remaining capacity above roughly 2x mean item for big items.
    cutoff = max(30.0, min(80.0, 1.6 * mean_item))

    rem_after = bins - item

    # Base: prefer tight fits (lower remaining after placement) => higher score.
    # Near-exact fits get a big bonus.
    score = -rem_after.astype(np.float64)

    # Bonus for near-exact fit
    near_exact = rem_after <= 2
    score += near_exact * 40.0

    # Reserve heuristic: if item is small/medium, prefer bins that will end up
    # relatively full (below cutoff), but don't touch very empty bins.
    # If item is large, prefer the emptiest bins that still fit.
    if item < cutoff:
        # penalize leaving a bin too empty (big remaining after placement)
        too_empty = rem_after > cutoff
        score -= too_empty * 25.0
    else:
        # large item: strongly prefer bins with more remaining capacity (better fit for big items)
        score += bins.astype(np.float64) * 0.8

    return score
