import numpy as np


def priority(item, bins):
    """Best-fit style priority with exact-fit and fragmentation avoidance.

    The item goes into the bin with the highest score (first on ties).

    Main ideas:
    - Exact fits are strongly preferred.
    - Otherwise, prefer bins where the leftover is either large enough to be useful
      for future items, or very small (so it does not waste much capacity).
    - Avoid creating medium-sized fragments that are hard to fill well.
    """
    rem_after = bins - item  # remaining capacity if item is placed here

    # Exact fit: strongly best.
    exact = (rem_after == 0)

    # Small leftover is good: little waste.
    small = np.maximum(0, 1.0 - rem_after / 20.0)

    # Large leftover is also useful: keeps bin reusable for big items.
    # Peak usefulness around rem_after ~ 50-80, but never beat exact.
    useful = np.exp(-((rem_after - 65.0) ** 2) / (2.0 * 25.0 ** 2))

    # Medium leftovers (around 20-35) are generally bad because they fragment capacity.
    bad_mid = np.exp(-((rem_after - 28.0) ** 2) / (2.0 * 8.0 ** 2))

    score = 10.0 * exact + 1.0 * small + 0.6 * useful - 0.5 * bad_mid

    # Slight tie-break: prefer more empty bins? Actually prefer fuller bins if scores equal,
    # but the above already encodes fit quality. Keep as float array.
    return score
