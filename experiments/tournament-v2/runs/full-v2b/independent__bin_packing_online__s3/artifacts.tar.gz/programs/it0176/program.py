"""Best-fit variant for online bin packing with Weibull-shaped item sizes.

Idea:
- Primary objective: choose the feasible bin whose remaining capacity is closest
  to the item size (classic best-fit — minimizes leftover waste).
- Secondary objective: among equal left-over capacities, prefer bins that are
  already in use (remaining < 100) over completely empty bins, which tends to
  reduce fragmentation by filling bins up before opening new ones.
- Tertiary tie-break: prefer the bin with smaller remaining capacity (fuller
  bin) to keep early bins packed.

Scoring: priority = -(remaining - item) * K - penalty, where K makes best-fit
dominant and penalty is tiny; ties then follow the bin order.
"""

import numpy as np


def priority(item, bins):
    # Distance from exact fit: 0 is perfect fit, larger means more wasted space.
    dist = bins - item

    # Classify: bins that are already in use vs. completely unused (cap 100).
    in_use = bins < 100

    # Score:
    #   -dist strongly dominates; multiply by a large constant.
    #   tiny bonus for in-use bins (prefer filling existing bins before new),
    #   tiny bonus for fuller bins among ties.
    score = -dist.astype(np.float64) * 1000.0
    score += in_use.astype(np.float64) * 1.0
    score += (100 - bins).astype(np.float64) * 0.001

    return score
