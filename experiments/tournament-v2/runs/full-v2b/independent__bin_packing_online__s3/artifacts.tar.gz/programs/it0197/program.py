import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin with the smallest remaining capacity that still fits the item.
    # Score = -(remaining capacity after placing item) = item - remaining capacity.
    # Ties go to the first bin. To improve slightly, add a tiny bonus for fuller bins
    # (smaller remaining capacity) which is already captured, but we can also add a
    # small preference against leaving large empty gaps.
    #
    # We use negative remaining capacity (after placement) so the tightest fit wins.
    # A tiny secondary term breaks ties in favor of bins with smaller remaining capacity
    # (i.e., bins already more loaded), which tends to reduce fragmentation.

    remaining_after = bins - item  # >= 0 for bins that fit

    # Primary: minimize remaining capacity (best fit).
    # Secondary: among equal fit, prefer bin with smaller original remaining capacity.
    # Both align, so just use best fit. Add a tiny epsilon based on bin index? No.
    return -remaining_after
