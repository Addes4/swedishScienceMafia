"""Online bin packing: improved best fit with fresh-bin penalty.

Strategy: rank bins by the residual capacity they would leave after placing the
item (best fit => smallest residual first).  Fresh/unused bins (capacity 100)
get a small penalty so that the packer prefers to fill already-open bins before
opening a new one, which reduces the number of bins used.  Ties are broken by
bin order, so the first (lowest-index) bin wins, encouraging consolidation.
"""
import numpy as np


def priority(item, bins):
    # residual capacity each bin would have after receiving the item
    residual = bins - item
    # Higher score = better.  Best fit: prefer smallest residual.
    # Add a small penalty for unused bins (residual == 100 - item, i.e. bins == 100)
    # so that open bins are favored, but never outweigh the residual ordering.
    score = -residual.astype(np.float64)
    # Penalty strictly smaller than the minimum gap between distinct residuals (1)
    score -= (bins == 100) * 0.1
    return score
