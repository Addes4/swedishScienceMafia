import numpy as np

# State kept across calls: estimate of item mean/size distribution and common heap helper.
# The rule is mostly deterministic "best fit", but with a slight bonus for exact fits and
# for bins that are already partially full, which tends to reduce the number of opened bins.

_state = {
    "count": 0,
    "sum": 0,
}

def priority(item, bins):
    """Score bins for online bin packing.

    Highest score wins.  We prefer the fullest bin into which the item fits (tightest fit),
    and slightly prefer bins that already contain something, while avoiding creating tiny
    leftover capacity when an exact fit is available.
    """
    # Track only a running mean; not required, but can be useful if one wants adaptive rules.
    _state["count"] += 1
    _state["sum"] += int(item)

    rem = bins
    residual = rem - item

    # Base: tightest fit = smallest residual (largest remaining capacity close to item)
    # score = -residual, so bin with residual 0 gets score 0, residual large gets negative.
    score = -residual.astype(np.float64)

    # Bonus for exact fit (residual == 0), strongly preferred.
    score += (residual == 0) * 1000.0

    # Small bonus for bins that are already used (remaining < 100), to discourage opening new bins.
    score += (rem < 100) * 0.01

    # Avoid leaving extremely tiny residual (1..2) unless exact fit: those waste capacity
    # and often block future items.  A tiny penalty compared to other near fits.
    score -= ((residual > 0) & (residual <= 2)) * 0.5

    return score
