import numpy as np


def priority(item, bins):
    """Rank bins by best-fit with a mild preference for nearly-closed bins.

    The score favors leaving the smallest possible residual capacity after
    placing the item.  A small extra bonus is given to bins that become
    completely full (residual 0), and a very small penalty is applied to
    completely empty bins so that we do not open new bins unnecessarily.
    """
    residual = bins - item

    # Base: prefer smallest residual (more tightly packed).
    score = -residual.astype(np.float64)

    # Strong bonus for bins that would be exactly filled.
    score += 1000.0 * (residual == 0)

    # Tiny penalty for opening a brand-new bin (residual == 100 after placement
    # means the bin was empty before, i.e. bins[i] == 100).
    score -= 0.01 * (bins == 100)

    return score
