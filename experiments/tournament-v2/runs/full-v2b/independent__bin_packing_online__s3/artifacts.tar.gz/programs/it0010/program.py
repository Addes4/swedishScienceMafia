"""Adaptive best-fit heuristic for online bin packing.

Primary rule: best fit (prefer the bin that leaves the smallest non-negative
leftover after placing the item).

Secondary/tie-breaking rule: when several bins leave similar leftovers, prefer
the one whose leftover is either exactly 0 or a "useful" residual size, where
usefulness is estimated from the running distribution of item sizes seen so
far.  This encourages packing that keeps bins free of awkward small gaps.

The function keeps only O(1) state (running mean and a small histogram) so it
stays fast across 5000 calls.
"""

import numpy as np

# ---------------------------------------------------------------
# Persistent statistics about the stream of items seen so far.
# ---------------------------------------------------------------
_ITEM_HIST = np.zeros(101, dtype=np.int64)   # counts of item sizes 1..100
_ITEM_COUNT = 0
_ITEM_SUM = 0.0

# Precomputed "useful" residual bonus table, refined online.
# A residual r is considered useful if many items in the observed stream
# would fit exactly into it (small leftover after placing) or if r is small
# enough to be easily filled later.
_LAST_UPDATE = -1


def _update_stats(item):
    global _ITEM_COUNT, _ITEM_SUM, _LAST_UPDATE
    _ITEM_HIST[item] += 1
    _ITEM_COUNT += 1
    _ITEM_SUM += item
    _LAST_UPDATE = _ITEM_COUNT


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (first on ties)."""
    _update_stats(item)

    b = np.asarray(bins, dtype=np.int64)

    # Leftover capacity if the item is placed into each bin.
    leftover = b - item

    # Primary term: strongly prefer the tightest fit (smallest leftover).
    # Using a negative leftover so higher score == better.
    # Scale so that primary differences dominate secondary bonuses.
    score = -leftover.astype(np.float64) * 1000.0

    # ---------------------------------------------------------------
    # Secondary term: reward leftover values that are "useful".
    #
    # A leftover r is useful if it can accommodate a decent number of the
    # item sizes that we have seen so far, weighted by their frequency.
    # Specifically, count how many upcoming items (in expectation) would
    # nicely fit into r; residual 0 gets a bonus for being perfectly full.
    # ---------------------------------------------------------------
    if _ITEM_COUNT > 1:
        total = float(_ITEM_COUNT)
        # Probability vector over sizes 1..100.
        p = _ITEM_HIST[1:].astype(np.float64) / total  # index i -> size i+1

        # For each distinct leftover value present, estimate usefulness.
        uniq = np.unique(leftover)
        usefulness = np.empty(uniq.shape[0], dtype=np.float64)
        for idx, r in enumerate(uniq):
            if r <= 0:
                usefulness[idx] = 0.0
                continue
            # Probability mass of items that fit in r.
            # Reward leaving a residual that exactly matches a frequent size
            # (so a single future item can complete the bin).
            if r <= 100:
                # mass of items <= r (fit) plus exact-match bonus
                fit_mass = float(p[:r].sum())
                exact = float(p[r - 1]) if r >= 1 else 0.0
                usefulness[idx] = fit_mass + 3.0 * exact
            else:
                usefulness[idx] = 1.0

        # Map usefulness back to each bin.
        # Build a lookup from residual value -> usefulness.
        look = {int(r): usefulness[i] for i, r in enumerate(uniq)}
        use_vec = np.array([look[int(r)] for r in leftover], dtype=np.float64)

        # Small weight; never overrides the primary best-fit ordering for
        # clearly different leftovers.
        score += use_vec * 1.0

    return score
