"""Online bin packing heuristic: adaptive best-fit with a reserved pool of emptier bins.

Idea: pure best-fit packs tightly and is strong, but it can waste space by closing
bins too early. We add a mild bias: when many bins already exist, prefer putting
an item into the currently tightest-fitting bin, but keep a small number of
"fresh" (near-empty) bins reserved as a buffer for future large items. Concretely,
we rank bins by (residual space after placement), with a tiny secondary preference
for bins that are neither the emptiest nor the fullest when the item is large.
"""

import numpy as np


def priority(item, bins):
    # residual space if the item is placed in each bin
    residual = bins - item  # bins all fit the item, so residual >= 0

    # Base: best fit -> smallest residual gets highest score.
    score = -residual.astype(np.float64)

    # Number of bins currently offered (unused bins have residual capacity 100).
    total = bins.shape[0]

    # Estimate how "crowded" the packing is: count non-empty bins by using the
    # fact that unused bins have capacity exactly 100.
    used = int(np.count_nonzero(bins != 100))

    # If the instance is still young, don't over-reserve; if it has grown large,
    # keep a small pool of emptier bins available for big items.
    if used > 8:
        # Fraction of currently used bins.
        fullness = used / float(total)
        # Reserve pressure grows with fullness. Scale small so best-fit still dominates.
        pressure = 0.02 * fullness * used

        # Penalize placing into a bin that becomes very full (residual near 0),
        # to avoid exhausting tight bins when we might need them for medium items.
        # Also slightly penalize placing into very empty bins (could be reserved).
        # residual ranges 0..(100-item)
        max_res = 100 - item if item < 100 else 1
        norm = residual.astype(np.float64) / float(max_res)

        # Prefer moderately filled bins over completely full ones.
        score -= pressure * (1.0 - norm)

        # Slight incentive to keep at least a few near-empty bins free: penalize
        # consuming a bin whose residual capacity is very large (i.e. almost unused),
        # but only mildly.
        almost_empty = (residual > 0.8 * max_res).astype(np.float64)
        score -= 0.5 * pressure * almost_empty

    return score
