import numpy as np


class _State:
    def __init__(self):
        self.calls = 0


_state = _State()


def priority(item, bins):
    """Score bins to approximate best-fit with light empty-bin reservation.

    Highest score wins; ties go to the earliest bin.  The main ordering is
    best-fit: prefer the bin with the smallest remaining capacity that still
    fits.  A small penalty on untouched empty bins delays opening a new bin,
    which usually helps online packing when item sizes are variable.
    """
    remaining_after = bins - item
    empty = bins == 100

    # Base: best fit.  Larger score means better fit.
    score = -remaining_after

    # Slight preference against opening brand-new bins.  This is especially
    # useful early on, but keeping it constant is safer and does not overfit.
    score = score.astype(np.float64)
    score[empty] -= 0.25

    # Prefer tighter fits among non-empty bins by a tiny amount proportional
    # to how little space would remain, breaking near-ties deterministically.
    score -= remaining_after.astype(np.float64) * 1e-6

    return score
