import numpy as np


def priority(item, bins):
    """Best-fit with a reserve for empty bins.

    Prefer placing the item into the tightest-fitting already-open bin.
    Strongly discourage using a fresh (empty) bin unless necessary,
    so that partially filled bins get consolidated and small residuals
    stay available for small future items.
    """
    # Penalty for using an empty bin (remaining capacity 100).
    # Make it larger for small items (which fit many places) and
    # smaller for big items (which may genuinely need a new bin).
    empty_penalty = 1000.0 + (100 - item) * 10.0

    # Tightest fit: smaller leftover is better -> higher score.
    # Empty bins get a large negative bonus subtracted.
    score = -(bins - item).astype(np.float64)

    empty_mask = bins == 100
    score[empty_mask] -= empty_penalty

    return score
