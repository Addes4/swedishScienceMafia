import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.s = 0.0
        self.s2 = 0.0
        # penalty exponent mu: score = -(bins-item) - alpha * (bins-after)^mu
        self.alpha = 0.12
        self.mu = 1.0


_state = _State()


def _reset():
    _state.__init__()


def priority(item, bins):
    st = _state
    st.n += 1
    st.s += item
    st.s2 += item * item

    # Adapt: mean item ~40. Weibull-shaped. Tune alpha slightly by mean.
    if st.n > 50:
        mean = st.s / st.n
        var = max(st.s2 / st.n - mean * mean, 0.0)
        sd = var ** 0.5
        # If items are small, prefer tighter (more negative penalty); if large, allow more open bins.
        # alpha scaled around mean 40.
        alpha = 0.12 * (40.0 / max(mean, 1.0)) ** 0.5
        # mu near 1, adjusted modestly
        mu = 1.0 + 0.15 * (sd / max(mean, 1.0) - 0.5)
        mu = min(max(mu, 0.7), 1.4)
        if abs(alpha - st.alpha) > 1e-6 or abs(mu - st.mu) > 1e-6:
            st.alpha = alpha
            st.mu = mu

    after = bins - item
    # Best fit base: prefer smallest after (tight fit)
    base = -after.astype(np.float64)
    # Penalty on leftover fragmentation depending on fill level
    pen = st.alpha * np.power(after.astype(np.float64), st.mu)
    score = base - pen
    return score
