"""Online bin packing heuristic: best fit with a small bonus for near-perfect fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Base score: prefer bins that are filled as tightly as possible (best fit).
    score = -remaining.astype(np.float64)
    # Small extra bonus when placing leaves little, or ideally no, leftover space.
    score += 0.01 / (1.0 + remaining)
    return score
