"""Weighted best fit: prefer the tightest bin, reward exact fills."""
import numpy as np


def priority(item, bins):
    """Score each bin: tightest fit wins, with a bonus for exactly filling a bin."""
    rem = bins - item          # remaining capacity after placing the item
    score = -rem.astype(np.float64)          # prefer smallest leftover (best fit)
    score += (rem == 0).astype(np.float64) * 0.5  # bonus for perfect fill
    return score
