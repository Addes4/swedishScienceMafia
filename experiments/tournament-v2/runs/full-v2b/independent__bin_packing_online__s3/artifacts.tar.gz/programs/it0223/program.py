import numpy as np


def priority(item, bins):
    """Best-fit style priority with tie-breaking and small adaptive bias.

    The item goes to the bin with the highest score. We want to pack tightly
    (Best Fit), but also prefer non-empty bins slightly so that empty bins
    stay available, and handle ties deterministically via bin order.
    """
    # Primary: tightest fit -> smaller (remaining - item) is better.
    # score = -(bins - item) = item - bins  (same as baseline)
    base = item - bins.astype(np.float64)

    # Tie-breaker / secondary term: prefer fuller (smaller remaining) bins
    # among those with equal slack. Reward lower remaining capacity slightly.
    # Scale so it cannot overcome a 1-unit difference in slack.
    tie_break = -0.001 * bins.astype(np.float64)

    # Small preference for bins whose remaining capacity is near a typical
    # item size (mean ~40). This mildly encourages leaving large empty bins.
    # Only apply to bins that are already in use (remaining < 100).
    remaining = bins.astype(np.float64)
    near_typical = np.where(remaining < 100.0,
                            -0.0005 * np.abs(remaining - 40.0),
                            0.0)

    return base + tie_break + near_typical
