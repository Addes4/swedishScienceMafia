"""Online best-fit variant: prefer tight fits, but slightly penalize opening new bins and
avoid leaving very small residual capacities (hard-to-fill gaps)."""
import numpy as np


def priority(item, bins):
    # bins is a numpy int64 array (a copy), length = number of bins that fit the item.
    # Higher score -> chosen (ties to lower index).
    residual = bins - item  # remaining capacity after placing item

    # Best-fit term: prefer smallest residual (tightest fit).
    score = -residual.astype(np.float64)

    # Small bonus for bins that already have some content (not brand-new bins),
    # to avoid scattering items across many fresh bins unnecessarily.
    score += 0.01 * (100 - bins)

    # Penalize leaving tiny residuals (e.g. 1..3) which are hard to fill later.
    tiny = (residual <= 3) & (residual > 0)
    score -= 0.5 * tiny

    return score
