"""Improved: best fit with preference weighted toward bins already holding items."""
import numpy as np


def priority(item, bins):
    # Best-fit: prefer bin whose remaining capacity is closest to fitting the item exactly.
    # That is equivalent to maximizing -(bins - item) or minimizing bins.
    # To favor partially filled bins over empty ones when equally good, we add a small
    # preference for bins with less remaining capacity (i.e., more full), which is what
    # best-fit already does. A slight tweak: avoid choosing unused bin (rem==100) when
    # a used bin fits equally well; best-fit already does this because a used bin will
    # have rem < 100 and thus be preferred over 100 for the same item.
    #
    # We simply maximize: -(bins) so the smallest remaining capacity (but still >= item)
    # gets the highest score. This is classic Best-Fit Decreasing online.
    return -(bins)
