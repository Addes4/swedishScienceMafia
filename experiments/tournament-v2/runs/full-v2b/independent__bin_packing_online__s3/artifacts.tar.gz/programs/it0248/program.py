# EVOLVE-BLOCK-START
"""Best fit with tie-break toward the most-loaded bin (smallest current remaining capacity)."""
import numpy as np


def priority(item, bins):
    """Score = tightest fit after placing (minimize leftover), tie-break by fullest bin."""
    leftover = bins - item  # bins only contains bins where item fits, so leftover >= 0
    # Primary: minimize leftover (tightest fit). Secondary: minimize current remaining capacity
    # (i.e., prefer the most-loaded bin). Combine with a large weight and int-friendly ordering.
    return -(leftover * 1024 + bins)
# EVOLVE-BLOCK-END
