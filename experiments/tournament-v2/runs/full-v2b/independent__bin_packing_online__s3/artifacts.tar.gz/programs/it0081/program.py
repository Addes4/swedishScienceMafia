"""Online bin packing: best fit with a slight preference for reusing partially filled bins."""
import numpy as np


def priority(item, bins):
    # Best fit: preferentially use the bin with the smallest remaining capacity that fits.
    # Add a tiny penalty for unused bins (capacity 100) to discourage opening new bins
    # unless necessary. The penalty is small enough not to override fit quality.
    score = -(bins - item).astype(np.float64)

    # Discourage brand-new bins slightly. Scale relative to item size so large items
    # are not forced into tight spaces just to avoid a new bin.
    new_bin_penalty = 1e-3 * item
    score[bins == 100] -= new_bin_penalty

    return score
