"""Improved online bin packing priority rule.

Idea:
- Base ranking is best fit: prefer the bin where the item leaves the least free space.
- However, leaving a very small free space can waste capacity just as leaving a huge
  free space can. We add a mild bonus for bins whose resulting free space is either
  zero or sufficiently large to likely fit another typical item.
- We estimate typical item size online from past arrivals and use that to judge whether
  a residual capacity is "useful" (likely to fit future items) or "dead" (too small).

This keeps the rule distribution-adaptive without tuning to any individual instance.
"""

# EVOLVE-BLOCK-START
import numpy as np


# Online running statistics: exponential moving average of item size.
_mean_item = 40.0
_alpha = 0.05


def priority(item, bins):
    """Rank bins for an arriving item using an online adaptive best-fit variant.

    Parameters
    ----------
    item : int
        Size of the arriving item, 1..100.
    bins : numpy.ndarray
        Remaining capacities of bins the item fits in, int64.

    Returns
    -------
    numpy.ndarray
        Scores, same length as bins. Highest score wins; ties go to first bin.
    """
    global _mean_item

    # Update online estimate of the item-size distribution mean.
    _mean_item = (1.0 - _alpha) * _mean_item + _alpha * float(item)

    # Resulting free space if we place the item in each candidate bin.
    residual = bins - item  # nonnegative because harness only shows fitting bins

    # Typical future item size estimate, bounded to avoid extreme behavior.
    typical = max(1.0, min(100.0, _mean_item))

    # Base: best fit. Smaller residual is better, so negate it.
    score = -residual.astype(np.float64)

    # Reward residuals that are "useful": zero, or at least large enough that a
    # typical item from the learned distribution is likely to fit later.
    useful = (residual == 0) | (residual >= typical)
    score += useful.astype(np.float64) * 0.5

    # Slight additional preference for residuals close to a multiple-fit boundary:
    # if residual can exactly fit an integer number of typical items, it is efficient.
    # This is a soft tie-breaker, not a hard rule.
    fit_count = np.floor(residual.astype(np.float64) / typical)
    leftover = residual.astype(np.float64) - fit_count * typical
    # Penalize leftover that is small but nonzero, since it may be unusable.
    small_leftover = (leftover > 0) & (leftover < typical * 0.5)
    score -= small_leftover.astype(np.float64) * 0.25

    return score
# EVOLVE-BLOCK-END
