import numpy as np


def priority(item, bins):
    """Score bins by best fit: minimize leftover capacity after placing the item."""
    # Highest score = smallest remaining capacity after placement.
    # Ties naturally go to the first bin; no extra preference needed.
    return -(bins - item)
