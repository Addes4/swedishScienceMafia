import numpy as np

# Best-fit with a mild "fill small gap" tiebreaker.
# The primary score is negative remaining capacity after placing the item,
# i.e. best fit. A tiny secondary term prefers bins whose remaining capacity
# is close to the item size, which helps reduce fragmentation without needing
# global state or future knowledge.

_STATE = {"count": 0}


def priority(item, bins):
    _STATE["count"] += 1

    # Primary: best fit => minimize leftover capacity (bins - item).
    leftover = bins - item

    # Secondary: prefer near-exact fits, already encoded by leftover.
    # Use a very small perturbation based on bin index parity to break ties
    # deterministically and avoid pathological ordering effects.
    idx = np.arange(bins.shape[0], dtype=np.int64)

    # Tiny index term: earlier bins slightly preferred, but negligible vs fit.
    score = -leftover.astype(np.float64) - 1e-9 * idx

    return score
