import numpy as np

# Online-learning best-fit-with-residual-preference.
# Keeps a histogram of residuals (bin capacity after item is placed) observed so far,
# initialized with a geometric prior favoring small residuals.

_CAP = 100
_NBINS = 101  # residuals 0..100

_prior_w = 0.02  # weight of the smooth prior
_prior_decay = 0.88

# Histogram over residuals. Index r -> count/score.
_hist = None


def _init_hist():
    global _hist
    # Prior: prefer residual 0 strongly, decaying slowly for larger residual.
    w = np.empty(_NBINS, dtype=np.float64)
    p = _prior_w
    for r in range(_NBINS):
        # Smooth preference: small residuals better, plus tiny constant.
        w[r] = p + 1.0 / (1.0 + r * r)
        p *= _prior_decay
    _hist = w


def priority(item, bins):
    global _hist
    if _hist is None:
        _init_hist()

    # bins: remaining capacities >= item
    # residual after placing item in bin = bins - item
    resid = bins - item  # int64 array, >= 0

    # Value of placing into a bin = preference for the resulting residual.
    # Use learned histogram + tie-breaking by tightness.
    vals = _hist[resid]

    # Strongly favor tight fits: secondary term to break near-ties.
    # -resid makes smaller residual score higher.
    score = vals * 1e6 - resid.astype(np.float64)

    # Update histogram online: record the residual we will most likely choose.
    # Best bin = argmax; record its residual.
    idx = int(np.argmax(score))
    r = int(resid[idx])
    _hist[r] += 1.0

    return score
