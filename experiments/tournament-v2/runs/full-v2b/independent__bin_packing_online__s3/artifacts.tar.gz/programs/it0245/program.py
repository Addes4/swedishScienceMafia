import numpy as np


# Tuned constants for the Weibull-shaped size distribution with mean ~40.
# The base rule is best fit: fill the fullest bin that can still take the item.
# Small positional weighting helps when many bins have similar residual capacity.
_INDEX_PENALTY = 1e-9


def priority(item, bins):
    """Best-fit with a tiny bias toward earlier bins.

    Args:
        item: integer size of the arriving item, 1..100.
        bins: numpy int64 array of remaining capacities for bins this item fits in.

    Returns:
        A numpy array of scores, one per bin. Highest score wins; ties go to the first bin.
    """
    # The item fits in every shown bin. Choosing the bin with the smallest remaining
    # capacity after placement minimizes wasted space locally.
    residual = bins - item

    # Highest score = smallest residual. The index penalty is negligible compared to
    # integer capacity differences, but it gives deterministic tie-breaking toward
    # earlier bins without affecting meaningful comparisons.
    scores = -residual.astype(np.float64)

    # Subtract a tiny index-dependent amount so that, among equal residuals, the
    # earlier bin is preferred.
    n = scores.shape[0]
    if n > 1:
        # Use a tiny monotone sequence; avoid constructing large temporaries.
        scores -= np.arange(n, dtype=np.float64) * _INDEX_PENALTY

    return scores
