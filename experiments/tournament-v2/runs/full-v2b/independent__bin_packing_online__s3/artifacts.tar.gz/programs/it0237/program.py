import numpy as np

_STATE = {"sum": 0.0, "n": 0}

def priority(item, bins):
    # track stats (unused for core ordering, but harmless and can aid future variants)
    _STATE["sum"] += float(item)
    _STATE["n"] += 1

    # Best fit: prefer the bin whose remaining capacity is closest to the item size.
    # equivalently minimize leftover = bins - item.
    # Then prefer fuller bins (smaller remaining capacity) as a tie-break.
    # Add a tiny index-independent tie-break using remaining capacity magnitude only.
    #
    # Score function: -leftover + epsilon * (100 - bins)
    # Since -(bins - item) = item - bins, maximizing it is best fit.
    # Adding a small multiple of (100 - bins) favors fuller bins among near-ties.
    leftover = bins - item
    return -leftover.astype(np.float64) + 1e-6 * (100.0 - bins.astype(np.float64))
