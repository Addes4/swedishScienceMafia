import numpy as np


def priority(item, bins):
    # Best fit: minimize leftover space after placement.
    # leftover = bins - item. Larger score = better.
    leftover = bins - item
    # Base score: prefer smallest leftover (tightest fit).
    score = -leftover.astype(np.float64)
    # Slight bonus for exact fit (leftover == 0).
    score += 0.5 * (leftover == 0)
    # Tiny tie-break: prefer later bins (higher index) to keep older bins
    # available for large items that may not fit in newer fragmented bins.
    n = len(bins)
    score += np.arange(n, dtype=np.float64) * 1e-6
    return score
