import numpy as np

# Historical state (kept across calls)
_hist = []          # list of past item sizes
_cum = 0.0          # cumulative sum of item sizes
_mean = 40.0        # running mean estimate
_n = 0              # number of items seen


def priority(item, bins):
    """Best-fit with a small anti-exact-fit penalty and mean-capacity tie-break."""
    global _cum, _mean, _n

    # Update running mean (cheap online estimate)
    _n += 1
    _cum += item
    mean = _cum / _n

    # remaining capacity after placing item (bins are remaining capacities)
    rem = bins - item

    # Primary: best fit (smallest non-negative remainder)
    score = -rem.astype(np.float64)

    # Penalize exact fits slightly: leaving 0 may be less useful than leaving a
    # small positive remainder, especially for medium/small items.
    exact = (rem == 0)
    if item < 60:
        score = score - exact * 0.05

    # Tie-break softly toward bins whose resulting remainder is close to the
    # observed mean size (more likely to be useful later).
    score = score - 0.001 * np.abs(rem - mean)

    # Prefer used bins over completely unused bins when remainders are equal:
    # a bin with capacity 100 is fine but keeping fresh bins can help large items.
    # Slight bonus for using already-opened bins (rem < 100).
    used = (bins < 100)
    score = score + used * 0.0005

    return score
