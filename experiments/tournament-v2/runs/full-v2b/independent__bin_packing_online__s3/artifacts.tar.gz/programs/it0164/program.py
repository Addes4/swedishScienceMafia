"""Online bin packing priority: best fit plus mild bias against opening new bins."""
import numpy as np


def priority(item, bins):
    # Best-fit score: smaller remaining capacity after placement is better.
    # This equals larger remaining-capacity-tightness, so use -(bins - item).
    residual = bins - item
    score = -residual

    # Mildly discourage using completely unused bins (capacity exactly 100)
    # unless no used bin can take the item. This encourages packing existing
    # bins more tightly and delays opening new bins.
    unused = (bins == 100)
    score = score - 1000.0 * unused

    return score
