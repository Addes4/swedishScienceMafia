"""Best fit with a usefulness-aware tie-break for online bin packing."""
import numpy as np

_state = {
    "small_items": 0,   # count of items <= 10 seen
    "total": 0,
}


def priority(item, bins):
    """Rank bins so the item goes to the tightest fit, with tie-break toward useful remainders.

    item: integer size 1..100.
    bins: int64 array of remaining capacities (including empty bins = 100), in bin index order.
    """
    _state["total"] += 1
    if item <= 10:
        _state["small_items"] += 1

    rem = bins - item            # remaining capacity after placing the item here
    # Primary: smaller remainder = tighter fit. Strong preference.
    score = -rem.astype(np.float64)

    # Tie-break: among bins whose remainder is within a tiny band of the minimum,
    # slightly prefer the larger remainder so we don't strand tiny unusable leftovers.
    min_rem = rem.min()
    near = rem <= (min_rem + 3)
    if near.any() and near.sum() > 1:
        # bonus scales with remainder within the near band, but stays well below 1
        bonus = np.where(near, rem * 0.4, 0.0)
        score = score + bonus

    return score
