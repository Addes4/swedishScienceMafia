import numpy as np


class PackerState:
    def __init__(self):
        # number of times each item size has been seen (for possible adaptation)
        self.counts = np.zeros(101, dtype=np.int64)
        self.calls = 0

    def update(self, item):
        self.counts[item] += 1
        self.calls += 1


_STATE = PackerState()


def priority(item, bins):
    """Rank bins by a best-fit rule with safeguards against wasteful tight packing.

    The item goes to the highest-scoring bin; ties are resolved by the harness to the
    earliest bin.  We return an array of the same length as `bins`.
    """
    _STATE.update(item)

    bins = np.asarray(bins, dtype=np.int64)
    n = bins.shape[0]

    # Base: best fit.  A bin with remaining capacity b leaves residual b - item.
    # Smaller residual is better.
    residual = bins - item

    # Score starts as negative residual so emptier bins (larger residual) score lower.
    scores = -residual.astype(np.float64)

    # Strongly prefer exact fits.
    exact = residual == 0
    if np.any(exact):
        scores[exact] += 1_000_000.0

    # Avoid leaving tiny unusable gaps.  If a bin would leave a residual in 1..gap_limit,
    # it is usually better to place the item elsewhere unless no better fit exists.
    # This helps prevent fragmenting capacity.
    gap_limit = 5
    tiny_gap = (residual > 0) & (residual <= gap_limit)
    if np.any(tiny_gap):
        # Penalize, but not so much that we choose a nearly empty bin over a small gap
        # when all choices create small gaps.
        scores[tiny_gap] -= 50.0 * (gap_limit + 1 - residual[tiny_gap])

    # Slight preference for bins closer to the front among equal residuals is already
    # handled by tie-breaking; add a deterministic tiny bias based on bin index.
    # This is negligible compared with real score differences.
    scores += (n - np.arange(n, dtype=np.float64)) * 1e-9

    return scores
