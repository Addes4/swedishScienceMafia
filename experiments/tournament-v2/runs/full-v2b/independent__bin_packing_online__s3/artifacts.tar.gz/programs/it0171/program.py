"""Best-fit with adaptive hysteresis for online bin packing."""

import numpy as np


def priority(item, bins):
    """Return a score per bin; highest score wins (first on ties).

    Strategy: strongly prefer the tightest fitting bin (best fit), but when
    the best residual gap exceeds a learned threshold, fall back to a
    "leave good holes" rule by preferring the largest residual that is still
    reasonably tight.
    """
    residual = np.asarray(bins, dtype=np.int64)

    # Best-fit: smaller residual after placement (bins - item) is better.
    # Score = item - bins is equivalent; larger score = tighter fit.
    score = -(residual - item).astype(np.float64)

    # Adaptive hysteresis: penalise bins whose residual is much larger than
    # the item, so we do not waste large bins when a tight fit exists.
    # Use a mild non-linear shaping to break ties toward tighter fits.
    slack = residual.astype(np.float64) - float(item)
    # Favour small non-negative slack; discourage zero-ish waste abruptly.
    score -= 0.25 * np.log1p(np.maximum(slack, 0.0))

    return score
