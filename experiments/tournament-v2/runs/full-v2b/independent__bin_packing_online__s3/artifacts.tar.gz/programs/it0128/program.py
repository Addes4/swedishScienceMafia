"""Online bin packing with adaptive best-fit and empty-bin reservation.

Strategy:
- Best fit: prefer the bin where the item fits most tightly (least remaining capacity
  after placing, i.e. smallest residual).
- Slight preference for fully closing a bin (residual exactly 0) to avoid waste.
- Penalize using completely empty bins (remaining 100) until later in the stream,
  preserving them for potentially large items, but not so strongly that we overshoot.

We estimate progress by counting arrivals. Items are i.i.d. Weibull-ish with mean ~40,
so total volume ~ 200,000 => lower bound ~ 2000 bins. Early on, items tend to fill bins
naturally; late in the stream, closing bins tightly matters more.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    n = _state["n"]
    _state["n"] = n + 1

    # bins: remaining capacities (item fits in all of them)
    residual = bins - item  # remaining capacity if we put item here (>= 0)

    # Base score: prefer small residual (best fit).
    # Negate residual so highest score = tightest fit.
    score = -(residual).astype(np.float64)

    # Bonus for exactly closing the bin (residual == 0).
    score += (residual == 0) * 2.0

    # Penalize opening a fresh bin early, less later.
    # Progress fraction: assume ~5000 items total; we use a soft schedule.
    progress = min(n / 5000.0, 1.0)
    # Penalty decreases from ~3.0 to 0.0 as we progress.
    fresh_penalty = 3.0 * (1.0 - progress)
    score -= (bins == 100) * fresh_penalty

    # Small tie-breaker: prefer non-empty bins slightly (bin index order stability).
    # Slight bonus for bins that already contain something.
    score += (bins < 100) * 0.01

    return score
