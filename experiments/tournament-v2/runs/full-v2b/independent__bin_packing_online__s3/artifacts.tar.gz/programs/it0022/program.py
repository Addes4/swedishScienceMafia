import numpy as np


def priority(item, bins):
    """Score bins to minimize the number of bins used.

    The item goes into the bin with the highest score.
    Strategy: combine best-fit (tight fit) with a preference for perfect fits
    and for avoiding tiny residual capacities.
    """
    # remaining capacity after placing the item
    rem = bins - item

    # Base: tighter fit is better => smaller remaining capacity is better.
    # Use a large negative scale so primary ordering follows remaining capacity.
    score = -rem.astype(np.float64)

    # Perfect fit bonus: prefer bins where the item exactly fills the bin.
    score += (rem == 0) * 1000.0

    # Penalize leaving very small unusable residues (1..item-? ) slightly.
    # Residues smaller than the smallest item size (1) are unavoidable; but small
    # residues like 1..15 tend to be wasted, so mildly penalize them.
    small_residue = (rem > 0) & (rem < 15)
    score -= small_residue * 0.5 * (15 - rem)

    # Prefer unused bins (remaining == 100) over partially full ones when fit is
    # not tight, to keep existing bins tighter. But only mildly.
    score += (bins == 100) * 0.25

    return score
