import numpy as np

# Online statistics of item sizes seen so far.
_count = 0
_sum = 0.0
_hist = np.zeros(101, dtype=np.float64)  # histogram of item sizes 1..100

def priority(item, bins):
    global _count, _sum, _hist
    # update statistics
    _hist[item] += 1.0
    _count += 1
    _sum += item

    n = bins.shape[0]
    # Base: best fit => smallest remaining capacity that still fits, highest priority.
    # Score = -(bins - item) = item - bins, so smaller bins get higher score.
    base = item - bins.astype(np.float64)

    # Penalize opening brand-new bins (remaining capacity == 100) unless necessary.
    # An unused bin has bins == 100. If any used bin exists (bins < 100), push
    # unused bins to the back strongly. If all are unused, no penalty matters.
    unused = (bins == 100)
    if np.any(~unused):
        base[unused] -= 1000.0

    # Adaptive residual preference:
    # If there are many used bins, prefer to leave a residual that matches a
    # common item size, so future items can fill it exactly.
    if _count >= 50:
        hist = _hist
        total = hist.sum()
        probs = hist / total
        # residual after placing item
        resid = bins - item  # >= 0 for bins item fits in
        # We want residuals that are likely to be exactly matched by a future item.
        # Probability approx probs[resid] (0..100). Large residual matching a common
        # size is good. Add a mild bonus.
        idx = resid.astype(np.int64)
        idx = np.clip(idx, 0, 100)
        bonus = probs[idx]
        base += 5.0 * bonus
        # Slight preference to NOT leave residuals that are too large to be useful
        # (already handled by best fit). Also mildly prefer residuals closer to mean.
        mean_item = _sum / _count
        base -= 0.02 * np.abs(resid - mean_item)

    return base
