"""Online bin packing: best-fit with an explicit preference against opening new bins.

The rule ranks the bins that the current item fits in.

Key idea
--------
Classic best fit (choose the bin with the least remaining capacity that still fits)
is a strong online packing heuristic.  However, best fit is indifferent between
placing an item into a *used* bin and into a fresh *unused* bin (remaining
capacity 100) when both give the same residual.  Opening a new bin is expensive,
so we add a bonus to already-used bins and a slight penalty to unused bins.  We
also keep light running statistics to slightly bias items that can almost fill a
bin toward leaving small residuals (closed bins), which helps in the tail of the
Weibull distribution.

The function is called once per arriving item; it keeps state between calls.
"""

import numpy as np

# Running statistics of item sizes seen so far.
_state = {
    "n": 0.0,
    "sum": 0.0,
    "mean": 40.0,
}


def priority(item, bins):
    """Return a priority score for every bin; highest score wins (first on ties).

    item : int, size of the arriving item (1..100).
    bins : numpy int64 array of remaining capacities of fitting bins.
    """
    n = _state["n"]
    s = _state["sum"]
    if n > 0:
        mean = s / n
    else:
        mean = 40.0

    # Expected item size helps decide when a near-full bin is worth closing.
    # Prefer the tightest fit = smallest remaining capacity (bins - item large
    # means bin is fuller).  We negate so that larger -(bins-item) wins.
    rem_after = bins - item          # residual capacity if the item is placed

    # Base score: tighter fit (smaller residual) scores higher.
    score = -(rem_after.astype(np.float64))

    # Unused bins have residual 100 after?  No: unused bins have remaining
    # capacity 100, so after placing they have 100-item.  Used-bins vs unused
    # is distinguished by their *current* remaining capacity.  Bins with
    # remaining capacity 100 are (almost always) unused.  Penalise opening them
    # unless there is no better option.
    unused = bins >= 100
    # Bonus for using an already-open bin.
    score = score + np.where(unused, 0.0, 1e6)

    # Within used bins, strongly prefer leaving a small residual, since such a
    # bin is unlikely to accept many more items.  Extra emphasis when the
    # residual becomes smaller than the typical item size.
    small = rem_after < mean
    score = score + np.where(small & ~unused, 1000.0 - rem_after, 0.0)

    # Update statistics.
    _state["n"] = n + 1.0
    _state["sum"] = s + float(item)

    return score
