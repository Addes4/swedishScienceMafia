"""Online bin packing heuristic: adaptive best-fit that discourages opening fresh bins
and reduces fragmentation by preferring tight fits into already-used bins.

The rule: a bin's score is higher when, after placing the item, the bin is either
completely full or leaves a small amount of free space, and it is also higher when the
bin was not a brand-new empty bin (remaining capacity 100). This biases the packer to
consolidate into existing bins before spending a fresh bin, while still relying on
best-fit tightness to limit wasted space.
"""
import numpy as np


def priority(item, bins):
    # remaining capacity after placing the item
    rem_after = bins - item  # >= 0 because bins shown all fit the item

    # Primary: best fit -> smallest remaining after placement.
    # Use negative rem_after so highest score = tightest fit.
    score = -rem_after.astype(np.float64)

    # Penalize using a completely empty bin (remaining capacity == 100) so that we
    # prefer to slot into already-partially-used bins when it is not much worse.
    # The penalty is mild so that a perfect fit (rem_after == 0) is still favored over
    # garbage fits into used bins.
    empty_mask = (bins == 100)
    score -= empty_mask * 0.5

    # Small bonus for leaving exactly 0 free space (perfect fill): already handled as
    # the maximum of -rem_after, but we add an explicit tie-break nudge.
    score += (rem_after == 0) * 1.0

    return score
# EVOLVE-BLOCK-END
