import numpy as np


def priority(item, bins):
    """Best-fit with a mild boost for bins that become compact after placement."""
    slack = bins - item
    # Primary: minimize remaining slack. Secondary: prefer tighter final states slightly more.
    return -(slack + 0.01 * (slack == 0))
