import numpy as np


def priority(item, bins):
    """Rank bins for online bin packing.

    Strategy: prefer an exact fit, then the tightest remaining capacity.
    This is classic best fit, with a tiny lexicographic tie-break only to
    avoid floating-point ambiguity while preserving first-bin tie behavior.
    """
    rem = np.asarray(bins, dtype=np.int64)
    diff = rem - item

    # Highest score: exact fits first.
    # Then bins with the smallest nonnegative leftover.
    # Use int64 arithmetic to avoid overflow/precision issues.
    return (diff == 0).astype(np.int64) * 1000000 - diff
