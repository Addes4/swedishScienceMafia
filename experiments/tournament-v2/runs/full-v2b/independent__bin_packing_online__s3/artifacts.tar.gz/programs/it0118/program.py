import numpy as np

# State (optional, harmless): we don't rely on it for correctness.
_CALLS = 0

# Precompute constants.
# We use a mix of:
#   1) best-fit score: prefer bin where remaining capacity after placing is smallest.
#   2) a slight preference for already-used bins over empty bins to avoid opening new bins.
#   3) tiny deterministic tie-breaker using bin index to preserve stable behavior.

def priority(item, bins):
    global _CALLS
    _CALLS += 1

    # bins is a numpy int64 array of remaining capacities >= item.
    # We want the highest score to go to the chosen bin.
    #
    # Best-fit: residual after placing = bins - item; smaller residual is better.
    # score = -residual = -(bins - item) = item - bins, which is baseline.
    #
    # Improvement: discourage using completely empty bins (capacity 100) slightly
    # unless we must, to reduce bin openings/fragmentation on average.
    # Also, among otherwise equal best-fit choices, prefer fuller bins (smaller bins value)
    # more strongly, which is already captured by best-fit but with integer ties.
    #
    # We add a small bonus for non-empty bins. Since bins are int64, unused bins == 100.
    # However, an item could exactly fill a bin (bins == item), which yields residual 0.
    # That is already best possible. The empty-bin penalty only matters when no perfect fit exists.
    #
    # We also add a tiny fractional tie-breaker based on bin index (earlier index wins ties
    # by harness rule). Actually harness already gives ties to first bin, so no need.

    # Base best-fit score.
    score = -(bins - item).astype(np.float64)

    # Penalize opening fresh bins very slightly.
    # This is a constant offset, so it only changes relative preference between used/unused bins.
    # Magnitude must be small enough not to override meaningful residual differences.
    # Residuals differ by integers, so 0.25 is safe: it cannot flip an integer residual gap.
    empty = (bins == 100)
    score -= empty * 0.25

    return score
