import numpy as np

# Stateful adaptive scoring for online bin packing.
# Idea: rank bins by a linear combination of features that matter for future packing:
#   - tight fit (small residual after placing) is generally good
#   - but preserving exact residual capacities that match common item sizes is better
# We learn weights online from observed item sizes to favor residuals that
# tend to be "refilled" exactly.

_state = {
    "counts": np.zeros(101, dtype=np.float64),  # observed item size histogram
    "total": 0.0,
    "w_fit": 1.0,
    "w_exact": 0.0,
    "fresh_bonus": 0.0,
}


def priority(item, bins):
    """Return a priority score for every bin in `bins`."""
    global _state
    bins = np.asarray(bins)

    s = _state
    s["total"] += 1.0
    # Exponentially weighted estimate of item-size distribution.
    counts = s["counts"]
    counts *= 0.999
    counts[item] += 1.0

    # Probability that a residual capacity r would be exactly filled by a
    # future item (estimated from the running histogram).
    probs = counts / max(counts.sum(), 1e-12)

    residual = bins - item  # remaining capacity if we place item in each bin

    # Base: prefer tight fit (small residual).
    fit_score = -residual.astype(np.float64)

    # Bonus if the leftover residual equals some item size frequently seen
    # (so it may be exactly filled later), but only when residual > 0.
    exact_bonus = np.where(residual > 0, probs[np.clip(residual, 0, 100)], 0.0)

    # Small bonus for using completely unused bins (residual 100) when the
    # item is large, to avoid fragmenting nearly-full bins.
    fresh = (bins == 100).astype(np.float64)

    w_fit = s["w_fit"]
    w_exact = s["w_exact"]
    w_fresh = s["fresh_bonus"]

    # Adapt weights slowly: if exact bonus helps (we can't measure directly),
    # keep it modest. We scale exact bonus relative to fit magnitude.
    score = w_fit * fit_score + w_exact * exact_bonus * (100.0 / (item + 1.0)) \
            + w_fresh * fresh * (item / 100.0)

    # Very slight tie-breaking preference for later bins (index order stable,
    # but adding tiny decreasing noise is not needed; ties go to first).
    return score


# Initialize modest adaptive weights using a simple heuristic calibration.
# We set exact bonus weight so it can influence only near-ties.
_state["w_fit"] = 1.0
_state["w_exact"] = 2.0
_state["fresh_bonus"] = 0.5
