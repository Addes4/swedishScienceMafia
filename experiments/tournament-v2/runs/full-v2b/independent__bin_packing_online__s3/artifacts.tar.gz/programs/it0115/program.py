import numpy as np


def priority(item, bins):
    """Return a score per bin; highest score wins, ties go to earliest bin."""
    # Best-fit: prefer the bin with the smallest remaining capacity that still fits.
    # Add a very small preference for earlier bins (smaller index), preserving ties.
    idx = np.arange(bins.shape[0], dtype=np.int64)
    return -(bins - item) - idx * 1e-9
