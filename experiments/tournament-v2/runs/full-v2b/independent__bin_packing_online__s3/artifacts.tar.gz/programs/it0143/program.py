import numpy as np


def priority(item, bins):
    """Best-fit with slight preference against unused bins and for tight packing.

    The item goes into the bin with the highest score. Ties go to the first bin.
    """
    # Best-fit: maximize -(remaining - item) == item - remaining, so tighter fit wins.
    # Add a small penalty for unused bins (remaining == 100) so they are not opened
    # unless no partially filled bin is available.
    # Add a tiny bonus for bins that become exactly full.
    remaining = bins.astype(np.float64)
    score = -(remaining - item)

    # Very small penalty for unused bins: prefer existing bins over fresh ones.
    score -= 0.02 * (remaining == 100)

    # Tiny preference for leaving zero remaining (perfect packing) to reduce waste.
    score += 0.01 * (remaining == item)

    return score
