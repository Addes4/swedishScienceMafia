"""Best-fit with residual-capacity tie-breaking for online bin packing.

Core idea: choose the bin that would leave the smallest residual capacity after
placing the item (classic Best Fit). Among bins with the same residual, prefer
the one whose residual is more "useful" -- i.e. closer to a typical item size or
to partial use -- which spreads waste slightly better than a pure index tie-break.
The rule is stateless and O(n) per call, well within the time limit.
"""

import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item

    # Primary: smaller residual is better (tight fit). Negate so higher score wins.
    score = -residual.astype(np.float64)

    # Secondary tie-break, kept tiny so it never overrides the primary term:
    # residual of 0 is ideal; small nonzero residuals that exactly fit future
    # items of common sizes are slightly better than large fragmented ones.
    # Use a smooth concave bonus on residual magnitude.
    sb = np.sqrt(residual.astype(np.float64) + 1.0)
    score -= 1e-6 * sb

    # Tertiary: prefer bins that already have less room (lower residual) among
    # equal residuals via index order is already handled by stable argmax;
    # additionally nudge toward lower-index bins to keep bins compact.
    n = bins.shape[0]
    score -= 1e-9 * np.arange(n, dtype=np.float64)

    return score
