import numpy as np

# Approximate Weibull(shape=1.5, scale=44.2) CDF for integer sizes 0..100.
# P(X <= k) computed via scipy.stats if available, else precomputed table.
# We'll precompute a table of useful quantities once.
_SIZE_PROBS = None
_CDF = None

def _build_tables():
    global _SIZE_PROBS, _CDF
    if _SIZE_PROBS is not None:
        return
    # Weibull with shape k=1.5, scale chosen so mean = 40.
    # mean = scale * Gamma(1 + 1/k) => scale = 40 / Gamma(1+1/1.5)
    import math
    k = 1.5
    # Gamma(1 + 2/3) = Gamma(5/3)
    try:
        g = math.gamma(1.0 + 1.0/k)
    except Exception:
        g = 0.9027453  # fallback
    scale = 40.0 / g
    # CDF for integer thresholds
    cdf = np.zeros(102, dtype=np.float64)
    for x in range(102):
        # P(X <= x)
        if x <= 0:
            cdf[x] = 0.0
        else:
            cdf[x] = 1.0 - math.exp(-(x/scale)**k)
    _CDF = cdf
    # probability item size == s for s=1..100 (approx)
    sizes = np.arange(1, 101, dtype=np.float64)
    probs = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        probs[s] = cdf[s] - cdf[s-1]
    # Normalize
    tot = probs[1:].sum()
    if tot > 0:
        probs[1:] /= tot
    _SIZE_PROBS = probs

def priority(item, bins):
    _build_tables()
    # bins: int64 array of remaining capacities >= item
    n = bins.shape[0]
    # Best-fit score baseline
    leftover = bins - item  # >= 0

    # Primary: prefer tight fit (small leftover) but not always best fit.
    # We design score so highest wins.
    # Score = A * tightness + B * future_usefulness
    # tightness: higher for smaller leftover. Use negative leftover.
    # future_usefulness: probability that a random future item fits in leftover.
    #   = 1 - CDF(leftover) roughly = P(X > leftover)
    # We want to balance: tight fit reduces waste, usefulness preserves space.
    # Empirically best fit alone is decent; adding a mild usefulness term helps.

    cdf = _CDF
    # P(future item fits) = P(X <= leftover) since item needs <= leftover
    # = cdf[leftover] but clipped to index range
    lo = leftover
    lo_clipped = np.clip(lo, 0, 100).astype(np.int64)
    fit_prob = cdf[lo_clipped]  # P(X <= leftover)

    # Score: strongly prefer small leftover, but among similar leftover, prefer more useful
    # Use score = -leftover + alpha * fit_prob * scale_factor
    # To make tightness dominant, multiply leftover by big weight.
    # Actually best-fit: score = -leftover. Let's add tie-breaking usefulness.
    # But if leftover small, fit_prob is small (few items fit), which is fine.
    # We want to avoid creating very small leftovers that are useless, BUT
    # best fit inherently does that. A known better heuristic is "worst fit"? No.
    # Let's use: score = -leftover + 0.5 * fit_prob * 100 / (1 + leftover)
    # Hmm, let's think: we want to place item such that leftover is useful.
    # A common practical rule: minimize leftover but if leftover < some threshold,
    # prefer a bin where leftover is exactly 0 or can fit common items.

    # We'll use a hybrid: score = -leftover + beta * cdf[leftover] * C
    # where C chosen so that usefulness can override small differences in leftover.
    # leftover in 0..100. cdf in 0..1.
    # Take beta = 30. So usefulness term in [0,30]. Tightness term in [-100,0].
    # This means a bin with leftover 10 (score -10 + 30*cdf(10)) vs leftover 0 (0 + 30*0)=0.
    # cdf(10) ~ small. Let's compute roughly: Weibull scale ~44, cdf(10) ~ 1-exp(-(10/44)^1.5) ~ 1-exp(-0.108) ~ 0.10.
    # So -10 + 3 = -7 vs 0. So leftover 0 wins. Good.
    # For leftover 20: cdf(20) ~ 1-exp(-(20/44)^1.5)=1-exp(-0.303)=0.26. score = -20+7.8=-12.2.
    # So smaller leftover always wins largely. The usefulness term mainly breaks ties/near-ties.

    beta = 25.0
    score = -leftover.astype(np.float64) + beta * fit_prob

    # Additional: if item is large, best fit is more important; if small, packing flexibility matters.
    # We'll keep it simple.

    # Ensure no NaN
    score = np.nan_to_num(score, nan=-1e18)

    return score
