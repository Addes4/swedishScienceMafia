import numpy as np


def priority(item, bins):
    # Exact fit is almost always optimal.
    exact = bins == item
    if exact.any():
        return exact.astype(np.float64) * 1e9 - bins.astype(np.float64)

    # Standard best fit: choose the bin with the smallest remaining capacity
    # after placing the item, i.e. maximize remaining - item.
    # Add a small preference for smaller bins and for not opening new bins.
    score = -(bins - item).astype(np.float64)

    # Slightly prefer bins that are already partially used over empty bins,
    # but only as a tie-breaker after fit quality.
    score += np.where(bins == 100, -0.01, 0.0)

    return score
