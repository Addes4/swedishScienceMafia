"""Smart bin-choice rule for online bin packing.

Strategy: weighted best-fit with a strong preference for reusing partially
filled bins, and a secondary tie-break that favors leaving a remainder that
matches typical item sizes (around 40). Also tracks whether a bin is "open"
(unused bins have capacity 100 and should be avoided unless necessary).
"""

import numpy as np

# Track open bins across calls using a set of indices we've placed into.
# Since bins array is in fixed bin order and length grows by one each call
# as needed (unused bins included), we can differentiate unused bins
# (rem cap == 100) from used ones, but some used bins may also return to 100.
# We'll maintain a dict of last-known filling status by bin position.

_item_sum = 0.0
_item_count = 0
_bin_used = {}  # bin index -> True if ever used

# Typical mean item size from distribution
TARGET_MEAN = 40.0


def priority(item, bins):
    """Return scores; item goes to highest score, ties to first bin."""
    global _item_sum, _item_count, _bin_used

    _item_sum += item
    _item_count += 1

    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]

    # Residual capacity after placing the item
    residual = bins - item  # all bins fit the item, so residual >= 0

    # Base: prefer tight fit (small residual after placement)
    # Negative residual so smallest residual scores highest.
    score = -residual

    # Strongly prefer bins that are partially used rather than fully empty.
    # Unused bins have capacity 100 -> residual == 100 - item.
    empty_residual = 100.0 - item
    is_empty = (bins == 100.0)

    # Bonus for non-empty bins to encourage consolidation
    score = score + 60.0 * (~is_empty).astype(np.float64)

    # Bonus for bins that when filled leave a residual close to a "good"
    # leftover: we want to avoid leaving tiny unusable remainders and
    # avoid large remainders that waste capacity. Prefer leaving a
    # remainder that is 0 (exact fit) or near ~ half of mean item.
    # Penalty for residuals in the "dead zone" (small but nonzero, < ~10)
    # that likely can't be filled well.
    dead_zone = (residual > 0.5) & (residual < 12.0)
    score = score - 25.0 * dead_zone.astype(np.float64)

    # Slight preference for residuals that are >= mean-ish or exactly zero,
    # handled naturally by tight-fit base.

    # Prefer bins that have been used before (persistent state), as they
    # are known to be committed bins.
    hist = np.zeros(n, dtype=np.float64)
    for i in range(n):
        if _bin_used.get(i, False):
            hist[i] = 1.0
    score = score + 5.0 * hist

    # Mark chosen bin as used: we don't know choice here, but mark the
    # min residual non-empty candidate as likely. Instead, mark all bins
    # that are currently partial as used (they're real bins now).
    for i in range(n):
        if bins[i] < 100.0:
            _bin_used[i] = True

    return score
