import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin whose remaining capacity is smallest but >= item.

    Score is higher for tighter fits. A small bonus is given to already-used bins
    (remaining capacity < 100) so that new bins are only opened when needed.
    """
    rem = bins - item          # remaining capacity after placing the item
    # Higher score = better. Prefer small `rem` (tighter fit), and among equal
    # fits prefer used bins over empty ones.
    used_bonus = (bins < 100).astype(np.int64) * 0.5
    return -(rem.astype(np.float64)) + used_bonus
