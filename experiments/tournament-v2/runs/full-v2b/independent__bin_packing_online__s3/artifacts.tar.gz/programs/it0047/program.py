"""Adaptive best-fit with slight preference against opening new bins."""
import numpy as np


def priority(item, bins):
    # Tightest fit: smaller leftover capacity after placing the item is better.
    # For unused bins (capacity 100), apply a penalty so they are chosen only
    # when no partially-filled bin can take the item reasonably well.
    leftover = bins - item
    score = -leftover.astype(np.float64)

    # Penalize opening new bins slightly. This encourages packing into existing
    # partially filled bins, reducing bin count for online packing.
    new_bin = bins >= 100
    score[new_bin] -= 30.0

    return score
