import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.opened = 0          # number of bins used so far (new bins start at capacity 100)
        self.last_caps = None
        self.alpha = 0.35        # weight on tightness term (best-fit strength)
        self.beta = 0.15         # weight on recency/fragmentation term


_state = _State()


def priority(item, bins):
    """Rank bins: mainly best-fit (tightest fit), with a mild prefer-near-full/stable term.

    item : integer size 1..100
    bins : np.int64 array of remaining capacities, in bin index order.
           Bins the item does not fit into are not shown; unused bins have cap 100.
    """
    _state.calls += 1

    b = bins.astype(np.float64)

    # Slack = leftover space if item goes here. Smaller is better (best fit).
    slack = b - float(item)

    # Tightness: normalized preference for fuller (smaller remaining capacity) bins.
    # Range roughly [0,1]; avoids huge scale differences.
    tight = (100.0 - b) / 100.0

    # Stability/fragmentation term: prefer bins that are neither nearly empty
    # (wasteful to start small) nor exactly a perfect fit unless it is truly tight.
    # Penalize leaving a bin with a tiny residual too small to be useful later.
    resid = slack
    # A residual below a small threshold is "dead space"; mildly penalize it.
    dead = 1.0 / (1.0 + resid)  # larger when residual is small

    # Combine: best fit dominates, tightness adds slight pressure, dead-space mild.
    score = -(_state.alpha * slack) - (0.20 * tight) - (0.05 * dead)

    # Very slight tie-break by bin index order is handled by harness (first wins),
    # so leave equal scores as-is.

    return score
