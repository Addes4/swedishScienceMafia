import numpy as np


def priority(item, bins):
    rem = bins - item
    # Best fit: prefer smallest remaining capacity after placement.
    score = -rem.astype(np.float64)
    # Mild penalty for using entirely empty bins when the item doesn't fit perfectly,
    # encouraging use of existing partial bins first.
    empty_penalty = (bins == 100).astype(np.float64) * (item < 100) * 0.5
    score -= empty_penalty
    return score
