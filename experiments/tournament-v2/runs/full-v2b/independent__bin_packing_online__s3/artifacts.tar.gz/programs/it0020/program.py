import numpy as np


def priority(item, bins):
    # Best-fit: prefer the bin with the smallest remaining capacity that still fits.
    # bins already contains only bins into which the item fits.
    # We score by negative leftover after placing the item (tightest fit highest).
    leftover = bins - item
    scores = -leftover.astype(np.float64)

    # Small tie-breaker: prefer bins that are already in use (leftover < 100 - item
    # means the bin was not empty) so we fill existing bins before opening fresh ones.
    unused_remaining = 100
    is_unused = (bins == unused_remaining)
    scores -= is_unused * 1e-6  # tiny penalty, does not override best-fit ordering

    return scores
