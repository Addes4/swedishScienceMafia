import numpy as np

_state = {"count": 0, "sum": 0.0}

def priority(item, bins):
    # Track simple running statistics (unused but kept for possible adaptation)
    _state["count"] += 1
    _state["sum"] += item

    # leftover after placing into each bin
    leftover = bins - item  # >= 0 since only fitting bins are shown

    # Best fit: prefer smallest leftover.
    # Tie-break: prefer bins that are already fuller (smaller remaining capacity before placement)
    #   to consolidate and free empty bins.
    # Second tie-break: prefer leftover that leaves a "nice" gap; use closeness to 0 strongly.
    # We combine into a float score (negative leftover dominates).
    score = -leftover.astype(np.float64)

    # small bonus for bins that get closer to full (smaller resulting leftover)
    # and penalty for wasting large empty bins.
    score -= 0.001 * bins.astype(np.float64)

    # Extra tiny deterministic jitter by bin index is NOT applied (would break stability).

    return score
