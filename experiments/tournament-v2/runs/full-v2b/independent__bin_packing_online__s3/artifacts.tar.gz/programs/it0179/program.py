import numpy as np


def priority(item, bins):
    """Best fit with a tiny index-based tie-break preference.

    The item is placed into the bin where it leaves the least remaining space.
    A very small deterministic term based on bin index is added so that bins
    that are otherwise equivalent are not always filled in the same order;
    this marginally improves packing on average without changing the core
    best-fit behavior for distinct fits.
    """
    residual = bins - item
    # Main objective: minimize residual (prefer tightest fit).
    score = -residual.astype(np.float64)
    # Tiny deterministic tie-break: spread equivalent choices across bin order.
    # This only affects exact ties in residual, preserving best-fit otherwise.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    score += 1e-9 * (idx / max(1.0, n))
    return score
