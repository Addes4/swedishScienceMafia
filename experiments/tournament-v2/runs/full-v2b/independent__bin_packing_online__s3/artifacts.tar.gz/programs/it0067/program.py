import numpy as np


def priority(item, bins):
    # Best-fit residual after placing the item: smaller leftover is better.
    leftover = bins - item

    # Base: negative leftover (so smaller leftover => higher priority, tighter fit).
    score = -leftover.astype(np.float64)

    # Prefer non-empty bins slightly when fits are similar; empty bins have remaining capacity 100.
    # Add a tiny bonus for bins that are already in use (bins < 100).
    score += np.where(bins < 100, 0.5, 0.0)

    # Encourage filling: extra small bonus when leftover is 0 (perfect fill).
    score += np.where(leftover == 0, 0.25, 0.0)

    return score
