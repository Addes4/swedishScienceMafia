import numpy as np

# State: track sizes seen to estimate distribution and adapt thresholds
_sizes = []
_seen = 0

def priority(item, bins):
    """
    Adaptive best-fit heuristic with small residual avoidance.

    Score bins to tightly fit the item, but prefer existing partially-filled bins
    over unused bins (capacity 100). Also avoid leaving tiny unusable residuals
    when possible.
    """
    global _sizes, _seen
    _sizes.append(item)
    _seen += 1
    if len(_sizes) > 5000:
        _sizes = _sizes[-5000:]

    # Convert bins to float for arithmetic
    cap = bins.astype(np.float64)

    # Base score: tighter fit is better => smaller residual (cap - item) is better
    residual = cap - item

    score = -residual

    # Strongly prefer non-empty bins over empty ones (avoid opening new bins unnecessarily)
    # Empty bins have capacity == 100
    is_empty = (cap >= 99.999)  # capacity 100 exactly for unused bins
    score = score - 50.0 * is_empty  # penalty for opening a new bin

    # Penalize leaving very small residual (< min item size ~ 1) in a bin
    # since it will likely be unusable. Encourage exact fits.
    tiny_residual_penalty = np.where(residual < 5.0, (5.0 - residual) * 1.0, 0.0)
    score = score - tiny_residual_penalty

    # Slight preference for bins with larger remaining capacity among non-empty ones
    # to preserve flexibility? Actually best-fit prefers tighter fit. We already do.
    # Small bonus for exact fit
    exact_bonus = np.where(residual == 0.0, 10.0, 0.0)
    score = score + exact_bonus

    return score
