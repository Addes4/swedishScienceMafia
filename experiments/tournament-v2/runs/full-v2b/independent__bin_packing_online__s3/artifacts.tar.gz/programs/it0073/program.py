import numpy as np


def priority(item, bins):
    """
    Score each bin by a best-fit rule with a small preference for bins
    that are already in use and leave less residual space.

    The item goes to the highest-scoring bin.  Since the harness chooses the
    first bin on ties, bins are effectively ordered by:
      1. larger score
      2. earlier index

    For a bin with remaining capacity c, placing `item` leaves residual
    r = c - item.  Smaller r is better (tighter fit).  Unused bins have
    c = 100, so they are preferred only when no used bin fits as tightly.
    """
    residual = bins - item

    # Main criterion: tightest fit (smallest residual).
    # Use negative residual so larger score means tighter fit.
    score = -residual.astype(np.float64)

    # Slight preference for non-empty bins: if a bin is exactly full, it is
    # ideal, but among equal residuals prefer bins that are already partially
    # filled rather than consuming a fresh bin.
    empty = (bins == 100).astype(np.float64)
    score -= 0.01 * empty

    # Secondary tie-break: avoid leaving very small unusable gaps when a
    # slightly less tight bin avoids fragmentation.  This term is small
    # enough not to override the main best-fit ordering.
    score -= 0.0001 * residual.astype(np.float64)

    return score
