import numpy as np


def priority(item, bins):
    """Score bins for online bin packing.

    The rule is a refined best-fit: strongly prefer the bin where the item leaves the
    smallest positive remainder, mildly prefer more-filled bins, and slightly penalize
    opening brand-new bins except for larger items.
    """
    # Strong tight-fit term: smaller positive remainder gets a higher score.
    # Using 101 - remainder keeps values positive and separated.
    tight = 101.0 - (bins - item)

    # Prefer bins that are already somewhat filled, but only as a tie-breaker.
    filled = 100.0 - bins

    # Fresh bins have remaining capacity 100. Penalize them, more for small items.
    # Small items can often fit into existing bins, so opening a new bin is costly.
    # Large items may genuinely need a new bin, so reduce the penalty.
    fresh_penalty = np.where(bins == 100, 35.0 + item * 0.35, 0.0)

    return tight + 0.02 * filled - fresh_penalty
