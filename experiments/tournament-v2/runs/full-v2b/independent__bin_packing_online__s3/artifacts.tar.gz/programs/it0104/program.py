import numpy as np


def priority(item, bins):
    # Best fit: prefer the fullest bin that still fits the item.
    # Score = -(remaining_capacity - item) = item - remaining_capacity
    # Highest score -> smallest remaining capacity >= item.
    # A tiny epsilon makes used/partially-used bins slightly more attractive
    # than unused bins (capacity 100), reducing premature bin openings.
    scores = item - bins
    # Penalize completely empty bins slightly so we reuse existing space first.
    scores = scores.astype(np.float64)
    scores[bins == 100] -= 0.5
    return scores
