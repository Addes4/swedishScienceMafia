import numpy as np


def priority(item, bins):
    """Rank bins for an incoming item.

    Strategy: best fit (tightest remaining capacity that still holds the item),
    but with a mild bias that penalizes leaving very small unusable remainders
    and slightly favors bins whose post-placement remainder is more "useful".

    Since the item goes to the highest score (ties to first), we return a score
    that is large for the best-fitting bin.
    """
    rem = bins - item  # remaining capacity after placing item (>= 0 for shown bins)

    # Base: prefer tightest fit => smaller remainder is better => larger score.
    # Use negative remainder so larger score = tighter fit.
    score = -rem.astype(np.float64)

    # Penalize remainders that are small but nonzero, which tend to waste space
    # (a bin with e.g. 3 left is almost as bad as a full one for future items).
    # Reward remainders that are more likely to be reusable.
    # keep item good if remainder is large.
    small = (rem > 0) & (rem < item)
    # scale penalty by how small the remainder is
    penalty = np.where(small, (item - rem) * 0.15, 0.0)
    score -= penalty

    # Slight preference for leaving a remainder that is itself a plausible item size,
    # to reduce fragmentation. We don't know the distribution exactly, but mean ~40.
    # Favor remainders near typical item sizes.
    useful = np.where(rem > 0, -np.abs(rem - 40.0) * 0.02, 0.0)
    score += useful

    # Prefer filling emptier bins (remaining 100) less strongly, keeping them open
    # for possible large items. Penalize using a completely empty bin slightly.
    empty = rem == (100 - item)
    score -= empty * 0.05

    return score
