import numpy as np


def priority(item, bins):
    """Best-fit with a mild preference against leaving tiny unusable slivers."""
    rem = bins - item
    # Primary: pack as tightly as possible (highest score = smallest remaining).
    # Secondary: penalize remainders in 1..4 because they are hard to reuse.
    tiny_penalty = np.where((rem >= 1) & (rem <= 4), 0.5, 0.0)
    return -rem - tiny_penalty
