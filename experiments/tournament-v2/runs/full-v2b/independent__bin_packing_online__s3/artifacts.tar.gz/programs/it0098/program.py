import numpy as np


def priority(item, bins):
    """Rank bins by a tuned best-fit preference.

    Higher score wins; ties go to the earliest bin.
    The goal is to pack tightly while slightly discouraging opening new bins.
    """
    rem = bins
    # Best fit: prefer the smallest remaining capacity that still fits the item.
    # Add a mild preference for fuller bins (smaller remaining capacity),
    # and a small penalty for completely empty bins to avoid unnecessary openings.
    score = -(rem - item)

    # Slightly favor bins with less remaining space overall, which encourages
    # consolidating items and keeping empty bins unused.
    score = score + 0.001 * (-rem)

    # Penalize opening a fresh bin (remaining capacity exactly 100) a little.
    score = score - 0.5 * (rem == 100)

    return score
