import numpy as np

# A static scoring table maps (item_size, remaining_capacity) -> adjustment.
# The base score is best-fit (-bins), i.e. prefer the tightest fitting bin.
# The adjustment slightly discourages leaving awkward small gaps and
# slightly encourages leaving common useful gaps.
_REM = np.arange(101)

def _build_adjust():
    adj = np.zeros((101, 101), dtype=np.float64)
    for item in range(1, 101):
        for rem in range(item, 101):
            gap = rem - item
            # base best fit: closer to zero leftover is better
            # Penalize tiny leftovers (1..5) a bit, they are hard to fill.
            # Reward leftovers around 8..20 and 30..45, typical useful sizes.
            pen = 0.0
            if 1 <= gap <= 5:
                pen -= 0.35 * (6 - gap)
            elif 6 <= gap <= 10:
                pen += 0.02
            elif 11 <= gap <= 25:
                pen += 0.08
            elif 26 <= gap <= 45:
                pen += 0.05
            elif 46 <= gap <= 70:
                pen -= 0.02
            else:
                pen += 0.0
            # small bonus for exactly filling
            if gap == 0:
                pen += 0.5
            adj[item, rem] = pen
    return adj

_ADJ = _build_adjust()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = np.asarray(bins)
    # Base best-fit score: tighter fit (smaller remaining capacity) is better.
    base = -b.astype(np.float64)
    # Clamp to table range
    rem = np.clip(b, 0, 100).astype(np.int64)
    adj = _ADJ[item, rem]
    return base + adj
