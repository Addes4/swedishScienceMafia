import numpy as np

COUNT = np.zeros(101, dtype=np.int64)
TOTAL = 0

def priority(item, bins):
    global TOTAL
    # update online size-frequency estimate
    COUNT[item] += 1
    TOTAL += 1

    # best-fit ranking: prefer smallest remaining slack (tightest fit).
    # tie-break / refine using a learned distribution: prefer leaving a
    # remaining capacity that is less likely to be useful for common items,
    # i.e. push toward "wasteful" leftovers that are hard to pair.
    slack = bins - item  # >= 0

    # estimate usefulness of a leftover capacity c: sum over common future
    # item sizes s <= c of prob(s). Higher usefulness => less attractive.
    # We approximate with a coarse lookup derived from the item histogram.
    nz = np.nonzero(COUNT)[0]
    if nz.size == 0:
        return -slack.astype(np.float64)

    p = COUNT[nz] / TOTAL  # probabilities of observed sizes

    # vectorized: useful(c) = sum_{s in nz, s<=c} p
    # compute via sorting
    order = np.argsort(nz)
    sizes = nz[order]
    probs = p[order]
    cum = np.cumsum(probs)

    # for each bin slack c, find count of sizes <= c
    idx = np.searchsorted(sizes, slack, side='right') - 1
    useful = np.where(idx >= 0, cum[np.clip(idx, 0, len(cum) - 1)], 0.0)
    # bins with slack beyond all observed sizes contribute 0 additional useful

    # score: tightest fit primary, penalize leaving highly-useful slack
    return -(slack.astype(np.float64)) - 0.5 * useful
