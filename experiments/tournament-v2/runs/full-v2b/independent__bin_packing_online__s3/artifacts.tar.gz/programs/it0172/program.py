import numpy as np


def priority(item, bins):
    """Online bin-choice rule: best-fit with residual-capacity shaping.

    Higher score wins; ties go to the first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (all bins the item fits in),
          including unused bins (capacity 100), in bin order.
    """
    rem = bins.astype(np.int64)
    residual = rem - item

    # Base: strongly prefer tight fit (small leftover).
    # Equivalent to maximizing -(residual), i.e. best fit.
    score = -residual.astype(np.float64)

    # Mild preference for emptier bins among equal fits? No: best fit already
    # handles that. Add a small term that favors residuals which are themselves
    # plausible item sizes, improving future packing efficiency.
    # Common sizes under a Weibull-shaped distribution with mean ~40 cluster
    # around small/medium values; reward residuals in useful ranges.
    r = residual.astype(np.float64)

    # reward leftovers that can likely be filled exactly-ish by future items
    # (non-trivial: avoid tiny unusable holes, prefer 1 and mid-range holes)
    # Shape: peak near small positive residuals and diminishing otherwise.
    shaped = np.where(
        r >= 0,
        -0.02 * np.abs(r - 10.0) / 10.0 + 0.01 * (r == 0),
        -1e6,
    )
    score = score + shaped

    # Slight preference to place into already-used fuller bins (larger item placed)
    # to keep empty bins available for large arrivals: bins with smaller remaining
    # capacity before placement are slightly preferred.
    score = score - 1e-6 * rem.astype(np.float64)

    return score
