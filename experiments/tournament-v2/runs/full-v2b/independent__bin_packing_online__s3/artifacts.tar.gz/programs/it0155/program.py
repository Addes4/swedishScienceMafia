import numpy as np


class PackingPolicy:
    def __init__(self):
        # Track observed item size counts (1..100) to estimate distribution.
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        # Cache for estimated "future fill probability" of a residual capacity.
        self._cache_r = None
        self._cache_v = None

    def _residual_value(self, r):
        """Score for leaving residual capacity r: high if r is likely to be exactly filled
        or well-packed later. Uses observed item distribution."""
        r = int(r)
        if r <= 0:
            return -1e9
        if self._cache_r is not None and int(self._cache_r) == r:
            return self._cache_v
        # Estimate probability that some single future item exactly matches r,
        # plus a smooth value for packability.
        p_exact = (self.counts[r] + 0.5) / (self.total + 100.0 * 0.5) if r <= 100 else 0.0
        # Reward residuals that are themselves common item sizes; penalize tiny unusable residuals.
        # Tiny residuals (1..small) are often wasted; large residuals keep flexibility.
        waste_penalty = 0.0
        if r < 10:
            waste_penalty = (10 - r) * 0.15
        # Prefer residuals close to common item sizes to enable exact fills.
        val = p_exact * 1000.0 - waste_penalty + r * 0.01
        self._cache_r = r
        self._cache_v = val
        return val

    def priority(self, item, bins):
        item = int(item)
        # Observe item (online learning of distribution).
        if 1 <= item <= 100:
            self.counts[item] += 1.0
            self.total += 1.0
            # invalidate cache when distribution changes
            self._cache_r = None

        bins = np.asarray(bins, dtype=np.int64)

        # Primary: best fit (minimize residual capacity after placing item).
        residual = bins - item  # all >= 0 since only fitting bins are shown

        # Secondary heuristic: among practically equivalent residuals, prefer ones
        # whose leftover space is more valuable for future packing.
        scores = -residual.astype(np.float64)

        # Apply a small distribution-aware bonus based on exact residual desirability.
        # To keep it fast, compute vectorized approximations and only refine unique values.
        max_bonus = 0.5  # must stay well below 1.0 so best-fit dominance is preserved
        uniq = np.unique(residual)
        bonus_map = {}
        for r in uniq:
            v = self._residual_value(int(r))
            bonus_map[int(r)] = v
        if len(uniq) <= len(residual):
            # vectorized gather
            vals = np.empty(len(uniq), dtype=np.float64)
            for i, r in enumerate(uniq):
                vals[i] = bonus_map[int(r)]
            order = np.argsort(uniq)
            inv = np.empty_like(order)
            inv[order] = np.arange(len(uniq))
            # map residuals to bonus
            idx = np.searchsorted(uniq[order], residual) if False else None

        # Faster: build bonus array directly with a dict lookup vectorized via bincount if small
        bonus = np.zeros_like(scores)
        # residual values range 0..99 (item>=1, bins<=100)
        # use a lookup table of size 101
        lut = np.empty(101, dtype=np.float64)
        for r in range(101):
            lut[r] = self._residual_value(r)
        np.clip(residual, 0, 100, out=None)
        # ensure within bounds for indexing
        res_clipped = residual
        if res_clipped.max() > 100:
            res_clipped = np.minimum(res_clipped, 100)
        bonus = lut[res_clipped] * 0.001

        scores = scores + bonus

        return scores


_policy = PackingPolicy()


def priority(item, bins):
    return _policy.priority(item, bins)
