import numpy as np


class _State:
    def __init__(self):
        self.calls = 0


_state = _State()


def priority(item, bins):
    """
    Online bin packing priority rule.

    Best-fit is strong for this problem. We add a small preference against
    opening completely empty bins, which often saves bins in the long run.
    """
    _state.calls += 1

    b = np.asarray(bins, dtype=np.int64)

    # Best fit: leftover capacity after placing item. Smaller is better.
    # score = -(b - item) = item - b
    score = item - b.astype(np.float64)

    # Penalize using a perfectly empty bin slightly.
    # This acts like a reservation threshold and avoids premature new bins.
    score -= (b == 100) * 0.35

    return score
