import numpy as np


def priority(item, bins):
    """Best fit with a small discouragement of perfect fits.

    The item goes to the bin where the resulting leftover is smallest, i.e.
    best fit.  Filling a bin exactly is slightly penalized so that slightly
    less full bins can absorb future small items, but the penalty is tiny
    enough that a perfect fit still wins over any meaningfully larger
    leftover.
    """
    leftover = bins - item
    # Prefer small leftover.  Add a tiny penalty for an exact fit.
    return -(leftover.astype(np.float64) + (leftover == 0) * 0.01)
