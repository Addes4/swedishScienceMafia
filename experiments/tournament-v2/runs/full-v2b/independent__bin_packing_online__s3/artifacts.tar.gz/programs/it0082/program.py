"""Online bin packing heuristic: best fit (tightest remaining capacity)."""
import numpy as np


def priority(item, bins):
    """Score bins by best fit: highest score for smallest remaining capacity after placing item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of all bins the item fits in.
    """
    # bins are all >= item by contract. Prefer bins where the remaining space
    # after placing the item is smallest (i.e., original remaining capacity is smallest).
    return -bins
