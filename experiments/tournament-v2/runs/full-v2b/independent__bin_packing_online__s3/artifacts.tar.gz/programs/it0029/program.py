"""Best fit with a slight scarcity bonus to preserve empty bins."""
import numpy as np


def priority(item, bins):
    """Rank bins for the arriving item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (as many bins as items).

    Highest score wins; ties go to the first bin.
    The base is best fit: prefer the tightest fit (smallest remaining capacity
    that still fits). A small bonus rewards leaving a completely empty bin
    unused, which tends to improve packing quality on Weibull-like sizes.
    """
    b = np.asarray(bins)
    # Best fit: smaller remaining capacity -> higher score.
    # -(b - item) = item - b, so smaller b gives larger value.
    return (item - b).astype(np.float64) - 0.05 * (b == 100)
