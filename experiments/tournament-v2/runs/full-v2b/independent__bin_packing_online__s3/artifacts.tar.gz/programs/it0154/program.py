import numpy as np


def priority(item, bins):
    """Adaptive best-fit/worst-fit heuristic for online bin packing."""
    # Number of bins currently in use (remaining < 100) and total bins shown
    in_use = np.count_nonzero(bins < 100)
    total = bins.shape[0]

    # How "full" is the packing overall?
    # If many bins are still nearly empty, worst-fit helps avoid tiny leftover bins.
    # If most bins are partly filled, best-fit reduces fragmentation.
    utilization = 1.0 - (bins.sum() - (total - in_use) * 100) / (total * 100.0 + 1e-9)

    # Blend factor: high utilization -> prefer tight fit (best fit),
    # low utilization -> prefer loose fit (worst fit).
    # Values chosen empirically as a smooth transition.
    w_best = 0.85 + 0.15 * utilization
    w_worst = 1.0 - w_best

    # Best fit score: larger (closer to 0) when remaining capacity is just above item
    best_fit = -(bins - item)

    # Worst fit score: prefer emptier bins (larger remaining capacity)
    worst_fit = bins.astype(np.float64)

    return w_best * best_fit + w_worst * worst_fit
