import numpy as np

def priority(item, bins):
    # 'bins' is np.int64 array of remaining capacities (>= item for all shown)
    caps = bins  # alias
    # Score the bins:
    # We want: prefer tighter fits (smaller residual) ideally,
    # but also sometimes avoid filling a bin too much to leave room for other items.
    # Classic: best fit decreasing is strong offline; online best fit is decent.
    # Here: score = residual after placing (caps - item), lower is better, so negate.
    # But tie-breaking and subtle preference: bins with capacity exactly 100 are empty.
    # Optionally prefer empty bins when item is large, to leave partially filled bins for small items.
    # Let's test variants conceptually and use a blended approach:
    #   score = -(residual) * w1 + small_factor(prefer_non_empty if item < 50 ?)
    # We'll use:
    #   base_score = -(caps - item)  # best fit
    #   Adjust: if item >= 60, prefer empty bins slightly more (to pack big items separately)
    #           if item < 40, prefer non-empty bins? But best fit already fills non-empty tightly.
    # Actually simple best-fit is quite good. Let's try to enhance with a small tie-breaker
    # to prefer bins that are already open (caps < 100) to reduce bin count.
    # But best fit naturally does that if residuals are close.
    # Another idea: Worst fit for large items can be bad; best fit generally good.
    # We'll implement: primary key = -(caps - item), secondary = -1 if (caps < 100) else 0 (prefer used bins)
    # Since harness picks highest score first, we can encode:
    # score = -(caps - item) * 1000 + (0 if caps < 100 else -1)
    # That strongly prefers best fit; among equal residual, prefers used bin.
    # But maybe also consider: if item is large (>50), we might want to leave used bins with small residual
    # for small items? Actually small items can fit in small residuals. So best fit is fine.

    # Let's try a version: score = -(caps - item) + alpha * (caps == 100)
    # alpha negative to slightly discourage empty bins for small items? Experiment mentally:
    # For small item, many bins fit. Best fit fills smallest residual. Empty bins have residual 100, high.
    # So empty bins rarely chosen anyway for small items unless all residuals large.
    # For large items, fewer bins fit. Best fit may put big item into bin with small residual, using it up.
    # That might be okay. But maybe better to put big item into emptier bin to save nearly-full bin for a
    # combination of small items? Hard to know.

    # Let's go with a hybrid: use best fit but with a small penalty for using empty bins if item is small,
    # and small bonus for using empty bins if item is very large. This encourages grouping similar sizes?
    # Actually Weibull distribution: many small items, few large.
    # To minimize bins, we want to pair small with large in same bin (complementary sizes).
    # Best fit does that: small item goes into bin with residual just enough (likely from large item).
    # So keep best fit primary. We'll add tiny tie-breaker to prefer bins that are already open,
    # which best fit does approximately already, but we make it explicit.

    # Final rule:
    residual = caps - item
    # Base score: higher for smaller residual
    score = -residual.astype(np.float64)
    # Tie-breaker: slightly prefer used bins (caps < 100) over empty bins (caps == 100)
    # Use a small epsilon.
    score += np.where(caps < 100, 1e-6, 0.0)
    # Additionally, if item is large (>=60), maybe prefer empty bins a tiny bit to avoid
    # clogging nearly-full bins? But best fit might fill a bin with residual 60 exactly, using it fully.
    # That is actually good. So no.
    return score
