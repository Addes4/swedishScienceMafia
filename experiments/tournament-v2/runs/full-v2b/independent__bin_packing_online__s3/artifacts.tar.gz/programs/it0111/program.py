import numpy as np


def priority(item, bins):
    """Rank bins.  Heuristic mix of best-fit and waste-minimising rules.

    The key observations for online bin packing under a Weibull size distribution
    (mean ~40, so many items in 10..60 and a heavy tail toward 100):

    * For very large items only a few bins can take them at all; using the
      tightest such bin is clearly right (best fit) because filling a nearly
      full bin is almost free, while opening a fresh bin wastes a lot.
    * For tiny items, best fit keeps bins compact and closes bins quickly.
    * The dangerous middle is handled by penalising the residual waste that a
      placement creates when the resulting slack cannot be filled by a typical
      future item.  A simple proxy is to prefer placements whose resulting
      remaining capacity is itself a "useful" size (i.e. large enough to host
      a typical item) rather than a dead small gap.

    Returned score is higher for better bins; ties go to the earlier bin.
    """
    cap = bins.astype(np.int64, copy=False)

    # Remaining capacity after placing the item in each candidate bin.
    rem = cap - item

    # --- base: best fit (smaller leftover is better) -----------------------
    # Scale so it dominates the shaping terms but stays smooth.
    score = -rem.astype(np.float64)

    # --- shaping ----------------------------------------------------------
    # Prefer placing into a bin that is already used (rem prior < 100) over
    # opening a brand-new bin when the item is not large: opening new bins
    # should be delayed as long as possible.
    if item < 50:
        score -= (cap == 100) * 8.0

    # Penalise leaving a "dead gap": residual 1..7 tends to be unfillable with
    # the same small items repeatedly, so mildly avoid creating tiny leftovers.
    dead = (rem >= 1) & (rem <= 7)
    score -= dead.astype(np.float64) * 3.0

    # For large items, strongly reward near-perfect fits so the few eligible
    # bins get consumed efficiently.
    if item >= 50:
        score += (rem == 0).astype(np.float64) * 50.0
        score += (rem <= 2).astype(np.float64) * 10.0

    return score
