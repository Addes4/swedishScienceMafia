import numpy as np

def priority(item, bins):
    # Best fit: prefer the bin whose remaining capacity after placing the item is smallest,
    # i.e., maximize remaining - item (least remaining capacity).
    # Since bins contains only bins where item fits (>= item), remaining - item >= 0.
    # We want the minimum resulting remaining capacity, so score = -(remaining - item).
    #
    # Additionally, to slightly encourage filling bins and avoiding new bins,
    # penalize completely empty bins (remaining == 100) when other bins fit the item.
    # This is done by giving unused bins a slightly worse score.
    rem = bins - item
    score = -rem.astype(np.float64)

    # Penalize unused bins (remaining capacity exactly 100), but only slightly,
    # so they are still used if no better bin exists.
    score[bins == 100] -= 0.5

    return score
