import numpy as np


def priority(item, bins):
    # Best fit: prefer the tightest remaining capacity that still fits.
    # Slightly penalize using a completely empty bin so that partially filled
    # bins are exhausted before opening new ones.
    slack = bins - item
    return -(slack + 0.02 * (bins == 100))
