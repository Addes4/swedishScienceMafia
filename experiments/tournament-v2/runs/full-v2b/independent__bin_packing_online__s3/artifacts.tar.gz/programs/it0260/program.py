import numpy as np


def priority(item, bins):
    # Best-fit: prefer the bin whose remaining capacity is just enough for this item.
    # Primary score: smaller leftover after placing is better.
    leftover = bins - item

    # Slight bonus for bins that become exactly full, because they are completely
    # consumed and cannot be wasted later.
    score = -leftover.astype(np.float64)

    # For large items, discourage partially filling a bin unless it becomes very full.
    # This helps avoid leaving medium-sized holes that hard-to-pack later items dislike.
    if item >= 60:
        # Penalize placements that leave a small but nonzero remainder, especially
        # remainders that are too small to be useful for typical future items.
        residual = leftover
        penalty = np.where((residual > 0) & (residual < 20), 5.0, 0.0)
        score -= penalty

    # Prefer avoiding the opening of new bins when a tight fit exists, but not at
    # the cost of leaving capacities that are almost certainly unusable.
    unused = bins == 100
    score = np.where(unused, score - 2.0, score)

    return score
