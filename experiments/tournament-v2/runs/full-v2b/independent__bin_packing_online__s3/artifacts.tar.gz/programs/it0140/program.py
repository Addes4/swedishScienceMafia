import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    Main idea: prefer tight fits in already-used bins, but discourage leaving
    very small residual capacities that are unlikely to fit future items.
    """
    # Remaining capacity after placing the item.
    rem = bins - item

    # Score: prefer smallest positive remaining capacity (best fit).
    # Add a mild bonus for bins that would still retain some usable space,
    # and a mild penalty for creating very small residuals.
    score = -rem.astype(np.float64)

    # Exact fit is always good.
    exact = (rem == 0)

    # Penalize residuals in (0, 10), which are often wasted.
    small_resid = (rem > 0) & (rem < 10)
    score[small_resid] -= 2.0

    # Slightly prefer residuals that are likely useful later.
    useful = (rem >= min(item, 10)) & (rem <= 80)
    score[useful] += 0.5

    # Strongly prefer exact fit if available.
    score[exact] += 10.0

    return score
