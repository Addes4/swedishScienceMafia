import numpy as np

# Precompute a penalty for creating a residual capacity after packing `item`.
# Small residuals are bad (hard to fill later), large residuals near 100 are neutral.
# This is a hand-crafted table that mimics avoiding small leftovers.
_RESID_PENALTY = np.zeros(101, dtype=np.float64)
for r in range(101):
    # penalize small positive residuals strongly; zero residual is ideal
    if r == 0:
        _RESID_PENALTY[r] = 0.0
    elif r <= 10:
        _RESID_PENALTY[r] = 50.0 - 5.0 * r  # r=1 -> 45, r=10 -> 0
    elif r <= 30:
        _RESID_PENALTY[r] = max(0.0, 10.0 - (r - 10) * 0.5)
    else:
        _RESID_PENALTY[r] = 0.0


def priority(item, bins):
    """Best-fit with a penalty for undesirable small residual capacities."""
    rem = bins - item  # residual capacity if item placed in each bin
    # Score: prefer small residual (best fit), but heavily penalize creating tiny leftovers.
    score = -rem.astype(np.float64)
    # Add penalty only for residuals < 100 (actual used bins); unused bins (rem==100-item) unaffected naturally
    n = rem.shape[0]
    for i in range(n):
        r = rem[i]
        if r < 100 - item:  # this bin was already used
            score[i] -= _RESID_PENALTY[r]
        else:
            # unused bin: prefer to not open new bins unless necessary, so give a bonus to fitting exactly
            if r == 0:
                score[i] += 0.0
    return score
