import numpy as np


def priority(item, bins):
    """Best fit with a bonus for exact fills.

    The item goes into the bin with the highest score.
    Tightest fit means smallest residual capacity bins - item, so use
    -(bins - item) = item - bins.  A tiny extra bonus for an exact fill
    (bins == item) helps close bins perfectly and leave more room for later items.
    """
    scores = item - bins
    # Prefer exact fills strongly without disturbing the main best-fit ordering.
    scores = scores.astype(np.float64)
    scores += 0.5 * (bins == item)
    return scores
