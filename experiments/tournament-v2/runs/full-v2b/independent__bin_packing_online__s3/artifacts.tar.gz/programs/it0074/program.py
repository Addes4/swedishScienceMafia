"""Hybrid best-fit rule with empty-bin reservation for online bin packing."""
import numpy as np


def priority(item, bins):
    """Rank bins: strongest fit first, with tie-breaking and empty-bin reservation.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (including empty bins = 100).
    """
    # Primary: tightest fit (smallest remaining capacity after placing the item).
    residual = bins - item

    # Secondary tie-breaker: prefer fuller bins (smaller remaining capacity)
    # among bins with equal residual.  This is already aligned with best fit,
    # so add a tiny monotone component based on capacity.
    score = -residual * 1000.0 - bins

    # Strongly avoid opening unused bins (remaining capacity 100) unless needed:
    # penalize empty bins heavily, but let them still win if no used bin fits.
    score = np.where(bins == 100, score - 1e9, score)

    return score
