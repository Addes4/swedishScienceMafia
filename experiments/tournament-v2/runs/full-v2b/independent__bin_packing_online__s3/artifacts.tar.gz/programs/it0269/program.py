import numpy as np

def priority(item, bins):
    # bins is a numpy array of remaining capacities
    # We want to return a score for each bin
    # Best fit: score = -(bins - item)
    # Modified: penalize small remainders
    T = 10  # threshold
    alpha = 2.0
    remainder = bins - item
    # For bins where item doesn't fit, remainder < 0, but the problem says bins only includes those where item fits.
    # So remainder >= 0.
    # Compute penalty
    penalty = alpha * np.maximum(0, T - remainder)
    # Score = -(remainder + penalty) = -remainder - penalty
    # Actually, we want to maximize score, so we want to minimize remainder + penalty.
    # So score = -(remainder + penalty)
    score = -(remainder + penalty)
    # For exact fit (remainder == 0), penalty = alpha*T, so score = -alpha*T = -20.
    # But we want exact fit to be best. So we should not penalize remainder 0.
    # So set penalty = 0 for remainder == 0.
    # Or better: give a bonus for exact fit.
    # Let's set score = -(remainder + penalty) but for remainder 0, score = 0.
    # Actually, if remainder 0, penalty = alpha*T = 20, score = -20. That's worse than remainder 10 (score -10).
    # So we must handle exact fit specially.
    # We can do: score = -remainder - penalty, but for remainder == 0, score = 1 (or any positive number to make it highest).
    # But the baseline uses -remainder, so exact fit gives 0, which is highest (since all others are negative).
    # If we add penalty, exact fit gets -20, which is lower than some other remainders. That's bad.
    # So we need to ensure exact fit is always chosen.
    # We can set: score = -remainder - penalty, but for remainder == 0, score = 0.
    # But then remainder 0 gives 0, remainder 10 gives -10, so 0 is still highest.
    # Wait, if remainder 0 gives 0, and remainder 10 gives -10, then 0 is higher. So that works.
    # But if we have remainder 0 and remainder 10, 0 gets 0, 10 gets -10, so 0 wins. Good.
    # So we can just do: score = -remainder - penalty, but set penalty = 0 when remainder == 0.
    # Actually, we can just do: score = -remainder - alpha * np.maximum(0, T - remainder) * (remainder > 0)
    # But that's the same as penalty = alpha * np.maximum(0, T - remainder) and then for remainder == 0, penalty = alpha*T, which is 20, score = -20. That's bad.
    # So we need to mask.
    # Simpler: compute base score = -remainder. Then for bins where remainder > 0 and remainder < T, subtract alpha*(T - remainder).
    # So score = -remainder - alpha*(T - remainder) * ((remainder > 0) & (remainder < T))
    # But we can vectorize.
    # Let's do:
    remainder = bins - item
    score = -remainder.astype(float)
    mask = (remainder > 0) & (remainder < T)
    score[mask] -= alpha * (T - remainder[mask])
    return score
