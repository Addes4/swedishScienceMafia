"""Best-fit with a small preference for used bins.

The arriving item is packed immediately. Among bins where it fits, tightest-fit
usually performs well for online bin packing.  A mild tie-breaking bonus for
already-used bins helps avoid opening new bins when a nearly-equally-tight used
bin is available, while an exact-fit bonus captures the especially valuable case.
"""
import numpy as np


def priority(item, bins):
    """Return priority scores for bins.

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities >= item.
    """
    rem = bins
    # Primary component: tightest fit (larger for smaller residual after item).
    tight = -(rem - item).astype(np.float64)

    # Strong bonus for exact fit.
    exact = (rem == item).astype(np.float64) * 50.0

    # Small bonus for used bins (remaining < 100) so among near-equal fits we
    # tend to fill existing bins rather than open a new one.
    used_bonus = (rem < 100).astype(np.float64) * 0.01

    return tight + exact + used_bonus
