"""Online bin packing: hybrid Best-Fit with mild Worst-Fit smoothing.

We score each candidate bin by the residual capacity it would have after
placing the item (Best Fit: smaller residual -> better).  A small additional
term rewards bins with *more* absolute remaining capacity before placement,
which slightly delays the sealing of medium-full bins and helps the typical
Weibull-shaped stream.  The smoothing coefficient is chosen small enough that
it only acts as a tie-breaker and does not override the primary Best-Fit
ordering.

Only numpy is used;  the function is O(n) per call in the number of bins.
"""

import numpy as np


# Small smoothing weight on the pre-placement remaining capacity.
# Kept small so the residual-capacity (Best-Fit) term dominates.
_SMOOTH = 1e-3


def priority(item, bins):
    """Return a score for every bin; highest score wins (ties -> first bin).

    Parameters
    ----------
    item : int
        Size of the arriving item, 1..100.
    bins : numpy.ndarray (int64)
        Remaining capacities of all bins the item fits into, in bin index order.

    Returns
    -------
    numpy.ndarray (float64)
        One score per bin.
    """
    b = bins.astype(np.float64)

    # Primary: Best Fit.  Residual after placing = b - item.
    # Smaller residual is better, so negate it.
    best_fit = -(b - item)

    # Secondary (tie-breaker): slightly prefer bins with more free space
    # before placement, i.e. less "already fragmented" bins.
    smooth = _SMOOTH * b

    return best_fit + smooth
