import numpy as np

def priority(item, bins):
    # Best-fit score: smaller residual after placement is better (negative residual).
    residual = bins - item

    # Coarse size-class bias: prefer placements that leave residuals in common classes.
    # This encourages consistent gaps and reduces fragmentation for Weibull-shaped sizes.
    # Bias magnitude is small so it only breaks near-ties (best-fit remains dominant).
    # Classes of 5 capacity units.
    class_residual = (residual // 5).astype(np.int64)
    # Prefer residuals that are multiples of 5 (score bonus).
    class_bonus = (residual % 5 == 0).astype(np.float64) * 0.01

    # Also slightly prefer bins where after placement the remaining capacity is not too small
    # (avoid creating tiny unusable slivers) but still best-fit dominates.
    # Score: -residual (best fit) plus small bonus for clean residuals.
    score = -residual.astype(np.float64) + class_bonus

    # Ensure no NaN (not needed here, but safe).
    return score
