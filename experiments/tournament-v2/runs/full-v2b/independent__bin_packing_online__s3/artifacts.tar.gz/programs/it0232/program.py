"""Online bin packing with a tuned best-fit-plus-fragmentation rule."""
import numpy as np

# Keep a small rolling history of item sizes to bias toward historically good residual gaps.
_hist_sum = 0.0
_hist_cnt = 0
_HIST_MAX = 64.0


def priority(item, bins):
    global _hist_sum, _hist_cnt

    # Update history.
    _hist_sum += item
    _hist_cnt += 1
    if _hist_cnt > _HIST_MAX:
        _hist_cnt *= 0.5
        _hist_sum *= 0.5
    mean_item = _hist_sum / _hist_cnt if _hist_cnt else 40.0

    # bins is an int64 numpy array; work in float to allow additive bonuses.
    b = bins.astype(np.float64)

    # Residual capacity after placing item.
    rem = b - item

    # Base: strict best-fit (smaller residual = higher score).
    score = -rem

    # Reward exact fits very strongly.
    score += (rem == 0) * 1000.0

    # Reward leaving a residual that is a "useful" small size or zero,
    # and penalize leaving tiny unusable scraps (1..4) unless exact.
    tiny = (rem > 0) & (rem < 5)
    score -= tiny * 15.0

    # Mild preference for fuller bins (larger used capacity = smaller b) to reduce
    # number of open bins: small bonus proportional to (100 - b).
    score += (100.0 - b) * 0.02

    # Bias toward residuals close to the historical mean item size, which tends
    # to leave gaps that later items can fill.
    score -= np.abs(rem - mean_item) * 0.05

    return score
