"""Online bin packing via residual-best-fit with open-bin preference."""

import numpy as np


def priority(item, bins):
    # Residual after placing the item. Best fit minimizes it.
    residual = (bins - item).astype(np.float64)

    # Prefer already-used bins (capacity < 100) over fresh 100-capacity bins
    # when the residual ties. Unused bins all have capacity 100, so residual
    # is the same for a given item; this avoids opening new bins needlessly.
    is_open = (bins < 100)

    # Primary: smaller residual is better  -> negate.
    # Secondary (tie-break): open bins get a small bonus.
    # The bonus (0.25) is far below the integer residual spacing (>=1),
    # so it only affects exact residual ties.
    score = -residual + 0.25 * is_open

    # Final tie-break by bin order is handled by the harness (first wins),
    # which naturally favors lower indices in the fixed bin order.
    return score
