"""Online bin packing: adaptive best-fit with worst-fit fallback for leftover space.

Strategy:
- Items arrive with unknown future (Weibull-shaped, mean ~40).
- Perfect fit (remaining == item) is always taken immediately.
- Otherwise use best fit (minimize leftover capacity), which is known to perform well
  for online bin packing. We add a small bias: if the item is small (< 15) and the
  best leftover would be large, we may prefer a bin that leaves a medium leftover
  to avoid fragmenting near-full bins. We also track running item statistics to
  subtly adapt thresholds.
- Never return NaN; return a float array of scores.
"""

import numpy as np

_state = {
    "count": 0,
    "sum": 0.0,
    "small_seen": 0,
    "large_seen": 0,
}


def priority(item, bins):
    # Update simple running statistics (allowed to keep state between calls)
    _state["count"] += 1
    _state["sum"] += item
    if item <= 20:
        _state["small_seen"] += 1
    if item >= 60:
        _state["large_seen"] += 1

    b = np.asarray(bins)
    # fraction of bins that are completely unused (capacity 100)
    # We prefer not to open new bins unless needed.
    leftovers = b - item  # >= 0 by contract (only bins item fits in are passed)

    # Base score: best fit = most negative leftover (tightest fit).
    score = -leftovers.astype(np.float64)

    # Exact fit gets a strong bonus (perfect packing).
    exact = (leftovers == 0)
    if exact.any():
        score = score + exact.astype(np.float64) * 1e6
        return score

    # Full bins (capacity 100) are brand-new bins.
    is_new = (b == 100)

    # For small items, avoid wasting a fresh bin if a suitable existing bin exists
    # that leaves a "reasonable" leftover; otherwise new bin is fine.
    if item <= 20:
        # If there's an existing (non-new) bin whose leftover after placing is
        # at most 100 - item (always) and at least some slack, prefer tightest.
        # Small nudge: penalize opening new bins slightly when non-new bins exist.
        if not is_new.all():
            score = score - is_new.astype(np.float64) * 0.5
    else:
        # Large items: strongly prefer not to open new bins if any fits.
        # best fit already handles it; small extra penalty for new bins.
        if not is_new.all():
            score = score - is_new.astype(np.float64) * 0.25

    return score
