import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.m2 = 0.0
        self.last = 40.0


_state = _State()


def priority(item, bins):
    s = _state
    s.n += 1
    alpha = 2.0 / (s.n + 1.0) if s.n > 1 else 1.0
    delta = item - s.mean
    s.mean += alpha * delta
    s.m2 += delta * (item - s.mean)
    s.last = item

    # Base best-fit score: smaller residual capacity after placement is better.
    residual = bins - item

    # Adaptive "usefulness" bonus: a residual is more valuable if it is not much
    # smaller than the running mean item size, because tiny residuals are often wasted.
    # Larger residuals are also okay (they can accept future items), but we still
    # prioritize tight fits via the first term.
    mean = max(5.0, s.mean)
    bonus = np.minimum(residual, mean) / mean

    # Combine: strongly prefer tight fits, but among bins with similar residual,
    # prefer the one whose residual is closer to the typical item size.
    score = -residual + 0.05 * bonus

    return score
