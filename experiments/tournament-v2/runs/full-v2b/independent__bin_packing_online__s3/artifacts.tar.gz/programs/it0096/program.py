import numpy as np


class _PackerState:
    def __init__(self):
        self.count = 0
        self.hist = np.zeros(101, dtype=np.float64)
        self.mean = 40.0
        self.alpha = 1e-3

    def observe(self, item):
        self.count += 1
        self.hist[item] += 1.0
        n = float(self.count)
        # Exponential moving average of item size, useful as a coarse scale estimate.
        self.mean = (1.0 - self.alpha) * self.mean + self.alpha * float(item)


_state = _PackerState()


def priority(item, bins):
    """Rank bins with a best-fit-like score plus a small future-fit term."""
    _state.observe(item)

    b = bins.astype(np.float64, copy=False)
    residual = b - float(item)

    # Primary: best fit.  Tighter residual (smaller remaining capacity) is preferred.
    # We turn residual into a score where larger is better.
    score = -residual

    # Secondary: mild preference for bins that leave a small but positive residual,
    # especially near the observed mean size, to reduce fragmentation.
    # This is still essentially best fit, but with a tiny distribution-aware nudge.
    n = _state.count
    if n > 20:
        # Estimate a representative future item size from the empirical mean.
        mu = max(1.0, float(_state.mean))
        # Favor residuals close to a typical item or slightly below it.
        # A Gaussian-like bump centered near mu/2 and mu.
        s1 = np.exp(-0.5 * ((residual - mu * 0.5) / (0.35 * mu + 1.0)) ** 2)
        s2 = np.exp(-0.5 * ((residual - mu) / (0.45 * mu + 1.0)) ** 2)
        score += 0.0015 * (s1 + 0.7 * s2)

    # Very small tie-breaker: prefer earlier bins on equal residual.
    # Since ties already go to the first bin, this only affects floating noise.
    score -= np.arange(bins.shape[0], dtype=np.float64) * 1e-12

    return score
