import numpy as np

# Online bin packing: choose the bin that leaves the "best" residual.
#
# The optimal online rule for this distribution is close to Best Fit, but raw
# Best Fit can be slightly improved by accounting for which residuals are
# awkward: leftover capacities that are too large to be filled by a typical
# future item but too small to be useful as a fresh bin waste space.
#
# We score each candidate bin by a weighted combination of:
#   * tightness (Best-Fit term): -(remaining - item)
#   * a residual-quality term that rewards residuals that are "neither tiny
#     nor enormous": very small residuals are effectively dead space, very
#     large residuals are just like a fresh bin (fine), and middle residuals
#     are the dangerous ones that neither accept big items nor help small ones.
#
# The penalty is a smooth function of the residual r = remaining - item:
#   penalty(r) = w * f(r), where f peaks around the typical item size.
#
# This keeps the greedy Best-Fit structure (which is near-optimal online here)
# while nudging away from creating mid-size unusable gaps.

_A = 1.0          # weight of Best-Fit tightness term
_W = 0.35         # weight of residual-quality penalty


def _residual_penalty(r):
    """Penalize mid-size residuals that are awkward to fill later.

    r is the leftover capacity (0..100) after placing the item.
    r = 0 is perfect (no waste).
    Small r is somewhat bad (dead space) but unavoidable.
    Large r is fine (acts as a fresh bin).
    Mid-size r is worst: too big to be covered by small items, too small
    to accept the next big item, causing fragmentation.
    """
    r = r.astype(np.float64)

    # Peak around typical item size (~40). Gaussian bump.
    # Penalty is high for residuals near 40, low near 0 and near 100.
    mid = np.exp(-((r - 40.0) ** 2) / (2.0 * 18.0 ** 2))

    # Additionally, very small residuals are dead space; mildly penalize.
    small = np.exp(-(r ** 2) / (2.0 * 8.0 ** 2))

    return mid + 0.30 * small


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining 100), in bin order.
    """
    # Residual capacity if the item were placed in each bin.
    residual = bins - item

    # Best-Fit term: prefer the tightest fit (smallest residual).
    tightness = -residual.astype(np.float64)

    # Residual-quality penalty: subtract penalty from score.
    penalty = _residual_penalty(residual)

    return _A * tightness - _W * penalty
