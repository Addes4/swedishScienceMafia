import numpy as np


def priority(item, bins):
    # Best fit: prefer bins where the remaining capacity after placing is smallest.
    # Slight preference for already-used bins helps avoid opening new bins too early.
    remaining = bins - item
    scores = -remaining.astype(np.float64)

    # Break exact-fit ties in favor of bins that are not completely unused.
    # This preserves tight packing without harming cases where a perfect fit is available.
    unused = (bins == 100)
    scores[unused] -= 1e-6

    return scores
