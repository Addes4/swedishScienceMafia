import numpy as np

# Module-level state: track observed item sizes to adapt thresholds.
_state = {
    "count": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "items": [],
}


def _reset_if_new_instance():
    # Heuristic: detect a new instance by resetting when count is a multiple gone stale.
    pass


def priority(item, bins):
    """
    Rank bins for the arriving item.

    Strategy: robust best-fit with a small penalty for leaving very small or very
    "awkward" residual capacities, since those residuals often can't be filled by
    future items. Since items are ~40 mean (Weibull-shaped), residuals near item
    sizes are valuable; residuals that are too small are nearly useless.

    We score by how well the bin's remaining capacity matches the item, plus a
    preference for residuals that are likely to remain packable.
    """
    # Update running statistics (state allowed between calls).
    _state["count"] += 1
    _state["sum"] += item
    _state["sumsq"] += item * item

    n = _state["count"]
    # Periodic light maintenance to keep memory bounded over very long runs.
    if n % 100000 == 0:
        _state["count"] = 1
        _state["sum"] = float(item)
        _state["sumsq"] = float(item * item)

    mean = _state["sum"] / n
    var = max(_state["sumsq"] / n - mean * mean, 1.0)
    std = var ** 0.5

    remaining = bins.astype(np.float64)

    # Residual after placing the item.
    residual = remaining - item

    # Base: tightest fit (best fit) -> prefer smallest residual >= 0.
    score = -residual

    # Penalize residuals that are "too small to ever be useful": a leftover of 1..few
    # is almost always wasted. Estimate the typical item size as `mean`.
    # A leftover is "good" if it can plausibly host a mean-ish or median-ish item.
    # We model desirability of a residual r as how many typical items it could hold,
    # but super-linearly prefer near-full utilization.
    small_thresh = max(1.0, mean * 0.25)

    # Bins that would be left with a tiny residual get demoted.
    tiny_penalty = np.where(residual < small_thresh, (small_thresh - residual) * 2.0, 0.0)
    score -= tiny_penalty

    # Mild preference for leaving residuals near the typical item size (so a future
    # item can fit snugly), which helps reduce fragmentation over the run.
    near_typ = np.exp(-((residual - mean) ** 2) / (2.0 * (std + 1.0) ** 2))
    score += 0.5 * near_typ

    # Prefer opening a fresh bin (remaining == 100) over creating awkward mid bins,
    # slightly: placing into a full empty bin avoids fragmentation only when the
    # item is large. For small items, filling partially-used bins is better.
    # Encode: if item is large relative to mean, slight bonus for empty bins.
    if item >= mean:
        empty_bonus = np.where(remaining >= 100.0, 1.0, 0.0)
        score += 0.25 * empty_bonus
    else:
        # For small items, slightly prefer non-empty bins (fill gaps).
        nonempty_bonus = np.where(remaining < 100.0, 1.0, 0.0)
        score += 0.25 * nonempty_bonus

    return score
