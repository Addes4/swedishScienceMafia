import numpy as np

class _State:
    def __init__(self):
        self.count = 0
        self.item_sum = 0
        self.big = 0
        self.small = 0
        self.recent = []
        # small-item target: fill bins to a complement-friendly residual
        self.target = 40.0
        self.small_thresh = 34

    def update(self, item):
        self.count += 1
        self.item_sum += item
        self.recent.append(item)
        if len(self.recent) > 64:
            self.recent.pop(0)
        if item <= self.small_thresh:
            self.small += 1
        else:
            self.big += 1
        # adapt target: average recent item size
        if self.recent:
            avg = sum(self.recent) / len(self.recent)
            self.target = max(20.0, min(70.0, avg))

_state = _State()


def priority(item, bins):
    s = _state
    s.update(item)

    cap = bins.astype(np.float64)
    # residual after placing
    residual = cap - item

    n = len(cap)
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    idx = np.arange(n, dtype=np.float64)

    # Basic scores:
    # best-fit preference (small residual good) but avoid leaving hard-to-fill tiny holes
    bf = -(residual)

    # Worst-fit preference (large residual good), used for big items to keep small bins available
    wf = cap

    # "Complementary packing": prefer bins whose residual is close to target
    # so that next similar item may exactly fill it.
    comp = -np.abs(residual - s.target)

    # Penalize residuals that are too small but nonzero (hard to reuse) slightly
    tiny_pen = np.where((residual > 0) & (residual < 8), -6.0, 0.0)
    # Penalize creating a bin with leftover in the awkward 45-60 range when many bins exist
    awkward = np.where((residual > 45) & (residual < 65), -1.5, 0.0)

    # unused bins: capacity 100. Mild preference to open a fresh bin only when necessary
    unused = (cap >= 100.0)
    fresh_bonus = np.where(unused, 0.4, 0.0)

    # weight by item size: small items go best-fit, large items benefit from worst-fit
    w = min(1.0, item / 100.0)
    score = (1.0 - w) * (bf + comp + tiny_pen + awkward + fresh_bonus) \
            + w * (wf + 0.3 * comp + fresh_bonus)

    # Slight preference to earlier bins on near-ties to concentrate filling
    score = score - 0.001 * idx

    return score
