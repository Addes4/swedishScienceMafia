import numpy as np


def priority(item, bins):
    # bins: remaining capacities of bins the item fits in (includes empty bins = 100)
    # Prefer tight fit (best fit): smaller remaining capacity after placement -> higher score.
    # score = -slack, where slack = bins - item.

    slack = bins - item  # >= 0 since item fits

    # Base: best fit. Exact fits (slack == 0) get top priority.
    score = -slack.astype(np.float64)

    # Bonus for exactly filling a bin (waste nothing).
    exact = (slack == 0)
    if exact.any():
        score = np.where(exact, score + 1000.0, score)

    # Slight preference to avoid leaving bins with small residual (hard-to-fill leftovers)
    # unless it's an exact fill: penalize tiny residual in non-exact placements lightly
    # by preferring residual that is either 0 or reasonably large.
    small_res = (slack > 0) & (slack < item)
    # among non-exact, prefer placing into bins that become more "usable" (larger residual
    # is worse for future small items? Actually small residual is hard to reuse).
    # Give a mild bonus to bins whose residual is not a tiny awkward leftover.
    awkward = (slack > 0) & (slack < 15)
    score = np.where(awkward, score - 0.5, score)

    return score
