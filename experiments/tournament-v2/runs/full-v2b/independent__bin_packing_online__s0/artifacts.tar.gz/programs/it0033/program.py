import numpy as np


def priority(item, bins):
    # Best-fit: prefer the bin with the smallest remaining capacity that still fits.
    # Equivalent to maximizing -(remaining_capacity - item) = item - remaining_capacity.
    # This tends to pack tightly and reduce the number of bins used.
    return -(bins - item)
