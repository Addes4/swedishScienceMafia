"""Best fit with a small preference against opening fresh bins on near-ties."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with mild preference for existing partially filled bins."""
    # Primary: tightest fit means smallest remaining capacity after placing the item.
    # Equivalent to maximizing -bins, but keeping item shifts tie behavior consistently.
    slack = bins - item

    # Lower slack is better, so negate. Empty bins have slack 100 - item; they are
    # slightly penalized compared to any already-used bin with the same resulting slack,
    # which helps avoid wasting a new bin when an equally tight used bin exists.
    score = -slack.astype(np.float64)

    # Tiny bonus for non-empty bins (remaining < 100), so existing bins win exact ties.
    score += (bins < 100) * 1e-6

    return score
