import numpy as np


def priority(item, bins):
    """Rank bins by closeness of their remaining capacity after placement to a target.

    Best-fit tends to overfill bins and create tiny remnants. Here we prefer placing
    into bins where the resulting free space is around 60-70, which tends to leave
    the packer with useful medium/high remaining capacities for the mean-40 items.
    """
    leftover = bins - item
    # Target leftover after placing: ~65 (slightly above mean item size).
    return -np.abs(leftover - 65.0)
