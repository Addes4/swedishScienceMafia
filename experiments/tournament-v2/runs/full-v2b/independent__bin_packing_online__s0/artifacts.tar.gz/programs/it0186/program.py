import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0

    def update(self, item):
        self.n += 1
        self.total += int(item)


_state = _State()


def priority(item, bins):
    """Best-fit style: prefer the bin whose remaining capacity is closest to the item.

    Bins with remaining capacity exactly equal to `item` get top priority (perfect fit).
    Among others, smaller leftover (bins - item) is preferred. A tiny preference is given
    to bins that are already partially used vs. completely empty bins (remaining 100),
    which tends to avoid opening new bins when a good fit exists.
    """
    _state.update(item)

    # leftover after placing the item
    leftover = bins - item  # non-negative for all shown bins

    # Base score: prefer smaller leftover (tightest fit).
    # Using negative leftover so higher score = tighter fit.
    score = -(leftover.astype(np.float64))

    # Tiny bonus for non-empty bins (remaining < 100) to discourage opening new bins,
    # and a small bonus for exact fits.
    empty = bins == 100
    score += (~empty).astype(np.float64) * 1e-3
    score += (leftover == 0).astype(np.float64) * 1e-2

    return score
