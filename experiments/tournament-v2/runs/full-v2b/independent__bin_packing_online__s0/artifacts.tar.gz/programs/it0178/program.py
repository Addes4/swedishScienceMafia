"""Best fit with a mild unused-bin penalty for online bin packing."""

import numpy as np


def priority(item, bins):
    """Score bins for best-fit placement, with a small penalty for unused bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    # Best hit: smallest remaining capacity that still fits the item.
    leftover = bins - item

    # Slightly penalize unused bins (remaining capacity 100) so that we do not
    # open a new bin unless it is clearly the best fit.
    unused_penalty = np.where(bins == 100, 0.25, 0.0)

    # Lower leftover is better.  The unused penalty makes a used bin with
    # leftover L preferred over an unused bin with leftover 100 when L is only
    # mildly larger, while still allowing best-fit when appropriate.
    return -(leftover.astype(np.float64) + unused_penalty)
