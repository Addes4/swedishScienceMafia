# EVOLVE-BLOCK-START
"""Best-fit with stable tie-breaking for online bin packing."""
import numpy as np


_state = {"tick": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["tick"] += 1

    # Primary: tightest fit (smallest residual capacity).
    score = -(bins - item)

    # Secondary: slightly prefer non-empty bins (bins are "used" if residual < 100)
    # over completely empty bins when residuals tie, which helps avoid opening new bins.
    score = score.astype(np.float64)
    score += (bins < 100) * 1e-6

    # Tiny deterministic jitter to break exact capacity ties consistently but harmlessly.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    score += 1e-9 * ((idx * 2654435761.0 + item * 40503.0 + _state["tick"] * 2246822519.0) % 1.0)

    return score
# EVOLVE-BLOCK-END
