"""Hybrid best-fit priority for online bin packing."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a mild bias against opening new bins.

    The item goes to the highest-scoring bin; ties go to the first bin.
    """
    # Classic best fit: smaller remaining capacity after placing is better.
    # Here bins contains remaining capacities, so tighter fits have smaller bins.
    # We return a score where larger is better: prefer smaller remaining capacity.
    return -(bins - item)
