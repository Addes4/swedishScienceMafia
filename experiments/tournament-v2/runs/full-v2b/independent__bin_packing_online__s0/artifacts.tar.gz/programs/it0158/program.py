import numpy as np


def priority(item, bins):
    """Score bins by best fit: prefer the smallest remaining capacity after placement.

    Returning -(bins - item) makes the tightest-fitting bin (smallest leftover) highest.
    Ties go to the first bin in the given order, matching the harness rule.
    """
    return -(bins - item)
