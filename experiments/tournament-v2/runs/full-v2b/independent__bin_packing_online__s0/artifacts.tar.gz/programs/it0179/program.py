import numpy as np


def priority(item, bins):
    # Best fit: prefer bins where the item leaves the least remaining capacity.
    # Add a tiny penalty for unused bins (remaining capacity 100) to encourage
    # filling partially used bins, which usually reduces total bins used.
    residual = bins - item
    score = -residual.astype(np.float64)
    # Penalize fresh bins slightly, scaled by item size so large items prefer reuse.
    score -= (bins == 100) * (0.001 * item)
    return score
