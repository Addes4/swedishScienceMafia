"""Online bin packing: best-fit with tie-breaking toward partially-used bins."""
import numpy as np


def priority(item, bins):
    """Rank bins for the arriving item.

    Primary goal: put the item in the feasible bin with the least remaining
    capacity after placement (classic best-fit), which packs tightly.

    Secondary goal: among bins that leave a similar residual, prefer the bin
    that is already partially used (capacity < 100) over a fresh empty bin,
    to avoid fragmenting fresh bins when an older bin can absorb the item.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Base score: strongly prefer small residual (tightest fit).
    score = -residual.astype(np.float64)

    # Small penalty for using a fresh/empty bin when alternatives exist.
    # Empty bins have remaining capacity 100; penalize those slightly so
    # partially used bins win close calls.
    empty_mask = bins >= 100
    # Only apply the penalty meaningfully: scale it so it never overrides
    # a genuinely better fit (residual gap of >=1 always wins).
    score = score - 0.5 * empty_mask

    return score
