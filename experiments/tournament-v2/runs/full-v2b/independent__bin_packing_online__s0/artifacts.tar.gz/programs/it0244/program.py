import numpy as np

_state = {
    "step": 0,
}


def priority(item, bins):
    # Classic best-fit: maximize -(remaining - item), i.e. fill the tightest fitting bin.
    # Add a tiny secondary preference for already-used bins (lower remaining capacity)
    # to reduce fragmentation without changing the primary ordering significantly.
    rem = bins.astype(np.int64, copy=False)
    scores = -(rem - item) * 1000 - rem
    return scores.astype(np.float64)
