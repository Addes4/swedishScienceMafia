"""Improved best-fit priority for online bin packing.

Rule:
  - Prefer bins where the item fits most tightly (smallest leftover).
  - Strongly prefer exact fits (leftover 0).
  - Among near-equal fits, slightly prefer already-used bins (residual < 100)
    so that we don't open a fresh bin while a nearly-full one can still be used.
  - Keep it deterministic and cheap: pure vectorized numpy per call.
"""
import numpy as np


def priority(item, bins):
    # leftover capacity after placing the item
    leftover = bins - item

    # Score: we want the SMALLEST leftover => score = -leftover
    score = -leftover.astype(np.float64)

    # Strongly favor exact fit (leftover == 0)
    score += (leftover == 0) * 1000.0

    # Slight preference for used bins (residual < 100) to reduce fragmentation
    # of empty bins; magnitude small so tightness remains dominant.
    score += (bins < 100) * 0.5

    # Small nudge: prefer leaving leftover that is close to 'item' (helps
    # produce reusable residuals for similar items). Tiny effect.
    score += 0.001 * (leftover == item)

    return score
