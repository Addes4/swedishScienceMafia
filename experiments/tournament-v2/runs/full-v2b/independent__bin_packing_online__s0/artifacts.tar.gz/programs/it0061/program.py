import numpy as np


def priority(item, bins):
    # Best-fit heuristic: put the item into the bin it fits most tightly.
    # We rank by smallest remaining capacity after placing the item
    # (equivalently, smallest bin remaining capacity >= item is best).
    #
    # Since `bins` already contains only bins the item fits into,
    # remaining capacity is in [item, 100].
    #
    # Score = -(remaining_after_placement)
    #       = -(bins - item)
    # Exact fit gives 0, loosest fit gives item-100 (more negative).
    #
    # Tie-breaking naturally goes to the first bin encountered for equal scores,
    # which is the earliest bin index among equally tight fits.
    #
    # This is a pure best-fit (a.k.a. tightest-fit) rule and is very fast.
    return -(bins - item)
