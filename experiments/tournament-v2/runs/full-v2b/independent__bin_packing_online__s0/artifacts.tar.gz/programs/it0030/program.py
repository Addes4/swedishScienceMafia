import numpy as np


def priority(item, bins):
    # rank all bins; highest score goes first.
    # Base: prefer tightest fit (largest remaining capacity after placing item).
    # Small correction: prefer residuals that are likely to be useful later,
    # while not overfitting to the exact distribution.
    score = (bins - item).astype(np.float64)

    # Prefer leaving a residual in the most common "usable" range.
    # If residual is very small it is often wasted; if very large it may be
    # better saved for another item. This is deliberately mild.
    residual = bins - item
    score -= 0.02 * np.abs(residual - 20.0)

    # Favor unused bins (capacity 100) only when the item is relatively large,
    # otherwise opening a new bin early can waste space.
    # A subtle bonus helps avoid fragmenting many small residuals.
    score += 0.03 * (bins == 100) * (item > 55)

    return score
