import numpy as np


def priority(item, bins):
    # Best fit: prefer the smallest remaining capacity that still fits.
    # Slight tie-breaking: prefer bins that are not completely unused unless
    # the fit is exact, to avoid opening new bins too early.
    remaining = bins - item
    score = -remaining

    # Strongly prefer an exact fit (remaining capacity 0 after placing item).
    exact = (remaining == 0)
    score[exact] += 1000.0

    # Mildly prefer reusing partially filled bins over untouched capacity-100 bins.
    untouched = (bins == 100)
    score[untouched] -= 0.01

    return score
