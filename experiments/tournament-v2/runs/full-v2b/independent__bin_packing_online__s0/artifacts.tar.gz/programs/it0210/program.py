import numpy as np


# Tuned constants (fixed, distribution-independent): balance tightness and spread.
ALPHA = 0.82
BETA = 0.10
GAMMA = 0.06
IDEAL_SLACK = 6.0


def priority(item, bins):
    # bins: remaining capacity of each fitting bin.
    # residual after placement would be bins - item (>= 0)
    residual = bins - item

    # Penalize both very tight (residual near 0) and very loose placements.
    # Reward bins that are already somewhat full (100 - bins small -> residual small).
    fit_term = -residual                      # prefer small residual (best fit)
    full_term = -(100 - bins)                 # prefer fuller bins (small remaining)
    slack_term = -np.abs(residual - IDEAL_SLACK)

    score = ALPHA * fit_term + BETA * full_term * 0.0 + GAMMA * slack_term
    # Simpler, more robust combination:
    score = -residual + 0.18 * slack_term
    return score
