import numpy as np


def priority(item, bins):
    """
    Online bin packing heuristic.

    The item must be placed immediately.  We use a size-dependent rule:
      - For small items, tightest fit (best fit) is usually excellent.
      - For larger items, we slightly prefer bins that are neither completely
        empty nor nearly full, because this helps preserve flexibility for
        future large items.

    bins is a numpy int64 array of remaining capacities.
    Returns a real-valued score for each bin; highest score wins.
    """
    b = bins.astype(np.float64)

    # Best-fit component: smaller remaining capacity after placement is better.
    # Score decreases with (remaining - item).
    left = b - item

    # Avoid leaving extremely tiny unusable holes: penalize fills that leave
    # less than a small threshold, especially for medium/large items.
    # Also encourage using partially filled bins over completely empty bins
    # when the fit is not too bad.
    if item <= 20:
        # Small items: pure best fit works very well.
        return -left

    if item >= 60:
        # Large items: prefer bins where they fit with some leftover, but not
        # a completely empty bin if a good partially filled one exists.
        # Slight preference for bins that already have some content.
        score = -left
        # Penalize leaving a very small residual gap.
        score -= 3.0 * np.maximum(0.0, 5.0 - np.abs(left))
        # Mild bias against opening a new bin for large-ish items.
        score -= 0.02 * (b == 100.0)
        return score

    # Medium items: balance tight fit with avoiding tiny residuals.
    score = -left
    # Penalize residuals in the awkward 0..8 range a bit.
    score -= 1.5 * np.maximum(0.0, 8.0 - np.abs(left))
    # Very small preference for already-open bins over empty ones.
    score -= 0.01 * (b == 100.0)
    return score
