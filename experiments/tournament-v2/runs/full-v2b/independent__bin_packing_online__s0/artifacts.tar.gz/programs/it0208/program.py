import numpy as np


def priority(item, bins):
    """Best-fit with a residual-aware tie-break.

    Primary objective: choose the bin with the smallest remaining capacity that still
    fits the item (best fit).  A small secondary term discourages creating tiny
    unusable residuals and slightly prefers fuller bins, which tends to reduce the
    number of bins opened for heavy-tailed item sizes.

    Returns higher scores for better bins.
    """
    # Residual after placing the item: smaller is better -> negate.
    residual = bins - item

    # Base score: strongest preference for tightest fit.
    score = -residual.astype(np.float64)

    # Mild penalty for very small residuals (hard to reuse) and slight bonus for
    # using bins that are already partially full over pristine bins.
    # This preserves best-fit ordering in the vast majority of decisions.
    score -= 0.02 * (residual < 5)
    score -= 0.01 * (residual < 15)
    score -= 0.005 * (bins == 100)

    return score
