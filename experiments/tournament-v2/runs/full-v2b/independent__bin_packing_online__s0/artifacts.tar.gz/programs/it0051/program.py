# EVOLVE-BLOCK-START
"""Hybrid bin-choice rule: mostly best-fit with a small anti-fragmentation bias."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # After placing, remaining capacity is bins - item.
    rem_after = bins - item

    # Primary: prefer tight fits (small remaining capacity).
    score = -rem_after.astype(np.float64)

    # Slight bonus for using a bin that is already partially filled, unless it is
    # completely empty. This helps avoid opening new bins too early.
    used = (bins < 100).astype(np.float64)
    score += 0.25 * used

    # Extremely small tie-breaker toward earlier bins.
    n = len(bins)
    score += np.arange(n, dtype=np.float64) * 1e-9

    return score
# EVOLVE-BLOCK-END
