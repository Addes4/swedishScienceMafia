"""Best-fit with used-bin tie-breaking to reduce fragmentation."""

import numpy as np

# Module-level state to adapt slightly over time (does not see future, only past).
_state = {
    "count": 0,
    "total": 0,
}


def priority(item, bins):
    """Score bins: prefer tightest fit, break ties toward already-used bins."""
    # Update running stats (not strictly needed but harmless and adaptive-ready).
    _state["count"] += 1
    _state["total"] += int(item)

    # Remaining capacity after placing the item. Lower = tighter fit.
    leftover = bins - item

    # Base score: tighter fit is better => higher score for smaller leftover.
    # Use a large negative multiplier so primary ordering is by leftover.
    score = -leftover.astype(np.float64) * 1000.0

    # Tie-break: prefer bins that are already partially used (leftover < 100)
    # over completely empty bins (leftover == 100). This keeps the number of
    # open/active bins lower and reduces fragmentation.
    # Since bins are shown as remaining capacity, an untouched bin has capacity 100.
    # After placing, an untouched bin would have leftover = 100 - item.
    # We add a small bonus to non-empty bins (bins < 100 means already used).
    used = (bins < 100).astype(np.float64)
    # Bonus large enough to matter for ties, small enough to not override fit.
    score += used * 0.5

    # Slight preference: if all fits are poor (item nearly fills a bin), that's fine.
    # If item is small, still prefer tightest existing bin via base score.

    return score
