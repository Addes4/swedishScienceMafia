"""Online bin-choice rule: gap-aware best fit with slight open-bin preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item          # residual capacity after placing the item
    # Best fit: small residual is good -> use negative residual.
    # However, avoid leaving tiny residuals that are hard to fill later.
    # Penalise residuals that are small but nonzero (dead space).
    # Also slightly prefer already-open bins (smaller original remaining) to
    # reduce the number of new bins opened.
    score = -rem * 100.0
    # Penalty for creating a small unusable gap: residual in (0, item)
    # can't fit another item of the same size; treat as slightly worse.
    # We use a smooth penalty around small residuals.
    small = (rem > 0) & (rem < 20)
    score[small] -= 50.0
    # Slight preference for opening fewer new bins: bins with rem == 100-item
    # are unused; penalise them a tiny bit relative to partially used bins.
    # An unused bin has remaining capacity 100.
    unused = bins >= 100
    score[unused] -= 1.0
    return score
