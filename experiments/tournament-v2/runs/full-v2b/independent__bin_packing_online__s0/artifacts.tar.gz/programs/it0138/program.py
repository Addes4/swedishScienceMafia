import numpy as np


def priority(item, bins):
    """Rank bins by best fit: maximize negative leftover capacity after placement."""
    return -(bins - item)
