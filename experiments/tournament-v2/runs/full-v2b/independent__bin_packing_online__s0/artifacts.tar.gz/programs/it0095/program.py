import numpy as np

# Best Fit / Best Fit Decreasing style online heuristic with a light "fresh bin" penalty
# and simple class tracking to reduce fragmentation.

_state = {
    "calls": 0,
}

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Strategy:
      - Strongly prefer bins that exactly fit the item (remaining == item).
      - Otherwise use tightest fit: prefer smaller remaining capacity after placement.
      - Slightly discourage opening completely empty bins when a nonempty option exists.
    This is a robust online policy for Weibull-like item sizes and generalizes well.
    """
    _state["calls"] += 1
    b = np.asarray(bins, dtype=np.int64)
    remaining_after = b - item

    # Base score: tighter fit is better -> smaller remaining_after is better.
    # Add a small bonus for exact fit.
    score = -remaining_after.astype(np.float64)

    # Exact fit gets a decisive bonus.
    score[b == item] += 1e6

    # Discourage opening fresh bins (remaining capacity 100) unless necessary.
    # Small penalty, enough to prefer existing partially-filled bins.
    score[b == 100] -= 0.25

    # Slight preference for bins that, after placing, become relatively more full.
    # This helps keep small residual spaces concentrated.
    with np.errstate(divide='ignore', invalid='ignore'):
        fullness = (100.0 - remaining_after) / 100.0
    score += 0.01 * fullness

    return score
