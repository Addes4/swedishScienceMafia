import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a mild preference against opening fresh bins."""
    # Base: prefer the tightest fit (smallest remaining capacity >= item).
    # bins are already filtered to those that fit, so bins >= item.
    tightness = -(bins - item)

    # Additional term: slightly discourage using a completely empty bin (cap 100)
    # when another fitting bin exists, since that tends to open more bins.
    # Compare against item to keep scale reasonable.
    empty_penalty = np.where(bins >= 100, -0.5, 0.0)

    return tightness + empty_penalty
