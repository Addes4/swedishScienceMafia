import numpy as np

_state = {
    "calls": 0,
    "sum_item": 0,
    "count": 0,
}

def priority(item, bins):
    """Adaptive best-fit: prefer the tightest feasible bin, but avoid leaving
    awkward large gaps when a slightly looser bin may preserve a useful slot."""
    s = _state
    s["calls"] += 1
    s["sum_item"] += item
    s["count"] += 1

    # Feasible bins are all bins with remaining capacity >= item.
    # Score highest for smallest remaining capacity after placing (best fit),
    # but use a mild penalty for creating very small residual capacity that
    # is unlikely to be useful, and a mild bonus for moderately full bins
    # that may still fit future items.
    residual = bins - item

    # Main best-fit component: smaller residual -> higher score.
    # Use exact tightness; this is the dominant term.
    score = -residual.astype(np.float64)

    # Small adjustment: penalize residuals in the hard-to-use range 1..7
    # because such bins are often wasted, while rewarding residuals that
    # retain a moderately useful chunk.
    r = residual.astype(np.int64)
    # Penalize tiny leftovers slightly; the strength is deliberately small.
    tiny = (r >= 1) & (r <= 7)
    score -= tiny * 0.35

    # Slight preference for a residual around 10-30 rather than 8-9,
    # to keep bins flexible for typical item sizes.
    good_leftover = (r >= 10) & (r <= 35)
    score += good_leftover * 0.10

    # Unused bins have residual = 100 - item. Best fit already deprioritizes
    # them when tighter bins exist, which is desirable for bin minimization.
    return score
