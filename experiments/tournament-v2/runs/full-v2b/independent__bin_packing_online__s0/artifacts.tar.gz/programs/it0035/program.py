"""Best-fit variant: tightly fit the item, slightly favoring more-used bins."""

import numpy as np


def priority(item, bins):
    # Best fit: prefer smallest remaining capacity that still fits.
    # bins - item is >= 0 since only fitting bins are shown.
    # Negate so highest score = tightest fit.
    # Add a tiny bonus for bins with less remaining capacity (more filled),
    # preserving best-fit ordering while breaking near-ties toward consolidation.
    rem = bins - item
    return -(rem.astype(np.float64) * 1024.0 + bins.astype(np.float64))
