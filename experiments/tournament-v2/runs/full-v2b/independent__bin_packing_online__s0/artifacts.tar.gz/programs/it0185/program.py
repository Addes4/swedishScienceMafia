import numpy as np

# State kept between calls (per instance, as harness creates fresh process per run typically)
_hist = []
_weight_sum = 0.0
_weight_cnt = 0


def priority(item, bins):
    """Score bins by a blend of best-fit and worst-fit.

    The blend is adaptive: we maintain a running estimate of item variability.
    For high-variance streams, we lean slightly toward best-fit to conserve
    large residuals; for low-variance streams, we lean slightly toward
    worst-fit to keep bins balanced and reduce fragmentation.
    """
    global _hist, _weight_sum, _weight_cnt

    # Record history (bounded, to keep memory and time O(1) in practice)
    _hist.append(item)
    if len(_hist) > 256:
        _hist.pop(0)

    # Adaptive blend weight based on observed dispersion relative to mean
    if len(_hist) >= 16:
        arr = np.asarray(_hist, dtype=np.float64)
        m = arr.mean()
        s = arr.std()
        if m > 0:
            cv = s / m
        else:
            cv = 0.0
        # cv typically in [0.5, 1.2] for Weibull(shape~1.5-ish scaled)
        # Map cv to weight w in [0.55, 0.85]: higher cv -> prefer best-fit more
        w = 0.55 + 0.30 * min(max((cv - 0.5) / 0.7, 0.0), 1.0)
    else:
        w = 0.7

    # Scores: best-fit term uses small remaining-after (good), worst-fit term
    # uses large remaining-capacity (good for balance). We blend by w.
    # best-fit component: - (bins - item) = item - bins  (higher when bins small)
    # worst-fit component: bins (higher when bins large)
    residual_after = bins - item  # >= 0 since bins only contain fitting bins
    best_fit_score = -(residual_after)
    worst_fit_score = bins

    scores = w * best_fit_score + (1.0 - w) * worst_fit_score
    return scores
