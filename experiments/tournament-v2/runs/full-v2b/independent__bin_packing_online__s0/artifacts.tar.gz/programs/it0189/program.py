"""Best-fit with an small bias against opening brand-new bins."""
import numpy as np


def priority(item, bins):
    # Bin remaining capacities in `bins`. Score higher = more preferred.
    # Tight fit: smaller leftover capacity should rank higher.
    # New-bin penalty: bins with capacity == 100 (empty) get a slight penalty
    # so we reuse partially filled bins when the fit quality is comparable.
    leftover = bins - item

    # Base score: negative leftover (a.k.a. tighter fit is better).
    score = -leftover.astype(np.float64)

    # Penalize completely empty bins slightly so that among nearly equal fits
    # we prefer an already-open bin. The penalty is small (less than 1 unit of
    # leftover capacity) so it only breaks near-ties.
    is_empty = (bins >= 100).astype(np.float64)
    score -= 0.05 * is_empty

    return score
