import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin whose remaining capacity is closest to the item size.

    Scoring is the negative residual (bins - item), so the bin that fits the item
    most tightly receives the highest score. Ties go to the first such bin.
    """
    return -(bins - item)
