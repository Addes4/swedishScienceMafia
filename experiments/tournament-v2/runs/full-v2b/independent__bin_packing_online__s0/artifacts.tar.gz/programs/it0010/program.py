import numpy as np


def priority(item, bins):
    """Rank bins by best fit with a mild penalty for leaving very small residual space.

    The item goes into the bin maximizing this score.  Best-fit alone is already strong
    for online bin packing with mean ~40 items; the extra term gently discourages leaving
    tiny unusable gaps without adding meaningful overhead.
    """
    residual = bins - item
    # Best fit: smaller residual -> higher score.
    score = -residual.astype(np.float64)
    # Mildly penalize leaving a tiny positive residual (wasted sliver),
    # but do not penalize exactly zero.
    small = (residual > 0) & (residual < 4)
    score[small] -= 0.5 * (4.0 - residual[small])
    return score
