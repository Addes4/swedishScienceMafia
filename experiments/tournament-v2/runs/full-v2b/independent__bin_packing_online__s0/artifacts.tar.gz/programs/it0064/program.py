"""Best-fit bin packing: place each item into the fullest bin that can still hold it."""
import numpy as np


def priority(item, bins):
    """Return a score per bin; highest score wins, ties go to the first such bin.

    Best-fit: prefer the bin whose remaining capacity is closest to the item size
    from above, i.e. minimize leftover capacity after placement.  Since the harness
    picks the highest score with first-bin tie-breaking, we return the negative of
    the leftover capacity.  Unused bins (capacity 100) are naturally least
    preferred unless nothing tighter fits, which is exactly the desired behaviour.
    """
    return -(bins - item)
