import numpy as np

# Harmonic-style choice: prefer bins whose remaining capacity equals the item size
# (exact fit), then best-fit. Slight preference to reuse existing bins over
# opening new empty ones by treating remaining==100 bins as marginally worse
# when a decent fitting bin exists.

def priority(item, bins):
    rem = bins.astype(np.int64)
    # exact match bonus (exact fits waste nothing)
    exact = (rem == item)
    # best fit: smaller remaining capacity is better once it fits
    # to avoid opening a new bin too eagerly, add a tiny penalty for rem==100
    score = -rem.astype(np.float64)
    score += exact.astype(np.float64) * 1000.0
    # discourage using completely empty bins unless exact/very tight fit;
    # but if item is large (>50), opening a new bin is often necessary
    if item <= 50:
        score[rem == 100] -= 0.5
    return score
