import numpy as np

# State for adaptive best-fit tie-breaker: running statistics of past item sizes.
_state = {
    "count": 0,
    "mean": 40.0,
    "hist": np.zeros(101, dtype=np.float64),  # histogram of item sizes seen
}


def priority(item, bins):
    """
    Best fit with an adaptive residual-value adjustment.

    Primary ordering: put the item into the bin where it leaves the least remaining
    capacity (classic best fit).  Secondary: among nearly equally good fits, prefer
    residuals that are likely to be usable by future items, estimated online.
    """
    global _state

    # Update online statistics about item sizes.
    _state["count"] += 1
    n = _state["count"]
    if item < 0:
        item = 0
    elif item > 100:
        item = 100
    _state["hist"][item] += 1.0

    # Empirical mean of observed item sizes.
    _state["mean"] += (item - _state["mean"]) / n

    # Residual capacities after putting the item in each bin.
    residual = bins - item

    # Base score: tightest fit gives highest score.
    score = -residual.astype(np.float64)

    # Small adaptive bonus for residuals that look "useful".
    # Estimate the probability that some future item exactly fits a residual r:
    # p(r) ~ hist[r] / n.  A residual of 0 is worthless (no bonus).
    # Use a smooth, bounded bonus to avoid destabilizing best fit.
    hist = _state["hist"]
    total = float(n)
    if total > 0:
        # Probability mass at exactly the residual size, smoothed.
        # residual is integer-valued; clip to valid range.
        res = residual.astype(np.int64)
        np.clip(res, 0, 100, out=res)
        prob = hist[res] / total
        # Prefer residuals with higher future-fit probability, but keep tiny.
        score += 0.05 * prob

    # Slight preference for using already-open bins rather than fresh ones
    # when fits are otherwise comparable: bins with remaining 100 are "new".
    # But do not overpower tight-fit primary rule.
    # Fresh bins are slightly less preferred than bins with close fits.
    is_fresh = bins >= 100
    score -= 1e-6 * is_fresh.astype(np.float64)

    return score
