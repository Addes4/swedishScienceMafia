import numpy as np

# State to track history of items (for adaptive scoring) and bins seen
_item_history = []
_bin_history = []

# Precomputed weights for gap sizes: favor leaving gaps that match common future item sizes.
# Distribution is Weibull-shaped mean ~40; common sizes near 30-50, but also many small.
# We'll compute a preference weight for the remaining gap after placement.
# The idea: if gap == 0, perfect. If gap fits a common item size exactly or slightly above, good.
# Small gaps that are "wasted" are penalized less if they can't fit future items.

# Since we can't know exact future, use an estimate of item size frequencies from a typical run.
_gap_weights = None

def _init_weights():
    global _gap_weights
    if _gap_weights is not None:
        return
    # Approximate Weibull distribution with shape k=1.5, scale=45 (mean ~40.7)
    # Generate many samples, count integer sizes
    np.random.seed(42)
    samples = np.random.weibull(1.5, 1000000) * 45.0
    samples = np.clip(np.round(samples), 1, 100).astype(int)
    counts = np.bincount(samples, minlength=101)
    freq = counts / counts.sum()
    # Gap weight: for a gap g, value = probability that a random item fits exactly in g
    # or can be packed in g with minimal waste.
    # Simpler: weight = freq[g] but also consider packing multiple items.
    # Use a smoothed version: gap weight = sum over item sizes <= g of freq[item] * (item / g)
    # This rewards gaps that are efficiently fillable.
    gap_w = np.zeros(101, dtype=float)
    for g in range(101):
        total = 0.0
        for s in range(1, g+1):
            total += freq[s] * (s / g if g > 0 else 0)
        gap_w[g] = total
    # Normalize so that 0 gap is best (perfect fill)
    gap_w[0] = 1.0
    # Penalize wasted space: final score for a bin is gap_w[gap] but we want smaller gap better.
    # Actually we want to score bins; higher score = better bin.
    # Best fit: prefer smallest gap (remaining after placement). So score = -gap.
    # But we can adjust: score = -gap + lambda * (gap_w[gap] - gap/100)? No.
    # Let's use: score = -gap + 0.3 * gap_w[gap] * 100? Hmm.
    # Simpler approach: score = -(gap) + 0.1 * freq[gap] * 100? Let's just do best-fit with small bonus for exact fits.
    # We'll set score = -gap + 0.5 * (gap_w[gap] * 100) - 0.5 * gap
    # This is heuristic. Let's just use best fit first, and break ties by preferring gaps that match common items.
    _gap_weights = gap_w
    return

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _gap_weights
    if _gap_weights is None:
        _init_weights()
    # bins is remaining capacity of bins the item fits in (all >= item)
    # Compute gap after placing item
    gaps = bins - item
    # Best-fit: smaller gap is better -> higher score = -gap
    # Add small tie-breaker bonus for gaps that are "useful" (fill well)
    # Use gap_weights to favor gaps that can accommodate common future items.
    # Score = -gap * 1.0 + gap_weights[gaps] * 0.5
    # But gaps can be large; gap_weights is 0..1. So adding up to 0.5 might override gap differences.
    # Scale gap term: -gap * 2.0 + gap_weights[gaps] * 1.0
    # Actually, keep primary sort by gap, secondary by gap_weights.
    # To do this numerically: score = -gap * 1000 + gap_weights[gaps] * 1.0
    # This makes gap dominate completely, gap_weights only breaks ties.
    # But we might want to allow small deviation when gap difference is tiny? No, best-fit is strong.
    # Let's use: score = -gaps * 1000.0 + gap_weights[gaps] * 1.0
    # Ensure no NaN (gaps >= 0)
    gaps_clipped = np.clip(gaps, 0, 100)
    weights = _gap_weights[gaps_clipped]
    return -gaps.astype(np.float64) * 1000.0 + weights
