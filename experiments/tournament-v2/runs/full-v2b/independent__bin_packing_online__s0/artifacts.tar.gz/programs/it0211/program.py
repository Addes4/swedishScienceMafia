# EVOLVE-BLOCK-START
"""Best-fit with anti-fragmentation bias.

Primary key: tightest fit (largest remaining-capacity usage).
Secondary key: avoid leaving very small, likely-unusable remainders.
"""
import numpy as np


def priority(item, bins):
    # Classic best fit: prefer smallest resulting remainder.
    rem = bins - item  # >= 0 for all shown bins
    # Penalize tiny remainders that waste capacity (can't fit much later).
    # A remainder r is "good" if r is either 0 or reasonably large; small
    # positive remainders waste a whole bin slot poorly.
    tiny = (rem > 0) & (rem < 20)
    score = -rem.astype(np.float64)
    score[tiny] -= 1000.0  # strongly discourage wasting a bin on a tiny leftover
    return score
# EVOLVE-BLOCK-END
