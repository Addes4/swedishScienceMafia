import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin that leaves the smallest remaining capacity."""
    return -(bins - item)
