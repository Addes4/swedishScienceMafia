import numpy as np


def priority(item, bins):
    """Hybrid best-fit: tightest fit, with a penalty for opening new bins and
    a reward for leaving a residual that can still hold small items."""
    rem = bins.astype(np.int64)
    # leftover after placing the item
    leftover = rem - item

    # Base: prefer tightest fit (smallest leftover) -> -leftover is best fit.
    score = -leftover.astype(np.float64)

    # Penalize using completely empty (fresh) bins: we'd rather reuse an open bin
    # even if the fit is slightly looser, to avoid increasing the bin count.
    fresh = (rem == 100)
    score[fresh] -= 60.0

    # Slightly reward leftovers that are "nice" (can still fit typical small items)
    # to reduce fragmentation: leaving a residual in [1..40] is generally worse than
    # leaving a small exact-ish fit. Encourage near-full residuals.
    # Penalize leaving small unusable slivers (leftover in 1..10).
    sliver = (leftover >= 1) & (leftover <= 10)
    score[sliver] -= 5.0

    # Reward perfect fills strongly.
    perfect = (leftover == 0)
    score[perfect] += 50.0

    return score
