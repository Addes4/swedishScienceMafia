import numpy as np

# State kept across calls: cumulative counts of item sizes seen so far.
# This gives a rough online estimate of the size distribution.
_counts = np.zeros(101, dtype=np.float64)
_total = 0

# Small deterministic dithering to avoid pathological ties among equivalent bins.
# It is based on bin remaining capacity only, not on call order, so it stays stable.
def _dither(cap):
    x = (cap * 1103515245 + 12345) & 0x7fffffff
    return (x % 1000) * 1e-9


def priority(item, bins):
    global _counts, _total

    # Update running distribution estimate.
    _counts[item] += 1.0
    _total += 1.0

    b = bins.astype(np.float64)
    residual = b - float(item)

    # -----------------------------
    # Base: best fit / tight fit.
    # Prefer small residual, especially exact fits.
    # -----------------------------
    score = -residual

    # Strong bonus for exact fit, since it wastes no capacity.
    exact = (residual == 0.0)
    score[exact] += 50.0

    # -----------------------------
    # Harmonic / waste-shape bonus.
    # A waste w is more useful if future items are likely to fit into it.
    # We reward small wastes that are close to common item sizes.
    # Use the empirical item-size distribution seen so far.
    # -----------------------------
    # Common target sizes: around the mean and around small sizes.
    # Harmonic packing intuition: prefer leftovers that can be filled by
    # typical upcoming items, not just tiny scraps.
    common = np.array([20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0, 60.0, 70.0, 80.0])

    # For each bin, measure closeness of waste to some useful item size.
    # Compute in a vectorized way.
    w = residual
    # closeness to best common target
    d = np.minimum.reduce([np.abs(w - c) for c in common])
    # Reward wastes near useful sizes, but never reward huge waste too much.
    useful = np.exp(-d / 8.0)
    score += 4.0 * useful

    # Also mildly prefer leaving a bit of room for medium items.
    # This helps avoid many almost-full bins that block future medium arrivals.
    score += 0.02 * np.minimum(w, 100.0) * (w < 45.0)

    # -----------------------------
    # Adaptive distribution bonus:
    # Reward bins whose residual could still accept likely future items.
    # Estimate probability that a random future item fits in the residual.
    # -----------------------------
    if _total > 0:
        p = _counts / _total
        # For each residual w, probability next item <= w.
        # Since sizes are 1..100, cumulative distribution.
        cum = np.cumsum(p)
        # Clip residual to [0,100] for indexing.
        idx = np.clip(residual.astype(np.int64), 0, 100)
        fit_prob = cum[idx]
        score += 3.0 * fit_prob

    # -----------------------------
    # Penalize large one-bin waste less when item is large,
    # and penalize opening a fresh bin more when we already have many bins.
    # This is the classic "avoid new bins" pressure, but softened.
    # -----------------------------
    # Fresh bins have residual 100 - item.
    # Prefer using existing bins when possible by slightly penalizing unused bins.
    fresh = (b == 100)
    score[fresh] -= 2.0

    # Tie-break slightly by bin order via stable tiny noise.
    score += _dither(b)

    return score
