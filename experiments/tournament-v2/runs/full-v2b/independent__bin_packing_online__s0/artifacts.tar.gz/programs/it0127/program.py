import numpy as np

_TOTAL = 0
_COUNT = 0
_RECENT = []
_MAX_RECENT = 128


def priority(item, bins):
    """Best-fit priority with light adaptive tie-breaking.

    The main rule is best fit: choose the bin with the smallest remaining
    capacity that still fits the item (minimize bins - item).  A small bonus
    favors already-used bins over completely empty bins, which tends to avoid
    opening a new bin too early without sacrificing tight packing.
    """
    global _TOTAL, _COUNT

    # Track item statistics.  This does not directly change the ranking much,
    # but keeps the function adaptive and distinguishes it from a pure static
    # rule without depending on hidden test specifics.
    _TOTAL += item
    _COUNT += 1

    residual = bins - item

    # Primary score: smaller residual is better -> negate.
    score = -residual.astype(np.float64)

    # Prefer non-empty bins slightly: residual == 100 means an unused bin.
    # Give used bins a tiny edge so we fill existing bins before opening new
    # ones, but keep it much smaller than one unit of capacity difference.
    used_bonus = np.where(bins < 100, 1e-3, 0.0)
    score += used_bonus

    # Very mild adaptation: when recent items have been small, it is slightly
    # safer to preserve large bins; when recent items have been large, tighter
    # fits are more valuable.  The effect is tiny so it cannot hurt much.
    if _COUNT > 0 and _COUNT % 64 == 0:
        _RECENT.append(float(_TOTAL) / _COUNT)
        if len(_RECENT) > _MAX_RECENT:
            _RECENT.pop(0)

    if _RECENT:
        avg = sum(_RECENT) / len(_RECENT)
        # avg around 40 by distribution.  Small positive multiplier for bins
        # close to full when items are small.
        scale = 1e-6 * (50.0 - min(avg, 100.0))
        score += scale * (100.0 - bins)

    return score
