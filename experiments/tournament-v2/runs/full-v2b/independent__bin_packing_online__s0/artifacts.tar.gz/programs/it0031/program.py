import numpy as np

# State: track recent average item size to switch strategies.
_state = {
    "n": 0,
    "sum": 0.0,
}

def priority(item, bins):
    """Rank fitting bins: best-fit normally, with tie-breaking that favors filling partially-used bins."""
    # bins are remaining capacities (int64). We want the smallest remaining capacity that still fits
    # (best fit), but break ties/plates by preferring bins whose residual after placement is small.
    residual = bins - item  # >= 0 since bins are only those the item fits in

    # Score: higher is better. Best fit -> minimize residual.
    # Use a small negative penalty on residual and a tiny bonus for bins that are not empty.
    score = -residual.astype(np.float64)

    # Slight preference against opening new bins when an equally good fit exists:
    # unused bins have bins == 100 (residual == 100 - item). Penalize those marginally.
    unused_mask = (bins == 100)
    score -= unused_mask.astype(np.float64) * 1e-6

    # Tiny stabilization: prefer earlier bins on exact ties (numpy argmax picks first anyway,
    # but adding a minuscule index term avoids floating noise misordering).
    idx = np.arange(len(bins), dtype=np.float64)
    score -= idx * 1e-12

    return score
