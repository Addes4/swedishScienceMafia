"""Online bin packing: refined best-fit rule."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base: best fit -> prefer bins where the item fits most tightly.
    base = -(bins - item)

    # Penalize opening brand-new bins (remaining capacity == 100) slightly,
    # so existing bins are filled first when reasonable.
    # But for large items, opening a new bin is often good, so reduce penalty.
    # The penalty decreases with item size.
    new_bin = bins == 100

    # penalty magnitude: larger candidates for empty bins get less penalty.
    # scale: item size from 1..100.
    # We want large items to be willing to start fresh bins.
    penalty = np.where(new_bin, 0.5 * (100 - item) - 50.0, 0.0)

    return base - penalty
