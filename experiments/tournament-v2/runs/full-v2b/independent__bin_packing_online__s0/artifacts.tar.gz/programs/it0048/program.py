import numpy as np


def priority(item, bins):
    # Base: best fit, lower residual after placement is better.
    residual = bins - item

    # Small tie-breaking preference against wasting large fresh bins.
    # This encourages filling partially used bins first near the boundary.
    score = -residual.astype(np.float64)

    # Slight preference for bins whose residual is small but not zero,
    # and a mild penalty for using completely empty bins.
    score += 0.002 * (residual == 0)
    score -= 0.001 * (bins == 100)

    return score
