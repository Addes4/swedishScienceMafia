import numpy as np


def priority(item, bins):
    """Best fit with tie-breaking that discourages opening new bins.

    Higher score = better bin.  Primary term favors the tightest fit
    (smallest remaining capacity after placement), i.e. largest occupied load.
    A small secondary term favors bins with larger remaining capacity *before*
    placement only among bins that give the same tightness, which effectively
    prefers existing partially filled bins over empty ones when the post-placement
    residual is identical.
    """
    # Post-placement remaining capacity.
    after = bins - item

    # Primary: prefer smallest after (best fit).  Since we return scores where
    # higher is better, use the negative of `after`.
    primary = -after.astype(np.float64)

    # Secondary: among equal `after`, prefer smaller `bins`?  Wait:
    # if `after` is equal, then bins are equal because after = bins - item, so
    # no tie can occur from that term.  The real tie among bins with different
    # `after` should not be broken arbitrarily.  But when several bins have the
    # same minimum residual, they also have identical remaining capacity.
    # To avoid opening new bins unnecessarily, prefer bins that are already
    # partially filled over completely empty bins only when the item fits
    # equally well in both.  That case has the same `bins` value, so it is a
    # true tie.  We cannot distinguish empty from partially filled by `bins`
    # alone in that exact tie, but the harness breaks ties by bin index, which
    # usually uses earlier (older) bins first.  That is already desirable.
    #
    # A tiny term based on the current remaining capacity can help prefer
    # fuller bins without changing the best-fit ordering.  Scale it so it is
    # smaller than the smallest possible difference in the primary term (1).
    secondary = -bins.astype(np.float64) * 1e-6

    return primary + secondary
