import numpy as np

def priority(item, bins):
    # Score bins: prefer the bin with the smallest remaining capacity after placing the item,
    # i.e. tightest fit (best fit). This equals maximizing (item - remaining_capacity),
    # or minimizing remaining_capacity - item.
    # We negate so that the highest score corresponds to the smallest resulting free space.
    # Tie-breaking favors earlier bins automatically due to argmax behavior.
    free_after = bins - item
    return -free_after
