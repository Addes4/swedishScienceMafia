# EVOLVE-BLOCK-START
"""Improved online bin packing: best fit with residue-aware tie-breaking."""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0

    def update(self, item):
        self.count += 1
        self.total += item

    @property
    def mean(self):
        if self.count == 0:
            return 40.0
        return self.total / self.count


_stats = _Stats()


def priority(item, bins):
    """Rank bins: tightest fit, but break ties by preferring fuller bins.

    The item goes to the highest score; ties go to the first bin.
    We use a score that primarily minimizes remaining capacity after placing
    the item (best fit), with a small adjustment so that among equally tight
    fits the bin with the least leftover is chosen.
    """
    _stats.update(item)

    # Remaining capacity after this item would be placed.
    leftover = bins - item  # non-negative for all bins shown

    # Best fit: smaller leftover is better, so negate.
    # Add a tiny preference against leaving bins far from the running mean size,
    # which mildly encourages filling bins to a consistent level.
    mean = _stats.mean

    # Tie-break / secondary objective: penalize leftover values that are far
    # from the expected next-item scale, but keep primary term dominant.
    scale = 1.0 / (101.0 * 101.0)
    secondary = -((leftover - mean) ** 2) * scale

    return -(leftover.astype(np.float64)) + secondary
# EVOLVE-BLOCK-END
