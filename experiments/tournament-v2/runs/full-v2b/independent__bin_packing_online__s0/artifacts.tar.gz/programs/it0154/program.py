import numpy as np

def priority(item, bins):
    # Best fit: prefer bins where the item fits most tightly.
    # Slight preference against opening brand-new bins (remaining == 100),
    # to encourage consolidating into already-used bins.
    leftover = bins - item
    # Score is higher for smaller leftover, but empty bins get a tiny penalty.
    # Since higher score wins, use negative leftover.
    score = -leftover.astype(np.float64)
    # Penalize entirely empty bins slightly (only when item < 100).
    if item < 100:
        score = score - 1e-6 * (bins == 100)
    return score
