import numpy as np

# State to track slight adaptivity: we keep a tiny amount of statistics
_state = {"count": 0}

def priority(item, bins):
    """
    Best-fit with a perfect-fit bonus and fuller-bin preference.

    The item goes to the bin with the highest score.
    Base idea: best fit (minimize leftover capacity after placing item).
    Add a bonus if leftover is zero or very small (avoids fragmentation).
    Add a tiny preference for bins with smaller remaining capacity
    (i.e., fuller bins) to concentrate items.
    """
    # remaining capacity after placing item
    rem_after = bins - item

    # Score: higher is better.
    # - Prefer smaller rem_after (best fit): use negative.
    # - Bonus for perfect or near-perfect fits.
    # - Small bonus for fuller bins (smaller bins).
    score = -(rem_after.astype(np.float64))

    # Perfect fit bonus
    perfect = (rem_after == 0)
    score = score + perfect * 5.0

    # Near-perfect fit bonus (leave little room, but not zero)
    near = (rem_after > 0) & (rem_after <= 3)
    score = score + near * 1.0

    # Slight preference for fuller bins (smaller remaining capacity)
    # This helps concentrate items and reduce number of open bins.
    score = score - 0.001 * bins.astype(np.float64)

    _state["count"] += 1
    return score
