import numpy as np


def priority(item, bins):
    """Best-fit with tie handling: prefer the tightest fit; break near-ties toward larger residuals."""
    # Distance from exact fit: zero for exact fit, positive otherwise.
    # Primary score is negative distance, so larger is better.
    score = -(bins - item).astype(np.float64)

    # Small secondary term: among bins with equal fit distance, prefer the one
    # leaving a slightly larger residual, which tends to preserve flexibility.
    score += 1e-6 * bins.astype(np.float64)

    return score
