import numpy as np


def priority(item, bins):
    # Best fit: prefer the tightest remaining capacity after placing item.
    return -(bins - item)
