import numpy as np

# Module-level state to track observed items across calls.
_seen_sum = 0.0
_seen_count = 0


def priority(item, bins):
    """Score bins for online bin packing.

    The rule is a tuned best-fit / reserve heuristic:
      - Strongly prefer bins where the item fits tightly (small remaining-after).
      - Add a small bonus for not opening a fresh bin when a used bin can take it.
      - Use the running mean item size to choose residual capacities that are likely reusable.
    """
    global _seen_sum, _seen_count

    _seen_sum += item
    _seen_count += 1
    mean_size = _seen_sum / _seen_count

    # residual capacity after placing the item in each bin
    residual = bins - item

    # Base: best fit. Smaller residual -> higher score.
    scores = -residual.astype(np.float64)

    # Identify unused bins (capacity exactly 100). They are interchangeable but
    # we want to open them only when necessary.
    unused = bins == 100

    # Penalize using a completely empty bin slightly, unless no used bin fits well.
    # The penalty is small enough not to override strong best-fit differences.
    scores -= unused * 1e-3

    # Encourage residuals that are close to a multiple-free "usable" leftover.
    # We reward residuals that can still hold at least one typical item, but
    # we don't want to leave a tiny unusable sliver.
    # A residual r is good if r >= mean_size (can fit a typical future item).
    usable = residual >= mean_size
    unusable_small = (residual >= 0) & (residual < mean_size)

    # Slight preference for a residual that is just under a typical item size?
    # No: prefer leaving capacity that is likely useful.
    scores += usable * 0.5
    scores -= unusable_small * 0.25

    # Small deterministic tie-breaker: earlier bins preferred if all else equal.
    # Since ties go to first, we don't need to add index explicitly, but adding
    # a negligible decreasing term preserves that.
    n = bins.shape[0]
    scores -= np.arange(n, dtype=np.float64) * 1e-9

    return scores
