"""Online bin packing heuristic: best-fit with open-bin preference and residual-shape bias."""

import numpy as np

# --- State kept across calls (allowed by the problem) ---
_HIST = np.zeros(101, dtype=np.float64)   # distribution of seen item sizes
_CALLS = 0
_TOTAL = 0.0

# Residual capacities we like to leave, to enable future packing.
# Small residuals are generally good (tight packing), so we bias towards tight fits,
# but we add a mild preference for residuals that match common item sizes remaining.
_ITEM_MEAN = 40.0


def _target_residual(item):
    # A heuristic "good residual" to leave: enough room for a typical small/medium item,
    # but not so much that we waste a bin. Roughly a mid-sized leftover.
    return 30.0


def priority(item, bins):
    """Rank bins: prefer tightest fit, but strongly prefer reusing already-opened bins.

    bins contains remaining capacities of all bins the item fits in. Unused bins are 100.
    The item goes to the bin with the highest score; ties go to first (lowest index).
    """
    global _CALLS, _TOTAL

    # Update lightweight statistics (cheap, no future info used).
    _CALLS += 1
    _TOTAL += item
    _HIST[item] += 1.0

    b = bins.astype(np.float64, copy=True)
    n = b.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    residual_after = b - float(item)

    # Best-fit base: tighter fits (smaller residual_after) score higher.
    # Using negative residual gives highest score to smallest leftover.
    score = -residual_after

    # Prefer already-opened bins (remaining < 100) over fresh bins (== 100).
    # A fresh bin leaves residual 100 - item; an opened bin may be a better or worse fit.
    # We add a bonus to non-full bins so we fill existing bins before opening new ones,
    # unless a fresh bin clearly gives a better (tighter) fit.
    opened = b < 100.0
    score += opened * 8.0

    # Fraction of fully unused bins available so far (avoid hoarding fresh bins when many exist).
    fresh = b >= 100.0
    n_fresh = int(fresh.sum())

    if n_fresh > 0:
        # If there are plenty of fresh bins, reduce the opened bonus slightly so we still
        # pack tightly. If nearly all bins are fresh, best-fit dominates.
        opened_bonus_scale = 1.0
        if n_fresh > 0.5 * n:
            opened_bonus_scale = 0.35
        elif n_fresh > 0.2 * n:
            opened_bonus_scale = 0.7
        # Recompute opened bonus with scale (subtract original and add scaled).
        score -= opened * 8.0
        score += opened * (8.0 * opened_bonus_scale)

    # Residual-shape bias: gently prefer leftovers that are "useful".
    # Perfect fit (residual 0) is ideal; near-perfect is great.
    # Discourage leaving huge unusable-but-open residues (like just under 100) only mildly.
    ra = residual_after
    # Reward exact fits and small leftovers.
    score += np.where(ra < 1e-9, 3.0, 0.0)
    # Mildly penalize very large leftovers on opened bins (they waste space).
    large_left = (ra > 70.0) & opened
    score -= large_left * 1.5

    # Slight preference to match a "sweet spot" leftover for fitting future typical items.
    target = 25.0  # ideal leftover to absorb future medium items
    score -= 0.02 * np.abs(ra - target)

    # Add small deterministic tie-breaker using bin index (earlier bins preferred on ties).
    # Since ties go to first, use index-based decay to make ranking stable.
    idx = np.arange(n, dtype=np.float64)
    score -= idx * 1e-6

    return score
