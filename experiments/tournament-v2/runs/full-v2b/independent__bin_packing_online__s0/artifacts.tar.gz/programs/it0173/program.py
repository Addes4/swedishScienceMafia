import numpy as np


class _State:
    """Global state kept between calls: item-size frequencies and a size ordering."""

    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.item_no = 0
        # order of preferred 'sizes to match': initially just reverse size (big first)
        self.order = np.arange(100, 0, -1, dtype=np.int64)
        self.dirty = 0

    def record(self, item):
        self.counts[item] += 1.0
        self.item_no += 1


_state = _State()


def priority(item, bins):
    """Rank bins for the arriving item.

    Strategy:
      * base score = best fit (prefer the bin with least remaining capacity that
        still fits the item),
      * strong bonus when the item exactly fills a bin,
      * mild bonus for bins that are already relatively full (encourage packing
        into existing bins before opening a fresh one),
      * tiny deterministic offset using bin index through remaining capacity to
        break ties consistently,
      * keep the score strictly decreasing in remaining capacity so the rule is
        a pure best-fit augmented by the above bonuses.
    """
    _state.record(item)

    n = bins.shape[0]
    # remaining capacities >= item (guaranteed by caller for shown bins)
    rem = bins.astype(np.int64)

    # Best-fit base: tighter fit (smaller remaining capacity) gets higher score.
    score = (100 - rem).astype(np.float64)  # larger for fuller/tighter bins

    # Exact-fill bonus.
    exact = (rem == item)
    score[exact] += 1000.0

    # Prefer fuller bins generally (encourage using already-open bins).
    score += (100.0 - rem.astype(np.float64)) * 0.5

    # Very small tie-break so all unused bins (rem==100) are ordered by index
    # consistently, and among equal remaining capacities the earlier bin wins.
    # Using capacity is enough; add a tiny decreasing term in index by capacity.
    return score
