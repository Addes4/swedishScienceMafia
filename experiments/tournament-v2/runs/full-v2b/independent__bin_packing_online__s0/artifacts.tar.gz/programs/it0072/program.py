import numpy as np


def priority(item, bins):
    """Score bins for best-fit with a small preference for already-used bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    # Base score: prefer the bin where leftover capacity after placing the item is smallest.
    score = -(bins - item).astype(np.float64)

    # Mildly discourage opening brand-new bins: bins with remaining capacity exactly 100
    # are empty, so subtract a small penalty. This tends to preserve empty bins.
    score -= np.where(bins == 100, 0.5, 0.0)

    return score
