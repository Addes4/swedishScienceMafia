"""Best-fit with a small preference for already-nearly-full bins.

The item is placed into the bin where it leaves the least free space
(classic Best Fit).  Among bins that achieve the same leftover space,
we prefer the bin that had less capacity left before the placement,
which slightly favours filling already-used bins and avoids opening
new ones prematurely.
"""

import numpy as np


def priority(item, bins):
    # Leftover capacity if the item were put into each bin.
    leftover = bins - item

    # Primary key: smallest leftover (best fit) -> larger score.
    # Secondary key: smallest original remaining capacity -> larger score.
    # The secondary term is tiny so it only breaks ties.
    return -(leftover * 1000 + bins)
