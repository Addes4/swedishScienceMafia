"""Online bin packing: best-fit with a bias toward closing already-used bins."""
import numpy as np

_state = {"last_item": 0}

def priority(item, bins):
    # Remaining capacity after placing item into each bin
    rem = bins - item  # all bins in `bins` fit the item, so rem >= 0

    # Base score: prefer smaller remaining capacity (best fit)
    # Negative rem so higher score = tighter fit
    score = -rem.astype(np.float64)

    # Bonus: bins that are already in use (capacity < 100 before placing)
    # Slight preference to not open new bins when a used bin is a decent fit.
    used = (bins < 100).astype(np.float64)
    score += 0.5 * used

    # Extra bonus for bins that become nearly full (closes them)
    # This helps reduce the number of open/used bins.
    nearly_full = (rem <= 10).astype(np.float64)
    score += 1.0 * nearly_full

    return score
