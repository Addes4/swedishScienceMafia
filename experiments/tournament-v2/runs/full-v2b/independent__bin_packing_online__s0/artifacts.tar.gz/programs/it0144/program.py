import numpy as np


def priority(item, bins):
    """Score bins by best fit, with a small tie-breaking preference for fuller bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities the item fits into, in bin order.
    """
    # Remaining space after insertion: smaller is better (best fit).
    residual = bins - item

    # Prefer tighter fits.  Subtracting a tiny fraction of residual makes fuller bins
    # win among equal residual, while preserving best-fit ordering.
    return -residual.astype(np.float64) - 0.001 * bins.astype(np.float64)
