"""Best-fit with exact-fit preference and gap-avoidance tie-breaking."""
import numpy as np


def priority(item, bins):
    # Score = -remaining_capacity_after_placement, i.e. prefer the tightest fit.
    # Add a tiny bonus for exact fits to break ties toward zero waste.
    leftover = bins - item
    score = -leftover.astype(np.float64)
    # Exact fit gets a meaningful boost (leftover 0).
    score += (leftover == 0) * 0.5
    return score
