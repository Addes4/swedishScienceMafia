"""Improved online bin packing heuristic.

The rule is a refined best-fit: always prefer exact fits, then bins whose
remaining capacity after placement lands in favorable residual classes.  These
classes are meant to encourage filling bins tightly without sacrificing the
robustness of ordinary best-fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    residual = bins - item

    # Primary score: exact fit is always best.
    exact = (residual == 0).astype(np.float64) * 1_000_000.0

    # Secondary score: penalize residual capacities that are hard to fill,
    # while rewarding small residuals and a few useful intermediate leftovers.
    # This is still close to best-fit but slightly more selective.
    r = residual.astype(np.float64)

    # Base best-fit pressure: smaller residual is better.
    score = -r

    # Avoid leaving tiny awkward residues less than the smallest item size.
    score -= (r == 1) * 8.0
    score -= (r == 2) * 6.0
    score -= (r == 3) * 5.0
    score -= (r == 4) * 4.0
    score -= (r == 5) * 3.0

    # Mild preference for residual ranges that often combine well.
    score += (r == 10) * 1.5
    score += (r == 15) * 1.2
    score += (r == 20) * 1.0
    score += (r == 25) * 0.8
    score += (r == 30) * 0.6
    score += (r == 35) * 0.4
    score += (r == 40) * 0.2

    # Prefer bins that are already partially filled over untouched bins,
    # except when the item exactly fills or leaves a very good residual.
    score += (bins < 100).astype(np.float64) * 0.25

    return exact + score
