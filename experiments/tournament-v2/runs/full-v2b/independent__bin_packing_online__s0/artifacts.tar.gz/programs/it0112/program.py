import numpy as np


def priority(item, bins):
    """Rank bins for online packing.

    Main idea: best-fit (tightest remaining capacity) is a strong online rule.
    Modifications:
      1) When the item is small (<= 50), slightly penalize choosing (near-)empty
         bins, so they remain available for future large items.
      2) Best-fit still dominates for larger items.
    Ties break to the first bin, so ordering among equal scores matters.
    """
    rem = bins.astype(np.int64, copy=False)

    # Best-fit score: prefer the bin whose remaining capacity is closest to item
    # (smallest leftover after placing). leftover = rem - item.
    leftover = rem - item

    # Base score: negative leftover (bigger is better => tighter fit).
    score = -leftover.astype(np.float64)

    # Small items: don't waste pristine/fresh bins.
    if item <= 50:
        # Empty-ish bins get a mild penalty; the emptier, the worse, but only
        # for very empty ones. Penalty grows as remaining capacity -> 100.
        # Scale so it never dominates best-fit among already-used bins.
        empty_pen = np.where(rem >= 90, (rem - 90) * 0.5, 0.0)
        score -= empty_pen

    # For items that fit in at most half: prefer bins that are more than half full
    # relative to remaining capacity patterns (classic "don't open/use new bin").
    # If there exists a bin where placing the item keeps leftover small AND the bin
    # was already somewhat full, that's naturally captured by best-fit.

    return score
