"""Online bin packing: residual-first best fit with a small load-balancing tie-break."""
import numpy as np


def priority(item, bins):
    """Score bins so the item goes into the tightest-fitting reasonably-packed bin.

    The main term is -(remaining - item), i.e. best fit: highest score = smallest
    leftover space after placement. A tiny secondary term favors bins that are
    already in use over fresh empty bins when leftovers tie, which tends to preserve
    empty bins for larger future items and avoids needlessly opening new bins.
    """
    residual = bins - item                     # leftover space if item placed here
    # Primary: best fit (smaller residual is better -> larger negative is better).
    score = -residual.astype(np.float64)
    # Secondary: gently prefer non-empty bins on exact ties to avoid opening new bins.
    # Empty bins have remaining capacity 100.
    score += np.where(bins == 100, -1e-6, 0.0)
    return score
