"""Best-fit bin choice with a small consolidation bias."""

import numpy as np


def priority(item, bins):
    """Rank bins by tightness of fit; prefer the fullest bin among equal wastes.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of fitting bins.
    """
    # Resulting remaining capacity after placing the item.
    remaining = bins - item

    # Primary objective: minimize leftover space (best fit).
    # Secondary tie-break: prefer the bin that is currently fuller
    # (smaller current remaining capacity) to encourage consolidation.
    # Scale tie-break so it never overrides the primary term.
    return -(remaining.astype(np.float64)) - 1e-6 * bins
