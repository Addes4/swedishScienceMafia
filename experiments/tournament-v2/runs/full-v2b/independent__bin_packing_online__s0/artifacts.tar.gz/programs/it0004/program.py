import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin where the item leaves the least free space.
    # A tiny tie-break nudges toward already-used bins and away from perfect
    # fragmentation (leftover small but nonzero), which helps Weibull sizes.
    leftover = bins - item
    score = -leftover.astype(np.float64)

    # Prefer bins that were already nonempty (avoid wasting a fresh bin when
    # an equally good fit exists), and slightly prefer filling to exactly zero
    # or leaving a relatively large residual over creating tiny unusable slivers.
    score += np.where(bins == 100, -1e-6, 0.0)
    score += np.where((leftover > 0) & (leftover < 5), -1e-7, 0.0)
    return score
