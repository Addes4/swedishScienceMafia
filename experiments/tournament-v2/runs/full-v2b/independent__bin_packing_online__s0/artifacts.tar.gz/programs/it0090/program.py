"""Online bin packing heuristic.

Primary rule: best fit (minimize remaining capacity after insertion).
Secondary rule: among equal residuals, prefer the earlier bin index (already
handled by tie-breaking), which tends to keep newer/emptier bins available.
"""

import numpy as np


def priority(item, bins):
    # Best fit: higher score when residual capacity is smaller.
    # The harness breaks ties by first bin index, which is desirable here.
    return -(bins - item)
