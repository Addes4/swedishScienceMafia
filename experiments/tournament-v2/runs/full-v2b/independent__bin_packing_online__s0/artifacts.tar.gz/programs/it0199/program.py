"""Best-fit variant for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    Strategy: primarily best fit (tightest remaining space after placement), with a
    slight bonus for exactly-filling a bin and a mild preference to use bins that
    are already partially used (avoid opening fresh bins unnecessarily).
    """
    rem_after = bins - item  # remaining capacity after placing item

    # Base score: tighter fit is better -> smaller rem_after is better.
    # Scale to keep integer-ish separations and allow bonuses below.
    score = -rem_after.astype(np.float64) * 1000.0

    # Bonus for exactly filling the bin (rem_after == 0): strongly preferred.
    score += (rem_after == 0).astype(np.float64) * 100000.0

    # Mild preference for bins that are already in use (remaining < 100) to avoid
    # opening brand-new bins when a used bin is nearly as good a fit.
    used = bins < 100
    score += used.astype(np.float64) * 20.0

    # Avoid using a fresh empty bin unless it's clearly the best option: penalize
    # full-capacity bins slightly so a used bin of similar fit wins ties.
    fresh = bins >= 100
    score -= fresh.astype(np.float64) * 10.0

    return score
