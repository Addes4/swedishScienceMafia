import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin whose remaining capacity is closest to the item.
    # score = (residual gap after placing), lower is better => use negative.
    gap = bins - item
    # Primary: smallest nonnegative gap (best fit).
    # Secondary: among equal gaps, slightly prefer fuller bins (smaller remaining capacity).
    return -(gap * 1000 + bins)
