import numpy as np


class _AdaptiveScorer:
    """Small stateful scorer that blends best-fit, worst-fit, and utilization cues."""

    def __init__(self):
        self.call_count = 0
        # Kept for potential diagnostics / future adaptation, but not needed for scoring.
        self._last_item = None

    def score(self, item, bins):
        # bins: remaining capacities. We want high score for good choices.
        b = bins.astype(np.float64)

        # Best fit: prefer smallest remaining capacity that still fits (b >= item).
        # Since bins are pre-filtered to those that fit, -(b - item) = item - b is increasing
        # as b decreases, so tightest fit gets highest score.
        best_fit = -(b - item)

        # Worst fit: prefer largest remaining capacity (helps keep small gaps usable later).
        worst_fit = b

        # Utilization-preserving: strongly prefer exact/near-exact fits.
        # This squashes differences among loose bins but rewards tight fits.
        tight = 1.0 / (1.0 + (b - item))

        # A simple adaptive coefficient based on how full bins currently are.
        # Early in an instance, worst-fit-ish behavior can avoid fragmentation;
        # later, best-fit helps pack efficiently.
        n = b.size
        if n == 0:
            return best_fit

        # Average remaining capacity among visible bins.
        avg_rem = float(np.mean(b))
        # 0..1: 1 when bins are relatively empty, 0 when relatively full.
        emptiness = avg_rem / 100.0

        # Blend: early -> a bit more worst-fit; later -> stronger best-fit.
        w_best = 0.65 + 0.30 * (1.0 - emptiness)
        w_worst = 0.20 * emptiness
        w_tight = 0.15

        return w_best * best_fit + w_worst * worst_fit + w_tight * tight


_scorer = _AdaptiveScorer()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    if bins.size == 0:
        return np.zeros(0, dtype=np.float64)

    _scorer.call_count += 1
    _scorer._last_item = item
    return _scorer.score(item, bins)
