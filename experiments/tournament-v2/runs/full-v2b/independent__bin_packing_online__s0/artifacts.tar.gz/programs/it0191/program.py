# EVOLVE-BLOCK-START
"""Best-fit with a mild fill preference and deterministic tie-breaking."""
import numpy as np


def priority(item, bins):
    """Return a priority score for each bin; highest score wins (first on ties).

    item: integer size 1..100.
    bins: int64 array of remaining capacities (100 for unused bins).
    """
    # Best fit: prefer the bin with the smallest remaining capacity after placement,
    # i.e. maximize (item - bins) = minimize bins - item.
    # Add a tiny preference for fuller bins (lower remaining capacity) to preserve
    # empty bins slightly for future large items, without overpowering best fit.
    # The small epsilon is chosen to be much smaller than one unit of capacity.
    score = (item - bins).astype(np.float64) - 0.001 * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
