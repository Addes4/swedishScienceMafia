import numpy as np


def priority(item, bins):
    """Best-fit with a mild preference for tighter fits and earlier bins.

    The item goes to the highest score. We primarily minimize the leftover
    space after placing the item (best fit), which is known to be near-optimal
    for these Weibull-sized online instances. A tiny index-based tie-break
    makes packing deterministic without hurting the main criterion.
    """
    leftover = bins - item
    # Strongly prefer smaller leftover (tightest fit). The small index term
    # only resolves exact ties toward the earlier bin and is negligible
    # otherwise.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.int64)
    return -leftover * 1000 - idx
