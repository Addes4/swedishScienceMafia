import numpy as np


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.int64)

    # Main score: best fit (smaller remaining capacity after placement is better).
    # This minimizes leftover space in nearly-full bins.
    score = -(bins - item)

    # Slight preference for fuller bins among equal fits is already covered by best-fit.
    # Add a gentle anti-fragmentation term: penalize using bins that would be left
    # with a very small but nonzero remainder, unless the fit is exact or near-exact.
    remainder = bins - item

    # Exact fit is ideal; strongly reward it.
    score += (remainder == 0) * 10.0

    # Avoid creating tiny unusable remainders (1..3) when alternatives exist.
    score -= ((remainder > 0) & (remainder <= 3)) * 0.5

    # Prefer fresh bins over heavily fragmented old bins when the fit is otherwise poor.
    # Unused bins have capacity 100 and are naturally disfavored by best fit, so this
    # only slightly helps when many bins are nearly full.
    score += (bins == 100) * 0.01

    return score
