import numpy as np

# EVOLVE-BLOCK-START
"""Best fit with a small, fixed bias toward good two-item complement sizes."""

# Fixed table based on mean ~40 Weibull-ish item sizes.
# For residual r after placing item, higher is slightly better if r is near
# common future item sizes, because it may enable a good exact/near-exact pair.
_BIAS = np.zeros(101, dtype=np.float64)
for _r in range(101):
    if _r == 0:
        _BIAS[_r] = -0.02
    elif 25 <= _r <= 60:
        _BIAS[_r] = 0.015 * (1.0 - abs(_r - 40.0) / 40.0)
    else:
        _BIAS[_r] = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    # Primary criterion: best fit (smallest resulting residual).
    residual = bins - item
    score = -(residual.astype(np.float64))

    # Small secondary bias to favor residuals that are plausible future item sizes.
    # Index is clamped only for safety; bins passed here already fit the item.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    score += _BIAS[idx]
    return score
# EVOLVE-BLOCK-END
