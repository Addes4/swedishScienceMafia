import numpy as np


def priority(item, bins):
    """Score bins to implement a best-fit-with-usage-preference rule.

    The item goes to the bin with the highest score.  We primarily want the
    tightest fit (classic best fit), but we slightly prefer bins that are
    already in use over completely empty bins so that a tight fit into a used
    bin is chosen before opening a new one.
    """
    # Primary: prefer smaller remaining capacity after placing the item.
    # This is equivalent to preferring bins with smaller current remaining
    # capacity, i.e. tighter fits.
    scores = -bins.astype(np.float64)

    # Secondary tie-breaker: prefer already used bins over unused ones.
    # Unused bins have remaining capacity exactly 100.  Add a tiny bonus to
    # used bins so that, among equally tight fits, a used bin is chosen first.
    used = bins < 100
    scores += used * 1e-6

    return scores
