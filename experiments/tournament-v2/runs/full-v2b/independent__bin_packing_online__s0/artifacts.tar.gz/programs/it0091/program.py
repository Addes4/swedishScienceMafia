import numpy as np

# Global state for the current instance
_items_seen = []
_m = 0.0
_counter = 0
_C = 2.0

def priority(item, bins):
    global _items_seen, _m, _counter
    # Reset state at the start of a new instance (first call has only 1 bin)
    if len(bins) == 1:
        _items_seen = []
        _m = 0.0
        _counter = 0
    
    _items_seen.append(item)
    _counter += 1
    
    # Update the threshold m periodically (every 100 items, and at the first item)
    if _counter % 100 == 0 or _counter == 1:
        if len(_items_seen) >= 50:
            _m = float(np.percentile(_items_seen, 10))
        else:
            _m = 0.0
    
    leftover = bins - item  # int64 array
    scores = -leftover.astype(np.float64)
    
    if _m > 0:
        # Penalize leaving a gap smaller than m, except when the bin becomes full (leftover=0)
        penalty = np.maximum(0.0, _m - leftover)
        penalty[leftover == 0] = 0.0
        scores -= _C * penalty
    
    return scores
