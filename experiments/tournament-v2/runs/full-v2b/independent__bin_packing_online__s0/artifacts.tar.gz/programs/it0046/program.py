import numpy as np

# State kept across calls (must not depend on unseen future items)
_state = {
    "count": 0,
    "sum": 0.0,
    "max_item": 0,
}


def priority(item, bins):
    """Adaptive bin-choice priority.

    Best fit minimizes waste when the system is dense; worst fit helps keep many
    bins available when there is still plenty of slack. We rank bins by a blend
    of tightness and remaining capacity, adapted to the current occupation level.
    """
    global _state
    _state["count"] += 1
    _state["sum"] += item
    if item > _state["max_item"]:
        _state["max_item"] = item

    b = bins.astype(np.float64)

    # Remaining slack after placing item in each bin.
    slack = b - item

    # Baseline best-fit score: prefer small remaining capacity (tight fit).
    best_fit = -slack

    # Worst-fit component: prefer large remaining capacity.
    worst_fit = b

    # Density of the current packing: how full are the available bins?
    # bins has one entry per item so far, mostly capacity-100 unused bins early.
    occupy = 1.0 - (b / 100.0)
    mean_occ = float(np.mean(occupy))

    # Adapt blend: when packing is dense, emphasize best fit; when sparse,
    # give more weight to keeping bins balanced (worst fit).
    t = max(0.0, min(1.0, mean_occ))
    alpha = 0.75 * t + 0.25  # best-fit weight in [0.25, 1.0]

    # Slight tie-breaking preference for bins with smaller index is automatic
    # via the harness tie rule. Add tiny deterministic bias by index to make
    # behavior consistent and avoid pathological equal scores.
    idx = np.arange(b.shape[0], dtype=np.float64)
    idx_bias = -1e-9 * idx

    score = alpha * best_fit + (1.0 - alpha) * worst_fit + idx_bias

    # Avoid any NaN/inf: all finite here.
    return score
