"""Refined best-fit for online bin packing with Weibull item sizes."""

import numpy as np


def priority(item, bins):
    """Return a score for every bin; highest score gets the item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of bins the item fits in.
    """
    # Remaining capacity after placing the item
    leftover = bins - item

    # Base: prefer tight fits (small leftover)
    score = -leftover.astype(np.float64)

    # Penalize leftovers that are too small to be useful (wasted space)
    # Small leftovers (1..12) are often unusable for future items; add a penalty
    wasted = (leftover > 0) & (leftover < 13)
    score -= wasted.astype(np.float64) * 3.0

    # Slight preference for fuller bins to reduce fragmentation
    # (larger item means fuller bin, so leftover is small)
    return score
