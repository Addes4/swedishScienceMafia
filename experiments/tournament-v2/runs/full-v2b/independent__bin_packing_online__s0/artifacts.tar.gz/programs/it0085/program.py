"""Hybrid best-fit / worst-fit bin selection.

The main idea is to avoid opening a new bin while there is any partially-filled
bin that the item fits into.  Among the partially-filled bins we use best-fit
(tightest remaining capacity) to reduce fragmentation.  Unused bins (remaining
capacity 100) get a heavily-penalized score so that they are chosen only when
no partially-filled bin can accommodate the item.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit among used bins: tighter remaining capacity (closer to item) is better.
    scores = -(bins - item).astype(np.float64)

    # Unused bins have remaining capacity 100.  Penalize them so that any
    # partially-filled bin is preferred, no matter how loose the fit.
    unused = bins == 100
    scores[unused] = -1.0e9

    return scores
