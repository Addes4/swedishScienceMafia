import numpy as np


def priority(item, bins):
    remaining = bins - item
    score = -remaining.astype(np.float64)

    # Strongly prefer bins that this item fills exactly.
    exact = (remaining == 0)
    if exact.any():
        score[exact] += 10000.0

    # For larger items, prefer leaving very small waste.
    if item >= 50:
        low_waste = (remaining >= 0) & (remaining <= 3)
        score[low_waste] += 20.0 - remaining[low_waste].astype(np.float64)

    return score
