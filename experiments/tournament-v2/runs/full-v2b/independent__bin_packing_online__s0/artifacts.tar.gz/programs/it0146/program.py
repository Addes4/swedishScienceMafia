import numpy as np


def priority(item, bins):
    # Primary: best fit (small leftover after placing item).
    # Secondary: mild preference for bins that are already somewhat full,
    # but not so strong that it creates many nearly-empty leftovers.
    leftover = bins - item
    fullness = 100 - bins
    # Lower leftover is better, and among similar leftovers prefer fuller bins.
    return -(leftover.astype(np.float64) * 4.0 + fullness.astype(np.float64))
