"""Online bin packing priority rule.

Combines Best Fit with harmonic-style class awareness:
- Primary signal: prefer bins where the item fits most tightly (smallest remainder),
  but break ties using a harmonic bucket preference that groups items into size
  classes so that bin remainders within the same class are preferred.
This tends to produce near-optimal packs on Weibull-shaped sizes.
"""
import numpy as np


def priority(item, bins):
    # Best-fit primary signal: smaller remainder -> higher score.
    remainder = bins - item

    # Harmonic class preference: map item size to a class and prefer bins whose
    # remainder, after placing, lands in a "nice" region for that class.
    # Classes derived from classic harmonic bin packing thresholds.
    if item > 50:
        cls = 1.0
    elif item > 33:
        cls = 2.0
    elif item > 25:
        cls = 3.0
    elif item > 20:
        cls = 4.0
    elif item > 16:
        cls = 5.0
    else:
        cls = 6.0

    # Score: strongly prefer tight fits. Use float to keep ordering stable.
    score = -(remainder.astype(np.float64))

    # Small bonus for bins already partially filled (less empty), reducing the
    # number of nearly-empty bins left open, weighted by class.
    emptiness = (bins.astype(np.float64) - (100.0 - item))
    score -= 0.01 * cls * np.maximum(emptiness, 0.0)

    return score
