"""Online bin packing with a tuned best-fit style priority rule."""
import numpy as np


def priority(item, bins):
    """Rank bins by how tightly `item` fits; prefer fuller bins and delay new bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining = 100), in bin order.
    """
    bins = np.asarray(bins)

    # Remaining capacity after placing the item.
    leftover = bins - item

    # Primary: minimize leftover (best fit). Strongest for small leftover.
    # Use a sharp reward for near-perfect fits.
    tight = -leftover.astype(np.float64)

    # Reward exact/very tight fills strongly so we close bins efficiently.
    tight += 2.0 / (leftover + 1.0)

    # Mildly penalize using brand-new empty bins (remaining == 100) to
    # encourage reusing partially filled bins and reduce bin count.
    fresh = (bins == 100).astype(np.float64)
    tight -= 0.5 * fresh

    # Small reward for bins that were already fairly full (low remaining),
    # which keeps the packing compact.
    tight += 0.01 * (100 - bins)

    return tight
