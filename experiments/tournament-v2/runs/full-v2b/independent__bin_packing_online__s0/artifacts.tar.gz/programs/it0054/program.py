import numpy as np

# Best-fit with a slight anti-waste adjustment tuned to Weibull-shaped items (mean ~40).
# We reward tight fits but adjust for the "residual" a bin will have afterward, so that
# leftovers are more likely to be usable by future items.

def priority(item, bins):
    residual = bins - item  # this is >= 0 for all shown bins
    # Base: tighter fit is better (smaller residual -> higher score).
    base = -residual.astype(np.float64)

    # Penalize residuals that are likely to be "hard leftovers": small amounts that are
    # too big to be a single common item but leave a bin hard to close out. Conversely,
    # reward residuals near 0 (perfect fill) and residual == 0 strongly.
    r = residual.astype(np.float64)

    # Smooth preference: penalize moderate residuals (like 20-30) so we don't strand space.
    penalty = np.where((r >= 1) & (r <= 30), 0.5 * (1.0 - np.abs(r - 15.0) / 15.0), 0.0)

    score = base - penalty
    # Strongly favor exact fits.
    score = score + np.where(r == 0, 5.0, 0.0)
    return score
