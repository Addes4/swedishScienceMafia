import numpy as np


def priority(item, bins):
    """Hybrid best-fit rule.

    Scores are higher for bins that fit the item tightly, with extra reward when the
    bin becomes exactly full. Brand-new bins (remaining capacity 100) get a mild
    penalty so that existing partially filled bins are preferred when the fit is good.
    """
    rem = np.asarray(bins)
    leftover = rem - item

    # Base: prefer tight fits (small leftover).
    score = -leftover.astype(np.float64)

    # Strongly reward a perfect fill (leftover == 0).
    score += 5.0 * (leftover == 0)

    # Mild penalty for opening a completely unused bin.
    score -= 0.5 * (rem >= 100)

    return score
