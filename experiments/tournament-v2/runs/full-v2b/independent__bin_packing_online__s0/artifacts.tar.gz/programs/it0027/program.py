import numpy as np


def priority(item, bins):
    """Best Fit: choose the bin with the smallest remaining capacity that fits the item."""
    return -(bins - item)
