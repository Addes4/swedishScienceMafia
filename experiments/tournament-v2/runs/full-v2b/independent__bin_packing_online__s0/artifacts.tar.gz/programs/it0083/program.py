import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary: best fit (smallest residual nonnegative)
    # Secondary: slight preference for residuals that are common small leftover sizes
    #           to encourage filling rather than creating tiny unusable gaps.
    # Since ties go to first bin, encode secondary as a tiny tie-break bonus.
    score = -residual.astype(np.float64)
    # Prefer exact fill or very tight fit strongly, then slightly prefer small leftovers.
    tight = (residual == 0).astype(np.float64)
    small = (residual <= item).astype(np.float64)
    score = score + 0.01 * tight - 0.0001 * residual
    return score
