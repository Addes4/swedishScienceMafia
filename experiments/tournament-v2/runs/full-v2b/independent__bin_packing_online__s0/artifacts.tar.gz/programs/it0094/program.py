"""Online bin packing: best fit with a mild empty-bin penalty for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest score.

    Primary rule: choose the bin where the item fits most tightly (smallest residual).
    Secondary: for larger items, avoid opening a fresh bin unless necessary.
    """
    residual = bins - item
    # Best-fit score: higher for tighter fits.
    score = -residual.astype(np.float64)

    # For large items, give a slight preference to non-empty bins over empty ones.
    # Empty bins have residual == 100 - item after subtracting; original capacity == 100.
    # Detect empty bins by bins == 100 (before subtracting item).
    if item >= 40:
        empty = (bins == 100)
        score[empty] -= 1e-3 * item

    return score
