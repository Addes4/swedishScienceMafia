"""Online bin packing: refined best-fit with capacity reserve heuristic."""
import numpy as np

_EMPTY_THRESHOLD = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Strategy: best fit (minimize leftover capacity after placement), with a mild
    nudge that avoids using up the last almost-empty bin when other tight fits
    exist, preserving flexibility for large incoming items.
    """
    leftover = bins - item  # remaining capacity if item placed here; >= 0

    # Base best-fit score: prefer the smallest leftover capacity.
    score = -leftover.astype(np.float64)

    # Count how many bins are currently completely empty (capacity 100).
    empty_mask = bins == _EMPTY_THRESHOLD
    n_empty = int(empty_mask.sum())

    # If there are multiple empty bins, discourage filling all but one of them
    # with medium items: give empty bins a small penalty so tighter fits win.
    if n_empty > 1:
        score[empty_mask] -= 0.5

    # Slight preference against creating very low remaining capacities in bins
    # that are otherwise comfortably loaded, but this is already handled by
    # best-fit. Add a tiny tie-breaker favoring bins with more remaining room
    # after placement only within equal leftover; since leftover is integer and
    # score is float, equal -leftover means equal score, so nudge toward larger
    # resulting leftover for exact ties is unnecessary. Keep it simple.
    return score
