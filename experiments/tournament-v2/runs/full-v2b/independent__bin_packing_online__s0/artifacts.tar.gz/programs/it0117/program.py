import numpy as np


class _State:
    total_items = 0
    total_size = 0.0

    @classmethod
    def update(cls, item):
        cls.total_items += 1
        cls.total_size += float(item)

    @classmethod
    def mean(cls):
        if cls.total_items == 0:
            return 40.0
        return cls.total_size / cls.total_items


def priority(item, bins):
    """Best-fit with tie handling that discourages premature new-bin use.

    The item is placed in the partially used bin with the smallest remaining
    capacity that still fits it.  If no partially used bin fits, it goes to a
    fresh bin.  Among equivalent choices, prefer a residual capacity near the
    observed mean item size, which tends to leave useful bins rather than
    almost-full dead space.
    """
    _State.update(item)
    mean = _State.mean()

    b = np.asarray(bins, dtype=np.int64)
    residual = b - item

    # Strongly prefer non-empty bins: bins with capacity 100 are unused.
    # Among fitting bins, score by tightness (smaller residual is better).
    used = (b != 100)

    # tightness score: higher for smaller residual capacity
    score = -residual.astype(np.float64)

    # Penalize fresh bins so they are used only when necessary.
    score = np.where(used, score, score - 1e6)

    # Tiny tie-break: prefer residuals closer to the mean future item size.
    score -= 0.001 * np.abs(residual.astype(np.float64) - mean)

    return score
