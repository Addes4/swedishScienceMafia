import numpy as np

_STATE = {"seen": 0}

def priority(item, bins):
    _STATE["seen"] += 1

    # Base score: prefer smaller remaining capacity after placement,
    # i.e. tighter fits. Since item goes to max score, minimize (bins - item).
    tight = 1000.0 * (item - bins)

    # Strong bonus for perfect fits / very tight fits.
    perfect = (bins == item) * 5000.0
    near = (bins <= item + 8) * 700.0
    decent = (bins <= item + 20) * 150.0

    # Mild preference for bins that are already partially used (less remaining),
    # which helps consolidate and reduce total bins.
    load_bias = (100.0 - bins) * 0.35

    # Small anti-opening bias: slightly discourage completely empty bins
    # unless the item is large enough that opening a new bin is reasonable.
    empty_penalty = (bins == 100) * (-12.0 if item < 70 else 0.0)

    # Prefer older bins by index order naturally through tie-breaking,
    # but add a tiny decaying bonus so earlier bins win close ties.
    n = len(bins)
    idx = np.arange(n, dtype=np.float64)
    age_bonus = (n - idx) * 0.001

    score = tight + perfect + near + decent + load_bias + empty_penalty + age_bonus

    # Avoid NaN/inf issues and return as float array.
    return score.astype(np.float64)
