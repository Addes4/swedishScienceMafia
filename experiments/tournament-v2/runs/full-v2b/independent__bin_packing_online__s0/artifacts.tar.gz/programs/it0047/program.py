import numpy as np


def priority(item, bins):
    # Positive score: higher is better.
    # Best-fit term: prefer smallest remaining capacity that still fits.
    # Extra reward for bins where placing the item leaves 0 or very little slack,
    # which tends to reduce waste and pack more tightly.
    rem = bins
    after = rem - item
    score = -after.astype(np.float64)
    # Strong bonus for exact/near-perfect fill; smooth tie-breaker.
    score += 60.0 * (after == 0)
    score += 6.0 / (1.0 + after)
    return score
