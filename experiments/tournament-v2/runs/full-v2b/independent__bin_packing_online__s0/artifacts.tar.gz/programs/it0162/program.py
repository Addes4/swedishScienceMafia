import numpy as np


def priority(item, bins):
    # Prefer tightest fit: smaller remaining capacity after placing item is better.
    # For bin with remaining capacity b, remaining after placement is b - item.
    # So score = -(b - item) = item - b.
    tightness = item - bins

    # Prefer non-empty bins (remaining < 100) over empty bins (remaining == 100)
    # when tightness ties. This reduces opening new bins unnecessarily.
    # Since empty bins have remaining capacity 100, they are the least tight anyway,
    # but this helps in edge cases and keeps behavior stable.
    used_bonus = np.where(bins < 100, 1e-6, 0.0)

    return tightness + used_bonus
