import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0


_state = _State()


def priority(item, bins):
    """Adaptive best-fit-like bin ranking for online bin packing.

    The score favors tight fits, but when no tight fit exists it slightly
    prefers leaving a small number of moderately filled bins rather than
    always filling the emptiest bin.
    """
    s = _state
    s.n += 1
    delta = item - s.mean
    s.mean += delta / s.n
    s.m2 += delta * (item - s.mean)

    # Use a stable, deterministic score.  Primary: best fit (small remaining
    # capacity after placement).  Secondary: a mild preference for lower bin
    # indices among equal fits, achieved by adding a tiny decreasing term.
    # A small adaptive offset discourages opening/using completely empty bins
    # when a reasonable fit already exists, which reduces premature bin opens.
    rem = bins - item
    score = -rem.astype(np.float64)

    # If the item is small relative to current mean, be slightly more willing
    # to use emptier bins; if large, be stricter toward tight fits.
    if s.n > 16:
        var = s.m2 / (s.n - 1)
        sd = var ** 0.5
        if sd > 0:
            z = (item - s.mean) / sd
            # z high  -> large item -> strong best-fit preference
            # z low   -> small item -> accept looser bins more readily
            strength = max(0.0, min(1.5, 0.5 + 0.25 * z))
        else:
            strength = 0.7
    else:
        strength = 0.7

    # Empty bins have rem = 100-item across all currently unused bins.
    # Penalize using an empty bin when some used bin is a decent fit.
    empty_rem = 100 - item
    is_empty = (bins == 100)
    if np.any(is_empty) and np.any(~is_empty):
        # Score adjustment only matters relative to non-empty candidates.
        # Prefer non-empty bins over empty ones unless their fit is bad.
        score += (~is_empty).astype(np.float64) * (2.0 + 0.05 * item)

    # Mild preference for tighter fits scales with item size; for small items
    # this matters less, avoiding fragmentation.
    score -= (0.001 * strength) * rem.astype(np.float64)

    # Tiny index preference (first bin on ties) to avoid churn.
    idx = np.arange(bins.size, dtype=np.float64)
    score -= idx * 1e-12

    return score
