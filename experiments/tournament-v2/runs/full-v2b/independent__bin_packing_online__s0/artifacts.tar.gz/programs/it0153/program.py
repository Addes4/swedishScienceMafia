import numpy as np

class PriorityRule:
    def __init__(self):
        self.count = 0
        self.sum = 0.0
        self.sumsq = 0.0
        self.hist = np.zeros(101, dtype=np.float64)
        self.last_avg = 40.0

    def priority(self, item, bins):
        self.count += 1
        self.sum += item
        self.sum_sq = getattr(self, "sum_sq", 0.0) + item * item
        self.hist[item] += 1.0

        n = bins.size
        if n == 0:
            return np.zeros(0, dtype=np.float64)

        # Best-fit baseline: higher score = better
        residual = bins.astype(np.float64)

        # Primary: prefer tight fit (small residual after placing item)
        tight = -np.abs(residual - item)

        # Secondary: prefer bins that are already partially filled over completely empty bins
        # when item is small, to avoid opening new bins unnecessarily.
        # This is naturally handled by tight fit: empty bins have residual 100, score -|100-item|.
        # But if item is large, empty bins may be forced.
        scores = tight.astype(np.float64)

        # Slight dynamic adjustment based on observed average item size.
        # If current item is larger than average, more strongly avoid medium residuals
        # that could only fit small items.
        avg = self.sum / self.count if self.count > 0 else 40.0

        # Add a small bias: penalize leaving too large a residual if item is large,
        # and penalize leaving too small a residual if item is small.
        # This reduces fragmentation.
        if item >= 60:
            # Large item: prefer bins where resulting residual is small (tight already does this)
            # and also prefer bins with residual close to item (no extra)
            pass
        else:
            # Small item: slight preference for bins that will still have capacity
            # for future items, i.e., avoid making tiny residuals that are useless.
            # Penalize residual after placement that is very small but > 0,
            # because such bins may be wasted.
            new_res = residual - item
            small_penalty = np.where((new_res > 0) & (new_res < 10), -0.5, 0.0)
            scores = scores + small_penalty

        # Tie-breaking: prefer lower bin index (first) automatically by using argsort
        # with stable kind, but we return scores and harness picks first max.
        # To ensure deterministic favor of earlier bins on exact ties, we can add tiny
        # decreasing bias by index.
        idx_bias = -np.arange(n, dtype=np.float64) * 1e-9
        scores = scores + idx_bias

        return scores


_rule = PriorityRule()

def priority(item, bins):
    return _rule.priority(item, bins)
