import numpy as np

_state = {"seen": 0}

def priority(item, bins):
    _state["seen"] += 1
    # bins holds remaining capacities; choose bin with score max.
    # Strategy: mostly best-fit, but when item is large, strongly prefer
    # earlier bins (lower index) that already have some used space to
    # avoid fragmenting fresh bins.
    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    # Best-fit score: smaller remaining capacity after placement is better.
    # remaining after placement = bins - item
    # Higher score = tighter fit.
    # Add a mild preference for earlier bins (first-fit tie-break already exists,
    # but we bias explicitly to reduce bin count in practice).
    # For unused bins (remaining == 100), penalize slightly so we don't open new bins.
    unused = bins >= 100

    # Base: prefer tight fits.
    scores[:] = -(bins - item).astype(np.float64)

    # Penalize untouched (fresh) bins so we fill partially used bins first.
    scores[unused] -= 0.5

    # For large items, avoid placing in a nearly-full bin if it would
    # waste the remainder... but best-fit already handles that.
    # Additional: prefer bins where the leftover after placement is small
    # but non-zero (reduces unavoidable waste).
    # This is already captured by best-fit.

    return scores
