import numpy as np


def priority(item, bins):
    # Best-fit: prefer the bin with the smallest remaining capacity that
    # still fits the item. Score is higher for tighter fits.
    # -(bins - item) gives smaller remaining capacity -> higher score.
    return -(bins - item)
