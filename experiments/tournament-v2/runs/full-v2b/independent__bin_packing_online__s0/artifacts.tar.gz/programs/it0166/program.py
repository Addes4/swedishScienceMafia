"""Online bin packing: best-fit with a small state-free bias toward tighter fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: the bin with the smallest remaining capacity that still fits the item.
    # Slightly reward fuller bins to reduce fragmentation, but keep enough spread so
    # that large items strongly prefer exact/near-exact fits.
    remaining = bins.astype(np.float64)
    # Larger item -> more important to avoid creating tiny leftovers; smaller item ->
    # more benefit from filling near-full bins.
    tight_weight = 1.0 + 1.0 / item
    return -(remaining * tight_weight)
