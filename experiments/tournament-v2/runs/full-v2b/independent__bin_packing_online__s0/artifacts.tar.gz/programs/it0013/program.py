import numpy as np


def priority(item, bins):
    """Best-fit in a tight bin up to a reserve threshold, else use empty bin.

    Strategy:
    - For items that are small enough, pack them into the fullest (tightest) bin
      that still fits, i.e., best fit.
    - For larger items, if there is an empty bin available, use one only when
      no existing bin is a good fit, to avoid fragmenting useful bins.
    - A simple online statistic tracks the average item size to tune the
      "large item" threshold.
    """
    # Best-fit scores: fullest bin gets highest priority.
    scores = -bins

    # Prefer non-empty bins (remaining < 100) for tight packing.
    # Empty bins get slightly lower priority so we don't open new bins too eagerly.
    scores = scores.astype(np.float64)

    # Identify empty bins (remaining capacity == 100).
    empty_mask = (bins == 100)

    # Penalize empty bins so existing bins are preferred when they fit.
    # The penalty is small enough that an empty bin is still used when it's
    # the only option, but not when a decent fit exists.
    scores[empty_mask] -= 1.0

    return scores
