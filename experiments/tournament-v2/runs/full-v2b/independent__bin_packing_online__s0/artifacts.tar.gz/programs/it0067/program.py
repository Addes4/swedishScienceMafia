"""Improved online bin packing rule: best-fit with slight new-bin avoidance."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a small bias against choosing unused bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Primary objective: best fit (smallest remaining capacity after insertion).
    # This corresponds to the largest current consumption among feasible bins.
    score = item - bins

    # Mildly discourage opening brand-new bins. A new bin has remaining capacity 100,
    # so it would otherwise only be selected when every existing bin is too full.
    # The penalty is small enough to preserve tight-fit behavior.
    score = score.astype(np.float64)
    score[bins == 100] -= 0.5

    return score
