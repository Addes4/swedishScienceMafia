import numpy as np


def priority(item, bins):
    rem = bins.astype(np.int64)
    waste = rem - item
    # Base: best fit (smallest waste). Larger score = better.
    score = -waste.astype(np.float64)

    # Slight preference to fill bins that become nearly full (better packing).
    # After placing, new remaining = waste. 0 => perfectly full.
    score += 0.01 * (1.0 / (1.0 + waste.astype(np.float64)))

    # Slightly discourage using a completely fresh bin (rem==100) unless the
    # item is large, keeping fresh bins for big items.
    fresh = (rem == 100)
    if item < 60:
        score -= 0.5 * fresh

    return score
