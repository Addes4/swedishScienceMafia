import numpy as np

# Precompute a small tie-breaking bonus/penalty by position.
_IDX_PENALTY = None

def priority(item, bins):
    global _IDX_PENALTY

    # Best fit: smallest remaining capacity that still fits, i.e. maximize -(rem - item)
    score = -(bins - item)

    # Tiny deterministic tie-break: earlier bins are preferred on exact ties.
    n = bins.size
    if _IDX_PENALTY is None or _IDX_PENALTY.size != n:
        _IDX_PENALTY = np.arange(n, dtype=np.float64) * 1e-12

    score = score.astype(np.float64, copy=False)
    score -= _IDX_PENALTY
    return score
