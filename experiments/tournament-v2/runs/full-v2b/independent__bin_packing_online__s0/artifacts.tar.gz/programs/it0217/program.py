"""Online bin packing heuristic: modified best fit.

Prefer to put an item into an already-open bin where it fits most tightly
(minimizes the leftover space after insertion).  Among near-ties, prefer a
bin that is already partially filled over a completely empty one, so empty
bins are conserved for large items that would otherwise be unplaceable.
"""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of each bin (numpy int64 array).
    """
    residual = bins - item  # remaining capacity after placing the item

    # Base score: best fit => smallest residual is best.
    score = -residual.astype(np.float64)

    # Slight bonus for using a bin that is NOT completely empty.
    # Empty bins (bins == 100) get a small penalty so they are conserved.
    score -= 6.0 * (bins == 100)

    # Slight bonus for filling a bin nearly completely, but avoid leaving
    # a tiny unusable gap. Prefer to avoid residuals in [1, 12] if a better
    # option exists by adding a small penalty proportional to how small and
    # positive the residual is.
    small_gap = (residual > 0) & (residual <= 12)
    score -= 3.0 * small_gap

    return score
