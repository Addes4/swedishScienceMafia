import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum_items = 0
        self.last = 0
        self.large_seen = 0

    def update(self, item):
        self.n += 1
        self.sum_items += int(item)
        if item >= 50:
            self.large_seen += 1
        self.last = int(item)


_state = _State()


def priority(item, bins):
    _state.update(item)
    b = bins.astype(np.int64)
    rem_after = b - item

    # Number of bins currently in use is approximated by bins with remaining < 100.
    used = int(np.count_nonzero(b < 100))
    total_used_cap = 0

    # Phase 1: early in the stream, prefer full/empty separation less aggressively.
    # Phase 2: once many bins are open, best fit usually wins.
    n = _state.n
    load_ratio = _state.sum_items / (100.0 * max(1, used))

    # Scores:
    # - Prefer bins where residual after placing is small (tight fit).
    # - Mildly prefer bins that are already partially used, to consolidate.
    # - Avoid creating a new bin if any existing bin fits well.
    # - Slight bonus for exact fit.
    tight = -rem_after.astype(np.float64)

    # Penalize opening new bins unless necessary or item is large.
    unused_penalty = np.where(b == 100, 2.5, 0.0)

    # Prefer bins with moderate remaining capacity, not tiny scattered gaps.
    # A bin with less remaining than item is already excluded by the harness.
    remaining_fraction = b.astype(np.float64) / 100.0
    consolidation = -0.75 * np.abs(remaining_fraction - 0.45)

    # Exact fit gets a strong but not overwhelming bonus.
    exact_bonus = np.where(rem_after == 0, 3.0, 0.0)

    # Later in the run, stronger best-fit behavior.
    w = min(1.0, n / 1500.0)
    score = (1.0 + w) * tight + consolidation + exact_bonus - (1.0 - w) * unused_penalty

    # Tiny deterministic tie-break to keep behavior stable.
    score = score - 1e-6 * np.arange(len(b), dtype=np.float64)

    return score
