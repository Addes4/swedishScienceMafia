import numpy as np


def priority(item, bins):
    # Best-fit dominates. The residual after placing item in each bin:
    residual = bins - item

    # Primary score: tighter fit is better (smaller residual).
    # We subtract a tiny term that slightly favors residuals near 1 rather than 0,
    # because exact fills can leave hard-to-reuse empty bins, while 1-2 units can
    # sometimes be absorbed by small items. The effect is deliberately small.
    score = -residual.astype(np.float64) + 0.001 * (residual == 1)

    return score
