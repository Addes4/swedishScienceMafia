import numpy as np

class Packer:
    def __init__(self):
        self.calls = 0
        self.last_item = 0

    def priority(self, item, bins):
        self.calls += 1
        self.last_item = item

        # All bins passed already fit the item (capacity >= item).
        # Best fit: minimize leftover residual (bins - item), i.e. maximize -(bins - item).
        # Residual 0 is perfect and gets the largest score.
        scores = -(bins - item)

        # Mild tie-breaking polish: among bins with equal residual, prefer bins
        # that are currently more full (smaller remaining capacity) to avoid
        # spreading items across many partially filled bins.
        # Since primary score is integer-valued, add a tiny secondary term.
        scores = scores * 10000.0 - bins

        return scores

_packer = Packer()

def priority(item, bins):
    return _packer.priority(item, bins)
