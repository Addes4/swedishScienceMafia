import numpy as np


class _State:
    def __init__(self):
        self.small_counts = {}
        self.total_seen = 0

    def observe(self, item):
        self.total_seen += 1
        if item <= 30:
            self.small_counts[item] = self.small_counts.get(item, 0) + 1


_STATE = _State()


def priority(item, bins):
    """Score bins for an online bin-packing decision.

    The rule combines:
    1. exact-fit preference,
    2. best-fit residual minimization,
    3. lookahead-free matching of the residual left in a bin to common small item sizes,
    4. mild preference against opening brand-new bins.
    """
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    # Adaptive estimate of the most common small residual sizes worth preserving.
    # We keep a small set of "useful" gaps and reward bins whose leftover after
    # placing this item roughly equals one of those gaps.
    useful = _STATE.small_counts
    seen = _STATE.total_seen

    for i in range(n):
        cap = int(bins[i])
        residual = cap - item

        # Base: strongest fit is residual 0, then small residuals.
        # Negative residual means exact fit; larger (less negative) is better.
        score = -float(residual)

        # Exact fit is very valuable.
        if residual == 0:
            score += 1000.0

        # Prefer bins that leave room for a common small item.
        # This is a soft, distribution-agnostic fragment heuristic.
        if residual > 0:
            # Reward residuals that have historically appeared often as items.
            c = useful.get(residual, 0)
            if c:
                score += 2.0 * c / (seen + 1.0)

            # Small bonus for residuals that are themselves plausible item sizes,
            # especially small ones, to avoid wasting tight but unusable gaps.
            if residual <= 60:
                score += 0.5 * (61 - residual) / 60.0

        # Slightly discourage opening unused bins unless the fit is good.
        if cap == 100 and residual < 100:
            score -= 0.25

        scores[i] = score

    _STATE.observe(item)
    return scores
