import numpy as np


def priority(item, bins):
    """Best-fit with a small preference for already-used bins over empty ones.

    The item goes to the bin where the remaining capacity after insertion is
    smallest (tightest fit).  Ties are broken in favour of bins that are not
    completely empty, which slightly delays opening fresh bins and improves
    packing on Weibull-shaped arrivals.
    """
    leftover = bins - item
    # Smaller leftover -> higher score.  Add a tiny bonus to used bins.
    used_bonus = (bins < 100).astype(np.float64) * 1e-3
    return -leftover.astype(np.float64) + used_bonus
