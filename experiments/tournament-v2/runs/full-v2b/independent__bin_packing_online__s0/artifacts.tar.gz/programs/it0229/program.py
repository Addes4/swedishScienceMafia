import numpy as np

_state = {"count": 0, "sum": 0, "n_bins_hint": 0}


def priority(item, bins):
    # Light state tracking; does not affect ordering but could be used adaptively.
    _state["count"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["count"] if _state["count"] > 0 else 40.0

    # Best-fit: prefer bin whose remaining capacity is closest above item size.
    # bins is remaining capacity; residual = bins - item.
    residual = bins - item

    # Primary score: best fit (smaller residual better).
    # Use large negative residual.
    score = -residual.astype(np.float64)

    # Small tie-breaker / promotion: slightly favor bins that would be almost exactly
    # filled (waste small) and also slightly favor bins that are already somewhat full
    # but not the unused 100-capacity bins, to reduce fragmentation.
    # Avoid over-biasing; keep secondary term tiny.
    remaining_after = residual + item  # = bins
    # waste ratio relative to item
    waste = residual / np.maximum(item, 1)

    # Penalize tiny wastage very slightly more (encourage near-perfect fits).
    score -= 1e-3 * waste

    # Slight preference for non-empty bins that become nearly full, avoiding
    # scattering into empty bins too early. Penalize completely empty bins slightly.
    empty_mask = (bins == 100)
    score -= 0.02 * empty_mask

    # Encourage using bins that are already fairly full (small remaining capacity)
    # only in the secondary term, ensuring best-fit dominates.
    score -= 1e-4 * bins

    return score
