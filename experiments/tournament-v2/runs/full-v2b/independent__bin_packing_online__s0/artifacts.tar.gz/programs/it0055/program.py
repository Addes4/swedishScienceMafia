import numpy as np

# Tracks total items seen and an estimate of the current "open bin" pressure.
_state = {
    "n": 0,
    "sum": 0.0,
}


def priority(item, bins):
    """Best-fit packing with a light hedge against wasting large empty bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Returns one score per bin; highest score wins, ties to the earliest bin.
    """
    _state["n"] += 1
    _state["sum"] += item

    n_open = int(np.count_nonzero(bins < 100))
    total = int(bins.size)

    # Standard best fit: prefer the bin with the least remaining capacity
    # that still fits.  The array only contains fitting bins, so -(bins - item)
    # ranks tighter fits higher.
    score = -(bins - item).astype(np.float64)

    # If the item is small relative to remaining space, and many bins are
    # already open, gently discourage putting it into a nearly-empty bin
    # when a moderately filled bin exists.  This preserves large bins for
    # future large items.
    if item <= 25 and n_open > 0:
        # Penalize bins whose remaining capacity is very large relative to
        # the average remaining capacity of currently open bins.
        open_bins = bins[bins < 100]
        if open_bins.size:
            avg_rem = float(open_bins.mean())
            # Small bonus for bins closer to the average remaining capacity,
            # i.e. avoid both extremes for tiny items.
            score -= 0.15 * np.abs(bins - avg_rem)

    # Slight preference for non-empty bins over empty ones when the item is
    # not large, to avoid prematurely opening fresh bins.
    if item <= 50:
        score -= 0.05 * (bins == 100).astype(np.float64)

    return score
