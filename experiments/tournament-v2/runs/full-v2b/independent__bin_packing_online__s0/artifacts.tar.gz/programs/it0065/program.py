import numpy as np

_state = {"count": 0}

def priority(item, bins):
    b = bins.astype(np.int64)
    # Best fit: maximize -(remaining - item) = item - remaining, i.e. minimize remaining.
    # Prefer bins that fit tightly; among equal remaining, prefer larger index bins
    # (unused bins at high indices) to keep lower-indexed partially full bins available.
    idx = np.arange(len(b), dtype=np.int64)
    score = -(b - item).astype(np.int64) * 4 - idx
    return score
