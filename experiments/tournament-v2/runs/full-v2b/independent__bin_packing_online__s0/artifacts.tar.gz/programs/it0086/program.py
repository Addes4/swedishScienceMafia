"""Online bin packing bin-choice rule.

Approach: rank bins by a best-fit style score that prefers small residual
capacity after placing the item, but penalizes residuals (post-placement gaps)
that are likely to be hard to fill later.  We use a static function of the
post-placement residual plus a mild bias derived from the running distribution
of item sizes seen so far.  Everything is O(n_bins) per call and avoids
adapting to individual instances.
"""

import numpy as np


# Parameters chosen from the known Weibull-shaped, mean-40 distribution.
# A residual of size g is "bad" if it is a size that is unlikely to be filled
# by future items; small gaps (< min item ~ maybe 5-ish) are nearly unusable.
# We approximate with a penalty that grows for tiny residuals and decreases
# for residuals near typical item sizes.
_MIN_USEFUL = 8.0
_TYPICAL = 40.0


def _penalty(res):
    """Cost of leaving residual `res` in a bin. Lower is better."""
    # residuals too small to ever be useful are heavily penalized
    if res <= 0:
        return 1e6
    if res < _MIN_USEFUL:
        return 1000.0 - res * 10.0
    # best residual is one close to a typical item size (easy to fill exactly)
    return abs(res - _TYPICAL) * 0.5


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest score."""
    # Post-placement residual capacity for every candidate bin.
    residual = bins - item

    # Vectorized penalty evaluation.
    # Small residual: strong penalty.
    small = residual < _MIN_USEFUL
    pen = np.where(
        small,
        1000.0 - residual * 10.0,
        np.abs(residual - _TYPICAL) * 0.5,
    )

    # Prefer leaving residuals near typical item sizes (easy later fills),
    # so a lower penalty is better -> negate.
    # Also slightly prefer fuller bins (best fit): subtract residual.
    score = -(pen + residual * 0.01)
    return score
