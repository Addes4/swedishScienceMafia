import numpy as np

# Precompute a small preference by remainder for a Weibull-like mean-40 distribution.
# We reward remainders that are likely to be reusable by common item sizes and lightly
# penalize very small unusable remainders, while preserving best-fit as the main signal.
_REM = np.arange(101, dtype=np.float64)

# A smooth "usefulness" kernel: remainders near typical item sizes are valuable,
# remainders near 0 are wasteful.
_USEFUL = np.zeros(101, dtype=np.float64)
# Typical item sizes around 20..60, with emphasis near 30..45.
for r in range(101):
    # Value of a leftover capacity r: chance it can hold a future typical item.
    # Approximate P(next item <= r) under mean-40 Weibull-ish distribution:
    # use a logistic-ish CDF centered at 40.
    x = (r - 40.0) / 18.0
    cdf = 1.0 / (1.0 + np.exp(-x))
    # Slightly favor mid leftovers over tiny waste, but do not override best fit much.
    _USEFUL[r] = cdf - 0.08 * np.exp(-((r - 0.0) / 6.0) ** 2)

_STATE = {"n": 0, "sum": 0}


def priority(item, bins):
    """Rank bins: mostly best fit, nudged toward leaving reusable remainders."""
    # Best-fit primary signal: smaller leftover is better -> higher score.
    leftover = bins.astype(np.float64) - float(item)

    # Secondary signal: prefer leftovers that are useful for future typical items.
    # Scale it small so best fit dominates.
    utility = _USEFUL[leftover.astype(np.int64)]

    # Very small nonzero leftovers are often wasted; strongly discourage them
    # when a better fitting bin is available.
    waste_pen = np.where((leftover > 0) & (leftover < 12), -0.25, 0.0)

    # Exact fits are excellent; keep them at the top.
    exact_bonus = np.where(leftover == 0, 0.5, 0.0)

    score = -leftover + 0.12 * utility + waste_pen + exact_bonus

    # Avoid returning NaN/inf and keep order stable for ties.
    return score
