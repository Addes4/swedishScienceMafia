import numpy as np


class _State:
    def __init__(self):
        self.n_seen = 0
        self.sum_items = 0.0
        self.alpha = 0.6  # blend: 1 = best fit, 0 = worst fit


_state = _State()


def priority(item, bins):
    s = _state
    s.n_seen += 1
    s.sum_items += item

    # Adapt blend based on observed mean item size.
    # Large items -> favor tight fit; small items -> can benefit from spreading.
    # Mean is around 40 for this distribution.
    mean_item = s.sum_items / s.n_seen
    # alpha higher (best-fit) when items are larger
    alpha = min(1.0, max(0.0, mean_item / 50.0))

    b = bins.astype(np.float64)

    # Best fit component: higher score when remaining after placement is small.
    # Equivalent to prefer bins whose remaining capacity is just >= item.
    # residual decreases as bins approach item; use -(b - item).
    best_fit = -(b - item)

    # Worst fit component: prefer bins with larger remaining capacity
    # (spread small items so future large items can fit in fresh bins).
    worst_fit = b

    # Normalize both to comparable scale.
    bf = best_fit / 100.0
    wf = (worst_fit - 100.0) / 100.0

    return alpha * bf + (1.0 - alpha) * wf
