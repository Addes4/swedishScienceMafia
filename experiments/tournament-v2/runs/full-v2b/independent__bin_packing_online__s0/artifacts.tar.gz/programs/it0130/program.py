"""Best-fit bin packing: put each item in the bin it fits most tightly.

The item is assigned to the bin with the smallest remaining capacity after
placement, i.e. the smallest residual.  This minimizes wasted slivers within a
bin, keeps bins as full as possible, and encourages closing bins early, which
is a robust online strategy for independent, identically distributed sizes.
"""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Negative residual: the tightest fit (smallest bins - item) gets the highest score.
    return -(bins - item)
