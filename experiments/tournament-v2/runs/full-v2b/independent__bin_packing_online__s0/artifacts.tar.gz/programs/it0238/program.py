import numpy as np

def priority(item, bins):
    """
    Returns a score for each bin. Higher score = higher priority.
    Best fit: prefer the bin with the smallest remaining capacity that still fits the item.
    Optionally, add a small penalty for using an empty bin (capacity 100), to save empty bins.
    """
    # Small penalty for using an empty bin (capacity 100) to keep some empty bins available
    penalty = 1.0
    # Score: negative remaining capacity (prefer tighter fits), minus penalty if empty
    scores = -(bins - item).astype(np.float64)
    # Add a small penalty for empty bins to avoid using them unless necessary
    scores -= penalty * (bins == 100)
    return scores
