import numpy as np


class _State:
    def __init__(self):
        # histogram of observed item sizes (1..100), Laplace smoothed
        self.counts = np.ones(101, dtype=np.float64)
        self.total = 101.0
        self.calls = 0

    def update(self, item):
        self.counts[item] += 1.0
        self.total += 1.0
        self.calls += 1

    def prob(self, size):
        if size < 1 or size > 100:
            return 0.0
        return self.counts[size] / self.total


_state = _State()


def _residual_value(r):
    """Estimate desirability of leaving a bin with remaining capacity r.

    A residual is valuable if it equals or nearly matches sizes that arrive often.
    We reward the probability mass in a small window around r, since exact matches
    are rare with integer items but near matches still allow tight packing.
    """
    if r <= 0:
        return 0.0
    if r >= 100:
        return 0.0
    cnts = _state.counts
    # window around r
    lo = max(1, r - 3)
    hi = min(100, r + 3)
    mass = cnts[lo:hi + 1].sum()
    # weight exact-ish match more strongly the closer to r
    weights = 1.0 / (1.0 + np.abs(np.arange(lo, hi + 1) - r))
    return float((cnts[lo:hi + 1] * weights).sum()) / _state.total


def priority(item, bins):
    """Rank bins: prefer tight fits, but value residuals likely to be reused."""
    _state.update(item)

    # residual capacity after placing item
    residual = bins - item  # all fit, so >= 0

    # Best-fit component: smaller residual is better -> larger score
    # Normalize residual magnitude.
    tight = -residual.astype(np.float64)

    # Residual-utility component: prefer leaving residual that matches common sizes.
    n = residual.shape[0]
    res_val = np.empty(n, dtype=np.float64)
    # Only large residuals benefit; small residuals (near 0) are perfect fits already
    # Vectorized approximation of _residual_value is expensive; cache by unique values.
    uniq, inv = np.unique(residual, return_inverse=True)
    vals = np.empty(uniq.shape[0], dtype=np.float64)
    cnts = _state.counts
    total = _state.total
    for i, r in enumerate(uniq):
        if r <= 0 or r >= 100:
            vals[i] = 0.0
        else:
            lo = max(1, r - 3)
            hi = min(100, r + 3)
            seg = cnts[lo:hi + 1]
            w = 1.0 / (1.0 + np.abs(np.arange(lo, hi + 1) - r))
            vals[i] = float((seg * w).sum()) / total
    res_val = vals[inv]

    # Combine: exact fits dominate; then residual utility; then tightness.
    # Large bonus for exact fit (residual == 0).
    exact = (residual == 0).astype(np.float64)

    score = exact * 1e6 + res_val * 100.0 + tight
    return score
