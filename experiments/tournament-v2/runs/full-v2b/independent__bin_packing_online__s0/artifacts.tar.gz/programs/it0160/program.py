import numpy as np


def priority(item, bins):
    # Residual capacity after placing the item in each bin.
    after = bins - item  # bins already restricted to bins that fit

    # Base: best fit -> prefer the smallest residual (most tightly packed).
    score = -after.astype(np.float64)

    # Bonus for perfect fits: keeps bins from being wasted.
    score += np.where(after == 0, 25.0, 0.0)

    # Mild preference to avoid opening brand-new (empty) bins,
    # especially for small items. Large items may still justify a fresh bin.
    empty = (bins == 100)
    penalty = (100.0 - item) / 100.0  # larger penalty for smaller items
    score -= np.where(empty, 40.0 * penalty, 0.0)

    return score
