"""Best-fit with a threshold rule: pack tightly, but don't waste bins on large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Remaining capacity after placing the item.
    after = bins - item

    # Base: strongly prefer the tightest fit (smallest remaining after placement).
    score = -after.astype(np.float64)

    # If the item is large and the current best fit would leave a very small remainder,
    # it is often better to open/use a fresh bin instead of stuffing it into a nearly full one.
    # A fresh bin has after = 100 - item; prefer it over very tight residual fits.
    # Small bonus for using a fresh bin proportional to item size.
    fresh = (bins == 100)
    score = score + fresh.astype(np.float64) * (item * 0.5)

    # Mild bonus for ending up nearly full (good density).
    score = score + np.maximum(0.0, 20.0 - np.maximum(after, 0)) * 0.05

    return score
