"""Online bin packing with a distribution-aware best-fit priority rule.

The item distribution is Weibull-shaped with mean ~40.  Plain best fit (tightest
remaining capacity) is already strong, but it ignores how likely the leftover
space is to be used later.  We score each bin by the tightness of the fit plus a
bonus for leaving a residual capacity that a typical future item is likely to
fill well (i.e. residuals near common item sizes are good; small unusable
residuals are bad).
"""
import numpy as np

# Precomputed histogram of the item distribution (Weibull-shaped, mean ~40).
# We approximate it with a smoothed shape over 1..100.
_rng = np.arange(1, 101, dtype=float)
# Weibull(k=2, lambda adjusted so mean ~40): mean = lambda * Gamma(1 + 1/k)
# Gamma(1.5) ~ 0.8862269 ; lambda = 40 / 0.8862269 ~ 45.13
_lam = 40.0 / 0.8862269254527580
_k = 2.0
_pdf = (_k / _lam) * (_rng / _lam) ** (_k - 1.0) * np.exp(-(_rng / _lam) ** _k)
_pdf = np.maximum(_pdf, 1e-12)
_pdf /= _pdf.sum()

# Cumulative distribution over "can an item <= s fit here" style residual value.
# residual value V(s) = expected best-fit quality if we leave residual s:
#   fraction of items that fit into s (i.e. item <= s), weighted so larger
#   usable residual tends to be more valuable but tight packing rewards small s.
_cdf = np.cumsum(_pdf)  # _cdf[i-1] = P(item <= i)


def priority(item, bins):
    bins = np.asarray(bins)
    remaining = bins - item  # residual if item placed here; >= 0 by construction

    # Base: best fit -> prefer smallest residual (tightest).
    score = -remaining.astype(np.float64)

    # Perfect/near-perfect fits: strongly favored to reduce waste.
    score += (remaining == 0) * 5.0
    score += (remaining == 1) * 2.0

    # Lookahead: value of the residual for future items.
    # residual r in [0, 99]; clip to valid index range.
    r = np.clip(remaining, 0, 100).astype(np.int64)
    # Probability that a typical next item fits the residual.
    fit_prob = _cdf[np.clip(r - 1, 0, 99)]
    # Good residual: high chance a future item fits AND it stays fairly tight.
    # Reward residuals that are likely usable; penalize tiny dead space.
    score += 1.5 * fit_prob
    # Penalize leaving residuals in the "dead zone" just below common sizes
    # (small residuals that waste space without being fillable well).
    score -= 0.8 * (r > 0) * (r < 10)

    return score
