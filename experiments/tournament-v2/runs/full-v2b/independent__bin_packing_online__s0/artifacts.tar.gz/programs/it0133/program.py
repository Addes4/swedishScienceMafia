import numpy as np


class Packer:
    def __init__(self):
        self.n_calls = 0
        self.total_item = 0
        self.total_waste = 0.0
        self.residuals = []

    def __call__(self, item, bins):
        self.n_calls += 1
        self.total_item += item

        residual = bins - item  # remaining after placing item

        # Best-fit base score
        score = -residual.astype(np.float64)

        if self.residuals:
            # Target residual: typical leftover we accept
            arr = np.array(self.residuals[-500:], dtype=np.float64)
            target = float(np.mean(arr))
            target = min(max(target, 0.0), 100.0)
        else:
            target = 0.0

        # Bonus for finishing close to target residual (tight but not perfect waste)
        diff = np.abs(residual.astype(np.float64) - target)
        score -= 0.15 * diff

        # Strongly prefer exact/perfect fits
        perfect = (residual == 0)
        score += 50.0 * perfect.astype(np.float64)

        # Slight bonus for very tight fits
        tight = (residual <= 5) & (residual > 0)
        score += 5.0 * tight.astype(np.float64)

        # Track chosen residual (record before returning)
        best_idx = int(np.argmax(score))
        self.residuals.append(int(residual[best_idx]))
        if len(self.residuals) > 2000:
            self.residuals = self.residuals[-1000:]

        return score


_packer = Packer()


def priority(item, bins):
    return _packer(item, bins)
