"""Online bin packing: best-fit with online residual-utility scoring."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes seen so far (index 1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.n = 0.0

    def update(self, item):
        self.hist[item] += 1.0
        self.n += 1.0


_state = _State()


def priority(item, bins):
    """Score bins: prefer tight fits, but avoid leaving residues that are
    likely to be hit exactly by a future item (wasted perfect-fit opportunities)."""
    _state.update(item)

    # Small-sample safety: for the first few items just do best fit.
    b = bins.astype(np.float64)
    if _state.n < 32:
        return -(b - item)

    # Estimated probability of each future size occurring.
    p = _state.hist / _state.n

    # residual capacity r = b - item  (>= 0)
    r = b - item

    # Probability that a future single item exactly equals the residual:
    # this is good if it happens (fills bin), so we do NOT want to discourage it;
    # instead we want to discourage residues that are hard to combine.
    #
    # Use a utility: -log-ish measure of small-bin fragmentation.
    # Score = best-fit tightness gain minus expected waste.
    #
    # Tighter fit leaves smaller residual -> generally better (classic best fit).
    # Additional penalty: residues in the "common small item" range that leave
    # a bin open but too small for typical items cause fragmentation.
    #
    # Expected remaining usable capacity contribution:
    # For residual r, the chance a random future item of size s <= r fits is
    # sum_{s<=r} p[s]. Larger residual => more likely usable.
    # We blend: strongly favor small residual, but mildly reward residual sizes
    # that are unlikely to be exactly matched yet still fit future items poorly
    # is contradictory; keep it simple and effective.

    # cumulative probability that a future item fits in residual r
    cum = np.cumsum(p)  # cum[k] = P(size <= k), index 0..100
    # For each bin, probability next item fits into this bin's residual.
    rr = r.astype(np.int64)
    np.clip(rr, 0, 100, out=rr)
    fit_prob = cum[rr]

    # Utility of a bin: tight fit is good (small residual), and residual that
    # is easy to fill later is good. Combine with a weighting that favors
    # leaving room exactly for common upcoming sizes.
    # Perfect-fit potential: probability residual equals a likely size.
    exact = p[rr]

    # Core best-fit term: -residual (so higher score for smaller residual).
    # Boost slightly when residual is very likely to be exactly filled later.
    score = -(r) + 2.0 * exact * 100.0 * 0.0  # keep tight-fit dominant
    # reward larger fit probability mildly (less fragmentation)
    score = score + 1.5 * fit_prob

    # tie-break / determinism: tiny preference for earlier bins
    score = score - 1e-9 * np.arange(len(bins))

    return score
