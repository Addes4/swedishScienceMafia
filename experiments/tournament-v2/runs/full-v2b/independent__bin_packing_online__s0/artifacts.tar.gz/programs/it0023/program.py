import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties go to first.

    Strategy: modified best fit.  Prefer bins whose remaining capacity is closest to
    the item size, but apply a mild bonus to nearly-full bins so that items tend to
    complete bins.  This approximates a hybrid of best-fit and a residue-preserving
    overfill heuristic.
    """
    # Residual after placing item: smaller is better (classic best fit).
    residual = bins - item

    # Bonus for bins that will be left with a very small residual.  This encourages
    # packing items together and closing bins, which is generally good online.
    # A smaller residual gets a larger (less negative) score.
    # The scale is chosen to be modest relative to item sizes so it does not
    # override best-fit too aggressively.
    closeness_bonus = np.where(residual >= 0, 100.0 / (residual + 1.0), -1e6)

    # Slight preference for using already-nonempty bins over empty bins (bins == 100)
    # to avoid opening new bins prematurely.  However, if an item is large, opening
    # a new bin may be unavoidable and best-fit handles that.
    nonempty_bonus = np.where(bins < 100, 1.0, 0.0)

    # Penalize bins where the item would leave a large remainder much larger than
    # the item, i.e., prevent putting small items into very empty bins when a
    # tighter fit exists.  This is implicitly handled by best-fit, but add a weak
    # term for robustness.
    waste_penalty = -np.maximum(residual - item, 0) * 0.01

    score = -residual.astype(np.float64) + closeness_bonus + nonempty_bonus + waste_penalty

    # Ensure unused bins (remaining == 100) are not scored identically to a
    # perfect fit bin with the same residual unless appropriate.
    # Unused bins have residual = 100 - item, which is usually large, so best-fit
    # already deprioritizes them for small items.
    return score
