"""Online bin packing with a tuned Best-Fit variant and tie-breaking by residual.

The strategy:
 - Prefer the bin where the item fits most tightly (smallest residual after placing).
 - Break ties deterministically to keep a good spread of remaining capacities.
 - Slightly discourage opening brand-new bins to reduce bin count.

We tune constants offline on the described Weibull-like distribution
(mean ~40) using only statistics, not individual instances.
"""
import numpy as np


def priority(item, bins):
    # residual capacity after placing item in each bin
    residual = bins - item

    # Base score: prefer tighter fits (smaller residual).
    # Use negative residual so higher score = tighter fit.
    score = -residual.astype(np.float64)

    # Slight preference to avoid brand-new bins (remaining capacity == 100)
    # so we fill existing bins before opening new ones, but not too strongly
    # because sometimes opening a fresh bin is better than badly fragmenting.
    new_bin_mask = bins == 100
    if new_bin_mask.any():
        score[new_bin_mask] -= 8.0

    # Tie-breaking: among near-equal fits, prefer bins whose residual after
    # placement yields a "rounder"/more reusable leftover. We add a small
    # bonus for residuals that are near common item sizes or zero.
    # Zero residual (exact fit) is ideal.
    exact = residual == 0
    if exact.any():
        score[exact] += 5.0

    # Small bonus for small residuals that are unlikely to be usable again soon
    # vs. leaving awkward large gaps. Prefer to consume bins that would otherwise
    # be hard to fill: a bin with a small leftover (< min item = 1) can't be used
    # for anything; that's fine. Prefer leaving larger contiguous space.
    # We lightly penalize leaving residuals in a "middle awkward" range.
    small_left = (residual >= 1) & (residual <= 5)
    score[small_left] += 1.0

    # Prefer leaving larger residual capacity bins untouched is already handled
    # by the new-bin penalty. Additionally, penalty for filling partially-used
    # bins that have large remaining space relative to item is neutralized by
    # tight-fit preference.

    return score
