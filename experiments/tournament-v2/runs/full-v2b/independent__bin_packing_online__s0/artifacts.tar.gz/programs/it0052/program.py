"""Adaptive best-fit: prefer tight fits, mildly discourage opening new bins."""
import numpy as np

# Tunable bonus subtracted from the score of completely empty bins.
# Since higher score wins, subtracting makes empty bins less attractive.
EMPTY_PENALTY = 5


def priority(item, bins):
    """Rank bins by best fit, with a small penalty for empty (capacity 100) bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of each bin the item fits in.
    Returns high scores for bins that leave little room after the item is placed.
    """
    remaining_after = bins - item          # smaller is better
    scores = -remaining_after.astype(np.float64)
    # discourage using brand-new bins unless they are clearly the best fit
    scores -= EMPTY_PENALTY * (bins == 100)
    return scores
