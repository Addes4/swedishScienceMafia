import numpy as np

# Simple state: running mean and count of items seen
_state = {
    "n": 0,
    "mean_size": 0.0,
}

def priority(item, bins):
    """
    Score each bin for the incoming item.

    Heuristic:
      - For small items, prefer tight fits (best fit).
      - For larger items, slightly prefer leaving bins with small residual
        that could still hold future items, and avoid fragmenting by
        always taking the tightest fit blindly.
      - Use a size-dependent weight on the negative residual to balance.
    """
    global _state

    # Update running mean of item sizes (cheap, no future info)
    _state["n"] += 1
    n = _state["n"]
    _state["mean_size"] += (item - _state["mean_size"]) / n

    # bins is int64 array of remaining capacities for bins the item fits into.
    # We must return scores of same length.
    remaining = bins.astype(np.float64)

    # Size categories: small (<30), medium (30..60), large (>60)
    # Tune weights: small items -> tightest fit; larger items -> mildly prefer
    # bins that leave a bit more room or less room depending on distribution.
    mean_sz = _state["mean_size"]

    if item <= 25:
        # Very small: pure best fit (tightest)
        score = -remaining
    elif item <= 55:
        # Medium: best fit with slight preference for bins whose residual
        # is close to a typical future item size (mean_sz) modulo 100?
        # Avoid leaving residual just below item size when possible.
        # Use negative residual plus a small bonus for residual >= item + mean_sz*0.5
        bonus = np.where(remaining - item >= mean_sz * 0.5, 1.0, 0.0)
        score = -remaining + bonus * 0.5
    else:
        # Large: prefer bins with larger remaining capacity after placement
        # (less fragmentation pressure), but still somewhat tight.
        # Weighted mix: negative residual scaled down, plus bonus for large leftover.
        score = -0.3 * remaining + 0.7 * (remaining - item)

    # Ensure no NaN and return as numpy array
    return score
