import numpy as np

# State: exponential moving average of item sizes, used to decide when to open a new bin.
# This is an online best-fit with a bias toward partially filled bins.

_ema = 40.0
_alpha = 0.01
_count = 0

def priority(item, bins):
    global _ema, _count
    # Update EMA of item sizes
    if _count == 0:
        _ema = float(item)
    else:
        _ema = (1 - _alpha) * _ema + _alpha * float(item)
    _count += 1

    # Best fit: score = -(remaining after placement) = -(bins - item)
    # This is the baseline. Add a small bias: prefer bins that are already partially used
    # (i.e., remaining capacity < 100), but without harming tightness too much.
    # Score = tightness + epsilon * (100 - bins) for partially filled bins.
    # Actually, the baseline -(bins - item) already prefers tighter fits.
    # A tiny bonus for non-empty bins can help avoid leaving small gaps.
    tightness = -(bins - item)  # higher for tighter fit
    # Bonus for bins that are already used (remaining < 100), scaled small.
    used_bonus = np.where(bins < 100, 0.01, 0.0)
    return tightness + used_bonus
