import numpy as np

# Precompute scores for all possible remaining capacities and item sizes.
# For a bin with remaining capacity r and an item of size s (s <= r <= 100),
# best fit prefers the smallest possible leftover r - s.
# To avoid overspecializing and to give a deterministic, fast, vectorized rule,
# we score bins by -leftover, with a tiny bonus for bins that are less full
# (i.e. larger r), which tends to leave more room for future items.
_ITEM = 100
_REM = 101
_SCORE = np.empty((_REM, _ITEM), dtype=np.float64)
for r in range(101):
    for s in range(1, 101):
        if s > r:
            _SCORE[r, s - 1] = -1e18
        else:
            leftover = r - s
            # Primary: minimize leftover (best fit). Secondary: mildly prefer
            # bins with more remaining capacity to avoid premature fragmentation.
            _SCORE[r, s - 1] = -leftover + 0.001 * r

def priority(item, bins):
    """Best-fit-like rule with a small secondary preference for emptier bins."""
    # bins contains only bins the item fits in, with capacities in 0..100.
    # Clip defensively in case a bin has remaining capacity exactly item (allowed).
    r = bins.astype(np.int64, copy=False)
    # Fast path: use lookup table. Clamp to valid indices.
    rr = np.clip(r, 0, 100)
    s = int(item)
    if s < 1:
        s = 1
    elif s > 100:
        s = 100
    return _SCORE[rr, s - 1]
