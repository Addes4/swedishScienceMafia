import numpy as np

_EPS = 0.01

def priority(item, bins):
    residual = bins - item
    fullness = 100 - bins
    return -(residual.astype(np.float64)) - _EPS * fullness
