import numpy as np


def priority(item, bins):
    # Best fit: prefer bins where the item leaves the least unused space.
    # Use a tiny preference for exact fits and for bins that remain reasonably open,
    # breaking near-ties toward earlier bins to keep behavior stable.
    remaining = bins - item
    score = -remaining.astype(np.float64)

    # Small bonus for exact fits (no wasted capacity).
    score[remaining == 0] += 0.25

    # Slightly avoid leaving tiny residuals that are hard to fill later.
    tiny = (remaining > 0) & (remaining < 5)
    score[tiny] -= 0.05

    return score
