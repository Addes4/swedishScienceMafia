"""Online bin packing: best-fit with remainder-aware tie-break.

Idea: choose the bin whose remaining capacity is smallest but still >= item
(i.e. best fit). This minimizes leftover space and tends to pack tightly.
A small secondary term discourages exact-fit-then-large-leftover patterns
by preferring bins that will be closer to full after placement.
"""
import numpy as np


def priority(item, bins):
    # Primary: best fit -> maximize -(bins - item), equivalently minimize bins.
    # Secondary: among bins with equal leftover, prefer the one whose post-placement
    # remainder is smaller relative to its pre-placement remainder (mild)
    rem_after = bins - item  # >= 0 since bins only contains fitting bins
    # Best fit score: negative remainder, larger (less negative) = better.
    return -rem_after
