# EVOLVE-BLOCK-START
"""Online bin packing: tight-fit prioritization with empty-bin preference control.

Strategy:
- Strongly prefer placing an item so the bin becomes exactly full (leftover 0).
- Otherwise prefer bins whose remaining capacity is closest to the item size
  (best fit), but penalize leaving tiny unusable gaps only mildly.
- Empty bins (capacity 100) get no special bonus, since early items are
  better packed into partially-filled bins when possible.

The score is designed so that lower leftover is better, with a large bonus
for an exact fill. This is essentially best-fit with a small exact-fit bonus.
"""
import numpy as np


def priority(item, bins):
    leftover = bins - item  # >= 0 for all shown bins
    # Exact fill gets a big bonus; otherwise prefer smallest leftover.
    score = -leftover.astype(np.float64)
    score[leftover == 0] += 1000.0
    return score
# EVOLVE-BLOCK-END
