import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    This is best fit with a penalty for leaving a small non-zero remainder,
    which is likely to be wasted given the item-size distribution.
    """
    leftover = bins - item
    score = -leftover.astype(np.float64)
    # Penalise leaving a small non-zero remainder (less than 20% of the item size).
    threshold = 0.2 * item
    mask = (leftover > 0) & (leftover < threshold)
    score[mask] -= 1000.0
    return score
