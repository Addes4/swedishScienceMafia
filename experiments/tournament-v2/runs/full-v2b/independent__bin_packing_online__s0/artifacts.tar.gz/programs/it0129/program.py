import numpy as np

# Deterministic online bin-packing heuristic tuned for items ~ Weibull(mean 40), capacity 100.
# Score = best-fit tightness, with a mild preference to avoid wasting large empty bins.
# The item goes to the highest score; ties go to the earliest bin.

def priority(item, bins):
    # bins: remaining capacities (int64). We want the bin that fits item most tightly,
    # i.e. minimal residual r = bins - item, but also avoid using a nearly empty (cap 100)
    # bin when a tighter fit exists. Best fit already does this well; add a tiny
    # preference for bins that leave a "useful" remainder (so small residuals are best).
    residual = bins - item
    # Small bonus for not leaving the bin completely empty (encourage filling larger bins).
    # For unused bins residual is 100 - item; we slightly penalize very large residuals.
    scores = -residual.astype(np.float64)
    # Mild extra reward for bins that become relatively full (small residual), already in scores.
    # Encourage exact/near fills by emphasizing small residuals, but not too strongly.
    scores -= 0.001 * residual * residual
    return scores
