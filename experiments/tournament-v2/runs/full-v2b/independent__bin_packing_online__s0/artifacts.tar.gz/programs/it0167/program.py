"""Adaptive online bin packing: best-fit with exact-fill bonus and new-bin penalty."""
import numpy as np


class PackerState:
    def __init__(self):
        self.calls = 0

    def reset(self):
        self.calls = 0


_STATE = PackerState()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _STATE.calls += 1

    # -(bins - item) is best fit: tightest residual capacity wins.
    tight = -(bins - item)

    # Bonus for near-perfect fills: a small residual after placement is very valuable.
    residual = bins - item  # >= 0 for fitting bins
    exact_bonus = np.where(residual == 0, 1000.0,
                 np.where(residual <= 2, 200.0,
                 np.where(residual <= 5, 50.0, 0.0)))

    # Penalize using a fresh/unused bin (capacity 100) unless the item is large,
    # to avoid prematurely opening many bins for small items.
    is_fresh = bins == 100
    # Larger items justify opening a new bin; small items should reuse bins.
    fresh_penalty = np.where(is_fresh, (item - 40) * 1.5, 0.0)

    # Slight preference for fuller used bins.
    fullness_bonus = np.where(is_fresh, 0.0, (100.0 - bins) * 0.01)

    return tight + exact_bonus + fresh_penalty + fullness_bonus
