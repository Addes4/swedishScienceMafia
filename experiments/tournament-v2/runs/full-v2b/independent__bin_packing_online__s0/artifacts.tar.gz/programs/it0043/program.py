"""Adaptive best-fit with residual-value scoring for online bin packing."""

import numpy as np

# State for online statistics
_state = {
    'count': 0,
    'sum': 0.0,
    'items': [],
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update online statistics (bounded memory)
    _state['count'] += 1
    _state['sum'] += item
    if len(_state['items']) < 2000:
        _state['items'].append(item)

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item  # remaining capacity after placing the item

    # Estimate the item-size distribution parameters online.
    if len(_state['items']) >= 50:
        arr = np.asarray(_state['items'], dtype=np.float64)
        mean = arr.mean()
        std = arr.std() + 1e-9
    else:
        mean = 40.0
        std = 25.0

    # A residual is "good" if it can still hold a typical item.
    # The score rewards residual capacity close to a typical item size,
    # i.e., bins whose leftover fits common future items tightly.
    # Base: classic best-fit -> residual small.
    # Correction: prefer residuals that are near a multiple-useful size.

    # Penalty for wasted residual: residual that is too small to be useful
    # but nonzero, or too large causing fragmentation.
    # We model the "utility" of a residual r as the chance it can accept
    # a future item, weighted to keep bins full.

    # Approximate probability that a future item fits into residual r
    # using a normal approximation of the item distribution.
    from math import erf, sqrt

    def p_fit(r):
        # P(item <= r) for item ~ Normal(mean, std), clipped to [0,1]
        if r <= 0:
            return 0.0
        z = (r - mean) / (std * sqrt(2.0))
        val = 0.5 * (1.0 + erf(z))
        return min(max(val, 0.0), 1.0)

    # Vectorized normal CDF for speed
    r = residual.astype(np.float64)
    z = (r - mean) / (std * np.sqrt(2.0))
    # erf via scipy if available, else numpy approximation
    try:
        from scipy.special import erf as sp_erf
        pfit = 0.5 * (1.0 + sp_erf(z))
    except Exception:
        # numpy erf approximation using tanh (fast, decent)
        pfit = 0.5 * (1.0 + np.tanh(0.7978845608 * (z + 0.044715 * z ** 3)))
    pfit = np.clip(pfit, 0.0, 1.0)

    # Score design:
    # We want to choose a bin minimizing expected waste.
    # A useful heuristic: score = fill_efficiency - fragmentation_penalty.
    # 1) Prefer bins whose residual is small (best fit) but still leave
    #    bins that can pack tightly.
    # 2) Prefer residuals that are themselves close to typical item sizes
    #    (so future items can fill them nicely).

    # Kernel around typical item sizes: residual modulo mean closeness
    # Reward residuals that are near a multiple of the mean item size,
    # which tends to indicate good packing structure.
    frac = r / mean
    near_multiple = np.abs(frac - np.round(frac))
    mult_bonus = 1.0 - near_multiple  # in [0,1]

    # Main term: best-fit (small residual => higher score)
    # Use negative residual scaled.
    best_fit = -r

    # Fragmentation penalty: penalize residuals that are small-but-nonzero
    # (can't fit typical items) less than mid residuals which could cause waste.
    # Reward residuals with decent pfit and near-multiple structure.
    structure = mult_bonus * pfit

    # Prefer bins that are already partially full (more used) to reduce bin count.
    used = 100 - bins
    fullness_bonus = used / 100.0

    # Combine terms with tuned weights.
    score = (
        best_fit
        + 12.0 * structure
        + 3.0 * fullness_bonus
    )

    # Ensure exact-fit gets top priority (residual 0)
    score = np.where(residual == 0, 1e6, score)

    return score
