import numpy as np

_state = {
    "counts": np.zeros(101, dtype=np.float64),
    "total": 0.0,
}


def priority(item, bins):
    # Update running size histogram (cheap, amortized O(1) per call)
    _state["counts"][item] += 1.0
    _state["total"] += 1.0

    # Estimate the mean item size so far (used to score "waste" of each bin).
    # For a stable estimate, blend toward the known distribution mean (~40).
    t = _state["total"]
    empirical_mean = float((np.arange(101, dtype=np.float64) * _state["counts"]).sum()) / t
    mean_size = 0.5 * 40.0 + 0.5 * empirical_mean

    # Residuals after placing the item.
    resid = bins - item  # >= 0 guaranteed for the bins we are shown.

    # A residual is "good" if it is small (tight fit) OR it matches a size that is
    # likely to arrive soon (so the bin can be filled completely). We reward residuals
    # near zero strongly, and reward residuals close to the mean item size modestly.
    # Score is negative "waste" with a bonus for residuals likely to be usable.
    waste = resid.astype(np.float64)

    # Bonus: residual close to a plausible next item size (~ mean) is useful.
    # Use a smooth window around mean_size with width ~ 10.
    bonus = np.exp(-((waste - mean_size) ** 2) / (2.0 * 10.0 * 10.0)) * 5.0

    # Strong preference for tight fits (small residual), which drives high utilization.
    score = -waste + bonus

    # Prefer bins that were utilized more relative to capacity (i.e., less remaining
    # before placement): tighter residual dominates already. Also, avoid leaving a bin
    # with residual just below a common item size (hard to fill) -> tiny penalty.
    # This penalty is only meaningful for small residuals that miss nice sums.
    return score
