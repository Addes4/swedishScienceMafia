import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes, used to estimate future packing potential
        self.hist = np.zeros(101, dtype=np.int64)
        self.count = 0
        # EMA of item size, used to bias opening behavior
        self.mean = 40.0


_st = _State()


def priority(item, bins):
    """Rank bins: prefer tightest fit, with tie-breaking for packing efficiency."""
    global _st
    it = int(item)
    b = bins.astype(np.int64)

    # Negative remaining-after-place = tightest fit gets highest score.
    # (b - item) is remaining capacity after placing; smaller is better.
    score = -(b - it)

    # Slight preference for already-used bins (lower remaining -> used)
    # over fresh bins only when the fresh bin would be essentially untouched,
    # which best-fit already handles. Add tiny deterministic jitter by index order
    # is not allowed to break ties (first wins), so encode tie-break in score.
    # Among equal scores, prefer the bin that leaves capacity matching common
    # item sizes (more likely reusable). Use histogram from past items.
    if _st.count > 0:
        # For each bin, compute residual after placing. Reward residuals that
        # correspond to frequently-seen future item sizes (bin can be refilled well).
        residual = b - it
        # probability mass of future item sizes <= residual (capped)
        h = _st.hist
        total = float(_st.count)
        # cumulative distribution up to residual, normalized
        cum = np.cumsum(h) / total
        # For zero residual, no future item fits -> slightly penalize exact fills
        # unless item is large; use a small bonus for residuals that fit many items.
        fit_mass = cum[np.clip(residual, 0, 100)]
        # exact fill (residual==0) is perfect reuse-wise; treat separately
        exact = (residual == 0).astype(np.float64)
        bonus = 0.02 * fit_mass + 0.01 * exact
        score = score.astype(np.float64) - bonus
    else:
        score = score.astype(np.float64)

    # Update statistics (after scoring, using only current item)
    _st.hist[it] += 1
    _st.count += 1
    _st.mean = 0.999 * _st.mean + 0.001 * it

    return score
