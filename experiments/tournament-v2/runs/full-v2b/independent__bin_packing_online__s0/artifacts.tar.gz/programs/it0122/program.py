import numpy as np

_state = {"count": 0, "hist": {}}


def priority(item, bins):
    # bins is a copy; do not modify it
    b = bins

    # Best fit: smaller remaining capacity after placing is better.
    # rem_after = bins - item ; tighter fit -> smaller rem_after.
    # Use negative so higher score is better.
    base = -(b - item)

    # Fragmentation-aware tie-break:
    # Prefer bins whose remaining capacity is closer to the item size,
    # and slightly prefer non-empty bins (b < 100) to avoid opening new bins.
    # Also prefer bins that leave remainders which are "useful" (small leftover waste).
    leftover = b - item

    # Bonus for using an already-used bin (full capacity 100 means unused).
    used_bonus = np.where(b < 100, 1e-3, 0.0)

    # Penalize leftover that is very small (< minimum item size 1 is always useful,
    # but leftover 0 is perfect). Basically best fit already captures this.

    # Small deterministic perturbation to reduce equal-score ties stacking badly:
    # prefer bins with more remaining capacity variance-compatible? Keep simple.
    # Prefer bin that becomes exactly full (leftover 0).
    exact_bonus = np.where(leftover == 0, 1e-2, 0.0)

    score = base.astype(np.float64) + used_bonus + exact_bonus

    # Track simple state (unused for now, but allowed)
    _state["count"] += 1

    return score
