import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin with the least remaining capacity that still fits.

    Score = -(remaining capacity after placing item). Highest score = tightest fit.
    Ties (equal remaining capacity) go to the first bin, which naturally favors
    already-open bins since used bins have lower remaining capacity than full bins.
    """
    return -(bins - item)
