import numpy as np


def priority(item, bins):
    # Best-fit style, but avoid leaving tiny unusable gaps.
    # Prefer fitting tightly, yet give a bonus to bins whose remainder
    # after placing the item is either zero or not too small.
    rem = bins.astype(np.int64) - item
    # Score: higher is better. Larger `bins` (more free space) is worse
    # than a tight fit, except we penalize creating small leftovers.
    score = -bins

    # Non-positive remainder means exact/excess fit region (since bins only
    # contains fitting bins, rem >= 0 in practice).
    exact = rem == 0
    small = (rem > 0) & (rem < 15)
    bonus = np.where(exact, 200.0, np.where(small, -50.0, 0.0))
    return score + bonus
