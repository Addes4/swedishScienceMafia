"""Best-fit with tuned tie-breaking and residual-aware scoring."""
import numpy as np

_state = {"n": 0, "sum": 0}

def priority(item, bins):
    # bins: remaining capacities (int64), only bins where item fits
    n = _state["n"]
    _state["n"] = n + 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    # remaining capacity AFTER placing item
    rem = bins - item  # in [0, 100-item]

    # Base: prefer tightest fit => smallest remaining after placement
    # Score higher for smaller rem. Use negative rem.
    score = -rem.astype(np.float64)

    # Bonus for bins that would become exactly full (rem == 0)
    exact = (rem == 0)
    score[exact] += 2.0

    # Slight preference for already-used bins over completely empty ones,
    # to avoid wasting fresh bins when a used bin is a decent fit.
    empty = (bins == 100)
    score[empty] -= 0.5

    # Refine: among fits, break ties by preferring bins with smaller resulting
    # leftover relative to typical future item size (favor residue that fits
    # typical items less? Actually leave room that suits mean item).
    # Add a tiny secondary term: penalize leftovers just below mean item size
    # (hard to reuse), reward leftovers near multiples of mean item.
    if mean_item > 1:
        ratio = rem.astype(np.float64) / mean_item
        frac = ratio - np.floor(ratio)
        # frac near 0 => leftover is near multiple of mean => good reuse
        # frac near 1 => leftover just under a multiple => wasteful
        score += 0.25 * (0.5 - frac)

    # Within same rem, first bin wins by tie order already; small stable noise
    # is avoided to keep determinism.
    return score
