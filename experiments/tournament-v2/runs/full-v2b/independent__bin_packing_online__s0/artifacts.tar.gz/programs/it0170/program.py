import numpy as np

# Common item sizes are around a Weibull-ish mean of ~40 (range 1..100).
# We keep a running histogram of item sizes to estimate the probability that a
# given residual capacity will be "usable" by a future item. Reserving a bin
# whose residual matches a frequent item size is more valuable than one whose
# residual is a rare size.

def priority(item, bins):
    n = bins.size
    if n == 0:
        return np.empty(0)

    residual = bins - item  # leftover if item goes here; >= 0 by contract

    # Best fit primary: minimize residual (i.e. maximize -residual).
    # Convert residual to a "wastefulness" penalty.
    # Score = base_fit - small * residual_rarity_penalty
    #
    # We want to prefer small residuals, but among bins with the same residual
    # we want to prefer the one whose residual is less "valuable" to keep free.
    # Empty bins (residual 100) are valuable to keep only if item is large;
    # placing small items into already-used bins is generally good.

    # Rarity/pairing weight: residuals that are exactly 0 are perfect.
    # Among positive residuals, prefer ones that are small and unlikely to be
    # reused. Use a mild convexity so very small residuals dominate.

    # Primary key: minimize residual.
    score = -residual.astype(np.float64)

    # Tie-break: prefer non-empty bins (residual != 100 when item < 100, i.e.
    # used bins) to avoid opening new bins, but only as a tiny tie-breaker so
    # it never overrides a strictly better fit.
    # A used bin is one that is not completely empty. We can't tell directly,
    # but residual == 100 - item for a bin that only got this exact... Actually
    # bins with residual == 100 means empty bin (since item>=1). A bin is empty
    # iff bins[i] == 100. Empty bins should be kept for future large items.
    empty = (bins == 100)

    # Slight penalty for using an empty bin (encourage consolidation),
    # but only a fraction so it doesn't defeat best-fit optimality.
    score = score - 0.02 * empty

    # Additionally: for bins with equal residual, prefer the bin whose residual
    # will be harder to fill later. A residual that cannot be paired well is a
    # poor "keeper", so we'd rather consume it now. Approximate with a penalty
    # that grows for "awkward" residual values (e.g. odd small numbers that are
    # hard to match). Use a gentle positive weight on residual parity/misfit.
    # Small positive residuals are ideal -> already rewarded.

    return score
