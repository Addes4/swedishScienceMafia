import numpy as np


def priority(item, bins):
    """Best-fit-style priority with tie-breaking and a near-full bonus.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
          Unused bins have capacity 100 and are included, in bin order.
    """
    # Primary: best fit = minimize remaining capacity after placement,
    # equivalently maximize item - bins? Actually bins are remaining capacities.
    # We want the bin with the smallest remaining capacity that still fits,
    # i.e. minimize (bins - item), so maximize -(bins - item) = item - bins.
    #
    # Secondary: prefer bins that are already fairly full (edge bias),
    # to reduce the number of open partially-filled bins.
    #
    # Tertiary: prefer earlier bins slightly, to keep tie behavior stable.
    n = bins.shape[0]
    # scores = -remaining_after = -(bins - item) = item - bins
    # Add a small bonus for bins that will become nearly full.
    rem_after = bins - item
    # Bonus for small rem_after (near-full after placing), but do not
    # overpower the primary ordering. Use a scaled term.
    # Primary term dominates; secondary breaks ties and nudges.
    primary = -rem_after.astype(np.float64)
    secondary = -(rem_after.astype(np.float64) ** 2) * 1e-3
    tertiary = -np.arange(n, dtype=np.float64) * 1e-9
    return primary + secondary + tertiary
