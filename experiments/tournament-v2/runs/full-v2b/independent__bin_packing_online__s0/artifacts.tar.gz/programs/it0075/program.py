"""Online bin packing: hybrid best-fit with residual-space heuristics.

The rule ranks each fitting bin by a combination of:
  * tightest-fit preference: smaller remaining capacity minus item is better
  * a mild penalty for creating very small unusable residual gaps
  * a mild bonus/penalty based on how close the resulting residual is to
    common future item sizes, estimated from the known Weibull-like distribution
  * a tie-breaker that prefers opening a new bin only when necessary

State is kept only to estimate online statistics, but the primary decision is
deterministic and robust across instances.
"""

import numpy as np

# Precomputed-ish constants for the expected item distribution.
# Mean about 40, Weibull-shaped.  These help mildly break ties.
_SMALL = 12          # threshold for awkward tiny residual space
_TINY = 5
_LARGE = 85

# Running statistics (optional; only used for very mild adaptation).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    global _state

    # Update simple online stats (not essential to the main rule).
    _state["n"] += 1
    _state["sum"] += item
    avg = _state["sum"] / _state["n"]

    bins = np.asarray(bins, dtype=np.float64)
    rem = bins - item  # residual capacity after placing the item

    # Base: prefer the tightest fit (smallest residual).  Negative residual
    # means it still fits, larger residual = worse.  We want higher score for
    # smaller residual, so use the negative residual.
    score = -rem

    # Avoid creating tiny residuals that are likely to be wasted.  A residual
    # of 0 is actually good (perfect fill).  Residuals 1.._TINY are bad.
    tiny_mask = (rem > 0) & (rem <= _TINY)
    score[tiny_mask] -= 2.5

    # Mildly penalize small-but-not-tiny residuals below a threshold, since
    # they can only accept small future items.
    small_mask = (rem > _TINY) & (rem <= _SMALL)
    score[small_mask] -= 0.6

    # Slight bonus for leaving a residual close to a typical item size,
    # because such holes are more likely to be filled later.
    # Typical sizes cluster around avg; reward residuals near avg.
    target = avg
    closeness = -np.abs(rem - target)
    score += 0.015 * closeness

    # Prefer not to open brand-new bins (remaining capacity 100) if an
    # existing bin is nearly as good.  This reduces fragmentation.
    unused = bins >= 100
    score[unused] -= 0.8

    # For very large items, opening a fresh bin is often necessary; reduce
    # the penalty so best-fit still works.
    if item > _LARGE:
        score[unused] += 0.7

    # For very small items, strongly prefer existing holes over new bins.
    if item <= _SMALL:
        score[unused] -= 1.5

    return score
