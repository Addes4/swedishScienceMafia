# EVOLVE-BLOCK-START
"""Adaptive best-fit for online bin packing.

The item is normally placed into the bin with the smallest remaining capacity
that still fits (best fit).  To reduce unnecessary opening of new bins, empty
bins are mildly penalized after a warm-up period using an estimate of the
current lower bound based on the total size seen so far and the current maximum
item size.  All decisions are made online and require only simple accumulated
statistics.
"""
import numpy as np


class _Packer:
    __slots__ = ("total_size", "count", "max_item", "warmup")

    def __init__(self):
        self.total_size = 0
        self.count = 0
        self.max_item = 0
        self.warmup = 32


_state = _Packer()


def priority(item, bins):
    """Score bins: highest score wins, first bin wins ties.

    Parameters
    ----------
    item : int
        Size of arriving item, 1..100.
    bins : numpy.ndarray
        Remaining capacities of all fitting bins, in fixed bin order.

    Returns
    -------
    numpy.ndarray
        Scores, one per bin.
    """
    global _state

    item = int(item)
    b = np.asarray(bins, dtype=np.int64)

    # Update online statistics.
    _state.total_size += item
    _state.count += 1
    if item > _state.max_item:
        _state.max_item = item

    # Best-fit score: prefer bins with the smallest remaining capacity >= item.
    # Since all bins fit the item, this is simply -remaining_capacity.
    score = -b.astype(np.float64)

    # After warm-up, mildly discourage completely empty bins when we already
    # have enough total volume to fill at least one bin.  This avoids opening
    # new bins too eagerly without harming correctness for small instances.
    if _state.count >= _state.warmup:
        # Conservative lower bound estimate on bins needed so far.  The max-item
        # term accounts for the fact that no bin can contain more than
        # floor(100 / max_item) such items, which is a standard valid lower bound
        # contribution for item sizes bounded by max_item.
        lb_volume = _state.total_size / 100.0
        if _state.max_item > 0:
            lb_count = _state.count / float(max(1, 100 // _state.max_item))
        else:
            lb_count = 0.0
        lb = max(lb_volume, lb_count)

        # Number of unused bins currently visible (remaining capacity == 100).
        # If the lower bound is already at least as large as the number of
        # non-empty bins, opening another empty bin is likely wasteful.
        nonempty = np.count_nonzero(b < 100)
        if nonempty > 0 and lb >= nonempty:
            # Penalize empty bins relative to the tightest fitting non-empty bin.
            empty_mask = b == 100
            if np.any(empty_mask):
                score[empty_mask] -= 0.5 + 0.001 * _state.count

    return score
# EVOLVE-BLOCK-END
