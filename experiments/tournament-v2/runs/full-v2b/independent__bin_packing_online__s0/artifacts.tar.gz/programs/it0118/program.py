import numpy as np


def priority(item, bins):
    """Best fit with a tiny deterministic tie-break toward lower bin index via residual."""
    # Prefer the bin with the smallest remaining capacity that still fits, i.e.
    # smallest residual bins - item. This is exactly best fit.
    return -(bins - item)
