import numpy as np


def priority(item, bins):
    """Best-fit: put the item in the tightest-fitting bin.

    Lower remaining capacity after placement is better, so bins with remaining
    capacity closest to `item` get the highest score. Unused bins (capacity 100)
    are naturally ranked last for items < 100 due to the larger waste.
    """
    return -(bins - item)
