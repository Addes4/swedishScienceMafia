import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    Best-fit-like rule with a mild bonus for bins whose remaining capacity is
    small but not too small, encouraging compact packing without fully
    starving large future items.
    """
    remaining = bins - item
    # Base score: tighter fit is better (larger score for smaller remaining).
    score = -remaining.astype(np.float64)

    # Bonus for bins that are reasonably tight but still leave a little room,
    # so that large items can still be placed later.
    # A bin whose remaining after placement is small (<= ~10) is very good.
    score += 3.0 / (1.0 + remaining.astype(np.float64))

    # Slight preference against leaving bins almost empty (remaining near 100-item)
    # to avoid fragmenting fresh bins when tight fits exist.
    score += 0.5 * (100 - bins).astype(np.float64) / 100.0

    return score
