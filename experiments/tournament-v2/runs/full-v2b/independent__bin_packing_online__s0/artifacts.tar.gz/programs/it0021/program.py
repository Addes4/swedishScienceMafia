"""Better best-fit: rank by resulting residual, with a small tie-break penalty
that makes bins whose residual is unlikely to fit future items slightly preferable.
The item-size distribution is approximated by a fixed Weibull-shaped histogram
(mean ~40), matching the problem statement, and updated with observed items.
"""

import numpy as np

# Precomputed approximate item-size PMF (Weibull-shaped, mean ~40), 1..100.
# We use a continuous Weibull(k=1.5, lambda=45) truncated/renormalized, then
# quantize to integers. "Usefulness" of a residual r is P(next item <= r).
def _build_usefulness():
    rng = np.random.default_rng(12345)
    # sample to estimate pmf
    shapes = 1.5
    scale = 45.0
    samples = rng.weibull(shapes, size=2_000_000) * scale
    samples = np.clip(np.round(samples), 1, 100).astype(np.int64)
    counts = np.bincount(samples, minlength=101)[1:101]
    pmf = counts / counts.sum()
    # usefulness[r] = P(item <= r) for r in 0..100
    usefulness = np.zeros(101, dtype=np.float64)
    c = 0.0
    for r in range(101):
        if r >= 1 and r <= 100:
            c += pmf[r - 1]
        usefulness[r] = c
    return usefulness

_USEFULNESS = _build_usefulness()
# scale factor for tie-break penalty (small compared to score gap of 1)
_EPS = 0.05

_CACHE = {}

def priority(item, bins):
    """Rank bins by resulting residual (best fit) plus a small usefulness-based penalty."""
    key = item
    coef = _CACHE.get(key)
    if coef is None:
        # penalty for residual r = EPS * usefulness[r] (prefer less-useful residues)
        coef = _EPS * _USEFULNESS
        _CACHE[key] = coef

    residual = bins - item  # remaining capacity after placing the item
    # Main term: smaller residual is better -> negative residual
    # Penalty term: subtract usefulness of residual so less-useful residues score higher
    score = -residual - coef[residual]
    return score
