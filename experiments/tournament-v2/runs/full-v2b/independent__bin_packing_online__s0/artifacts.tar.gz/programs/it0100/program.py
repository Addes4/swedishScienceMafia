import numpy as np

# Global state to keep simple statistics from past items
_count = 0
_total = 0

def priority(item, bins):
    """
    Online bin-choice rule for online bin packing.

    Heuristic: prefer a bin where the item fits tightly (small remaining capacity
    after placement), i.e. best fit. To reduce fragmentation, add a mild reward
    for leaving bins with large residual capacity untouched and a penalty for
    nearly-full bins that can no longer accept typical future items.

    Bins are ordered by index; ties go to the first highest-scoring bin.
    """
    global _count, _total
    _count += 1
    _total += item
    mean_item = _total / _count

    rem = bins.astype(np.float64)

    # Base: best-fit (most negative residual after placement => smallest rem).
    # Priority is higher for smaller remaining capacity, but not absurdly so.
    base = -(rem - item)

    # Penalize bins that would become too full to fit a typical item. A bin
    # remains useful if rem-after >= typical_next (approx mean_item).
    # Smooth penalty: the more the post-placement residual drops below a
    # fraction of the average item, the less attractive the bin.
    post = rem - item
    typical = max(1.0, mean_item)

    # Fraction of a typical item that should remain available in the bin.
    # Keeping some slack helps future items land without opening new bins.
    desired = 0.35 * typical

    # Below 'desired', flatten by subtracting an increasingly negative term.
    # This discourages consuming the last bit of a bin too eagerly.
    shortage = np.maximum(0.0, desired - post)
    slant = -(shortage / typical) * 4.0

    # Slight preference for almost-empty bins over moderately-used ones can
    # help consolidate; but strongest signal stays best-fit.
    score = base + slant

    return score
