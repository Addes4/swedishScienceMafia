import numpy as np


def priority(item, bins):
    # Best fit: prefer bin whose remaining capacity is closest to item (tightest fit).
    # Add a small bonus to non-full bins that already contain items (capacity < 100),
    # to encourage consolidation and delay opening new bins.
    scores = -(bins - item)

    # Slight preference for used bins over completely empty bins.
    # Empty bins have remaining capacity 100.
    empty_mask = (bins == 100)
    scores = scores.astype(np.float64)
    scores[empty_mask] -= 0.5

    return scores
