import numpy as np


class _State:
    calls = 0
    # estimate of average item size from the Weibull-ish distribution, updated online
    mean_item = 40.0


_state = _State()


def priority(item, bins):
    """Score bins by a blend of best-fit and residual-avoidance.

    The item goes to the highest score (ties go to the first bin).
    """
    # Update running mean item estimate (for adaptive thresholds)
    _state.calls += 1
    n = _state.calls
    _state.mean_item += (item - _state.mean_item) / n

    residual = bins - item  # remaining capacity after placing item; >= 0 for shown bins

    # Best-fit component: prefer smaller residual (i.e. tighter fit)
    # Use a strong negative weighting so tighter fits rank higher.
    score = -residual.astype(np.float64)

    # Discourage leaving bins already lightly loaded sitting around as tiny residues.
    # If residual is small (< some fraction of item), that's ideal; if it's near the
    # original capacity (100 - item), it means placing into an empty-ish bin.
    # Slight bonus for not opening new bins when residual would be large.
    empty_like = (bins == 100)
    # Penalize using a perfectly empty bin unless the item doesn't fit well elsewhere.
    score -= 0.25 * empty_like

    # Encourage using bins that will end up with moderate fill, but not overly fragmented.
    # A small bonus for residual near half of item, which tends to create reusable spaces.
    target = item * 0.5
    score -= 0.01 * np.abs(residual - target)

    return score
