import numpy as np

_state = {}

def priority(item, bins):
    n = len(bins)
    if n == 0:
        return np.array([])

    # Score bins: prefer tighter fit (smaller residual), with a bonus for exact fit.
    residual = bins - item  # nonnegative by construction

    # Best fit base: smaller residual -> higher score
    score = -residual.astype(np.float64)

    # Strongly prefer exact fits
    score[residual == 0] += 50.0

    # Prefer bins that are fuller overall but avoid leaving tiny unusable gaps.
    # Slight preference for lower indices to close earlier bins when nearly tied.
    score += np.arange(n, dtype=np.float64) * 1e-6

    return score
