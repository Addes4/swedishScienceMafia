"""Online bin packing priority rule: best fit with empty-bin avoidance tie-breaking."""
import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin where the remaining capacity after placing the item is smallest.
    residual = bins - item

    # Penalize (very slightly) using an unused bin (remaining capacity 100).
    # This avoids opening a fresh bin when an equally tight fit already exists.
    # A tiny epsilon keeps the primary best-fit ordering intact.
    empty_penalty = np.where(bins == 100, 1e-6, 0.0)

    # Higher score wins, so negate residual; ties break toward the first bin.
    return -(residual + empty_penalty)
