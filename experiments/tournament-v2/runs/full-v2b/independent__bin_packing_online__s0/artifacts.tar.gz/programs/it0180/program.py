"""Adaptive best-fit with limited worsening for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority score per feasible bin; highest score wins (first on ties)."""
    # bins: remaining capacities of feasible bins (>= item), including empty bins (=100).
    # Best-fit score would be -(bins - item), i.e. maximize bins (tightest fit).
    # We add a tiny preference for bins that are already somewhat full but not too full,
    # and avoid completely empty bins unless necessary.
    rem = bins.astype(np.float64)

    # Base score: prefer tight fit strongly.
    score = -rem

    # Small bonus for bins that are fuller than average among feasible bins,
    # but not so large that it overrides fit quality.
    if rem.size:
        mean_rem = rem.mean()
        # Already-full bins get a small boost; empty bins get a small penalty.
        score += 0.02 * (mean_rem - rem) / 100.0

    # Slightly discourage opening brand-new bins when non-empty options exist,
    # to keep bin count down.
    score -= 0.001 * (rem >= 100.0)

    return score
