import numpy as np


def priority(item, bins):
    """Rank bins for online bin packing.

    Primary: exact fit is best.
    Secondary: after placing the item, if the leftover is smaller than the item,
    the bin is unlikely to fit another item soon; prefer such bins.
    Tertiary: best fit (smallest leftover).
    Also prefer already-used bins slightly over empty bins to delay opening new ones.
    """
    leftover = bins - item

    score = np.empty(bins.shape, dtype=np.float64)

    # exact fit gets huge bonus
    score[:] = 0.0
    score += (leftover == 0) * 1e6

    # prefer bins where leftover < item: these are "used up" more completely
    score += ((leftover > 0) & (leftover < item)) * 1e3

    # best fit: smaller leftover is better
    score += (100.0 - leftover) * 10.0

    # prefer non-empty bins over empty ones (remaining < 100 means used)
    score += (bins < 100) * 1.0

    return score
