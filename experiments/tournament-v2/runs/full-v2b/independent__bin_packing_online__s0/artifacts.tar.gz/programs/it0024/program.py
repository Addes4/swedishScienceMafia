import numpy as np

# State
hist = np.zeros(101, dtype=np.int64)
total_items = 0

def priority(item, bins):
    global hist, total_items
    # Update histogram
    hist[item] += 1
    total_items += 1
    
    # Compute threshold T
    if total_items < 20:
        T = 10
    else:
        # 20th percentile
        target = 0.2 * total_items
        cum = 0
        T = 100
        for v in range(1, 101):
            cum += hist[v]
            if cum >= target:
                T = v
                break
        # Cap T at 20
        if T > 20:
            T = 20
        # Ensure T at least 5
        if T < 5:
            T = 5
    
    # Compute scores for each bin
    scores = np.empty_like(bins, dtype=np.float64)
    for i, c in enumerate(bins):
        r = c - item
        if r == 0:
            scores[i] = 1e6
        elif r >= T:
            scores[i] = -float(r)
        else:
            scores[i] = -float(r) - 1e6
    
    return scores
