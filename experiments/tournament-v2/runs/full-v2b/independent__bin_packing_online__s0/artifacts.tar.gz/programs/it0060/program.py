import numpy as np

def priority(item, bins):
    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.int64)

    scores = np.zeros(n, dtype=np.float64)

    # For each bin, compute remaining capacity after placing the item
    remaining_after = bins - item

    if item > 50:
        # Large item: prefer bins that are already used (smaller remaining capacity)
        # but cannot fit another large item. Prefer tightest fit among non-empty bins.
        # Score: prefer non-empty bins; among them, tightest remaining.
        # Empty bins (cap == 100) should be lower priority.
        is_empty = (bins == 100)
        # Base: negative remaining capacity after placement (best fit)
        scores = -(remaining_after).astype(np.float64)
        # Penalize using empty bins for large items (save them for pairs of small items? Actually
        # large items need partners < 50, so using empty bin wastes space for other big items)
        scores[is_empty] -= 1000.0
        # Additionally, prefer bins where remaining_after < 50 so no more large items fit,
        # but small items can. If remaining_after >= 50, another large item could fit, which is bad.
        # So reward remaining_after < 50.
        scores += np.where(remaining_after < 50, 5.0, 0.0)
        # Strongly prefer exact fit
        scores += np.where(remaining_after == 0, 100.0, 0.0)
    else:
        # Small item (<=50)
        # Prefer exact fit, then tightest fit, but avoid consuming bins that are
        # nearly empty (cap near 100) because those are valuable for large items
        # that need a partner.
        # Best-fit score: negate remaining capacity after placement
        scores = -(remaining_after).astype(np.float64)
        # Penalize using bins with large remaining capacity (especially near 100)
        # because a small item can fit anywhere; save big spaces.
        # bins remaining capacity between 0 and 100.
        # Reward bins with capacity just enough (tight fit) already handled by -(remaining_after).
        # Additional penalty for using near-empty bins:
        scores -= (bins.astype(np.float64) / 100.0) * 20.0
        # Exact fit is very good
        scores += np.where(remaining_after == 0, 100.0, 0.0)
        # Prefer bins with remaining capacity such that after placing, the leftover
        # is small (already via best fit)
        # Also, if a bin has remaining capacity exactly item + something < 50 as partner
        # for a large item, maybe avoid. Hard to know future.

    # Tie-break: prefer lower index (bins appear in fixed order, argmax picks first)
    return scores
