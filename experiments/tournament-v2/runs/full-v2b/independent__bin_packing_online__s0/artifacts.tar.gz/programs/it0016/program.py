"""Online best-fit bin packing with a deterministic unused-bin tie-breaker."""
import numpy as np


def priority(item, bins):
    # Higher score is better.  Prefer bins where the item leaves the least
    # remaining capacity (best fit), but always open a new bin last.
    # `bins` contains remaining capacities, including unused bins at 100.
    tightness = -np.abs(bins - item)          # closest remaining capacity to item
    used = bins < 100                         # already-used bins get a bonus
    return tightness + used * 1e-6
