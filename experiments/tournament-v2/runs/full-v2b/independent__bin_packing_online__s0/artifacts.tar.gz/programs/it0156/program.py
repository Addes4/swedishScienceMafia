"""Adaptive best-fit with remainder quality bias for online bin packing."""

import numpy as np

# State kept across calls within an instance
_state = {
    "seen": 0,
    "hist": np.zeros(101, dtype=np.int64),
    "item_mean": 0.0,
    "mean_est": 0.0,
    "fit_count": 0,
    "alpha": 0.0,
}


def priority(item, bins):
    """Score bins: prefer tight fits, exact fits, and 'good' remainders.

    item: integer size 1..100
    bins: numpy int64 array of remaining capacities (only bins that fit)
    """
    bins = np.asarray(bins, dtype=np.int64)

    # --- update running statistics (cheap, once per item) ---
    st = _state
    st["seen"] += 1
    st["hist"][item] += 1
    n = st["seen"]
    # incremental mean estimate of item sizes
    st["mean_est"] += (item - st["mean_est"]) / n

    rem = bins - item  # leftover capacity after placing item

    # --- base: best fit (tightest fit preferred) ---
    # score ~ -rem, but we flatten it a bit so that differences in large
    # remainders matter less. Use a smooth monotone decreasing function.
    # A quadratic-like shaping keeps small remainders strongly preferred.
    base = -rem.astype(np.float64)

    # --- strong bonus for exact fits ---
    exact = (rem == 0).astype(np.float64)

    # --- "good remainder" bias ---
    # After placing, the leftover rem should ideally itself be packable.
    # Bins whose remainder is a multiple of common sizes, or equals a
    # typical item size, are more likely to be filled exactly later.
    # We reward remainders that are 0 (perfect) or near common item sizes.
    good = np.zeros_like(rem, dtype=np.float64)

    # Reward remainders that are exactly a likely future item size.
    # Use a soft target: multiples of 10 and common item values.
    targets = np.array([0, 10, 20, 25, 30, 33, 40, 50, 60, 67, 75, 80, 90, 100],
                       dtype=np.float64)
    d = np.abs(rem[:, None].astype(np.float64) - targets[None, :])
    good = np.exp(-(d ** 2) / (2.0 * 3.0 ** 2)).max(axis=1)

    # Penalize leaving very small, useless slivers (1..3) that can rarely
    # accommodate any item; also moderately penalize tiny leftovers.
    sliver = np.where((rem >= 1) & (rem <= 3), 1.0, 0.0)

    # Penalize leaving a remainder larger than a full bin minus something
    # (i.e., "wasting" a nearly-empty bin is fine; wasting a nearly-full
    # one is bad) -- best fit already handles this, but we sharpen it.

    # --- combine ---
    score = base + 5.0 * exact + 8.0 * good - 4.0 * sliver

    # Slight preference for earlier bins on ties is automatic (argmax first).
    return score
