"""Online bin packing heuristic: best fit with tie-breaking toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Score each bin; the item is placed in the highest-scoring bin.

    We primarily minimize leftover capacity after placement (best fit).
    Ties are broken by preferring bins that are already fuller, so we
    tend to pack bins more completely and leave the capacity-100 bins
    available for future items.
    """
    remaining = bins - item  # leftover capacity if placed here
    # Primary: smaller leftover is better -> negative leftover.
    # Secondary: prefer bins that are already more used (smaller bins value),
    # which is equivalent to larger (100 - bins). Scale secondary so it only
    # breaks ties of the primary term.
    score = -remaining * 1000.0 - bins
    return score
