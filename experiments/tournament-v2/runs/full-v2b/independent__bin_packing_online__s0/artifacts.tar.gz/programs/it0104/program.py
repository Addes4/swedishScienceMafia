import numpy as np


def priority(item, bins):
    # Fill bins as tightly as possible in general, but make use of small
    # differences in resulting leftover capacity to favor bins that are a bit
    # less "filled" among near-optimal choices. This acts as a light version of
    # best-fit-decreasing-like behavior without seeing future items.
    #
    # bins is an int64 array of remaining capacities. Score higher is better.
    #
    # Main term: prefer smaller resulting leftover (tight fit).
    # Secondary term: among equal-size items, slightly prefer larger bins
    # (more remaining after placement) to avoid wasting small bins early.
    # Empty bins (capacity 100) get no special treatment beyond that.
    leftover = bins - item

    # Negative leftover: best-fit.  Add a tiny positive bonus for larger bins
    # so that among near-equal tight fits we choose the larger remaining bin.
    # Scale is small enough not to override the primary fit ordering.
    return -leftover.astype(np.float64) + 1e-3 * bins
