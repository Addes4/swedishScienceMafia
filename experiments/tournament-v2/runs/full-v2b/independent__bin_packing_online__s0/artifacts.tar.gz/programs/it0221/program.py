import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin whose remaining capacity after placing is smallest.

    Score = -(bins - item), i.e. larger for tighter fits.
    A tiny bonus nudges toward bins that fill exactly to sizes unlikely to help
    future items (capacity left < item is useless for this item already; here we
    just deepen the best-fit preference for near-exact fills).
    """
    leftover = bins - item  # >= 0 since only fitting bins are shown
    # Best fit primary; slight preference for smaller leftover among near ties.
    return -(leftover * 1.0)
