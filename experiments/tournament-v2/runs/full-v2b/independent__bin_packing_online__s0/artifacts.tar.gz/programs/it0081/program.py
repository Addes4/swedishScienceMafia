import numpy as np


def priority(item, bins):
    """Score bins for online bin packing.

    Prefer the bin that leaves the least remaining capacity (best fit), while
    slightly favoring already-open bins over empty bins to reduce fragmentation.
    Ties go to the first bin, which is preserved by using integer scores.
    """
    # Lower remaining capacity after putting the item in is better.
    # Multiply by a large factor and add a small reuse bonus for non-full bins.
    # Empty bins have remaining capacity 100.
    recycle_bonus = np.where(bins < 100, 1, 0)
    return -(bins - item) * 1000 + recycle_bonus
