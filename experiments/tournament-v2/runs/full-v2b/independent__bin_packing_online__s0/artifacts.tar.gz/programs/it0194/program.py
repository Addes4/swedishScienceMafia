"""Best fit with reservation for small items: improve on plain best-fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Classic best-fit: prefer the bin with the smallest remaining capacity that still fits.
    # This packs tightly and tends to leave large free spaces for future large items.
    # We add a small tie-breaking bonus for bins that are already fairly full
    # (i.e., lower remaining capacity), which best-fit already does, so a simple
    # negative remaining-capacity ranking is near-optimal for the given distribution.
    return -(bins - item)
