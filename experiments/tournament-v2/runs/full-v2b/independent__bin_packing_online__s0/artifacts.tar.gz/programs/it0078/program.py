"""Online bin packing: best-fit with a residue-aware tie-breaking bias."""
import numpy as np

# State can be kept across calls if needed, but this rule is stateless.
# We use a deterministic scoring function based on remaining capacity and item size.
# The main term is best-fit: prefer the smallest bin that still fits.
# A secondary term mildly prefers leaving certain residual capacities, which
# empirically improves online performance for Weibull(mean~40) sizes.


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of bins that fit the item.
    """
    # bins contains only bins where item fits, so residual after placement is >= 0.
    residual = bins - item

    # Best-fit primary score: smaller residual is better.
    # Use a large negative coefficient so it dominates tie-breaking.
    score = -1000.0 * residual

    # Mild preference against leaving very small unusable gaps when possible.
    # For typical items around 40, residuals near 0 are ideal for best fit,
    # but residuals around 60--100 can preserve future flexibility.
    # The secondary term slightly rewards residuals in [40, 70] and [90, 100],
    # and slightly penalizes awkward small leftovers in (0, 20).
    r = residual.astype(np.float64)

    # Smooth bonus: prefer residuals that are not tiny positive leftovers.
    # Use a small positive bonus for residual == 0 and moderate residuals.
    bonus = np.zeros_like(r)
    bonus += 0.8 * np.exp(-((r - 0.0) ** 2) / 50.0)      # exact fit very good
    bonus += 0.3 * np.exp(-((r - 50.0) ** 2) / 400.0)    # balanced leftover
    bonus += 0.2 * np.exp(-((r - 95.0) ** 2) / 200.0)    # near-empty bin good

    # Mild penalty for tiny positive residuals (hard to reuse).
    tiny = (r > 0) & (r < 15)
    bonus -= 0.5 * tiny.astype(np.float64)

    score += bonus

    # Tie-break deterministically toward bins with larger remaining capacity
    # only when residuals are equal is already handled by first-index tie rule,
    # so no extra index term is needed.
    return score
