"""Adaptive Best/Worst Fit bin-choice rule for online bin packing."""
import numpy as np

_state = {
    "count": 0,
    "sum": 0.0,
    "small_count": 0,
}

# Common item granularity guidance: prefer leaving capacities that are "nice"
# relative to the mean item size, to reduce fragmentation.
def priority(item, bins):
    """Rank bins: small items -> tightest fit; large items -> emptiest bin."""
    # Update running statistics
    _state["count"] += 1
    _state["sum"] += item

    mean_item = _state["sum"] / _state["count"]

    # Threshold: items below this prefer best fit, above prefer worst fit
    threshold = mean_item

    if item < threshold:
        # Best fit: prefer smallest remaining capacity that still fits.
        # bins already contain only bins where item fits (capacity >= item).
        scores = -(bins.astype(np.float64) - item)
    else:
        # Worst fit: prefer largest remaining capacity (emptiest bin),
        # but avoid perfectly empty bins too eagerly for large items:
        # still prefer empty-ish bins.
        scores = bins.astype(np.float64)

        # Slight preference: penalize leaving a residual just below a multiple-ish
        # of the mean, to reduce creation of unusable fragments.
        residual = bins - item
        # Encourage residuals near 0 for near-full fills, and discourage tiny leftovers.
        scores -= 0.001 * np.abs(residual - mean_item)

    # Tie-breaking nudge: prefer bins whose remaining capacity after placement is
    # exactly an integer multiple-ish of the mean item size (fills cleanly).
    residual = bins - item
    scores += 0.0005 * (residual % max(1, int(round(mean_item))) == 0).astype(np.float64)

    return scores
