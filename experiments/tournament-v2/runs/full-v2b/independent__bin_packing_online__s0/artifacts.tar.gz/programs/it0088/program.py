"""Hybrid best-fit/worst-fit online bin packing with adaptive thresholding."""
import numpy as np


def priority(item, bins):
    # Prefer bins with remaining capacity close to item (best fit),
    # but if the closest fit wastes too much, mildly prefer emptier bins
    # to keep fragmentation low and preserve large free space.
    residual = bins - item
    # score: higher is better
    # Strongly prefer exact/near fits; penalize large leftovers; also
    # give a slight bonus to bins that are currently full-ish (small residual).
    score = -residual.astype(np.float64)
    # If the minimum residual is large (item fits poorly everywhere), prefer
    # emptier bins less: still best-fit dominates. The main behavior is best-fit.
    # Slight nudge against leaving a bin with residual just below 100 when
    # residual is very large (essentially opening a fresh bin).
    return score
