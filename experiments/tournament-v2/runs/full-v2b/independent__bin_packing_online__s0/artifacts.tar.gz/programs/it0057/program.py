import numpy as np

# Weibull-shaped item distribution, mean about 40.
# Use a fixed shape/scale heuristic; no file/network access.
# Precompute a reusable-residual penalty table once.

def _build_penalty_table():
    # Approximate common item sizes under a Weibull(shape ~1.5, scale ~45) distribution.
    # Penalize residual capacities that are likely to be needed as exact fits later.
    # The penalty is highest for residuals near common item sizes.
    penalty = np.zeros(101, dtype=np.float64)
    # Common item sizes roughly 5..95; peaks near 30-50.
    for r in range(1, 101):
        # A residual of r is reusable if many items have size <= r and are likely.
        # Penalize exact-match residuals strongly, especially medium ones.
        # Smooth penalty around 40.
        d = (r - 40.0) / 25.0
        penalty[r] = np.exp(-0.5 * d * d)
        # Also penalize residuals that are themselves common small/medium sizes.
        if 10 <= r <= 60:
            penalty[r] += 0.5
    return penalty

_PENALTY = _build_penalty_table()

def priority(item, bins):
    """Best fit with a small penalty for leaving highly reusable residuals."""
    bins = np.asarray(bins)
    # Primary: tighter fit is better -> higher score for smaller remaining capacity.
    # Use negative slack; slack = remaining - item.
    slack = bins - item
    score = -slack.astype(np.float64)
    # Bonus for leaving a residual that is less likely to be exactly needed later.
    residual = slack
    # Penalize residuals that are common future item sizes, but only mildly.
    # For very small residuals, reusing them is hard anyway, so small bonus.
    pen = np.zeros_like(score)
    valid = residual >= 0
    pen[valid] = _PENALTY[np.clip(residual[valid], 0, 100)]
    # Subtract penalty: prefer bins whose residual is not a common item size.
    # Scale small so best-fit remains dominant.
    score -= 0.15 * pen
    return score
