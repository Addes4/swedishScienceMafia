# EVOLVE-BLOCK-START
"""Best-fit with residual-aware adjustments to reduce fragmentation."""
import numpy as np

# Track global statistics to adapt thresholds
_state = {"count": 0, "sum": 0.0, "sq": 0.0}


def priority(item, bins):
    """Rank bins for the arriving item.

    Strategy: primarily best-fit (minimize residual after placement), but
    penalize placing into a bin that would leave a small unusable residual,
    and slightly prefer reusing already-used bins over brand-new ones.
    """
    remainder = bins - item  # residual capacity after placing item (>=0)

    # Base score: tightest fit -> smallest remainder = highest score.
    score = -remainder.astype(np.float64)

    # Penalty for leaving a residual that is too small to hold a "typical small"
    # future item but wastes space. A residual of 1..(small_thresh) is nearly
    # useless; a residual of 0 (exact fill) is great. We want to avoid creating
    # tiny residuals if a slightly larger residual bin is available.
    # Small threshold ~10: items smaller than this are rare in Weibull(mean 40).
    small_gap_penalty = np.where(
        (remainder > 0) & (remainder < 10),
        # the closer to 0 but nonzero, the worse the waste of a bin with a slot
        1.0 - remainder * 0.05,
        0.0,
    )
    score -= small_gap_penalty

    # Strong bonus for using a bin already partially filled (bins < 100) rather
    # than opening a fresh bin (bins == 100). This reduces bin count by packing
    # existing bins more fully before starting new ones.
    fresh = (bins == 100)
    score -= np.where(fresh, 0.5, 0.0)

    # Bonus for exact fill (nice, frees the bin perfectly).
    score += np.where(remainder == 0, 0.8, 0.0)

    return score
# EVOLVE-BLOCK-END
