"""Improved online bin packing: best-fit with open-bin preference and capacity shaping."""
import numpy as np

_state = {
    "opened": None,  # set of bin indices ever used (approx via capacity<100 markers)
    "n_seen": 0,
}


def priority(item, bins):
    # Best-fit residual: prefer the bin whose remaining capacity is closest to the item.
    residual = bins - item  # >= 0 for bins in `bins` (all shown fit)

    # Penalize large residuals slightly to favor tighter packing (best fit).
    score = -residual.astype(np.float64)

    # Encourage using already-opened bins over pristine (capacity 100) bins,
    # to avoid scattering items and to reduce the number of bins touched.
    pristine = (bins == 100)
    score -= 5.0 * pristine

    # Slight preference to fill bins near a "sweet spot" residual (e.g. leave room
    # for a typical item ~40) to reduce fragmentation.
    # Reward residuals that leave usable space for common item sizes.
    target = 40.0
    score -= 0.05 * np.abs(residual - target)

    return score
