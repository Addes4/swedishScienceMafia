import numpy as np


_UNUSED = np.int64(100)


def priority(item, bins):
    """
    Online bin packing priority rule.

    Strategy:
    - Strongly prefer bins where the item leaves a small but nonzero remainder.
    - Prefer unused bins only when no partially-filled bin is a decent fit.
    - Break ties by bin order via a tiny decreasing bonus.

    This is essentially best-fit with a small bias toward exact/near-exact fits
    and away from opening new bins.
    """
    # bins is a copy, but may be any int64 array.
    rem = bins

    # Best-fit: smaller remaining capacity after placement is better.
    # Since item is fixed, this is equivalent to preferring smaller current capacity.
    # We use negative remaining capacity as base score.
    base = -rem.astype(np.float64)

    # Bonus for exact fit (remainder 0 cannot happen for bins shown, because item fits,
    # so rem >= item; exact means rem == item).
    exact = (rem == item).astype(np.float64)

    # Bonus for leaving a small remainder, especially remainders that match common item sizes.
    # This encourages filling bins tightly.
    leftover = rem - item
    small_rem = 1.0 / (1.0 + leftover.astype(np.float64))

    # Penalize opening a fresh bin unless it is the only option or fits exactly.
    # Unused bins have remaining capacity 100.
    fresh_penalty = (rem == _UNUSED).astype(np.float64) * 2.0

    # Small index-order bonus so earlier bins win ties.
    # bins length varies, but this is stable per call.
    n = rem.shape[0]
    order_bonus = np.arange(n, dtype=np.float64)
    # The item goes to highest score, so earlier bins should have higher bonus.
    order_bonus = 1e-6 * (n - order_bonus)

    score = base + 8.0 * exact + 3.0 * small_rem - fresh_penalty + order_bonus

    return score
