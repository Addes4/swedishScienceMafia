import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.recent_fail = 0


_state = _State()


def priority(item, bins):
    """Best-fit with a mild penalty for empty bins, plus simple online state bias."""
    _state.calls += 1

    # bins are remaining capacities; item fits in all of them by construction
    rem = bins

    # Best-fit score: prefer the smallest remaining capacity that still fits item.
    # This minimizes leftover space after placement.
    score = -(rem - item).astype(np.float64)

    # Mild penalty for using unused bins (remaining capacity == 100), since opening
    # new bins increases total bin count. Only apply if some used bin also fits.
    # Detect used bins as those with remaining capacity < 100.
    used_mask = rem < 100
    if used_mask.any():
        # Penalize empty bins slightly. The penalty is small enough that if only
        # empty bins fit, they still win; otherwise used bins are strongly favored.
        score = score - 50.0 * (~used_mask)

    # Tiny deterministic tie-breaker favoring later lower-index bins is already
    # handled by first-on-ties, so leave scores as is.
    return score
