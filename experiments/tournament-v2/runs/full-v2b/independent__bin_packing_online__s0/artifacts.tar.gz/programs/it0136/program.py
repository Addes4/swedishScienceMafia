"""Online bin packing: adaptive best-fit with open-bin usage penalty."""
import numpy as np


class _State:
    total = 0
    count = 0
    seen = set()

_state = _State()


def priority(item, bins):
    # Track a light running statistic; unused by default but keeps interface flexible.
    _state.total += item
    _state.count += 1

    b = np.asarray(bins, dtype=np.int64)

    # Bins with remaining capacity 100 are considered "new/unused".
    unused = (b == 100)

    # Core: best fit -> prefer smallest remaining capacity that still fits.
    # score = -remaining_capacity
    score = -(b.astype(np.float64))

    # Slight preference for unused bins over used bins when the fit isn't much worse.
    # This helps avoid fragmenting partially-filled bins when opening a new bin is cheap.
    # Penalize used bins by a small amount proportional to item size.
    penalty = 0.02 * float(item)
    score = np.where(unused, score, score - penalty)

    # Optional smoothing: among open bins that fit, slightly prefer bins that are
    # not extremely full or extremely empty relative to the item, reducing pathological
    # fragmentation. This is a very mild, monotone adjustment around best-fit.
    # residual = b
    # We add a tiny quadratic term around residual == item (perfect fill) to strengthen best fit.
    residual = b.astype(np.float64)
    # For used bins only (residual < 100), reward closeness to item mildly.
    closeness = -np.abs(residual - float(item)) * 0.001
    score = score + np.where(unused, 0.0, closeness)

    return score
