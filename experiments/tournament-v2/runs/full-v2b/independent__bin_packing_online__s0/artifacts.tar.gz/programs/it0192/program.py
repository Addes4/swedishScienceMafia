import numpy as np


def priority(item, bins):
    """Best fit: highest score for the bin with the least remaining space after placing item."""
    return -(bins - item)
