"""Adaptive best-fit with residual-usefulness scoring for online bin packing.

Core idea: when choosing a bin, prefer the bin that (a) leaves the smallest
waste (classic best fit) but (b) leaves a residual that is likely to be
reusable by a *typical* future item. We learn the empirical distribution of
item sizes online (no peeking at the future) and use it to estimate how much
of a bin's leftover capacity is "dead" vs "reusable".

For a candidate bin with remaining capacity `r` after placing the item, the
leftover `r` can hold a future item of size s if s <= r. A leftover is more
valuable if it is close to a commonly observed size (so it can be filled
exactly) or small enough that it's cheap to give up. We score bins to balance
minimizing immediate waste against preserving fillable holes.
"""
import numpy as np


class _State:
    def __init__(self):
        # Histogram of observed item sizes (1..100).
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        # Cached normalized CDF-ish arrays.
        self._dirty = True
        # Precomputed "value of a leftover hole of size r".
        self._hole_value = None

    def observe(self, item):
        self.counts[item] += 1.0
        self.total += 1.0
        self._dirty = True

    def _rebuild(self):
        c = self.counts
        t = self.total if self.total > 0 else 1.0
        p = c / t  # probability of each size

        # Expected "usable fraction" of a hole of size r:
        #   we can place a future item of size s (s <= r) and continue; a hole
        #   is valuable if common items fit in it. We compute, for each r,
        #   V[r] = sum_{s<=r} p[s] * (s / r)  ... how tightly a single typical
        #   item can fill the hole, weighted by probability. A hole that no
        #   item can fill (r smaller than min observed size) is pure waste.
        cum_p = np.cumsum(p)  # cum_p[r] = P(size <= r)
        # weighted sum of s*p[s] up to r
        sw = np.cumsum(np.arange(101) * p)

        V = np.zeros(101, dtype=np.float64)
        for r in range(1, 101):
            mass = cum_p[r]
            if mass <= 0:
                V[r] = 0.0
                continue
            # average fill ratio achievable by a single item fitting in the hole
            avg_s = sw[r] / mass
            # fraction of the hole consumed by a typical fitting item
            V[r] = (avg_s / r) * mass  # mass weights feasibility

        # Normalize V to ~[0,1] scale by dividing by max.
        vmax = V.max()
        if vmax > 0:
            V = V / vmax
        self._hole_value = V
        self._dirty = False

    def hole_value(self, r):
        if self._dirty or self._hole_value is None:
            self._rebuild()
        if r <= 0:
            return 0.0
        if r > 100:
            r = 100
        return self._hole_value[r]


_state = _State()


def priority(item, bins):
    """Rank bins: best-fit base, penalized by low-value leftover holes."""
    _state.observe(item)

    bins = np.asarray(bins)

    # Remaining capacity after placing this item in each candidate bin.
    remaining = bins - item  # >= 0 for all shown bins

    # ---- Immediate waste: smaller remaining is better (classic best fit).
    # Normalize to a comparable scale.
    waste_score = -remaining.astype(np.float64)

    # ---- Leftover hole value: a hole that future items can fill well is
    # better to keep than a dead hole. We want to *consume* dead holes and
    # keep useful ones, so we slightly penalize leaving a worthless hole and
    # reward leaving a useful one. But primary objective is minimizing bins,
    # so weight modestly.
    hv = _state.hole_value
    hole_vals = np.array([hv(int(r)) for r in remaining], dtype=np.float64)

    # Reward keeping a *useful* hole (high hole_vals) and reward exactly
    # emptying a bin (remaining == 0 is ideal: perfect fill).
    exact_fill = (remaining == 0).astype(np.float64)

    # Score: tightest fit dominates; add small term valuing the leftover.
    # Weight chosen so best-fit ordering is only broken on near-ties where
    # the leftover quality clearly differs.
    score = waste_score + 0.35 * item * hole_vals + 3.0 * item * exact_fill

    return score
