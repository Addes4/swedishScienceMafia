"""Online bin packing: modified best fit with a preference against opening new bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin with the least remaining capacity after placing the item.
    residual = bins - item  # smaller residual => tighter fit => higher score
    # Prefer non-empty bins: penalize bins that are still completely unused (capacity 100).
    # This delays opening new bins and tends to reduce total bin count.
    empty_penalty = (bins == 100).astype(np.int64)
    return -(residual + empty_penalty * 1000)
