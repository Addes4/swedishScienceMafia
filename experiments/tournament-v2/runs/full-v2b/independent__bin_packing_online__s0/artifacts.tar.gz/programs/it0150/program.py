import numpy as np


def priority(item, bins):
    """Best fit with a dynamic threshold: prefer tightest fit but avoid leaving tiny waste."""
    # Remaining space after placing item
    rem = bins - item
    # Prefer smallest remaining space (tightest fit), but add a bonus for filling bins
    # near capacity to encourage closing bins; and a mild preference against using
    # completely empty bins when other fits exist (to consolidate).
    score = -rem.astype(np.float64)
    # Bonus for bins that become nearly full (rem small) — sharper than linear
    score += 5.0 / (rem + 1.0)
    # Slight bonus for using already-used bins (rem < 100-item) over empty ones
    # by preferring bins whose original remaining capacity < 100
    used = bins < 100
    score += 0.5 * used.astype(np.float64)
    return score
