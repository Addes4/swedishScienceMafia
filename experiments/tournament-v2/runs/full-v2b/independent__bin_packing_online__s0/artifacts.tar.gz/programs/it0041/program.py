import numpy as np


def priority(item, bins):
    # Score bins by how tightly the item fits, with a preference for partially-filled bins.
    # bins is int64 remaining capacity; item is 1..100.
    # Unused bins have capacity 100, so bins == 100 means empty.
    fit = bins - item  # smaller is better
    empty = (bins == 100)
    # Prefer non-empty bins slightly: add a small bonus when not empty.
    # Also prefer tighter fit strongly.
    score = -(fit.astype(np.float64))
    score += np.where(empty, 0.0, 1e-6)
    # Tie-break very slightly by lower remaining capacity (fuller bins first).
    score -= bins.astype(np.float64) * 1e-12
    return score
