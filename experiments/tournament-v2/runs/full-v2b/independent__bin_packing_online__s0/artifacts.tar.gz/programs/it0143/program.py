import numpy as np

# ---------------------------------------------------------------------------
# Online bin packing: bin-choice rule
#
# Strategy:
#   * Best-fit is a strong greedy baseline for random Weibull items.
#   * We enrich it with a small set of adaptive penalties/bonuses:
#       - Prefer the tightest fit (smallest leftover), but subtract a tiny
#         constant so that unused bins (capacity 100) are strictly last.
#       - Add a small bonus for leftovers that are "rare useful sizes" to keep
#         small gaps available, and a penalty for creating very large leftovers
#         in a nearly-empty bin when a tight fit exists.
#   * State kept across calls: simple running stats (counts) used to adapt the
#     rarity bonus.  No future information is used.
# ---------------------------------------------------------------------------

_STATE = {
    "n": 0,
    "leftover_hist": np.zeros(101, dtype=np.float64),  # leftover after placing
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (ties -> first)."""
    bins = np.asarray(bins, dtype=np.int64)
    cap = bins - item                       # leftover after placing item in this bin
    n = bins.size

    # Base: best fit (tighter = better).  Negate leftover.
    score = -cap.astype(np.float64)

    # Strongly demote unused bins (remaining == 100) unless needed:
    # unused bins are only useful when no partially-filled bin can take the item.
    unused = (bins == 100)
    # Unused bins should be used last, but also we want to pack them well.
    # Give a large negative constant to unused bins so any used bin wins.
    score[unused] -= 1e6

    # Rarity / slack shaping.
    # Leftover sizes that are commonly useful as exact fits for future items are
    # slightly more valuable to keep.  We estimate usefulness from a static
    # distribution shape (Weibull-like, mean ~40): small leftovers (<= item-like
    # sizes) tend to be handy; large leftovers in big gaps are less useful.
    #
    # Convert: prefer leaving a leftover that is itself a plausible item size.
    # Plausible item sizes cluster around 20..60 for mean 40.
    # We give a small bonus when leftover is in a "useful" band, and a small
    # penalty for leftover very close to 100 (wasted near-empty bin) or very
    # small but nonzero (a tiny unusable slot is slightly worse than perfect fit).
    legit = ~unused

    if legit.any():
        lc = cap[legit].astype(np.float64)
        bonus = np.zeros_like(lc)
        # Perfect fit: big bonus.
        bonus += np.where(lc == 0.0, 3.0, 0.0)
        # Leftover in a handy mid band: small bonus.
        bonus += np.where((lc >= 1.0) & (lc <= 60.0), 0.35, 0.0)
        # Leftover too tiny to ever be useful: slight penalty.
        bonus += np.where((lc >= 1.0) & (lc <= 3.0), -0.5, 0.0)
        # Leftover near full capacity (fresh-ish bin): penalty, preserve space.
        bonus += np.where(lc >= 85.0, -1.5, 0.0)
        score[legit] += bonus

        # Adaptive rarity: keep a mild bonus for leftovers that were rare so far
        # (so we don't over-create rare slot sizes), scaled very small.
        hist = _STATE["leftover_hist"]
        total = hist.sum()
        if total > 200.0:
            p = hist[cap[legit]] / total
            # rare leftover -> slightly higher bonus
            score[legit] += (1.0 - p) * 0.15

    # Update state (leftovers of the bin that would actually be chosen are not
    # known here in advance, so record all feasible leftovers lightly weighted).
    if n > 0:
        # record distribution of leftovers for used bins (bins < 100)
        used_mask = (bins < 100)
        if used_mask.any():
            lc = cap[used_mask]
            lc = lc[(lc >= 0) & (lc <= 100)]
            if lc.size:
                np.add.at(_STATE["leftover_hist"], lc, 1.0)
        _STATE["n"] += 1

    return score
