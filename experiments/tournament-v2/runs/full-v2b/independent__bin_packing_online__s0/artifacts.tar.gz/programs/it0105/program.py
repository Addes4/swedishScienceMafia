import numpy as np

# Weibull-shaped distribution with mean ~40. Most items are small (<40),
# but there is a tail of large items. Classic online bin packing wisdom:
#  - Best Fit (tightest remaining capacity) is strong.
#  - Keeping some bins nearly full is good, but reserving empty bins for
#    large items helps a lot.

SMALL = 40          # threshold below which an item is "small"
LARGE = 70          # threshold above which an item is "large"


def priority(item, bins):
    """Priority for each bin; highest score wins, ties go to first bin.

    Strategy: best fit with slight adjustments.
      * For every bin, prefer the bin whose residual after placement is smallest
        (classic Best Fit): score = -(bins - item) = item - bins.
      * For small items, add a penalty for using a completely empty bin
        (residual 100) so we don't open a fresh bin when a used one has room.
      * For large items, give empty bins a bonus, since they fit poorly elsewhere.
      * Encourage filling bins that are already fairly full (below a threshold).
    """
    residual = bins - item  # remaining capacity if item placed here (>= 0)

    # Base best-fit score: larger is better (smaller residual).
    score = -(residual.astype(np.float64))

    # Penalize placing small items in completely empty bins.
    if item <= SMALL:
        # residual == 100 means the bin was empty
        score = np.where(bins >= 100, score - 50.0, score)
    elif item >= LARGE:
        # Encourage using empty bins for large items
        score = np.where(bins >= 100, score + 5.0, score)

    # Slight preference for already-full bins (small residual) beyond best fit:
    # reward bins that become very tight, penalize leaving a lot of space.
    # This is already encoded in best fit, but we add a mild square term.
    score -= 0.002 * (residual.astype(np.float64) ** 2)

    return score
