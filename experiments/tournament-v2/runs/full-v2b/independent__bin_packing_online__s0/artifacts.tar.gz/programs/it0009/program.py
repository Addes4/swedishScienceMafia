# EVOLVE-BLOCK-START
"""Perturbed best fit: prefer tight fits, slightly discourage opening new bins."""
import numpy as np


def priority(item, bins):
    leftover = bins - item
    # Primary: prefer tight fit (smaller leftover).
    # Secondary: small bonus for using an already-nonempty bin (leftover < 100 - item),
    # i.e. a bin that isn't a fresh unused bin. This nudges toward reuse.
    fresh = (bins == 100).astype(np.float64)
    return -(leftover.astype(np.float64)) - 0.5 * fresh
# EVOLVE-BLOCK-END
