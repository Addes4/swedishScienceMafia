import numpy as np

def priority(item, bins):
    """Hybrid best-fit / worst-fit packing rule.

    Large items (>= 50) use best-fit to minimize wasted space.
    Small items (< 50) use worst-fit to keep bins empty enough for large items.
    """
    if item >= 50:
        # Best fit: prefer bin with smallest remaining capacity >= item
        return -(bins - item).astype(np.float64)
    else:
        # Worst fit: prefer bin with largest remaining capacity
        return bins.astype(np.float64)
