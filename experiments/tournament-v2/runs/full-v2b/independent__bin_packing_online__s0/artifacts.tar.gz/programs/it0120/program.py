import numpy as np

_STATE = {"calls": 0}

def priority(item, bins):
    _STATE["calls"] += 1
    remaining = bins - item

    # Best fit: minimize remaining capacity after placing the item.
    score = -remaining.astype(np.float64)

    # Slight preference for bins that are already used (remaining < 100),
    # to avoid opening new bins when the fit is nearly as good.
    used_bonus = np.where(bins < 100, 0.01, 0.0)

    return score + used_bonus
