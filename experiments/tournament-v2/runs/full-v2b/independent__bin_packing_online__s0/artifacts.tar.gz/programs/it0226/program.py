import numpy as np

class PackingRule:
    def __init__(self):
        # State for tracking item distribution and bin usage
        self.item_count = 0
        self.total_item_size = 0
        self.large_items = 0
        self.medium_items = 0
        self.small_items = 0
        # Track recent items to adapt threshold
        self.recent_items = []
        self.max_recent = 100
        
        # Adaptive threshold for "large" items
        self.large_threshold = 50
        # Threshold for considering a bin "full" when deciding to fill gaps
        self.gap_fill_threshold = 30

    def priority(self, item, bins):
        self.item_count += 1
        self.total_item_size += item
        
        # Update recent items
        self.recent_items.append(item)
        if len(self.recent_items) > self.max_recent:
            self.recent_items.pop(0)
        
        # Classify item size
        if item >= 60:
            self.large_items += 1
        elif item >= 30:
            self.medium_items += 1
        else:
            self.small_items += 1
        
        # Adaptive thresholds based on observed distribution
        # For Weibull with mean ~40, large items are relatively rare but important
        # Adjust gap_fill_threshold based on recent item sizes
        if len(self.recent_items) >= 20:
            recent_mean = sum(self.recent_items) / len(self.recent_items)
            # If recent items are smaller, we can afford to fill bins more aggressively
            self.gap_fill_threshold = int(25 + (recent_mean / 4))
            # Bound it
            self.gap_fill_threshold = max(15, min(50, self.gap_fill_threshold))
        
        n = len(bins)
        scores = np.zeros(n, dtype=np.float64)
        
        # For very large items, use pure best fit (tightest fit)
        if item >= 70:
            # Best fit: maximize -(bins - item), i.e., smallest remaining capacity after placement
            # But we want to prefer bins that are already somewhat full
            # Actually, best fit means minimize leftover: choose bin with smallest bins >= item
            # Score = bins (lower bins = tighter fit) -> higher score for smaller bins
            # But bins here are remaining capacities >= item
            scores = -bins.astype(np.float64)
            return scores
        
        # For medium items, prefer bins that leave a small but usable gap
        # or bins that are nearly full to consolidate
        if item >= 30:
            # Try to find bins that are nearly full (small remaining capacity)
            # but not so tight that we waste space
            # Use best fit primarily, but add bonus for bins that would become full
            remaining_after = bins - item
            # Best fit: smaller remaining_after is better
            # But we also want to avoid creating tiny unusable gaps
            # Score: prioritize bins where remaining_after is either very small (fill) or very large (preserve)
            scores = np.where(remaining_after < 15,
                              -remaining_after + 50,  # bonus for filling bins
                              -remaining_after)       # normal best fit
            return scores
        
        # For small items (item < 30), we can be more flexible
        # Strategy: try to fill existing bins that have small remaining capacity
        # to consolidate and free up bins for larger items
        remaining_after = bins - item
        
        # For small items, prefer bins that are nearly full (small remaining capacity)
        # to finish them off. But also avoid creating very small gaps.
        # If a bin would become full (remaining_after == 0), great.
        # If a bin has large remaining capacity, placing a small item there is fine too
        # but less optimal than finishing a nearly full bin.
        
        # Score: 
        # - Highly prefer bins where remaining_after is 0 (perfect fill)
        # - Prefer bins where remaining_after is small (finish them)
        # - Otherwise prefer best fit (tightest)
        
        # Use a sigmoid-like bonus for small remaining_after
        # Actually let's use a simpler approach:
        # Primary: minimize remaining_after (best fit)
        # Secondary: if remaining_after is 0, huge bonus
        
        scores = -remaining_after.astype(np.float64)
        
        # Add bonus for perfect fills
        perfect = (remaining_after == 0)
        scores[perfect] += 1000
        
        # Add bonus for bins that become very full (remaining_after small)
        very_full = (remaining_after > 0) & (remaining_after < 10)
        scores[very_full] += 100
        
        # If there are many bins with large remaining capacity, 
        # we might want to avoid using them for small items
        # to save them for larger items
        # Count bins with capacity > item + 30 (reserve for larger items)
        large_capacity_bins = (bins >= item + 30)
        if np.sum(large_capacity_bins) > 3:
            # Penalize using large capacity bins for small items
            scores[large_capacity_bins] -= 20
        
        return scores


# Global instance to maintain state across calls
_rule_instance = None

def priority(item, bins):
    global _rule_instance
    if _rule_instance is None:
        _rule_instance = PackingRule()
    return _rule_instance.priority(item, bins)
