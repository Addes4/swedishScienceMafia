import numpy as np


def priority(item, bins):
    """Best-fit: prefer the bin that leaves the least room after placing the item."""
    return -(bins - item)
