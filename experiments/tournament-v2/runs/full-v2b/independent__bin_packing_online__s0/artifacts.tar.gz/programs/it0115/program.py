"""Best-fit with mild empty-bin aversion for online bin packing.

Rule: prefer the bin whose residual capacity after placing `item` is smallest
(i.e. tightest fit).  Among equal residuals, prefer a bin that is already
partially used over a completely empty one, so empty bins stay available for
large future items.  This is a standard effective online heuristic for
randomly sized items.
"""
import numpy as np

_MAX_SEEN = 100


def priority(item, bins):
    global _MAX_SEEN

    # Track the largest item seen so far (defensive; distribution is fixed).
    if item > _MAX_SEEN:
        _MAX_SEEN = item

    residual = bins - item  # remaining capacity if item placed here (>=0)

    # Primary score: smaller residual is better (tighter fit) -> negate.
    score = -residual.astype(np.float64)

    # Secondary (tie-break) bonus: strongly prefer non-empty bins over empty
    # ones when residual is equal, keeping empty bins for large items.
    empty = (bins == 100)
    score -= empty.astype(np.float64) * 0.5

    # Tertiary tie-break keeps the order stable among identical cases.
    return score
