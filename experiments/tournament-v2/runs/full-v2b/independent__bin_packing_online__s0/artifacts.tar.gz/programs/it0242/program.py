import numpy as np

# Adaptive statistics across calls within an instance.
_state = {
    "n": 0,
    "hist": np.zeros(101, dtype=np.float64),  # item size histogram
    "res_hist": np.zeros(101, dtype=np.float64),  # residual after placing, historical
}

def priority(item, bins):
    st = _state

    # Update item size statistics (online).
    st["n"] += 1
    if item <= 100:
        st["hist"][item] += 1.0

    # Base: best fit -> prefer smallest residual after placement.
    residual = bins - item  # nonnegative since bins shown all fit

    # Fragmentation-aware adjustment:
    # Slightly prefer residuals that match frequently seen item sizes, since such
    # residual holes are more likely to be reusable. Weight is small so best fit dominates.
    n = st["n"]
    if n > 0:
        freq = st["hist"] / float(n)
    else:
        freq = st["hist"]

    # residual values are in [0, 100]
    match = freq[residual]

    # Also mildly penalize leaving very large residual in already-used bins
    # versus keeping large free bins available; best-fit residual already handles much.
    # Score: higher is better. Primary term: smaller residual.
    score = -residual.astype(np.float64) + 0.15 * match
    return score
