import numpy as np


def priority(item, bins):
    """Score bins by best fit, with a slight preference for non-empty bins."""
    remaining_after = bins - item
    # Strongest priority: smallest remaining capacity that still fits.
    best_fit_score = -remaining_after

    # Small bonus for already-used bins: avoid opening a new 100-capacity bin
    # unless another bin is a much better fit.
    used = bins < 100
    return best_fit_score.astype(np.float64) + 0.01 * used
