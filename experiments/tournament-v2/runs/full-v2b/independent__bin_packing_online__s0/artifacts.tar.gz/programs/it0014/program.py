"""Adaptive best-fit bin packing with residual-usefulness scoring.

The item must be placed immediately.  We score each candidate bin using a blend of:

  * best fit   : smaller residual after placement is preferred,
  * fit quality: prefer residuals that match common future item sizes,
  * avoid waste: penalise leaving residuals below the smallest typical item.

The scoring is computed vectorially with numpy so 5000 calls stay well within
the time limit.
"""
import numpy as np

# --- state kept between calls (allowed by the rules) -------------------------
_HIST = np.zeros(101, dtype=np.float64)      # histogram of observed item sizes
_COUNT = 0
_MEAN = 40.0


def _update_state(item):
    global _COUNT, _MEAN
    _HIST[item] += 1.0
    _COUNT += 1
    # running mean, cheap and robust
    _MEAN += (item - _MEAN) / _COUNT


# Precompute a smooth "usefulness" curve for residual capacities.
def _build_usefulness():
    # Sizes cluster around the mean (~40) with a Weibull-ish right tail.
    # We favour residuals close to likely future item sizes, i.e. mass near
    # the mean and below it, and we rise again for large residuals.
    caps = np.arange(101, dtype=np.float64)
    # Gaussian bump around the mean
    sigma = 18.0
    bump = np.exp(-((caps - 40.0) ** 2) / (2.0 * sigma * sigma))
    # large residuals are generally good (roomy bins absorb big items)
    linear = caps / 100.0
    return 0.6 * bump + 0.4 * linear


_USEFUL = _build_usefulness()


def priority(item, bins):
    """Return a score for every bin in `bins` (higher score wins)."""
    _update_state(item)

    # residual capacity after putting the item here
    residual = bins - item

    # --- best-fit component -------------------------------------------------
    # Smaller residual should be preferred, but not so aggressively that we
    # blindly fill tiny scraps.  Use a bounded inverse-ranges score.
    # Normalised 0..1: tighter fit -> larger score.
    tight = 1.0 - residual / 100.0

    # --- residual usefulness component --------------------------------------
    useful = _USEFUL[residual]

    # --- waste-avoidance: penalise leaving an unusable scrap ---------------
    # If residual is positive but smaller than the typical smallest item, it is
    # nearly dead space, so demote it slightly.
    small = residual < 10
    waste_pen = np.where(small & (residual > 0), 0.15 * (10 - residual) / 10.0, 0.0)

    # --- prefer slightly fuller bins overall (knapsack-ish) -----------------
    fullness = 1.0 - bins / 100.0

    score = 0.45 * tight + 0.35 * useful + 0.15 * fullness - waste_pen

    return score
