import numpy as np


class _State:
    def __init__(self):
        self.n_calls = 0
        self.n_items = 0
        self.sum_items = 0.0
        self.remaining_counts = np.zeros(101, dtype=np.int64)
        self.remaining_counts[100] = 1
        self.threshold = 86.0

    def observe_item(self, item):
        self.n_items += 1
        self.sum_items += item

    def observe_bin_chosen(self, before_capacity, after_capacity):
        self.remaining_counts[before_capacity] -= 1
        if self.remaining_counts[before_capacity] < 0:
            self.remaining_counts[before_capacity] = 0
        self.remaining_counts[after_capacity] += 1


_state = _State()


def _score_bin(item, cap, state):
    if cap == 100:
        if item == 100:
            return 1_000_000.0
        return -1_000_000.0 + item

    residual = cap - item

    if residual == 0:
        return 10_000_000.0

    fullness = 100 - cap

    if residual == 1:
        return 9_000_000.0 - fullness
    if residual == 2:
        return 8_000_000.0 - fullness
    if residual <= 4:
        return 7_000_000.0 - fullness * 2.0
    if residual <= 7:
        return 6_000_000.0 - fullness * 2.0
    if residual <= 12:
        return 5_000_000.0 - fullness * 3.0

    if fullness >= state.threshold:
        return 4_000_000.0 - residual
    if fullness >= 70:
        return 3_000_000.0 - residual * 2.0

    return 1_000_000.0 - residual * 10.0 - fullness


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.int64)
    n = bins.shape[0]
    state = _state

    state.n_calls += 1
    state.observe_item(item)

    scores = np.empty(n, dtype=np.float64)
    best_idx = 0
    best_score = -1e300

    threshold = state.threshold

    for i in range(n):
        cap = int(bins[i])
        s = _score_bin(item, cap, state)
        scores[i] = s
        if s > best_score:
            best_score = s
            best_idx = i

    if n > 0:
        chosen_cap = int(bins[best_idx])
        state.observe_bin_chosen(chosen_cap, chosen_cap - item)

    return scores
