"""Online bin packing: best-fit with shaped tie-breaking.

The rule ranks each usable bin by how tightly it would fit the item, with a
small extra bonus for bins that would become more completely full and a very
small deterministic index nudge so ties resolve consistently.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining_after = bins - item

    # Primary: best fit (smaller remaining capacity after placement is better).
    score = -remaining_after.astype(np.float64)

    # Shape: slight preference for bins that become nearly full (fill ratio).
    # This encourages packing tightly where it helps, without overriding best fit.
    fill = 1.0 - remaining_after / 100.0
    score += 0.05 * fill

    # Mild penalty for using a completely empty/unused bin (cap == 100),
    # to reduce needless bin openings when an existing bin fits.
    score -= 0.02 * (bins == 100)

    # Deterministic tiny tie-break toward earlier bin indices.
    n = bins.shape[0]
    score -= np.arange(n, dtype=np.float64) * 1e-9

    return score
