# EVOLVE-BLOCK-START
"""Adaptive best-fit with residual-usefulness tie-breaking for online bin packing."""
import numpy as np

# Light global state (allowed: may keep state between calls, never sees future items)
_state = {
    "n": 0,
    "sum": 0.0,
    "min_seen": 100,
    "max_seen": 1,
}


def _update_state(item):
    s = _state
    s["n"] += 1
    s["sum"] += float(item)
    if item < s["min_seen"]:
        s["min_seen"] = int(item)
    if item > s["max_seen"]:
        s["max_seen"] = int(item)


def priority(item, bins):
    """Rank bins by best-fit, with a small correction favoring useful residuals.

    Primary objective: place the item where it fits most tightly (minimize leftover).
    Secondary objective: avoid creating very small, likely-unusable leftovers,
    and prefer residuals that are likely to be matched by future items.
    """
    _update_state(item)

    # Resulting remaining capacity if the item is placed in each bin
    rem = bins - item  # bins guaranteed to fit item, so rem >= 0

    # Estimate typical future item size from history.
    s = _state
    if s["n"] > 1:
        mean_item = s["sum"] / s["n"]
    else:
        mean_item = 40.0

    # A plausible "small useful" residual threshold: future items vary, but
    # residuals below roughly min_seen are hard to reuse. We use a soft threshold.
    tiny = max(1.0, 0.5 * float(s["min_seen"]))
    # A residual close to the typical item size is especially attractive because
    # it can likely be paired with one future item.
    target = mean_item

    # Base score: strongly prefer tighter fit (larger rem means worse fit -> lower score)
    score = -(rem.astype(np.float64))

    # Correction: penalize very tiny leftovers (wasted space), reward residuals near target.
    # These are small refinements so they don't override clear best-fit decisions.
    tiny_pen = np.where(rem < tiny, -(tiny - rem) * 0.05, 0.0)
    near_target = -np.abs(rem - target) * 0.01
    exact = np.where(rem == 0, 0.02, 0.0)  # slight extra reward for perfectly full bin

    return score + tiny_pen + near_target + exact
# EVOLVE-BLOCK-END
