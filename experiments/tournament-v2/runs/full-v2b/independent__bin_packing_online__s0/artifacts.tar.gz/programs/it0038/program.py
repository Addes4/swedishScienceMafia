import numpy as np

# Global state: running histogram of observed item sizes.
_HIST = None
_TOTAL = 0
# Item sizes are 1..100; bucket by size directly.
_BUCKETS = 101


def _ensure():
    global _HIST
    if _HIST is None:
        _HIST = np.zeros(_BUCKETS, dtype=np.float64)


def priority(item, bins):
    _ensure()
    global _TOTAL

    # Update histogram with current item (before placement).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
    _TOTAL += 1

    # Estimate probability that a future item <= some value.
    # For a leftover capacity c, estimate the chance (or expected count) of future
    # items that fit exactly into c. Prefer bins whose leftover is close to
    # commonly occurring item sizes, but mainly do best-fit.
    #
    # A robust and strong greedy is best-fit (tightest fit). We add a mild
    # correction: among near-tight fits, prefer leftovers that equal or are just
    # below common item sizes, since those bins can still absorb a single
    # common item, reducing future bin openings.
    n = bins.shape[0]
    leftover = bins - item  # >= 0 for all fitting bins

    # Base: best fit -- smaller leftover is better.
    score = -(leftover.astype(np.float64))

    # Histogram-based desirability of a leftover value.
    # Compute, for each bin, an estimate of how many future items would fit
    # in the leftover (capacity-based utility), normalized.
    # util[c] = sum_{s<=c} hist[s] / total * something.
    # Since many bins may share leftover values, vectorize via lookup table.
    total = _TOTAL if _TOTAL > 0 else 1
    hist = _HIST
    # cumulative counts of items <= c
    csum = np.cumsum(hist)  # csum[c] = count of items with size <= c
    # probability a random future item fits in capacity c
    fit_prob = csum / total  # length 101

    # Expected number of future items (out of some horizon) fitting.
    # Use a fixed horizon H to scale.
    H = 50.0
    util_table = fit_prob * H  # indexed by capacity 0..100

    # Clamp leftover into [0,100]
    lc = np.clip(leftover, 0, 100).astype(np.int64)
    util = util_table[lc]

    # Penalize bins that would be "wasted": leftover too small to hold typical
    # small items is fine (best fit already tight). Mild positive weight.
    # Also mildly prefer leaving exactly capacity that matches a common size.
    w = 0.35
    score += w * util

    return score
