import numpy as np


def priority(item, bins):
    """Score bins to approximate an online best-fit with size-aware tie-breaking.

    The main objective is to use few bins, so we strongly prefer the tightest fit.
    A small correction makes bins whose remaining capacity after placement is a
    "useful" future size slightly less attractive than equally tight bins whose
    residual is awkward.
    """
    residual = bins - item
    # Strongly prefer smallest residual (best fit). Add a tiny deterministic
    # adjustment that penalizes leaving capacities that are uncommon/hard to fill.
    # For the Weibull-like distribution with mean ~40, very small leftovers and
    # exact zero are best; next-best are leftovers that match common small sizes.
    # Since exact common distribution is unknown, use a smooth preference for
    # residuals that are either zero or small.
    adjust = np.zeros_like(residual, dtype=np.float64)

    # Exact fill gets a substantial bonus.
    adjust[residual == 0] = 1000.0

    # Prefer leaving small but usable gaps over medium awkward gaps.
    # Bins with residual 1..20 are generally easier to fill than 21..60.
    small = (residual > 0) & (residual <= 20)
    adjust[small] += (21.0 - residual[small])

    medium = (residual > 20) & (residual <= 60)
    adjust[medium] -= (residual[medium] - 20) * 0.2

    # Primary key: smaller residual. Higher score wins.
    return -residual.astype(np.float64) * 100.0 + adjust
