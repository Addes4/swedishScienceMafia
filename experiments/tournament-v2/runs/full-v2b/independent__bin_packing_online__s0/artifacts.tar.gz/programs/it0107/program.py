import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
}


def priority(item, bins):
    global _state
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    # Best-fit primary score: prefer bins whose remaining capacity is just enough.
    # bins - item is the leftover after placing; smaller leftover is better.
    leftover = bins - item

    # Slight bias toward fuller bins (smaller remaining) to reduce fragmentation.
    score = -(leftover * 1000 + bins)

    # Tiny deterministic jitter based on item to break ties toward consistent choices.
    # Avoid randomness; keep ordering stable and cheap.
    score = score.astype(np.float64) + (item % 7) * 1e-6

    # If the item is large relative to typical sizes, prefer exact fits even more.
    if item >= mean_item:
        score += (bins == item) * 1e-3

    return score
