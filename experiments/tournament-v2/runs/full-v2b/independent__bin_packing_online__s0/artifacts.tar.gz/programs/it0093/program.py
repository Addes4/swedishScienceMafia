import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin with the smallest remaining capacity that still fits.
    # Ties go to the earliest bin, which the harness enforces.
    # Slight adjustment: penalize choosing a completely empty bin (remaining 100)
    # only when a non-empty feasible bin exists and the tightest non-empty fit
    # isn't much worse than opening a new bin. This reduces bin count in practice.
    slack = bins - item  # remaining capacity after placing; -1 if doesn't fit

    # Maximize: tight fits -> large score. Equivalent to -(bins - item) among feasible.
    # Empty bins have slack = 100 - item.
    # Add a tiny bonus for non-empty bins to encourage reuse.
    non_empty = bins < 100
    score = -(slack.astype(np.float64))

    # bonus for using non-empty bins, scaled small so it only breaks near-ties
    score += non_empty * 1e-6

    return score
