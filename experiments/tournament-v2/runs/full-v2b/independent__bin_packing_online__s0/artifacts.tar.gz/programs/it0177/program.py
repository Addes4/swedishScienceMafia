import numpy as np


def priority(item, bins):
    """Best-fit with a mild residual-size preference.

    The item must be placed immediately.  We rank bins only by how well they
    pack this item, but slightly favour non-empty bins and perfectly-fitting
    residuals so that new bins are opened only when genuinely needed.
    """
    residual = bins - item

    # Strong preference for exact fits, which are almost always optimal.
    exact = (residual == 0)

    # Among the remaining bins, prefer tighter fits (smaller residual), but
    # give a small advantage to bins that are already in use.  This avoids
    # opening brand-new bins when an existing bin can take the item well.
    score = -residual.astype(np.float64)

    # Penalise empty/new bins very slightly relative to used bins with the
    # same residual.  Since unused bins have capacity 100, their residual is
    # 100 - item; used bins with this residual are indistinguishable here, so
    # the penalty is encoded by the raw capacity as a tie-breaker.
    score -= (bins == 100) * 1e-6

    # Exact fits receive a large bonus.
    score += exact * 1e6

    return score
