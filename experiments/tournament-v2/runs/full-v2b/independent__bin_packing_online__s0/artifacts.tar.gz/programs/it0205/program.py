"""Online bin packing: best-fit with fragmentation-aware tie-breaking and future-fit bias."""
import numpy as np


# Distribution-aware constants (Weibull-shaped, mean ~40).
MEAN = 40.0


def priority(item, bins):
    """Score bins for placing `item`; higher score wins, ties go to earlier bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    b = bins.astype(np.float64)
    residual = b - item  # remaining capacity after placing the item, >= 0

    # 1) Strongly prefer tight fits (small residual).
    score = -residual

    # 2) Bonus for perfect fits (residual 0): don't waste a perfect match.
    score += np.where(residual == 0.0, 400.0, 0.0)

    # 3) Slight preference for partially-used bins over fresh ones, to avoid
    #    spawning many barely-used bins. Fresh bin iff remaining == 100.
    score += np.where(b < 100.0, 3.0, 0.0)

    # 4) Future-fit heuristic: prefer leaving a residual that is a "useful"
    #    size for future items. Residuals near the item size band (so future
    #    items can still exploit the bin) get a small nudge; very small
    #    non-zero residuals (fragments) are mildly penalized.
    frag = np.where((residual > 0.0) & (residual < MEAN * 0.5), -2.0, 0.0)
    score += frag

    return score
