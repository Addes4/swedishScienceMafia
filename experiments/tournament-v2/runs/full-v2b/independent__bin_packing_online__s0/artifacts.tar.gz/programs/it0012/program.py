import numpy as np

# State kept across calls (allowed by the problem statement).
_state = {
    "used": None,   # boolean array marking which bins have been used at least once
}


def priority(item, bins):
    """Score bins for best-fit packing with a small stateful refinement.

    Primary rule: prefer the bin with the smallest remaining capacity after placing
    the item (classic best fit).  Secondary: slightly prefer bins that are already
    in use and are nearly full, which tends to close partial bins sooner.  The
    index term is tiny and only breaks near-ties.
    """
    n = len(bins)
    if _state["used"] is None or len(_state["used"]) != n:
        # First call / array size grew: mark all currently full-ish bins as used.
        _state["used"] = bins < 100

    used = _state["used"]

    after = bins - item  # remaining capacity if placed here

    # Mark bins that become non-empty as used (they now contain this or prior items).
    used[:] |= (after < 100)

    # Main score: smaller remaining capacity is better.
    score = -after.astype(np.float64)

    # Small bonus for used bins that are close to full.
    # (after == 0 means perfect fill; used bins get a nudge.)
    score += 0.01 * (used & (after < 10))

    # Tiny deterministic index preference to stabilise ties / encourage order.
    score += -1e-9 * np.arange(n, dtype=np.float64)

    return score
