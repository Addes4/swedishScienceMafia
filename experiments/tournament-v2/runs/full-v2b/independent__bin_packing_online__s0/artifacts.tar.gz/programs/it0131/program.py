"""Online bin packing heuristic: adaptive best-fit with residual matching.

State: we keep a running estimate of the item-size distribution mean and
variance from previously seen items.  For each arriving item we score bins
by a discounted best-fit rule: strongly prefer bins whose remaining capacity
is close to the item size, but add a small bonus for leaving residuals near
the expected "slack" size.  This tends to pack small items into the gaps
created by large items and reduces total bins.

Uses only numpy and the standard library.
"""
import numpy as np

# Running statistics over items seen so far
_n = 0
_sum = 0.0
_sum2 = 0.0
# exponential moving average of item sizes (for recent-trend sensitivity)
_ema = 40.0
_alpha = 0.02

# initial guess: distribution mean ~40
_mean = 40.0
_std = 20.0


def priority(item, bins):
    global _n, _sum, _sum2, _ema, _mean, _std

    # --- update statistics with the arriving item ---
    _n += 1
    _sum += item
    _sum2 += item * item
    _ema = (1.0 - _alpha) * _ema + _alpha * item
    if _n >= 10:
        m = _sum / _n
        var = max(_sum2 / _n - m * m, 1.0)
        _mean = 0.7 * _mean + 0.3 * m
        _std = 0.7 * _std + 0.3 * var ** 0.5
    else:
        _mean = 0.5 * _mean + 0.5 * _ema

    rem = bins.astype(np.float64)

    # Best-fit core: negative residual after placing item.
    slack = rem - item  # >= 0 for all shown bins

    # Score:
    #  * primary term: minimize resulting slack -> maximize -slack
    #  * secondary term: reward residuals that are likely to be filled later.
    #    target residual ~ expected size of a future small item.
    target = min(max(_mean * 0.5, 5.0), 40.0)

    # quadratic penalty on deviation of resulting slack from target
    dev = slack - target
    score = -slack - 0.15 * (dev * dev) / (target + 1.0)

    # Slight preference for full bins (small slack) to close them out,
    # already captured above.  Add tiny tie-breaker on bin activity:
    # bins with rem==100 are empty; avoid opening new bins unless needed.
    score = score + (rem >= 100.0) * (-1e-6)

    return score
