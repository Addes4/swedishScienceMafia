import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.recent_sum = 0.0
        self.recent_count = 0
        self.recent = []
        self.mean = 40.0
        self.alpha = 0.15


_state = _State()


def priority(item, bins):
    """Best-fit with mild adaptive tie-breaking for online bin packing."""
    global _state

    # Maintain a smoothed estimate of the item-size distribution mean.
    _state.count += 1
    _state.recent.append(item)
    _state.recent_sum += item
    _state.recent_count += 1
    if _state.recent_count > 200:
        _state.recent_sum -= _state.recent.pop(0)
        _state.recent_count -= 1
    observed = _state.recent_sum / max(1, _state.recent_count)
    _state.mean = (1.0 - _state.alpha) * _state.mean + _state.alpha * observed

    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    b = bins.astype(np.float64, copy=False)

    # Primary score: best fit (smaller remaining capacity is better).
    # Penalize extremely empty bins slightly so that we tend to fill existing bins
    # when fits are comparable, but keep unused bins attractive when necessary.
    residual = b - float(item)
    score = -residual

    # Mild preference for bins that are neither almost empty nor almost full.
    # This helps avoid opening new bins too eagerly while retaining flexibility.
    used = 100.0 - b
    target = 0.55 * (100.0 - _state.mean)
    fullness_penalty = 0.002 * np.abs(used - target)

    # Stronger bonus for exact or very tight fits.
    tight = np.maximum(0.0, 2.0 - residual)
    score += 0.01 * tight

    # Slight bonus for partially used bins over untouched empty bins.
    empty_penalty = np.where(b >= 100.0, 0.003, 0.0)

    score -= fullness_penalty + empty_penalty

    return score
