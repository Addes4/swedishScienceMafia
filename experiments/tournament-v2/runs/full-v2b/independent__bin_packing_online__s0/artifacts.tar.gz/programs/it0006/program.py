import numpy as np


def priority(item, bins):
    # Best-fit primary, with slight bias against creating tiny unusable gaps.
    # bins contains remaining capacities of all bins; unused have 100.
    residual = bins - item  # remaining capacity after placing item here

    # Primary score: prefer smallest non-negative residual (tightest fit).
    score = -residual.astype(np.float64)

    # Add a tiny bonus for bins that would be exactly filled.
    exact = (residual == 0)
    score += exact * 1e-6

    # For large items, add a tiny, bounded preference for fuller bins so we
    # don't fragment capacity. This is scaled below the integer granularity.
    # (Strictly, integer residual ordering dominates, so this only breaks
    # among equal residuals, which is the desired safe behavior.)
    # Among equal residuals, prefer earlier bins slightly.
    idx = np.arange(score.shape[0], dtype=np.float64)
    score -= idx * 1e-9

    return score
