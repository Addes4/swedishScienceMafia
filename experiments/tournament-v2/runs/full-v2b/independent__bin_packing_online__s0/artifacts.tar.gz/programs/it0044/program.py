# EVOLVE-BLOCK-START
"""Online bin packing: tight best-fit priority with slight secondary preference for fuller bins."""
import numpy as np


def priority(item, bins):
    """Rank bins by tightest fit.

    The primary term is -(remaining capacity after this item), i.e. best fit.
    The secondary term slightly prefers bins that are already less empty when
    the post-placement gap is similar, which tends to reduce scattered medium
    gaps without requiring future items.
    """
    remaining_after = bins - item
    # Best fit: smaller remaining_after is better, so negative it.
    # Secondary: among near-equal fits, prefer bins with smaller remaining
    # capacity before placement (fuller bins), encoded with a small weight.
    return -(remaining_after.astype(np.float64) * 1024.0 + bins.astype(np.float64))
# EVOLVE-BLOCK-END
