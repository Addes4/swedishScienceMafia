import numpy as np


# Harmonic-style thresholds: place items near these boundaries into dedicated bins
# to avoid fragmenting large bins.
_THRESH = [
    100,  # items 100 -> own bin
    80,   # 80..99
    50,   # 50..79
    34,   # 34..49
    25,   # 25..33
    20,   # 20..24
    17,   # 17..19
    15,   # 15..16
    13,   # 13..14
    11,   # 11..12
    10,   # 10
    9,    # 9
    8,    # 8
    7,    # 7
    6,    # 6
    5,    # 5
    4,    # 4
    3,    # 3
    2,    # 2
    1,    # 1
]


def priority(item, bins):
    """Best-fit with harmonic reservation for small/medium items."""
    rem = bins - item

    # Estimate current "tightness" of each bin: how much would be left unused
    # if we place this item. Lower rem = better fit.
    score = -rem.astype(np.float64)

    if item >= 100:
        return score

    # Harmonic reservation: for items in [t/2, t), prefer bins in [0, t/2)
    # or otherwise avoid leaving a bin in a known "bad" residue range.
    for t in _THRESH:
        if t <= item:
            break
        lo = t // 2
        if lo < item:
            # item in [lo, t)
            # Prefer placing in a bin whose leftover is either 0 or at least lo
            # (so residue doesn't fall into (0, lo), wasting space).
            after = rem
            bad = (after > 0) & (after < lo)
            score -= bad.astype(np.float64) * (lo + 1.0)
            break

    # Slight preference for bins that already contain items (lower remaining
    # capacity than 100-item) to consolidate, and to keep full bins closed.
    used = bins < 100
    score += used.astype(np.float64) * 0.01

    return score
