import numpy as np


def priority(item, bins):
    """Best-fit priority with a mild preference against opening unused bins.

    The item goes to the highest score, ties to the first bin.
    For bins with the same leftover capacity relative to `item`, this ranks
    non-empty bins slightly above empty ones so that an existing bin is used
    whenever it can fit.
    """
    # Primary: minimize leftover space after placing the item.
    score = -(bins - item)

    # Secondary: avoid opening new bins when an existing bin fits.
    # Empty bins have remaining capacity exactly 100.
    score = score - (bins == 100) * 1e-6

    return score
