"""Online bin packing heuristic: best-fit with fill bias to reduce bin count."""
import numpy as np


def priority(item, bins):
    # bins: remaining capacities (int64), unused bins have 100.
    # Score: prefer tight fit, but avoid leaving tiny unusable gaps.
    # Larger score = better.
    rem = bins - item  # remaining capacity after placing item; >= 0 since bins pre-filtered to fitting
    # Base: tightest fit (smallest remaining after placement) -> -rem
    # Bias: strongly prefer bins that end up with small residual (better packing)
    # Also slightly prefer filling bins that already have small residual to close them.
    score = -(rem.astype(np.float64))
    # Penalize near-full-but-not-perfect residuals that waste space? 
    # Encourage placing into bins that become very full (rem small) - already covered.
    # Additional: unused bins (bins==100) should be last resort -> give them a large penalty
    unused_penalty = np.where(bins == 100, -50.0, 0.0)
    # Slight preference for bins with smaller current remaining (pack existing bins first)
    score += unused_penalty
    return score
