import numpy as np

_STATE = {
    "items": 0,
    "used_start": 0,
    "threshold": 102,  # set after seeing first item
}


def priority(item, bins):
    """Best-fit with a mild anti-new-bin bias and dynamic reserve threshold."""
    if _STATE["items"] == 0:
        # First call: choose a reserve threshold. Since mean item ~40, capacity 100,
        # a reserve around item+8 favors putting an item into an existing bin if
        # the resulting slack is not too much worse than opening a fresh bin.
        _STATE["threshold"] = min(100, item + 8)
        _STATE["used_start"] = np.count_nonzero(bins < 100)
    _STATE["items"] += 1

    # Need to identify unused bins: remaining capacity 100. But an actually empty
    # bin can also have 100 remaining; since harness includes all unused bins, any
    # bin with remaining capacity 100 is considered fresh/unused.
    is_unused = bins == 100

    # Score: largest remaining capacity that still fits, i.e. least leftover after
    # placement (best fit), with stronger preference for bins that are not unused.
    leftover = bins - item

    # Base best-fit score: smaller leftover is better. Shift so all scores <= 0.
    score = -leftover

    # Mild bias against opening brand-new bins when the item is small relative to
    # remaining capacity. This helps consolidate and reduces bin count.
    # A fresh bin has leftover = 100 - item; penalize choosing it unless clearly best.
    reserve = _STATE["threshold"]
    if reserve < 100:
        score = score - (leftover >= reserve) * 2

    # Stronger preference for already-used bins generally: subtract 1 from unused.
    # This is safe because if only unused bins remain, it just ties among them.
    score = score - is_unused.astype(np.int64)

    return score
