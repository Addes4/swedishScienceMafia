import numpy as np

# State kept across calls (allowed by the problem, never sees future items).
_call_count = 0

def priority(item, bins):
    global _call_count
    _call_count += 1

    # bins is an int64 numpy array of remaining capacities of fitting bins.
    rem = bins.astype(np.float64)
    leftover = rem - item  # >= 0 for all shown bins

    # Base: tightest fit => smallest leftover gets highest score.
    score = -leftover

    # Mild preference for bins that are already partially used (smaller remaining
    # capacity) so that empty bins (capacity 100) can be saved for future large items.
    # This bias grows with item size: large items benefit more from having room.
    score += -0.02 * rem

    # Extra discouragement for opening a brand-new (empty) bin, unless the item is
    # large and the fit is very tight.
    is_empty = (rem == 100.0)
    score += -0.5 * is_empty

    # For small items, avoid stuffing them into bins that are nearly full if a
    # slightly less full bin exists only marginally worse -- reduce fragmentation
    # by mildly rewarding moderate residuals using a concave term.
    score += 0.001 * (leftover * leftover) / 100.0

    return score
