import numpy as np
from collections import defaultdict

class _State:
    def __init__(self):
        # No heavy state needed for the final simple rule, but kept for compatibility/extensibility.
        pass

_state = _State()

def priority(item, bins):
    """Priority for online bin packing.

    Args:
        item: integer size 1..100
        bins: numpy int64 array with remaining capacity of bins the item fits in,
              including unused bins (capacity 100), in bin order.

    Returns:
        numpy array (or list) of scores; highest score wins, ties to first.
    """
    # Strategy: best fit, but avoid opening new bins unnecessarily.
    # For every bin that fits, prefer bins with the least remaining capacity
    # after placing the item, i.e. maximize (bins - item)?  Actually:
    # Best fit = minimize remaining capacity after place = minimize (bins - item).
    # We want the highest score, so score = -(bins - item) = item - bins.
    # The baseline already does this. To improve, we distinguish empty bins (100)
    # from partially-filled bins. Prefer a partially-filled bin over an empty bin
    # when both fit, even if the empty bin would be a better "fit" numerically.
    # This reduces bin count because it fills up bins before opening new ones.

    # Identify empty bins (remaining capacity == 100).
    empty_mask = (bins == 100)
    # Score based on tight fit: smaller remaining capacity is better.
    # We add a large bonus to non-empty bins to prefer them over empty bins.
    # Since scores are compared directly, we can add a constant to all non-empty,
    # but scale matters relative to differences in remaining capacity.
    # Remaining capacity ranges 0..99 (non-empty) and 100 (empty).
    # Best fit score is item - bins; higher is better.
    # Adding 200 to non-empty bins guarantees they beat empty bins
    # (since max difference between bins is 100 and item-bins varies by at most 99).
    scores = item - bins.astype(np.float64)

    # Bonus for non-empty bins: prefer not to use a fresh bin.
    scores += np.where(empty_mask, 0.0, 200.0)

    return scores
