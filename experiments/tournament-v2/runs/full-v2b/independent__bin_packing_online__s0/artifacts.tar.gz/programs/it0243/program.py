import numpy as np


def priority(item, bins):
    # Best-fit style rule: prefer the bin with the smallest remaining capacity
    # that can still hold the current item. Since the harness only passes bins
    # where the item fits, this is equivalent to preferring smaller residual
    # capacity. Return larger scores for tighter fits.
    return item - bins
