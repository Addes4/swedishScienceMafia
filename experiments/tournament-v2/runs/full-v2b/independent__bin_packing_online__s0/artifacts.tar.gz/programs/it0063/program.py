import numpy as np


class Solver:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.bins_used = 0

    def priority(self, item, bins):
        # Track observed item sizes
        self.n += 1
        self.sum += item
        mean = self.sum / self.n

        # Compare remaining capacity after placing item
        remaining = bins - item  # positive means fits (bins already filtered)
        # Score: prefer smaller remaining (best fit), but penalize leaving
        # leftovers too small to be useful for a typical future item.
        # Use a soft penalty based on the mean item size.
        threshold = max(1.0, mean * 0.5)

        # Base best-fit score: negative remaining (higher = tighter fit)
        score = -remaining.astype(np.float64)

        # Penalize bins that would leave a remainder below threshold
        # (since that space is likely wasted). This encourages opening
        # a fresh bin instead.
        small = remaining < threshold
        score[small] -= (threshold - remaining[small]) * 0.5

        return score


_solver = Solver()


def priority(item, bins):
    return _solver.priority(item, bins)
