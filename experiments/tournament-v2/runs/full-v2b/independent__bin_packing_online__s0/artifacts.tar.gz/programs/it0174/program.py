import numpy as np


def priority(item, bins):
    """Bin-choice rule: best fit with a slight preference for partially filled bins.

    The item goes in the bin with the highest score.  Ties go to the first bin,
    so scores are made just a little bit unequal where it helps.
    """
    b = np.asarray(bins, dtype=np.int64)

    # Best-fit score: smaller remaining capacity after placing is better.
    # Maximising this pushes the item into the tightest possible bin.
    score = item - b

    # Penalise using completely empty bins for small items.  Empty bins have
    # remaining capacity 100; keeping a few large bins untouched is often worth
    # more than exactly fitting a tiny item into one of them.
    empty = (b == 100)
    if item < 100:
        # The smaller the item, the stronger the penalty for opening an empty bin.
        score = score - (100 - item) * 8 * empty

    return score
