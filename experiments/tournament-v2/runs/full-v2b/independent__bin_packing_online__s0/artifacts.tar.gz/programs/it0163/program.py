"""Best-fit bin choice with a small bonus for exact fills/usable residuals.

Rule: place the item in the feasible bin that leaves the smallest remaining
capacity after the placement (classic Best Fit).  Among bins that leave the
same remainder, prefer those already more full (i.e. smaller residual) and
deterministic lower index; a tiny epsilon bonus marks remainders that are
either exactly full or large enough to seat another typical (~40-sized) item.
Best Fit is a strong, low-variance online rule for large items relative to
capacity, which is exactly this setting.
"""
import numpy as np


def priority(item, bins):
    # `bins` holds only bins the item fits in; remaining capacity after placing:
    rem = bins - item

    # Primary term: Best Fit -> minimize the post-placement remainder.
    # Weighting by 1.0 keeps this strictly dominant (integer remainders differ
    # by at least 1), so ordering is pure Best Fit.
    score = -rem.astype(np.float64)

    # Secondary, tie-only refinement (epsilon, cannot override a 1-unit gap):
    # reward leaving a remainder that is empty (0) or can host a mid-size item.
    usable = (rem == 0) | (rem >= 21)
    score += 1e-6 * usable

    # Tertiary, tie-only refinement: prefer bins already fuller (smaller raw
    # remaining capacity) to concentrate packing and keep empty bins available.
    score += 1e-9 * (-bins.astype(np.float64))

    return score
