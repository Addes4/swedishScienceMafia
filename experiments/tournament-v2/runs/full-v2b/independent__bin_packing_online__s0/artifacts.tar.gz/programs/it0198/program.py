import numpy as np


def priority(item, bins):
    """Score each bin for the arriving item.

    Primary criterion: best fit (minimize leftover capacity after placing item).
    To break ties among equally good fits, prefer bins that are *already* used
    (lower remaining capacity) so we keep packing existing bins rather than
    opening new ones. Unused bins have remaining capacity 100; among them, the
    first is chosen, which keeps bin indices dense.
    """
    leftover = bins - item  # >= 0 for all candidate bins
    # Lower leftover is better -> higher score. Use a large multiplier for the
    # primary key, and bins' current remaining capacity as a secondary key that
    # favours more-filled bins (smaller remaining capacity -> larger score).
    return -(leftover.astype(np.int64) * 1000) - bins.astype(np.int64)
