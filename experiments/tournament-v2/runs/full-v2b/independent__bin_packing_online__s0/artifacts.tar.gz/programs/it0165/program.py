import numpy as np


_CALL_COUNT = 0


def priority(item, bins):
    """
    Best-fit bin packing with a mild anti-waste correction.

    The item goes into the bin whose remaining capacity is closest to the item size,
    i.e. the tightest fitting bin.  Ties are broken by the original order, since we
    return higher scores for smaller residuals.

    A small bonus is added to bins that are not completely empty when the item is
    relatively small, which helps preserve empty bins for larger future items
    without materially changing the tight-fit behaviour.
    """
    global _CALL_COUNT
    _CALL_COUNT += 1

    # Best fit: residual after placing item. Smaller residual -> higher priority.
    residual = bins - item

    # Slight preference for already-used bins (small remaining capacity) when the
    # item is not huge.  This is encoded implicitly by the residual itself:
    # among bins that fit, the smallest residual is the fullest bin.
    #
    # Add a tiny deterministic tie-breaker favouring lower residual more strongly.
    # The scale is chosen to be much smaller than one capacity unit, so it only
    # affects exact ties and very close calls.
    score = -residual.astype(np.float64) * 1000.0

    # For moderately sized items, avoid opening a new bin if an existing bin has
    # a reasonably tight fit.  If the item is large, prefer tighter fits even more.
    if item >= 60:
        # Large items: strong best fit, keep gaps small.
        score -= (100 - bins).astype(np.float64) * 0.01
    elif item <= 25:
        # Small items: when possible, place them in non-empty bins to keep empty
        # bins available.  Empty bins have remaining=100, so penalise those
        # slightly relative to partially-full bins, but still allow them if no
        # used bin fits well.
        empty_mask = (bins == 100)
        score -= empty_mask.astype(np.float64) * 2.0
    else:
        # Medium items: very small preference for non-empty bins.
        empty_mask = (bins == 100)
        score -= empty_mask.astype(np.float64) * 0.5

    return score
