import numpy as np


def priority(item, bins):
    # bins: remaining capacities of all fitting bins (including empty ones = 100)
    # We choose a bin by best fit, but with two adjustments:
    # 1) an item that can exactly fill a bin is strongly preferred.
    # 2) among near-ties, prefer the bin that is already more filled
    #    (i.e. smaller remaining capacity after placement), to pack denser.
    remaining_after = bins - item  # >= 0 for all shown bins

    # Base: tightest fit -> smallest remaining_after
    score = -remaining_after.astype(np.float64)

    # Strong bonus for exact fill.
    exact = (remaining_after == 0)
    score += exact * 1000.0

    # Mild preference for fuller bins: encourages using already-started bins.
    # used_before = 100 - bins. Scale small to keep best-fit dominant.
    used_before = 100.0 - bins.astype(np.float64)
    score += used_before * 0.01

    return score
