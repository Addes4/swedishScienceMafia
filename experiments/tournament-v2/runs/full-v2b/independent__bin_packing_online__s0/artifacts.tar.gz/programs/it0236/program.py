import numpy as np


def priority(item, bins):
    """Improved online bin-choice rule.

    Main idea: choose the bin with the smallest resulting waste, but bias toward
    exact fits and avoid destroying almost-empty bins when the item is small.
    This is a deterministic, distribution-independent heuristic.
    """
    rem_after = bins - item

    # Waste after placing the item. Smaller waste is better.
    score = -rem_after.astype(np.float64)

    # Strongly prefer exact fits.
    score += (rem_after == 0) * 1000.0

    # For small items, do not consume a nearly empty bin unless necessary.
    # Reserving capacity-100 bins helps future large items.
    if item <= 20:
        score -= (bins >= 95) * 200.0
    elif item <= 40:
        score -= (bins >= 95) * 50.0

    # Mildly prefer bins whose remaining capacity is just above the item,
    # which tends to preserve larger gaps.
    score += (bins <= item + 5) * 5.0

    return score
