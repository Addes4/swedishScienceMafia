import numpy as np


def priority(item, bins):
    # Best fit: prefer smallest remaining capacity that still fits (bins - item smallest).
    # Slight preference to avoid leaving a gap < item that could be hard to reuse,
    # by giving a tiny bonus to bins where leftover remainder is 0 or large.
    leftover = bins - item  # >= 0 for all shown bins
    # Primary: fill tightly. score = -leftover.
    # Secondary tie-break: prefer leaving no remainder (exact fit).
    exact_bonus = (leftover == 0).astype(np.float64) * 1e-6
    return -leftover.astype(np.float64) + exact_bonus
