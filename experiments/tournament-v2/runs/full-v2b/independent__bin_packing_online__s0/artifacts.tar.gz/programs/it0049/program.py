import numpy as np

_state = {
    "last_bin": -1,
    "num_used": 0,
}


def priority(item, bins):
    # Base: best fit. Higher score = tighter fit.
    scores = -(bins - item).astype(np.float64)

    # Strongly prefer exact fits (remaining == item).
    exact = bins == item
    if exact.any():
        # Order exact-fit bins by bin order; add a tiny bias so earlier bins win ties.
        scores[exact] += 1e6

    # Slight preference for bins that are already partially used over fresh bins,
    # to avoid opening new bins when an existing one is nearly as good.
    # Remaining capacity 100 means unused.
    used = bins < 100
    scores[used] += 1e-3

    # Tie-break toward the most recently used bin to encourage consolidation.
    # This is a tiny epsilon, only affecting otherwise-equal scores.
    # We can't know actual bin indices beyond array position, so use position.
    return scores
