import numpy as np


def priority(item, bins):
    """Best-fit with deterministic tie behavior.

    Highest score goes to the bin leaving the smallest residual capacity.
    Ties are resolved by the harness to the earlier bin, which is fine.
    """
    return -(bins - item)
