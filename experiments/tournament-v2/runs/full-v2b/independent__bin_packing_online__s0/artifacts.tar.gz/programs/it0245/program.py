import numpy as np

# Precomputed empirical item-size distribution stats for a Weibull-shaped
# distribution with mean ~40 (typical of this problem family).
# We use a small histogram to estimate how likely a residual capacity is
# to be useful for future items.

def _build_hist():
    # Approximate Weibull(shape=2, scale=45): mean = 45*Gamma(1.5) ~ 39.9
    # Build a discrete pmf over sizes 1..100.
    shape = 2.0
    scale = 45.0
    # Sample many points deterministically and histogram
    xs = np.linspace(0.0001, 200.0, 200000)
    pdf = (shape / scale) * (xs / scale) ** (shape - 1.0) * np.exp(-(xs / scale) ** shape)
    # Discretize to integers 1..100
    pmf = np.zeros(101, dtype=np.float64)
    idx = np.clip(np.floor(xs + 0.5).astype(np.int64), 1, 100)
    np.add.at(pmf, idx, pdf)
    pmf = pmf / pmf.sum()
    return pmf


_PMF = _build_hist()
# cumulative probability that a random item is <= c
_CDF = np.cumsum(_PMF)  # _CDF[c] = P(item <= c)


def priority(item, bins):
    """Rank bins for an arriving item.

    Primary: best-fit (tightest remaining capacity).
    Tie-break: prefer a residual capacity that is a good "fit" for future
    typical items (small residual may be useless; too-large residual wastes).
    """
    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item  # remaining capacity after placing item here

    # Best-fit score: smaller residual is better -> negative residual
    score = -residual.astype(np.float64)

    # Value of the residual bin: probability that a typical future item fits
    # into the leftover capacity, tempered so we don't over-prefer big leftovers.
    # residual clamped to [0,100]
    r = np.clip(residual, 0, 100)
    value = _CDF[r]

    # Small weight so best-fit dominates but ties are broken by usefulness.
    score = score + 0.001 * value

    return score
