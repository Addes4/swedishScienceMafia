import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.sum = 0.0
        self.sq = 0.0
        self.small = 0
        self.big = 0


_S = _State()


def priority(item, bins):
    # Update simple statistics (unused for now, but kept for potential adaptive behavior)
    _S.count += 1
    _S.sum += item
    _S.sq += item * item
    if item <= 10:
        _S.small += 1
    if item >= 80:
        _S.big += 1

    # Best fit: score is negative leftover capacity after placing the item.
    # Add a tiny preference for tighter bins to enforce best fit.
    residual = bins - item
    # Primary: minimize residual. Use negative residual.
    # Secondary: slight tie-break by smaller bin index (natural order), so no extra term needed.
    return -residual
