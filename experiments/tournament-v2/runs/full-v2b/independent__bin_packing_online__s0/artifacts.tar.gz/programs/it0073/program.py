import numpy as np

_hist = None
_total = 0


def priority(item, bins):
    global _hist, _total
    # Lightweight running statistics (kept for possible adaptation; rule below is robust).
    if _hist is None:
        _hist = np.zeros(101, dtype=np.float64)
    _hist[item] += 1
    _total += 1

    # Best-fit primary score: tighter packing is good.
    tight = item - bins  # same ordering as -(bins - item); larger = bin is tighter

    # Discourage creating tiny unusable residues (1..4) that waste almost a full bin's slot.
    # Penalize residues that are small but not zero, because they rarely accept future items.
    resid = bins - item
    small_waste = ((resid >= 1) & (resid <= 4)).astype(np.int64)
    # Slightly favor exact fits and near-exact fits, and mildly favor larger residues over tiny waste.
    # The tiny bonus to zero residue helps hit exact packing when available.
    exact_bonus = (resid == 0).astype(np.float64) * 0.75
    near_bonus = ((resid >= 5) & (resid <= 12)).astype(np.float64) * 0.15

    # Prefer bins with larger remaining capacity when otherwise similar, but only very mildly,
    # to keep big bins available without abandoning best fit.
    breadth = bins.astype(np.float64) * 0.002

    score = tight.astype(np.float64) - small_waste * 0.9 + exact_bonus + near_bonus + breadth
    return score
