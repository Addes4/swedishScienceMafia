import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a tiny penalty for opening a brand-new bin."""
    residual = bins - item
    # Prefer the bin that leaves the least residual capacity (best fit).
    # Break near-ties in favor of bins that are already partially used,
    # to slightly discourage opening fresh bins when an existing bin is close.
    fresh_penalty = (bins == 100).astype(np.int64)
    return -residual * 1024 - fresh_penalty
