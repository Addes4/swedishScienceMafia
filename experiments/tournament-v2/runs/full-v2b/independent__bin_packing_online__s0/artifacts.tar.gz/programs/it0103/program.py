import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.total = 0.0

    def update(self, item):
        self.count += 1
        self.total += float(item)

    @property
    def mean(self):
        if self.count == 0:
            return 40.0
        return self.total / self.count


_state = _State()


def priority(item, bins):
    _state.update(item)

    # bins are remaining capacities. Smallest resulting remaining capacity is best fit.
    remaining_after = bins - item

    # Base score: negative remaining capacity => tighter fit has higher score.
    score = -remaining_after.astype(np.float64)

    # Slight bonus for using existing non-empty bins (remaining < 100) to reduce new bin usage.
    # This is especially helpful when many bins are nearly full.
    used = bins < 100
    score += used * 0.5

    # Small preference to exact fits / bins that become fuller, independent of index,
    # while tie-breaking gently toward earlier bins.
    # A tiny increasing penalty by index makes lower indices win ties.
    n = len(bins)
    if n:
        idx = np.arange(n, dtype=np.float64)
        score -= idx * 1e-6

    # When the running mean is larger, exact filling matters a bit more; scale the best-fit term.
    m = _state.mean
    if m > 50.0:
        # Favor bins that are used and tight even more slightly.
        score += used * 0.25

    return score
