import numpy as np


class _State:
    def __init__(self):
        # Online estimate of item size distribution (1..100)
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        # histogram-based residual "usefulness" prior
        self._cache = None
        self._cache_total = -1.0


_STATE = _State()


def _update_state(item):
    _STATE.counts[item] += 1.0
    _STATE.total += 1.0
    if _STATE.total % 64 == 0 or _STATE._cache is None:
        _STATE._cache = None


def _usefulness():
    """Return array u[r] = estimated probability that a residual r is 'useful'
    (i.e. close to a future item size). r in 0..100. Higher is better.
    """
    if _STATE._cache is not None and _STATE._cache_total == _STATE.total:
        return _STATE._cache

    counts = _STATE.counts
    total = _STATE.total

    if total < 20.0:
        # Unknown regime: mildly prefer residuals that are typical sizes near mean 40.
        r = np.arange(101)
        # Gaussian-ish prior centered ~40 with std ~20
        u = np.exp(-0.5 * ((r - 40.0) / 20.0) ** 2)
        u[0] = 1.0  # perfectly full bin is great
        _STATE._cache = u
        _STATE._cache_total = total
        return u

    prob = counts / total  # prob[s] = P(next item size = s)
    r = np.arange(101)
    # u[r] = sum_s prob[s] * P_place(item s into residual r) = prob[r]  (if r==s exactly)
    # But partial fits matter too: residual r is useful if some likely item <= r consumes it well.
    # Use prob[r] plus small contribution from items slightly smaller than r.
    u = prob.copy()
    # add smoothing: an item of size s leaves residual; a residual r helps if r itself is a
    # common size, or if a common size divides near r. Encourage exact matches strongly.
    # Slight smoothing with neighbors to be robust.
    sm = prob.copy()
    for d in (1, 2, 3):
        sm[d:] += 0.25 * prob[:-d]
        sm[:-d] += 0.25 * prob[d:]
    u = sm
    u[0] = max(u[0], 1.0)  # filling a bin completely is always excellent
    # Normalize to reasonable scale
    m = u.max()
    if m > 0:
        u = u / m
    _STATE._cache = u
    _STATE._cache_total = total
    return u


def priority(item, bins):
    """Best fit with a residual-usefulness tiebreak.

    Primary: tightest fit => smallest residual (= bins - item). This minimizes wasted space.
    Tiebreak: prefer residuals that are likely to be reusable by future items (and exact fill).
    A small penalty is applied to tiny unusable residuals.
    """
    _update_state(item)

    # bins: remaining capacities of bins the item fits in (all >= item)
    residual = bins - item  # >= 0

    u = _usefulness()  # u[r] in ~[0,1], high = useful residual

    # Primary tightest-fit term dominates; secondary usefulness breaks ties/slight differences.
    # score = -residual + weight * usefulness(residual)
    # weight small so it only nudges within tight-fit clusters but helps escape bad small gaps.
    weight = 3.0

    # Tiny residuals (1..4) are often dead space unless they're exactly a likely size.
    # usefulness already captures this, but add explicit mild penalty for very small residuals
    # when they are not zero and not a likely size.
    tiny_pen = np.zeros_like(residual, dtype=np.float64)
    mask_small = (residual > 0) & (residual < 6)
    if mask_small.any():
        tiny_pen[mask_small] = 1.0

    scores = -(residual.astype(np.float64)) + weight * u[residual] - tiny_pen

    # Strongly reward perfectly filled bins (residual 0)
    perfect = (residual == 0)
    if perfect.any():
        scores[perfect] += 5.0

    return scores
