import numpy as np

# Online bin packing heuristic:
# best-fit with a small correction that avoids wasting perfectly matching
# residual capacity when the arriving item is small relative to typical items.

# We do not know the exact distribution, but mean item size is about 40.
# The main score is best-fit (smallest residual).  A tiny tie-break-like
# correction helps in some regimes without hurting too much elsewhere.

# State kept across calls: counts of past item sizes are not needed.
# The bin array order is fixed, so ties naturally go to earlier bins.

# Tuned constants (kept deliberately simple and robust):
# Prefer bins with residual close to 0, but slightly prefer residuals that
# are more likely to be filled later.  For item size s, residual r = b - s.
# We score by -r + alpha * f(r), where f is a mild bonus for useful residuals.
# In practice the plain best-fit is strong; this correction is small.

# To stay fast, compute vectorized.

def priority(item, bins):
    # Residual capacity after placing the item.
    rem = bins - item

    # Best-fit primary term: smaller residual -> higher score.
    score = -rem.astype(np.float64)

    # Mild avoidance of leaving capacities that are extremely unlikely to be
    # reused by future items of mean ~40.  For example, residual 1..3 is often
    # useless; residual around 0 is perfect; large residual is flexible.
    # We add a small bonus for perfect fit and for residuals near common item
    # sizes, and a tiny penalty for tiny nonzero residuals.

    # Perfect fit bonus (residual == 0) is already maximal under -rem, but
    # adding a small extra helps break ties robustly.
    score += (rem == 0) * 1e-3

    # Tiny penalty for residuals in [1, 5]: these are typically hard to fill.
    small = (rem >= 1) & (rem <= 5)
    score -= small * 0.05

    # Tiny bonus for residuals that are themselves plausible future item sizes
    # (roughly 1..100).  This is intentionally weak.
    # Since all residuals are in 0..100, just a mild preference for larger
    # residuals among otherwise equal primary scores is already handled by -rem.
    # No further adjustment needed.

    return score
