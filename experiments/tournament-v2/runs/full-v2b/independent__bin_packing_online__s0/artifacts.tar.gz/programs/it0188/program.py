import numpy as np


def priority(item, bins):
    """Rank bins with a tuned best-fit variant.

    The item goes to the bin where it fits most tightly, but exact-fit and
    near-exact-fit placements receive a small bonus because they preserve
    larger residual capacities that are harder to use later.
    """
    residual = bins - item

    # Base best-fit ranking: smaller residual is better.
    score = -residual.astype(np.float64)

    # Strong bonus for exact fits.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Mild bonus for very tight fits, as they tend to create fewer problems
    # with future items while still packing densely.
    score += np.where((residual > 0) & (residual <= 5), 10.0 - residual * 0.5, 0.0)

    # Slight preference against leaving medium residuals that may be hard to
    # combine with future small items.
    score -= np.where((residual >= 15) & (residual <= 40), (residual - 15) * 0.05, 0.0)

    return score
