"""Best-fit bin packing with a stable tie-break favoring fuller existing bins."""

import numpy as np


def priority(item, bins):
    """Score bins by tightest fit, with a small bonus for older/fuller bins on ties.

    The item is placed into the bin whose remaining capacity is closest to the item size
    while still fitting. When multiple bins have the same remaining capacity, prefer the
    one earlier in the bin order, which tends to correspond to an older, more-filled bin.
    """
    remaining_after = bins - item

    # Primary: smaller remaining capacity after placing the item is better.
    # Secondary: earlier bins (smaller index) get a tiny bonus to break exact ties.
    n = bins.shape[0]
    # Use a small fraction of the item size as tie-break, negligible against integer
    # differences in remaining capacity but enough to favor earlier bins.
    tie_break = (n - np.arange(n, dtype=np.int64)) * 1e-9

    return -remaining_after + tie_break
