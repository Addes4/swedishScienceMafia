"""Best-fit with fragmentation-aware biasing for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = np.asarray(bins, dtype=np.float64)

    # Best-fit base: prefer the tightest fitting bin (smallest remaining capacity).
    tightness = -(b - item)

    # Bias toward fuller bins (smaller remaining capacity) to avoid fragmentation
    # and to delay opening new bins.
    fullness_bias = -0.05 * b

    # Penalize putting items into nearly-empty (unused) bins unless necessary:
    # a fresh bin (capacity 100) gets an extra small penalty so that if any
    # existing bin fits reasonably, it is preferred. The penalty grows with the
    # emptiness of the bin relative to the item, discouraging wasteful openings.
    empty_penalty = -0.10 * np.maximum(b - item, 0.0)

    return tightness + fullness_bias + empty_penalty
