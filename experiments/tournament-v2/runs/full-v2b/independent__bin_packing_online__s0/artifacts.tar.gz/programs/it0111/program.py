import numpy as np


class _State:
    def __init__(self):
        self.calls = 0


_state = _State()


def priority(item, bins):
    """
    Online bin packing priority.

    The item is placed into the bin with the highest score.
    Bins are shown in fixed index order, and unused bins have remaining capacity 100.

    Strategy:
    - Strongly prefer reusing non-empty bins before opening a new bin.
    - Among fitting non-empty bins, choose the tightest fit (best fit).
    - Add a very small tie-breaker based on remaining capacity to slightly favor
      bins that leave a larger residual after placement, reducing fragmentation.
    """
    _state.calls += 1

    # Bins with capacity 100 are unused. Penalize them so empty bins are opened
    # only when the item cannot be placed in any existing partially filled bin.
    unused_penalty = -1000000.0

    # For non-empty bins, best fit minimizes residual capacity after placement.
    # Since higher score wins, score = -(residual_after_placement).
    residual_after = bins - item

    scores = -residual_after.astype(np.float64)

    # Very small secondary preference: if several bins have the same resulting
    # residual, prefer one with a slightly larger residual to keep small slots open.
    scores += 0.000001 * bins.astype(np.float64)

    # Penalize completely unused bins so they sort last.
    scores = np.where(bins == 100, unused_penalty + bins.astype(np.float64) * 0.000001, scores)

    return scores
