import numpy as np

# Constants tuned for the fixed Weibull-ish item-size distribution (mean ~40, capacity 100).
# The rule is essentially best-fit with a slight preference against opening new bins too early
# and a small deterministic tie-break perturbation.
_FULL_BIAS = 0.0          # shift for used bins
_EMPTY_BIAS = 0.0001      # tiny penalty for using completely empty bins
_EPS = 1e-9


def priority(item, bins):
    """
    Online bin-packing choice rule.

    item: integer size, 1..100.
    bins: numpy int64 array of remaining capacities (all bins the item fits in), in fixed order.

    Returns scores; highest score wins, ties to first bin.
    """
    # Basic best-fit score: smaller remaining capacity after placing is better.
    # score = -(remaining_after) = -(bins - item) = item - bins
    # Equivalent to preferring the tightest fit.
    base = item - bins.astype(np.float64)

    # Perturbation: deterministic tiny tie-breaker so identical remainders don't always
    # resolve purely by bin index in a way that can correlate badly with arrival order.
    # Use a simple integer hash of the bin index and remaining capacity.
    idx = np.arange(bins.shape[0], dtype=np.int64)
    h = (idx * 1103515245 + bins.astype(np.int64) * 12345 + item * 2654435761) & 0x7fffffff
    perturbation = (h % 1000003).astype(np.float64) * 1e-7

    scores = base + perturbation

    # Tiny penalty for opening a brand-new empty bin, to reduce premature bin opening.
    # Only matters when remainder equals item (i.e., bins == 100).
    empty_mask = bins == 100
    if np.any(empty_mask):
        scores[empty_mask] -= _EMPTY_BIAS

    return scores
