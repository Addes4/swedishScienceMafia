import numpy as np

# Persistent state (module-level).  Kept small and simple: running mean of items.
_STATE = {
    "n": 0,
    "sum": 0.0,
}


def priority(item, bins):
    """Rank bins for an arriving item.

    The core rule is best fit.  A mild, online-adapting correction discourages
    placing small items into completely fresh/empty bins, so that spare large
    capacity is preserved for large arrivals.  The correction depends only on
    past items, never future ones.
    """
    _STATE["n"] += 1
    _STATE["sum"] += float(item)
    mean_size = _STATE["sum"] / _STATE["n"]

    # Fit quality: smaller leftover after placing is better.
    leftover = bins - item

    # Base score: strong preference for the tightest fitting bin.
    score = -(leftover.astype(np.float64))

    # Penalize using a completely empty bin for an item that is not large.
    # "Large" is judged relative to the running mean of observed item sizes.
    empty = (bins == 100)
    if item < mean_size:
        # A small extra penalty per unit of unused room on empty bins.
        # Scale modestly so it only breaks / tilts near-ties.
        score[empty] -= 0.35 * (100 - item) / 100.0

    return score
