import numpy as np

# Global state for online statistics (only used lightly; main rule is deterministic).
_seen = 0
_sum = 0.0

# Tuned parameters for residual desirability.
# Score = -(bin - item) is best-fit. We make gaps of certain small sizes
# less desirable unless they can still fit common small items.
# Since future items are unknown, we use a smooth preference favoring exact
# or near-exact fit, but penalizing tiny unusable leftovers slightly less
# than pure best fit would.

def priority(item, bins):
    global _seen, _sum
    n = bins.shape[0]
    residual = bins - item  # >= 0 for all shown bins

    # Basic best-fit base score.
    base = -residual.astype(np.float64)

    # A small preference: exact fit (residual 0) is best.
    # But among positive residuals, being just above a "dead zone" is bad
    # if it's below the smallest likely item size. Mean item ~40, but small
    # items occur. Penalize residuals in (0, ~10) a bit more, because they
    # tend to waste space, while not over-penalizing moderate gaps.
    r = residual.astype(np.float64)

    # Smooth penalty peaking around small positive residuals, vanishing for 0.
    # Use exp decay: penalty = A * r * exp(-r / tau)
    # At r=0 penalty 0 (exact fit favored). Small r penalized modestly.
    tau = 8.0
    A = 0.15
    penalty = A * r * np.exp(-r / tau)

    score = base - penalty

    # Tie-break by bin index order implicitly via first-max.
    # To ensure stable behavior, add a tiny index-based epsilon.
    if n > 1:
        eps = np.arange(n, dtype=np.float64) * 1e-12
        score = score - eps

    return score
