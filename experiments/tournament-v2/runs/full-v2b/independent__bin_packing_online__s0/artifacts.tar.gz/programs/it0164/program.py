"""Hybrid online bin packing rule: near best-fit while discouraging unnecessary use of empty bins."""

import numpy as np


def priority(item, bins):
    """Score each bin; highest score wins, ties go to the earliest bin.

    The rule is a soft best-fit:
    - Strongly prefer bins whose remaining capacity is close to `item`.
    - Penalize unused bins (capacity 100) a little so small/medium items
      are packed into existing gaps before opening a new bin.
    - Still allow empty bins when they are clearly the best option.

    No future information is used and no persistent state is required.
    """
    # Base best-fit score: smaller leftover is better.
    score = -(bins - item)

    # Discourage opening brand-new bins unless the fit is unusually good.
    # Empty bins have remaining capacity exactly 100.
    empty_mask = bins == 100

    if np.any(empty_mask):
        # Compute the best score among already-used bins.
        used_scores = score[~empty_mask]
        if used_scores.size:
            best_used = used_scores.max()
        else:
            best_used = -10**9

        # Penalty is mild but enough to avoid needlessly consuming empty bins
        # when an existing bin offers a comparable fit.
        penalty = 0.25 * (100 - item)
        if penalty < 1.0:
            penalty = 1.0

        score = score.astype(np.float64, copy=True)
        score[empty_mask] -= penalty

        # If no used bin is competitive at all, restore empty bins' priority.
        # This avoids pathological behavior on large items.
        if best_used < -(100):
            score[empty_mask] += penalty

    return score
