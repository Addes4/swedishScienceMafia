import numpy as np

_last = [None]

def priority(item, bins):
    # Best-fit style: prefer smallest remaining capacity after placing item.
    # Score = gap after placing item; smaller gap is better, so negative gap.
    gap = bins - item
    score = -gap.astype(np.float64)

    # Slight preference for already-used bins when gaps are close,
    # to reduce the number of nearly-empty bins.
    score += -0.001 * bins

    return score
