import numpy as np

_state = {
    "calls": 0,
    "item_sum": 0,
}


def priority(item, bins):
    """Best-fit with a mild stateful bias for preserving large empty bins."""
    _state["calls"] += 1
    _state["item_sum"] += item

    # Base: best fit. Larger score means the item goes into a tighter-fitting bin.
    residual = bins - item

    # Primary score: strongly prefer small residual (tight fit).
    score = -residual.astype(np.float64)

    # Mild preference for using partially filled bins before completely empty ones.
    # This helps avoid opening new bins when a good fit exists, without hurting tight fits.
    empty = bins == 100
    score[empty] -= 0.05

    # Tiny preference against leaving tiny unusable gaps, except when the fit is excellent.
    tiny_gap = (residual > 0) & (residual < 10)
    score[tiny_gap] -= 0.01

    return score
