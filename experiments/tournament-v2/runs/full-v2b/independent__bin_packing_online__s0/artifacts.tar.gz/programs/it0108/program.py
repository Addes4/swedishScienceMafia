import numpy as np


def priority(item, bins):
    """Rank bins by a combination of fit quality and reluctance to open new bins.

    All bins the item fits in are provided, including completely unused bins
    (remaining capacity 100). We prefer:
      - existing partially filled bins over unused bins,
      - tighter fits (smaller residual after placement),
      - residues that are not too large, to preserve packing flexibility.
    """
    residual = bins - item

    # Base preference: tighter fit is better (smaller residual => larger score).
    score = 100.0 - residual

    # Strongly discourage opening a new bin unless necessary.
    score -= 1000.0 * (bins == 100)

    # If residual becomes zero (perfect fit), heavily reward it.
    score += 500.0 * (residual == 0)

    # Mild preference for leaving useful residuals rather than tiny unusable ones,
    # except when perfect or nearly full. This helps future items fit.
    # Small positive bonus for residuals in useful mid-range, small penalty for 1..5.
    score += 0.05 * np.minimum(residual, 50)
    score -= 3.0 * ((residual >= 1) & (residual <= 5))

    return score
