"""Best-fit with a secondary preference for fuller bins (fewer open bins)."""
import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin with remaining capacity closest to the item size.
    # Primary: exact fit (gap 0) is best.
    # Secondary: when multiple bins have similar gaps, prefer the one with less
    # remaining capacity (fuller bins), which reduces the number of opened bins.
    #
    # score = -(gap^2) - alpha * (bins / 100) * (gap / 100)
    # The quadratic term dominates; the small linear term breaks ties toward
    # fuller bins without distorting the tight-fit preference.
    gap = bins - item
    score = -(gap.astype(np.float64) ** 2)
    # Small tie-breaker: prefer larger bins (fuller) when gaps are equal,
    # but always after exact/tighter fit. Add a tiny term proportional to -(bins)
    # scaled so it only matters for near-equal primary scores.
    score += -(bins.astype(np.float64)) * 1e-6
    return score
