"""Best-fit with a mild anti-new-bin tie-break.

Core rule: choose the bin where the item fits most tightly (smallest leftover).
Tie-break: among equally tight bins, prefer one that is already partially used
over a completely empty bin, since opening a fresh bin early tends to waste
capacity on later small items that could have filled the gap.
"""
import numpy as np


def priority(item, bins):
    # Best fit: smallest remaining capacity after placing the item is best.
    # Score = -(bins - item) = item - bins, so smaller bins score higher.
    score = -(bins - item)

    # Anti-new-bin bias: a completely empty bin (remaining == 100) gets a
    # small penalty so that among equally tight options we reuse partial bins.
    # Only apply when the item is not itself filling a fresh bin tightly.
    empty_penalty = (bins == 100).astype(np.float64) * 0.5

    return score.astype(np.float64) - empty_penalty
