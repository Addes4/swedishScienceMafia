import numpy as np

class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.threshold = 30.0
        self.tight = 0.0

_state = _State()


def priority(item, bins):
    s = _state
    s.n += 1
    s.sum += item
    mean = s.sum / s.n
    # Update a rough estimate of a "small item" threshold.
    # Weibull-ish mean ~40, so small items are below ~30 shifted by observed mean.
    target = 0.72 * mean
    s.threshold = 0.98 * s.threshold + 0.02 * target

    rem = bins
    # Base score: best fit -> smaller remaining capacity after placing item is better.
    score = -(rem - item).astype(np.float64)

    # Penalize completely empty bins slightly when tight alternatives exist,
    # to keep empty bins available for large future items.
    empty_mask = (rem == 100)
    if item <= s.threshold:
        # Small item: mild preference against opening a brand-new bin.
        score = np.where(empty_mask, score - 4.0, score)
    else:
        # Larger item: avoid stuffing it into tight bins if it barely fits,
        # but still favor good fit. Slight preference for emptier bins is bad for
        # pure best fit, so keep it mild and only for very tight fits.
        score = np.where(rem < item + 3, score - 1.0, score)

    return score
