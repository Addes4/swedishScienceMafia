import numpy as np


def priority(item, bins):
    residual = bins - item
    # Best-fit-like rule: prefer the smallest nonnegative residual.
    # Squaring makes the preference sharper, reducing fragmentation.
    scores = -(residual.astype(np.float64) ** 2)
    # Tie-break: prefer bins that are already more full (lower remaining capacity before placement).
    scores -= bins.astype(np.float64) * 1e-9
    return scores
