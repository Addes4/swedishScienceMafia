# EVOLVE-BLOCK-START
"""Pack n squares by physical relaxation: grow when feasible, push apart when not."""
import math
import random


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    def overlap_all(sq):
        m = len(sq)
        for i in range(m):
            ax, ay, aw, ah, ar = sq[i]
            for j in range(i + 1, m):
                bx, by, bw, bh, br = sq[j]
                dx = bx - ax
                dy = by - ay
                ca = math.cos(ar)
                sa = math.sin(ar)
                cb = math.cos(br)
                sb = math.sin(br)
                # quick reject using bounding radii
                ra = 0.5 * math.hypot(aw, ah)
                rb = 0.5 * math.hypot(bw, bh)
                if abs(dx) > ra + rb or abs(dy) > ra + rb:
                    continue
                # SAT using separated axis projection (approximate via half-extents)
                # Use approximate overlap test with rotated half-extents
                hx_a = 0.5 * (abs(ca) * aw + abs(sa) * ah)
                hy_a = 0.5 * (abs(sa) * aw + abs(ca) * ah)
                hx_b = 0.5 * (abs(cb) * bw + abs(sb) * bh)
                hy_b = 0.5 * (abs(sb) * bw + abs(cb) * bh)
                ox = hx_a + hx_b - abs(dx) - 1e-12
                oy = hy_a + hy_b - abs(dy) - 1e-12
                if ox > 0 and oy > 0:
                    return True
        return False

    def clamp(sq):
        for s in sq:
            w, h, a = s[2], s[3], s[4]
            hx = 0.5 * (abs(math.cos(a)) * w + abs(math.sin(a)) * h)
            hy = 0.5 * (abs(math.sin(a)) * w + abs(math.cos(a)) * h)
            s[0] = min(max(s[0], hx), 1.0 - hx)
            s[1] = min(max(s[1], hy), 1.0 - hy)

    def total(sq):
        return sum(s[2] for s in sq)

    best_sum = -1.0
    best = None
    k0 = math.ceil(math.sqrt(n))

    trials = 10
    for trial in range(trials):
        random.seed((n * 7919 + trial * 104729) & 0x7FFFFFFF)
        sq = []
        for i in range(n):
            r = i // k0
            c = i % k0
            base = 1.0 / (k0 + 0.2)
            ang = 0.0
            if n >= 13:
                ang = random.uniform(-0.05, 0.05)
            sq.append([
                (c + 0.5) / k0 + random.uniform(-0.06, 0.06),
                (r + 0.5) / k0 + random.uniform(-0.06, 0.06),
                base * random.uniform(0.75, 1.0),
                base * random.uniform(0.75, 1.0),
                ang,
            ])
        clamp(sq)

        for it in range(3500):
            if not overlap_all(sq):
                tot = total(sq)
                if tot > best_sum:
                    best_sum = tot
                    best = [x[:] for x in sq]
                for s in sq:
                    s[2] = min(s[2] * 1.008, 1.0)
                    s[3] = s[2]
            else:
                for _ in range(6):
                    m = len(sq)
                    for i in range(m):
                        a = sq[i]
                        for j in range(i + 1, m):
                            b = sq[j]
                            dx = b[0] - a[0]
                            dy = b[1] - a[1]
                            half = (a[2] + b[2]) / 2.0
                            ox = half - abs(dx)
                            oy = half - abs(dy)
                            if ox > 0.0 and oy > 0.0:
                                if ox < oy:
                                    p = ox / 2.0
                                    if dx >= 0:
                                        a[0] -= p
                                        b[0] += p
                                    else:
                                        a[0] += p
                                        b[0] -= p
                                else:
                                    p = oy / 2.0
                                    if dy >= 0:
                                        a[1] -= p
                                        b[1] += p
                                    else:
                                        a[1] += p
                                        b[1] -= p
                    clamp(sq)
                if overlap_all(sq):
                    for s in sq:
                        s[2] *= 0.99
                        s[3] = s[2]
            clamp(sq)

        # Polish phase: grow squares one at a time if feasible
        if best is not None:
            sq = [x[:] for x in best]
            for _ in range(60):
                improved = False
                order = list(range(n))
                random.shuffle(order)
                for idx in order:
                    old = sq[idx][2]
                    target = min(old * 1.02, 1.0)
                    sq[idx][2] = target
                    sq[idx][3] = target
                    clamp(sq)
                    if overlap_all(sq):
                        sq[idx][2] = old
                        sq[idx][3] = old
                    else:
                        improved = True
                if not improved:
                    break
            tot = total(sq)
            if not overlap_all(sq) and tot > best_sum:
                best_sum = tot
                best = [x[:] for x in sq]

    if best is None:
        k = math.isqrt(n)
        side = 1.0 / k
        best = [((i % k + 0.5) * side, (i // k + 0.5) * side, side, side, 0.0) for i in range(n)]
        best += [(0.5, 0.5, 0.0, 0.0, 0.0)] * (n - len(best))

    return [(x[0], x[1], x[4], x[2]) for x in best][:n]
# EVOLVE-BLOCK-END
