"""Growth-and-relaxation: inflate random rotated squares, resolve overlaps by
projected-gradient repulsion, repeatedly restart and keep the best."""

import math
import random

# ----------------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------------

def _rad(a, s):
    """Bounding radius of a square (half diagonal) -- radius of its bounding
    circle.  Independent of rotation, but kept as a helper for clarity."""
    return 0.5 * s * math.sqrt(2.0)


def _overlap_area(q1, q2):
    """Approximate penetration between two squares using separating-axis
    distance.  Returns a signed 'penetration depth' (positive = overlapping)."""
    (c1x, c1y, a1, s1) = q1
    (c2x, c2y, a2, s2) = q2

    def axes(a):
        t = a * 2.0 * math.pi
        c, s = math.cos(t), math.sin(t)
        return (c, s), (-s, c)

    u1, v1 = axes(a1)
    u2, v2 = axes(a2)
    dx = c2x - c1x
    dy = c2y - c1y
    best = 1e18
    for (ux, uy), hs, other in (
        (u1, 0.5 * s1, (u2, v2, 0.5 * s2)),
        (v1, 0.5 * s1, (u2, v2, 0.5 * s2)),
        (u2, 0.5 * s2, (u1, v1, 0.5 * s1)),
        (v2, 0.5 * s2, (u1, v1, 0.5 * s1)),
    ):
        (ox, oy), (px, py), ho = other
        d = abs(dx * ux + dy * uy)
        proj = abs(ox * ux + oy * uy) * ho + abs(px * ux + py * uy) * ho
        gap = d - (hs + proj)
        if gap < best:
            best = gap
    return best


# ----------------------------------------------------------------------------
# clamp helper: keep a rotated square fully inside the unit square
# ----------------------------------------------------------------------------

def _clamp_center(x, y, a, s):
    """Clamp centre so the rotated square stays inside [0,1]^2.

    For an axis-aligned square of side s the centre must be at least s/2 from
    each wall.  For a rotated square the extent along x and y depends on the
    angle; we use the exact axis-aligned bounding box of the rotated square.
    """
    t = a * 2.0 * math.pi
    c, sn = abs(math.cos(t)), abs(math.sin(t))
    hx = 0.5 * s * (c + sn)
    hy = hx  # same by symmetry of a square
    lo_x, hi_x = hx, 1.0 - hx
    lo_y, hi_y = hy, 1.0 - hy
    if lo_x > hi_x:
        x = 0.5
    else:
        x = min(max(x, lo_x), hi_x)
    if lo_y > hi_y:
        y = 0.5
    else:
        y = min(max(y, lo_y), hi_y)
    return x, y


def _fits(x, y, a, s):
    t = a * 2.0 * math.pi
    c, sn = abs(math.cos(t)), abs(math.sin(t))
    hx = 0.5 * s * (c + sn)
    return (hx <= x <= 1.0 - hx) and (hx <= y <= 1.0 - hx)


# ----------------------------------------------------------------------------
# core relaxation
# ----------------------------------------------------------------------------

def _relax(squares, steps, grow=None):
    """Move squares apart, optionally growing them towards `grow`."""
    n = len(squares)
    if n == 0:
        return squares
    pos = [[q[0], q[1]] for q in squares]
    ang = [q[2] for q in squares]
    siz = [q[3] for q in squares]

    for it in range(steps):
        if grow is not None:
            frac = (it + 1) / steps
            for i in range(n):
                if frac < 1.0:
                    siz[i] += (grow[i] - siz[i]) * (2.0 / steps)

        fx = [0.0] * n
        fy = [0.0] * n
        for i in range(n):
            for j in range(i + 1, n):
                xi, yi = pos[i]
                xj, yj = pos[j]
                dx = xj - xi
                dy = yj - yi
                d2 = dx * dx + dy * dy
                si, sj = siz[i], siz[j]
                rad = 0.5 * (si + sj) * 1.4143
                if d2 > rad * rad:
                    continue
                if d2 < 1e-18:
                    dx = (random.random() - 0.5) * 1e-3
                    dy = (random.random() - 0.5) * 1e-3
                    d2 = dx * dx + dy * dy + 1e-18
                ov = _overlap_area((xi, yi, ang[i], si), (xj, yj, ang[j], sj))
                if ov <= 0.0:
                    continue
                d = math.sqrt(d2)
                f = ov * 60.0 / d
                fx[i] -= dx * f
                fy[i] -= dy * f
                fx[j] += dx * f
                fy[j] += dy * f

        for i in range(n):
            h = _rad(ang[i], siz[i])
            if pos[i][0] < h:
                fx[i] += (h - pos[i][0]) * 200.0
            elif pos[i][0] > 1.0 - h:
                fx[i] -= (pos[i][0] - (1.0 - h)) * 200.0
            if pos[i][1] < h:
                fy[i] += (h - pos[i][1]) * 200.0
            elif pos[i][1] > 1.0 - h:
                fy[i] -= (pos[i][1] - (1.0 - h)) * 200.0

        lr = 0.35
        for i in range(n):
            pos[i][0] += fx[i] * lr
            pos[i][1] += fy[i] * lr
            cx, cy = _clamp_center(pos[i][0], pos[i][1], ang[i], siz[i])
            pos[i][0] = cx
            pos[i][1] = cy

    return [(pos[i][0], pos[i][1], ang[i], siz[i]) for i in range(n)]


def _overlaps(squares):
    n = len(squares)
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap_area(squares[i], squares[j]) > 1e-7:
                return True
    return False


def _repair(squares, rounds=200):
    """Make a layout feasible: shrink offending squares and re-clamp."""
    squares = [list(q) for q in squares]
    n = len(squares)
    for q in squares:
        if q[3] < 0:
            q[3] = 0.0
        q[0], q[1] = _clamp_center(q[0], q[1], q[2], q[3])
    for _ in range(rounds):
        bad = False
        for i in range(n):
            for j in range(i + 1, n):
                ov = _overlap_area(squares[i], squares[j])
                if ov > 1e-9:
                    bad = True
                    for q in (squares[i], squares[j]):
                        q[3] = max(0.0, q[3] - 0.5 * ov - 1e-6)
        for q in squares:
            q[0], q[1] = _clamp_center(q[0], q[1], q[2], q[3])
        if not bad:
            break
    return [(q[0], q[1], q[2], q[3]) for q in squares]


def _feasible(squares, eps=1e-6):
    n = len(squares)
    for i in range(n):
        x, y, a, s = squares[i]
        if s < -eps:
            return False
        if not _fits(x, y, a, s):
            return False
        for j in range(i + 1, n):
            if _overlap_area(squares[i], squares[j]) > 1e-6:
                return False
    return True


def _score(squares):
    return sum(max(0.0, q[3]) for q in squares)


def _best_from(n, seed, tries):
    rng = random.Random(seed)
    best = None
    bestv = -1.0
    for t in range(tries):
        cols = int(math.ceil(math.sqrt(n))) + 1
        squares = []
        for i in range(n):
            cx = rng.random()
            cy = rng.random()
            a = rng.random()
            s = rng.uniform(0.01, 0.9 / cols)
            squares.append((cx, cy, a, s))
        target = min(1.0 / max(1, cols - 0.5), 0.9 / math.sqrt(n + 1))
        grow = [target * rng.uniform(0.98, 1.02) for _ in range(n)]
        cand = _relax(squares, 120, grow)
        if not _feasible(cand):
            cand = _relax(cand, 120, None)
        if not _feasible(cand):
            cand = _repair(cand)
        if _feasible(cand):
            v = _score(cand)
            if v > bestv:
                bestv = v
                best = cand
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    attempts = 6 if n <= 60 else 3
    best = _best_from(n, 12345 + n, attempts)
    if best is None:
        k = math.isqrt(n)
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = _repair(best)
    best = _repair(best)
    return best[:n]
