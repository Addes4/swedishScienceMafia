# EVOLVE-BLOCK-START
"""Pack n axis-aligned squares by physics relaxation + per-square growth polish."""
import math
import random


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    def clamp(sq):
        for s in sq:
            h = s[2] / 2.0
            s[0] = min(max(s[0], h), 1.0 - h)
            s[1] = min(max(s[1], h), 1.0 - h)

    def total(sq):
        return sum(s[2] for s in sq)

    def overlap_amount(sq):
        m = len(sq)
        s = 0.0
        for i in range(m):
            ax, ay, a = sq[i]
            ha = a / 2.0
            for j in range(i + 1, m):
                bx, by, b = sq[j]
                hb = b / 2.0
                r = ha + hb
                ox = r - abs(bx - ax)
                oy = r - abs(by - ay)
                if ox > 0.0 and oy > 0.0:
                    s += min(ox, oy)
        return s

    def resolve(sq, steps=6, strength=0.5):
        m = len(sq)
        for _ in range(steps):
            for i in range(m):
                a = sq[i]
                for j in range(i + 1, m):
                    b = sq[j]
                    dx = b[0] - a[0]
                    dy = b[1] - a[1]
                    half = (a[2] + b[2]) / 2.0
                    ox = half - abs(dx)
                    oy = half - abs(dy)
                    if ox > 0.0 and oy > 0.0:
                        if ox < oy:
                            p = ox * strength
                            if dx >= 0:
                                a[0] -= p
                                b[0] += p
                            else:
                                a[0] += p
                                b[0] -= p
                        else:
                            p = oy * strength
                            if dy >= 0:
                                a[1] -= p
                                b[1] += p
                            else:
                                a[1] += p
                                b[1] -= p
            clamp(sq)

    best_sum = -1.0
    best = None
    k0 = max(1, round(math.sqrt(n)))

    for trial in range(14):
        random.seed((n * 2654435761 + trial * 40503) & 0x7FFFFFFF)
        sq = []
        for i in range(n):
            r = i // k0
            c = i % k0
            base = 1.0 / (k0 + 0.15)
            sq.append([
                (c + 0.5) / k0 + random.uniform(-0.07, 0.07),
                (r + 0.5) / k0 + random.uniform(-0.07, 0.07),
                base * random.uniform(0.7, 1.05),
            ])
        clamp(sq)

        # Phase 1: grow/repel relaxation
        for it in range(1800):
            if overlap_amount(sq) <= 1e-12:
                t = total(sq)
                if t > best_sum:
                    best_sum = t
                    best = [x[:] for x in sq]
                for s in sq:
                    s[2] = min(s[2] * 1.008, 1.0)
                clamp(sq)
            else:
                resolve(sq, steps=8, strength=0.5)
                if overlap_amount(sq) > 1e-9:
                    for s in sq:
                        s[2] *= 0.99
                clamp(sq)

        # Phase 2: per-square growth polish
        for polish in range(6):
            order = list(range(n))
            random.shuffle(order)
            for idx in order:
                s = sq[idx]
                old = s[2]
                # ceiling implied by walls
                ceil_wall = 2.0 * min(min(s[0], 1.0 - s[0]), min(s[1], 1.0 - s[1]))
                ceil_wall = min(ceil_wall, 1.0)
                # try to grow until blocked
                lo, hi = old, max(old, ceil_wall)
                if hi <= lo:
                    continue
                s[2] = hi
                clamp(sq)
                if overlap_amount(sq) > 1e-12:
                    # binary search largest feasible
                    for _ in range(22):
                        mid = 0.5 * (lo + hi)
                        s[2] = mid
                        clamp(sq)
                        if overlap_amount(sq) <= 1e-12:
                            lo = mid
                        else:
                            hi = mid
                    s[2] = lo
                    clamp(sq)
                else:
                    lo = hi
                s[2] = lo
                clamp(sq)
            # after polishing, resolve tiny overlaps
            if overlap_amount(sq) > 1e-12:
                resolve(sq, steps=4, strength=0.5)
                if overlap_amount(sq) > 1e-9:
                    for s in sq:
                        s[2] *= 0.995
                    clamp(sq)
            t = total(sq)
            if overlap_amount(sq) <= 1e-12 and t > best_sum:
                best_sum = t
                best = [x[:] for x in sq]

    if best is None:
        k = max(1, math.isqrt(n))
        side = 1.0 / k
        best = [((i % k + 0.5) * side, (i // k + 0.5) * side, side) for i in range(n)]
        best += [(0.5, 0.5, 0.0)] * (n - len(best))

    return [(x[0], x[1], 0.0, x[2]) for x in best][:n]
# EVOLVE-BLOCK-END
