"""Inflate-and-repair solver for packing squares (possibly rotated) in the unit
square, maximising the sum of side lengths.

Strategy:
  * build a guaranteed-valid starting layout,
  * inflate the squares while resolving overlaps with SAT minimum-translation
    vectors and wall constraints (projected gradient / soft-body relaxation),
  * within each square's allowed orientation, rotate to escape grid patterns,
  * finally run a strict 'repair' that shrinks any still-overlapping squares and
    settles, so the returned layout is always feasible.
Restarts are kept and the best feasible layout is returned.
"""

import math
import random

# --------------------------------------------------------------------------
# geometry
# --------------------------------------------------------------------------

def _corner_offsets(a, s):
    t = a * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    return (
        (h * (c - sn), h * (sn + c)),
        (h * (-c - sn), h * (-sn + c)),
        (h * (-c + sn), h * (-sn - c)),
        (h * (c + sn), h * (sn - c)),
    )


def _axes(a):
    t = a * 2.0 * math.pi
    c, s = math.cos(t), math.sin(t)
    return (c, s), (-s, c)


def _half_extent(a, s):
    """Distance from centre to farthest corner (bounding radius)."""
    return 0.5 * s * math.sqrt(2.0)


def _sat_mtv(q1, q2):
    """Return (overlap_depth, nxx, nyy) pushing q1 away from q2, or None if
    separated.  overlap_depth > 0 means overlapping."""
    (x1, y1, a1, s1) = q1
    (x2, y2, a2, s2) = q2
    u1, v1 = _axes(a1)
    u2, v2 = _axes(a2)
    dx = x2 - x1
    dy = y2 - y1
    h1 = 0.5 * s1
    h2 = 0.5 * s2
    best = 1e18
    bnx = 0.0
    bny = 0.0
    for (ax, ay) in (u1, v1, u2, v2):
        # overlap along axis
        d = dx * ax + dy * ay
        r1 = h1 * (abs(u1[0] * ax + u1[1] * ay) + abs(v1[0] * ax + v1[1] * ay))
        r2 = h2 * (abs(u2[0] * ax + u2[1] * ay) + abs(v2[0] * ax + v2[1] * ay))
        if r1 + r2 == 0.0:
            continue
        gap = (r1 + r2) - abs(d)
        if gap <= 0.0:
            return None
        if gap < best:
            best = gap
            if d >= 0.0:
                bnx, bny = -ax, -ay
            else:
                bnx, bny = ax, ay
    return best, bnx, bny


# --------------------------------------------------------------------------
# relaxation: inflate with soft-body overlap resolution
# --------------------------------------------------------------------------

def _relax(squares, steps, target, lr=0.4, rot_noise=0.0, rng=None):
    """Inflate towards `target` sizes while pushing overlaps apart via MTV."""
    n = len(squares)
    if n == 0:
        return squares
    pos = [[q[0], q[1]] for q in squares]
    ang = [q[2] for q in squares]
    siz = [q[3] for q in squares]

    for it in range(steps):
        frac = min(1.0, (it + 1) / float(steps))
        # grow toward target
        for i in range(n):
            if siz[i] < target[i]:
                siz[i] = min(target[i], siz[i] + (target[i] - siz[i]) * (2.0 / steps) + 1e-5)
        # gentle rotation perturbation early on
        if rot_noise > 0.0 and rng is not None and frac < 0.5:
            for i in range(n):
                ang[i] += rot_noise * (rng.random() - 0.5)
        fx = [0.0] * n
        fy = [0.0] * n
        for i in range(n):
            xi, yi = pos[i]
            si = siz[i]
            ai = ang[i]
            r_i = _half_extent(ai, si)
            for j in range(i + 1, n):
                xj, yj = pos[j]
                sj = siz[j]
                aj = ang[j]
                rj = _half_extent(aj, sj)
                dx = xj - xi
                dy = yj - yi
                # cheap bounding-circle rejection
                if dx * dx + dy * dy > (r_i + rj) ** 2:
                    continue
                mtv = _sat_mtv((xi, yi, ai, si), (xj, yj, aj, sj))
                if mtv is None:
                    continue
                depth, nx, ny = mtv
                f = depth * 40.0
                fx[i] += nx * f
                fy[i] += ny * f
                fx[j] -= nx * f
                fy[j] -= ny * f
                # also push sizes down a touch when deeply overlapped
                if depth > 0.02:
                    siz[i] = max(0.0, siz[i] - depth * 0.05)
                    siz[j] = max(0.0, siz[j] - depth * 0.05)
        # wall constraints using bounding radius
        for i in range(n):
            r = _half_extent(ang[i], siz[i])
            lo, hi = r, 1.0 - r
            if lo > hi:
                lo = hi = 0.5
            if pos[i][0] < lo:
                fx[i] += (lo - pos[i][0]) * 120.0
            elif pos[i][0] > hi:
                fx[i] -= (pos[i][0] - hi) * 120.0
            if pos[i][1] < lo:
                fy[i] += (lo - pos[i][1]) * 120.0
            elif pos[i][1] > hi:
                fy[i] -= (pos[i][1] - hi) * 120.0
        for i in range(n):
            pos[i][0] += fx[i] * lr
            pos[i][1] += fy[i] * lr
            r = _half_extent(ang[i], siz[i])
            lo, hi = r, 1.0 - r
            if lo > hi:
                lo = hi = 0.5
            if pos[i][0] < lo:
                pos[i][0] = lo
            elif pos[i][0] > hi:
                pos[i][0] = hi
            if pos[i][1] < lo:
                pos[i][1] = lo
            elif pos[i][1] > hi:
                pos[i][1] = hi
    return [(pos[i][0], pos[i][1], ang[i], siz[i]) for i in range(n)]


# --------------------------------------------------------------------------
# feasibility + repair
# --------------------------------------------------------------------------

def _valid(squares, eps=1e-7):
    n = len(squares)
    for i in range(n):
        x, y, a, s = squares[i]
        if s < 0.0:
            return False
        r = _half_extent(a, s)
        if x < r - eps or x > 1.0 - r + eps:
            return False
        if y < r - eps or y > 1.0 - r + eps:
            return False
        for j in range(i + 1, n):
            if _sat_mtv(squares[i], squares[j]) is not None:
                return False
    return True


def _repair(squares, rng):
    """Shrink overlappers / out-of-bounds then settle until valid."""
    n = len(squares)
    sq = [list(q) for q in squares]
    # clamp inside
    for i in range(n):
        r = _half_extent(sq[i][2], sq[i][3])
        lo, hi = r, 1.0 - r
        if lo > hi:
            lo = hi = 0.5
        sq[i][0] = min(max(sq[i][0], lo), hi)
        sq[i][1] = min(max(sq[i][1], lo), hi)
    for _ in range(400):
        bad = False
        pushed = False
        for i in range(n):
            for j in range(i + 1, n):
                mtv = _sat_mtv(tuple(sq[i]), tuple(sq[j]))
                if mtv is None:
                    continue
                bad = True
                depth, nx, ny = mtv
                # shrink the larger square slightly
                if sq[i][3] >= sq[j][3]:
                    sq[i][3] = max(0.0, sq[i][3] - depth * 0.5 - 1e-4)
                else:
                    sq[j][3] = max(0.0, sq[j][3] - depth * 0.5 - 1e-4)
                # move apart a bit
                sq[i][0] += nx * depth * 0.25
                sq[i][1] += ny * depth * 0.25
                sq[j][0] -= nx * depth * 0.25
                sq[j][1] -= ny * depth * 0.25
                pushed = True
        # re-clamp
        for i in range(n):
            r = _half_extent(sq[i][2], sq[i][3])
            lo, hi = r, 1.0 - r
            if lo > hi:
                lo = hi = 0.5
            if sq[i][0] < lo or sq[i][0] > hi or sq[i][1] < lo or sq[i][1] > hi:
                bad = True
            sq[i][0] = min(max(sq[i][0], lo), hi)
            sq[i][1] = min(max(sq[i][1], lo), hi)
        if not bad:
            break
    return [(q[0], q[1], q[2], max(0.0, q[3])) for q in sq]


def _score(squares):
    return sum(max(0.0, q[3]) for q in squares)


# --------------------------------------------------------------------------
# initial layouts
# --------------------------------------------------------------------------

def _grid_start(n, rng):
    k = max(1, int(math.ceil(math.sqrt(n))))
    side = 1.0 / k
    sq = []
    for idx in range(n):
        i = idx % k
        j = idx // k
        cx = (i + 0.5) * side
        cy = (j + 0.5) * side
        if cx > 1.0:
            cx = 1.0 - 0.5 * side
        if cy > 1.0:
            cy = 1.0 - 0.5 * side
        # jitter within cell
        cx = min(1.0 - 0.5 * side, max(0.5 * side, cx + (rng.random() - 0.5) * side * 0.2))
        cy = min(1.0 - 0.5 * side, max(0.5 * side, cy + (rng.random() - 0.5) * side * 0.2))
        sq.append((cx, cy, 0.0, side * 0.98))
    return sq


def _random_start(n, rng):
    sq = []
    for _ in range(n):
        s = rng.uniform(0.02, 0.8 / math.sqrt(n + 1.0))
        r = _half_extent(0.0, s)
        lo, hi = r, 1.0 - r
        if lo > hi:
            lo = hi = 0.5
        sq.append((rng.uniform(lo, hi), rng.uniform(lo, hi),
                   rng.random(), s))
    return sq


def _run(n, rng, target_scale, steps, rot_noise):
    starts = [_grid_start(n, rng), _random_start(n, rng)]
    best = None
    bestv = -1.0
    for st in starts:
        target = [min(0.99, target_scale) for _ in range(n)]
        cand = _relax(st, steps, target, rot_noise=rot_noise, rng=rng)
        cand = _repair(cand, rng)
        if _valid(cand):
            v = _score(cand)
            if v > bestv:
                bestv = v
                best = cand
    return best, bestv


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(987654321 + n)
    overall_best = None
    overall_v = -1.0

    # candidate target sizes to try
    base = 1.0 / math.sqrt(n)
    targets = [base * f for f in (1.0, 1.15, 1.3, 1.5)]

    for tgt in targets:
        for trial in range(3):
            steps = 220
            rot_noise = 0.02 if trial > 0 else 0.0
            cand, v = _run(n, rng, tgt, steps, rot_noise)
            if cand is not None and v > overall_v:
                overall_v = v
                overall_best = cand

    if overall_best is None:
        # guaranteed-valid fallback
        k = max(1, int(math.ceil(math.sqrt(n))))
        side = 1.0 / k
        overall_best = []
        for idx in range(n):
            i = idx % k
            j = idx // k
            cx = min(1.0 - 0.5 * side, (i + 0.5) * side)
            cy = min(1.0 - 0.5 * side, (j + 0.5) * side)
            overall_best.append((cx, cy, 0.0, side))
        overall_best = overall_best[:n]

    # final safety repair
    overall_best = _repair(overall_best, rng)
    overall_best = overall_best[:n]
    return overall_best
