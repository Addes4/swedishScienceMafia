# EVOLVE-BLOCK-START
"""Greedy skyline packing: place squares largest-first onto a shelf/skyline,
trying many orderings and sizes; keep the best total side length."""
import math


def _place_skyline(order, total):
    """Try to fit squares of relative sizes order (list) into unit square
    using a shelf packing. Return list of (cx, cy, side) or None."""
    # shelf packing: rows with height = max square in row; squares left to right
    x = 0.0
    y = 0.0
    row_h = 0.0
    placed = []
    for s in order:
        if x + s > 1.0 + 1e-12:
            # new row
            y += row_h
            x = 0.0
            row_h = 0.0
        if y + s > 1.0 + 1e-12:
            return None
        placed.append((x + s / 2.0, y + s / 2.0, s))
        x += s
        row_h = max(row_h, s)
    if y + row_h > 1.0 + 1e-12:
        return None
    return placed


def _scale_fit(sizes):
    """Scale sizes so shelf packing fits in unit square; return (scale, placed)."""
    lo, hi = 0.0, 2.0
    # binary search the largest scale that fits
    for _ in range(60):
        mid = (lo + hi) / 2.0
        res = _place_skyline([s * mid for s in sizes], None)
        if res is not None:
            lo = mid
        else:
            hi = mid
    res = _place_skyline([s * lo for s in sizes], None)
    return lo, res


def solve(n):
    if n <= 0:
        return []
    # reference relative sizes: use 1/k grid values so scaled skyline behaves
    best_total = -1.0
    best = None
    # try different "shapes": mostly equal sizes, with one or two slightly bigger
    base_patterns = []
    base_patterns.append([1.0] * n)
    # agressive: one big + many small
    for big in (1.5, 2.0, 2.5, 3.0):
        base_patterns.append([big] + [1.0] * (n - 1))
    # two bigs
    for big in (1.5, 2.0):
        base_patterns.append([big, big] + [1.0] * (n - 2))
    # decreasing: big to small
    for ratio in (0.7, 0.8, 0.9):
        sizes = [ratio ** i for i in range(n)]
        base_patterns.append(sizes)
    # grid-like: k near sqrt(n)
    k = math.isqrt(n)
    if k * k == n:
        base_patterns.append([1.0] * n)

    for pat in base_patterns:
        if len(pat) != n:
            continue
        # try sorted descending
        for order in (pat, sorted(pat, reverse=True)):
            scale, placed = _scale_fit(order)
            if placed is None:
                continue
            total = sum(p[2] for p in placed)
            if total > best_total:
                best_total = total
                best = placed

    # fallback grid
    if best is None:
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 0.0
        best = [((i + 0.5) * side, (j + 0.5) * side, side)
                for i in range(k) for j in range(k)]
        while len(best) < n:
            best.append((0.5, 0.5, 0.0))

    # pad with zero squares if needed
    while len(best) < n:
        best.append((0.5, 0.5, 0.0))
    best = best[:n]
    # return in required 4-tuple form
    return [(cx, cy, 0.0, s) for (cx, cy, s) in best]
# EVOLVE-BLOCK-END

