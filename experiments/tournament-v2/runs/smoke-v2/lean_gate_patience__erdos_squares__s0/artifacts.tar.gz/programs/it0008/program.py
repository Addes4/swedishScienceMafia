"""Growth-and-relaxation: inflate random rotated squares, resolve overlaps by
projected-gradient repulsion, repeatedly restart and keep the best."""

import math
import random

# ----------------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------------

def _corners(cx, cy, a, s):
    """Corners of a square with centre (cx,cy), angle a (turns), side s."""
    t = a * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    return (
        (cx + h * (c - sn), cy + h * (sn + c)),
        (cx + h * (-c - sn), cy + h * (-sn + c)),
        (cx + h * (-c + sn), cy + h * (-sn - c)),
        (cx + h * (c + sn), cy + h * (sn - c)),
    )


def _axes(a):
    t = a * 2.0 * math.pi
    c, s = math.cos(t), math.sin(t)
    return (c, s), (-s, c)


def _overlap_area(q1, q2):
    """Approximate penetration between two squares using separating-axis
    distance.  Returns a signed 'penetration depth' (positive = overlapping)."""
    (c1x, c1y, a1, s1) = q1
    (c2x, c2y, a2, s2) = q2
    u1, v1 = _axes(a1)
    u2, v2 = _axes(a2)
    dx = c2x - c1x
    dy = c2y - c1y
    best = 1e18
    for (ux, uy), hs, other in (
        (u1, 0.5 * s1, (u2, v2, 0.5 * s2)),
        (v1, 0.5 * s1, (u2, v2, 0.5 * s2)),
        (u2, 0.5 * s2, (u1, v1, 0.5 * s1)),
        (v2, 0.5 * s2, (u1, v1, 0.5 * s1)),
    ):
        (ox, oy), (px, py), ho = other
        # distance along (ux,uy) between centres
        d = abs(dx * ux + dy * uy)
        # projected half-extent of the other square onto this axis
        proj = abs(ox * ux + oy * uy) * ho + abs(px * ux + py * uy) * ho
        gap = d - (hs + proj)
        if gap < best:
            best = gap
    return best


# ----------------------------------------------------------------------------
# core relaxation
# ----------------------------------------------------------------------------

def _relax(squares, steps, grow=None):
    """Move squares apart, optionally growing them towards `grow`."""
    n = len(squares)
    if n == 0:
        return squares
    pos = [[q[0], q[1]] for q in squares]
    ang = [q[2] for q in squares]
    siz = [q[3] for q in squares]

    for it in range(steps):
        # grow
        if grow is not None:
            frac = (it + 1) / steps
            for i in range(n):
                siz[i] += (grow[i] - siz[i]) * (2.0 / steps) if frac < 1.0 else 0.0
        # repulsion forces
        fx = [0.0] * n
        fy = [0.0] * n
        for i in range(n):
            for j in range(i + 1, n):
                xi, yi = pos[i]
                xj, yj = pos[j]
                dx = xj - xi
                dy = yj - yi
                d2 = dx * dx + dy * dy
                si, sj = siz[i], siz[j]
                # only bother if bounding circles overlap
                rad = 0.5 * (si + sj) * 1.4143
                if d2 > rad * rad or d2 < 1e-18:
                    if d2 < 1e-18:
                        dx = (random.random() - 0.5) * 1e-3
                        dy = (random.random() - 0.5) * 1e-3
                        d2 = dx * dx + dy * dy + 1e-18
                    else:
                        continue
                # precise overlap test
                ov = _overlap_area((xi, yi, ang[i], si), (xj, yj, ang[j], sj))
                if ov <= 0.0:
                    continue
                d = math.sqrt(d2)
                # push apart proportional to overlap
                f = ov * 60.0 / d
                fx[i] -= dx * f
                fy[i] -= dy * f
                fx[j] += dx * f
                fy[j] += dy * f
        # wall forces keep centres inside, then clamp
        for i in range(n):
            h = 0.5 * siz[i]
            lo, hi = h, 1.0 - h
            if lo > hi:
                lo = hi = 0.5
            if pos[i][0] < lo:
                fx[i] += (lo - pos[i][0]) * 200.0
            elif pos[i][0] > hi:
                fx[i] -= (pos[i][0] - hi) * 200.0
            if pos[i][1] < lo:
                fy[i] += (lo - pos[i][1]) * 200.0
            elif pos[i][1] > hi:
                fy[i] -= (pos[i][1] - hi) * 200.0
        # integrate with damping
        lr = 0.35
        for i in range(n):
            pos[i][0] += fx[i] * lr
            pos[i][1] += fy[i] * lr
            h = 0.5 * siz[i]
            lo, hi = h, 1.0 - h
            if lo > hi:
                lo = hi = 0.5
            if pos[i][0] < lo:
                pos[i][0] = lo
            elif pos[i][0] > hi:
                pos[i][0] = hi
            if pos[i][1] < lo:
                pos[i][1] = lo
            elif pos[i][1] > hi:
                pos[i][1] = hi

    return [(pos[i][0], pos[i][1], ang[i], siz[i]) for i in range(n)]


def _feasible(squares, eps=1e-7):
    n = len(squares)
    for i in range(n):
        x, y, a, s = squares[i]
        if s < 0:
            return False
        h = 0.5 * s
        if x < h - eps or x > 1.0 - h + eps:
            return False
        if y < h - eps or y > 1.0 - h + eps:
            return False
        for j in range(i + 1, n):
            if _overlap_area(squares[i], squares[j]) > 1e-6:
                return False
    return True


def _score(squares):
    return sum(max(0.0, q[3]) for q in squares)


def _best_from(n, seed, tries):
    rng = random.Random(seed)
    best = None
    bestv = -1.0
    for t in range(tries):
        # initial layout: random positions on a jittered grid, random angles
        cols = int(math.ceil(math.sqrt(n))) + 1
        squares = []
        for i in range(n):
            cx = rng.random()
            cy = rng.random()
            a = rng.random()
            s = rng.uniform(0.01, 0.9 / cols)
            squares.append((cx, cy, a, s))
        # grow towards a target that is feasible-ish: use an estimate
        target = min(1.0 / max(1, cols - 0.5), 0.9 / math.sqrt(n + 1))
        grow = [target * rng.uniform(0.98, 1.02) for _ in range(n)]
        cand = _relax(squares, 120, grow)
        if not _feasible(cand):
            cand = _relax(cand, 120, None)
        if _feasible(cand):
            v = _score(cand)
            if v > bestv:
                bestv = v
                best = cand
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # try a few attempts and return the best feasible layout
    attempts = 6 if n <= 60 else 3
    best = _best_from(n, 12345 + n, attempts)
    if best is None:
        # fallback grid
        k = math.isqrt(n)
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]
