# EVOLVE-BLOCK-START
"""Pack n squares by physical relaxation: grow when feasible, push apart when not.

Each square may rotate.  Overlaps are detected with the Separating Axis Theorem
(SAT) for convex polygons and resolved along the minimum-translation vector.
"""
import math
import random


def _corners(cx, cy, ang, side):
    """Return the 4 corner points of a square (ang in turns)."""
    t = ang * 2.0 * math.pi
    ca = math.cos(t)
    sa = math.sin(t)
    h = side / 2.0
    pts = []
    for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        px = sx * h
        py = sy * h
        pts.append((cx + px * ca - py * sa, cy + px * sa + py * ca))
    return pts


def _axes(pts):
    n = len(pts)
    out = []
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        ex = x2 - x1
        ey = y2 - y1
        L = math.hypot(ex, ey)
        if L > 1e-12:
            out.append((-ey / L, ex / L))
    return out


def _project(pts, ax):
    d = pts[0][0] * ax[0] + pts[0][1] * ax[1]
    mn = mx = d
    for x, y in pts[1:]:
        d = x * ax[0] + y * ax[1]
        if d < mn:
            mn = d
        elif d > mx:
            mx = d
    return mn, mx


def _mtv(pa, pb):
    """Minimum translation vector to separate polygon a from b, or None."""
    best = None
    best_d = float('inf')
    for ax in _axes(pa) + _axes(pb):
        amn, amx = _project(pa, ax)
        bmn, bmx = _project(pb, ax)
        # interval overlap on this axis
        if amx <= bmn or bmx <= amn:
            return None  # separated
        ov = min(amx - bmn, bmx - amn)
        if ov < best_d:
            best_d = ov
            # direction: push a away from b
            ca = (amn + amx) / 2.0
            cb = (bmn + bmx) / 2.0
            sgn = 1.0 if ca < cb else -1.0
            best = (ax[0] * sgn * ov, ax[1] * sgn * ov)
    return best, best_d


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    def poly(s):
        return _corners(s[0], s[1], s[2], s[3])

    def inside(s):
        """True if the rotated square fits in the unit square."""
        pts = poly(s)
        for x, y in pts:
            if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
                return False
        return True

    def fix_inside(s):
        """Shrink side until the rotated square fits inside the unit square."""
        for _ in range(60):
            if inside(s):
                return
            s[3] *= 0.985
            if s[3] < 1e-6:
                s[3] = 0.0
                return
        s[3] = 0.0

    best_sum = -1.0
    best = None
    k0 = math.ceil(math.sqrt(n))

    for trial in range(10):
        random.seed((n * 7919 + trial * 131) & 0x7FFFFFFF)
        sq = []
        for i in range(n):
            r = i // k0
            c = i % k0
            base = 1.0 / (k0 + 0.25)
            ang = random.choice((0.0, 0.0, 0.25))
            sq.append([
                (c + 0.5) / k0 + random.uniform(-0.06, 0.06),
                (r + 0.5) / k0 + random.uniform(-0.06, 0.06),
                ang,
                base * random.uniform(0.7, 1.0),
            ])
        for s in sq:
            fix_inside(s)

        cur_best = -1.0
        cur_cfg = None

        for it in range(2600):
            # find worst overlap
            bad = None
            for i in range(n):
                pa = poly(sq[i])
                for j in range(i + 1, n):
                    res = _mtv(pa, poly(sq[j]))
                    if res is not None:
                        bad = (i, j, res)
                        break
                if bad:
                    break

            if bad is None:
                tot = sum(s[3] for s in sq)
                if tot > cur_best:
                    cur_best = tot
                    cur_cfg = [x[:] for x in sq]
                if tot > best_sum:
                    best_sum = tot
                    best = [x[:] for x in sq]
                grow = 0.006 * (0.5 + 0.5 * random.random())
                for s in sq:
                    s[3] = min(s[3] * (1.0 + grow), 1.0)
                for s in sq:
                    fix_inside(s)
            else:
                i, j, (vec, dist) = bad
                a = sq[i]
                b = sq[j]
                # push apart along mtv, half each
                a[0] -= vec[0] / 2.0
                a[1] -= vec[1] / 2.0
                b[0] += vec[0] / 2.0
                b[1] += vec[1] / 2.0
                # occasionally nudge rotation to escape axis-aligned traps
                if random.random() < 0.02:
                    a[2] = (a[2] + random.uniform(-0.01, 0.01)) % 1.0
                    b[2] = (b[2] + random.uniform(-0.01, 0.01)) % 1.0
                # slight shrink if badly stuck
                if dist > 0.02:
                    a[3] *= 0.999
                    b[3] *= 0.999
                fix_inside(a)
                fix_inside(b)

        # local polish: try to grow each square alone
        if cur_cfg is not None:
            cfg = cur_cfg
            for _round in range(40):
                improved = False
                for i in range(n):
                    save = cfg[i][:]
                    cfg[i][3] *= 1.01
                    fix_inside(cfg[i])
                    # check overlap with others
                    ok = True
                    pa = poly(cfg[i])
                    for j in range(n):
                        if j == i:
                            continue
                        if _mtv(pa, poly(cfg[j])) is not None:
                            ok = False
                            break
                    if ok:
                        improved = True
                    else:
                        cfg[i] = save
                if not improved:
                    break
            tot = sum(s[3] for s in cfg)
            if tot > best_sum:
                best_sum = tot
                best = [x[:] for x in cfg]

    if best is None:
        k = math.isqrt(n) or 1
        side = 1.0 / k
        best = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side) for i in range(n)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))

    out = []
    for x, y, a, s in best[:n]:
        out.append((min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0), a % 1.0, min(max(s, 0.0), 1.0)))
    return out
# EVOLVE-BLOCK-END
