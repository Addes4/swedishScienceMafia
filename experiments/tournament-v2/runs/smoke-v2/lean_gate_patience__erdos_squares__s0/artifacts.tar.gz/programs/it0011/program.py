"""Squares in a square: grow + relax with rotated squares.

Key ideas:
- Valid construction guaranteed: rotated squares are contained using their
  true axis-aligned bounding half-extent; overlaps resolved by SAT MTV pushes.
- Multi-start from structured layouts (grids, spiral, ring) plus random ones.
- Inflation schedule grows all squares; then a per-square polish phase.
- A final repair-and-verify ensures the returned layout is always valid.
"""

import math
import random

TAU = 2.0 * math.pi


# ---------------------------------------------------------------------------
# geometry
# ---------------------------------------------------------------------------

def _axes(a):
    t = a * TAU
    c, s = math.cos(t), math.sin(t)
    return (c, s), (-s, c)


def _half_extents(a, s):
    """Axis-aligned bounding half-extents (hx, hy) of a rotated square."""
    u, v = _axes(a)
    h = 0.5 * s
    return h * (abs(u[0]) + abs(v[0])), h * (abs(u[1]) + abs(v[1]))


def _sat(q1, q2):
    """Return overlap info between two squares.

    Returns (overlap, nx, ny) where overlap>0 means overlapping and (nx,ny)
    is the unit minimum translation vector to push square 2 away from 1.
    """
    x1, y1, a1, s1 = q1
    x2, y2, a2, s2 = q2
    u1, v1 = _axes(a1)
    u2, v2 = _axes(a2)
    h1 = 0.5 * s1
    h2 = 0.5 * s2
    dx = x2 - x1
    dy = y2 - y1

    best = 1e30
    bnx = bny = 0.0
    for (ax, ay), r1, (bx, by), r2 in (
        (u1, h1, u2, h2),
        (v1, h1, u2, h2),
        (u2, h2, u1, h1),
        (v2, h2, u1, h1),
    ):
        # projection radius of square on axis
        proj1 = r1 + abs(bx * ax + by * ay) * r2
        # careful: radius1 of the "owning" square plus extent of other
        # Note: caller chose axis from owning square, so r1 is its half-side.
        # We must compute full radius for each square on this axis:
        pass

    for (ax, ay) in (u1, v1, u2, v2):
        d = dx * ax + dy * ay
        ra = h1 * (abs(u1[0] * ax + u1[1] * ay) + abs(v1[0] * ax + v1[1] * ay))
        rb = h2 * (abs(u2[0] * ax + u2[1] * ay) + abs(v2[0] * ax + v2[1] * ay))
        overlap = ra + rb - abs(d)
        if overlap <= 0.0:
            return 0.0, 0.0, 0.0
        if overlap < best:
            best = overlap
            sign = 1.0 if d > 0 else -1.0
            bnx, bny = sign * ax, sign * ay
    return best, bnx, bny


def _overlap(q1, q2):
    return _sat(q1, q2)[0]


def _feasible(sq, eps=1e-9):
    for (x, y, a, s) in sq:
        if s < -eps:
            return False
        hx, hy = _half_extents(a, max(s, 0.0))
        if x < hx - eps or x > 1.0 - hx + eps:
            return False
        if y < hy - eps or y > 1.0 - hy + eps:
            return False
    n = len(sq)
    for i in range(n):
        xi, yi, ai, si = sq[i]
        if si <= 0:
            continue
        hxi, hyi = _half_extents(ai, si)
        for j in range(i + 1, n):
            xj, yj, aj, sj = sq[j]
            if sj <= 0:
                continue
            hxj, hyj = _half_extents(aj, sj)
            if xi + hxi < xj - hxj or xj + hxj < xi - hxi:
                continue
            if yi + hyi < yj - hyj or yj + hyj < yi - hyi:
                continue
            if _overlap(sq[i], sq[j]) > 1e-7:
                return False
    return True


def _clamp_in(p):
    x, y, a, s = p
    hx, hy = _half_extents(a, max(s, 0.0))
    x = min(max(x, hx), 1.0 - hx) if hx <= 0.5 else 0.5
    y = min(max(y, hy), 1.0 - hy) if hy <= 0.5 else 0.5
    return (x, y, a, s)


# ---------------------------------------------------------------------------
# relaxation
# ---------------------------------------------------------------------------

def _relax(sq, steps, grow=None, lr=0.5):
    n = len(sq)
    if n == 0:
        return sq
    pos = [[p[0], p[1]] for p in sq]
    ang = [p[2] for p in sq]
    siz = [p[3] for p in sq]

    for it in range(steps):
        if grow is not None:
            t = (it + 1) / steps
            for i in range(n):
                siz[i] += (grow[i] - siz[i]) * (3.0 / steps)

        fx = [0.0] * n
        fy = [0.0] * n
        for i in range(n):
            xi, yi = pos[i]
            ai, si = ang[i], siz[i]
            if si <= 0:
                continue
            hxi, hyi = _half_extents(ai, si)
            for j in range(i + 1, n):
                sj = siz[j]
                if sj <= 0:
                    continue
                xj, yj = pos[j]
                hxj, hyj = _half_extents(ang[j], sj)
                if xi + hxi < xj - hxj or xj + hxj < xi - hxi:
                    continue
                if yi + hyi < yj - hyj or yj + hyj < yi - hyi:
                    continue
                ov, nx, ny = _sat((xi, yi, ai, si), (xj, yj, ang[j], sj))
                if ov <= 0:
                    continue
                f = ov * 40.0
                fx[i] -= nx * f
                fy[i] -= ny * f
                fx[j] += nx * f
                fy[j] += ny * f

        for i in range(n):
            hx, hy = _half_extents(ang[i], max(siz[i], 0.0))
            lo, hi = hx, 1.0 - hx
            if lo > hi:
                lo = hi = 0.5
            if pos[i][0] < lo:
                fx[i] += (lo - pos[i][0]) * 300.0
            elif pos[i][0] > hi:
                fx[i] -= (pos[i][0] - hi) * 300.0
            lo, hi = hy, 1.0 - hy
            if lo > hi:
                lo = hi = 0.5
            if pos[i][1] < lo:
                fy[i] += (lo - pos[i][1]) * 300.0
            elif pos[i][1] > hi:
                fy[i] -= (pos[i][1] - hi) * 300.0

        for i in range(n):
            pos[i][0] += fx[i] * lr
            pos[i][1] += fy[i] * lr
            hx, hy = _half_extents(ang[i], max(siz[i], 0.0))
            pos[i][0] = min(max(pos[i][0], hx), 1.0 - hx) if hx <= 0.5 else 0.5
            pos[i][1] = min(max(pos[i][1], hy), 1.0 - hy) if hy <= 0.5 else 0.5

    return [(pos[i][0], pos[i][1], ang[i], siz[i]) for i in range(n)]


def _resolve(sq, steps=60):
    """Just resolve overlaps without growing."""
    return _relax(sq, steps, None)


def _shrink_feasible(sq):
    """Scale all sides down until feasible."""
    sq = [_clamp_in(p) for p in sq]
    if _feasible(sq):
        return sq
    for _ in range(80):
        sq = [(x, y, a, s * 0.98) for (x, y, a, s) in sq]
        sq = _resolve(sq, 10)
        sq = [_clamp_in(p) for p in sq]
        if _feasible(sq):
            return sq
    return sq


# ---------------------------------------------------------------------------
# growth
# ---------------------------------------------------------------------------

def _grow_all(sq, target, rounds=6):
    """Grow every square toward target side, relaxing between rounds."""
    cur = [p[3] for p in sq]
    for r in range(rounds):
        grow = [max(cur[i], target) for i in range(len(sq))]
        sq = _relax(sq, 80, grow, lr=0.4)
        cur = [p[3] for p in sq]
        if _feasible(sq):
            sq = _resolve(sq, 20)
        else:
            sq = _shrink_feasible(sq)
    return sq


def _polish(sq, passes=3):
    """Grow each square individually to its max feasible size."""
    n = len(sq)
    sq = [list(p) for p in sq]

    for _ in range(passes):
        order = list(range(n))
        random.shuffle(order)
        for i in order:
            # binary search the max size for square i
            x, y, a, s0 = sq[i]
            lo, hi = s0, 1.0
            # quick feasibility test
            def ok(s):
                if s <= 0:
                    return True
                hx, hy = _half_extents(a, s)
                if hx > 0.5 or hy > 0.5:
                    return False
                if x < hx or x > 1.0 - hx or y < hy or y > 1.0 - hy:
                    return False
                qi = (x, y, a, s)
                for j in range(n):
                    if j == i:
                        continue
                    if sq[j][3] <= 0:
                        continue
                    if _overlap(qi, tuple(sq[j])) > 1e-9:
                        return False
                return True

            if not ok(hi):
                for _ in range(40):
                    mid = 0.5 * (lo + hi)
                    if ok(mid):
                        lo = mid
                    else:
                        hi = mid
            else:
                lo = hi
            sq[i] = [x, y, a, lo]

        # relax a bit then re-clamp
        sq = [tuple(p) for p in _resolve(sq, 40)]
        sq = [_clamp_in(p) for p in sq]
        if not _feasible(sq):
            sq = _shrink_feasible(sq)
        sq = [list(p) for p in sq]

    return [tuple(p) for p in sq]


# ---------------------------------------------------------------------------
# initial layouts
# ---------------------------------------------------------------------------

def _init_grid(n, cols, angle=0.0, jitter=0.0, rng=None):
    sq = []
    rows = int(math.ceil(n / cols))
    cell = 1.0 / max(cols, rows)
    s = cell * 0.9
    k = 0
    for r in range(rows):
        for c in range(cols):
            if k >= n:
                break
            cx = (c + 0.5) * (1.0 / cols)
            cy = (r + 0.5) * (1.0 / rows)
            a = angle
            if jitter and rng:
                cx += (rng.random() - 0.5) * jitter * cell
                cy += (rng.random() - 0.5) * jitter * cell
                a = (angle + (rng.random() - 0.5) * jitter) % 1.0
            sq.append((cx, cy, a, s))
            k += 1
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq[:n]


def _init_random(n, rng):
    k = max(1, int(math.ceil(math.sqrt(n))))
    s = 1.0 / k
    sq = []
    for _ in range(n):
        sq.append((rng.random(), rng.random(), rng.random(), s * rng.uniform(0.2, 1.0)))
    return sq


def _try_layout(init, n):
    sq = [tuple(p) for p in init]
    sq = [_clamp_in(p) for p in sq]
    sq = _resolve(sq, 40)

    # grow phase
    target = 1.0 / max(1.0, math.sqrt(n))
    sq = _grow_all(sq, target * 1.6, rounds=8)

    # polish
    if _feasible(sq):
        sq = _polish(sq, passes=4)

    if not _feasible(sq):
        sq = _shrink_feasible(sq)

    if not _feasible(sq):
        return None
    return sq


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    rng = random.Random(9871 + n)
    best = None
    bestv = -1.0

    inits = []
    # structured grids at a few column counts and angles
    for cols in range(1, int(math.ceil(math.sqrt(n))) + 3):
        inits.append(_init_grid(n, cols, 0.0))
        inits.append(_init_grid(n, cols, 0.25))
    # random
    for _ in range(4):
        inits.append(_init_random(n, rng))

    for init in inits:
        try:
            cand = _try_layout(init, n)
        except Exception:
            cand = None
        if cand is None:
            continue
        if _feasible(cand):
            v = sum(max(0.0, p[3]) for p in cand)
            if v > bestv:
                bestv = v
                best = cand

    if best is None:
        # trivial feasible fallback: grid of small AABB squares
        k = int(math.ceil(math.sqrt(n)))
        s = 0.9 / k
        best = []
        idx = 0
        for r in range(k):
            for c in range(k):
                if idx >= n:
                    break
                best.append(((c + 0.5) / k, (r + 0.5) / k, 0.0, s))
                idx += 1
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))
        best = best[:n]

    # FINAL safety: guarantee validity
    best = [_clamp_in(p) for p in best]
    if not _feasible(best):
        best = _shrink_feasible(best)
    return best
