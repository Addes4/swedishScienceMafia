"""Packing unit square with n possibly-rotated squares, maximising sum of sides.

Strategy:
  * multi-start local search.
  * each start: place squares (axis-aligned grid / random / mixed).
  * iterative phase: try to grow every square by a small factor, then run a
    SAT-based overlap resolver that pushes overlapping pairs apart along their
    minimum-translation vector; if the layout stays infeasible, shrink the
    offending squares and retry.
  * final hard repair so every output is guaranteed valid.
"""

import math
import random

TWO_PI = 2.0 * math.pi


# ---------------------------------------------------------------- geometry

def _axes(a):
    t = a * TWO_PI
    c, s = math.cos(t), math.sin(t)
    return (c, s), (-s, c)


def _corners(cx, cy, a, s):
    (ux, uy), (vx, vy) = _axes(a)
    h = 0.5 * s
    return (
        (cx + h * (ux + vx), cy + h * (uy + vy)),
        (cx + h * (ux - vx), cy + h * (uy - vy)),
        (cx + h * (-ux - vx), cy + h * (-uy - vy)),
        (cx + h * (-ux + vx), cy + h * (-uy + vy)),
    )


def _sat_mtv(q1, q2):
    """Minimum translation vector (as (mx,my) applied to q1 to separate it
    from q2, negative = q1 should move by (mx,my)) plus penetration depth.

    Returns (mx, my, depth) where depth >= 0 means overlapping; the vector
    (mx,my) has length `depth` and points from q2 to q1 (i.e. moving q1 by
    +(...)*? actually moving q1 by (mx,my) with positive depth separates).
    """
    (c1x, c1y, a1, s1) = q1
    (c2x, c2y, a2, s2) = q2
    u1, v1 = _axes(a1)
    u2, v2 = _axes(a2)
    dx = c1x - c2x
    dy = c1y - c2y
    best_depth = 1e18
    best_axis = (1.0, 0.0)
    for (ux, uy), half1, (ox, oy), half2 in (
        (u1, 0.5 * s1, u2, 0.5 * s2),
        (v1, 0.5 * s1, v2, 0.5 * s2),
        (u2, 0.5 * s2, u1, 0.5 * s1),
        (v2, 0.5 * s2, v1, 0.5 * s1),
    ):
        # projection of centre-diff on axis
        d = dx * ux + dy * uy
        # half-extent of q1 and q2 along this axis
        e1 = abs(ux * u1[0] + uy * u1[1]) * (0.5 * s1) + \
             abs(ux * v1[0] + uy * v1[1]) * (0.5 * s1)
        e2 = abs(ux * u2[0] + uy * u2[1]) * (0.5 * s2) + \
             abs(ux * v2[0] + uy * v2[1]) * (0.5 * s2)
        pen = e1 + e2 - abs(d)
        if pen <= 0.0:
            return (0.0, 0.0, -pen if pen < 0 else 0.0)  # separated
        if pen < best_depth:
            best_depth = pen
            sign = 1.0 if d >= 0.0 else -1.0
            best_axis = (sign * ux, sign * uy)
    mx = best_axis[0] * best_depth
    my = best_axis[1] * best_depth
    return (mx, my, best_depth)


def _overlap_depth(q1, q2):
    """Return overlap depth (>=0) or -1 if separated."""
    (c1x, c1y, a1, s1) = q1
    (c2x, c2y, a2, s2) = q2
    u1, v1 = _axes(a1)
    u2, v2 = _axes(a2)
    dx = c2x - c1x
    dy = c2y - c1y
    best = 1e18
    for (ux, uy), hs in ((u1[0], u1[1], 0.5 * s1), (v1[0], v1[1], 0.5 * s1),
                          (u2[0], u2[1], 0.5 * s2), (v2[0], v2[1], 0.5 * s2)):
        d = abs(dx * ux + dy * uy)
        proj = (abs(u2[0] * ux + u2[1] * uy) + abs(v2[0] * ux + v2[1] * uy)) * 0.5 * s2 \
            if (ux, uy) in ((u1[0], u1[1]), (v1[0], v1[1])) else \
            (abs(u1[0] * ux + u1[1] * uy) + abs(v1[0] * ux + v1[1] * uy)) * 0.5 * s1
        gap = d - (hs + proj)
        if gap > best and best != 1e18:
            pass
        if gap > 0.0:
            return -1.0
    # recompute properly (simpler, correct)
    best = 1e18
    for ax in ((u1[0], u1[1]), (v1[0], v1[1]), (u2[0], u2[1]), (v2[0], v2[1])):
        ux, uy = ax
        e1 = (abs(u1[0] * ux + u1[1] * uy) + abs(v1[0] * ux + v1[1] * uy)) * 0.5 * s1
        e2 = (abs(u2[0] * ux + u2[1] * uy) + abs(v2[0] * ux + v2[1] * uy)) * 0.5 * s2
        d = abs(dx * ux + dy * uy)
        pen = e1 + e2 - d
        if pen <= 0.0:
            return -1.0
        if pen < best:
            best = pen
    return best


def _half_diag(s):
    return 0.5 * s * math.sqrt(2.0)


def _clamp_walls(q):
    """Return a copy of q clamped so its bounding circle stays in the unit
    square.  If the square is too big to fit (s > sqrt(2)/2) we shrink it."""
    cx, cy, a, s = q
    if s < 0.0:
        s = 0.0
    r = _half_diag(s)
    if r > 0.5:
        r = 0.5
        s = r / (0.5 * math.sqrt(2.0))
    if cx < r:
        cx = r
    elif cx > 1.0 - r:
        cx = 1.0 - r
    if cy < r:
        cy = r
    elif cy > 1.0 - r:
        cy = 1.0 - r
    if cx < 0.5:
        cx = max(r, min(cx, 0.5))
    if cy < 0.5:
        cy = max(r, min(cy, 0.5))
    # if r made 1-2r < 0 it can't happen after shrink; ensure
    if cx < r:
        cx = r
    if cx > 1.0 - r:
        cx = 1.0 - r
    if cy < r:
        cy = r
    if cy > 1.0 - r:
        cy = 1.0 - r
    return (cx, cy, a, s)


def _feasible(sq, eps=1e-9):
    for i in range(len(sq)):
        cx, cy, a, s = sq[i]
        if s < -1e-12:
            return False
        r = _half_diag(s)
        if cx < r - eps or cx > 1.0 - r + eps:
            return False
        if cy < r - eps or cy > 1.0 - r + eps:
            return False
        for j in range(i + 1, len(sq)):
            if _overlap_depth(sq[i], sq[j]) > 1e-9:
                return False
    return True


# ---------------------------------------------------------------- solver

def _resolve(squares, iters, grow_mask=None, grow_amt=1.02, rot_perturb=0.0):
    """Iteratively grow & push apart.  Returns a list of quads."""
    n = len(squares)
    cx = [q[0] for q in squares]
    cy = [q[1] for q in squares]
    aa = [q[2] for q in squares]
    ss = [q[3] for q in squares]

    for it in range(iters):
        # grow a bit
        if grow_mask is not None:
            for i in range(n):
                if grow_mask[i]:
                    ss[i] *= grow_amt
        # random rotation perturbation
        if rot_perturb > 0.0:
            for i in range(n):
                aa[i] += (random.random() - 0.5) * rot_perturb

        # resolve overlaps
        for _ in range(40):
            moved = False
            for i in range(n):
                for j in range(i + 1, n):
                    si = ss[i]; sj = ss[j]
                    if si <= 0 or sj <= 0:
                        continue
                    # bounding circle cull
                    rsum = _half_diag(si) + _half_diag(sj)
                    ddx = cx[j] - cx[i]; ddy = cy[j] - cy[i]
                    if ddx * ddx + ddy * ddy > rsum * rsum:
                        continue
                    mx, my, depth = _sat_mtv(
                        (cx[i], cy[i], aa[i], si),
                        (cx[j], cy[j], aa[j], sj))
                    if depth <= 1e-12:
                        continue
                    # move both apart (mx,my is displacement for i to separate)
                    half = 0.5 * depth + 1e-12
                    ux = mx / depth if depth > 0 else 0.0
                    uy = my / depth if depth > 0 else 0.0
                    cx[i] -= ux * half
                    cy[i] -= uy * half
                    cx[j] += ux * half
                    cy[j] += uy * half
                    moved = True
            if not moved:
                break

        # wall clamp
        for i in range(n):
            r = _half_diag(ss[i])
            if r > 0.5:
                r = 0.5
                ss[i] = r / (0.5 * math.sqrt(2.0))
            if cx[i] < r: cx[i] = r
            elif cx[i] > 1.0 - r: cx[i] = 1.0 - r
            if cy[i] < r: cy[i] = r
            elif cy[i] > 1.0 - r: cy[i] = 1.0 - r

    return [(cx[i], cy[i], aa[i], ss[i]) for i in range(n)]


def _repair(squares):
    """Ensure feasibility: repeatedly push overlaps apart and shrink the
    offending squares."""
    n = len(squares)
    cx = [q[0] for q in squares]
    cy = [q[1] for q in squares]
    aa = [q[2] for q in squares]
    ss = [max(0.0, q[3]) for q in squares]

    for _ in range(400):
        # wall clamp
        for i in range(n):
            r = _half_diag(ss[i])
            while r > 0.5:
                ss[i] *= 0.98
                r = _half_diag(ss[i])
            if cx[i] < r: cx[i] = r
            elif cx[i] > 1.0 - r: cx[i] = 1.0 - r
            if cy[i] < r: cy[i] = r
            elif cy[i] > 1.0 - r: cy[i] = 1.0 - r
        # overlap
        worst = 0.0
        for i in range(n):
            for j in range(i + 1, n):
                if ss[i] <= 0 or ss[j] <= 0:
                    continue
                mx, my, depth = _sat_mtv(
                    (cx[i], cy[i], aa[i], ss[i]),
                    (cx[j], cy[j], aa[j], ss[j]))
                if depth <= 1e-9:
                    continue
                worst = max(worst, depth)
                ux = mx / depth; uy = my / depth
                tolm = 1e-9
                excess = depth + 4 * tolm
                half = 0.5 * excess
                cx[i] -= ux * half
                cy[i] -= uy * half
                cx[j] += ux * half
                cy[j] += uy * half
        if worst < 1e-7:
            return [(cx[i], cy[i], aa[i], ss[i]) for i in range(n)]
    # last resort: shrink every square a hair and clamp
    out = []
    for i in range(n):
        s = ss[i]
        for _ in range(50):
            ok = True
            r = _half_diag(s)
            x = min(max(cx[i], r), 1.0 - r)
            y = min(max(cy[i], r), 1.0 - r)
            for j in range(n):
                if j == i or ss[j] <= 0:
                    continue
                _, _, d = _sat_mtv((x, y, aa[i], s),
                                    (cx[j], cy[j], aa[j], ss[j]))
                if d > 1e-9:
                    ok = False
                    break
            if ok:
                out.append((x, y, aa[i], s))
                break
            s *= 0.95
        else:
            out.append((0.5, 0.5, aa[i], 0.0))
    return out


def _score(sq):
    return sum(max(0.0, q[3]) for q in sq)


def _improve_individual(sq, passes=3):
    """Greedy per-square growth polish."""
    sq = [list(q) for q in sq]
    n = len(sq)
    for _ in range(passes):
        for i in range(n):
            # try to grow square i
            old = sq[i][3]
            lo, hi = old, 1.0
            best = old
            for _ in range(18):
                mid = 0.5 * (lo + hi)
                sq[i][3] = mid
                # clamp walls
                r = _half_diag(mid)
                sq[i][0] = min(max(sq[i][0], r), 1.0 - r)
                sq[i][1] = min(max(sq[i][1], r), 1.0 - r)
                ok = True
                for j in range(n):
                    if j == i or sq[j][3] <= 0:
                        continue
                    _, _, d = _sat_mtv(tuple(sq[i]), tuple(sq[j]))
                    if d > 1e-9:
                        ok = False
                        break
                if ok:
                    best = mid
                    lo = mid
                else:
                    hi = mid
            sq[i][3] = best
            r = _half_diag(best)
            sq[i][0] = min(max(sq[i][0], r), 1.0 - r)
            sq[i][1] = min(max(sq[i][1], r), 1.0 - r)
    return [tuple(q) for q in sq]


def _start_grid(n, rng, jitter=0.0):
    cols = int(math.ceil(math.sqrt(n)))
    rows = int(math.ceil(n / cols))
    s = 1.0 / max(cols, rows)
    sq = []
    for idx in range(n):
        r = idx // cols
        c = idx % cols
        cx = (c + 0.5) * s
        cy = (r + 0.5) * s
        if jitter > 0:
            cx += (rng.random() - 0.5) * jitter * s
            cy += (rng.random() - 0.5) * jitter * s
        sq.append((cx, cy, 0.0, s * 0.999))
    return sq


def _start_random(n, rng):
    sq = []
    for _ in range(n):
        cx = rng.random()
        cy = rng.random()
        a = rng.random()
        s = rng.uniform(0.01, 0.35)
        sq.append((cx, cy, a, s))
    return sq


def _try(n, seed):
    rng = random.Random(seed)
    best = None
    bestv = -1.0
    starts = []
    # several grid-based starts with different jitter
    for jf in (0.0, 0.15, 0.3):
        starts.append(_start_grid(n, rng, jf))
    # a few random starts
    for _ in range(3):
        starts.append(_start_random(n, rng))

    for st in starts:
        cur = _repair(st)
        # main grow loop
        for _ in range(6):
            mask = [True] * n
            cand = _resolve(cur, 8, grow_mask=mask, grow_amt=1.05,
                            rot_perturb=0.01)
            cand = _repair(cand)
            cur = cand
        cur = _improve_individual(cur, passes=2)
        cur = _repair(cur)
        if _feasible(cur):
            v = _score(cur)
            if v > bestv:
                bestv = v
                best = cur
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    bestv = -1.0
    trials = 5 if n <= 30 else 3
    for t in range(trials):
        sq = _try(n, 1000 + n * 37 + t * 911)
        if sq is not None and _feasible(sq):
            v = _score(sq)
            if v > bestv:
                bestv = v
                best = sq

    if best is None:
        # safe fallback: axis-aligned grid, shrink to guarantee fit
        k = int(math.ceil(math.sqrt(n)))
        s = 1.0 / k
        sq = []
        for idx in range(n):
            r = idx // k
            c = idx % k
            sq.append(((c + 0.5) * s, (r + 0.5) * s, 0.0, s))
        sq = _repair(sq)
        best = sq

    # final safety clamp
    out = []
    for cx, cy, a, s in best:
        if s < 0:
            s = 0.0
        r = _half_diag(s)
        if r > 0.5:
            s = 0.5 / (0.5 * math.sqrt(2.0))
            r = 0.5
        cx = min(max(cx, r), 1.0 - r)
        cy = min(max(cy, r), 1.0 - r)
        out.append((cx, cy, a % 1.0, s))
    return out[:n]
