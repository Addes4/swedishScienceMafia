import math
import random


def _corners(cx, cy, ang, s):
    h = s * 0.5
    a = ang * 2.0 * math.pi
    ca = math.cos(a)
    sa = math.sin(a)
    out = []
    for dx, dy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        x = dx * h
        y = dy * h
        out.append((cx + ca * x - sa * y, cy + sa * x + ca * y))
    return out


def _mtv(a, b):
    """Return (depth, dirx, diry) minimal translation pushing b away from a, or None."""
    best = None
    for poly in (a, b):
        for i in range(4):
            p1 = poly[i]
            p2 = poly[(i + 1) & 3]
            ax = -(p2[1] - p1[1])
            ay = p2[0] - p1[0]
            L = math.hypot(ax, ay)
            if L < 1e-12:
                continue
            ax /= L
            ay /= L
            d = a[0][0] * ax + a[0][1] * ay
            amin = amax = d
            for p in a[1:]:
                d = p[0] * ax + p[1] * ay
                if d < amin:
                    amin = d
                elif d > amax:
                    amax = d
            d = b[0][0] * ax + b[0][1] * ay
            bmin = bmax = d
            for p in b[1:]:
                d = p[0] * ax + p[1] * ay
                if d < bmin:
                    bmin = d
                elif d > bmax:
                    bmax = d
            o1 = amax - bmin
            o2 = bmax - amin
            if o1 <= 0.0 or o2 <= 0.0:
                return None
            depth = o1 if o1 < o2 else o2
            if best is None or depth < best[0]:
                sgn = 1.0 if o1 < o2 else -1.0
                best = (depth, ax * sgn, ay * sgn)
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    SQ2H = 0.5 * math.sqrt(2.0)

    def clamp(q):
        rad = q[3] * SQ2H
        if q[0] < rad:
            q[0] = rad
        elif q[0] > 1.0 - rad:
            q[0] = 1.0 - rad
        if q[1] < rad:
            q[1] = rad
        elif q[1] > 1.0 - rad:
            q[1] = 1.0 - rad

    best_sum = -1.0
    best = None

    trials = 6 if n <= 20 else 4
    iters = 700 if n <= 8 else (500 if n <= 16 else 300)

    for trial in range(trials):
        random.seed((n * 104729 + trial) & 0x7FFFFFFF)
        k = max(1, int(math.ceil(math.sqrt(n))))
        sq = []
        for i in range(n):
            r = i // k
            c = i % k
            cx = (c + 0.5) / k + random.uniform(-0.05, 0.05)
            cy = (r + 0.5) / k + random.uniform(-0.05, 0.05)
            ang = random.random()
            s = (1.0 / k) * random.uniform(0.7, 0.95)
            sq.append([cx, cy, ang, s])
            clamp(sq[-1])

        for it in range(iters):
            C = [_corners(q[0], q[1], q[2], q[3]) for q in sq]
            overl = False
            for i in range(n):
                ci = C[i]
                for j in range(i + 1, n):
                    if _mtv(ci, C[j]) is not None:
                        overl = True
                        break
                if overl:
                    break

            if not overl:
                tot = 0.0
                for q in sq:
                    tot += q[3]
                if tot > best_sum:
                    best_sum = tot
                    best = [q[:] for q in sq]
                for q in sq:
                    q[3] = min(q[3] * 1.012, 1.0)
            else:
                for _ in range(3):
                    C = [_corners(q[0], q[1], q[2], q[3]) for q in sq]
                    for i in range(n):
                        ci = C[i]
                        for j in range(i + 1, n):
                            m = _mtv(ci, C[j])
                            if m is not None:
                                d, ax, ay = m
                                p = d * 0.5 + 1e-9
                                sq[i][0] -= ax * p
                                sq[i][1] -= ay * p
                                sq[j][0] += ax * p
                                sq[j][1] += ay * p
                    for q in sq:
                        clamp(q)

                C = [_corners(q[0], q[1], q[2], q[3]) for q in sq]
                still = False
                for i in range(n):
                    ci = C[i]
                    for j in range(i + 1, n):
                        if _mtv(ci, C[j]) is not None:
                            still = True
                            break
                    if still:
                        break
                if still:
                    for q in sq:
                        q[3] *= 0.985

            for q in sq:
                clamp(q)

    if best is None:
        k = max(1, int(math.isqrt(n)))
        side = 1.0 / k
        best = []
        for i in range(n):
            best.append([(i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side])
        while len(best) < n:
            best.append([0.5, 0.5, 0.0, 0.0])

    out = []
    for q in best[:n]:
        cx = min(max(q[0], 0.0), 1.0)
        cy = min(max(q[1], 0.0), 1.0)
        ang = q[2] % 1.0
        s = min(max(q[3], 0.0), 1.0)
        out.append((cx, cy, ang, s))
    return out
