# Research notebook: erdos_squares

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.856172.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Use a simulated annealing optimizer that starts from the current grid solution, then perturbs square positions, sizes, and angles, accepting moves that increase | 0.66 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.856172 |
| 5 | Use a physics-inspired "circle packing" relaxation: approximate squares by their inscribed circles for an initial layout, then expand them back to squares while | 0.52 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.783235 |
| 3 | Formulate the problem as a nonlinear constrained optimization and use a sequential quadratic programming (SQP) solver with the sum of sides as objective and non | 0.51 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | improved | 0.923389 |
| 0 | Replace the grid packing with a greedy algorithm that places squares in descending size order, trying random positions and rotations and keeping the first place | 0.50 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.653996 |
| 4 | Construct a set of "compound" configurations for small n (e.g., one large tilted square surrounded by smaller squares) that are known to be optimal for n<=20, t | 0.49 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.111111 |
| 2 | Implement a "strip packing" heuristic: sort squares by side length, then pack them into horizontal strips of varying heights, allowing 45-degree rotations to fi | 0.41 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Promotion: deepseek-ai/DeepSeek-V4.1-Flash:deepinfra found an improvement; deepseek-ai/DeepSeek-V4-Pro:deepinfra refined it -> api_error (0.000000).

Best after round 1: **0.923389** (spent $0.02)

