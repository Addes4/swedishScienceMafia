import math
import random
import numpy as np

def _corners(x, y, angle, side):
    """Return the 4 corners of the square in counterclockwise order."""
    # half-side
    h = side / 2.0
    # rotation matrix
    c = math.cos(angle * 2 * math.pi)
    s = math.sin(angle * 2 * math.pi)
    # local corners: (±h, ±h) rotated
    corners = []
    for dx, dy in [(-h, -h), (h, -h), (h, h), (-h, h)]:
        rx = x + c * dx - s * dy
        ry = y + s * dx + c * dy
        corners.append((rx, ry))
    return corners

def _separating_axis_polygons(poly1, poly2):
    """Check if two convex polygons overlap using separating axis theorem.
    poly1, poly2: list of (x,y) vertices in CCW order."""
    def edges(poly):
        n = len(poly)
        for i in range(n):
            p1 = poly[i]
            p2 = poly[(i+1)%n]
            ex = p2[0] - p1[0]
            ey = p2[1] - p1[1]
            # perpendicular = (-ey, ex)
            yield (-ey, ex)

    def project(poly, axis_x, axis_y):
        dots = [p[0]*axis_x + p[1]*axis_y for p in poly]
        return min(dots), max(dots)

    for axis in list(edges(poly1)) + list(edges(poly2)):
        ax, ay = axis
        min1, max1 = project(poly1, ax, ay)
        min2, max2 = project(poly2, ax, ay)
        if max1 < min2 - 1e-12 or max2 < min1 - 1e-12:
            return False  # separating axis found
    return True  # overlapping

def _overlap(sq1, sq2):
    """Return True if squares sq1 and sq2 overlap (interiors intersect)."""
    poly1 = _corners(*sq1)
    poly2 = _corners(*sq2)
    # First check: if any corner of one is inside the other, they overlap.
    # A rigorous SAT works for convex polygons, but squares are convex.
    return _separating_axis_polygons(poly1, poly2)

def _total_side(squares):
    return sum(s[3] for s in squares)

def _clip_square(x, y, angle, side, margin=0.0):
    """Ensure square fits within [margin, 1-margin] x [margin, 1-margin]."""
    corners = _corners(x, y, angle, side)
    min_x = min(c[0] for c in corners)
    max_x = max(c[0] for c in corners)
    min_y = min(c[1] for c in corners)
    max_y = max(c[1] for c in corners)
    if min_x < margin or max_x > 1 - margin or min_y < margin or max_y > 1 - margin:
        # Shift toward center to fit
        shift_x = 0.0
        shift_y = 0.0
        if min_x < margin:
            shift_x = margin - min_x
        elif max_x > 1 - margin:
            shift_x = (1 - margin) - max_x
        if min_y < margin:
            shift_y = margin - min_y
        elif max_y > 1 - margin:
            shift_y = (1 - margin) - max_y
        x += shift_x
        y += shift_y
    return x, y

def solve(n):
    # Initial solution: largest k x k grid that fits, plus zero-size squares
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            x = (i + 0.5) * side
            y = (j + 0.5) * side
            squares.append((x, y, 0.0, side))
    # pad with zero-size squares
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]

    if n <= 4:
        # Grid already optimal for small n (n=1..4)
        return squares

    # Simulated annealing parameters
    T_start = 0.01
    T_end = 1e-6
    steps = 20000
    random.seed(42)
    np.random.seed(42)

    current = [list(sq) for sq in squares]
    current_sum = _total_side(current)
    best = [list(sq) for sq in current]
    best_sum = current_sum

    def is_valid_state(sqs):
        """Check no overlaps and all inside [0,1]^2 (touching allowed)."""
        for i, sq in enumerate(sqs):
            x, y, a, s = sq
            corners = _corners(x, y, a, s)
            for cx, cy in corners:
                if not (-1e-9 <= cx <= 1+1e-9 and -1e-9 <= cy <= 1+1e-9):
                    return False
        for i in range(len(sqs)):
            for j in range(i+1, len(sqs)):
                if sqs[i][3] > 0 and sqs[j][3] > 0 and _overlap(sqs[i], sqs[j]):
                    return False
        return True

    for step in range(steps):
        T = T_start * (T_end / T_start) ** (step / steps)
        idx = random.randrange(n)
        old_sq = current[idx]
        x, y, a, s = old_sq

        # Generate neighbor
        scale = 0.05 * (1 + T * 100)
        new_x = x + np.random.normal(0, scale)
        new_y = y + np.random.normal(0, scale)
        new_a = a + np.random.normal(0, scale * 0.5)
        new_s = s + np.random.normal(0, scale)
        new_s = max(0.0, min(1.0, new_s))  # side within [0,1]
        new_x = max(0.0, min(1.0, new_x))
        new_y = max(0.0, min(1.0, new_y))
        new_a = new_a % 1.0

        new_sq = [new_x, new_y, new_a, new_s]

        # Temporarily apply
        current[idx] = new_sq

        if is_valid_state(current):
            new_sum = _total_side(current)
            delta = new_sum - current_sum
            if delta > 0 or random.random() < math.exp(delta / (T+1e-12)):
                # Accept
                current_sum = new_sum
                if current_sum > best_sum:
                    best = [list(sq) for sq in current]
                    best_sum = current_sum
            else:
                # Reject
                current[idx] = old_sq
        else:
            # Revert
            current[idx] = old_sq

    # Ensure all within [0,1] precisely
    result = []
    for x, y, a, s in best:
        x = max(0.0, min(1.0, x))
        y = max(0.0, min(1.0, y))
        a = a % 1.0
        s = max(0.0, min(1.0, s))
        result.append((x, y, a, s))
    return result
