# EVOLVE-BLOCK-START
"""Greedy randomised packing: place squares in descending size order, trying random
positions/rotations, keeping the first non-overlapping placement.  Repeat with many
random seeds and keep the best total.  Sizes are chosen from a few candidate schedules
(geometric decay, uniform, single big square plus remainder grid, etc.)."""

import math
import random


def _corners(cx, cy, ang, s):
    """Return the 4 corner points of a square (centre cx,cy, angle as fraction of a turn, side s)."""
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap(p1, p2):
    """Separating axis test for two convex polygons (lists of points)."""
    for poly in (p1, p2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            # normal
            nx, ny = -ey, ex
            min1 = min2 = None
            for (px, py) in p1:
                d = px * nx + py * ny
                if min1 is None or d < min1:
                    min1 = d
                if min1 is not None and d > (min1 if False else d):
                    pass
            # compute projections properly
            a1 = [px * nx + py * ny for (px, py) in p1]
            a2 = [px * nx + py * ny for (px, py) in p2]
            if max(a1) < min(a2) or max(a2) < min(a1):
                return False
    return True


def _fits(pts, placed):
    for poly in placed:
        if _overlap(pts, poly):
            return False
    return True


def _in_unit(pts):
    for x, y in pts:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _greedy(sizes, rng, tries=220):
    """Greedily place squares with given sizes (descending) using random positions/angles."""
    placed = []
    total = 0.0
    # precompute small candidate angles
    for s in sizes:
        if s <= 0:
            continue
        best = None
        for _ in range(tries):
            ang = rng.choice((0.0, 0.0, 0.0, rng.random(), rng.random(), 0.25, 0.125, 0.375))
            # choose centre so that square is inside unit box
            # bounding half-extent along axes:
            a = ang * 2.0 * math.pi
            c = abs(math.cos(a))
            sn = abs(math.sin(a))
            hx = s * 0.5 * (c + sn)
            if hx >= 0.5:
                continue
            cx = rng.uniform(hx, 1.0 - hx)
            cy = rng.uniform(hx, 1.0 - hx)
            pts = _corners(cx, cy, ang, s)
            if _fits(pts, placed):
                best = pts
                break
        if best is not None:
            placed.append(best)
            total += s
    return total


def _schedules(n):
    """Yield candidate descending size lists."""
    out = []
    # geometric decay family
    for r in (0.85, 0.9, 0.93, 0.95, 0.97):
        sizes = []
        s = 1.0 / math.sqrt(max(1, n)) if n > 0 else 0.0
        # normalise so total roughly fits; try a top size
        top = 1.0
        val = top
        acc = 0.0
        for _ in range(n):
            sizes.append(val)
            acc += val * val
            val *= r
        # scale so sum of areas <= 1
        if acc > 0:
            f = 1.0 / math.sqrt(acc)
            sizes = [min(1.0, x * f) for x in sizes]
        out.append(sizes)
    # one big + remainder grid
    for k in range(1, int(math.sqrt(n)) + 2):
        rem = n - 1
        if rem < 0:
            continue
        g = max(1, math.isqrt(rem)) if rem > 0 else 1
        sub = 1.0 / (g + 1) if rem > 0 else 0.0
        sizes = [1.0] + [sub] * rem
        sizes = sizes[:n]
        while len(sizes) < n:
            sizes.append(0.0)
        out.append(sizes)
    # uniform grid kxk plus epsilon
    for k in range(1, int(math.sqrt(n)) + 2):
        s = 1.0 / k
        sizes = [s] * (k * k) + [0.0] * (n - k * k)
        out.append(sizes)
    # all equal small
    s = 1.0 / math.sqrt(n)
    out.append([s] * n)
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    rng = random.Random(12345)
    best_val = -1.0
    best_out = None
    scheds = _schedules(n)
    # limit number of schedules to keep runtime manageable
    for si, sizes in enumerate(scheds):
        for seed_try in range(3):
            r = random.Random(hash((si, seed_try, n)) & 0xffffffff)
            # build placement and capture result
            placed = []
            total = 0.0
            tries = 180
            for s in sizes:
                if s <= 0:
                    continue
                got = None
                for _ in range(tries):
                    ang = r.choice((0.0, 0.0, 0.0, r.random(), r.random(), 0.25, 0.125, 0.375))
                    a = ang * 2.0 * math.pi
                    cc = abs(math.cos(a))
                    ss = abs(math.sin(a))
                    hx = s * 0.5 * (cc + ss)
                    if hx >= 0.5 + 1e-12:
                        continue
                    cx = r.uniform(hx, 1.0 - hx)
                    cy = r.uniform(hx, 1.0 - hx)
                    pts = _corners(cx, cy, ang, s)
                    if _fits(pts, placed):
                        got = (cx, cy, ang, s, pts)
                        break
                if got is not None:
                    placed.append(got[4])
                    total += got[3]
            if total > best_val:
                # reconstruct tuples
                res = []
                idx = 0
                for s in sizes:
                    if s <= 0:
                        res.append((0.5, 0.5, 0.0, 0.0))
                        continue
                # need to re-run to get positions consistent; instead store separately
                best_val = total
    # Final deterministic-ish run preserving best schedule found: rerun best schedule many times
    # Simpler: just perform a good greedy on the best schedule discovered
    # We stored only value; redo search with stored schedules and pick best result.
    best_out = None
    best_val = -1.0
    for si, sizes in enumerate(scheds):
        for seed_try in range(2):
            r = random.Random((si * 131 + seed_try * 17 + n) & 0xffffffff)
            placed = []
            total = 0.0
            tuples = []
            tries = 160
            for s in sizes:
                if s <= 0:
                    tuples.append((0.5, 0.5, 0.0, 0.0))
                    continue
                got = None
                for _ in range(tries):
                    ang = r.choice((0.0, 0.0, 0.0, r.random(), r.random(), 0.25, 0.125, 0.375))
                    a = ang * 2.0 * math.pi
                    cc = abs(math.cos(a))
                    ss = abs(math.sin(a))
                    hx = s * 0.5 * (cc + ss)
                    if hx >= 0.5 + 1e-12:
                        continue
                    cx = r.uniform(hx, 1.0 - hx)
                    cy = r.uniform(hx, 1.0 - hx)
                    pts = _corners(cx, cy, ang, s)
                    if _fits(pts, placed):
                        got = (cx, cy, ang, s, pts)
                        break
                if got is not None:
                    placed.append(got[4])
                    total += got[3]
                    tuples.append((got[0], got[1], got[2], got[3]))
                else:
                    tuples.append((0.5, 0.5, 0.0, 0.0))
            if total > best_val:
                best_val = total
                best_out = tuples
    if best_out is None:
        # fallback grid
        k = math.isqrt(n)
        side = 1.0 / k
        best_out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                    for i in range(k) for j in range(k)]
        best_out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_out))
    # clamp
    out = []
    for (cx, cy, ang, s) in best_out[:n]:
        out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)),
                    ang % 1.0, min(1.0, max(0.0, s))))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END
