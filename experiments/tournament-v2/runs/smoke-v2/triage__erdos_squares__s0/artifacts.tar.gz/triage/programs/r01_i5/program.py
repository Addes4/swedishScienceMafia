import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint
import math
import time

def pack_circles(n):
    """
    Place n equal circles in the unit square, maximising radius,
    using a penalty/barrier method.
    Returns (centres, radius) with centres (n,2) array.
    """
    # Initial guess: grid of sqrt(n) x sqrt(n)
    k = math.ceil(math.sqrt(n))
    spacing = 1.0 / k
    r0 = spacing / 2.0 * 0.99  # small margin
    xs = []
    for i in range(k):
        for j in range(k):
            if len(xs) >= n:
                break
            xs.append(((i + 0.5) * spacing, (j + 0.5) * spacing))
        if len(xs) >= n:
            break
    
    xs = np.array(xs)
    
    # If n is not a perfect square, we may have extra points; add them near the corners
    if len(xs) < n:
        needed = n - len(xs)
        corners = np.array([[0.2, 0.2], [0.8, 0.2], [0.2, 0.8], [0.8, 0.8]])
        for i in range(needed):
            xs = np.vstack([xs, corners[i % 4] + np.random.randn(2)*0.05])
    
    # Variables: centres (x_i, y_i) and radius r
    def unpack(vars_):
        r = vars_[-1]
        centres = vars_[:-1].reshape((n, 2))
        return centres, r
    
    def objective(vars_):
        _, r = unpack(vars_)
        return -r  # maximise radius
    
    def penalty(vars_):
        """Barrier-like penalty: large when circles overlap or are outside."""
        centres, r = unpack(vars_)
        
        # out of bounds penalty
        out_penalty = 0.0
        for i in range(n):
            x, y = centres[i]
            out_penalty += max(0, r - x) ** 2
            out_penalty += max(0, x + r - 1.0) ** 2
            out_penalty += max(0, r - y) ** 2
            out_penalty += max(0, y + r - 1.0) ** 2
        
        # overlap penalty
        overlap_penalty = 0.0
        for i in range(n):
            for j in range(i+1, n):
                dx = centres[i, 0] - centres[j, 0]
                dy = centres[i, 1] - centres[j, 1]
                dist = math.sqrt(dx*dx + dy*dy)
                min_dist = 2 * r
                if dist < min_dist:
                    overlap_penalty += (min_dist - dist) ** 2
        
        return out_penalty + overlap_penalty
    
    def total_objective(vars_):
        return objective(vars_) + 10.0 * penalty(vars_)
    
    # Initial vars
    v0 = np.concatenate([xs.flatten(), [r0]])
    
    # Bounds
    bounds = Bounds([0.0]* (2*n) + [1e-6], [1.0]* (2*n) + [0.5])
    
    # We'll run a few steps of gradient-based optimisation
    try:
        res = minimize(total_objective, v0, method='L-BFGS-B', 
                      bounds=bounds, options={'maxiter': 200, 'disp': False, 'ftol': 1e-9})
        centres, r = unpack(res.x)
    except:
        centres = xs
        r = r0
    
    # Clamp centres inside feasible region
    centres = np.clip(centres, r, 1.0 - r)
    
    return centres, max(r, 0.01)


def solve(n):
    """
    Physics-inspired circle packing relaxation for squares.
    1) Pack n equal inscribed circles.
    2) Convert to squares with side = sqrt(2)*r (diagonal of square equals 2r for inscribed).
    3) Refine to resolve overlaps using penalty method for squares,
       potentially shrinking some squares.
    4) Return list of (cx, cy, angle, side).
    """
    if n <= 0:
        return []
    
    start_time = time.time()
    time_limit = 55  # seconds, leave margin
    
    # Step 1: pack circles
    centres, r = pack_circles(n)
    
    # Initial squares: inscribed circle -> square side = sqrt(2)*r
    initial_side = math.sqrt(2) * r
    # But we want to maximise sum of sides, so we may enlarge.
    # We'll start with side = initial_side, then try to expand.
    
    # Variables for squares: centres (x,y), angle, side length
    # angles initialised to 0
    angles = np.zeros(n)
    sides = np.full(n, initial_side)
    
    # We'll attempt to maximise sum of sides while keeping squares inside [0,1]^2 and no overlap.
    # Use penalty method for optimisation.
    
    def unpack_vars(vars_):
        # vars: n centres (2n), n angles, n sides => 4n variables
        c = vars_[:2*n].reshape((n, 2))
        a = vars_[2*n:3*n]
        s = vars_[3*n:4*n]
        return c, a, s
    
    def pack_vars(c, a, s):
        return np.concatenate([c.flatten(), a, s])
    
    # Square vertices for overlap detection using separating axis theorem
    def get_vertices(cx, cy, angle, side):
        # angle in turns, so full turn = 1.0
        theta = angle * 2.0 * math.pi
        half = side / 2.0
        # Local vertices (clockwise)
        v_local = np.array([
            [-half, -half],
            [ half, -half],
            [ half,  half],
            [-half,  half]
        ])
        cos_t = math.cos(theta)
        sin_t = math.sin(theta)
        rot = np.array([[cos_t, -sin_t], [sin_t, cos_t]])
        return v_local @ rot.T + np.array([cx, cy])
    
    def squares_overlap(c1, a1, s1, c2, a2, s2):
        """Check if two squares overlap (interior intersection) using SAT."""
        v1 = get_vertices(c1[0], c1[1], a1, s1)
        v2 = get_vertices(c2[0], c2[1], a2, s2)
        
        # Edges of both squares
        for shape_verts in [v1, v2]:
            for i in range(4):
                edge = shape_verts[(i+1)%4] - shape_verts[i]
                if np.linalg.norm(edge) < 1e-12:
                    continue
                # Normal perpendicular to edge
                normal = np.array([-edge[1], edge[0]])
                normal = normal / np.linalg.norm(normal)
                # Project vertices
                proj1 = v1 @ normal
                proj2 = v2 @ normal
                min1, max1 = np.min(proj1), np.max(proj1)
                min2, max2 = np.min(proj2), np.max(proj2)
                if max1 < min2 - 1e-9 or max2 < min1 - 1e-9:
                    return False
        return True
    
    def penalty(vars_):
        c, a, s = unpack_vars(vars_)
        pen = 0.0
        
        # Out of bounds penalty
        for i in range(n):
            verts = get_vertices(c[i,0], c[i,1], a[i], s[i])
            for v in verts:
                pen += max(0, -v[0])**2 + max(0, v[0]-1.0)**2
                pen += max(0, -v[1])**2 + max(0, v[1]-1.0)**2
        
        # Overlap penalty
        for i in range(n):
            for j in range(i+1, n):
                if squares_overlap(c[i], a[i], s[i], c[j], a[j], s[j]):
                    # Estimate overlap depth by shrinking both until no overlap
                    # Quick penalty: distance between centres vs sum of half-diagonals?
                    dist = np.linalg.norm(c[i] - c[j])
                    # Max possible centre distance for overlap avoidance (sum of bounding circle radii)
                    # But squares can be rotated; using bounding circle radius = s * sqrt(2)/2
                    r_i = s[i] * math.sqrt(2) / 2.0
                    r_j = s[j] * math.sqrt(2) / 2.0
                    if dist < r_i + r_j:
                        pen += (r_i + r_j - dist)**2
                    else:
                        # Still overlap? Add constant penalty to force separation
                        pen += 0.01 * (s[i] * s[j])
        return pen
    
    def objective(vars_):
        _, _, s = unpack_vars(vars_)
        return -np.sum(s)  # minimise negative sum -> maximise sum
    
    def total_obj(vars_):
        return objective(vars_) + 100.0 * penalty(vars_)
    
    # Initial variables
    v0 = pack_vars(centres, angles, sides)
    
    # Bounds
    lb_centres = np.zeros(2*n)
    ub_centres = np.ones(2*n)
    lb_angles = np.zeros(n)
    ub_angles = np.ones(n)  # full turn; wrap-around handled implicitly?
    lb_sides = np.full(n, 1e-6)
    ub_sides = np.full(n, 1.0)
    bounds = Bounds(np.concatenate([lb_centres, lb_angles, lb_sides]),
                    np.concatenate([ub_centres, ub_angles, ub_sides]))
    
    # First attempt: quick local optimisation
    try:
        res = minimize(total_obj, v0, method='L-BFGS-B', bounds=bounds,
                      options={'maxiter': 300, 'disp': False, 'ftol': 1e-9})
        c_opt, a_opt, s_opt = unpack_vars(res.x)
    except:
        c_opt, a_opt, s_opt = centres, angles, sides
    
    # If n is small and we have time, try multiple random initial angles for better packing
    if n <= 30 and time.time() - start_time < time_limit * 0.6:
        best_val = -np.sum(s_opt)
        best_vars = pack_vars(c_opt, a_opt, s_opt)
        for trial in range(min(n, 5)):
            angles_rand = np.random.rand(n)  # random angles in [0,1]
            v_init = pack_vars(centres, angles_rand, sides)
            try:
                res2 = minimize(total_obj, v_init, method='L-BFGS-B', bounds=bounds,
                              options={'maxiter': 150, 'disp': False, 'ftol': 1e-9})
                val = total_obj(res2.x)
                if val < total_obj(best_vars):  # we minimise total_obj, lower is better
                    best_vars = res2.x
                    c_opt, a_opt, s_opt = unpack_vars(best_vars)
            except:
                pass
            if time.time() - start_time > time_limit * 0.6:
                break
    
    # Final cleanup: ensure non-overlap by slightly shrinking if needed
    for i in range(n):
        for j in range(i+1, n):
            while squares_overlap(c_opt[i], a_opt[i], s_opt[i], c_opt[j], a_opt[j], s_opt[j]) and s_opt[i] > 1e-6 and s_opt[j] > 1e-6:
                # shrink both proportionally
                s_opt[i] *= 0.99
                s_opt[j] *= 0.99
    
    # Ensure inside unit square by clamping and shrinking if necessary
    for i in range(n):
        verts = get_vertices(c_opt[i,0], c_opt[i,1], a_opt[i], s_opt[i])
        max_out = 0.0
        for v in verts:
            out_x = max(0, -v[0], v[0]-1.0)
            out_y = max(0, -v[1], v[1]-1.0)
            max_out = max(max_out, out_x, out_y)
        if max_out > 0 and s_opt[i] > 1e-6:
            # shrink to fit
            # Move centre inward away from violation and shrink
            # Simple: shrink side until vertices are inside
            while True:
                verts = get_vertices(c_opt[i,0], c_opt[i,1], a_opt[i], s_opt[i])
                out = False
                for v in verts:
                    if v[0] < 0 or v[0] > 1.0 or v[1] < 0 or v[1] > 1.0:
                        out = True
                        break
                if not out or s_opt[i] <= 1e-6:
                    break
                s_opt[i] *= 0.99
            # Clamp centre to ensure feasibility
            c_opt[i,0] = np.clip(c_opt[i,0], s_opt[i]/2.0, 1.0 - s_opt[i]/2.0)
            c_opt[i,1] = np.clip(c_opt[i,1], s_opt[i]/2.0, 1.0 - s_opt[i]/2.0)
    
    # Construct output
    result = []
    for i in range(n):
        result.append((float(c_opt[i,0]), float(c_opt[i,1]), float(a_opt[i] % 1.0), float(s_opt[i])))
    
    # Sort by side descending (optional)
    result.sort(key=lambda x: x[3], reverse=True)
    
    return result


if __name__ == "__main__":
    # quick test
    for test_n in [5,6,7,8,11,12,13,14,15]:
        sol = solve(test_n)
        total = sum(s[3] for s in sol)
        print(f"n={test_n}: sum={total:.5f}")
