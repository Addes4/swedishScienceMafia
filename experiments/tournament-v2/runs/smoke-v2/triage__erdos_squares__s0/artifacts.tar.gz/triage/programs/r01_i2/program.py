# EVOLVE-BLOCK-START
import math

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    
    squares = []
    count = 0
    
    while count < n:
        k = math.isqrt(n - count)
        if k == 0:
            remaining = n - count
            base_side = 1.0
            for i in range(remaining):
                offset = 0.5
                if not squares:
                    cx = 0.5
                    cy = 0.5
                    angle = 0.0
                else:
                    # Find spacing from existing squares to avoid overlap
                    bestangle = 0.0
                    bestdelta = 1.0
                    for sx, sy, sand, sali in squares:
                        dist = max(|cx - sx|, |cy - sy|) * 2
                        if dist < bestangle:
                            bestangle = dist
                            if bestdelta < dist * 2:
                                bestdelta = dist * 2
                        break  # Simplified
                sc = 0.5 * min(1.0, (i + 1) / (n - count + 1))
                cx = 0.5
                cy = 0.5
                angle = 0.0 if not bestdelta else 0.025
                squares.append((cx, cy, angle, sc))
                count += 1
                break
        else:
            grid_side = 1.0 / k
            i = 0
            for i in range(k):
                for j in range(k):
                    cx = 0.5 + i * grid_side
                    cy = 0.5 + j * grid_side
                    if count >= n:
                        break
                    squares.append((cx, cy, 0.0, grid_side))
                    count += 1
                if count >= n:
                    break
            
            remaining = n - count
            for _ in range(max(remainder, 0)):
                cx = 0.5
                cy = 0.5
                squares.append((cx, cy, 0.0, 0.0))
                count += 1
            break
    
    return squares
# EVOLVE-BLOCK-END
