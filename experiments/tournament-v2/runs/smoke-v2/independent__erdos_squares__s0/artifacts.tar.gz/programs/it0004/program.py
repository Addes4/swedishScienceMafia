import math
import random
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    a = 2.0 * math.pi * ang
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)):
        pts.append((cx + c*dx - sn*dy, cy + sn*dx + c*dy))
    return pts


def _gjk_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2, eps=1e-10):
    """Return True if two squares overlap with positive area."""
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)

    axes = []
    for i in range(4):
        x1,y1 = p1[i]; x2,y2 = p1[(i+1)%4]
        axes.append((y1-y2, x2-x1))
        x1,y1 = p2[i]; x2,y2 = p2[(i+1)%4]
        axes.append((y1-y2, x2-x1))

    for ax, ay in axes:
        n = math.hypot(ax, ay)
        if n < 1e-14:
            continue
        ax /= n; ay /= n
        min1 = min(px*ax+py*ay for px,py in p1)
        max1 = max(px*ax+py*ay for px,py in p1)
        min2 = min(px*ax+py*ay for px,py in p2)
        max2 = max(px*ax+py*ay for px,py in p2)
        if max1 <= min2 + eps or max2 <= min1 + eps:
            return False
    return True


def _boundary_penalty(cx, cy, ang, s):
    """Penalty if square exits the unit square."""
    p = _corners(cx, cy, ang, s)
    pen = 0.0
    for x, y in p:
        if x < 0:
            pen += (0 - x) ** 2
        elif x > 1:
            pen += (x - 1) ** 2
        if y < 0:
            pen += (0 - y) ** 2
        elif y > 1:
            pen += (y - 1) ** 2
    return pen


def _total_overlap(sqs):
    """Sum of squared overlap penalties."""
    total = 0.0
    n = len(sqs)
    for i in range(n):
        xi, yi, ai, si = sqs[i]
        if si <= 1e-12:
            continue
        for j in range(i + 1, n):
            xj, yj, aj, sj = sqs[j]
            if sj <= 1e-12:
                continue
            # quick AABB reject
            ri = si * 0.5 * 1.4143
            rj = sj * 0.5 * 1.4143
            if abs(xi - xj) > ri + rj or abs(yi - yj) > ri + rj:
                continue
            if _gjk_overlap(xi, yi, ai, si, xj, yj, aj, sj):
                # approximate overlap penalty using centers distance vs half-diagonal sums
                diag_i = si * 0.5 * math.sqrt(2)
                diag_j = sj * 0.5 * math.sqrt(2)
                dist = math.hypot(xi - xj, yi - yj)
                overlap = max(0.0, diag_i + diag_j - dist)
                total += overlap * overlap
    return total


def _objective_and_grad(x):
    pass


def _eval_cost(sqs):
    pen = _total_overlap(sqs)
    for cx, cy, ang, s in sqs:
        if s > 1e-12:
            pen += 5.0 * _boundary_penalty(cx, cy, ang, s)
    return pen


def _project(sqs, n):
    """Project squares to satisfy boundary constraints exactly, then resolve overlaps iteratively."""
    for _ in range(60):
        # ensure inside
        for i in range(n):
            cx, cy, ang, s = sqs[i]
            if s <= 1e-12:
                continue
            ok = True
            p = _corners(cx, cy, ang, s)
            minx = min(q[0] for q in p)
            maxx = max(q[0] for q in p)
            miny = min(q[1] for q in p)
            maxy = max(q[1] for q in p)
            dx = 0.0
            dy = 0.0
            if minx < 0:
                dx = -minx
            elif maxx > 1:
                dx = 1 - maxx
            if miny < 0:
                dy = -miny
            elif maxy > 1:
                dy = 1 - maxy
            if dx != 0.0 or dy != 0.0:
                sqs[i] = (cx + dx, cy + dy, ang, s)

        # resolve overlaps by shrinking the smaller square slightly
        changed = False
        for i in range(n):
            xi, yi, ai, si = sqs[i]
            if si <= 1e-12:
                continue
            for j in range(i + 1, n):
                xj, yj, aj, sj = sqs[j]
                if sj <= 1e-12:
                    continue
                if _gjk_overlap(xi, yi, ai, si, xj, yj, aj, sj):
                    if si <= sj:
                        new_s = max(0.0, si * 0.97)
                        sqs[i] = (xi, yi, ai, new_s)
                    else:
                        new_s = max(0.0, sj * 0.97)
                        sqs[j] = (xj, yj, aj, new_s)
                    changed = True
        if not changed:
            break
    return sqs


def _refine(sqs, n, iters=300):
    """Simple random coordinate descent on centers, angles and sizes."""
    if n == 0:
        return sqs
    best = [tuple(v) for v in sqs]
    best_cost = _eval_cost(best)

    step_c = 0.02
    step_a = 0.02
    step_s = 0.01

    for it in range(iters):
        i = random.randrange(n)
        cx, cy, ang, s = best[i]
        if s <= 1e-12 and random.random() < 0.5:
            continue
        dc = random.gauss(0, step_c)
        da = random.gauss(0, step_a)
        ds = random.gauss(0, step_s)

        ncx = min(1.0, max(0.0, cx + dc))
        ncy = min(1.0, max(0.0, cy + dc))
        nang = (ang + da) % 1.0
        ns = min(1.0, max(0.0, s + ds))

        trial = best[:]
        trial[i] = (ncx, ncy, nang, ns)
        trial = _project(trial, n)
        cost = _eval_cost(trial)

        if cost < best_cost or random.random() < math.exp(-(cost - best_cost) / max(1e-8, 0.001)):
            best = trial
            best_cost = cost

        if it % 50 == 49:
            step_c *= 0.9
            step_a *= 0.9
            step_s *= 0.9

    return best


def _greedy_initial(n):
    """Construct an initial packing: large squares first, then random placements."""
    random.seed(12345 + n)
    sqs = []

    # start with one full square if n == 1
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # recursively place: start with full square and subdivide
    # Simple: use grid based on k x k, then add random small squares
    k = max(1, int(math.floor(math.sqrt(n))))
    while k * k > n:
        k -= 1
    side = 1.0 / k
    grid_sqs = []
    for i in range(k):
        for j in range(k):
            if len(grid_sqs) < n:
                grid_sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))

    # add more squares in remaining slots if needed
    while len(grid_sqs) < n:
        grid_sqs.append((random.uniform(0.1, 0.9), random.uniform(0.1, 0.9),
                         random.random(), 0.02))

    sqs = grid_sqs[:n]

    # try to grow sizes greedily
    for _ in range(200):
        for i in range(n):
            cx, cy, ang, s = sqs[i]
            # try larger sizes
            for factor in (1.05, 1.02, 1.01):
                ns = s * factor
                if ns > 1.0:
                    continue
                trial = sqs[:]
                trial[i] = (cx, cy, ang, ns)
                # check boundary
                if _boundary_penalty(cx, cy, ang, ns) > 1e-10:
                    continue
                # check overlap with others
                ok = True
                for j in range(n):
                    if i == j:
                        continue
                    xj, yj, aj, sj = trial[j]
                    if sj <= 1e-12:
                        continue
                    if _gjk_overlap(cx, cy, ang, ns, xj, yj, aj, sj):
                        ok = False
                        break
                if ok:
                    sqs = trial
                    break

    return sqs


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    sqs = _greedy_initial(n)
    sqs = _project([tuple(v) for v in sqs], n)

    # multiple restarts
    best = _refine(sqs, n, iters=200)
    best_cost = _eval_cost(best)
    best_sum = sum(s for _, _, _, s in best)

    for restart in range(3):
        cand = _greedy_initial(n)
        cand = _project([tuple(v) for v in cand], n)
        cand = _refine(cand, n, iters=150)
        c_cost = _eval_cost(cand)
        c_sum = sum(s for _, _, _, s in cand)
        if c_sum > best_sum or (c_sum == best_sum and c_cost < best_cost):
            best = cand
            best_sum = c_sum
            best_cost = c_cost

    # final polish
    best = _refine(best, n, iters=400)

    # remove overlaps one last time
    best = _project(best, n)

    # clamp all to [0,1]
    result = []
    for cx, cy, ang, s in best:
        result.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)),
                       ang % 1.0, min(1.0, max(0.0, s))))
    return result[:n]
