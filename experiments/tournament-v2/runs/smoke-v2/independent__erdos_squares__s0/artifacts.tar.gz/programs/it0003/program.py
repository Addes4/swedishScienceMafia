import math
import random


def _clip_centers(squares):
    for s in squares:
        x, y, a, w = s
        r = 0.5 * w * (abs(math.cos(2 * math.pi * a)) + abs(math.sin(2 * math.pi * a)))
        if x < r:
            x = r
        if x > 1.0 - r:
            x = 1.0 - r
        if y < r:
            y = r
        if y > 1.0 - r:
            y = 1.0 - r
        s[0] = x
        s[1] = y


def _sep_axes(a):
    t = 2 * math.pi * a
    c = math.cos(t)
    s = math.sin(t)
    # half-extent vectors along the two axes (for unit-side square scaled by w/2)
    return (c, s), (-s, c)


def _overlap_separate(squares, iters=40):
    n = len(squares)
    for _ in range(iters):
        moved = False
        for i in range(n):
            xi, yi, ai, wi = squares[i]
            if wi <= 0:
                continue
            (cxi, sxi), (cxi2, sxi2) = _sep_axes(ai)
            hi = 0.5 * wi
            # vertices of square i
            vi = [
                (xi + hi * (cxi + cxi2), yi + hi * (sxi + sxi2)),
                (xi + hi * (cxi - cxi2), yi + hi * (sxi - sxi2)),
                (xi - hi * (cxi + cxi2), yi - hi * (sxi + sxi2)),
                (xi - hi * (cxi - cxi2), yi - hi * (sxi - sxi2)),
            ]
            for j in range(i + 1, n):
                xj, yj, aj, wj = squares[j]
                if wj <= 0:
                    continue
                dx = xj - xi
                dy = yj - yi
                # rough distance check
                rad = 0.75 * (wi + wj)
                if dx * dx + dy * dy > rad * rad:
                    continue
                # separating axis test on the 4 edge normals
                (cxj, sxj), (cxj2, sxj2) = _sep_axes(aj)
                hj = 0.5 * wj
                axes = ((cxi, sxi), (cxi2, sxi2), (cxj, sxj), (cxj2, sxj2))
                min_pen = None
                min_axis = None
                for ax, ay in axes:
                    # projection radius of i
                    ri = hi * (abs(ax * cxi + ay * sxi) + abs(ax * cxi2 + ay * sxi2))
                    rj = hj * (abs(ax * cxj + ay * sxj) + abs(ax * cxj2 + ay * sxj2))
                    dist = ax * dx + ay * dy
                    pen = ri + rj - abs(dist)
                    if pen > 0:
                        if min_pen is None or pen < min_pen:
                            min_pen = pen
                            min_axis = (ax, ay, dist)
                if min_pen is not None and min_pen > 1e-12:
                    ax, ay, dist = min_axis
                    push = 0.5 * min_pen
                    if dist < 0:
                        push = -push
                    squares[i][0] -= push * ax
                    squares[i][1] -= push * ay
                    squares[j][0] += push * ax
                    squares[j][1] += push * ay
                    moved = True
        _clip_centers(squares)
        if not moved:
            break


def _expand(squares, rounds=60, rate=0.02):
    n = len(squares)
    for r in range(rounds):
        for s in squares:
            if s[3] > 0:
                s[3] *= (1.0 + rate)
        _clip_centers(squares)
        _overlap_separate(squares, iters=25)


def _total(squares):
    return sum(s[3] for s in squares)


def _shrink_to_fit(squares, margin=1e-9):
    """Scale all sizes so the layout is definitely feasible."""
    # binary search on scale factor checking overlap-freeness via SAT
    def feasible(k):
        for i in range(len(squares)):
            xi, yi, ai, wi = squares[i]
            hi = 0.5 * wi * k
            if hi < 0:
                return False
            t = 2 * math.pi * ai
            c = math.cos(t)
            s = math.sin(t)
            c2 = -s
            s2 = c
            vi = [
                (xi + hi * (c + c2), yi + hi * (s + s2)),
                (xi + hi * (c - c2), yi + hi * (s - s2)),
                (xi - hi * (c + c2), yi - hi * (s + s2)),
                (xi - hi * (c - c2), yi - hi * (s - s2)),
            ]
            # bounds
            for vx, vy in vi:
                if vx < -margin or vx > 1 + margin or vy < -margin or vy > 1 + margin:
                    return False
            for j in range(i + 1, len(squares)):
                xj, yj, aj, wj = squares[j]
                hj = 0.5 * wj * k
                t2 = 2 * math.pi * aj
                cj = math.cos(t2)
                sj = math.sin(t2)
                cj2 = -sj
                sj2 = cj
                vj = [
                    (xj + hj * (cj + cj2), yj + hj * (sj + sj2)),
                    (xj + hj * (cj - cj2), yj + hj * (sj - sj2)),
                    (xj - hj * (cj + cj2), yj - hj * (sj + sj2)),
                    (xj - hj * (cj - cj2), yj - hj * (sj - sj2)),
                ]
                axes = ((c, s), (c2, s2), (cj, sj), (cj2, sj2))
                dx = xj - xi
                dy = yj - yi
                overlap = True
                for ax, ay in axes:
                    ri = hi * (abs(ax * c + ay * s) + abs(ax * c2 + ay * s2))
                    rj = hj * (abs(ax * cj + ay * sj) + abs(ax * cj2 + ay * sj2))
                    dist = ax * dx + ay * dy
                    if abs(dist) >= ri + rj - margin:
                        overlap = False
                        break
                if overlap:
                    return False
        return True

    lo, hi = 0.0, 1.0
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        if feasible(mid):
            lo = mid
        else:
            hi = mid
    for s in squares:
        s[3] *= lo
    return squares


def solve(n):
    if n <= 0:
        return []
    # initial layout: k x k grid plus zero-size squares
    k = max(1, int(math.isqrt(n)))
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) >= n:
                break
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
        if len(squares) >= n:
            break
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])

    # small deterministic jitter to break symmetry for the extra squares
    random.seed(n)
    for i in range(k * k, n):
        squares[i][0] = 0.1 + 0.8 * random.random()
        squares[i][1] = 0.1 + 0.8 * random.random()
        squares[i][2] = 0.0

    squares = [list(s) for s in squares]

    # give every square a tiny positive size so it can grow
    for s in squares:
        if s[3] <= 0:
            s[3] = 1e-4

    _shrink_to_fit(squares)

    # growth phase
    for cycle in range(8):
        _expand(squares, rounds=25, rate=0.015 + 0.005 * cycle)
        _shrink_to_fit(squares)

    # final polish: many small separation steps
    for _ in range(30):
        for s in squares:
            s[3] *= 1.005
        _clip_centers(squares)
        _overlap_separate(squares, iters=10)
        _shrink_to_fit(squares)

    _shrink_to_fit(squares)

    # ensure zero-size squares are allowed for degeneracy
    out = []
    for x, y, a, w in squares:
        # normalize angle into [0,1)
        a = a % 1.0
        out.append((x, y, a, w))
    return out
