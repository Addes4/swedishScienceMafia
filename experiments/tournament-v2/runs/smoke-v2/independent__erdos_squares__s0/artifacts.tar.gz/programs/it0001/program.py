import math
import random
from typing import List, Tuple

import numpy as np
from scipy.optimize import minimize


def _rotated_square_corners(cx: float, cy: float, angle: float, side: float):
    """Return four corners of a rotated square (angle in turns)."""
    a = 2.0 * math.pi * angle
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * side

    # local axes: u = (ca, sa), v = (-sa, ca)
    ux, uy = ca, sa
    vx, vy = -sa, ca

    return [
        (cx + h * (ux + vx), cy + h * (uy + vy)),
        (cx + h * (ux - vx), cy + h * (uy - vy)),
        (cx - h * (ux + vx), cy - h * (uy + vy)),
        (cx - h * (ux - vx), cy - h * (uy - vy)),
    ]


def _obb_axes(cx: float, cy: float, angle: float, side: float):
    """Return centre and two orthonormal axes for an OBB."""
    a = 2.0 * math.pi * angle
    ca, sa = math.cos(a), math.sin(a)
    ux, uy = ca, sa
    vx, vy = -sa, ca
    return np.array((cx, cy), dtype=float), np.array((ux, uy), dtype=float), np.array((vx, vy), dtype=float)


def _obb_overlap_penalty(a_cx: float, a_cy: float, a_ang: float, a_side: float,
                         b_cx: float, b_cy: float, b_ang: float, b_side: float) -> float:
    """Positive if interiors overlap; scale-invariant smooth penalty."""
    if a_side <= 1e-14 or b_side <= 1e-14:
        return 0.0

    ca, ua, va = _obb_axes(a_cx, a_cy, a_ang, a_side)
    cb, ub, vb = _obb_axes(b_cx, b_cy, b_ang, b_side)

    # Separating axis theorem for two OBBs: axes are ua, va, ub, vb.
    axes = [ua, va, ub, vb]
    delta = cb - ca

    # half extents along each local axis
    ha_u = 0.5 * a_side
    ha_v = 0.5 * a_side
    hb_u = 0.5 * b_side
    hb_v = 0.5 * b_side

    min_overlap = None
    for ax in axes:
        # projection radii
        ra = abs(np.dot(ua, ax)) * ha_u + abs(np.dot(va, ax)) * ha_v
        rb = abs(np.dot(ub, ax)) * hb_u + abs(np.dot(vb, ax)) * hb_v
        d = abs(np.dot(delta, ax))
        gap = d - (ra + rb)
        if gap >= -1e-12:
            return 0.0  # separated on this axis
        ov = -gap
        if min_overlap is None or ov < min_overlap:
            min_overlap = ov

    return min_overlap if min_overlap is not None else 0.0


def _boundary_penalty(cx: float, cy: float, angle: float, side: float, margin: float = 0.0) -> float:
    """Positive if square crosses outside [0,1]^2 (with optional margin)."""
    if side <= 1e-14:
        # point: must lie in unit square
        p = 0.0
        for v in (cx, cy):
            if v < margin:
                p += (margin - v) ** 2
            elif v > 1.0 - margin:
                p += (v - (1.0 - margin)) ** 2
        return p

    pts = _rotated_square_corners(cx, cy, angle, side)
    p = 0.0
    for x, y in pts:
        if x < margin:
            p += (margin - x) ** 2
        elif x > 1.0 - margin:
            p += (x - (1.0 - margin)) ** 2
        if y < margin:
            p += (margin - y) ** 2
        elif y > 1.0 - margin:
            p += (y - (1.0 - margin)) ** 2
    return p


def _safe_initial(n: int):
    """Create a reasonable initial packing using grids and simple adjustments."""
    squares = []

    if n <= 0:
        return squares

    # For small n, try some known-ish manually constructed good packings.
    # For general n, start from a near-square grid and rotate alternate cells to
    # reduce wasted boundary and packing gaps.
    k = int(math.sqrt(n))
    if k * k < n:
        k += 0

    # Build a rectangular grid with rows/cols as balanced as possible.
    rows = int(math.floor(math.sqrt(n)))
    while rows > 1 and n // rows < rows - 1:
        rows -= 1
    cols = (n + rows - 1) // rows

    # Adaptive cell sizes: use full cell initially.
    cell_w = 1.0 / cols
    cell_h = 1.0 / rows

    cnt = 0
    for r in range(rows):
        for c in range(cols):
            if cnt >= n:
                break
            # Add slight jitter to break symmetry; alternate 45-degree rotations for
            # diagonal packing effect.
            jitter_x = 0.02 * cell_w * ((r * 13 + c * 7) % 5 - 2) / 2.0
            jitter_y = 0.02 * cell_h * ((r * 11 + c * 5) % 5 - 2) / 2.0
            cx = (c + 0.5) * cell_w + jitter_x
            cy = (r + 0.5) * cell_h + jitter_y
            side = min(cell_w, cell_h) * 0.98
            # alternate rotation for some cells to promote diagonal packing
            ang = 0.0
            if (r + c) % 2 == 1:
                ang = 0.125  # ~45 degrees? actually 0.125 turn = 45 deg
            squares.append((cx, cy, ang, side))
            cnt += 1
        if cnt >= n:
            break

    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _objective_and_grad(params, n, shapes_meta):
    """Unpack params and compute objective. Gradient is numerical due to complexity."""
    # params: for each square we have 4 values: cx, cy, angle, side
    # We optimise side via a transformed variable to keep it positive.
    squares = []
    penalty = 0.0

    # reconstruct
    p = params.reshape((n, 4))
    for i in range(n):
        cx = p[i, 0]
        cy = p[i, 1]
        ang = p[i, 2]
        s = p[i, 3]

        # enforce bounds softly
        # clip to reasonable ranges to avoid extreme
        cx = min(max(cx, -0.1), 1.1)
        cy = min(max(cy, -0.1), 1.1)
        ang = ang % 1.0
        s = max(0.0, s)

        squares.append((cx, cy, ang, s))

    # Boundary penalties
    for i, (cx, cy, ang, s) in enumerate(squares):
        penalty += 20.0 * _boundary_penalty(cx, cy, ang, s)

    # Overlap penalties between all pairs
    for i in range(n):
        for j in range(i + 1, n):
            cx1, cy1, a1, s1 = squares[i]
            cx2, cy2, a2, s2 = squares[j]
            ov = _obb_overlap_penalty(cx1, cy1, a1, s1, cx2, cy2, a2, s2)
            if ov > 0:
                penalty += 100.0 * (ov ** 2) + 10.0 * ov

    # Objective: maximise sum of sides = minimise negative sum + penalty
    total_side = sum(s for _, _, _, s in squares)
    return -total_side + penalty


def _optimize_squares(init_squares, n, max_iter=200):
    """Perform local optimisation on squares."""
    if n == 0:
        return []

    # Flatten
    x0 = []
    for cx, cy, ang, s in init_squares:
        x0.extend([cx, cy, ang, s])
    x0 = np.array(x0, dtype=float)

    # Bounds: centres can be slightly outside to allow optimization to move,
    # but we penalise. Angles [0,1]. Sides [0, 0.75].
    bounds = []
    for _ in range(n):
        bounds.append((-0.2, 1.2))  # cx
        bounds.append((-0.2, 1.2))  # cy
        bounds.append((0.0, 1.0))   # angle
        bounds.append((0.0, 0.8))   # side

    def fun(x):
        return _objective_and_grad(x, n, None)

    try:
        res = minimize(fun, x0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': max_iter, 'ftol': 1e-12, 'gtol': 1e-8})
        x = res.x
    except Exception:
        x = x0

    # Reconstruct and clean up tiny overlaps
    p = x.reshape((n, 4))
    squares = []
    for i in range(n):
        cx = float(np.clip(p[i, 0], 0.0, 1.0))
        cy = float(np.clip(p[i, 1], 0.0, 1.0))
        ang = float(p[i, 2] % 1.0)
        s = float(max(0.0, p[i, 3]))
        squares.append((cx, cy, ang, s))

    # Final hard repair: shrink overlapping squares slightly and clamp to boundary.
    squares = _repair(squares, n)
    return squares


def _repair(squares, n):
    """Greedy repair: shrink any square that overlaps or crosses boundary."""
    if n == 0:
        return []

    sq = [list(t) for t in squares]

    # Clamp centres into [0,1]
    for i in range(n):
        sq[i][0] = min(max(sq[i][0], 0.0), 1.0)
        sq[i][1] = min(max(sq[i][1], 0.0), 1.0)
        sq[i][2] = sq[i][2] % 1.0

    # Iteratively shrink until valid
    for _ in range(200):
        changed = False

        # Boundary violations: if any corner outside, shrink.
        for i in range(n):
            cx, cy, ang, s = sq[i]
            if s <= 0:
                continue
            pts = _rotated_square_corners(cx, cy, ang, s)
            minx = min(p[0] for p in pts)
            maxx = max(p[0] for p in pts)
            miny = min(p[1] for p in pts)
            maxy = max(p[1] for p in pts)

            if minx < -1e-9 or maxx > 1.0 + 1e-9 or miny < -1e-9 or maxy > 1.0 + 1e-9:
                # shrink side by factor
                new_s = s * 0.98
                if new_s < 1e-12:
                    new_s = 0.0
                sq[i][3] = new_s
                changed = True

        # Overlap violations: shrink the smaller of the two.
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            for j in range(i + 1, n):
                if sq[j][3] <= 0:
                    continue
                cx1, cy1, a1, s1 = sq[i]
                cx2, cy2, a2, s2 = sq[j]
                ov = _obb_overlap_penalty(cx1, cy1, a1, s1, cx2, cy2, a2, s2)
                if ov > 1e-9:
                    # Shrink both slightly, smaller more.
                    if s1 < s2:
                        sq[i][3] = max(0.0, s1 * 0.98)
                        sq[j][3] = max(0.0, s2 * 0.995)
                    else:
                        sq[i][3] = max(0.0, s1 * 0.995)
                        sq[j][3] = max(0.0, s2 * 0.98)
                    changed = True

        if not changed:
            break

    return [tuple(x) for x in sq]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    # Special-case tiny n with high-quality simple packings.
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    if n == 2:
        # Two equal squares side by side along diagonal? Best known is two
        # rectangles actually, but squares: half unit side by side gives 1.0.
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    if n == 3:
        # Three squares: one large on left, two on right.
        # Try empirical good: large square 0.5 side, two smaller stacked.
        # But better known sum for 3 is about 1.5? Let's just use optimizer.
        pass

    if n == 4:
        # Four quadrants = 2.0
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # General initial guess.
    init = _safe_initial(n)

    # Improve with several restarts.
    best = None
    best_score = -1e18

    tries = 1
    if n <= 30:
        tries = 5
    elif n <= 100:
        tries = 3
    else:
        tries = 1

    for t in range(tries):
        if t == 0:
            candidate = init
        else:
            # Random restart: jitter centres and angles.
            candidate = []
            for (cx, cy, ang, s) in init:
                jx = random.uniform(-0.05, 0.05)
                jy = random.uniform(-0.05, 0.05)
                ja = random.uniform(-0.2, 0.2)
                candidate.append((
                    min(max(cx + jx, 0.0), 1.0),
                    min(max(cy + jy, 0.0), 1.0),
                    (ang + ja) % 1.0,
                    s
                ))
            candidate = _repair(candidate, n)

        # Optimize
        try:
            optimized = _optimize_squares(candidate, n, max_iter=200 if n < 80 else 100)
        except Exception:
            optimized = candidate

        score = sum(s for _, _, _, s in optimized)
        if score > best_score:
            best_score = score
            best = optimized

    if best is None:
        best = init

    # Final repair to ensure validity.
    best = _repair(best, n)

    # Verify score is at least grid baseline? If not, fall back to grid.
    k = int(math.isqrt(n))
    if k > 0:
        grid_side = 1.0 / k
        grid_sum = (k * k) * grid_side + (n - k * k) * 0.0
        if best_score < grid_sum * 0.95:
            # Fall back to grid + zeros
            squares = [((i + 0.5) * grid_side, (j + 0.5) * grid_side, 0.0, grid_side)
                       for i in range(k) for j in range(k)]
            squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
            best = squares[:n]

    return best[:n]
