import math
import random
import numpy as np
from scipy.optimize import minimize


# ----------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------

def _corners(cx, cy, angle, side):
    """Return the four corners of a square as a 4x2 numpy array."""
    a = 2.0 * math.pi * angle
    d = side * 0.5
    c, s = math.cos(a), math.sin(a)
    corners = np.array([[-d, -d], [d, -d], [d, d], [-d, d]], dtype=float)
    R = np.array([[c, -s], [s, c]], dtype=float)
    return corners @ R.T + np.array([cx, cy], dtype=float)


def _poly_inside(poly, tol=1e-9):
    """True if all vertices of the convex polygon lie inside the unit square."""
    return (np.all(poly[:, 0] >= -tol) and np.all(poly[:, 0] <= 1.0 + tol) and
            np.all(poly[:, 1] >= -tol) and np.all(poly[:, 1] <= 1.0 + tol))


def _overlap_area(poly1, poly2):
    """Approximate overlapping area of two convex polygons via Sutherland-Hodgman clipping."""
    # clip poly1 by each half-plane of poly2 (CCW)
    output = poly1.tolist()
    # ensure poly2 is CCW for consistent normals
    p2 = poly2.tolist()
    area2 = 0.0
    for i in range(len(p2)):
        x1, y1 = p2[i]
        x2, y2 = p2[(i + 1) % len(p2)]
        area2 += x1 * y2 - x2 * y1
    if area2 < 0:
        p2 = p2[::-1]

    def inside(pt, a, b):
        return (b[0] - a[0]) * (pt[1] - a[1]) - (b[1] - a[1]) * (pt[0] - a[0]) >= -1e-12

    def intersect(p, q, a, b):
        # line p->q with line a->b
        x1, y1 = p
        x2, y2 = q
        x3, y3 = a
        x4, y4 = b
        den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if abs(den) < 1e-20:
            return q
        px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / den
        py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / den
        return [px, py]

    for i in range(len(p2)):
        a = p2[i]
        b = p2[(i + 1) % len(p2)]
        if not output:
            break
        inp = output
        output = []
        s = inp[-1]
        for e in inp:
            if inside(e, a, b):
                if not inside(s, a, b):
                    output.append(intersect(s, e, a, b))
                output.append(e)
            elif inside(s, a, b):
                output.append(intersect(s, e, a, b))
            s = e
    if len(output) < 3:
        return 0.0
    area = 0.0
    for i in range(len(output)):
        x1, y1 = output[i]
        x2, y2 = output[(i + 1) % len(output)]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


# ----------------------------------------------------------------------
# Initial placement strategies
# ----------------------------------------------------------------------

def _initial_grid(n):
    """Start from a k x k grid with side 1/k, plus optimally added/removed squares."""
    k = max(1, int(math.floor(math.sqrt(n))))
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([ (i + 0.5) * side, (j + 0.5) * side, 0.0, side ])
    squares = squares[:n]
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares


def _initial_mixed(n):
    """Try a few structured layouts and pick the best feasible one."""
    candidates = []

    # exact grid
    k = int(math.floor(math.sqrt(n)))
    if k > 0:
        s = 1.0 / k
        sq = []
        for i in range(k):
            for j in range(k):
                sq.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
        candidates.append(sq[:n] + [[0.5, 0.5, 0.0, 0.0]] * (n - len(sq[:n])))

    # grid plus rotated extras
    for extra_rot in [0.25, 0.5]:
        sq = []
        k = int(math.floor(math.sqrt(max(0, n - 1))))
        if k > 0:
            s = 1.0 / k
            for i in range(k):
                for j in range(k):
                    sq.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
        used = len(sq)
        if used < n:
            rem = n - used
            # place small rotated squares at random in gaps
            for _ in range(rem):
                sq.append([random.random(), random.random(), extra_rot, 0.0])
        candidates.append(sq)

    # sparse / random search
    for _ in range(5):
        sq = []
        for _ in range(n):
            sq.append([random.random(), random.random(), random.random(), random.random() * 0.3])
        candidates.append(sq)

    best = None
    best_val = -1.0
    for cand in candidates:
        val = _feasible_value(cand)
        if val is not None and val > best_val:
            best_val = val
            best = cand
    if best is None:
        best = _initial_grid(n)
    return best


def _feasible_value(sq):
    """Return sum of sides if arrangement is non-overlapping; None otherwise."""
    total = 0.0
    polys = []
    for cx, cy, ang, side in sq:
        if side <= 1e-12:
            total += 0.0
            polys.append(None)
            continue
        c = _corners(cx, cy, ang, side)
        if not _poly_inside(c):
            return None
        polys.append(c)
    for i in range(len(polys)):
        if polys[i] is None:
            continue
        for j in range(i + 1, len(polys)):
            if polys[j] is None:
                continue
            if _overlap_area(polys[i], polys[j]) > 1e-7:
                return None
    for cx, cy, ang, side in sq:
        total += side
    return total


# ----------------------------------------------------------------------
# Optimisation: shrink overlaps and expand sides
# ----------------------------------------------------------------------

def _packing_cost(x, n):
    """Cost: sum of penalties for out-of-bounds and overlaps, minus total side."""
    pen = 0.0
    total_side = 0.0
    polys = []
    for i in range(n):
        cx = x[4 * i]
        cy = x[4 * i + 1]
        ang = x[4 * i + 2]
        side = max(0.0, x[4 * i + 3])
        total_side += side
        if side <= 1e-12:
            polys.append(None)
            continue
        c = _corners(cx, cy, ang, side)
        if not _poly_inside(c):
            # penalty proportional to outside extent
            L = min(c[:, 0]) if min(c[:, 0]) < 0 else 0.0
            R = max(c[:, 0]) - 1.0 if max(c[:, 0]) > 1.0 else 0.0
            B = min(c[:, 1]) if min(c[:, 1]) < 0 else 0.0
            T = max(c[:, 1]) - 1.0 if max(c[:, 1]) > 1.0 else 0.0
            pen += 50.0 * (abs(L) + abs(R) + abs(B) + abs(T)) ** 2
        polys.append(c)

    # overlap penalties
    for i in range(n):
        if polys[i] is None:
            continue
        for j in range(i + 1, n):
            if polys[j] is None:
                continue
            ov = _overlap_area(polys[i], polys[j])
            if ov > 1e-10:
                pen += 200.0 * ov ** 2

    # also penalise centres out of [0,1]
    for i in range(n):
        cx = x[4 * i]
        cy = x[4 * i + 1]
        if cx < 0.0 or cx > 1.0:
            pen += 100.0 * (cx - 0.5) ** 2
        if cy < 0.0 or cy > 1.0:
            pen += 100.0 * (cy - 0.5) ** 2

    return pen - total_side


def _optimise(x0, n, maxiter=150, verbose=False):
    """Coordinate-descent / L-BFGS style improvement."""
    x = np.array(x0, dtype=float).ravel()
    best_x = x.copy()
    best_cost = _packing_cost(x, n)

    # start with Nelder-Mead for robustness on small n
    if n <= 6:
        res = minimize(lambda z: _packing_cost(z, n), x, method='Nelder-Mead',
                       options={'maxiter': 4000, 'xatol': 1e-7, 'fatol': 1e-7})
        if res.fun < best_cost:
            best_cost = res.fun
            best_x = res.x

    # L-BFGS-B with numerical gradient
    res = minimize(lambda z: _packing_cost(z, n), best_x, method='L-BFGS-B',
                   options={'maxiter': maxiter, 'ftol': 1e-12, 'gtol': 1e-8})
    if res.fun < best_cost:
        best_cost = res.fun
        best_x = res.x

    # coordinate descent / random perturbation
    for it in range(20):
        improved = False
        step = 0.02
        for i in range(4 * n):
            for delta in (-step, step):
                z = best_x.copy()
                z[i] += delta
                c = _packing_cost(z, n)
                if c < best_cost - 1e-12:
                    best_cost = c
                    best_x = z
                    improved = True
        if not improved:
            step *= 0.5
            if step < 1e-5:
                break
    return best_x


def _expand_and_feasible(x, n, max_rounds=200):
    """After optimisation, gradually expand sides while keeping feasibility."""
    x = np.array(x, dtype=float).copy()
    x = _optimise(x, n)
    best_val = _feasible_value(_to_sq(x, n))
    if best_val is None:
        # fall back: shrink everything slightly
        for i in range(n):
            x[4 * i + 3] *= 0.9
        best_val = _feasible_value(_to_sq(x, n))
        if best_val is None:
            return None

    # greedy local expansion
    for _ in range(max_rounds):
        improved = False
        order = list(range(n))
        random.shuffle(order)
        for i in order:
            cur = x[4 * i + 3]
            if cur <= 0:
                # try to grow from zero at a random free spot
                for _ in range(20):
                    cx = random.random()
                    cy = random.random()
                    ang = random.random()
                    x[4 * i] = cx
                    x[4 * i + 1] = cy
                    x[4 * i + 2] = ang
                    x[4 * i + 3] = 0.001
                    val = _feasible_value(_to_sq(x, n))
                    if val is not None:
                        improved = True
                        break
                continue
            # binary search largest feasible increase
            lo = cur
            hi = cur + 0.05
            # find upper bound that is infeasible
            for _ in range(10):
                x[4 * i + 3] = hi
                if _feasible_value(_to_sq(x, n)) is None:
                    break
                lo = hi
                hi *= 1.5
            else:
                lo = hi
            # binary search
            for _ in range(25):
                mid = (lo + hi) * 0.5
                x[4 * i + 3] = mid
                if _feasible_value(_to_sq(x, n)) is not None:
                    lo = mid
                else:
                    hi = mid
            x[4 * i + 3] = lo
            if lo > cur + 1e-9:
                improved = True
        if not improved:
            break
    return x


def _to_sq(x, n):
    sq = []
    for i in range(n):
        sq.append([x[4 * i], x[4 * i + 1], x[4 * i + 2], max(0.0, x[4 * i + 3])])
    return sq


# ----------------------------------------------------------------------
# Multi-start wrapper
# ----------------------------------------------------------------------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    maximising the sum of the sides."""
    if n <= 0:
        return []

    best_sq = None
    best_val = -1.0

    # number of restarts based on n (keep within time budget)
    restarts = 8 if n <= 12 else (5 if n <= 40 else 3)

    for r in range(restarts):
        if r == 0:
            init = _initial_grid(n)
        elif r == 1:
            # grid plus leftovers
            k = int(math.floor(math.sqrt(max(0, n - 1))))
            init = []
            if k > 0:
                s = 1.0 / k
                for i in range(k):
                    for j in range(k):
                        init.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
            while len(init) < n:
                init.append([0.5 + 0.01 * random.random(),
                             0.5 + 0.01 * random.random(),
                             random.random(),
                             random.random() * 0.04])
        else:
            # random perturbed grid
            init = _initial_grid(n)
            for i in range(n):
                init[i][0] += (random.random() - 0.5) * 0.05
                init[i][1] += (random.random() - 0.5) * 0.05
                init[i][0] = min(1.0, max(0.0, init[i][0]))
                init[i][1] = min(1.0, max(0.0, init[i][1]))
                init[i][2] += (random.random() - 0.5) * 0.2
                init[i][3] *= 1.0 - 0.1 * random.random()

        # shrink sides slightly to ensure feasibility before optimisation
        for i in range(n):
            if init[i][3] > 0:
                init[i][3] *= 0.98

        x0 = np.array(init, dtype=float).ravel()

        try:
            x = _expand_and_feasible(x0, n)
            if x is None:
                continue
            sq = _to_sq(x, n)
            val = _feasible_value(sq)
            if val is not None and val > best_val:
                best_val = val
                best_sq = [tuple(s) for s in sq]
        except Exception:
            continue

    if best_sq is None:
        # fallback baseline
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 1.0
        best_sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))
        best_sq = best_sq[:n]

    # clean up: clamp values and zero tiny sides
    result = []
    for cx, cy, ang, side in best_sq:
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        ang = float(ang % 1.0)
        side = max(0.0, float(side))
        if side < 1e-10:
            side = 0.0
        result.append((cx, cy, ang, side))

    # final verification; if infeasible, fall back to grid
    if _feasible_value(result) is None:
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 1.0
        result = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                  for i in range(k) for j in range(k)]
        result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
        result = result[:n]

    return result
