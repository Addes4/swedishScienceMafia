# EVOLVE-BLOCK-START
"""Guillotine strip packing with local search over row structure.

We represent a packing as an ordered list of rows; each row is a list of equal
squares placed side by side. Row heights are chosen jointly by an exact greedy/LP
argument: for fixed row sizes c_1..c_m, heights h_i with h_i <= 1/c_i and
sum h_i <= 1 maximise sum c_i h_i, whose optimum is obtained by filling rows in
decreasing order of c_i (water-filling).  We then locally search over the row
size vector (moving one square between rows, splitting/merging rows, changing
counts) plus a transposed layout, all cheap to evaluate.
"""
import math


def _height_opt(part):
    """Given non-increasing-ish row sizes, return optimal heights (list) and value."""
    rows = list(part)
    # sort row sizes descending; water-fill
    order = sorted(range(len(rows)), key=lambda i: -rows[i])
    rem = 1.0
    h = [0.0] * len(rows)
    total = 0.0
    for i in order:
        c = rows[i]
        if c == 0:
            continue
        cap = 1.0 / c
        hh = cap if cap < rem else rem
        if hh < 0:
            hh = 0.0
        h[i] = hh
        rem -= hh
        total += c * hh
        if rem <= 0:
            break
    return h, total


def _value(part):
    return _height_opt(part)[1]


def _normalize_rows(part):
    return [c for c in part if c > 0]


def _local_search(n):
    # start from several sensible partitions
    starts = []
    k = max(1, int(math.isqrt(n)))
    # square-ish
    base = n // k
    r = n % k
    starts.append([base + 1] * r + [base] * (k - r) if k else [n])
    starts.append([k] * (n // k) + ([n % k] if n % k else []))
    # one big row
    starts.append([n])
    # halving
    a = n // 2
    starts.append([a, n - a])
    # singleton-ish rows
    if n <= 60:
        starts.append([1] * n)
    # decreasing sweep
    for c0 in range(1, min(n, 12) + 1):
        p = []
        left = n
        c = c0
        while left > 0 and c > 0:
            t = min(c, left)
            p.append(t)
            left -= t
            if left <= 0:
                break
        if left == 0:
            starts.append(p)

    best_part = None
    best_v = -1.0
    for s in starts:
        s = _normalize_rows(s)
        if sum(s) != n:
            continue
        v = _value(s)
        if v > best_v:
            best_v = v
            best_part = s

    def try_part(p):
        nonlocal best_v, best_part
        p = _normalize_rows(p)
        if not p or sum(p) != n:
            return
        v = _value(p)
        if v > best_v + 1e-15:
            best_v = v
            best_part = list(p)

    # local search: move one square between rows, add/remove rows, perturb counts
    improved = True
    rounds = 0
    while improved and rounds < 60:
        improved = False
        rounds += 1
        p = list(best_part)
        m = len(p)
        # move a square from row i to row j
        for i in range(m):
            if p[i] <= 1:
                continue
            for j in range(m):
                if i == j:
                    continue
                q = list(p)
                q[i] -= 1
                q[j] += 1
                try_part(q)
                # also place them adjacent (new row)
                q2 = list(p)
                q2[i] -= 1
                q2.append(1)
                try_part(q2)
        # merge two rows
        for i in range(m):
            for j in range(i + 1, m):
                q = [p[t] for t in range(m) if t != i and t != j]
                q.append(p[i] + p[j])
                try_part(q)
        # split a row into two
        for i in range(m):
            if p[i] >= 2:
                for a in range(1, p[i] // 2 + 1):
                    q = [p[t] for t in range(m) if t != i]
                    q.append(a)
                    q.append(p[i] - a)
                    try_part(q)
        if best_part is not None and list(best_part) != p:
            improved = True

    return best_part


def _build(part, n):
    h, _ = _height_opt(part)
    out = []
    y = 0.0
    for c, hh in zip(part, h):
        if c <= 0:
            continue
        if hh <= 0:
            y += hh
            continue
        w = hh  # square of side hh, c of them across
        for j in range(c):
            cx = (j + 0.5) * w
            cy = y + 0.5 * w
            out.append((cx, cy, 0.0, w))
        y += hh
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _rotate_layout(out):
    # rotate whole layout 90 deg about center: (x,y)->(y,1-x)
    res = []
    for (x, y, a, s) in out:
        res.append((y, 1.0 - x, a, s))
    return res


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # large n: fall back to a clean grid, but distribute leftover squares
    if n > 400:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    part = _local_search(n)
    if part is None:
        part = [n]
    # sanity value
    v1, _ = _height_opt(part), None
    out_a = _build(part, n)
    out_b = _rotate_layout(_build(part, n))

    def ssum(o):
        return sum(s for (_, _, _, s) in o)

    if ssum(out_b) > ssum(out_a):
        return out_b
    return out_a
# EVOLVE-BLOCK-END
