# EVOLVE-BLOCK-START
"""Maximise sum of side lengths: shelf rows OR big-corner-square + L-strip grids,
then a continuous coordinate-ascent polish over all squares."""
import math


def _gen(n, maxp):
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _shelf(n):
    best_t = -1.0
    best_rows = None
    for part in _gen(n, n):
        rem = 1.0
        total = 0.0
        rows = []
        for c in part:
            h = 1.0 / c
            if h > rem:
                h = rem
            if h < 0.0:
                h = 0.0
            rem -= h
            total += c * h
            rows.append((c, h))
        if total > best_t:
            best_t = total
            best_rows = rows
    out = []
    y = 0.0
    for c, h in best_rows:
        for j in range(c):
            out.append(((j + 0.5) * h, y + 0.5 * h, 0.0, h))
        y += h
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _corner_L(n):
    best_sq = None
    best_score = -1.0
    A = 160
    B = 160
    for ia in range(1, A):
        a = ia / A
        for ib in range(1, B):
            b = ib / B
            if b > a or b > 1.0 - a:
                continue
            cols_r = int((1.0 - a + 1e-9) / b)
            rows_r = int((1.0 + 1e-9) / b)
            cols_t = int((a + 1e-9) / b)
            rows_t = int((1.0 - a + 1e-9) / b)
            cap = cols_r * rows_r + cols_t * rows_t
            if cap < n - 1:
                continue
            use = n - 1
            score = a + use * b
            if score > best_score:
                best_score = score
                best_sq = (a, b, cols_r, rows_r, cols_t, rows_t, cap)
    if best_sq is None:
        return None
    a, b, cols_r, rows_r, cols_t, rows_t, cap = best_sq
    out = [(a / 2.0, a / 2.0, 0.0, a)]
    need = n - 1
    placed = 0
    for i in range(cols_r):
        for j in range(rows_r):
            if placed >= need:
                break
            out.append((a + (i + 0.5) * b, (j + 0.5) * b, 0.0, b))
            placed += 1
        if placed >= need:
            break
    for i in range(cols_t):
        for j in range(rows_t):
            if placed >= need:
                break
            out.append(((i + 0.5) * b, a + (j + 0.5) * b, 0.0, b))
            placed += 1
        if placed >= need:
            break
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _overlap(i, j, sq):
    """Axis-aligned SAT overlap test. Returns True if interiors overlap."""
    x1, y1, _, s1 = sq[i]
    x2, y2, _, s2 = sq[j]
    if s1 <= 0.0 or s2 <= 0.0:
        return False
    return (abs(x1 - x2) < (s1 + s2) / 2.0 - 1e-12 and
            abs(y1 - y2) < (s1 + s2) / 2.0 - 1e-12)


def _polish(n, sq, iters=60):
    sq = [list(t) for t in sq]
    # sort indices by size descending: bigger squares get priority to grow
    order = sorted(range(n), key=lambda i: -sq[i][3])
    for _ in range(iters):
        improved = False
        for i in order:
            x, y, ang, s = sq[i]
            # try to grow side s
            # max feasible growth: limited by box and neighbours
            best_s = s
            # box limit
            max_s_box = 2.0 * min(x, y, 1.0 - x, 1.0 - y)
            if max_s_box > s:
                cand = max_s_box
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    x2, y2, _, s2 = sq[j]
                    if s2 <= 0.0:
                        continue
                    if (abs(x - x2) < (cand + s2) / 2.0 - 1e-12 and
                            abs(y - y2) < (cand + s2) / 2.0 - 1e-12):
                        # shrink cand to just touching
                        need_dx = (cand + s2) / 2.0
                        need_dy = (cand + s2) / 2.0
                        dx = abs(x - x2)
                        dy = abs(y - y2)
                        # cand such that (cand+s2)/2 <= max(dx,dy) won't overlap
                        m = max(dx, dy)
                        cand2 = 2.0 * m - s2
                        if cand2 < cand:
                            cand = cand2
                        if cand <= s:
                            ok = False
                            break
                if ok and cand > best_s + 1e-12:
                    best_s = cand
            if best_s > s + 1e-12:
                sq[i][3] = best_s
                improved = True
        # centre nudges: try pushing each square toward nearby gaps
        for i in order:
            x, y, ang, s = sq[i]
            best_gain = 0.0
            best_pos = (x, y)
            # try 8 directions * small steps
            step = 0.01
            for _step in range(3):
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1),
                               (1, 1), (1, -1), (-1, 1), (-1, -1)):
                    nx = x + dx * step
                    ny = y + dy * step
                    if s / 2.0 > nx or s / 2.0 > ny or nx > 1.0 - s / 2.0 or ny > 1.0 - s / 2.0:
                        continue
                    # check no overlap
                    ok = True
                    for j in range(n):
                        if j == i:
                            continue
                        x2, y2, _, s2 = sq[j]
                        if s2 <= 0.0:
                            continue
                        if (abs(nx - x2) < (s + s2) / 2.0 - 1e-12 and
                                abs(ny - y2) < (s + s2) / 2.0 - 1e-12):
                            ok = False
                            break
                    if ok:
                        # feasible new position; try to grow here
                        max_s_box = 2.0 * min(nx, ny, 1.0 - nx, 1.0 - ny)
                        cand = max_s_box
                        for j in range(n):
                            if j == i:
                                continue
                            x2, y2, _, s2 = sq[j]
                            if s2 <= 0.0:
                                continue
                            dxa = abs(nx - x2)
                            dya = abs(ny - y2)
                            m = max(dxa, dya)
                            cand2 = 2.0 * m - s2
                            if cand2 < cand:
                                cand = cand2
                        gain = cand - s
                        if gain > best_gain + 1e-12:
                            best_gain = gain
                            best_pos = (nx, ny)
                step *= 0.5
            if best_gain > 1e-12:
                sq[i][0], sq[i][1] = best_pos
                # recompute size at new position
                nx, ny = best_pos
                max_s_box = 2.0 * min(nx, ny, 1.0 - nx, 1.0 - ny)
                cand = max_s_box
                for j in range(n):
                    if j == i:
                        continue
                    x2, y2, _, s2 = sq[j]
                    if s2 <= 0.0:
                        continue
                    m = max(abs(nx - x2), abs(ny - y2))
                    cand2 = 2.0 * m - s2
                    if cand2 < cand:
                        cand = cand2
                if cand > s:
                    sq[i][3] = cand
                improved = True
        if not improved:
            break
    # final safety clamp
    for i in range(n):
        x, y, ang, s = sq[i]
        if s <= 0.0:
            sq[i] = [0.5, 0.5, 0.0, 0.0]
            continue
        if s < 1e-9:
            sq[i] = [0.5, 0.5, 0.0, 0.0]
            continue
        s = min(s, 1.0)
        s = min(s, 2.0 * x, 2.0 * y, 2.0 * (1.0 - x), 2.0 * (1.0 - y))
        if s < 0.0:
            s = 0.0
        sq[i] = [x, y, 0.0, s]
    # verify no overlap; if any, shrink them to 0
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(i, j, sq):
                sq[j][3] = 0.0
    return [tuple(t) for t in sq]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n > 60:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    cands = [_shelf(n)]
    cl = _corner_L(n)
    if cl is not None:
        cands.append(cl)
    best = None
    best_s = -1.0
    for c in cands:
        s = sum(t[3] for t in c)
        if s > best_s:
            best_s = s
            best = c
    polished = _polish(n, best)
    if sum(t[3] for t in polished) > best_s:
        return polished
    return best
# EVOLVE-BLOCK-END
