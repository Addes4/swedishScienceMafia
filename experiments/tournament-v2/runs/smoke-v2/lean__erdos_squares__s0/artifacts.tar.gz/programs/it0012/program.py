# EVOLVE-BLOCK-START
"""Shelf packing with exact water-filling row heights and local search refinement."""
import math


def _gen(n, maxp):
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _build(part, n):
    """Given non-increasing row sizes, compute optimal heights so that
    sum h_i <= 1 and sum c_i*h_i is maximised (water filling / LP)."""
    m = len(part)
    if m == 0:
        return None
    # LP: maximise sum c_i h_i s.t. sum h_i <= 1, 0<=h_i<=1.
    # Greedy: fill rows by c_i in decreasing order.
    order = sorted(range(m), key=lambda i: -part[i])
    h = [0.0] * m
    rem = 1.0
    total = 0.0
    for i in order:
        hi = min(rem, 1.0)
        h[i] = hi
        rem -= hi
        total += part[i] * hi
    rows = [(part[i], h[i]) for i in range(m) if h[i] > 0]
    return rows, total


def _layout(rows, n):
    out = []
    y = 0.0
    used = 0
    for c, h in rows:
        for j in range(c):
            if used >= n:
                break
            out.append(((j + 0.5) * h, y + 0.5 * h, 0.0, h))
            used += 1
        y += h
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _score(rows):
    return sum(c * h for c, h in rows)


def solve(n):
    if n <= 0:
        return []
    if n > 55:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    best_t = -1.0
    best_rows = None
    # Precompute largest divisor-shelf: also allow truncating a row's count.
    for part in _gen(n, n):
        res = _build(part, n)
        if res is None:
            continue
        rows, total = res
        if total > best_t:
            best_t = total
            best_rows = rows

    # Repair: some rows may contain more squares than needed; try truncated rows.
    # Enumerate partitions of n where last row can be partially filled.
    if best_rows is not None:
        for part in _gen(n, n):
            rem = 1.0
            total = 0.0
            rows = []
            y = 0.0
            left = n
            for c in part:
                # number we actually place in this row
                cnt = min(c, left)
                h = 1.0 / c
                if h > rem:
                    h = rem
                rem -= h
                total += cnt * h
                rows.append((cnt, h, c))
                left -= cnt
                if left <= 0:
                    break
            if abs(total) > best_t:
                # verify geometric validity: cnt squares of side h in width 1
                ok = all(cnt * h <= 1.0 + 1e-12 for cnt, h, c in rows)
                if ok:
                    best_t = total
                    best_rows = [(cnt, h) for cnt, h, c in rows]

    if best_rows is None:
        best_rows = [(1, 1.0 / n)] if n <= 1 else [(1, 1.0 / math.isqrt(n))]

    return _layout(best_rows, n)
# EVOLVE-BLOCK-END
