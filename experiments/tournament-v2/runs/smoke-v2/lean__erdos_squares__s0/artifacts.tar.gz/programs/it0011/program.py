# EVOLVE-BLOCK-START
"""Shelf packing with exact row-height optimization and transposed comparison."""
import math
from scipy.optimize import linprog


def _gen(n, maxp):
    """Yield all non-increasing integer partitions of n with parts <= maxp."""
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _eval_partition(part):
    """Given non-increasing row counts, return list of (c, h) maximizing sum c*h
    subject to h_i >= 0, h_i <= 1/c_i, sum(h_i) <= 1. LP -> water filling."""
    m = len(part)
    if m == 0:
        return []
    c = [float(x) for x in part]
    # maximize sum c_i h_i  => minimize -sum c_i h_i
    cobj = [-v for v in c]
    A_ub = [[1.0] * m]
    b_ub = [1.0]
    bounds = [(0.0, 1.0 / c[i]) for i in range(m)]
    res = linprog(cobj, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not res.success:
        # fallback greedy
        rem = 1.0
        hs = []
        for ci in part:
            h = min(1.0 / ci, rem)
            rem -= h
            hs.append(h)
        return list(zip(part, hs))
    hs = res.x
    return list(zip(part, hs))


def _build_layout(rows):
    """rows: iterable of (c, h) in top-to-bottom order."""
    out = []
    y = 0.0
    for c, h in rows:
        if h <= 0 or c <= 0:
            y += h
            continue
        w = h  # squares of side h arranged in a row of width c*h; c*h <= 1
        for j in range(int(c)):
            out.append(((j + 0.5) * w, y + 0.5 * h, 0.0, h))
        y += h
    return out


def _search_partitions(n, max_rows):
    best_t = -1.0
    best_rows = None
    for part in _gen(n, n):
        if len(part) > max_rows:
            continue
        rows = _eval_partition(part)
        total = sum(c * h for c, h in rows)
        if total > best_t:
            best_t = total
            best_rows = rows
    return best_t, best_rows


def solve(n):
    if n <= 0:
        return []
    if n > 40:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    best_t, best_rows = _search_partitions(n, n)

    # Try transposed view: same partition but treat rows as columns (swap axes).
    # Laying squares in columns gives the same total, but we can combine: keep both,
    # choose whichever fits. Totals are identical for a pure transposition, so
    # instead explore "mixed" partitions where we also allow the last row to be
    # split into two rows with different counts.
    for part in _gen(n, n):
        # try splitting each single row into two rows of different counts
        for i in range(len(part)):
            base = part[:i] + part[i + 1:]
            for a in range(1, part[i]):
                b = part[i] - a
                if b <= 0:
                    continue
                newpart = sorted(base + [a, b], reverse=True)
                rows = _eval_partition(newpart)
                total = sum(c * h for c, h in rows)
                if total > best_t:
                    best_t = total
                    best_rows = rows

    out = _build_layout(best_rows)
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
