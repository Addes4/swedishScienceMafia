# EVOLVE-BLOCK-START
"""Shelf packing with two-row rebalance local search to maximise sum of sides."""
import math


def _gen(n, maxp):
    """Yield all non-increasing integer partitions of n with parts <= maxp."""
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _row_total(part):
    """Given row sizes (list of c), assign heights by water-filling to maximise
    sum(c_i * h_i) subject to h_i <= 1/c_i and sum(h_i) <= 1.
    Greedy: smallest c first should get its max height (largest cap = 1/c).
    Actually cap 1/c: smaller c -> larger cap. Give larger caps first."""
    caps = [1.0 / c for c in part]
    order = sorted(range(len(part)), key=lambda i: -caps[i])
    h = [0.0] * len(part)
    rem = 1.0
    for i in order:
        take = min(caps[i], rem)
        h[i] = take
        rem -= take
        if rem <= 0:
            break
    total = sum(part[i] * h[i] for i in range(len(part)))
    return total, h


def solve(n):
    if n <= 0:
        return []
    # Fallback for very large n (partition enumeration would be too slow).
    if n > 55:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    best_t = -1.0
    best_part = None
    for part in _gen(n, n):
        total, _ = _row_total(part)
        if total > best_t:
            best_t = total
            best_part = part

    # Local search: try rebalancing each pair of adjacent rows by merging their
    # square counts and re-splitting into two rows, then re-water-filling all rows.
    part = list(best_part)
    improved = True
    while improved:
        improved = False
        for i in range(len(part)):
            for j in range(i + 1, len(part)):
                combined = part[i] + part[j]
                for a in range(1, combined):
                    b = combined - a
                    cand = part[:i] + [a, b] + part[i + 1:j] + part[j + 1:]
                    cand = [c for c in cand if c > 0]
                    total, _ = _row_total(cand)
                    if total > best_t + 1e-12:
                        best_t = total
                        part = cand
                        improved = True
                        break
                if improved:
                    break
            if improved:
                break

    best_part = part
    _, heights = _row_total(best_part)

    out = []
    y = 0.0
    for c, h in zip(best_part, heights):
        if h <= 0:
            continue
        for j in range(c):
            out.append(((j + 0.5) * h, y + 0.5 * h, 0.0, h))
        y += h
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
