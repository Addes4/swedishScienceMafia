# EVOLVE-BLOCK-START
"""Recursive guillotine shelf packing: at each step choose a row count c and pack
c equal squares across, then recurse on the leftover rectangle above it.
Uses memoised DP over (k, width) to split n squares into a full-width row plus
a sub-packing of the remaining squares in the leftover strip."""
import math
import sys
from functools import lru_cache

sys.setrecursionlimit(10000)


def _rows_for_width(k, w):
    """Best layout using exactly k squares in a rectangle of width w and height 1
    (top-aligned within the full unit square), via guillotine shelves.
    Returns (value, layout) where layout is a list of (x, y, angle, side) using
    normalised y in [0,1] local coordinates (rectangle occupies y in [0,h]).
    All squares are axis-aligned equal squares per row."""
    # For small k we do a full search over partitions into rows.
    if k <= 0:
        return 0.0, []

    best_val = -1.0
    best_rows = None
    # Enumerate non-increasing partitions of k (row sizes).
    for part in _gen(k, k):
        # Greedy: rows get heights equal to width/ c (width = w), capped so
        # total height <= 1. Greedy maximal height per row is optimal for
        # maximising sum c_i * h_i with h_i <= w/c_i, sum h_i <= 1.
        rem = 1.0
        total = 0.0
        rows = []
        for c in part:
            hcap = w / c
            h = min(hcap, rem)
            if h < 0.0:
                h = 0.0
            rem -= h
            total += c * h
            rows.append((c, h))
        if total > best_val:
            best_val = total
            best_rows = rows

    layout = []
    y = 0.0
    for c, h in best_rows:
        for j in range(c):
            layout.append(((j + 0.5) * (w / c), y + 0.5 * h, 0.0, h))
        y += h
    return best_val, layout


def _gen(n, maxp):
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


# Memoised sub-packing: given k squares, available width w, available height h
# (rectangle in local coords), return best sum and layout with normalised coords.
@lru_cache(maxsize=None)
def _pack(k, w, h):
    if k <= 0:
        return (0.0, ())
    w = round(w, 6)
    h = round(h, 6)
    best = (-1.0, ())
    # Option 1: place a row of c equal squares spanning the width w:
    # each square has side s = w / c, and they occupy height s of the strip.
    for c in range(1, k + 1):
        s = w / c
        if s > h + 1e-12:
            continue
        sub_val, sub_layout = _pack(k - c, w, h - s)
        val = c * s + sub_val
        if val > best[0] + 1e-12:
            lay = tuple(((j + 0.5) * s, 0.5 * s, 0.0, s) for j in range(c))
            # shift sub_layout down by s
            shifted = tuple((x, y + s, a, si) for (x, y, a, si) in sub_layout)
            best = (val, lay + shifted)
    # Option 2: rotate the whole sub-rectangle: try packing in the other
    # orientation by swapping w and h conceptually, i.e. place a column of c
    # squares down the left side, each of side h / c, occupying width h/c.
    for c in range(1, k + 1):
        s = h / c
        if s > w + 1e-12:
            continue
        sub_val, sub_layout = _pack(k - c, w - s, h)
        val = c * s + sub_val
        if val > best[0] + 1e-12:
            lay = tuple((0.5 * s, (j + 0.5) * s, 0.0, s) for j in range(c))
            shifted = tuple((x + s, y, a, si) for (x, y, a, si) in sub_layout)
            best = (val, lay + shifted)
    return best


def solve(n):
    if n <= 0:
        return []
    val, layout = _pack(n, 1.0, 1.0)
    out = [tuple(min(max(v, 0.0), 1.0) for v in (x, y, a, s)) for (x, y, a, s) in layout]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
