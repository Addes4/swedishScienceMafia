# EVOLVE-BLOCK-START
"""Shelf packing with LP-optimal row heights, plus transposed (column-major) variants."""
import math


def _gen(n, maxp):
    """Yield all non-increasing integer partitions of n with parts <= maxp."""
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _best_heights(part):
    """Given non-increasing row sizes, maximize sum c_i*h_i with h_i<=1/c_i, sum h_i<=1.
    Greedy water-filling: distribute height 1 among rows, each row capped at 1/c_i.
    Rows with smaller c get larger caps; fill largest caps first (they hold more c*h per height)."""
    # ratio c_i (per unit height) is just c_i, so fill rows with largest c_i first.
    m = len(part)
    order = sorted(range(m), key=lambda i: -part[i])
    remaining = 1.0
    h = [0.0] * m
    for i in order:
        cap = 1.0 / part[i]
        if remaining <= 0.0:
            break
        give = min(cap, remaining)
        h[i] = give
        remaining -= give
    return h


def _layout(part, transpose):
    h = _best_heights(part)
    out = []
    if not transpose:
        y = 0.0
        for c, hh in zip(part, h):
            for j in range(c):
                out.append(((j + 0.5) * hh, y + 0.5 * hh, 0.0, hh))
            y += hh
    else:
        x = 0.0
        for c, hh in zip(part, h):
            for j in range(c):
                out.append((x + 0.5 * hh, (j + 0.5) * hh, 0.0, hh))
            x += hh
    return out


def solve(n):
    if n <= 0:
        return []
    if n > 60:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    best_t = -1.0
    best_out = None
    for part in _gen(n, n):
        h = _best_heights(part)
        total = sum(c * hh for c, hh in zip(part, h))
        if total > best_t:
            best_t = total
            best_out = _layout(part, False)
        # transposed variant
        if total > best_t - 1e-12:
            out2 = _layout(part, True)
            if total > best_t:
                best_t = total
                best_out = out2
    if best_out is None:
        best_out = [(0.5, 0.5, 0.0, 0.0)] * n
    while len(best_out) < n:
        best_out.append((0.5, 0.5, 0.0, 0.0))
    return best_out[:n]
# EVOLVE-BLOCK-END
