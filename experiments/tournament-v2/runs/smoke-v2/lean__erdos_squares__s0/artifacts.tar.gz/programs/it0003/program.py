# EVOLVE-BLOCK-START
"""Shelf packing with LP-optimised row heights: partition n into rows, then choose
row heights to maximise sum(c_i * h_i) subject to h_i <= width-fitting bound and
total height <= 1."""
import math
import numpy as np
from scipy.optimize import linprog


def _gen(n, maxp):
    """Yield all non-increasing integer partitions of n with parts <= maxp."""
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _rows_sum(rows):
    return sum(c * h for c, h in rows)


def solve(n):
    if n <= 0:
        return []
    # Fallback for very large n (partition enumeration would be too slow).
    if n > 45:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    best_t = -1.0
    best_rows = None
    for part in _gen(n, n):
        c = np.array(part, dtype=float)          # non-increasing row sizes
        # maximize sum(c_i h_i)  <=>  minimize -c . h
        # constraints: sum h_i <= 1 ; 0 <= h_i <= 1/c_i
        A_ub = np.ones((1, len(c)))
        b_ub = np.array([1.0])
        bounds = [(0.0, 1.0 / ci) for ci in c]
        res = linprog(-c, A_ub=A_ub, b_ub=b_ub, bounds=bounds,
                      method="highs")
        if not res.success:
            continue
        h = res.x
        total = float(c @ h)
        if total > best_t:
            best_t = total
            best_rows = list(zip(part, h))

    out = []
    y = 0.0
    for c, h in best_rows:
        for j in range(c):
            out.append(((j + 0.5) * h, y + 0.5 * h, 0.0, h))
        y += h
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
