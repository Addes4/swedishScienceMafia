# EVOLVE-BLOCK-START
"""Shelf packing with per-row square sizes optimized by water-filling."""
import math


def _gen(n, maxp):
    """Yield all non-increasing integer partitions of n with parts <= maxp."""
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _eval_partition(part):
    """Given non-increasing row sizes, allocate heights to maximize sum of sides.

    Row i has c_i squares; if it uses square side s_i, it needs height >= s_i
    and width c_i * s_i <= 1, so s_i <= 1/c_i.  Total height sum s_i <= 1.
    Maximize sum c_i * s_i  subject to  0<=s_i<=1/c_i, sum s_i<=1.

    This is a fractional knapsack: best ratio per unit height is c_i, so we
    fill rows in decreasing c_i order with s_i = 1/c_i until height runs out.
    """
    rem = 1.0
    total = 0.0
    sides = []
    for c in part:                       # non-increasing c => fill widest first
        cap = 1.0 / c
        if cap <= rem:
            s = cap
            rem -= s
        else:
            s = rem
            rem = 0.0
        sides.append(s)
        total += c * s
        if rem <= 0.0:
            # any further rows get side 0
            pass
    # pad sides for remaining rows at 0
    while len(sides) < len(part):
        sides.append(0.0)
    return total, sides


def solve(n):
    if n <= 0:
        return []
    if n > 55:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    best_t = -1.0
    best_part = None
    best_sides = None
    for part in _gen(n, n):
        total, sides = _eval_partition(part)
        if total > best_t:
            best_t = total
            best_part = part
            best_sides = sides

    out = []
    y = 0.0
    for c, s in zip(best_part, best_sides):
        if s <= 0.0:
            continue
        # place c squares of side s across width, centered horizontally if needed
        row_w = c * s
        x0 = (1.0 - row_w) * 0.5
        for j in range(c):
            out.append((x0 + (j + 0.5) * s, y + 0.5 * s, 0.0, s))
        y += s
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
