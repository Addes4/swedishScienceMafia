# EVOLVE-BLOCK-START
"""Maximise sum of side lengths: shelf rows, big-corner-square + L-strip grids,
plus continuous coordinate ascent to grow underfilled squares."""
import math


def _gen(n, maxp):
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _shelf(n):
    best_t = -1.0
    best_rows = None
    for part in _gen(n, n):
        rem = 1.0
        total = 0.0
        rows = []
        for c in part:
            h = 1.0 / c
            if h > rem:
                h = rem
            if h < 0.0:
                h = 0.0
            rem -= h
            total += c * h
            rows.append((c, h))
        if total > best_t:
            best_t = total
            best_rows = rows
    out = []
    y = 0.0
    for c, h in best_rows:
        for j in range(c):
            out.append(((j + 0.5) * h, y + 0.5 * h, 0.0, h))
        y += h
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _corner_L(n):
    best_sq = None
    best_score = -1.0
    A = 240
    B = 240
    for ia in range(1, A):
        a = ia / A
        for ib in range(1, B):
            b = ib / B
            if b > a or b > 1.0 - a:
                continue
            cols_r = int((1.0 - a + 1e-9) / b)
            rows_r = int((1.0 + 1e-9) / b)
            cols_t = int((a + 1e-9) / b)
            rows_t = int((1.0 - a + 1e-9) / b)
            cap = cols_r * rows_r + cols_t * rows_t
            if cap < n - 1:
                continue
            use = n - 1
            score = a + use * b
            if score > best_score:
                best_score = score
                best_sq = (a, b, cols_r, rows_r, cols_t, rows_t)
    if best_sq is None:
        return None
    a, b, cols_r, rows_r, cols_t, rows_t = best_sq
    out = [(a / 2.0, a / 2.0, 0.0, a)]
    need = n - 1
    placed = 0
    for i in range(cols_r):
        for j in range(rows_r):
            if placed >= need:
                break
            out.append((a + (i + 0.5) * b, (j + 0.5) * b, 0.0, b))
            placed += 1
        if placed >= need:
            break
    for i in range(cols_t):
        for j in range(rows_t):
            if placed >= need:
                break
            out.append(((i + 0.5) * b, a + (j + 0.5) * b, 0.0, b))
            placed += 1
        if placed >= need:
            break
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _corners(cx, cy, s, ang):
    """Axis-agnostic: return list of 4 corner points of a square."""
    th = 2.0 * math.pi * ang
    c, sn = math.cos(th), math.sin(th)
    h = s / 2.0
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _inside(cx, cy, s, ang):
    for x, y in _corners(cx, cy, s, ang):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _overlap(sq1, sq2):
    """Separating axis test between two squares."""
    (x1, y1, a1, s1) = sq1
    (x2, y2, a2, s2) = sq2
    if s1 <= 1e-12 or s2 <= 1e-12:
        return False
    p1 = _corners(x1, y1, s1, a1)
    p2 = _corners(x2, y2, s2, a2)
    for pts, ang in ((p1, a1), (p2, a2)):
        th = 2.0 * math.pi * ang
        c, sn = math.cos(th), math.sin(th)
        axes = [(c, sn), (-sn, c)]
        for ax, ay in axes:
            mn1 = mn2 = 1e18
            mx1 = mx2 = -1e18
            for x, y in p1:
                v = x * ax + y * ay
                mn1 = min(mn1, v); mx1 = max(mx1, v)
            for x, y in p2:
                v = x * ax + y * ay
                mn2 = min(mn2, v); mx2 = max(mx2, v)
            if mx1 <= mn2 + 1e-9 or mx2 <= mn1 + 1e-9:
                return False
    return True


def _valid_all(sqs):
    m = len(sqs)
    for i in range(m):
        if sqs[i][3] <= 0:
            continue
        if not _inside(*sqs[i]):
            return False
    for i in range(m):
        if sqs[i][3] <= 0:
            continue
        for j in range(i + 1, m):
            if sqs[j][3] <= 0:
                continue
            if _overlap(sqs[i], sqs[j]):
                return False
    return True


def _coord_ascent(sqs, iters=6):
    """Greedily try to grow each square's side, adjusting centre to fit."""
    sqs = [list(s) for s in sqs]
    m = len(sqs)
    for _ in range(iters):
        improved = False
        for i in range(m):
            base = sqs[i][:]
            for grow in (0.02, 0.01, 0.005, 0.002, 0.001):
                # try growing side and recentering toward free space
                s = base[3] + grow
                if s > 1.0:
                    continue
                for dx in (0.0, grow / 2, -grow / 2):
                    for dy in (0.0, grow / 2, -grow / 2):
                        cand = [base[0] + dx, base[1] + dy, base[2], s]
                        if cand[3] == 0:
                            continue
                        if not _inside(*cand):
                            continue
                        old = sqs[i]
                        sqs[i] = cand
                        ok = True
                        for j in range(m):
                            if j == i:
                                continue
                            if sqs[j][3] <= 0:
                                continue
                            if _overlap(sqs[i], sqs[j]):
                                ok = False
                                break
                        if ok:
                            improved = True
                            break
                    if improved:
                        break
                if improved:
                    break
        if not improved:
            break
    return [tuple(s) for s in sqs]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n > 55:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    cands = [_shelf(n)]
    cl = _corner_L(n)
    if cl is not None:
        cands.append(cl)

    best = None
    best_s = -1.0
    for c in cands:
        trial = _coord_ascent(c)
        s = sum(t[3] for t in trial)
        if s > best_s:
            best_s = s
            best = trial

    # final safety: ensure validity, else fall back
    if best is None or not _valid_all(best):
        k = math.isqrt(n)
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]
    return [tuple(t) for t in best]
# EVOLVE-BLOCK-END

