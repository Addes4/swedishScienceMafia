# EVOLVE-BLOCK-START
"""Shelf packing, with an option to fill the remaining strip by a rotated column."""
import math


def _gen(n, maxp):
    """Yield all non-increasing integer partitions of n with parts <= maxp."""
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _rows_layout(part):
    """Greedy row layout for a partition; returns (total, rows, used_height)."""
    rem = 1.0
    total = 0.0
    rows = []
    for c in part:
        h = 1.0 / c
        if h > rem:
            h = rem
        if h < 0.0:
            h = 0.0
        rem -= h
        total += c * h
        rows.append((c, h))
    return total, rows, 1.0 - rem


def _build_rows(rows, y0=0.0):
    out = []
    y = y0
    for c, h in rows:
        for j in range(c):
            out.append(((j + 0.5) * h, y + 0.5 * h, 0.0, h))
        y += h
    return out, y


def solve(n):
    if n <= 0:
        return []
    if n > 55:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    best_t = -1.0
    best_rows = None
    best_out = None

    # Plain shelf layout.
    for part in _gen(n, n):
        total, rows, used = _rows_layout(part)
        if total > best_t:
            best_t = total
            best_rows = rows
            best_out = None

    # Two-level: k equal rows on top (k = number of parts), remaining strip filled
    # by a rotated column-of-equal-squares arrangement.
    for part in _gen(n, n):
        total, rows, used = _rows_layout(part)
        for extra_n in range(1, min(n, 12) + 1):
            base_n = n - extra_n
            if base_n <= 0:
                continue
            # Try trimming the last rows to free width for a rotated column.
            pass

    # Direct enumeration of "rows then a rotated tail block" where the tail block
    # is a column of m equal squares of side s = width_of_free_strip.
    for nrows in range(1, n + 1):
        for tail in range(1, n - nrows + 1):
            head_n = n - tail
            # distribute head_n over nrows rows as evenly as possible
            c = head_n // nrows
            if c < 1:
                continue
            widths = []
            base = head_n // nrows
            r = head_n % nrows
            for i in range(nrows):
                widths.append(base + (1 if i < r else 0))
            if min(widths) < 1:
                continue
            # place tail as a column of equal squares in the leftover strip
            # Greedy: rows use the top, tail uses the remaining height at left.
            # Try tail side s: rows occupy width 1-s on full height, tail occupies
            # width s.  We just try a few s values and pick the best feasible.
            for ts in range(1, 41):
                s = ts / 40.0
                if s <= 0.0 or s >= 1.0:
                    continue
                avail_h = 1.0
                # each row: squares of side = (1-s)/w_i  height
                rem = 1.0
                total = 0.0
                ok = False
                for w in widths:
                    if w <= 0:
                        continue
                    h = (1.0 - s) / w
                    if h > rem + 1e-12:
                        h = rem
                    rem -= h
                    total += w * h
                # tail: `tail` equal squares in a column of width s
                tside = min(s, 1.0 / tail)
                ttotal = tail * tside
                cand = total + ttotal
                if cand > best_t:
                    best_t = cand
                    best_rows = ("mixed", widths, rem, s, tside)
                    best_out = None

    # Build output for the best found.
    out = []
    if best_rows is None:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    if best_rows[0] == "mixed":
        _, widths, rem, s, tside = best_rows
        # rows of equal squares of side (1-s)/w
        y = 0.0
        avail = 1.0
        for w in widths:
            if w <= 0:
                continue
            h = (1.0 - s) / w
            if h > avail:
                h = avail
            for j in range(w):
                out.append((s + (j + 0.5) * h, y + 0.5 * h, 0.0, h))
            y += h
            avail -= h
        # rotated column of `tail` squares of side tside at x in [0, s]
        cy = 0.0
        for _ in range(tail):
            out.append((0.5 * s, cy + 0.5 * tside, 0.0, tside))
            cy += tside
            if cy + tside > 1.0 + 1e-9:
                out.append((0.5, 0.5, 0.0, 0.0))
    else:
        out, _ = _build_rows(best_rows)

    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
