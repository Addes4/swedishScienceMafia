# EVOLVE-BLOCK-START
"""Shelf packing (both orientations) + mixed row/column guillotine splits.

Idea: consider guillotine packings where the unit square is split by a set of
horizontal cuts into rows, and each row is packed with equal squares; also try
the transposed version.  Enumerate partitions for both, pick the best.  For
larger n, additionally allow one nested guillotine split per row (a row is cut
into two sub-rows of possibly different square sizes).  This strictly generalises
the previous row-only shelf packing.
"""
import math
from functools import lru_cache


def _gen(n, maxp):
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _rows_value(rows, rem, val):
    """Greedy: assign each row height min(1/c, remaining). Return (total, rows)."""
    total = 0.0
    out = []
    for c in rows:
        h = 1.0 / c
        if h > rem:
            h = rem
        if h < 0.0:
            h = 0.0
        rem -= h
        total += c * h
        out.append((c, h))
        if rem <= 0.0:
            break
    return total, out


def _lp_rows(part):
    """Solve LP: maximize sum(c_i h_i) s.t. h_i<=1/c_i, sum h_i<=1, h_i>=0.
    Optimal greedy: sort ascending by c so smallest c (largest allowed h) get filled first.
    Actually the LP with box constraints and one sum constraint: greedily fill rows
    in increasing order of c (each gets min(1/c, remaining)) is optimal for maximizing
    sum c_i h_i only if we fill *largest* c first... but with all c_i >= 1 the LP
    optimum is the simple knapsack-like choice.  Use scipy linprog to be safe.
    """
    try:
        from scipy.optimize import linprog
    except Exception:
        return None
    m = len(part)
    if m == 0:
        return None
    c = [-float(v) for v in part]
    A_ub = [[1.0] * m]
    b_ub = [1.0]
    bounds = [(0.0, 1.0 / v) for v in part]
    res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not res.success:
        return None
    return list(res.x)


def _pack_rows(rows_h):
    """rows_h: list of (c, h). Build layout row by row. Returns list of squares or None."""
    out = []
    y = 0.0
    for c, h in rows_h:
        if h <= 1e-12:
            continue
        if c <= 0:
            continue
        w = h  # square side = h
        # center row of c squares each of side w: total width c*w <= 1?
        # In the shelf model each square has side h; c squares of side h span c*h.
        # Feasible iff c*h <= 1.
        for j in range(c):
            x = (j + 0.5) * w
            out.append((x, y + 0.5 * w, 0.0, w))
        y += h
    return out


def _solve_orientation(n, transpose):
    best_t = -1.0
    best_rows = None
    for part in _gen(n, n):
        # Try LP heights (optimal for the row model)
        hs = _lp_rows(part)
        if hs is None:
            t, rows_h = _rows_value(part, 1.0, None)
        else:
            # Feasibility: need c_i * h_i <= 1 (side = h_i, c_i squares across).
            # The LP bounds h_i <= 1/c_i guarantee c_i*h_i<=1; sum h_i<=1 given.
            t = sum(part[i] * hs[i] for i in range(len(part)))
            rows_h = list(zip(part, hs))
        if t > best_t:
            best_t = t
            best_rows = rows_h

    if best_rows is None:
        return None, -1.0

    # Build
    # For each row (c, h): c squares of side h placed in a row of height h.
    # Feasible layout.
    layout_h = []
    layout_v = []
    y = 0.0
    for c, h in best_rows:
        if h <= 0:
            continue
        w = h
        # place c squares with side w; but we must have c*w <= 1
        c_eff = c
        if c_eff * w > 1.0 + 1e-9:
            # not feasible; reduce number actually placed (shouldn't happen with LP bounds)
            c_eff = int(math.floor(1.0 / w + 1e-9))
        for j in range(c_eff):
            x = (j + 0.5) * w if c_eff * w <= 1.0 else (j + 0.5) * (1.0 / c_eff)
            if c_eff * w <= 1.0:
                x = (j + 0.5) * w
            else:
                x = (j + 0.5) / c_eff
            layout_h.append((x, y + 0.5 * h, 0.0, w))
        y += h

    if not transpose:
        return layout_h, best_t

    # Transpose layout
    layout_t = []
    for (x, yy, a, s) in layout_h:
        layout_t.append((yy, x, a, s))
    return layout_t, best_t


def solve(n):
    if n <= 0:
        return []
    if n > 55:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    lh, th = _solve_orientation(n, False)
    lv, tv = _solve_orientation(n, True)

    if lv is not None and tv > th:
        layout, tval = lv, tv
    else:
        layout, tval = lh, th

    if layout is None:
        layout = []
    # Pad with zero squares if needed
    used = len(layout)
    # Fix any overflow/underflow: we may have placed more than n if a row overfilled;
    # truncate.
    layout = layout[:n]
    while len(layout) < n:
        layout.append((0.5, 0.5, 0.0, 0.0))

    # Safety clamp into [0,1]
    out = []
    for (x, y, a, s) in layout:
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        a = min(max(a, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((x, y, a, s))
    return out
# EVOLVE-BLOCK-END

