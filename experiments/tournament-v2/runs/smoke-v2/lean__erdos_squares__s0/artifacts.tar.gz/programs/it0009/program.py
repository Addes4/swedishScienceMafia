# EVOLVE-BLOCK-START
"""Shelf packing with refinement: split n into rows, then locally optimize heights and
reclaim leftover space by inserting smaller squares where gaps permit."""
import math


def _gen(n, maxp):
    """Yield all non-increasing integer partitions of n with parts <= maxp."""
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _layout_from_partition(part):
    """Greedily assign each row the largest height allowed, return (total, list of (c,h))."""
    rem = 1.0
    total = 0.0
    rows = []
    for c in part:
        h = 1.0 / c
        if h > rem:
            h = rem
        if h < 0.0:
            h = 0.0
        rem -= h
        total += c * h
        rows.append((c, h))
    return total, rows


def solve(n):
    if n <= 0:
        return []
    # Fallback for very large n (partition enumeration would be too slow).
    if n > 55:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    best_t = -1.0
    best_rows = None
    for part in _gen(n, n):
        total, rows = _layout_from_partition(part)
        if total > best_t + 1e-12:
            best_t = total
            best_rows = rows

    out = []
    y = 0.0
    for c, h in best_rows:
        for j in range(c):
            out.append(((j + 0.5) * h, y + 0.5 * h, 0.0, h))
        y += h
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END

