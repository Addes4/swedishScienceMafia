# EVOLVE-BLOCK-START
"""Maximise sum of side lengths: shelf rows OR big-corner-square + L-strip grids
OR grid + strip packing."""
import math


def _gen(n, maxp):
    if n == 0:
        yield []
        return
    for p in range(min(n, maxp), 0, -1):
        for rest in _gen(n - p, p):
            yield [p] + rest


def _shelf(n):
    """Rows of equal squares (non-increasing row counts). Returns list of squares."""
    best_t = -1.0
    best_rows = None
    for part in _gen(n, n):
        rem = 1.0
        total = 0.0
        rows = []
        for c in part:
            h = 1.0 / c
            if h > rem:
                h = rem
            if h < 0.0:
                h = 0.0
            rem -= h
            total += c * h
            rows.append((c, h))
        if total > best_t:
            best_t = total
            best_rows = rows
    out = []
    y = 0.0
    for c, h in best_rows:
        for j in range(c):
            out.append(((j + 0.5) * h, y + 0.5 * h, 0.0, h))
        y += h
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _corner_L(n):
    """One big square side a at bottom-left; fill right strip (width 1-a) and
    top strip (width a, height 1-a) each with a uniform grid of side b."""
    best_sq = None
    best_score = -1.0
    A = 160
    B = 160
    for ia in range(1, A):
        a = ia / A
        for ib in range(1, B):
            b = ib / B
            if b > a or b > 1.0 - a:
                continue
            cols_r = int((1.0 - a + 1e-9) / b)
            rows_r = int((1.0 + 1e-9) / b)
            cols_t = int((a + 1e-9) / b)
            rows_t = int((1.0 - a + 1e-9) / b)
            cap = cols_r * rows_r + cols_t * rows_t
            if cap < n - 1:
                continue
            use = n - 1
            score = a + use * b
            if score > best_score:
                best_score = score
                best_sq = (a, b, cols_r, rows_r, cols_t, rows_t, cap)
    if best_sq is None:
        return None
    a, b, cols_r, rows_r, cols_t, rows_t, cap = best_sq
    out = [(a / 2.0, a / 2.0, 0.0, a)]
    need = n - 1
    placed = 0
    for i in range(cols_r):
        for j in range(rows_r):
            if placed >= need:
                break
            cx = a + (i + 0.5) * b
            cy = (j + 0.5) * b
            out.append((cx, cy, 0.0, b))
            placed += 1
        if placed >= need:
            break
    for i in range(cols_t):
        for j in range(rows_t):
            if placed >= need:
                break
            cx = (i + 0.5) * b
            cy = a + (j + 0.5) * b
            out.append((cx, cy, 0.0, b))
            placed += 1
        if placed >= need:
            break
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _grid_strip(n):
    """An m x m grid of side 1/m at bottom-left; leftover right column of width
    w = 1 - m/m = 0 (full width) so instead: place an m x m grid occupying a
    square of side a = m*b' ... Simpler: corner square of side g = mg/m where we
    take G x G grid of side s = g/G with G chosen so g close to 1, then pack the
    thin strips. Enumerate grid counts gr x gc and grid side s, pack remaining
    rectangle strips with second size t."""
    best_sq = None
    best_score = -1.0
    # grid of gc cols x gr rows of side s placed bottom-left
    # leftover: right strip width 1 - gc*s (full height), and top strip height
    # 1 - gr*s for x in [0, gc*s].
    S = 120
    for igc in range(1, 24):
        for igr in range(1, 24):
            for isx in range(1, S):
                s = isx / S
                w = 1.0 - igc * s
                h = 1.0 - igr * s
                if w < -1e-9 or h < -1e-9:
                    continue
                # second size t, fit in right strip (w wide, full height 1) and
                # top strip (gc*s wide, h tall)
                for it in range(1, S):
                    t = it / S
                    if t > s + 1e-9:
                        break
                    if w > 1e-9:
                        cols_r = int((w + 1e-9) / t)
                        rows_r = int((1.0 + 1e-9) / t)
                    else:
                        cols_r = 0
                        rows_r = 0
                    if h > 1e-9:
                        cols_t = int((igc * s + 1e-9) / t)
                        rows_t = int((h + 1e-9) / t)
                    else:
                        cols_t = 0
                        rows_t = 0
                    cap_grid = igc * igr
                    cap2 = cols_r * rows_r + cols_t * rows_t
                    if cap_grid + cap2 < n:
                        continue
                    use2 = min(cap2, n - cap_grid)
                    score = cap_grid * s + use2 * t
                    if score > best_score:
                        best_score = score
                        best_sq = (igc, igr, s, t, w, h, cols_r, rows_r,
                                   cols_t, rows_t, cap_grid)
    if best_sq is None:
        return None
    igc, igr, s, t, w, h, cols_r, rows_r, cols_t, rows_t, cap_grid = best_sq
    out = []
    for i in range(igc):
        for j in range(igr):
            out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    placed = len(out)
    if placed < n and cols_r > 0:
        for i in range(cols_r):
            for j in range(rows_r):
                if placed >= n:
                    break
                cx = igc * s + (i + 0.5) * t
                cy = (j + 0.5) * t
                out.append((cx, cy, 0.0, t))
                placed += 1
            if placed >= n:
                break
    if placed < n and cols_t > 0:
        for i in range(cols_t):
            for j in range(rows_t):
                if placed >= n:
                    break
                cx = (i + 0.5) * t
                cy = igr * s + (j + 0.5) * t
                out.append((cx, cy, 0.0, t))
                placed += 1
            if placed >= n:
                break
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n > 55:
        k = math.isqrt(n)
        side = 1.0 / k
        out = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
        return out[:n]

    cands = [_shelf(n)]
    cl = _corner_L(n)
    if cl is not None:
        cands.append(cl)
    gs = _grid_strip(n)
    if gs is not None:
        cands.append(gs)
    best = None
    best_s = -1.0
    for c in cands:
        s = sum(t[3] for t in c)
        if s > best_s:
            best_s = s
            best = c
    return best
# EVOLVE-BLOCK-END

