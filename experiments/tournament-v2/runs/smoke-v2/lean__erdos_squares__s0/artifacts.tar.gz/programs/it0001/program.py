# EVOLVE-BLOCK-START
"""Packing n squares in the unit square by gradient ascent with overlap repulsion.

We start from a grid-ish layout and iteratively:
  * push overlapping (or too-close) squares apart,
  * grow the squares,
  * keep everything inside [0,1]^2 (rotated bounding box aware).
Finally we rescale so the largest useful square fits, and zero-pad if needed.
"""
import math
import random
import numpy as np


def _bbox_half(angle, side):
    """Half-extent of a rotated square's axis-aligned bounding box along x and y."""
    c = abs(math.cos(2 * math.pi * angle))
    s = abs(math.sin(2 * math.pi * angle))
    h = side * 0.5
    return h * (c + s), h * (c + s)


def _sep(a, b):
    """Approximate overlap/separation measure between two squares.

    Returns a positive number when the squares (as rotated squares) are
    separated, using separating-axis on the two square orientations plus
    the axis-aligned directions.  Negative => overlap.
    """
    ax, ay, aa, asd = a
    bx, by, ba, bsd = b
    dx = bx - ax
    dy = by - ay
    # axes to test: x, y, and each square's two edge normals
    axes = [(1.0, 0.0), (0.0, 1.0)]
    for ang, sd in ((aa, asd), (ba, bsd)):
        t = 2 * math.pi * ang
        ux, uy = math.cos(t), math.sin(t)
        # normal to edge
        axes.append((-uy, ux))
    best = 1e9
    for ux, uy in axes:
        # projection radius of square a
        t = 2 * math.pi * aa
        ax1, ay1 = math.cos(t), math.sin(t)
        ra = asd * 0.5 * (abs(ax1 * ux + ay1 * uy) + abs(-ay1 * ux + ax1 * uy))
        t = 2 * math.pi * ba
        bx1, by1 = math.cos(t), math.sin(t)
        rb = bsd * 0.5 * (abs(bx1 * ux + by1 * uy) + abs(-by1 * ux + bx1 * uy))
        dist = abs(dx * ux + dy * uy)
        best = min(best, dist - ra - rb)
    return best


def _relax(squares, iters=3500, rng=None):
    n = len(squares)
    x = np.array([s[0] for s in squares], float)
    y = np.array([s[1] for s in squares], float)
    a = np.array([s[2] for s in squares], float)
    s = np.array([s[3] for s in squares], float)
    if n == 0:
        return squares
    lr = 0.03
    for it in range(iters):
        # gradient from pairwise separation
        gx = np.zeros(n)
        gy = np.zeros(n)
        gs = np.zeros(n)
        for i in range(n):
            for j in range(i + 1, n):
                sep = _sep((x[i], y[i], a[i], s[i]), (x[j], y[j], a[j], s[j]))
                if sep < 0.05:
                    dx = x[j] - x[i]
                    dy = y[j] - y[i]
                    d = math.hypot(dx, dy) + 1e-9
                    pen = (0.05 - sep)
                    ux, uy = dx / d, dy / d
                    gx[i] -= pen * ux
                    gy[i] -= pen * uy
                    gx[j] += pen * ux
                    gy[j] += pen * uy
                    # shrinking helps resolve overlap
                    gs[i] -= 0.5 * pen
                    gs[j] -= 0.5 * pen
        # grow toward filling
        gs += 1.0
        x += lr * gx
        y += lr * gy
        s += lr * gs
        # keep inside
        for i in range(n):
            hx, hy = _bbox_half(a[i], s[i])
            x[i] = min(max(x[i], hx), 1 - hx)
            y[i] = min(max(y[i], hy), 1 - hy)
        s = np.maximum(s, 0.0)
        if it % 700 == 699:
            lr *= 0.75
    return [(float(x[i]), float(y[i]), float(a[i]), float(s[i])) for i in range(n)]


def solve(n):
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0 if n == 1 else 0.0)]
    rng = random.Random(12345)
    best = None
    best_sum = -1.0
    tries = 1
    for t in range(tries):
        k = math.isqrt(n)
        init = []
        # grid positions
        m = int(math.ceil(math.sqrt(n)))
        side0 = 1.0 / m
        for idx in range(n):
            i = idx % m
            j = idx // m
            cx = (i + 0.5) * side0
            cy = (j + 0.5) * side0
            ang = 0.0
            init.append((cx, cy, ang, side0 * 0.95))
        res = _relax(init, iters=2500, rng=rng)
        tot = sum(r[3] for r in res)
        if tot > best_sum:
            best_sum = tot
            best = res
    # rescale so everything fits tightly (fix any overflow), then re-relax little
    return best
# EVOLVE-BLOCK-END
