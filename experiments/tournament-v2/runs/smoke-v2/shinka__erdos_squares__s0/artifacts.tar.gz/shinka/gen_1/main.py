# EVOLVE-BLOCK-START
"""Adaptive guillotine packing of squares in the unit square.

Key ideas:
  - Recursively split the unit square into rectangles (guillotine cuts).
  - Place an inscribed square in each rectangle; alternate axis-aligned and
    45-degree rotations so rotated squares can use corner slack.
  - Use a non-trivial split ratio (golden-ratio ~0.618) for better packing
    than the uniform 0.5 split.
  - After placement, run a local growth pass to enlarge the smallest squares
    into available slack, checking disjointness with a rotated-SAT test.
"""
import math

GOLDEN = 0.6180339887498949
ROT45 = 0.25


def _rects_guillotine(n, ratio=GOLDEN):
    """Return a list of n rectangles (x, y, w, h) tiling the unit square."""
    # Start with the unit square as a single rectangle.
    rects = [(0.0, 0.0, 1.0, 1.0)]
    while len(rects) < n:
        # Pick the rectangle with the largest area to split (best for balance).
        idx = max(range(len(rects)), key=lambda i: rects[i][2] * rects[i][3])
        x, y, w, h = rects.pop(idx)
        # Split along the longer dimension, at the golden ratio.
        if w >= h:
            w1 = w * ratio
            w2 = w - w1
            rects.append((x, y, w1, h))
            rects.append((x + w1, y, w2, h))
        else:
            h1 = h * ratio
            h2 = h - h1
            rects.append((x, y, w, h1))
            rects.append((x, y + h1, w, h2))
    return rects


def _inscribed_square(rect, rotated):
    """Return (cx, cy, angle, side) for the largest square inscribed in rect,
    either axis-aligned or rotated 45 degrees."""
    x, y, w, h = rect
    if not rotated:
        s = min(w, h)
        return (x + w * 0.5, y + h * 0.5, 0.0, s)
    # 45-degree rotated square inside a w x h box:
    # For a square of side s rotated 45 deg, its bounding box is s/sqrt(2) wide.
    # Max s such that s/sqrt(2) <= w and <= h  ->  s = sqrt(2) * min(w, h).
    # But it must fit with the diagonal inside the box: s*sqrt(2) <= min(w,h)*? 
    # Actually the rotated square's axis-aligned bounding box has side s*sqrt(2).
    s = min(w, h) / math.sqrt(2.0)
    return (x + w * 0.5, y + h * 0.5, ROT45, s)


def _corners_sat(a, b):
    """Return True if two squares a=(cx,cy,angle,side) and b overlap.
    Uses separating axis theorem on the 4 edge normals of each square."""
    def corners(cx, cy, angle, side):
        # angle is fraction of full turn
        th = angle * 2.0 * math.pi
        c, s = math.cos(th), math.sin(th)
        h = side * 0.5
        pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
        return [(cx + p[0] * c - p[1] * s, cy + p[0] * s + p[1] * c) for p in pts]

    pa = corners(*a)
    pb = corners(*b)

    def axes(pts):
        ax = []
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            # normal
            nx, ny = -ey, ex
            ln = math.hypot(nx, ny)
            if ln > 1e-12:
                ax.append((nx / ln, ny / ln))
        return ax

    for nx, ny in axes(pa) + axes(pb):
        proj_a = [p[0] * nx + p[1] * ny for p in pa]
        proj_b = [p[0] * nx + p[1] * ny for p in pb]
        if max(proj_a) <= min(proj_b) + 1e-9 or max(proj_b) <= min(proj_a) + 1e-9:
            return False  # separating axis found -> no overlap
    return True  # all axes overlap -> overlap


def _clip_inside(sq):
    """Clamp square centre so it stays inside the unit square, adjusting side if needed."""
    cx, cy, ang, side = sq
    if side <= 0:
        return (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), ang, 0.0)
    # bounding half-extent for rotated square
    th = ang * 2.0 * math.pi
    c, s = abs(math.cos(th)), abs(math.sin(th))
    half = side * 0.5 * (c + s)
    if half > 0.5:
        # shrink to fit
        side = 1.0 / (c + s)
        half = side * 0.5 * (c + s)
        if side <= 1e-9:
            return (0.5, 0.5, ang, 0.0)
    cx = min(max(cx, half), 1.0 - half)
    cy = min(max(cy, half), 1.0 - half)
    return (cx, cy, ang, side)


def _grow_pass(squares, iters=3):
    """Try to grow the smallest squares into slack; keep if no overlap."""
    n = len(squares)
    for _ in range(iters):
        # order by side ascending
        order = sorted(range(n), key=lambda i: squares[i][3])
        for i in order:
            cx, cy, ang, side = squares[i]
            if side <= 1e-9:
                continue
            # try increasing side
            for factor in (1.10, 1.05, 1.02):
                new_side = side * factor
                cand = _clip_inside((cx, cy, ang, new_side))
                if cand[3] <= side + 1e-12:
                    continue
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if squares[j][3] <= 1e-12:
                        continue
                    if _corners_sat(cand, squares[j]):
                        ok = False
                        break
                if ok:
                    squares[i] = cand
                    break
    return squares


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Build a guillotine tiling with n rectangles.
    rects = _rects_guillotine(n)

    # Place a square in each rectangle; alternate rotation for variety.
    squares = []
    for i, r in enumerate(rects):
        rotated = (i % 2 == 1)
        sq = _inscribed_square(r, rotated)
        squares.append(_clip_inside(sq))

    # Local growth pass to squeeze more side length out of slack.
    squares = _grow_pass(squares, iters=3)

    # Pad with zero-size squares if somehow short.
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
# EVOLVE-BLOCK-END
