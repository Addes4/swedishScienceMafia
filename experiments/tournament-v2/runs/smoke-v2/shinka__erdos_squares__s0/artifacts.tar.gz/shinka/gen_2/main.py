# EVOLVE-BLOCK-START
"""Improved packing: mix grid sizes to use leftover space better than pure k x k grid."""
import math


def _layout_grid(a, n):
    """a x a grid of side 1/a, plus leftover zero-size squares."""
    side = 1.0 / a
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(a) for j in range(a)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n], a


def _layout_mixed(a, b, n):
    """Top (a-1) rows of size 1/a, bottom row of size 1/b squares.
    Requires (a-1)/a + 1/b <= 1 => 1/b <= 1/a => b >= a.
    Number of squares: (a-1)*a + b. If that's less than n, pad with zeros.
    If more than n, truncate (shouldn't happen if we choose b carefully).
    """
    if b < a:
        return None, -1
    # check fit: (a-1) rows of height 1/a, bottom row of height 1/b
    # total height = (a-1)/a + 1/b <= 1  <=>  1/b <= 1/a <=> b >= a. OK.
    count = (a - 1) * a + b
    if count < n:
        return None, -1
    squares = []
    sa = 1.0 / a
    sb = 1.0 / b
    y = 0.0
    # top rows of size sa
    for r in range(a - 1):
        for c in range(a):
            squares.append(((c + 0.5) * sa, y + 0.5 * sa, 0.0, sa))
        y += sa
    # bottom row of size sb
    for c in range(b):
        squares.append(((c + 0.5) * sb, y + 0.5 * sb, 0.0, sb))
    # pad or truncate
    if len(squares) > n:
        # keep the largest ones (all sa > sb here since a < b typically)
        # just truncate keeping full-size squares first
        squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = sum(s[3] for s in squares)
    return squares, total


def _layout_two_rows(a, b, pa, pb, n):
    """pa rows of size 1/a and pb rows of size 1/b.
    Constraint: pa/a + pb/b <= 1.
    Squares: pa*a + pb*b. Pad/truncate to n.
    """
    if pa / a + pb / b > 1 + 1e-9:
        return None, -1
    count = pa * a + pb * b
    if count < n:
        return None, -1
    squares = []
    sa = 1.0 / a
    sb = 1.0 / b
    y = 0.0
    for r in range(pa):
        for c in range(a):
            squares.append(((c + 0.5) * sa, y + 0.5 * sa, 0.0, sa))
        y += sa
    for r in range(pb):
        for c in range(b):
            squares.append(((c + 0.5) * sb, y + 0.5 * sb, 0.0, sb))
        y += sb
    if len(squares) > n:
        squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = sum(s[3] for s in squares)
    return squares, total


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    best_squares = None
    best_total = -1.0

    # Candidate 1: pure a x a grid
    for a in range(1, math.isqrt(n) + 3):
        sq, tot = _layout_grid(a, n)
        if tot > best_total:
            best_total = tot
            best_squares = sq

    # Candidate 2: mixed (a-1) rows of size 1/a + bottom row of size 1/b
    # Try a up to isqrt(n)+2, b chosen so count >= n and b maximized
    for a in range(2, math.isqrt(n) + 4):
        need = n - (a - 1) * a
        if need <= 0:
            continue
        # choose smallest b >= a such that b >= need (so count >= n) and b >= a
        b = max(a, need)
        # also try b slightly larger or smaller within reason
        for bb in range(max(a, need - 2), max(a, need) + 4):
            if bb < a:
                continue
            sq, tot = _layout_mixed(a, bb, n)
            if sq is not None and tot > best_total:
                best_total = tot
                best_squares = sq

    # Candidate 3: two different row sizes
    max_a = math.isqrt(n) + 3
    for a in range(1, max_a + 1):
        for b in range(a, max_a + 2):
            for pa in range(1, a + 2):
                # max pb such that pa/a + pb/b <= 1
                max_pb = int((1.0 - pa / a) * b + 1e-9)
                for pb in range(0, max_pb + 1):
                    if pa * a + pb * b < n:
                        continue
                    sq, tot = _layout_two_rows(a, b, pa, pb, n)
                    if sq is not None and tot > best_total:
                        best_total = tot
                        best_squares = sq

    if best_squares is None:
        # fallback to baseline
        k = max(1, math.isqrt(n))
        side = 1.0 / k
        best_squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                        for i in range(k) for j in range(k)]
        while len(best_squares) < n:
            best_squares.append((0.5, 0.5, 0.0, 0.0))
        best_squares = best_squares[:n]

    return best_squares[:n]
# EVOLVE-BLOCK-END
