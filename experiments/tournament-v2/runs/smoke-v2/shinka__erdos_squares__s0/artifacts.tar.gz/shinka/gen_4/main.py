# EVOLVE-BLOCK-START
"""Hybrid structured packing: pick the best of several valid layouts."""
import math


def _grid_layout(n, K):
    """Place n squares of side 1/K in a K x K grid (top-left aligned)."""
    side = 1.0 / K
    squares = []
    for i in range(K):
        for j in range(K):
            if len(squares) < n:
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _strip_layout(n):
    """k x k grid of side s on top, plus m = n - k^2 extra squares in a strip
    of height t at the bottom, arranged in b rows x a columns."""
    k = math.isqrt(n)
    m = n - k * k
    if m == 0 or k == 0:
        return None
    best = None
    best_sum = -1.0
    for b in range(1, m + 1):
        a = (m + b - 1) // b  # ceil(m / b)
        if b > a:
            continue
        t = b / a          # strip height
        s = (1.0 - t) / k  # grid side so that k rows of side s fill height 1-t
        if s <= 1e-12:
            continue
        u = 1.0 / a        # strip square side
        total = k * k * s + m * u
        if total > best_sum:
            best_sum = total
            best = (s, t, a, b, u)
    if best is None:
        return None
    s, t, a, b, u = best
    squares = []
    # k x k grid of side s occupying [0, 1-t] x [t, 1]
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * s, t + (j + 0.5) * s, 0.0, s))
    # strip of m squares of side u in b rows x a columns occupying [0,1] x [0,t]
    placed = 0
    for j in range(b):
        for i in range(a):
            if placed >= m:
                break
            squares.append(((i + 0.5) * u, (j + 0.5) * u, 0.0, u))
            placed += 1
        if placed >= m:
            break
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides.

    Evaluate several structured layouts and return the best:
      A) floor(sqrt(n)) x floor(sqrt(n)) uniform grid.
      B) ceil(sqrt(n)) x ceil(sqrt(n)) uniform grid (first n cells used).
      C) k x k grid of side s on top plus m = n - k^2 extra squares in a
         bottom strip of height t, arranged in b rows x a columns.
    """
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    k = math.isqrt(n)
    K = k if k * k == n else k + 1

    candidates = []
    if k > 0:
        candidates.append(_grid_layout(n, k))
    if K != k:
        candidates.append(_grid_layout(n, K))
    strip = _strip_layout(n)
    if strip is not None:
        candidates.append(strip)

    best = max(candidates, key=lambda cand: sum(sq[3] for sq in cand))
    return best[:n]
# EVOLVE-BLOCK-END