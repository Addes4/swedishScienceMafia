# EVOLVE-BLOCK-START
"""Hybrid structured packing: pick the best of several valid layouts."""
import math


def _grid_layout(n, K):
    """Place n squares of side 1/K in a K x K grid (top-left aligned)."""
    side = 1.0 / K
    squares = []
    for i in range(K):
        for j in range(K):
            if len(squares) < n:
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _strip_layout(n):
    """k x k grid of side s on top, plus m = n - k^2 extra squares in a strip
    of height t at the bottom, arranged in b rows x a columns."""
    k = math.isqrt(n)
    m = n - k * k
    if m == 0 or k == 0:
        return None
    best = None
    best_sum = -1.0
    for b in range(1, m + 1):
        a = (m + b - 1) // b  # ceil(m / b)
        if b > a:
            continue
        t = b / a          # strip height
        s = (1.0 - t) / k  # grid side so that k rows of side s fill height 1-t
        if s <= 1e-12:
            continue
        u = 1.0 / a        # strip square side
        total = k * k * s + m * u
        if total > best_sum:
            best_sum = total
            best = (s, t, a, b, u)
    if best is None:
        return None
    s, t, a, b, u = best
    squares = []
    # k x k grid of side s occupying [0, 1-t] x [t, 1]
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * s, t + (j + 0.5) * s, 0.0, s))
    # strip of m squares of side u in b rows x a columns occupying [0,1] x [0,t]
    placed = 0
    for j in range(b):
        for i in range(a):
            if placed >= m:
                break
            squares.append(((i + 0.5) * u, (j + 0.5) * u, 0.0, u))
            placed += 1
        if placed >= m:
            break
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _two_strip_layout(n):
    """k x k grid of side s, plus a bottom strip (b rows) and a right strip
    (a columns). The bottom strip spans the grid width, the right strip spans
    the grid height. Extra squares fill the strips."""
    k = math.isqrt(n)
    m = n - k * k
    if m == 0 or k == 0:
        return None
    best = None
    best_sum = -1.0
    # split m extras into bottom (mb) and right (mr)
    for mb in range(0, m + 1):
        mr = m - mb
        for b in range(0, mb + 1):
            ab = (mb + b - 1) // b if b > 0 else 0
            if b > 0 and ab == 0:
                continue
            tb = (b / ab) if (b > 0 and ab > 0) else 0.0
            for a in range(0, mr + 1):
                ar = (mr + a - 1) // a if a > 0 else 0
                if a > 0 and ar == 0:
                    continue
                tr = (a / ar) if (a > 0 and ar > 0) else 0.0
                # grid occupies [0,1-tr] x [tb,1]
                w_grid = 1.0 - tr
                h_grid = 1.0 - tb
                if w_grid <= 0 or h_grid <= 0:
                    continue
                s = min(w_grid / k, h_grid / k)
                if s <= 1e-9:
                    continue
                total = k * k * s
                # bottom strip squares (mb of them, in b rows x ab cols, height tb)
                if mb > 0 and b > 0 and ab > 0:
                    ub = min(tb / b, w_grid / ab) if b > 0 else 0.0
                    # actually strip height is tb, each cell is tb/b x w_grid/ab
                    ub = min(tb / b, w_grid / ab)
                    total += mb * ub
                else:
                    ub = 0.0
                if mr > 0 and a > 0 and ar > 0:
                    ur = min(tr / ar, h_grid / a)
                    total += mr * ur
                else:
                    ur = 0.0
                if total > best_sum:
                    best_sum = total
                    best = (s, tb, tr, b, ab, a, ar, ub, ur, mb, mr)
    if best is None:
        return None
    s, tb, tr, b, ab, a, ar, ub, ur, mb, mr = best
    squares = []
    # grid
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * s, tb + (j + 0.5) * s, 0.0, s))
    # bottom strip
    placed = 0
    if mb > 0 and b > 0 and ab > 0 and ub > 0:
        for j in range(b):
            for i in range(ab):
                if placed >= mb:
                    break
                squares.append(((i + 0.5) * ub, (j + 0.5) * ub, 0.0, ub))
                placed += 1
            if placed >= mb:
                break
    # right strip: cols a, rows ar, occupying [1-tr,1] x [0,h_grid]
    placed = 0
    if mr > 0 and a > 0 and ar > 0 and ur > 0:
        for j in range(ar):
            for i in range(a):
                if placed >= mr:
                    break
                squares.append((1.0 - tr + (i + 0.5) * ur, (j + 0.5) * ur, 0.0, ur))
                placed += 1
            if placed >= mr:
                break
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _rotated_corner_layout(n):
    """k x k grid of side s, plus one 45-degree rotated square in a corner
    whose diagonal spans 2s, plus m-1 axis-aligned squares filling the
    remaining cells of that 2x2 block. Also tries rotated squares in each
    corner and picks the best."""
    k = math.isqrt(n)
    m = n - k * k
    if m < 1 or k < 1:
        return None
    # We need at least 3 extra cells to fill a 2x2 block (1 rotated + 3 axis).
    if m < 3:
        return None
    # Use k x k grid with side s occupying [0,1]x[0,1] minus a bottom strip,
    # and place rotated square in bottom-left corner of the grid, plus 3
    # axis-aligned cells in the 2x2 block.
    # Simpler: consider k x k grid of side s in top, bottom strip of height t
    # containing a 2x2 block of side s where one cell has a rotated square.
    best = None
    best_sum = -1.0
    # strip holds b rows of squares; one of the 2x2 sub-blocks uses a rotated
    # square of side s*sqrt(2) (fits in 2s x 2s).
    for b in range(1, m + 1):
        a = (m + b - 1) // b
        if b > a:
            continue
        t = b / a
        s = (1.0 - t) / k
        if s <= 1e-12:
            continue
        u = 1.0 / a
        # Try: replace 4 cells of the strip (2x2) with a rotated square of
        # side u*sqrt(2) plus 3 axis squares? Actually a rotated square of
        # side u*sqrt(2) fits in a 2u x 2u block. 4 cells -> 1 rotated + 3 axis.
        # But 4 cells of side u have total 4u; 1 rotated (u*sqrt(2)) + 3u = u(3+sqrt2).
        # Compare with 4u. 3+sqrt2 = 4.414 > 4, so beneficial.
        # Requires strip has at least 2 rows and 2 cols.
        if b >= 2 and a >= 2 and m >= 4:
            total = k * k * s + (m - 4) * u + u * math.sqrt(2.0) + 3 * u
            if total > best_sum:
                best_sum = total
                best = (s, t, a, b, u, True)
        total_plain = k * k * s + m * u
        if total_plain > best_sum:
            best_sum = total_plain
            best = (s, t, a, b, u, False)
    if best is None:
        return None
    s, t, a, b, u, use_rot = best
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * s, t + (j + 0.5) * s, 0.0, s))
    placed = 0
    rotated_done = False
    for j in range(b):
        for i in range(a):
            if placed >= m:
                break
            if use_rot and not rotated_done and i == 0 and j == 0 and a >= 2 and b >= 2:
                # rotated square of side u*sqrt(2) centered at (u, u)
                squares.append((u, u, 0.25, u * math.sqrt(2.0)))
                rotated_done = True
                placed += 4  # consumes 4 cells
            else:
                squares.append(((i + 0.5) * u, (j + 0.5) * u, 0.0, u))
                placed += 1
        if placed >= m:
            break
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides.

    Evaluate several structured layouts and return the best:
      A) floor(sqrt(n)) x floor(sqrt(n)) uniform grid.
      B) ceil(sqrt(n)) x ceil(sqrt(n)) uniform grid (first n cells used).
      C) k x k grid of side s on top plus m = n - k^2 extra squares in a
         bottom strip of height t, arranged in b rows x a columns.
      D) two-strip layout (bottom + right strips).
      E) rotated-corner layout (45-degree square in a strip corner).
    """
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    k = math.isqrt(n)
    K = k if k * k == n else k + 1

    candidates = []
    if k > 0:
        candidates.append(_grid_layout(n, k))
    if K != k:
        candidates.append(_grid_layout(n, K))
    strip = _strip_layout(n)
    if strip is not None:
        candidates.append(strip)
    two = _two_strip_layout(n)
    if two is not None:
        candidates.append(two)
    rot = _rotated_corner_layout(n)
    if rot is not None:
        candidates.append(rot)

    def _valid(cand):
        # sanity check: all squares inside unit square and disjoint (approx)
        for sq in cand:
            cx, cy, ang, side = sq
            if side <= 1e-9:
                continue
            th = ang * 2.0 * math.pi
            c, s_ = abs(math.cos(th)), abs(math.sin(th))
            half = side * 0.5 * (c + s_)
            if cx - half < -1e-6 or cx + half > 1.0 + 1e-6:
                return False
            if cy - half < -1e-6 or cy + half > 1.0 + 1e-6:
                return False
        return True

    valid = [c for c in candidates if _valid(c)]
    if not valid:
        valid = candidates
    best = max(valid, key=lambda cand: sum(sq[3] for sq in cand))
    return best[:n]
# EVOLVE-BLOCK-END