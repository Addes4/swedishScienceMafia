# EVOLVE-BLOCK-START
"""Guillotine packing of squares in the unit square with greedy local growth.

Strategy:
  - Start with the unit square and repeatedly split the rectangle whose
    inscribed square is largest, choosing the split ratio that maximises the
    minimum of the two children's inscribed-square sides (balanced split).
  - In each rectangle place an inscribed square; alternate orientation between
    axis-aligned and 45-degree to exploit corner slack.
  - Run a strong local growth pass: repeatedly try to enlarge the smallest
    squares (with small centre/angle perturbations) as long as disjointness
    (rotated SAT test) is preserved.
"""
import math


def _inscribed_side(w, h):
    """Side of the largest axis-aligned square inscribed in a w x h rectangle."""
    return min(w, h)


def _split_ratio(w, h):
    """Return the fraction t in (0,1) along the longer axis that balances the
    inscribed-square sides of the two children. For a w x h rectangle split
    along width, child sides are min(t*w, h) and min((1-t)*w, h). Choosing
    t*w = (1-t)*w = w/2 gives equal sides when h >= w/2; otherwise we cap
    the smaller side at h. A balanced choice is t = 0.5, but if h < w/2 we
    can do better by choosing t = h/w (so first child is exactly h wide,
    second child gets the rest). Symmetric logic along height.
    """
    if w >= h:
        # split along width
        if h >= w * 0.5:
            return 0.5, True
        # first child width = h (square), second child = w - h
        return h / w, True
    else:
        if w >= h * 0.5:
            return 0.5, False
        return w / h, False


def _rects_guillotine(n):
    """Return a list of n rectangles (x, y, w, h) tiling the unit square."""
    rects = [(0.0, 0.0, 1.0, 1.0)]
    while len(rects) < n:
        # Pick the rectangle whose inscribed square is largest (best to split).
        idx = max(range(len(rects)), key=lambda i: min(rects[i][2], rects[i][3]))
        x, y, w, h = rects.pop(idx)
        t, along_w = _split_ratio(w, h)
        if along_w:
            w1 = w * t
            w2 = w - w1
            rects.append((x, y, w1, h))
            rects.append((x + w1, y, w2, h))
        else:
            h1 = h * t
            h2 = h - h1
            rects.append((x, y, w, h1))
            rects.append((x, y + h1, w, h2))
    return rects


def _random_rects_guillotine(n, rng):
    """Randomized guillotine tiling: pick a rectangle to split (weighted by
    inscribed-square side) and split at a random ratio in a sensible range."""
    rects = [(0.0, 0.0, 1.0, 1.0)]
    while len(rects) < n:
        # Weighted selection by inscribed side (larger rectangles more likely).
        weights = [min(r[2], r[3]) for r in rects]
        tot = sum(weights)
        if tot <= 1e-12:
            idx = rng.randrange(len(rects))
        else:
            pick = rng.random() * tot
            acc = 0.0
            idx = len(rects) - 1
            for i, wgt in enumerate(weights):
                acc += wgt
                if pick <= acc:
                    idx = i
                    break
        x, y, w, h = rects.pop(idx)
        # Random split ratio in [0.35, 0.65] along the longer axis.
        t = 0.35 + 0.30 * rng.random()
        if w >= h:
            w1 = w * t
            w2 = w - w1
            rects.append((x, y, w1, h))
            rects.append((x + w1, y, w2, h))
        else:
            h1 = h * t
            h2 = h - h1
            rects.append((x, y, w, h1))
            rects.append((x, y + h1, w, h2))
    return rects


def _inscribed_square(rect, rotated):
    """Return (cx, cy, angle, side) for the largest square inscribed in rect."""
    x, y, w, h = rect
    if not rotated:
        s = min(w, h)
        return (x + w * 0.5, y + h * 0.5, 0.0, s)
    # 45-degree rotated square: bounding box side s*sqrt(2) must fit in w x h.
    s = min(w, h) / math.sqrt(2.0)
    return (x + w * 0.5, y + h * 0.5, 0.25, s)


def _corners(cx, cy, angle, side):
    th = angle * 2.0 * math.pi
    c, s = math.cos(th), math.sin(th)
    h = side * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + p[0] * c - p[1] * s, cy + p[0] * s + p[1] * c) for p in pts]


def _overlap(a, b):
    """True if squares a and b overlap (rotated SAT)."""
    pa = _corners(*a)
    pb = _corners(*b)

    def axes(pts):
        ax = []
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            nx, ny = -ey, ex
            ln = math.hypot(nx, ny)
            if ln > 1e-12:
                ax.append((nx / ln, ny / ln))
        return ax

    for nx, ny in axes(pa) + axes(pb):
        proj_a = [p[0] * nx + p[1] * ny for p in pa]
        proj_b = [p[0] * nx + p[1] * ny for p in pb]
        if max(proj_a) <= min(proj_b) + 1e-9 or max(proj_b) <= min(proj_a) + 1e-9:
            return False
    return True


def _clip_inside(sq):
    """Clamp square centre so it stays inside the unit square, shrinking if needed."""
    cx, cy, ang, side = sq
    if side <= 0:
        return (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), ang, 0.0)
    th = ang * 2.0 * math.pi
    c, s = abs(math.cos(th)), abs(math.sin(th))
    half = side * 0.5 * (c + s)
    if half > 0.5:
        side = 1.0 / (c + s)
        half = side * 0.5 * (c + s)
        if side <= 1e-9:
            return (0.5, 0.5, ang, 0.0)
    cx = min(max(cx, half), 1.0 - half)
    cy = min(max(cy, half), 1.0 - half)
    return (cx, cy, ang, side)


def _grow_pass(squares, iters=8):
    """Try to grow the smallest squares into slack; keep if no overlap."""
    n = len(squares)
    for _ in range(iters):
        order = sorted(range(n), key=lambda i: squares[i][3])
        improved = False
        for i in order:
            cx, cy, ang, side = squares[i]
            if side <= 1e-9:
                continue
            best = squares[i]
            # try growing side, with small centre/angle perturbations
            for factor in (1.20, 1.10, 1.05, 1.02, 1.005):
                for dx in (0.0, 0.005, -0.005, 0.02, -0.02, 0.05, -0.05):
                    for dy in (0.0, 0.005, -0.005, 0.02, -0.02, 0.05, -0.05):
                        cand = _clip_inside((cx + dx, cy + dy, ang, side * factor))
                        if cand[3] <= best[3] + 1e-12:
                            continue
                        ok = True
                        for j in range(n):
                            if j == i or squares[j][3] <= 1e-12:
                                continue
                            if _overlap(cand, squares[j]):
                                ok = False
                                break
                        if ok:
                            best = cand
                            break
                    if best[3] > squares[i][3]:
                        break
                if best[3] > squares[i][3]:
                    break
            if best[3] > squares[i][3] + 1e-12:
                squares[i] = best
                improved = True
        if not improved:
            break
    return squares


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # For small n use simple known-good arrangements.
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    import random
    rng = random.Random(12345 + n)

    def build(rects):
        squares = []
        for i, r in enumerate(rects):
            w, h = r[2], r[3]
            nearly_square = min(w, h) >= 0.85 * max(w, h)
            rotated = (i % 2 == 1) and nearly_square
            sq = _inscribed_square(r, rotated)
            squares.append(_clip_inside(sq))
        squares = _grow_pass(squares, iters=8)
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        return squares[:n]

    def total(sqs):
        return sum(s[3] for s in sqs)

    best = build(_rects_guillotine(n))
    best_score = total(best)

    # Multi-start randomized restarts.
    for _ in range(11):
        rects = _random_rects_guillotine(n, rng)
        cand = build(rects)
        sc = total(cand)
        if sc > best_score + 1e-12:
            best = cand
            best_score = sc
    return best
# EVOLVE-BLOCK-END