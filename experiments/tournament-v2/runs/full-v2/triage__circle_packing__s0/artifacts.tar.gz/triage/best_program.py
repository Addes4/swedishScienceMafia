"""Optimized circle packing using convex optimization with iterative center adjustment.
Combines LP-based radius optimization with gradient-based center movement and local search."""
import numpy as np
from scipy.optimize import linprog, minimize


def pack_circles_lp(centers):
    """Solve LP to maximize sum of radii given fixed centers.
    Returns optimal radii."""
    n = len(centers)
    m = n
    obj = -np.ones(m)  # minimize -sum(r)
    
    A_ub = []
    b_ub = []
    
    # Wall constraints: r_i <= distance to each wall
    for i in range(n):
        x, y = centers[i]
        constraints = [
            (x, [1 if j == i else 0 for j in range(n)]),
            (y, [1 if j == i else 0 for j in range(n)]),
            (1 - x, [1 if j == i else 0 for j in range(n)]),
            (1 - y, [1 if j == i else 0 for j in range(n)])
        ]
        for bound, row in constraints:
            A_ub.append(row)
            b_ub.append(bound * 0.9999)  # tiny safety margin
    
    # Pairwise non-overlap: r_i + r_j <= d_ij
    for i in range(n):
        for j in range(i + 1, n):
            d = np.linalg.norm(centers[i] - centers[j])
            row = [0] * n
            row[i] = 1
            row[j] = 1
            A_ub.append(row)
            b_ub.append(d * 0.9999)
    
    bounds = [(0, None)] * n
    
    result = linprog(obj, A_ub=np.array(A_ub), b_ub=np.array(b_ub), 
                     bounds=bounds, method='highs')
    
    if result.success:
        return np.maximum(result.x, 0.0)
    else:
        return np.zeros(n)


def objective_from_centers(centers_flat, n):
    """Compute negative sum of radii for a given center configuration."""
    centers = centers_flat.reshape(n, 2)
    # Clip centers to ensure they stay within bounds
    centers = np.clip(centers, 0.001, 0.999)
    radii = pack_circles_lp(centers)
    return -np.sum(radii)


def solve(n=26):
    """Return (centers, radii) for n disjoint circles in unit square,
    maximizing sum of radii."""
    
    # Initialize centers using a force-based approach to get good initial positions
    # Use hexagonal-like packing with variable sizes
    np.random.seed(42)
    
    # Start with a grid-based initialization for better coverage
    rows = int(np.ceil(np.sqrt(n)))
    cols = int(np.ceil(n / rows))
    
    centers = []
    for i in range(rows):
        for j in range(cols):
            if len(centers) >= n:
                break
            x = (j + 0.5) / cols
            y = (i + 0.5) / rows
            # Add slight jitter to break symmetry
            x += np.random.uniform(-0.03, 0.03)
            y += np.random.uniform(-0.03, 0.03)
            centers.append([np.clip(x, 0.05, 0.95), np.clip(y, 0.05, 0.95)])
        if len(centers) >= n:
            break
    
    # If we don't have enough, add random points
    while len(centers) < n:
        centers.append([np.random.uniform(0.05, 0.95), 
                       np.random.uniform(0.05, 0.95)])
    
    centers = np.array(centers[:n], dtype=float)
    
    # Phase 1: Optimize centers using gradient-free method first
    # Use multiple restarts with different random seeds
    best_score = -np.inf
    best_centers = None
    best_radii = None
    
    for restart in range(3):
        if restart > 0:
            # Perturb centers for restarts
            centers = best_centers + np.random.normal(0, 0.02, (n, 2))
            centers = np.clip(centers, 0.01, 0.99)
        
        # Use Nelder-Mead for robust center optimization
        result = minimize(
            lambda c: objective_from_centers(c, n),
            centers.flatten(),
            method='Nelder-Mead',
            options={'maxiter': 2000, 'xatol': 1e-8, 'fatol': 1e-8}
        )
        
        opt_centers = result.x.reshape(n, 2)
        opt_centers = np.clip(opt_centers, 0.001, 0.999)
        opt_radii = pack_circles_lp(opt_centers)
        score = np.sum(opt_radii)
        
        if score > best_score:
            best_score = score
            best_centers = opt_centers.copy()
            best_radii = opt_radii.copy()
    
    # Phase 2: Local search - move each circle to improve packing
    centers = best_centers.copy()
    radii = best_radii.copy()
    
    for iteration in range(5):
        improved = False
        order = np.random.permutation(n)
        
        for idx in order:
            best_local_score = np.sum(radii)
            best_move = None
            
            # Try small perturbations
            for dx, dy in [(0, 0)] + [
                (d * np.cos(theta), d * np.sin(theta))
                for d in [0.005, 0.01, 0.02]
                for theta in np.linspace(0, 2*np.pi, 8, endpoint=False)
            ]:
                new_centers = centers.copy()
                new_centers[idx, 0] = np.clip(new_centers[idx, 0] + dx, 0.001, 0.999)
                new_centers[idx, 1] = np.clip(new_centers[idx, 1] + dy, 0.001, 0.999)
                
                new_radii = pack_circles_lp(new_centers)
                local_score = np.sum(new_radii)
                
                if local_score > best_local_score:
                    best_local_score = local_score
                    best_move = (new_centers[idx].copy(), new_radii)
            
            if best_move is not None:
                centers[idx] = best_move[0]
                radii = best_move[1]
                improved = True
        
        if not improved:
            break
    
    # Final LP solve for clean radii
    radii = pack_circles_lp(centers)
    
    return centers, radii
