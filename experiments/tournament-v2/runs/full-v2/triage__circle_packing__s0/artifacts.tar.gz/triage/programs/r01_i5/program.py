import numpy as np
from scipy.optimize import minimize, rosen


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximizing the sum of radii."""
    centers, radii = _circle_packing_physics(n)
    return centers, radii

def _distance_matrix(centers):
    """Pairwise distances between all center points."""
    from sklearn.metrics import pairwise_distances_matrix
    return pairwise_distances_matrix(centers)

def _overlap_penalty(centers, radii):
    """Sum of squared overlaps between all pairs plus wall penalties."""
    n = len(centers)
    dists = np.zeros((n, n))
    for i in range(n):
        for j in range(i+1, n):
            dists[i, j] = np.linalg.norm(centers[i] - centers[j])
            dists[j, i] = dists[i, j]
    overlaps = 0
    for i in range(n):
        for j in range(i+1, n):
            r_sum = radii[i] + radii[j]
            overlap = max(0, r_sum - dists[i, j])
            overlaps += overlap * overlap
    # Wall penalties
    wall_x = np.maximum(np.abs(np.dot(centers, [1, 0]) - 0.5 - radii), 0)
    wall_y = np.maximum(np.abs(np.dot(centers, [0, 1]) - 0.5 - radii), 0)
    wall_x += np.maximum(np.abs(centers[:, 0] - 1 + radii), 0)
    wall_y += np.maximum(np.abs(1 - centers[:, 0] - radii), 0)
    wall_y += np.maximum(np.abs(centers[:, 1] - 1 + radii), 0)
    wall_y += np.maximum(np.abs(0 - centers[:, 1] - radii), 0)
    return overlaps + np.sum(wall_x ** 4) + np.sum(wall_y ** 4)

def _boundary_penalty(centers, radii):
    """Penalty for violating boundaries."""
    n = len(centers)
    p = 0
    for i in range(n):
        p += radius_clamp_penalty(centers[i][0], radii[i])
        p += radius_clamp_penalty(1 - centers[i][0], radii[i])
        p += radius_clamp_penalty(centers[i][1], radii[i])
        p += radius_clamp_penalty(1 - centers[i][1], radii[i])
    return p

def radius_clamp_penalty(dist, rad):
    """Calculate boundary penalty."""
    return max(0, dist - rad) ** 4

def _relax_circles(centric_centers, radii, max_iter=200, dt=0.01, damping=0.9):
    """Physics simulation to relax centers to minimize overlaps."""
    n = len(centric_centers)
    centers = centric_centers.astype(np.float64)
    velocities = np.zeros((n, 2))
    prev_loss = np.inf
    
    for iteration in range(max_iter):
        loss = _overlap_penalty(centers, radii)
        if abs(prev_loss - loss) < 1e-6 and iteration > 10:
            break
        prev_loss = loss
        # Recover positions
        active = [ study_centers[i] for i in range(n) ]
        for i in range(n):
            force_accum = np.zeros(2)
            for j in range(i+1, n):
                dist = np.linalg.norm(centers[i] - centers[j])
                if dist > 1e-6:
                    direction = (centers[i] - centers[j]) / dist
                    overlap = max(0, radii[i] + radii[j] - dist)
                    if overlap > 0:
                        force_accum += 2 * overlap * direction
            # Add wall forces
            wall_force = np.zeros(2)
            for c in [[0, centers[i][0]], [1 - centers[i][0], 0], [centers[i][1], 1], [centers[i][0], 1]]:
                if c[0] < radii[i] * 2:
                    force_acc += (c[0] - radii[i] * 2)
                    force_acc += (c[0] - radii[i] * 2)
            wall_force += np.ones(2) * 100
            force_accum += wall_force * 0.5
        # Apply force and damping
        velocity = force_accum * dt * 5 * (1 - damping)
        velocity = velocities * damping
        centers = centers + velocity
        
        # Trim radii
        for i in range(n):
            min_dist = 2.0
            for j in range(n):
                if i != j:
                    d = np.linalg.norm(centers[i] - centers[j])
                    min_dist = min(min_dist, d)
            radii[i] = min(0.9, (min_dist - 0.0001) / 2.0)
    
    return centers

def _best_initial_positions(n, radii):
    """Select elegant initial geometry."""
    from itertools import product
    points = []
    for _ in range(8):
        point = np.array([0.5 + 0.3 * np.cos(2 * np.pi * _ / 8),
                         0.5 + 0.3 * np.sin(0.5 * np.pi * _ / 4)])
        points.append(point)
    if n > 8:
        for _ in range(8):
            for i in range(4):
                offset = 0.4 + 0.1 * i
                point = np.array([0.3 + 0.45 * np.cos(2 * np.pi * _ / 8),
                                 0.3 + 0.45 * np.sin(2 * np.pi * _ / 8)])
                points.append(point)
        n = min(len(points), n)
        return np.array(points)
    return np.array(points)

def _circle_packing_physics(n):
    """Place and grow circles using physics-based simulation."""
    centers_initial = np.zeros((n, 2))
    radii_initial = np.array([0.01] * n)
    
    for _ in range(3):
        centers_done = np.zeros((n, 2))
        radii_done = np.array([0.01] * n)
        loss = _overlap_penalty(centers_done, radii_done)
        
        optimization = minimize(_overlap_penalty, [centers_done], args=(radii_done,),
                      method='Nelder-Mead',
                      options={'maxiter': 1000, 'disp': False})
        centers_done = optimization.x
        
        for i in range(n):
            for j in range(n):
                if i != j:
                    d = np.linalg.norm(centers_done[i] - centers_done[j])
                    radii_done[i] = min(radii_done[i], (d - 0.001) / 2.0)
                if d > 1e-3:
                    radii_done[i] = min(radii_done[i], (d - 0.001) / 2.0)
        
        if loss > np.inf:
            print("Warning: strong penalty")
            
    # Global relaxation
    centers, radii = _relax_circles(centers_done, radii_done, max_iter=500)
    
    # Last PSD optimization
    for iteration in range(5):
        try:
            opt = minimize(_overlap_penalty, [centers], args=(radii,),
                          method='SLSQP', options={'ftol': 1e-8, 'disp': False})
            centers = opt.x
            loss = _overlap_penalty(centers, radii)
        except Exception:
            break
    
    return centers, radii

if __name__ == "__main__":
    centers, radii = solve(26)
    print(f"Sum of radii: {np.sum(radii):.6f}")
    print(f"Min radius: {np.min(radii):.6f}")
    print(f"Max radius: {np.max(radii):.6f}")
