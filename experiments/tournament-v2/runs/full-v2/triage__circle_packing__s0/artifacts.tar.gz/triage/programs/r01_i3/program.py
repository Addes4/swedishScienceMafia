import numpy as np
from scipy.optimize import differential_evolution
import time

def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii using differential evolution."""
    
    # Bounds for x and y coordinates of all centers
    bounds = [(0.001, 0.999)] * (2 * n)
    
    # Objective function to minimize (negative sum of radii)
    def objective(coords):
        centers = coords.reshape(n, 2)
        # Ensure coordinates are within bounds (redundant but safe)
        centers = np.clip(centers, 0.001, 0.999)
        radii = max_radii(centers)
        return -np.sum(radii)
    
    # Use differential evolution with a time limit
    start_time = time.time()
    time_limit = 290  # Leave some margin
    
    # Strategy: run with multiple random seeds, pick best
    best_score = -np.inf
    best_centers = None
    
    # Generate a few different initial populations via random seeds
    # We'll run multiple short DE optimizations and take the best result
    for seed in range(5):
        if time.time() - start_time > time_limit:
            break
        
        remaining = time_limit - (time.time() - start_time)
        if remaining < 10:
            break
            
        # Each run gets a fraction of the remaining time
        run_time = min(remaining / (5 - seed), 60)
        
        result = differential_evolution(
            objective,
            bounds,
            seed=seed * 42 + 123,
            maxiter=1000,
            tol=1e-8,
            polish=False,
            workers=-1,
            updating='deferred',
            popsize=30,
            mutation=(0.5, 1.5),
            recombination=0.7,
            max_time=run_time
        )
        
        if -result.fun > best_score:
            best_score = -result.fun
            best_centers = result.x.reshape(n, 2)
    
    # If for some reason no optimization ran, fall back to random
    if best_centers is None:
        best_centers = np.random.rand(n, 2) * 0.98 + 0.01
    
    # Final polish: ensure non-overlapping and compute radii
    best_centers = np.clip(best_centers, 0.001, 0.999)
    radii = max_radii(best_centers)
    
    return best_centers, radii


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    # Start with distance to walls
    radii = np.minimum.reduce([
        centers[:, 0],
        centers[:, 1],
        1 - centers[:, 0],
        1 - centers[:, 1]
    ])
    
    # More iterations with careful pairwise shrinking
    for _ in range(100):
        changed = False
        # Randomize order to avoid bias
        order = np.random.permutation(n)
        for idx in range(n):
            i = order[idx]
            for j in range(n):
                if i == j:
                    continue
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    # Scale both radii proportionally
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        
        # Also check wall constraints
        radii = np.minimum(radii, 
                          np.minimum(centers[:, 0], 
                          np.minimum(centers[:, 1],
                          np.minimum(1 - centers[:, 0], 1 - centers[:, 1]))))
        
        if not changed:
            break
    
    return np.maximum(radii, 0.0)
