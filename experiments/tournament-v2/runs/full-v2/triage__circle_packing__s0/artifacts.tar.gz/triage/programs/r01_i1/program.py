import numpy as np
from scipy.optimize import minimize


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii using gradient-based optimization."""
    
    # Good initial layout: central circle, two rings, random fill
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    if n > len(centers):
        centers += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()] for _ in range(n - len(centers))]
    centers = np.clip(np.array(centers[:n], dtype=np.float64), 0.01, 0.99)
    
    # Objective: negative sum of radii with soft penalty for overlaps and boundary violations
    def objective_and_grad(flat_centers):
        c = flat_centers.reshape(-1, 2)
        n_c = len(c)
        
        # Radii are maximum possible respecting walls and pairwise distances
        radii = np.minimum(np.minimum(c[:, 0], c[:, 1]), 
                           np.minimum(1 - c[:, 0], 1 - c[:, 1]))
        
        # Pairwise constraints
        for i in range(n_c):
            for j in range(i + 1, n_c):
                d = np.linalg.norm(c[i] - c[j])
                if radii[i] + radii[j] > d:
                    # Scale down both proportionally
                    factor = d / (radii[i] + radii[j] + 1e-12)
                    radii[i] *= factor
                    radii[j] *= factor
        
        # Soft penalty: negative sum plus penalties for violations
        obj = -np.sum(radii)
        penalty = 0.0
        grad_penalty = np.zeros_like(c)
        
        # Boundary penalty (very soft)
        margin = 1e-6
        for i in range(n_c):
            for dim in range(2):
                if c[i, dim] < margin:
                    pen = (margin - c[i, dim])**2
                    obj += 1000 * pen
                    grad_penalty[i, dim] += 1000 * (-2 * (margin - c[i, dim]))
                elif c[i, dim] > 1 - margin:
                    pen = (c[i, dim] - (1 - margin))**2
                    obj += 1000 * pen
                    grad_penalty[i, dim] += 1000 * (2 * (c[i, dim] - (1 - margin)))
        
        # Overlap penalty: soft penalty for pairwise distances less than sum of radii
        # We use a simple approximation: maximize minimal distance
        for i in range(n_c):
            for j in range(i + 1, n_c):
                d = np.linalg.norm(c[i] - c[j])
                if d < radii[i] + radii[j]:
                    # Penalty for overlap
                    overlap = radii[i] + radii[j] - d
                    obj += 1000 * overlap**2
                    if d > 1e-9:
                        direction = (c[i] - c[j]) / d
                        grad_penalty[i] += 1000 * 2 * overlap * direction
                        grad_penalty[j] -= 1000 * 2 * overlap * direction
                    # Also modify radii contribution to gradient via chain rule
                    # Since radii depend on centers, we'd need full autodiff.
                    # We use a simpler approach: direct numerical optimization of centers
                    # with objective being sum of radii computed from current centers.
        
        grad = np.zeros_like(flat_centers)
        # Numerical gradient for the non-penalty part (sum of radii)
        eps = 1e-8
        for i in range(n_c):
            for dim in range(2):
                c_plus = c.copy()
                c_plus[i, dim] += eps
                c_plus = np.clip(c_plus, 0, 1)
                r_plus = np.minimum(np.minimum(c_plus[:, 0], c_plus[:, 1]),
                                    np.minimum(1 - c_plus[:, 0], 1 - c_plus[:, 1]))
                for ii in range(n_c):
                    for jj in range(ii + 1, n_c):
                        dd = np.linalg.norm(c_plus[ii] - c_plus[jj])
                        if r_plus[ii] + r_plus[jj] > dd:
                            factor = dd / (r_plus[ii] + r_plus[jj] + 1e-12)
                            r_plus[ii] *= factor
                            r_plus[jj] *= factor
                sum_plus = np.sum(r_plus)
                
                c_minus = c.copy()
                c_minus[i, dim] -= eps
                c_minus = np.clip(c_minus, 0, 1)
                r_minus = np.minimum(np.minimum(c_minus[:, 0], c_minus[:, 1]),
                                     np.minimum(1 - c_minus[:, 0], 1 - c_minus[:, 1]))
                for ii in range(n_c):
                    for jj in range(ii + 1, n_c):
                        dd = np.linalg.norm(c_minus[ii] - c_minus[jj])
                        if r_minus[ii] + r_minus[jj] > dd:
                            factor = dd / (r_minus[ii] + r_minus[jj] + 1e-12)
                            r_minus[ii] *= factor
                            r_minus[jj] *= factor
                sum_minus = np.sum(r_minus)
                
                grad[i * 2 + dim] = (sum_plus - sum_minus) / (2 * eps)
        
        # Gradient for penalty part (analytical)
        grad += grad_penalty.ravel()
        
        return obj, grad
    
    # Initial flat array
    x0 = centers.ravel()
    bounds = [(0.0, 1.0)] * (n * 2)
    
    result = minimize(
        objective_and_grad,
        x0,
        method='L-BFGS-B',
        jac=True,
        bounds=bounds,
        options={'maxiter': 500, 'disp': False, 'gtol': 1e-8, 'ftol': 1e-12}
    )
    
    optimized_centers = result.x.reshape(-1, 2)
    optimized_centers = np.clip(optimized_centers, 0.0, 1.0)
    
    # Final radii calculation with strict collision handling
    radii = max_radii(optimized_centers)
    
    return optimized_centers, radii


def max_radii(centers):
    """Largest radii for fixed centres respecting walls and pairwise distances."""
    n = len(centers)
    radii = np.minimum(np.minimum(centers[:, 0], centers[:, 1]),
                       np.minimum(1 - centers[:, 0], 1 - centers[:, 1]))
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j] + 1e-12)
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
