# EVOLVE-BLOCK-START
"""Convex optimization approach: use scipy.optimize.linprog for optimal radii.
This replaces the iterative overlap resolution with a single-shot linear program.
Objective: maximize sum of radii subject to non-overlap and wall constraints."""
import numpy as np
from scipy.optimize import linprog


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    # Initialize centers: 1 central, ring around it, fill remaining with random
    centers = [[0.5, 0.5]]
    
    # Ring around center (8 points)
    for i in range(8):
        if len(centers) >= n:
            break
        theta = 2 * np.pi * i / 8
        r = 0.25  # distance from center to first ring
        centers.append([0.5 + r * np.cos(theta), 0.5 + r * np.sin(theta)])
    
    # Additional ring (closer, more points)
    for i in range(16):
        if len(centers) >= n:
            break
        theta = 2 * np.pi * i / 16
        r = 0.4
        centers.append([0.5 + r * np.cos(theta), 0.5 + r * np.sin(theta)])
    
    # Random fill for remaining
    for _ in range(n - len(centers)):
        cx, cy = np.random.uniform(0.05, 0.95, 2)
        centers.append([cx, cy])
    
    centers = np.array(centers[:n])
    
    # Build linear constraints for optimizing radii
    # Maximize sum(r_i) = minimize -sum(r_i) subject to:
    #   r_i >= 0
    #   r_i <= dist to walls
    #   r_i + r_j <= distance(C_i, C_j) for all i < j
    
    m = n  # number of radii variables
    obj = -np.ones(m)  # minimize -sum(r) == maximize sum(r)
    
    # Constraints: A_ub @ r <= b_ub
    # Bounds: r_i >= 0
    
    A_ub = []
    b_ub = []
    
    # Wall distance constraints (4 per circle): x, y, 1-x, 1-y
    for i in range(m):
        A_ub.append([1.0 if j == i else 0.0 for j in range(m)])
        b_ub.append(min(centers[i, 0], centers[i, 1], 1 - centers[i, 0], 1 - centers[i, 1]))
    
    # Pairwise non-overlap constraints
    for i in range(m):
        for j in range(i + 1, m):
            d = np.linalg.norm(centers[i] - centers[j])
            # r_i + r_j <= d
            row = [0.0] * m
            row[i] = 1.0
            row[j] = 1.0
            A_ub.append(row)
            b_ub.append(d)
    
    cons = {'type': 'ineq', 'func': lambda r: -np.maximum(A_ub @ r, b_ub) * 0.0}  # Not quite right
    # Instead, linprog uses A_ub @ r <= b_ub directly
    
    # Correct approach:
    # linprog expects A_ub @ x <= b_ub for inequality constraints
    # So we need to ensure all radii satisfy r_i + r_j <= d
    # But only r_i >= 0 handled via bounds
    
    # Let's solve properly with bounds handling
    A_ub = []
    b_ub = []
    
    # Wall constraints
    for i in range(m):
        A_ub.append(np.eye(m)[:, i])
        b_ub.append(min(centers[i, 0], centers[i, 1], 1 - centers[i, 0], 1 - centers[i, 1]))
    
    # Pairwise non-overlap
    for i in range(m):
        for j in range(i + 1, m):
            d = np.linalg.norm(centers[i] - centers[j])
            row = np.zeros(m)
            row[i] = 1
            row[j] = 1
            A_ub.append(row)
            b_ub.append(d)
    
    bounds = [(0, None)] * m  # r_i >= 0
    
    result = linprog(obj, A_ub=np.array(A_ub), b_ub=np.array(b_ub), bounds=bounds, method='highs')
    
    radii = np.maximum(result.x, 0.0)  # Ensure non-negative
    
    return centers, radii
# EVOLVE-BLOCK-END
