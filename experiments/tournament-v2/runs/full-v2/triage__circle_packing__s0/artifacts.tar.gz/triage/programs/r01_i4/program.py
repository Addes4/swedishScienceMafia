# EVOLVE-BLOCK-START
"""Sequential insertion / deletion circle packing.

Idea: the best-known n=26 packings are near hexagonal in the interior, but
setting the packing up with exactly 26 circles from the start makes the
optimiser fight the outer rings.  Instead we grow the packing: solve a small
packing first (few big circles), then repeatedly re-optimise the radii and
insert a new (small) circle into the largest empty gap until we have n
circles.  Radii are always solved to optimality for the fixed centres via a
fast projection/bisection scheme, and centres are polished with a few passes
of randomised coordinate ascent + a Voronoi-style "largest hole" probe.

Only numpy / stdlib are used.
"""
import numpy as np


# ----------------------------------------------------------------------
# Largest feasible radii for fixed centres
# ----------------------------------------------------------------------
def max_radii(centers, iters=60):
    """Feasible radii for fixed centres: shrink to remove pairwise overlaps.

    Repeatedly multiply each radius by min over (a) wall slack, (b) half of
    the pairwise distance budget.  Converges monotonically downwards.
    """
    c = np.asarray(centers, dtype=float)
    n = len(c)
    if n == 0:
        return np.zeros(0)
    r = np.minimum.reduce([c[:, 0], c[:, 1], 1.0 - c[:, 0], 1.0 - c[:, 1]])
    r = np.maximum(r, 1e-12)
    for _ in range(iters):
        # pairwise distances
        diff = c[:, None, :] - c[None, :, :]
        d = np.sqrt((diff ** 2).sum(-1))
        np.fill_diagonal(d, np.inf)
        s = r[:, None] + r[None, :]
        # allowed scale per circle from pair constraints
        ratio = d / np.maximum(s, 1e-30)
        scale = np.minimum(1.0, ratio.min(axis=1))
        # wall constraints
        wall = np.minimum.reduce(
            [c[:, 0], c[:, 1], 1.0 - c[:, 0], 1.0 - c[:, 1]]
        )
        r = np.minimum(r * scale, np.maximum(wall, 0.0))
        if np.all(scale > 0.999999):
            break
    return np.maximum(r, 0.0)


# ----------------------------------------------------------------------
# Objective / helper quantities
# ----------------------------------------------------------------------
def _radii_and_gaps(centers):
    """Return (radii, slack) where slack[i,j] = d_ij - r_i - r_j >= 0."""
    c = np.asarray(centers, dtype=float)
    r = max_radii(c)
    diff = c[:, None, :] - c[None, :, :]
    d = np.sqrt((diff ** 2).sum(-1))
    np.fill_diagonal(d, np.inf)
    slack = d - (r[:, None] + r[None, :])
    return r, slack


def _total(r):
    return float(r.sum())


# ----------------------------------------------------------------------
# Local search over centres (randomised coordinate ascent)
# ----------------------------------------------------------------------
def _local_search(centers, rng, rounds=2500, t_max=0.06):
    c = np.asarray(centers, dtype=float).copy()
    n = len(c)
    cur = max_radii(c)
    best_val = _total(cur)
    T0 = t_max
    for it in range(rounds):
        i = rng.integers(n)
        t = T0 * (1.0 - it / max(1, rounds)) + 1e-4
        old = c[i].copy()
        step = rng.normal(0.0, t, size=2)
        c[i] = np.clip(c[i] + step, 1e-9, 1.0 - 1e-9)
        # only re-solve the affected radius approximately: full solve is cheap enough
        new = max_radii(c)
        val = _total(new)
        if val >= best_val - 1e-12:
            best_val = val
            cur = new
        else:
            c[i] = old
    return c, cur, best_val


# ----------------------------------------------------------------------
# Best insertion point: sample the candidate with the largest free radius
# ----------------------------------------------------------------------
def _best_insert(centers, radii, rng, samples=900):
    c = np.asarray(centers, dtype=float)
    n = len(c)
    if n == 0:
        return np.array([0.5, 0.5]), 0.5

    # candidate points: a coarse grid plus random samples
    m = int(np.sqrt(samples)) + 1
    gx, gy = np.meshgrid(np.linspace(0, 1, m), np.linspace(0, 1, m))
    pts = np.column_stack([gx.ravel(), gy.ravel()])
    rnd = rng.random((samples, 2))
    pts = np.vstack([pts, rnd])

    diff = pts[:, None, :] - c[None, :, :]
    d = np.sqrt((diff ** 2).sum(-1))
    free = d - radii[None, :]
    free = free.min(axis=1)
    wall = np.minimum.reduce(
        [pts[:, 0], pts[:, 1], 1.0 - pts[:, 0], 1.0 - pts[:, 1]]
    )
    allowance = np.minimum(free, wall)
    j = int(np.argmax(allowance))
    return pts[j].copy(), float(allowance[j])


# ----------------------------------------------------------------------
# Main driver
# ----------------------------------------------------------------------
def _build(n, rng, seed_centers=None, seed_radii=None, time_budget=1.0):
    """Grow a packing from a few circles up to n circles."""
    if seed_centers is None:
        # start from a single big circle in the middle
        c = np.array([[0.5, 0.5]])
    else:
        c = np.asarray(seed_centers, dtype=float).copy()

    r = max_radii(c)
    best_c, best_r, best_val = c.copy(), r.copy(), _total(r)

    # phase 1: fill until we have n circles
    while len(c) < n:
        pt, allow = _best_insert(c, r, rng)
        if allow <= 1e-4:
            # no real gap: nudge a random circle and retry
            c, r, val = _local_search(c, rng, rounds=400, t_max=0.05)
            pt, allow = _best_insert(c, r, rng)
            if allow <= 1e-5:
                # give up inserting usefully; put it at the best spot anyway
                pt = rng.random(2)
        c = np.vstack([c, pt])
        r = max_radii(c)
        # short polish after every insertion
        c, r, val = _local_search(c, rng, rounds=350, t_max=0.05)
        v = _total(r)
        if v > best_val:
            best_val, best_c, best_r = v, c.copy(), r.copy()

    # phase 2: long polish with insertion of the smallest circles into gaps
    rounds = 0
    while rounds < 6:
        rounds += 1
        c, r, val = _local_search(c, rng, rounds=1800, t_max=0.045)
        if val > best_val:
            best_val, best_c, best_r = val, c.copy(), r.copy()

        # try to remove the least useful circle and replace it by a better
        # positioned one (delete + insert into the largest gap)
        r2, slack = _radii_and_gaps(c)
        order = np.argsort(r2)
        cand_c = c.copy()
        cand_r = r2.copy()
        for k in order[:3]:
            c_try = np.delete(c, k, axis=0)
            r_try = max_radii(c_try)
            pt, allow = _best_insert(c_try, r_try, rng)
            c_new = np.vstack([c_try, pt])
            r_new = max_radii(c_new)
            v_new = _total(r_new)
            if v_new > best_val:
                best_val, best_c, best_r = v_new, c_new.copy(), r_new.copy()
                c, r = c_new, r_new
                break

    return best_c, best_r, best_val


def solve(n=26):
    """Return (centers, radii) for n disjoint circles in the unit square."""
    rng = np.random.default_rng(12345)
    best_c, best_r, best_val = None, None, -1.0

    # A handful of restarts with different seeds / initial configurations.
    starts = []

    # seed 1: hexagonal-ish small start
    starts.append(None)

    # seed 2: ring of 6 + centre
    ring = [[0.5 + 0.35 * np.cos(2 * np.pi * i / 6),
             0.5 + 0.35 * np.sin(2 * np.pi * i / 6)] for i in range(6)]
    starts.append(np.array([[0.5, 0.5]] + ring))

    # seed 3: 3x3 grid
    g = np.array([[0.2 + 0.3 * i, 0.2 + 0.3 * j] for i in range(3) for j in range(3)])
    starts.append(g)

    # seed 4: 4 corners + middle
    starts.append(np.array([[0.25, 0.25], [0.75, 0.25], [0.25, 0.75],
                            [0.75, 0.75], [0.5, 0.5]]))

    for s in starts:
        if s is None:
            c0 = None
        else:
            c0 = np.clip(s, 1e-6, 1 - 1e-6)
        for _ in range(2):
            try:
                c, r, v = _build(n, rng, seed_centers=c0)
            except Exception:
                continue
            if v > best_val:
                best_val, best_c, best_r = v, c.copy(), r.copy()

    # final intensive polish of the champion
    if best_c is not None:
        for _ in range(3):
            c, r, v = _local_search(best_c, rng, rounds=4000, t_max=0.03)
            if v > best_val:
                best_val, best_c, best_r = v, c.copy(), r.copy()

    # safety: enforce feasibility and exactly n circles
    best_c = np.asarray(best_c, dtype=float)
    if len(best_c) > n:
        best_c = best_c[:n]
    best_r = max_radii(best_c)
    best_c = np.clip(best_c, 0.0, 1.0)

    return best_c, np.maximum(best_r, 0.0)
# EVOLVE-BLOCK-END
