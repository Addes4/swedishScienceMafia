# EVOLVE-BLOCK-START
"""Hexagonal-like lattice initialization plus iterative radius maximization."""
import numpy as np


def _hex_lattice(n):
    """Return n points forming a perturbed triangular/hexagonal lattice in [0,1]^2,
    biased toward the boundary where larger circles can fit."""
    # Target rows/cols for a roughly triangular packing of n points.
    # For a triangular lattice, row spacing is sqrt(3)/2 times column spacing.
    best = None
    for rows in range(1, n + 1):
        cols = int(np.ceil(n / rows))
        # Aspect-aware cost: we want the lattice to fill the square
        dx = 1.0 / max(cols - 1, 1)
        dy = 1.0 / max(rows - 1, 1)
        # triangular ratio ideal dy/dx = sqrt(3)/2
        ratio = dy / dx if dx > 0 else 1e9
        cost = abs(ratio - np.sqrt(3) / 2.0)
        if best is None or cost < best[0]:
            best = (cost, rows, cols)
    _, rows, cols = best
    pts = []
    for r in range(rows):
        y = 0.5 if rows == 1 else r / (rows - 1)
        offset = 0.0
        if r % 2 == 1 and cols > 1:
            offset = 0.5 / (cols - 1) if cols > 1 else 0.0
        for c in range(cols):
            x = 0.5 if cols == 1 else c / (cols - 1)
            x = x + offset
            if x > 1.0:
                x -= 1.0 / (cols - 1) if cols > 1 else 0.0
            pts.append((x, y))
    pts = np.array(pts[:n], dtype=float)
    if len(pts) < n:
        # pad with random interior points
        extra = np.random.rand(n - len(pts), 2) * 0.8 + 0.1
        pts = np.vstack([pts, extra])
    return pts


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    centers = _hex_lattice(n)
    centers = np.clip(centers, 0.02, 0.98)
    return centers, max_radii(centers)


def max_radii(centers):
    """Largest radii for fixed centres: wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([
        centers[:, 0], centers[:, 1],
        1 - centers[:, 0], 1 - centers[:, 1]
    ])
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                s = radii[i] + radii[j]
                if s > d and s > 1e-15:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END
