import numpy as np
from scipy.optimize import minimize

N = 26
TARGET = 300.0


def overlap_energy(radii, centers):
    """Penalty = sum over pairs/walls of squared overlap plus a tiny pull to grow."""
    n = len(radii)
    pen = 0.0
    # walls: circle must satisfy r <= dist to each wall
    pen += np.sum(np.maximum(radii - centers[:, 0], 0.0) ** 2)
    pen += np.sum(np.maximum(radii - centers[:, 1], 0.0) ** 2)
    pen += np.sum(np.maximum(radii - (1.0 - centers[:, 0]), 0.0) ** 2)
    pen += np.sum(np.maximum(radii - (1.0 - centers[:, 1]), 0.0) ** 2)
    # pairs
    dx = centers[:, 0][:, None] - centers[:, 0][None, :]
    dy = centers[:, 1][:, None] - centers[:, 1][None, :]
    dist = np.sqrt(dx * dx + dy * dy + 1e-18)
    rr = radii[:, None] + radii[None, :]
    pen += np.sum(np.maximum(rr - dist, 0.0) ** 2) * 0.5
    return pen


def relax(centers, radii, iters=200, grow=1.005):
    """Iteratively grow radii and push circles apart."""
    n = len(centers)
    centers = centers.copy()
    radii = radii.copy()
    for it in range(iters):
        radii *= grow
        for _ in range(60):
            # compute pair forces from overlaps
            dx = centers[:, 0][:, None] - centers[:, 0][None, :]
            dy = centers[:, 1][:, None] - centers[:, 1][None, :]
            dist = np.sqrt(dx * dx + dy * dy + 1e-18)
            rr = radii[:, None] + radii[None, :]
            overlap = np.maximum(rr - dist, 0.0)
            np.fill_diagonal(overlap, 0.0)
            if overlap.max() < 1e-12:
                break
            # force magnitude proportional to overlap, direction = unit separation
            force = overlap / (dist + 1e-18)
            fx = np.sum(force * dx, axis=1)
            fy = np.sum(force * dy, axis=1)
            # wall forces
            fx += np.maximum(radii - centers[:, 0], 0.0) * 0.5
            fx -= np.maximum(radii - (1.0 - centers[:, 0]), 0.0) * 0.5
            fy += np.maximum(radii - centers[:, 1], 0.0) * 0.5
            fy -= np.maximum(radii - (1.0 - centers[:, 1]), 0.0) * 0.5
            # damping step
            centers[:, 0] += fx * 0.15
            centers[:, 1] += fy * 0.15
            centers = np.clip(centers, 1e-6, 1 - 1e-6)
        # after resolving, shrink radii to feasible
        d_wall = np.minimum.reduce([centers[:, 0], centers[:, 1],
                                    1 - centers[:, 0], 1 - centers[:, 1]])
        radii = np.minimum(radii, d_wall)
        # shrink to remove pair overlap (simple scaling)
        for _ in range(20):
            dx = centers[:, 0][:, None] - centers[:, 0][None, :]
            dy = centers[:, 1][:, None] - centers[:, 1][None, :]
            dist = np.sqrt(dx * dx + dy * dy + 1e-18)
            rr = radii[:, None] + radii[None, :]
            over = rr - dist
            np.fill_diagonal(over, -1)
            mx = over.max()
            if mx < 1e-12:
                break
            scale = np.ones(n)
            # uniform shrink to fix worst overlap
            if mx > 0:
                shrink = 1.0 - (mx / (rr.max() + 1e-18)) * 0.5
                radii *= max(shrink, 0.9)
        radii = np.maximum(radii, 0.0)
    return centers, radii


def hex_init(n):
    centers = []
    # try 2, 3, 4, 5, 6 rows and pick best fit
    best = None
    for rows in range(2, 8):
        cols = int(np.ceil(n / rows))
        r = 0.5 / max(rows, cols)
        h = np.sqrt(3) * r
        cnt = 0
        c = []
        for i in range(rows):
            for j in range(cols):
                if cnt >= n:
                    break
                x = j * 2 * r + (r if i % 2 else 0)
                y = i * h
                c.append([x, y])
                cnt += 1
            if cnt >= n:
                break
        c = np.array(c)
        if len(c) < n:
            continue
        # normalize into unit square
        c[:, 0] -= c[:, 0].min()
        c[:, 1] -= c[:, 1].min()
        sx = c[:, 0].max()
        sy = c[:, 1].max()
        if sx > 1e-9:
            c[:, 0] /= sx
        if sy > 1e-9:
            c[:, 1] /= sy
        c = c * 0.9 + 0.05
        c = c[:n]
        # compute feasible radii
        d = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
        r0 = np.minimum(d, 0.2)
        if best is None or r0.sum() > best[1].sum():
            best = (c, r0)
    return best


def solve(n=26):
    best_sum = -1.0
    best = None
    np.random.seed(42)
    for trial in range(12):
        if trial == 0:
            centers, radii = hex_init(n)
        elif trial < 6:
            centers, radii = hex_init(n)
            centers += np.random.randn(*centers.shape) * 0.02
            centers = np.clip(centers, 0.02, 0.98)
        else:
            # random init
            centers = np.random.rand(n, 2) * 0.8 + 0.1
            d = np.minimum.reduce([centers[:, 0], centers[:, 1],
                                   1 - centers[:, 0], 1 - centers[:, 1]])
            radii = np.minimum(d, 0.15)
        centers, radii = relax(centers, radii, iters=150, grow=1.004)
        s = radii.sum()
        if s > best_sum:
            best_sum = s
            best = (centers.copy(), radii.copy())
        # local neighbourhood perturbations around current best
        if best is not None:
            for k in range(3):
                c2 = best[0] + np.random.randn(n, 2) * 0.015
                c2 = np.clip(c2, 0.02, 0.98)
                d = np.minimum.reduce([c2[:, 0], c2[:, 1],
                                       1 - c2[:, 0], 1 - c2[:, 1]])
                r2 = np.minimum(best[1], d)
                c2, r2 = relax(c2, r2, iters=120, grow=1.004)
                s2 = r2.sum()
                if s2 > best_sum:
                    best_sum = s2
                    best = (c2.copy(), r2.copy())
    # final polish: greedy radius expansion per circle
    centers, radii = best
    for _ in range(400):
        improved = False
        for i in range(n):
            # max allowed radius for circle i given others fixed and walls
            d = min(centers[i, 0], centers[i, 1],
                    1 - centers[i, 0], 1 - centers[i, 1])
            for j in range(n):
                if i == j:
                    continue
                dist = np.linalg.norm(centers[i] - centers[j])
                d = min(d, dist - radii[j])
            if d > radii[i] + 1e-9:
                radii[i] = d
                improved = True
        if not improved:
            break
    return centers, np.maximum(radii, 0.0)


if __name__ == "__main__":
    c, r = solve(N)
    print("sum radii:", r.sum())
