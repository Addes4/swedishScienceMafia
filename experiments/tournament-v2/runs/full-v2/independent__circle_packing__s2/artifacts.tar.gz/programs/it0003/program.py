import numpy as np
from scipy.optimize import minimize


def objective(z, n):
    """Negative sum of radii with penalty for overlaps and boundary violation.
    z = [x0,y0,r0, x1,y1,r1, ...]"""
    X = z.reshape(n, 3)
    cx, cy, r = X[:, 0], X[:, 1], X[:, 2]
    # boundary penalties: circle must be inside [0,1]^2
    pen = 0.0
    # push outside: if cx - r < 0 -> penalty
    pen += np.sum(np.maximum(0.0, r - cx) ** 2)
    pen += np.sum(np.maximum(0.0, r - (1.0 - cx)) ** 2)
    pen += np.sum(np.maximum(0.0, r - cy) ** 2)
    pen += np.sum(np.maximum(0.0, r - (1.0 - cy)) ** 2)
    # overlap penalties
    dx = cx[:, None] - cx[None, :]
    dy = cy[:, None] - cy[None, :]
    d2 = dx * dx + dy * dy
    ri = r[:, None]
    rj = r[None, :]
    # distance must be >= ri+rj
    sum_r = ri + rj
    # avoid diagonal
    np.fill_diagonal(d2, 1.0)
    overlap = np.maximum(0.0, sum_r ** 2 - d2)
    pen += 1e4 * np.sum(np.triu(overlap, 1))
    return -np.sum(r) + pen


def soft_objective(z, n, penalty=1e5):
    """Smooth-ish objective for local refinement."""
    X = z.reshape(n, 3)
    cx, cy, r = X[:, 0], X[:, 1], X[:, 2]
    pen = 0.0
    pen += np.sum(np.maximum(0.0, r - cx) ** 2)
    pen += np.sum(np.maximum(0.0, r - (1.0 - cx)) ** 2)
    pen += np.sum(np.maximum(0.0, r - cy) ** 2)
    pen += np.sum(np.maximum(0.0, r - (1.0 - cy)) ** 2)
    dx = cx[:, None] - cx[None, :]
    dy = cy[:, None] - cy[None, :]
    d2 = dx * dx + dy * dy
    ri = r[:, None]
    rj = r[None, :]
    sum_r = ri + rj
    np.fill_diagonal(d2, 1.0)
    overlap = np.maximum(0.0, sum_r ** 2 - d2)
    pen += penalty * np.sum(np.triu(overlap, 1))
    return -np.sum(r) + pen


def initial_configs(n, rng, num=200):
    """Generate diverse initial configurations."""
    configs = []
    # 1. grid-like
    for _ in range(num):
        # random points with small radii
        pts = rng.random((n, 2)) * 0.8 + 0.1
        r = np.full(n, 0.05)
        # jitter
        r *= rng.uniform(0.5, 1.5, n)
        z = np.zeros((n, 3))
        z[:, :2] = pts
        z[:, 2] = np.maximum(r, 1e-4)
        configs.append(z.ravel())
    # 2. hexagonal/ring patterns
    for _ in range(num // 2):
        # ring pattern with several rings
        pts = []
        # center
        pts.append([0.5, 0.5])
        # rings
        n_rings = 3
        idx = 0
        ring_counts = [6, 12, n - 1 - 6 - 12]
        for ring_idx, cnt in enumerate(ring_counts):
            if cnt <= 0:
                continue
            rad_ring = (ring_idx + 1) / (n_rings + 1) * 0.45
            for k in range(cnt):
                ang = 2 * np.pi * k / cnt + rng.uniform(0, 0.1)
                pts.append([0.5 + rad_ring * np.cos(ang), 0.5 + rad_ring * np.sin(ang)])
        pts = np.array(pts[:n])
        if len(pts) < n:
            extra = rng.random((n - len(pts), 2)) * 0.8 + 0.1
            pts = np.vstack([pts, extra])
        r = np.full(n, 0.04)
        r *= rng.uniform(0.5, 1.5, n)
        z = np.zeros((n, 3))
        z[:, :2] = np.clip(pts, 0.05, 0.95)
        z[:, 2] = np.maximum(r, 1e-4)
        configs.append(z.ravel())
    return configs


def refine(z0, n, maxiter=2000):
    """Local refinement with L-BFGS-B."""
    bounds = [(0.0, 1.0)] * (2 * n) + [(1e-6, 0.5)] * n
    res = minimize(soft_objective, z0, args=(n,), method='L-BFGS-B',
                   bounds=bounds, options={'maxiter': maxiter, 'ftol': 1e-14, 'gtol': 1e-12})
    return res.x


def extract(z, n):
    X = z.reshape(n, 3)
    centers = X[:, :2].copy()
    radii = np.maximum(X[:, 2], 0.0)
    # fix overlaps and boundary: shrink radii
    for _ in range(200):
        changed = False
        # boundary
        for i in range(n):
            m = min(centers[i, 0], centers[i, 1], 1 - centers[i, 0], 1 - centers[i, 1])
            if radii[i] > m:
                radii[i] = m
                changed = True
        # overlaps
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    # shrink both proportionally
                    s = d / (radii[i] + radii[j] + 1e-12)
                    radii[i] *= s
                    radii[j] *= s
                    changed = True
        if not changed:
            break
    centers = np.clip(centers, 0.0, 1.0)
    return centers, np.maximum(radii, 0.0)


def solve(n=26):
    rng = np.random.default_rng(42)
    best_sum = -np.inf
    best_z = None

    configs = initial_configs(n, rng, num=300)
    # first do a quick global search on a subset
    for idx, z0 in enumerate(configs):
        z1 = refine(z0, n, maxiter=300)
        c, r = extract(z1, n)
        s = np.sum(r)
        if s > best_sum:
            best_sum = s
            best_z = z1.copy()
        if idx > 100 and best_sum > 2.0:  # early exit if good enough
            break

    # full refinement on best
    for _ in range(20):
        z1 = refine(best_z, n, maxiter=5000)
        c, r = extract(z1, n)
        s = np.sum(r)
        if s > best_sum:
            best_sum = s
            best_z = z1.copy()
        else:
            # perturb and retry
            z_pert = best_z + rng.normal(0, 0.005, best_z.shape)
            z_pert.reshape(n, 3)[:, 2] = np.maximum(z_pert.reshape(n, 3)[:, 2], 1e-4)
            z1 = refine(z_pert, n, maxiter=2000)
            c, r = extract(z1, n)
            s = np.sum(r)
            if s > best_sum:
                best_sum = s
                best_z = z1.copy()

    centers, radii = extract(best_z, n)

    # final safety: ensure no overlaps
    for _ in range(500):
        changed = False
        for i in range(n):
            m = min(centers[i, 0], centers[i, 1], 1 - centers[i, 0], 1 - centers[i, 1])
            if radii[i] > m:
                radii[i] = m
                changed = True
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    s = d / (radii[i] + radii[j] + 1e-12)
                    radii[i] *= s
                    radii[j] *= s
                    changed = True
        if not changed:
            break

    return centers, radii
