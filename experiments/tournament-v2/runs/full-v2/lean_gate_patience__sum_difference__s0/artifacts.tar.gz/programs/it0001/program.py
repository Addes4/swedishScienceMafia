# EVOLVE-BLOCK-START
"""Constructive search: Golomb-ruler seed plus a scaled shift to grow the difference set."""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    val = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return val, len(diffs), len(sums)


def _golomb(n, limit=4000):
    """Greedy near-Golomb ruler: all pairwise differences distinct."""
    marks = [0]
    used = set()
    k = 0
    for _ in range(n - 1):
        k += 1
        while True:
            ok = True
            for m in marks:
                d = k - m
                if d in used:
                    ok = False
                    break
            if ok:
                break
            k += 1
        for m in marks:
            used.add(k - m)
        marks.append(k)
    return marks


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Build a difference-dense seed via Golomb ruler (guarantees |A-A| = n^2-n+1).
    for n in (6, 8, 10, 12, 16, 20, 25, 30):
        ruler = _golomb(n)
        base = [2 * r for r in ruler]  # even, sums stay structured
        s, nd, ns = _stats(base)
        if s > best_score:
            best_score, best = s, list(base)

    # Combine the dense seed with a large scaled copy to enlarge A-A multiplicatively.
    ruler = _golomb(30)
    base = [2 * r for r in ruler]
    for scale in (10, 100, 1000, 10000, 100000, 1000000):
        shifted = list(base) + [scale * (2 * r + 1) for r in ruler]
        if len(shifted) > 4000:
            continue
        s, nd, ns = _stats(shifted)
        if s > best_score:
            best_score, best = s, list(shifted)

    # Local refinement: tweak large-scale offsets to maximise the ratio.
    if best is not None:
        cur = list(best)
        while time.time() < deadline:
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, 1000)
            if max(abs(v) for v in cand) > 10 ** 15:
                continue
            s, _, _ = _stats(cand)
            if s > best_score:
                best_score, best = s, cand[:]
                cur = cand

    return sorted(set(best)) if best else [0, 1]
# EVOLVE-BLOCK-END
