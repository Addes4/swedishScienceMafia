# EVOLVE-BLOCK-START
"""Simulated annealing search for a set with large difference set and small sum set."""
import math
import random
import time

import numpy as np


def _counts(A):
    """Return (|A-A|, |A+A|) as numpy int64 arrays."""
    A = np.ascontiguousarray(A, dtype=np.int64)
    d = (A[:, None] - A[None, :]).ravel()
    s = (A[:, None] + A[None, :]).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    return nd, ns


def _score(A):
    n = A.size
    if n < 2:
        return -1e18
    nd, ns = _counts(A)
    if ns < 2:
        return -1e18
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def solve():
    """Return A maximising log|A-A| / log|A+A| (with a small bonus for large |A|)."""
    seed = int(time.time() * 1000) & 0x7FFFFFFF
    random.seed(seed)
    np.random.seed(seed)

    deadline = time.time() + 115.0
    LIMIT = 300
    bestA = np.array([0, 1, 3], dtype=np.int64)
    bestS = _score(bestA)

    while time.time() < deadline:
        # ---- start a fresh restart ----
        n0 = random.randint(6, 25)
        lo, hi = -random.choice([20, 40, 80]), random.choice([20, 40, 80])
        A = np.array(sorted(random.sample(range(-hi, hi + 1), min(n0, 2 * hi + 1))),
                     dtype=np.int64)
        curS = _score(A)
        if curS > bestS:
            bestS, bestA = curS, A.copy()

        restart_end = min(deadline, time.time() + random.uniform(2.0, 5.0))
        T = 0.04
        it = 0
        since = 0
        while time.time() < restart_end and time.time() < deadline:
            it += 1
            since += 1
            if since >= 3000:
                T *= 0.97
                since = 0
                if T < 1e-4:
                    T = 0.02  # reheat

            cand = A.copy()
            r = random.random()
            if r < 0.70:
                i = random.randrange(cand.size)
                step = random.choice([-5, -3, -2, -1, 1, 2, 3, 5])
                cand[i] += step
            elif r < 0.86:
                if cand.size < LIMIT:
                    span = max(10, int(cand.size))
                    cand = np.append(cand, random.randint(-3 * span, 3 * span))
            elif r < 0.95:
                if cand.size > 4:
                    cand = np.delete(cand, random.randrange(cand.size))
            else:
                # global shift/scale of one element to a far value
                i = random.randrange(cand.size)
                cand[i] = random.randint(-1000, 1000)

            cand = np.unique(cand)
            s = _score(cand)
            if s > curS or random.random() < math.exp((s - curS) / max(T, 1e-9)):
                A, curS = cand, s
            if s > bestS:
                bestS, bestA = s, cand.copy()

    return [int(x) for x in np.unique(bestA)]
# EVOLVE-BLOCK-END
