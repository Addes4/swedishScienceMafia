# EVOLVE-BLOCK-START
"""Circle packing in the unit square via barrier optimisation + contact refinement."""
import numpy as np
from scipy.optimize import minimize


def _initial(n, rng):
    centers = [[0.5, 0.5]]
    m1 = 8
    centers += [[0.5 + 0.25 * np.cos(2 * np.pi * i / m1),
                 0.5 + 0.25 * np.sin(2 * np.pi * i / m1)] for i in range(m1)]
    rem = n - 1 - m1
    if rem > 0:
        centers += [[0.5 + 0.62 * np.cos(2 * np.pi * i / rem + 0.3),
                     0.5 + 0.62 * np.sin(2 * np.pi * i / rem + 0.3)] for i in range(rem)]
    centers = np.array(centers[:n], dtype=float)
    centers = np.clip(centers + rng.normal(0, 0.02, centers.shape), 0.03, 0.97)
    r = np.full(n, 0.04)
    for _ in range(800):
        r = np.minimum.reduce([r, centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if r[i] + r[j] > d:
                    s = d / (r[i] + r[j])
                    r[i] *= s
                    r[j] *= s
                    changed = True
        if not changed:
            break
    r *= 0.85
    return centers, np.maximum(r, 1e-3)


def _slacks(c, r, n):
    s = [r, c[:, 0] - r, 1 - c[:, 0] - r, c[:, 1] - r, 1 - c[:, 1] - r]
    dx = c[:, None, 0] - c[None, :, 0]
    dy = c[:, None, 1] - c[None, :, 1]
    d = np.sqrt(dx * dx + dy * dy)
    rs = r[:, None] + r[None, :]
    iu = np.triu_indices(n, 1)
    s.append(d[iu] - rs[iu])
    return s


def _obj(z, n, mu):
    c = z[:2 * n].reshape(n, 2)
    r = z[2 * n:]
    slacks = _slacks(c, r, n)
    tot = np.concatenate([np.asarray(s).ravel() for s in slacks])
    tot = np.maximum(tot, 1e-14)
    return -r.sum() - np.log(tot).sum() / mu


def _grad(z, n, mu):
    c = z[:2 * n].reshape(n, 2)
    r = z[2 * n:]
    g = np.zeros_like(z)

    def add_slack_grad(mask, drad, dcx, dcy):
        sl = np.maximum(mask, 1e-14)
        coef = -1.0 / (mu * sl)
        g[2 * n:] += coef * drad
        g[0::2][:n] += coef * dcx
        g[1::2][:n] += coef * dcy

    g[2 * n:] += -1.0
    one = np.ones(n)
    zero = np.zeros(n)
    add_slack_grad(r, one, zero, zero)
    add_slack_grad(c[:, 0] - r, -one, one, zero)
    add_slack_grad(1 - c[:, 0] - r, -one, -one, zero)
    add_slack_grad(c[:, 1] - r, -one, zero, one)
    add_slack_grad(1 - c[:, 1] - r, -one, zero, -one)

    dx = c[:, None, 0] - c[None, :, 0]
    dy = c[:, None, 1] - c[None, :, 1]
    d = np.sqrt(dx * dx + dy * dy) + 1e-14
    rs = r[:, None] + r[None, :]
    iu = np.triu_indices(n, 1)
    ii, jj = iu
    sl = np.maximum(d[ii, jj] - rs[ii, jj], 1e-14)
    coef = -1.0 / (mu * sl)
    ux = dx[ii, jj] / d[ii, jj]
    uy = dy[ii, jj] / d[ii, jj]
    gx = np.zeros(n); gy = np.zeros(n); gr = np.zeros(n)
    np.add.at(gx, ii, coef * ux)
    np.add.at(gx, jj, coef * (-ux))
    np.add.at(gy, ii, coef * uy)
    np.add.at(gy, jj, coef * (-uy))
    np.add.at(gr, ii, coef * (-1.0))
    np.add.at(gr, jj, coef * (-1.0))
    g[0::2][:n] += gx
    g[1::2][:n] += gy
    g[2 * n:] += gr
    return g


def _repair_feasible(c, r, n):
    r = np.maximum(r, 1e-7)
    for _ in range(600):
        r = np.minimum.reduce([r, c[:, 0], c[:, 1],
                               1 - c[:, 0], 1 - c[:, 1]])
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(c[i] - c[j])
                if d < 1e-12:
                    r[j] *= 0.5
                    changed = True
                    continue
                if r[i] + r[j] > d:
                    s = d / (r[i] + r[j]) * 0.99999
                    r[i] *= s
                    r[j] *= s
                    changed = True
        if not changed:
            break
    return c, np.maximum(r, 0.0)


def _max_feasible_radius(c, r, n, i):
    hi = min(c[i, 0], c[i, 1], 1 - c[i, 0], 1 - c[i, 1])
    for j in range(n):
        if j == i:
            continue
        dist = np.linalg.norm(c[i] - c[j])
        hi = min(hi, dist - r[j])
    return max(hi, 0.0)


def _polish(c, r, n, iters=4000, rng=None):
    if rng is None:
        rng = np.random.default_rng(12345)
    for it in range(iters):
        order = rng.permutation(n)
        improved = False
        for i in order:
            hi = _max_feasible_radius(c, r, n, i)
            if hi > r[i] + 1e-12:
                r[i] = hi
                improved = True
        if not improved and it > n:
            break
    return r


def _contact_energy(c, r, n):
    """Energy that penalizes overlaps and pushes circles to contact; center-only."""
    dx = c[:, None, 0] - c[None, :, 0]
    dy = c[:, None, 1] - c[None, :, 1]
    d = np.sqrt(dx * dx + dy * dy) + 1e-14
    rs = r[:, None] + r[None, :]
    gap = d - rs
    iu = np.triu_indices(n, 1)
    g = gap[iu]
    # penalize gaps (encourage contact) softly
    e = np.sum(np.maximum(g, 0.0) ** 2)
    return e


def _contact_grad(c, r, n):
    dx = c[:, None, 0] - c[None, :, 0]
    dy = c[:, None, 1] - c[None, :, 1]
    d = np.sqrt(dx * dx + dy * dy) + 1e-14
    rs = r[:, None] + r[None, :]
    gap = d - rs
    iu = np.triu_indices(n, 1)
    ii, jj = iu
    g = np.maximum(gap[ii, jj], 0.0)
    ux = dx[ii, jj] / d[ii, jj]
    uy = dy[ii, jj] / d[ii, jj]
    gx = np.zeros(n); gy = np.zeros(n)
    np.add.at(gx, ii, 2 * g * ux)
    np.add.at(gx, jj, -2 * g * ux)
    np.add.at(gy, ii, 2 * g * uy)
    np.add.at(gy, jj, -2 * g * uy)
    return np.stack([gx, gy], axis=1)


def _grow_centers(c, r, n, rng):
    """Move centers to open space, then re-grow radii."""
    c = c + rng.normal(0, 0.006, c.shape)
    c = np.clip(c, 1e-3, 1 - 1e-3)
    c, r = _repair_feasible(c, r, n)
    return c, r


def solve(n=26):
    rng = np.random.default_rng(7)
    best_val = -np.inf
    best_c, best_r = None, None
    n_trials = 6
    mus = [20.0, 60.0, 200.0, 1000.0, 5000.0, 25000.0]
    for trial in range(n_trials):
        seed = 0 if trial == 0 else int(rng.integers(0, 10**6))
        centers, radii = _initial(n, np.random.default_rng(seed))
        if trial > 0:
            centers = np.clip(centers + rng.normal(0, 0.05, centers.shape),
                              0.02, 0.98)
            # random permutation of radii magnitudes
            radii = np.maximum(radii * rng.uniform(0.5, 1.5, n), 1e-3)
            centers, radii = _repair_feasible(centers, radii, n)
        z0 = np.concatenate([centers.ravel(), radii])
        for mu in mus:
            try:
                res = minimize(_obj, z0, args=(n, mu), jac=_grad,
                               method="L-BFGS-B",
                               options={"maxiter": 2000, "maxfun": 300000,
                                        "ftol": 1e-15, "gtol": 1e-12})
                z0 = res.x
            except Exception:
                break
        c = np.clip(z0[:2 * n].reshape(n, 2), 0.0, 1.0)
        r = z0[2 * n:]
        c, r = _repair_feasible(c, r, n)

        # alternate greedy growth + jitter, and contact refinement
        for k in range(40):
            r = _polish(c, r, n, iters=n * 30, rng=rng)
            # contact refinement: try to remove gaps by moving centers
            if k % 2 == 0:
                try:
                    res = minimize(lambda z: _contact_energy(z.reshape(n, 2), r, n),
                                   c.ravel(),
                                   jac=lambda z: _contact_grad(z.reshape(n, 2), r, n).ravel(),
                                   method="L-BFGS-B",
                                   bounds=[(1e-4, 1 - 1e-4)] * (2 * n),
                                   options={"maxiter": 200})
                    c2 = np.clip(res.x.reshape(n, 2), 1e-4, 1 - 1e-4)
                    c2, r2 = _repair_feasible(c2, r, n)
                    if r2.sum() >= r.sum() - 1e-9:
                        c, r = c2, r2
                except Exception:
                    pass
            c, r = _grow_centers(c, r, n, rng)
            r = _polish(c, r, n, iters=n * 30, rng=rng)
        val = r.sum()
        if val > best_val:
            best_val = val
            best_c, best_r = c.copy(), r.copy()
    best_c, best_r = _repair_feasible(best_c, best_r, n)
    best_r = _polish(best_c, best_r, n, iters=n * 100,
                     rng=np.random.default_rng(999))
    best_c, best_r = _repair_feasible(best_c, best_r, n)
    return best_c, best_r
# EVOLVE-BLOCK-END
