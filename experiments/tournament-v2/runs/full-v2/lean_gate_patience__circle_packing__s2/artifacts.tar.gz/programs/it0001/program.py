# EVOLVE-BLOCK-START
"""Circle packing via direct maximisation of sum of radii.

We optimise the centre coordinates and radii with scipy's L-BFGS-B.  Overlap
constraints are handled with an exact penalty: whenever two circles or a circle
and a wall overlap we add a large squared violation term, making the optimum
feasible.  A good initial guess (central circle plus rings) keeps the solver in
a promising basin.
"""
import numpy as np
from scipy.optimize import minimize


def _initial(n):
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8),
                 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.68 * np.cos(2 * np.pi * i / 16),
                 0.5 + 0.68 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    centers += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()]
                for _ in range(max(0, n - len(centers)))]
    centers = np.clip(np.array(centers[:n], dtype=float), 0.02, 0.98)
    # initial radii: distance to nearest wall, shrunk for neighbours
    r = np.minimum.reduce([centers[:, 0], centers[:, 1],
                           1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if r[i] + r[j] > d:
                    s = d / (r[i] + r[j])
                    r[i] *= s
                    r[j] *= s
                    changed = True
        if not changed:
            break
    r = np.maximum(r, 1e-4)
    return centers, r


def _pack(z, n):
    c = z[:2 * n].reshape(n, 2)
    r = z[2 * n:]
    return c, r


def _penalty(c, r, n, mu):
    pen = 0.0
    # wall constraints
    viol = np.maximum(r - c[:, 0], 0) ** 2
    viol += np.maximum(r - c[:, 1], 0) ** 2
    viol += np.maximum(c[:, 0] + r - 1, 0) ** 2
    viol += np.maximum(c[:, 1] + r - 1, 0) ** 2
    pen += mu * viol.sum()
    # pairwise overlap
    dx = c[:, None, 0] - c[None, :, 0]
    dy = c[:, None, 1] - c[None, :, 1]
    d = np.sqrt(dx * dx + dy * dy)
    rs = r[:, None] + r[None, :]
    ov = np.maximum(rs - d, 0)
    iu = np.triu_indices(n, 1)
    pen += mu * (ov[iu] ** 2).sum()
    return pen


def _objective(z, n, mu):
    c, r = _pack(z, n)
    return -r.sum() + _penalty(c, r, n, mu)


def _grad(z, n, mu):
    c, r = _pack(z, n)
    g = np.zeros_like(z)
    # radius gradients (sum term)
    g[2 * n:] = -1.0
    # wall penalties
    # left wall
    v = np.maximum(r - c[:, 0], 0)
    g[2 * n:] += mu * 2 * v
    g[0::2][:n] += mu * (-2 * v)
    v = np.maximum(r - c[:, 1], 0)
    g[2 * n:] += mu * 2 * v
    g[1::2][:n] += mu * (-2 * v)
    v = np.maximum(c[:, 0] + r - 1, 0)
    g[2 * n:] += mu * 2 * v
    g[0::2][:n] += mu * 2 * v
    v = np.maximum(c[:, 1] + r - 1, 0)
    g[2 * n:] += mu * 2 * v
    g[1::2][:n] += mu * 2 * v
    # pair overlaps
    dx = c[:, None, 0] - c[None, :, 0]
    dy = c[:, None, 1] - c[None, :, 1]
    d = np.sqrt(dx * dx + dy * dy) + 1e-12
    rs = r[:, None] + r[None, :]
    ov = np.maximum(rs - d, 0)
    iu = np.triu_indices(n, 1)
    ii, jj = iu
    o = ov[ii, jj]
    coef = mu * 2 * o
    # derivative of overlap wrt positions and radii
    gx = np.zeros(n)
    gy = np.zeros(n)
    gr = np.zeros(n)
    ddx = dx[ii, jj] / d[ii, jj]
    ddy = dy[ii, jj] / d[ii, jj]
    # overlap = r_i + r_j - d ; d/dx_i(d) = ddx
    gx[ii] += coef * (-ddx)
    gx[jj] += coef * (ddx)
    gy[ii] += coef * (-ddy)
    gy[jj] += coef * (ddy)
    gr[ii] += coef
    gr[jj] += coef
    g[0::2][:n] += gx
    g[1::2][:n] += gy
    g[2 * n:] += gr
    return g


def solve(n=26):
    best_z = None
    best_val = -np.inf
    rng = np.random.default_rng(0)
    for trial in range(3):
        centers, radii = _initial(n)
        if trial > 0:
            centers = centers + rng.normal(0, 0.02, centers.shape)
            centers = np.clip(centers, 0.02, 0.98)
        z0 = np.concatenate([centers.ravel(), radii])
        # start with small penalty, then increase
        mu = 50.0
        for stage in range(4):
            res = minimize(_objective, z0, args=(n, mu), jac=_grad,
                           method="L-BFGS-B",
                           options={"maxiter": 2000, "maxfun": 200000,
                                    "ftol": 1e-14, "gtol": 1e-10})
            z0 = res.x
            mu *= 10.0
        c, r = _pack(z0, n)
        # project to a feasible point, then compute true objective
        r = np.maximum(r, 0.0)
        for _ in range(300):
            changed = False
            for i in range(n):
                r[i] = min(r[i], c[i, 0], c[i, 1], 1 - c[i, 0], 1 - c[i, 1])
            for i in range(n):
                for j in range(i + 1, n):
                    d = np.linalg.norm(c[i] - c[j])
                    if r[i] + r[j] > d:
                        s = d / (r[i] + r[j])
                        r[i] *= s
                        r[j] *= s
                        changed = True
            if not changed:
                break
        val = r.sum()
        if val > best_val:
            best_val = val
            best_z = z0.copy()
            best_c, best_r = c.copy(), r.copy()
    return best_c, best_r
# EVOLVE-BLOCK-END

