import math
import random
import time
import numpy as np


def _score_set(s):
    n = len(s)
    if n < 2:
        return -1e18
    arr = np.fromiter(s, dtype=np.int64, count=n)
    ssum = arr[:, None] + arr[None, :]
    sdif = arr[:, None] - arr[None, :]
    ns = np.unique(ssum).size
    nd = np.unique(sdif).size
    if ns < 2 or nd < 2:
        return -1e18
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _seeds():
    seeds = []
    # arithmetic progressions of various sizes
    for n in (30, 60, 100, 140):
        seeds.append(set(range(n)))
        seeds.append(set(range(-n // 2, n - n // 2)))
    # geometric-ish (powers of 2)
    seeds.append({0} | {1 << i for i in range(1, 20)})
    seeds.append({0} | {3 ** i for i in range(0, 12)})
    # two-scale: dense block plus scaled sparse block
    for k, m, M in ((30, 20, 2000), (50, 15, 5000), (20, 30, 1000), (40, 25, 3000)):
        s = set(range(k))
        s |= {M * i for i in range(1, m + 1)}
        seeds.append(s)
    # dense block with far outliers
    for k in (60, 100, 140):
        s = set(range(k))
        s |= {10007 * i for i in range(1, 6)}
        seeds.append(s)
    # mostly-random small range
    for _ in range(6):
        n = random.randint(40, 140)
        seeds.append(set(random.sample(range(-3 * n, 3 * n), n)))
    return seeds


def solve():
    random.seed(1234567)
    np.random.seed(1234567)

    deadline = time.time() + 117.0
    best = None
    best_sc = -1e18

    def consider(s, sc):
        nonlocal best, best_sc
        if sc > best_sc:
            best_sc = sc
            best = set(s)

    # local hill-climb / anneal from each seed
    def anneal(start, budget, t0=0.02):
        s = set(start)
        sc = _score_set(s)
        consider(s, sc)
        T = t0
        it = 0
        while time.time() < budget:
            it += 1
            r = random.random()
            cand = set(s)
            if r < 0.55 and len(cand) > 2:
                # perturb one element
                x = random.choice(tuple(cand))
                cand.discard(x)
                cand.add(x + random.choice((-3, -2, -1, 1, 2, 3)))
            elif r < 0.8 and len(cand) < 260:
                # add a new element near existing structure
                x = random.choice(tuple(cand))
                step = random.choice((1, 2, 3, 5, 9, 17, 33, 129, 1000))
                cand.add(x + step * random.choice((-1, 1)))
            elif r < 0.9 and len(cand) > 4:
                cand.discard(random.choice(tuple(cand)))
            else:
                # larger jump: shift a random element by a big amount
                if len(cand) > 1:
                    x = random.choice(tuple(cand))
                    cand.discard(x)
                    cand.add(x + random.randint(-5000, 5000))
            nsc = _score_set(cand)
            if nsc >= sc or random.random() < math.exp(min(0.0, (nsc - sc) / max(T, 1e-6))):
                s, sc = cand, nsc
                consider(s, sc)
            # slow cooling
            if it % 400 == 0:
                T *= 0.9
                if T < 1e-4:
                    T = t0
        return best

    for seed in _seeds():
        if time.time() > deadline:
            break
        anneal(seed, min(deadline, time.time() + 8.0))

    # global annealing around the current best
    while time.time() < deadline:
        anneal(set(best) if best else set(range(50)),
               min(deadline, time.time() + 10.0), t0=0.05)

    if best is None:
        best = {0, 1, 2, 4, 8}

    best = [int(x) for x in best]
    best = sorted(set(best))
    # safety: respect constraints
    best = [x for x in best if abs(x) <= 10 ** 15][:4000]
    if len(best) < 2:
        best = [0, 1]
    return best
