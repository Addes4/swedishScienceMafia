import numpy as np
from scipy.optimize import minimize, linprog
from scipy.spatial import cKDTree
import time

N = 26


def radii_from_centers_lp(centers):
    """Exact max sum of radii for fixed centers via LP:
       maximize sum r_i s.t. r_i <= wall distances, r_i + r_j <= dist(i,j)."""
    n = len(centers)
    # variables: r_0..r_{n-1}
    c = -np.ones(n)  # minimize -sum r
    A = []
    b = []
    # wall constraints: r_i <= min(x, 1-x, y, 1-y)
    walls = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    for i in range(n):
        row = np.zeros(n)
        row[i] = 1.0
        A.append(row)
        b.append(walls[i])
    # pair constraints: r_i + r_j <= d
    tree = cKDTree(centers)
    pairs = tree.query_pairs(2.0)
    for i, j in pairs:
        d = np.linalg.norm(centers[i] - centers[j])
        row = np.zeros(n)
        row[i] = 1.0
        row[j] = 1.0
        A.append(row)
        b.append(d)
    if not A:
        return np.zeros(n)
    A = np.array(A)
    b = np.array(b)
    res = linprog(c, A_ub=A, b_ub=b, bounds=[(0, None)] * n, method='highs')
    if not res.success:
        # fallback to iterative shrink
        return radii_from_centers_shrink(centers)
    return res.x


def radii_from_centers_shrink(centers):
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    radii = np.maximum(radii, 1e-12)
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if d < 1e-15:
                    radii[j] = 0.0
                    changed = True
                    continue
                if radii[i] + radii[j] > d + 1e-14:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def objective(flat, n):
    centers = flat.reshape(n, 2)
    centers = np.clip(centers, 1e-6, 1 - 1e-6)
    r = radii_from_centers_shrink(centers)
    return -np.sum(r)


def refine_lp(centers):
    """Local polish using Nelder-Mead on centers with LP radii (cheap enough for polish)."""
    n = len(centers)

    def obj(flat):
        cc = np.clip(flat.reshape(n, 2), 1e-6, 1 - 1e-6)
        try:
            r = radii_from_centers_lp(cc)
        except Exception:
            r = radii_from_centers_shrink(cc)
        return -np.sum(r)

    res = minimize(obj, centers.ravel(), method='Nelder-Mead',
                   options={'maxiter': 4000, 'xatol': 1e-10, 'fatol': 1e-12})
    best = np.clip(res.x.reshape(n, 2), 1e-6, 1 - 1e-6)
    return best


def initial_center_config(n, rng):
    """Generate a reasonable initial packing attempt."""
    # hexagonal-ish grid scaled to n circles
    k = int(np.ceil(np.sqrt(n)))
    pts = []
    for i in range(k):
        for j in range(k):
            x = (j + 0.5 + (i % 2) * 0.5) / k
            y = (i + 0.5) / k
            pts.append([x, y])
    pts = np.array(pts)
    rng.shuffle(pts)
    pts = pts[:n]
    # jitter
    pts += rng.normal(0, 0.02, size=pts.shape)
    pts = np.clip(pts, 0.02, 0.98)
    return pts


def perturb(centers, rng, scale=0.03):
    c = centers.copy()
    idx = rng.integers(0, len(c))
    c[idx] += rng.normal(0, scale, size=2)
    c = np.clip(c, 1e-5, 1 - 1e-5)
    return c


def solve(n=26):
    rng = np.random.default_rng(12345)
    t0 = time.time()
    time_limit = 280.0

    best_centers = None
    best_score = -np.inf

    # --- Phase 1: multi-start on good initial configs, use shrink radii (fast) ---
    candidates = []
    for trial in range(60):
        if time.time() - t0 > time_limit * 0.55:
            break
        init = initial_center_config(n, rng)
        # quick local optimization with shrink radii (fast, coarse)
        res = minimize(objective, init.ravel(), args=(n,), method='Nelder-Mead',
                       options={'maxiter': 3000, 'xatol': 1e-9, 'fatol': 1e-11})
        cc = np.clip(res.x.reshape(n, 2), 1e-6, 1 - 1e-6)
        try:
            r = radii_from_centers_lp(cc)
        except Exception:
            r = radii_from_centers_shrink(cc)
        s = np.sum(r)
        candidates.append((s, cc))
        if s > best_score:
            best_score = s
            best_centers = cc.copy()

    # sort candidates
    candidates.sort(key=lambda x: -x[0])

    # --- Phase 2: LP-accurate polish on best few ---
    for s, cc in candidates[:8]:
        if time.time() - t0 > time_limit * 0.85:
            break
        polished = refine_lp(cc)
        try:
            r = radii_from_centers_lp(polished)
        except Exception:
            r = radii_from_centers_shrink(polished)
        s2 = np.sum(r)
        if s2 > best_score:
            best_score = s2
            best_centers = polished.copy()

    # --- Phase 3: random restarts / basin hopping around best using LP objective (if time) ---
    current = best_centers.copy()
    current_score = best_score
    n_iter = 0
    while time.time() - t0 < time_limit - 5:
        n_iter += 1
        trial = perturb(current, rng, scale=0.05)
        try:
            r = radii_from_centers_lp(trial)
        except Exception:
            r = radii_from_centers_shrink(trial)
        s = np.sum(r)
        if s > current_score:
            current = trial
            current_score = s
            if s > best_score:
                best_score = s
                best_centers = trial.copy()
        elif rng.random() < 0.03:
            current = trial
            current_score = s

    # final: exact radii from LP on best centers
    try:
        radii = radii_from_centers_lp(best_centers)
    except Exception:
        radii = radii_from_centers_shrink(best_centers)

    # safety: ensure no overlap (radii <= walls and pair sums <= distance)
    radii = np.maximum(radii, 0.0)
    walls = np.minimum.reduce([best_centers[:, 0], best_centers[:, 1],
                               1 - best_centers[:, 0], 1 - best_centers[:, 1]])
    radii = np.minimum(radii, walls)
    # resolve any residual pair overlap conservatively
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(best_centers[i] - best_centers[j])
                if radii[i] + radii[j] > d + 1e-12:
                    scale = d / (radii[i] + radii[j] + 1e-18)
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break

    return best_centers, radii
