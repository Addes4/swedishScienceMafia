# EVOLVE-BLOCK-START
"""Maximise sum of radii of 26 non-overlapping circles in the unit square.

For fixed centres the optimal radii solve a linear program:
    maximise  sum r_i
    s.t.      r_i <= min(x_i, 1-x_i, y_i, 1-y_i)   (walls)
              r_i + r_j <= dist(i, j)              (pairs)
              r_i >= 0
We solve this exactly with scipy's linprog (HiGHS).  The centre positions are
optimised with SLSQP using this exact value as the objective, seeded from a
dense triangular lattice plus structured patterns and perturbations.
"""
import numpy as np
from scipy.optimize import minimize, linprog


def max_radii(centers):
    """Exact maximal radii for fixed centres via an LP."""
    c = np.asarray(centers, dtype=float)
    n = len(c)
    A_ub = []
    b_ub = []
    # wall constraints: r_i <= wall_i  =>  r_i <= w  (upper bound only)
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1.0 - c[:, 0], 1.0 - c[:, 1]])
    wall = np.maximum(wall, 0.0)
    # pair constraints
    diff = c[:, None, :] - c[None, :, :]
    dmat = np.sqrt(np.sum(diff * diff, axis=-1))
    for i in range(n):
        for j in range(i + 1, n):
            row = np.zeros(n)
            row[i] = 1.0
            row[j] = 1.0
            A_ub.append(row)
            b_ub.append(dmat[i, j])
    A_ub = np.array(A_ub) if A_ub else np.zeros((0, n))
    b_ub = np.array(b_ub) if len(b_ub) else np.zeros(0)
    bounds = [(0.0, wall[i]) for i in range(n)]
    try:
        res = linprog(c=-np.ones(n), A_ub=A_ub, b_ub=b_ub, bounds=bounds,
                      method="highs")
        if res.success:
            return np.maximum(res.x, 0.0)
    except Exception:
        pass
    # fallback: iterative projection
    r = wall.copy()
    for _ in range(60):
        s = r[:, None] + r[None, :]
        viol = s - dmat
        ratio = np.where(dmat > 1e-12, dmat / np.maximum(s, 1e-12), 1.0)
        factor = np.where((viol > 0) & (ratio < 1.0), ratio, 1.0)
        np.fill_diagonal(factor, 1.0)
        shrink = np.minimum.reduce(factor, axis=1)
        if np.all(shrink >= 1.0 - 1e-15):
            break
        r = r * np.minimum(shrink, 1.0)
    return np.maximum(r, 0.0)


def total_radius(centers):
    return float(np.sum(max_radii(centers)))


def tri_lattice(n, scale):
    pts = []
    dy = np.sqrt(3.0) / 2.0
    row = 0
    while len(pts) < n:
        for col in range(row + 1):
            x = scale * (col - row / 2.0)
            y = scale * dy * row
            pts.append([x, y])
        row += 1
    pts = np.array(pts[:n], dtype=float)
    pts -= pts.mean(axis=0)
    extent = max(pts[:, 0].ptp(), pts[:, 1].ptp(), 1e-9)
    pts /= extent
    return 0.5 + pts * 0.9


def make_inits(n, rng):
    inits = []
    for scale in (0.9, 1.05, 1.2, 1.35, 1.5):
        try:
            inits.append(np.clip(tri_lattice(n, scale), 0.02, 0.98))
        except Exception:
            pass
    rows = int(np.ceil(np.sqrt(n)))
    pts = []
    for i in range(rows):
        for j in range(rows):
            x = (j + 0.5 + 0.5 * (i % 2)) / rows
            y = (i + 0.5) / rows
            pts.append([x, y])
    inits.append(np.clip(np.array(pts[:n]), 0.02, 0.98))
    g = int(np.ceil(np.sqrt(n)))
    pts = np.array([[(i % g + 0.5) / g, (i // g + 0.5) / g] for i in range(n)])
    inits.append(np.clip(pts, 0.02, 0.98))
    for rad in (0.33, 0.40, 0.45):
        pts = [[0.5, 0.5]]
        m = n - 1
        for i in range(m):
            a = 2 * np.pi * i / m
            pts.append([0.5 + rad * np.cos(a), 0.5 + rad * np.sin(a)])
        inits.append(np.clip(np.array(pts), 0.02, 0.98))
    for _ in range(6):
        inits.append(rng.uniform(0.05, 0.95, size=(n, 2)))
    return inits


def slsqp_opt(centers, maxiter=200):
    n = len(centers)
    x0 = np.clip(centers, 0.005, 0.995).flatten()

    def neg_obj(x):
        c = x.reshape(n, 2)
        return -total_radius(c)

    bounds = [(0.005, 0.995)] * (2 * n)
    try:
        res = minimize(neg_obj, x0, method="SLSQP", bounds=bounds,
                       options={"maxiter": maxiter, "ftol": 1e-10})
        c = res.x.reshape(n, 2)
    except Exception:
        c = x0.reshape(n, 2)
    c = np.clip(c, 0.005, 0.995)
    return c, total_radius(c)


def perturb(centers, rng, sigma=0.03):
    c = centers + rng.normal(0.0, sigma, size=centers.shape)
    return np.clip(c, 0.01, 0.99)


def solve(n=26):
    rng = np.random.default_rng(20240517)
    best = None
    best_val = -1.0
    for c0 in make_inits(n, rng):
        c, v = slsqp_opt(c0, maxiter=120)
        if v > best_val:
            best_val, best = v, c
    # refinement with perturbations
    for _ in range(10):
        c0 = perturb(best, rng, sigma=0.02)
        c, v = slsqp_opt(c0, maxiter=120)
        if v > best_val:
            best_val, best = v, c
    # final polish
    c, v = slsqp_opt(best, maxiter=400)
    if v > best_val:
        best_val, best = v, c
    radii = max_radii(best)
    return np.asarray(best, dtype=float), radii
# EVOLVE-BLOCK-END
