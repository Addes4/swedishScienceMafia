# EVOLVE-BLOCK-START
"""Maximise sum of radii of 26 non-overlapping circles in the unit square.

Strategy: for fixed centres the optimal radii are determined by the wall
constraints r_i <= min(x_i, 1-x_i, y_i, 1-y_i) and the pair constraints
r_i + r_j <= dist(i, j).  We compute these radii with a fast iterative
projection, then optimise the centre positions with a numerical local search
(multi-start) to push the sum of radii upward.
"""
import numpy as np


def max_radii(centers, iters=60):
    """Largest radii for fixed centres (fast iterative projection)."""
    c = np.asarray(centers, dtype=float)
    n = len(c)
    r = np.minimum.reduce([c[:, 0], c[:, 1], 1.0 - c[:, 0], 1.0 - c[:, 1]]).copy()
    for _ in range(iters):
        diff = c[:, None, :] - c[None, :, :]
        d = np.sqrt(np.sum(diff * diff, axis=-1))
        np.fill_diagonal(d, np.inf)
        s_ij = r[:, None] + r[None, :]
        viol = s_ij - d               # >0 means overlap
        # symmetric shrink factor for violated pairs
        ratio = np.where(d > 1e-12, d / np.maximum(s_ij, 1e-12), 1.0)
        factor = np.where((viol > 0) & (ratio < 1.0), ratio, 1.0)
        shrink = np.minimum.reduce(factor, axis=1)
        if np.all(shrink >= 1.0 - 1e-15):
            break
        r = r * np.minimum(shrink, 1.0)
    return np.maximum(r, 0.0)


def total_radius(centers, iters=60):
    return float(np.sum(max_radii(centers, iters)))


def make_inits(n, rng):
    """A few structured starting configurations."""
    inits = []
    # hexagonal-like grid
    pts = []
    rows = int(np.ceil(np.sqrt(n)))
    for i in range(rows):
        for j in range(rows):
            x = (j + 0.5 + 0.5 * (i % 2)) / rows
            y = (i + 0.5) / rows
            pts.append([x, y])
    pts = np.array(pts[:n])
    inits.append(np.clip(pts, 0.02, 0.98))
    # grid
    g = int(np.ceil(np.sqrt(n)))
    pts = np.array([[ (i % g + 0.5)/g, (i // g + 0.5)/g ] for i in range(n)])
    inits.append(np.clip(pts, 0.02, 0.98))
    # ring patterns
    for rad in (0.35, 0.42):
        pts = [[0.5, 0.5]]
        m = n - 1
        for i in range(m):
            a = 2 * np.pi * i / m
            pts.append([0.5 + rad * np.cos(a), 0.5 + rad * np.sin(a)])
        inits.append(np.clip(np.array(pts), 0.02, 0.98))
    # random
    for _ in range(4):
        inits.append(rng.uniform(0.05, 0.95, size=(n, 2)))
    return inits


def local_search(centers, rng, budget_steps):
    """Coordinate/gradient-free local search on centres."""
    best = centers.copy()
    best_val = total_radius(best)
    cur = best.copy()
    cur_val = best_val
    step = 0.05
    for t in range(budget_steps):
        i = rng.integers(len(cur))
        cand = cur.copy()
        cand[i] += rng.normal(0.0, step, size=2)
        cand[i] = np.clip(cand[i], 0.005, 0.995)
        val = total_radius(cand, iters=25)
        if val > cur_val - 1e-9:
            if val > cur_val:
                cur_val = val
                cur = cand
                if val > best_val:
                    best_val = val
                    best = cand.copy()
        # occasional restart-style perturbation
        if t % 400 == 399:
            step = max(step * 0.95, 0.005)
            cur = best + rng.normal(0.0, step * 0.5, size=best.shape)
            cur = np.clip(cur, 0.005, 0.995)
            cur_val = total_radius(cur, iters=25)
        if t % 150 == 149:
            # a few multi-coordinate kicks
            cand = best + rng.normal(0.0, step, size=best.shape)
            cand = np.clip(cand, 0.005, 0.995)
            val = total_radius(cand, iters=25)
            if val > best_val:
                best_val = val
                best = cand.copy()
                cur = cand.copy()
                cur_val = val
    return best, best_val


def solve(n=26):
    rng = np.random.default_rng(12345)
    best = None
    best_val = -1.0
    inits = make_inits(n, rng)
    for c0 in inits:
        c, v = local_search(c0, rng, budget_steps=900)
        if v > best_val:
            best_val = v
            best = c
    # final polish with more accurate radii evaluations
    c, v = local_search(best, rng, budget_steps=700)
    if v > best_val:
        best_val = v
        best = c
    radii = max_radii(best, iters=200)
    return np.asarray(best, dtype=float), radii
# EVOLVE-BLOCK-END
