# EVOLVE-BLOCK-START
"""Maximise sum of radii of 26 non-overlapping circles in the unit square.

Strategy: the optimal radii for fixed centres are the solution of
    r_i <= wall_i,  r_i + r_j <= d_ij
and we compute them with a fast iterative projection.  To move the centres we
use the *analytically differentiable* soft-min/geometric-mean proxy for the
maximal radii, optimise it with L-BFGS-B, and then run a cheap contact-based
local descent that shifts each circle away from its tightest neighbours.
"""
import numpy as np
from scipy.optimize import minimize


def max_radii(centers, iters=80):
    """Largest feasible radii for fixed centres (iterative projection)."""
    c = np.asarray(centers, dtype=float)
    n = len(c)
    r = np.minimum.reduce([c[:, 0], c[:, 1], 1.0 - c[:, 0], 1.0 - c[:, 1]]).copy()
    for _ in range(iters):
        diff = c[:, None, :] - c[None, :, :]
        d = np.sqrt(np.sum(diff * diff, axis=-1))
        np.fill_diagonal(d, np.inf)
        s_ij = r[:, None] + r[None, :]
        viol = s_ij - d
        ratio = np.where(d > 1e-12, d / np.maximum(s_ij, 1e-12), 1.0)
        factor = np.where((viol > 0) & (ratio < 1.0), ratio, 1.0)
        shrink = np.minimum.reduce(factor, axis=1)
        if np.all(shrink >= 1.0 - 1e-15):
            break
        r = r * np.minimum(shrink, 1.0)
    return np.maximum(r, 0.0)


def total_radius(centers, iters=80):
    return float(np.sum(max_radii(centers, iters)))


def soft_radii(centers, k=10.0):
    """Differentiable proxy: soft-min of wall and (d_ij) constraints."""
    c = np.asarray(centers, dtype=float)
    n = len(c)
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1.0 - c[:, 0], 1.0 - c[:, 1]])
    diff = c[:, None, :] - c[None, :, :]
    d = np.sqrt(np.sum(diff * diff, axis=-1) + 1e-12)
    # soft-min for the pairwise constraint r_i + r_j <= d_ij  ->  r_i <= d_ij - r_j
    # Use a smooth approx: r_i = softmin_j (d_ij - r_j), iterate a few times.
    r = wall.copy()
    for _ in range(6):
        D = d - r[None, :]                      # candidate upper bounds for r_i
        np.fill_diagonal(D, np.inf)
        # smooth min via -log(sum(exp(-k*x)))/k
        m = np.min(D, axis=1, keepdims=True)
        sm = m[:, 0] - np.log(np.sum(np.exp(-k * (D - m)), axis=1)) / k
        r = np.minimum(wall, np.minimum(r, sm))
    return r


def total_soft(centers):
    return float(np.sum(soft_radii(centers)))


def lbfgsb_opt(centers, maxiter=300):
    n = len(centers)
    x0 = np.clip(centers, 0.005, 0.995).flatten()

    def neg_obj(x):
        c = x.reshape(n, 2)
        return -total_soft(c)

    bounds = [(0.005, 0.995)] * (2 * n)
    try:
        res = minimize(neg_obj, x0, method="L-BFGS-B", bounds=bounds,
                       options={"maxiter": maxiter, "ftol": 1e-12, "gtol": 1e-9})
        x = res.x
    except Exception:
        x = x0
    return np.clip(x.reshape(n, 2), 0.005, 0.995)


def contact_descent(centers, steps=60, lr=0.02):
    """Move circles apart along their tightest constraints to grow radii."""
    c = centers.copy()
    n = len(c)
    best_c = c.copy()
    best_v = total_radius(c)
    for it in range(steps):
        r = max_radii(c, iters=100)
        diff = c[:, None, :] - c[None, :, :]
        d = np.sqrt(np.sum(diff * diff, axis=-1) + 1e-18)
        np.fill_diagonal(d, np.inf)
        s = r[:, None] + r[None, :]
        gap = d - s                      # >=0 for feasible
        # gradient of sum radii w.r.t. centres (approximately reciprocal weights)
        grad = np.zeros_like(c)
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                if gap[i, j] < 1e-3:
                    dir_ij = (c[i] - c[j]) / max(d[i, j], 1e-9)
                    grad[i] += dir_ij * (1.0 / max(gap[i, j], 1e-3))
        # wall pressure
        for i in range(n):
            x, y = c[i]
            grad[i, 0] += (0.5 - x) / max(min(x, 1 - x), 1e-3) ** 2 * 0.05
            grad[i, 1] += (0.5 - y) / max(min(y, 1 - y), 1e-3) ** 2 * 0.05
        gnorm = np.sqrt(np.sum(grad * grad)) + 1e-12
        c = c + lr * grad / gnorm * np.sqrt(n)
        c = np.clip(c, 0.003, 0.997)
        v = total_radius(c)
        if v > best_v + 1e-7:
            best_v = v
            best_c = c.copy()
        elif v < best_v - 1e-4:
            lr *= 0.5
            c = best_c.copy()
        if lr < 1e-5:
            break
    return best_c, best_v


def tri_lattice(n, scale):
    pts = []
    dy = np.sqrt(3.0) / 2.0
    k = 0
    row = 0
    while len(pts) < n:
        for col in range(row + 1):
            x = scale * (col - row / 2.0)
            y = scale * dy * row
            pts.append([x, y])
        row += 1
    pts = np.array(pts[:n], dtype=float)
    pts -= pts.mean(axis=0)
    extent = max(pts[:, 0].ptp(), pts[:, 1].ptp(), 1e-9)
    pts /= extent
    return 0.5 + pts * 0.9


def make_inits(n, rng):
    inits = []
    for scale in (0.9, 1.0, 1.1, 1.25, 1.4):
        try:
            inits.append(np.clip(tri_lattice(n, scale), 0.02, 0.98))
        except Exception:
            pass
    g = int(np.ceil(np.sqrt(n)))
    for rows in (g, g + 1):
        pts = []
        for i in range(rows):
            for j in range(rows):
                x = (j + 0.5 + 0.5 * (i % 2)) / rows
                y = (i + 0.5) / rows
                pts.append([x, y])
        inits.append(np.clip(np.array(pts[:n]), 0.02, 0.98))
    for rad in (0.32, 0.40):
        pts = [[0.5, 0.5]]
        m = n - 1
        for i in range(m):
            a = 2 * np.pi * i / m
            pts.append([0.5 + rad * np.cos(a), 0.5 + rad * np.sin(a)])
        inits.append(np.clip(np.array(pts), 0.02, 0.98))
    for _ in range(6):
        inits.append(rng.uniform(0.05, 0.95, size=(n, 2)))
    return inits


def solve(n=26):
    rng = np.random.default_rng(2024)
    best = None
    best_val = -1.0
    inits = make_inits(n, rng)

    def improve(c0, tag):
        nonlocal best, best_val
        c1 = lbfgsb_opt(c0, maxiter=250)
        v1 = total_radius(c1)
        c2, v2 = contact_descent(c1, steps=80, lr=0.03)
        c3 = lbfgsb_opt(c2, maxiter=250)
        v3 = total_radius(c3)
        c4, v4 = contact_descent(c3, steps=80, lr=0.02)
        candidates = [(c1, v1), (c2, v2), (c3, v3), (c4, v4)]
        for c, v in candidates:
            if v > best_val:
                best_val = v
                best = c.copy()

    for c0 in inits:
        improve(c0, "init")

    # extra random restarts focused near the best
    for _ in range(8):
        c0 = best + rng.normal(0.0, 0.02, size=best.shape)
        c0 = np.clip(c0, 0.01, 0.99)
        improve(c0, "perturb")

    radii = max_radii(best, iters=300)
    return np.asarray(best, dtype=float), radii
# EVOLVE-BLOCK-END

