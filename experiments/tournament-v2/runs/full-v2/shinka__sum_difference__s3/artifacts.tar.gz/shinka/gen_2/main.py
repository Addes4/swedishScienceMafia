# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _score_fast(a):
    """Score a set (list) quickly."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _initial_seed(rng):
    """Create a structured seed: a Sidon-like set with small sums."""
    n = rng.randint(8, 30)
    base = sorted(rng.sample(range(-50, 51), n))
    return base


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    rng = random.Random(12345)
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score_fast(best)
    deadline = time.time() + 110
    restarts = 0
    while time.time() < deadline:
        restarts += 1
        cur = _initial_seed(rng)
        cur_score = _score_fast(cur)
        # local search on this restart
        stall = 0
        while stall < 400 and time.time() < deadline:
            cand = cur[:]
            r = rng.random()
            if r < 0.45 and cand:
                # perturb one element
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1, -2, 2, -3, 3, -5, 5, -10, 10, -20, 20])
            elif r < 0.65:
                # add a new element near the existing range
                lo = min(cand) - 30
                hi = max(cand) + 30
                cand.append(rng.randint(lo, hi))
            elif r < 0.80 and len(cand) > 3:
                # remove an element
                i = rng.randrange(len(cand))
                cand.pop(i)
            elif r < 0.90:
                # shift whole set
                d = rng.randint(-15, 15)
                cand = [x + d for x in cand]
            else:
                # scale whole set
                k = rng.choice([2, 3])
                cand = [x * k for x in cand]
            cand = list(set(cand))
            if len(cand) < 2:
                continue
            s = _score_fast(cand)
            if s > cur_score or (s == cur_score and rng.random() < 0.5):
                cur, cur_score = cand, s
                stall = 0
                if s > best_score:
                    best, best_score = cand[:], s
            else:
                stall += 1
        # also consider merging best with a fresh seed
        if rng.random() < 0.3:
            merged = list(set(best + _initial_seed(rng)))
            ms = _score_fast(merged)
            if ms > best_score:
                best, best_score = merged, ms
    return sorted(set(best))
# EVOLVE-BLOCK-END