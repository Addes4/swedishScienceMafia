# EVOLVE-BLOCK-START
"""Structured construction: union of APs with Sidon offsets + simulated annealing."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _greedy_sidon(limit, target):
    """Greedily build a Sidon set (all pairwise sums distinct) within [0, limit)."""
    s = [0]
    sums = {0}
    for x in range(1, limit):
        ok = True
        new = set()
        for y in s:
            v = x + y
            if v in sums or v in new:
                ok = False
                break
            new.add(v)
        if ok:
            s.append(x)
            sums |= new
            if len(s) >= target:
                break
    return s


def _build_seed():
    """Union of k shifts of a Sidon set by multiples of M."""
    best = None
    best_sc = -1.0
    for sidon_size in (8, 10, 12, 14):
        for k in (2, 3, 4, 5, 6):
            for M in (50, 100, 200, 400, 800, 1600):
                S = _greedy_sidon(M, sidon_size)
                if len(S) < sidon_size:
                    continue
                A = []
                for i in range(k):
                    off = i * M
                    for s in S:
                        A.append(s + off)
                sc = _score(A)
                if sc > best_sc:
                    best_sc = sc
                    best = A
    return best, best_sc


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    seed, seed_sc = _build_seed()
    if seed is None:
        seed = [0, 1, 3, 7, 12, 20]
        seed_sc = _score(seed)

    best = list(seed)
    best_score = seed_sc
    cur = list(seed)
    cur_score = seed_sc

    deadline = time.time() + 110
    t0 = time.time()
    it = 0
    while time.time() < deadline:
        it += 1
        frac = (time.time() - t0) / 110.0
        T = max(0.0005, 0.05 * (1.0 - frac))
        cand = list(cur)
        r = random.random()
        if r < 0.55:
            # perturb one element
            i = random.randrange(len(cand))
            span = max(1, 20000 // (1 + len(cand)))
            cand[i] += random.randint(-span, span)
        elif r < 0.8:
            # shift a whole shift-block (structure-preserving move)
            n = len(cand)
            cand = [x + random.randint(-500, 500) for x in cand]
            cand = list(set(cand))
        elif r < 0.92:
            # add a new element
            cand.append(random.randint(-100000, 100000))
        else:
            # remove an element
            if len(cand) > 6:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s >= cur_score or random.random() < math.exp((s - cur_score) / T):
            cur = cand
            cur_score = s
            if s > best_score:
                best = list(cand)
                best_score = s
    return sorted(set(best))
# EVOLVE-BLOCK-END