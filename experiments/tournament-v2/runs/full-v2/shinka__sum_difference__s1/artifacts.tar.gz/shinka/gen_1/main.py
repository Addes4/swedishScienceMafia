# EVOLVE-BLOCK-START
"""Search over structured integer sets to make |A - A| large and |A + A| small:
maximise log|A - A| / log|A + A|. Uses convex-sequence seeds (squares, cubes, mixed)
plus local search, since strictly convex sets have all-distinct differences while their
sums collide, giving a favourable ratio."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _seeds():
    seeds = []
    for n in (20, 30, 40, 60, 80, 120, 160, 200, 260, 320):
        seeds.append([i * i for i in range(1, n + 1)])
        seeds.append([i * i * i for i in range(1, n + 1)])
        seeds.append([i * i + i for i in range(1, n + 1)])
        seeds.append([i * i + 3 * i for i in range(1, n + 1)])
    return seeds


def _local_search(seed, deadline):
    best = seed[:]
    best_score = _score(best)
    cur = seed[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-3, -2, -1, 1, 2, 3])
            if len(set(cand)) < len(cand):
                continue
        elif r < 0.8:
            cand.append(random.randint(1, max(4, max(cand) + 5)))
            if len(set(cand)) < len(cand):
                continue
        elif r < 0.9 and len(cand) > 3:
            i = random.randrange(len(cand))
            del cand[i]
        else:
            # shift a suffix
            k = random.randrange(1, len(cand) + 1)
            d = random.choice([-2, -1, 1, 2])
            cand = [x + (d if idx >= k else 0) for idx, x in enumerate(cand)]
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s >= best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.15:
            cur, cur_score = best[:], best_score
    return best, best_score


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    for seed in _seeds():
        if time.time() >= deadline:
            break
        sub_deadline = min(deadline, time.time() + 8)
        b, s = _local_search(seed, sub_deadline)
        if s > best_score:
            best, best_score = b, s
    # final polish on the best found
    if time.time() < deadline:
        b, s = _local_search(best, deadline)
        if s > best_score:
            best, best_score = b, s
    return sorted(set(best))
# EVOLVE-BLOCK-END