# EVOLVE-BLOCK-START
"""Greedy set-growing search for sets with large difference sets and small sum sets.

The score is  log|A-A| / log|A+A|  (+ small bonus for larger |A|).

Idea: start from a small seed and greedily add the integer (from a candidate pool)
that maximises the resulting score.  Difference and sum sets are maintained
incrementally so each trial insertion only costs O(n) set operations instead of
O(n^2).  Seeds come from a couple of structured families (geometric-ish, powers
of two / base-3 style) plus randomised multi-starts, each grown greedily.
"""

import math
import random
import time


def _score(diffs, sums, n):
    if n < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _grow(seed, pool, deadline):
    """Greedily grow *seed* by adding pool elements that most improve the score.

    diffs / sums are maintained incrementally: adding x to A creates new
    differences {x - a : a in A} union {a - x : a in A} and new sums
    {x + a : a in A}.  Only |A| new elements per candidate, no full recompute.
    """
    A = list(dict.fromkeys(seed))
    diffset = set()
    sumset = set()
    for i in range(len(A)):
        for j in range(len(A)):
            diffset.add(A[i] - A[j])
            sumset.add(A[i] + A[j])

    # pool as a set-backed list we can shrink
    pool = list(dict.fromkeys(pool))
    n = len(A)
    cur_score = _score(diffset, sumset, n)

    improved = True
    while improved and time.time() < deadline:
        improved = False
        best_gain = 0.0
        best_idx = -1
        best_nd = None
        best_ns = None
        best_score = cur_score

        # Evaluate every pool element that is not already in A
        cur_set = set(A)
        for idx, x in enumerate(pool):
            if x in cur_set:
                continue

            # incremental difference set
            new_diffs = set()
            new_sums = set()
            for a in A:
                new_diffs.add(x - a)
                new_diffs.add(a - x)
                new_sums.add(x + a)

            nd = diffset | new_diffs
            ns = sumset | new_sums
            s = _score(nd, ns, n + 1)

            if s > best_score:
                best_score = s
                best_idx = idx
                best_gain = s - cur_score
                best_nd = nd
                best_ns = ns

        if best_idx >= 0:
            x = pool[best_idx]
            A.append(x)
            diffset = best_nd
            sumset = best_ns
            n += 1
            cur_score = best_score
            improved = True

    return A, cur_score


def _seed_pool(rng):
    """A pool of candidate integers, biased toward structured values."""
    pool = set()
    # scaled powers / geometric-style values
    for base in (2, 3, 4, 5, 7):
        v = 1
        for _ in range(40):
            pool.add(v)
            pool.add(-v)
            v = v * base + rng.randint(0, 1)
            if v > 10 ** 12:
                break
    # small dense values
    for v in range(-60, 61):
        pool.add(v)
    # random moderate values
    for _ in range(200):
        pool.add(rng.randint(-5000, 5000))
    return sorted(pool)


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110.0

    pool = _seed_pool(rng)

    best_A = [0]
    best_score = 0.0

    # --- structured / random multi-starts, each grown greedily ---
    seeds = []

    # pure geometric (powers of 2, 3, 5)
    for base in (2, 3, 5):
        s = []
        v = 1
        for _ in range(4):
            s.append(v)
            v *= base
        seeds.append(s)

    # small random starting sets
    for _ in range(6):
        k = rng.randint(2, 5)
        seeds.append([rng.randint(-20, 20) for _ in range(k)])

    # single tiny seed to let greedy bootstrap
    seeds.append([0])
    seeds.append([1])
    seeds.append([0, 1])

    for si, seed in enumerate(seeds):
        if time.time() > deadline:
            break
        try:
            A, sc = _grow(seed, pool, deadline)
        except Exception:
            continue
        if sc > best_score:
            best_score = sc
            best_A = A[:]

    # local polish: try small perturbations of the best set
    cur = best_A[:]
    while time.time() < deadline:
        cand = cur[:]
        i = rng.randrange(len(cand))
        cand[i] += rng.randint(-2, 2)
        if cand[i] in cand and cand.count(cand[i]) > 1:
            continue
        d = set()
        s = set()
        for x in cand:
            for y in cand:
                d.add(x - y)
                s.add(x + y)
        sc = _score(d, s, len(cand))
        if sc > best_score:
            best_score = sc
            best_A = cand[:]
            cur = cand[:]
        elif rng.random() < 0.05:
            cur = best_A[:]

    return sorted(set(best_A))

# EVOLVE-BLOCK-END
