# EVOLVE-BLOCK-START
"""Union of scaled copies of a small Sidon-like base set, with local refinement.

Idea: take a small base set B whose pairwise differences are mostly distinct (Sidon-like),
and a set of shifts/multipliers so that A = union_k (m_k * B + t_k).  Choosing the m_k with
different magnitudes makes many cross-differences distinct, while sums stay confined because
the mixing coefficients are chosen so m_i + m_j also live in a small set of values (e.g., all
m_k equal to +/- powers of 2 gives few distinct sums but structured differences).  Then do a
short local search to polish.
"""
import math
import random
import time


def _stats(a):
    a = list(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            if x <= y:
                sums.add(x + y)
    # sums symmetric: |A+A| = 2*#unordered pairs - 1 (diagonal)
    nsum = 2 * len(sums) - 1
    return len(diffs), nsum


def _score(a):
    if len(set(a)) < 2:
        return 0.0
    d, s = _stats(list(set(a)))
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(set(a))) / 100


# Small Sidon-like base sets (distinct pairwise differences as much as possible).
BASE_SETS = [
    [0, 1, 4, 9, 15, 22, 32, 34],
    [0, 1, 3, 7, 12, 20, 30, 44],
    [0, 1, 4, 10, 18, 23, 35, 46],
    [0, 1, 3, 8, 14, 22, 30, 41],
    [0, 1, 4, 11, 19, 28, 39, 51],
    [0, 1, 5, 12, 21, 34, 44, 58],
    [0, 1, 3, 9, 17, 27, 40, 54],
    [0, 1, 4, 9, 16, 27, 39, 52],
]


def _build(base, mults, shifts):
    """A = union_k ( mults[k] * base + shifts[k] )."""
    out = []
    for m, t in zip(mults, shifts):
        for b in base:
            out.append(m * b + t)
    return out


def _union_copies(base, size):
    """Build A with roughly `size` elements from scaled translated copies of base."""
    lb = len(base)
    k = max(2, size // lb)
    # coefficients: use a small set of magnitudes with alternating signs to keep sums few
    coeffs = []
    p = 1
    while len(coeffs) < k:
        coeffs.append(p)
        coeffs.append(-p)
        p *= 2
    coeffs = coeffs[:k]
    shifts = []
    for i, c in enumerate(coeffs):
        # distinct offsets spread out, but bounded so that shifts don't blow up sums
        shifts.append(i * 1000003 + (i * i) % 7919)
    A = _build(base, coeffs, shifts)
    return list(set(A))


def _improve(a, best_score, deadline, rng):
    a = list(set(a))
    span = max(abs(x) for x in a)
    step = max(1, span // 1000 + 1)
    cur = a[:]
    best = a[:]
    while time.time() < deadline:
        cand = cur[:]
        if rng.random() < 0.7 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-step, step)
        elif rng.random() < 0.5:
            cand.append(rng.randint(-span, span))
        elif len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif rng.random() < 0.05:
            cur = best[:]
        else:
            cur = cand
    return best, best_score


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Try structured constructions and keep the best.
    targets = [60, 120, 240, 400, 800, 1600, 3000, 4000]
    for base in BASE_SETS:
        for tgt in targets:
            A = _union_copies(base, tgt)
            s = _score(A)
            if s > best_score:
                best, best_score = A, s

    # A couple of direct polynomial/geometric style constructions.
    for n in [64, 200, 1000]:
        A = [i * i + i for i in range(n)]
        s = _score(A)
        if s > best_score:
            best, best_score = A, s

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # Local refinement.
    best, best_score = _improve(best, best_score, deadline, rng)

    return sorted(set(best))
# EVOLVE-BLOCK-END
