import math
import random
import time

def _score(a):
    """Compute objective: log|A-A| / log|A+A| + (1 - 1/|A|)/100."""
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _evaluate_diff_sum(a):
    """Return (|A-A|, |A+A|) for a list of integers."""
    a = set(a)
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums)

def geometric_construction(n, base, multiplier):
    """Return list of integers M * base**i for i=0..n-1."""
    # Use integer arithmetic; base can be fractional but we use integer ratios
    # Here we just build geometric progression with integer base and multiplier
    result = []
    val = multiplier
    for _ in range(n):
        result.append(val)
        val *= base
    return result

def modular_progression(p, m, start, step, n):
    """Generate n elements of arithmetic progression modulo m, lifted to integers."""
    result = []
    cur = start
    for _ in range(n):
        result.append((cur % m) - m//2)  # center around zero
        cur += step
    return result

def tuned_geometric():
    """Try geometric-like construction with multiplier and base tuning."""
    best_list = None
    best_score = -1
    
    # Grid search over parameters
    for n in range(2, 250):  # limit size due to time
        for mult in [1, 2, 3, 5, 7, 11, 13]:
            for base in [2, 3, 4, 5]:
                cand = geometric_construction(n, base, mult)
                # ensure distinct
                if len(set(cand)) < n:
                    continue
                # check magnitude limits
                if max(abs(x) for x in cand) > 1e15:
                    continue
                s = _score(cand)
                if s > best_score:
                    best_score = s
                    best_list = cand[:]
    return best_list, best_score

def tuned_modular():
    """Try modular arithmetic progression with parameter search."""
    best_list = None
    best_score = -1
    
    # Sizes up to ~1000; larger sets can be slow
    for n in [50, 100, 150, 200, 250, 300, 400, 500, 600, 800, 1000]:
        for m in [n*2 + 1, n*3, n*5, n*7, 9973, 10007]:  # prime-ish moduli
            if m > 20000:  # keep bounds reasonable
                continue
            for start in range(0, m, max(1, m//20)):
                steps = [1, 2, 3, 5, 7, 11]
                for step in steps:
                    cand = modular_progression(m, m, start, step, n)
                    if len(set(cand)) < n:
                        continue
                    s = _score(cand)
                    if s > best_score:
                        best_score = s
                        best_list = cand[:]
    return best_list, best_score

def local_search_improve(initial, steps=2000, time_limit=100):
    """Hill-climb on given initial list: add/remove/mutate elements."""
    best = initial[:]
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    deadline = time.time() + time_limit
    iteration = 0
    
    while time.time() < deadline and iteration < steps:
        iteration += 1
        # choose operation
        op = random.random()
        if op < 0.5 and len(cur) > 2:
            # mutate an element
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, 50)
            s = _score(cand)
            if s > cur_score:
                cur, cur_score = cand, s
                if cur_score > best_score:
                    best, best_score = cur, cur_score
            elif random.random() < 0.05:
                cur = best[:]  # reset occasionally
                cur_score = _score(cur)
        elif op < 0.8 and len(cur) < 4000:
            # add element
            cand = cur[:]
            # choose value near existing
            base = random.choice(cand)
            new_val = base + random.randint(-100, 100)
            if new_val not in cand:
                cand.append(new_val)
                s = _score(cand)
                if s > cur_score:
                    cur, cur_score = cand, s
                    if cur_score > best_score:
                        best, best_score = cur, cur_score
        elif len(cur) > 5:
            # remove element
            cand = cur[:]
            i = random.randrange(len(cand))
            del cand[i]
            s = _score(cand)
            if s > cur_score:
                cur, cur_score = cand, s
                if cur_score > best_score:
                    best, best_score = cur, cur_score
        # adaptive restart
        if random.random() < 0.01:
            cur = best[:]
            cur_score = _score(cur)
    return best, best_score

def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    best_overall = None
    best_overall_score = -1
    
    start_time = time.time()
    total_time = 118  # leave small margin

    # Phase 1: try geometric constructions
    geo_list, geo_score = tuned_geometric()
    if geo_list and geo_score > best_overall_score:
        best_overall = geo_list[:]
        best_overall_score = geo_score

    # Phase 2: try modular progressions
    mod_list, mod_score = tuned_modular()
    if mod_list and mod_score > best_overall_score:
        best_overall = mod_list[:]
        best_overall_score = mod_score

    # Phase 3: refine best found so far with local search
    if best_overall:
        # spend remaining time on improvement
        remaining = total_time - (time.time() - start_time)
        if remaining > 0:
            improved, improved_score = local_search_improve(
                best_overall, steps=100000, time_limit=remaining
            )
            if improved_score > best_overall_score:
                best_overall = improved[:]
                best_overall_score = improved_score

    # Final fallback - robust set from literature-like construction:
    # A = {k * (2**i) for i in range(n)} can give good ratio.
    if best_overall is None or best_overall_score < 1.0:
        # Quick geometric
        n = 1600
        base = 2
        mult = 1
        best_overall = geometric_construction(n, base, mult)
        # tweak with small shifts
        best_overall = [x + (i % 3 - 1) for i, x in enumerate(best_overall)]
        # limit magnitude
        best_overall = [x for x in best_overall if abs(x) <= 1e15]
        # ensure distinct
        best_overall = list(set(best_overall))
        best_overall_score = _score(best_overall)

    # final clean: sort and ensure constraints
    result = sorted(set(best_overall))
    # if too many, trim; if too large magnitude, truncate
    if len(result) > 4000:
        # keep best scoring subset by greedy removal of worst element
        while len(result) > 4000:
            worst_idx = 0
            worst_drop_score = -1
            for i in range(len(result)):
                tmp = result[:i] + result[i+1:]
                s = _score(tmp)
                if s > worst_drop_score:
                    worst_drop_score = s
                    worst_idx = i
            result = result[:worst_idx] + result[worst_idx+1:]
    # ensure absolute values <= 1e15
    result = [x for x in result if abs(x) <= 1e15]
    if len(result) < 2:
        # fallback
        result = [0, 1, 3, 7, 15, 31]
    
    return sorted(set(result))
