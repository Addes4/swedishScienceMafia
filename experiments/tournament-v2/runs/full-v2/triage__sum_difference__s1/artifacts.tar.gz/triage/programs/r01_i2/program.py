# EVOLVE-BLOCK-START
"""Simulated annealing over integer sets with a library of high-scoring seeds.

Moves: shift an element by a small offset, swap two elements, add/remove an element,
and occasionally merge in a seed from a precomputed library of good small sets.

Objective: maximise log|A - A| / log|A + A| plus a small bonus for larger sets.
"""
import math
import random
import time

# ---------------------------------------------------------------------------
# Fast evaluation
# ---------------------------------------------------------------------------

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    s = set(a)
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


# ---------------------------------------------------------------------------
# Build a library of high-scoring small seed sets
# ---------------------------------------------------------------------------

def _build_library(deadline):
    """Greedily / randomly search for small sets with high scores."""
    lib = []

    def add_if_good(cand):
        cand = sorted(set(cand))
        if len(cand) < 3:
            return
        sc = _score(cand)
        lib.append((sc, tuple(cand)))

    # A few classic structured seeds (B_h-like / Sidon-ish / geometric)
    add_if_good([0, 1, 3, 7, 12, 20])
    add_if_good([0, 1, 4, 10, 18, 27])
    add_if_good([-1, 0, 1, 3, 8, 16, 27])
    add_if_good([0, 1, 2, 5, 10, 20, 40])
    add_if_good([0, 1, 3, 9, 27, 81, 243])

    # Random perturbation search toward high difference / low sum
    base = [0, 1, 3, 7, 12]
    cur = base[:]
    cur_sc = _score(cur)
    rng = random.Random(12345)
    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.6:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-4, 4)
        elif op < 0.8:
            cand.append(rng.randint(0, 30))
        else:
            if len(cand) > 3:
                cand.pop(rng.randrange(len(cand)))
        cand = sorted(set(cand))
        if len(cand) < 3:
            continue
        sc = _score(cand)
        if sc >= cur_sc or rng.random() < 0.05:
            cur, cur_sc = cand, sc
            if sc > 1.2:
                add_if_good(cand)

    lib.sort(reverse=True)
    # Keep a diverse top slice
    seen = set()
    uniq = []
    for sc, t in lib:
        if t in seen:
            continue
        seen.add(t)
        uniq.append((sc, t))
    return uniq[:60]


# ---------------------------------------------------------------------------
# Simulated annealing
# ---------------------------------------------------------------------------

def solve():
    deadline = time.time() + 110.0
    lib_deadline = time.time() + 12.0
    library = _build_library(lib_deadline)

    rng = random.Random(987654321)

    # Start from the best seed found
    if library:
        best = list(library[0][1])
    else:
        best = [0, 1, 3, 7, 12, 20]
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score

    t0 = time.time()
    total = deadline - t0

    while time.time() < deadline:
        # Temperature schedule: exponential-ish decay to a small floor
        frac = (time.time() - t0) / total
        T = max(0.02, 0.9 * (1.0 - frac) ** 2)

        cand = cur[:]
        r = rng.random()

        if r < 0.45:
            # shift one element by a small offset
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-3, 3)
        elif r < 0.65 and len(cand) >= 2:
            # swap two elements (perturb magnitudes around)
            i, j = rng.sample(range(len(cand)), 2)
            cand[i], cand[j] = cand[j], cand[i]
            if rng.random() < 0.5:
                cand[i] += rng.randint(-2, 2)
        elif r < 0.80:
            # add a new element
            if len(cand) < 4000:
                seed = cand[rng.randrange(len(cand))] if cand else 0
                cand.append(seed + rng.randint(-25, 25))
        elif r < 0.90:
            # remove an element
            if len(cand) > 3:
                cand.pop(rng.randrange(len(cand)))
        else:
            # merge with a library seed
            if library:
                _, seed = library[rng.randrange(min(10, len(library)))]
                for v in seed:
                    if rng.random() < 0.7:
                        cand.append(v + rng.randint(-2, 2))
                if len(cand) > 4000:
                    rng.shuffle(cand)
                    cand = cand[:4000]

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue

        sc = _score(cand)
        if sc >= cur_score or rng.random() < math.exp((sc - cur_score) / T):
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
