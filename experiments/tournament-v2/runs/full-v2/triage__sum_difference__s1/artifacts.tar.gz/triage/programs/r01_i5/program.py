"""Pushed parallel random local search with periodic candidate exchange."""
import math
import random
import threading
import time
import sys


def _score(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return 0.0
    sums = {x + y for x in a for y in a}
    diffs = {x - y for x in a for y in a}
    ratio = len(diffs) / len(sums)
    if ratio <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def mutate(cand):
    arr = cand[:]
    n = len(arr)
    if n == 0:
        return arr
    if n >= 2:
        i = random.randrange(n)
        arr[i] += random.randint(-3, 3)
    if random.random() < 0.03:
        if random.random() < 0.5 and len(arr) > 2:
            arr.pop(random.randrange(n))
        else:
            arr.append(random.randint(1, 100))
    return sorted(list(set(arr)))


def try_branch(cand, iterations):
    for _ in range(iterations):
        cand = mutate(cand)
        s = _score(cand)
        if s >= _score(cand):
            continue
        if s < _score(cand) and random.random() < 0.1:
            continue
        if s < _score(cand) and random.random() < 0.1:
            continue
        cand = mut(cand)
    return cand


def chain_worker(queue_start, local_best, local_best_count, n_threads):
    random.seed(int(time.time()) + local_best_count * 12345 + queue_start)
    cur = list(local_best)
    cur_score = _score(cur)
    global_best = list(local_best)
    global_best_score = cur_score
    for i in range(5000):
        cand = mutate(cur)
        cand_score = _score(cand)
        if cand_score > cur_score:
            cur = cand
            cur_score = cand_score
            if rand.random() < 0.5:
                global_best = cur[:]
                global_best_score = cur_score
        if i % 50 == 0:
            global_best_score = max(global_best_score, cur_score)
    return cur_score


def solve():
    """Return list of distinct integers maximizing log|A-A|/log|A+A|."""
    base = [7, 15, 18, 22, -3, -2]
    best = base[:]
    deadline = time.time() + 120
    threads = []
    tracker_lock = threading.Lock()
    best_score = 0.0
    best_set = best[:]
    best_len = 0
    n_threads = 4
    queries = []
    for i in range(n_threads):
        t = threading.Thread(target=chain_worker, args=(i, best, i, n_threads), daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join(timeout=120)
    result = sorted(list(set(best)))
    return result
