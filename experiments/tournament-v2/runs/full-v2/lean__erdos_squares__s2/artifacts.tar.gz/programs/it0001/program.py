# EVOLVE-BLOCK-START
"""Constructive packing: uniform grid seed refined by a repulsion/expansion optimizer."""
import math
import random


def _overlap_penalty(squares):
    """Sum of squared overlap depths between all pairs (interior overlap)."""
    total = 0.0
    m = len(squares)
    for i in range(m):
        xi, yi, ai, si = squares[i]
        if si <= 0.0:
            continue
        for j in range(i + 1, m):
            xj, yj, aj, sj = squares[j]
            if sj <= 0.0:
                continue
            pen = _pair_pen(xi, yi, ai, si, xj, yj, aj, sj)
            total += pen
    return total


def _corners(x, y, a, s):
    """Return the 4 corner points of a square."""
    h = s * 0.5
    t = a * 2.0 * math.pi
    c = math.cos(t)
    sn = math.sin(t)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((x + dx * c - dy * sn, y + dx * sn + dy * c))
    return pts


def _pair_pen(x1, y1, a1, s1, x2, y2, a2, s2):
    """Approximate overlap penalty via separating axis test on the two squares."""
    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0
    p1 = _corners(x1, y1, a1, s1)
    p2 = _corners(x2, y2, a2, s2)
    axes = []
    for pts in (p1, p2):
        for k in range(4):
            ax = pts[(k + 1) % 4][0] - pts[k][0]
            ay = pts[(k + 1) % 4][1] - pts[k][1]
            ln = math.hypot(ax, ay)
            if ln > 1e-12:
                axes.append((ax / ln, ay / ln))
    sep = 0.0
    overlap = None
    for ax, ay in axes:
        mn1 = min(px * ax + py * ay for px, py in p1)
        mx1 = max(px * ax + py * ay for px, py in p1)
        mn2 = min(px * ax + py * ay for px, py in p2)
        mx2 = max(px * ax + py * ay for px, py in p2)
        o = min(mx1, mx2) - max(mn1, mn2)
        if o <= 0.0:
            return 0.0
        if overlap is None or o < overlap:
            overlap = o
    if overlap is None:
        return 0.0
    return overlap * overlap


def _in_unit(x, y, a, s):
    """Check all corners lie in [0,1]^2 (with tolerance)."""
    if s <= 0.0:
        return True
    for px, py in _corners(x, y, a, s):
        if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
            return False
    return True


def _clamp_inside(x, y, a, s):
    """Move centre so the square fits (if possible)."""
    if s <= 0.0:
        return 0.5, 0.5
    t = a * 2.0 * math.pi
    c = abs(math.cos(t))
    sn = abs(math.sin(t))
    h = s * 0.5
    rx = h * (c + sn)
    ry = h * (c + sn)
    if 2 * rx > 1.0 + 1e-9 or 2 * ry > 1.0 + 1e-9:
        return None
    x = min(max(x, rx), 1.0 - rx)
    y = min(max(y, ry), 1.0 - ry)
    return x, y


def _cost(squares):
    pen = _overlap_penalty(squares)
    total = pen * 1e4
    for x, y, a, s in squares:
        if s > 0:
            if not _in_unit(x, y, a, s):
                total += 1e5
    return total


def _improve(squares, iters):
    m = len(squares)
    best = [list(s) for s in squares]
    bestc = _cost(best)
    cur = [list(s) for s in squares]
    curc = bestc
    step = 0.05
    rng = random.Random(12345)
    for it in range(iters):
        if curc <= 1e-9:
            # try growing
            grown = []
            for x, y, a, s in cur:
                s2 = min(s * 1.02 + 0.0005, 0.99)
                g = _clamp_inside(x, y, a, s2)
                if g is None:
                    grown.append((x, y, a, s))
                else:
                    grown.append((g[0], g[1], a, s2))
            gc = _cost(grown)
            if gc < curc:
                cur = [list(s) for s in grown]
                curc = gc
                if curc < bestc:
                    best = [list(s) for s in cur]
                    bestc = curc
            else:
                step *= 0.99
            continue
        i = rng.randrange(m)
        cand = [list(s) for s in cur]
        x, y, a, s = cand[i]
        if rng.random() < 0.7:
            nx = x + rng.uniform(-step, step)
            ny = y + rng.uniform(-step, step)
            cl = _clamp_inside(nx, ny, a, s)
            if cl is None:
                continue
            x, y = cl
        if rng.random() < 0.2:
            a = (a + rng.uniform(-step, step)) % 1.0
        cand[i] = [x, y, a, s]
        cc = _cost(cand)
        if cc <= curc:
            cur = cand
            curc = cc
            if cc < bestc:
                best = [list(s) for s in cand]
                bestc = cc
        else:
            step *= 0.995
    return best


def solve(n):
    # Base: best uniform grid dimension
    k = max(1, math.isqrt(n))
    # For leftover, distribute sizes among grid cells
    squares = []
    # choose grid k x k covering n slots, sizes = 1/k
    side = 1.0 / k
    cells = [(i, j) for i in range(k) for j in range(k)]
    sq = []
    used = 0
    for (i, j) in cells:
        if used >= n:
            break
        cx = (i + 0.5) * side
        cy = (j + 0.5) * side
        sq.append([cx, cy, 0.0, side])
        used += 1
    while used < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
        used += 1
    # For non perfect squares, try using fewer equal squares and one larger
    # Optimize with the local search
    best = _improve(sq, 8000)
    # Ensure fits
    res = []
    for x, y, a, s in best:
        if s <= 1e-9:
            res.append((0.5, 0.5, 0.0, 0.0))
        else:
            cl = _clamp_inside(x, y, a, s)
            if cl is None:
                res.append((0.5, 0.5, 0.0, 0.0))
            else:
                res.append((cl[0], cl[1], a % 1.0, s))
    return res[:n]
# EVOLVE-BLOCK-END
