import numpy as np
from scipy.optimize import minimize, Bounds
from scipy.spatial import distance

def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    
    # 1. Start with known good configurations for smaller n
    # Use hexagonal packing in the center region with optimal density
    if n == 26:
        # Place a good initial configuration using a hexagonal-like arrangement
        # that fills the square efficiently
        centers, radii = initial_hexagonal_fill(n)
    else:
        # General fallback: random but bounded
        centers = np.random.rand(n, 2) * 0.8 + 0.1
        radii = np.ones(n) * 0.4 / np.sqrt(n)
    
    # 2. Fine-tune: maximize sum of radii using gradient-free optimization
    # We optimize log(radii) to ensure positivity
    log_radii = np.log(np.maximum(radii, 1e-8))
    
    bounds = Bounds(lb=-20, ub=0)  # radii from 2e-9 to 1
    
    # Define constraint: all circles inside square (handled by radii bounds + centers)
    # and circle pairs non-overlapping
    constraints = []
    for i in range(n):
        for j in range(i+1, n):
            constraints.append({
                'type': 'ineq',
                'fun': lambda x, i=i, j=j: distance_constraint(x, i, j, n, centers)
            })
    
    # Also constraints: circles stay inside square
    for i in range(n):
        constraints.append({
            'type': 'ineq',
            'fun': lambda x, i=i: inside_constraint(x, i, n, centers)
        })
    
    # Objective: maximize sum of radii = minimize negative sum
    def objective(log_r):
        radii = np.exp(log_r)
        return -np.sum(radii)
    
    # Initial guess
    x0 = np.log(np.clip(radii, 1e-8, 0.5))
    
    # For computational efficiency with many constraints, use SLSQP or COBYLA
    result = minimize(objective, x0, method='SLSQP', bounds=bounds,
                      constraints=constraints, options={'maxiter': 2000, 'ftol': 1e-12})
    
    radii_opt = np.exp(result.x)
    
    return centers, radii_opt


def initial_hexagonal_fill(n):
    """Create a hexagonal-like packing of n circles in unit square."""
    # Use a grid-based approach with hexagonal packing
    
    # First, estimate how many circles per row
    cols = int(np.ceil(np.sqrt(n * np.sqrt(3) / 2)))  # hexagonal packing factor
    rows = int(np.ceil(n / cols))
    
    # Adjust to fit exactly n circles
    dx = 1.0 / (cols + 0.5)
    dy = np.sqrt(3) / 2 * dx
    
    centers = []
    count = 0
    for r in range(rows):
        offset = 0 if r % 2 == 0 else dx/2
        for c in range(cols):
            if count < n:
                x = 0.5*dx + offset + c*dx
                y = 0.5*dy + r*dy
                # Clamp to borders
                x = np.clip(x, 0.01, 0.99)
                y = np.clip(y, 0.01, 0.99)
                centers.append([x, y])
                count += 1
    
    # If we don't have enough, add random points
    while len(centers) < n:
        centers.append([0.1 + 0.8*np.random.rand(), 0.1 + 0.8*np.random.rand()])
    
    centers = np.array(centers[:n])
    
    # Compute initial radii as half the minimum distance (with boundaries)
    radii = []
    for i in range(n):
        # Distance to walls
        min_dist = min(centers[i,0], centers[i,1], 1-centers[i,0], 1-centers[i,1])
        # Distance to neighbors
        if i > 0:
            dists = np.linalg.norm(centers[:i] - centers[i], axis=1)
            min_dist = min(min_dist, np.min(dists) / 2)
        radii.append(min_dist * 0.9)  # safety factor
    
    radii = np.array(radii)
    return centers, radii


def distance_constraint(log_r, i, j, n, centers):
    """Constraint: distance(center_i, center_j) >= r_i + r_j"""
    radii = np.exp(log_r)
    d = np.linalg.norm(centers[i] - centers[j])
    return d - (radii[i] + radii[j])


def inside_constraint(log_r, i, n, centers):
    """Constraint: circle i is inside square (padding by radius)"""
    radii = np.exp(log_r)
    r = radii[i]
    x, y = centers[i]
    return min(x - r, y - r, 1 - (x + r), 1 - (y + r))
