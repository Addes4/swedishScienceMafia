import numpy as np
from scipy.optimize import minimize, NonlinearConstraint
from scipy.spatial.distance import cdist

def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of radii using interior-point NLP relaxation."""
    # Multiple restarts with different seeds to improve reliability
    seeds = list(range(10))
    best_result = None
    
    for seed in seeds:
        np.random.seed(seed if seed < 100 else seed % 100)
        centers = generate_hexagonal_initializers(n)
        result = optimize_packing(centers, n)
        total_radius = np.sum(result['radii'])
        if best_result is None or total_radius > best_result['total_radius']:
            best_result = result
    
    return best_result['centers'], best_result['radii']


def generate_hexagonal_initializers(n):
    """Return hexagonal lattice initial centers for n circles."""
    centers = []
    row_spacing = 0.80  # Vertical spacing for hex lattice
    col_spacing = 0.95  # Horizontal spacing
    shift = 0.5
    
    rows = int(np.sqrt(2 * n)) + 1
    for i in range(n * 2):
        if i >= n * 2:
            break
        row = i // 2
        col = i % 2
        if col == 1:
            centers.append([0.5 + col * 0.5 + row * col_spacing * 0.5,
                           shift + row * row_spacing])
        elif i == 0:
            centers.append([0.5, 0.5])
        elif i == 1:
            centers.append([0.5, shift])
        elif i == 2:
            centers.append([0.5 + 0.4, shift + row_spacing])
        elif i == 3:
            centers.append([0.5 - 0.4, shift + row_spacing])
        else:
            x = 0.5 + (col + 1) * 0.5
            y = shift + row * row_spacing
            if x < 0.5:
                x = 0.5 - abs(x - 0.5)
            centers.append([x, y])
    
    centers = np.array(centers)
    if len(centers) < n:
        # Pad with random points if needed
        for _ in range(n - len(centers)):
            centers.append([np.random.uniform(0.1, 0.9), np.random.uniform(0.1, 0.9)])
    centers = np.array(centers[:n])
    return centers.clip(0.1, 0.9)


def optimize_packing(initial_centers, n):
    """Solve circle packing as NLP using interior-point method."""
    n = len(initial_centers) if n == 26 else len(initial_centers)
    initial_params = np.concatenate([initial_centers, np.ones(n) * 0.3])
    
    def objective(params):
        return -np.sum(params[n*2:])
    
    # Non-overlap constraints: ri + rj <= d(i,j)
    cons = []
    distsq = cdist(initial_centers, initial_centers) ** 2
    for i in range(n):
        for j in range(i+1, n):
            d = np.sqrt(distsq[i, j])
            if d < 0.1:
                continue
            cons.append({
                'type': 'ineq',
                'fun': lambda p, i=i, j=j, d=d, idx_start=n*2: 
                    np.sqrt((p[idx_start + 2*i] - p[idx_start + 2*j])**2 +
                           (p[idx_start + 2*i + 1] - p[idx_start + 2*j + 1])**2) 
                    - (p[idx_start + 2*i + 2] + p[idx_start + 2*j + 2]) + d
            })
    
    # Bound constraints
    bounds = [(0.01, 0.99)] * (2*n) + [(1e-6, 0.5)] * n
    
    # Run optimization
    result = minimize(
        objective, initial_params, method='SLSQP',
        constraints=cons, bounds=bounds,
        options={'ftol': 1e-8, 'maxiter': 5000, 'disp': False}
    )
    
    final_params = result.x
    final_centers = final_params[:2*n].reshape(n, 2)
    final_centers = final_centers.clip(0.01, 0.99)
    final_radii = np.maximum(final_params[n*2:], 1e-6)
    
    # Enforce final validity
    final_centers = ensure_no_overlap(final_centers, final_radii, n)
    return {'centers': final_centers, 'radii': np.maximum(final_radii, 1e-6),
            'total_radius': np.sum(final_radii)}


def ensure_no_overlap(centers, radii, n):
    """Shrink radii linearly until no circles overlap."""
    max_iter = 50
    for _ in range(max_iter):
        changed = False
        for i in range(n):
            for j in range(i+1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                max_r = d / 2
                if radii[i] > max_r:
                    radii[i] = max_r
                    changed = True
                if radii[j] > max_r:
                    radii[j] = max_r
                    changed = True
        if not changed:
            break
    return centers, radii


def solve_single(n=26):
    """Solve circle packing without multiple seeding for fast retry."""
    centers = generate_hexagonal_initializers(n)
    result = optimize_packing(centers, n)
    return result['centers'], result['radii']
