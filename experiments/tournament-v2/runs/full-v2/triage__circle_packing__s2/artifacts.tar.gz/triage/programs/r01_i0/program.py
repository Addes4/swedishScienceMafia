import numpy as np
from scipy.optimize import minimize


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    # Initial layout from the baseline
    centers = [[0.5, 0.5]]
    centers += [
        [0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)]
        for i in range(8)
    ]
    centers += [
        [0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)]
        for i in range(16)
    ]
    centers += [
        [0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()]
        for _ in range(n - len(centers))
    ]
    centers = np.clip(np.array(centers[:n]), 0.01, 0.99)
    radii = max_radii(centers)

    # Optimise centers and radii jointly via gradient descent with repulsive forces
    centers, radii = _repulsive_optimisation(centers, radii, steps=200, lr=0.005)

    # Final projection to valid packing
    radii = max_radii(centers)

    return centers, radii


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce(
        [centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]]
    )
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _repulsive_optimisation(centers, radii, steps=200, lr=0.005):
    """Gradient descent minimising overlaps and wall penetrations, encouraging radius growth."""
    n = len(centers)
    for step in range(steps):
        # Compute pairwise distances and unit vectors
        diff = centers[:, np.newaxis, :] - centers[np.newaxis, :, :]  # (n, n, 2)
        dist = np.linalg.norm(diff, axis=-1)  # (n, n)
        np.fill_diagonal(dist, np.inf)  # ignore self

        # Overlap penalty: when sum of radii > distance
        overlap = radii[:, np.newaxis] + radii[np.newaxis, :] - dist
        overlap = np.maximum(overlap, 0.0)  # (n, n)

        # Unit direction from j to i for each overlap
        valid = dist > 0
        direction = np.zeros_like(diff)
        direction[valid] = diff[valid] / dist[valid][:, np.newaxis]

        # Repulsive force on centers: pushes overlapping circles apart
        force_magnitude = overlap  # (n, n)
        force = direction * force_magnitude[:, :, np.newaxis]  # (n, n, 2)
        center_grad = np.sum(force, axis=1)  # (n, 2)

        # Wall repulsion: keep centers inside [0, 1] with margin
        margin = 0.01
        wall_force = np.zeros_like(centers)
        wall_force[:, 0] -= np.maximum(margin - centers[:, 0], 0)
        wall_force[:, 0] += np.maximum(centers[:, 0] - (1 - margin), 0)
        wall_force[:, 1] -= np.maximum(margin - centers[:, 1], 0)
        wall_force[:, 1] += np.maximum(centers[:, 1] - (1 - margin), 0)

        centers = centers - lr * (center_grad + 0.5 * wall_force)
        centers = np.clip(centers, margin, 1 - margin)

        # Adjust radii: encourage growth but penalise overlaps
        overlap_per_circle = np.sum(overlap, axis=1)  # total overlap each circle
        # Wall distance penalty
        wall_dist = np.minimum.reduce(
            [centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]]
        )
        # Gradient for radii: reduce overlap penalty, increase radius up to wall limit
        radius_grad = overlap_per_circle - 0.1 * (wall_dist - radii)
        radii = radii - lr * radius_grad
        radii = np.maximum(radii, 0.001)

    return centers, radii


if __name__ == "__main__":
    c, r = solve(26)
    print("Sum of radii:", np.sum(r))
