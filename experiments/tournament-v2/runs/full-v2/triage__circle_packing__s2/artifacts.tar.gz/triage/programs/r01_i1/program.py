# EVOLVE-BLOCK-START
"""Poisson-disc style sampling with greedy maximal independent set pruning.

Strategy:
  1. Generate many candidate circles (positions + radii) in the unit square.
     Positions come from a Poisson-disc-like random sampling biased by a
     smooth size function so that circles vary in radius in a structured way.
  2. Greedily keep a maximal independent set under the condition that two
     circles may coexist only if their centres are at least (r_i + r_j)
     apart, i.e. no overlap.  We prefer larger radii by processing candidates
     in decreasing radius order and accepting a candidate only if it does not
     conflict with already accepted ones.
  3. If we end up with more than n circles, greedily drop the smallest ones
     that conflict the least / are least useful until exactly n remain.
  4. Finally polish with a local shrinking step to squeeze out overlaps that
     remain due to discrete acceptance order.
"""
import numpy as np


def _poisson_disc_candidates(n_candidates, rng):
    """Generate roughly Poisson-disc-distributed candidate points in the unit
    square, with associated tentative radii driven by a smooth size field."""
    pts = []
    # Poisson disc sampling with a small radius to spread points out.
    # Use a simple dart-throwing approach with a grid for O(1) lookups.
    cell = 0.03
    gsize = int(np.ceil(1.0 / cell))
    grid = -np.ones((gsize, gsize), dtype=int)
    base_r = 0.02
    tries = 0
    max_tries = 200 * n_candidates
    while len(pts) < n_candidates and tries < max_tries:
        tries += 1
        x, y = rng.random(), rng.random()
        gx = min(int(x / cell), gsize - 1)
        gy = min(int(y / cell), gsize - 1)
        ok = True
        for dx in (-2, -1, 0, 1, 2):
            for dy in (-2, -1, 0, 1, 2):
                nx, ny = gx + dx, gy + dy
                if 0 <= nx < gsize and 0 <= ny < gsize:
                    idx = grid[nx, ny]
                    if idx >= 0:
                        px, py = pts[idx]
                        if (px - x) ** 2 + (py - y) ** 2 < base_r ** 2:
                            ok = False
                            break
            if not ok:
                break
        if ok:
            grid[gx, gy] = len(pts)
            pts.append((x, y))
    pts = np.array(pts) if pts else np.zeros((0, 2))

    # Smooth size field: larger radii near the centre, smaller near the edges.
    if len(pts) == 0:
        return np.zeros((0, 2)), np.zeros(0)
    dx = pts[:, 0] - 0.5
    dy = pts[:, 1] - 0.5
    dist_c = np.sqrt(dx ** 2 + dy ** 2) / 0.7071
    wall = np.minimum.reduce([pts[:, 0], pts[:, 1], 1 - pts[:, 0], 1 - pts[:, 1]])
    # Radius field: blend centre preference and wall distance, plus noise.
    field = 0.5 * (1.0 - dist_c) + 0.9 * wall
    field = field + 0.02 * rng.random(len(pts))
    return pts, field


def _prune_maximal_independent(pts, radii, n_target):
    """Greedy maximal independent set: accept circles largest-radius first,
    rejecting any that overlap already accepted ones.  Then trim to n_target
    by removing the smallest accepted circles."""
    m = len(pts)
    if m == 0:
        return pts, radii
    order = np.argsort(-radii)
    accepted = []
    ax = []
    ay = []
    ar = []
    cent = pts
    for idx in order:
        x, y, r = cent[idx, 0], cent[idx, 1], radii[idx]
        conflict = False
        for ax_i, ay_i, ar_i in zip(ax, ay, ar):
            need = (r + ar_i) ** 2
            if (x - ax_i) ** 2 + (y - ay_i) ** 2 < need:
                conflict = True
                break
        if not conflict:
            ax.append(x)
            ay.append(y)
            ar.append(r)
            accepted.append(idx)
    ax = np.array(ax)
    ay = np.array(ay)
    ar = np.array(ar)
    out_pts = np.stack([ax, ay], axis=1)
    out_r = ar

    if len(out_r) > n_target:
        keep = np.argsort(-out_r)[:n_target]
        out_pts = out_pts[keep]
        out_r = out_r[keep]
    return out_pts, out_r


def _polish(pts, radii, rng, iters=200):
    """Tiny local jitter + shrinking to remove leftover overlaps."""
    n = len(pts)
    pts = pts.copy()
    radii = radii.copy()
    best_pts = pts.copy()
    best_r = radii.copy()
    best_sum = radii.sum()
    for _ in range(iters):
        # Shrink to remove overlaps exact.
        r = radii.copy()
        r = np.minimum.reduce([pts[:, 0], pts[:, 1], 1 - pts[:, 0], 1 - pts[:, 1]])
        for _ in range(30):
            changed = False
            for i in range(n):
                for j in range(i + 1, n):
                    d = np.hypot(pts[i, 0] - pts[j, 0], pts[i, 1] - pts[j, 1])
                    if r[i] + r[j] > d and r[i] + r[j] > 0:
                        scale = d / (r[i] + r[j])
                        r[i] *= scale
                        r[j] *= scale
                        changed = True
            if not changed:
                break
        s = r.sum()
        if s > best_sum:
            best_sum = s
            best_pts = pts.copy()
            best_r = r.copy()
        # Randomly jitter centres.
        step = 0.01 * (1.0 + rng.random())
        pts = pts + (rng.random((n, 2)) - 0.5) * step
        pts = np.clip(pts, 0.0, 1.0)
        radii = radii.copy()
    return best_pts, np.maximum(best_r, 0.0)


def solve(n=26):
    """Return (centers, radii) maximising the sum of radii for n circles in
    the unit square."""
    rng = np.random.default_rng(12345)
    best_centers = None
    best_radii = None
    best_sum = -1.0

    # Multiple independent attempts to escape poor local shapes.
    for attempt in range(6):
        pts, field = _poisson_disc_candidates(600, rng)
        if len(pts) == 0:
            continue
        # Radii from the smooth size field, but shrunken by wall constraint.
        wall = np.minimum.reduce([pts[:, 0], pts[:, 1], 1 - pts[:, 0], 1 - pts[:, 1]])
        radii = np.minimum(field, wall)
        radii = np.maximum(radii, 1e-4)
        c, r = _prune_maximal_independent(pts, radii, n)
        if len(r) == 0:
            continue
        # Fill up to n if too few accepted (unlikely, but be safe).
        if len(r) < n:
            # append random small circles in gaps
            extra_pts = []
            extra_r = []
            while len(r) + len(extra_r) < n:
                x, y = rng.random(2)
                rr = min(x, y, 1 - x, 1 - y)
                # shrink against existing
                for k in range(len(r)):
                    d = np.hypot(x - c[k, 0], y - c[k, 1])
                    rr = min(rr, max(d - r[k], 0.0))
                for k in range(len(extra_r)):
                    d = np.hypot(x - extra_pts[k][0], y - extra_pts[k][1])
                    rr = min(rr, max(d - extra_r[k], 0.0))
                if rr > 1e-6:
                    extra_pts.append((x, y))
                    extra_r.append(rr)
            if extra_pts:
                c = np.vstack([c, np.array(extra_pts)])
                r = np.concatenate([r, np.array(extra_r)])
        c, r = _polish(c, r, rng, iters=120)
        # Exact overlap removal.
        r = _max_radii_exact(c)
        s = r.sum()
        if s > best_sum:
            best_sum = s
            best_centers = c.copy()
            best_radii = r.copy()

    if best_centers is None:
        # Fallback: simple grid layout.
        centers = []
        radii = []
        k = int(np.ceil(np.sqrt(n)))
        for i in range(k):
            for j in range(k):
                if len(centers) < n:
                    centers.append(((i + 0.5) / k, (j + 0.5) / k))
                    radii.append(0.4 / k)
        centers = np.array(centers)
        radii = np.array(radii)
        radii = _max_radii_exact(centers)
        return centers, radii

    return best_centers, _max_radii_exact(best_centers)


def _max_radii_exact(centers):
    """Largest feasible radii for fixed centres: wall distance then pairwise shrink."""
    centers = np.asarray(centers, dtype=float)
    n = len(centers)
    radii = np.minimum.reduce(
        [centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]]
    )
    radii = np.maximum(radii, 0.0)
    for _ in range(100):
        changed = False
        for i in range(n):
            xi, yi = centers[i]
            ri = radii[i]
            for j in range(i + 1, n):
                d = np.hypot(xi - centers[j, 0], yi - centers[j, 1])
                s = radii[i] + radii[j]
                if s > d and s > 0:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END

