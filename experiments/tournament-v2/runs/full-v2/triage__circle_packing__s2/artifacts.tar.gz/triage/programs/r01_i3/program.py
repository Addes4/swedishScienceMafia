import numpy as np
import time
from scipy.spatial import cKDTree

def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    # Adaptive iteration
    for _ in range(100):
        changed = False
        # Use cKDTree to find potential overlaps efficiently
        tree = cKDTree(centers)
        pairs = tree.query_pairs(r=np.max(radii)*2, output_type='ndarray')
        for i, j in pairs:
            d = np.linalg.norm(centers[i] - centers[j])
            if radii[i] + radii[j] > d:
                scale = d / (radii[i] + radii[j])
                radii[i] *= scale
                radii[j] *= scale
                changed = True
        # Also check borders (already done by initial radii, but shrinking can violate bounds)
        radii = np.minimum(radii, np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]]))
        if not changed:
            break
    return np.maximum(radii, 0.0)


def score(centers, radii):
    return np.sum(radii)


def generate_ring(center, radius, n_circles, phase=0.0):
    """Generate a ring of n_circles around center with given radius."""
    angles = np.linspace(0, 2*np.pi, n_circles, endpoint=False) + phase
    return center + radius * np.column_stack([np.cos(angles), np.sin(angles)])


def create_initial_population(pop_size, n):
    """Create diverse initial layouts."""
    pop_centers = []
    pop_radii = []
    templates = []
    
    # Template 1: Center + 2 rings
    centers = [[0.5, 0.5]]
    centers += generate_ring(np.array([0.5, 0.5]), 0.3, 8).tolist()
    needed = n - len(centers)
    if needed > 0:
        centers += generate_ring(np.array([0.5, 0.5]), 0.65, min(needed, 16)).tolist()
    remaining = n - len(centers)
    if remaining > 0:
        centers += [[0.1 + 0.8*np.random.rand(), 0.1 + 0.8*np.random.rand()] for _ in range(remaining)]
    templates.append(np.array(centers[:n]))
    
    # Template 2: Hexagonal-like packing with random perturbation
    n_cols = int(np.ceil(np.sqrt(n)))
    xs = np.linspace(0.1, 0.9, n_cols)
    ys = np.linspace(0.1, 0.9, n_cols)
    grid = np.array([[x, y] for x in xs for y in ys])
    templates.append(grid[:n] + np.random.randn(*grid[:n].shape)*0.02)
    
    # Template 3: Random uniform
    templates.append(np.random.rand(n, 2) * 0.8 + 0.1)
    
    # Template 4: Clustered rings
    n_clusters = max(2, n // 8)
    cluster_centers = np.random.rand(n_clusters, 2) * 0.6 + 0.2
    centers = []
    for i in range(n):
        cl = i % n_clusters
        offset = (np.random.rand(2) - 0.5) * 0.3
        centers.append(cluster_centers[cl] + offset)
    templates.append(np.clip(np.array(centers), 0.01, 0.99))
    
    for template in templates[:min(pop_size, len(templates))]:
        cent = np.clip(template, 0.001, 0.999)
        pop_centers.append(cent)
        pop_radii.append(max_radii(cent))
    
    # Fill remaining with random perturbations of templates
    while len(pop_centers) < pop_size:
        base = templates[np.random.randint(len(templates))].copy()
        perturbation = np.random.randn(*base.shape) * 0.05
        cent = np.clip(base + perturbation, 0.001, 0.999)
        pop_centers.append(cent)
        pop_radii.append(max_radii(cent))
    
    return pop_centers, pop_radii


def cluster_circles(centers, radii, n_clusters):
    """Cluster circles based on spatial proximity."""
    from scipy.cluster.vq import kmeans2
    if n_clusters >= len(centers):
        return [list(range(len(centers)))]
    centroids, labels = kmeans2(centers, n_clusters, minit='points')
    clusters = [[] for _ in range(n_clusters)]
    for i, label in enumerate(labels):
        clusters[label].append(i)
    return clusters


def cluster_by_rings(centers, radii):
    """Cluster circles by distance from center, separating rings."""
    if len(centers) <= 5:
        return [list(range(len(centers)))]
    center_mass = np.mean(centers, axis=0)
    dists = np.linalg.norm(centers - center_mass, axis=1)
    sorted_idx = np.argsort(dists)
    # Split into rings of roughly equal size
    n_rings = max(2, int(np.sqrt(len(centers))))
    ring_size = len(centers) // n_rings
    clusters = []
    for i in range(n_rings):
        start = i * ring_size
        end = (i + 1) * ring_size if i < n_rings - 1 else len(centers)
        clusters.append(sorted_idx[start:end].tolist())
    return clusters


def crossover_rings(parent1_centers, parent2_centers, parent1_radii, parent2_radii):
    """Crossover by swapping whole rings between parents."""
    # Cluster both parents into rings
    clusters1 = cluster_by_rings(parent1_centers, parent1_radii)
    clusters2 = cluster_by_rings(parent2_centers, parent2_radii)
    
    # Randomly select clusters to swap
    child_centers = parent1_centers.copy()
    child_radii = parent1_radii.copy()
    
    for i in range(min(len(clusters1), len(clusters2))):
        if np.random.rand() < 0.5:  # Randomly swap each ring
            # Ensure the child has the same number of circles
            idx1 = clusters1[i]
            idx2 = clusters2[i % len(clusters2)]
            if len(idx1) == len(idx2):
                child_centers[idx1] = parent2_centers[idx2]
                child_radii[idx1] = parent2_radii[idx2]
    
    return child_centers, child_radii


def crossover_cluster(parent1_centers, parent2_centers, parent1_radii, parent2_radii):
    """Crossover by swapping spatial clusters."""
    n = len(parent1_centers)
    n_clusters = max(2, n // 5)
    clusters1 = cluster_circles(parent1_centers, parent1_radii, n_clusters)
    clusters2 = cluster_circles(parent2_centers, parent2_radii, n_clusters)
    
    child_centers = parent1_centers.copy()
    child_radii = parent1_radii.copy()
    
    # Randomly swap clusters
    swap_prob = 0.5
    for i in range(min(len(clusters1), len(clusters2))):
        if np.random.rand() < swap_prob:
            idx1 = clusters1[i]
            # Find a cluster in parent2 of similar size
            sizes2 = [len(c) for c in clusters2]
            best_match = np.argmin(np.abs(np.array(sizes2) - len(idx1)))
            idx2 = clusters2[best_match]
            if len(idx1) == len(idx2):
                child_centers[idx1] = parent2_centers[idx2]
                child_radii[idx1] = parent2_radii[idx2]
    
    return child_centers, child_radii


def mutate(centers, radii, mutation_rate=0.1):
    """Apply mutations: move circles, adjust radii, then run overlap shrink."""
    n = len(centers)
    new_centers = centers.copy()
    
    for i in range(n):
        if np.random.rand() < mutation_rate:
            # Random perturbation
            perturbation = np.random.randn(2) * 0.02
            new_centers[i] += perturbation
            new_centers[i] = np.clip(new_centers[i], 0.001, 0.999)
    
    # Sometimes perform a ring rotation mutation
    if np.random.rand() < 0.2:
        clusters = cluster_by_rings(new_centers, radii)
        for cluster in clusters:
            if len(cluster) >= 4 and np.random.rand() < 0.3:
                # Rotate positions in the ring
                idx = cluster
                perm = np.random.permutation(len(idx))
                new_centers[idx] = new_centers[idx][perm]
    
    new_radii = max_radii(new_centers)
    return new_centers, new_radii


def local_improvement(centers):
    """Intensive local search to maximize radii sum given positions."""
    radii = max_radii(centers)
    best_score = score(centers, radii)
    best_centers = centers.copy()
    best_radii = radii.copy()
    
    # Try small perturbations of each circle
    n = len(centers)
    for _ in range(5):  # Multiple passes
        improved = False
        for i in range(n):
            original = centers[i].copy()
            # Try moving in random directions
            for _ in range(3):
                direction = np.random.randn(2)
                direction /= np.linalg.norm(direction)
                step = 0.01 * (1 + np.random.rand())
                new_pos = original + direction * step
                new_pos = np.clip(new_pos, 0.001, 0.999)
                centers[i] = new_pos
                new_radii = max_radii(centers)
                new_score = score(centers, new_radii)
                if new_score > best_score:
                    best_score = new_score
                    best_centers = centers.copy()
                    best_radii = new_radii.copy()
                    improved = True
            centers[i] = original  # Restore
    
    return best_centers, best_radii


def solve(n=26):
    """Memetic algorithm for circle packing."""
    start_time = time.time()
    time_limit = 295  # seconds, leave margin
    
    pop_size = 30
    elite_size = 5
    pool_size = pop_size * 2
    
    pop_centers, pop_radii = create_initial_population(pop_size, n)
    
    # Evaluate initial population
    scores = [score(c, r) for c, r in zip(pop_centers, pop_radii)]
    
    generation = 0
    no_improvement = 0
    best_score_overall = max(scores)
    
    while time.time() - start_time < time_limit:
        generation += 1
        
        # Create offspring pool
        offspring_centers = []
        offspring_radii = []
        
        # Elite preservation
        sorted_indices = np.argsort(scores)[::-1]
        for idx in sorted_indices[:elite_size]:
            offspring_centers.append(pop_centers[idx].copy())
            offspring_radii.append(pop_radii[idx].copy())
        
        # Generate offspring through crossover and mutation
        while len(offspring_centers) < pool_size:
            # Tournament selection
            t1, t2 = np.random.choice(len(pop_centers), 2, replace=False)
            if scores[t1] > scores[t2]:
                p1_c, p1_r = pop_centers[t1].copy(), pop_radii[t1].copy()
            else:
                p1_c, p1_r = pop_centers[t2].copy(), pop_radii[t2].copy()
                
            t3, t4 = np.random.choice(len(pop_centers), 2, replace=False)
            if scores[t3] > scores[t4]:
                p2_c, p2_r = pop_centers[t3].copy(), pop_radii[t3].copy()
            else:
                p2_c, p2_r = pop_centers[t4].copy(), pop_radii[t4].copy()
            
            # Choose crossover type
            if np.random.rand() < 0.5:
                child_c, child_r = crossover_rings(p1_c, p2_c, p1_r, p2_r)
            else:
                child_c, child_r = crossover_cluster(p1_c, p2_c, p1_r, p2_r)
            
            # Mutation
            mutation_rate = 0.1 + 0.2 * np.random.rand()  # Adaptive mutation
            child_c, child_r = mutate(child_c, child_r, mutation_rate)
            
            offspring_centers.append(child_c)
            offspring_radii.append(child_r)
        
        # Apply local improvement to some offspring
        for i in range(len(offspring_centers)):
            if np.random.rand() < 0.2:
                offspring_centers[i], offspring_radii[i] = local_improvement(offspring_centers[i])
        
        # Evaluate offspring
        offspring_scores = [score(c, r) for c, r in zip(offspring_centers, offspring_radii)]
        
        # Select next generation
        combined_scores = scores + offspring_scores
        combined_centers = pop_centers + offspring_centers
        combined_radii = pop_radii + offspring_radii
        
        sorted_indices = np.argsort(combined_scores)[::-1]
        
        pop_centers = [combined_centers[i].copy() for i in sorted_indices[:pop_size]]
        pop_radii = [combined_radii[i].copy() for i in sorted_indices[:pop_size]]
        scores = [combined_scores[i] for i in sorted_indices[:pop_size]]
        
        # Check improvement
        current_best = scores[0]
        if current_best > best_score_overall:
            best_score_overall = current_best
            no_improvement = 0
        else:
            no_improvement += 1
        
        # Restart if stuck
        if no_improvement > 50:
            # Keep best solution, reinitialize rest
            new_centers, new_radii = create_initial_population(pop_size - 1, n)
            pop_centers = [pop_centers[0].copy()] + new_centers
            pop_radii = [pop_radii[0].copy()] + new_radii
            scores = [score(c, r) for c, r in zip(pop_centers, pop_radii)]
            no_improvement = 0
        
        # Adaptive population size refinement
        if generation % 100 == 0:
            # Intensify search around best
            best_c = pop_centers[0].copy()
            best_r = pop_radii[0].copy()
            improved_c, improved_r = local_improvement(best_c)
            if score(improved_c, improved_r) > scores[0]:
                pop_centers[0] = improved_c
                pop_radii[0] = improved_r
                scores[0] = score(improved_c, improved_r)
    
    # Final intensive local search on best solution
    best_idx = np.argmax(scores)
    best_c = pop_centers[best_idx]
    best_c, best_r = local_improvement(best_c)
    
    # Ensure non-negative radii
    best_r = np.maximum(best_r, 0.0)
    
    return best_c, best_r
