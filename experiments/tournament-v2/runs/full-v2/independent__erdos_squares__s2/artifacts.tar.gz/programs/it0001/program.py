import math
import random
import time
from itertools import combinations

# ---------- geometry ----------

def corners(cx, cy, ang, s):
    """Return the 4 corners of a square with centre (cx,cy), angle fraction of turn, side s."""
    a = ang * 2.0 * math.pi
    c, si = math.cos(a), math.sin(a)
    h = s * 0.5
    return (
        (cx + c * h - si * h, cy + si * h + c * h),
        (cx - c * h - si * h, cy - si * h + c * h),
        (cx - c * h + si * h, cy - si * h - c * h),
        (cx + c * h + si * h, cy + si * h - c * h),
    )


def _proj(poly, ax):
    ax, ay = ax
    vals = [px * ax + py * ay for px, py in poly]
    return min(vals), max(vals)


def overlap(p1, p2):
    """Separating-axis test for convex polygons.  True iff interiors overlap (or touch improperly)."""
    for poly in (p1, p2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ax = (-(y2 - y1), x2 - x1)
            n = math.hypot(*ax)
            if n < 1e-15:
                continue
            ax = (ax[0] / n, ax[1] / n)
            lo1, hi1 = _proj(p1, ax)
            lo2, hi2 = _proj(p2, ax)
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return False
    return True


def inside_unit(poly, eps=1e-9):
    for x, y in poly:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def valid(sq):
    """sq: list of (cx,cy,ang,s)."""
    polys = [corners(*q) for q in sq]
    for i, p in enumerate(polys):
        if not inside_unit(p):
            return False
    for i, j in combinations(range(len(sq)), 2):
        if overlap(polys[i], polys[j]):
            return False
    return True


def total(sq):
    return sum(q[3] for q in sq)


# ---------- construction ----------

def grid(n, k):
    """k x k grid of equal squares; if n<k^2 the surplus are points."""
    s = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
            else:
                out.append((0.5, 0.5, 0.0, 0.0))
    return out


def guillotine(n):
    """Recursive guillotine split: alternately split rectangle horizontally/vertically."""
    squares = []

    def rec(x, y, w, h, cnt, depth):
        if cnt <= 0:
            return
        if cnt == 1:
            s = min(w, h)
            squares.append((x + w * 0.5, y + h * 0.5, 0.0, s))
            return
        # split count roughly proportional to area, but keep it simple: half/half
        c1 = cnt // 2
        c2 = cnt - c1
        if w >= h:
            # vertical cut
            frac = c1 / cnt
            w1 = w * frac
            rec(x, y, w1, h, c1, depth + 1)
            rec(x + w1, y, w - w1, h, c2, depth + 1)
        else:
            frac = c1 / cnt
            h1 = h * frac
            rec(x, y, w, h1, c1, depth + 1)
            rec(x, y + h1, w, h - h1, c2, depth + 1)

    rec(0.0, 0.0, 1.0, 1.0, n, 0)
    return squares


def best_initial(n):
    """Try several simple layouts and pick the best valid one."""
    cands = []
    k = max(1, int(math.isqrt(n)))
    for kk in (k, k + 1):
        cands.append(grid(n, kk))
    cands.append(guillotine(n))
    best = None
    bestval = -1.0
    for c in cands:
        if len(c) < n:
            c = c + [(0.5, 0.5, 0.0, 0.0)] * (n - len(c))
        if len(c) > n:
            c = c[:n]
        if valid(c):
            v = total(c)
            if v > bestval:
                bestval = v
                best = c
    if best is None:
        s = 1.0 / max(1, k)
        best = grid(n, k)
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))
        best = best[:n]
    return best[:n]


# ---------- local search ----------

def perturb(sq, rng):
    i = rng.randrange(len(sq))
    cx, cy, ang, s = sq[i]
    mode = rng.random()
    if mode < 0.45:
        # resize
        ds = rng.gauss(0.0, 0.08 * (s + 0.03))
        s = max(0.0, s + ds)
    elif mode < 0.70:
        # recentre
        dx = rng.gauss(0.0, 0.05)
        dy = rng.gauss(0.0, 0.05)
        return (cx + dx, cy + dy, ang, s), i
    elif mode < 0.90:
        # rotate
        da = rng.gauss(0.0, 0.08)
        ang = (ang + da) % 1.0
    else:
        # shift + resize
        cx += rng.gauss(0.0, 0.03)
        cy += rng.gauss(0.0, 0.03)
        s = max(0.0, s + rng.gauss(0.0, 0.04 * (s + 0.03)))
    return (cx % 1.0 if False else cx, cy, ang, s), i


def clamp_to_unit(cx, cy, ang, s):
    """Shrink s and clamp centre so the square lies inside the unit square."""
    if s <= 0.0:
        return (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), ang, 0.0)
    for _ in range(24):
        poly = corners(cx, cy, ang, s)
        minx = min(p[0] for p in poly)
        maxx = max(p[0] for p in poly)
        miny = min(p[1] for p in poly)
        maxy = max(p[1] for p in poly)
        # shift back in
        if minx < 0.0:
            cx -= minx
        if miny < 0.0:
            cy -= miny
        if maxx > 1.0:
            cx -= (maxx - 1.0)
        if maxy > 1.0:
            cy -= (maxy - 1.0)
        poly = corners(cx, cy, ang, s)
        minx = min(p[0] for p in poly)
        maxx = max(p[0] for p in poly)
        miny = min(p[1] for p in poly)
        maxy = max(p[1] for p in poly)
        over = max(0.0, maxx - 1.0, -minx, maxy - 1.0, -miny)
        if over <= 1e-12:
            break
        # shrink
        shrink = max(0.0, min(1.0, 1.0 - over / max(s, 1e-9)))
        s *= shrink
        if s <= 0.0:
            s = 0.0
            break
    cx = min(max(cx, 0.0), 1.0)
    cy = min(max(cy, 0.0), 1.0)
    return (cx, cy, ang, s)


def anneal(n, time_limit=55.0, seed=12345):
    rng = random.Random(seed)
    cur = best_initial(n)
    curval = total(cur)
    best = [tuple(q) for q in cur]
    bestval = curval

    start = time.time()
    # allocate budget
    it = 0
    temp0 = 0.08
    temp1 = 0.0005
    while True:
        el = time.time() - start
        if el > time_limit:
            break
        frac = el / time_limit
        T = temp0 * (temp1 / temp0) ** frac

        new_sq, i = perturb(cur, rng)
        new_sq = clamp_to_unit(*new_sq)
        trial = [tuple(q) for q in cur]
        trial[i] = new_sq

        # check validity: only need to test square i vs the rest, plus inside unit
        ok = True
        for q in trial:
            if q[3] < -1e-12:
                ok = False
                break
        if ok:
            poly_i = corners(*trial[i])
            if not inside_unit(poly_i):
                ok = False
            else:
                for j in range(n):
                    if j == i:
                        continue
                    if overlap(poly_i, corners(*trial[j])):
                        ok = False
                        break

        if ok:
            oldsum = sum(q[3] for q in cur)
            newsum = sum(q[3] for q in trial)
            gain = newsum - oldsum
            if gain >= 0.0 or rng.random() < math.exp(gain / max(T, 1e-12)):
                cur = trial
                curval = newsum
                if newsum > bestval:
                    bestval = newsum
                    best = [tuple(q) for q in cur]
        it += 1
        # occasionally do a deterministic "grow attempt" on a random square
        if it % 90 == 0:
            # try to enlarge each square a bit
            improved = False
            order = list(range(n))
            rng.shuffle(order)
            for idx in order:
                cx, cy, ang, s = cur[idx]
                grow = s + max(1e-4, 0.02 * (1.0 + s))
                cand = clamp_to_unit(cx, cy, ang, grow)
                poly_c = corners(*cand)
                bad = not inside_unit(poly_c)
                if not bad:
                    for j in range(n):
                        if j == idx:
                            continue
                        if overlap(poly_c, corners(*cur[j])):
                            bad = True
                            break
                if not bad:
                    cur[idx] = cand
                    curval = sum(q[3] for q in cur)
                    improved = True
                    if curval > bestval:
                        bestval = curval
                        best = [tuple(q) for q in cur]
            if improved:
                pass
    return [tuple(q) for q in best]


def polish(n, sq, time_limit, seed):
    """Deterministic hill-climb: repeatedly try to grow squares; then fine recentre."""
    rng = random.Random(seed)
    cur = [tuple(q) for q in sq]
    end = time.time() + time_limit
    improved = True
    while improved and time.time() < end:
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for idx in order:
            if time.time() > end:
                break
            cx, cy, ang, s = cur[idx]
            # try increasing side in binary steps until fail, then bisect
            lo = s
            hi = s + 0.2
            # ensure hi fails
            bad_hi = True
            cand_hi = clamp_to_unit(cx, cy, ang, hi)
            poly_hi = corners(*cand_hi)
            if inside_unit(poly_hi):
                bad_hi = False
                for j in range(n):
                    if j == idx:
                        continue
                    if overlap(poly_hi, corners(*cur[j])):
                        bad_hi = True
                        break
            if not bad_hi:
                # can grow a lot
                lo = cand_hi[3]
            else:
                for _ in range(18):
                    mid = 0.5 * (lo + hi)
                    cand = clamp_to_unit(cx, cy, ang, mid)
                    poly_c = corners(*cand)
                    bad = not inside_unit(poly_c)
                    if not bad:
                        for j in range(n):
                            if j == idx:
                                continue
                            if overlap(poly_c, corners(*cur[j])):
                                bad = True
                                break
                    if bad:
                        hi = mid
                    else:
                        lo = mid
            if lo > s + 1e-12:
                cand = clamp_to_unit(cx, cy, ang, lo)
                cur[idx] = cand
                improved = True
        # fine position adjustments
        for _ in range(n):
            if time.time() > end:
                break
            idx = rng.randrange(n)
            cx, cy, ang, s = cur[idx]
            bestpos = (cx, cy)
            bests = s
            for dx in (-0.02, -0.01, 0.0, 0.01, 0.02):
                for dy in (-0.02, -0.01, 0.0, 0.01, 0.02):
                    cand = clamp_to_unit(cx + dx, cy + dy, ang, s)
                    poly_c = corners(*cand)
                    if not inside_unit(poly_c):
                        continue
                    bad = False
                    for j in range(n):
                        if j == idx:
                            continue
                        if overlap(poly_c, corners(*cur[j])):
                            bad = True
                            break
                    if not bad:
                        ns = cand[3]
                        if ns > bests + 1e-12:
                            bests = ns
                            bestpos = (cand[0], cand[1])
            if bests > s + 1e-12:
                cand = clamp_to_unit(bestpos[0], bestpos[1], ang, bests)
                cur[idx] = cand
                improved = True
    return cur


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    total_budget = 57.0
    t0 = time.time()
    seeds = [1, 2, 3, 4, 5, 6]
    best = None
    bestval = -1.0
    # split budget among restarts
    for si, sd in enumerate(seeds):
        elapsed = time.time() - t0
        left = total_budget - elapsed
        if left <= 0.5:
            break
        remain = len(seeds) - si
        budget = left / remain
        # anneal
        sq = anneal(n, time_limit=max(1.0, budget * 0.75), seed=sd * 101 + n)
        # polish
        sq2 = polish(n, sq, time_limit=max(1.0, budget * 0.25), seed=sd * 37 + n)
        v = total(sq2)
        if not valid(sq2):
            # fall back to safer previous
            if v > total(sq):
                v = total(sq)
                sq2 = sq
        if v > bestval:
            bestval = v
            best = sq2
        if time.time() - t0 > total_budget - 0.5:
            break
    if best is None:
        best = best_initial(n)
    # safety: if invalid (should not happen), fall back
    if not valid(best):
        best = best_initial(n)
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))
        best = best[:n]
    # ensure all numbers in [0,1]
    out = []
    for cx, cy, ang, s in best[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, ang, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
