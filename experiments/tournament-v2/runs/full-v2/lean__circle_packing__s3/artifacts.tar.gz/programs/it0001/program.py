# EVOLVE-BLOCK-START
"""Circle packing via direct constrained optimisation with scipy (SLSQP)."""
import numpy as np
from scipy.optimize import minimize


def _initial_centers(n):
    """A slightly perturbed grid/hexagonal seed inside the square."""
    pts = []
    k = 0
    rows = int(np.ceil(np.sqrt(n)))
    for i in range(rows):
        for j in range(rows):
            if len(pts) >= n:
                break
            x = 0.5 + (j + 0.5 * (i % 2)) / rows - 0.5 / rows
            y = 0.5 + (i + 0.5) / rows - 0.5 / rows
            pts.append([x, y])
    pts = np.array(pts[:n])
    return np.clip(pts, 0.05, 0.95)


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square."""
    rng = np.random.default_rng(12345)

    best_sum = -1.0
    best_centers = None
    best_radii = None

    # variable vector: [x0..x_{n-1}, y0..y_{n-1}, r0..r_{n-1}]
    nvars = 3 * n

    def unpack(v):
        c = v[: 2 * n].reshape(n, 2)
        r = v[2 * n:]
        return c, r

    def neg_sum(v):
        return -np.sum(v[2 * n:])

    def neg_sum_grad(v):
        g = np.zeros(nvars)
        g[2 * n:] = -1.0
        return g

    # build constraints: boundary (r - wall <= 0) and pairwise (ri+rj - dist <= 0)
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

    def make_cons():
        cons = []
        for i in range(n):
            cons.append({"type": "ineq", "fun": (lambda v, i=i: v[: 2 * n].reshape(n, 2)[i, 0] - v[2 * n + i])})
            cons.append({"type": "ineq", "fun": (lambda v, i=i: 1 - v[: 2 * n].reshape(n, 2)[i, 0] - v[2 * n + i])})
            cons.append({"type": "ineq", "fun": (lambda v, i=i: v[: 2 * n].reshape(n, 2)[i, 1] - v[2 * n + i])})
            cons.append({"type": "ineq", "fun": (lambda v, i=i: 1 - v[: 2 * n].reshape(n, 2)[i, 1] - v[2 * n + i])})
        for (i, j) in pairs:
            cons.append({"type": "ineq", "fun": (lambda v, i=i, j=j: (
                np.linalg.norm(v[: 2 * n].reshape(n, 2)[i] - v[: 2 * n].reshape(n, 2)[j])
                - v[2 * n + i] - v[2 * n + j]))})
        return cons

    cons = make_cons()

    n_restarts = 12
    for trial in range(n_restarts):
        if trial == 0:
            centers = _initial_centers(n)
        else:
            centers = _initial_centers(n) + rng.uniform(-0.08, 0.08, size=(n, 2))
            centers = np.clip(centers, 0.05, 0.95)

        # feasible-ish initial radii: small equal radii
        radii = np.full(n, 0.03)
        v0 = np.concatenate([centers.ravel(), radii])

        bnds = [(0.01, 0.99)] * (2 * n) + [(0.0, 0.5)] * n
        try:
            res = minimize(neg_sum, v0, jac=neg_sum_grad, bounds=bnds,
                           constraints=cons, method="SLSQP",
                           options={"maxiter": 400, "ftol": 1e-12})
        except Exception:
            continue

        c, r = unpack(res.x)
        r = np.maximum(r, 0.0)
        # repair any tiny constraint violations by shrinking
        r = _repair(c, r)
        s = float(np.sum(r))
        if s > best_sum:
            best_sum = s
            best_centers = c.copy()
            best_radii = r.copy()

    if best_centers is None:
        c = _initial_centers(n)
        return c, max_radii(c)

    return best_centers, best_radii


def _repair(centers, radii):
    """Shrink radii slightly to remove residual overlaps."""
    n = len(centers)
    radii = np.maximum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1],
                               radii])
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d + 1e-12:
                    excess = radii[i] + radii[j] - d
                    radii[i] -= excess / 2
                    radii[j] -= excess / 2
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def max_radii(centers):
    """Largest radii for fixed centres: wall distance then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END

