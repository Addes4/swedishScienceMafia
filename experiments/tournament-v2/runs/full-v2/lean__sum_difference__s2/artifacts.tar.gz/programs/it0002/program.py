# EVOLVE-BLOCK-START
"""Construct A = (dense AP core) U (geometric tail), maximizing |A-A| / |A+A|.

Idea: sums within the AP core collide heavily (small sum set), while the
geometric tail (powers of 2) keeps differences nearly all distinct.  We
grid-search a few structural parameters and locally polish.
"""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            s = ai + a[j]
            sums.add(s)
            d = ai - a[j]
            diffs.add(d)
            diffs.add(-d)
    return (math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100,
            len(diffs), len(sums))


def _build(k, m, gap, offset):
    """AP core of m terms with step `gap`, plus powers of 2 tail of length k."""
    core = [offset + gap * i for i in range(m)]
    # shift tail far away to avoid accidental collisions
    base = offset + gap * m + max(1, gap)
    tail = [base + (1 << t) for t in range(k)]
    a = sorted(set(core + tail))
    return a


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 110

    # coarse structural search
    for k in range(6, 26):
        for m in range(1, 40):
            for gap in (1, 2, 3, 5, 8, 13, 21, 34):
                a = _build(k, m, gap, 0)
                s, _, _ = _stats(a)
                if s > best_score:
                    best_score, best = s, a[:]

    # local polish: tweak tail exponents / core step
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice((-2, -1, 1, 2, 3, -3))
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s, _, _ = _stats(cand)
        if s >= best_score:
            best_score, best, cur = s, cand[:], cand
        elif random.random() < 0.15:
            cur = best[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END

