# EVOLVE-BLOCK-START
"""Structured construction + local search for large difference set and small sum set."""
import math
import random
import time


def _stats(a):
    vals = list(a)
    n = len(vals)
    if n < 2:
        return 0, 0
    aa = set(vals)
    diffs = set()
    sums = set()
    for x in vals:
        for y in vals:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score(a):
    s = set(a)
    if len(s) < 2:
        return 0.0
    d, sm = _stats(s)
    if sm < 1 or d < 1:
        return 0.0
    return math.log(d) / math.log(sm) + (1 - 1 / len(s)) / 100


def _construct():
    """Dense arithmetic block (many colliding sums) + geometric tail (many distinct diffs)."""
    A = []
    # Dense block: an arithmetic progression so sums collide heavily.
    base = 1000
    step = 1
    m = 40
    for i in range(m):
        A.append(base + i * step)
    # Geometric tail with large ratio: differences mostly new.
    v = base + m * step + 5000
    r = 3
    for _ in range(18):
        A.append(v)
        v *= r
        if abs(v) > 10**14:
            break
    return A


def solve():
    best = _construct()
    best_score = _score(best)
    cur = best[:]
    deadline = time.time() + 110
    rng = random.Random(12345)

    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.5 and cand:
            # perturb an existing element
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-2, 2)
        elif op < 0.75:
            # insert a small random integer near the dense block
            cand.append(rng.randint(900, 1200))
        elif len(cand) > 3:
            # drop an element
            del cand[rng.randrange(len(cand))]

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if max(abs(x) for x in cand) > 10**15:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif rng.random() < 0.05:
            cur = cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
