# EVOLVE-BLOCK-START
"""Structured two-phase search for sets with large |A-A| and small |A+A|.

Architecture:
  - scoring utilities (_diff_sum_counts, _score)
  - construction phase (greedy Sidon/Golomb-like seeding)
  - refinement phase (incremental local search)
  - driver (solve) that restarts under a deadline and returns the best set.
"""
import math
import random
import time
from collections import Counter


# ---------------------------------------------------------------------------
# Scoring layer
# ---------------------------------------------------------------------------
def _diff_sum_counts(a):
    """Return (|A - A|, |A + A|) using sets."""
    a = list(a)
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    d, s = _diff_sum_counts(a)
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


# ---------------------------------------------------------------------------
# Construction layer
# ---------------------------------------------------------------------------
def _greedy_construct(rng, target_size, pool):
    """Greedy: start from a small seed, repeatedly add the pool element that
    maximises the score of the enlarged set.  This tends to produce
    Sidon-like sets with rich difference structure and sparse sums."""
    seed = rng.sample(pool, 3)
    A = list(seed)
    while len(A) < target_size:
        best_elem = None
        best_s = -1.0
        # Sample a subset of the pool for speed on large pools.
        candidates = pool if len(pool) <= 200 else rng.sample(pool, 200)
        for x in candidates:
            if x in A:
                continue
            trial = A + [x]
            s = _score(trial)
            if s > best_s:
                best_s = s
                best_elem = x
        if best_elem is None:
            break
        A.append(best_elem)
    return A


def _seed_variants():
    """A few hand-picked structured seeds known to score well."""
    return [
        [7, 15, 18, 22, -3, -2],
        [0, 1, 4, 9, 15, 22, 32],
        [0, 1, 3, 7, 12, 20, 30, 44],
        [1, 2, 5, 10, 17, 26, 37, 50],
        [0, 1, 4, 10, 18, 27, 40, 56],
    ]


# ---------------------------------------------------------------------------
# Refinement layer (incremental local search)
# ---------------------------------------------------------------------------
def _diff_counter(a):
    c = Counter()
    for x in a:
        for y in a:
            c[x - y] += 1
    return c


def _sum_counter(a):
    c = Counter()
    for x in a:
        for y in a:
            c[x + y] += 1
    return c


def _score_from_counters(dc, sc, n):
    if n < 2 or len(sc) <= 1:
        return 0.0
    return math.log(len(dc)) / math.log(len(sc)) + (1 - 1 / n) / 100


def _refine(A, rng, deadline, step_scale):
    """Local search: perturb one element at a time, accept non-worsening moves,
    occasionally restart from the current best.  Uses incremental counters."""
    A = list(set(A))
    dc = _diff_counter(A)
    sc = _sum_counter(A)
    best = A[:]
    best_score = _score_from_counters(dc, sc, len(A))
    cur = A[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        i = rng.randrange(len(cand))
        cand[i] += rng.randint(-step_scale, step_scale)
        cand = list(set(cand))
        if len(cand) < 2:
            continue

        # Incremental-ish evaluation: only recompute if set changed.
        d, s = _diff_sum_counts(cand)
        if s <= 1:
            continue
        sc_val = math.log(d) / math.log(s) + (1 - 1 / len(cand)) / 100

        if sc_val >= best_score:
            best, best_score, cur, cur_score = cand[:], sc_val, cand, sc_val
            dc = _diff_counter(cand)
            sc = _sum_counter(cand)
        elif sc_val > cur_score - 0.02:
            cur, cur_score = cand, sc_val
        elif rng.random() < 0.1:
            cur, cur_score = best[:], best_score

        # Occasionally try adding/removing an element.
        r = rng.random()
        if r < 0.04:
            cand2 = cur + [rng.randint(-40, 40)]
            cand2 = list(set(cand2))
            s2 = _score(cand2)
            if s2 >= best_score:
                best, best_score, cur, cur_score = cand2[:], s2, cand2, s2
        elif r < 0.06 and len(cur) > 4:
            j = rng.randrange(len(cur))
            cand2 = cur[:j] + cur[j + 1:]
            s2 = _score(cand2)
            if s2 >= best_score:
                best, best_score, cur, cur_score = cand2[:], s2, cand2, s2

    return best, best_score


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------
def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A|
    small: maximise log|A - A| / log|A + A|."""
    rng = random.Random(12345)
    deadline = time.time() + 100

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Phase 1: try structured seeds and greedy constructions.
    pool_base = list(range(-60, 61))
    for seed in _seed_variants():
        if time.time() > deadline:
            break
        s = _score(seed)
        if s > best_score:
            best, best_score = seed[:], s

    while time.time() < deadline * 0.5:
        target = rng.randint(5, 10)
        pool = rng.sample(pool_base, min(len(pool_base), 60))
        cand = _greedy_construct(rng, target, pool)
        s = _score(cand)
        if s > best_score:
            best, best_score = cand[:], s

    # Phase 2: refine from the best-known seeds with restarts.
    step_scales = [1, 2, 3, 5]
    while time.time() < deadline:
        start = best[:]
        if rng.random() < 0.5:
            # Perturb a bit before refining to escape the current basin.
            start = list(set(start + [rng.randint(-30, 30) for _ in range(2)]))
        scale = rng.choice(step_scales)
        cand, s = _refine(start, rng, min(deadline, time.time() + 8), scale)
        if s > best_score:
            best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END