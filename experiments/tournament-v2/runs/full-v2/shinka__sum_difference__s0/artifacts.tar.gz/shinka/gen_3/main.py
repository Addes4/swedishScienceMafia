# EVOLVE-BLOCK-START
"""Structured two-phase search for sets with large |A-A| and small |A+A|.

Architecture:
  - scoring utilities (_diff_sum_counts, _score)
  - construction phase (greedy Sidon/Golomb-like seeding)
  - refinement phase (incremental local search)
  - driver (solve) that restarts under a deadline and returns the best set.
"""
import math
import random
import time
from collections import Counter


# ---------------------------------------------------------------------------
# Scoring layer
# ---------------------------------------------------------------------------
def _diff_sum_counts(a):
    """Return (|A - A|, |A + A|) using sets."""
    a = list(a)
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    d, s = _diff_sum_counts(a)
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


# ---------------------------------------------------------------------------
# Construction layer
# ---------------------------------------------------------------------------
def _delta_gain(A, x):
    """Marginal gain of adding x to A: new differences created minus new sums
    created.  Used to greedily grow sets that favor differences over sums."""
    diffs = set()
    sums = set()
    for a in A:
        diffs.add(a - x)
        diffs.add(x - a)
        sums.add(a + x)
    new_d = 0
    new_s = 0
    for a in A:
        for b in A:
            diffs.add(a - b)
            sums.add(a + b)
    return new_d, new_s


def _greedy_construct(rng, target_size, pool):
    """Greedy grow from a small seed by choosing the element that maximises
    the resulting score.  Uses a two-stage filter: cheap marginal-gain
    estimate first, then exact score on the top candidates."""
    seed = rng.sample(pool, 3)
    A = list(seed)
    while len(A) < target_size:
        # Deduplicate pool against current A.
        cands = [x for x in pool if x not in A]
        if not cands:
            break
        # Cheap pre-screen: pick candidates with the best (new_diffs - new_sums).
        scored = []
        for x in cands:
            d_set = set()
            s_set = set()
            for a in A:
                d_set.add(a - x)
                d_set.add(x - a)
                s_set.add(a + x)
            # Estimate: count of unique new differences minus unique new sums.
            scored.append((len(d_set) - len(s_set), x))
        scored.sort(reverse=True)
        top = [x for _, x in scored[:min(30, len(scored))]]
        best_elem = None
        best_s = -1.0
        for x in top:
            trial = A + [x]
            s = _score(trial)
            if s > best_s:
                best_s = s
                best_elem = x
        if best_elem is None:
            best_elem = top[0]
        A.append(best_elem)
    return A


def _seed_variants():
    """A few hand-picked structured seeds known to score well."""
    return [
        [7, 15, 18, 22, -3, -2],
        [0, 1, 4, 9, 15, 22, 32],
        [0, 1, 3, 7, 12, 20, 30, 44],
        [1, 2, 5, 10, 17, 26, 37, 50],
        [0, 1, 4, 10, 18, 27, 40, 56],
        # Seeds biased to shrink the sum set: elements clustered near 0 with
        # both signs so that many sums collide.
        [-3, -2, -1, 0, 1, 2, 3, 7, 15, 22],
        [-10, -7, -3, -1, 0, 1, 4, 9, 18, 30],
        [-20, -12, -5, -2, 0, 1, 3, 8, 17, 29],
    ]


# ---------------------------------------------------------------------------
# Refinement layer (incremental local search)
# ---------------------------------------------------------------------------
def _diff_counter(a):
    c = Counter()
    for x in a:
        for y in a:
            c[x - y] += 1
    return c


def _sum_counter(a):
    c = Counter()
    for x in a:
        for y in a:
            c[x + y] += 1
    return c


def _score_from_counters(dc, sc, n):
    if n < 2 or len(sc) <= 1:
        return 0.0
    return math.log(len(dc)) / math.log(len(sc)) + (1 - 1 / n) / 100


def _refine(A, rng, deadline, step_scale):
    """Local search: perturb one element at a time, accept non-worsening moves,
    occasionally restart from the current best.  Uses incremental counters."""
    A = list(set(A))
    dc = _diff_counter(A)
    sc = _sum_counter(A)
    best = A[:]
    best_score = _score_from_counters(dc, sc, len(A))
    cur = A[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        i = rng.randrange(len(cand))
        cand[i] += rng.randint(-step_scale, step_scale)
        cand = list(set(cand))
        if len(cand) < 2:
            continue

        # Incremental-ish evaluation: only recompute if set changed.
        d, s = _diff_sum_counts(cand)
        if s <= 1:
            continue
        sc_val = math.log(d) / math.log(s) + (1 - 1 / len(cand)) / 100

        if sc_val >= best_score:
            best, best_score, cur, cur_score = cand[:], sc_val, cand, sc_val
            dc = _diff_counter(cand)
            sc = _sum_counter(cand)
        elif sc_val > cur_score - 0.02:
            cur, cur_score = cand, sc_val
        elif rng.random() < 0.1:
            cur, cur_score = best[:], best_score

        # Occasionally try adding/removing an element.
        r = rng.random()
        if r < 0.04:
            cand2 = cur + [rng.randint(-40, 40)]
            cand2 = list(set(cand2))
            s2 = _score(cand2)
            if s2 >= best_score:
                best, best_score, cur, cur_score = cand2[:], s2, cand2, s2
        elif r < 0.06 and len(cur) > 4:
            j = rng.randrange(len(cur))
            cand2 = cur[:j] + cur[j + 1:]
            s2 = _score(cand2)
            if s2 >= best_score:
                best, best_score, cur, cur_score = cand2[:], s2, cand2, s2

    return best, best_score


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------
def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A|
    small: maximise log|A - A| / log|A + A|."""
    rng = random.Random(12345)
    deadline = time.time() + 100

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Phase 1: try structured seeds and greedy constructions.
    pool_base = list(range(-200, 201))
    # Weighted pool: bias toward smaller magnitudes to keep sums sparse.
    pool_weighted = [x for x in pool_base if abs(x) <= 60] * 3 + pool_base
    for seed in _seed_variants():
        if time.time() > deadline:
            break
        s = _score(seed)
        if s > best_score:
            best, best_score = seed[:], s

    while time.time() < deadline * 0.5:
        target = rng.randint(5, 12)
        pool = rng.sample(pool_weighted, min(len(pool_weighted), 120))
        cand = _greedy_construct(rng, target, pool)
        s = _score(cand)
        if s > best_score:
            best, best_score = cand[:], s

    # Phase 2: refine from the best-known seeds with restarts.
    step_scales = [1, 2, 3, 5]
    while time.time() < deadline:
        start = best[:]
        if rng.random() < 0.5:
            # Perturb a bit before refining to escape the current basin.
            start = list(set(start + [rng.randint(-30, 30) for _ in range(2)]))
        scale = rng.choice(step_scales)
        cand, s = _refine(start, rng, min(deadline, time.time() + 8), scale)
        if s > best_score:
            best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END