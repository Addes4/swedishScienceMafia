# EVOLVE-BLOCK-START
import math
import random
import time


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0 or len(diffs) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _golomb_ruler(n):
    """Greedy construction of a near-minimal Golomb ruler with n marks."""
    marks = [0]
    used_diffs = {0}
    candidate = 1
    while len(marks) < n:
        ok = True
        new_diffs = set()
        for m in marks:
            d = candidate - m
            if d in used_diffs or d in new_diffs:
                ok = False
                break
            new_diffs.add(d)
        if ok:
            marks.append(candidate)
            used_diffs |= new_diffs
        candidate += 1
    return marks


def _build_symmetric_golomb(n_half, spread):
    """Build A as two Golomb-ruler blocks placed symmetrically far from origin.

    Positive block: base + g
    Negative block: -base - g  (negated copy)
    Cross sums then tend to collapse near 0, shrinking |A+A| while differences
    stay large because within-block differences are distinct and cross-block
    differences are far apart.
    """
    g = _golomb_ruler(n_half)
    # scale so blocks are well separated
    scale = max(1, spread // (g[-1] + 1))
    gp = [x * scale for x in g]
    base = gp[-1] + spread
    pos = [base + x for x in gp]
    neg = [-base - x for x in gp]
    return pos + neg


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try several symmetric Golomb-ruler embeddings of different sizes/spreads.
    for n_half in range(3, 9):
        for spread in (50, 120, 300, 800, 2000, 5000):
            if time.time() > deadline:
                break
            cand = _build_symmetric_golomb(n_half, spread)
            cand = sorted(set(cand))
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s

    # Local refinement: nudge single elements to reduce sum-set size / fix collisions.
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        delta = random.choice([-2, -1, 1, 2, 3, -3, 5, -5])
        cand[i] += delta
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
