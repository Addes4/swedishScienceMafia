# EVOLVE-BLOCK-START
"""Nonlinear-programming circle packing in the unit square.

For fixed centres the optimal radii are determined by a simple LP:
    maximise sum r_i
    s.t.  r_i >= 0,
          r_i + r_j <= dist(i,j),
          r_i <= min(x_i, 1-x_i, y_i, 1-y_i).
We use scipy.optimize.linprog to get that (it is exact), then feed that value
and its gradient to an outer optimisation over the centres using SLSQP on the
full joint (centres, radii) problem.  Multiple restarts from hexagonal /
random seeds keep the best.
"""
import numpy as np
from scipy.optimize import linprog, minimize


def max_radii_lp(centers):
    """Exact optimal radii for fixed centres (LP)."""
    n = len(centers)
    # variables r_0..r_{n-1}
    c = -np.ones(n)
    A = []
    b = []
    for i in range(n):
        for j in range(i + 1, n):
            d = np.hypot(centers[i, 0] - centers[j, 0],
                         centers[i, 1] - centers[j, 1])
            row = np.zeros(n)
            row[i] = 1.0
            row[j] = 1.0
            A.append(row)
            b.append(d)
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1],
                              1 - centers[:, 0], 1 - centers[:, 1]])
    for i in range(n):
        row = np.zeros(n)
        row[i] = 1.0
        A.append(row)
        b.append(wall[i])
    res = linprog(c, A_ub=np.array(A), b_ub=np.array(b),
                  bounds=[(0, None)] * n, method="highs")
    if not res.success:
        return np.zeros(n)
    return np.maximum(res.x, 0.0)


def _constraints(z, n):
    """z = [x_0..x_{n-1}, y_0..y_{n-1}, r_0..r_{n-1}]."""
    x = z[:n]
    y = z[n:2 * n]
    r = z[2 * n:]
    cons = []
    # non-overlap: (x_i-x_j)^2 + (y_i-y_j)^2 - (r_i+r_j)^2 >= 0
    for i in range(n):
        for j in range(i + 1, n):
            cons.append({'type': 'ineq',
                         'fun': (lambda z, i=i, j=j:
                                 (z[i] - z[j]) ** 2 + (z[n + i] - z[n + j]) ** 2
                                 - (z[2 * n + i] + z[2 * n + j]) ** 2)})
    for i in range(n):
        cons.append({'type': 'ineq',
                     'fun': (lambda z, i=i: z[i] - z[2 * n + i])})
        cons.append({'type': 'ineq',
                     'fun': (lambda z, i=i: 1 - z[i] - z[2 * n + i])})
        cons.append({'type': 'ineq',
                     'fun': (lambda z, i=i: z[n + i] - z[2 * n + i])})
        cons.append({'type': 'ineq',
                     'fun': (lambda z, i=i: 1 - z[n + i] - z[2 * n + i])})
    return cons


def _obj(z, n):
    return -np.sum(z[2 * n:])


def _init_hex(n, seed):
    rng = np.random.default_rng(seed)
    m = int(np.ceil(np.sqrt(n)))
    pts = []
    xs = np.linspace(0, 1, m + 2)[1:-1]
    ys = np.linspace(0, 1, m + 2)[1:-1]
    for iy, y in enumerate(ys):
        for ix, x in enumerate(xs):
            if len(pts) >= n:
                break
            off = 0.5 / m if iy % 2 else 0.0
            xx = min(max(x + off + 0.03 * (rng.random() - 0.5), 0.01), 0.99)
            yy = min(max(y + 0.03 * (rng.random() - 0.5), 0.01), 0.99)
            pts.append([xx, yy])
        if len(pts) >= n:
            break
    pts = np.array(pts[:n])
    if len(pts) < n:
        extra = rng.random((n - len(pts), 2)) * 0.98 + 0.01
        pts = np.vstack([pts, extra])
    return pts


def _pack_from(centers, n, maxiter=1500):
    centers = centers.copy()
    radii = max_radii_lp(centers)
    z0 = np.concatenate([centers[:, 0], centers[:, 1], radii])
    cons = _constraints(z0, n)
    res = minimize(_obj, z0, args=(n,), method="SLSQP",
                   constraints=cons,
                   bounds=[(0, 1)] * (2 * n) + [(0, 0.5)] * n,
                   options={'maxiter': maxiter, 'ftol': 1e-12})
    z = res.x
    x = z[:n]
    y = z[n:2 * n]
    r = z[2 * n:]
    best_centers = np.column_stack([x, y])
    best_r = max_radii_lp(best_centers)
    if best_r.sum() < r.sum():
        # keep optimizer's solution if LP shrunk it (shouldn't happen)
        best_r = r
    return best_centers, best_r


def solve(n=26):
    best_sum = -1.0
    best = None
    seeds = list(range(12))
    for seed in seeds:
        centers = _init_hex(n, seed)
        try:
            c, r = _pack_from(centers, n)
        except Exception:
            continue
        s = r.sum()
        if s > best_sum:
            best_sum = s
            best = (c.copy(), r.copy())
    # polish the best solution a bit more
    if best is not None:
        c, r = _pack_from(best[0], n, maxiter=4000)
        if r.sum() > best_sum:
            best = (c, r)
    return best
# EVOLVE-BLOCK-END
