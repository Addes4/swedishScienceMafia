# EVOLVE-BLOCK-START
"""Multi-start SLSQP optimizer for circle packing in the unit square.

Maximise sum of radii subject to wall and non-overlap constraints.

Key ideas:
 - Build many diverse feasible starts (hexagonal / grid / spiral / random).
 - For fixed centres compute good radii via pairwise shrinking (max_radii).
 - Polish with SLSQP on (x, y, r) using smooth squared-distance constraints.
 - Do a short random-restart perturbation around the best solution.
"""
import numpy as np
from scipy.optimize import minimize


def max_radii(centers):
    """Largest radii for fixed centres via pairwise shrinking."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    radii = np.maximum(radii, 1e-6)
    for _ in range(400):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                dx = centers[i, 0] - centers[j, 0]
                dy = centers[i, 1] - centers[j, 1]
                d = np.sqrt(dx * dx + dy * dy)
                s = radii[i] + radii[j]
                if d < s - 1e-12:
                    scale = d / s if s > 0 else 0.0
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _init_centers_hex(n, seed, jitter=0.04):
    rng = np.random.default_rng(seed)
    centers = []
    rows = int(np.ceil(np.sqrt(n)))
    y_step = 1.0 / rows
    x_step = 1.0 / rows
    placed = 0
    r = 0
    while placed < n:
        y = (r + 0.5) * y_step
        offset = 0.5 * x_step if (r % 2) else 0.0
        cols = int(np.floor((1.0 - offset) / x_step)) + 1
        for c in range(cols):
            if placed >= n:
                break
            x = offset + (c + 0.5) * x_step
            centers.append([x + jitter * (rng.random() - 0.5),
                            y + jitter * (rng.random() - 0.5)])
            placed += 1
        r += 1
    centers = np.array(centers[:n])
    return np.clip(centers, 0.05, 0.95)


def _init_centers_grid(n, seed, jitter=0.03):
    rng = np.random.default_rng(seed)
    cols = int(np.ceil(np.sqrt(n)))
    rows = int(np.ceil(n / cols))
    centers = []
    for i in range(n):
        rr = i // cols
        cc = i % cols
        x = (cc + 0.5) / cols + jitter * (rng.random() - 0.5)
        y = (rr + 0.5) / rows + jitter * (rng.random() - 0.5)
        centers.append([x, y])
    return np.clip(np.array(centers), 0.05, 0.95)


def _init_centers_random(n, seed):
    rng = np.random.default_rng(seed)
    return rng.uniform(0.1, 0.9, size=(n, 2))


def _init_centers_spiral(n, seed):
    rng = np.random.default_rng(seed)
    centers = []
    for i in range(n):
        t = i / max(1, n - 1)
        ang = 2 * np.pi * t * 3.0
        rad = 0.05 + 0.40 * t
        x = 0.5 + rad * np.cos(ang) + 0.02 * (rng.random() - 0.5)
        y = 0.5 + rad * np.sin(ang) + 0.02 * (rng.random() - 0.5)
        centers.append([x, y])
    return np.clip(np.array(centers), 0.05, 0.95)


def _pack_centers(centers, iters=600, lr=0.02):
    """Push overlapping circles apart (fixed radii = max feasible)."""
    n = len(centers)
    centers = centers.copy()
    for _ in range(iters):
        radii = max_radii(centers)
        grad = np.zeros_like(centers)
        for i in range(n):
            for j in range(i + 1, n):
                dx = centers[i, 0] - centers[j, 0]
                dy = centers[i, 1] - centers[j, 1]
                d = np.sqrt(dx * dx + dy * dy) + 1e-12
                s = radii[i] + radii[j]
                if d < s:
                    f = (s - d) / d
                    grad[i, 0] += f * dx
                    grad[i, 1] += f * dy
                    grad[j, 0] -= f * dx
                    grad[j, 1] -= f * dy
        for i in range(n):
            r = radii[i]
            if centers[i, 0] - r < 1e-3:
                grad[i, 0] += 1e-2
            if 1 - centers[i, 0] - r < 1e-3:
                grad[i, 0] -= 1e-2
            if centers[i, 1] - r < 1e-3:
                grad[i, 1] += 1e-2
            if 1 - centers[i, 1] - r < 1e-3:
                grad[i, 1] -= 1e-2
        centers = centers + grad * lr
        centers = np.clip(centers, 0.0, 1.0)
    return centers


def _objective(z, n):
    r = z[2 * n:3 * n]
    return -np.sum(r)


def _constraints(z, n, idx_i, idx_j):
    x = z[0:n]
    y = z[n:2 * n]
    r = z[2 * n:3 * n]
    out = []
    out.append(x - r)
    out.append(1 - x - r)
    out.append(y - r)
    out.append(1 - y - r)
    dx = x[idx_i] - x[idx_j]
    dy = y[idx_i] - y[idx_j]
    rr = r[idx_i] + r[idx_j]
    out.append(dx * dx + dy * dy - rr * rr)
    return np.concatenate(out)


def _feasible(centers, radii, tol=1e-6):
    x = centers[:, 0]
    y = centers[:, 1]
    r = radii
    if np.any(x - r < -tol) or np.any(1 - x - r < -tol):
        return False
    if np.any(y - r < -tol) or np.any(1 - y - r < -tol):
        return False
    n = len(centers)
    for i in range(n):
        for j in range(i + 1, n):
            dx = x[i] - x[j]
            dy = y[i] - y[j]
            d2 = dx * dx + dy * dy
            if d2 < (r[i] + r[j]) ** 2 - tol:
                return False
    return True


def _optimize(centers0, radii0, maxiter=600):
    n = len(centers0)
    z0 = np.concatenate([centers0[:, 0], centers0[:, 1], radii0])
    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 0.5)] * n
    ii, jj = np.triu_indices(n, 1)
    cons = [{'type': 'ineq', 'fun': _constraints,
             'args': (n, ii, jj)}]
    try:
        res = minimize(_objective, z0, args=(n,), method='SLSQP',
                       bounds=bounds, constraints=cons,
                       options={'maxiter': maxiter, 'ftol': 1e-12})
        z = res.x
    except Exception:
        return None
    x = z[0:n]
    y = z[n:2 * n]
    r = np.maximum(z[2 * n:3 * n], 0.0)
    centers = np.stack([x, y], axis=1)
    if not _feasible(centers, r, tol=1e-6):
        return None
    return centers, r


def solve(n=26):
    best_sum = -1.0
    best = None

    starts = []
    for s in range(6):
        starts.append(_init_centers_hex(n, s))
    for s in range(4):
        starts.append(_init_centers_grid(n, s))
    for s in range(3):
        starts.append(_init_centers_spiral(n, s))
    for s in range(6):
        starts.append(_init_centers_random(n, s))

    for c0 in starts:
        c0 = _pack_centers(c0, iters=500, lr=0.02)
        r0 = max_radii(c0)
        r0 = np.maximum(r0 * 0.98, 1e-5)
        res = _optimize(c0, r0, maxiter=500)
        if res is None:
            continue
        centers, radii = res
        s_val = radii.sum()
        if s_val > best_sum:
            best_sum = s_val
            best = (centers.copy(), radii.copy())

    if best is None:
        c0 = _init_centers_hex(n, 0)
        c0 = _pack_centers(c0)
        r0 = max_radii(c0)
        best = (c0, r0)

    # polish from best with more iterations
    centers, radii = best
    r2 = _optimize(centers, radii, maxiter=1500)
    if r2 is not None and r2[1].sum() > best_sum:
        best_sum = r2[1].sum()
        best = r2

    # random perturbation restarts around best
    rng = np.random.default_rng(12345)
    for _ in range(8):
        centers, radii = best
        c = centers + rng.normal(0, 0.015, size=centers.shape)
        c = np.clip(c, 0.02, 0.98)
        r = max_radii(c) * 0.98
        r = np.maximum(r, 1e-5)
        res = _optimize(c, r, maxiter=800)
        if res is not None and res[1].sum() > best_sum:
            best_sum = res[1].sum()
            best = res

    return best
# EVOLVE-BLOCK-END
