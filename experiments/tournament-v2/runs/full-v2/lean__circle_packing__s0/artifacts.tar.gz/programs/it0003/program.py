# EVOLVE-BLOCK-START
"""SLSQP-based local optimisation for circle packing in the unit square.

The problem: choose centres (x_i,y_i) in [0,1]^2 and radii r_i >= 0 to
maximise sum(r_i) subject to
    (x_i-x_j)^2 + (y_i-y_j)^2 >= (r_i+r_j)^2        (non-overlap)
    r_i <= x_i, r_i <= 1-x_i, r_i <= y_i, r_i <= 1-y_i   (inside square)

We use scipy.optimize.minimize with SLSQP. Starting points are built from a
hexagonal layout; radii are initialised strictly inside the feasible region
(scaled-down max_radii) so we never leave the square.
"""
import numpy as np
from scipy.optimize import minimize


def max_radii(centers):
    """Largest radii for fixed centres, via rounds of pairwise shrinking."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    radii = np.maximum(radii, 0.0)
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                dx = centers[i, 0] - centers[j, 0]
                dy = centers[i, 1] - centers[j, 1]
                d = np.sqrt(dx * dx + dy * dy)
                s = radii[i] + radii[j]
                if d < s - 1e-12 and s > 0:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _init_centers(n, seed):
    rng = np.random.default_rng(seed)
    centers = []
    rows = int(np.ceil(np.sqrt(n)))
    y_step = 1.0 / rows
    x_step = 1.0 / rows
    placed = 0
    r = 0
    while placed < n:
        y = (r + 0.5) * y_step
        offset = 0.5 * x_step if (r % 2) else 0.0
        cols = int(np.floor((1.0 - offset) / x_step)) + 1
        for c in range(cols):
            if placed >= n:
                break
            x = offset + (c + 0.5) * x_step
            centers.append([x + 0.05 * (rng.random() - 0.5),
                            y + 0.05 * (rng.random() - 0.5)])
            placed += 1
        r += 1
    centers = np.clip(np.array(centers[:n]), 0.02, 0.98)
    return centers


def _pack_vector(centers, radii):
    return np.concatenate([centers[:, 0], centers[:, 1], radii])


def _unpack(v, n):
    x = v[0:n]
    y = v[n:2 * n]
    r = v[2 * n:3 * n]
    return x, y, r


def _objective(v, n):
    _, _, r = _unpack(v, n)
    return -np.sum(r)


def _constraints(n):
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

    def nonoverlap(v, n=n, pairs=pairs):
        x, y, r = _unpack(v, n)
        dx = x[:, None] - x[None, :]
        dy = y[:, None] - y[None, :]
        rs = r[:, None] + r[None, :]
        d2 = dx * dx + dy * dy - rs * rs
        vals = []
        for i, j in pairs:
            vals.append(d2[i, j])
        return np.array(vals)

    def walls(v, n=n):
        x, y, r = _unpack(v, n)
        c = np.concatenate([
            r - x,            # x - r >= 0  => r - x <= 0
            r - (1 - x),
            r - y,
            r - (1 - y),
        ])
        return c

    return [
        {"type": "ineq", "fun": nonoverlap},
        {"type": "ineq", "fun": walls},
    ]


def _solve_from(centers0, radii0, n, maxiter=400):
    v0 = _pack_vector(centers0, radii0)
    cons = _constraints(n)
    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 0.5)] * n
    res = minimize(_objective, v0, args=(n,), method="SLSQP",
                   bounds=bounds, constraints=cons,
                   options={"maxiter": maxiter, "ftol": 1e-12})
    x, y, r = _unpack(res.x, n)
    centers = np.column_stack([x, y])
    return centers, np.maximum(r, 0.0)


def _feasible_start(centers0, n):
    """Shrink radii to be strictly inside the square before SLSQP."""
    radii = max_radii(centers0)
    radii = radii * 0.9  # margin so we start strictly feasible
    return radii


def solve(n=26):
    best_sum = -1.0
    best = None
    seeds = list(range(8))
    for seed in seeds:
        centers0 = _init_centers(n, seed)
        radii0 = _feasible_start(centers0, n)
        try:
            centers, radii = _solve_from(centers0, radii0, n, maxiter=300)
        except Exception:
            continue
        # clamp and re-verify feasibility
        centers = np.clip(centers, 0.0, 1.0)
        radii = np.maximum(radii, 0.0)
        # enforce exact feasibility by shrinking if needed
        radii = np.minimum(radii, max_radii(centers))
        s = radii.sum()
        if s > best_sum:
            best_sum = s
            best = (centers.copy(), radii.copy())
    if best is None:
        centers0 = _init_centers(n, 0)
        best = (centers0, max_radii(centers0))
    return best
# EVOLVE-BLOCK-END
