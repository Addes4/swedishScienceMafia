# EVOLVE-BLOCK-START
"""Billiard/relaxation heuristic for circle packing in the unit square.

Idea: start from a perturbed hexagonal packing, then alternate
 (a) computing the maximal feasible radii for fixed centres and
 (b) pushing overlapping circles apart / toward walls to grow the radii,
so the sum of radii increases monotonically.
"""
import numpy as np


def max_radii(centers):
    """Largest radii for fixed centres, via a few rounds of pairwise shrinking."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                dx = centers[i, 0] - centers[j, 0]
                dy = centers[i, 1] - centers[j, 1]
                d = np.sqrt(dx * dx + dy * dy)
                s = radii[i] + radii[j]
                if d < s - 1e-12:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _init_centers(n, seed):
    rng = np.random.default_rng(seed)
    # Hexagonal-ish seed: fill the square on a triangular lattice with jitter.
    centers = []
    rows = int(np.ceil(np.sqrt(n)))
    y_step = 1.0 / rows
    x_step = 1.0 / rows
    placed = 0
    r = 0
    while placed < n:
        y = (r + 0.5) * y_step
        offset = 0.5 * x_step if (r % 2) else 0.0
        cols = int(np.floor((1.0 - offset) / x_step)) + 1
        for c in range(cols):
            if placed >= n:
                break
            x = offset + (c + 0.5) * x_step
            centers.append([x + 0.05 * (rng.random() - 0.5),
                            y + 0.05 * (rng.random() - 0.5)])
            placed += 1
        r += 1
    centers = np.clip(np.array(centers[:n]), 0.02, 0.98)
    return centers


def _grow(centers, iters=4000, lr=0.02):
    n = len(centers)
    centers = centers.copy()
    for _ in range(iters):
        radii = max_radii(centers)
        # gradients of sum(radii) w.r.t. centres:
        # For each active constraint pair, push apart along the line.
        grad = np.zeros_like(centers)
        for i in range(n):
            for j in range(i + 1, n):
                dx = centers[i, 0] - centers[j, 0]
                dy = centers[i, 1] - centers[j, 1]
                d = np.sqrt(dx * dx + dy * dy) + 1e-12
                s = radii[i] + radii[j]
                if d < s + 1e-6:
                    # two circles are (nearly) touching: they want to separate
                    # each gains radius if they get further apart, but the wall
                    # constraints also matter. Push them apart.
                    f = (s - d) / d
                    grad[i, 0] += f * dx
                    grad[i, 1] += f * dy
                    grad[j, 0] -= f * dx
                    grad[j, 1] -= f * dy
        # wall pressure: small circles near a wall want to move inward only if
        # the wall is their binding constraint and they touch something outside.
        for i in range(n):
            r = radii[i]
            if centers[i, 0] - r < 1e-6:
                grad[i, 0] += lr * 10
            if 1 - centers[i, 0] - r < 1e-6:
                grad[i, 0] -= lr * 10
            if centers[i, 1] - r < 1e-6:
                grad[i, 1] += lr * 10
            if 1 - centers[i, 1] - r < 1e-6:
                grad[i, 1] -= lr * 10
        step = grad * lr
        centers = centers + step
        centers = np.clip(centers, 0.0, 1.0)
    return centers


def solve(n=26):
    best_sum = -1.0
    best = None
    for seed in range(6):
        centers = _init_centers(n, seed)
        centers = _grow(centers, iters=1500, lr=0.015)
        radii = max_radii(centers)
        s = radii.sum()
        if s > best_sum:
            best_sum = s
            best = (centers.copy(), radii.copy())
    return best
# EVOLVE-BLOCK-END

