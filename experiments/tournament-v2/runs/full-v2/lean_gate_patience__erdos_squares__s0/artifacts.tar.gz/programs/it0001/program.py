# EVOLVE-BLOCK-START
"""Better baseline: grid plus optimized leftover strip packing."""
import math


def _grid(k):
    s = 1.0 / k
    return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)], s


def solve(n):
    if n <= 0:
        return []
    k = math.isqrt(n)
    if k * k == n:
        sq, _ = _grid(k)
        return sq
    # Use k x k grid, then add leftover in extra row/col if possible.
    # Option A: k rows + leftover placed in a new partial row (k columns wide)
    # Fit (k+1) rows? Not possible at full size. Try: k columns, one column split.
    # Simpler: choose grid of k cols and distribute leftover among top strip.
    best = None

    # Try layout: k x k grid with one cell subdivided into (r+1) thin rectangles via
    # vertical split, all kept as squares scaled. We just do a scan of "extra strip"
    # model: base k*k squares of size s; leftover m = n-k*k squares placed in a strip.
    # Strip model: take top row of k cells, shrink them to allow an extra partial row.
    m = n - k * k
    # Layout: k full rows of k squares each except bottom row region replaced by k+? 
    # Try: k columns, (k) rows plus m squares squeezed in a strip of height h at top.
    # The top strip has k*m? Instead: put m squares in a strip of height h, each width 1/m-ish.
    # Squares in top strip: m squares side h arranged horizontally, need m*h <= 1.
    # Below strip: k rows each height (1-h)/k, k squares each side (1-h)/k.
    # total = k*k*(1-h)/k + m*h = k*(1-h) + m*h (each strip square side h)
    # => maximize k + (m-k)*h, so if m>k take largest h: h<=1/m and h<=1 => h=1/m but
    # need (1-h)/k <= h too? Not required, disjoint just needs total heights fit: k*(1-h)/k=1-h
    # plus h => 1. ok. But widths: strip squares side h, m of them: m*h<=1 => h<=1/m.
    # Also constrained: bottom squares side (1-h)/k fit in width: k*(1-h)/k=1-h<=1 ok.
    h = 1.0 / m
    s = (1.0 - h) / k
    sq = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    y0 = 1.0 - h / 2
    for t in range(m):
        x = (t + 0.5) * h
        sq.append((x, y0, 0.0, h))
    val = k * k * s + m * h
    best = (val, sq)

    # Alternative: right strip of width w, m squares side w stacked vertically
    w = 1.0 / m
    s2 = (1.0 - w) / k
    if s2 > 0:
        sq2 = [((i + 0.5) * s2 + w, (j + 0.5) * s2, 0.0, s2) for i in range(k) for j in range(k)]
        x0 = w / 2
        for t in range(m):
            y = (t + 0.5) * w
            sq2.append((x0, y, 0.0, w))
        val2 = k * k * s2 + m * w
        if val2 > best[0]:
            best = (val2, sq2)

    # Alternative: (k+1) grid with some zero squares
    kk = k + 1
    s3 = 1.0 / kk
    if kk * kk <= n:
        sq3, _ = _grid(kk)
        sq3 += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq3))
        return sq3[:n]

    return best[1][:n]
# EVOLVE-BLOCK-END
