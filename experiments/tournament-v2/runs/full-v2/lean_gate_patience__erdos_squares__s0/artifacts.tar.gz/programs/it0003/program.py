# EVOLVE-BLOCK-START
"""Optimized packing of n squares in the unit square via local search."""
import math
import numpy as np
from scipy.optimize import minimize


def _penetration_and_bounds(squares):
    """Return total violation of bounds plus overlaps for given squares."""
    n = len(squares)
    v = 0.0
    # bounds: compute half-extent along x and y
    for cx, cy, a, s in squares:
        if s <= 0:
            continue
        c = abs(math.cos(2 * math.pi * a))
        sn = abs(math.sin(2 * math.pi * a))
        ex = 0.5 * s * (c + sn)
        ey = 0.5 * s * (c + sn)
        v += max(0.0, ex - cx) ** 2
        v += max(0.0, cx + ex - 1.0) ** 2
        v += max(0.0, ey - cy) ** 2
        v += max(0.0, cy + ey - 1.0) ** 2
    # overlaps: approximate via sampling axis-aligned bounding boxes then real SAT-free check
    for i in range(n):
        cxi, cyi, ai, si = squares[i]
        if si <= 0:
            continue
        for j in range(i + 1, n):
            cxj, cyj, aj, sj = squares[j]
            if sj <= 0:
                continue
            # separating axis theorem for two rotated squares
            from math import cos, sin, pi
            def axes(a):
                th = 2 * pi * a
                ct, st = cos(th), sin(th)
                return [(ct, st), (-st, ct)]
            def corners(cx, cy, a, s):
                th = 2 * pi * a
                ct, st = cos(th), sin(th)
                h = 0.5 * s
                return [(cx + ct * h - st * h, cy + st * h + ct * h),
                        (cx + ct * h + st * h, cy + st * h - ct * h),
                        (cx - ct * h + st * h, cy - st * h - ct * h),
                        (cx - ct * h - st * h, cy - st * h + ct * h)]
            ci = corners(cxi, cyi, ai, si)
            cj = corners(cxj, cyj, aj, sj)
            sep = False
            for ax in axes(ai) + axes(aj):
                p1 = [pt[0] * ax[0] + pt[1] * ax[1] for pt in ci]
                p2 = [pt[0] * ax[0] + pt[1] * ax[1] for pt in cj]
                if max(p1) < min(p2) - 1e-12 or max(p2) < min(p1) - 1e-12:
                    sep = True
                    break
            if not sep:
                # compute minimal overlap depth roughly = min over axes of positive overlap
                best = 1e9
                for ax in axes(ai) + axes(aj):
                    p1 = [pt[0] * ax[0] + pt[1] * ax[1] for pt in ci]
                    p2 = [pt[0] * ax[0] + pt[1] * ax[1] for pt in cj]
                    ov = min(max(p1), max(p2)) - max(min(p1), min(p2))
                    if ov > 0:
                        best = min(best, ov)
                if best < 1e9:
                    v += best ** 2
    return v


def solve(n):
    k = math.isqrt(n)
    best_squares = None
    best_val = -1.0

    # Candidate initial layouts: kxk grid, with extras inserted as subdivisions
    candidates = []

    # plain grid + zero-size
    side = 1.0 / k
    g = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    g += [(0.5, 0.5, 0.0, 0.0)] * (n - len(g))
    candidates.append(g[:n])

    # grid where the last cell is subdivided into m equal squares (recursively one level)
    m = n - k * k
    if m > 0 and k >= 1:
        for split_dim in range(2):
            for rows in range(1, m + 1):
                cols = (m + rows - 1) // rows
                cell = 1.0 / k
                # subdivide top-right cell into rows x cols
                # but here we just try a slightly different grid: 1D split of one row
                pass

    # Try k+1 by using one bigger row/col arrangement: place k full rows plus a partial row
    for rows in range(1, min(n, k + 2) + 1):
        cols_full = n // rows
        rem = n % rows
        cell_h = 1.0 / rows
        # each row has either cols_full or cols_full+1 squares
        layout = []
        for r in range(rows):
            c_here = cols_full + (1 if r < rem else 0)
            if c_here == 0:
                continue
            cw = 1.0 / c_here
            for c in range(c_here):
                layout.append(((c + 0.5) * cw, (r + 0.5) * cell_h, 0.0, min(cw, cell_h)))
        if layout:
            layout += [(0.5, 0.5, 0.0, 0.0)] * (n - len(layout))
            candidates.append(layout[:n])

    # Also: rows where cell is square, filling leftover with zero
    for cols in range(1, n + 1):
        rows = n // cols
        if rows == 0:
            continue
        cell = min(1.0 / cols, 1.0 / rows)
        layout = []
        for c in range(cols):
            for r in range(rows):
                layout.append(((c + 0.5) * (1.0 / cols), (r + 0.5) * (1.0 / rows), 0.0, cell))
        layout += [(0.5, 0.5, 0.0, 0.0)] * (n - len(layout))
        candidates.append(layout[:n])

    for cand in candidates:
        if len(cand) != n:
            continue
        total = sum(s for _, _, _, s in cand)
        if total > best_val:
            best_val = total
            best_squares = cand

    # Local optimization: variables are cx, cy, s for each square (angle fixed at 0)
    if best_squares is not None:
        x0 = []
        for cx, cy, a, s in best_squares:
            x0.append(cx)
            x0.append(cy)
            x0.append(s)
        x0 = np.array(x0)

        def unpack(x):
            sq = []
            for i in range(n):
                cx = x[3 * i]
                cy = x[3 * i + 1]
                s = max(0.0, x[3 * i + 2])
                sq.append((cx, cy, 0.0, s))
            return sq

        def neg_obj(x):
            return -sum(max(0.0, x[3 * i + 2]) for i in range(n))

        def constraint(x):
            sq = unpack(x)
            return _penetration_and_bounds(sq)

        try:
            res = minimize(lambda x: -sum(max(0.0, x[3 * i + 2]) for i in range(n)) + 10.0 * constraint(x),
                           x0, method='L-BFGS-B',
                           bounds=[(0.0, 1.0)] * (3 * n),
                           options={'maxiter': 400, 'ftol': 1e-12})
            sq = unpack(res.x)
            pen = _penetration_and_bounds(sq)
            if pen < 1e-6:
                newtotal = sum(s for _, _, _, s in sq)
                if newtotal > best_val:
                    # clamp inside
                    fixed = []
                    for cx, cy, a, s in sq:
                        s = max(0.0, s)
                        # shrink to fit bounds
                        ex = 0.5 * s
                        cx = min(max(cx, ex), 1.0 - ex)
                        cy = min(max(cy, ex), 1.0 - ex)
                        fixed.append((cx, cy, a, s))
                    # final overlap shrink pass
                    for _ in range(200):
                        pen = _penetration_and_bounds(fixed)
                        if pen < 1e-9:
                            break
                        fixed = [(cx, cy, a, s * 0.999) for cx, cy, a, s in fixed]
                    fixed_total = sum(s for _, _, _, s in fixed)
                    if fixed_total > best_val and _penetration_and_bounds(fixed) < 1e-6:
                        best_val = fixed_total
                        best_squares = fixed
        except Exception:
            pass

    if best_squares is None:
        best_squares = [(0.5, 0.5, 0.0, 0.0)] * n

    # Final safety: ensure no overlaps via iterative shrink if needed
    sq = list(best_squares)
    for _ in range(300):
        if _penetration_and_bounds(sq) < 1e-9:
            break
        sq = [(cx, cy, a, s * 0.999) for cx, cy, a, s in sq]

    # clamp bounds
    out = []
    for cx, cy, a, s in sq:
        s = max(0.0, min(s, 1.0))
        ex = 0.5 * s
        cx = min(max(cx, ex), 1.0 - ex) if ex <= 0.5 else 0.5
        cy = min(max(cy, ex), 1.0 - ex) if ex <= 0.5 else 0.5
        out.append((cx, cy, a, s))
    return out
# EVOLVE-BLOCK-END

