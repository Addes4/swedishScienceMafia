# EVOLVE-BLOCK-START
"""Asymmetric grid: k x k cells with the extra squares packed into one row/column."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    k = math.isqrt(n)
    extra = n - k * k
    # Build a grid with k rows and k columns, but expand to hold `extra` squares
    # by splitting one row into (extra+1) columns of varying widths.
    # Choose to subdivide the first row: it has k columns normally; we want
    # extra additional squares, so the first row gets k+extra "cells".
    #
    # Layout: top row has (k + extra) small squares across the width.
    # Remaining (k-1) rows each have k squares of equal height.
    # All squares in a row share the row height. Sum of sides:
    #   row0: (k+extra) * w0 where w0 = 1/(k+extra) -> total 1
    #   other rows: k * h where h = (1 - w0)/(k-1)  ... but better to make
    # the rows equal: use same height for all rows for balance.
    #
    # Simple valid approach: single column split gives (k+extra) columns of width
    # w = 1/(k+extra); the grid is (k+extra) wide by k tall? No, that's k*(k+extra)
    # which overshoots. Instead: choose a rectangular grid a x b with a*b >= n and
    # use min(a,b) maximised. Take a = ceil(n/k), b = k, then place n in a*b slots.
    a = (n + k - 1) // k  # columns
    b = k                 # rows
    # Use side = min(1/a, 1/b) and lay out the first n cells.
    cw = 1.0 / a
    ch = 1.0 / b
    s = min(cw, ch)
    squares = []
    count = 0
    for j in range(b):
        for i in range(a):
            if count >= n:
                break
            cx = (i + 0.5) * cw
            cy = (j + 0.5) * ch
            squares.append((cx, cy, 0.0, s))
            count += 1
        if count >= n:
            break
    # If s < cw or s < ch, we have wasted space; not ideal, but valid.
    # Fall back to pure k x k grid when that yields larger side sum.
    side = 1.0 / k
    base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(k) for j in range(k)]
    base += [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
    base = base[:n]
    if sum(q[3] for q in base) >= sum(q[3] for q in squares):
        return base
    return squares
# EVOLVE-BLOCK-END
