import math
import random
import numpy as np

# We use a fast geometric feasibility test for axis-aligned and rotated squares
# using separating axis theorem (SAT) for convex polygons.

def square_vertices(cx, cy, ang, s):
    """Return 4 vertices of a square, angle as fraction of full turn."""
    theta = 2.0 * math.pi * ang
    c, sn = math.cos(theta), math.sin(theta)
    h = s * 0.5
    # corners in local coords: (-h,-h),(h,-h),(h,h),(-h,h)
    dx = c * h
    dy = sn * h
    # rotation matrix: x' = x*c - y*sn, y' = x*sn + y*c
    pts = []
    for lx, ly in ((-h, -h), (h, -h), (h, h), (-h, h)):
        px = cx + lx * c - ly * sn
        py = cy + lx * sn + ly * c
        pts.append((px, py))
    return pts

def project_poly(pts, axis):
    d = [p[0] * axis[0] + p[1] * axis[1] for p in pts]
    return min(d), max(d)

def sat_overlap(pts1, pts2):
    """Return True if interiors overlap (strict)."""
    polys = [pts1, pts2]
    for poly in polys:
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            edge = (x2 - x1, y2 - y1)
            axis = (-edge[1], edge[0])
            L = math.hypot(*axis)
            if L < 1e-15:
                continue
            axis = (axis[0] / L, axis[1] / L)
            a_min, a_max = project_poly(pts1, axis)
            b_min, b_max = project_poly(pts2, axis)
            if a_max <= b_min + 1e-12 or b_max <= a_min + 1e-12:
                return False
    return True

def inside_unit(pts):
    for x, y in pts:
        if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
            return False
    return True

def valid_config(squares):
    """squares: list of (cx, cy, ang, s). Check all inside [0,1]^2 and disjoint interiors."""
    n = len(squares)
    polys = []
    for cx, cy, ang, s in squares:
        if s <= 0:
            # zero-size counts as point: just check center inside
            if cx < -1e-12 or cx > 1 + 1e-12 or cy < -1e-12 or cy > 1 + 1e-12:
                return False
            polys.append(None)
        else:
            pts = square_vertices(cx, cy, ang, s)
            if not inside_unit(pts):
                return False
            polys.append(pts)
    for i in range(n):
        if polys[i] is None:
            continue
        for j in range(i + 1, n):
            if polys[j] is None:
                continue
            if sat_overlap(polys[i], polys[j]):
                return False
    return True

def total_side(squares):
    return sum(max(0.0, s) for _, _, _, s in squares

def try_place_square(squares, existing_polys, cx, cy, ang, s):
    pts = square_vertices(cx, cy, ang, s)
    if not inside_unit(pts):
        return False
    for ep in existing_polys:
        if ep is None:
            continue
        if sat_overlap(pts, ep):
            return False
    return True

def greedy_build(n, seed=0, restarts=4):
    """Try to place n squares greedily with random order and sizes."""
    rng = random.Random(seed)
    best = None
    best_sum = -1.0

    # initial grid as fallback for large n
    for attempt in range(restarts):
        squares = []
        polys = []
        # We'll attempt to place squares of various sizes at random positions
        # Start with a coarse grid to guarantee feasibility for large n
        k = int(math.isqrt(n))
        if k > 0 and attempt == 0:
            # grid fill
            side = 1.0 / k
            for i in range(k):
                for j in range(k):
                    if len(squares) >= n:
                        break
                    cx = (i + 0.5) * side
                    cy = (j + 0.5) * side
                    squares.append((cx, cy, 0.0, side))
                    polys.append(square_vertices(cx, cy, 0.0, side))
                if len(squares) >= n:
                    break
            while len(squares) < n:
                squares.append((0.5, 0.5, 0.0, 0.0))
                polys.append(None)
            s = total_side(squares)
            if s > best_sum:
                best_sum = s
                best = squares[:]
            continue

        # Random greedy: try to place squares from largest to smallest
        # We'll use a set of candidate sizes and positions
        squares = []
        polys = []
        # Place a few larger squares first, then fill with smaller ones
        attempts_per = 300
        for _ in range(n):
            best_candidate = None
            best_size = 0.0
            # Try random placements with decreasing sizes
            for trial in range(attempts_per):
                # propose a size
                max_s = min(1.0, 2.0 / (len(squares) + 1.0) if len(squares) > 0 else 1.0)
                # bias towards larger sizes early
                u = rng.random()
                s = max_s * (1.0 - u ** 2)
                if s < 1e-9:
                    s = 0.0
                ang = 0.0 if rng.random() < 0.7 else rng.random()
                cx = rng.random()
                cy = rng.random()
                if s == 0.0:
                    if inside_unit([(cx, cy)]) and all(
                        not (ep is not None and sat_overlap([(cx, cy)], ep)) for ep in polys
                    ):
                        best_candidate = (cx, cy, ang, 0.0)
                        best_size = 0.0
                        break
                else:
                    if try_place_square(squares, polys, cx, cy, ang, s):
                        if s > best_size:
                            best_size = s
                            best_candidate = (cx, cy, ang, s)
                            if s > 0.9 * max_s and s > 0.3:
                                break
            if best_candidate is None:
                # place zero-size
                best_candidate = (0.5, 0.5, 0.0, 0.0)
                squares.append(best_candidate)
                polys.append(None)
            else:
                squares.append(best_candidate)
                cx, cy, ang, s = best_candidate
                if s > 0:
                    polys.append(square_vertices(cx, cy, ang, s))
                else:
                    polys.append(None)
        val = total_side(squares)
        if val > best_sum:
            best_sum = val
            best = squares[:]
    return best

def local_improve(squares, iterations=2000, seed=1):
    """Perturb centers/angles and try to increase sizes while maintaining validity."""
    rng = random.Random(seed)
    n = len(squares)
    if n == 0:
        return squares
    current = [list(sq) for sq in squares]
    cur_val = total_side(current)

    for it in range(iterations):
        # pick a random square
        i = rng.randrange(n)
        cx, cy, ang, s = current[i]
        # propose small perturbation
        if s > 0:
            dcx = rng.gauss(0, 0.01)
            dcy = rng.gauss(0, 0.01)
            dang = rng.gauss(0, 0.01)
            ds = rng.gauss(0, 0.02)
        else:
            dcx = rng.gauss(0, 0.02)
            dcy = rng.gauss(0, 0.02)
            dang = 0.0
            ds = abs(rng.gauss(0, 0.02))
        ncx = min(1.0, max(0.0, cx + dcx))
        ncy = min(1.0, max(0.0, cy + dcy))
        nang = (ang + dang) % 1.0
        ns = max(0.0, s + ds)
        # try to apply
        trial = current[:]
        trial[i] = [ncx, ncy, nang, ns]
        if valid_config(trial):
            new_val = total_side(trial)
            if new_val >= cur_val - 1e-12:
                current = trial
                cur_val = new_val
    return [tuple(x) for x in current]

def solve(n):
    if n <= 0:
        return []
    # Try a few seeds and keep best
    best = None
    best_val = -1.0
    seeds = [0, 1, 2]
    for sd in seeds:
        sq = greedy_build(n, seed=sd, restarts=2 if n > 50 else 4)
        sq = local_improve(sq, iterations=1500 if n <= 100 else 800, seed=sd)
        val = total_side(sq)
        if val > best_val:
            best_val = val
            best = sq
    # Ensure exactly n squares
    if len(best) < n:
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]
