import math
import random
import numpy as np

def overlap_area(s1, s2):
    """Return overlapping area of two squares (axis-aligned or rotated)."""
    cx1, cy1, a1, s1 = s1
    cx2, cy2, a2, s2 = s2
    if s1 <= 0 or s2 <= 0:
        return 0.0
    # Quick boundary check for centers
    if abs(cx1 - cx2) > (s1 + s2) * 0.75 or abs(cy1 - cy2) > (s1 + s2) * 0.75:
        return 0.0

    # Get corners of square 1
    def corners(cx, cy, ang, side):
        h = side / 2.0
        c, s = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
        pts = []
        for dx, dy in [(-h, -h), (h, -h), (h, h), (-h, h)]:
            x = cx + dx * c - dy * s
            y = cy + dx * s + dy * c
            pts.append((x, y))
        return pts

    p1 = corners(cx1, cy1, a1, s1)
    p2 = corners(cx2, cy2, a2, s2)

    # Use separating axis theorem for convex polygons
    def project(poly, axis):
        dots = [p[0] * axis[0] + p[1] * axis[1] for p in poly]
        return min(dots), max(dots)

    def get_axes(poly):
        axes = []
        for i in range(len(poly)):
            p1, p2 = poly[i], poly[(i + 1) % len(poly)]
            edge = (p2[0] - p1[0], p2[1] - p1[1])
            normal = (-edge[1], edge[0])
            length = math.hypot(*normal)
            if length > 1e-12:
                axes.append((normal[0] / length, normal[1] / length))
        return axes

    axes = get_axes(p1) + get_axes(p2)
    for ax in axes:
        min1, max1 = project(p1, ax)
        min2, max2 = project(p2, ax)
        if max1 < min2 + 1e-12 or max2 < min1 + 1e-12:
            return 0.0  # Separated
    # If no separating axis, they overlap
    return 1.0

def total_overlap(squares):
    n = len(squares)
    total = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            total += overlap_area(squares[i], squares[j])
    return total

def clip_to_unit(squares):
    """Clip centers so squares stay inside [0,1]^2 and sides ≤ 1."""
    res = []
    for cx, cy, ang, side in squares:
        side = max(0.0, min(1.0, side))
        h = side / 2.0
        c = abs(math.cos(2 * math.pi * ang)) * h + abs(math.sin(2 * math.pi * ang)) * h
        # bounding box half-extent
        bx = abs(math.cos(2 * math.pi * ang)) * h + abs(math.sin(2 * math.pi * ang)) * h
        by = abs(math.cos(2 * math.pi * ang)) * h + abs(math.sin(2 * math.pi * ang)) * h
        cx = max(bx, min(1.0 - bx, cx))
        cy = max(by, min(1.0 - by, cy))
        res.append((cx, cy, ang, side))
    return res

def evaluate(squares):
    """Score = sum of sides - large penalty for overlaps and boundary violations."""
    squares = clip_to_unit(squares)
    side_sum = sum(s[3] for s in squares)
    ov = total_overlap(squares)
    # Boundary penalty
    bound_pen = 0.0
    for cx, cy, ang, side in squares:
        h = side / 2.0
        c = abs(math.cos(2 * math.pi * ang))
        s = abs(math.sin(2 * math.pi * ang))
        bx = c * h + s * h
        by = s * h + c * h
        if cx - bx < -1e-9:
            bound_pen += (bx - cx)
        if cx + bx > 1.0 + 1e-9:
            bound_pen += (cx + bx - 1.0)
        if cy - by < -1e-9:
            bound_pen += (by - cy)
        if cy + by > 1.0 + 1e-9:
            bound_pen += (cy + by - 1.0)
    return side_sum - 1000.0 * ov - 1000.0 * bound_pen

def initial_solution(n):
    """Start with grid or recursive subdivision."""
    if n == 0:
        return []
    k = int(math.sqrt(n))
    if k * k == n:
        side = 1.0 / k
        return [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
    # Else: use k x k grid plus extra squares squeezed in gaps
    k = max(1, int(math.sqrt(n)))
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    # Fill extra squares with tiny sizes in random positions
    while len(squares) < n:
        squares.append((random.random(), random.random(), random.random(), 0.01))
    return squares[:n]

def perturb(squares, n):
    """Perturb the solution: move, rotate, or resize squares."""
    new_squares = list(squares)
    idx = random.randrange(n)
    cx, cy, ang, side = new_squares[idx]
    action = random.random()
    if action < 0.4:
        # Move
        cx += random.gauss(0, 0.05)
        cy += random.gauss(0, 0.05)
    elif action < 0.7:
        # Rotate
        ang += random.gauss(0, 0.1)
    else:
        # Resize
        side += random.gauss(0, 0.05)
        side = max(0.0, min(1.0, side))
    new_squares[idx] = (cx, cy, ang, side)
    return new_squares

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_score = -float('inf')

    # Multiple restarts
    for restart in range(8):
        current = initial_solution(n)
        current = clip_to_unit(current)
        current_score = evaluate(current)

        # Simulated annealing
        T = 0.5
        cooling = 0.9995
        for step in range(4000):
            candidate = perturb(current, n)
            candidate = clip_to_unit(candidate)
            cand_score = evaluate(candidate)

            if cand_score > current_score or random.random() < math.exp((cand_score - current_score) / max(T, 1e-6)):
                current = candidate
                current_score = cand_score

            T *= cooling

            if current_score > best_score:
                best_score = current_score
                best = list(current)

    # Final repair pass: ensure no overlaps by shrinking problematic squares
    if best is not None:
        for _ in range(50):
            best = clip_to_unit(best)
            changed = False
            for i in range(len(best)):
                for j in range(i + 1, len(best)):
                    if overlap_area(best[i], best[j]) > 0:
                        # Shrink the smaller one slightly
                        si = best[i][3]
                        sj = best[j][3]
                        if si < sj:
                            best[i] = (best[i][0], best[i][1], best[i][2], si * 0.9)
                        else:
                            best[j] = (best[j][0], best[j][1], best[j][2], sj * 0.9)
                        changed = True
            if not changed:
                break

    # Clean up and return
    result = []
    for cx, cy, ang, side in best[:n]:
        # final safety clip
        side = max(0.0, min(1.0, side))
        h = side / 2.0
        c = abs(math.cos(2 * math.pi * ang))
        s = abs(math.sin(2 * math.pi * ang))
        bx = c * h + s * h
        by = s * h + c * h
        cx = max(bx, min(1.0 - bx, cx))
        cy = max(by, min(1.0 - by, cy))
        result.append((cx, cy, ang, side))
    return result
