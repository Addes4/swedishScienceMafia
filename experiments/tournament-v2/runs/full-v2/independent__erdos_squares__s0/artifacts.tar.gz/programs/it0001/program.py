import math

# ---------------------------------------------------------------
# Helpers for exact constructions of a few special n
# ---------------------------------------------------------------

def _grid(k):
    s = 1.0 / k
    return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
            for i in range(k) for j in range(k)]


def _best_for_small(n):
    """Exact / near-exact constructions for small n."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two 0.5 squares side by side
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # one 0.5 square, two 0.5 squares stacked -> actually 3 squares of 0.5
        return [(0.25, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5),
                (0.75, 0.5, 0.0, 0.5)]
    if n == 4:
        return _grid(2)
    if n == 5:
        # four 0.5 squares + one in a corner (not possible), use best known approx:
        # 0.5,0.5,0.5,0.5 plus tiny -> 5 squares: use grid 3? no.
        # Known good: 4 of side 0.5 and a small one in the middle gap? middle is filled.
        # Use: two columns: left column split into 2, right column split into 3?
        # Try: squares of side 0.5,0.5,0.5,0.25,0.25? sum=2.0? Let's do 0.5*4 + 0.25*? 
        # Actually 5 squares: cut unit square into 1/2 x 1/2 grid (4 squares) then 
        # can't add. Use 5 squares: use a 1x1 split into 0.5 columns, then each 
        # column split unevenly to get 5: left column 2 squares (0.5x0.5 each),
        # right column 3 squares (0.5 x 1/3 each). Sum = 0.5*2 + 0.5*3? sides: 0.5,0.5 
        # (from 2 in left col) and 0.5? no, right col squares are 0.5 wide, 1/3 tall -> not squares.
        # Instead: use 0.5x0.5 (4 squares) and one more 0.5x0.5? impossible.
        # Known: best for n=5 is approx 1.5 + something. Let's just use grid(2)+tiny.
        g = _grid(2)
        g.append((0.5, 0.5, 0.0, 0.0))
        return g
    if n == 9:
        return _grid(3)
    if n == 16:
        return _grid(4)
    return None


# ---------------------------------------------------------------
# Collision test for axis-aligned squares (fast, conservative)
# ---------------------------------------------------------------

def _overlap_axis(cx1, cy1, s1, cx2, cy2, s2):
    """True if two axis-aligned squares with given centres and sides overlap
    interiors."""
    h1 = s1 * 0.5
    h2 = s2 * 0.5
    return (abs(cx1 - cx2) < h1 + h2 - 1e-12 and
            abs(cy1 - cy2) < h1 + h2 - 1e-12)


def _fits_in_unit(cx, cy, s):
    h = s * 0.5
    return (cx - h >= -1e-12 and cy - h >= -1e-12 and
            cx + h <= 1.0 + 1e-12 and cy + h <= 1.0 + 1e-12)


# ---------------------------------------------------------------
# Greedy placement: axis-aligned squares, largest first
# ---------------------------------------------------------------

def _greedy_axis(n, seed_grid=None):
    """Greedy: try to place axis-aligned squares at grid candidate positions,
    taking the largest that fits."""
    if seed_grid is None:
        seed_grid = []
    placed = list(seed_grid)

    # candidate centres: fine grid
    m = 60  # resolution
    cands = []
    for i in range(m + 1):
        for j in range(m + 1):
            if i == 0:
                x = 0.001
            elif i == m:
                x = 0.999
            else:
                x = i / m
            if j == 0:
                y = 0.001
            elif j == m:
                y = 0.999
            else:
                y = j / m
            cands.append((x, y))

    # We'll try to place the remaining squares
    remaining = n - len(placed)
    # For each remaining square, search for the largest square we can place.
    # Binary search on size.
    def can_place(cx, cy, s):
        if not _fits_in_unit(cx, cy, s):
            return False
        for (px, py, pa, ps) in placed:
            if ps <= 0:
                continue
            # placed is axis-aligned in this routine (angle 0)
            if _overlap_axis(cx, cy, s, px, py, ps):
                return False
        return True

    for _ in range(remaining):
        best_s = 0.0
        best_pos = (0.5, 0.5)
        # Try candidate positions, binary search size
        # To speed up, use a coarser candidate set for large n
        step = max(1, len(cands) // 800)
        for idx in range(0, len(cands), step):
            cx, cy = cands[idx]
            # quick: max possible side from boundaries
            max_s = min(cx, 1 - cx, cy, 1 - cy) * 2
            if max_s <= best_s:
                continue
            # binary search
            lo, hi = 0.0, max_s
            for _ in range(25):
                mid = (lo + hi) * 0.5
                if can_place(cx, cy, mid):
                    lo = mid
                else:
                    hi = mid
            if lo > best_s:
                best_s = lo
                best_pos = (cx, cy)
        if best_s <= 1e-9:
            placed.append((0.5, 0.5, 0.0, 0.0))
        else:
            placed.append((best_pos[0], best_pos[1], 0.0, best_s))

    return placed


# ---------------------------------------------------------------
# Rotated-square collision test (general: two convex polygons)
# ---------------------------------------------------------------

def _square_corners(cx, cy, ang, s):
    """Corners of a square (angle in turns)."""
    h = s * 0.5
    c = math.cos(2 * math.pi * ang)
    sn = math.sin(2 * math.pi * ang)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        px = cx + dx * c - dy * sn
        py = cy + dx * sn + dy * c
        pts.append((px, py))
    return pts


def _polygons_overlap(p1, p2):
    """SAT for two convex polygons (lists of points)."""
    for poly in (p1, p2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            nx, ny = -(y2 - y1), (x2 - x1)
            # axis
            min1 = min(px * nx + py * ny for px, py in p1)
            max1 = max(px * nx + py * ny for px, py in p1)
            min2 = min(px * nx + py * ny for px, py in p2)
            max2 = max(px * nx + py * ny for px, py in p2)
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return False
    return True


def _inside_unit(poly):
    for x, y in poly:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


# ---------------------------------------------------------------
# Tiling-with-rotations: try to improve by splitting remaining space
# ---------------------------------------------------------------

def _fill_rotated(placed, n, iters=2000):
    """Try to add rotated squares in remaining space via local search."""
    import random
    random.seed(12345)

    def can_place(cx, cy, ang, s):
        if s <= 0:
            return True
        poly = _square_corners(cx, cy, ang, s)
        if not _inside_unit(poly):
            return False
        for (px, py, pa, ps) in placed:
            if ps <= 0:
                continue
            ppoly = _square_corners(px, py, pa, ps)
            if _polygons_overlap(poly, ppoly):
                return False
        return True

    # For each missing square, try random placements and keep the best
    while len(placed) < n:
        best_s = 0.0
        best = (0.5, 0.5, 0.0)
        for _ in range(iters // max(1, n - len(placed)) + 200):
            cx = random.random()
            cy = random.random()
            ang = random.random()
            # quick bound
            if not can_place(cx, cy, ang, 1e-6):
                # maybe try tiny, still fine
                pass
            # binary search size
            lo, hi = 0.0, 1.0
            for _ in range(20):
                mid = (lo + hi) * 0.5
                if can_place(cx, cy, ang, mid):
                    lo = mid
                else:
                    hi = mid
            if lo > best_s:
                best_s = lo
                best = (cx, cy, ang)
        placed.append((best[0], best[1], best[2], best_s))

    return placed


# ---------------------------------------------------------------
# Main solver
# ---------------------------------------------------------------

def solve(n):
    """Return n squares (cx, cy, angle, side) inside unit square,
    disjoint interiors, maximise sum of sides."""
    if n <= 0:
        return []

    # exact constructions
    exact = _best_for_small(n)
    if exact is not None:
        return exact

    # Greedy axis-aligned for all n
    placed = _greedy_axis(n)

    # For moderately large n, try to improve with rotated fill of remaining
    # (but axis-aligned greedy already fills well for large n)

    # Final safety: clip all to unit square and ensure validity approximately
    result = []
    for (cx, cy, ang, s) in placed:
        if s <= 1e-12:
            result.append((0.5, 0.5, 0.0, 0.0))
            continue
        # clip center
        h = s * 0.5
        cx = min(max(cx, h), 1.0 - h)
        cy = min(max(cy, h), 1.0 - h)
        result.append((cx, cy, ang, s))

    # ensure exactly n
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]


# quick self-test (not used in scoring)
if __name__ == "__main__":
    for nn in [1, 2, 3, 4, 5, 9, 16, 7, 10, 20]:
        res = solve(nn)
        tot = sum(s for (_, _, _, s) in res)
        print(nn, "sum=", round(tot, 4), "count=", len(res))
