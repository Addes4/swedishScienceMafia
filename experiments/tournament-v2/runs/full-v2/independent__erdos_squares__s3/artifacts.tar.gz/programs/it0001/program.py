import math
import random


def _overlap(c1, c2):
    """Return True if two squares' interiors intersect."""
    x1, y1, a1, s1 = c1
    x2, y2, a2, s2 = c2
    if s1 <= 0.0 or s2 <= 0.0:
        return False
    # separating axis theorem for two squares
    a1r = a1 * 2.0 * math.pi
    a2r = a2 * 2.0 * math.pi
    c1x, c1y = math.cos(a1r), math.sin(a1r)
    c2x, c2y = math.cos(a2r), math.sin(a2r)

    def axes(x, y):
        # unit local axes of a square with rotation (x, y)=(cos,sin)
        return ((x, y), (-y, x))

    def extents(cx, cy, s, ax, ay):
        # projection half-extent of a square centered (cx, cy) side s on (ax, ay)
        ax1x, ax1y = ax, ay
        # local axes rotated by square angle unknown here; handled in caller
        return None

    def proj(cx, cy, ar, s, ax, ay):
        ca, sa = math.cos(ar), math.sin(ar)
        # square axes
        ux, uy = ca, sa
        vx, vy = -sa, ca
        # half-projection: s/2*(|u·a| + |v·a|)
        return abs(ux * ax + uy * ay) * s / 2.0 + abs(vx * ax + vy * ay) * s / 2.0

    # Test axes: normals of both squares
    axes_list = []
    for ar in (a1r, a2r):
        ca, sa = math.cos(ar), math.sin(ar)
        axes_list.append((ca, sa))
        axes_list.append((-sa, ca))

    for ax, ay in axes_list:
        p1 = proj(x1, y1, a1r, s1, ax, ay)
        p2 = proj(x2, y2, a2r, s2, ax, ay)
        d = abs((x2 - x1) * ax + (y2 - y1) * ay)
        if d >= p1 + p2 - 1e-12:
            return False
    return True


def _inside(c):
    x, y, a, s = c
    if s <= 0.0:
        return 0.0 <= x <= 1.0 and 0.0 <= y <= 1.0
    ar = a * 2.0 * math.pi
    ca, sa = math.cos(ar), math.sin(ar)
    # half extents in x and y
    hx = s / 2.0 * (abs(ca) + abs(sa))
    hy = s / 2.0 * (abs(ca) + abs(sa))
    return (x - hx >= -1e-12 and x + hx <= 1.0 + 1e-12 and
            y - hy >= -1e-12 and y + hy <= 1.0 + 1e-12)


def _fits(c, placed):
    if not _inside(c):
        return False
    for p in placed:
        if _overlap(c, p):
            return False
    return True


def _max_side_at(x, y, a, placed, limit):
    """Binary search the largest side <= limit fitting at (x,y,a)."""
    lo, hi = 0.0, limit
    if not _fits((x, y, a, 0.0), placed):
        return 0.0
    for _ in range(40):
        mid = (lo + hi) * 0.5
        if _fits((x, y, a, mid), placed):
            lo = mid
        else:
            hi = mid
    return lo


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    random.seed(12345 + n)

    placed = []

    # Step 1: greedy largest-square packing on a fine candidate set.
    # Candidate centres from a grid plus boundaries.
    angles = [0.0, 0.125, 0.25, 0.375]
    # weight axis-aligned heavily
    angles = [0.0] * 4 + angles

    def candidate_points(k):
        pts = []
        for i in range(k + 1):
            for j in range(k + 1):
                pts.append((i / k, j / k))
        # midpoints and random
        for _ in range(k * k):
            pts.append((random.random(), random.random()))
        return pts

    # Determine number of real squares to try: all n but last few can be zero.
    # Greedily place squares reducing size.
    remaining = n
    target_sizes = []

    # Initial guess: place squares until no room, using decreasing side limits.
    # We'll do iterative greedy: at each step choose placement with max side.
    for step in range(n):
        best = None
        best_s = 0.0
        limit = 1.0
        # try axis aligned first with fine grid
        k = 12 if step < 40 else 8
        pts = candidate_points(k)
        # also consider centers adjacent to placed squares
        extra = []
        for p in placed:
            px, py, pa, ps = p
            d = ps if ps > 0 else 0.1
            for ang in (0.0, 0.25):
                for dx, dy in ((d, 0), (-d, 0), (0, d), (0, -d), (d, d), (-d, -d), (d, -d), (-d, d)):
                    extra.append((px + dx * 0.5, py + dy * 0.5))
        pts.extend(extra)
        # local search around best found
        for (x, y) in pts:
            for a in angles:
                if not (0.0 <= x <= 1.0 and 0.0 <= y <= 1.0):
                    continue
                s = _max_side_at(x, y, a, placed, limit)
                if s > best_s:
                    best_s = s
                    best = (x, y, a, s)
        if best is None or best_s <= 1e-9:
            # no more room, add zero-size squares
            placed.extend([(0.5, 0.5, 0.0, 0.0)] * (n - len(placed)))
            break
        placed.append(best)

    # Step 2: local refinement — jiggle positions/sizes/angles to increase sum.
    def total_sum(pl):
        return sum(p[3] for p in pl)

    best_pl = list(placed)
    best_val = total_sum(best_pl)

    # Coordinate descent: for each square, try to expand and shift.
    for _ in range(3):
        improved = False
        for idx in range(len(best_pl)):
            others = best_pl[:idx] + best_pl[idx + 1:]
            cur = best_pl[idx]
            cx, cy, ca, cs = cur
            if cs <= 0:
                # try to place a small square in a gap
                candidates = []
                for _ in range(60):
                    candidates.append((random.random(), random.random(), random.choice(angles)))
                for x, y, a in candidates:
                    s = _max_side_at(x, y, a, others, 0.3)
                    if s > cs + 1e-9:
                        best_pl[idx] = (x, y, a, s)
                        improved = True
                        break
                continue

            # search local perturbations
            best_local = cur
            best_s = cs
            for _ in range(50):
                nx = min(1.0, max(0.0, cx + random.uniform(-0.08, 0.08)))
                ny = min(1.0, max(0.0, cy + random.uniform(-0.08, 0.08)))
                na = ca + random.choice([-0.02, -0.01, 0.0, 0.01, 0.02])
                na = na % 1.0
                limit = min(1.0, cs + 0.12)
                s = _max_side_at(nx, ny, na, others, limit)
                if s > best_s + 1e-9:
                    best_s = s
                    best_local = (nx, ny, na, s)
            if best_s > cs + 1e-9:
                best_pl[idx] = best_local
                improved = True
        new_val = total_sum(best_pl)
        if new_val > best_val + 1e-9:
            best_val = new_val
            improved = True
        if not improved:
            break

    # ensure exactly n
    while len(best_pl) < n:
        best_pl.append((0.5, 0.5, 0.0, 0.0))
    best_pl = best_pl[:n]
    # clamp sizes to fit
    out = []
    for (x, y, a, s) in best_pl:
        s = max(0.0, min(1.0, s))
        x = max(0.0, min(1.0, x))
        y = max(0.0, min(1.0, y))
        a = a % 1.0
        out.append((x, y, a, s))
    return out
