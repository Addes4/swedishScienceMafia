import math
import random
import numpy as np

EPS = 1e-9


def _squares_for_n(n):
    """Return list of (cx, cy, angle, side) for a good deterministic packing."""
    if n <= 0:
        return []
    k = int(math.floor(math.sqrt(n)))
    out = []
    if k * k == n:
        s = 1.0 / k
        for i in range(k):
            for j in range(k):
                out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        return out

    # le = k*k, rem = n - k*k
    # We try to fit rem extra squares by splitting some cells into halves,
    # either vertically, horizontally, or with a mixed pattern.
    best = None
    best_score = -1.0

    # Strategy A: use k+1 columns for rows 0..r-1 and k columns below.
    # Actually do: choose number of rows R, each row has some number of squares.
    # For equal side in a row of m squares: side = 1/m.
    # Overall sum = sum_rows side_row.
    # We need sum_rows m_row = n and each m_row <= some max.
    # Rigorous simple family: rows with counts in {k, k+1,...}.
    for R in range(1, n + 1):
        base = n // R
        rem = n % R
        if base == 0:
            continue
        # rem rows have base+1 squares, rest have base squares
        if base >= 1:
            side_big = 1.0 / (base + 1)
            side_small = 1.0 / base
            total = rem * side_big + (R - rem) * side_small
            if total > best_score:
                best_score = total
                best = (R, base, rem)

    # Strategy B: a full grid of size k, but replace some cells with 4 smaller squares?
    # That's covered partially by rows above if we choose larger R.
    # Also try column-based with widths equal.
    for C in range(1, n + 1):
        base = n // C
        rem = n % C
        if base == 0:
            continue
        side_big = 1.0 / (base + 1)
        side_small = 1.0 / base
        total = rem * side_big + (C - rem) * side_small
        if total > best_score:
            best_score = total
            best = (C, base, rem)
            # mark orientation
            best = ('col', C, base, rem) if False else ('row', C, base, rem)

    # Recompute best properly
    best = None
    best_score = -1.0

    # horizontal strips: row i has m_i squares side 1/m_i, height 1/?? Actually rows can have different heights.
    # To keep simple: rows have height = 1/R, each row's squares have side = 1/m_i, need side <= 1/R.
    # So m_i >= R. sum m_i = n. Sum side = sum 1/m_i.
    # For fixed R, maximize sum with m_i >= R and sum m_i = n.
    # Convex: make m_i as unequal as possible: one row big, others = R? Actually 1/x convex -> want extremes.
    # But need m_i <= ? no upper bound inside row, side = 1/m_i, height constraint side <= 1/R means m_i >= R ok.
    # But width: m_i * (1/m_i) = 1 ok.
    # So with R rows: put as many squares as possible in one row, others minimal R.
    # Let n = q*R + r, 0<=r<R. We can have r rows with R+1? No, better: one row gets n - (R-1)*R squares, rest R.
    if n >= 1:
        for R in range(1, n + 1):
            min_rest = (R - 1) * R
            if min_rest > n:
                continue
            big = n - min_rest
            if big < R:
                # all rows equal-ish
                m = n // R
                rem = n % R
                cnt = {}
                for i in range(R):
                    cnt[m + (1 if i < rem else 0)] = cnt.get(m + (1 if i < rem else 0), 0) + 1
                # not needed, just use formula
                total = rem * (1.0 / (m + 1)) + (R - rem) * (1.0 / m)
                if total > best_score:
                    best_score = total
                    best = ('rows', R, [m + 1] * rem + [m] * (R - rem))
            else:
                m = [R] * R
                m[-1] = big
                total = sum(1.0 / x for x in m)
                if total > best_score:
                    best_score = total
                    best = ('rows', R, m)

        # vertical strips analogous. But by symmetry similar. We'll just use rows.

    # Build the layout from best
    if best is None:
        # fallback
        k = max(1, int(math.floor(math.sqrt(n))))
        s = 1.0 / k
        out = []
        for i in range(k):
            for j in range(k):
                out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                if len(out) == n:
                    return out
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        return out

    typ, R, ms = best
    # rows
    heights = [1.0 / R] * R
    y0 = 0.0
    out = []
    for i, m in enumerate(ms):
        h = heights[i]
        side = min(1.0 / m, h)
        # center row
        cy = y0 + h / 2.0
        # distribute m squares across width 1
        if m == 0:
            y0 += h
            continue
        w = 1.0 / m
        for j in range(m):
            cx = (j + 0.5) * w
            out.append((cx, cy, 0.0, side))
        y0 += h
    assert len(out) == n, (len(out), n)
    return out


def _overlap_area_penalty(squares):
    """Sum of overlap areas between pairs."""
    total = 0.0
    n = len(squares)
    # approximate via rotated squares: use separating axis sampling (corners + midpoints)
    for i in range(n):
        xi, yi, ai, si = squares[i]
        if si <= 0:
            continue
        ci, si_ = math.cos(ai), math.sin(ai)
        # corners of square i
        hx = si / 2.0
        pts_i = []
        for dx, dy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            px = xi + dx * hx * ci - dy * hx * si_
            py = yi + dx * hx * si_ + dy * hx * ci
            pts_i.append((px, py))
        for j in range(i + 1, n):
            xj, yj, aj, sj = squares[j]
            if sj <= 0:
                continue
            cj, sj_ = math.cos(aj), math.sin(aj)
            hx = sj / 2.0
            pts_j = []
            for dx, dy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                px = xj + dx * hx * cj - dy * hx * sj_
                py = yj + dx * hx * sj_ + dy * hx * cj
                pts_j.append((px, py))
            # check via polygon clipping? too heavy for many. Use SAT for convex polys.
            # SAT: project onto axes of both squares.
            axes = []
            for a in (ai, aj):
                ca, sa = math.cos(a), math.sin(a)
                axes.append((ca, sa))
                axes.append((-sa, ca))
            overlap = True
            min_overlap = float('inf')
            for (ax, ay) in axes:
                # projection of i
                pi = [px * ax + py * ay for (px, py) in pts_i]
                pj = [px * ax + py * ay for (px, py) in pts_j]
                mini = min(pi); maxi = max(pi)
                minj = min(pj); maxj = max(pj)
                if maxi <= minj + 1e-12 or maxj <= mini + 1e-12:
                    overlap = False
                    break
                ov = min(maxi - minj, maxj - mini)
                if ov < min_overlap:
                    min_overlap = ov
            if overlap:
                total += min_overlap * min_overlap  # rough area-like penalty
    return total


def _refine(squares, n, time_budget=5.0):
    """Improve via random perturbations and growth."""
    squares = [list(s) for s in squares]
    # objective: sum sides - big penalty for out-of-bounds and overlap
    # We'll do simple coordinate/angle descent with random restarts.

    def clamp_all(sq):
        for s in sq:
            s[0] = min(max(s[0], 0.0), 1.0)
            s[1] = min(max(s[1], 0.0), 1.0)
            # angle normalize to [0,1)
            s[2] = s[2] % 1.0
            s[3] = max(s[3], 0.0)

    def score(sq):
        # check containment: all corners inside [0,1]^2
        bad = 0.0
        for (x, y, a, s) in sq:
            if s <= 0:
                continue
            hx = s / 2.0
            ca, sa = math.cos(a), math.sin(a)
            for dx, dy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                px = x + dx * hx * ca - dy * hx * sa
                py = y + dx * hx * sa + dy * hx * ca
                if px < -1e-9:
                    bad += (0 - px) ** 2
                if px > 1 + 1e-9:
                    bad += (px - 1) ** 2
                if py < -1e-9:
                    bad += (0 - py) ** 2
                if py > 1 + 1e-9:
                    bad += (py - 1) ** 2
        ov = _overlap_area_penalty(sq)
        total = sum(s[3] for s in sq)
        return total - 100.0 * bad - 100.0 * ov

    clamp_all(squares)
    cur = score(squares)
    best = [s[:] for s in squares]
    best_score = cur

    # try growing sides
    improved = True
    it = 0
    while improved and it < 200:
        improved = False
        it += 1
        for k in range(n):
            # try increase side
            old = squares[k][3]
            if old < 1.0 - 1e-9:
                delta = 0.01 * (1.0 - old) + 1e-4
                squares[k][3] = min(1.0, old + delta)
                clamp_all(squares)
                sc = score(squares)
                if sc > cur + 1e-9:
                    cur = sc
                    improved = True
                    if cur > best_score:
                        best_score = cur
                        best = [s[:] for s in squares]
                else:
                    squares[k][3] = old

            # try small moves
            for dim in (0, 1, 2):
                oldv = squares[k][dim]
                for step in (0.01, -0.01, 0.003, -0.003):
                    squares[k][dim] = oldv + step
                    clamp_all(squares)
                    sc = score(squares)
                    if sc > cur + 1e-9:
                        cur = sc
                        improved = True
                        if cur > best_score:
                            best_score = cur
                            best = [s[:] for s in squares]
                        oldv = squares[k][dim]
                    else:
                        squares[k][dim] = oldv
        # occasionally try random restart of one square
    return [tuple(s) for s in best]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    base = _squares_for_n(n)
    # refine
    try:
        refined = _refine(base, n, time_budget=4.0)
    except Exception:
        refined = base
    # ensure exactly n and valid
    out = []
    for s in refined[:n]:
        out.append(tuple(s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
