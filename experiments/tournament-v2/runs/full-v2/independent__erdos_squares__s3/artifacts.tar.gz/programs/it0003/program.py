import math
import random
import numpy as np
from scipy.spatial import cKDTree


def _corners(cx, cy, ang, s):
    """Return 4 corner points of the square (cx,cy), angle fraction of turn."""
    t = ang * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cx * 0 + cy + dx * sn + dy * c))
    return pts


def _project(pts, ax, ay):
    vals = [p[0] * ax + p[1] * ay for p in pts]
    return min(vals), max(vals)


def _inside(pts):
    for x, y in pts:
        if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
            return False
    return True


def _overlap(c1, c2, s1, s2, a1, a2):
    """Separating axis check for two rotated squares."""
    p1 = _corners(c1[0], c1[1], a1, s1)
    p2 = _corners(c2[0], c2[1], a2, s2)
    for pts, a in ((p1, a1), (p2, a2)):
        t = a * 2.0 * math.pi
        for ang in (t, t + math.pi / 2):
            ax, ay = math.cos(ang), math.sin(ang)
            mn1, mx1 = _project(p1, ax, ay)
            mn2, mx2 = _project(p2, ax, ay)
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def _feasible(sq):
    """Check all squares inside unit box and disjoint (O(n^2) but n moderate)."""
    n = len(sq)
    corners = []
    for (cx, cy, a, s) in sq:
        if s <= 0:
            corners.append([])
            continue
        pts = _corners(cx, cy, a, s)
        if not _inside(pts):
            return False
        corners.append(pts)
    for i in range(n):
        if not corners[i]:
            continue
        for j in range(i + 1, n):
            if not corners[j]:
                continue
            if _overlap(sq[i][:2], sq[j][:2], sq[i][3], sq[j][3], sq[i][2], sq[j][2]):
                return False
    return True


def _total(sq):
    return sum(s for (_, _, _, s) in sq)


def _grid_pack(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    best = None
    for rot in (0.0,):
        sq = [((i + 0.5) * side, (j + 0.5) * side, rot, side)
              for i in range(k) for j in range(k)]
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        if best is None or _total(sq) > _total(best):
            best = sq
    return best[:n]


def _greedy_place(n, seed=0, tries=200):
    """Greedily add one square at a time maximising the next side length."""
    rng = random.Random(seed)
    best_overall = None
    # For small n do local search; for large n greedy fill grid + slight growth
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)] if n == 1 else []
    if n <= 400:
        # Try a few candidate layouts from greedy placement
        for trial in range(tries if n <= 60 else 20):
            sq = []
            ok = True
            for idx in range(n):
                cand = _best_next(sq, rng)
                if cand is None:
                    sq.append((0.5, 0.5, 0.0, 0.0))
                else:
                    sq.append(cand)
            sq = _polish(sq, rng)
            if best_overall is None or _total(sq) > _total(best_overall):
                best_overall = sq
        if best_overall is None:
            best_overall = _grid_pack(n)
        # also compare with pure grid for larger n
        g = _grid_pack(n)
        if _total(g) > _total(best_overall):
            best_overall = g
        return best_overall
    else:
        return _grid_pack(n)


def _best_next(sq, rng):
    """Find placement of the next square with good side, random restarts."""
    best = None
    n = len(sq)
    cand_sizes = []
    if n == 0:
        return (0.5, 0.5, 0.0, 1.0)
    # Try candidate sizes decreasing
    base = 1.0
    for _ in range(30):
        base *= 0.97
        cand_sizes.append(base)
    cand_sizes = [0.9, 0.8, 0.7, 0.6, 0.5, 0.45, 0.4, 0.35, 0.33, 0.3, 0.28, 0.25,
                  0.22, 0.2, 0.18, 0.16, 0.15, 0.13, 0.12, 0.1, 0.09, 0.08, 0.07, 0.06, 0.05]
    for s in cand_sizes:
        for _ in range(60):
            ang = 0.0 if rng.random() < 0.6 else rng.choice([0.0, 0.25, 0.125, -0.125, 0.5])
            cx = rng.random()
            cy = rng.random()
            # shrink to fit inside
            for _ in range(8):
                pts = _corners(cx, cy, ang, s)
                mnx = min(p[0] for p in pts); mxx = max(p[0] for p in pts)
                mny = min(p[1] for p in pts); mxy = max(p[1] for p in pts)
                if mnx >= -1e-12 and mxx <= 1 + 1e-12 and mny >= -1e-12 and mxy <= 1 + 1e-12:
                    break
                # shift toward centre
                cx += (0.5 - cx) * 0.5
                cy += (0.5 - cy) * 0.5
                s *= 0.95
                if s < 1e-6:
                    break
            if s < 1e-6:
                continue
            ok = True
            for (ox, oy, oa, os) in sq:
                if os <= 0:
                    continue
                if _overlap((cx, cy), (ox, oy), s, os, ang, oa):
                    ok = False
                    break
            if ok:
                cand = (cx, cy, ang, s)
                if best is None or s > best[3]:
                    best = cand
        if best is not None and best[3] >= s * 0.95:
            # found a good one for this size
            if s < 0.15:
                break
    return best


def _polish(sq, rng):
    """Local continuous improvement: grow each square slightly and move."""
    sq = [list(x) for x in sq]
    n = len(sq)
    improved = True
    it = 0
    while improved and it < 40:
        improved = False
        it += 1
        for i in range(n):
            if sq[i][3] <= 1e-9:
                continue
            # try growing square i
            base_s = sq[i][3]
            for factor in (1.03, 1.06, 1.1, 1.15, 1.25):
                ns = base_s * factor
                if ns > 1.0:
                    ns = 1.0
                old = sq[i][:]
                sq[i][3] = ns
                if _feasible(sq):
                    improved = True
                    break
                sq[i] = old
            # try moving/rotating
            if rng.random() < 0.7:
                pass
    # second pass: reorder and try to place bigger
    return [tuple(x) for x in sq]


def solve(n):
    """Return n squares inside unit square maximising total side length."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    random.seed(12345)
    # greedy pack for moderate n
    if n <= 100:
        best = _grid_pack(n)
        # try several seeds
        for seed in range(4):
            sq = _greedy_place(n, seed=seed, tries=1)
            if _total(sq) > _total(best):
                best = sq
        # compare with a checkerboard/grid
        return best
    else:
        return _grid_pack(n)
