import math
import random
import time


def solve(n):
    end = time.time() + 55.0
    best = None
    best_score = -1.0

    def consider(sqs):
        nonlocal best, best_score
        if len(sqs) < n:
            return
        sqs = sqs[:n]
        # strict feasibility check: all inside and pairwise interior-disjoint
        for cx, cy, a, s in sqs:
            if s < 0:
                return
            if s == 0:
                if not (0 <= cx <= 1 and 0 <= cy <= 1):
                    return
                continue
            c = math.cos(a * 2 * math.pi)
            sn = math.sin(a * 2 * math.pi)
            r = s * 0.5
            # half-extent in x and y
            ex = r * (abs(c) + abs(sn))
            ey = r * (abs(c) + abs(sn))
            if cx - ex < -1e-12 or cx + ex > 1 + 1e-12:
                return
            if cy - ey < -1e-12 or cy + ey > 1 + 1e-12:
                return
        # SAT check between pairs
        for i in range(len(sqs)):
            cx1, cy1, a1, s1 = sqs[i]
            if s1 == 0:
                continue
            for j in range(i + 1, len(sqs)):
                cx2, cy2, a2, s2 = sqs[j]
                if s2 == 0:
                    continue
                if not _disjoint(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
                    return
        sc = sum(x[3] for x in sqs)
        if sc > best_score + 1e-12:
            best_score = sc
            best = [list(x) for x in sqs]

    # ---------- structured candidates ----------

    # uniform grid
    k = max(1, math.isqrt(n))
    if k * k <= n:
        s = 1.0 / k
        g = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        g += [(0.5, 0.5, 0.0, 0.0)] * (n - len(g))
        consider(g)

    # grid with rows of varying count (near-square rectangles)
    for rows in range(1, 40):
        cols = (n + rows - 1) // rows
        if cols <= 0:
            continue
        s = min(1.0 / cols, 1.0 / rows)
        g = []
        for r in range(rows):
            for c in range(cols):
                if len(g) < n:
                    g.append(((c + 0.5) * s, (r + 0.5) * s, 0.0, s))
        g += [(0.5, 0.5, 0.0, 0.0)] * (n - len(g))
        consider(g)

    # single big square plus small squares in remaining strips
    for kx in range(1, 8):
        for ky in range(1, 8):
            total = kx * ky
            if total < 1:
                continue
            # try big square side b, rest filled in L-shape by grid
            for bnum in range(1, 20):
                b = bnum / 20.0
                if b <= 0 or b > 1:
                    continue
                cells = []
                # right strip
                rw = 1.0 - b
                if rw > 1e-9:
                    sc = max(1, kx)
                    sr = max(1, ky)
                    sw = rw / sc
                    sh = 1.0 / sr
                    s = min(sw, sh)
                    if s > 0:
                        for i in range(sc):
                            for j in range(sr):
                                cells.append((b + (i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                # top strip
                th = 1.0 - b
                if th > 1e-9:
                    sc = max(1, kx)
                    sr = max(1, ky)
                    sw = 1.0 / sc
                    sh = th / sr
                    s = min(sw, sh)
                    if s > 0:
                        for i in range(sc):
                            for j in range(sr):
                                cells.append(((i + 0.5) * s, b + (j + 0.5) * s, 0.0, s))
                cells.append((b / 2.0, b / 2.0, 0.0, b))
                if len(cells) >= n:
                    consider(cells)

    # rotation grid variants
    for k in range(1, 25):
        if k * k > n:
            continue
        s = 1.0 / k
        if s <= 0:
            continue
        for ang in (0.0, 0.1, 0.2, 0.25, 0.3, 0.4, 0.5):
            g = []
            c = math.cos(ang * 2 * math.pi)
            sn = math.sin(ang * 2 * math.pi)
            R = s * 0.5 * (abs(c) + abs(sn))
            ok = True
            if R > 0.5 + 1e-12:
                ok = False
            if ok:
                for i in range(k):
                    for j in range(k):
                        cx = (i + 0.5) * s
                        cy = (j + 0.5) * s
                        g.append((cx, cy, ang, s))
                g += [(0.5, 0.5, 0.0, 0.0)] * (n - len(g))
                consider(g)

    # randomized packer - grow squares greedily in free space
    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
        best_score = 0.0

    deadline = end
    rng = random.Random(12345 + n)
    iters = 0
    while time.time() < deadline and iters < 20000:
        iters += 1
        # seed with current best, then random perturbation: try to add one more small square
        cand = [list(x) for x in best]
        # attempt: reduce all by tiny factor and insert new square in largest gap
        try:
            # random greedy: place n squares by choosing sizes descending
            k = 2 + rng.randrange(max(1, min(12, n)))
            base = 1.0 / k
            sizes = []
            for i in range(n):
                f = rng.uniform(0.5, 1.0)
                sizes.append(base * f)
            sizes.sort(reverse=True)
            placed = []
            for s in sizes:
                placed = _try_insert(placed, s, rng)
                if placed is None:
                    break
            if placed is not None and len(placed) == n:
                consider(placed)
        except Exception:
            pass

        # local search on best
        if best is not None:
            cand = [list(x) for x in best]
            # perturb one square
            for _ in range(3):
                i = rng.randrange(n)
                cx, cy, a, s = cand[i]
                if s > 0:
                    ns = s * rng.uniform(0.9, 1.1)
                    na = a + rng.uniform(-0.05, 0.05)
                    ncx = cx + rng.uniform(-0.02, 0.02)
                    ncy = cy + rng.uniform(-0.02, 0.02)
                    cand[i] = [min(max(ncx, 0), 1), min(max(ncy, 0), 1), na, max(0.0, ns)]
            consider([tuple(x) for x in cand])

    return [(float(x[0]), float(x[1]), float(x[2]), float(x[3])) for x in best]


def _corners(cx, cy, a, s):
    c = math.cos(a * 2 * math.pi)
    sn = math.sin(a * 2 * math.pi)
    r = s * 0.5
    pts = [(-r, -r), (r, -r), (r, r), (-r, r)]
    out = []
    for x, y in pts:
        out.append((cx + x * c - y * sn, cy + x * sn + y * c))
    return out


def _axes(a):
    c = math.cos(a * 2 * math.pi)
    sn = math.sin(a * 2 * math.pi)
    return [(c, sn), (-sn, c)]


def _disjoint(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    axes = _axes(a1) + _axes(a2)
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)
    for ax, ay in axes:
        min1 = min(p[0] * ax + p[1] * ay for p in p1)
        max1 = max(p[0] * ax + p[1] * ay for p in p1)
        min2 = min(p[0] * ax + p[1] * ay for p in p2)
        max2 = max(p[0] * ax + p[1] * ay for p in p2)
        if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
            return True
    return False


def _try_insert(placed, s, rng):
    # try random candidates for a square of side s, then return placed+s or None
    for _ in range(40):
        cx = rng.uniform(s * 0.5, 1 - s * 0.5)
        cy = rng.uniform(s * 0.5, 1 - s * 0.5)
        a = 0.0
        ok = True
        for (px, py, pa, ps) in placed:
            if not _disjoint(cx, cy, a, s, px, py, pa, ps):
                ok = False
                break
        if ok:
            return placed + [(cx, cy, a, s)]
    return None
