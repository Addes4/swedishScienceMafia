# EVOLVE-BLOCK-START
"""Hybrid: dense interval plus greedy Sidon-style perturbation, optimizing ratio."""
import math
import random
import time


def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return (math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, n)


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    # Try several base widths; dense interval has small |A+A| ~ 2*range, but small |A-A|.
    # We want many differences: use a Sidon-ish set spread over a wider range while
    # keeping sums distinct-ish but bounded.
    for trial in range(60):
        if time.time() > deadline:
            break
        # base: random dense-ish set in [0, W]
        W = random.choice([8, 12, 16, 20, 24, 32, 40])
        k = random.choice([6, 8, 10, 12, 14])
        A = set()
        while len(A) < k:
            A.add(random.randint(0, W))
        A = sorted(A)
        score, _ = _score_fast(A)
        if score > best_score:
            best, best_score = A[:], score

    # Local search polish: single-element moves
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice([-2, -1, 1, 2])
        if len(set(cand)) < len(cand):
            continue
        s, _ = _score_fast(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.02:
            cur, cur_score = cand, s
    return sorted(set(best))
# EVOLVE-BLOCK-END
