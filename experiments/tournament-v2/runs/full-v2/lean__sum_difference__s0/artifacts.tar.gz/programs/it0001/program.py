# EVOLVE-BLOCK-START
"""Construction: long arithmetic progression plus sparse distinct powers of two
offsets to blow up the difference set while keeping the sum set fairly small."""
import math


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A with large |A-A| and small |A+A|."""
    n = 600
    a = list(range(n))

    # Add sparse, very large, distinct offsets to a subset of positions.
    # Using powers of two times a huge base B makes most pairwise differences
    # distinct (many new difference values) while most sums remain in a
    # relatively narrow range around B.
    B = 10 ** 8
    k = 12  # number of perturbed elements
    for i in range(k):
        pos = (i * (n // k)) % n
        a[pos] += (2 ** i) * B

    return sorted(set(a))
# EVOLVE-BLOCK-END

