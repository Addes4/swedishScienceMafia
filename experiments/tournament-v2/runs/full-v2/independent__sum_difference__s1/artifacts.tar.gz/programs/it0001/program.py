import math
import random
import time

# ---------------------------------------------------------------
#  The ratio to maximise is   log|A-A| / log|A+A|  (+ tiny bonus)
#  The key is that for many structured sets, |A+A| can be made
#  surprisingly small while |A-A| stays large.
#
#  We use a two-part construction:
#     B  = a dense interval  (all differences up to ~|B|)
#     C  = a sparse Sidon-like / geometric-ish set
#  A = B union C, then local search.
# ---------------------------------------------------------------


def _diffs(a):
    s = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            s.add(ai - a[j])
    return s


def _sums(a):
    s = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            s.add(ai + a[j])
    return s


def score(a):
    a = sorted(set(a))
    if len(a) < 2:
        return 0.0, 0, 0
    d = _diffs(a)
    s = _sums(a)
    if len(s) == 0:
        return 0.0, 0, 0
    val = math.log(len(d)) / math.log(len(s))
    val += (1.0 - 1.0 / len(a)) / 100.0
    return val, len(d), len(s)


def solve():
    random.seed(12345)
    best_A = None
    best_val = -1.0

    # ---- phase 1: try several structured seeds -----------------
    deadline = time.time() + 110.0

    def try_set(a, budget=3.0):
        nonlocal best_A, best_val
        a = sorted(set(int(x) for x in a))
        if len(a) < 2:
            return
        v, nd, ns = score(a)
        if v > best_val:
            best_val = v
            best_A = a[:]

        # local search: move / add / remove / shift
        end = time.time() + budget
        cur = a[:]
        curval = v
        while time.time() < end:
            cand = cur[:]
            op = random.random()
            if op < 0.45 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-2, -1, 1, 2, 3, -3,
                                          5, -5, 8, -8])
            elif op < 0.70:
                lo = min(cand) - 20
                hi = max(cand) + 20
                cand.append(random.randint(lo, hi))
            elif op < 0.85 and len(cand) > 4:
                i = random.randrange(len(cand))
                cand.pop(i)
            else:
                k = random.randint(1, 4)
                for _ in range(k):
                    i = random.randrange(len(cand))
                    cand[i] += random.choice([-1, 1])

            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cv, _, _ = score(cand)
            if cv >= curval or random.random() < 0.03:
                cur, curval = cand, cv
                if cv > best_val:
                    best_val = cv
                    best_A = cand[:]
        return

    # seed 1: dense interval + geometric tail
    for L in [8, 12, 16, 20, 26, 32, 40, 50]:
        base = list(range(1, L + 1))
        # add a few large spread points to enlarge difference set
        extra = []
        x = L + 1
        for _ in range(10):
            extra.append(x)
            x *= 2
        try_set(base + extra, budget=2.0)
        if time.time() > deadline:
            break

    # seed 2: interval + powers of 2 slightly offset
    for L in [10, 16, 24, 36, 48]:
        base = list(range(0, L))
        extra = []
        x = L
        for _ in range(14):
            extra.append(x)
            x = x * 2 + random.randint(0, 3)
        try_set(base + extra, budget=2.0)
        if time.time() > deadline:
            break

    # seed 3: interval + multiples of a big step
    for L in [12, 20, 30, 42]:
        base = list(range(0, L))
        extra = [random.randint(-10**6, 10**6) for _ in range(18)]
        extra = sorted(set(extra))
        try_set(base + extra, budget=2.0)
        if time.time() > deadline:
            break

    # ---- phase 2: long local search from the best found --------
    if best_A is None:
        best_A = [0, 1, 3, 7, 15, 31]
        best_val, _, _ = score(best_A)

    cur = best_A[:]
    curval = best_val
    end = time.time() + 100.0
    stall = 0
    while time.time() < end:
        cand = cur[:]
        op = random.random()
        if op < 0.40 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice(
                [-100, -50, -20, -10, -5, -3, -2, -1,
                 1, 2, 3, 5, 10, 20, 50, 100])
        elif op < 0.65:
            lo = min(cand) - 1000
            hi = max(cand) + 1000
            cand.append(random.randint(lo, hi))
        elif op < 0.82 and len(cand) > 5:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # shift whole block
            delta = random.randint(-1000, 1000)
            cand = [x + delta for x in cand]

        cand = sorted(set(int(x) for x in cand))
        # keep size reasonable for speed
        if len(cand) > 800:
            cand = cand[:400] + cand[-400:]
            cand = sorted(set(cand))
        if len(cand) < 3:
            continue

        cv, nd, ns = score(cand)
        if cv >= curval or random.random() < 0.02:
            cur, curval = cand, cv
            if cv > best_val:
                best_val = cv
                best_A = cand[:]
        # occasionally restart from best
        if random.random() < 0.001:
            cur = best_A[:]
            curval = best_val

    return sorted(set(int(x) for x in best_A))
