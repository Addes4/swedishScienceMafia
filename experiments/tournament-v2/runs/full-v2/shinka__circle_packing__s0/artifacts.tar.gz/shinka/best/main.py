# EVOLVE-BLOCK-START
"""Circle packing via joint centre/radius optimisation (SLSQP).

Formulation (classical, cf. Graham & Lubachevsky and the ShinkaEvolve
circle_packing example): maximise sum(r_i) subject to
    r_i + r_j <= ||c_i - c_j||        (pairwise)
    r_i       <= c_i.x, c_i.y, 1-c_i.x, 1-c_i.y   (walls)
We solve the equivalent penalty problem
    minimise  -sum(r_i) + mu * sum_violation^2
with SLSQP from several random starts, then run a strict shrink-repair so
the returned configuration is guaranteed feasible.
"""
import numpy as np
from scipy.optimize import minimize


def _initial_configs(n, seed=0):
    """A handful of diverse starting layouts (hex-like + jittered random)."""
    rng = np.random.default_rng(seed)
    configs = []
    # Hexagonal-ish grid
    best_cols = None
    for cols in range(1, n + 1):
        rows = int(np.ceil(n / cols))
        if best_cols is None or rows <= best_cols[1]:
            best_cols = (cols, rows)
    cols, rows = best_cols
    pts = []
    for r in range(rows):
        for c in range(cols):
            if len(pts) >= n:
                break
            x = (c + 0.5 + 0.5 * (r % 2)) / cols
            y = (r + 0.5) / rows
            pts.append([x, y])
    configs.append(np.array(pts[:n]))
    # Concentric rings (baseline style)
    base = [[0.5, 0.5]]
    base += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8),
              0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    base += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16),
              0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    base += [[rng.random(), rng.random()] for _ in range(n - len(base))]
    configs.append(np.clip(np.array(base[:n]), 0.02, 0.98))
    # Random jittered configs
    for _ in range(4):
        configs.append(np.clip(rng.random((n, 2)), 0.02, 0.98))
    return configs


def _pack_objective(z, n, mu):
    """Penalty objective over z = [x_0..,y_0.., r_0..]."""
    c = z[:2 * n].reshape(n, 2)
    r = z[2 * n:]
    # Wall slack: r_i <= dist to each wall. Violation >= 0.
    vx = np.maximum(r - c[:, 0], 0.0)
    vy = np.maximum(r - c[:, 1], 0.0)
    vX = np.maximum(r - (1.0 - c[:, 0]), 0.0)
    vY = np.maximum(r - (1.0 - c[:, 1]), 0.0)
    # Pairwise slack: r_i + r_j <= d
    diff = c[:, None, :] - c[None, :, :]
    d = np.sqrt((diff ** 2).sum(-1))
    np.fill_diagonal(d, 1.0)
    viol = np.maximum(r[:, None] + r[None, :] - d, 0.0)
    iu = np.triu_indices(n, 1)
    pv = viol[iu]
    pen = mu * (vx @ vx + vy @ vy + vX @ vX + vY @ vY + pv @ pv)
    return -r.sum() + pen


def _pack_grad(z, n, mu):
    c = z[:2 * n].reshape(n, 2)
    r = z[2 * n:]
    g = np.zeros_like(z)
    # d(-sum r)/dr
    g[2 * n:] -= 1.0
    # Wall penalties
    for wall_vec, sign in ((c[:, 0], +1.0), (c[:, 1], +1.0),
                           (1.0 - c[:, 0], -1.0), (1.0 - c[:, 1], -1.0)):
        viol = np.maximum(r - wall_vec, 0.0)
        active = viol > 0
        if np.any(active):
            g[2 * n:][active] += 2 * mu * viol[active]
            # d/dc: -sign * 2*mu*viol for the corresponding coordinate
            if sign > 0:
                # wall at 0: d(dist)/dc = +1 for x/y
                comp = 0 if wall_vec is c[:, 0] else 1
                g[comp::2][active] += 2 * mu * viol[active]
            else:
                comp = 0 if wall_vec is (1.0 - c[:, 0]) or np.array_equal(wall_vec, 1.0 - c[:, 0]) else 1
                # fallback: recompute below
    # Recompute wall grads cleanly (avoid identity confusion)
    g[:2 * n] = 0.0
    for comp in (0, 1):
        v0 = np.maximum(r - c[:, comp], 0.0)
        v1 = np.maximum(r - (1.0 - c[:, comp]), 0.0)
        g[2 * n:] += 2 * mu * v0 + 2 * mu * v1
        g[comp::2] += 2 * mu * v0 - 2 * mu * v1
    # Pairwise
    diff = c[:, None, :] - c[None, :, :]
    d = np.sqrt((diff ** 2).sum(-1))
    np.fill_diagonal(d, 1.0)
    viol = np.maximum(r[:, None] + r[None, :] - d, 0.0)
    iu = np.triu_indices(n, 1)
    pv = viol[iu]
    if pv.size:
        ii, jj = iu
        # d/dr_i (+), d/dr_j (+)
        np.add.at(g[2 * n:], ii, 2 * mu * pv)
        np.add.at(g[2 * n:], jj, 2 * mu * pv)
        # d/dc_i = -2*mu*viol * (c_i - c_j)/d  (for pair i,j)
        dij = d[ii, jj]
        dij = np.where(dij < 1e-12, 1e-12, dij)
        coef = 2 * mu * pv / dij
        dc = coef[:, None] * (c[ii] - c[jj])
        np.add.at(g[:2 * n].reshape(n, 2), ii, dc)
        np.add.at(g[:2 * n].reshape(n, 2), jj, -dc)
    return g


def max_radii(centers):
    """Largest radii for fixed centres: start from wall distance, then shrink overlaps."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                s = radii[i] + radii[j]
                if s > d and s > 0:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _resolve_overlaps(centers, radii, iters=60, step=0.6):
    """Push overlapping circles apart (and off walls) while keeping radii fixed.
    Returns a feasible-ish configuration (centres only)."""
    c = centers.copy()
    n = len(c)
    for _ in range(iters):
        moved = False
        # pairwise repulsion
        for i in range(n):
            for j in range(i + 1, n):
                diff = c[i] - c[j]
                d = np.sqrt((diff * diff).sum())
                target = radii[i] + radii[j]
                if d < target and d > 1e-12:
                    push = (target - d) * 0.5 * step
                    c[i] += push * diff / d
                    c[j] -= push * diff / d
                    moved = True
        # wall repulsion
        for i in range(n):
            r = radii[i]
            if c[i, 0] - r < 0:
                c[i, 0] += (r - c[i, 0]) * step
                moved = True
            if c[i, 0] + r > 1:
                c[i, 0] -= (c[i, 0] + r - 1) * step
                moved = True
            if c[i, 1] - r < 0:
                c[i, 1] += (r - c[i, 1]) * step
                moved = True
            if c[i, 1] + r > 1:
                c[i, 1] -= (c[i, 1] + r - 1) * step
                moved = True
        c = np.clip(c, 0.0, 1.0)
        if not moved:
            break
    return c


def _inflate(centers, radii, growth=0.02, outer=40, inner=30):
    """Billiards/inflation: repeatedly scale radii up, then re-project centres.
    Radii never shrink. Returns (centers, radii) of the best feasible config."""
    c = centers.copy()
    r = radii.copy()
    # ensure feasible start
    r = max_radii(c)
    best_c, best_r = c.copy(), r.copy()
    best_s = r.sum()
    for _ in range(outer):
        r = r * (1.0 + growth)
        c = _resolve_overlaps(c, r, iters=inner, step=0.7)
        # after projection, shrink any residual overlaps strictly
        r2 = max_radii(c)
        # if r2 < r, the projection wasn't enough; accept shrunk version
        s = r2.sum()
        if s > best_s:
            best_s = s
            best_c, best_r = c.copy(), r2.copy()
        # restart inflation from best feasible to avoid drift
        c, r = best_c.copy(), best_r.copy()
    return best_c, best_r


def solve(n=26):
    """Return (centers, radii) for n disjoint circles in the unit square,
    maximising sum of radii."""
    rng = np.random.default_rng(12345)
    best_sum = -np.inf
    best_c = None
    best_r = None

    def unpack(z):
        c = z[:2 * n].reshape(n, 2)
        r = np.maximum(z[2 * n:], 0.0)
        return c, r

    for c0 in _initial_configs(n, seed=0):
        c0 = np.clip(c0, 0.02, 0.98)
        r0 = max_radii(c0)
        z0 = np.concatenate([c0.ravel(), r0])
        for mu in (1e3, 1e4):
            try:
                res = minimize(_pack_objective, z0, args=(n, mu),
                               jac=_pack_grad, method="L-BFGS-B",
                               options={"maxiter": 500, "ftol": 1e-12})
                z0 = res.x
            except Exception:
                break
        c, r = unpack(z0)
        c = np.clip(c, 0.0, 1.0)
        # Strict repair: shrink radii so no overlaps, then re-grow via max_radii
        r = max_radii(c)
        s = r.sum()
        if s > best_sum:
            best_sum = s
            best_c = c.copy()
            best_r = r.copy()

    # Local random restarts to escape local optima
    for _ in range(6):
        c0 = np.clip(rng.random((n, 2)), 0.02, 0.98)
        r0 = max_radii(c0)
        z0 = np.concatenate([c0.ravel(), r0])
        for mu in (1e3, 1e4, 1e5):
            try:
                res = minimize(_pack_objective, z0, args=(n, mu),
                               jac=_pack_grad, method="L-BFGS-B",
                               options={"maxiter": 400, "ftol": 1e-12})
                z0 = res.x
            except Exception:
                break
        c, r = unpack(z0)
        c = np.clip(c, 0.0, 1.0)
        r = max_radii(c)
        s = r.sum()
        if s > best_sum:
            best_sum = s
            best_c = c.copy()
            best_r = r.copy()

    # Inflation refinement on the best SLSQP result and on several random starts
    if best_c is not None:
        c_inf, r_inf = _inflate(best_c, best_r, growth=0.02, outer=60, inner=40)
        if r_inf.sum() > best_sum:
            best_sum = r_inf.sum()
            best_c, best_r = c_inf, r_inf

    for trial in range(8):
        seed = 777 + trial
        cc = np.clip(np.random.default_rng(seed).random((n, 2)), 0.05, 0.95)
        rr = max_radii(cc)
        c_inf, r_inf = _inflate(cc, rr, growth=0.025, outer=60, inner=40)
        if r_inf.sum() > best_sum:
            best_sum = r_inf.sum()
            best_c, best_r = c_inf, r_inf

    if best_c is None:
        c0 = np.clip(np.random.default_rng(0).random((n, 2)), 0.02, 0.98)
        return c0, max_radii(c0)
    return best_c, np.maximum(best_r, 0.0)
# EVOLVE-BLOCK-END