# EVOLVE-BLOCK-START
"""Circle packing via a physics-based jammed packing simulation.

Algorithm (Lubachevsky–Stillinger style):
  1. Start with n points in the unit square (random or structured).
  2. Assign small radii and let them grow slowly while we resolve
     overlaps by moving circles apart (repulsive dynamics).
  3. When a circle cannot grow further without overlapping, it stops
     growing.  Continue until all circles are jammed.
  4. Add stochastic "kicks" (random displacements) to escape local
     minima, then re-run the growth phase.

The result is a dense, jammed packing that typically beats gradient-based
methods on this problem, and is much faster per restart so we can try many.
"""
import numpy as np


def _random_layout(n, rng):
    """Random points inside the square with a small margin."""
    return rng.random((n, 2)) * 0.9 + 0.05


def _hex_layout(n):
    """Hexagonal grid layout."""
    pts = []
    rows = int(np.ceil(np.sqrt(n)))
    cols = int(np.ceil(n / rows))
    for r in range(rows):
        for c in range(cols):
            x = (c + 0.5 * (r % 2)) / cols
            y = (r + 0.5) / rows
            pts.append([x, y])
    pts = np.array(pts[:n])
    return np.clip(pts, 0.02, 0.98)


def _ring_layout(n):
    """Concentric rings layout."""
    centers = [[0.5, 0.5]]
    ring_counts = [6, 12, 18, 24, 30]
    ring_radii = [0.22, 0.36, 0.42, 0.45, 0.47]
    for k, (cnt, rad) in enumerate(zip(ring_counts, ring_radii)):
        for i in range(cnt):
            ang = 2 * np.pi * i / cnt + 0.2 * k
            centers.append([0.5 + rad * np.cos(ang), 0.5 + rad * np.sin(ang)])
    centers = np.array(centers[:n])
    return np.clip(centers, 0.02, 0.98)


def _simulate(centers, n, rng, growth_steps=400, dt=0.35, kick_scale=0.0):
    """Run the jammed packing simulation.

    Returns (centers, radii).
    """
    centers = centers.copy().astype(float)
    # initial small radii
    radii = np.full(n, 1e-3)

    # velocities for dynamics
    vel = np.zeros((n, 2))

    # pre-allocate pair index arrays
    iu, ju = np.triu_indices(n, k=1)

    # global growth rate
    grow = 0.0008

    for step in range(growth_steps):
        # --- compute pairwise overlaps and forces ---
        dx = centers[iu, 0] - centers[ju, 0]
        dy = centers[iu, 1] - centers[ju, 1]
        dist = np.sqrt(dx * dx + dy * dy) + 1e-12
        overlap = radii[iu] + radii[ju] - dist

        # repulsive force (only when overlapping)
        fx = np.zeros(n)
        fy = np.zeros(n)
        active = overlap > 0
        if np.any(active):
            # normal direction
            nx = dx[active] / dist[active]
            ny = dy[active] / dist[active]
            # force magnitude proportional to overlap
            mag = overlap[active] * 2.0
            np.add.at(fx, iu[active], nx * mag)
            np.add.at(fy, iu[active], ny * mag)
            np.add.at(fx, ju[active], -nx * mag)
            np.add.at(fy, ju[active], -ny * mag)

        # wall repulsion (only when circle is close to a wall)
        for i in range(n):
            r = radii[i]
            x, y = centers[i]
            if x - r < 0:
                fx[i] += (r - x) * 2.0
            if y - r < 0:
                fy[i] += (r - y) * 2.0
            if 1 - x - r < 0:
                fx[i] -= (r - (1 - x)) * 2.0
            if 1 - y - r < 0:
                fy[i] -= (r - (1 - y)) * 2.0

        # random kicks (for escaping local minima)
        if kick_scale > 0:
            fx += rng.normal(0, kick_scale, n)
            fy += rng.normal(0, kick_scale, n)

        # velocity update (damping)
        vel = 0.85 * vel + dt * np.stack([fx, fy], axis=1)
        centers += vel * dt

        # keep inside square (hard clamp with small margin)
        centers[:, 0] = np.clip(centers[:, 0], 1e-6, 1 - 1e-6)
        centers[:, 1] = np.clip(centers[:, 1], 1e-6, 1 - 1e-6)

        # --- growth step: try to increase all radii ---
        # compute maximum allowed radius for each circle given current positions
        # wall limit
        wall_max = np.minimum.reduce([
            centers[:, 0], centers[:, 1],
            1 - centers[:, 0], 1 - centers[:, 1]
        ])
        # neighbor limit: half distance to nearest neighbor
        if n > 1:
            # compute nearest neighbor distance
            dmat = np.sqrt(
                (centers[:, None, 0] - centers[None, :, 0]) ** 2 +
                (centers[:, None, 1] - centers[None, :, 1]) ** 2
            )
            np.fill_diagonal(dmat, np.inf)
            nn = dmat.min(axis=1)
            neighbor_max = nn / 2.0
        else:
            neighbor_max = np.full(n, 0.5)
        allowed = np.minimum(wall_max, neighbor_max)
        # grow radii toward allowed, but never shrink below current
        target = radii + grow
        radii = np.minimum(target, allowed)
        # ensure non-negative
        radii = np.maximum(radii, 1e-6)

    # final repair: shrink any remaining overlaps (should be rare)
    for _ in range(200):
        changed = False
        # wall
        for i in range(n):
            lim = min(centers[i, 0], centers[i, 1],
                      1 - centers[i, 0], 1 - centers[i, 1])
            if radii[i] > lim:
                radii[i] = lim
                changed = True
        # pairs
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                s = radii[i] + radii[j]
                if s > d and s > 0:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break

    return centers, np.maximum(radii, 0.0)


def solve(n=26):
    """Return (centers, radii) maximising sum of radii for n disjoint circles."""
    rng = np.random.default_rng(12345)

    best_centers = None
    best_radii = None
    best_sum = -1.0

    # Build a diverse set of initial layouts
    layouts = []
    layouts.append(_hex_layout(n))
    layouts.append(_ring_layout(n))
    for _ in range(10):
        layouts.append(_random_layout(n, rng))

    # Run the physics simulation from each layout
    for init in layouts:
        c, r = _simulate(init, n, rng, growth_steps=350, dt=0.30)
        s = float(np.sum(r))
        if s > best_sum:
            best_sum = s
            best_centers, best_radii = c.copy(), r.copy()

    # Stochastic refinement: perturb the best and re-simulate
    for trial in range(15):
        if best_centers is None:
            break
        # perturb: random kicks + small shrink
        c = best_centers.copy()
        r = best_radii.copy()
        # shrink radii a bit to make room
        r = r * 0.92
        # random displacement
        kick = rng.normal(0, 0.015, (n, 2))
        c = np.clip(c + kick, 0.02, 0.98)
        c2, r2 = _simulate(c, n, rng, growth_steps=250, dt=0.25, kick_scale=0.0005)
        s = float(np.sum(r2))
        if s > best_sum:
            best_sum = s
            best_centers, best_radii = c2.copy(), r2.copy()

    # Final local refinement: try growing radii with fixed centers
    if best_centers is not None:
        c = best_centers
        r = best_radii
        for _ in range(500):
            # compute allowed radii
            wall_lim = np.minimum.reduce([
                c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]
            ])
            # nearest neighbor distances
            dmat = np.sqrt(
                (c[:, None, 0] - c[None, :, 0]) ** 2 +
                (c[:, None, 1] - c[None, :, 1]) ** 2
            )
            np.fill_diagonal(dmat, np.inf)
            nn = dmat.min(axis=1)
            # for each circle, allowed radius is min over its neighbors of (d - r_j)
            # iterative refinement
            prev = r.copy()
            # use a max-min approach: each circle can grow until it touches
            # the nearest neighbor's current radius
            for i in range(n):
                # find nearest neighbor
                j = np.argmin(dmat[i])
                d = dmat[i, j]
                # allowed so that r_i + r_j <= d
                allowed = d - r[j]
                if allowed < wall_lim[i]:
                    r[i] = min(r[i], allowed)
                else:
                    r[i] = min(r[i], wall_lim[i])
            # then try to grow uniformly
            grow_amount = 0.0005
            wall_lim = np.minimum.reduce([
                c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]
            ])
            # recompute allowed after neighbor shrink
            for i in range(n):
                j = np.argmin(dmat[i])
                d = dmat[i, j]
                allowed = d - r[j]
                r[i] = min(r[i] + grow_amount, allowed, wall_lim[i])
            r = np.maximum(r, 0.0)
            if np.all(np.abs(r - prev) < 1e-9):
                break
        best_radii = r

    if best_centers is None:
        # fallback
        c = rng.random((n, 2)) * 0.8 + 0.1
        r = np.full(n, 0.01)
        best_centers, best_radii = c, r

    return best_centers, best_radii
# EVOLVE-BLOCK-END