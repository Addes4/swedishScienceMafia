# EVOLVE-BLOCK-START
"""Hybrid circle packing: vectorised repair + SLSQP + momentum gradient polish."""
import numpy as np
from scipy.optimize import minimize


# ----------------------------------------------------------------------------
# Vectorised feasibility repair
# ----------------------------------------------------------------------------
def max_radii(centers):
    """Largest radii for fixed centres: start from wall distance, then
    iteratively shrink every overlapping pair (vectorised)."""
    centers = np.asarray(centers, dtype=float)
    n = centers.shape[0]
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1.0 - centers[:, 0], 1.0 - centers[:, 1]])
    radii = np.maximum(radii, 0.0)
    for _ in range(400):
        diff = centers[:, None, :] - centers[None, :, :]
        d = np.sqrt((diff ** 2).sum(-1))
        np.fill_diagonal(d, np.inf)
        s = radii[:, None] + radii[None, :]
        viol = s - d
        iu = np.triu_indices(n, 1)
        v = viol[iu]
        if not np.any(v > 1e-12):
            break
        scale = np.where(v > 1e-12, d[iu] / np.maximum(s[iu], 1e-300), 1.0)
        ii, jj = iu
        fac = np.ones(n)
        np.minimum.at(fac, ii, scale)
        np.minimum.at(fac, jj, scale)
        radii = radii * fac
        if np.all(fac > 1.0 - 1e-12):
            break
    return np.maximum(radii, 0.0)


# ----------------------------------------------------------------------------
# Vectorised overlap/wall resolution (billiards projection)
# ----------------------------------------------------------------------------
def _resolve_overlaps(centers, radii, iters=250, step=0.6):
    """Push overlapping circles apart and off walls (radii fixed).
    Fully vectorised for speed."""
    c = np.asarray(centers, dtype=float).copy()
    n = c.shape[0]
    r = np.asarray(radii, dtype=float)
    for _ in range(iters):
        # pairwise repulsion
        diff = c[:, None, :] - c[None, :, :]
        d = np.sqrt((diff ** 2).sum(-1))
        np.fill_diagonal(d, np.inf)
        s = r[:, None] + r[None, :]
        overlap = np.maximum(s - d, 0.0)
        np.fill_diagonal(overlap, 0.0)
        moved = False
        if np.any(overlap > 1e-12):
            d_safe = np.where(d < 1e-12, 1e-12, d)
            push = 0.5 * step * overlap / d_safe
            # centre i gets pushed along +diff, centre j along -diff
            contrib = (push[:, :, None] * diff).sum(axis=1)
            c = c + contrib
            moved = True
        # wall repulsion
        x, y = c[:, 0], c[:, 1]
        lx = np.maximum(r - x, 0.0)
        rx = np.maximum(x + r - 1.0, 0.0)
        by = np.maximum(r - y, 0.0)
        ty = np.maximum(y + r - 1.0, 0.0)
        if np.any((lx + rx + by + ty) > 1e-12):
            c[:, 0] += (lx - rx) * step
            c[:, 1] += (by - ty) * step
            moved = True
        np.clip(c, 0.0, 1.0, out=c)
        if not moved:
            break
    return c


def _inflate(centers, radii, growth=0.02, outer=80, inner=200):
    """Billiards-style inflation: grow radii, re-project centres, repeat.
    Radii never shrink within a trial. Returns best feasible (c, r)."""
    c = np.asarray(centers, dtype=float).copy()
    r = max_radii(c)
    best_c, best_r = c.copy(), r.copy()
    best_s = float(r.sum())
    for _ in range(outer):
        r = r * (1.0 + growth)
        c = _resolve_overlaps(c, r, iters=inner, step=0.7)
        r2 = max_radii(c)
        s = float(r2.sum())
        if s > best_s:
            best_s = s
            best_c, best_r = c.copy(), r2.copy()
        # restart from best feasible to avoid drift
        c, r = best_c.copy(), best_r.copy()
    return best_c, best_r


# ----------------------------------------------------------------------------
# Momentum gradient descent polish (vectorised)
# ----------------------------------------------------------------------------
def optimize_positions(centers, radii, steps=200, lr=0.005, momentum=0.9):
    """Gradient-based optimisation of positions to minimise overlap/wall penalty."""
    n = len(centers)
    centers = centers.copy()
    velocity = np.zeros_like(centers)

    for _ in range(steps):
        grad = np.zeros_like(centers)

        # Wall gradients (vectorised)
        x, y = centers[:, 0], centers[:, 1]
        r = radii
        left = np.maximum(r - x, 0.0)
        right = np.maximum(x + r - 1.0, 0.0)
        bot = np.maximum(r - y, 0.0)
        top = np.maximum(y + r - 1.0, 0.0)
        grad[:, 0] += -2.0 * left + 2.0 * right
        grad[:, 1] += -2.0 * bot + 2.0 * top

        # Pairwise overlap gradients (vectorised)
        diff = centers[:, None, :] - centers[None, :, :]
        d = np.sqrt((diff ** 2).sum(-1))
        np.fill_diagonal(d, np.inf)
        s = radii[:, None] + radii[None, :]
        overlap = np.maximum(s - d, 0.0)
        np.fill_diagonal(overlap, 0.0)
        if np.any(overlap > 0):
            d_safe = np.where(d < 1e-12, 1e-12, d)
            factor = -2.0 * overlap / d_safe
            # contribution to each particle
            g_pair = factor[:, :, None] * diff
            grad += g_pair.sum(axis=1)

        velocity = momentum * velocity - lr * grad
        centers = centers + velocity
        centers = np.clip(centers, 0.0, 1.0)

    return centers


# ----------------------------------------------------------------------------
# Diverse initial configurations
# ----------------------------------------------------------------------------
def _hex_grid(n, cols):
    rows = int(np.ceil(n / cols))
    pts = []
    for r in range(rows):
        for c in range(cols):
            if len(pts) >= n:
                break
            x = (c + 0.5 + 0.5 * (r % 2)) / cols
            y = (r + 0.5) / rows
            pts.append([x, y])
    return np.array(pts[:n])


def _ring_layout(n):
    base = [[0.5, 0.5]]
    k1 = min(8, n - 1)
    base += [[0.5 + 0.3 * np.cos(2 * np.pi * i / max(k1, 1)),
              0.5 + 0.3 * np.sin(2 * np.pi * i / max(k1, 1))]
             for i in range(k1)]
    k2 = n - len(base)
    if k2 > 0:
        base += [[0.5 + 0.7 * np.cos(2 * np.pi * i / max(k2, 1)),
                  0.5 + 0.7 * np.sin(2 * np.pi * i / max(k2, 1))]
                 for i in range(k2)]
    return np.array(base[:n])


def _spiral_layout(n):
    pts = [np.array([0.5, 0.5])]
    for i in range(1, n):
        t = i / max(n - 1, 1)
        ang = 2 * np.pi * 3.0 * t
        rad = 0.45 * np.sqrt(t)
        pts.append(np.array([0.5 + rad *np.cos(ang), 0.5 + rad * np.sin(ang)]))
    return np.array(pts)


def _initial_configs(n, seed=0):
    rng = np.random.default_rng(seed)
    configs = []
    cols_list = sorted(set([1, 2, 3, 4, 5, 6, 7, 8, n // 2, n]))
    for cols in cols_list:
        if cols < 1:
            continue
        configs.append(_hex_grid(n, cols))
    configs.append(_ring_layout(n))
    configs.append(_spiral_layout(n))
    for _ in range(4):
        pts = rng.random((n, 2))
        for k in range(min(4, n)):
            pts[k] = rng.random(2) * 0.15 + np.array([0.02, 0.02]) * (k % 2)
        configs.append(pts)
    for _ in range(8):
        configs.append(rng.random((n, 2)))
    return [np.clip(c, 0.02, 0.98) for c in configs]


# ----------------------------------------------------------------------------
# Bounds / constraints for SLSQP
# ----------------------------------------------------------------------------
def _make_bounds(n):
    return [(0.0, 1.0)] * (2 * n) + [(0.0, 0.5)] * n


def _pack_constraints(n):
    def g(z):
        c = z[:2 * n].reshape(n, 2)
        r = z[2 * n:]
        cons = []
        cons.append(c[:, 0] - r)
        cons.append(c[:, 1] - r)
        cons.append(1.0 - c[:, 0] - r)
        cons.append(1.0 - c[:, 1] - r)
        diff = c[:, None, :] - c[None, :, :]
        d = np.sqrt((diff ** 2).sum(-1))
        np.fill_diagonal(d, np.inf)
        s = r[:, None] + r[None, :]
        iu = np.triu_indices(n, 1)
        cons.append((d - s)[iu])
        return np.concatenate(cons)
    return [{"type": "ineq", "fun": g}]


def _pack_objective(z, n):
    return -float(np.sum(z[2 * n:]))


def _pack_grad(z, n):
    g = np.zeros_like(z)
    g[2 * n:] = -1.0
    return g


# ----------------------------------------------------------------------------
# Solve
# ----------------------------------------------------------------------------
def _run_slsqp(z0, n, maxiter, ftol):
    try:
        res = minimize(
            _pack_objective, z0, args=(n,),
            jac=_pack_grad, method="SLSQP",
            bounds=_make_bounds(n),
            constraints=_pack_constraints(n),
            options={"maxiter": maxiter, "ftol": ftol, "disp": False},
        )
        return res.x
    except Exception:
        return z0


def solve(n=26):
    rng = np.random.default_rng(20240517)
    best_sum = -np.inf
    best_c = None
    best_r = None

    def record(z):
        nonlocal best_sum, best_c, best_r
        c = np.clip(z[:2 * n].reshape(n, 2), 0.0, 1.0)
        r = max_radii(c)
        s = float(r.sum())
        if s > best_sum:
            best_sum = s
            best_c = c.copy()
            best_r = r.copy()

    configs = _initial_configs(n, seed=7)

    def record_cr(c, r):
        nonlocal best_sum, best_c, best_r
        c2 = np.clip(c, 0.0, 1.0)
        r2 = max_radii(c2)
        s = float(r2.sum())
        if s > best_sum:
            best_sum = s
            best_c = c2.copy()
            best_r = r2.copy()

    # --- Stage 1: inflation (billiards) on every diverse start ---
    # This is the primary, most productive engine for circle packing.
    for c0 in configs:
        c0 = np.clip(c0, 0.02, 0.98)
        r0 = max_radii(c0)
        # a couple of growth rates for robustness
        for growth in (0.015, 0.03):
            c_inf, r_inf = _inflate(c0, r0, growth=growth, outer=80, inner=200)
            record_cr(c_inf, r_inf)
        # SLSQP polish of the best-so-far on this start (cheap)
        z0 = np.concatenate([best_c.ravel(), best_r]) if best_c is not None \
            else np.concatenate([c0.ravel(), r0])
        z = _run_slsqp(z0, n, maxiter=300, ftol=1e-10)
        record(z)

    # --- Stage 2: inflation on random restarts ---
    for k in range(30):
        c0 = np.clip(rng.random((n, 2)), 0.02, 0.98)
        r0 = max_radii(c0)
        c_inf, r_inf = _inflate(c0, r0, growth=0.025, outer=100, inner=200)
        record_cr(c_inf, r_inf)

    # --- Stage 3: alternating SLSQP + inflation + momentum polish on the best ---
    if best_c is not None:
        for it in range(10):
            # SLSQP polish
            z0 = np.concatenate([best_c.ravel(), best_r])
            z = _run_slsqp(z0, n, maxiter=600, ftol=1e-12)
            c = np.clip(z[:2 * n].reshape(n, 2), 0.0, 1.0)
            r = max_radii(c)
            if r.sum() > best_sum:
                best_sum = float(r.sum())
                best_c = c.copy()
                best_r = r.copy()
            # inflation polish
            c_inf, r_inf = _inflate(best_c, best_r, growth=0.02,
                                    outer=120, inner=250)
            if r_inf.sum() > best_sum:
                best_sum = float(r_inf.sum())
                best_c = c_inf.copy()
                best_r = r_inf.copy()
            # momentum gradient polish
            c_pol = optimize_positions(best_c, best_r, steps=300, lr=0.003,
                                       momentum=0.9)
            r_pol = max_radii(c_pol)
            if r_pol.sum() > best_sum:
                best_sum = float(r_pol.sum())
                best_c = c_pol.copy()
                best_r = r_pol.copy()
            else:
                best_c = np.clip(best_c + 0.005 * rng.standard_normal(best_c.shape),
                                 0.0, 1.0)
                best_r = max_radii(best_c)
        best_r = max_radii(best_c)

    if best_c is None:
        c0 = np.clip(rng.random((n, 2)), 0.02, 0.98)
        return c0, max_radii(c0)
    return best_c, np.maximum(best_r, 0.0)
# EVOLVE-BLOCK-END