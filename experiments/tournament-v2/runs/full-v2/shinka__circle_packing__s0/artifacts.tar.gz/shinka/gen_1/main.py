# EVOLVE-BLOCK-START
"""Improved circle packing via soft-sphere relaxation and random restarts."""
import numpy as np


def max_radii(centers):
    """Largest radii for fixed centres: start from wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def compute_penalty(centers, radii):
    """Compute overlap and wall violation penalty."""
    n = len(centers)
    penalty = 0.0
    # Wall violations
    for i in range(n):
        x, y = centers[i]
        r = radii[i]
        if x - r < 0:
            penalty += (r - x) ** 2
        if x + r > 1:
            penalty += (x + r - 1) ** 2
        if y - r < 0:
            penalty += (r - y) ** 2
        if y + r > 1:
            penalty += (y + r - 1) ** 2
    # Overlaps
    for i in range(n):
        for j in range(i + 1, n):
            d = np.linalg.norm(centers[i] - centers[j])
            overlap = radii[i] + radii[j] - d
            if overlap > 0:
                penalty += overlap ** 2
    return penalty


def optimize_positions(centers, radii, steps=200, lr=0.01, momentum=0.9):
    """Gradient-based optimization of positions to minimize penalty."""
    n = len(centers)
    centers = centers.copy()
    velocity = np.zeros_like(centers)
    
    for step in range(steps):
        grad = np.zeros_like(centers)
        
        # Wall gradients
        for i in range(n):
            x, y = centers[i]
            r = radii[i]
            if x - r < 0:
                grad[i, 0] -= 2 * (r - x)
            if x + r > 1:
                grad[i, 0] += 2 * (x + r - 1)
            if y - r < 0:
                grad[i, 1] -= 2 * (r - y)
            if y + r > 1:
                grad[i, 1] += 2 * (y + r - 1)
        
        # Overlap gradients
        for i in range(n):
            for j in range(i + 1, n):
                diff = centers[i] - centers[j]
                d = np.linalg.norm(diff)
                if d < 1e-12:
                    d = 1e-12
                overlap = radii[i] + radii[j] - d
                if overlap > 0:
                    # d(overlap^2)/d(centers[i]) = 2*overlap * d(overlap)/d(centers[i])
                    # d(overlap)/d(centers[i]) = -diff/d
                    factor = -2 * overlap / d
                    grad[i] += factor * diff
                    grad[j] -= factor * diff
        
        # Momentum update
        velocity = momentum * velocity - lr * grad
        centers += velocity
        
        # Clip to [0,1]
        centers = np.clip(centers, 0.0, 1.0)
    
    return centers


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    best_sum = -1.0
    best_centers = None
    best_radii = None
    
    num_restarts = 10
    for restart in range(num_restarts):
        # Random initial centers
        np.random.seed(restart * 12345 + 42)
        centers = np.random.rand(n, 2) * 0.8 + 0.1
        
        # Initial radii
        radii = max_radii(centers)
        
        # Alternate between position optimization and radius recomputation
        for iteration in range(5):
            centers = optimize_positions(centers, radii, steps=100, lr=0.005, momentum=0.9)
            radii = max_radii(centers)
        
        total_radius = np.sum(radii)
        if total_radius > best_sum:
            best_sum = total_radius
            best_centers = centers.copy()
            best_radii = radii.copy()
    
    # Final refinement on best solution
    for _ in range(10):
        best_centers = optimize_positions(best_centers, best_radii, steps=200, lr=0.002, momentum=0.9)
        best_radii = max_radii(best_centers)
    
    return best_centers, best_radii
# EVOLVE-BLOCK-END
