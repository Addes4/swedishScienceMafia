# EVOLVE-BLOCK-START
"""Circle packing via constrained numerical optimization (SLSQP).

We maximize sum(r_i) subject to circles staying in the unit square and
non-overlapping.  Variables are (x_i, y_i, r_i) for each circle.  We use
analytic Jacobians for the objective and constraints, and run several
restarts from varied initial layouts, keeping the best feasible solution.
"""
import numpy as np
from scipy.optimize import minimize


def _initial_layouts(n):
    """Yield several initial (centers) layouts of size n."""
    layouts = []

    # 1) Concentric rings (current baseline style), several densities
    for n_rings in (2, 3, 4):
        centers = [[0.5, 0.5]]
        counts = [8, 16, 24, 32]
        radii = [0.25, 0.4, 0.42, 0.46]
        for k in range(n_rings):
            cnt = counts[k]
            rad = radii[k]
            for i in range(cnt):
                ang = 2 * np.pi * i / cnt + 0.13 * k
                centers.append([0.5 + rad * np.cos(ang), 0.5 + rad * np.sin(ang)])
        centers = np.array(centers[:n])
        layouts.append(centers)

    # 2) Hexagonal-ish grid
    for rows in range(3, 9):
        pts = []
        for r in range(rows):
            cols = int(np.ceil(n / rows))
            for c in range(cols):
                x = (c + 0.5 * (r % 2)) / cols
                y = (r + 0.5) / rows
                pts.append([x, y])
        pts = np.array(pts[:n])
        layouts.append(pts)

    # 3) Random jittered layouts
    rng = np.random.default_rng(0)
    for _ in range(4):
        pts = rng.random((n, 2)) * 0.8 + 0.1
        layouts.append(pts)

    return layouts


def _make_jacobian(n):
    """Build analytic Jacobian callables for objective and constraints."""
    nv = 3 * n

    def obj_jac(x):
        g = np.zeros(nv)
        g[2::3] = -1.0
        return g

    def wall_jac(x):
        # 4*n wall constraints, each on one variable
        J = np.zeros((4 * n, nv))
        for i in range(n):
            xi, yi, ri = 3 * i, 3 * i + 1, 3 * i + 2
            # x_i - r_i >= 0
            J[4 * i, xi] = 1.0
            J[4 * i, ri] = -1.0
            # y_i - r_i >= 0
            J[4 * i + 1, yi] = 1.0
            J[4 * i + 1, ri] = -1.0
            # 1 - x_i - r_i >= 0
            J[4 * i + 2, xi] = -1.0
            J[4 * i + 2, ri] = -1.0
            # 1 - y_i - r_i >= 0
            J[4 * i + 3, yi] = -1.0
            J[4 * i + 3, ri] = -1.0
        return J

    def pair_jac(x):
        m = n * (n - 1) // 2
        J = np.zeros((m, nv))
        k = 0
        for i in range(n):
            xi, yi, ri = 3 * i, 3 * i + 1, 3 * i + 2
            for j in range(i + 1, n):
                xj, yj, rj = 3 * j, 3 * j + 1, 3 * j + 2
                dx = x[xi] - x[xj]
                dy = x[yi] - x[yj]
                sr = x[ri] + x[rj]
                J[k, xi] = 2 * dx
                J[k, yi] = 2 * dy
                J[k, ri] = -2 * sr
                J[k, xj] = -2 * dx
                J[k, yj] = -2 * dy
                J[k, rj] = -2 * sr
                k += 1
        return J

    return obj_jac, wall_jac, pair_jac


def _pack(centers, iters=500):
    """Run SLSQP from initial centers, returning (centers, radii)."""
    n = len(centers)
    centers = np.clip(np.asarray(centers, dtype=float), 0.02, 0.98)

    # Feasible initial radii: min of wall distance and half nearest-neighbour distance
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    for i in range(n):
        for j in range(i + 1, n):
            d = np.linalg.norm(centers[i] - centers[j])
            radii[i] = min(radii[i], d / 2.0)
            radii[j] = min(radii[j], d / 2.0)
    radii = np.maximum(radii * 0.9, 1e-4)

    x0 = np.zeros(3 * n)
    x0[0::3] = centers[:, 0]
    x0[1::3] = centers[:, 1]
    x0[2::3] = radii

    obj_jac, wall_jac, pair_jac = _make_jacobian(n)

    def objective(x):
        return -np.sum(x[2::3])

    def wall_con(x):
        return np.concatenate([
            x[0::3] - x[2::3],
            x[1::3] - x[2::3],
            1.0 - x[0::3] - x[2::3],
            1.0 - x[1::3] - x[2::3],
        ])

    def pair_con(x):
        c = x.reshape(n, 3)
        cx, cy, cr = c[:, 0], c[:, 1], c[:, 2]
        out = []
        for i in range(n):
            dx = cx[i] - cx[i + 1:]
            dy = cy[i] - cy[i + 1:]
            sr = cr[i] + cr[i + 1:]
            out.append(dx * dx + dy * dy - sr * sr)
        return np.concatenate(out)

    constraints = [
        {"type": "ineq", "fun": wall_con, "jac": wall_jac},
        {"type": "ineq", "fun": pair_con, "jac": pair_jac},
    ]
    bounds = [(0.0, 1.0)] * (3 * n)
    for i in range(n):
        bounds[3 * i + 2] = (0.0, 0.5)

    try:
        res = minimize(objective, x0, method="SLSQP", jac=obj_jac,
                       bounds=bounds, constraints=constraints,
                       options={"maxiter": iters, "ftol": 1e-12})
        x = res.x
    except Exception:
        x = x0

    c = x.reshape(n, 3)
    centers_out = c[:, :2].copy()
    radii_out = np.maximum(c[:, 2], 0.0)

    # Repair small violations (numerical) using the old shrink heuristic
    for _ in range(200):
        changed = False
        for i in range(n):
            r = min(radii_out[i], centers_out[i, 0], centers_out[i, 1],
                    1 - centers_out[i, 0], 1 - centers_out[i, 1])
            if r < radii_out[i]:
                radii_out[i] = r
                changed = True
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers_out[i] - centers_out[j])
                s = radii_out[i] + radii_out[j]
                if s > d and s > 0:
                    scale = d / s
                    radii_out[i] *= scale
                    radii_out[j] *= scale
                    changed = True
        if not changed:
            break

    return centers_out, np.maximum(radii_out, 0.0)


def solve(n=26):
    """Return (centers, radii) maximising sum of radii for n disjoint circles."""
    best_centers, best_radii = None, None
    best_sum = -1.0

    for centers in _initial_layouts(n):
        c, r = _pack(centers)
        s = float(np.sum(r))
        if s > best_sum:
            best_sum = s
            best_centers, best_radii = c, r

    if best_centers is None:
        # Fallback
        centers = np.random.rand(n, 2) * 0.8 + 0.1
        best_centers, best_radii = _pack(centers)

    return best_centers, best_radii
# EVOLVE-BLOCK-END