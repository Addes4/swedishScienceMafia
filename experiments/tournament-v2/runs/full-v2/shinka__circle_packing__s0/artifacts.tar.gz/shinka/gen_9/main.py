# EVOLVE-BLOCK-START
"""Circle packing via a staged multi-scale pipeline.

Stages:
  1. seed_layouts(n)          -> diverse initial center sets
  2. seed_radii(centers)      -> feasible radii via wall + nearest-neighbour
  3. refine(x0, ...)          -> coarse SLSQP with active-set pair constraints
  4. inflate(centers, radii)  -> uniform radius growth + projection
  5. polish(x0, ...)          -> fine SLSQP with full pair constraints
  6. repair(centers, radii)   -> feasibility repair fallback

The best (centers, radii) over all restarts is returned.
"""
import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------------------
# Stage 1: seed layouts
# ---------------------------------------------------------------------------

def _hex_layout(n, rows):
    pts = []
    cols = int(np.ceil(n / rows))
    for r in range(rows):
        for c in range(cols):
            x = (c + 0.5 * (r % 2)) / cols
            y = (r + 0.5) / rows
            pts.append([x, y])
    return np.array(pts[:n])


def _ring_layout(n, n_rings, counts, radii, phase=0.0):
    centers = [[0.5, 0.5]]
    for k in range(n_rings):
        cnt = counts[k]
        rad = radii[k]
        for i in range(cnt):
            ang = 2 * np.pi * i / cnt + phase + 0.13 * k
            centers.append([0.5 + rad * np.cos(ang), 0.5 + rad * np.sin(ang)])
    return np.array(centers[:n])


def _spiral_layout(n):
    pts = []
    for i in range(n):
        t = i / max(n - 1, 1)
        ang = 2 * np.pi * 2.5 * t
        rad = 0.02 + 0.46 * np.sqrt(t)
        pts.append([0.5 + rad * np.cos(ang), 0.5 + rad * np.sin(ang)])
    return np.array(pts)


def seed_layouts(n):
    layouts = []
    # Hex grids of various aspect ratios
    for rows in (3, 4, 5, 6, 7, 8):
        layouts.append(_hex_layout(n, rows))
    # Concentric rings
    layouts.append(_ring_layout(n, 2, [8, 16, 24, 32], [0.25, 0.40, 0.42, 0.46]))
    layouts.append(_ring_layout(n, 3, [8, 16, 24, 32], [0.25, 0.40, 0.42, 0.46], phase=0.4))
    # Spiral
    layouts.append(_spiral_layout(n))
    # Jittered random
    rng = np.random.default_rng(12345)
    for _ in range(3):
        layouts.append(rng.random((n, 2)) * 0.8 + 0.1)
    return layouts


# ---------------------------------------------------------------------------
# Stage 2: initial feasible radii
# ---------------------------------------------------------------------------

def seed_radii(centers):
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    # nearest-neighbour distance based cap
    diff = centers[:, None, :] - centers[None, :, :]
    dist = np.sqrt((diff ** 2).sum(-1))
    np.fill_diagonal(dist, np.inf)
    nn = dist.min(axis=1)
    radii = np.minimum(radii, nn / 2.0)
    return np.maximum(radii * 0.9, 1e-4)


# ---------------------------------------------------------------------------
# Stage 3/5: SLSQP refinement with vectorized active-set pair constraints
# ---------------------------------------------------------------------------

def _pack_vars(x):
    c = x.reshape(-1, 3)
    return c[:, 0], c[:, 1], c[:, 2]


def _objective(x):
    return -np.sum(x[2::3])


def _obj_jac(x):
    g = np.zeros_like(x)
    g[2::3] = -1.0
    return g


def _wall_con(x):
    cx, cy, r = _pack_vars(x)
    return np.concatenate([cx - r, cy - r, 1.0 - cx - r, 1.0 - cy - r])


def _wall_jac(x):
    n = len(x) // 3
    nv = 3 * n
    J = np.zeros((4 * n, nv))
    idx = np.arange(n)
    xi = 3 * idx
    yi = 3 * idx + 1
    ri = 3 * idx + 2
    J[4 * idx,     xi] = 1.0;  J[4 * idx,     ri] = -1.0
    J[4 * idx + 1, yi] = 1.0;  J[4 * idx + 1, ri] = -1.0
    J[4 * idx + 2, xi] = -1.0; J[4 * idx + 2, ri] = -1.0
    J[4 * idx + 3, yi] = -1.0; J[4 * idx + 3, ri] = -1.0
    return J


def _make_pair_closures(pairs_i, pairs_j, n):
    """Return (fun, jac) for non-overlap constraints on the given index pairs."""
    nv = 3 * n

    def pair_con(x):
        cx, cy, r = _pack_vars(x)
        dx = cx[pairs_i] - cx[pairs_j]
        dy = cy[pairs_i] - cy[pairs_j]
        sr = r[pairs_i] + r[pairs_j]
        return dx * dx + dy * dy - sr * sr

    def pair_jac(x):
        cx, cy, r = _pack_vars(x)
        m = len(pairs_i)
        J = np.zeros((m, nv))
        dx = cx[pairs_i] - cx[pairs_j]
        dy = cy[pairs_i] - cy[pairs_j]
        sr = r[pairs_i] + r[pairs_j]
        ii = 3 * pairs_i
        jj = 3 * pairs_j
        J[np.arange(m), ii]     = 2 * dx
        J[np.arange(m), ii + 1] = 2 * dy
        J[np.arange(m), ii + 2] = -2 * sr
        J[np.arange(m), jj]     = -2 * dx
        J[np.arange(m), jj + 1] = -2 * dy
        J[np.arange(m), jj + 2] = -2 * sr
        return J

    return pair_con, pair_jac


def _all_pairs(n):
    iu, ju = np.triu_indices(n, k=1)
    return iu, ju


def _active_pairs(centers, radii, margin):
    """Pairs whose surface gap is smaller than margin (potential contacts)."""
    n = len(centers)
    diff = centers[:, None, :] - centers[None, :, :]
    dist = np.sqrt((diff ** 2).sum(-1))
    sr = radii[:, None] + radii[None, :]
    gap = dist - sr
    iu, ju = np.triu_indices(n, k=1)
    mask = (gap[iu, ju] < margin) & (iu < ju)
    return iu[mask], ju[mask]


def refine(x0, n, iters, pairs_i, pairs_j, ftol=1e-10):
    pair_con, pair_jac = _make_pair_closures(pairs_i, pairs_j, n)
    constraints = [
        {"type": "ineq", "fun": _wall_con, "jac": _wall_jac},
        {"type": "ineq", "fun": pair_con, "jac": pair_jac},
    ]
    bounds = [(0.0, 1.0)] * (3 * n)
    for i in range(n):
        bounds[3 * i + 2] = (0.0, 0.5)
    try:
        res = minimize(_objective, x0, method="SLSQP", jac=_obj_jac,
                       bounds=bounds, constraints=constraints,
                       options={"maxiter": iters, "ftol": ftol})
        return res.x
    except Exception:
        return x0


# ---------------------------------------------------------------------------
# Stage 4: uniform radius inflation + projection
# ---------------------------------------------------------------------------

def inflate(centers, radii, factor=1.05):
    """Grow radii by `factor`, then shrink to restore feasibility."""
    r = np.maximum(radii * factor, 1e-6)
    n = len(centers)
    # Wall cap
    r = np.minimum.reduce([r, centers[:, 0], centers[:, 1],
                           1 - centers[:, 0], 1 - centers[:, 1]])
    # Pairwise shrink loop (fast, converges in a few sweeps)
    for _ in range(50):
        changed = False
        for i in range(n):
            dx = centers[i, 0] - centers[i + 1:, 0]
            dy = centers[i, 1] - centers[i + 1:, 1]
            d = np.sqrt(dx * dx + dy * dy)
            s = r[i] + r[i + 1:]
            over = s > d
            if over.any():
                scale = np.where(over, d / np.maximum(s, 1e-12), 1.0)
                # update both ends
                r[i + 1:] = np.minimum(r[i + 1:], r[i + 1:] * scale)
                r[i] = min(r[i], r[i] * scale.min() if over.any() else r[i])
                changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


# ---------------------------------------------------------------------------
# Stage 6: feasibility repair
# ---------------------------------------------------------------------------

def repair(centers, radii):
    n = len(centers)
    r = np.maximum(radii, 0.0)
    for _ in range(200):
        changed = False
        # Wall
        wall = np.minimum.reduce([centers[:, 0], centers[:, 1],
                                  1 - centers[:, 0], 1 - centers[:, 1]])
        new_r = np.minimum(r, wall)
        if np.any(new_r < r):
            r = new_r
            changed = True
        # Pairs
        for i in range(n):
            dx = centers[i, 0] - centers[i + 1:, 0]
            dy = centers[i, 1] - centers[i + 1:, 1]
            d = np.sqrt(dx * dx + dy * dy)
            s = r[i] + r[i + 1:]
            over = (s > d) & (s > 0)
            if over.any():
                scale = np.where(over, d / np.maximum(s, 1e-12), 1.0)
                r[i + 1:] *= scale
                r[i] *= scale.min()
                changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


# ---------------------------------------------------------------------------
# Top-level pipeline
# ---------------------------------------------------------------------------

def _pack(centers, coarse_iters=120, fine_iters=400):
    n = len(centers)
    centers = np.clip(np.asarray(centers, dtype=float), 0.02, 0.98)
    radii = seed_radii(centers)

    x0 = np.zeros(3 * n)
    x0[0::3] = centers[:, 0]
    x0[1::3] = centers[:, 1]
    x0[2::3] = radii

    # Coarse pass: only nearby pairs constrained
    pi, pj = _active_pairs(centers, radii, margin=0.05)
    x1 = refine(x0, n, coarse_iters, pi, pj, ftol=1e-8)

    # Inflate radii (structure fixed, radii grow)
    c1 = x1.reshape(n, 3)
    centers1 = c1[:, :2].copy()
    radii1 = np.maximum(c1[:, 2], 0.0)
    radii1 = inflate(centers1, radii1, factor=1.06)

    x1[2::3] = radii1

    # Fine pass: full pair constraints
    ai, aj = _all_pairs(n)
    x2 = refine(x1, n, fine_iters, ai, aj, ftol=1e-12)

    c2 = x2.reshape(n, 3)
    centers_out = c2[:, :2].copy()
    radii_out = np.maximum(c2[:, 2], 0.0)
    radii_out = repair(centers_out, radii_out)
    return centers_out, radii_out


def solve(n=26):
    """Return (centers, radii) maximising sum of radii for n disjoint circles."""
    best_c, best_r = None, None
    best_sum = -1.0

    for centers in seed_layouts(n):
        c, r = _pack(centers)
        s = float(np.sum(r))
        if s > best_sum:
            best_sum = s
            best_c, best_r = c, r

    if best_c is None:
        centers = np.random.rand(n, 2) * 0.8 + 0.1
        best_c, best_r = _pack(centers)

    return best_c, best_r
# EVOLVE-BLOCK-END