# EVOLVE-BLOCK-START
"""Circle packing: maximise the sum of radii for n circles in the unit square.

Strategy:
  * For fixed centres, the maximum total radius is found by computing the
    largest scale s such that r_i = s * w_i satisfies all constraints
    r_i + r_j <= dist_ij and r_i <= wall_dist_i.  Solve by bisection +
    per-circle candidate evaluation: the true optimum is a "bottleneck"
    where each r_i = min(wall_i, min_j (d_ij - r_j)).
  * We compute this exactly by simple per-circle fixed-point (which is exact
    because the constraint graph is a "min" recursion): start r_i = wall_i,
    then relax r_i = min(r_i, d_ij - r_j) repeatedly until convergence; this
    is the standard "largest inscribed disks" fixed-point and converges fast.
  * Local search on centres: coordinate-wise moves accepted when they raise
    the exact sum; multi-start with hexagonal initialisation.
"""
import numpy as np


def _exact_radii(centers, max_passes=10000):
    """Maximum radii for fixed centres.

    The largest-feasible-radii vector is the unique maximal fixed point of
      r_i = min( wall_i, min_{j != i} (d_ij - r_j) )
    starting from r_i = wall_i.  Iterate to convergence.
    """
    centers = np.asarray(centers, dtype=float)
    n = len(centers)
    r = np.minimum.reduce([
        centers[:, 0], centers[:, 1],
        1.0 - centers[:, 0], 1.0 - centers[:, 1],
    ])
    r = np.maximum(r, 0.0)

    dx = centers[:, 0][:, None] - centers[:, 0][None, :]
    dy = centers[:, 1][:, None] - centers[:, 1][None, :]
    d = np.sqrt(dx * dx + dy * dy)
    np.fill_diagonal(d, np.inf)

    for _ in range(max_passes):
        # new_r_i = min(wall_i, min_j (d_ij - r_j))
        cand = d - r[None, :]
        new_r = cand.min(axis=1)
        new_r = np.minimum(new_r, np.minimum.reduce([
            centers[:, 0], centers[:, 1],
            1.0 - centers[:, 0], 1.0 - centers[:, 1],
        ]))
        new_r = np.maximum(new_r, 0.0)
        if np.allclose(new_r, r, atol=1e-11, rtol=0.0):
            r = new_r
            break
        r = new_r
    return np.maximum(r, 0.0)


def _seed_centers(n, rng):
    """Hexagonal-ish grid seeded inside the unit square with jitter."""
    cols = int(np.ceil(np.sqrt(n)))
    rows = int(np.ceil(n / cols))
    pts = []
    for iy in range(rows):
        for ix in range(cols):
            if len(pts) >= n:
                break
            x = (ix + 0.5) / cols
            y = (iy + 0.5) / rows
            if iy % 2 == 1:
                x += 0.5 / cols
            pts.append([x, y])
    pts = np.array(pts[:n], dtype=float)
    pts += rng.normal(0.0, 0.04, size=pts.shape)
    return np.clip(pts, 0.01, 0.99)


def solve(n=26):
    rng = np.random.default_rng(12345)
    best_centers = None
    best_radii = None
    best_sum = -1.0

    for restart in range(80):
        centers = _seed_centers(n, rng)
        radii = _exact_radii(centers)
        cur_sum = radii.sum()

        step = 0.04
        for _ in range(500):
            improved = False
            for i in range(n):
                for _try in range(3):
                    delta = rng.normal(0.0, step, size=2)
                    new_c = centers.copy()
                    new_c[i] = np.clip(centers[i] + delta, 0.0, 1.0)
                    new_r = _exact_radii(new_c)
                    new_sum = new_r.sum()
                    if new_sum > cur_sum + 1e-7:
                        centers = new_c
                        radii = new_r
                        cur_sum = new_sum
                        improved = True
                        break
            if not improved:
                step *= 0.65
                if step < 1e-4:
                    break

        if cur_sum > best_sum:
            best_sum = cur_sum
            best_centers = centers.copy()
            best_radii = radii.copy()

    best_radii = _exact_radii(best_centers)
    return best_centers, best_radii
# EVOLVE-BLOCK-END
