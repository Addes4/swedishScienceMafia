# EVOLVE-BLOCK-START
"""Circle packing via constrained SLSQP optimisation (ShinkaEvolve-style layout as init)."""
import numpy as np
from scipy.optimize import minimize


def _initial_layout(n):
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    while len(centers) < n:
        centers.append([0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()])
    return np.clip(np.array(centers[:n], dtype=float), 0.01, 0.99)


def _max_radii_heuristic(centers):
    """Cheap feasible radii for fixed centres (used to seed the optimiser)."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d and radii[i] + radii[j] > 1e-12:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _optimise(centers0, radii0):
    """SLSQP: maximise sum(r) subject to walls and non-overlap."""
    n = len(centers0)
    x0 = np.concatenate([centers0[:, 0], centers0[:, 1], radii0])

    # Wall constraints: r_i <= min(x_i, 1-x_i, y_i, 1-y_i)
    def wall_con(z):
        x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
        return np.minimum.reduce([x, 1 - x, y, 1 - y]) - r

    def overlap_con(z):
        x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
        dx = x[:, None] - x[None, :]
        dy = y[:, None] - y[None, :]
        d2 = dx * dx + dy * dy
        sr = r[:, None] + r[None, :]
        iu = np.triu_indices(n, k=1)
        return d2[iu] - sr[iu] ** 2

    cons = [
        {"type": "ineq", "fun": wall_con},
        {"type": "ineq", "fun": overlap_con},
    ]
    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 0.5)] * n

    def obj(z):
        return -np.sum(z[2 * n:])

    res = minimize(obj, x0, method="SLSQP", bounds=bounds, constraints=cons,
                   options={"maxiter": 500, "ftol": 1e-10})
    z = res.x
    centers = np.column_stack([z[:n], z[n:2 * n]])
    radii = np.maximum(z[2 * n:], 0.0)
    # Project to strict feasibility (SLSQP can leave tiny violations)
    centers = np.clip(centers, 1e-9, 1 - 1e-9)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1], radii])
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d and radii[i] + radii[j] > 1e-12:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return centers, np.maximum(radii, 0.0)


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    best_centers = None
    best_radii = None
    best_sum = -np.inf

    n_trials = 6
    for trial in range(n_trials):
        if trial == 0:
            centers0 = _initial_layout(n)
        else:
            centers0 = _initial_layout(n)
            # jitter for diversity
            centers0 += (np.random.rand(*centers0.shape) - 0.5) * 0.1
            centers0 = np.clip(centers0, 0.01, 0.99)
        radii0 = _max_radii_heuristic(centers0)
        try:
            centers, radii = _optimise(centers0, radii0)
        except Exception:
            centers, radii = centers0, _max_radii_heuristic(centers0)
        s = float(np.sum(radii))
        if s > best_sum:
            best_sum = s
            best_centers = centers
            best_radii = radii

    return best_centers, best_radii
# EVOLVE-BLOCK-END