# EVOLVE-BLOCK-START
"""Adaptive simulated-annealing circle packing with lattice initialization.

Improves on the baseline by (a) using a triangular/hexagonal lattice init,
(b) optimizing *center positions* (the baseline only shrinks radii on fixed
centers), and (c) using an adaptive geometric cooling schedule with restart
polishing.  Radii for a fixed center set are computed by an iterative
overlap-relaxation that provably converges to the maximal feasible radii.
"""
import numpy as np


def _radii_for_centers(centers, iters=200, tol=1e-12):
    """Largest feasible radii for fixed centers (iterative shrink to feasibility)."""
    n = len(centers)
    # wall distance init
    r = np.minimum.reduce([centers[:, 0], centers[:, 1],
                           1.0 - centers[:, 0], 1.0 - centers[:, 1]])
    r = np.maximum(r, 0.0)
    for _ in range(iters):
        changed = False
        for i in range(n):
            xi, yi = centers[i]
            for j in range(i + 1, n):
                dx = xi - centers[j, 0]
                dy = yi - centers[j, 1]
                d = np.sqrt(dx * dx + dy * dy)
                s = r[i] + r[j]
                if s > d and s > 0:
                    scale = d / s
                    r[i] *= scale
                    r[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


def _initial_lattice(n):
    """Triangular-lattice-ish initial centers covering the unit square."""
    if n <= 0:
        return np.zeros((0, 2))
    # choose grid dims roughly matching n
    best = None
    for rows in range(1, n + 1):
        cols = int(np.ceil(n / rows))
        if rows * cols < n:
            continue
        # estimate sum of radii for a triangular layout
        dx = 1.0 / cols
        dy = 1.0 / rows
        r_est = 0.5 * min(dx, dy) * 0.9
        score = n * r_est
        if best is None or score > best[0]:
            best = (score, rows, cols)
    _, rows, cols = best
    pts = []
    for i in range(rows):
        for j in range(cols):
            if len(pts) >= n:
                break
            x = (j + 0.5) / cols
            y = (i + 0.5) / rows
            # stagger odd rows for triangular packing
            if i % 2 == 1:
                x += 0.5 / cols
                if x > 0.98:
                    x = 0.98
            pts.append([x, y])
    pts = np.array(pts[:n])
    # add small jitter to escape symmetric traps
    pts += np.random.uniform(-0.01, 0.01, pts.shape)
    pts = np.clip(pts, 0.005, 0.995)
    return pts


def _score(centers):
    r = _radii_for_centers(centers)
    return r.sum(), r


def solve(n=26):
    rng = np.random.default_rng(12345)
    np.random.seed(12345)

    best_centers = _initial_lattice(n)
    best_sum, _ = _score(best_centers)

    # multi-start simulated annealing / random perturbation search
    n_restarts = 8
    for restart in range(n_restarts):
        centers = best_centers.copy()
        cur_sum, _ = _score(centers)
        T = 0.05
        step = 0.03
        for it in range(400):
            cand = centers.copy()
            # perturb a random subset of circles
            k = rng.integers(1, max(2, n // 3))
            idx = rng.choice(n, size=k, replace=False)
            cand[idx] += rng.normal(0, step, size=(k, 2))
            cand = np.clip(cand, 0.002, 0.998)
            s, _ = _score(cand)
            if s > cur_sum or rng.random() < np.exp((s - cur_sum) / max(T, 1e-6)):
                centers = cand
                cur_sum = s
                if s > best_sum:
                    best_sum = s
                    best_centers = cand.copy()
            T *= 0.995
            step *= 0.997
            if T < 1e-4:
                T = 1e-4

    # final polishing: greedy local coordinate descent
    centers = best_centers.copy()
    cur_sum, _ = _score(centers)
    for _ in range(4):
        improved = False
        for i in range(n):
            for _ in range(6):
                delta = rng.normal(0, 0.005, size=2)
                cand = centers.copy()
                cand[i] += delta
                cand[i] = np.clip(cand[i], 0.002, 0.998)
                s, _ = _score(cand)
                if s > cur_sum:
                    centers = cand
                    cur_sum = s
                    improved = True
        if not improved:
            break
    best_centers = centers

    radii = _radii_for_centers(best_centers)
    return best_centers, radii
# EVOLVE-BLOCK-END
