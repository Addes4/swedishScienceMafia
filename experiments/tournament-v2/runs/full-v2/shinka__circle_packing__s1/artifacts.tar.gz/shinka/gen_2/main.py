# EVOLVE-BLOCK-START
"""Gradient-flow circle packing: maximise sum of radii via differentiable relaxation
and gradient ascent on centres, with exact radii recomputation and multi-start."""
import numpy as np

def solve(n=26, time_limit=280):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    rng = np.random.default_rng(42)
    best_centers, best_radii, best_sum = None, None, -1.0

    # ---------- helper: exact max radii for fixed centres ----------
    def max_radii(centers):
        n = len(centers)
        radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                                   1 - centers[:, 0], 1 - centers[:, 1]])
        for _ in range(60):
            changed = False
            for i in range(n):
                for j in range(i + 1, n):
                    d = np.linalg.norm(centers[i] - centers[j])
                    if radii[i] + radii[j] > d:
                        scale = d / (radii[i] + radii[j] + 1e-12)
                        radii[i] *= scale
                        radii[j] *= scale
                        changed = True
            if not changed:
                break
        return np.maximum(radii, 0.0)

    # ---------- smooth surrogate for gradient ----------
    def smooth_sum_radii(centers, tau=0.02):
        """Differentiable approximation of sum of max radii."""
        n = len(centers)
        # wall distances (softmin over 4 walls)
        walls = np.stack([centers[:, 0], centers[:, 1],
                          1 - centers[:, 0], 1 - centers[:, 1]], axis=1)
        # softmin: -tau * log sum exp(-x/tau)
        r_wall = -tau * np.log(np.sum(np.exp(-walls / tau), axis=1) + 1e-15)
        # pairwise: softmin over d/2 (since r_i + r_j <= d => each <= d/2)
        # approximate r_i = min(r_wall_i, min_j d_ij/2)
        # use softmin over all constraints
        constraints = [r_wall]
        for i in range(n):
            dists = np.linalg.norm(centers - centers[i], axis=1)
            dists[i] = np.inf
            constraints.append(dists / 2.0)
        C = np.stack(constraints, axis=1)  # n x (1 + n)
        r_smooth = -tau * np.log(np.sum(np.exp(-C / tau), axis=1) + 1e-15)
        return np.sum(r_smooth)

    # ---------- gradient ascent step ----------
    def grad_step(centers, lr=0.005, tau=0.02):
        eps = 1e-4
        n = len(centers)
        g = np.zeros_like(centers)
        for i in range(n):
            for d in range(2):
                cp = centers.copy(); cp[i, d] += eps
                cm = centers.copy(); cm[i, d] -= eps
                g[i, d] = (smooth_sum_radii(cp, tau) - smooth_sum_radii(cm, tau)) / (2 * eps)
        # project to [0,1]
        new_c = centers + lr * g
        return np.clip(new_c, 0.0, 1.0)

    # ---------- initial layouts ----------
    def halton(i, b):
        f, r = 1, 0
        while i > 0:
            f /= b
            r += f * (i % b)
            i //= b
        return r

    def init_halton(n):
        pts = np.array([[halton(i + 1, 2), halton(i + 1, 3)] for i in range(n)])
        return np.clip(pts, 0.01, 0.99)

    def init_grid(n):
        k = int(np.ceil(np.sqrt(n)))
        pts = []
        for i in range(k):
            for j in range(k):
                pts.append([(i + 0.5) / k, (j + 0.5) / k])
        pts = np.array(pts[:n])
        return np.clip(pts, 0.01, 0.99)

    def init_random(n, rng):
        return np.clip(rng.random((n, 2)) * 0.98 + 0.01, 0.01, 0.99)

    inits = [init_halton(n), init_grid(n)] + [init_random(n, rng) for _ in range(6)]

    import time
    start = time.time()

    for init_idx, centers in enumerate(inits):
        centers = centers.copy()
        radii = max_radii(centers)
        current_sum = radii.sum()
        if current_sum > best_sum:
            best_sum = current_sum
            best_centers = centers.copy()
            best_radii = radii.copy()

        # gradient ascent with decreasing step and temperature
        lr = 0.01
        tau = 0.05
        for step in range(400):
            if time.time() - start > time_limit:
                break
            new_centers = grad_step(centers, lr=lr, tau=tau)
            new_radii = max_radii(new_centers)
            new_sum = new_radii.sum()
            if new_sum > current_sum:
                centers = new_centers
                radii = new_radii
                current_sum = new_sum
                if new_sum > best_sum:
                    best_sum = new_sum
                    best_centers = centers.copy()
                    best_radii = radii.copy()
            else:
                # backtrack: shrink step
                lr *= 0.7
                if lr < 1e-5:
                    break
            # occasionally reheat
            if step % 50 == 49:
                lr = min(lr * 2.0, 0.02)
                tau = max(tau * 0.9, 0.005)

        if time.time() - start > time_limit:
            break

    # fallback
    if best_centers is None:
        best_centers = init_halton(n)
        best_radii = max_radii(best_centers)

    return best_centers, best_radii
# EVOLVE-BLOCK-END
