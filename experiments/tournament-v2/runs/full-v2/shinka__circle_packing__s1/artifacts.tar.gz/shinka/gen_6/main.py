# EVOLVE-BLOCK-START
"""Circle packing via mixed multi-start relaxation + SLSQP polish.

Combines:
  * diverse structured/random initial layouts (radial, hex, random, jittered hex)
  * fast vectorised non-overlap relaxation (multiplicative shrink + centre push)
  * SLSQP refinement of the best candidates with strict feasibility projection
"""
import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------------------
# Initial layouts
# ---------------------------------------------------------------------------
def _radial_layout(n):
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8),
                 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16),
                 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    while len(centers) < n:
        centers.append([0.1 + 0.8 * np.random.rand(),
                        0.1 + 0.8 * np.random.rand()])
    return np.clip(np.array(centers[:n], dtype=float), 0.01, 0.99)


def _hex_layout(n, rows=None):
    if rows is None:
        rows = max(2, int(np.ceil(np.sqrt(n))))
    per_row = []
    remaining = n
    for i in range(rows):
        r = remaining // (rows - i)
        per_row.append(r)
        remaining -= r
    centers = []
    y = 0.05
    for ri, cnt in enumerate(per_row):
        if cnt <= 0:
            continue
        x0 = 0.05 + (0.1 if ri % 2 == 1 else 0.0)
        xs = np.linspace(x0, 0.95, cnt) if cnt > 1 else np.array([0.5])
        for x in xs:
            centers.append([x, y])
        y += 0.9 / max(rows, 1)
    centers = np.array(centers[:n], dtype=float)
    return np.clip(centers, 0.02, 0.98)


def _initial_layout(n, rng):
    mode = int(rng.integers(0, 4))
    if mode == 0:
        return _radial_layout(n)
    elif mode == 1:
        return _hex_layout(n)
    elif mode == 2:
        return 0.02 + 0.96 * rng.random((n, 2))
    else:
        c = _hex_layout(n)
        c += (rng.random(c.shape) - 0.5) * 0.15
        return np.clip(c, 0.01, 0.99)


# ---------------------------------------------------------------------------
# Feasibility helpers
# ---------------------------------------------------------------------------
def _wall_radii(centers):
    return np.minimum.reduce([centers[:, 0], centers[:, 1],
                              1 - centers[:, 0], 1 - centers[:, 1]])


def _project_feasible(centers, radii):
    """Shrink radii until walls and all pairwise overlaps are satisfied."""
    n = len(centers)
    radii = np.minimum(radii, _wall_radii(centers))
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                s = radii[i] + radii[j]
                if s > d and s > 1e-12:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


# ---------------------------------------------------------------------------
# Fast relaxation
# ---------------------------------------------------------------------------
def _fast_relax(centers, radii=None, iters=200):
    n = len(centers)
    centers = centers.astype(float).copy()
    if radii is None:
        radii = _wall_radii(centers) * 0.5
    radii = np.maximum(radii, 1e-6)

    for _ in range(iters):
        dx = centers[:, 0][:, None] - centers[:, 0][None, :]
        dy = centers[:, 1][:, None] - centers[:, 1][None, :]
        d = np.sqrt(dx * dx + dy * dy)
        np.fill_diagonal(d, np.inf)
        sr = radii[:, None] + radii[None, :]
        ratio = sr / np.maximum(d, 1e-12)
        max_ratio = np.max(ratio, axis=1)

        wall = _wall_radii(centers)
        target = np.minimum(wall, radii * 1.02 + 1e-4)
        shrink = np.where(max_ratio > 1.0, 1.0 / max_ratio, 1.0)
        new_radii = np.minimum(target, radii * shrink)

        # push centres apart if heavily overlapping
        if np.max(max_ratio) > 1.05:
            upper = np.triu(np.ones_like(ratio), 1) > 0
            mask = (ratio > 1.0) & upper
            i_idx, j_idx = np.where(mask)
            if len(i_idx) > 0:
                order = np.argsort(-ratio[i_idx, j_idx])[:n]
                for k in order:
                    i, j = i_idx[k], j_idx[k]
                    diff = centers[j] - centers[i]
                    dist = np.linalg.norm(diff)
                    if dist < 1e-9:
                        diff = np.random.randn(2)
                        dist = np.linalg.norm(diff) + 1e-12
                    push = (sr[i, j] - d[i, j]) * 0.5 * 0.3
                    unit = diff / dist
                    centers[i] -= unit * push
                    centers[j] += unit * push
            centers = np.clip(centers, 1e-4, 1 - 1e-4)

        if np.all(np.abs(new_radii - radii) < 1e-9):
            radii = new_radii
            break
        radii = new_radii

    radii = _project_feasible(centers, radii)
    return centers, radii


# ---------------------------------------------------------------------------
# SLSQP polish
# ---------------------------------------------------------------------------
def _slsqp_polish(centers0, radii0, maxiter=500, ftol=1e-12):
    n = len(centers0)
    x0 = np.concatenate([centers0[:, 0], centers0[:, 1], radii0])

    def wall_con(z):
        x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
        return np.minimum.reduce([x, 1 - x, y, 1 - y]) - r

    def overlap_con(z):
        x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
        dx = x[:, None] - x[None, :]
        dy = y[:, None] - y[None, :]
        d2 = dx * dx + dy * dy
        sr = r[:, None] + r[None, :]
        iu = np.triu_indices(n, k=1)
        return d2[iu] - sr[iu] ** 2

    cons = [
        {"type": "ineq", "fun": wall_con},
        {"type": "ineq", "fun": overlap_con},
    ]
    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 0.5)] * n

    def obj(z):
        return -np.sum(z[2 * n:])

    try:
        res = minimize(obj, x0, method="SLSQP", bounds=bounds, constraints=cons,
                       options={"maxiter": maxiter, "ftol": ftol})
        z = res.x
        centers = np.column_stack([z[:n], z[n:2 * n]])
        radii = np.maximum(z[2 * n:], 0.0)
        centers = np.clip(centers, 1e-9, 1 - 1e-9)
        radii = _project_feasible(centers, radii)
        return centers, radii
    except Exception:
        return centers0, radii0


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def solve(n=26):
    rng = np.random.default_rng(12345)

    n_trials = 40          # multi-start relaxation trials
    n_polish = 4           # top candidates polished with SLSQP

    candidates = []
    for _ in range(n_trials):
        centers0 = _initial_layout(n, rng)
        try:
            c, r = _fast_relax(centers0, iters=250)
        except Exception:
            c, r = centers0, _wall_radii(centers0) * 0.1
        candidates.append((float(np.sum(r)), c, r))

    # keep best few
    candidates.sort(key=lambda t: -t[0])
    top = candidates[:n_polish]

    # add a few jittered versions of the best for extra polish diversity
    best_c, best_r = top[0][1], top[0][2]
    for _ in range(2):
        c = best_c + rng.standard_normal(best_c.shape) * 0.01
        c = np.clip(c, 0.005, 0.995)
        c, r = _fast_relax(c, iters=200)
        top.append((float(np.sum(r)), c, r))

    best_sum = -np.inf
    best_centers = best_c
    best_radii = best_r

    for s0, c0, r0 in top:
        try:
            c, r = _slsqp_polish(c0, r0)
        except Exception:
            c, r = c0, r0
        s = float(np.sum(r))
        if s > best_sum:
            best_sum = s
            best_centers = c
            best_radii = r

    # final safety projection
    best_radii = _project_feasible(best_centers, best_radii)
    return best_centers, best_radii
# EVOLVE-BLOCK-END