# EVOLVE-BLOCK-START
"""Circle packing via fast non-overlap relaxation with multi-start and SLSQP polish."""
import numpy as np
from scipy.optimize import minimize


def _hex_layout(n, rows=None):
    """Generate a hexagonal-like initial layout."""
    centers = []
    if rows is None:
        rows = max(2, int(np.ceil(np.sqrt(n))))
    # distribute n circles across rows
    per_row = []
    remaining = n
    for i in range(rows):
        r = remaining // (rows - i)
        per_row.append(r)
        remaining -= r
    y = 0.05
    for ri, cnt in enumerate(per_row):
        if cnt <= 0:
            continue
        x0 = 0.05 + (0.1 if ri % 2 == 1 else 0.0)
        xs = np.linspace(x0, 0.95, cnt) if cnt > 1 else np.array([0.5])
        for x in xs:
            centers.append([x, y])
        y += 0.9 / max(rows, 1)
    centers = np.array(centers[:n], dtype=float)
    return np.clip(centers, 0.02, 0.98)


def _random_layout(n, rng):
    return 0.02 + 0.96 * rng.random((n, 2))


def _initial_layout(n, rng):
    """Mix of structured and random layouts."""
    mode = rng.integers(0, 4)
    if mode == 0:
        centers = [[0.5, 0.5]]
        centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8),
                     0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
        centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16),
                     0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
        while len(centers) < n:
            centers.append([0.1 + 0.8 * rng.random(), 0.1 + 0.8 * rng.random()])
        return np.clip(np.array(centers[:n], dtype=float), 0.01, 0.99)
    elif mode == 1:
        return _hex_layout(n)
    elif mode == 2:
        c = _random_layout(n, rng)
        return c
    else:
        c = _hex_layout(n)
        c += (rng.random(c.shape) - 0.5) * 0.15
        return np.clip(c, 0.01, 0.99)


def _wall_radii(centers):
    return np.minimum.reduce([centers[:, 0], centers[:, 1],
                              1 - centers[:, 0], 1 - centers[:, 1]])


def _fast_relax(centers, radii=None, iters=200):
    """Fast relaxation: inflate radii, resolve overlaps by multiplicative scaling."""
    n = len(centers)
    if radii is None:
        radii = _wall_radii(centers) * 0.5
    radii = np.maximum(radii, 1e-6)

    for _ in range(iters):
        # compute pairwise distances
        dx = centers[:, 0][:, None] - centers[:, 0][None, :]
        dy = centers[:, 1][:, None] - centers[:, 1][None, :]
        d = np.sqrt(dx * dx + dy * dy)
        np.fill_diagonal(d, np.inf)
        sr = radii[:, None] + radii[None, :]
        # overlap ratios
        ratio = sr / np.maximum(d, 1e-12)
        # for each circle, find max overlap with any other
        max_ratio = np.max(ratio, axis=1)
        # inflate towards wall limits
        wall = _wall_radii(centers)
        target = np.minimum(wall, radii * 1.02 + 1e-4)
        # shrink if overlapping
        shrink = np.where(max_ratio > 1.0, 1.0 / max_ratio, 1.0)
        new_radii = np.minimum(target, radii * shrink)
        # also push centers apart slightly if heavily overlapping
        if np.max(max_ratio) > 1.05:
            i_idx, j_idx = np.where((ratio > 1.0) & (np.triu(np.ones_like(ratio), 1) > 0))
            if len(i_idx) > 0:
                # take strongest overlaps
                order = np.argsort(-ratio[i_idx, j_idx])[:n]
                for k in order:
                    i, j = i_idx[k], j_idx[k]
                    diff = centers[j] - centers[i]
                    dist = np.linalg.norm(diff)
                    if dist < 1e-9:
                        diff = rng_dir()
                        dist = 1e-9
                    push = (sr[i, j] - d[i, j]) * 0.5 * 0.3
                    unit = diff / dist
                    centers[i] -= unit * push
                    centers[j] += unit * push
            centers = np.clip(centers, 1e-4, 1 - 1e-4)
        if np.all(np.abs(new_radii - radii) < 1e-9):
            radii = new_radii
            break
        radii = new_radii

    # final safety projection
    radii = _project_feasible(centers, radii)
    return centers, radii


def rng_dir():
    v = np.random.randn(2)
    v /= np.linalg.norm(v) + 1e-12
    return v


def _project_feasible(centers, radii):
    n = len(centers)
    radii = np.minimum(radii, _wall_radii(centers))
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d and radii[i] + radii[j] > 1e-12:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _slsqp_polish(centers0, radii0):
    """SLSQP refinement of the best configuration."""
    n = len(centers0)
    x0 = np.concatenate([centers0[:, 0], centers0[:, 1], radii0])

    def wall_con(z):
        x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
        return np.minimum.reduce([x, 1 - x, y, 1 - y]) - r

    def overlap_con(z):
        x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
        dx = x[:, None] - x[None, :]
        dy = y[:, None] - y[None, :]
        d2 = dx * dx + dy * dy
        sr = r[:, None] + r[None, :]
        iu = np.triu_indices(n, k=1)
        return d2[iu] - sr[iu] ** 2

    cons = [
        {"type": "ineq", "fun": wall_con},
        {"type": "ineq", "fun": overlap_con},
    ]
    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 0.5)] * n

    def obj(z):
        return -np.sum(z[2 * n:])

    try:
        res = minimize(obj, x0, method="SLSQP", bounds=bounds, constraints=cons,
                       options={"maxiter": 300, "ftol": 1e-12})
        z = res.x
        centers = np.column_stack([z[:n], z[n:2 * n]])
        radii = np.maximum(z[2 * n:], 0.0)
        centers = np.clip(centers, 1e-9, 1 - 1e-9)
        radii = _project_feasible(centers, radii)
        return centers, radii
    except Exception:
        return centers0, radii0


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    rng = np.random.default_rng(12345)
    best_centers = None
    best_radii = None
    best_sum = -np.inf

    # Phase 1: many fast multi-start relaxations
    n_trials = 40
    relaxed = []
    for trial in range(n_trials):
        centers0 = _initial_layout(n, rng)
        try:
            centers, radii = _fast_relax(centers0, iters=300)
        except Exception:
            centers, radii = centers0, _wall_radii(centers0) * 0.1
        s = float(np.sum(radii))
        relaxed.append((s, centers.copy(), radii.copy()))
        if s > best_sum:
            best_sum = s
            best_centers = centers.copy()
            best_radii = radii.copy()

    # Phase 2: SLSQP polish on top-K relaxed candidates (diverse basins)
    relaxed.sort(key=lambda t: -t[0])
    top_k = relaxed[:8]
    candidates = [(best_centers.copy(), best_radii.copy())]
    for _, c, r in top_k:
        candidates.append((c.copy(), r.copy()))
    # jittered variants of the best
    for _ in range(4):
        c = best_centers + (rng.standard_normal(best_centers.shape) * 0.008)
        c = np.clip(c, 0.005, 0.995)
        c, r = _fast_relax(c, iters=200)
        candidates.append((c, r))

    for c0, r0 in candidates:
        try:
            c, r = _slsqp_polish(c0, r0)
        except Exception:
            c, r = c0, r0
        s = float(np.sum(r))
        if s > best_sum:
            best_sum = s
            best_centers = c
            best_radii = r

    # Phase 3: final long SLSQP polish on the current best
    try:
        c, r = _slsqp_polish(best_centers, best_radii)
        s = float(np.sum(r))
        if s > best_sum:
            best_sum = s
            best_centers = c
            best_radii = r
    except Exception:
        pass

    return best_centers, best_radii
# EVOLVE-BLOCK-END