# EVOLVE-BLOCK-START
"""Optimise circle packing by maximising the true sum of feasible radii.

For fixed centres, the largest feasible radius vector is the unique maximal
fixed point of r_i = min(wall_i, min_j (d_ij - r_j)), which can be computed
exactly with a saturation/linear-programming style iteration.  We optimise the
centres with a smooth (log-sum-exp) surrogate of that quantity and polish with
Nelder-Mead.
"""
import numpy as np
from scipy.optimize import minimize


def solve(n=26):
    rng = np.random.default_rng(12345)
    best_val = -1.0
    best_c = None

    starts = [initial_hex(n)]
    # structured: hex plus small random jitter for diversity
    for _ in range(14):
        c = initial_hex(n) + rng.normal(0.0, 0.03, size=(n, 2))
        starts.append(np.clip(c, 0.02, 0.98))
    # purely random starts
    for _ in range(10):
        starts.append(np.clip(rng.random((n, 2)), 0.05, 0.95))

    bounds = [(0.0, 1.0)] * (2 * n)
    for c0 in starts:
        try:
            res = minimize(obj, c0.ravel(), method="L-BFGS-B",
                           bounds=bounds,
                           options={"maxiter": 4000, "ftol": 1e-15,
                                    "gtol": 1e-13, "maxls": 50})
            c = np.clip(res.x.reshape(n, 2), 0.0, 1.0)
            val = sum_radii(c)
            if val > best_val:
                best_val = val
                best_c = c
        except Exception:
            pass

    # local polish with Nelder-Mead (unbounded, we clip inside)
    if best_c is not None:
        res2 = minimize(lambda x: -sum_radii(np.clip(x.reshape(n, 2), 0.0, 1.0)),
                        best_c.ravel(), method="Nelder-Mead",
                        options={"maxiter": 20000, "xatol": 1e-9, "fatol": 1e-11})
        c2 = np.clip(res2.x.reshape(n, 2), 0.0, 1.0)
        v2 = sum_radii(c2)
        if v2 > best_val:
            best_val = v2
            best_c = c2

    centers = best_c
    radii = max_radii(centers)
    return centers, radii


def _wall(centers):
    return np.minimum.reduce([centers[:, 0], centers[:, 1],
                              1.0 - centers[:, 0], 1.0 - centers[:, 1]])


def sum_radii(centers, iters=400):
    """True maximal feasible radii for fixed centres; return their sum."""
    r = max_radii(centers, iters=iters)
    return float(r.sum())


def max_radii(centers, iters=400):
    """Largest feasible radii at fixed centres.

    Iterate r_i <- min(wall_i, min_j (d_ij - r_j)) until convergence; the
    maximal fixed point of this monotone operator is the optimum.
    """
    n = len(centers)
    walls = _wall(centers)
    diff = centers[:, None, :] - centers[None, :, :]
    d = np.sqrt(np.sum(diff ** 2, axis=-1) + 1e-18)
    np.fill_diagonal(d, np.inf)
    r = walls.copy()
    for _ in range(iters):
        # candidate from pairwise constraints: d_ij - r_j
        cand = d - r[None, :]
        np.fill_diagonal(cand, np.inf)
        new_r = np.minimum(walls, cand.min(axis=1))
        if np.max(np.abs(new_r - r)) < 1e-12:
            r = new_r
            break
        r = new_r
    return np.maximum(r, 0.0)


def obj(x):
    """Smooth surrogate for -sum(feasible radii) at the given centres.

    Uses a log-sum-exp soft-min so the objective is smooth and differentiable,
    which L-BFGS-B can exploit.
    """
    c = x.reshape(-1, 2)
    n = len(c)
    walls = _wall(c)
    diff = c[:, None, :] - c[None, :, :]
    d = np.sqrt(np.sum(diff ** 2, axis=-1) + 1e-12)
    np.fill_diagonal(d, np.inf)
    half = 0.5 * d.min(axis=1)
    # soft-min of wall and half-distance with a smooth blending parameter
    beta = 12.0
    r_soft = -np.logaddexp(-beta * walls, -beta * half) / beta
    return -np.sum(r_soft)


def initial_hex(n):
    c = []
    rows = int(np.ceil(np.sqrt(n)))
    for i in range(rows):
        for j in range(rows):
            x = (j + 0.5 * (i % 2)) / rows
            y = (i + 0.5) / rows
            c.append([x, y])
    c = np.array(c[:n])
    # ensure exactly n rows if slicing underfilled (rows^2 >= n always here)
    return np.clip(c, 0.05, 0.95)
# EVOLVE-BLOCK-END
