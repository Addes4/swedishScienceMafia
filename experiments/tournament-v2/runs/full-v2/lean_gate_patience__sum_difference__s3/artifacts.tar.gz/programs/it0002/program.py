# EVOLVE-BLOCK-START
"""Structured construction: many distinct differences, few sums, with fast local search."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    ld = len(diffs)
    ls = len(sums)
    if ld < 2 or ls < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _build_base(n):
    # Golomb-ruler-like sparse set gives many distinct differences.
    # Use a greedy Sidon-ish construction then perturb.
    s = [0, 1]
    used_diffs = {0, 1, -1}
    x = 1
    while len(s) < n:
        x += 1
        ok = True
        for y in s:
            d = x - y
            if d in used_diffs:
                ok = False
                break
        if ok:
            for y in s:
                used_diffs.add(x - y)
                used_diffs.add(y - x)
            s.append(x)
    return s


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # Try several structured seeds
    seeds = []
    for n in (30, 50, 70, 100, 140, 180, 220, 260):
        try:
            seeds.append(_build_base(n))
        except Exception:
            pass
    # a few random-ish seeds
    random.seed(12345)
    for _ in range(6):
        k = random.randint(40, 200)
        seeds.append(sorted(random.sample(range(-5000, 5000), k)))

    for seed in seeds:
        cur = seed[:]
        cs = _score(cur)
        if cs > best_score:
            best, best_score = cur[:], cs
        if time.time() > deadline:
            break
        # local search: try shifting a single element to a promising new value
        steps = 0
        no_improve = 0
        while time.time() < deadline and no_improve < 300:
            steps += 1
            cand = cur[:]
            i = random.randrange(len(cand))
            # bias toward values already near existing sums/diffs boundaries
            shift = random.choice([-1, 1]) * (1 + int(abs(random.gauss(0, 30))))
            cand[i] += shift
            if cand[i] in cand:
                no_improve += 1
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                no_improve = 0
                if cs > best_score:
                    best, best_score = cur[:], cs
            else:
                no_improve += 1
        # occasional reset
        if time.time() > deadline:
            break

    if best is None:
        best = [0, 1]
    return sorted(set(best))
# EVOLVE-BLOCK-END
