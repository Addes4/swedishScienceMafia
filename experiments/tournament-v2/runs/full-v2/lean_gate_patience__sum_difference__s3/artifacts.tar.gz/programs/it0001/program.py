# EVOLVE-BLOCK-START
"""Search for integer sets maximizing log|A-A| / log|A+A|."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    ls = math.log(len(sums))
    if ls <= 0:
        return 0.0
    return math.log(len(diffs)) / ls + (1 - 1 / n) / 100


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    deadline = time.time() + 110
    random.seed(12345)

    cur = best[:]
    cur_score = best_score
    # temperature schedule
    T0 = 1.0
    top = 40

    while time.time() < deadline:
        n = len(cur)
        T = T0 * max(0.0, 0.5 * (1 - (time.time() - (deadline - 110)) / 110))
        cand = cur[:]
        r = random.random()
        if r < 0.45:
            # perturb one element
            i = random.randrange(n)
            cand[i] += random.randint(-5, 5)
        elif r < 0.80:
            # add a new element (try to extend difference set)
            base = random.choice(cur)
            cand.append(base + random.randint(-10 * max(1, n), 10 * max(1, n)))
        elif r < 0.92:
            # shift the whole set (affects sums/diffs only via structure, keeps ratios)
            s = random.randint(-3, 3)
            cand = [x + s for x in cand]
        else:
            if n > 4:
                i = random.randrange(n)
                cand.pop(i)
        cand = sorted(set(cand))
        if len(cand) < 3:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < math.exp((s - cur_score) / max(1e-6, T) * 0.05):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur, cur_score = best[:], best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END

