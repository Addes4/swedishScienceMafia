import numpy as np
from scipy.optimize import minimize


def _radii_from_centers(centers):
    """Largest feasible radii for fixed centers via iterative pairwise shrinking."""
    n = len(centers)
    r = np.minimum.reduce([centers[:, 0], centers[:, 1],
                           1.0 - centers[:, 0], 1.0 - centers[:, 1]])
    for _ in range(60):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                dx = centers[i, 0] - centers[j, 0]
                dy = centers[i, 1] - centers[j, 1]
                d = np.hypot(dx, dy)
                s = r[i] + r[j]
                if s > d and s > 0:
                    scale = d / s
                    r[i] *= scale
                    r[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(r, 1e-9)


def _score(centers):
    r = _radii_from_centers(centers)
    return r.sum(), r


def _initial_layouts(n, rng):
    layouts = []
    # Hexagonal-ish packed rows
    for rows in range(3, 9):
        pts = []
        for i in range(rows):
            cols = int(np.ceil(n / rows))
            y = (i + 0.5) / rows
            xoff = 0.5 / cols if (i % 2) else 0.0
            for j in range(cols):
                x = (j + 0.5) / cols + xoff
                pts.append([x, y])
        pts = pts[:n]
        while len(pts) < n:
            pts.append([rng.random(), rng.random()])
        layouts.append(np.array(pts[:n]))
    # Concentric rings
    for _ in range(4):
        pts = [[0.5, 0.5]]
        k = 1
        while len(pts) < n:
            m = 3 + k * 4
            rad = 0.5 * k / (np.sqrt(n) * 0.6)
            for i in range(m):
                if len(pts) >= n:
                    break
                a = 2 * np.pi * i / m
                pts.append([0.5 + rad * np.cos(a), 0.5 + rad * np.sin(a)])
            k += 1
        layouts.append(np.array(pts[:n]))
    # Random
    for _ in range(30):
        layouts.append(np.clip(rng.random((n, 2)), 0.02, 0.98))
    return layouts


def _refine(centers0, n, time_budget_hint=1):
    """Joint optimization of centers + radii (variables: x,y for each, plus r for each)."""
    def unpack(v):
        c = v[:2 * n].reshape(n, 2)
        r = v[2 * n:]
        return c, r

    def obj(v):
        r = v[2 * n:]
        return -r.sum()

    def obj_grad(v):
        g = np.zeros_like(v)
        g[2 * n:] = -1.0
        return g

    cons = []
    # Box constraints
    for i in range(n):
        def wall_left(v, i=i):
            c, r = unpack(v)
            return c[i, 0] - r[i]
        def wall_right(v, i=i):
            c, r = unpack(v)
            return 1.0 - c[i, 0] - r[i]
        def wall_bot(v, i=i):
            c, r = unpack(v)
            return c[i, 1] - r[i]
        def wall_top(v, i=i):
            c, r = unpack(v)
            return 1.0 - c[i, 1] - r[i]
        cons.append({'type': 'ineq', 'fun': wall_left})
        cons.append({'type': 'ineq', 'fun': wall_right})
        cons.append({'type': 'ineq', 'fun': wall_bot})
        cons.append({'type': 'ineq', 'fun': wall_top})
    for i in range(n):
        for j in range(i + 1, n):
            def nonoverlap(v, i=i, j=j):
                c, r = unpack(v)
                dx = c[i, 0] - c[j, 0]
                dy = c[i, 1] - c[j, 1]
                d = np.hypot(dx, dy)
                return d - r[i] - r[j]
            cons.append({'type': 'ineq', 'fun': nonoverlap})

    r0 = _radii_from_centers(centers0)
    v0 = np.concatenate([centers0.ravel(), r0])
    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 0.5)] * n

    res = minimize(obj, v0, method='SLSQP', jac=obj_grad, bounds=bounds,
                   constraints=cons, options={'maxiter': 400, 'ftol': 1e-10})
    c, r = unpack(res.x)
    r = np.maximum(r, 0.0)
    # Verify & repair
    r = np.minimum(r, np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]]))
    for _ in range(80):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.hypot(c[i, 0] - c[j, 0], c[i, 1] - c[j, 1])
                s = r[i] + r[j]
                if s > d and s > 0:
                    sc = d / s
                    r[i] *= sc
                    r[j] *= sc
                    changed = True
        if not changed:
            break
    return c, np.maximum(r, 0.0)


def solve(n=26):
    rng = np.random.default_rng(12345)
    best_c, best_r = None, None
    best_sum = -1.0

    layouts = _initial_layouts(n, rng)
    # Quick local hill-climb on centers
    for c0 in layouts:
        c = c0.copy()
        s, r = _score(c)
        # coordinate descent on centers
        for _ in range(60):
            improved = False
            for i in range(n):
                for dx, dy in [(0.005, 0), (-0.005, 0), (0, 0.005), (0, -0.005),
                               (0.003, 0.003), (-0.003, 0.003), (0.003, -0.003), (-0.003, -0.003)]:
                    old = c[i].copy()
                    c[i] = np.clip(c[i] + [dx, dy], 0.0, 1.0)
                    s2, r2 = _score(c)
                    if s2 > s + 1e-9:
                        s, r = s2, r2
                        improved = True
                    else:
                        c[i] = old
            if not improved:
                break
        if s > best_sum:
            best_sum = s
            best_c, best_r = c.copy(), r.copy()

    # Global refinement with SLSQP
    try:
        c_ref, r_ref = _refine(best_c, n)
        if r_ref.sum() > best_sum:
            best_sum = r_ref.sum()
            best_c, best_r = c_ref, r_ref
    except Exception:
        pass

    # A couple more SLSQP restarts from perturbed best
    for _ in range(3):
        try:
            pert = best_c + rng.normal(0, 0.01, best_c.shape)
            pert = np.clip(pert, 0.0, 1.0)
            c_ref, r_ref = _refine(pert, n)
            if r_ref.sum() > best_sum:
                best_sum = r_ref.sum()
                best_c, best_r = c_ref, r_ref
        except Exception:
            pass

    # Final feasibility guarantee
    r_final = np.minimum(best_r, np.minimum.reduce(
        [best_c[:, 0], best_c[:, 1], 1 - best_c[:, 0], 1 - best_c[:, 1]]))
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.hypot(best_c[i, 0] - best_c[j, 0], best_c[i, 1] - best_c[j, 1])
                s = r_final[i] + r_final[j]
                if s > d and s > 0:
                    sc = d / s
                    r_final[i] *= sc
                    r_final[j] *= sc
                    changed = True
        if not changed:
            break
    r_final = np.maximum(r_final, 0.0)

    return np.clip(best_c, 0.0, 1.0), r_final
