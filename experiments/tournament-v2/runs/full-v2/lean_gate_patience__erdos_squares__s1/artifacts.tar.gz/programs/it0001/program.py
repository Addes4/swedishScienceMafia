# EVOLVE-BLOCK-START
"""Greedy + local search packer of axis-slack squares in the unit square."""
import math
import random


def _overlap(a, b):
    """True if two squares overlap with positive area.
    Square = (cx, cy, angle_fraction, side)."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return False
    import math as _m
    ta = aa * 2.0 * _m.pi
    tb = ba * 2.0 * _m.pi
    ca, sa = _m.cos(ta), _m.sin(ta)
    cb, sb = _m.cos(tb), _m.sin(tb)
    # corners relative to centre
    h = 0.5
    pa = []
    for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        px = sx * asz
        py = sy * asz
        pa.append((ax + px * ca - py * sa, ay + px * sa + py * ca))
    pb = []
    for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        px = sx * bsz
        py = sy * bsz
        pb.append((bx + px * cb - py * sb, by + px * sb + py * cb))
    # axes
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    for nx, ny in axes:
        amin = min(px * nx + py * ny for px, py in pa)
        amax = max(px * nx + py * ny for px, py in pa)
        bmin = min(px * nx + py * ny for px, py in pb)
        bmax = max(px * nx + py * ny for px, py in pb)
        if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
            return False
    return True


def _inside(center, angle, side):
    cx, cy, ang, sz = center, center, angle, side
    return True


def _feasible(sq):
    """All squares inside unit square (or zero)."""
    import math as _m
    for (cx, cy, ang, sz) in sq:
        if sz <= 0.0:
            continue
        if cx < -1e-9 or cx > 1 + 1e-9 or cy < -1e-9 or cy > 1 + 1e-9:
            return False
        t = ang * 2.0 * _m.pi
        c, s = _m.cos(t), _m.sin(t)
        ax = abs(c) + abs(s)
        if sz * ax * 0.5 > min(cx, 1 - cx) + 1e-9:
            return False
        if sz * ax * 0.5 > min(cy, 1 - cy) + 1e-9:
            return False
    for i in range(len(sq)):
        for j in range(i + 1, len(sq)):
            if _overlap(sq[i], sq[j]):
                return False
    return True


def _score(sq):
    return sum(s[3] for s in sq)


def _shrink_to_fit(sq):
    """Scale all boxes about (0.5,0.5) until feasible."""
    lo, hi = 0.0, 1.0
    # find feasible scale
    for _ in range(40):
        mid = (lo + hi) * 0.5
        scaled = [((cx - 0.5) * mid + 0.5, (cy - 0.5) * mid + 0.5, ang, sz * mid)
                  for (cx, cy, ang, sz) in sq]
        if _feasible(scaled):
            lo = mid
        else:
            hi = mid
    return [((cx - 0.5) * lo + 0.5, (cy - 0.5) * lo + 0.5, ang, sz * lo)
            for (cx, cy, ang, sz) in sq]


def _improve(sq, rng, iters=4000):
    """Random local search: perturb then shrink-to-fit."""
    best = list(sq)
    bs = _score(best)
    n = len(sq)
    for it in range(iters):
        cur = [list(s) for s in best]
        # pick a random square and a random move type
        i = rng.randrange(n)
        cx, cy, ang, sz = cur[i]
        r = rng.random()
        if r < 0.5:
            # try to enlarge
            cur[i][3] = sz * (1.0 + 0.05 + 0.2 * rng.random())
        elif r < 0.8:
            # move
            cur[i][0] = min(1.0, max(0.0, cx + (rng.random() - 0.5) * 0.08))
            cur[i][1] = min(1.0, max(0.0, cy + (rng.random() - 0.5) * 0.08))
        else:
            # rotate
            cur[i][2] = (ang + (rng.random() - 0.5) * 0.2) % 1.0
        trial = _shrink_to_fit([tuple(x) for x in cur])
        s = _score(trial)
        if s > bs - 1e-12:
            best = trial
            bs = s
    return best


def solve(n):
    if n <= 0:
        return []
    rng = random.Random(12345 + n)
    results = []

    # candidate 1: k x k grid
    k = math.isqrt(n)
    if k >= 1:
        side = 1.0 / k
        base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        base += [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
        base = base[:n]
        results.append(_improve(_shrink_to_fit(base), rng, iters=3000))

    # candidate 2: equal squares in a row/column layout maximizing count
    # k x k grid but with leftovers spread as thin strips
    if k >= 1:
        base = []
        for i in range(k):
            for j in range(k):
                base.append(((i + 0.5) / k, (j + 0.5) / k, 0.0, 1.0 / k))
        # replace some squares with pairs to use extra count
        extra = n - k * k
        if extra > 0:
            idx = 0
            while extra > 0 and idx < len(base):
                cx, cy, ang, sz = base[idx]
                sz2 = sz * 0.5
                base[idx] = (cx - sz2 * 0.5, cy, 0.0, sz2)
                base.append((cx + sz2 * 0.5, cy, 0.0, sz2))
                extra -= 1
                idx += 1
        base = base[:n]
        base += [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
        results.append(_improve(_shrink_to_fit(base[:n]), rng, iters=2000))

    # candidate 3: all zero placed, then greedy grow one by one
    base = [(0.5, 0.5, 0.0, 0.0)] * n
    results.append(_improve(_shrink_to_fit(base), rng, iters=2000))

    best = max(results, key=_score)
    # final light polish
    best = _improve(best, rng, iters=1500)
    return best[:n]
# EVOLVE-BLOCK-END
