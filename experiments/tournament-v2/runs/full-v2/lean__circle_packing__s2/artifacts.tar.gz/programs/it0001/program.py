# EVOLVE-BLOCK-START
"""Circle packing in the unit square: maximise sum of radii.

Approach: build a hexagonal-like initial layout, then optimise all 3n variables
(cx, cy, r for each circle) with L-BFGS-B using a smooth penalty for overlaps
and wall violations, followed by a shrink-to-feasible repair and local polishing.
"""
import numpy as np
from scipy.optimize import minimize


def _initial(n):
    """Hexagonal-ish starting configuration."""
    centers = []
    r0 = 0.5 / np.sqrt(n)
    spacing = 2.0 * r0
    cols = int(np.ceil(np.sqrt(n)))
    rows = int(np.ceil(n / cols))
    for i in range(n):
        row = i // cols
        col = i % cols
        x = 0.1 + col * spacing * (0.9 / max(cols - 1, 1) if cols > 1 else 0)
        y = 0.1 + row * spacing * (0.9 / max(rows - 1, 1) if rows > 1 else 0)
        x = 0.5 + (col - (cols - 1) / 2.0) * min(spacing, 0.9 / max(cols, 1))
        y = 0.5 + (row - (rows - 1) / 2.0) * min(spacing, 0.9 / max(rows, 1))
        if row % 2 == 1:
            x += min(spacing, 0.9 / max(cols, 1)) * 0.5
        centers.append([x, y])
    centers = np.clip(np.array(centers), 0.02, 0.98)
    return centers


def max_radii(centers):
    """Largest radii for fixed centres via greedy pairwise shrinking."""
    n = len(centers)
    c = np.asarray(centers)
    radii = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(c[i] - c[j])
                s = radii[i] + radii[j]
                if s > d and s > 1e-12:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square."""
    centers = _initial(n)
    radii = max_radii(centers)

    def unpack(v):
        c = v[:2 * n].reshape(n, 2)
        r = np.abs(v[2 * n:])
        return c, r

    def penalty(v):
        c, r = unpack(v)
        total = -np.sum(r)
        # wall penalties
        for k in range(n):
            cx, cy = c[k]
            rx, ry = r[k], r[k]
            for val, pen in ((cx - rx, 1.0), (cy - ry, 1.0), (1 - cx - rx, 1.0), (1 - cy - ry, 1.0)):
                if val < 0:
                    total += 1e3 * val * val
        # overlap penalties
        idx = np.arange(n)
        dx = c[:, 0][:, None] - c[:, 0][None, :]
        dy = c[:, 1][:, None] - c[:, 1][None, :]
        dist = np.sqrt(dx * dx + dy * dy)
        rsum = r[:, None] + r[None, :]
        gap = dist - rsum
        np.fill_diagonal(gap, 1.0)
        mask = gap < 0
        total += 1e3 * np.sum((gap[mask]) ** 2)
        return total

    v0 = np.concatenate([centers.ravel(), radii])
    res = minimize(penalty, v0, method='L-BFGS-B',
                   options={'maxiter': 5000, 'maxfun': 200000, 'ftol': 1e-12, 'gtol': 1e-10})
    c, r = unpack(res.x)
    c = np.clip(c, 1e-6, 1 - 1e-6)
    r = max_radii(c)
    return c, r
# EVOLVE-BLOCK-END
