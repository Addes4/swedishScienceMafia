# EVOLVE-BLOCK-START
"""Circle packing in the unit square: maximise sum of radii.

Approach: build a hexagonal lattice start, then locally maximise sum of radii
with scipy's SLSQP using explicit non-overlap and wall inequality constraints.
Multiple restarts (perturbed lattices + a couple random) are tried and the best
feasible packing is kept.
"""
import numpy as np
from scipy.optimize import minimize


def _hex_init(n, rng=None):
    """Hexagonal lattice start clipped to the square."""
    cols = int(np.ceil(np.sqrt(n)))
    rows = int(np.ceil(n / cols))
    pts = []
    for i in range(n):
        row = i // cols
        col = i % cols
        x = (col + 0.5 * (row % 2)) / cols
        y = (row + 0.5) / rows
        pts.append([x, y])
    pts = np.array(pts)
    pts = np.clip(pts, 0.02, 0.98)
    if rng is not None:
        pts = pts + rng.normal(0, 0.01, pts.shape)
        pts = np.clip(pts, 0.02, 0.98)
    return pts


def _feasible_radii(centers):
    """Largest radii for fixed centres via iterative pairwise shrinking."""
    n = len(centers)
    c = np.asarray(centers, dtype=float)
    radii = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    for _ in range(500):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                dx = c[i, 0] - c[j, 0]
                dy = c[i, 1] - c[j, 1]
                d = np.sqrt(dx * dx + dy * dy)
                s = radii[i] + radii[j]
                if s > d and s > 1e-12:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _slsqp_optimize(c0, r0, maxiter=400):
    """Maximise sum of radii with SLSQP subject to packing constraints."""
    n = len(c0)
    v0 = np.concatenate([c0.ravel(), r0])

    def obj(v):
        return -np.sum(v[2 * n:])

    def grad(v):
        g = np.zeros_like(v)
        g[2 * n:] = -1.0
        return g

    # constraints: for each pair, (xi-xj)^2+(yi-yj)^2 - (ri+rj)^2 >= 0
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

    def pair_con(v, i, j):
        xi, yi = v[2 * i], v[2 * i + 1]
        xj, yj = v[2 * j], v[2 * j + 1]
        ri, rj = v[2 * n + i], v[2 * n + j]
        return (xi - xj) ** 2 + (yi - yj) ** 2 - (ri + rj) ** 2

    cons = [{'type': 'ineq', 'fun': pair_con, 'args': (i, j)} for (i, j) in pairs]
    # wall constraints: xi - ri >= 0, 1 - xi - ri >= 0, yi - ri >= 0, 1 - yi - ri >= 0

    def wall_x_lo(v, i):
        return v[2 * i] - v[2 * n + i]

    def wall_x_hi(v, i):
        return 1.0 - v[2 * i] - v[2 * n + i]

    def wall_y_lo(v, i):
        return v[2 * i + 1] - v[2 * n + i]

    def wall_y_hi(v, i):
        return 1.0 - v[2 * i + 1] - v[2 * n + i]

    for i in range(n):
        cons.append({'type': 'ineq', 'fun': wall_x_lo, 'args': (i,)})
        cons.append({'type': 'ineq', 'fun': wall_x_hi, 'args': (i,)})
        cons.append({'type': 'ineq', 'fun': wall_y_lo, 'args': (i,)})
        cons.append({'type': 'ineq', 'fun': wall_y_hi, 'args': (i,)})

    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 0.5)] * n

    res = minimize(obj, v0, method='SLSQP', jac=grad, bounds=bounds,
                   constraints=cons, options={'maxiter': maxiter, 'ftol': 1e-12})
    v = res.x
    c = v[:2 * n].reshape(n, 2)
    c = np.clip(c, 1e-9, 1 - 1e-9)
    r = _feasible_radii(c)
    return c, r


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square."""
    rng = np.random.default_rng(2024)
    best_sum = -1.0
    best_c = None
    best_r = None

    starts = []
    base = _hex_init(n)
    starts.append(base)
    for _ in range(3):
        starts.append(_hex_init(n, rng))
    for _ in range(2):
        starts.append(rng.uniform(0.05, 0.95, size=(n, 2)))

    for c0 in starts:
        r0 = _feasible_radii(c0) * 0.98
        try:
            c, r = _slsqp_optimize(c0, r0, maxiter=400)
        except Exception:
            continue
        # polish: small inflations with overlap relaxation
        for _ in range(15):
            r_test = r * 1.01
            c_try, r_try = _slsqp_optimize(c, r_test, maxiter=150)
            if r_try.sum() > r.sum():
                c, r = c_try, r_try
        s = r.sum()
        if s > best_sum:
            best_sum = s
            best_c = c.copy()
            best_r = r.copy()

    return best_c, best_r
# EVOLVE-BLOCK-END
