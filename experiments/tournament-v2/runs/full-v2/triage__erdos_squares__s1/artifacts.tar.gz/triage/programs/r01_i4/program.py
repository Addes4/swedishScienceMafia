# EVOLVE-BLOCK-START
"""Simulated annealing packing of rotated squares in the unit square.

The initial configuration comes from the largest integer grid of equal squares.
Then a single square is perturbed at random and the move is accepted by a
Metropolis rule.  Feasibility (no shared interior points + stay in the box) is
checked with the separating axis theorem, which is exact for convex polygons.
"""

import math
import random


def _rand(seed=None):
    return random.Random(seed)


def _corners(cx, cy, angle, side):
    """Return the four corners of the square as a list of (x, y)."""
    h = 0.5 * side
    c = math.cos(2.0 * math.pi * angle)
    s = math.sin(2.0 * math.pi * angle)
    # local axes
    ax, ay = c, s
    bx, by = -s, c
    return [
        (cx + h * (ax + bx), cy + h * (ay + by)),
        (cx + h * (ax - bx), cy + h * (ay - by)),
        (cx - h * (ax - bx), cy - h * (ay - by)),
        (cx - h * (ax + bx), cy - h * (ay + by)),
    ]


def _axes(poly):
    """Outward normals (normalised) of the edges of a convex polygon."""
    axes = []
    m = len(poly)
    for i in range(m):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % m]
        ex, ey = x2 - x1, y2 - y1
        length = math.hypot(ex, ey)
        if length > 1e-12:
            axes.append((-ey / length, ex / length))
    return axes


def _project(poly, ax):
    dots = [p[0] * ax[0] + p[1] * ax[1] for p in poly]
    return min(dots), max(dots)


def _separated(poly1, axes1, poly2, axes2, tol=1e-9):
    """True if the two convex polygons are separated (do not overlap interiors)."""
    for ax in axes1:
        lo1, hi1 = _project(poly1, ax)
        lo2, hi2 = _project(poly2, ax)
        if hi1 <= lo2 + tol or hi2 <= lo1 + tol:
            return True
    for ax in axes2:
        lo1, hi1 = _project(poly1, ax)
        lo2, hi2 = _project(poly2, ax)
        if hi1 <= lo2 + tol or hi2 <= lo1 + tol:
            return True
    return False


def _inside(poly, tol=1e-9):
    for x, y in poly:
        if x < -tol or x > 1.0 + tol or y < -tol or y > 1.0 + tol:
            return False
    return True


def _feasible(idx, squares, polys, axes, tol=1e-9):
    """Check that square idx does not overlap any other and lies in the box."""
    if not _inside(polys[idx], tol):
        return False
    for j in range(len(squares)):
        if j == idx:
            continue
        if not _separated(polys[idx], axes[idx], polys[j], axes[j], tol):
            return False
    return True


def solve(n):
    rng = _rand()

    # --- initial configuration: largest integer grid of equal squares ---
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
            if len(squares) == n:
                break
        if len(squares) == n:
            break

    # remaining squares: degenerate points, allowed by the rules
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])

    # trim / pad exactly to n
    squares = squares[:n]

    def build_cache(vals):
        polys = [_corners(*v) for v in vals]
        axes = [_axes(p) for p in polys]
        return polys, axes

    polys, axes = build_cache(squares)

    def total():
        return sum(v[3] for v in squares)

    best = [row[:] for row in squares]
    best_total = total()
    cur_total = best_total

    # number of iterations scaled to problem size
    iters = max(40000, 6000 * n)
    # temperature schedule parameters
    side_scale = 1.0 / max(1, math.isqrt(max(1, n)))
    T0 = 0.12 * side_scale
    T1 = 1e-4 * side_scale

    for it in range(iters):
        frac = it / iters
        T = T0 * (1.0 - frac) + T1 * frac
        T = max(T, 1e-7)

        idx = rng.randrange(n)
        old = squares[idx][:]
        move = rng.random()

        if move < 0.70:
            # perturb one parameter
            a = rng.randrange(4)
            new = old[:]
            if a == 3:
                # resize
                delta = rng.gauss(0.0, 0.25 * side_scale)
                ns = old[3] + delta
                if ns < 0.0:
                    ns = 0.0
                new[3] = ns
            elif a == 2:
                # rotate
                new[2] = (old[2] + rng.uniform(-0.25, 0.25)) % 1.0
            else:
                # translate
                d = rng.gauss(0.0, 0.25 * side_scale)
                if a == 0:
                    new[0] = min(1.0, max(0.0, old[0] + d))
                else:
                    new[1] = min(1.0, max(0.0, old[1] + d))
        elif move < 0.85:
            # centre resample
            new = old[:]
            new[0] = rng.random()
            new[1] = rng.random()
        else:
            # grow attempt: scale side up
            new = old[:]
            new[3] = min(1.0, old[3] + abs(rng.gauss(0.0, 0.3 * side_scale)))

        if new[3] > 1.0:
            new[3] = 1.0

        prev_poly = polys[idx]
        prev_ax = axes[idx]

        new_poly = _corners(*new)
        new_ax = _axes(new_poly)

        # temporarily install
        polys[idx] = new_poly
        axes[idx] = new_ax
        squares[idx] = new

        ok = _feasible(idx, squares, polys, axes)

        if not ok:
            # revert
            polys[idx] = prev_poly
            axes[idx] = prev_ax
            squares[idx] = old
            continue

        delta = new[3] - old[3]
        new_total = cur_total + delta

        if delta >= 0.0 or rng.random() < math.exp(delta / max(T, 1e-7)):
            cur_total = new_total
            if cur_total > best_total:
                best_total = cur_total
                best = [row[:] for row in squares]
        else:
            # revert
            polys[idx] = prev_poly
            axes[idx] = prev_ax
            squares[idx] = old

    # --- final repair pass: pull everything inside and keep feasible ---
    result = []
    for v in best:
        result.append((v[0], v[1], v[2], v[3]))

    # normalise to guarantees (should already hold, but be safe)
    out = []
    for (cx, cy, ang, s) in result:
        if s < 0:
            s = 0.0
        if s > 1.0:
            s = 1.0
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        out.append((cx, cy, ang, s))

    return out
# EVOLVE-BLOCK-END
