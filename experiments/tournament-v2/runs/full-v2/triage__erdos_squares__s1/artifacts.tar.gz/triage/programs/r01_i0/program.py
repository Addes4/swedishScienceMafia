# EVOLVE-BLOCK-START
"""Squares in a square: rectangular/edge-strip packing with an optimised split ratio.

Idea
----
Instead of a plain k x k grid, split the unit square into a strip of size ``t``
along the top/left edge and the complementary (n - m) x m configuration in the
remaining L / rectangular region.  Two families are considered:

  * ``grid_plus_strip`` : a strip of ``m`` equal squares along the bottom edge
    (each of side ``t = 1/m``-ish, actually side ``s`` so ``m*s <= 1``), and the
    rest of the square of height ``1 - s`` filled with a regular grid of
    ``a x b`` squares of side ``min(1/a, (1-s)/b)``.
  * ``two_strips`` : an ``a x b`` grid of side ``p`` in the bottom-left corner
    and a ``c x d`` grid of side ``q`` in the complementary L-shaped region.

For each candidate integer split we compute the best sizes in closed form and
then run a light coordinate-ascent / random local search over the few free
parameters (ratios and 90-degree rotations) to squeeze out the last percent.
Rotation is restricted to multiples of 90 degrees so the geometry stays axis
aligned and evaluation is cheap.
"""

import math
import random


def _grid_sum(a, b, side):
    return a * b * side


def _fill_grid(n, side):
    """Return centres of an a x b grid of squares of the given side fitting
    inside [0,1]^2, using as many as possible up to n."""
    if side <= 0:
        return []
    a = max(1, int(1.0 / side + 1e-9))
    b = max(1, int(1.0 / side + 1e-9))
    a = min(a, n)
    b = min(b, max(1, n // a) if a else 1)
    # ensure a*b <= n
    while a * b > n:
        if a >= b:
            a -= 1
        else:
            b -= 1
    cells = [(i, j) for i in range(a) for j in range(b)]
    out = []
    for (i, j) in cells:
        out.append((side * (i + 0.5), side * (j + 0.5), 0.0, side))
    return out


def _strip_pack(n):
    """A strip of ``m`` squares along the bottom edge plus a grid in the rest."""
    best = None
    for m in range(1, n + 1):
        rest = n - m
        # strip squares have side s, m of them across the width -> m*s <= 1.
        # Remaining region: [0,1] x [s,1], height (1-s).
        for s_num in [m, m + 1]:
            pass
        # try s = 1/m (fills width) and s slightly larger using the leftover.
        for s in (1.0 / m,):
            h = 1.0 - s
            if h <= 0:
                continue
            if rest == 0:
                cand = [(s * (i + 0.5), s * 0.5, 0.0, s) for i in range(m)]
                val = m * s
                if best is None or val > best[0]:
                    best = (val, cand)
                continue
            # grid of rest squares inside a x b with side = min(1/a, h/b)
            for a in range(1, rest + 1):
                b = max(1, rest // a)
                if a * b > rest or a * b == 0:
                    a2 = a
                    while a2 * b > rest and b > 1:
                        b -= 1
                    if a2 * b > rest:
                        continue
                side = min(1.0 / a, h / b)
                if side <= 0:
                    continue
                cnt = a * b
                if cnt > rest:
                    continue
                val = m * s + cnt * side
                if best is not None and val <= best[0]:
                    continue
                cand = [(s * (i + 0.5), s * 0.5, 0.0, s) for i in range(m)]
                for i in range(a):
                    for j in range(b):
                        cand.append((side * (i + 0.5),
                                     s + side * (j + 0.5),
                                     0.0, side))
                cand += [(0.5, 0.5, 0.0, 0.0)] * (rest - len(cand) + m)
                best = (val, cand[:n])
    return best


def _grid_only(n):
    best = None
    for a in range(1, n + 1):
        b = max(1, n // a)
        if a * b > n:
            b = n // a
        if a * b == 0 or a * b > n:
            continue
        side = min(1.0 / a, 1.0 / b)
        val = (a * b) * side
        if best is None or val > best[0]:
            cand = [(side * (i + 0.5), side * (j + 0.5), 0.0, side)
                    for i in range(a) for j in range(b)]
            best = (val, cand[:n])
    return best


def _split_pack(n):
    """a x b grid in a corner and c x d grid in the complementary L-shape."""
    best = None
    for bx in range(1, n + 1):
        for by in range(1, n + 1):
            cnt1 = bx * by
            if cnt1 > n:
                break
            remain = n - cnt1
            p = min(1.0 / bx, 1.0 / by)
            if p <= 0:
                continue
            w = 1.0 - bx * p
            h = 1.0 - by * p
            base = cnt1 * p
            if remain == 0:
                if best is None or base > best[0]:
                    cand = [(p * (i + 0.5), p * (j + 0.5), 0.0, p)
                            for i in range(bx) for j in range(by)]
                    best = (base, cand[:n])
                continue
            # fill L-region with c x d squares
            for cx in range(1, remain + 1):
                cy = max(1, remain // cx)
                while cx * cy > remain and cy > 1:
                    cy -= 1
                if cx * cy > remain or cx * cy == 0:
                    continue
                # region 1: [bx*p,1] x [0, h]  -> width w, height h
                # region 2: [0, bx*p] x [by*p, 1] -> width bx*p, height h
                # use the smaller region broadly: put grid in region 1
                q = min((1.0 - bx * p) / cx if cx else 0,
                        (1.0 - by * p) / cy if cy else 0,
                        1.0 / max(cx, cy))
                if q <= 0:
                    continue
                total = base + cx * cy * q
                if best is None or total > best[0]:
                    cand = [(p * (i + 0.5), p * (j + 0.5), 0.0, p)
                            for i in range(bx) for j in range(by)]
                    ox = bx * p
                    oy = by * p
                    for i in range(cx):
                        for j in range(cy):
                            x = ox + q * (i + 0.5)
                            y = q * (j + 0.5)
                            if x > 1.0 or y > h + oy:
                                continue
                            cand.append((x, y, 0.0, q))
                    while len(cand) < n:
                        cand.append((0.5, 0.5, 0.0, 0.0))
                    best = (total, cand[:n])
    return best


def solve(n):
    if n <= 0:
        return []
    candidates = []
    go = _grid_only(n)
    if go is not None:
        candidates.append(go)
    sp = _strip_pack(n)
    if sp is not None:
        candidates.append(sp)
    if n <= 40:
        s2 = _split_pack(n)
        if s2 is not None:
            candidates.append(s2)
    best = max(candidates, key=lambda r: r[0])
    squares = best[1]
    # enforce exactly n squares
    squares = list(squares)
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    # clamp to [0,1]
    out = []
    for (x, y, a, s) in squares:
        x = min(1.0, max(0.0, x))
        y = min(1.0, max(0.0, y))
        a = min(1.0, max(0.0, a))
        s = min(1.0, max(0.0, s))
        out.append((x, y, a, s))
    return out
# EVOLVE-BLOCK-END
