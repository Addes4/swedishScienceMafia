# EVOLVE-BLOCK-START
"""Searches over guillotine cut partitions: recursively split rectangles to pack n squares optimally."""
import numpy as np

def solve(n):
    """Return n (centre_x, centre_y, angle, side) inside the unit square."""
    
    best_total = 0.0
    best_squares = []

    def make_square(center_x, center_y, angle_frac, side):
        """Convert params to final list format with angle in [0,1] fractions."""
        return [tuple((center_x, center_y, angle_frac, side))]
    
    def pack(curr_rect_left, curr_rect_bottom, rect_w, rect_h, rem_squares):
        """
        Recursively explore guillotine partitions for rem_squares within a rect.
        Returns best total side length found (not a complete packing).
        """
        nonlocal best_total, best_squares
        
        if rem_squares <= 0:
            return 0.0, []
        
        # If rect is too small to place one non-zero square
        if rect_w <= 1e-8 or rect_h <= 1e-8:
            return 0.0, []
        
        # Option A: Just insert one square (greedy max size)
        max_side = min(rect_w, rect_h)
        placed_one = [make_square(curr_rect_left + max_side/2, 
                                   curr_rect_bottom + max_side/2, 
                                   0.0, max_side)]
        total_A = max_side
        
        # Option B: Try different splits (guillotine cuts)
        min_split = 1e-4  # Avoid equally tiny splits
        max_split = 1.0 - min_split
        split_resolution = 15  # Accuracy
        split_count = rem_squares - 1  # We must recurse on >=1-square side for non-trivial.
        
        # Limit splits to make it tractable
        if rem_squares < 5:
            splits = np.linspace(min_split, max_split, 5)
        else:
            splits = np.linspace(min_split, max_split, 15)
        
        best_split_total = 0.0
        best_split_squares = []
        
        for s in splits:
            split_x = min(max_split, min(rem_squares, n) * s)
            
            # Horizontal vs vertical, but we model all as vertical w.l.o.g.
            w_left, h_left = rect_w * split_x, rect_h
            w_right, h_right = rect_w * (1 - split_x), rect_h
            
            # Left child needs k squares (k from 1 to rem_squares-1)
            for left_rem in range(1, min(rem_squares, n)):
                right_rem = rem_squares - left_rem
                
                left_total, left_sq = pack(curr_rect_left, curr_rect_bottom, 
                                           min(1.0, w_left, h_left), 
                                           max(1e-6, h_left), left_rem)
                right_total, right_sq = pack(curr_rect_left + w_left - min(1e-6,w_left),
                                              curr_rect_bottom,
                                              min(1.0, w_right, h_right), 
                                              max(1e-6, h_right), right_rem)
                
                total_B = left_total + right_total
                if total_B > best_split_total:
                    best_split_total = total_B
                    best_split_squares = left_sq + right_sq
        
        # Choose best option
        if total_A > best_split_total:
            best_total, best_squares = max_side + 0, placed_one + [best_squares] if best_squares else placed_one
        else:
            best_total, best_squares = best_split_total + 0, best_split_squares + [placed_one] if best_squares else best_split_squares
        
        return best_total, best_squares
    
    # Start recursion from main unit square
    pack(0, 0, 1.0, 1.0, n)
    return best_squares[:n] if best_squares else [(0.5, 0.5, 0.0, 0.0)] * n
# EVOLVE-BLOCK-END
