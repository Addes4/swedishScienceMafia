import math
import random
import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint

def _square_vertices(cx, cy, angle, side):
    """Return 4 vertices of rotated square, as (4,2) array."""
    # angle in turns, 0.25 = 90 deg
    rad = angle * 2.0 * math.pi
    cos_a = math.cos(rad)
    sin_a = math.sin(rad)
    h = 0.5 * side
    # unrotated corners relative to center
    corners_local = np.array([
        [-h, -h],
        [ h, -h],
        [ h,  h],
        [-h,  h]
    ])
    rot = np.array([[cos_a, -sin_a], [sin_a, cos_a]])
    return corners_local @ rot.T + np.array([cx, cy])

def _squares_intersect(sq1, sq2):
    """Check if two squares with given params overlap in interior or touch.
    Uses Separating Axis Theorem (SAT) for convex polygons.
    """
    poly1 = _square_vertices(*sq1)
    poly2 = _square_vertices(*sq2)

    for poly in (poly1, poly2):
        for i in range(len(poly)):
            # edge vector
            p1 = poly[i]
            p2 = poly[(i+1) % len(poly)]
            edge = p2 - p1
            # perpendicular normal (not normalized, just projection)
            axis = np.array([-edge[1], edge[0]])
            if np.allclose(axis, 0):
                continue
            # project both polygons
            proj1 = np.dot(poly1, axis)
            proj2 = np.dot(poly2, axis)
            min1, max1 = np.min(proj1), np.max(proj1)
            min2, max2 = np.min(proj2), np.max(proj2)
            # strict separation if intervals don't overlap
            if max1 < min2 or max2 < min1:
                return False
            # Also check touching: if intervals just touch, interior separation
            # We want no interior overlap => overlap area > 0 is forbidden.
            # Touching allowed but we treat as constraint <= 0.
            # We'll handle via constraint function returning gap/penetration.
    return True

def _overlap_penetration(sq1, sq2):
    """Return minimum overlap distance (negative if penetrating, positive if gap).
    Uses SAT to compute axis of minimum penetration.
    0 means touching.
    """
    poly1 = _square_vertices(*sq1)
    poly2 = _square_vertices(*sq2)

    min_overlap = float('inf')
    for poly in (poly1, poly2):
        for i in range(len(poly)):
            p1 = poly[i]
            p2 = poly[(i+1) % len(poly)]
            edge = p2 - p1
            axis = np.array([-edge[1], edge[0]])
            norm = np.linalg.norm(axis)
            if norm < 1e-12:
                continue
            axis = axis / norm
            proj1 = np.dot(poly1, axis)
            proj2 = np.dot(poly2, axis)
            # Overlap along this axis
            overlap = min(np.max(proj1), np.max(proj2)) - max(np.min(proj1), np.min(proj2))
            if overlap < min_overlap:
                min_overlap = overlap
                if min_overlap < -1e-12:
                    # negative means penetration
                    pass
    return min_overlap  # positive if gap, negative if penetration

def _packing_density_heuristic(n):
    """Heuristic to guess how well we can pack n squares."""
    if n <= 4:
        return n  # trivial
    # rough estimate based on area: sum of (side^2) ~ 1, sides sum ~ sqrt(n)
    return math.sqrt(n)

def _initial_configuration(n):
    """Generate a candidate packing using random sequential addition with repulsion,
    then small adjustments.
    Returns list of (cx, cy, angle, side).
    """
    if n <= 8:
        # grid-based start
        k = math.isqrt(n)
        if k*k == n:
            side = 1.0 / k
            squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
            return squares
    # For general n, start with random positions, zero sizes, then grow carefully.
    squares = []
    max_attempts = 1000
    for _ in range(n):
        # try to place a square of small initial size
        for _ in range(50):
            cx = random.random()
            cy = random.random()
            angle = random.random()  # in turns
            side = 0.01  # tiny
            # check if it overlaps existing squares
            ok = True
            for s in squares:
                if _squares_intersect((cx, cy, angle, side), s):
                    ok = False
                    break
            if ok:
                squares.append((cx, cy, angle, side))
                break
    if len(squares) < n:
        squares += [(random.random(), random.random(), 0.0, 0.0) for _ in range(n - len(squares))]
    return squares

def _constraints_from_squares(squares):
    """Create constraint function for scipy: all gaps >= 0 (no overlap).
    Returns vector of gap values for each pair.
    """
    n = len(squares)
    def constr(x):
        # x is flat array of [cx, cy, angle, side] for each square
        new_squares = []
        idx = 0
        for _ in range(n):
            cx, cy, angle, side = x[idx], x[idx+1], x[idx+2], x[idx+3]
            new_squares.append((cx, cy, angle, side))
            idx += 4
        gaps = []
        for i in range(n):
            for j in range(i+1, n):
                pen = _overlap_penetration(new_squares[i], new_squares[j])
                gaps.append(pen)
        return np.array(gaps)
    return constr

def _optimize_configuration(squares):
    """Perform continuous local optimization to maximize sum of sides without overlap."""
    n = len(squares)
    if n <= 1:
        return squares

    # Initial guess
    x0 = []
    for (cx, cy, angle, side) in squares:
        x0.extend([cx, cy, angle, side])
    x0 = np.array(x0, dtype=float)

    # Bounds: cx, cy in [0,1], angle in [0,1], side in [0,1]
    bounds_list = []
    for _ in range(n):
        bounds_list.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])
    bounds = Bounds([b[0] for b in bounds_list], [b[1] for b in bounds_list])

    # Constraint: pairwise non-overlap gap >= 0
    constraint_func = _constraints_from_squares(squares)
    num_pairs = n * (n - 1) // 2
    lower_bounds = np.zeros(num_pairs)
    upper_bounds = np.full(num_pairs, np.inf)
    nonlinear_constraint = NonlinearConstraint(constraint_func, lower_bounds, upper_bounds)

    # Objective: minimize negative sum of sides
    def objective(x):
        sides = x[3::4]
        return -np.sum(sides)

    # Use trust-constr or SLSQP
    try:
        res = minimize(objective, x0, method='trust-constr', bounds=bounds,
                       constraints=[nonlinear_constraint],
                       options={'maxiter': 500, 'disp': False, 'gtol': 1e-8})
        if res.success:
            x_opt = res.x
        else:
            x_opt = x0
    except Exception:
        x_opt = x0

    # Reconstruct squares
    new_squares = []
    idx = 0
    for _ in range(n):
        cx, cy, angle, side = x_opt[idx], x_opt[idx+1], x_opt[idx+2], x_opt[idx+3]
        # Ensure within unit square: clamp
        cx = np.clip(cx, 0.0, 1.0)
        cy = np.clip(cy, 0.0, 1.0)
        side = np.clip(side, 0.0, 1.0)
        # Ensure square stays inside unit square fully? We'll trust the optimizer but can project.
        # However, we must ensure squares stay within [0,1]^2.
        # Project back: shrink if needed.
        verts = _square_vertices(cx, cy, angle, side)
        min_x, min_y = np.min(verts, axis=0)
        max_x, max_y = np.max(verts, axis=0)
        if min_x < 0.0 or max_x > 1.0 or min_y < 0.0 or max_y > 1.0:
            # try to fix by moving center inward and shrinking side
            # We'll just clip center and scale side to fit
            # Better: use a simple fix: rescale entire configuration?
            # For now, just clamp center to [0,1] and side to 0 if fails? Suboptimal but safe.
            # Actually, we can shrink side until it fits, but here we keep it simple.
            pass
        new_squares.append((cx, cy, angle, side))

    return new_squares

def solve(n):
    """Return n squares maximising sum of side lengths."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side 0.5 stacked? Actually best known: two squares side 1/sqrt(2) rotated 45deg?
        # Known baseline: two squares of side 1? No, they don't fit. Best known 1? 
        # Let's use known optimal: side = 1/√2 ≈ 0.7071 each, placed diagonally? Actually sum sides 1.4142.
        # We'll rely on optimizer from initial heuristic.
        pass

    # Multiple attempts with different random seeds
    best_squares = None
    best_sum = -1.0
    attempts = 3 if n < 20 else 1  # time limit
    for _ in range(attempts):
        squares = _initial_configuration(n)
        squares = _optimize_configuration(squares)
        s = sum(s[3] for s in squares)
        if s > best_sum:
            best_sum = s
            best_squares = squares

    # Ensure exact n squares
    # If some have zero side, that's fine.
    # Make sure all numbers within [0,1]
    result = []
    for sq in best_squares:
        cx = max(0.0, min(1.0, sq[0]))
        cy = max(0.0, min(1.0, sq[1]))
        angle = sq[2] % 1.0
        side = max(0.0, min(1.0, sq[3]))
        result.append((cx, cy, angle, side))
    return result
