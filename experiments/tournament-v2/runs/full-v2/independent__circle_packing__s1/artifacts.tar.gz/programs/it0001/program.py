import numpy as np
from scipy.optimize import minimize


def max_radii(centers):
    """Largest radii for fixed centres."""
    n = len(centers)
    r = np.minimum.reduce([centers[:, 0], centers[:, 1],
                           1 - centers[:, 0], 1 - centers[:, 1]])
    # iterative pairwise shrink to feasibility
    for _ in range(200):
        changed = False
        for i in range(n):
            xi, yi = centers[i]
            for j in range(i + 1, n):
                dx = xi - centers[j, 0]
                dy = yi - centers[j, 1]
                d = np.hypot(dx, dy)
                if r[i] + r[j] > d + 1e-15:
                    s = d / (r[i] + r[j])
                    r[i] *= s
                    r[j] *= s
                    changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


def total_sum(centers_flat, n):
    c = centers_flat.reshape(n, 2)
    r = max_radii(c)
    return -r.sum()


def initial_layout(n):
    """Corner-anchored hexagonal-ish layout."""
    pts = []
    # corner circles
    pts += [[0.0, 0.0], [1.0, 0.0], [0.0, 1.0], [1.0, 1.0]]
    # edge midpoints pull - approximate boundary packing
    pts += [[0.5, 0.0], [0.5, 1.0], [0.0, 0.5], [1.0, 0.5]]
    # fill interior with hex-like grid
    k = int(np.ceil(np.sqrt(n))) + 3
    for i in range(k):
        for j in range(k):
            x = (i + 0.5 + 0.5 * (j % 2)) / k
            y = (j + 0.5) / k
            if 0 <= x <= 1 and 0 <= y <= 1:
                pts.append([x, y])
    pts = np.array(pts)
    # remove duplicates / too close
    keep = []
    for p in pts:
        ok = True
        for q in keep:
            if np.hypot(*(p - q)) < 1e-6:
                ok = False
                break
        if ok:
            keep.append(p)
        if len(keep) >= n:
            break
    if len(keep) < n:
        while len(keep) < n:
            keep.append([np.random.rand(), np.random.rand()])
    return np.clip(np.array(keep[:n]), 1e-4, 1 - 1e-4)


def solve(n=26):
    np.random.seed(12345)
    best_c = None
    best_s = -1.0

    # multiple restarts
    for trial in range(6):
        if trial == 0:
            c0 = initial_layout(n)
        else:
            c0 = initial_layout(n) + np.random.randn(n, 2) * 0.05
            c0 = np.clip(c0, 1e-3, 1 - 1e-3)

        # Phase 1: physics-style relaxation with growing radii
        c = c0.copy()
        for step in range(400):
            r = max_radii(c)
            # push apart overlapping circles
            disp = np.zeros_like(c)
            for i in range(n):
                for j in range(i + 1, n):
                    d = np.hypot(c[i, 0] - c[j, 0], c[i, 1] - c[j, 1])
                    target = r[i] + r[j]
                    if d < target and d > 1e-9:
                        overlap = target - d
                        ux = (c[i, 0] - c[j, 0]) / d
                        uy = (c[i, 1] - c[j, 1]) / d
                        f = 0.5 * overlap
                        disp[i, 0] += f * ux
                        disp[i, 1] += f * uy
                        disp[j, 0] -= f * ux
                        disp[j, 1] -= f * uy
            # boundary push
            for i in range(n):
                if c[i, 0] < r[i]:
                    disp[i, 0] += (r[i] - c[i, 0]) * 0.5
                if c[i, 0] > 1 - r[i]:
                    disp[i, 0] -= (c[i, 0] - (1 - r[i])) * 0.5
                if c[i, 1] < r[i]:
                    disp[i, 1] += (r[i] - c[i, 1]) * 0.5
                if c[i, 1] > 1 - r[i]:
                    disp[i, 1] -= (c[i, 1] - (1 - r[i])) * 0.5
            c = c + 0.6 * disp
            c = np.clip(c, 1e-6, 1 - 1e-6)
            if np.max(np.abs(disp)) < 1e-9:
                break

        # Phase 2: Nelder-Mead / Powell polish
        for method in ['Powell', 'Nelder-Mead']:
            try:
                res = minimize(total_sum, c.flatten(), args=(n,),
                               method=method,
                               options={'maxiter': 600 if method == 'Powell' else 1500,
                                        'xtol': 1e-8, 'ftol': 1e-10})
                cand = res.x.reshape(n, 2)
                cand = np.clip(cand, 1e-5, 1 - 1e-5)
                s = max_radii(cand).sum()
                if s > best_s:
                    best_s = s
                    best_c = cand
                c = cand
            except Exception:
                pass

        s = max_radii(c).sum()
        if s > best_s:
            best_s = s
            best_c = c

    centers = np.clip(best_c, 1e-5, 1 - 1e-5)
    radii = max_radii(centers)
    # final feasibility repair
    for _ in range(500):
        ok = True
        r = max_radii(centers)
        for i in range(n):
            for j in range(i + 1, n):
                d = np.hypot(centers[i, 0] - centers[j, 0],
                             centers[i, 1] - centers[j, 1])
                if r[i] + r[j] > d + 1e-12:
                    ok = False
        if ok:
            break
        radii = max_radii(centers)
    return centers, max_radii(centers)
