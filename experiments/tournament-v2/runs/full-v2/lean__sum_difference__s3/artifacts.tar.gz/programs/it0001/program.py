# EVOLVE-BLOCK-START
"""Search for sets with large difference set and small sum set."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _diffs_sums(a):
    a = list(set(a))
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums)


def solve():
    deadline = time.time() + 120
    random.seed(12345)

    def score(a):
        a = list(set(a))
        if len(a) < 2:
            return 0.0
        nd, ns = _diffs_sums(a)
        if ns < 2:
            return 0.0
        return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100

    # --- seed constructions ---
    seeds = []

    # dense Golomb-like ruler built greedily: many distinct differences
    def golomb(n, spread):
        g = [0]
        used = {0}
        while len(g) < n:
            best = None
            for c in range(1, spread):
                if c in used:
                    continue
                ok = True
                for x in g:
                    if abs(x - c) in used and x != c:
                        pass
                nd = set()
                good = True
                for x in g:
                    d = abs(c - x)
                    if d in nd:
                        good = False
                        break
                    nd.add(d)
                if good:
                    best = c
                    break
            if best is None:
                break
            for x in g:
                used.add(abs(best - x))
            g.append(best)
        return sorted(g)

    for n, sp in [(12, 200), (16, 400), (20, 800), (24, 1500)]:
        seeds.append(golomb(n, sp))

    # k-shifted AP: A = {b + i*t} -> sums nearly AP, diffs AP -> ratio small, skip
    # random dense sets
    for _ in range(6):
        n = random.randint(10, 25)
        base = random.randint(-50, 50)
        seeds.append([base + random.randint(0, 300) for _ in range(n)])

    # random near-binary (Sidon-ish) sets
    for _ in range(6):
        n = random.randint(10, 25)
        seeds.append(sorted({random.randint(-500, 500) for _ in range(n * 3)})[:n])

    best = None
    best_score = -1.0
    for s in seeds:
        sc = score(s)
        if sc > best_score:
            best_score = sc
            best = list(set(s))

    # --- hill climbing / annealing over the best set ---
    cur = best[:]
    cur_score = best_score
    T = 0.02
    while time.time() < deadline:
        if random.random() < 0.03:
            T = random.choice([0.001, 0.005, 0.02, 0.1])
        cand = cur[:]
        op = random.random()
        if op < 0.6:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1, -2, 2, -3, 3, -5, 5,
                                      -10, 10, -30, 30, -100, 100])
        elif op < 0.85:
            cand.append(random.randint(-1000, 1000))
        else:
            if len(cand) > 4:
                cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        if len(cand) < 4 or len(cand) > 4000:
            continue
        s = score(cand)
        if s > cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-9)):
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        if random.random() < 0.01:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
