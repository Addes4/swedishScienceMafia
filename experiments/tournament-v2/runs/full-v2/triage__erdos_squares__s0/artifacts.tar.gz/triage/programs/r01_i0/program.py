# EVOLVE-BLOCK-START
"""Greedy packing: fill unit square by placing largest axis-aligned squares
greedily at lowest-leftmost positions, tracking available rectangular regions."""
import math
from heapq import heappush, heappop


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square."""
    if n <= 0:
        return []

    # Max-heap of (remaining_area, -min_dim, rect_right, rect_bottom, width, height)
    # Using negative min_dim for max-heap behavior (heapq is min-heap)
    # Initially the unit square
    free_rects = [(-1.0, 1.0, 1.0, 1.0)]  # (-area, -min_dim, right, bottom, width, height)

    squares = []
    placed_keys = set()  # Avoid duplicate rectangle tracking

    for _ in range(n):
        if not free_rects:
            break

        # Extract rectangle with largest potential square size (min dimension)
        best = heappop(free_rects)
        area_neg, min_dim, right, bottom, width, height = best

        # If no valid square can be placed, try next best
        if min_dim < 1e-15:
            continue

        # Square size = rectangle's minimum dimension
        size = min_dim

        # Place at lowest-leftmost (right - width, bottom)
        left = right - width
        center_x = left + size / 2.0
        center_y = bottom + size / 2.0

        squares.append((center_x, center_y, 0.0, size))

        # Cut the rectangle and add remaining regions back to heap
        if size < width and width - size > 1e-15:
            new_right = right - (width - size)
            new_area = (width - size) * height
            heappush(free_rects, (-new_area, height, new_right, bottom, width - size, height))

        if size < height and height - size > 1e-15:
            new_bottom = size  # place above the square (since it's at bottom)
            new_area = width * (height - size)
            heappush(free_rects, (-new_area, width, right, new_bottom, width, height - size))

    # Add zero-size squares if n is greater than placed
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))

    return squares[:n]
# EVOLVE-BLOCK-END
