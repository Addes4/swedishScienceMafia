import numpy as np
from scipy.optimize import minimize
import math


def _pack_squares(x, n):
    """Convert flat vector to list of squares (cx, cy, angle, s)."""
    squares = []
    for i in range(n):
        cx = x[4*i]
        cy = x[4*i+1]
        ang = x[4*i+2]
        s = x[4*i+3]
        squares.append((cx, cy, ang, s))
    return squares


def _corners(cx, cy, angle, s):
    """Return 4 corners of a square (4x2 array)."""
    # Rotate by angle*2π
    th = angle * 2 * math.pi
    rot = np.array([[math.cos(th), -math.sin(th)],
                    [math.sin(th), math.cos(th)]])
    # Half side
    hs = s / 2.0
    # Local corners (centered at origin)
    local = np.array([[-hs, -hs],
                      [hs, -hs],
                      [hs, hs],
                      [-hs, hs]])
    return np.array([cx, cy]) + local @ rot.T


def _separation_penalty(squares):
    """Penalty for overlapping squares or going outside unit square."""
    n = len(squares)
    penalty = 0.0
    # bounding box penalty: all corners inside [0,1]
    for i, (cx, cy, ang, s) in enumerate(squares):
        if s <= 0:
            continue
        corners = _corners(cx, cy, ang, s)
        # Soft penalty for going outside [0,1]
        penalty += np.sum(np.maximum(0.0, -corners))**2
        penalty += np.sum(np.maximum(0.0, corners - 1.0))**2

    # Overlap penalty via separating axis theorem for convex polygons
    for i in range(n):
        cxi, cyi, angi, si = squares[i]
        if si <= 0:
            continue
        for j in range(i+1, n):
            cxj, cyj, angj, sj = squares[j]
            if sj <= 0:
                continue
            # Quick bounding circle check
            dist = math.hypot(cxi - cxj, cyi - cyj)
            # diagonal length = s * sqrt(2)
            if dist > (si + sj) * 0.70710678 * 1.1:
                continue
            # Separating axis theorem for two OBBs
            # Get corners
            corners_i = _corners(cxi, cyi, angi, si)
            corners_j = _corners(cxj, cyj, angj, sj)
            # Generate axes: face normals of both squares
            axes_i = []
            for k in range(4):
                edge = corners_i[(k+1)%4] - corners_i[k]
                norm = np.array([-edge[1], edge[0]])
                nrm = np.linalg.norm(norm)
                if nrm > 1e-12:
                    axes_i.append(norm / nrm)
            axes_j = []
            for k in range(4):
                edge = corners_j[(k+1)%4] - corners_j[k]
                norm = np.array([-edge[1], edge[0]])
                nrm = np.linalg.norm(norm)
                if nrm > 1e-12:
                    axes_j.append(norm / nrm)
            all_axes = axes_i + axes_j
            overlap = True
            min_overlap = float('inf')
            for axis in all_axes:
                proj_i = corners_i @ axis
                proj_j = corners_j @ axis
                min_i, max_i = np.min(proj_i), np.max(proj_i)
                min_j, max_j = np.min(proj_j), np.max(proj_j)
                if max_i < min_j or max_j < min_i:
                    overlap = False
                    break
                else:
                    ov = min(max_i - min_j, max_j - min_i)
                    min_overlap = min(min_overlap, ov)
            if overlap:
                penalty += (min_overlap ** 2)
    return penalty


def solve(n):
    """Return n squares maximizing sum of side lengths."""
    if n <= 0:
        return []
    # Initial guess: grid as in baseline
    k = math.isqrt(n)
    side0 = 1.0 / k if k > 0 else 1.0
    x0 = []
    idx = 0
    for i in range(k):
        for j in range(k):
            if idx >= n:
                break
            cx = (i + 0.5) * side0
            cy = (j + 0.5) * side0
            ang = 0.0
            s = side0
            x0.extend([cx, cy, ang, s])
            idx += 1
    # Remaining squares get side 0
    while idx < n:
        # Place them randomly but with side 0
        cx = np.random.uniform(0.2, 0.8)
        cy = np.random.uniform(0.2, 0.8)
        ang = 0.0
        s = 0.0
        x0.extend([cx, cy, ang, s])
        idx += 1

    x0 = np.array(x0, dtype=np.float64)

    # Bounds: cx,cy in [0,1], angle in [0,1] (cyclic but we restrict), s in [0,1]
    bounds = []
    for _ in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])

    def objective_and_penalty(x):
        squares = _pack_squares(x, n)
        side_sum = sum(s for (_, _, _, s) in squares)
        penalty = _separation_penalty(squares)
        # We want to maximize side_sum - penalty_weight * penalty
        # Minimizer minimizes f -> we use negative sum + penalty
        # Start with high penalty weight and increase? We'll do fixed high weight.
        penalty_weight = 1000.0 + n * 10  # heuristic
        return -side_sum + penalty_weight * penalty

    # Use L-BFGS-B with finite differences
    res = minimize(objective_and_penalty, x0, method='L-BFGS-B',
                   bounds=bounds,
                   options={'maxiter': 2000, 'ftol': 1e-8})

    x_opt = res.x
    squares = _pack_squares(x_opt, n)
    # Post-process: ensure no negative side lengths
    squares = [(cx, cy, ang, max(0.0, s)) for (cx, cy, ang, s) in squares]
    # Re-normalize? We trust penalty guided to inside.
    # Return in required format
    return squares
