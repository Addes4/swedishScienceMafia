import numpy as np
import math
import random
import time

def solve(n, time_limit=60):
    """
    Place n non-overlapping squares inside the unit square [0,1]x[0,1] to maximize the sum of side lengths.
    Returns a list of (cx, cy, angle, side) where angle is fraction of full turn (0.25 = 90 degrees).
    """
    start_time = time.time()
    
    # Quick degenerate case
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    # Helper functions for axis-aligned bounding box overlap
    def get_vertices(cx, cy, angle_frac, side):
        """Return 4 vertices of square as (4,2) array."""
        angle = angle_frac * 2 * math.pi
        half = side / 2.0
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        # Local offsets: right, up, left, down from center
        dirs = [(half, half), (-half, half), (-half, -half), (half, -half)]
        verts = []
        for dx, dy in dirs:
            x = cx + dx * cos_a - dy * sin_a
            y = cy + dx * sin_a + dy * cos_a
            verts.append((x, y))
        return np.array(verts)
    
    def aabb(vertices):
        """Axis-aligned bounding box: (min_x, max_x, min_y, max_y)"""
        return (vertices[:,0].min(), vertices[:,0].max(), vertices[:,1].min(), vertices[:,1].max())
    
    def aabb_overlap(a, b):
        """Check if two axis-aligned bounding boxes overlap (including touching)."""
        return not (a[1] < b[0] or b[1] < a[0] or a[3] < b[2] or b[3] < a[2])
    
    def separating_axis_test(verts1, verts2):
        """Return True if two convex polygons (given vertices) overlap, using separating axis theorem."""
        # We need to test axes from both polygons.
        # For squares, axes are the normals to edges, which are simply (0,1) directions of sides.
        # But easier: use SAT with all edges of both polygons.
        def edges(poly):
            e = []
            for i in range(len(poly)):
                e.append(poly[(i+1)%len(poly)] - poly[i])
            return e
        
        def get_projection(poly, axis):
            dots = np.dot(poly, axis)
            return dots.min(), dots.max()
        
        polys = [verts1, verts2]
        for poly_idx, poly in enumerate(polys):
            for edge in edges(poly):
                # axis perpendicular to edge
                axis = np.array([-edge[1], edge[0]])
                # Normalize axis
                norm = np.linalg.norm(axis)
                if norm < 1e-12:
                    continue
                axis = axis / norm
                p1 = get_projection(verts1, axis)
                p2 = get_projection(verts2, axis)
                if p1[1] < p2[0] - 1e-12 or p2[1] < p1[0] - 1e-12:
                    return False  # separating axis found
        # Also check axes of the second polygon's edges (already covered by above loop for both polys)
        return True  # no separating axis, overlap
    
    def overlap(i, j, positions):
        """Return True if squares i and j overlap (interiors touch counts as overlap? Problem says no shared interior point, so touching edges allowed.
        We treat touching as non-overlap. SAT with small epsilon accounts for floating errors."""
        ci, ri, si = positions[i]
        cj, rj, sj = positions[j]
        # quick AABB check
        vi = get_vertices(ci[0], ci[1], ri, si)
        vj = get_vertices(cj[0], cj[1], rj, sj)
        ai = aabb(vi)
        aj = aabb(vj)
        if not aabb_overlap(ai, aj):
            return False
        # precise SAT
        return separating_axis_test(vi, vj)
    
    def total_side(positions):
        return sum(p[2] for p in positions)
    
    def valid_positions(positions):
        """Check all pairs for overlap and that squares are inside [0,1]x[0,1]."""
        for i, (c, r, s) in enumerate(positions):
            # square inside unit square? Check vertices
            v = get_vertices(c[0], c[1], r, s)
            if np.any(v < -1e-9) or np.any(v > 1+1e-9):
                return False
            # slight margin
            # for j in range(i+1, len(positions)):
            #     if overlap(i, j, positions):
            #         return False
        # Check all pairs
        m = len(positions)
        # We'll check all pairs O(m^2), but m=n. For n up to maybe 20-30 this is fine.
        # But for larger n, we need speed. We'll optimize by only checking if AABB overlap.
        for i in range(m):
            ci, ri, si = positions[i]
            vi = get_vertices(ci[0], ci[1], ri, si)
            ai = aabb(vi)
            for j in range(i+1, m):
                cj, rj, sj = positions[j]
                vj = get_vertices(cj[0], cj[1], rj, sj)
                aj = aabb(vj)
                if aabb_overlap(ai, aj):
                    if separating_axis_test(vi, vj):
                        return False
        return True
    
    # Initial configuration: grid of floor(sqrt(n)) plus zeros
    def initial_configuration(n):
        k = int(math.floor(math.sqrt(n)))
        if k == 0:
            k = 1
        side = 1.0 / k
        positions = []
        for i in range(k):
            for j in range(k):
                if len(positions) < n:
                    cx = (i + 0.5) * side
                    cy = (j + 0.5) * side
                    positions.append(((cx, cy), 0.0, side))
        # Fill remaining with zeros
        while len(positions) < n:
            positions.append(((0.5, 0.5), 0.0, 0.0))
        return positions
    
    positions = initial_configuration(n)
    best_positions = positions[:]
    best_total = total_side(best_positions)
    
    if not valid_positions(positions):
        # Should be valid, but just in case
        positions = best_positions
    
    current_total = best_total
    
    # Simulated annealing parameters
    T_start = 0.01  # initial temperature (relative to side sum)
    T_end = 1e-7
    # Cooling schedule: exponential, T = T_start * (T_end/T_start)^(step/max_steps)
    # Time limit: we'll run until 58 seconds, using maximum iterations.
    max_time = time_limit - 1.0  # safety margin
    start_time = time.time()
    iteration = 0
    # Dynamic max steps based on n? We'll just loop until time out.
    
    # for efficiency, precompute current vertices for collision detection? We'll recompute as needed.
    
    while time.time() - start_time < max_time:
        iteration += 1
        # Compute current temperature
        progress = (time.time() - start_time) / max_time
        T = T_start * (T_end / T_start) ** progress
        
        # Generate neighbor: pick a random square, change one or more properties
        i = random.randrange(n)
        old_c, old_r, old_s = positions[i]
        
        # Choose mutation type
        mutation = random.choice(['move', 'rotate', 'resize', 'all'])
        
        if mutation == 'move':
            # move center by small random step, keep inside unit square roughly
            step = random.uniform(-0.1, 0.1) * (1.0 if old_s > 0 else 0.5)
            new_c = (old_c[0] + step * random.uniform(-1, 1), old_c[1] + step * random.uniform(-1, 1))
            # clamp to [0,1]
            new_c = (max(0.0, min(1.0, new_c[0])), max(0.0, min(1.0, new_c[1])))
            new_r = old_r
            new_s = old_s
        elif mutation == 'rotate':
            if old_s > 0:
                new_r = (old_r + random.uniform(-0.1, 0.1)) % 1.0
            else:
                new_r = old_r
            new_c = old_c
            new_s = old_s
        elif mutation == 'resize':
            if old_s > 0:
                # change size by relative factor or absolute
                delta = random.uniform(-0.05, 0.05) * old_s
                new_s = max(0.0, old_s + delta)
                if new_s < 1e-6:
                    new_s = 0.0  # set to zero
                # adjust center to keep inside bounds? We'll rely on validation
            else:
                # possibly grow a zero-square
                new_s = random.uniform(0, 0.3)
                # place randomly
                new_c = (random.uniform(0.2, 0.8), random.uniform(0.2, 0.8))
                new_r = random.uniform(0, 1)
            new_c = old_c
            new_r = old_r
        else:  # all
            if old_s > 0:
                step = random.uniform(-0.05, 0.05)
                new_c = (old_c[0] + step * random.uniform(-1, 1), old_c[1] + step * random.uniform(-1, 1))
                new_c = (max(0.0, min(1.0, new_c[0])), max(0.0, min(1.0, new_c[1])))
                new_r = (old_r + random.uniform(-0.05, 0.05)) % 1.0
                delta = random.uniform(-0.05, 0.05) * old_s
                new_s = max(0.0, old_s + delta)
                if new_s < 1e-6:
                    new_s = 0.0
            else:
                # grow
                new_s = random.uniform(0, 0.3)
                new_c = (random.uniform(0.2, 0.8), random.uniform(0.2, 0.8))
                new_r = random.uniform(0, 1)
        
        # Check validity of position i alone with bounds and other squares
        # First check if square i with new params is inside unit square
        vi_new = get_vertices(new_c[0], new_c[1], new_r, new_s)
        if np.any(vi_new < -1e-9) or np.any(vi_new > 1+1e-9):
            # out of bounds, reject
            continue
        
        # Check overlap with all other squares j
        ai_new = aabb(vi_new)
        valid_move = True
        for j in range(n):
            if j == i:
                continue
            cj, rj, sj = positions[j]
            vj = get_vertices(cj[0], cj[1], rj, sj)
            aj = aabb(vj)
            if aabb_overlap(ai_new, aj):
                if separating_axis_test(vi_new, vj):
                    valid_move = False
                    break
        
        if not valid_move:
            continue
        
        # Accept move?
        old_total = current_total
        new_total = old_total - old_s + new_s
        delta = new_total - old_total
        if delta > 0 or random.random() < math.exp(delta / (T + 1e-12)):
            # Accept
            positions[i] = (new_c, new_r, new_s)
            current_total = new_total
            if new_total > best_total:
                best_total = new_total
                best_positions = [ ( (c[0], c[1]), r, s ) for c, r, s in positions ]
    
    # Convert to required format
    result = []
    for (c, r, s) in best_positions:
        result.append((c[0], c[1], r, s))
    return result


# Example usage
if __name__ == "__main__":
    for n in [5,6,7,8,11,12,13,14,15]:
        sol = solve(n, time_limit=10)  # shorter for test
        total = sum(s[3] for s in sol)
        print(f"n={n}: sum={total:.5f}")
