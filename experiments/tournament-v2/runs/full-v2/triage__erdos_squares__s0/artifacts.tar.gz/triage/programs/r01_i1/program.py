# EVOLVE-BLOCK-START
"""Packing squares in a unit square by simulated annealing + constructive seeds.

The approach:
  * start from a good constructive configuration (grid / corner rotated square),
  * then run a fast simulated-annealing style local optimiser that moves squares,
    changes their sizes/angles and softly penalises overlaps and boundary
    violations.  The penalty is annealed away so the final configuration is
    (nearly) feasible.
  * Sizes of the "extra" squares (those not on a grid) are allowed to grow.

All arithmetic is done in plain Python lists / math; numpy & scipy available but
not required.  Time is bounded well below 60 s per call.
"""
import math
import random


# ---------------------------------------------------------------------------
# geometry helpers
# ---------------------------------------------------------------------------
def _half_extent(s, a):
    """Half-width and half-height of an axis-aligned bounding box of a square
    of side s rotated by angle a (fractions of a full turn)."""
    t = 2.0 * math.pi * a
    c = abs(math.cos(t))
    sn = abs(math.sin(t))
    return 0.5 * s * (c + sn), 0.5 * s * (c + sn)


def _corners(cx, cy, a, s):
    t = 2.0 * math.pi * a
    c = math.cos(t)
    sn = math.sin(t)
    h = 0.5 * s
    # local corners
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap_penalty(sq, eps):
    """Penalty for square sq = (cx,cy,a,s) exceeding unit box or overlapping
    others is computed outside; here we only compute boundary violation."""
    cx, cy, a, s = sq
    if s <= 0.0:
        return 0.0
    pts = _corners(cx, cy, a, s)
    pen = 0.0
    for x, y in pts:
        if x < -eps:
            pen += (-eps - x) ** 2
        elif x > 1.0 + eps:
            pen += (x - 1.0 - eps) ** 2
        if y < -eps:
            pen += (-eps - y) ** 2
        elif y > 1.0 + eps:
            pen += (y - 1.0 - eps) ** 2
    return pen


def _pair_penalty(s1, s2):
    """Approximate overlap penalty between two rotated squares.

    We use a separating-axis test on the 4 axes of both squares.  If all axes
    overlap, the squares' interiors intersect; the minimal overlap depth over
    the axes gives a penalty measure."""
    cx1, cy1, a1, s1_ = s1
    cx2, cy2, a2, s2_ = s2
    if s1_ <= 0.0 or s2_ <= 0.0:
        return 0.0
    # axes normals: for a square rotated by a, edges are at a, a+0.25 turns
    axes = []
    t1 = 2.0 * math.pi * a1
    t2 = 2.0 * math.pi * a2
    for t in (t1, t1 + 0.5 * math.pi, t2, t2 + 0.5 * math.pi):
        axes.append((math.cos(t), math.sin(t)))

    def proj(cx, cy, a, ss, ax, ay):
        t = 2.0 * math.pi * a
        c = math.cos(t)
        sn = math.sin(t)
        h = 0.5 * ss
        # project the four corners
        vals = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            px = cx + dx * c - dy * sn
            py = cy + dx * sn + dy * c
            vals.append(px * ax + py * ay)
        return min(vals), max(vals)

    min_pen = None
    for ax, ay in axes:
        lo1, hi1 = proj(cx1, cy1, a1, s1_, ax, ay)
        lo2, hi2 = proj(cx2, cy2, a2, s2_, ax, ay)
        ov = min(hi1, hi2) - max(lo1, lo2)
        if ov <= 0.0:
            return 0.0
        if min_pen is None or ov < min_pen:
            min_pen = ov
    return min_pen if min_pen else 0.0


def _total_penalty(squares, eps, w_pair=1.0):
    pen = 0.0
    n = len(squares)
    for s in squares:
        pen += _overlap_penalty(s, eps)
    for i in range(n):
        si = squares[i]
        if si[3] <= 0.0:
            continue
        for j in range(i + 1, n):
            sj = squares[j]
            if sj[3] <= 0.0:
                continue
            p = _pair_penalty(si, sj)
            if p:
                pen += w_pair * p * p
    return pen


def _score(squares):
    return sum(s[3] for s in squares)


# ---------------------------------------------------------------------------
# constructive seeds
# ---------------------------------------------------------------------------
def _grid_seed(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


def _corner_seed(n):
    """Big rotated square in a corner + grid of axis-aligned squares."""
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)] if n == 1 else []
    # try to place a rotated square of side s in the lower-left corner
    best = None
    best_score = -1.0
    for k in range(2, min(n, 8)):
        rem = n - 1
        # a rotated square of side s at angle 45 deg in the corner
        # then fill the remaining two triangles and outside with axis-aligned
        # simplest: just use grid for remainder
        s = 0.5
        cand = _grid_seed(rem)
        # shift grid squares to the right/up so corner is free?  Instead:
        # place the rotated square at the very corner and leave rest as zeros,
        # then let the annealer sort it out.
        conf = [(s * 0.5 * math.sqrt(2) / 1.0 * 0.5, s * 0.5 * math.sqrt(2) * 0.5,
                 0.125, s)] + cand
        sc = _score(conf)
        if sc > best_score:
            best_score = sc
            best = conf
    if best is None:
        best = _grid_seed(n)
    return best[:n]


# ---------------------------------------------------------------------------
# local optimiser
# ---------------------------------------------------------------------------
def _optimise(squares, n, time_budget=6.0, rng=None):
    import time
    if rng is None:
        rng = random.Random(12345 + n)

    squares = [list(s) for s in squares]

    def clamp_box(s):
        cx, cy, a, ss = s
        # keep centre inside
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        ss = max(ss, 0.0)
        return [cx, cy, a, ss]

    squares = [clamp_box(s) for s in squares]

    start = time.time()
    eps = 0.0
    # anneal: allow small violations early, drive to zero
    temp0 = 0.02
    cur_pen = _total_penalty(squares, eps)
    cur_val = _score(squares)

    # weighted objective: maximise value - penalty*big
    big = 50.0
    cur_obj = cur_val - big * cur_pen

    best = [s[:] for s in squares]
    best_val = cur_val
    best_pen = cur_pen

    step = 0
    while time.time() - start < time_budget:
        step += 1
        prog = (time.time() - start) / time_budget
        temp = temp0 * (1.0 - prog) + 1e-5
        # pick a random square
        i = rng.randrange(n)
        old = squares[i][:]
        new = old[:]
        r = rng.random()
        if r < 0.45:
            # jiggle position
            new[0] += rng.gauss(0, 0.02 * (1.0 - 0.8 * prog) + 0.002)
            new[1] += rng.gauss(0, 0.02 * (1.0 - 0.8 * prog) + 0.002)
        elif r < 0.65:
            # change angle
            new[2] += rng.gauss(0, 0.02 * (1.0 - 0.8 * prog) + 0.002)
        elif r < 0.85:
            # change size
            new[3] += rng.gauss(0, 0.02 * (1.0 - 0.8 * prog) + 0.002)
        else:
            # all
            new[0] += rng.gauss(0, 0.02 * (1.0 - 0.8 * prog) + 0.002)
            new[1] += rng.gauss(0, 0.02 * (1.0 - 0.8 * prog) + 0.002)
            new[2] += rng.gauss(0, 0.05 * (1.0 - 0.8 * prog) + 0.002)
            new[3] += rng.gauss(0, 0.02 * (1.0 - 0.8 * prog) + 0.002)
        new[3] = max(new[3], 0.0)
        new[2] = new[2] % 1.0
        new[0] = min(max(new[0], 0.0), 1.0)
        new[1] = min(max(new[1], 0.0), 1.0)

        squares[i] = new
        new_pen = _total_penalty(squares, eps)
        new_val = cur_val + (new[3] - old[3])
        new_obj = new_val - big * new_pen

        d = new_obj - cur_obj
        if d >= 0 or rng.random() < math.exp(d / max(temp, 1e-9)):
            cur_obj = new_obj
            cur_pen = new_pen
            cur_val = new_val
            if new_val - big * new_pen > best_val - big * best_pen:
                best = [s[:] for s in squares]
                best_val = new_val
                best_pen = new_pen
        else:
            squares[i] = old

    # final polishing: shrink to feasible
    # estimate max violation and scale out
    squares = best
    pen = _total_penalty(squares, 0.0)
    # small repair loop: if overlap, push squares apart a bit
    for _ in range(200):
        if pen < 1e-7:
            break
        for i in range(n):
            for j in range(i + 1, n):
                p = _pair_penalty(squares[i], squares[j])
                if p > 1e-9:
                    # move both apart along centre line
                    ci = squares[i]
                    cj = squares[j]
                    dx = cj[0] - ci[0]
                    dy = cj[1] - ci[1]
                    dd = math.hypot(dx, dy)
                    if dd < 1e-9:
                        dx, dy, dd = 1.0, 0.0, 1.0
                    ux, uy = dx / dd, dy / dd
                    shift = 0.5 * p
                    ci[0] = min(max(ci[0] - ux * shift, 0.0), 1.0)
                    ci[1] = min(max(ci[1] - uy * shift, 0.0), 1.0)
                    cj[0] = min(max(cj[0] + ux * shift, 0.0), 1.0)
                    cj[1] = min(max(cj[1] + uy * shift, 0.0), 1.0)
        pen = _total_penalty(squares, 0.0)
        # clamp
        for s in squares:
            s[0] = min(max(s[0], 0.0), 1.0)
            s[1] = min(max(s[1], 0.0), 1.0)
    return [tuple(s) for s in squares]


# ---------------------------------------------------------------------------
# main entry
# ---------------------------------------------------------------------------
_CACHE = {}


def solve(n):
    if n in _CACHE:
        return list(_CACHE[n])
    if n <= 0:
        return []
    if n == 1:
        res = [(0.5, 0.5, 0.0, 1.0)]
        _CACHE[n] = res
        return list(res)

    if n <= 4:
        # small cases: grid
        res = _grid_seed(n)
        _CACHE[n] = res
        return list(res)

    # try a few seeds, pick the best after a quick anneal
    seeds = []
    seeds.append(_grid_seed(n))
    seeds.append(_corner_seed(n))
    # random seeds
    rng = random.Random(999 + n)
    for _ in range(2):
        s = []
        for _i in range(n):
            s.append((rng.random(), rng.random(),
                      rng.random(), rng.uniform(0.05, 0.3)))
        seeds.append(s)

    best = None
    best_score = -1e9
    # allocate time budget
    budget = 8.0
    per = budget / len(seeds)
    for idx, sd in enumerate(seeds):
        res = _optimise(sd, n, time_budget=per, rng=random.Random(1000 + n * 7 + idx))
        sc = _score(res) - 20.0 * _total_penalty(res, 0.0)
        if sc > best_score:
            best_score = sc
            best = res

    # final strong anneal on best
    best = _optimise(best, n, time_budget=12.0, rng=random.Random(2000 + n))
    # ensure feasibility
    if n <= 2:
        best = _grid_seed(n)
    _CACHE[n] = best
    return list(best)
# EVOLVE-BLOCK-END
