# EVOLVE-BLOCK-START
"""Packing squares: grid plus slack-distributed extra squares.

For n not a perfect square, take the k x k grid (k = floor(sqrt(n))) and shrink the grid
squares uniformly, then use the freed space to insert the remaining r = n - k^2 squares.
"""
import math


def _grid_with_extras(n):
    k = math.isqrt(n)
    r = n - k * k
    if r == 0:
        side = 1.0 / k
        return [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]

    # Base grid occupies [0, k*s]^2 with square side s. We want total width 1.
    # Reserve a strip for extra squares. Try several layouts / strip sizes.
    best = None
    best_sum = -1.0

    # candidate shrink factors t in (0,1): grid side s = t / k, leftover (1-t) used
    # for extras along one edge (or split among edges).
    steps = 220
    for si in range(1, steps):
        t = si / steps
        s = t / k
        # free width available
        free = 1.0 - t
        if free <= 0:
            continue
        # Try to place r extras in the free strip of width `free` and height 1.
        # Extras could be squares of side up to `free`, stacked.
        # Simple greedy: m per column, columns along strip.
        extras = _place_extras(r, free)
        if extras is None:
            continue
        total = (k * k) * s + sum(e[3] for e in extras)
        if total > best_sum:
            best_sum = total
            grid = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                    for i in range(k) for j in range(k)]
            # shift extras into strip at right side [t, 1]
            placed = []
            for (ex, ey, ang, es) in extras:
                placed.append((t + ex, ey, ang, es))
            # rescale extra x-coordinates: they are stored in [0, free]
            best = grid + placed

    # Also try splitting free space between right strip and top strip for variety.
    for si in range(1, 120):
        t = si / 120
        s = t / k
        free = 1.0 - t
        if free <= 0:
            continue
        # split free into horizontal and vertical bands
        for frac in (0.35, 0.5, 0.65):
            fw = free * frac   # right band width
            fh = free * (1 - frac)  # top band height
            if fw <= 1e-9 or fh <= 1e-9:
                continue
            extras = _place_extras_split(r, fw, fh, t)
            if extras is None:
                continue
            total = (k * k) * s + sum(e[3] for e in extras)
            if total > best_sum:
                best_sum = total
                grid = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                        for i in range(k) for j in range(k)]
                best = grid + extras

    if best is None:
        # fallback
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * r
    return best


def _place_extras(r, width):
    """Place r equal squares of side = min(width, height/r?) inside strip [0,width]x[0,1]."""
    # Try single column of r equal squares of side a (a <= width, r*a <= 1).
    a_col = min(width, 1.0 / r) if r > 0 else 0.0
    # Try m columns each with c squares.
    best = None
    best_sum = -1.0
    for m in range(1, r + 1):
        c = math.ceil(r / m)
        a = min(width / m, 1.0 / c)
        if a <= 0:
            continue
        total = r * a
        if total > best_sum:
            best_sum = total
            best = m
    if best is None:
        return None
    m = best
    c = math.ceil(r / m)
    a = min(width / m, 1.0 / c)
    if a <= 1e-12:
        return None
    res = []
    count = 0
    for col in range(m):
        for row in range(c):
            if count >= r:
                break
            cx = (col + 0.5) * a
            cy = (row + 0.5) * a
            res.append((cx, cy, 0.0, a))
            count += 1
    return res


def _place_extras_split(r, fw, fh, t):
    """Place r squares using right band (width fw, full height) and top band (height fh)."""
    best = []
    best_sum = -1.0
    # right band squares side <= fw, stacked c in column
    # and top band squares side <= fh, placed in row
    for nr in range(0, r + 1):
        nt = r - nr
        ar = fw
        if nr > 0:
            ar = min(fw, 1.0 / nr)
        else:
            ar = 0.0
        at = fh
        if nt > 0:
            at = min(fh, 1.0 / nt)
        else:
            at = 0.0
        total = nr * ar + nt * at
        if total > best_sum:
            best_sum = total
            best = (nr, nt, ar, at)
    nr, nt, ar, at = best
    res = []
    # right band at x in [t, t+fw], y in [0,1]
    for i in range(nr):
        if ar <= 0:
            continue
        cy = (i + 0.5) * ar
        if cy + ar / 2 > 1.0 + 1e-9:
            break
        res.append((t + ar / 2, cy, 0.0, ar))
    # top band at y in [1-fh, 1], x in [0, t] (avoid overlap with right band)
    xt = max(t, 0.0)
    for i in range(nt):
        if at <= 0:
            continue
        cx = (i + 0.5) * at
        if cx + at / 2 > xt + 1e-9:
            break
        res.append((cx, 1.0 - fh + at / 2, 0.0, at))
    if len(res) < r:
        # pad with zeros
        while len(res) < r:
            res.append((0.5, 0.5, 0.0, 0.0))
    return res[:r]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    return _grid_with_extras(n)
# EVOLVE-BLOCK-END
