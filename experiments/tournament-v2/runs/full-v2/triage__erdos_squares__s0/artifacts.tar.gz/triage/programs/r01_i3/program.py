# EVOLVE-BLOCK-START
"""Hexagonal-like packing: alternate row shifts with adaptive size for better space utilization."""
import math
import numpy as np


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) using hexagonal packing."""
    squares = []
    
    if n <= 5:
        # Handle small n cases with known optimal or near-optimal patterns
        if n == 1:
            squares.append((0.5, 0.5, 0.0, 1.0))
        elif n == 2:
            squares = [(0.3, 0.5, 0.0, 0.5), (0.7, 0.5, 0.0, 0.5)]
        elif n == 3:
            squares = [(0.5, 0.5, 0.0, 1.0), (0.3, 0.3, 0.0, 0.2), (0.7, 0.3, 0.0, 0.2)]
        elif n == 4:
            squares = [(0.5, 0.5, 0.0, 1.0), 
                       (0.25, 0.25, 0.0, 0.25), (0.75, 0.25, 0.0, 0.25),
                       (0.5, 0.75, 0.0, 0.25)]
        elif n == 5:
            # 4 squares of side 0.5 in corners, 1 point at center
            squares = [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                       (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5),
                       (0.5, 0.5, 0.0, 0.0)]
    else:
        # Hexagonal packing: rows with alternating offsets
        m = max(3, int(math.sqrt(2*n/3)) + 1)
        s = 1.0 / m
        
        row_y_start = 0.5
        row_y_spacing = s * math.sqrt(3.0) / 2.0
        
        for row in range(m):
            # Even rows not shifted, odd rows shift by half a square side
            shift = (row % 2) * (s / 2.0)
            
            # Center positions: with spacing s between centers
            first_x = s - shift + s/2/math.sqrt(2)/2
            # Ensure first position fits in [s/2, 1-s/2]
            first_x = max(s / 2.0, s - shift)
            
            x_positions = [first_x + i * s for i in range(m)]
            # Clip to valid range [s/2, 1-s/2]
            x_positions = [max(s/2.0, min(1 - s/2.0, cx)) for cx in x_positions]
            
            # Add squares to this row until we have enough
            for j in range(len(x_positions)):
                if n - len(squares) <= 0:
                    break
                row_y = row_y_start + row * row_y_spacing
                squares.append((x_positions[j], row_y, 0.0, s))
    
    # Fill remaining n - len(squares) points with size-zero squares at center
    for _ in range(n - len(squares)):
        squares.append((0.5, 0.5, 0.0, 0.0))
    
    return squares[:n]
# EVOLVE-BLOCK-END
