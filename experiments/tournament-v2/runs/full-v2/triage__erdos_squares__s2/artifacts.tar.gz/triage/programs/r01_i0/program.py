import math
import random

def _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Approximate overlap check via separating axis theorem for squares."""
    if s1 <= 0 or s2 <= 0:
        return False
    def corners(cx, cy, a, s):
        c, sn = math.cos(2*math.pi*a), math.sin(2*math.pi*a)
        h = s/2
        pts = []
        for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)):
            pts.append((cx + dx*c - dy*sn, cy + dx*sn + dy*c))
        return pts
    p1 = corners(cx1, cy1, a1, s1)
    p2 = corners(cx2, cy2, a2, s2)
    axes = []
    for pts in (p1, p2):
        for i in range(4):
            x1,y1 = pts[i]
            x2,y2 = pts[(i+1)%4]
            ex, ey = x2-x1, y2-y1
            nrm = math.hypot(ex,ey)
            if nrm > 1e-12:
                axes.append((-ey/nrm, ex/nrm))
    for ax, ay in axes:
        min1 = min(px*ax+py*ay for px,py in p1)
        max1 = max(px*ax+py*ay for px,py in p1)
        min2 = min(px*ax+py*ay for px,py in p2)
        max2 = max(px*ax+py*ay for px,py in p2)
        if max1 <= min2 + 1e-9 or max2 <= min1 + 1e-9:
            return False
    return True

def _inside(cx, cy, a, s):
    c, sn = math.cos(2*math.pi*a), math.sin(2*math.pi*a)
    h = s/2
    for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)):
        x = cx + dx*c - dy*sn
        y = cy + dx*sn + dy*c
        if x < -1e-9 or x > 1+1e-9 or y < -1e-9 or y > 1+1e-9:
            return False
    return True

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # Start from best grid
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    while len(squares) > n:
        squares.pop()
    # Greedy: add squares in remaining space, then try local improvements
    while len(squares) < n:
        best = None
        # try random candidate placements
        for _ in range(200):
            s = random.uniform(0.01, 0.6)
            a = random.choice([0.0, 0.25, 0.125, 0.375, 0.0625, 0.1875, random.random()])
            cx = random.uniform(s/2, 1-s/2)
            cy = random.uniform(s/2, 1-s/2)
            if not _inside(cx, cy, a, s):
                continue
            ok = True
            for (x,y,aa,ss) in squares:
                if _overlap(cx,cy,a,s,x,y,aa,ss):
                    ok = False
                    break
            if ok:
                if best is None or s > best[3]:
                    best = (cx,cy,a,s)
        if best is None:
            squares.append((0.5,0.5,0.0,0.0))
        else:
            squares.append(best)
    # Try to enlarge each square
    squares = [list(s) for s in squares]
    improved = True
    it = 0
    while improved and it < 8:
        improved = False
        it += 1
        for idx in range(len(squares)):
            cx, cy, a, s = squares[idx]
            lo, hi = s, min(cx, 1-cx, cy, 1-cy)*2 + 0.001
            hi = min(hi, 1.5)
            best_s = s
            for _ in range(20):
                mid = (lo+hi)/2
                if mid <= s:
                    lo = mid
                    continue
                # check expanding around center
                if not _inside(cx,cy,a,mid):
                    hi = mid
                    continue
                ok = True
                for j in range(len(squares)):
                    if j == idx: continue
                    x2,y2,aa2,ss2 = squares[j]
                    if _overlap(cx,cy,a,mid,x2,y2,aa2,ss2):
                        ok = False
                        break
                if ok:
                    best_s = mid
                    lo = mid
                else:
                    hi = mid
            if best_s > s + 1e-9:
                squares[idx][3] = best_s
                improved = True
    return [tuple(s) for s in squares]
