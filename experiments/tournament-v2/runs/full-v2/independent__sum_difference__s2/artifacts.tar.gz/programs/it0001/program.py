import math
import random
import time


def _score_parts(a):
    A = list(set(a))
    n = len(A)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        x = A[i]
        for j in range(n):
            y = A[j]
            diffs.add(x - y)
            sums.add(x + y)
    d = len(diffs)
    s = len(sums)
    score = math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0
    return score, d, s


def _score(a):
    return _score_parts(a)[0]


def solve():
    random.seed(123456789)
    deadline = time.time() + 115.0

    # A known good structured construction: symmetric around 0 makes sums smaller
    # while preserving many differences.  Start from small Sidon/Golomb-like sets.
    starts = [
        [0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96, 122, 147, 181, 203],
        [0, 1, 4, 10, 18, 23, 25, 29, 42, 57, 68, 79, 95, 105, 123, 137],
        [0, 1, 3, 8, 12, 22, 28, 36, 47, 59, 74, 90, 110, 127, 149, 167],
        [0, 2, 5, 11, 15, 24, 36, 48, 61, 77, 92, 109, 128, 151, 171, 189],
    ]

    best = None
    best_score = -1e100
    best_d = 0
    best_s = 0

    # First improve each structured start by local search.
    for st in starts:
        if time.time() > deadline:
            break
        cur = st[:]
        cur_score, d, s = _score_parts(cur)
        if cur_score > best_score:
            best = cur[:]
            best_score = cur_score
            best_d, best_s = d, s

    # Main search: randomized greedy expansion plus local perturbation.
    # We use sets centered near 0 so that A+A has many collisions but A-A is large.
    while time.time() < deadline:
        # occasionally build fresh set greedily
        if random.random() < 0.15 or best is None:
            cur = [0]
            n_target = random.randint(20, 120)
            for _ in range(n_target):
                cand_add = []
                base = cur[:]
                existing_sums = {x + y for x in base for y in base}
                existing_diffs = {x - y for x in base for y in base}
                for _try in range(30):
                    v = random.randint(-200, 200)
                    if v in base:
                        continue
                    new_sums = {v + x for x in base}
                    new_sums.add(2 * v)
                    new_diffs = {v - x for x in base}
                    new_diffs.update({x - v for x in base})
                    new_diffs.add(0)
                    # estimate score improvement
                    ns = len(existing_sums | new_sums)
                    nd = len(existing_diffs | new_diffs)
                    if ns <= 0:
                        continue
                    ratio = math.log(nd) / math.log(ns)
                    cand_add.append((ratio, v))
                if not cand_add:
                    break
                cand_add.sort(reverse=True)
                # pick among top few
                top = cand_add[:max(1, min(5, len(cand_add)))]
                _, v = random.choice(top)
                cur.append(v)
            cur = list(set(cur))
        else:
            cur = best[:]

        cur = list(set(cur))
        cur_score, cd, cs = _score_parts(cur)

        # simulated annealing / hill climbing
        temp = 0.02
        local_deadline = min(deadline, time.time() + random.uniform(0.5, 3.0))
        while time.time() < local_deadline:
            cand = cur[:]
            op = random.random()

            if op < 0.45 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-8, 8)
            elif op < 0.75:
                cand.append(random.randint(-250, 250))
            elif op < 0.9 and len(cand) > 15:
                i = random.randrange(len(cand))
                del cand[i]
            else:
                # perturb several elements
                for _ in range(random.randint(1, 4)):
                    if cand and random.random() < 0.7:
                        i = random.randrange(len(cand))
                        cand[i] += random.randint(-15, 15)
                    else:
                        cand.append(random.randint(-300, 300))

            cand = list(set(cand))
            if len(cand) < 2:
                continue

            s2, d2, ss2 = _score_parts(cand)
            if s2 >= cur_score or random.random() < math.exp(min(0, (s2 - cur_score) / max(temp, 1e-9))):
                cur = cand
                cur_score = s2
                cd, cs = d2, ss2

            if cur_score > best_score:
                best = cur[:]
                best_score = cur_score
                best_d, best_s = cd, cs

            temp *= 0.9995

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    result = sorted(set(best))
    # ensure within limits
    result = [x for x in result if abs(x) <= 10**15][:4000]
    if len(result) < 2:
        result = [0, 1]
    return result
