# EVOLVE-BLOCK-START
import math
import random
import time

def _score_vals(dn, sn, n):
    if sn <= 1 or n < 2:
        return 0.0
    return math.log(dn) / math.log(sn) + (1.0 - 1.0 / n) / 100.0

def _full(a):
    s = set(a)
    d = {x - y for x in s for y in s}
    sm = {x + y for x in s for y in s}
    return _score_vals(len(d), len(sm), len(s))

def _construct_modular(p, shift=0):
    # quadratic residues mod prime: sums concentrate, differences spread
    A = []
    for x in range(1, p):
        A.append((x * x) % p)
    return sorted(set(A))

def _construct_ap_pert(n):
    # small additive doubling base with multiplicative perturbation
    A = []
    for i in range(n):
        A.append(i * (n + 1) + (i * i) % (n + 1))
    return sorted(set(A))

def _construct_base_B(n, B):
    # base-B mixed radix: digits 0/1 give small sumset structure
    A = []
    for mask in range(1 << n):
        v = 0
        m = mask
        for k in range(n):
            if m & 1:
                v += B ** k
            m >>= 1
        A.append(v)
    return A

def solve():
    random.seed(12345)
    deadline = time.time() + 115.0
    best = [7, 15, 18, 22, -3, -2]
    best_s = _full(best)

    # candidate seeds
    seeds = []
    seeds.append(best[:])
    # quadratic residues style
    for p in [31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173]:
        A = _construct_modular(p)
        if len(A) >= 2 and len(A) <= 4000:
            seeds.append(A)
    for n in range(2, 13):
        for B in [3, 4, 5, 6, 7, 8, 10, 13, 16]:
            A = _construct_base_B(n, B)
            if len(A) <= 4000:
                seeds.append(A)
    for n in range(5, 60):
        seeds.append(_construct_ap_pert(n))

    for A in seeds:
        if time.time() > deadline:
            break
        A = sorted(set(A))
        if len(A) < 2 or len(A) > 4000:
            continue
        s = _full(A)
        if s > best_s:
            best_s = s
            best = A[:]

    # local refinement using random perturbations
    def local(cur, tlimit, iters_cap=10**9):
        nonlocal best, best_s
        cur = cur[:]
        cs = _full(cur)
        it = 0
        while time.time() < tlimit and it < iters_cap:
            it += 1
            cand = cur[:]
            r = random.random()
            if r < 0.5:
                # perturb an element
                i = random.randrange(len(cand))
                cand[i] += random.randint(-2, 2)
            elif r < 0.8:
                # add element
                if len(cand) < 4000:
                    cand.append(random.randint(-50, 50))
            else:
                # remove element
                if len(cand) > 2:
                    del cand[random.randrange(len(cand))]
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            s = _full(cand)
            if s >= cs:
                cur = cand
                cs = s
                if s > best_s:
                    best_s = s
                    best = cand[:]
            elif random.random() < 0.02:
                cur = cand
                cs = s
        return cur

    # refine the top seeds
    order = sorted(seeds, key=lambda A: -_full(sorted(set(A)) if 2 <= len(set(A)) <= 4000 else [0, 0]))
    step = max(1.0, (deadline - time.time()) / max(1, len(order[:40])))
    for A in order[:40]:
        if time.time() > deadline:
            break
        local(sorted(set(A)), min(deadline, time.time() + step))

    # final greedy polish on best
    while time.time() < deadline:
        local(best, min(deadline, time.time() + 5.0), iters_cap=200000)

    # a final exhaustive-ish cleanup: try scaling
    return sorted(set(best))
# EVOLVE-BLOCK-END
