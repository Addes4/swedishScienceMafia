import math
import random
import time

def _score(a):
    """Compute the objective function for a set A."""
    a = set(map(int, a))
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def construct_geometric_set(n, base=1, ratio=3):
    """Generate a geometric-like set with controlled sum/difference properties."""
    result = []
    for i in range(n):
        result.append(int(base * (ratio ** i)))
    return result

def construct_polynomial_set(n, deg=2):
    """Generate a polynomial sequence set (e.g., quadratic)."""
    return [(i ** deg + i) % (10**15 + 7) for i in range(n)]

def construct_block_union(k, block_size, gap):
    """Create a union of k arithmetic progressions with large gaps."""
    result = []
    for i in range(k):
        start = i * gap
        for j in range(block_size):
            result.append(start + j)
    return result

def construct_mixed_set(geometric_factor, poly_base, size):
    """Hybrid: scaled polynomial values with geometric separation."""
    result = []
    exp = 0
    for _ in range(size):
        val = poly_base + exp
        result.append(val)
        exp += geometric_factor * (exp // 100 + 1) if exp > 0 else 1
    return list(set(result))[:size]

def _optimize_block(base_set, mutate_rate=0.3, steps=100):
    """Local search starting from block-structured seed."""
    current = sorted(list(set(base_set)))
    best = current[:]
    best_score = _score(best)
    
    for _ in range(steps):
        cur = best[:]
        # Try block translation
        if random.random() < mutate_rate:
            block_start = random.randint(0, len(cur) // 3)
            block_len = max(1, len(cur) // (block_start * 2 + 1))
            shift = random.randint(-10, 10)
            block = cur[block_start:block_start + block_len]
            new_block = [x + shift for x in block]
            cur[block_start:block_start + block_len] = new_block
            # Enforce uniqueness
            cur = list(set(cur))
            if len(cur) != len(best):
                cur = sorted(cur[:len(best)])
        # Occasional mutation to improve
        elif random.random() < mutate_rate:
            idx = random.randint(0, len(cur) - 1)
            delta = random.randint(-5, 5)
            if delta != 0:
                cur[idx] += delta
                cur = list(set(cur))
                if len(cur) != len(best):
                    cur = sorted(cur[:len(best)])
        
        s = _score(cur)
        if s > best_score:
            best, best_score = cur, s
    
    return best

def _generate_seeds():
    """Generate diverse starting configurations."""
    seeds = []
    
    # Geometric growth
    seeds.append(construct_geometric_set(20, base=1, ratio=3))
    seeds.append(construct_geometric_set(25, base=2, ratio=5))
    
    # Polynomial-like
    seeds.append(construct_polynomial_set(15, deg=2))
    seeds.append(construct_polynomial_set(20, deg=3))
    
    # Block unions
    seeds.append(construct_block_union(5, 10, 100))
    seeds.append(construct_block_union(10, 5, 200))
    
    # Mixed construction
    for gf in [10, 50, 100]:
        for pb in [0, 100, 500]:
            seeds.append(construct_mixed_set(gf, pb, 15))
    
    # Random structured
    for _ in range(5):
        base = sorted(random.sample(range(1000), 10))
        ext = [b + i*15 for b in base for i in range(random.randint(1, 4))]
        seeds.append(sorted(set(ext))[:20])
    
    return seeds

def solve():
    """Find set A maximizing log|A-A|/log|A+A|."""
    global best_set, best_score
    
    deadline = time.time() + 120
    all_seeds = _generate_seeds()
    best_set = None
    best_score = -1e9
    
    for seed in all_seeds:
        if len(seed) < 3:
            continue
        if time.time() >= deadline:
            break
        if _score(seed) > best_score:
            best_score = _score(seed)
            best_set = seed[:]
            
        # Run local search from seed
        optimized = _optimize_block(seed)
        if _score(optimized) > best_score:
            best_score = _score(optimized)
            best_set = optimized[:]
    
    # Final refinement with full restart
    for _ in range(5):
        seed = all_seeds[hash(random.randint(0, len(all_seeds)-1)) % len(all_seeds)]
        if time.time() >= deadline:
            break
        optimized = _optimize_block(seed, mutate_rate=0.5, steps=200)
        if _score(optimized) > best_score:
            best_score = _score(optimized)
            best_set = optimized[:]
    
    # Normalize for output
    return sorted(list(set(best_set)))

if __name__ == "__main__":
    result = solve()
    print(len(result))
