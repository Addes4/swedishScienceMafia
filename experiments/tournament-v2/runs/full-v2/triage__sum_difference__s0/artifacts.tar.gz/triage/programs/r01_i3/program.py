# EVOLVE-BLOCK-START
"""Final optimized construction with multiple multiplier strategy."""
import math
import random
import time
from scipy.optimize import differential_evolution


def _generate_primes_upto(limit):
    """Generate primes up to a limit using Sieve of Eratosthenes."""
    sieve = [True] * (limit + 1)
    sieve[0:2] = [False, False]
    for i in range(2, int(limit ** 0.5) + 1):
        if sieve[i]:
            for j in range(i * i, limit + 1, i):
                sieve[j] = False
    return [i for i, prime in enumerate(sieve) if prime]


def construct_set(n, g, p, multipliers=None, seed=42):
    """Construct set based on g^i mod p with optional multipliers."""
    random.seed(seed + hash((n, g, p)) % 1000)
    if multipliers is None:
        m_values = [1, 2, 3, 5, 7]
    else:
        m_values = multipliers
    A = set()
    seen = set()
    for i in range(n):
        base = pow(g, i, p)
        for m in m_values:
            elem = (base * m) % p
            if elem not in seen:
                A.add(elem)
                seen.add(elem)
                if len(A) >= n:
                    return sorted(list(A))[:n]
    if len(A) > 0:
        return sorted(list(A))
    return []


def _score(A):
    a_set = set(A)
    if len(a_set) < 2:
        return 0.0
    diffs = {x - y for x in a_set for y in a_set}
    sums = {x + y for x in a_set for y in a_set}
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a_set)) / 100
    return score


def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    primes = _generate_primes_upto(6000000)
    L = len(primes)
    n0 = 300

    def objective(params):
        idx, g, mult = params
        if idx < 0 or idx >= L or g < 2 or g > primes[idx] - 1 or not isinstance(mult, bool):
            return -1e9
        p = primes[idx]
        A = construct_set(n0, g, p, multipliers=[1, 2] if mult else [1])
        if not A:
            return -1e9
        s = _score(A)
        return -s

    bounds = [
        (0, L - 1),
        (2, min(50000, primes[0] - 1)),
        (0, 2)
    ]

    best_f = -1
    best_A = []
    
    # Run multiple strategies
    configs = [(n0, 0.5), (350, 0.5), (250, 1.5)]
    for config in configs:
        n = int(config[0])
        weight = config[1]
        params = differential_evolution(
            objective, bounds, maxiter=30, popsize=10, 
            mutation=(0.5, 1.5), tol=1e-5, seed=42, disp=False, workers=1,
            polish=False
        )
        idx, g, mult = params.round()[0], params.round()[1], bool(params.round()[2])
        p = primes[idx]
        A = construct_set(n, g, p, multipliers=[1, 2] if mult else [1])
        s = _score(A)
        if s > best_f:
            best_f = s
            best_A = A
    
    # Final polish attempt
    for idx in [0, L // 10, L // 2, L - 1]:
        p = primes[idx]
        for g in [2, 3, 5, 7, 11]:
            if g < p:
                for m in [1, 2]:
                    A = construct_set(n0, g, p, multipliers=[m])
                    if len(A) >= n0 - 50:
                        s = _score(A)
                        if s > best_f:
                            best_f = s
                            best_A = A
                            break
        if A: break
    
    if not best_A:
        best_A = [i for i in range(1, 500)]
    
    return sorted(set(best_A))
# EVOLVE-BLOCK-END
