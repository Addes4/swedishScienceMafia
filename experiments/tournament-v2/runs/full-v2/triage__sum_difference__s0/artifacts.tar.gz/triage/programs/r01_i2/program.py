import math
import random
import time

def score_from_sets(n, diff_size, sum_size):
    if n < 2:
        return 0.0
    return math.log(diff_size) / math.log(sum_size) + (1 - 1/n) / 100

def compute_sizes(A):
    # Using numpy if available for speed, fallback to pure Python
    try:
        import numpy as np
        arr = np.array(A, dtype=np.int64)
        n = len(arr)
        # differences
        diffs = np.unique(np.subtract.outer(arr, arr).ravel())
        # sums
        sums = np.unique(np.add.outer(arr, arr).ravel())
        return len(diffs), len(sums)
    except ImportError:
        A_set = set(A)
        n = len(A_set)
        diffs = {x - y for x in A_set for y in A_set}
        sums = {x + y for x in A_set for y in A_set}
        return len(diffs), len(sums)

def evaluate(A):
    diff_size, sum_size = compute_sizes(A)
    return score_from_sets(len(set(A)), diff_size, sum_size)

def solve():
    random.seed(42)
    deadline = time.time() + 118  # leave 2 seconds margin

    # --- Construction: subset sums of base B, scaled and shifted ---
    # We want many differences (large additive energy) but few sums (small doubling constant).
    # A known trick: take a set of numbers with many additive relations, like geometric progression.
    # Here we use the idea: pick numbers of the form sum_{i=0}^{k-1} eps_i * M^i where eps_i in {0,1}.
    # This gives 2^k numbers with many sums/diffs controlled by base M.
    # For differences to be many, M should be > 2, but for sums to be few, M should be small.
    # Balancing yields M = 3 is a classic for Sidon sets? Actually M=2 gives binary, many sums.
    # We use M = 3 base with digits 0,1: this gives set with small doubling.
    # We then optimize via greedy swaps and local hill climbing.

    # Parameters
    k = 12  # gives 4096 points, slightly above the 4000 limit, we'll subsample
    base = 3
    # generate all 2^k combinations
    all_vals = []
    for mask in range(1 << k):
        val = 0
        for i in range(k):
            if mask & (1 << i):
                val += base ** i
        all_vals.append(val)
    # sort to get a narrow interval? They are already spread, we compress by scaling and shifting?
    # The set is large in absolute terms, but we can scale down by a huge factor and add offset.
    # Actually, we want numbers within 1e15, they are huge (3^11 is 177147), so that's fine.
    # But we need to ensure |A-A| large relative to |A+A|. Original set may have certain structure.
    # We'll select a subset of these points to satisfy constraint, then hill climb.

    # Select an initial subset: we can take all, but that's 4096 > 4000, so drop some.
    # We'll keep up to 4000.
    initial_A = all_vals[:4000]  # max 4000
    # We'll try to improve by local modifications.

    # Use sets for faster operations
    import numpy as np
    A_array = np.array(initial_A, dtype=np.int64)
    A_list = list(initial_A)
    A_set = set(A_list)

    best_A = A_list[:]
    best_score = evaluate(best_A)

    # Warm start: random local search
    # We allow: changing one element slightly (shift by small amount), adding, removing.
    cur_A = best_A[:]
    cur_score = best_score

    iteration = 0
    while time.time() < deadline:
        iteration += 1
        # Choose operation
        op = random.random()
        cand = cur_A[:]
        if op < 0.6:  # modify one element
            if not cand:
                continue
            idx = random.randrange(len(cand))
            old = cand[idx]
            # shift by small random amount (can be negative)
            delta = random.randint(-5, 5)
            if delta == 0:
                delta = 1
            new_val = old + delta
            # ensure distinctness
            if new_val in cand[:idx] + cand[idx+1:]:
                continue
            cand[idx] = new_val
        elif op < 0.85:  # add a new element
            if len(cand) >= 4000:
                continue
            # generate new element near some existing
            if cand:
                base_val = random.choice(cand)
                new_val = base_val + random.randint(-10, 10)
            else:
                new_val = random.randint(-50, 50)
            if new_val in cand:
                continue
            cand.append(new_val)
        else:  # remove an element
            if len(cand) <= 5:
                continue
            idx = random.randrange(len(cand))
            cand.pop(idx)

        # evaluate
        if cand:
            diff_sz, sum_sz = compute_sizes(cand)
            cand_score = score_from_sets(len(cand), diff_sz, sum_sz)
            if cand_score >= cur_score:
                cur_A = cand
                cur_score = cand_score
                if cand_score > best_score:
                    best_A = cand[:]
                    best_score = cand_score
            # Occasionally reset to best to escape local minima
            elif random.random() < 0.05:
                cur_A = best_A[:]
                cur_score = best_score

    # Final polish: try systematic small perturbations on best
    # For each element, try shifting by -2..2 and keep if improves.
    improved = True
    polish_start = time.time()
    while improved and time.time() < deadline:
        improved = False
        A_set = set(best_A)
        for i in range(len(best_A)):
            original = best_A[i]
            best_local = original
            best_local_score = best_score
            for delta in range(-3, 4):
                if delta == 0:
                    continue
                new_val = original + delta
                if new_val in A_set:
                    continue
                test_A = best_A[:]
                test_A[i] = new_val
                diff_sz, sum_sz = compute_sizes(test_A)
                sc = score_from_sets(len(test_A), diff_sz, sum_sz)
                if sc > best_local_score:
                    best_local = new_val
                    best_local_score = sc
            if best_local != original:
                best_A[i] = best_local
                A_set.remove(original)
                A_set.add(best_local)
                best_score = best_local_score
                improved = True

    # Ensure distinct
    best_A_unique = list(set(best_A))
    # If below max limit, we could try to add more elements that improve score
    while len(best_A_unique) < 4000 and time.time() < deadline:
        # try to add an element near existing ones
        base = random.choice(best_A_unique)
        for delta in range(-5, 6):
            candidate = base + delta
            if candidate not in best_A_unique:
                test_A = best_A_unique + [candidate]
                diff_sz, sum_sz = compute_sizes(test_A)
                sc = score_from_sets(len(test_A), diff_sz, sum_sz)
                if sc > best_score:
                    best_A_unique.append(candidate)
                    best_score = sc
                    break
        else:
            break  # no improvement

    return sorted(best_A_unique)

if __name__ == "__main__":
    # For testing
    A = solve()
    print(f"len: {len(A)}, score: {evaluate(A)}")
