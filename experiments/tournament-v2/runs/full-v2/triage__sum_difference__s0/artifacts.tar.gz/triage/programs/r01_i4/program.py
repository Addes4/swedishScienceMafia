import math
import random
import time
import itertools
from collections import defaultdict

def _precompute_benefit_naive(a):
    """Compute the marginal benefit of adding each possible element."""
    # This is expensive, so we'll use a heuristic version
    pass

def _greedy_boost(A, max_additions=20, time_limit=0.1):
    """Greedily add elements to A that maximize the difference-to-sum ratio improvement."""
    A = set(A)
    if not A:
        return A
    # Precompute current sets
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    
    # Limit candidate range to something manageable around current elements
    min_val = min(A) - max(A) - 10
    max_val = max(A) + max(A) - min(A) + 10
    # But we need to restrict to avoid huge loops
    # We'll consider candidates in the range [min_val, max_val] but not too many
    # For large sets, this is too big. We'll use a heuristic sample.
    
    # Instead, we'll consider elements that are specifically good for differences.
    # An element x contributes differences x - y for all y in A.
    # So adding x adds len(A) new differences (some may be duplicates).
    # We want these differences to be mostly new.
    # Similarly, it adds x + y for all y in A, which we want to be mostly old.
    # So we want x such that {x - y | y in A} has many new elements,
    # and {x + y | y in A} has few new elements.
    
    # We'll sample candidates from nearby integers and also from sums/differences patterns.
    candidates = set()
    # Candidates that are close to existing elements (small modifications)
    for a in A:
        for d in range(-10, 11):
            candidates.add(a + d)
    # Candidates that are specifically chosen to create new differences without new sums.
    # If we pick x such that x - y1 = y2 - y3 for some y1, y2, y3, then it might reuse existing differences.
    # Our goal: many new differences.
    # New differences are elements not in current diffs.
    # So we can try to find x such that x - y is often not in diffs.
    # But we cannot enumerate all possible x.
    # Instead, we'll do a hill-climbing: start from a candidate, evaluate its benefit, keep if good.
    
    # We'll use a time-bound loop
    start = time.time()
    improved = True
    additions = 0
    while improved and additions < max_additions and (time.time() - start) < time_limit:
        improved = False
        best_cand = None
        best_ratio = 0
        best_new_diffs = 0
        best_new_sums = 0
        # Evaluate candidates
        # For efficiency, we precompute something? Not easily.
        # We'll just evaluate a random subset of candidates if too many.
        cand_list = list(candidates)[:200] + random.sample(list(range(min_val, max_val+1)), min(200, max_val-min_val+1))
        for c in cand_list:
            if c in A:
                continue
            new_diffs = set()
            new_sums = set()
            for y in A:
                d = c - y
                s = c + y
                if d not in diffs:
                    new_diffs.add(d)
                if s not in sums:
                    new_sums.add(s)
            # Metric: we want many new diffs, few new sums
            # Use ratio of new diffs to (1 + new sums) or similar
            if new_sums == 0:
                # Perfect: no new sums! Highly beneficial
                benefit = len(new_diffs) + 1.0  # strongly prefer
            else:
                benefit = len(new_diffs) / len(new_sums)
            if benefit > best_ratio:
                best_ratio = benefit
                best_cand = c
                best_new_diffs = new_diffs
                best_new_sums = new_sums
        if best_cand is not None and best_ratio > 0.5:  # threshold to ensure improvement
            # Add best_cand
            A.add(best_cand)
            diffs.update(best_new_diffs)
            sums.update(best_new_sums)
            additions += 1
            improved = True
            # Update candidate set to include this new element
            # Add variations around the new element
            for d in range(-5, 6):
                candidates.add(best_cand + d)
    return A

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    cur = best[:]
    deadline = time.time() + 110  # leave some margin
    while time.time() < deadline:
        # Apply greedy booster periodically to candidate or best?
        # We'll apply it to cur before evaluation sometimes.
        if random.random() < 0.2:  # 20% of the time
            boosted = _greedy_boost(cur[:], max_additions=5, time_limit=0.01)  # quick boost
            # The booster returns a set, convert to list
            cur_boosted = list(boosted)
            sc = _score(cur_boosted)
            if sc > best_score:
                best = cur_boosted
                best_score = sc
                cur = cur_boosted
            # else continue with regular search
        # Regular local search
        cand = cur[:]
        # mutation
        if random.random() < 0.3:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        if random.random() < 0.1:
            cand.append(random.randint(min(cand)-5, max(cand)+5) if cand else random.randint(-10,10))
        if random.random() < 0.05 and len(cand) > 5:
            cand.pop(random.randrange(len(cand)))
        # Keep candidate size within limits
        if len(cand) > 200:  # limit growth
            cand = cand[:150]
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand, s, cand
        elif random.random() < 0.1:
            cur = best[:]
        # Also occasionally run booster on best and see if it improves further
        if random.random() < 0.01:
            boosted_best = _greedy_boost(best[:], max_additions=10, time_limit=0.02)
            sc_bb = _score(list(boosted_best))
            if sc_bb > best_score:
                best = list(boosted_best)
                best_score = sc_bb
                cur = best[:]
    # Final boost on best
    final = _greedy_boost(best, max_additions=50, time_limit=2.0)
    final_list = list(final)
    # Ensure distinct and within bounds
    final_list = sorted(set(final_list))
    # Trim if too large? 4000 limit.
    if len(final_list) > 4000:
        final_list = final_list[:4000]
    return final_list

# EVOLVE-BLOCK-END
