# EVOLVE-BLOCK-START
"""Hybrid simulated annealing: random progressions + cut-and-paste recombination.

Goal: maximize log|A-A| / log|A+A| with a small bonus for larger sets.
Strategy:
  - The theoretical maximum is around 4/3 (achieved by Sidon-like / perfect difference sets),
    e.g. a set whose differences cover a huge range while sums stay few.
  - Small sets have noisy ratio; larger structured sets (e.g. quadratic/poly residues,
    Golomb-ruler-like constructions, or affine copies of perfect difference sets) do well.
  - We build candidates from arithmetic/geometric progressions, random subsets,
    and quadratic-residue-style sets, then refine with simulated annealing on integers.
  - Cut-and-paste recombination: take halves/pruned pieces of the best set and combine.
"""
import math
import random
import time


def _score_details(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0, n
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1 or ld <= 1:
        return 0.0, ld, ls, n
    score = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
    return score, ld, ls, n


def _diffs(a):
    n = len(a)
    d = set()
    for i in range(n):
        ai = a[i]
        for j in range(i + 1, n):
            d.add(ai - aj)
            d.add(aj - ai)
    d.add(0)
    return d


def _sums(a):
    n = len(a)
    s = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            s.add(ai + a[j])
    return s


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    ld = len(_diffs(a))
    ls = len(_sums(a))
    if ls <= 1 or ld <= 1:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _builder_perfect_difference_field(p, shift=0):
    """Perfect difference set of size p+1 from a projective plane iff p is prime power (use prime)."""
    # Standard construction: D = {x in Z_{p^2+p+1} : x^2+x+1 = 0 mod ...} complicated.
    # Simple fallback: quadratic residues mod q for prime q give difference-rich small sets.
    return None


def _builder_quadratic_residues(q, offset=0):
    """Quadratic residues mod prime q. |A| ~ q/2, differences cover almost all of Z_q, sums too.
    Mod small q gives compact integers but sums also large; scale can't help because we work in Z."""
    res = sorted({(x * x) % q for x in range(q)}) 
    # shift to center around 0
    return [r + offset for r in res]


def _builder_progression(step, n, start):
    return [start + step * i for i in range(n)]


def _builder_geometric(r, n, start=0):
    out = []
    v = start + 1
    for _ in range(n):
        out.append(v)
        v *= r
        if abs(v) > 10**14:
            break
    return out


def _builder_ruler(n):
    """Sidon-ish / Golomb ruler-like greedy: keep adding the largest integer such that
    the resulting difference set grows fast while the sum set stays bounded-ish."""
    a = [0]
    used_d = {0}
    maxv = 0
    while len(a) < n:
        best_v = None
        best_gain = -1
        # try candidates
        for trial in range(40):
            cand = random.randint(1, max(10, 4 * len(a) * len(a)))
            if cand in a:
                continue
            new_d = set()
            ok = True
            for x in a:
                new_d.add(cand - x)
                new_d.add(x - cand)
            gain = len(new_d - used_d)
            if gain > best_gain:
                best_gain = gain
                best_v = cand
        if best_v is None:
            break
        a.append(best_v)
        for x in a:
            used_d.add(best_v - x)
            used_d.add(x - best_v)
        maxv = max(maxv, best_v)
    return a


def _local_improve(a, deadline, best_score):
    """Simulated annealing with larger local moves."""
    a = list(set(a))
    if len(a) < 2:
        return a, best_score
    cur = a[:]
    cur_score = _score(cur)
    if cur_score > best_score:
        best_score = cur_score
        bestlist = cur[:]
    else:
        bestlist = a[:]
    T = 0.05
    it = 0
    while time.time() < deadline:
        it += 1
        if it % 200 == 0:
            T = max(0.0005, T * 0.995)
        cand = cur[:]
        r = random.random()
        m = len(cand)
        if r < 0.55:
            # perturb element with size depending on T
            i = random.randrange(m)
            step = max(1, int(1 + abs(random.gauss(0, 3 + 30 * T))))
            cand[i] += random.choice([-1, 1]) * step
        elif r < 0.75:
            # move block of elements
            i = random.randrange(m)
            shift = random.choice([-1, 1]) * random.randint(1, 5)
            for k in range(i, min(m, i + random.randint(1, 4))):
                cand[k] += shift
        elif r < 0.90:
            # add a new element near an existing one
            i = random.randrange(m)
            cand.append(cand[i] + random.choice([-1, 1]) * random.randint(1, 50))
        else:
            # delete an element
            if m > 5:
                i = random.randrange(m)
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 3:
            continue
        s = _score(cand)
        d = s - cur_score
        if d >= 0 or random.random() < math.exp(d / max(T, 1e-9)):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                bestlist = cand[:]
    return bestlist, best_score


def _cut_and_paste(a, b, rng):
    """Recombine two sets: take a random contiguous chunk from each and merge, plus mutations."""
    a = list(a)
    b = list(b)
    if not a or not b:
        return a or b
    a_sorted = sorted(a)
    b_sorted = sorted(b)
    i = rng.randrange(len(a_sorted))
    j = rng.randrange(len(b_sorted))
    k = rng.randint(1, max(1, len(a_sorted) // 2))
    l = rng.randint(1, max(1, len(b_sorted) // 2))
    chunk_a = a_sorted[i:i + k]
    chunk_b = b_sorted[j:j + l]
    merged = chunk_a + chunk_b
    return merged


def solve():
    deadline = time.time() + 110
    rng = random.Random(12345)
    random.seed(12345)

    # --- Seed candidates ---
    candidates = []

    # Known good small set from the baseline
    candidates.append([7, 15, 18, 22, -3, -2])
    # Perfect difference set-ish small examples (Bertrand-style)
    # {0,1,3,7} differences: 1 -1, 3 -3, 7 -7, 2 -2, 6 -6, 4 -4 => {±1,±2,±3,±4,±6,±7}, sums {0,1,2,3,4,6,7,8,10,14}
    candidates.append([0, 1, 3, 7])
    candidates.append([0, 1, 3, 7, 12])
    candidates.append([0, 1, 4, 9, 15, 22, 26, 31])
    # Bertrand-style / perfect difference set from Singer for small orders
    candidates.append([0, 1, 3, 9])
    candidates.append([1, 2, 5, 10, 16, 23, 31])

    # Geometric progressions of various base ratios
    for r in [2, 3, 4, 5, -2, -3]:
        for n in [5, 6, 7, 8]:
            candidates.append(_builder_geometric(r, n))

    # Arithmetic progressions (many offsets/steps)
    for step in [1, 2, 3, 5, 7, 11]:
        for n in [5, 6, 7, 8, 10, 12]:
            candidates.append(_builder_progression(step, n, 0))
            candidates.append(_builder_progression(step, n, -step * n // 2))

    # Quadratic residues
    for q in [7, 11, 13, 17, 19, 23]:
        a = _builder_quadratic_residues(q)
        if len(a) >= 3:
            candidates.append(a)

    # Greedy Sidon-like rulers
    for n in [6, 8, 10, 12]:
        try:
            candidates.append(_builder_ruler(n))
        except Exception:
            pass

    # Random small sets (as diversity)
    for _ in range(30):
        n = rng.randint(4, 12)
        candidates.append([rng.randint(-50, 50) for _ in range(n)])

    # --- Initial evaluation ---
    scored = []
    for c in candidates:
        c = list(set(c))
        if len(c) >= 3:
            scored.append((_score(c), c))
    scored.sort(key=lambda t: -t[0])
    best_score = scored[0][0] if scored else 0.0
    best = scored[0][1] if scored else [7, 15, 18, 22, -3, -2]

    # --- Simulated annealing on multiple seeds, recombining ---
    sa_deadline = time.time() + 60
    pop = [c for _, c in scored[:8]]
    if not pop:
        pop = [best[:]]

    while time.time() < sa_deadline:
        # Cut-and-paste recombination
        if len(pop) >= 2 and rng.random() < 0.4:
            a = rng.choice(pop)
            b = rng.choice(pop)
            child = _cut_and_paste(a, b, rng)
            # mutate
            child = list(set(child))
            for _ in range(rng.randint(0, 3)):
                if not child:
                    break
                child[rng.randrange(len(child))] += rng.randint(-5, 5)
            child = list(set(child))
            if len(child) >= 3:
                pop.append(child)
                if len(pop) > 12:
                    pop.pop(0)
        seed = rng.choice(pop) if pop else best[:]
        # add small randomization
        seed = list(set(seed))
        for _ in range(rng.randint(0, 2)):
            if seed:
                seed[rng.randrange(len(seed))] += rng.choice([-1, 1]) * rng.randint(1, 4)
        seed = list(set(seed))
        if len(seed) < 3:
            seed = best[:]
        # split remaining time
        local_deadline = min(sa_deadline, time.time() + 4.0)
        improved, sc = _local_improve(seed, local_deadline, best_score)
        if sc > best_score:
            best_score = sc
            best = improved[:]
            pop.append(best[:])
            if len(pop) > 12:
                pop.pop(0)

    # --- Final refinement: larger SA with bigger moves and add/remove ---
    final_deadline = time.time() + (deadline - time.time())
    cur = best[:]
    cur_score = best_score
    T = 0.08
    it = 0
    while time.time() < final_deadline:
        it += 1
        if it % 500 == 0:
            T = max(0.0002, T * 0.997)
        cand = cur[:]
        r = random.random()
        m = len(cand)
        if r < 0.4:
            i = random.randrange(m)
            cand[i] += random.choice([-1, 1]) * random.randint(1, 1 + int(50 * T))
        elif r < 0.6:
            # translate the whole set slightly (doesn't change diffs, may change sums)
            shift = random.choice([-1, 1]) * random.randint(1, 3)
            cand = [x + shift for x in cand]
        elif r < 0.75:
            # scale differently
            cand = [2 * x for x in cand] + [x for x in cand[::2]]
        elif r < 0.9:
            # add element
            i = random.randrange(m)
            cand.append(cand[i] + random.choice([-1, 1]) * random.randint(1, 30))
        else:
            if m > 6:
                cand = random.sample(cand, m - 1)
        cand = list(set(cand))
        if len(cand) < 3 or len(cand) > 4000:
            continue
        s = _score(cand)
        d = s - cur_score
        if d >= 0 or random.random() < math.exp(d / max(T, 1e-9)):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]

    # Final cleanup
    best = sorted(set(int(x) for x in best if abs(x) <= 10**15))
    if len(best) < 2:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
