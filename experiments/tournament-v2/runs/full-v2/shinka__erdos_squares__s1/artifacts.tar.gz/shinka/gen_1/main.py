# EVOLVE-BLOCK-START
"""Greedy packing with rotations and local search for n squares in unit square."""
import math
import random

def _corners(cx, cy, angle, side):
    """Return the 4 corners of a square as (x, y) tuples."""
    h = side / 2.0
    c = math.cos(2 * math.pi * angle)
    s = math.sin(2 * math.pi * angle)
    pts = []
    for dx, dy in [(-h, -h), (h, -h), (h, h), (-h, h)]:
        x = cx + dx * c - dy * s
        y = cy + dx * s + dy * c
        pts.append((x, y))
    return pts

def _overlap(sq1, sq2):
    """Return True if two squares (cx, cy, angle, side) overlap in interior."""
    if sq1[3] <= 1e-12 or sq2[3] <= 1e-12:
        return False
    c1 = _corners(*sq1)
    c2 = _corners(*sq2)
    # Separating Axis Theorem for convex polygons
    for poly in (c1, c2):
        for i in range(4):
            p1 = poly[i]
            p2 = poly[(i + 1) % 4]
            # Normal to edge
            nx = p2[1] - p1[1]
            ny = p1[0] - p2[0]
            # Project both polygons onto normal
            def proj(pts):
                return [pt[0] * nx + pt[1] * ny for pt in pts]
            p1_proj = proj(c1)
            p2_proj = proj(c2)
            if max(p1_proj) < min(p2_proj) - 1e-12 or max(p2_proj) < min(p1_proj) - 1e-12:
                return False
    return True

def _fits(cx, cy, angle, side, placed):
    """Check if square fits inside unit square and doesn't overlap placed squares."""
    if side <= 1e-12:
        return True
    # Check inside unit square
    corners = _corners(cx, cy, angle, side)
    for x, y in corners:
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    # Check overlap
    new_sq = (cx, cy, angle, side)
    for sq in placed:
        if _overlap(new_sq, sq):
            return False
    return True

def _greedy_place(n, angles=(0.0, 0.25, 0.125, 0.375)):
    """Greedy place squares from largest to smallest using a candidate grid."""
    # We'll try to place squares one by one, starting from a large side and decreasing.
    # For each square, we search over a grid of positions and angles.
    placed = []
    # Initial guess: side decreases from 1.0
    # We'll use a simple strategy: for each of n squares, try to place the largest possible side.
    # To make it fast, we use a coarse grid and refine.
    # We'll place squares in order, each time trying to maximize side.
    # Start with a reasonable side: for n squares, average side ~ 1/sqrt(n)
    # But we want to maximize sum, so we try larger first.
    # We'll do a binary search on side for each square? That might be slow.
    # Instead, we use a fixed set of candidate sides from large to small.
    # For simplicity, we'll try a range of sides and pick the best that fits.
    # We'll use a grid of positions (coarse) and angles.
    # To save time, we limit the number of candidates.
    grid_res = min(20, max(5, int(2 * math.sqrt(n))))
    positions = [(i / (grid_res - 1), j / (grid_res - 1)) for i in range(grid_res) for j in range(grid_res)]
    # Also include center and some random positions
    positions.append((0.5, 0.5))
    # Angle candidates
    if angles is None:
        angles = [0.0, 0.25, 0.125, 0.375]
    # We'll place n squares. For each, try to maximize side.
    # To avoid O(n * grid * angles * sides) being too slow, we use a heuristic:
    # Start with a target side = 1.0 / math.sqrt(n) * 1.5, then decrease.
    # Actually, we can just try a set of sides for each square.
    # Let's do: for each square, try sides from a list (descending), pick first that fits.
    # But this may not be optimal. We'll do a simple greedy:
    # For the first square, try largest side that fits (up to 1.0).
    # For subsequent, try largest that fits given previous.
    # We'll limit the number of side candidates to 30.
    side_candidates = [1.0 - i * 0.02 for i in range(50)]  # 1.0 down to 0.02
    side_candidates += [0.0]
    for idx in range(n):
        best = None
        best_side = -1.0
        # Try to find a placement with as large side as possible
        # We'll iterate over side candidates in descending order
        for side in side_candidates:
            if side <= 1e-12:
                # place zero-size square
                placed.append((0.5, 0.5, 0.0, 0.0))
                best = (0.5, 0.5, 0.0, 0.0)
                best_side = 0.0
                break
            # For this side, try positions and angles
            found = False
            # Shuffle positions to get variety? No, we want deterministic.
            for cx, cy in positions:
                for ang in angles:
                    if _fits(cx, cy, ang, side, placed):
                        best = (cx, cy, ang, side)
                        best_side = side
                        found = True
                        break
                if found:
                    break
            if found:
                break
        if best is None:
            # fallback: zero size
            best = (0.5, 0.5, 0.0, 0.0)
        placed.append(best)
    return placed

def _local_search(squares, n, iterations=200):
    """Try to improve sum of sides by random perturbations."""
    best = [list(s) for s in squares]
    best_sum = sum(s[3] for s in best)
    for _ in range(iterations):
        # Pick a random square to perturb
        idx = random.randrange(n)
        old = best[idx][:]
        # Randomly adjust side, position, angle
        new_side = max(0.0, old[3] + random.uniform(-0.05, 0.05))
        new_cx = min(1.0, max(0.0, old[0] + random.uniform(-0.05, 0.05)))
        new_cy = min(1.0, max(0.0, old[1] + random.uniform(-0.05, 0.05)))
        new_ang = (old[2] + random.uniform(-0.1, 0.1)) % 1.0
        candidate = (new_cx, new_cy, new_ang, new_side)
        # Check if fits with others
        others = [tuple(best[i]) for i in range(n) if i != idx]
        if _fits(new_cx, new_cy, new_ang, new_side, others):
            # Accept if sum improves or with small probability
            new_sum = best_sum - old[3] + new_side
            if new_sum > best_sum or random.random() < 0.01:
                best[idx] = list(candidate)
                best_sum = new_sum
    return [tuple(s) for s in best]

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # For small n, use known optimal or simple patterns
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares of side 0.5? Actually three squares of side 0.5 can't fit (sum area 0.75, but arrangement?)
        # Best known for n=3 is 1.5? Wait, three squares of side 0.5: place two at bottom, one at top?
        # Actually three squares of side 0.5 can be placed: two at bottom left and right, one at top center?
        # But they would overlap? Let's check: two at bottom: (0.25,0.25) and (0.75,0.25) side 0.5.
        # Third at (0.5,0.75) side 0.5. Check overlap: bottom two touch at x=0.5, no overlap.
        # Third touches bottom two? Its bottom edge y=0.5, bottom squares top edge y=0.5, so touch only.
        # So sum = 1.5. Is that optimal? For n=3, best known is 1.5? The baseline for n=3 gives 1.0?
        # Actually baseline: k=1, side=1, but only 1 square, then zeros. So sum=1.0.
        # Our algorithm should find 1.5. Let's hardcode for small n to be safe.
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    # For general n, use greedy + local search
    # To save time for large n, limit iterations
    squares = _greedy_place(n)
    # Local search
    iterations = min(500, max(50, 2000 // n))
    squares = _local_search(squares, n, iterations=iterations)
    # Ensure all squares are within bounds and non-overlapping (should be)
    # Final check: if any overlap, revert to zero-size for problematic ones
    # (should not happen)
    return squares
# EVOLVE-BLOCK-END