import math
import random
import time

def _score(a):
    s = set(a)
    if len(s) < 2:
        return 0.0
    diffs = set()
    sums = set()
    # compute diffs and sums efficiently
    lst = list(s)
    n = len(lst)
    for i in range(n):
        xi = lst[i]
        for j in range(i, n):
            xj = lst[j]
            d = xi - xj
            diffs.add(d)
            if d != 0:
                diffs.add(-d)
            sums.add(xi + xj)
    Ld = len(diffs)
    Ls = len(sums)
    return math.log(Ld) / math.log(Ls) + (1 - 1 / n) / 100

def solve():
    random.seed(42)
    # Small promising seed set (tuned for good diff/sum ratio)
    seed_candidates = [
        [0, 1, 4, 10, 15],
        [0, 1, 4, 9, 14],
        [0, 1, 3, 8, 12, 18],
        [0, 1, 4, 10, 12, 17],
        [0, 2, 5, 11, 14],
        [0, 1, 3, 7, 12, 20],
        [0, 1, 4, 10, 16, 22],
        [0, 2, 6, 13, 21],
    ]
    # Evaluate seeds
    best_seed = max(seed_candidates, key=_score)
    best_overall = best_seed[:]
    best_overall_score = _score(best_overall)

    deadline = time.time() + 115  # leave small margin

    # Stage 1: create large set by translating and combining copies of the seed
    # Use random shifts to create a structured larger set
    shift_range = 500
    while time.time() < deadline - 60:  # leave 60s for stage 2
        # try different numbers of copies
        num_copies = random.randint(3, 8)
        # generate shifted copies
        big = []
        used_shifts = set()
        for _ in range(num_copies):
            shift = random.randint(1, shift_range)
            while shift in used_shifts:
                shift = random.randint(1, shift_range)
            used_shifts.add(shift)
            for val in best_seed:
                big.append(val + shift)
        s = _score(big)
        if s > best_overall_score:
            best_overall = big[:]
            best_overall_score = s

    # Stage 2: local optimization on the best found large set
    cur = best_overall[:]
    cur_score = best_overall_score
    best = best_overall[:]
    best_score = best_overall_score
    
    # Parameters for local search
    n = len(cur)
    max_magnitude = max(abs(x) for x in cur) + 1000
    
    while time.time() < deadline:
        cand = cur[:]
        # Mutation operators
        op = random.random()
        if op < 0.4:
            # modify a single element
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2])
        elif op < 0.6:
            # swap small changes in two elements
            if len(cand) >= 2:
                i, j = random.sample(range(len(cand)), 2)
                delta = random.choice([-2, -1, 1, 2])
                cand[i] += delta
                cand[j] -= delta
        elif op < 0.75:
            # add a new element near existing ones
            base = random.choice(cand)
            cand.append(base + random.randint(-5, 5))
        elif op < 0.9 and len(cand) > 5:
            # remove a random element
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # shift a subset (global translation move)
            if len(cand) > 1:
                # pick a random element and shift all elements > it
                pivot = random.choice(cand)
                shift = random.randint(1, 5) * random.choice([-1, 1])
                cand = [x + shift if x > pivot else x for x in cand]

        # Remove duplicates and bound values
        cand = list(set(cand))
        # ensure diversity by clipping extreme growth but still allow exploration
        if len(cand) > 4000:
            # keep largest values or randomly prune
            cand.sort()
            cand = cand[:4000]
        if len(cand) < 2:
            cand = cur[:]
        
        cand_score = _score(cand)
        
        if cand_score >= cur_score:
            cur = cand[:]
            cur_score = cand_score
            if cand_score > best_score:
                best = cand[:]
                best_score = cand_score
        else:
            # occasionally accept worse to escape local optima
            if random.random() < 0.05:
                cur = cand[:]
                cur_score = cand_score
    
    # Final polishing: try removing worst elements one by one
    current_set = set(best)
    improved = True
    while improved and time.time() < deadline:
        improved = False
        base_score = _score(list(current_set))
        for val in list(current_set):
            if len(current_set) <= 2:
                break
            trial = set(current_set)
            trial.remove(val)
            s_trial = _score(list(trial))
            if s_trial > base_score:
                current_set = trial
                base_score = s_trial
                improved = True
                best_score = s_trial
                break
        
    best = sorted(list(current_set))
    return best
