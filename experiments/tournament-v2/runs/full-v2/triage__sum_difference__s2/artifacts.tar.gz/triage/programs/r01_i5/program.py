import numpy as np
import time

def _score_from_bits(bits, offset, max_time=None):
    # bits: 1D numpy int array (0/1) representing membership in interval [offset, offset+len(bits)-1]
    n = len(bits)
    if bits.sum() < 2:
        return None, 0.0
    # convolution via FFT-like integer autocorrelation using FFT (numpy)
    # For exact counts, use FFT and round.
    f = np.fft.rfft(bits.astype(np.float64), n=2*n-1)
    conv = np.fft.irfft(f * np.conj(f), n=2*n-1)
    conv = np.rint(conv).astype(np.int64)
    # conv[k] = number of pairs (i,j) with i-j = k - (n-1)  (autocorrelation)
    # sum set: pairs i+j = m => use convolution of bits with itself
    f2 = np.fft.rfft(bits.astype(np.float64), n=2*n-1)
    conv2 = np.fft.irfft(f2 * f2, n=2*n-1)
    conv2 = np.rint(conv2).astype(np.int64)
    # diff set size: count nonzero entries in conv (for k from -(n-1)..n-1)
    diff_size = np.count_nonzero(conv)
    # sum set size: count nonzero entries in conv2 (for m from 0..2n-2)
    sum_size = np.count_nonzero(conv2)
    if sum_size < 2:
        return None, 0.0
    A_size = int(bits.sum())
    score = np.log(diff_size) / np.log(sum_size) + (1 - 1/A_size) / 100
    return A_size, score

def _bits_to_set(bits, offset):
    idx = np.nonzero(bits)[0]
    return [int(i + offset) for i in idx]

def solve():
    # Search over intervals of integers. We'll use a population-based local search.
    # To make it fast, use numpy and vectors of bits.
    best_score = -1.0
    best_bits = None
    best_offset = 0

    # We'll consider intervals of length L (number of positions). 
    # We need to choose offset so numbers fit in |a| <= 1e15.
    # For speed, use L up to maybe 2000, with dense bit arrays.
    # We'll do a simple hill climbing with random restarts and mutations.

    rng = np.random.default_rng(12345)

    # Initial candidates: random dense sets within a small interval.
    # Known good constructions: sets like {0,1,3,7,12,20,...} but we search.
    # We'll start with L=64 and random 30% density.
    deadline = time.time() + 110  # leave 10s margin

    # Try multiple lengths. We'll focus on lengths around 100-500.
    # For each length, run a local search.

    lengths = [30, 50, 80, 120, 200, 300, 500, 800]
    # We'll do random restarts for each length.

    for trial in range(100):
        if time.time() > deadline:
            break
        L = lengths[trial % len(lengths)]
        # random initial density: pick a random fraction between 0.1 and 0.5
        p = rng.uniform(0.1, 0.5)
        bits = (rng.random(L) < p).astype(np.int64)
        if bits.sum() < 2:
            bits[rng.integers(0, L)] = 1
            bits[rng.integers(0, L)] = 1
        # offset: choose so that numbers are centered, but any works.
        offset = -L // 2
        # evaluate
        _, sc = _score_from_bits(bits, offset)
        cur_bits = bits.copy()
        cur_score = sc
        # local search: flip bits
        for step in range(2000):
            if time.time() > deadline:
                break
            # choose a random index to flip
            i = rng.integers(0, L)
            cand_bits = cur_bits.copy()
            cand_bits[i] ^= 1
            if cand_bits.sum() < 2:
                continue
            _, s = _score_from_bits(cand_bits, offset)
            if s > cur_score:
                cur_bits = cand_bits
                cur_score = s
                if s > best_score:
                    best_score = s
                    best_bits = cur_bits.copy()
                    best_offset = offset
            else:
                # occasional random restart or accept sideways?
                if rng.random() < 0.01:
                    # small perturbation: flip a few bits
                    idx = rng.choice(L, size=3, replace=False)
                    cur_bits[idx] ^= 1
                    if cur_bits.sum() < 2:
                        cur_bits[idx[0]] = 1
                    _, cur_score = _score_from_bits(cur_bits, offset)

    # Also try to include known good sets from literature? But we search.

    # If nothing found, fallback to a decent set.
    if best_bits is None or best_score < 0:
        # fallback: use a known good set from the baseline
        return [7, 15, 18, 22, -3, -2]

    # Convert to list of ints
    A = _bits_to_set(best_bits, best_offset)
    # Ensure all within 1e15
    A = [a for a in A if abs(a) <= 10**15]
    # Ensure distinct and at least 2
    if len(A) < 2:
        A = [0, 1]
    # Sort maybe not needed, but return
    return A

if __name__ == "__main__":
    res = solve()
    print(len(res), res[:10], "..." if len(res) > 10 else "")
