"""Greedy hill climbing with efficient set size computation for maximizing log|A-A|/log|A+A|."""
import math
from collections import defaultdict
import time
import random
import sys

def compute_set_sizes(arr, dtype='int64'):
    """Compute |A-A| and |A+A| using numpy for efficiency."""
    a = set(arr)
    if len(a) < 2:
        return 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums)

def compute_set_sizes_fast(arr):
    """Optimized set sizing using Python sets with early pruning."""
    n = len(arr)
    if n < 2:
        return 0, 0
    diffs = {}
    sums = {}
    memo_d = {}
    memo_s = {}
    count_diff = 0
    count_sum = 0
    a = set(arr)
    for x in a:
        for y in a:
            d = x - y
            if d not in memo_d:
                memo_d[d] = True
                count_diff += 1
            s = x + y
            if s not in memo_s:
                memo_s[s] = True
                count_sum += 1
    return count_diff, count_sum

def objective_score(a):
    """Compute log|A-A| / log|A+A| + size bonus."""
    if len(a) < 2:
        return 0.0
    diffs, sums = compute_set_sizes_fast(sorted(list(a)))
    if diffs == 0 or sums == 0:
        return 0.0
    ratio = math.log(diffs) / math.log(sums)
    return ratio + (1 - 1 / len(a)) / 100

def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 120
    time_spent = 0

    # Seed with a structurally promising set
    seed = [0, 5, 10, -5, -10, 15, -15, 20, -20]
    seed = sorted(set(seed))

    candidates = set(seed)
    best = list(candidates)
    best_score = objective_score(best)
    best_len = len(best)

    added_counts = [0] * 4005
    added_cancel = False

    while time_spent < 120:
        best_gain_existing = float('-inf')
        best_candidate = None

        # Try adding a few candidates to explore options
        to_try = []

        # Try random new candidates
        base = max(best)
        for offset in [base + j * 100 for j in range(1, 11)]:
            to_try.append(offset)
            to_try.append(offset - base)
            to_try.append(-offset)
            to_try.append(base - offset)

        random.shuffle(to_try)

        for cand in to_try:
            if cand in candidates:
                continue
            if len(candidates) >= 4000:
                break
            # Quick estimate before full compute
            old_score = _score_snapshot(candidates)
            new_cands = set(candidates) | set([cand])
            if len(new_cands) > best_len + 10:
                continue
            new_score = _score_snapshot(new_cands)
            if new_score > best_score + 0.01:
                best_candidate = cand
                break

        if best_candidate is not None:
            best.update([best_candidate])
            candidates.add(best_candidate)
            best_len = len(best)
            best_score = _score_snapshot(set(best))
            time_spent += 120 // 120
            continue

        # Local optimization: remove/swap
        removed_gain = 0
        removed_candidate = None
        for rem in list(*candidates):
            if len(candidates) > best_len:
                temp = set(best) | {rem}
                old_score = _score_snapshot(best)
                old_best = best.copy()
                new_best = [x for x in list(best) if x != rem]
                temp_set = set(new_best)
                if len(temp_set) < 2:
                    continue
                candidate = _score_snapshot(temp_set)
                if candidate - best_score > removed_gain:
                    removed_gain = candidate
                    removed_candidate = rem
            best_score, best_gain_existing = removed_gain, best_score
            break

            break

        # Swap: remove one, add another
        best_remove = None
        best_remove_gain = float('-inf')
        for x in best:
            for k in to_try:
                if k in best or len(best) < 2:
                    continue
                x_set = set(best)
                x_set.remove(x)
                x_set.add(k)
                if len(x_set) < 2:
                    continue
                score = _score_snapshot(x_set)
                if score > best_gain_existing:
                    best_gain_existing = score
                    best_remove = x
                    best_candidate = k
                    break
        if best_remove is not None:
            best.remove(best_remove)
            best.add(best_candidate)
            best_len = len(best)
            best_score = _score_snapshot(set(best))

    return sorted(best)[:4000]

def _score_snapshot(a):
    """Very fast score snapshot for candidate evaluation."""
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if not diffs or not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

# Final solve function as required
def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 120
    time_spent = 0

    candidates = set()
    candidates.add(0)
    candidates.add(1)
    candidates.add(-1)

    best = list(candidates)
    best_score = objective_score(best)
    best_len = len(best)

    added = 0
    while time_spent < 120:
        time_start = time.time()
        # Greedy hill climb phase
        best_diff = float('-inf')
        best_chg = None

        # Try adding new candidates
        best_base = 100
        for b in range(1, 60):
            for sign in [1, -1]:
                for scale in [b, b*2, b*5, b*10]:
                    cand = sign * scale
                    if cand in candidates:
                        continue
                    new_set = candidates | {cand}
                    if len(list(new_set)) > 4000:
                        break
                    score = objective_score(list(new_set))
                    if len(best) < 4000:
                        if score > best_score:
                            best = list(new_set)
                            best_score = score
                            best_len = len(best)
                    added += 1
        candidates.update(best[:])

        # Small cleanup
        if len(best) > 30:
            avg_step = 500
            best = sorted(best)[:min(30, best_len)]
            best_score = objective_score(best)

        time_spent += time.time() - time_start
        if time_spent >= 120:
            break

    return sorted(best)[:4000]
