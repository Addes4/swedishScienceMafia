import math
import random
import time
from itertools import combinations

def _subset_sums(basis):
    """Return sorted list of all subset sums of basis (including empty sum 0)."""
    sums = [0]
    for b in basis:
        # new sums = old sums + b
        new_sums = [s + b for s in sums]
        # merge to keep sorted (optional, but helps later pruning)
        sums.extend(new_sums)
        # To keep sorted we can merge, but for speed we just sort once later.
    sums.sort()
    return sums

def _score_from_sets(a_set):
    """Compute score from a Python set of integers."""
    if len(a_set) < 2:
        return 0.0
    diffs = set()
    sums_set = set()
    # compute diffs and sums efficiently
    lst = list(a_set)
    n = len(lst)
    for i in range(n):
        xi = lst[i]
        for j in range(i, n):
            xj = lst[j]
            sums_set.add(xi + xj)
        for j in range(n):
            diffs.add(xi - lst[j])
    # Note: sum set from all pairs, we need both orders (xi+xj) but only once, above captures all; difference set all ordered pairs.
    return math.log(len(diffs)) / math.log(len(sums_set)) + (1 - 1 / len(a_set)) / 100

def solve():
    deadline = time.time() + 115  # leave margin
    random.seed(42)

    # initial basis: powers of 3 of length 12
    basis = [3**i for i in range(12)]  # up to 177147
    best_basis = basis[:]
    best_A = None
    best_score = -1.0

    while time.time() < deadline:
        # perturb one element
        idx = random.randrange(len(basis))
        old_val = basis[idx]
        # ensure super-increasing property holds after change
        # We'll try small changes
        delta = random.choice([-2, -1, 1, 2])
        new_val = old_val + delta
        if new_val <= 0:
            continue
        # Check super-increasing: for i>0, b_i > 2 * sum_{j < i} b_j
        ok = True
        cum = 0
        for i, b in enumerate(basis):
            if i == idx:
                b_candidate = new_val
            else:
                b_candidate = b
            if i > 0 and b_candidate <= 2 * cum:
                ok = False
                break
            cum += b_candidate
        if not ok:
            continue
        # apply change
        basis[idx] = new_val

        # generate subset sums
        all_sums = _subset_sums(basis)  # length 4096
        # prune to at most 4000 elements
        if len(all_sums) > 4000:
            # keep smallest 4000
            A_list = all_sums[:4000]
        else:
            A_list = all_sums

        # compute score
        sc = _score_from_sets(set(A_list))
        if sc > best_score:
            best_score = sc
            best_basis = basis[:]
            best_A = A_list[:]

        # revert with probability if not improved? Actually we're doing hill climbing with small steps,
        # but we can also sometimes keep bad moves to escape local optima.
        if sc < best_score - 0.0001:
            # revert
            basis[idx] = old_val
        # else keep basis changed, continue climbing

    if best_A is None:
        # fallback: simple set
        return sorted({0,1,3,9,27,81,243,729,2187,6561,19683,59049})
    return sorted(set(best_A))
