# EVOLVE-BLOCK-START
"""Simulated annealing search over sets of integers to maximise log|A-A|/log|A+A|.

The search starts from a small high-quality seed (a known good set in the small range)
and uses a fast incremental update of the difference and sum multiset sizes to allow
efficient evaluation of perturbations. A schedule that starts hot and cools down
permits exploration of larger sets and temporary score degradation.
"""
import math
import random
import time
from collections import Counter


def _initial_set():
    # A known good small set from the original baseline, scaled slightly to keep
    # numbers in a moderate range while leaving room for expansion.
    return [7, 15, 18, 22, -3, -2]


def _score_from_counts(n, ndiff, nsum):
    """Compute the target metric given current sizes."""
    if nsum <= 0 or ndiff <= 0:
        return 0.0
    return math.log(ndiff) / math.log(nsum) + (1 - 1 / n) / 100


class SetEvaluator:
    """Maintains a set A and the exact sizes of A-A and A+A incrementally."""

    def __init__(self, initial):
        self.A = list(initial)
        self.n = len(self.A)
        self.diff_counter = Counter()
        self.sum_counter = Counter()
        for i in range(self.n):
            x = self.A[i]
            for j in range(i, self.n):
                y = self.A[j]
                self.diff_counter[x - y] += 1
                self.diff_counter[y - x] += 1  # accounts for both orders
                self.sum_counter[x + y] += 1 if i == j else 2
        # Correct for double counting of x-x when i==j in diff above
        for i in range(self.n):
            x = self.A[i]
            self.diff_counter[0] -= 1  # we added x-x twice, keep only one
        self.ndiff = len(self.diff_counter)
        self.nsum = len(self.sum_counter)

    def score(self):
        return _score_from_counts(self.n, self.ndiff, self.nsum)

    def change_at(self, idx, new_val):
        """Update counters when self.A[idx] is replaced by new_val (must not be present already)."""
        old_val = self.A[idx]
        # remove old contributions
        for i in range(self.n):
            if i == idx:
                continue
            y = self.A[i]

            # diff: old_val - y
            key = old_val - y
            self.diff_counter[key] -= 1
            if self.diff_counter[key] == 0:
                del self.diff_counter[key]
                self.ndiff -= 1

            # diff: y - old_val
            key = y - old_val
            self.diff_counter[key] -= 1
            if self.diff_counter[key] == 0:
                del self.diff_counter[key]
                self.ndiff -= 1

            # sum: old_val + y
            key = old_val + y
            self.sum_counter[key] -= 1
            if self.sum_counter[key] == 0:
                del self.sum_counter[key]
                self.nsum -= 1

        # add new contributions
        for i in range(self.n):
            if i == idx:
                continue
            y = self.A[i]

            # diff: new_val - y
            key = new_val - y
            if key not in self.diff_counter:
                self.ndiff += 1
                self.diff_counter[key] = 0
            self.diff_counter[key] += 1

            # diff: y - new_val
            key = y - new_val
            if key not in self.diff_counter:
                self.ndiff += 1
                self.diff_counter[key] = 0
            self.diff_counter[key] += 1

            # sum: new_val + y
            key = new_val + y
            if key not in self.sum_counter:
                self.nsum += 1
                self.sum_counter[key] = 0
            self.sum_counter[key] += 1

        self.A[idx] = new_val

    def add(self, new_val):
        """Add a new element to the set."""
        self.A.append(new_val)
        idx = self.n  # index of the new element after append
        self.n += 1
        for i in range(self.n - 1):
            y = self.A[i]

            key = new_val - y
            if key not in self.diff_counter:
                self.ndiff += 1
                self.diff_counter[key] = 0
            self.diff_counter[key] += 1

            key = y - new_val
            if key not in self.diff_counter:
                self.ndiff += 1
                self.diff_counter[key] = 0
            self.diff_counter[key] += 1

            key = new_val + y
            if key not in self.sum_counter:
                self.nsum += 1
                self.sum_counter[key] = 0
            self.sum_counter[key] += 1

        # self difference (0)
        self.diff_counter[0] += 1
        if self.diff_counter[0] == 1:
            self.ndiff += 1

    def remove(self, idx):
        """Remove element at idx."""
        old_val = self.A[idx]
        # Remove all pairs involving old_val
        for i in range(self.n):
            if i == idx:
                continue
            y = self.A[i]

            key = old_val - y
            self.diff_counter[key] -= 1
            if self.diff_counter[key] == 0:
                del self.diff_counter[key]
                self.ndiff -= 1

            key = y - old_val
            self.diff_counter[key] -= 1
            if self.diff_counter[key] == 0:
                del self.diff_counter[key]
                self.ndiff -= 1

            key = old_val + y
            self.sum_counter[key] -= 1
            if self.sum_counter[key] == 0:
                del self.sum_counter[key]
                self.nsum -= 1
        # remove self difference (0)
        self.diff_counter[0] -= 1
        if self.diff_counter[0] == 0:
            del self.diff_counter[0]
            self.ndiff -= 1
        self.A.pop(idx)
        self.n -= 1


def solve():
    random.seed(42)
    # Start with a known good small seed and build the evaluator.
    init = _initial_set()
    ev = SetEvaluator(init)
    best_set = ev.A.copy()
    best_score = ev.score()

    # Simulated annealing parameters
    T_start = 0.2       # initial temperature (relative to score range)
    T_end = 1e-6
    alpha = 0.9995      # cooling rate per iteration
    step_limit = 200000  # limited to avoid exceeding time budget
    deadline = time.time() + 115  # leave a little margin
    max_size = 4000

    current_score = best_score

    iteration = 0
    T = T_start
    while T > T_end and iteration < step_limit and time.time() < deadline:
        # Simple geometric cooling
        if iteration % 100 == 0:
            T = T_start * (alpha ** iteration)

        # Decide mutation type
        r = random.random()
        if r < 0.70 and ev.n > 2:
            # Change one element to a nearby value
            idx = random.randrange(ev.n)
            old_val = ev.A[idx]
            # propose a new value not already in A
            for _attempt in range(5):
                delta = random.randint(-10, 10)
                if delta == 0:
                    continue
                candidate = old_val + delta
                if candidate not in ev.A:
                    break
            else:
                iteration += 1
                continue
            ev.change_at(idx, candidate)
            new_score = ev.score()
            delta_score = new_score - current_score

            if new_score > best_score:
                best_score = new_score
                best_set = ev.A.copy()
                current_score = new_score
            elif random.random() < math.exp(delta_score / T):
                current_score = new_score
            else:
                # revert
                ev.change_at(idx, old_val)
        elif r < 0.95 and ev.n < max_size:
            # Add a new element derived from existing ones, or completely random.
            if ev.n > 1 and random.random() < 0.8:
                # pick two existing elements and add a small offset to their sum/diff
                i, j = random.sample(range(ev.n), 2)
                base = ev.A[i] + ev.A[j] + random.randint(-5, 5)
            else:
                base = random.randint(-100, 100)
            # mutate until we find a value not in set
            for _attempt in range(20):
                cand = base + random.randint(-10, 10)
                if cand not in ev.A:
                    break
            else:
                iteration += 1
                continue
            ev.add(cand)
            new_score = ev.score()
            delta_score = new_score - current_score
            if new_score > best_score:
                best_score = new_score
                best_set = ev.A.copy()
                current_score = new_score
            elif random.random() < math.exp(delta_score / T):
                current_score = new_score
            else:
                ev.remove(ev.n - 1)
        else:
            # Remove a random element if not too small
            if ev.n > 5:
                idx = random.randrange(ev.n)
                removed_val = ev.A[idx]
                ev.remove(idx)
                new_score = ev.score()
                delta_score = new_score - current_score
                if new_score > best_score:
                    best_score = new_score
                    best_set = ev.A.copy()
                    current_score = new_score
                elif random.random() < math.exp(delta_score / T):
                    current_score = new_score
                else:
                    # undo remove: add back at same position? Re-adding is easier;
                    # we can just add it back and then rearrange? For simplicity we
                    # re-insert it (order doesn't matter). But the evaluator's remove
                    # is destructive; we just add it back.
                    ev.add(removed_val)
            # else skip

        iteration += 1

    # ensure final set is distinct and sorted
    final = sorted(set(best_set))
    # Safety: if something went wrong, fallback to seed
    if len(final) < 2:
        final = sorted(set(_initial_set()))
    return final
# EVOLVE-BLOCK-END
