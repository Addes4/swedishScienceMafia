# EVOLVE-BLOCK-START
"""Shelf packing plus a time-bounded simulated-annealing refinement.

The deterministic shelf/guillotine packing gives a good feasible layout.
We then perturb centres, side lengths and angles to push squares into the
corners and grow them, which recovers the gains that pure grid layouts miss
(e.g. mixed-orientation packs for small n).
"""

import math
import random
import time


def _shelf(n):
    """Deterministic starting layout (one or two horizontal strips)."""
    if n <= 0:
        return []

    out = None
    best_sum = -1.0
    for a1 in range(1, n + 1):
        for b1 in range(1, n + 1):
            m1 = a1 * b1
            if m1 > n:
                break
            rem = n - m1
            if rem == 0:
                s = min(1.0 / a1, 1.0 / b1)
                tot = m1 * s
                if tot > best_sum:
                    best_sum = tot
                    out = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                           for i in range(a1) for j in range(b1)]
                continue
            for a2 in range(1, rem + 1):
                if rem % a2 != 0:
                    continue
                b2 = rem // a2
                s1cap = 1.0 / a1
                s2cap = 1.0 / a2
                h1 = b1 * s1cap
                if h1 <= 1.0:
                    s1 = s1cap
                    s2 = min((1.0 - h1) / b2, s2cap)
                else:
                    h1 = 1.0
                    s1 = min(h1 / b1, s1cap)
                    s2 = 0.0
                tot = m1 * s1 + rem * s2
                if tot > best_sum:
                    best_sum = tot
                    cand = []
                    for i in range(a1):
                        for j in range(b1):
                            cand.append(((i + 0.5) * s1 + (1.0 - a1 * s1) * 0.5,
                                         (j + 0.5) * s1 + (h1 - b1 * s1) * 0.5,
                                         0.0, s1))
                    for i in range(a2):
                        for j in range(b2):
                            cand.append(((i + 0.5) * s2 + (1.0 - a2 * s2) * 0.5,
                                         h1 + (j + 0.5) * s2
                                         + ((1.0 - h1) - b2 * s2) * 0.5,
                                         0.0, s2))
                    out = cand
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _aabb(x, y, ang, side):
    c = abs(math.cos(2 * math.pi * ang))
    s = abs(math.sin(2 * math.pi * ang))
    hx = 0.5 * side * (c + s)
    hy = 0.5 * side * (c + s)
    return x - hx, x + hx, y - hy, y + hy


def _score(rects):
    total = 0.0
    for (_, _, _, side) in rects:
        total += side
    return total


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side)."""
    if n <= 0:
        return []

    start = _shelf(n)
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    deadline = time.time() + 55.0
    rng = random.Random(12345 + n)

    # normalise into a compact internal representation
    best = [(x, y, a, s) for (x, y, a, s) in start]
    best_score = _score(best)

    cur = list(best)
    cur_score = best_score

    # tabu-ish overlimit avoidance is unnecessary: we score only feasible packs
    t0 = time.time()
    it = 0
    while time.time() < deadline:
        it += 1
        T = max(0.0005, 0.05 * (1.0 - (time.time() - t0) / (deadline - t0)) ** 2)
        idx = rng.randrange(n)
        x, y, a, s = cur[idx]
        nx, ny, na, ns = x, y, a, s

        r = rng.random()
        if r < 0.35:
            # jitter position
            d = 0.02 * T / 0.05 * rng.uniform(-1, 1) + 0.003 * rng.uniform(-1, 1)
            nx = x + d
            ny = y + (0.02 * T / 0.05 * rng.uniform(-1, 1) + 0.003 * rng.uniform(-1, 1))
        elif r < 0.70:
            # grow / shrink
            g = 1.0 + (0.05 + 0.2 * T) * rng.uniform(-1, 1)
            ns = s * g
        elif r < 0.88:
            # rotate
            na = a + 0.25 * rng.randint(-1, 1)
        else:
            # move toward a corner
            nx = 0.25 if rng.random() < 0.5 else 0.75
            ny = 0.25 if rng.random() < 0.5 else 0.75
            ns = s * (1.0 + 0.1 * rng.random())

        ns = max(0.0, ns)
        if ns > 1.0:
            ns = 1.0
        # clamp into unit square using axis-aligned bounding box
        c = abs(math.cos(2 * math.pi * na))
        sn = abs(math.sin(2 * math.pi * na))
        half = 0.5 * ns * (c + sn)
        if half > 0.5:
            ns = 1.0 / (c + sn) if (c + sn) > 0 else 0.0
            c = abs(math.cos(2 * math.pi * na))
            sn = abs(math.sin(2 * math.pi * na))
            half = 0.5 * ns * (c + sn)
        nx = min(max(nx, half), 1.0 - half)
        ny = min(max(ny, half), 1.0 - half)

        old = cur[idx]
        cur[idx] = (nx, ny, na, ns)

        # compute overlap penalty (only among squares with positive side)
        pen = 0.0
        sidesum = 0.0
        boxes = []
        for (xx, yy, aa, ss) in cur:
            c = abs(math.cos(2 * math.pi * aa))
            sn = abs(math.sin(2 * math.pi * aa))
            h = 0.5 * ss * (c + sn)
            boxes.append((xx - h, xx + h, yy - h, yy + h))
            sidesum += ss
        for i in range(n):
            ax0, ax1, ay0, ay1 = boxes[i]
            for j in range(i + 1, n):
                bx0, bx1, by0, by1 = boxes[j]
                ox = min(ax1, bx1) - max(ax0, bx0)
                oy = min(ay1, by1) - max(ay0, by0)
                if ox > 0 and oy > 0:
                    pen += ox * oy

        new_energy = -sidesum + 30.0 * pen
        old_energy = -cur_score  # approximate (penalty previously ~0)
        if new_energy < old_energy or rng.random() < math.exp((old_energy - new_energy) / max(1e-9, T)):
            cur_score = sidesum
            if pen < 1e-12 and sidesum > best_score:
                best_score = sidesum
                best = list(cur)
        else:
            cur[idx] = old

        # periodic cleanup: snap away tiny overlaps by shrinking a random square
        if it % 4000 == 0:
            for k in range(n):
                xx, yy, aa, ss = cur[k]
                c = abs(math.cos(2 * math.pi * aa))
                sn = abs(math.sin(2 * math.pi * aa))
                h = 0.5 * ss * (c + sn)
                bx0, bx1, by0, by1 = xx - h, xx + h, yy - h, yy + h
                for j in range(n):
                    if j == k:
                        continue
                    ox0, ox1, oy0, oy1 = boxes[j]
                    ox = min(bx1, ox1) - max(bx0, ox0)
                    oy = min(by1, oy1) - max(by0, oy0)
                    if ox > 0 and oy > 0:
                        cur[k] = (xx, yy, aa, max(0.0, ss - 0.6 * min(ox, oy)))
                        break

    out = [(x, y, a % 1.0, s) for (x, y, a, s) in best]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
