# EVOLVE-BLOCK-START
"""Greedy growth + local search packing of squares into the unit square."""
import math
import random


def _overlap(a, b):
    # approximate check via separating axis on rotated squares using bounding circles + corners
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    # quick reject by circumradius
    ra = asz * 0.7071067811865476
    rb = bsz * 0.7071067811865476
    dx = ax - bx
    dy = ay - by
    if dx * dx + dy * dy > (ra + rb) ** 2:
        return False
    return _sat_overlap(a, b)


def _corners(x, y, ang, s):
    c = math.cos(ang * 2 * math.pi)
    sn = math.sin(ang * 2 * math.pi)
    h = s * 0.5
    return [
        (x + h * (c - sn), y + h * (sn + c)),
        (x + h * (-c - sn), y + h * (-sn + c)),
        (x + h * (-c + sn), y + h * (-sn - c)),
        (x + h * (c + sn), y + h * (sn - c)),
    ]


def _sat_overlap(a, b):
    pa = _corners(a[0], a[1], a[2], a[3])
    pb = _corners(b[0], b[1], b[2], b[3])
    for poly, other in ((pa, pb), (pb, pa)):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            ln = math.hypot(nx, ny)
            if ln == 0:
                continue
            nx /= ln
            ny /= ln
            amin = amax = None
            for px, py in pa:
                d = px * nx + py * ny
                if amin is None or d < amin:
                    amin = d
                if amax is None or d > amax:
                    amax = d
            bmin = bmax = None
            for px, py in pb:
                d = px * nx + py * ny
                if bmin is None or d < bmin:
                    bmin = d
                if bmax is None or d > bmax:
                    bmax = d
            if amax <= bmin or bmax <= amin:
                return False
    return True


def _valid(squares):
    n = len(squares)
    for i in range(n):
        x, y, ang, s = squares[i]
        if s <= 0:
            continue
        # inside unit square check via corners
        for px, py in _corners(x, y, ang, s):
            if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                return False
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _clamp_inside(sq):
    x, y, ang, s = sq
    if s <= 0:
        return (0.5, 0.5, 0.0, 0.0)
    # shrink/translate to fit
    cs = _corners(x, y, ang, s)
    minx = min(p[0] for p in cs)
    maxx = max(p[0] for p in cs)
    miny = min(p[1] for p in cs)
    maxy = max(p[1] for p in cs)
    if minx < 0:
        x -= minx
    if maxx > 1:
        x -= (maxx - 1)
    if miny < 0:
        y -= miny
    if maxy > 1:
        y -= (maxy - 1)
    return (x, y, ang, s)


def _score(sq):
    return sum(s[3] for s in sq)


def _repair(squares):
    # ensure valid; if invalid shrink offending squares
    for i in range(len(squares)):
        squares[i] = _clamp_inside(squares[i])
    for i in range(len(squares)):
        for j in range(i + 1, len(squares)):
            if _overlap(squares[i], squares[j]):
                x, y, ang, s = squares[i]
                # binary shrink both
                lo, hi = 0.0, s
                for _ in range(20):
                    mid = (lo + hi) / 2
                    squares[i] = (x, y, ang, mid)
                    if _overlap(squares[i], squares[j]):
                        hi = mid
                    else:
                        lo = mid
                squares[i] = (x, y, ang, lo)
    return squares


def _init_grid(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    # leftovers: try to place near remaining space (just append tiny)
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def solve(n):
    rng = random.Random(12345 + n * 7919)
    best = None
    best_s = -1.0
    for restart in range(6):
        if restart == 0:
            sq = _init_grid(n)
        else:
            k = math.isqrt(n)
            base = 1.0 / max(k, 1)
            sq = []
            for _ in range(n):
                s = base * (0.6 + 0.4 * rng.random())
                ang = rng.choice([0.0, 0.25, rng.random() * 0.5])
                x = 0.5
                y = 0.5
                sq.append((x, y, ang, s))
            sq = _repair(sq)

        sq = _repair(sq)
        cur = _score(sq)

        # simulated-annealing-ish local search
        T = 0.05
        steps = 4000
        for step in range(steps):
            i = rng.randrange(n)
            x, y, ang, s = sq[i]
            mode = rng.random()
            if mode < 0.4:
                nx = x + rng.gauss(0, 0.05)
                ny = y + rng.gauss(0, 0.05)
                ns = s
                na = ang
            elif mode < 0.75:
                ns = s + rng.gauss(0, 0.03)
                if ns < 0:
                    ns = 0.0
                nx, ny, na = x, y, ang
            else:
                na = ang + rng.gauss(0, 0.1)
                nx, ny, ns = x, y, s
            old = sq[i]
            sq[i] = _clamp_inside((nx, ny, na, ns))
            # fix overlaps
            changed = True
            sq = _repair(sq)
            new = _score(sq)
            d = new - cur
            if d >= 0 or rng.random() < math.exp(d / max(T, 1e-6)):
                cur = new
            else:
                sq = _repair(list(sq))
                cur = _score(sq)
            T *= 0.999
        if cur > best_s:
            best_s = cur
            best = [s for s in sq]
    return best


# EVOLVE-BLOCK-END
