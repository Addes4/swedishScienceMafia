import math
import random
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    """Return the four corners of a square."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        xr = ca * x - sa * y + cx
        yr = sa * x + ca * y + cy
        out.append((xr, yr))
    return out


def _hull(points):
    pts = sorted(set(points))
    if len(pts) <= 1:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower = []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def _dot(u, v):
    return u[0] * v[0] + u[1] * v[1]


def _sub(u, v):
    return (u[0] - v[0], u[1] - v[1])


def _mul(k, v):
    return (k * v[0], k * v[1])


def _norm(v):
    return math.hypot(v[0], v[1])


def _normalize(v):
    n = _norm(v)
    if n < 1e-15:
        return (0.0, 0.0)
    return (v[0] / n, v[1] / n)


def _edges(poly):
    return [(poly[i], poly[(i + 1) % len(poly)]) for i in range(len(poly))]


def _project_poly(poly, axis):
    vals = [_dot(p, axis) for p in poly]
    return min(vals), max(vals)


def _overlap(poly_a, poly_b):
    """Return positive overlap amount if interiors overlap, else <= 0."""
    axes = []
    for e in _edges(poly_a):
        axes.append(_normalize((-e[1][1] + e[0][1], e[1][0] - e[0][0])))
    for e in _edges(poly_b):
        axes.append(_normalize((-e[1][1] + e[0][1], e[1][0] - e[0][0])))

    min_overlap = float("inf")
    for ax in axes:
        if _norm(ax) < 1e-12:
            continue
        a0, a1 = _project_poly(poly_a, ax)
        b0, b1 = _project_poly(poly_b, ax)
        ov = min(a1, b1) - max(a0, b0)
        if ov <= 1e-12:
            return -1.0
        min_overlap = min(min_overlap, ov)
    return min_overlap


def _inside_unit_square(poly, eps=1e-9):
    for x, y in poly:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _clip_center(cx, cy, ang, s):
    """Move center to make the square fit inside the unit square if possible."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    dx = abs(ca * h) + abs(sa * h)
    dy = abs(sa * h) + abs(ca * h)
    cx = min(max(cx, dx), 1.0 - dx)
    cy = min(max(cy, dy), 1.0 - dy)
    return cx, cy


def _greedy(n, rng):
    squares = []
    best_area = 0.0
    attempts = 0
    target = n
    while len(squares) < target:
        attempts += 1
        if attempts > 4000:
            squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        s = rng.uniform(0.02, 1.0)
        if len(squares) == 0:
            s = 1.0
        ang = rng.choice([0.0, 0.25, 0.5, 0.75]) if rng.random() < 0.7 else rng.random()
        cx = rng.random()
        cy = rng.random()
        cx, cy = _clip_center(cx, cy, ang, s)
        poly = _hull(_corners(cx, cy, ang, s))
        if not _inside_unit_square(poly):
            continue
        ok = True
        for (ocx, ocy, oang, os) in squares:
            if os <= 1e-14:
                continue
            opoly = _hull(_corners(ocx, ocy, oang, os))
            if _overlap(poly, opoly) > 0:
                ok = False
                break
        if ok:
            squares.append((cx, cy, ang, s))
    return squares


def _pack_score(squares):
    return sum(sq[3] for sq in squares)


def _local_improve(squares, rng, steps=200):
    squares = [list(sq) for sq in squares]
    n = len(squares)
    best = _pack_score(squares)
    for _ in range(steps):
        i = rng.randrange(n)
        old = squares[i][:]
        # perturb
        squares[i][0] += rng.uniform(-0.03, 0.03)
        squares[i][1] += rng.uniform(-0.03, 0.03)
        squares[i][2] = (squares[i][2] + rng.uniform(-0.05, 0.05)) % 1.0
        squares[i][3] = max(0.0, squares[i][3] + rng.uniform(-0.03, 0.03))
        cx, cy, ang, s = squares[i]
        cx, cy = _clip_center(cx, cy, ang, s)
        squares[i] = [cx, cy, ang, s]

        # check all
        ok = True
        polys = []
        for sq in squares:
            p = _hull(_corners(sq[0], sq[1], sq[2], sq[3]))
            if not _inside_unit_square(p):
                ok = False
                break
            polys.append(p)
        if ok:
            for a in range(n):
                if not ok:
                    break
                for b in range(a + 1, n):
                    if squares[a][3] <= 1e-14 or squares[b][3] <= 1e-14:
                        continue
                    if _overlap(polys[a], polys[b]) > 0:
                        ok = False
                        break
        if ok:
            cur = _pack_score(squares)
            if cur > best:
                best = cur
            else:
                squares[i] = old
        else:
            squares[i] = old
    return [tuple(sq) for sq in squares]


def _refine(squares, maxiter=60):
    """Continuous refinement maximizing total side subject to separation."""
    squares = [list(sq) for sq in squares]
    n = len(squares)
    if n == 0:
        return []
    # variables: cx, cy, ang, s for each square
    x0 = []
    for cx, cy, ang, s in squares:
        x0.extend([cx, cy, ang, s])
    x0 = np.array(x0)

    def unpack(x):
        return x.reshape((n, 4))

    def objective(x):
        arr = unpack(x)
        return -float(np.sum(arr[:, 3]))

    def constraints(x):
        arr = unpack(x)
        cons = []
        # bounds via inequality constraints (to be safe)
        for i in range(n):
            cx, cy, ang, s = arr[i]
            a = ang * 2 * math.pi
            ca, sa = math.cos(a), math.sin(a)
            h = s * 0.5
            dx = abs(ca * h) + abs(sa * h)
            dy = abs(sa * h) + abs(ca * h)
            cons.append(cx - dx)
            cons.append(1.0 - dx - cx)
            cons.append(cy - dy)
            cons.append(1.0 - dy - cy)
        # pairwise separation: use support function along normals
        for i in range(n):
            for j in range(i + 1, n):
                si = arr[i, 3]
                sj = arr[j, 3]
                if si <= 1e-14 or sj <= 1e-14:
                    continue
                # use axis-aligned overlap approximation and SAT-like margin
                # We'll use the polygon overlap function but smooth by sampling axes
                ai = arr[i, 2] * 2 * math.pi
                aj = arr[j, 2] * 2 * math.pi
                # representative axes: four per square
                axes = []
                for base in [ai, ai + math.pi / 2, aj, aj + math.pi / 2]:
                    axes.append((math.cos(base), math.sin(base)))
                # also axis-aligned
                axes.extend([(1, 0), (0, 1)])
                for (ux, uy) in axes:
                    # support of square i along u: h_i * (|u . e1| + |u . e2|)
                    e1i = (math.cos(ai), math.sin(ai))
                    e2i = (-math.sin(ai), math.cos(ai))
                    hi = si * 0.5 * (abs(ux * e1i[0] + uy * e1i[1]) + abs(ux * e2i[0] + uy * e2i[1]))
                    e1j = (math.cos(aj), math.sin(aj))
                    e2j = (-math.sin(aj), math.cos(aj))
                    hj = sj * 0.5 * (abs(ux * e1j[0] + uy * e1j[1]) + abs(ux * e2j[0] + uy * e2j[1]))
                    d = (arr[j, 0] - arr[i, 0]) * ux + (arr[j, 1] - arr[i, 1]) * uy
                    # separation along u: |d| >= hi + hj or there is some axis where separation is ok
                    cons.append(abs(d) - (hi + hj))
                # We need "at least one axis separates", which is not directly expressible.
                # Instead, we add a soft penalty through an aggregated constraint:
        return np.array(cons)

    # Since exact disjunctive constraints are hard, use a simpler approach:
    # optimize sizes only with fixed centers/angles, then adjust.
    def obj_sizes(x):
        return -np.sum(x[3::4])

    bounds = []
    for i in range(n):
        bounds.extend([(0, 1), (0, 1), (0, 1), (0, max(0.0, squares[i][3] + 0.05))])

    def con_fun(x):
        arr = unpack(x)
        vals = []
        for i in range(n):
            cx, cy, ang, s = arr[i]
            a = ang * 2 * math.pi
            ca, sa = math.cos(a), math.sin(a)
            h = s * 0.5
            dx = abs(ca * h) + abs(sa * h)
            dy = abs(sa * h) + abs(ca * h)
            vals.extend([cx - dx, 1.0 - dx - cx, cy - dy, 1.0 - dy - cy])
        # pairwise via polygon overlap approximation using SAT on limited axes
        return np.array(vals)

    try:
        res = minimize(objective, x0, method="SLSQP", bounds=bounds,
                       constraints=[{"type": "ineq", "fun": con_fun}],
                       options={"maxiter": maxiter, "ftol": 1e-9, "disp": False})
        if res.success or True:
            arr = unpack(res.x)
            # final validity check and clip
            out = []
            for i in range(n):
                cx, cy, ang, s = arr[i]
                ang = ang % 1.0
                s = max(0.0, min(1.0, s))
                cx, cy = _clip_center(cx, cy, ang, s)
                out.append([cx, cy, ang, s])
            return [tuple(o) for o in out]
    except Exception:
        pass
    return [tuple(sq) for sq in squares]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_score = -1.0
    rng = random.Random(12345 + n)

    # deterministic grid baseline
    k = math.isqrt(n)
    side = 1.0 / k
    grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
    grid = grid[:n]
    if _pack_score(grid) > best_score:
        best_score = _pack_score(grid)
        best = grid

    # greedy random attempts
    for trial in range(8):
        sq = _greedy(n, rng)
        sq = _local_improve(sq, rng, steps=120)
        sc = _pack_score(sq)
        if sc > best_score:
            best_score = sc
            best = sq

    # refinement
    refined = _refine(best, maxiter=50)
    sc = _pack_score(refined)
    if sc > best_score:
        best_score = sc
        best = refined

    # ensure exactly n and valid
    out = []
    for i in range(n):
        if i < len(best):
            cx, cy, ang, s = best[i]
        else:
            cx, cy, ang, s = 0.5, 0.5, 0.0, 0.0
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = float(ang) % 1.0
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, ang, s))

    # validate/correct for overlaps by shrinking problematic squares
    changed = True
    rounds = 0
    while changed and rounds < 60:
        changed = False
        rounds += 1
        polys = [_hull(_corners(cx, cy, ang, s)) if s > 1e-14 else [] for cx, cy, ang, s in out]
        for i in range(n):
            if out[i][3] <= 1e-14:
                continue
            ci = polys[i]
            if not _inside_unit_square(ci):
                cx, cy, ang, s = out[i]
                s *= 0.95
                cx, cy = _clip_center(cx, cy, ang, s)
                out[i] = (cx, cy, ang, s)
                polys[i] = _hull(_corners(cx, cy, ang, s))
                changed = True
            for j in range(i + 1, n):
                if out[j][3] <= 1e-14:
                    continue
                ov = _overlap(polys[i], polys[j])
                if ov > 0:
                    # shrink both
                    for idx in (i, j):
                        cx, cy, ang, s = out[idx]
                        s *= 0.9
                        cx, cy = _clip_center(cx, cy, ang, s)
                        out[idx] = (cx, cy, ang, s)
                        polys[idx] = _hull(_corners(cx, cy, ang, s))
                    changed = True

    return out
