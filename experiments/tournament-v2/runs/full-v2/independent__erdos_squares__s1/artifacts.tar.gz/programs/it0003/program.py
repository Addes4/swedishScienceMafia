"""Optimized solver for packing n squares with maximum total side length."""
import math
import random
import numpy as np
from scipy.optimize import minimize


def _overlap_penalty(squares):
    """Penalty for overlaps and out-of-bounds (vectorized-ish for small n)."""
    n = len(squares)
    pen = 0.0
    boxes = []
    for cx, cy, ang, s in squares:
        if s <= 1e-12:
            boxes.append(None)
            continue
        h = s * 0.5
        c, si = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
        # corners relative
        corners = []
        for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + c * sx - si * sy
            y = cy + si * sx + c * sy
            corners.append((x, y))
        boxes.append(corners)
        # boundary penalty
        xs = [p[0] for p in corners]
        ys = [p[1] for p in corners]
        for v in xs:
            if v < 0: pen += 20 * v * v
            if v > 1: pen += 20 * (v - 1) * (v - 1)
        for v in ys:
            if v < 0: pen += 20 * v * v
            if v > 1: pen += 20 * (v - 1) * (v - 1)
    # pairwise overlap via separating axis (small n)
    for i in range(n):
        if boxes[i] is None:
            continue
        for j in range(i + 1, n):
            if boxes[j] is None:
                continue
            b1, b2 = boxes[i], boxes[j]
            overlap = True
            for a, b in ((b1[1][0] - b1[0][0], b1[1][1] - b1[0][1]),
                         (b1[3][0] - b1[0][0], b1[3][1] - b1[0][1]),
                         (b2[1][0] - b2[0][0], b2[1][1] - b2[0][1]),
                         (b2[3][0] - b2[0][0], b2[3][1] - b2[0][1])):
                ax, ay = -a, -b  # normal to edge
                p1 = [x * ax + y * ay for x, y in b1]
                p2 = [x * ax + y * ay for x, y in b2]
                if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
                    overlap = False
                    break
            if overlap:
                # compute approximate overlap area penalty
                dx = abs(b1[0][0] - b2[0][0])
                dy = abs(b1[0][1] - b2[0][1])
                pen += 50 * max(0, (1 - dx)) * max(0, (1 - dy))
    return pen


def _pack_grid_and_extras(n):
    """Baseline: k x k grid, and fill rest as tiny squares in free-ish spots."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    return squares


def _improve(squares, iters=40):
    """Local coordinate descent: adjust each square to maximize side sum."""
    n = len(squares)
    # parameterize: x, y, angle, side
    best = [list(s) for s in squares]
    best_score = sum(s[3] for s in best) - _overlap_penalty(best)

    rng = random.Random(12345)
    for it in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for idx in order:
            cx, cy, ang, s = best[idx]
            # try to grow this square
            for trial in range(60):
                scale = 1.0 + 0.15 * (trial + 1) / 60
                ns = s * scale
                # random small perturbations
                ncx = cx + rng.uniform(-0.03, 0.03)
                ncy = cy + rng.uniform(-0.03, 0.03)
                nang = ang + rng.uniform(-0.1, 0.1)
                ncx = min(max(ncx, 0), 1)
                ncy = min(max(ncy, 0), 1)
                nang = min(max(nang, 0), 1)
                cand = [list(x) for x in best]
                cand[idx] = [ncx, ncy, nang, ns]
                if any(c[3] <= 0 for c in cand):
                    pass
                score = sum(c[3] for c in cand) - _overlap_penalty(cand)
                if score > best_score + 1e-9:
                    best = cand
                    best_score = score
                    improved = True
                    cx, cy, ang, s = ncx, ncy, nang, ns
        if not improved:
            break
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Start with grid-based seed
    k = math.isqrt(n)
    squares = _pack_grid_and_extras(n)
    # Make all squares but the grid ones tiny (then let optimizer decide)
    if len(squares) < n:
        extra = n - len(squares)
        # place extras at random free-ish locations
        rng = random.Random(777)
        for _ in range(extra):
            squares.append([rng.uniform(0.1, 0.9), rng.uniform(0.1, 0.9), rng.uniform(0, 1), 0.001])
    squares = squares[:n]

    # Optimize
    attempts = 4 if n <= 30 else 2
    best_sol = None
    best_val = -1e9
    for a in range(attempts):
        if a == 0:
            seed = [list(s) for s in squares]
        else:
            rng = random.Random(100 + a)
            seed = []
            for _ in range(n):
                seed.append([rng.uniform(0.05, 0.95), rng.uniform(0.05, 0.95), rng.uniform(0, 1), rng.uniform(0.01, 0.2)])
        sol = _improve(seed, iters=30)
        val = sum(s[3] for s in sol) - _overlap_penalty(sol)
        if val > best_val:
            best_val = val
            best_sol = sol

    # Polish with scipy
    def obj(x):
        sq = []
        for i in range(n):
            cx = np.clip(x[4*i], 0, 1)
            cy = np.clip(x[4*i+1], 0, 1)
            ang = x[4*i+2] % 1.0
            side = max(0.0, x[4*i+3])
            sq.append([cx, cy, ang, side])
        pen = _overlap_penalty(sq)
        return -(sum(s[3] for s in sq) - pen)

    x0 = np.array([v for s in best_sol for v in s], dtype=float)
    try:
        res = minimize(obj, x0, method='Nelder-Mead',
                       options={'maxiter': 2000, 'xatol': 1e-6, 'fatol': 1e-6})
        xr = res.x
        refined = []
        for i in range(n):
            cx = float(np.clip(xr[4*i], 0, 1))
            cy = float(np.clip(xr[4*i+1], 0, 1))
            ang = float(xr[4*i+2] % 1.0)
            side = float(max(0.0, xr[4*i+3]))
            refined.append([cx, cy, ang, side])
        if sum(s[3] for s in refined) - _overlap_penalty(refined) > best_val:
            best_sol = refined
            best_val = sum(s[3] for s in refined) - _overlap_penalty(refined)
    except Exception:
        pass

    # Final validation: zero out any oversize squares that cause overlaps
    result = []
    for cx, cy, ang, side in best_sol:
        result.append((min(max(cx, 0), 1), min(max(cy, 0), 1), ang % 1.0, max(0.0, min(side, 1.0))))
    return result
