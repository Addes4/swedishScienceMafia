# EVOLVE-BLOCK-START
"""Adaptive greedy packer with local-search refinement for disjoint squares in the unit square.

Architecture:
    generate_candidates(n) -> diverse pool of (cx, cy, angle, side)
    overlaps(sq1, sq2)     -> exact separating-axis overlap test
    select_squares(n, pool)-> greedy feasible subset maximising sum of sides
    refine(chosen, n, pool)-> local search: shrink/translate to fit extra squares
    finalize(chosen, n)    -> pad to exactly n entries with zero-size squares
"""
import math


def _corners(cx, cy, angle, side):
    h = side * 0.5
    ca = math.cos(angle * 2.0 * math.pi)
    sa = math.sin(angle * 2.0 * math.pi)
    return [
        (cx + sx * ca - sy * sa, cy + sx * sa + sy * ca)
        for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h))
    ]


def _axes(angle):
    a = angle * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    return (ca, sa), (-sa, ca)


def overlaps(sq1, sq2):
    if sq1[3] <= 0.0 or sq2[3] <= 0.0:
        return False
    c1 = _corners(*sq1)
    c2 = _corners(*sq2)
    axes = list(_axes(sq1[2])) + list(_axes(sq2[2]))
    for ax, ay in axes:
        p1 = [x * ax + y * ay for x, y in c1]
        p2 = [x * ax + y * ay for x, y in c2]
        if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
            return False
    return True


def _inside_unit_square(sq):
    for x, y in _corners(*sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def generate_candidates(n):
    candidates = []

    # Strategy A: uniform grids of several resolutions.
    for k in range(1, n + 2):
        side = 1.0 / k
        if side <= 0.0:
            continue
        for i in range(k):
            for j in range(k):
                candidates.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))

    # Strategy B: rotated grids (45 degrees) for extra packing slack.
    for k in range(1, n + 2):
        side = 1.0 / (k * math.sqrt(2.0))
        step = side * math.sqrt(2.0)
        for i in range(k):
            for j in range(k):
                cx = (i + 0.5) * step
                cy = (j + 0.5) * step
                if 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0:
                    candidates.append((cx, cy, 0.125, side))

    # Strategy C: centre-focused squares of decreasing size.
    for m in range(1, n + 3):
        side = 1.0 / m
        for dx in (-0.25, 0.0, 0.25):
            for dy in (-0.25, 0.0, 0.25):
                cx = min(max(0.5 + dx, side * 0.5), 1.0 - side * 0.5)
                cy = min(max(0.5 + dy, side * 0.5), 1.0 - side * 0.5)
                candidates.append((cx, cy, 0.0, side))

    # Strategy D: small rotated squares near edges for gap filling.
    for m in range(2, n + 4):
        side = 1.0 / m
        for ang in (0.125, 0.25):
            for i in range(m + 1):
                for j in range(m + 1):
                    cx = i / m
                    cy = j / m
                    if 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0:
                        candidates.append((cx, cy, ang, side))

    # Deduplicate and keep only valid candidates.
    seen = set()
    pool = []
    for sq in candidates:
        if not _inside_unit_square(sq):
            continue
        key = (round(sq[0], 9), round(sq[1], 9), round(sq[2], 9), round(sq[3], 9))
        if key in seen:
            continue
        seen.add(key)
        pool.append(sq)
    return pool


def select_squares(n, pool):
    """Greedy selection: sort by side descending, accept if no overlap."""
    ordered = sorted(pool, key=lambda s: -s[3])
    chosen = []
    for sq in ordered:
        if len(chosen) >= n:
            break
        if sq[3] <= 0.0:
            continue
        ok = True
        for other in chosen:
            if overlaps(sq, other):
                ok = False
                break
        if ok:
            chosen.append(sq)
    return chosen


def refine(chosen, n, pool):
    """Local search: try to fit additional squares by shrinking existing ones."""
    if len(chosen) >= n:
        return chosen

    # Sort candidates by side descending for new additions.
    ordered = sorted(pool, key=lambda s: -s[3])

    # Try shrinking each chosen square slightly to free space.
    shrink_factors = (0.95, 0.8, 0.6, 0.4, 0.2)
    max_iters = max(2, min(8, n))
    for _ in range(max_iters):
        if len(chosen) >= n:
            break
        # Attempt to add one more square.
        added = False
        for sq in ordered:
            if len(chosen) >= n:
                break
            if sq[3] <= 0.0:
                continue
            ok = True
            for other in chosen:
                if overlaps(sq, other):
                    ok = False
                    break
            if ok:
                chosen.append(sq)
                added = True
                break
        if added:
            continue
        # No direct addition possible: shrink a chosen square to make room.
        for idx in range(len(chosen)):
            if len(chosen) >= n:
                break
            cx, cy, ang, side = chosen[idx]
            if side <= 1e-6:
                continue
            for f in shrink_factors:
                trial = (cx, cy, ang, side * f)
                # Check that trial still fits inside unit square.
                if not _inside_unit_square(trial):
                    continue
                # Temporarily replace.
                old = chosen[idx]
                chosen[idx] = trial
                # Check overlap with all others.
                bad = False
                for j, other in enumerate(chosen):
                    if j == idx:
                        continue
                    if overlaps(trial, other):
                        bad = True
                        break
                if bad:
                    chosen[idx] = old
                    continue
                # Try to add a new square now.
                for sq in ordered:
                    if len(chosen) >= n:
                        break
                    if sq[3] <= 0.0:
                        continue
                    ok2 = True
                    for k, other in enumerate(chosen):
                        if k == idx:
                            continue
                        if overlaps(sq, other):
                            ok2 = False
                            break
                    if ok2:
                        chosen.append(sq)
                        break
                if len(chosen) > len([1 for _ in chosen]):
                    break
                # If we didn't add, revert shrink.
                if len(chosen) == len(chosen):
                    pass
            if len(chosen) >= n:
                break
        # If still no progress, break.
        if len(chosen) >= n:
            break
    return chosen


def finalize(chosen, n):
    result = list(chosen[:n])
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result


def solve(n):
    if n <= 0:
        return []
    # Start from best grid (baseline) to guarantee good score.
    k = math.isqrt(n)
    side = 1.0 / k
    base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(k) for j in range(k)]
    if len(base) >= n:
        return finalize(base, n)

    # Generate candidates and try to improve beyond the grid.
    pool = generate_candidates(n)
    chosen = select_squares(n, pool)
    # If greedy pool is worse than grid, start from grid.
    if sum(s[3] for s in chosen) < sum(s[3] for s in base):
        chosen = base
    chosen = refine(chosen, n, pool)
    # Final safety: if still fewer than n, pad with zero-size squares.
    return finalize(chosen, n)
# EVOLVE-BLOCK-END
