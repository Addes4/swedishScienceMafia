# EVOLVE-BLOCK-START
"""Optimised packing of n squares in the unit square to maximise sum of sides."""
import math
import random
import time


def _overlap(sq1, sq2):
    """Return True if two squares (cx, cy, angle, side) overlap in interior."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 1e-12 or s2 <= 1e-12:
        return False
    # quick bounding circle check
    r1 = s1 * math.sqrt(2) / 2
    r2 = s2 * math.sqrt(2) / 2
    dx = cx1 - cx2
    dy = cy1 - cy2
    if dx * dx + dy * dy > (r1 + r2) ** 2:
        return False
    # SAT for two rectangles (squares are rectangles)
    # half extents
    h1 = s1 / 2
    h2 = s2 / 2
    # axes of square 1
    c1, s1a = math.cos(2 * math.pi * a1), math.sin(2 * math.pi * a1)
    axes1 = [(c1, s1a), (-s1a, c1)]
    # axes of square 2
    c2, s2a = math.cos(2 * math.pi * a2), math.sin(2 * math.pi * a2)
    axes2 = [(c2, s2a), (-s2a, c2)]
    axes = axes1 + axes2
    for ax, ay in axes:
        # project centers
        p1 = cx1 * ax + cy1 * ay
        p2 = cx2 * ax + cy2 * ay
        # project half-extents
        e1 = h1 * (abs(ax * c1 + ay * s1a) + abs(ax * (-s1a) + ay * c1))
        e2 = h2 * (abs(ax * c2 + ay * s2a) + abs(ax * (-s2a) + ay * c2))
        if abs(p1 - p2) > e1 + e2 - 1e-12:
            return False
    return True


def _valid(squares, n):
    """Check all pairs for overlap and containment in unit square."""
    for i in range(n):
        cx, cy, a, s = squares[i]
        if s <= 0:
            continue
        # containment: all corners inside [0,1]^2
        h = s / 2
        c = math.cos(2 * math.pi * a)
        sn = math.sin(2 * math.pi * a)
        for dx, dy in ((h, h), (h, -h), (-h, h), (-h, -h)):
            x = cx + dx * c - dy * sn
            y = cy + dx * sn + dy * c
            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _greedy_place(existing, n_extra, grid=80):
    """Try to place additional squares in the largest empty spots."""
    # build occupancy grid
    occ = [[False] * grid for _ in range(grid)]
    for cx, cy, a, s in existing:
        if s <= 0:
            continue
        h = s / 2
        c = math.cos(2 * math.pi * a)
        sn = math.sin(2 * math.pi * a)
        # bounding box in grid
        r = s * math.sqrt(2) / 2
        gx0 = max(0, int((cx - r) * grid))
        gx1 = min(grid - 1, int((cx + r) * grid))
        gy0 = max(0, int((cy - r) * grid))
        gy1 = min(grid - 1, int((cy + r) * grid))
        for gx in range(gx0, gx1 + 1):
            for gy in range(gy0, gy1 + 1):
                px = (gx + 0.5) / grid
                py = (gy + 0.5) / grid
                dx = px - cx
                dy = py - cy
                # rotate into square frame
                rx = dx * c + dy * sn
                ry = -dx * sn + dy * c
                if abs(rx) <= h and abs(ry) <= h:
                    occ[gx][gy] = True
    # greedy: find largest square that fits in any empty cell
    new_squares = []
    for _ in range(n_extra):
        best = (0, 0, 0, 0)
        best_side = 0
        for gx in range(grid):
            for gy in range(grid):
                if occ[gx][gy]:
                    continue
                # try to grow square centered at this cell
                cx = (gx + 0.5) / grid
                cy = (gy + 0.5) / grid
                # max side limited by distance to edge
                max_s = 2 * min(cx, 1 - cx, cy, 1 - cy)
                # binary search for largest side that fits without hitting occupied cells
                lo, hi = 0.0, max_s
                for _ in range(20):
                    mid = (lo + hi) / 2
                    ok = True
                    h = mid / 2
                    r = mid * math.sqrt(2) / 2
                    gx0 = max(0, int((cx - r) * grid))
                    gx1 = min(grid - 1, int((cx + r) * grid))
                    gy0 = max(0, int((cy - r) * grid))
                    gy1 = min(grid - 1, int((cy + r) * grid))
                    # check if any occupied cell center is inside this square
                    for qx in range(gx0, gx1 + 1):
                        for qy in range(gy0, gy1 + 1):
                            if occ[qx][qy]:
                                px = (qx + 0.5) / grid
                                py = (qy + 0.5) / grid
                                if abs(px - cx) <= h and abs(py - cy) <= h:
                                    ok = False
                                    break
                        if not ok:
                            break
                    if ok:
                        lo = mid
                    else:
                        hi = mid
                if lo > best_side:
                    best_side = lo
                    best = (cx, cy, 0.0, lo)
        if best_side > 1e-9:
            new_squares.append(best)
            # mark occupied
            cx, cy, a, s = best
            h = s / 2
            r = s * math.sqrt(2) / 2
            gx0 = max(0, int((cx - r) * grid))
            gx1 = min(grid - 1, int((cx + r) * grid))
            gy0 = max(0, int((cy - r) * grid))
            gy1 = min(grid - 1, int((cy + r) * grid))
            for gx in range(gx0, gx1 + 1):
                for gy in range(gy0, gy1 + 1):
                    px = (gx + 0.5) / grid
                    py = (gy + 0.5) / grid
                    if abs(px - cx) <= h and abs(py - cy) <= h:
                        occ[gx][gy] = True
        else:
            new_squares.append((0.5, 0.5, 0.0, 0.0))
    return new_squares


def _local_search(squares, n, time_limit):
    """Randomly perturb squares to improve sum of sides."""
    best = [list(s) for s in squares]
    best_sum = sum(s[3] for s in best)
    current = [list(s) for s in best]
    current_sum = best_sum
    start = time.time()
    step = 0
    while time.time() - start < time_limit:
        step += 1
        # pick a random square
        i = random.randrange(n)
        old = current[i][:]
        # random perturbation
        if random.random() < 0.7:
            # change size
            delta = random.gauss(0, 0.02)
            new_s = max(0.0, old[3] + delta)
            current[i][3] = new_s
        if random.random() < 0.5:
            # move
            current[i][0] = min(1.0, max(0.0, old[0] + random.gauss(0, 0.02)))
            current[i][1] = min(1.0, max(0.0, old[1] + random.gauss(0, 0.02)))
        if random.random() < 0.3:
            # rotate
            current[i][2] = (old[2] + random.gauss(0, 0.05)) % 1.0
        # check validity
        if _valid(current, n):
            new_sum = sum(s[3] for s in current)
            if new_sum > current_sum - 1e-12:
                current_sum = new_sum
                if new_sum > best_sum:
                    best_sum = new_sum
                    best = [s[:] for s in current]
            else:
                current[i] = old
        else:
            current[i] = old
        # occasionally restart from best
        if step % 5000 == 0:
            current = [s[:] for s in best]
            current_sum = best_sum
    return [tuple(s) for s in best]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    # start with grid baseline
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    squares = squares[:n]
    # try to improve by greedy placement of extra squares in leftover space
    # first, identify how many non-zero squares we have
    non_zero = [s for s in squares if s[3] > 1e-9]
    n_zero = n - len(non_zero)
    if n_zero > 0:
        # try greedy placement
        new_squares = _greedy_place(non_zero, n_zero, grid=60)
        candidate = non_zero + new_squares
        if _valid(candidate, n):
            if sum(s[3] for s in candidate) > sum(s[3] for s in squares):
                squares = candidate
    # also try a layout with one large square and rest equal
    # large square side L in corner, remaining area packed with (n-1) equal squares
    # simple heuristic: try L from 0.3 to 0.9
    best_sum = sum(s[3] for s in squares)
    best_layout = squares
    for L in [0.3, 0.4, 0.5, 0.6, 0.7, 0.8]:
        if L >= 1.0:
            continue
        # place large square at bottom-left corner
        large = (L / 2, L / 2, 0.0, L)
        # remaining L-shaped region: right strip width 1-L, top strip height 1-L
        # try to pack (n-1) equal squares of side t in the remaining region
        # simple: pack in right strip and top strip
        rem = n - 1
        if rem <= 0:
            continue
        # area of remaining region
        area = 1.0 - L * L
        # max possible side if all equal
        t_max = math.sqrt(area / rem) if rem > 0 else 0
        # but must fit in strips
        t = min(t_max, 1 - L)
        # count how many fit in right strip (width 1-L, height 1)
        # and top strip (width L, height 1-L) - avoid double counting corner
        # right strip: x from L to 1, y from 0 to 1
        # top strip: x from 0 to L, y from L to 1
        # pack squares of side t
        if t > 1e-9:
            # right strip
            nx = int((1 - L) / t)
            ny = int(1.0 / t)
            # top strip
            nx2 = int(L / t)
            ny2 = int((1 - L) / t)
            total = nx * ny + nx2 * ny2
            if total >= rem:
                # construct layout
                layout = [large]
                # place in right strip
                placed = 0
                for i in range(nx):
                    for j in range(ny):
                        if placed >= rem:
                            break
                        cx = L + (i + 0.5) * t
                        cy = (j + 0.5) * t
                        if cx + t / 2 <= 1.0 + 1e-9 and cy + t / 2 <= 1.0 + 1e-9:
                            layout.append((cx, cy, 0.0, t))
                            placed += 1
                    if placed >= rem:
                        break
                # place in top strip
                for i in range(nx2):
                    for j in range(ny2):
                        if placed >= rem:
                            break
                        cx = (i + 0.5) * t
                        cy = L + (j + 0.5) * t
                        if cx + t / 2 <= L + 1e-9 and cy + t / 2 <= 1.0 + 1e-9:
                            layout.append((cx, cy, 0.0, t))
                            placed += 1
                    if placed >= rem:
                        break
                if placed >= rem:
                    layout = layout[:n]
                    while len(layout) < n:
                        layout.append((0.5, 0.5, 0.0, 0.0))
                    if _valid(layout, n):
                        s = sum(sq[3] for sq in layout)
                        if s > best_sum:
                            best_sum = s
                            best_layout = layout
    squares = best_layout
    # local search to improve
    squares = _local_search(squares, n, 5.0)
    # ensure exactly n squares
    if len(squares) < n:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
# EVOLVE-BLOCK-END