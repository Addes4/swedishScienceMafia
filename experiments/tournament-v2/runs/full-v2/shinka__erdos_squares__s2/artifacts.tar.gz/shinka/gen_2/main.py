# EVOLVE-BLOCK-START
"""Layered greedy packer for disjoint squares inside the unit square.

Architecture:
    generate_candidates() -> list of (cx, cy, angle, side)
    overlaps()            -> exact separating-axis overlap test
    select_squares()      -> greedy feasible subset maximising sum of sides
    finalize()            -> pad to exactly n entries
"""
import math


def _corners(cx, cy, angle, side):
    """Return the four corners of a square as (x, y) tuples."""
    h = side * 0.5
    ca = math.cos(angle * 2.0 * math.pi)
    sa = math.sin(angle * 2.0 * math.pi)
    pts = []
    for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + sx * ca - sy * sa, cy + sx * sa + sy * ca))
    return pts


def _axes(angle):
    """Return the two unit axis directions of a square."""
    a = angle * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    return (ca, sa), (-sa, ca)


def overlaps(sq1, sq2):
    """Separating-axis overlap test for two (cx, cy, angle, side) squares."""
    if sq1[3] <= 0.0 or sq2[3] <= 0.0:
        return False
    c1 = _corners(*sq1)
    c2 = _corners(*sq2)
    axes = list(_axes(sq1[2])) + list(_axes(sq2[2]))
    for ax, ay in axes:
        p1 = [x * ax + y * ay for x, y in c1]
        p2 = [x * ax + y * ay for x, y in c2]
        if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
            return False
    return True


def _inside_unit_square(sq):
    """Check that all corners of a square lie inside [0,1]^2."""
    for x, y in _corners(*sq):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def generate_candidates(n):
    """Produce a diverse pool of candidate squares."""
    candidates = []

    # Strategy A: uniform grids of several resolutions.
    for k in range(1, n + 2):
        side = 1.0 / k
        if side <= 0.0:
            continue
        for i in range(k):
            for j in range(k):
                cx = (i + 0.5) * side
                cy = (j + 0.5) * side
                candidates.append((cx, cy, 0.0, side))

    # Strategy B: rotated grids (45 degrees) for extra packing slack.
    for k in range(1, n + 2):
        side = 1.0 / (k * math.sqrt(2.0))
        for i in range(k):
            for j in range(k):
                cx = (i + 0.5) * side * math.sqrt(2.0)
                cy = (j + 0.5) * side * math.sqrt(2.0)
                if 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0:
                    candidates.append((cx, cy, 0.125, side))

    # Strategy C: centre-focused squares of decreasing size.
    for m in range(1, n + 3):
        side = 1.0 / m
        for dx in (-0.25, 0.0, 0.25):
            for dy in (-0.25, 0.0, 0.25):
                cx = min(max(0.5 + dx, side * 0.5), 1.0 - side * 0.5)
                cy = min(max(0.5 + dy, side * 0.5), 1.0 - side * 0.5)
                candidates.append((cx, cy, 0.0, side))

    # Deduplicate and keep only valid candidates.
    seen = set()
    pool = []
    for sq in candidates:
        if not _inside_unit_square(sq):
            continue
        key = (round(sq[0], 9), round(sq[1], 9), round(sq[2], 9), round(sq[3], 9))
        if key in seen:
            continue
        seen.add(key)
        pool.append(sq)
    return pool


def select_squares(n, pool):
    """Greedily select at most n non-overlapping squares maximising sum of sides."""
    # Sort by side length descending so large squares are placed first.
    ordered = sorted(pool, key=lambda s: -s[3])
    chosen = []
    for sq in ordered:
        if len(chosen) >= n:
            break
        if sq[3] <= 0.0:
            continue
        ok = True
        for other in chosen:
            if overlaps(sq, other):
                ok = False
                break
        if ok:
            chosen.append(sq)

    # If we still have room, try to add smaller squares by shrinking candidates.
    if len(chosen) < n:
        for sq in ordered:
            if len(chosen) >= n:
                break
            cx, cy, ang, side = sq
            for factor in (0.9, 0.75, 0.5, 0.25):
                trial = (cx, cy, ang, side * factor)
                if trial[3] <= 0.0:
                    continue
                ok = True
                for other in chosen:
                    if overlaps(trial, other):
                        ok = False
                        break
                if ok:
                    chosen.append(trial)
                    break

    return chosen


def finalize(chosen, n):
    """Pad the chosen list with zero-size squares to reach exactly n entries."""
    result = list(chosen[:n])
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    pool = generate_candidates(n)
    chosen = select_squares(n, pool)
    return finalize(chosen, n)
# EVOLVE-BLOCK-END
