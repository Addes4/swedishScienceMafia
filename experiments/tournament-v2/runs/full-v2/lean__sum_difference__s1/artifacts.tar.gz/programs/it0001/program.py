# EVOLVE-BLOCK-START
"""Greedy construction over a bounded grid using bitset arithmetic (numpy)."""
import math
import numpy as np


def _sets(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    d = np.unique(a[:, None] - a[None, :])
    s = np.unique(a[:, None] + a[None, :])
    return len(d), len(s)


def solve():
    # Work on a shifted non-negative grid; builds union of APs then greedy.
    # Candidate universe: multiples / combinations that keep sums in a small lattice.
    # Use two APs with coprime-ish steps merged, then greedy refine.
    cand = []
    for k in range(1, 30):
        cand.append(k)
    for k in range(1, 30):
        cand.append(337 * k)
    # greedy add from pool maximizing score
    pool = list(range(1, 62)) + [337 * k for k in range(1, 62)]
    A = []
    best = -1.0
    import time
    t0 = time.time()
    while time.time() - t0 < 30 and len(A) < 60:
        bd, bs = (-1, -1) if not A else _sets(A)
        bestc = None
        bests = best
        for c in pool:
            if c in A:
                continue
            d, s = _sets(A + [c])
            if s == 0 or len(A) + 1 < 2:
                continue
            sc = math.log(d) / math.log(s) + (1 - 1.0 / (len(A) + 1)) / 100
            if sc > bests:
                bests = sc
                bestc = c
        if bestc is None:
            break
        A.append(bestc)
        best = bests
    return sorted(set(A))
# EVOLVE-BLOCK-END
