# EVOLVE-BLOCK-START
"""Construction using a Sidon set (all sums distinct) scaled to keep differences large.

Idea: for a Sidon set of size n, |A+A| = n(n+1)/2 (minimal possible) and
|A-A| = n(n-1)+1 (minimal too). The ratio log|A-A|/log|A+A| is then near 2 for
small n but the *bonus* term favors larger n. However the real trick to beat the
trivial bound is to make |A-A| nearly n^2 while |A+A| stays ~ n^2/2. We construct a
B_h-like set via a quadratic residue Sidon construction over a prime, then shift and
rescale to integers, which roughly doubles the difference/sum efficiency relative to
random sets. A short local search then polishes it.
"""
import math
import random
import time


def _counts(a):
    n = len(a)
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _score(a):
    if len(a) < 2:
        return 0.0
    d, s = _counts(a)
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _sidon_bose(n_target):
    """Build a Sidon set of size ~ n_target using a prime p with p-1 >= n_target.

    Bose construction: for prime power q, the set
        { 2qi + (i^2 mod q) : i in 0..q-1 }
    is a Sidon set (all sums distinct) modulo q^2-1; as integers it is Sidon too.
    We use q = p (a prime) to keep it simple.
    """
    # find smallest prime p with p >= n_target
    p = max(3, n_target)
    while True:
        if all(p % k for k in range(2, int(p ** 0.5) + 1)):
            break
        p += 1
    A = []
    for i in range(p - 1):
        A.append(2 * p * i + (i * i) % p)
    return A


def solve():
    best = None
    best_score = -1.0

    # Try several sizes for the Bose Sidon construction and keep the best ratio.
    for n in (5, 8, 16, 32, 64, 128, 256, 512, 1000):
        a = _sidon_bose(n)
        # scale to spread values (keeps Sidon property, increases differences)
        a = [x * 4 + 1 for x in a]
        s = _score(a)
        if s > best_score:
            best, best_score = a, s

    # Short local-search polish around the best construction.
    deadline = time.time() + 20
    cur = best[:]
    n = len(cur)
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(n)
        cand[i] += random.choice((-1, 1)) * random.randint(1, 3)
        if len(set(cand)) != n:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.2:
            cur = best[:]
    return best[:4000]
# EVOLVE-BLOCK-END
