# EVOLVE-BLOCK-START
"""Construct sets with many differences and few sums using geometric-like progressions."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build_geometric(base, n):
    """Powers of base give many distinct differences, few sums."""
    a = []
    v = 1
    for _ in range(n):
        if abs(v) > 10**15:
            break
        a.append(v)
        v *= base
    return a


def solve():
    best = None
    best_score = -1.0

    # Try various geometric bases and sizes first.
    for base in [2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 16]:
        for n in range(2, 60):
            a = _build_geometric(base, n)
            if len(a) < 2:
                continue
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a[:]

    if best is None:
        best = [1, 2, 4, 8]
        best_score = _score(best)

    cur = best[:]
    deadline = time.time() + 100
    # Local search polish: perturb entries, add/remove elements.
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.5 and cand:
            i = random.randrange(len(cand))
            scale = max(1, abs(cand[i]) // 10)
            cand[i] += random.randint(-scale, scale)
        elif r < 0.8:
            # add a new element near existing ones
            cand.append(random.choice(cand) + random.randint(-5, 5))
        elif r < 0.9 and len(cand) > 3:
            cand.pop(random.randrange(len(cand)))
        else:
            # swap: combine two elements
            if len(cand) >= 2:
                i = random.randrange(len(cand))
                j = random.randrange(len(cand))
                if i != j:
                    cand[i] = cand[i] + cand[j]

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue
        if len(cand) > 4000:
            continue

        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
