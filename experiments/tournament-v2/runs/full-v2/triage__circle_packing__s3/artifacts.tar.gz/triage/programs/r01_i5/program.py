import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint

def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    # Initial layout from the provided baseline
    np.random.seed(42)
    centers_init = [[0.5, 0.5]]
    centers_init += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers_init += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    centers_init += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()] for _ in range(n - len(centers_init))]
    centers_init = np.clip(np.array(centers_init[:n]), 0.01, 0.99)
    radii_init = _max_radii_fixed_centers(centers_init)

    # Flatten centers and radii into a single vector x = [x0, y0, r0, x1, y1, r1, ...]
    x0 = np.zeros(3 * n)
    for i in range(n):
        x0[3*i:3*i+2] = centers_init[i]
        x0[3*i+2] = radii_init[i]

    # Bounds: centers in [0,1], radii >= 0
    lb = np.zeros(3 * n)
    ub = np.ones(3 * n)
    bounds = Bounds(lb, ub)

    # Nonlinear constraints: for each pair (i,j) with i<j,
    # (xi - xj)^2 + (yi - yj)^2 >= (ri + rj)^2   =>   g(x) >= 0
    # We'll define g(x) = (xi-xj)^2 + (yi-yj)^2 - (ri+rj)^2
    def constraint_func(x):
        n_local = n
        # Number of pairs
        m = n_local * (n_local - 1) // 2
        g = np.zeros(m)
        idx = 0
        for i in range(n_local):
            xi = x[3*i]
            yi = x[3*i+1]
            ri = x[3*i+2]
            for j in range(i+1, n_local):
                xj = x[3*j]
                yj = x[3*j+1]
                rj = x[3*j+2]
                g[idx] = (xi - xj)**2 + (yi - yj)**2 - (ri + rj)**2
                idx += 1
        # Also boundary constraints: ri <= xi, ri <= yi, ri <= 1-xi, ri <= 1-yi
        # We'll include those as inequality constraints ri - xi <= 0 etc.
        # Actually we can handle them in the same constraint vector.
        # We'll append 4*n extra entries.
        g_bound = np.zeros(4 * n_local)
        for i in range(n_local):
            xi = x[3*i]
            yi = x[3*i+1]
            ri = x[3*i+2]
            g_bound[4*i] = xi - ri       # >=0
            g_bound[4*i+1] = yi - ri
            g_bound[4*i+2] = 1.0 - xi - ri
            g_bound[4*i+3] = 1.0 - yi - ri
        return np.concatenate([g, g_bound])

    # All constraints should be >= 0
    lower_bound = np.zeros(len(constraint_func(x0)))
    upper_bound = np.full(len(constraint_func(x0)), np.inf)
    constraints = NonlinearConstraint(constraint_func, lower_bound, upper_bound)

    # Objective: maximize sum of radii = minimize -sum(r_i)
    def objective(x):
        return -np.sum(x[2::3])

    # Use L-BFGS-B or SLSQP (SLSQP supports constraints)
    # SLSQP typically handles nonlinear constraints well for small to medium problems.
    # Set options:
    options = {'maxiter': 5000, 'ftol': 1e-12, 'disp': False}
    result = minimize(objective, x0, method='SLSQP', bounds=bounds,
                      constraints=constraints, options=options, tol=1e-12)

    optimized_x = result.x
    centers = np.zeros((n, 2))
    radii = np.zeros(n)
    for i in range(n):
        centers[i] = optimized_x[3*i:3*i+2]
        radii[i] = optimized_x[3*i+2]
    # Clip radii to non-negative just in case
    radii = np.maximum(radii, 0.0)
    # Ensure centers are strictly within [0,1] with radii; clip if necessary
    centers = np.clip(centers, 0.0, 1.0)
    # Adjust radii if they exceed boundary distance (due to numerical inaccuracies)
    max_allowed = np.minimum.reduce([centers[:, 0], centers[:, 1],
                                     1.0 - centers[:, 0], 1.0 - centers[:, 1]])
    radii = np.minimum(radii, max_allowed)
    return centers, radii


def _max_radii_fixed_centers(centers):
    """Helper to get initial radii for given centers (from baseline)."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
