import numpy as np
from scipy.optimize import basinhopping
import time

def solve(n=26):
    # Start with a good initial configuration: rings around center
    np.random.seed(42)
    centers = [[0.5, 0.5]]
    # inner ring of 7
    for i in range(7):
        angle = 2 * np.pi * i / 7
        centers.append([0.5 + 0.25 * np.cos(angle), 0.5 + 0.25 * np.sin(angle)])
    # outer ring of 12
    for i in range(12):
        angle = 2 * np.pi * i / 12 + np.pi/12
        centers.append([0.5 + 0.45 * np.cos(angle), 0.5 + 0.45 * np.sin(angle)])
    # remaining 6 randomly placed
    for _ in range(n - len(centers)):
        centers.append([0.2 + 0.6 * np.random.rand(), 0.2 + 0.6 * np.random.rand()])
    
    centers = np.array(centers[:n], dtype=float)
    
    # Initial radii: max possible respecting walls
    radii = np.minimum.reduce([centers[:,0], centers[:,1], 
                                1-centers[:,0], 1-centers[:,1]])
    # Shrink to avoid overlaps
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i+1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = (d / (radii[i] + radii[j])) * 0.99
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    
    # Scale radii to sum ~ 1.0 initial
    radii *= 0.4 / np.sum(radii)
    
    # Optimization via basin hopping
    x0 = np.concatenate([centers.flatten(), radii])
    
    def penalty(x):
        c = x[:2*n].reshape(n, 2)
        r = x[2*n:]
        # Boundary penalty
        penalty_val = 0
        for i in range(n):
            if r[i] < 0:
                penalty_val += 1e6 * (-r[i])**2
            # walls
            for val, limit in [(c[i,0], 0), (c[i,1], 0), (1-c[i,0], 0), (1-c[i,1], 0)]:
                if val - r[i] < limit:
                    penalty_val += 1e6 * (r[i] - val)**2
        
        # Overlap penalty
        for i in range(n):
            for j in range(i+1, n):
                d = np.linalg.norm(c[i] - c[j])
                sum_r = r[i] + r[j]
                if d < sum_r:
                    penalty_val += 1e6 * (sum_r - d)**2
        
        return -np.sum(r) + penalty_val
    
    # Bounds: centers in [0,1], radii >= 0
    bounds = [(0.0, 1.0)] * (2*n) + [(0.0, 0.5)] * n
    
    # Basin hopping with local minimization
    minimizer_kwargs = {'method': 'L-BFGS-B', 'bounds': bounds, 
                       'options': {'maxiter': 100}}
    
    start_time = time.time()
    time_limit = 290  # seconds
    
    best_x = x0.copy()
    best_energy = penalty(x0)
    
    result = basinhopping(penalty, x0, niter=1000, stepsize=0.05,
                          minimizer_kwargs=minimizer_kwargs,
                          seed=42, callback=None)
    
    if time.time() - start_time > time_limit:
        pass
    else:
        best_x = result.x
        best_energy = result.fun
    
    # Extract solution
    centers_opt = best_x[:2*n].reshape(n, 2)
    radii_opt = best_x[2*n:]
    
    # Final fix: ensure no overlaps and inside square
    radii_opt = np.maximum(radii_opt, 0)
    centers_opt = np.clip(centers_opt, 0, 1)
    
    # Shrink to strictly satisfy constraints
    for _ in range(100):
        changed = False
        # Walls
        for i in range(n):
            max_r = min(centers_opt[i,0], centers_opt[i,1], 
                       1-centers_opt[i,0], 1-centers_opt[i,1])
            if radii_opt[i] > max_r:
                radii_opt[i] = max_r * 0.999
                changed = True
        # Overlaps
        for i in range(n):
            for j in range(i+1, n):
                d = np.linalg.norm(centers_opt[i] - centers_opt[j])
                if radii_opt[i] + radii_opt[j] > d:
                    scale = (d / (radii_opt[i] + radii_opt[j])) * 0.999
                    radii_opt[i] *= scale
                    radii_opt[j] *= scale
                    changed = True
        if not changed:
            break
    
    return centers_opt, radii_opt


if __name__ == "__main__":
    centers, radii = solve(26)
    print(f"Sum of radii: {np.sum(radii):.6f}")
