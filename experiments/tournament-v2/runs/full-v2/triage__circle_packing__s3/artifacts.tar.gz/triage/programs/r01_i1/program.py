import numpy as np
from scipy.stats.qmc import Sobol

def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    # Use Sobol quasi-random sequence for better space coverage
    sobol = Sobol(d=2, seed=42)
    # Generate n additional quasi-random points in [0,1]x[0,1]
    points = sobol.random(n)
    
    # Map points into [0.05, 0.95] range to keep away from walls
    margin = 0.05
    points = margin + (1 - 2 * margin) * points
    centers = np.clip(points, margin, 1 - margin)
    
    radii = calculate_largest_radii(centers)
    return centers, radii

def calculate_largest_radii(centers):
    """Calculate largest possible radii for non-overlapping circles given fixed centers."""
    n = len(centers)
    # Initial radii from distance to walls
    radii = np.minimum.reduce([
        centers[:, 0],
        centers[:, 1],
        1.0 - centers[:, 0],
        1.0 - centers[:, 1]
    ])
    
    # Iteratively reduce radii to avoid overlaps
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if d == 0:
                    radii[i] = 0.01
                    continue
                possible = d if d > 0 else 0.001
                max_both = d / 2.0
                current_sum = radii[i] + radii[j]
                if current_sum > max_both + 1e-10:
                    scale = min(max_both / radii[i], max_both / radii[j]) if radii[i] + radii[j] > 0 else 0
                    radii[i] *= scale if radii[i] > max_both else 1.0
                    radii[j] *= scale if radii[j] > max_both else 1.0
                    changed = True
        if not changed:
            break
    
    radii = np.maximum(radii, 1e-6)
    return radii
