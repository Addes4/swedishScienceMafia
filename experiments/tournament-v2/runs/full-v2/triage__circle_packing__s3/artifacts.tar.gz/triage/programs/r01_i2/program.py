import numpy as np
from scipy.optimize import minimize
from scipy.spatial.distance import pdist, squareform


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    # Good initial layout: center, two rings, random fill
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.25 * np.cos(2 * np.pi * i / 8),
                 0.5 + 0.25 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.55 * np.cos(2 * np.pi * i / 16),
                 0.5 + 0.55 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    # If n is larger, fill with random points inside [0.05, 0.95]
    needed = n - len(centers)
    if needed > 0:
        rng = np.random.default_rng(42)
        centers += [[rng.uniform(0.05, 0.95),
                     rng.uniform(0.05, 0.95)] for _ in range(needed)]
    centers = np.array(centers[:n])

    # Initial radii: half the minimum distance to walls and neighbours
    radii = initial_radii(centers)
    # Reduce radii until feasible, then project centers onto feasible region
    radii = shrink_radii(centers, radii, iters=30)
    centers = project_to_feasible(centers, radii)

    # Local optimisation loop: alternate between updating radii and projecting centers
    for _ in range(30):
        # Shrink radii to feasibility
        radii = shrink_radii(centers, radii, iters=10)
        # Optimize centers via gradient-based method while respecting variable bounds
        centers = optimize_centers(centers, radii)
        # Final radius shrink
        radii = shrink_radii(centers, radii, iters=20)

    return centers, np.maximum(radii, 0.0)


def initial_radii(centers):
    """Set radii to half the distance to the closest wall or neighbour."""
    n = len(centers)
    # wall distances
    wall_dists = np.minimum(
        np.minimum(centers[:, 0], centers[:, 1]),
        np.minimum(1 - centers[:, 0], 1 - centers[:, 1])
    )
    # pairwise distances
    dists = squareform(pdist(centers))
    np.fill_diagonal(dists, np.inf)
    nn_dists = np.min(dists, axis=1)
    radii = np.minimum(wall_dists / 2, nn_dists / 2)
    radii = np.clip(radii, 0.0, 0.5)
    return radii


def shrink_radii(centers, radii, iters=20):
    """Iteratively reduce radii until no overlap and no wall violation."""
    n = len(centers)
    r = radii.copy()
    for _ in range(iters):
        changed = False
        # walls
        for i in range(n):
            max_allowed = min(centers[i, 0], centers[i, 1], 1 - centers[i, 0], 1 - centers[i, 1])
            if r[i] > max_allowed:
                r[i] = max_allowed
                changed = True
        # overlaps
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if r[i] + r[j] > d:
                    # scale both proportionally
                    total = r[i] + r[j]
                    if total > 0:
                        factor = d / total
                        r[i] *= factor
                        r[j] *= factor
                    else:
                        r[i] = r[j] = 0.0
                    changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


def project_to_feasible(centers, radii):
    """Push centers into [r, 1-r] based on current radii."""
    n = len(centers)
    c = centers.copy()
    for i in range(n):
        if radii[i] <= 0.0:
            # keep inside [0, 1]
            c[i] = np.clip(c[i], 0.0, 1.0)
        else:
            lower = radii[i]
            upper = 1.0 - radii[i]
            c[i, 0] = np.clip(c[i, 0], lower, upper)
            c[i, 1] = np.clip(c[i, 1], lower, upper)
    return c


def optimize_centers(centers, radii):
    """Small local adjustment of centers to maximize sum of radii potential.
    We maximize a proxy function: negative pairwise overlap plus wall margin."""
    n = len(centers)
    r = radii.copy()
    x0 = centers.ravel()

    def objective(x):
        c = x.reshape((n, 2))
        # wall penalty
        penalty = 0.0
        for i in range(n):
            if r[i] > 0:
                lo = r[i]
                hi = 1.0 - r[i]
                penalty += max(0, lo - c[i, 0]) ** 2
                penalty += max(0, lo - c[i, 1]) ** 2
                penalty += max(0, c[i, 0] - hi) ** 2
                penalty += max(0, c[i, 1] - hi) ** 2
        # overlap penalty: sum of squared excess over allowed distance
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(c[i] - c[j])
                target = r[i] + r[j]
                if d < target and target > 0:
                    excess = (target - d) ** 2
                    penalty += excess
        return penalty

    def jac(x):
        c = x.reshape((n, 2))
        grad = np.zeros_like(c)
        for i in range(n):
            if r[i] > 0:
                lo = r[i]
                hi = 1.0 - r[i]
                if c[i, 0] < lo:
                    grad[i, 0] += 2 * (c[i, 0] - lo)
                elif c[i, 0] > hi:
                    grad[i, 0] += 2 * (c[i, 0] - hi)
                if c[i, 1] < lo:
                    grad[i, 1] += 2 * (c[i, 1] - lo)
                elif c[i, 1] > hi:
                    grad[i, 1] += 2 * (c[i, 1] - hi)
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(c[i] - c[j])
                target = r[i] + r[j]
                if d < target and target > 0 and d > 1e-8:
                    vec = c[i] - c[j]
                    excess = target - d
                    # derivative of (target - d)^2 = 2*(target - d) * (-1/d) * vec, etc.
                    coeff = 2 * (target - d) / d
                    grad[i] -= coeff * vec
                    grad[j] += coeff * vec
        return grad.ravel()

    # bounds: allow a bit of movement but keep within r..1-r if r>0, else [0,1]
    bounds = []
    for i in range(n):
        if r[i] > 0:
            bounds.append((r[i], 1.0 - r[i]))
            bounds.append((r[i], 1.0 - r[i]))
        else:
            bounds.append((0.0, 1.0))
            bounds.append((0.0, 1.0))

    res = minimize(objective, x0, method='L-BFGS-B', jac=jac,
                   bounds=bounds, options={'maxiter': 50, 'ftol': 1e-12, 'gtol': 1e-12})
    return res.x.reshape((n, 2))


if __name__ == '__main__':
    centers, radii = solve(26)
    print(f"Score: {np.sum(radii):.6f}")
