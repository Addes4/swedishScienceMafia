# EVOLVE-BLOCK-START
"""Circle packing via a power-diagram / Voronoi-like partition.

Idea
----
Instead of guessing centres and then shrinking radii, we *partition* the
square: every point of the square belongs to the circle whose "power"
  power_i(p) = |p - c_i|^2 - r_i^2
is smallest.  For a true power diagram with prescribed radii this gives
disjoint interiors.  We interleave:

  * Lloyd / power steps: move each centre to the centroid of its cell,
    which keeps the cells roughly equal (good for the sum of radii).
  * radial steps: set each radius to the distance from its centre to the
    nearest boundary of its own cell (walls + Voronoi edges), i.e. the
    largest inscribed circle of the cell, then repair residual overlaps
    by a proportional shrink.

The partition is a discretised Voronoi on a grid, which makes the whole
thing cheap: one pass over the grid per iteration.  Starting from a
concentric ring layout we end up with a nicely balanced packing.
"""
import numpy as np


def _grid_assign(centers, gx, gy):
    """Return, for every grid point, the index of the closest centre.

    centers : (n, 2).  gx, gy : (m,) coordinate vectors.
    Returns idx : (m, m) int array.
    """
    # squared distance to each centre, computed in blocks to save memory
    X, Y = np.meshgrid(gx, gy, indexing="ij")           # (m, m)
    pts = np.stack([X.ravel(), Y.ravel()], axis=1)      # (m*m, 2)
    # chunked distance computation
    n = len(centers)
    best = np.full(len(pts), np.inf)
    idx = np.zeros(len(pts), dtype=np.int32)
    chunk = max(1, 4_000_000 // max(n, 1))
    for s in range(0, len(pts), chunk):
        e = min(s + chunk, len(pts))
        d2 = ((pts[s:e, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
        b = d2.argmin(axis=1)
        idx[s:e] = b
    return idx.reshape(X.shape)


def _cell_radius(cx, cy, mask, gx, gy):
    """Largest radius of a circle centred at (cx, cy) inside its own cell.

    The cell is approximated by the grid points assigned to it; the radius is
    limited by the wall and by the distance to the cell boundary, estimated as
    the distance to the nearest grid point assigned to a *different* cell.
    """
    # wall distance
    r = min(cx, cy, 1.0 - cx, 1.0 - cy)
    # distance to nearest "foreign" grid point
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return max(r, 0.0)
    dx = gx[xs] - cx
    dy = gy[ys] - cy
    d = np.sqrt(dx * dx + dy * dy)
    r = min(r, float(d.min()) if len(d) else r)
    return max(r, 0.0)


def _relax_overlaps(centers, radii, iters=60):
    """Proportional shrink of overlapping pairs (keeps centres fixed)."""
    n = len(centers)
    radii = radii.copy()
    C = np.asarray(centers)
    for _ in range(iters):
        D = np.sqrt(((C[:, None, :] - C[None, :, :]) ** 2).sum(axis=2))
        np.fill_diagonal(D, np.inf)
        s = radii[:, None] + radii[None, :]
        over = s > D
        if not over.any():
            break
        # gentle proportional shrink on the worst offender of every row
        ratio = np.where(over, D / np.maximum(s, 1e-12), 1.0)
        factor = np.minimum(ratio.min(axis=1), 1.0)
        radii = radii * np.sqrt(factor)   # sqrt -> both partners shrink
    return np.maximum(radii, 0.0)


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square."""
    rng = np.random.default_rng(12345)

    # ---- initial layout: concentric rings (good balanced seeding) ----
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.30 * np.cos(2 * np.pi * i / 8),
                 0.5 + 0.30 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.68 * np.cos(2 * np.pi * i / 16 + 0.3),
                 0.5 + 0.68 * np.sin(2 * np.pi * i / 16 + 0.3)] for i in range(16)]
    centers = np.array(centers[:n], dtype=float)
    centers = np.clip(centers, 0.02, 0.98)
    # tiny jitter to break symmetry
    centers += rng.normal(0.0, 0.004, size=centers.shape)
    centers = np.clip(centers, 0.01, 0.99)

    # ---- grid used for the discretised power/Voronoi partition ----
    m = 140
    gx = (np.arange(m) + 0.5) / m
    gy = (np.arange(m) + 0.5) / m

    best_centers = centers.copy()
    best_radii = None
    best_score = -np.inf

    # ---- alternating partition / Lloyd / radial optimisation ----
    radii = None
    for step in range(22):
        idx = _grid_assign(centers, gx, gy)

        # new radii: largest inscribed circle of every cell
        new_r = np.zeros(n)
        for k in range(n):
            mask = idx == k
            cnt = int(mask.sum())
            if cnt == 0:
                new_r[k] = 0.0
                continue
            cx, cy = centers[k]
            new_r[k] = _cell_radius(cx, cy, mask, gx, gy)

        # repair residual overlaps (cells can still touch)
        new_r = _relax_overlaps(centers, new_r, iters=40)
        radii = new_r
        score = radii.sum()

        if score > best_score:
            best_score = score
            best_centers = centers.copy()
            best_radii = radii.copy()

        # Lloyd / power step: move centre to centroid of its own cell,
        # pulled slightly toward the geometric centre of mass so that
        # radii stay as large as possible.
        new_centers = centers.copy()
        for k in range(n):
            mask = idx == k
            if mask.sum() < 3:
                continue
            ys, xs = np.nonzero(mask)
            mx = gx[xs].mean()
            my = gy[ys].mean()
            # blend: centroid (equalises cell sizes) and current centre
            new_centers[k, 0] = 0.7 * mx + 0.3 * centers[k, 0]
            new_centers[k, 1] = 0.7 * my + 0.3 * centers[k, 1]
        centers = np.clip(new_centers, 0.01, 0.99)

    # ---- final refinement with a finer grid and more overlap fixing ----
    m2 = 220
    gx2 = (np.arange(m2) + 0.5) / m2
    gy2 = (np.arange(m2) + 0.5) / m2
    for step in range(6):
        idx = _grid_assign(centers, gx2, gy2)
        new_r = np.zeros(n)
        for k in range(n):
            mask = idx == k
            if mask.sum() == 0:
                new_r[k] = 0.0
                continue
            cx, cy = centers[k]
            new_r[k] = _cell_radius(cx, cy, mask, gx2, gy2)
        new_r = _relax_overlaps(centers, new_r, iters=80)
        if new_r.sum() > best_score:
            best_score = new_r.sum()
            best_centers = centers.copy()
            best_radii = new_r.copy()
        # gentle Lloyd on the fine grid
        new_centers = centers.copy()
        for k in range(n):
            mask = idx == k
            if mask.sum() < 3:
                continue
            ys, xs = np.nonzero(mask)
            new_centers[k, 0] = 0.6 * gx2[xs].mean() + 0.4 * centers[k, 0]
            new_centers[k, 1] = 0.6 * gy2[ys].mean() + 0.4 * centers[k, 1]
        centers = np.clip(new_centers, 0.01, 0.99)

    # ---- ensure strict feasibility of the returned packing ----
    if best_radii is None:
        best_radii = _relax_overlaps(best_centers, np.full(n, 1.0 / (2 * n)), iters=200)
    C = best_centers
    R = _relax_overlaps(C, best_radii, iters=200)

    # wall safety: shrink any circle crossing the border
    wall = np.minimum.reduce([C[:, 0], C[:, 1], 1 - C[:, 0], 1 - C[:, 1]])
    R = np.minimum(R, np.maximum(wall, 0.0))
    R = _relax_overlaps(C, R, iters=200)

    # final guard: if anything still overlaps (numerics), scale everything
    D = np.sqrt(((C[:, None, :] - C[None, :, :]) ** 2).sum(axis=2))
    np.fill_diagonal(D, np.inf)
    if (R[:, None] + R[None, :] > D + 1e-12).any():
        R *= 0.999
        R = _relax_overlaps(C, R, iters=200)

    return C, np.maximum(R, 0.0)
# EVOLVE-BLOCK-END
