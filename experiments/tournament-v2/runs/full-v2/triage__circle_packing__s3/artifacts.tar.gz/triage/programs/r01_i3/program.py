# EVOLVE-BLOCK-START
"""Circle packing in the unit square: build a good starting layout, then
refine it with a gradient-free random local search on the centres, where for
any candidate set of centres the radii are recomputed optimally-ish via a
iterative "grow until collision" relaxation."""
import numpy as np


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink
    overlapping pairs iteratively."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(60):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                s = radii[i] + radii[j]
                if s > d > 1e-12:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _initial_centers(n):
    """Hexagonal-ish packing: rows of circles with a centre circle bias."""
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8),
                 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16),
                 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    rng = np.random.default_rng(0)
    centers += [[0.1 + 0.8 * rng.random(), 0.1 + 0.8 * rng.random()]
                for _ in range(max(0, n - len(centers)))]
    return np.clip(np.array(centers[:n], dtype=float), 0.01, 0.99)


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    rng = np.random.default_rng(12345)

    best_centers = _initial_centers(n)
    best_radii = max_radii(best_centers)
    best_score = float(best_radii.sum())

    # Multi-start: perturb the initial layout a few times and keep the best.
    for _ in range(6):
        cand = best_centers + rng.normal(0, 0.05, size=best_centers.shape)
        cand = np.clip(cand, 0.005, 0.995)
        radii = max_radii(cand)
        score = float(radii.sum())
        if score > best_score:
            best_centers, best_radii, best_score = cand, radii, score

    # Gradient-free local refinement: perturb one centre at a time and accept
    # any move that increases the total sum of radii after re-computing radii
    # for the whole set.
    step = 0.05
    accepts = 0
    tries = 0
    no_improve_rounds = 0
    while step > 1e-4:
        tries += 1
        if tries % 400 == 0:
            if no_improve_rounds > 30:
                step *= 0.7
                no_improve_rounds = 0
            else:
                no_improve_rounds = 0

        cand = best_centers.copy()
        i = rng.integers(n)
        cand[i] += rng.normal(0, step, size=2)
        cand[i] = np.clip(cand[i], 0.001, 0.999)

        radii = max_radii(cand)
        score = float(radii.sum())
        if score > best_score:
            best_centers, best_radii, best_score = cand, radii, score
            accepts += 1
            no_improve_rounds = 0
        else:
            no_improve_rounds += 1

        if accepts > 0 and accepts % 50 == 0:
            step = min(0.05, step * 1.05)

    # Final polish pass with a very small fixed-scale search.
    for _ in range(4000):
        cand = best_centers.copy()
        i = rng.integers(n)
        cand[i] += rng.normal(0, 1e-3, size=2)
        cand[i] = np.clip(cand[i], 0.001, 0.999)
        radii = max_radii(cand)
        score = float(radii.sum())
        if score > best_score:
            best_centers, best_radii, best_score = cand, radii, score

    return best_centers, np.maximum(best_radii, 0.0)
# EVOLVE-BLOCK-END

