# EVOLVE-BLOCK-START
"""Packing n squares in the unit square to maximise the sum of side lengths.

Strategy:  We consider the family "a columns x b full rows, plus a partial row of
c = n - a*b squares along the top".  Full rows each have height h and contain a
squares of side s_b = min(h, 1/a).  The partial row has c squares in a strip of
height H = 1 - b*h with side s_p = min(H, 1/c).  For fixed (a,b,c) the objective
a*b*min(h,1/a) + c*min(1-b*h,1/c) is piecewise linear in h and its maximum is
attainable analytically by evaluating the breakpoints:
    h = 1/a                 (full squares become width-limited)
    h = (1 - 1/c)/b         (partial squares become width-limited)
    h = 1/(b+1)             (natural equal-height split)
plus the domain endpoints.  We evaluate all (a,b) with a*b <= n and take the best.

We also try the transposed family (partial column instead of partial row) since
the unit square is symmetric under transposition.
"""

import math


def _best_for_ab(n, a, b):
    """n = a*b + c : b full rows of a squares, plus a partial row of c squares."""
    c = n - a * b
    if c < 0:
        return None
    if c == 0:
        s = min(1.0 / a, 1.0 / b)
        sq = [((i + 0.5) / a, (j + 0.5) / b, 0.0, s)
              for i in range(a) for j in range(b)]
        return (n * s, sq)

    sb_max = 1.0 / a
    sp_max = 1.0 / c

    # Evaluate the objective at a handful of candidate heights.
    hcands = set()
    # breakpoints
    hcands.add(sb_max)                 # full squares become width-limited
    hcands.add((1.0 - sp_max) / b)     # partial squares become width-limited
    hcands.add(1.0 / (b + 1))          # equal split
    hcands.add(1.0 / (b + c))          # alt guess
    # endpoints of feasible h range:  h in (0, 1/b)
    for h in (1.0 / b * 0.999, 1e-6):
        hcands.add(h)

    best = None
    for hb in hcands:
        if hb <= 0 or hb >= 1.0 / b:
            continue
        hp = 1.0 - b * hb
        if hp < 0:
            continue
        sb = min(hb, sb_max)
        sp = min(hp, sp_max)
        total = a * b * sb + c * sp
        if best is None or total > best[0]:
            best = (total, hb, sb, sp)
    if best is None:
        return None
    total, hb, sb, sp = best
    sq = []
    for i in range(a):
        for j in range(b):
            sq.append(((i + 0.5) / a, (j + 0.5) * hb, 0.0, sb))
    hp = 1.0 - b * hb
    for i in range(c):
        sq.append(((i + 0.5) / c, 1.0 - hp / 2.0, 0.0, sp))
    return (total, sq)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square."""
    if n <= 0:
        return []
    best = None
    maxa = n + 1
    for a in range(1, maxa):
        b = n // a
        if b < 1:
            continue
        for (aa, bb) in ((a, b), (b, a)):
            r = _best_for_ab(n, aa, bb)
            if r is not None and (best is None or r[0] > best[0]):
                best = r
    if best is None:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    total, squares = best
    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
# EVOLVE-BLOCK-END
