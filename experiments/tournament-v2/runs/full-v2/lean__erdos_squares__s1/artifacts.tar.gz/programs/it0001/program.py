# EVOLVE-BLOCK-START
"""Packing n squares in the unit square to maximise the sum of side lengths.

Strategy: choose k = floor(sqrt(n)) and lay out k full rows plus one extra row of
r = n - k*k squares.  In the extra row the r squares share the width equally; the
other k*k squares occupy the remaining height equally.  When r == 0 this reduces to
the plain k x k grid.  Additionally, if r > 0 we allow the extra row's squares to be
slightly larger/smaller by a linear programming-free heuristic: the standard result
is that the optimal arrangement makes all squares large and equal-ish, so we simply
compare a few candidate splits (some rows) and pick the one maximizing the sum.

The final tie-break uses the observation that for n = k*k + r the best known sum is
achieved by a "k+1 wide top strip" configuration in many small cases; we therefore
test all ways of writing n = a*b + c (a, b >= 1) using an a x b grid plus a partial
row and return the best.

Simple candidate families (all with disjoint interiors):

1. Full grid k x k of side 1/k  (r == 0).
2. k rows of height h stacked, plus one row of height 1 - k*h containing r squares.
   Optimise h analytically: the bottom k rows each hold k squares of side h, the top
   row holds r squares.  When r == k the top row also holds k squares and the optimum
   is h = 1/(k+1), giving side 1/(k+1) for all -> sum (k*k + k)/(k+1) = k.
   Otherwise the r top squares have side min((1 - k*h)/1, ...) => side (1 - k*h) since
   width 1 with r squares side <= 1/r each, but the top squares cannot be wider than
   the horizontal slot; the binding constraint is the row height.  So top side = 1-k*h.
   Bottom side = min(h, slot).  Slot for bottom = h (height) and 1/k horizontally, so
   bottom side = min(h, 1/k).  We maximise k*k*min(h,1/k) + r*(1-k*h) over h in [0,1/k].
"""

import math


def _best_for_ab(n, a, b):
    """n = a*b + c : use b rows of height h with a squares each, plus a partial
    row of c squares.  Return (sum, squares)."""
    c = n - a * b
    if c < 0:
        return None
    if c == 0:
        s = 1.0 / max(a, b)
        sq = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
              for i in range(a) for j in range(b)]
        # better: use rectangular grid where each cell is (1/a) x (1/b)
        s2 = min(1.0 / a, 1.0 / b)
        sq = [((i + 0.5) / a, (j + 0.5) / b, 0.0, s2)
              for i in range(a) for j in range(b)]
        return (n * s2, sq)
    # b full rows of a squares, plus a partial row of c squares.
    # full rows: height hb, squares side min(hb, 1/a).
    # partial row: height hp = 1 - b*hb, squares side min(hp, 1/c).
    # maximise a*b*min(hb,1/a) + c*min(1-b*hb,1/c)
    best = None
    for hb_choice in (1.0 / a, 1.0 / (b + 1), 1.0 / (a + 1)):
        if hb_choice <= 0 or hb_choice > 1.0 / b:
            continue
        hp = 1.0 - b * hb_choice
        if hp < 0:
            continue
        sb = min(hb_choice, 1.0 / a)
        sp = min(hp, 1.0 / c) if c > 0 else 0.0
        total = a * b * sb + c * sp
        if best is None or total > best[0]:
            best = (total, hb_choice, sb, sp)
    if best is None:
        return None
    total, hb, sb, sp = best
    sq = []
    for i in range(a):
        for j in range(b):
            sq.append(((i + 0.5) / a, (j + 0.5) * hb, 0.0, sb))
    hp = 1.0 - b * hb
    for i in range(c):
        sq.append(((i + 0.5) / c, 1.0 - hp / 2.0, 0.0, sp))
    return (total, sq)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square."""
    if n <= 0:
        return []
    best = None
    k = math.isqrt(n)
    # candidate grid shapes
    cands = set()
    for a in range(1, n + 1):
        b = n // a
        if b >= 1:
            cands.add((a, b))
            cands.add((b, a))
    # also a few near-sqrt shapes with partial rows
    for a in range(1, int(math.isqrt(n)) + 3):
        for b in range(1, int(math.isqrt(n)) + 3):
            if a * b <= n:
                cands.add((a, b))
    for (a, b) in cands:
        r = _best_for_ab(n, a, b)
        if r is not None and (best is None or r[0] > best[0]):
            best = r
    if best is None:
        sq = [(0.5, 0.5, 0.0, 0.0)] * n
        return sq[:n]
    total, squares = best
    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
# EVOLVE-BLOCK-END
