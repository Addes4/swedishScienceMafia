# EVOLVE-BLOCK-START
"""Packing n squares in the unit square to maximise the sum of side lengths.

Strategy:
1. Build good structured candidates: grids a x b (full) plus a partial row,
   trying many (a,b) splits, exactly as before.
2. Improve the winning candidate with a stochastic local search: perturb one
   square's (cx, cy, angle, side) at random, accept if it does not overlap
   (checked exactly for rotated squares) and total side sum does not decrease.
"""

import math
import random


def _best_for_ab(n, a, b):
    c = n - a * b
    if c < 0:
        return None
    if c == 0:
        s2 = min(1.0 / a, 1.0 / b)
        sq = [((i + 0.5) / a, (j + 0.5) / b, 0.0, s2)
              for i in range(a) for j in range(b)]
        return (n * s2, sq)
    best = None
    for hb_choice in (1.0 / a, 1.0 / (b + 1), 1.0 / (a + 1),
                      1.0 / max(a, b)):
        if hb_choice <= 0 or hb_choice > 1.0 / b:
            continue
        hp = 1.0 - b * hb_choice
        if hp < 0:
            continue
        sb = min(hb_choice, 1.0 / a)
        sp = min(hp, 1.0 / c) if c > 0 else 0.0
        total = a * b * sb + c * sp
        if best is None or total > best[0]:
            best = (total, hb_choice, sb, sp)
    if best is None:
        return None
    total, hb, sb, sp = best
    sq = []
    for i in range(a):
        for j in range(b):
            sq.append(((i + 0.5) / a, (j + 0.5) * hb, 0.0, sb))
    hp = 1.0 - b * hb
    for i in range(c):
        sq.append(((i + 0.5) / c, 1.0 - hp / 2.0, 0.0, sp))
    return (total, sq)


def _corners(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((h, h), (h, -h), (-h, -h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap(s1, s2):
    # separated by axis using SAT for convex polygons
    p1 = _corners(*s1)
    p2 = _corners(*s2)
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            mn1 = mx1 = p1[0][0] * nx + p1[0][1] * ny
            for px, py in p1[1:]:
                d = px * nx + py * ny
                if d < mn1: mn1 = d
                if d > mx1: mx1 = d
            mn2 = mx2 = p2[0][0] * nx + p2[0][1] * ny
            for px, py in p2[1:]:
                d = px * nx + py * ny
                if d < mn2: mn2 = d
                if d > mx2: mx2 = d
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def _feasible(sq):
    n = len(sq)
    # inside unit square
    for cx, cy, ang, s in sq:
        if s <= 0:
            continue
        if s > 1.0 + 1e-9:
            return False
        r = s * 0.7071067811865476 + 1e-9
        if cx < r - 1e-7 or cx > 1.0 - r + 1e-7:
            # conservative but allow rotated check below
            pass
        for px, py in _corners(cx, cy, ang, s):
            if px < -1e-9 or px > 1.0 + 1e-9 or py < -1e-9 or py > 1.0 + 1e-9:
                return False
    for i in range(n):
        for j in range(i + 1, n):
            if sq[i][3] <= 0 or sq[j][3] <= 0:
                continue
            if _overlap(sq[i], sq[j]):
                return False
    return True


def _total(sq):
    return sum(s for _, _, _, s in sq)


def _local_search(squares, iters):
    sq = list(squares)
    if not _feasible(sq):
        # relax: shrink to fit if infeasible
        return sq
    tot = _total(sq)
    n = len(sq)
    rng = random.Random(12345)
    best = sq
    best_tot = tot
    cur = list(sq)
    cur_tot = tot
    for _ in range(iters):
        i = rng.randrange(n)
        cx, cy, ang, s = cur[i]
        mode = rng.random()
        if mode < 0.5:
            # grow
            ns = min(1.0, s + rng.uniform(0.0, 0.02))
            ncx = cx + rng.uniform(-0.01, 0.01)
            ncy = cy + rng.uniform(-0.01, 0.01)
            nang = ang + rng.uniform(-0.02, 0.02)
        elif mode < 0.8:
            ns = s
            ncx = cx + rng.uniform(-0.02, 0.02)
            ncy = cy + rng.uniform(-0.02, 0.02)
            nang = ang + rng.uniform(-0.05, 0.05)
        else:
            ns = max(0.0, s - rng.uniform(0.0, 0.01))
            ncx = cx
            ncy = cy
            nang = ang
        nang = nang % 1.0
        cand = (ncx, ncy, nang, ns)
        cur[i] = cand
        if _feasible(cur):
            dtot = _total(cur)
            if dtot >= cur_tot - 1e-12:
                cur_tot = dtot
                if cur_tot > best_tot:
                    best_tot = cur_tot
                    best = list(cur)
            else:
                cur[i] = (cx, cy, ang, s)
        else:
            cur[i] = (cx, cy, ang, s)
    return best


def solve(n):
    if n <= 0:
        return []
    best = None
    cands = set()
    for a in range(1, n + 1):
        b = n // a
        if b >= 1:
            cands.add((a, b))
            cands.add((b, a))
    for a in range(1, int(math.isqrt(n)) + 3):
        for b in range(1, int(math.isqrt(n)) + 3):
            if a * b <= n:
                cands.add((a, b))
    for (a, b) in cands:
        r = _best_for_ab(n, a, b)
        if r is not None and (best is None or r[0] > best[0]):
            best = r
    if best is None:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    total, squares = best
    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]

    # stochastic improvement, budget iters based on n
    iters = 400 if n <= 40 else 200
    improved = _local_search(squares, iters)
    if _total(improved) > total - 1e-12 and _feasible(improved):
        return [tuple(map(float, s)) for s in improved]
    return [tuple(map(float, s)) for s in squares]
# EVOLVE-BLOCK-END
