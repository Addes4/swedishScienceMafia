# EVOLVE-BLOCK-START
"""Constructive Sidon/Golomb-ruler based search for sets A maximizing
log|A-A| / log|A+A| with a small bonus for large |A|.

Architecture:
  generators -> refiners -> evaluator -> selector
"""
import math
import random
import time


# ---------- scoring ----------
def score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


# ---------- generators ----------
def gen_golomb_ruler(n, seed=0):
    """Greedy Golomb-ruler style construction: each new element placed so that
    all pairwise differences stay distinct (Sidon condition)."""
    rng = random.Random(seed)
    a = [0]
    used_diffs = {0}
    while len(a) < n:
        best_x = None
        best_new = None
        # try several random perturbations of the naive greedy pick
        for _ in range(20):
            x = a[-1] + rng.randint(1, 4 * len(a) + 4)
            new_diffs = set()
            ok = True
            for y in a:
                d = abs(x - y)
                if d in used_diffs or d in new_diffs:
                    ok = False
                    break
                new_diffs.add(d)
            if ok:
                if best_new is None or len(new_diffs) > best_new:
                    best_new = len(new_diffs)
                    best_x = x
        if best_x is None:
            # relax: allow collisions but prefer fewer
            x = a[-1] + rng.randint(1, 3 * len(a) + 3)
            for y in a:
                used_diffs.add(abs(x - y))
            a.append(x)
        else:
            used_diffs |= {abs(best_x - y) for y in a}
            a.append(best_x)
    return a


def gen_sidon_modular(n, seed=0):
    """Sidon set in Z_p lifted to integers: pick p ~ n^2, choose a Sidon set
    modulo p via greedy, then lift."""
    rng = random.Random(seed)
    p = max(2 * n * n, 4 * n + 1)
    # find prime >= p
    def is_prime(x):
        if x < 2:
            return False
        i = 2
        while i * i <= x:
            if x % i == 0:
                return False
            i += 1
        return True
    while not is_prime(p):
        p += 1
    used = set()
    a = []
    while len(a) < n:
        x = rng.randrange(p)
        ok = True
        new = set()
        for y in a:
            d = (x - y) % p
            d2 = (y - x) % p
            if d in used or d2 in used or d in new or d2 in new:
                ok = False
                break
            new.add(d)
            new.add(d2)
        if ok:
            used |= new
            a.append(x)
    return a


def gen_shifted_golomb(n, seed=0):
    """Sidon set via base construction: {2*k*p + (k^2 mod p)} for prime p."""
    rng = random.Random(seed)
    # find prime p with p >= n
    p = n
    def is_prime(x):
        if x < 2:
            return False
        i = 2
        while i * i <= x:
            if x % i == 0:
                return False
            i += 1
        return True
    while not is_prime(p):
        p += 1
    a = [2 * k * p + (k * k) % p for k in range(n)]
    rng.shuffle(a)
    return a


# ---------- refiners ----------
def refine_symmetry(a, rng):
    """Try to reduce |A+A| while keeping |A-A| large by small shifts."""
    a = list(set(a))
    best = a[:]
    best_s = score(best)
    for _ in range(30):
        cand = best[:]
        i = rng.randrange(len(cand))
        cand[i] += rng.choice([-2, -1, 1, 2])
        s = score(cand)
        if s > best_s:
            best, best_s = cand, s
    return best


def refine_remove_add(a, rng):
    """Swap out a redundant element and add a fresh one."""
    a = list(set(a))
    if len(a) < 3:
        return a
    best = a[:]
    best_s = score(best)
    for _ in range(20):
        cand = best[:]
        i = rng.randrange(len(cand))
        cand.pop(i)
        cand.append(max(cand) + rng.randint(1, 3 * len(cand) + 3))
        s = score(cand)
        if s > best_s:
            best, best_s = cand, s
    return best


# ---------- evaluator / selector ----------
def solve():
    rng = random.Random(12345)
    deadline = time.time() + 20
    best = [7, 15, 18, 22, -3, -2]
    best_s = score(best)

    generators = [gen_golomb_ruler, gen_sidon_modular, gen_shifted_golomb]
    sizes = list(range(4, 40))

    # Phase 1: constructive generation
    for gen in generators:
        for n in sizes:
            if time.time() > deadline:
                break
            try:
                a = gen(n, seed=rng.randrange(10**9))
            except Exception:
                continue
            a = list(set(a))
            if len(a) < 2:
                continue
            s = score(a)
            if s > best_s:
                best, best_s = a, s
            # refine
            a2 = refine_symmetry(a, rng)
            s2 = score(a2)
            if s2 > best_s:
                best, best_s = a2, s2
            a3 = refine_remove_add(a2, rng)
            s3 = score(a3)
            if s3 > best_s:
                best, best_s = a3, s3

    # Phase 2: local search around best
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        i = rng.randrange(len(cand))
        cand[i] += rng.randint(-2, 2)
        if rng.random() < 0.1:
            cand.append(max(cand) + rng.randint(1, 5 * len(cand) + 5))
        if rng.random() < 0.05 and len(cand) > 4:
            cand.pop(rng.randrange(len(cand)))
        s = score(cand)
        if s >= best_s:
            best, best_s, cur = cand[:], s, cand
        elif rng.random() < 0.15:
            cur = best[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
