# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Build diverse structured starting points
    inits = []
    for k in range(4, 40):
        # grid-like set
        inits.append([i + j * 1000 for i in range(k) for j in range(k)])
        # squares + arithmetic progression
        inits.append([i * i for i in range(k)] + [i * 10000 for i in range(k)])
        # powers of two + small AP
        inits.append([2 ** i for i in range(min(k, 50))] + list(range(k)))
        # two-block AP far apart
        M = k * k + 1
        inits.append(list(range(k)) + [i * M for i in range(1, k + 1)])
    for _ in range(40):
        k = random.randint(10, 120)
        inits.append([random.randint(-100000, 100000) for _ in range(k)])

    for init in inits:
        if time.time() > deadline:
            break
        cur = list(set(init))
        cur_score = _score(cur)
        T = 1.0
        while time.time() < deadline:
            cand = cur[:]
            op = random.random()
            if op < 0.35:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-20, 20)
            elif op < 0.55:
                i = random.randrange(len(cand))
                cand[i] = random.randint(-1000000, 1000000)
            elif op < 0.75:
                cand.append(random.randint(-1000000, 1000000))
            elif len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
            cand = list(set(cand))
            if len(cand) > 4000:
                continue
            s = _score(cand)
            if s > cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-12)):
                cur = cand
                cur_score = s
                if cur_score > best_score:
                    best = cur[:]
                    best_score = cur_score
            T *= 0.99999
            if T < 1e-10:
                T = 0.5
        if best_score > 1.25:
            break

    # Final hill-climbing polish
    while time.time() < deadline:
        cand = best[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-2, 2)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    return sorted(set(best))
# EVOLVE-BLOCK-END