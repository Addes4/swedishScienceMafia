# EVOLVE-BLOCK-START
"""Symmetric Golomb-ruler construction: A = S ∪ (-S) with S a near-Golomb ruler.

Idea: if S has all pairwise differences distinct (a Golomb ruler), then |S-S| = m(m-1)+1
is maximal. For the symmetric set A = S ∪ (-S) with |A| = 2m, the difference set is large
(roughly 2·|S-S|) while the sum set collapses because x + (-x) = 0 for many pairs and
S+S is small relative to S-S. This yields a much better log|A-A|/log|A+A| ratio.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _golomb_ruler(m, seed=0):
    """Greedy construction of a near-Golomb ruler of m marks.

    Marks are positive integers; we greedily add the smallest mark that keeps all
    pairwise differences distinct.
    """
    rng = random.Random(seed)
    marks = [0]
    diffs = set()
    while len(marks) < m:
        # candidate next marks, search a window above the last mark
        last = marks[-1]
        # try candidates in increasing order, with a small random offset to diversify
        found = None
        start = last + 1
        # search up to a reasonable bound (greedy Golomb rulers grow ~ m^2)
        bound = start + max(50, 4 * m * m)
        cands = list(range(start, bound))
        if seed:
            # shuffle a bit to get different rulers
            rng.shuffle(cands)
        for c in cands:
            ok = True
            new_diffs = []
            for x in marks:
                d = c - x
                if d in diffs:
                    ok = False
                    break
                new_diffs.append(d)
            if ok:
                found = (c, new_diffs)
                break
        if found is None:
            break
        c, nd = found
        marks.append(c)
        for d in nd:
            diffs.add(d)
    return marks


def _construct(m):
    """Build symmetric set A = S ∪ (-S) from a Golomb ruler S."""
    S = _golomb_ruler(m)
    A = set(S)
    for x in S:
        A.add(-x)
    return sorted(A)


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    deadline = time.time() + 100

    # Try several Golomb ruler sizes and pick the best-scoring symmetric set.
    best = None
    best_score = -1.0
    sizes = [40, 80, 120, 160, 200, 240, 280, 320]
    for m in sizes:
        if time.time() > deadline:
            break
        A = _construct(m)
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A

    if best is None:
        best = _construct(80)
        best_score = _score(best)

    # Local search: perturb elements while keeping symmetry roughly intact.
    cur = best[:]
    cur_set = set(cur)
    while time.time() < deadline:
        cand = cur[:]
        # pick a random element and perturb it
        i = random.randrange(len(cand))
        delta = random.choice([-2, -1, 1, 2, 3, -3])
        cand[i] += delta
        # occasionally add a new element
        if random.random() < 0.02 and len(cand) < 4000:
            cand.append(random.randint(-1000, 1000))
        cand = sorted(set(cand))
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END