import math
import random
import itertools
import copy
import numpy as np
from scipy.spatial import ConvexHull
from scipy.optimize import linear_sum_assignment
import time

# --- Geometry primitives (polygon intersection, etc.) ---

def rotate_point(x, y, angle_frac):
    """Rotate point (x,y) by angle_frac * 2*pi radians around origin."""
    if angle_frac == 0:
        return x, y
    angle = angle_frac * 2 * math.pi
    c, s = math.cos(angle), math.sin(angle)
    return x * c - y * s, x * s + y * c

def square_vertices(cx, cy, angle_frac, side):
    """Return 4 vertices of square centered at (cx,cy) with side length and rotation."""
    half = side / 2.0
    corners = [(-half, -half), (half, -half), (half, half), (-half, half)]
    verts = []
    for dx, dy in corners:
        rx, ry = rotate_point(dx, dy, angle_frac)
        verts.append((cx + rx, cy + ry))
    return verts

def polygon_intersect(poly1, poly2):
    """
    Check if two convex polygons (lists of 2D vertices in order) intersect.
    Uses Separating Axis Theorem (SAT) for convex polygons.
    Returns True if they intersect (share an interior point or touch? 
    The problem says "no two share an interior point", so we return True if 
    intersection has non-zero area or they overlap on edges? Actually we want
    no interior point sharing, meaning they can touch on boundary. So we consider
    intersection only if their interiors intersect. We'll use a tolerance
    and treat edge contact as non-intersecting. This SAT implementation returns True
    for overlap, False for disjoint, and we treat degenerate overlap (area ~0) as False.
    """
    def edges(poly):
        n = len(poly)
        for i in range(n):
            yield (poly[i], poly[(i+1)%n])

    def project(poly, axis):
        dots = [axis[0]*p[0] + axis[1]*p[1] for p in poly]
        return min(dots), max(dots)

    def perp(v):
        return (-v[1], v[0])

    polys = [poly1, poly2]
    for poly in polys:
        for e1, e2 in edges(poly):
            axis = perp((e2[0]-e1[0], e2[1]-e1[1]))
            # Avoid zero-length edge
            if axis[0]==0 and axis[1]==0:
                continue
            min1, max1 = project(poly1, axis)
            min2, max2 = project(poly2, axis)
            if max1 <= min2 + 1e-9 or max2 <= min1 + 1e-9:
                return False
    return True

def squares_touch_or_overlap(sq1, sq2):
    """Return True if interiors intersect (overlap or one inside another)."""
    # get vertices of both squares
    v1 = square_vertices(*sq1)
    v2 = square_vertices(*sq2)
    # Check SAT. If they only touch edges, SAT will find no separating axis but
    # still projection intervals will touch. To strictly forbid interior sharing,
    # we check if all projections have distance > 1e-7.
    # SAT returns False if there is a gap, True if overlap or touch.
    # We'll convert 'touch' to False by checking if the minimum gap is < -eps (meaning overlap).
    # Actually we want to forbid interior point sharing: if they just touch edges, it's allowed.
    # So we need to detect actual overlap with area>0.
    # We'll use SAT but add a small shrink to the squares for intersection test.
    # By slightly shrinking each square, if they only touch, they become disjoint.
    # So we test intersection of shrunken squares: shrink factor 0.9999.
    # If still intersect, they overlap.
    return polygon_intersect_shrunk(sq1, sq2, shrink=1e-5)

def polygon_intersect_shrunk(sq1, sq2, shrink=1e-5):
    """Check if squares intersect after shrinking them by 'shrink' factor towards center."""
    # We'll shrink each square towards its center a bit.
    def shrink_square(sq, shrink):
        cx, cy, angle, side = sq
        new_side = side * (1 - shrink)
        return (cx, cy, angle, new_side)
    sq1s = shrink_square(sq1, shrink)
    sq2s = shrink_square(sq2, shrink)
    v1 = square_vertices(*sq1s)
    v2 = square_vertices(*sq2s)
    return polygon_intersect(v1, v2)

# --- Check if square is completely inside unit square ---
def square_inside_unit(sq):
    """Check if the square is entirely inside [0,1]x[0,1] (including boundary)."""
    verts = square_vertices(*sq)
    for x, y in verts:
        if x < -1e-9 or x > 1+1e-9 or y < -1e-9 or y > 1+1e-9:
            return False
    return True

# --- Generate candidate placements for a new square in the free space ---
# We'll use a heuristic: generate many random placements and keep the best (largest side) that fits.
# In beam search, adding squares incrementally.

def random_angle():
    return random.random()

def random_point():
    return random.random(), random.random()

def max_side_at_point(cx, cy, angle, existing_squares):
    """Find maximum side length for a square at (cx,cy,angle) that doesn't overlap existing squares and stays inside unit square.
    Returns side length. Uses binary search on side."""
    lo, hi = 0.0, 2.0  # max possible side is sqrt(2) but 2 safe
    for _ in range(20):
        mid = (lo + hi) / 2.0
        sq = (cx, cy, angle, mid)
        if mid > 1.5:
            hi = mid
            continue
        if not square_inside_unit(sq):
            hi = mid
            continue
        overlap = False
        for esq in existing_squares:
            if esq[3] == 0:
                continue
            if squares_touch_or_overlap(sq, esq):
                overlap = True
                break
        if overlap:
            hi = mid
        else:
            lo = mid
    return lo

def generate_candidates(existing_squares, num_candidates=30):
    """Generate candidate placements (cx,cy,angle,side) that fit existing squares.
    Best effort: random positions and angles, compute max side. Keep a few best."""
    candidates = []
    for _ in range(num_candidates):
        cx, cy = random_point()
        angle = random_angle()
        side = max_side_at_point(cx, cy, angle, existing_squares)
        if side > 1e-9:
            # refine with small perturbations
            # optional local search? skip for speed.
            candidates.append((cx, cy, angle, side))
    if not candidates:
        # if no candidates, force zero squares
        return [(0.5,0.5,0.0,0.0)]
    # keep unique best ones: we'll use them later
    # For beam search, we need many candidates. We can also try grid-based approach.
    # But random is okay.
    return candidates

def solve(n, time_limit=60):
    """Stochastic beam search to maximize sum of side lengths for n squares in unit square."""
    start_time = time.time()
    random.seed(42 + n)  # deterministic for reproducibility? But evaluator expects good average.
    # Actually, stochastic approach might give varied results, we want best possible. Use fixed seed per n? 
    # But we want best average across multiple runs? The scoring is based on single run per n? Problem says runs are limited to 60s per n.
    # We'll try to do multistart beam search with time limit.
    
    if n <= 4:
        # simple grid for small n
        k = math.isqrt(n)
        if k == 0:
            k = 1
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        return squares[:n]
    
    # For larger n, we'll use beam search to incrementally place squares.
    # Start with empty set.
    best_state = []
    best_sum = 0.0
    
    # Beam width parameter
    beam_width = 20  # trades off exploration vs time
    max_iter = 5000  # safety
    
    # We'll run multiple attempts from scratch with different random seeds, pick best.
    attempt = 0
    while time.time() - start_time < time_limit * 0.95:
        random.seed(42 + n*100 + attempt)
        state = []  # list of squares
        state_sum = 0.0
        # incremental placement: we need n squares.
        # We'll try to place n squares; if impossible, we fill remainder with zeros.
        for _ in range(n):
            candidates = generate_candidates(state, num_candidates=50)
            if not candidates:
                # fill with zeros
                state.append((0.5,0.5,0.0,0.0))
                continue
            # Heuristic: pick candidate with largest side, but we also want to explore.
            # We'll do beam: maintain top beam_width states? Hard, but we can simplify: for each square,
            # we randomly pick one of top candidates (greedy with noise).
            # For beam search proper, we need to keep multiple sequences. Let's implement simple greedy with
            # random tie-breaking among top candidates.
            candidates.sort(key=lambda q: q[3], reverse=True)
            # pick among top 5
            top_k = min(5, len(candidates))
            chosen = candidates[random.randrange(top_k)]
            state.append(chosen)
            state_sum += chosen[3]
        if state_sum > best_sum:
            best_sum = state_sum
            best_state = state.copy()
        attempt += 1
        if attempt > 20:
            break  # don't spend too much time
    
    # If best_state has fewer than n (should not), pad with zeros.
    while len(best_state) < n:
        best_state.append((0.5,0.5,0.0,0.0))
    # Return only n elements
    return best_state[:n]
