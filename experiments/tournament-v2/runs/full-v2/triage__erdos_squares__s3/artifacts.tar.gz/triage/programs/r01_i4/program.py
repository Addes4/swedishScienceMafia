# EVOLVE-BLOCK-START
"""Circle-packing driven construction of square packings.

Strategy
--------
1. For a given n, generate many candidate *circle* packings inside the unit
   square (circles of varying radii, disjoint interiors).  This is done with a
   simple but effective random sequential / growth heuristic plus local
   relaxation on the radii, since circle packing is far easier to optimise than
   square packing.
2. Map every circle to the largest square whose inscribed circle is that
   circle, i.e. centre = circle centre, side = r * sqrt(2), angle arbitrary.
   The resulting squares are initially disjoint (their inscribed circles are
   disjoint, hence the squares --- which nest around those circles --- are
   disjoint too when given matching orientations).
3. Locally expand the squares and adjust their rotations/positions with a
   constrained optimisation that maximises the total side while keeping all
   pairwise interior-disjointness and the bounding box constraints satisfied.
4. Fall back to the best simple grid when n is a perfect square.

The whole thing is deterministic and runs comfortably inside the time limit.
"""

import math
import random

import numpy as np
from scipy.optimize import minimize


# --------------------------------------------------------------------------
# geometry helpers
# --------------------------------------------------------------------------
SQRT2 = math.sqrt(2.0)


def _corners(cx, cy, ang, s):
    """Return the four corners of a square as a (4,2) array."""
    c, sn = math.cos(2.0 * math.pi * ang), math.sin(2.0 * math.pi * ang)
    h = 0.5 * s
    # local corner offsets (u, v), rotated
    off = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    R = np.array([[c, -sn], [sn, c]], dtype=float)
    return off @ R.T + np.array([cx, cy])


def _axes(ang):
    """Unit vectors along the two sides of a square with orientation `ang`."""
    c, sn = math.cos(2.0 * math.pi * ang), math.sin(2.0 * math.pi * ang)
    return np.array([c, sn]), np.array([-sn, c])


def _overlap_amount(sq1, sq2):
    """Return a positive number if two squares overlap, else <= 0.

    Uses the separating axis theorem with the four candidate axes.
    """
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    u1, v1 = _axes(a1)
    u2, v2 = _axes(a2)
    axes = [u1, v1, u2, v2]
    d = np.array([cx2 - cx1, cy2 - cy1])
    best = -1e9
    for ax in axes:
        r1 = 0.5 * s1 * (abs(np.dot(u1, ax)) + abs(np.dot(v1, ax)))
        r2 = 0.5 * s2 * (abs(np.dot(u2, ax)) + abs(np.dot(v2, ax)))
        gap = abs(np.dot(d, ax)) - (r1 + r2)
        best = max(best, gap)
    # best <= 0 => separated (or touching).  Return penetration depth.
    return best


def _out_of_box_amount(sq):
    """Positive if the square sticks out of [0,1]^2."""
    cx, cy, ang, s = sq
    pts = _corners(cx, cy, ang, s)
    lo = pts.min(axis=0)
    hi = pts.max(axis=0)
    return max(-lo[0], -lo[1], hi[0] - 1.0, hi[1] - 1.0)


def _feasible(squares, tol=1e-9):
    for i in range(len(squares)):
        if _out_of_box_amount(squares[i]) > tol:
            return False
    for i in range(len(squares)):
        for j in range(i + 1, len(squares)):
            if _overlap_amount(squares[i], squares[j]) > tol:
                return False
    return True


def _total_side(squares):
    return sum(s[3] for s in squares)


# --------------------------------------------------------------------------
# circle packing heuristic
# --------------------------------------------------------------------------
def _circle_pack(n, rng, iters=400):
    """Greedy + jiggle circle packing in the unit square.

    Returns list of (cx, cy, r).
    """
    circles = []
    # seed with a few random circles
    seeds = max(1, min(n, 2 + rng.randint(0, 2)))
    for _ in range(seeds):
        r = rng.uniform(0.01, 0.12)
        cx = rng.uniform(r, 1.0 - r)
        cy = rng.uniform(r, 1.0 - r)
        circles.append([cx, cy, r])

    attempts = 0
    max_attempts = 4000
    while len(circles) < n and attempts < max_attempts:
        attempts += 1
        # try to place a new circle tangent-ish to lucky geometry
        r = rng.uniform(0.004, 0.10)
        cx = rng.uniform(r, 1.0 - r)
        cy = rng.uniform(r, 1.0 - r)
        ok = True
        for (ox, oy, orr) in circles:
            dx, dy = cx - ox, cy - oy
            if dx * dx + dy * dy < (r + orr) ** 2 - 1e-14:
                ok = False
                break
        if ok:
            circles.append([cx, cy, r])

    # pad to n
    while len(circles) < n:
        r = 0.002
        circles.append([0.5, 0.5, r])

    arr = np.array(circles, dtype=float)

    # local relaxation: try to grow all radii while keeping disjoint
    for _ in range(iters // 4):
        # grow phase
        arr[:, 2] *= 1.02
        for i in range(n):
            cx, cy, r = arr[i]
            # clamp into box
            r = min(r, cx, 1.0 - cx, cy, 1.0 - cy)
            arr[i, 2] = max(r, 1e-9)
        # resolve overlaps
        for i in range(n):
            for j in range(i + 1, n):
                xi, yi, ri = arr[i]
                xj, yj, rj = arr[j]
                dx, dy = xj - xi, yj - yi
                dist = math.hypot(dx, dy)
                if dist < ri + rj and dist > 1e-12:
                    need = (ri + rj - dist) * 0.5
                    ux, uy = dx / dist, dy / dist
                    xi -= ux * need
                    yi -= uy * need
                    xj += ux * need
                    yj += uy * need
                    arr[i, 0], arr[i, 1] = xi, yi
                    arr[j, 0], arr[j, 1] = xj, yj
        # shrink radii slightly if they cause trouble
        for i in range(n):
            cx, cy, r = arr[i]
            arr[i, 2] = min(r, cx, 1.0 - cx, cy, 1.0 - cy)
            arr[i, 2] = max(arr[i, 2], 1e-9)
        # keep centres inside
        arr[:, 0] = np.clip(arr[:, 0], arr[:, 2], 1.0 - arr[:, 2])
        arr[:, 1] = np.clip(arr[:, 1], arr[:, 2], 1.0 - arr[:, 2])

    return arr


# --------------------------------------------------------------------------
# mapping circles -> squares and local optimisation
# --------------------------------------------------------------------------
def _circles_to_squares(arr):
    squares = []
    for cx, cy, r in arr:
        side = r * SQRT2
        squares.append((float(cx), float(cy), 0.0, float(side)))
    return squares


def _improve_squares(squares, rng, rounds=6):
    """Randomised local improvement of a feasible square packing.

    Repeatedly tries to enlarge each square (and nudge its angle), accepting
    only feasible moves.
    """
    n = len(squares)
    best = [tuple(s) for s in squares]
    best_val = _total_side(best)

    for _ in range(rounds):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, s = best[i]
            base = best[:]
            # try several candidate expansions
            for ds in (0.02, 0.008, 0.004, 0.0015):
                for dang in (0.0, 0.03, -0.03, 0.08, -0.08, 0.15, -0.15, 0.25):
                    cand = (cx, cy, (ang + dang) % 1.0, s + ds)
                    trial = list(best)
                    trial[i] = cand
                    # quick local check against a few neighbours first
                    if _out_of_box_amount(cand) > 1e-12:
                        continue
                    feasible = True
                    for j in range(n):
                        if j == i:
                            continue
                        if _overlap_amount(cand, trial[j]) > 1e-12:
                            feasible = False
                            break
                    if feasible:
                        val = _total_side(trial)
                        if val > best_val + 1e-12:
                            best = trial
                            best_val = val
                            improved = True
                            cx, cy, ang, s = cand
                            break
                else:
                    continue
                break

        # global translation/rotation micro tuning
        if not improved:
            break

    return [tuple(s) for s in best], best_val


def _scipy_polish(squares):
    """Constrained polish with scipy.

    Variables: for each square cx, cy, ang, s.  Objective: maximise sum(s).
    Constraints: pairwise separating-axis gaps >= 0 and box containment.
    """
    n = len(squares)
    x0 = np.zeros(4 * n)
    for i, (cx, cy, ang, s) in enumerate(squares):
        x0[4 * i] = cx
        x0[4 * i + 1] = cy
        x0[4 * i + 2] = ang
        x0[4 * i + 3] = s

    def unpack(x):
        return [(x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]) for i in range(n)]

    def neg_obj(x):
        return -np.sum(x[3::4])

    cons = []

    # box constraints via corner inequalities (linear in cx, cy for fixed ang,s
    # but we treat ang/s as variables -> use the generic SAT slack)
    def make_box_con(i):
        def con(x):
            sq = (x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3])
            return -_out_of_box_amount(sq)
        return con

    def make_pair_con(i, j):
        def con(x):
            a = (x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3])
            b = (x[4 * j], x[4 * j + 1], x[4 * j + 2], x[4 * j + 3])
            return -_overlap_amount(a, b)
        return con

    # Only include non-trivial constraints to keep the problem small.
    eps_box = 1e-3
    for i in range(n):
        if _out_of_box_amount(x0[4 * i:4 * i + 4].reshape(4)[[0, 1, 2, 3]] if False else
                              (x0[4 * i], x0[4 * i + 1], x0[4 * i + 2], x0[4 * i + 3])) > -eps_box:
            cons.append({'type': 'ineq', 'fun': make_box_con(i)})
        else:
            cons.append({'type': 'ineq', 'fun': make_box_con(i)})

    for i in range(n):
        for j in range(i + 1, n):
            a = (x0[4 * i], x0[4 * i + 1], x0[4 * i + 2], x0[4 * i + 3])
            b = (x0[4 * j], x0[4 * j + 1], x0[4 * j + 2], x0[4 * j + 3])
            if _overlap_amount(a, b) > -eps_box:
                cons.append({'type': 'ineq', 'fun': make_pair_con(i, j)})

    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))   # cx
        bounds.append((0.0, 1.0))   # cy
        bounds.append((0.0, 1.0))   # ang
        bounds.append((0.0, 1.0))   # side

    try:
        res = minimize(neg_obj, x0, method='SLSQP', bounds=bounds,
                       constraints=cons, options={'maxiter': 300, 'ftol': 1e-12})
        if res.success or res.fun < neg_obj(x0):
            cand = unpack(res.x)
            # verify feasibility
            if _feasible(cand, tol=1e-7):
                return cand
    except Exception:
        pass
    return squares


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def _grid_solution(n):
    k = math.isqrt(n)
    if k <= 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def solve(n):
    """Return n disjoint squares inside the unit square maximising sum of sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # perfect square -> trivial optimum, use grid
    k = math.isqrt(n)
    if k * k == n and n <= 64:
        return _grid_solution(n)

    rng = random.Random(12345 + 7919 * n)

    best = _grid_solution(n)
    best_val = _total_side(best)

    # multiple restarts of the circle-packing driven pipeline
    restarts = 8 if n <= 24 else 5
    for _ in range(restarts):
        try:
            arr = _circle_pack(n, rng)
            squares = _circles_to_squares(arr)
            if not _feasible(squares, tol=1e-7):
                # repair by shrinking a touch
                squares = [(cx, cy, a, max(0.0, s * 0.999)) for (cx, cy, a, s) in squares]
                if not _feasible(squares, tol=1e-6):
                    continue
            improved, val = _improve_squares(squares, rng, rounds=8)
            if val > best_val:
                best, best_val = improved, val
        except Exception:
            continue

    # final polish attempt
    try:
        polished = _scipy_polish(best)
        if _feasible(polished, tol=1e-7) and _total_side(polished) > best_val - 1e-9:
            if _total_side(polished) > best_val:
                best = polished
    except Exception:
        pass

    # ensure exactly n tuples, all entries within [0,1]
    out = []
    for (cx, cy, a, s) in best[:n]:
        out.append((
            float(min(1.0, max(0.0, cx))),
            float(min(1.0, max(0.0, cy))),
            float(min(1.0, max(0.0, a))),
            float(min(1.0, max(0.0, s))),
        ))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END

