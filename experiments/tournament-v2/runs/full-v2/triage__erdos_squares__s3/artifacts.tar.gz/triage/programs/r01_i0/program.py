# EVOLVE-BLOCK-START
"""Greedy rotated-square packing.

Idea: repeatedly find the largest axis-rotated square that fits somewhere in the
remaining free region and place it there.  The free region is represented as a
collection of clipped cells (a fine grid over the unit square where each cell is
either free or occupied by an already placed square).  For a candidate centre and
angle we search over angles and positions using a quick grid scan, picking the
largest square that fits without overlapping any occupied cell.
"""
import math


def _point_in_square(px, py, cx, cy, ang, s):
    """Return True if point (px,py) is inside the square (cx,cy,ang,s)."""
    ca = math.cos(2.0 * math.pi * ang)
    sa = math.sin(2.0 * math.pi * ang)
    dx = px - cx
    dy = py - cy
    # rotate point into square's local frame
    lx = dx * ca + dy * sa
    ly = -dx * sa + dy * ca
    h = 0.5 * s
    return abs(lx) <= h and abs(ly) <= h


def _square_fits(cx, cy, ang, s, occupied, grid_n):
    """Check that square (cx,cy,ang,s) stays in unit square and is free.

    occupied is a boolean list of size grid_n*grid_n marking blocked cells.
    We approximate occupancy by testing grid cell centres that fall inside the
    candidate square.
    """
    h = 0.5 * s
    if cx - h < -1e-9 or cx + h > 1.0 + 1e-9:
        return False
    if cy - h < -1e-9 or cy + h > 1.0 + 1e-9:
        return False
    ca = math.cos(2.0 * math.pi * ang)
    sa = math.sin(2.0 * math.pi * ang)
    # bounding box in grid coordinates
    rad = h * (abs(ca) + abs(sa))
    x0 = max(0, int((cx - rad) * grid_n) - 1)
    x1 = min(grid_n - 1, int((cx + rad) * grid_n) + 1)
    y0 = max(0, int((cy - rad) * grid_n) - 1)
    y1 = min(grid_n - 1, int((cy + rad) * grid_n) + 1)
    step = 1.0 / grid_n
    for gx in range(x0, x1 + 1):
        px = (gx + 0.5) * step
        for gy in range(y0, y1 + 1):
            if occupied[gy * grid_n + gx]:
                py = (gy + 0.5) * step
                if _point_in_square(px, py, cx, cy, ang, s):
                    return False
    return True


def _refresh_occupancy(squares, grid_n):
    occupied = [False] * (grid_n * grid_n)
    step = 1.0 / grid_n
    for (cx, cy, ang, s) in squares:
        if s <= 1e-12:
            continue
        ca = math.cos(2.0 * math.pi * ang)
        sa = math.sin(2.0 * math.pi * ang)
        h = 0.5 * s
        rad = h * (abs(ca) + abs(sa))
        x0 = max(0, int((cx - rad) * grid_n) - 1)
        x1 = min(grid_n - 1, int((cx + rad) * grid_n) + 1)
        y0 = max(0, int((cy - rad) * grid_n) - 1)
        y1 = min(grid_n - 1, int((cy + rad) * grid_n) + 1)
        for gx in range(x0, x1 + 1):
            px = (gx + 0.5) * step
            for gy in range(y0, y1 + 1):
                if occupied[gy * grid_n + gx]:
                    continue
                py = (gy + 0.5) * step
                if _point_in_square(px, py, cx, cy, ang, s):
                    occupied[gy * grid_n + gx] = True
    return occupied


def _largest_fitting_square(occupied, grid_n):
    """Return (cx, cy, ang, s) of a large square that fits in the free cells."""
    best = (0.5, 0.5, 0.0, 0.0)
    # coarse-to-fine candidate centres on a grid of free cells
    step = 1.0 / grid_n
    angles = [0.0, 0.25, 0.125, 0.375]
    cx_list = []
    cy_list = []
    for gy in range(grid_n):
        for gx in range(grid_n):
            if not occupied[gy * grid_n + gx]:
                cx_list.append((gx + 0.5) * step)
                cy_list.append((gy + 0.5) * step)
    if not cx_list:
        return best
    # For each free cell as a candidate centre try to grow a square.
    for ang in angles:
        ca = math.cos(2.0 * math.pi * ang)
        sa = math.sin(2.0 * math.pi * ang)
        for idx in range(0, len(cx_list), 1):
            cx = cx_list[idx]
            cy = cy_list[idx]
            # max possible half-size limited by unit square
            hx = min(cx, 1.0 - cx)
            hy = min(cy, 1.0 - cy)
            hmax = min(hx, hy)
            s = 2.0 * hmax
            if s <= best[3]:
                continue
            if _square_fits(cx, cy, ang, s, occupied, grid_n):
                if s > best[3]:
                    best = (cx, cy, ang, s)
            else:
                # binary-search shrink for a quick improvement
                lo, hi = 0.0, s
                for _ in range(8):
                    mid = 0.5 * (lo + hi)
                    if _square_fits(cx, cy, ang, mid, occupied, grid_n):
                        lo = mid
                    else:
                        hi = mid
                if lo > best[3]:
                    best = (cx, cy, ang, lo)
    return best


def solve(n):
    """Greedy rotated-square packing."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    grid_n = 40
    squares = []
    # initial grid placement for small n provides a good seed
    if n >= 4:
        k = math.isqrt(n)
        if k * k == n:
            side = 1.0 / k
            for i in range(k):
                for j in range(k):
                    squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))

    placed = 0
    while placed < n:
        occupied = _refresh_occupancy(squares, grid_n)
        cx, cy, ang, s = _largest_fitting_square(occupied, grid_n)
        if s <= 1e-9:
            squares.append((0.5, 0.5, 0.0, 0.0))
        else:
            # shrink slightly to guarantee interior disjointness
            s = s * (1.0 - 1e-6)
            squares.append((cx, cy, ang, s))
        placed = len(squares)
        # safety guard against infinite loops
        if placed > n:
            break

    return squares[:n]
# EVOLVE-BLOCK-END
