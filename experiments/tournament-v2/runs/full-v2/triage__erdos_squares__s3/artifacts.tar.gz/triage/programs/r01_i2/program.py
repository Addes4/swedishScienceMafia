import numpy as np
from scipy.optimize import minimize
from scipy.spatial import ConvexHull
import math
import random

def squares_overlap(s1, s2):
    """
    Check if two squares overlap using the separating axis theorem.
    Each square is (cx, cy, angle, side).
    Returns True if they overlap (share interior points).
    """
    cx1, cy1, a1, s1_side = s1
    cx2, cy2, a2, s2_side = s2
    
    # If either side is 0, they don't overlap (point can be placed anywhere)
    if s1_side <= 1e-12 or s2_side <= 1e-12:
        return False
    
    # Get corners of both squares
    def get_corners(cx, cy, angle, side):
        h = side / 2
        corners = np.array([[-h, -h], [h, -h], [h, h], [-h, h]])
        cos_a = np.cos(angle * 2 * np.pi)
        sin_a = np.sin(angle * 2 * np.pi)
        rot = np.array([[cos_a, -sin_a], [sin_a, cos_a]])
        return np.dot(corners, rot.T) + np.array([cx, cy])
    
    corners1 = get_corners(cx1, cy1, a1, s1_side)
    corners2 = get_corners(cx2, cy2, a2, s2_side)
    
    # Get edge normals for both squares
    def get_axes(corners):
        axes = []
        for i in range(4):
            edge = corners[(i+1)%4] - corners[i]
            normal = np.array([-edge[1], edge[0]])
            norm = np.linalg.norm(normal)
            if norm > 1e-12:
                axes.append(normal / norm)
        return axes
    
    axes = get_axes(corners1) + get_axes(corners2)
    
    for axis in axes:
        proj1 = np.dot(corners1, axis)
        proj2 = np.dot(corners2, axis)
        min1, max1 = np.min(proj1), np.max(proj1)
        min2, max2 = np.min(proj2), np.max(proj2)
        
        # If separated along this axis
        if max1 < min2 - 1e-10 or max2 < min1 - 1e-10:
            return False
    
    return True

def check_all_overlaps(squares):
    """Check if any pair of squares overlaps."""
    n = len(squares)
    for i in range(n):
        for j in range(i+1, n):
            if squares_overlap(squares[i], squares[j]):
                return True
    return False

def check_in_bounds(sq):
    """Check if square is completely inside [0,1]x[0,1]."""
    cx, cy, angle, side = sq
    if side <= 1e-12:
        return 0 <= cx <= 1 and 0 <= cy <= 1
    h = side / 2
    corners = np.array([[-h, -h], [h, -h], [h, h], [-h, h]])
    cos_a = np.cos(angle * 2 * np.pi)
    sin_a = np.sin(angle * 2 * np.pi)
    rot = np.array([[cos_a, -sin_a], [sin_a, cos_a]])
    rotated = np.dot(corners, rot.T) + np.array([cx, cy])
    return np.all(rotated >= -1e-10) and np.all(rotated <= 1 + 1e-10)

def differentiable_non_overlap_penalty(squares):
    """
    Compute a differentiable penalty for overlapping squares.
    Uses soft constraints based on distances between square centers and sizes.
    """
    n = len(squares)
    if n <= 1:
        return 0.0
    
    penalty = 0.0
    for i in range(n):
        for j in range(i+1, n):
            cx1, cy1, a1, s1 = squares[i]
            cx2, cy2, a2, s2 = squares[j]
            
            # Skip if either is essentially a point
            if s1 < 1e-8 or s2 < 1e-8:
                continue
            
            # Approximate distance metric: use bounding circle radius as distance
            # For rotated squares, worst case radius is side/√2
            dist = np.sqrt((cx1 - cx2)**2 + (cy1 - cy2)**2)
            min_dist = (s1 + s2) / np.sqrt(2)  # Approximate: sum of half-diagonals
            
            if dist < min_dist:
                # Smooth penalty: quadratic when overlapping, zero otherwise
                overlap = min_dist - dist
                penalty += overlap**2
    
    return penalty

def bounds_penalty(squares):
    """Differentiable penalty for squares going outside bounds."""
    penalty = 0.0
    for sq in squares:
        cx, cy, angle, side = sq
        if side < 1e-8:
            # Point constraint
            penalty += max(0, -cx)**2 + max(0, cx-1)**2
            penalty += max(0, -cy)**2 + max(0, cy-1)**2
        else:
            h = side / 2
            # Use the fact that max extent from center is h*|cos| + h*|sin| = h*sqrt(2)
            # But differentiable: use soft constraints
            margin = h * np.sqrt(2)
            penalty += max(0, margin - cx)**2 + max(0, cx + margin - 1)**2
            penalty += max(0, margin - cy)**2 + max(0, cy + margin - 1)**2
    return penalty

def objective(params, n):
    """Objective to minimize: negative sum of side lengths + penalties."""
    squares = params_to_squares(params, n)
    total_side = sum(s[3] for s in squares)
    
    overlap_pen = differentiable_non_overlap_penalty(squares)
    bounds_pen = bounds_penalty(squares)
    
    # Weight penalties heavily
    return -total_side + 1000 * overlap_pen + 1000 * bounds_pen

def params_to_squares(params, n):
    """Convert flat parameter array to list of square tuples."""
    squares = []
    for i in range(n):
        cx = params[4*i]
        cy = params[4*i + 1]
        angle = params[4*i + 2] % 1.0  # Keep in [0,1]
        side = params[4*i + 3]
        squares.append((cx, cy, angle, side))
    return squares

def squares_to_params(squares):
    """Convert squares to flat array."""
    params = []
    for sq in squares:
        params.extend([sq[0], sq[1], sq[2], sq[3]])
    return np.array(params)

def clamp_to_bounds(params, n):
    """Project parameters to feasible bounds (soft constraints)."""
    for i in range(n):
        side = params[4*i + 3]
        params[4*i + 3] = max(0.0, min(1.0, side))
        params[4*i] = max(0.0, min(1.0, params[4*i]))
        params[4*i + 1] = max(0.0, min(1.0, params[4*i + 1]))
        params[4*i + 2] = params[4*i + 2] % 1.0

def generate_initial_guess(n, seed=None):
    """Generate a good initial guess based on known optimal/suboptimal patterns."""
    if seed is not None:
        np.random.seed(seed)
        random.seed(seed)
    
    # Try grid-based initializations first
    k = math.isqrt(n)
    if k * k == n and k > 0:
        # Perfect square: regular grid
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) 
                   for i in range(k) for j in range(k)]
        return squares_to_params(squares)
    
    # For non-perfect squares, start with grid plus extra
    if k > 0:
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) 
                   for i in range(k) for j in range(k)]
        # Add remaining squares as small ones
        remaining = n - len(squares)
        for _ in range(remaining):
            cx = np.random.uniform(0.1, 0.9)
            cy = np.random.uniform(0.1, 0.9)
            squares.append((cx, cy, np.random.uniform(0, 1), 0.01))
        return squares_to_params(squares)
    
    # Very small n: random
    squares = []
    for _ in range(n):
        cx = np.random.uniform(0.2, 0.8)
        cy = np.random.uniform(0.2, 0.8)
        angle = np.random.uniform(0, 1)
        side = np.random.uniform(0.1, 0.5)
        squares.append((cx, cy, angle, side))
    return squares_to_params(squares)

def post_process(squares, n):
    """
    Ensure squares are non-overlapping by shrinking/adjusting.
    Simple greedy adjustment.
    """
    # Sort by side length descending
    sorted_indices = sorted(range(n), key=lambda i: squares[i][3], reverse=True)
    
    final_squares = [(0.5, 0.5, 0.0, 0.0)] * n
    
    for idx in sorted_indices:
        sq = squares[idx]
        cx, cy, angle, side = sq
        
        # Try to place this square
        if side < 1e-8:
            final_squares[idx] = (cx, cy, angle, 0.0)
            continue
        
        # Binary search for maximum non-overlapping size
        low, high = 0.0, side
        best_side = 0.0
        best_pos = (cx, cy)
        
        for _ in range(20):
            mid = (low + high) / 2
            test_sq = (cx, cy, angle, mid)
            
            # Check if this square would fit
            fits = True
            if not check_in_bounds(test_sq):
                fits = False
            else:
                for j in range(n):
                    if final_squares[j][3] > 1e-12 and squares_overlap(test_sq, final_squares[j]):
                        fits = False
                        break
            
            if fits:
                best_side = mid
                best_pos = (cx, cy)
                low = mid
            else:
                high = mid
        
        final_squares[idx] = (best_pos[0], best_pos[1], angle, best_side)
    
    return final_squares

def solve(n):
    """
    Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides.
    """
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    best_result = None
    best_sum = -1
    
    # Try multiple random starts
    num_starts = min(10, max(3, 30 // n))  # More starts for smaller n
    
    for start_idx in range(num_starts):
        # Generate initial guess
        initial_params = generate_initial_guess(n, seed=42 + start_idx)
        
        # Bounds for parameters
        bounds = []
        for i in range(n):
            bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])
        
        # Run optimization
        try:
            result = minimize(
                objective,
                initial_params,
                args=(n,),
                method='L-BFGS-B',
                bounds=bounds,
                options={'maxiter': 500, 'ftol': 1e-12, 'gtol': 1e-8}
            )
            
            # Convert result to squares
            opt_squares = params_to_squares(result.x, n)
            
            # Post-process to ensure hard constraints
            final_squares = post_process(opt_squares, n)
            
            total_side = sum(s[3] for s in final_squares)
            
            if total_side > best_sum:
                best_sum = total_side
                best_result = final_squares
                
        except Exception as e:
            continue
    
    # If optimization failed, fall back to baseline
    if best_result is None:
        k = math.isqrt(n)
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) 
                   for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        return squares[:n]
    
    # Format output
    output = []
    for sq in best_result[:n]:
        output.append((float(sq[0]), float(sq[1]), float(sq[2]), float(sq[3])))
    
    return output
