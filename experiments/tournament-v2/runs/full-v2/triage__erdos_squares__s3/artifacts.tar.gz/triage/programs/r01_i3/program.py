import math
import random
import numpy as np
from scipy.optimize import minimize

def _overlap(s1, s2):
    """
    Check if two squares s1 and s2 overlap.
    Each square is given as (cx, cy, angle, side).
    Uses separating axis theorem for two rotated squares.
    Returns True if they overlap (interior intersection), False otherwise.
    """
    cx1, cy1, a1, s1_side = s1
    cx2, cy2, a2, s2_side = s2
    
    # Convert angle to radians (angle is fraction of full turn)
    theta1 = a1 * 2 * math.pi
    theta2 = a2 * 2 * math.pi
    
    # For a square centered at origin with side s, the half-side is s/2
    h1 = s1_side / 2.0
    h2 = s2_side / 2.0
    
    # Rotated axes for square 1: two unit vectors
    axes = [
        (math.cos(theta1), math.sin(theta1)),
        (-math.sin(theta1), math.cos(theta1)),
        (math.cos(theta2), math.sin(theta2)),
        (-math.sin(theta2), math.cos(theta2))
    ]
    
    # Center offset
    dx = cx2 - cx1
    dy = cy2 - cy1
    
    for ax, ay in axes:
        # Project square 1 onto axis
        # For a rotated square with half-sides h1 along axis u1,v1,
        # projection half-length is h1 * (|ax*cos(theta1)+ay*sin(theta1)| + |ax*(-sin(theta1))+ay*cos(theta1)|)
        # Actually, projection of half-extents along an axis ax,ay:
        # extent = h * (abs(cos(theta) dot axis) + abs(sin(theta) perpendicular axis))
        # For square 1:
        # side1 axis1 = (cos1, sin1), axis2 = (-sin1, cos1)
        ext1 = h1 * (abs(math.cos(theta1)*ax + math.sin(theta1)*ay) + 
                     abs(-math.sin(theta1)*ax + math.cos(theta1)*ay))
        # For square 2:
        ext2 = h2 * (abs(math.cos(theta2)*ax + math.sin(theta2)*ay) + 
                     abs(-math.sin(theta2)*ax + math.cos(theta2)*ay))
        
        # Project center distance
        proj_dist = abs(dx * ax + dy * ay)
        
        # If gap, no overlap
        if proj_dist > ext1 + ext2 + 1e-12:
            return False
    
    return True

def _overlap_wall(sq):
    """
    Check if square sq overlaps with the boundary of unit square [0,1]x[0,1].
    Returns True if any part of square lies outside (overlap with exterior).
    We treat the unit square interior as allowed region.
    """
    cx, cy, a, side = sq
    h = side / 2.0
    # We can check using SAT: the square against the bounding box.
    # But simpler: find the AABB of the square and check whether it's inside [0,1].
    # For a rotated square, the bounding box half-extents are:
    # h * (abs(cos) + abs(sin)) etc.
    theta = a * 2 * math.pi
    cos_a = abs(math.cos(theta))
    sin_a = abs(math.sin(theta))
    ext_x = h * (cos_a + sin_a)
    ext_y = h * (sin_a + cos_a)  # same as ext_x because cos+sin symmetric
    
    min_x = cx - ext_x
    max_x = cx + ext_x
    min_y = cy - ext_y
    max_y = cy + ext_y
    
    return min_x < -1e-12 or max_x > 1.0 + 1e-12 or min_y < -1e-12 or max_y > 1.0 + 1e-12

def _no_overlap_all(squares):
    """Check pairwise overlap and wall overlap for all squares. Returns True if no overlaps."""
    n = len(squares)
    for i in range(n):
        s1 = squares[i]
        if s1[3] == 0:
            continue
        if _overlap_wall(s1):
            return False
        for j in range(i+1, n):
            s2 = squares[j]
            if s2[3] == 0:
                continue
            if _overlap(s1, s2):
                return False
    return True

def _pack_squares_randomly(n):
    """
    Greedy placement with physics-like relaxation.
    Start with small sides, place randomly, then expand until no more room.
    Returns list of squares.
    """
    # Initial sides: large enough to be non-zero but small
    initial_side = 0.5 / n  # start small
    # Place randomly in [0,1]x[0,1] with random angles
    squares = []
    for _ in range(n):
        cx = random.random()
        cy = random.random()
        angle = random.random()
        squares.append([cx, cy, angle, initial_side])
    
    # Relax using simple force-directed method to reduce overlaps
    # We simulate for a few iterations, gradually increasing sides
    max_iter = 200
    growth_factor = 1.02  # slow growth
    current_sides = initial_side
    # For relaxation: use gradient-free adjustments
    for it in range(max_iter):
        # Compute forces: repulsion between squares and from walls
        forces = np.zeros((n, 3))  # fx, fy, torque
        overlaps = False
        for i in range(n):
            s1 = squares[i]
            if s1[3] == 0:
                continue
            # Wall repulsion
            # For each wall, push inward if too close
            theta = s1[2] * 2 * math.pi
            h = s1[3] / 2.0
            # Compute bounding box extents
            cos_a = abs(math.cos(theta))
            sin_a = abs(math.sin(theta))
            ext = h * (cos_a + sin_a)
            # left wall
            if s1[0] - ext < 0:
                forces[i][0] += (ext - s1[0])  # push right
                overlaps = True
            # right wall
            if s1[0] + ext > 1.0:
                forces[i][0] -= (s1[0] + ext - 1.0)  # push left
                overlaps = True
            # bottom
            if s1[1] - ext < 0:
                forces[i][1] += (ext - s1[1])
                overlaps = True
            # top
            if s1[1] + ext > 1.0:
                forces[i][1] -= (s1[1] + ext - 1.0)
                overlaps = True
            
            # Inter-square forces
            for j in range(n):
                if i == j:
                    continue
                s2 = squares[j]
                if s2[3] == 0:
                    continue
                # Compute overlap depth approx using bounding circles
                dx = s1[0] - s2[0]
                dy = s1[1] - s2[1]
                dist = math.hypot(dx, dy)
                min_dist = (s1[3] + s2[3]) / 2.0 * 1.5  # rough, not exact SAT but works
                if dist < min_dist and dist > 0:
                    force_mag = (min_dist - dist) / dist
                    forces[i][0] += dx * force_mag
                    forces[i][1] += dy * force_mag
                    overlaps = True
                # Torque: random noise to rotate
                forces[i][2] += (random.random() - 0.5) * 0.01
        # Apply forces
        for i in range(n):
            step = 0.05 / (it + 1)  # cooling
            squares[i][0] += forces[i][0] * step
            squares[i][1] += forces[i][1] * step
            squares[i][2] += forces[i][2] * step
            # clamp positions
            squares[i][0] = max(0.001, min(0.999, squares[i][0]))
            squares[i][1] = max(0.001, min(0.999, squares[i][1]))
            squares[i][2] %= 1.0
        # Increase sides if no overlaps for a while
        if not overlaps and current_sides < 0.5:
            current_sides = min(current_sides * growth_factor, 1.0)
            for s in squares:
                if s[3] > 0:
                    s[3] = current_sides
        # Re-check overlaps using exact SAT; if still overlaps, reduce sides slightly
        if not _no_overlap_all(squares):
            # reduce sides
            for s in squares:
                s[3] *= 0.98
            current_sides = squares[0][3] if n>0 else 0
    # Final check: ensure disjointness, trim if necessary
    if not _no_overlap_all(squares):
        # Shrink all to zero if still overlap
        for s in squares:
            s[3] = 0.0
    return [tuple(s) for s in squares]

def solve(n):
    """
    Return n squares inside unit square, maximising sum of side lengths.
    Uses physics-inspired simulation to pack squares with rotation.
    """
    if n == 0:
        return []
    best_sum = -1
    best_squares = None
    # Multiple restarts
    for _ in range(20):
        squares = _pack_squares_randomly(n)
        total_side = sum(s[3] for s in squares)
        if total_side > best_sum:
            best_sum = total_side
            best_squares = squares
    # If still zero, fallback to grid
    if best_sum == 0:
        k = math.isqrt(n)
        side = 1.0 / k if k>0 else 0
        best_squares = [((i + 0.5)*side, (j + 0.5)*side, 0.0, side) for i in range(k) for j in range(k)]
        best_squares += [(0.5,0.5,0.0,0.0)]*(n - len(best_squares))
        best_squares = best_squares[:n]
    return best_squares
