# EVOLVE-BLOCK-START
"""BSP-tree partitioning approach: recursively divide unit square into regions,
then place the largest fitting square in each region. This maximizes the sum
of side lengths by using a greedy partitioning strategy."""
import math
from typing import List, Tuple

def solve(n: int) -> List[Tuple[float, float, float, float]]:
    """
    Place n squares in unit square [0,1]x[0,1] maximizing sum of side lengths.
    Squares may have different sizes, may be rotated (angle is fraction of full turn),
    and must have disjoint interiors. Returns list of (centre_x, centre_y, angle, side).
    
    Uses recursive BSP-tree/quadtree partitioning with greedy square placement.
    """
    
    result: List[Tuple[float, float, float, float]] = []
    
    def place_in_rect(rect: Tuple[float, float, float, float], 
                     remaining: int,
                     depth: int = 0) -> None:
        """
        Recursively place squares in a rectangular region.
        rect = (x, y, width, height) of available space
        """
        x, y, w, h = rect
        
        # If no space left or no squares to place, stop
        if w <= 0 or h <= 0 or remaining <= 0:
            return
        
        # Determine the largest axis-aligned square that fits
        max_side = min(w, h)
        
        # Center the square in the region
        cx = x + w / 2
        cy = y + h / 2
        
        # Place a square if possible
        if max_side > 0 and remaining > 0:
            result.append((cx, cy, 0.0, max_side))
            remaining -= 1
        
        # If squares remain, partition remaining space into subregions
        if remaining > 0:
            # Create two non-overlapping subregions for recursion:
            # 1. Strip on the right side (for vertical partitioning)
            if w > max_side:
                strip1_rect = (x + max_side, y, w - max_side, h)
                place_in_rect(strip1_rect, remaining - 1, depth + 1)
            
            # 2. Strip on the bottom side (for horizontal partitioning)
            if h > max_side:
                strip2_rect = (x, y + max_side, w, h - max_side)
                place_in_rect(strip2_rect, remaining, depth + 1)
    
    # Start partitioning from the unit square at depth 0
    place_in_rect((0.0, 0.0, 1.0, 1.0), n, 0)
    
    # Pad with zero-size squares if we didn't place enough
    while len(result) < n:
        result.append((0.5, 0.0, 0.0, 0.0))
    
    return result[:n]
# EVOLVE-BLOCK-END
