# EVOLVE-BLOCK-START
"""Circle packing in the unit square: maximise sum of radii.

Strategy:
  - Given centers, the largest feasible radii are computed by starting from the
    wall distance and repeatedly shrinking overlapping pairs (monotone, converges
    to a feasible assignment; we then grow back where possible with a barrier).
  - The centers are optimised with scipy.optimize.minimize (Nelder-Mead) on a
    smooth surrogate objective, followed by randomized restarts / perturbations
    within the time budget.
"""
import time
import numpy as np
from scipy.optimize import minimize


def max_radii(centers):
    """Largest radii for fixed centers (heuristic feasible shrink)."""
    n = len(centers)
    radii = np.minimum.reduce([
        centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]
    ])
    radii = np.maximum(radii, 1e-9)
    for _ in range(200):
        changed = False
        # pair overlaps
        diff = centers[:, None, :] - centers[None, :, :]
        d = np.sqrt((diff ** 2).sum(-1))
        np.fill_diagonal(d, np.inf)
        s = radii[:, None] + radii[None, :]
        over = s - d
        if np.any(over > 1e-12):
            changed = True
            # relax with Jacobi-style multiplicative shrink
            scale = np.where(d > 1e-12, d / np.maximum(s, 1e-12), 1.0)
            scale = np.minimum(scale, 1.0)
            newr = radii.copy()
            for i in range(n):
                newr[i] = radii[i] * np.min(scale[i])
            radii = newr
        if not changed:
            break
    return np.maximum(radii, 0.0)


def sum_for_centers(x):
    c = x.reshape(-1, 2)
    r = max_radii(c)
    return r.sum()


def smooth_obj(x):
    """Negative of a soft-min surrogate so Nelder-Mead can move smoothly."""
    c = x.reshape(-1, 2)
    n = len(c)
    # soft wall radii
    w = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    diff = c[:, None, :] - c[None, :, :]
    d = np.sqrt((diff ** 2).sum(-1))
    np.fill_diagonal(d, np.inf)
    # soft-min over (wall, pair constraints): r_i <= w_i and r_i+r_j <= d_ij
    # use log-sum-exp style smooth approximation of min
    beta = 60.0
    # radii via soft min of half pairwise distances
    half = d / 2.0
    # for each i, min over j of half_ij, combined with wall
    def logsumexp_neg(a):
        m = a.max(axis=-1, keepdims=True)
        return m - np.log(np.exp((a - m) * beta).sum(axis=-1, keepdims=True)) / beta
    # soft min of half distances per i
    smin_half = -logsumexp_neg(-half)  # soft min
    smin_half = smin_half[:, 0]
    r = np.minimum(w, smin_half)
    return -r.sum()


def refine(centers, budget_iters=4000):
    x0 = np.clip(centers, 1e-4, 1 - 1e-4).ravel()
    res = minimize(
        smooth_obj, x0, method="Nelder-Mead",
        options={"maxiter": budget_iters, "xatol": 1e-6, "fatol": 1e-8},
    )
    c = np.clip(res.x.reshape(-1, 2), 1e-4, 1 - 1e-4)
    return c


def solve(n=26):
    rng = np.random.default_rng(12345)
    t0 = time.time()
    time_limit = 280.0

    # initial layouts: rings + random
    def initial_layout(kind):
        if kind == 0:
            c = [[0.5, 0.5]]
            c += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8),
                   0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
            c += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16),
                   0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
            c = np.array(c[:n])
        else:
            c = 0.1 + 0.8 * rng.random((n, 2))
        return np.clip(c, 0.05, 0.95)

    best_c = None
    best_s = -1.0

    candidates = [initial_layout(0), initial_layout(1)]
    # a hex-like fill initialization
    hex_c = []
    rows = 5
    for ri in range(rows):
        y = (ri + 0.5) / rows
        cols = 6 if ri % 2 == 0 else 5
        for ci in range(cols):
            x = (ci + 0.5) / 6 + (0.5 / 6 if ri % 2 else 0.0)
            hex_c.append([x, y])
    hex_c = np.array(hex_c[:n])
    candidates.append(np.clip(hex_c, 0.05, 0.95))

    for c in candidates:
        if time.time() - t0 > time_limit * 0.4:
            break
        c = refine(c, budget_iters=3000)
        s = sum_for_centers(c.ravel())
        if s > best_s:
            best_s = s
            best_c = c.copy()

    # randomized restarts with perturbations
    iteration = 0
    while time.time() - t0 < time_limit and best_c is not None:
        iteration += 1
        base = best_c.copy()
        # perturb a subset
        k = rng.integers(1, max(2, n // 2))
        idx = rng.choice(n, size=k, replace=False)
        base[idx] += rng.normal(0.0, 0.03, size=(k, 2))
        base = np.clip(base, 1e-3, 1 - 1e-3)
        c = refine(base, budget_iters=2000)
        s = sum_for_centers(c.ravel())
        if s > best_s:
            best_s = s
            best_c = c.copy()
        # occasionally full random restart
        if iteration % 7 == 0:
            r = np.clip(0.05 + 0.9 * rng.random((n, 2)), 1e-3, 1 - 1e-3)
            c = refine(r, budget_iters=1500)
            s = sum_for_centers(c.ravel())
            if s > best_s:
                best_s = s
                best_c = c.copy()

    if best_c is None:
        best_c = np.clip(initial_layout(0), 0.05, 0.95)

    # final polish: local coordinate-descent on the exact objective
    c = best_c.copy()
    s = sum_for_centers(c.ravel())
    step = 0.02
    while time.time() - t0 < time_limit and step > 1e-4:
        improved = False
        for i in range(n):
            for dim in range(2):
                for delta in (step, -step):
                    trial = c.copy()
                    trial[i, dim] = np.clip(trial[i, dim] + delta, 1e-4, 1 - 1e-4)
                    ts = sum_for_centers(trial.ravel())
                    if ts > s + 1e-10:
                        c = trial
                        s = ts
                        improved = True
        if not improved:
            step *= 0.5

    best_c = np.clip(c, 1e-4, 1 - 1e-4)
    radii = max_radii(best_c)
    return best_c, radii
# EVOLVE-BLOCK-END
