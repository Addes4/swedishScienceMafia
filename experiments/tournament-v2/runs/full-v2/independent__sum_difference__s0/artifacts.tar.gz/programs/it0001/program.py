import math
import random
import time


def _counts(a):
    A = set(a)
    if len(A) < 2:
        return 0, 0
    diffs = set()
    sums = set()
    L = list(A)
    for i, x in enumerate(L):
        for y in L[i:]:
            diffs.add(x - y)
            diffs.add(y - x)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score(a):
    A = set(a)
    n = len(A)
    if n < 2:
        return -1.0
    d, s = _counts(a)
    if s < 2 or d < 2:
        return -1.0
    return math.log(d) / math.log(s) + (1 - 1.0 / n) / 100


def _fast_diffsum(a):
    diffs = set()
    sums = set()
    L = list(a)
    for i, x in enumerate(L):
        xi = x
        for j in range(i, len(L)):
            y = L[j]
            diffs.add(xi - y)
            sums.add(xi + y)
    return diffs, sums


def greedy_build(n, rng):
    """Greedily build a set: add the element maximising |A-A| growth while limiting |A+A| growth."""
    A = [0, 1]
    diffs, sums = _fast_diffsum(A)
    for _ in range(n - 2):
        best_val = None
        best_key = -1e18
        lo = -50 * n
        hi = 50 * n
        step = max(1, (hi - lo) // 400)
        for cand in range(lo, hi + 1, step):
            if cand in A:
                continue
            nd = len(diffs)
            ns = len(sums)
            cd = 0
            cs = 0
            for x in A:
                if (cand - x) not in diffs:
                    cd += 1
                if (x - cand) not in diffs:
                    cd += 1
                if (cand + x) not in sums:
                    cs += 1
            if cand not in diffs:
                cd += 1
            if (cand + cand) not in sums:
                cs += 1
            newd = nd + cd
            news = ns + cs
            if news <= 0:
                continue
            key = math.log(newd) / math.log(news) if news > 1 else 1e9
            key += 1e-4 * cd - 1e-6 * cs
            if key > best_key:
                best_key = key
                best_val = cand
        if best_val is None:
            best_val = rng.randint(-100 * n, 100 * n)
        A.append(best_val)
        diffs, sums = _fast_diffsum(A)
    return A


def local_search(a, deadline, base_score):
    A = list(set(a))
    cur_score = _score(A)
    if cur_score < 0:
        return A, base_score
    best = A[:]
    best_score = cur_score
    n = len(A)
    it = 0
    while time.time() < deadline:
        it += 1
        cand = best[:]
        op = random.random()
        if op < 0.5:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif op < 0.8:
            if len(cand) < 60:
                hi = max(abs(x) for x in cand)
                cand.append(random.randint(-hi - 5, hi + 5))
        else:
            if len(cand) > 5:
                cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc >= best_score:
            best = cand
            best_score = sc
    return best, best_score


def solve():
    deadline = time.time() + 110
    rng = random.Random(12345)
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    # Try greedy constructions of various sizes
    for n in [8, 10, 12, 15, 20, 25, 30]:
        if time.time() > deadline - 5:
            break
        for _ in range(3):
            if time.time() > deadline - 3:
                break
            A = greedy_build(n, rng)
            sc = _score(A)
            if sc > best_score:
                best = A[:]
                best_score = sc
    # Polish with random changes
    end = deadline
    while time.time() < end:
        best, ns = local_search(best, min(end, time.time() + 8), best_score)
        if ns > best_score:
            best_score = ns
    return sorted(set(best))
