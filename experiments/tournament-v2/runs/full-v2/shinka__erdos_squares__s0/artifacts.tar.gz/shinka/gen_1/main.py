# EVOLVE-BLOCK-START
import math, random

def solve(n):
    if n == 0:
        return []
    # Initialize with baseline grid
    k = math.isqrt(n)
    side = 1.0/k if k > 0 else 1.0
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i+0.5)*side, (j+0.5)*side, side])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0])
    squares = squares[:n]
    
    # Simulated annealing
    random.seed(42 + n)
    def overlap_penalty(sqs):
        pen = 0.0
        for i in range(len(sqs)):
            x1,y1,s1 = sqs[i]
            # out of bounds
            if x1 - s1/2 < -1e-9: pen += (s1/2 - x1)**2 * 100
            if x1 + s1/2 > 1+1e-9: pen += (x1 + s1/2 - 1)**2 * 100
            if y1 - s1/2 < -1e-9: pen += (s1/2 - y1)**2 * 100
            if y1 + s1/2 > 1+1e-9: pen += (y1 + s1/2 - 1)**2 * 100
            for j in range(i+1, len(sqs)):
                x2,y2,s2 = sqs[j]
                dx = abs(x1-x2) - (s1+s2)/2
                dy = abs(y1-y2) - (s1+s2)/2
                if dx < 0 and dy < 0:
                    pen += (-dx)*(-dy) * 1000
        return pen
    
    def energy(sqs):
        return -sum(s for _,_,s in sqs) + overlap_penalty(sqs)
    
    current = [s[:] for s in squares]
    cur_e = energy(current)
    best = [s[:] for s in current]
    best_e = cur_e
    
    T = 0.05
    for it in range(30000):
        T = max(0.001, 0.05 * (1 - it/30000))
        new = [s[:] for s in current]
        op = random.randint(0,2)
        idx = random.randrange(n)
        if op == 0:
            # resize
            delta = random.uniform(-0.05, 0.05)
            new[idx][2] = max(0.0, min(1.0, new[idx][2] + delta))
        elif op == 1:
            # move
            new[idx][0] = max(0.0, min(1.0, new[idx][0] + random.uniform(-0.05, 0.05)))
            new[idx][1] = max(0.0, min(1.0, new[idx][1] + random.uniform(-0.05, 0.05)))
        else:
            # swap sizes
            jdx = random.randrange(n)
            new[idx][2], new[jdx][2] = new[jdx][2], new[idx][2]
        new_e = energy(new)
        if new_e < cur_e or random.random() < math.exp(-(new_e-cur_e)/T):
            current = new
            cur_e = new_e
            if cur_e < best_e:
                best = [s[:] for s in current]
                best_e = cur_e
    
    # Final: clamp and return
    result = []
    for x,y,s in best:
        s = max(0.0, min(1.0, s))
        x = max(s/2, min(1-s/2, x))
        y = max(s/2, min(1-s/2, y))
        result.append((x, y, 0.0, s))
    return result
# EVOLVE-BLOCK-END
