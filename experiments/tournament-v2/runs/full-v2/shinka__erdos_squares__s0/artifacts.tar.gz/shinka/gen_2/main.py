# EVOLVE-BLOCK-START
"""Recursive guillotine partition packer for squares in a unit square."""
import math


def _split_rect(rect, target_leaves):
    """Recursively split a rectangle until it has target_leaves leaves.

    rect = (x, y, w, h). Returns a list of leaf rectangles.
    """
    if target_leaves <= 1:
        return [rect]

    x, y, w, h = rect

    # Choose a split that is balanced in leaf count and uses the longer axis.
    left_leaves = target_leaves // 2
    right_leaves = target_leaves - left_leaves

    if w >= h:
        # Vertical split
        frac = left_leaves / target_leaves
        left_w = w * frac
        right_w = w - left_w
        left = (x, y, left_w, h)
        right = (x + left_w, y, right_w, h)
    else:
        # Horizontal split
        frac = left_leaves / target_leaves
        bottom_h = h * frac
        top_h = h - bottom_h
        left = (x, y, w, bottom_h)
        right = (x, y + bottom_h, w, top_h)

    return _split_rect(left, left_leaves) + _split_rect(right, right_leaves)


def _rects_to_squares(rects):
    """Convert leaf rectangles into centered squares."""
    squares = []
    for x, y, w, h in rects:
        side = min(w, h)
        cx = x + w * 0.5
        cy = y + h * 0.5
        squares.append((cx, cy, 0.0, side))
    return squares


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    rects = _split_rect((0.0, 0.0, 1.0, 1.0), n)
    squares = _rects_to_squares(rects)

    # Guarantee exactly n outputs.
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
# EVOLVE-BLOCK-END
