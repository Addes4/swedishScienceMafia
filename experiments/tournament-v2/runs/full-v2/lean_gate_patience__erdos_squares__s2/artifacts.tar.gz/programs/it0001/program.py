# EVOLVE-BLOCK-START
"""Packing squares in a unit square by grid initialisation + numerical refinement."""
import math
import numpy as np
from scipy.optimize import minimize


def _pack_score(sides, cx, cy, ang, n):
    """Penalty for overlap and out-of-bounds. Lower is better; feasible -> 0."""
    pen = 0.0
    # boundary penalty (axis-aligned bounding approximation using actual extents)
    for i in range(n):
        s = sides[i]
        c = abs(math.cos(ang[i] * 2 * math.pi))
        sn = abs(math.sin(ang[i] * 2 * math.pi))
        half_w = 0.5 * s * (c + sn)
        half_h = half_w
        pen += max(0.0, half_w - cx[i]) ** 2
        pen += max(0.0, cx[i] + half_w - 1.0) ** 2
        pen += max(0.0, half_h - cy[i]) ** 2
        pen += max(0.0, cy[i] + half_h - 1.0) ** 2
    # overlap penalty using separating axes (AABB approximation is too loose;
    # use distance between centres vs sum of half-diagonals as soft proxy)
    for i in range(n):
        for j in range(i + 1, n):
            dx = cx[i] - cx[j]
            dy = cy[i] - cy[j]
            d = math.hypot(dx, dy)
            # approximate required separation for rotated squares:
            # for axis-aligned, require dx>= (si+sj)/2 OR dy >= (si+sj)/2
            si, sj = sides[i], sides[j]
            req = 0.5 * (si + sj)
            # generic soft overlap using AABB of rotated squares
            def ext(s, a):
                cc = abs(math.cos(a * 2 * math.pi))
                ss = abs(math.sin(a * 2 * math.pi))
                return 0.5 * s * (cc + ss)
            exi, eyi = ext(si, ang[i]), ext(si, ang[i])
            exj, eyj = ext(sj, ang[j]), ext(sj, ang[j])
            ox = (exi + exj) - abs(dx)
            oy = (eyi + eyj) - abs(dy)
            if ox > 0 and oy > 0:
                pen += (min(ox, oy)) ** 2
    return pen


def _local_opt(n, init):
    """Refine a packing starting from init (list of (cx,cy,ang,s))."""
    x0 = np.array(init, dtype=float).ravel()

    def obj(x):
        v = x.reshape(n, 4)
        cx, cy, ang, s = v[:, 0], v[:, 1], v[:, 2], v[:, 3]
        s = np.clip(s, 0.0, 1.0)
        p = _pack_score(s, cx, cy, ang, n)
        return p - 0.5 * float(np.sum(s))

    bounds = [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)] * n
    res = minimize(obj, x0, method="L-BFGS-B", bounds=bounds,
                   options={"maxiter": 200, "ftol": 1e-12})
    v = res.x.reshape(n, 4)
    return v


def _feasible_and_score(v):
    n = len(v)
    cx, cy, ang, s = v[:, 0], v[:, 1], v[:, 2], v[:, 3]
    p = _pack_score(s, cx, cy, ang, n)
    return p


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side)."""
    if n <= 0:
        return []
    # initial grid
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(k) for j in range(k)]
    base = base[:n]
    while len(base) < n:
        base.append((0.5, 0.5, 0.0, 0.0))

    best = None
    best_val = -1e18
    starts = [base]
    # a few random perturbations
    rng = np.random.default_rng(12345)
    for _ in range(3):
        arr = np.array(base, dtype=float)
        arr += rng.normal(0, 0.02, arr.shape)
        arr[:, 3] = np.clip(arr[:, 3], 0.0, 1.0)
        arr[:, :2] = np.clip(arr[:, :2], 0.0, 1.0)
        starts.append(arr.tolist())

    for st in starts:
        v = _local_opt(n, st)
        p = _feasible_and_score(v)
        val = p - np.sum(np.clip(v[:, 3], 0, 1)) * 0.0  # evaluate raw
        # compute total side if feasible else heavily penalized
        tot = float(np.sum(np.clip(v[:, 3], 0, 1)))
        quality = tot - 1000.0 * p
        if quality > best_val:
            best_val = quality
            best = v

    out = []
    for row in best:
        cx, cy, ang, s = row
        s = float(np.clip(s, 0.0, 1.0))
        cx = float(np.clip(cx, 0.0, 1.0))
        cy = float(np.clip(cy, 0.0, 1.0))
        ang = float(ang % 1.0)
        out.append((cx, cy, ang, s))
    return out
# EVOLVE-BLOCK-END
