# EVOLVE-BLOCK-START
"""Two-phase circle packing: randomized ring seeding + vectorized feasibility
projection + bottleneck-driven radius growth, wrapped in a multi-restart loop."""
import numpy as np


def _seed_layout(n, rng):
    """Structured ring seed with random jitter; extra points fill the interior."""
    centers = [[0.5, 0.5]]
    # Inner ring
    k1 = min(8, max(0, n - 1))
    for i in range(k1):
        ang = 2 * np.pi * i / k1 + rng.uniform(-0.15, 0.15)
        rad = 0.28 + rng.uniform(-0.04, 0.04)
        centers.append([0.5 + rad * np.cos(ang), 0.5 + rad * np.sin(ang)])
    # Outer ring
    k2 = max(0, n - len(centers))
    for i in range(k2):
        ang = 2 * np.pi * i / max(k2, 1) + rng.uniform(-0.1, 0.1)
        rad = 0.68 + rng.uniform(-0.06, 0.06)
        centers.append([0.5 + rad * np.cos(ang), 0.5 + rad * np.sin(ang)])
    c = np.array(centers[:n], dtype=float)
    c += rng.uniform(-0.01, 0.01, size=c.shape)
    return np.clip(c, 0.02, 0.98)


def _wall_limits(c):
    """Per-circle maximum radius allowed by the four walls."""
    return np.minimum.reduce([c[:, 0], c[:, 1], 1.0 - c[:, 0], 1.0 - c[:, 1]])


def _project(c, r, sweeps=60):
    """Vectorized feasibility projection: shrink overlapping pairs / wall violations."""
    n = len(c)
    r = np.maximum(r, 0.0)
    # Wall clamp
    r = np.minimum(r, _wall_limits(c))
    for _ in range(sweeps):
        diff = c[:, None, :] - c[None, :, :]
        dist = np.sqrt(np.sum(diff * diff, axis=-1))
        np.fill_diagonal(dist, np.inf)
        rsum = r[:, None] + r[None, :]
        viol = rsum - dist
        # Any positive violation -> shrink both circles proportionally
        if not np.any(viol > 1e-12):
            break
        # Shrink factor per pair, then take the min over partners for each circle
        with np.errstate(divide="ignore", invalid="ignore"):
            factor = np.where(viol > 0, dist / np.maximum(rsum, 1e-12), 1.0)
        np.fill_diagonal(factor, 1.0)
        shrink = np.min(factor, axis=1)
        r = r * shrink
        r = np.minimum(r, _wall_limits(c))
    return np.maximum(r, 0.0)


def _grow(c, r, rounds=8):
    """Try to enlarge each circle toward its current bottleneck (wall or neighbour)."""
    n = len(c)
    r = r.copy()
    for _ in range(rounds):
        improved = False
        # Distance matrix
        diff = c[:, None, :] - c[None, :, :]
        dist = np.sqrt(np.sum(diff * diff, axis=-1))
        np.fill_diagonal(dist, np.inf)
        # Pairwise limit: r_i <= dist_ij - r_j
        pair_lim = dist - r[None, :]
        pair_lim = np.min(pair_lim, axis=1)
        wall_lim = _wall_limits(c)
        target = np.minimum(pair_lim, wall_lim)
        target = np.maximum(target, 0.0)
        # Only accept increases that keep feasibility
        new_r = np.where(target > r + 1e-9, target, r)
        if np.any(new_r > r + 1e-9):
            improved = True
            r = new_r
        if not improved:
            break
    return r


def solve(n=26):
    """Multi-restart two-phase packing; returns (centers, radii)."""
    rng = np.random.default_rng(20240607)
    best_sum = -1.0
    best_c = None
    best_r = None

    n_restarts = 24
    for k in range(n_restarts):
        c = _seed_layout(n, rng)
        # Start from a small uniform radius, project, then grow
        r = np.full(n, 0.01)
        r = _project(c, r, sweeps=80)
        r = _grow(c, r, rounds=10)
        r = _project(c, r, sweeps=40)
        r = _grow(c, r, rounds=6)

        s = float(np.sum(r))
        if s > best_sum:
            best_sum = s
            best_c = c.copy()
            best_r = r.copy()

    # Final polish on the best configuration
    best_r = _project(best_c, best_r, sweeps=100)
    best_r = _grow(best_c, best_r, rounds=15)
    best_r = _project(best_c, best_r, sweeps=60)
    return best_c, best_r
# EVOLVE-BLOCK-END
