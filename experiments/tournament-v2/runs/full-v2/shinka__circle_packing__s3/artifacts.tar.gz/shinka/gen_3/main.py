# EVOLVE-BLOCK-START
"""Annealed spiral packing: phyllotaxis init + exact LP radii + pattern-search centres."""
import numpy as np


def _lp_radii(centers):
    """Exact-ish max sum r_i for fixed centres via iterative constraint projection.

    Constraints:
      r_i <= wall_i           (box)
      r_i + r_j <= d_ij       (pairwise)
    Maximise sum r_i.  We use a dual-free iterative scheme: start from wall
    upper bounds and repeatedly project the radius vector onto the violated
    pairwise constraints, but always keep the wall bound.  This converges to
    the LP optimum for this monotone structure (each projection reduces the
    sum by the minimal amount needed to satisfy one constraint).
    """
    n = len(centers)
    wall = np.minimum.reduce([
        centers[:, 0], centers[:, 1],
        1.0 - centers[:, 0], 1.0 - centers[:, 1],
    ])
    radii = wall.copy()

    # Precompute pairwise distances
    diff = centers[:, None, :] - centers[None, :, :]
    dist = np.sqrt((diff ** 2).sum(axis=2))

    # Iterate projections: for each violated pair, scale both down equally so
    # that r_i + r_j = d_ij (equal reduction keeps sum loss symmetric).
    for _ in range(200):
        viol = radii[:, None] + radii[None, :] - dist
        np.fill_diagonal(viol, -1.0)
        worst = viol.max()
        if worst <= 1e-12:
            break
        # Update all violated pairs simultaneously (Jacobi style) with damping
        mask = viol > 0
        # amount each pair must lose together
        loss = np.where(mask, viol * 0.5, 0.0)
        # Each radius loses the max required over its incident pairs, but
        # capped so it never goes negative.
        dec = loss.max(axis=1)
        radii = np.maximum(radii - dec, 0.0)
        # Re-enforce walls
        radii = np.minimum(radii, wall)
    return np.maximum(radii, 0.0)


def _objective(centers):
    """Sum of LP radii (the true objective for fixed centres)."""
    return _lp_radii(centers).sum()


def _phyllotaxis(n, rng, jitter=0.0):
    """Vogel spiral seeding inside the unit square, then rescale to fit."""
    idx = np.arange(1, n + 1)
    golden = np.pi * (3.0 - np.sqrt(5.0))
    r = np.sqrt(idx / n) * 0.5
    theta = idx * golden
    x = 0.5 + r * np.cos(theta)
    y = 0.5 + r * np.sin(theta)
    pts = np.stack([x, y], axis=1)
    if jitter > 0:
        pts += rng.normal(0.0, jitter, pts.shape)
    pts = np.clip(pts, 1e-4, 1 - 1e-4)
    return pts


def _pattern_search(centers, iters=400, rng=None):
    """Coordinate-wise pattern search on the sum-of-radii objective."""
    if rng is None:
        rng = np.random.default_rng(0)
    n = len(centers)
    centers = centers.copy()
    best = _objective(centers)
    step = 0.05
    for it in range(iters):
        improved = False
        order = rng.permutation(n)
        for i in order:
            for dim in (0, 1):
                for sgn in (1.0, -1.0):
                    trial = centers.copy()
                    trial[i, dim] = np.clip(
                        trial[i, dim] + sgn * step, 1e-4, 1 - 1e-4
                    )
                    val = _objective(trial)
                    if val > best + 1e-12:
                        best = val
                        centers = trial
                        improved = True
                        break
                if improved:
                    break
        if not improved:
            step *= 0.5
            if step < 1e-4:
                break
    return centers, best


def solve(n=26, time_budget=280.0):
    """Return (centers, radii) maximising sum of radii in the unit square."""
    import time
    t0 = time.time()
    rng = np.random.default_rng(12345)

    best_centers = None
    best_val = -np.inf

    # Multi-start: vary jitter and golden-angle offset for diversity.
    restarts = 0
    while time.time() - t0 < time_budget and restarts < 60:
        jitter = 0.0 if restarts == 0 else float(rng.uniform(0.005, 0.05))
        c0 = _phyllotaxis(n, rng, jitter=jitter)
        c, v = _pattern_search(c0, iters=500, rng=rng)
        # A quick second polish with smaller initial step
        c2, v2 = _pattern_search(c, iters=200, rng=rng)
        if v2 > v:
            c, v = c2, v2
        if v > best_val:
            best_val = v
            best_centers = c.copy()
        restarts += 1
        # Early exit if we are near the known optimum scale
        if best_val > 2.63:
            break

    radii = _lp_radii(best_centers)
    return best_centers, radii
# EVOLVE-BLOCK-END
