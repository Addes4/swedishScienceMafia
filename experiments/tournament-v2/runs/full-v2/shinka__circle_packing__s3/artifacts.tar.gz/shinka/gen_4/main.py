# EVOLVE-BLOCK-START
"""Adaptive multi-start gradient packing with greedy radius expansion."""
import numpy as np


def _initial_layout(n, rng):
    """Centre circle + rings + random fill, randomised for restarts."""
    centers = [[0.5, 0.5]]
    for i in range(8):
        centers.append([0.5 + 0.3 * np.cos(2 * np.pi * i / 8),
                        0.5 + 0.3 * np.sin(2 * np.pi * i / 8)])
    for i in range(16):
        centers.append([0.5 + 0.7 * np.cos(2 * np.pi * i / 16),
                        0.5 + 0.7 * np.sin(2 * np.pi * i / 16)])
    while len(centers) < n:
        centers.append([0.1 + 0.8 * rng.random(), 0.1 + 0.8 * rng.random()])
    c = np.clip(np.array(centers[:n]), 0.02, 0.98)
    r = np.full(n, 0.02)
    return c, r


def _optimize(c0, r0, n, iters=4500, lr0=0.05, lr1=0.01, lam=120.0, rng=None):
    """Adam ascent on (x, y, log-r) with penalty for overlaps and walls."""
    if rng is None:
        rng = np.random.default_rng(0)
    theta = np.zeros((n, 3))
    theta[:, :2] = c0
    theta[:, 2] = np.log(np.maximum(r0, 1e-4))

    m = np.zeros_like(theta)
    v = np.zeros_like(theta)
    b1, b2, eps = 0.9, 0.999, 1e-8

    for t in range(1, iters + 1):
        # Decaying learning rate schedule
        frac = (t - 1) / max(1, iters - 1)
        lr = lr0 * (1.0 - frac) + lr1 * frac

        xy = theta[:, :2]
        r = np.exp(theta[:, 2])

        grad = np.zeros_like(theta)
        grad[:, 2] = r  # d(sum r)/d(log r) = r

        # Wall penalties: r <= x, r <= 1-x, r <= y, r <= 1-y
        walls = [
            (r - xy[:, 0], xy[:, 0], -1.0),
            (r - (1.0 - xy[:, 0]), 1.0 - xy[:, 0], 1.0),
            (r - xy[:, 1], xy[:, 1], -1.0),
            (r - (1.0 - xy[:, 1]), 1.0 - xy[:, 1], 1.0),
        ]
        for viol, w, dwdx in walls:
            mask = viol > 0
            if not np.any(mask):
                continue
            g_r = lam * 2.0 * viol * r
            g_x = -lam * 2.0 * viol * dwdx
            grad[:, 2] -= np.where(mask, g_r, 0.0)
            grad[:, 0] -= np.where(mask, g_x, 0.0)

        # Pairwise overlaps
        diff = xy[:, None, :] - xy[None, :, :]
        dist = np.sqrt(np.sum(diff * diff, axis=-1) + 1e-12)
        rsum = r[:, None] + r[None, :]
        overlap = rsum - dist
        np.fill_diagonal(overlap, 0.0)
        pos = np.maximum(overlap, 0.0)
        g_r_pair = lam * 2.0 * pos * r[:, None]
        grad[:, 2] -= np.sum(g_r_pair, axis=1)
        inv_dist = 1.0 / dist
        coef = lam * 2.0 * pos * inv_dist
        gx = np.sum(coef[:, :, None] * diff, axis=1)
        grad[:, :2] -= gx

        # Adam update (ascent)
        m = b1 * m + (1 - b1) * grad
        v = b2 * v + (1 - b2) * grad * grad
        mhat = m / (1 - b1 ** t)
        vhat = v / (1 - b2 ** t)
        theta += lr * mhat / (np.sqrt(vhat) + eps)

        # Keep parameters sane
        theta[:, 0] = np.clip(theta[:, 0], 1e-4, 1 - 1e-4)
        theta[:, 1] = np.clip(theta[:, 1], 1e-4, 1 - 1e-4)
        theta[:, 2] = np.clip(theta[:, 2], np.log(1e-5), np.log(0.5))

    xy = theta[:, :2]
    r = np.exp(theta[:, 2])
    return xy, r


def max_radii(centers, sweeps=500):
    """Largest radii for fixed centres via iterative pairwise shrink."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    radii = np.maximum(radii, 0.0)
    for _ in range(sweeps):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                s = radii[i] + radii[j]
                if s > d and s > 0:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _greedy_expand(centers, radii, rounds=6):
    """Try to increase individual radii while keeping feasibility."""
    n = len(centers)
    radii = radii.copy()
    for _ in range(rounds):
        improved = False
        # Process circles from largest to smallest for better gains
        order = np.argsort(-radii)
        for i in order:
            # Current wall and pairwise limits
            wall_lim = min(centers[i, 0], centers[i, 1],
                           1 - centers[i, 0], 1 - centers[i, 1])
            pair_lim = np.inf
            for j in range(n):
                if j == i:
                    continue
                d = np.linalg.norm(centers[i] - centers[j])
                lim = d - radii[j]
                if lim < pair_lim:
                    pair_lim = lim
            new_r = min(wall_lim, pair_lim)
            if new_r > radii[i] + 1e-12:
                radii[i] = max(0.0, new_r)
                improved = True
        if not improved:
            break
    return radii


def solve(n=26):
    """Run adaptive gradient ascent from several restarts, keep best feasible packing."""
    rng = np.random.default_rng(20240607)
    best_sum = -1.0
    best_c = None
    best_r = None

    n_restarts = 8
    for k in range(n_restarts):
        c0, r0 = _initial_layout(n, rng)
        # Vary lr0 and lam slightly per restart
        lr0 = 0.05 * (1.0 + 0.25 * (k % 4))
        lam = 100.0 + 20.0 * (k % 3)
        xy, r = _optimize(c0, r0, n, iters=4500, lr0=lr0, lr1=0.01,
                          lam=lam, rng=rng)
        r_feas = max_radii(xy)
        r_feas = _greedy_expand(xy, r_feas)
        s = float(np.sum(r_feas))
        if s > best_sum:
            best_sum = s
            best_c = xy.copy()
            best_r = r_feas.copy()

    # Final feasibility polish and expansion
    best_r = max_radii(best_c)
    best_r = _greedy_expand(best_c, best_r)
    best_r = max_radii(best_c)
    return best_c, best_r
# EVOLVE-BLOCK-END
