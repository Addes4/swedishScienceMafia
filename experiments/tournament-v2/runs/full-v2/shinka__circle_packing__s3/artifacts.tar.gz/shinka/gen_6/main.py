# EVOLVE-BLOCK-START
"""Circle packing via billiard-style repulsion relaxation + LP polishing.

Novel approach:
  * Fast approximate radii for inner-loop evaluation (greedy shrink).
  * Physics-inspired repulsion relaxation that pushes centers apart while
    letting the boundary walls pull them into corner regions where larger
    circles fit.
  * Basin-hopping multi-start with diverse geometric seeds.
  * Exact LP radii + coordinate polish on the best configuration.
"""
import numpy as np
from scipy.optimize import linprog


# ----------------------------------------------------------------------
# Radii evaluators
# ----------------------------------------------------------------------
def fast_radii(centers):
    """Fast approximate radii: wall bound then iterative pairwise shrink."""
    centers = np.asarray(centers, dtype=float)
    n = len(centers)
    walls = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    radii = np.maximum(walls, 1e-9).copy()
    # iterative shrink (Gauss-Seidel style, a few sweeps)
    for _ in range(30):
        changed = False
        for i in range(n):
            ri = radii[i]
            for j in range(i + 1, n):
                dx = centers[i, 0] - centers[j, 0]
                dy = centers[i, 1] - centers[j, 1]
                d = np.sqrt(dx * dx + dy * dy)
                s = radii[i] + radii[j]
                if s > d and s > 1e-12:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def lp_radii(centers):
    """Exact LP-optimal radii for fixed centers."""
    centers = np.asarray(centers, dtype=float)
    n = len(centers)
    c = -np.ones(n)
    walls = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    bounds = [(0.0, float(w)) for w in walls]
    rows = []
    rhs = []
    for i in range(n):
        xi, yi = centers[i]
        for j in range(i + 1, n):
            dx = xi - centers[j, 0]
            dy = yi - centers[j, 1]
            d = float(np.sqrt(dx * dx + dy * dy))
            row = np.zeros(n)
            row[i] = 1.0
            row[j] = 1.0
            rows.append(row)
            rhs.append(d)
    A_ub = np.array(rows) if rows else None
    b_ub = np.array(rhs) if rhs else None
    try:
        res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
        if res.success:
            return np.maximum(res.x, 0.0)
    except Exception:
        pass
    return fast_radii(centers)


# ----------------------------------------------------------------------
# Seeds
# ----------------------------------------------------------------------
def seed_hexagonal(n, rng):
    """Hexagonal-ish lattice seed."""
    pts = []
    cols = int(np.ceil(np.sqrt(n)))
    rows = int(np.ceil(n / cols))
    for i in range(rows):
        for j in range(cols):
            if len(pts) >= n:
                break
            x = (j + 0.5 + 0.5 * (i % 2)) / cols
            y = (i + 0.5) / rows
            pts.append([x, y])
    pts = np.array(pts[:n])
    pts += rng.normal(0, 0.01, pts.shape)
    return np.clip(pts, 0.02, 0.98)


def seed_rings(n, rng):
    """Concentric rings seed (like baseline but denser)."""
    pts = [[0.5, 0.5]]
    ring_sizes = []
    remaining = n - 1
    k = 1
    while remaining > 0:
        s = min(6 * k, remaining)
        ring_sizes.append(s)
        remaining -= s
        k += 1
    for k_idx, s in enumerate(ring_sizes):
        radius = 0.15 + 0.28 * k_idx
        radius = min(radius, 0.46)
        for i in range(s):
            ang = 2 * np.pi * i / s + (0.3 if k_idx % 2 else 0.0)
            pts.append([0.5 + radius * np.cos(ang),
                        0.5 + radius * np.sin(ang)])
    pts = np.array(pts[:n])
    pts += rng.normal(0, 0.008, pts.shape)
    return np.clip(pts, 0.02, 0.98)


def seed_random(n, rng):
    return np.clip(rng.random((n, 2)) * 0.96 + 0.02, 0.02, 0.98)


# ----------------------------------------------------------------------
# Billiard-style relaxation
# ----------------------------------------------------------------------
def relax(centers, iters=200, dt=0.6, rng=None):
    """Push centers apart using repulsive forces over overlaps.

    For each overlapping pair, move both centers along the line joining
    them by an amount proportional to the overlap. Walls are handled
    implicitly by the radii evaluator; here we only resolve overlaps.
    """
    centers = centers.copy()
    n = len(centers)
    for it in range(iters):
        radii = fast_radii(centers)
        forces = np.zeros_like(centers)
        moved = False
        for i in range(n):
            xi, yi = centers[i]
            for j in range(i + 1, n):
                dx = xi - centers[j, 0]
                dy = yi - centers[j, 1]
                d2 = dx * dx + dy * dy
                d = np.sqrt(d2) + 1e-12
                overlap = radii[i] + radii[j] - d
                if overlap > 1e-6:
                    fx = overlap * dx / d
                    fy = overlap * dy / d
                    forces[i, 0] += fx
                    forces[i, 1] += fy
                    forces[j, 0] -= fx
                    forces[j, 1] -= fy
                    moved = True
        if not moved:
            break
        # damped update
        centers += dt * forces
        centers = np.clip(centers, 0.001, 0.999)
    return centers


# ----------------------------------------------------------------------
# Coordinate polish with LP oracle
# ----------------------------------------------------------------------
def polish(centers, rng, rounds=3, iters=1500, T0=0.004):
    centers = centers.copy()
    radii = lp_radii(centers)
    score = radii.sum()
    for r in range(rounds):
        T = T0
        step0 = 0.02
        for it in range(iters):
            frac = it / iters
            T = T0 * (1 - frac) + 1e-6
            step = step0 * (1 - 0.7 * frac)
            k = rng.integers(0, len(centers))
            old = centers[k].copy()
            centers[k] += rng.normal(0, step, size=2)
            centers[k] = np.clip(centers[k], 0.002, 0.998)
            new_radii = lp_radii(centers)
            new_score = new_radii.sum()
            delta = new_score - score
            if delta > 0 or rng.random() < np.exp(delta / max(T, 1e-9)):
                score = new_score
                radii = new_radii
            else:
                centers[k] = old
        # shrink temperature
        T0 *= 0.5
    return centers, lp_radii(centers)


# ----------------------------------------------------------------------
# Main solver
# ----------------------------------------------------------------------
def solve(n=26):
    rng = np.random.default_rng(12345)
    best_centers = None
    best_radii = None
    best_score = -1.0

    seed_fns = [seed_hexagonal, seed_rings, seed_random]

    # --- multi-start with billiard relaxation ---
    n_starts = 12
    for s in range(n_starts):
        fn = seed_fns[s % len(seed_fns)]
        centers = fn(n, rng)
        centers = relax(centers, iters=250, dt=0.5, rng=rng)
        # a couple of light random kicks + relax
        for _ in range(3):
            kick = rng.normal(0, 0.01, centers.shape)
            centers = np.clip(centers + kick, 0.005, 0.995)
            centers = relax(centers, iters=120, dt=0.4, rng=rng)
        radii = fast_radii(centers)
        score = radii.sum()
        if score > best_score:
            best_score = score
            best_centers = centers.copy()
            best_radii = radii.copy()

    # --- choose top-k starts for LP polish ---
    # re-evaluate top candidates with LP and polish each briefly
    candidates = []
    for s in range(6):
        fn = seed_fns[s % len(seed_fns)]
        centers = fn(n, rng)
        centers = relax(centers, iters=250, dt=0.5, rng=rng)
        candidates.append(centers)

    polished = []
    for c in candidates:
        pc, pr = polish(c, rng, rounds=2, iters=800, T0=0.006)
        polished.append((pr.sum(), pc, pr))

    # also polish the best relaxed centers
    pc, pr = polish(best_centers, rng, rounds=3, iters=1500, T0=0.005)
    polished.append((pr.sum(), pc, pr))

    polished.sort(key=lambda t: -t[0])
    best_score, best_centers, best_radii = polished[0]

    # --- final aggressive polish on the winner ---
    for _ in range(2):
        pc, pr = polish(best_centers, rng, rounds=4, iters=2000, T0=0.003)
        if pr.sum() > best_score:
            best_score = pr.sum()
            best_centers = pc
            best_radii = pr

    # safety: re-evaluate with LP at the very end
    final_radii = lp_radii(best_centers)
    if final_radii.sum() >= best_radii.sum():
        best_radii = final_radii

    return np.asarray(best_centers), np.asarray(best_radii)
# EVOLVE-BLOCK-END