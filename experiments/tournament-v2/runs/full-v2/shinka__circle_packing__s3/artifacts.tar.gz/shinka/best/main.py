# EVOLVE-BLOCK-START
"""Circle packing via LP-optimal radii plus center optimization."""
import numpy as np
from scipy.optimize import linprog


def max_radii(centers):
    """Optimal radii for fixed centres via LP: maximize sum(r) s.t.
    r_i <= wall_i and r_i + r_j <= d_ij."""
    centers = np.asarray(centers, dtype=float)
    n = len(centers)
    # objective: maximize sum r -> minimize -sum r
    c = -np.ones(n)
    # bounds: 0 <= r_i <= wall_i
    walls = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    bounds = [(0.0, float(w)) for w in walls]
    # pairwise constraints: r_i + r_j <= d_ij
    rows = []
    rhs = []
    for i in range(n):
        for j in range(i + 1, n):
            d = float(np.hypot(centers[i, 0] - centers[j, 0],
                               centers[i, 1] - centers[j, 1]))
            row = np.zeros(n)
            row[i] = 1.0
            row[j] = 1.0
            rows.append(row)
            rhs.append(d)
    A_ub = np.array(rows) if rows else None
    b_ub = np.array(rhs) if rhs else None
    res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if res.success:
        return np.maximum(res.x, 0.0)
    # fallback: greedy shrink
    radii = walls.copy()
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.hypot(centers[i, 0] - centers[j, 0],
                             centers[i, 1] - centers[j, 1])
                if radii[i] + radii[j] > d and radii[i] + radii[j] > 0:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _initial_centers(n):
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8),
                 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16),
                 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    while len(centers) < n:
        centers.append([0.1 + 0.8 * np.random.rand(),
                        0.1 + 0.8 * np.random.rand()])
    return np.clip(np.array(centers[:n]), 0.01, 0.99)


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii. Uses LP-optimal radii and a
    simulated-annealing search over center positions."""
    rng = np.random.default_rng(0)
    best_centers = _initial_centers(n)
    best_radii = max_radii(best_centers)
    best_score = best_radii.sum()

    # A few restarts with different random seeds
    for restart in range(3):
        centers = _initial_centers(n)
        radii = max_radii(centers)
        score = radii.sum()

        T0 = 0.02
        iters = 4000
        step0 = 0.05
        for it in range(iters):
            T = T0 * (1.0 - it / iters) + 1e-5
            step = step0 * (1.0 - 0.8 * it / iters)
            k = rng.integers(0, n)
            old = centers[k].copy()
            centers[k] += rng.normal(0, step, size=2)
            centers[k] = np.clip(centers[k], 0.005, 0.995)
            new_radii = max_radii(centers)
            new_score = new_radii.sum()
            delta = new_score - score
            if delta > 0 or rng.random() < np.exp(delta / max(T, 1e-9)):
                score = new_score
                radii = new_radii
                if score > best_score:
                    best_score = score
                    best_centers = centers.copy()
                    best_radii = radii.copy()
            else:
                centers[k] = old

    return best_centers, best_radii
# EVOLVE-BLOCK-END