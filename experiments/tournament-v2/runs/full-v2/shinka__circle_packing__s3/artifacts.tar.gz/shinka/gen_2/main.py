# EVOLVE-BLOCK-START
"""Gradient-based circle packing: maximise sum(r) - penalty(overlap, wall)."""
import numpy as np


def _initial_layout(n, rng):
    """Centre circle + rings + random fill, like the baseline but randomised."""
    centers = [[0.5, 0.5]]
    for i in range(8):
        centers.append([0.5 + 0.3 * np.cos(2 * np.pi * i / 8),
                        0.5 + 0.3 * np.sin(2 * np.pi * i / 8)])
    for i in range(16):
        centers.append([0.5 + 0.7 * np.cos(2 * np.pi * i / 16),
                        0.5 + 0.7 * np.sin(2 * np.pi * i / 16)])
    while len(centers) < n:
        centers.append([0.1 + 0.8 * rng.random(), 0.1 + 0.8 * rng.random()])
    c = np.clip(np.array(centers[:n]), 0.02, 0.98)
    r = np.full(n, 0.02)
    return c, r


def _optimize(c0, r0, n, iters=4000, lr=0.02, lam=50.0, rng=None):
    """Adam ascent on (x, y, log-r) with penalty for overlaps and walls."""
    if rng is None:
        rng = np.random.default_rng(0)
    # Parameterise radii as unconstrained logs
    theta = np.zeros((n, 3))
    theta[:, :2] = c0
    theta[:, 2] = np.log(np.maximum(r0, 1e-4))

    m = np.zeros_like(theta)
    v = np.zeros_like(theta)
    b1, b2, eps = 0.9, 0.999, 1e-8

    for t in range(1, iters + 1):
        xy = theta[:, :2]
        r = np.exp(theta[:, 2])

        # Gradient of sum(r) wrt log-r is r
        grad = np.zeros_like(theta)
        grad[:, 2] = r

        # Wall penalties: r <= x, r <= 1-x, r <= y, r <= 1-y
        for axis in range(2):
            for sign in (-1.0, 1.0):
                # violation when r - (sign*x) > 0 for sign=-1: x-r<0 -> r>x
                # use w = sign*xy[:,axis] ; require r <= w
                w = sign * xy[:, axis] if sign == 1.0 else -xy[:, axis]
                # For sign=1: w = x (needs r<=x). For sign=-1: w = -x (needs r<=-x), invalid.
                # Simpler: handle four walls explicitly below.
                pass

        # Explicit wall handling
        # left: r - x <= 0 ; right: r - (1-x) <= 0 ; bottom: r - y <= 0 ; top: r - (1-y) <= 0
        walls = [
            (r - xy[:, 0], xy[:, 0], -1.0),          # r <= x  -> w = x
            (r - (1.0 - xy[:, 0]), 1.0 - xy[:, 0], 1.0),  # r <= 1-x
            (r - xy[:, 1], xy[:, 1], -1.0),          # r <= y
            (r - (1.0 - xy[:, 1]), 1.0 - xy[:, 1], 1.0),  # r <= 1-y
        ]
        for viol, w, dwdx in walls:
            mask = viol > 0
            if not np.any(mask):
                continue
            # penalty = lam * viol^2 ; d/dlogr = lam*2*viol*r ; d/dx = -lam*2*viol*dwdx
            g_r = lam * 2.0 * viol * r
            g_x = -lam * 2.0 * viol * dwdx
            grad[:, 2] -= np.where(mask, g_r, 0.0)
            grad[:, 0] -= np.where(mask, g_x, 0.0)

        # Pairwise overlaps
        diff = xy[:, None, :] - xy[None, :, :]
        dist = np.sqrt(np.sum(diff * diff, axis=-1) + 1e-12)
        rsum = r[:, None] + r[None, :]
        overlap = rsum - dist
        np.fill_diagonal(overlap, 0.0)
        pos = np.maximum(overlap, 0.0)
        # penalty = lam * pos^2
        # d/dlogr_i = lam*2*pos*r_i (sum over j)
        g_r_pair = lam * 2.0 * pos * r[:, None]
        grad[:, 2] -= np.sum(g_r_pair, axis=1)
        # d/dx_i = lam*2*pos * (dx_i/dist) ; dx_i = (x_i - x_j)
        inv_dist = 1.0 / dist
        coef = lam * 2.0 * pos * inv_dist
        gx = np.sum(coef[:, :, None] * diff, axis=1)
        grad[:, :2] -= gx

        # Adam update (ascent)
        m = b1 * m + (1 - b1) * grad
        v = b2 * v + (1 - b2) * grad * grad
        mhat = m / (1 - b1 ** t)
        vhat = v / (1 - b2 ** t)
        theta += lr * mhat / (np.sqrt(vhat) + eps)

        # Keep centers in a sane range
        theta[:, 0] = np.clip(theta[:, 0], 1e-4, 1 - 1e-4)
        theta[:, 1] = np.clip(theta[:, 1], 1e-4, 1 - 1e-4)
        theta[:, 2] = np.clip(theta[:, 2], np.log(1e-5), np.log(0.5))

    xy = theta[:, :2]
    r = np.exp(theta[:, 2])
    return xy, r


def max_radii(centers):
    """Largest radii for fixed centres: shrink overlapping pairs until feasible."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    radii = np.maximum(radii, 0.0)
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d and (radii[i] + radii[j]) > 0:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def solve(n=26):
    """Run gradient ascent from several random restarts, keep the best feasible packing."""
    rng = np.random.default_rng(12345)
    best_sum = -1.0
    best_c = None
    best_r = None

    n_restarts = 6
    for k in range(n_restarts):
        c0, r0 = _initial_layout(n, rng)
        # Slightly different learning rates per restart for robustness
        lr = 0.02 * (1.0 + 0.2 * (k % 3))
        xy, r = _optimize(c0, r0, n, iters=3500, lr=lr, lam=60.0, rng=rng)
        # Snap to feasible radii given the final centres
        r_feas = max_radii(xy)
        s = float(np.sum(r_feas))
        if s > best_sum:
            best_sum = s
            best_c = xy.copy()
            best_r = r_feas.copy()

    # Final polish: no-op but guarantees feasibility
    best_r = max_radii(best_c)
    return best_c, best_r
# EVOLVE-BLOCK-END