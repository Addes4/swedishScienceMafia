# EVOLVE-BLOCK-START
"""Voronoi-based radius allocation for circle packing.

Idea:
  1. Start with a quasi-uniform set of centres (hex-like jittered lattice).
  2. For fixed centres, assign each circle a radius equal to the minimum over:
       - distance to the four walls,
       - half the distance to each neighbour (Voronoi-style partition of space),
     which is a good surrogate for the largest non-overlapping radius.
  3. Move each centre towards the centroid of its own Voronoi cell (clipped to the
     unit square) to enlarge the local free area, keeping the assignment feasible.
  4. Iterate while the total sum of radii improves.

The final answer is the best feasible configuration found.
"""

import numpy as np


# ---------------------------------------------------------------------------
# geometry helpers
# ---------------------------------------------------------------------------

def _wall_distance(pts):
    """Minimum distance from each point to the boundary of [0,1]^2."""
    return np.minimum.reduce([pts[:, 0], pts[:, 1], 1.0 - pts[:, 0], 1.0 - pts[:, 1]])


def _radii_from_centres(centres):
    """Voronoi-style radii: min(wall distance, half distance to nearest neighbour).

    This guarantees pairwise non-overlap and containment in the unit square.
    """
    n = centres.shape[0]
    radii = _wall_distance(centres).copy()
    if n < 2:
        return np.maximum(radii, 0.0)
    diff = centres[:, None, :] - centres[None, :, :]      # (n, n, 2)
    dist = np.sqrt(np.sum(diff * diff, axis=2))            # (n, n)
    np.fill_diagonal(dist, np.inf)
    half_nearest = 0.5 * np.min(dist, axis=1)
    radii = np.minimum(radii, half_nearest)
    return np.maximum(radii, 0.0)


# ---------------------------------------------------------------------------
# Voronoi cell approximation by dense sampling
# ---------------------------------------------------------------------------

def _voronoi_centroids(centres, grid_res=90):
    """Approximate the centroid of each Voronoi cell (restricted to the square).

    A uniform grid of points is assigned to its nearest centre; each centre's
    centroid is the mean of the grid points assigned to it.  Empty cells fall
    back to the current centre.
    """
    n = centres.shape[0]
    xs = (np.arange(grid_res) + 0.5) / grid_res
    gx, gy = np.meshgrid(xs, xs)
    grid = np.stack([gx.ravel(), gy.ravel()], axis=1)        # (m, 2), m = res^2

    # nearest centre for each grid point
    d2 = ((grid[:, None, :] - centres[None, :, :]) ** 2).sum(axis=2)  # (m, n)
    owner = np.argmin(d2, axis=1)

    centroids = centres.copy()
    for i in range(n):
        mask = owner == i
        if np.any(mask):
            centroids[i] = grid[mask].mean(axis=0)
    return centroids


# ---------------------------------------------------------------------------
# initial layout: jittered hex packing to fill the square
# ---------------------------------------------------------------------------

def _initial_centres(n, rng):
    """Hexagonal-ish lattice of n points covering the unit square with jitter."""
    best = None
    best_min_dist = -1.0
    for _ in range(200):
        # choose grid shape roughly matching aspect ratio 1
        rows = int(np.ceil(np.sqrt(n)))
        cols = int(np.ceil(n / rows))
        pts = []
        for r in range(rows):
            for c in range(cols):
                if len(pts) >= n:
                    break
                x = (c + 0.5 + 0.5 * (r % 2)) / cols
                y = (r + 0.5) / rows
                pts.append([x, y])
        pts = np.array(pts[:n], dtype=float)
        # jitter
        pts += rng.uniform(-0.5, 0.5, size=pts.shape) / max(rows, cols)
        pts = np.clip(pts, 1e-4, 1 - 1e-4)

        # score by minimum neighbour distance (larger is better)
        d = np.sqrt(((pts[:, None, :] - pts[None, :, :]) ** 2).sum(axis=2))
        np.fill_diagonal(d, np.inf)
        md = d.min()
        if md > best_min_dist:
            best_min_dist = md
            best = pts
    return best


# ---------------------------------------------------------------------------
# local refinement (fixed neighbourhood, coordinate moves)
# ---------------------------------------------------------------------------

def _refine(centres, iters=300, step0=0.03):
    """Small random jitter moves accepted if the Voronoi radius sum improves."""
    centres = centres.copy()
    radii = _radii_from_centres(centres)
    score = radii.sum()
    rng = np.random.default_rng(12345)
    for it in range(iters):
        step = step0 * (1.0 - it / iters) + 1e-4
        i = rng.integers(len(centres))
        new = centres.copy()
        new[i] += rng.normal(0.0, step, size=2)
        new[i] = np.clip(new[i], 1e-4, 1 - 1e-4)
        r = _radii_from_centres(new)
        s = r.sum()
        if s > score:
            centres, radii, score = new, r, s
    return centres, radii, score


# ---------------------------------------------------------------------------
# main solver
# ---------------------------------------------------------------------------

def solve(n=26):
    rng = np.random.default_rng(20240517)

    works = [_initial_centres(n, rng) for _ in range(8)]
    best = None
    best_score = -np.inf

    grid_schedule = [80, 100, 120]

    for w in works:
        centres = w.copy()
        radii = _radii_from_centres(centres)
        score = radii.sum()

        for res in grid_schedule:
            for _ in range(40):
                centroids = _voronoi_centroids(centres, grid_res=res)
                # blend current centres towards Voronoi centroids (relaxation)
                new_centres = 0.5 * centres + 0.5 * centroids
                new_centres = np.clip(new_centres, 1e-4, 1 - 1e-4)
                new_radii = _radii_from_centres(new_centres)
                new_score = new_radii.sum()
                if new_score >= score - 1e-9:
                    centres, radii, score = new_centres, new_radii, new_score
                else:
                    # partial step towards centroids
                    new_centres = 0.85 * centres + 0.15 * centroids
                    new_centres = np.clip(new_centres, 1e-4, 1 - 1e-4)
                    new_radii = _radii_from_centres(new_centres)
                    new_score = new_radii.sum()
                    if new_score > score:
                        centres, radii, score = new_centres, new_radii, new_score
                    else:
                        break

        # local coordinate descent polish
        centres, radii, score = _refine(centres, iters=250, step0=0.02)

        if score > best_score:
            best_score = score
            best = (centres.copy(), radii.copy())

    # Final safety pass: enforce feasibility exactly and return
    centres, radii = best
    radii = _radii_from_centres(centres)
    centres = np.clip(centres, 0.0, 1.0)
    # re-derive radii after clipping to guarantee wall distance respect
    radii = _radii_from_centres(centres)
    return centres, radii
# EVOLVE-BLOCK-END

