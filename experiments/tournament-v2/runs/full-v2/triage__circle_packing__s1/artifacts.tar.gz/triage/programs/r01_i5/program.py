# EVOLVE-BLOCK-START
"""Advanced: SOCP-based radius optimization for fixed centers using scipy optimization."""
import numpy as np
from scipy.optimize import minimize


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    # Create a structured concentric ring layout for 26 circles
    centers = []
    # Center circle
    centers.append([0.5, 0.5])
    # First ring: 8 circles
    for i in range(8):
        r = 0.35 * np.sqrt(16/8)  # Adjusted radius for ~equal spacing
        theta = 2 * np.pi * i / 8
        x = 0.5 + r * np.cos(theta)
        y = 0.5 + r * np.sin(theta)
        centers.append([x, y])
    # Second ring: 8 more circles
    for i in range(8):
        r = 0.55
        theta = 2 * np.pi * i / 8
        x = 0.5 + r * np.cos(theta)
        y = 0.5 + r * np.sin(theta)
        centers.append([cx, cy])
        cx = 0.5 + r * np.cos(theta)
        cy = 0.5 + r * np.sin(theta)
    # Fill remaining with random in valid region
    while len(centers) < n:
        # Ensure they're placed inside reasonable area
        attempts = 0
        while attempts < 100:
            x = 0.1 + 0.8 * np.random.rand()
            y = 0.1 + 0.8 * np.random.rand()
            # Check min distance from all existing centers
            valid = True
            for cx, cy in centers:
                d = np.sqrt((x - cx)**2 + (y - cy)**2)
                if d < 0.15:  # Minimum initial separation
                    valid = False
                    break
            if valid:
                centers.append([x, y])
                break
            attempts += 1
    
    centers = np.array(centers[:n])
    # Clip centers to stay away from boundaries
    centers = np.clip(centers, 0.1, 0.9)
    
    # Optimize radii using SOCP-style quadratic programming
    radii = optimize_radii_for_centers(centers)
    return centers, radii


def optimize_radii_for_centers(centers):
    """Find optimal radii maximizing sum of radii without overlaps."""
    n = len(centers)
    dim = len(centers[0])
    
    # Constraint: r_i + r_j <= distance(i, j) for all pairs
    # And r_i <= min distance to square boundaries
    
    # Build optimization: maximize sum(r) = -minimize sum(-r)
    x0 = np.full(n, 0.05)  # Initial guess
    
    def objective(r):
        return -np.sum(r)  # Negative sum since minimize
    
    constraints = []
    
    # Pairwise non-overlap constraints: r_i + r_j <= d_ij
    for i in range(n):
        for j in range(i + 1, n):
            d = np.linalg.norm(centers[i] - centers[j])
            if d > 1e-8:
                # r_i + r_j <= d
                constraints.append({
                    'type': 'ineq',
                    'fun': lambda r: d - r[i] - r[j]
                })
    
    # Boundary constraints: r_i <= distance to wall
    for i in range(n):
        wall_dist = min(
            centers[i, 0],           # Left wall
            1 - centers[i, 0],        # Right wall
            centers[i, 1],            # Bottom wall
            1 - centers[i, 1]         # Top wall
        )
        x_i = centers[i, 0]
        y_i = centers[i, 1]
        constraints.append({
            'type': 'ineq',
            'fun': lambda r, i=i: wall_dist - r[i]
        })
    
    # Bounds: radii >= 0
    bounds = [(0, float('inf')) for _ in range(n)]
    
    # Use SLSQP for constrained optimization
    result = minimize(
        objective, x0, method='SLSQP',
        constraints=constraints, bounds=bounds,
        options={'maxiter': 500, 'ftol': 1e-9}
    )
    
    radii = np.maximum(result.x, 0.0)
    return radii
# EVOLVE-BLOCK-END
