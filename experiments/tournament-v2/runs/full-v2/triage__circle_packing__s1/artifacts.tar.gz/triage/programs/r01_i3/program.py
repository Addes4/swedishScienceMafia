import numpy as np
from scipy.optimize import minimize

def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    # Initial layout: use a known good configuration as starting point
    # Start with a grid-like arrangement that can be optimized
    np.random.seed(42)
    
    # Generate initial centers using a quasi-random approach
    k = int(np.ceil(np.sqrt(n)))
    x = np.linspace(0.05, 0.95, k)
    y = np.linspace(0.05, 0.95, k)
    xx, yy = np.meshgrid(x, y)
    centers = np.column_stack([xx.ravel(), yy.ravel()])[:n]
    
    # Add small random perturbations
    centers += np.random.normal(0, 0.02, centers.shape)
    centers = np.clip(centers, 0.01, 0.99)
    
    # Optimize using shrink-and-grow with gradient-based refinement
    best_centers, best_radii = shrink_and_grow(centers, n_iter=200)
    
    return best_centers, best_radii


def shrink_and_grow(centers, n_iter=200):
    """Iteratively improve circle packing using shrink-and-grow approach."""
    n = len(centers)
    centers = centers.copy()
    step_size = 0.01
    momentum = np.zeros_like(centers)
    
    for iteration in range(n_iter):
        # Compute current max radii
        radii = max_radii(centers)
        
        # Compute gradients for center adjustments
        gradients = compute_constraint_gradients(centers, radii)
        
        # Update centers with momentum
        momentum = 0.9 * momentum + step_size * gradients
        centers = centers + momentum
        
        # Project back into unit square with margin
        centers = np.clip(centers, 0.001, 0.999)
        
        # Decay step size
        step_size *= 0.995
        
        # Occasionally do a local optimization step
        if iteration % 20 == 0 and iteration > 0:
            centers = local_optimize_centers(centers)
    
    # Final refinement
    radii = max_radii(centers)
    return centers, radii


def compute_constraint_gradients(centers, radii):
    """Compute gradients pushing centers away from constraints."""
    n = len(centers)
    gradients = np.zeros_like(centers)
    
    # Wall constraints: push away from walls if too close
    margin = 1e-6
    for i in range(n):
        # Distance to each wall
        dist_left = centers[i, 0]
        dist_right = 1 - centers[i, 0]
        dist_bottom = centers[i, 1]
        dist_top = 1 - centers[i, 1]
        
        # Push away from walls if violating
        if dist_left < radii[i] + margin:
            gradients[i, 0] += (radii[i] - dist_left + margin)
        if dist_right < radii[i] + margin:
            gradients[i, 0] -= (radii[i] - dist_right + margin)
        if dist_bottom < radii[i] + margin:
            gradients[i, 1] += (radii[i] - dist_bottom + margin)
        if dist_top < radii[i] + margin:
            gradients[i, 1] -= (radii[i] - dist_top + margin)
    
    # Pairwise overlap constraints
    for i in range(n):
        for j in range(i + 1, n):
            diff = centers[i] - centers[j]
            dist = np.linalg.norm(diff)
            if dist < 1e-12:
                diff = np.random.randn(2) * 1e-6
                dist = np.linalg.norm(diff)
            
            overlap = radii[i] + radii[j] - dist
            if overlap > 0:
                # Direction from j to i
                direction = diff / dist
                # Move circles apart proportionally
                gradients[i] += direction * overlap * 0.5
                gradients[j] -= direction * overlap * 0.5
    
    # Normalize gradients
    grad_norm = np.linalg.norm(gradients)
    if grad_norm > 1e-12:
        gradients /= grad_norm * 10
    
    return gradients


def local_optimize_centers(centers):
    """Perform local optimization of centers to maximize sum of radii."""
    n = len(centers)
    
    def objective(flat_centers):
        c = flat_centers.reshape(n, 2)
        # Penalize going outside bounds
        penalty = np.sum(np.maximum(0, -c) ** 2) + np.sum(np.maximum(0, c - 1) ** 2)
        r = max_radii(c)
        return -np.sum(r) + penalty * 1000
    
    def constraint(flat_centers, i, j):
        c = flat_centers.reshape(n, 2)
        r = max_radii(c)
        dist = np.linalg.norm(c[i] - c[j])
        return dist - r[i] - r[j]
    
    x0 = centers.ravel()
    
    # Only do a few iterations of local optimization for speed
    try:
        res = minimize(
            objective,
            x0,
            method='L-BFGS-B',
            bounds=[(0.001, 0.999)] * (2 * n),
            options={'maxiter': 10, 'disp': False}
        )
        if res.success:
            return res.x.reshape(n, 2)
    except:
        pass
    
    return centers


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    
    for _ in range(100):
        changed = False
        # Process in random order for better convergence
        order = np.random.permutation(n)
        for idx_i in range(n):
            i = order[idx_i]
            for idx_j in range(idx_i + 1, n):
                j = order[idx_j]
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    
    return np.maximum(radii, 0.0)
