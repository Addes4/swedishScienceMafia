# EVOLVE-BLOCK-START
"""Greedy disc packing: sequentially place the largest possible circle
tangent to two existing circles (or circle/wall, wall/wall), choosing the
placement that maximises the added radius.  Then locally refine with radii
optimisation."""
import numpy as np


def solve(n=26):
    centers = greedy_pack(n)
    return centers, max_radii(centers)


def greedy_pack(n):
    """Greedy sequential placement.  Circles are stored as (x, y, r).
    At each step try all contact pairs among existing circles plus the four
    walls, compute the tangent circle(s) that fit inside the square without
    overlapping anything, and take the one with the largest radius."""
    # Start with a big central circle (scaled to allow room for growth).
    circles = [(0.5, 0.5, 0.25)]

    tries = 0
    max_tries = 4000
    while len(circles) < n and tries < max_tries:
        tries += 1
        best = None
        best_r = -1.0

        # Candidate positions generated from contacts.
        cands = []
        m = len(circles)
        # circle-circle tangency candidates
        for i in range(m):
            for j in range(i + 1, m):
                for p in tangent_cc(circles[i], circles[j]):
                    cands.append(p)
        # circle-wall tangency candidates
        for i in range(m):
            for wall in range(4):
                for p in tangent_cw(circles[i], wall):
                    cands.append(p)

        # wall-wall corners (plus tangent to one wall pair) - just corners.
        cands.extend([(0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0)])

        for (cx, cy) in cands:
            if cx < 0 or cx > 1 or cy < 0 or cy > 1:
                continue
            r = radius_at(circles, cx, cy)
            if r > best_r:
                best_r = r
                best = (cx, cy)

        if best is None or best_r <= 0:
            # Fallback: shrink the whole configuration slightly and retry.
            circles = [(x, y, r * 0.95) for (x, y, r) in circles]
            continue

        cx, cy = best
        circles.append((cx, cy, best_r))

    # Trim to n and rescale to fill square under overlap-free constraint.
    circles = circles[:n]
    # Recompute radii from scratch for the fixed centres to maximize.
    cxy = np.array([(x, y) for (x, y, r) in circles])
    return cxy


def tangent_cc(a, b):
    """Return candidate points tangent to two circles (external tangency).
    For circle a=(x1,y1,r1), b=(x2,y2,r2) and unknown r, tangency means
    distance from new center to each >= r_i + r (touching in best case).
    We enumerate the 'kissing' points assuming the new circle touches both."""
    x1, y1, r1 = a
    x2, y2, r2 = b
    dx, dy = x2 - x1, y2 - y1
    d = np.hypot(dx, dy)
    if d < 1e-12:
        return []
    # Intersection of two circles with radii r1 + t and r2 + t is not solvable
    # in closed form for both point and t.  Use approximate Apollonius points:
    # solve for center on the locus where distance to a minus distance to b
    # equals (r1 - r2).  This is a hyperbola; sample along it.
    res = []
    # Parametrize: center P with |P-A| - |P-B| = r1 - r2.
    # Use a simple two-step approximation via midpoints scaled.
    for t in np.linspace(0.0, 0.8, 33):
        # Center along line joining the two, offset perpendicular.
        ux, uy = dx / d, dy / d
        px, py = x1 + ux * (r1 + t), y1 + uy * (r1 + t)
        # perpendicular offset to also be distance r2 + t from b
        # distance from b should equal r2 + t
        # Solve for offset s:
        bx, by = x2, y2
        vx, vy = px - bx, py - by
        dist = np.hypot(vx, vy)
        target = r2 + t
        if dist > target:
            continue
        # perpendicular direction
        nx, ny = -uy, ux
        off = np.sqrt(max(target * target - dist * dist, 0.0))
        res.append((px + nx * off, py + ny * off))
        res.append((px - nx * off, py - ny * off))
    return res


def tangent_cw(c, wall):
    """Candidate points tangent to circle c and a wall.
    wall: 0=left x=0, 1=right x=1, 2=bottom y=0, 3=top y=1."""
    x, y, r = c
    res = []
    for t in np.linspace(0.0, 0.8, 33):
        R = r + t
        if wall == 0:
            cx = t
            dy = np.sqrt(max(R * R - (cx - x) ** 2, 0.0))
            res.append((cx, y + dy))
            res.append((cx, y - dy))
        elif wall == 1:
            cx = 1.0 - t
            dy = np.sqrt(max(R * R - (cx - x) ** 2, 0.0))
            res.append((cx, y + dy))
            res.append((cx, y - dy))
        elif wall == 2:
            cy = t
            dx = np.sqrt(max(R * R - (cy - y) ** 2, 0.0))
            res.append((x + dx, cy))
            res.append((x - dx, cy))
        else:
            cy = 1.0 - t
            dx = np.sqrt(max(R * R - (cy - y) ** 2, 0.0))
            res.append((x + dx, cy))
            res.append((x - dx, cy))
    return res


def radius_at(circles, cx, cy):
    """Maximum radius at (cx,cy) so it stays inside square and disjoint."""
    r = min(cx, cy, 1.0 - cx, 1.0 - cy)
    if r < 0:
        return -1.0
    for (x, y, rr) in circles:
        d = np.hypot(cx - x, cy - y)
        lim = d - rr
        if lim < r:
            r = lim
    return r


def max_radii(centers):
    """Largest radii for fixed centres: start from wall distance, shrink overlaps."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if d < 1e-12:
                    continue
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END

