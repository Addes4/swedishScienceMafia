# EVOLVE-BLOCK-START
"""Force-based continuous optimisation for the 26-circle packing problem.

Strategy
--------
1. Build a decent initial layout: a large central circle with concentric rings,
   tuned so the ring radii are dense but feasible.
2. Compute the fixed-centre maximal radii (used as a starting point and as a
   cheap feasibility model).
3. Run a many-step projected gradient / penalty descent on the joint variables
   (centres and radii) that maximises sum(radii) while penalising
   • circle-circle overlap,
   • wall violations,
   • negative radii.
   The penalty weight is increased over time (a continuation / annealing
   schedule) so the solution is driven to strict feasibility at the end.
4. Finish with a fixed-centre "shrink-to-fit" pass to remove any residual
   penetration and guarantee a valid packing.
"""

import numpy as np


def _fixed_radii(centers):
    """Max radii for fixed centres: wall distance then iterative shrink."""
    n = len(centers)
    r = np.minimum.reduce([centers[:, 0], centers[:, 1],
                           1.0 - centers[:, 0], 1.0 - centers[:, 1]])
    r = np.maximum(r, 0.0)
    for _ in range(80):
        changed = False
        for i in range(n):
            xi, yi = centers[i]
            for j in range(i + 1, n):
                dx = xi - centers[j, 0]
                dy = yi - centers[j, 1]
                d = np.sqrt(dx * dx + dy * dy)
                s = r[i] + r[j]
                if s > d and s > 1e-12:
                    scale = d / s
                    r[i] *= scale
                    r[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


def _initial(n):
    """Ring-based initial layout for n circles."""
    centers = []
    if n >= 1:
        centers.append([0.5, 0.5])
    # inner ring of 8
    for i in range(min(8, n - len(centers))):
        a = 2 * np.pi * i / 8 + 0.1
        centers.append([0.5 + 0.30 * np.cos(a), 0.5 + 0.30 * np.sin(a)])
    # outer ring of 16
    for i in range(n - len(centers)):
        a = 2 * np.pi * i / 16 + np.pi / 16
        centers.append([0.5 + 0.72 * np.cos(a), 0.5 + 0.72 * np.sin(a)])
    c = np.array(centers[:n], dtype=float)
    return c


def _feasible_radii(centers, radii):
    """Shrink overlapping pairs (and wall violations) to feasibility."""
    r = np.array(radii, dtype=float)
    n = len(r)
    for _ in range(200):
        changed = False
        # wall
        for i in range(n):
            m = min(centers[i, 0], centers[i, 1],
                    1.0 - centers[i, 0], 1.0 - centers[i, 1])
            if r[i] > m:
                r[i] = max(m, 0.0)
                changed = True
        for i in range(n):
            for j in range(i + 1, n):
                dx = centers[i, 0] - centers[j, 0]
                dy = centers[i, 1] - centers[j, 1]
                d = np.sqrt(dx * dx + dy * dy)
                s = r[i] + r[j]
                if s > d and s > 1e-12:
                    scale = d / s
                    r[i] *= scale
                    r[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


def solve(n=26):
    rng = np.random.default_rng(12345)
    centers = _initial(n)
    # small random jitter to break symmetry
    centers = centers + rng.normal(0, 0.005, centers.shape)
    centers = np.clip(centers, 0.02, 0.98)

    radii = _fixed_radii(centers)
    radii = np.maximum(radii * 0.95, 1e-4)

    # Joint variables: x,y for each circle plus r.
    # Objective: maximise sum(r) - penalty * sum(overlap violations).
    # We use projected gradient ascent with an increasing penalty.
    X = centers.copy()
    R = radii.copy()

    lr_c = 3e-3
    lr_r = 3e-3

    def overlaps(X, R):
        n = len(R)
        viol = 0.0
        gradX = np.zeros_like(X)
        gradR = np.zeros(n)
        # wall violations: r > min(dist to walls)
        for i in range(n):
            x, y = X[i]
            wall = min(x, y, 1.0 - x, 1.0 - y)
            v = R[i] - wall
            if v > 0:
                viol += v * v
                gradR[i] += 2 * v
                # gradient wrt x,y of -wall distance term
                # wall = min of four linear functions; use active one
                cands = [(x, 0), (y, 1), (1.0 - x, 2), (1.0 - y, 3)]
                _, k = min(cands, key=lambda t: t[0])
                # d(wall)/dx, d(wall)/dy
                if k == 0:
                    dwx, dwy = 1.0, 0.0
                elif k == 1:
                    dwx, dwy = 0.0, 1.0
                elif k == 2:
                    dwx, dwy = -1.0, 0.0
                else:
                    dwx, dwy = 0.0, -1.0
                # d(v)/dX = -d(wall)/dX
                gradX[i, 0] += 2 * v * (-dwx)
                gradX[i, 1] += 2 * v * (-dwy)
        for i in range(n):
            for j in range(i + 1, n):
                dx = X[i, 0] - X[j, 0]
                dy = X[i, 1] - X[j, 1]
                d2 = dx * dx + dy * dy
                d = np.sqrt(d2) + 1e-12
                s = R[i] + R[j]
                v = s - d
                if v > 0:
                    viol += v * v
                    # d(v)/dRi = 1, d(v)/dRj = 1
                    gradR[i] += 2 * v
                    gradR[j] += 2 * v
                    # d(v)/dXi = -dx/d ; d(v)/dXj = dx/d etc
                    gx = -dx / d
                    gy = -dy / d
                    gradX[i, 0] += 2 * v * gx
                    gradX[i, 1] += 2 * v * gy
                    gradX[j, 0] += -2 * v * gx
                    gradX[j, 1] += -2 * v * gy
        return viol, gradX, gradR

    best_sum = -np.inf
    best_X = X.copy()
    best_R = _feasible_radii(X, R)
    best_sum = best_R.sum()

    # Continuation over penalty weight
    penalties = [1.0, 3.0, 10.0, 30.0, 100.0, 300.0, 1000.0]
    iters_per = 400

    for pen in penalties:
        for it in range(iters_per):
            # gradient of objective: d(sum r)/dR = 1, d/dX = 0
            viol, gX, gR = overlaps(X, R)
            step_c = lr_c / (1.0 + it * 0.002)
            step_r = lr_r / (1.0 + it * 0.002)
            # maximise: X += lr * (0 - pen*gX) ; R += lr*(1 - pen*gR)
            X = X + step_c * (-pen * gX)
            R = R + step_r * (1.0 - pen * gR)
            # project
            X = np.clip(X, 0.0, 1.0)
            R = np.maximum(R, 1e-5)
            # hard wall clamp on radii
            for i in range(n):
                m = min(X[i, 0], X[i, 1], 1.0 - X[i, 0], 1.0 - X[i, 1])
                if R[i] > m:
                    R[i] = max(m, 1e-5)
            # track best feasible
            if it % 20 == 0:
                Rf = _feasible_radii(X, R)
                s = Rf.sum()
                if s > best_sum:
                    best_sum = s
                    best_X = X.copy()
                    best_R = Rf.copy()

    # Final polish: fixed-centre radii on best centres
    Rf = _fixed_radii(best_X)
    if Rf.sum() > best_sum:
        best_R = Rf
        best_sum = Rf.sum()

    # One more pass: local coordinate descent on centres.
    for _ in range(3):
        improved = False
        base = _fixed_radii(best_X).sum()
        step = 0.01
        for i in range(n):
            for dx, dy in ((step, 0), (-step, 0), (0, step), (0, -step),
                           (step, step), (-step, -step), (step, -step), (-step, step)):
                cand = best_X.copy()
                cand[i, 0] = np.clip(cand[i, 0] + dx, 0.0, 1.0)
                cand[i, 1] = np.clip(cand[i, 1] + dy, 0.0, 1.0)
                s = _fixed_radii(cand).sum()
                if s > base + 1e-9:
                    best_X = cand
                    base = s
                    improved = True
        if not improved:
            break

    best_R = _fixed_radii(best_X)
    # Safety: ensure strict feasibility
    best_R = _feasible_radii(best_X, best_R)
    return best_X, best_R
# EVOLVE-BLOCK-END
