# EVOLVE-BLOCK-START
"""Circle packing in the unit square via joint (center, radius) optimization.

Idea: instead of fixing centers and computing maximal radii, we optimize over
both centers and radii with a soft overlap penalty.  This is the standard
approach in the circle-packing literature (Graham & Lubachevsky billiards,
Nurmela & Ostergard).  We use scipy's L-BFGS-B with multiple restarts and a
final feasibility projection so the returned configuration is always valid.
"""
import numpy as np
from scipy.optimize import minimize


def _pack_objective(z, n, lam):
    """Negative sum of radii + penalty for overlaps and wall violations."""
    c = z[: 2 * n].reshape(n, 2)
    r = z[2 * n:]

    # Wall penalty: circle must satisfy r <= x, r <= 1-x, r <= y, r <= 1-y
    wall = np.maximum(0.0, r - c[:, 0])
    wall += np.maximum(0.0, r - (1.0 - c[:, 0]))
    wall += np.maximum(0.0, r - c[:, 1])
    wall += np.maximum(0.0, r - (1.0 - c[:, 1]))
    wall_pen = lam * np.sum(wall ** 2)

    # Pairwise overlap penalty
    diff = c[:, None, :] - c[None, :, :]
    d = np.sqrt(np.sum(diff * diff, axis=-1))
    np.fill_diagonal(d, np.inf)
    overlap = np.maximum(0.0, r[:, None] + r[None, :] - d)
    pair_pen = lam * np.sum(overlap ** 2)

    return -np.sum(r) + wall_pen + pair_pen


def _initial_layout(n, rng):
    """A decent starting layout: one center + rings, plus jitter."""
    centers = [[0.5, 0.5]]
    k1 = min(8, n - 1)
    for i in range(k1):
        a = 2 * np.pi * i / k1
        centers.append([0.5 + 0.30 * np.cos(a), 0.5 + 0.30 * np.sin(a)])
    k2 = n - len(centers)
    for i in range(k2):
        a = 2 * np.pi * i / max(1, k2)
        centers.append([0.5 + 0.68 * np.cos(a), 0.5 + 0.68 * np.sin(a)])
    centers = np.array(centers[:n], dtype=float)
    centers += rng.normal(0.0, 0.01, size=centers.shape)
    centers = np.clip(centers, 0.02, 0.98)
    radii = np.full(n, 0.4 / np.sqrt(n))
    return np.concatenate([centers.ravel(), radii])


def _feasible_radii(centers, radii):
    """Shrink radii so nothing overlaps and all circles lie in the square."""
    n = len(centers)
    r = np.minimum.reduce([centers[:, 0], centers[:, 1],
                           1 - centers[:, 0], 1 - centers[:, 1]])
    r = np.minimum(r, radii)
    r = np.maximum(r, 0.0)
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                s = r[i] + r[j]
                if s > d and s > 0:
                    scale = d / s
                    r[i] *= scale
                    r[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    rng = np.random.default_rng(0)

    best_centers = None
    best_radii = None
    best_sum = -np.inf

    # Bounds: centers in [0,1], radii in [0, 0.5]
    lower = np.concatenate([np.zeros(2 * n), np.zeros(n)])
    upper = np.concatenate([np.ones(2 * n), np.full(n, 0.5)])
    bounds = list(zip(lower, upper))

    # A few restarts with decreasing penalty (continuation) reach better optima.
    n_restarts = 8
    for trial in range(n_restarts):
        z0 = _initial_layout(n, rng)
        # Continuation on penalty: start soft, then hard.
        for lam in (10.0, 50.0, 200.0, 800.0):
            res = minimize(
                _pack_objective, z0, args=(n, lam),
                method="L-BFGS-B", bounds=bounds,
                options={"maxiter": 400, "ftol": 1e-12, "gtol": 1e-10},
            )
            z0 = res.x

        c = z0[: 2 * n].reshape(n, 2)
        r = z0[2 * n:]
        # Final hard projection to guarantee feasibility.
        r_feas = _feasible_radii(c, r)
        s = float(np.sum(r_feas))
        if s > best_sum:
            best_sum = s
            best_centers = c.copy()
            best_radii = r_feas.copy()

    # Safety: if optimizer failed completely, fall back to a simple grid.
    if best_centers is None:
        k = int(np.ceil(np.sqrt(n)))
        xs = np.linspace(0.05, 0.95, k)
        grid = np.array([[x, y] for x in xs for y in xs])[:n]
        best_centers = grid
        best_radii = _feasible_radii(grid, np.full(n, 0.4 / np.sqrt(n)))

    return best_centers, best_radii
# EVOLVE-BLOCK-END