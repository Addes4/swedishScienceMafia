# EVOLVE-BLOCK-START
"""Gradient-based circle packing.

Idea: treat each circle's centre and radius as free parameters and maximise
sum(radii) subject to smooth penalties for wall and pairwise overlaps.  Use
JAX autodiff + Adam to relax a random initial configuration, then project the
radii to the exact feasible values for the final centres.
"""
from __future__ import annotations

import numpy as np

try:
    import jax
    import jax.numpy as jnp

    HAS_JAX = True
except Exception:  # pragma: no cover - fallback if JAX missing
    HAS_JAX = False


def _max_radii_np(centers):
    """Largest feasible radii for fixed centres (projection step)."""
    centers = np.asarray(centers, dtype=float)
    n = len(centers)
    radii = np.minimum.reduce(
        [centers[:, 0], centers[:, 1], 1.0 - centers[:, 0], 1.0 - centers[:, 1]]
    )
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                s = radii[i] + radii[j]
                if s > d and s > 0:
                    scale = d / s
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


if HAS_JAX:
    @jax.jit
    def _loss(params, n, overlap_weight):
        xy = params[: 2 * n].reshape(n, 2)
        r = params[2 * n :]
        # keep centres inside [0,1] softly
        wall = jnp.sum(jnp.maximum(0.0, -xy) ** 2) + jnp.sum(
            jnp.maximum(0.0, xy - 1.0) ** 2
        )
        # wall clearance: r_i <= min(x, 1-x, y, 1-y)
        clearance = jnp.minimum(
            jnp.minimum(xy[:, 0], 1.0 - xy[:, 0]),
            jnp.minimum(xy[:, 1], 1.0 - xy[:, 1]),
        )
        wall_r = jnp.sum(jnp.maximum(0.0, r - clearance) ** 2)
        # pairwise overlap
        diff = xy[:, None, :] - xy[None, :, :]
        dist = jnp.sqrt(jnp.sum(diff * diff, axis=-1) + 1e-12)
        sum_r = r[:, None] + r[None, :]
        overlap = jnp.maximum(0.0, sum_r - dist)
        # exclude diagonal
        mask = 1.0 - jnp.eye(n)
        pair = jnp.sum((overlap ** 2) * mask) * 0.5
        penalty = overlap_weight * (pair + wall_r) + 50.0 * wall
        return -jnp.sum(r) + penalty


def _relax_jax(n, seed, steps=2500, lr=0.01):
    key = jax.random.PRNGKey(seed)
    k1, k2 = jax.random.split(key)
    # initialisation: jittered grid-ish points
    m = int(np.ceil(np.sqrt(n)))
    gx, gy = jnp.meshgrid(jnp.linspace(0.1, 0.9, m), jnp.linspace(0.1, 0.9, m))
    grid = jnp.stack([gx.ravel(), gy.ravel()], axis=1)[:n]
    noise = jax.random.uniform(k1, (n, 2), minval=-0.05, maxval=0.05)
    xy0 = jnp.clip(grid + noise, 0.02, 0.98)
    r0 = jax.random.uniform(k2, (n,), minval=0.02, maxval=0.08)
    params = jnp.concatenate([xy0.ravel(), r0])

    # Adam state
    m_t = jnp.zeros_like(params)
    v_t = jnp.zeros_like(params)
    beta1, beta2, eps = 0.9, 0.999, 1e-8

    grad_fn = jax.jit(jax.grad(_loss))

    best_params = params
    best_score = -jnp.inf

    for t in range(1, steps + 1):
        # overlap penalty weight grows smoothly (annealing)
        w = 200.0 * (t / steps) + 50.0
        g = grad_fn(params, n, w)
        m_t = beta1 * m_t + (1 - beta1) * g
        v_t = beta2 * v_t + (1 - beta2) * (g * g)
        m_hat = m_t / (1 - beta1 ** t)
        v_hat = v_t / (1 - beta2 ** t)
        params = params - lr * m_hat / (jnp.sqrt(v_hat) + eps)
        params = params.at[2 * n :].set(jnp.maximum(params[2 * n :], 0.0))
        params = params.at[: 2 * n].set(jnp.clip(params[: 2 * n], 0.0, 1.0))

        if t % 100 == 0 or t == steps:
            cur = _loss(params, n, w)
            score = -float(cur)  # lower loss = better
            if score > best_score:
                best_score = score
                best_params = params
    return np.asarray(best_params)


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square."""
    if n <= 0:
        return np.zeros((0, 2)), np.zeros((0,))

    if not HAS_JAX:
        # graceful fallback: concentric baseline
        centers = [[0.5, 0.5]]
        centers += [
            [0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)]
            for i in range(8)
        ]
        centers += [
            [0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)]
            for i in range(16)
        ]
        centers = np.clip(np.array(centers[:n]), 0.01, 0.99)
        return centers, _max_radii_np(centers)

    # multi-start gradient relaxation, keep best by projected sum of radii
    best_centers = None
    best_radii = None
    best_val = -np.inf

    n_starts = 6
    for s in range(n_starts):
        params = _relax_jax(n, seed=1234 + 17 * s, steps=2500, lr=0.01)
        xy = params[: 2 * n].reshape(n, 2)
        xy = np.clip(xy, 1e-4, 1 - 1e-4)
        r = _max_radii_np(xy)
        val = float(r.sum())
        if val > best_val:
            best_val = val
            best_centers = xy.copy()
            best_radii = r.copy()

    # tiny local refinement of centres: coordinate descent on projected sum
    rng = np.random.default_rng(0)
    step = 0.01
    for _ in range(400):
        improved = False
        for i in range(n):
            for dim in range(2):
                for delta in (step, -step):
                    trial = best_centers.copy()
                    trial[i, dim] = np.clip(trial[i, dim] + delta, 1e-4, 1 - 1e-4)
                    tr = _max_radii_np(trial)
                    tv = float(tr.sum())
                    if tv > best_val + 1e-9:
                        best_val = tv
                        best_centers = trial
                        best_radii = tr
                        improved = True
        if not improved:
            step *= 0.5
            if step < 1e-4:
                break

    return best_centers, best_radii
# EVOLVE-BLOCK-END
