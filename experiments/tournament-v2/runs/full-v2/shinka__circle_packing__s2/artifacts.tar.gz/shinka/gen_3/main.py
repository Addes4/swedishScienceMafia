# EVOLVE-BLOCK-START
"""Optimized circle packing: solve LP for radii given centers, optimize centers with local search."""
import numpy as np
import time
from scipy.optimize import linprog

def max_radii(centers):
    """Solve LP: maximize sum r_i subject to r_i + r_j <= d_ij, r_i <= wall_i, r_i >= 0."""
    n = len(centers)
    # objective: minimize -sum r
    c = -np.ones(n)
    # constraints: r_i + r_j <= d_ij for i<j
    A_ub = []
    b_ub = []
    for i in range(n):
        for j in range(i+1, n):
            row = np.zeros(n)
            row[i] = 1.0
            row[j] = 1.0
            A_ub.append(row)
            b_ub.append(np.linalg.norm(centers[i] - centers[j]))
    # wall constraints: r_i <= min(x, y, 1-x, 1-y)
    for i in range(n):
        row = np.zeros(n)
        row[i] = 1.0
        A_ub.append(row)
        b_ub.append(min(centers[i][0], centers[i][1], 1-centers[i][0], 1-centers[i][1]))
    A_ub = np.array(A_ub)
    b_ub = np.array(b_ub)
    bounds = [(0, None)] * n
    res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
    if res.success:
        return np.maximum(res.x, 0.0)
    else:
        # fallback to iterative shrinking
        radii = np.minimum.reduce([centers[:,0], centers[:,1], 1-centers[:,0], 1-centers[:,1]])
        for _ in range(100):
            changed = False
            for i in range(n):
                for j in range(i+1, n):
                    d = np.linalg.norm(centers[i] - centers[j])
                    if radii[i] + radii[j] > d:
                        scale = d / (radii[i] + radii[j])
                        radii[i] *= scale
                        radii[j] *= scale
                        changed = True
            if not changed:
                break
        return np.maximum(radii, 0.0)

def total_radius(centers):
    return np.sum(max_radii(centers))

def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    np.random.seed(42)
    # initial layout: hexagonal-like pattern
    centers = []
    # try to place n circles in a hexagonal grid
    # estimate radius ~ 1/(2*sqrt(n)) for square packing
    # Use a simple grid then perturb
    grid_size = int(np.ceil(np.sqrt(n)))
    for i in range(grid_size):
        for j in range(grid_size):
            if len(centers) >= n:
                break
            x = (i + 0.5) / grid_size
            y = (j + 0.5) / grid_size
            centers.append([x, y])
        if len(centers) >= n:
            break
    centers = np.array(centers[:n])
    # add small random perturbation
    centers += np.random.randn(n, 2) * 0.02
    centers = np.clip(centers, 0.01, 0.99)
    
    best_centers = centers.copy()
    best_radii = max_radii(best_centers)
    best_sum = np.sum(best_radii)
    
    start_time = time.time()
    time_limit = 250.0  # seconds
    iteration = 0
    # local search with simulated annealing
    temperature = 0.1
    cooling = 0.99995
    step_size = 0.05
    
    while time.time() - start_time < time_limit:
        iteration += 1
        # perturb a random subset of centers
        new_centers = best_centers.copy()
        k = np.random.randint(1, max(2, n//2))
        indices = np.random.choice(n, size=k, replace=False)
        for idx in indices:
            new_centers[idx] += np.random.randn(2) * step_size
            new_centers[idx] = np.clip(new_centers[idx], 0.005, 0.995)
        
        new_radii = max_radii(new_centers)
        new_sum = np.sum(new_radii)
        
        delta = new_sum - best_sum
        if delta > 0 or np.random.rand() < np.exp(delta / max(temperature, 1e-8)):
            best_centers = new_centers
            best_radii = new_radii
            best_sum = new_sum
        
        temperature *= cooling
        if temperature < 1e-6:
            temperature = 0.01
        # adaptive step size
        if iteration % 100 == 0:
            step_size = max(0.005, step_size * 0.995)
    
    # final polish: try to improve with smaller perturbations
    for _ in range(1000):
        new_centers = best_centers.copy()
        idx = np.random.randint(n)
        new_centers[idx] += np.random.randn(2) * 0.005
        new_centers[idx] = np.clip(new_centers[idx], 0.005, 0.995)
        new_radii = max_radii(new_centers)
        new_sum = np.sum(new_radii)
        if new_sum > best_sum:
            best_centers = new_centers
            best_radii = new_radii
            best_sum = new_sum
    
    return best_centers, best_radii
# EVOLVE-BLOCK-END
