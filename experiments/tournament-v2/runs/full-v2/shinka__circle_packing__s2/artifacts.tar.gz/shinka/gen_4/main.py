# EVOLVE-BLOCK-START
"""Circle packing via multi-start inflate-and-relax local search.

Approach: for a given set of centres, the largest feasible radii are found by
iteratively shrinking overlaps (max_radii). To improve the centres we push each
circle in the direction that relaxes its tightest constraint (wall or neighbour),
then recompute radii. Multiple random restarts plus the baseline ring layout are
tried, and the best configuration is returned. This is a standard, effective
heuristic for circle packing problems.
"""
import numpy as np


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    rng = np.random.default_rng(0)

    # Baseline ring layout (seeded so we never do worse than the original).
    base = [[0.5, 0.5]]
    base += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    base += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    base += [[0.1 + 0.8 * rng.random(), 0.1 + 0.8 * rng.random()] for _ in range(n - len(base))]
    base = np.clip(np.array(base[:n]), 0.01, 0.99)

    best_c = base
    best_r = max_radii(base)
    best_s = float(best_r.sum())

    # Number of restarts scales modestly with n.
    n_restarts = 40 if n <= 30 else 20
    for restart in range(n_restarts):
        if restart == 0:
            c = base.copy()
        else:
            # Random initial centres, avoiding exact overlaps.
            c = rng.random((n, 2)) * 0.96 + 0.02
        c = _relax(c, n, rng)
        r = max_radii(c)
        s = float(r.sum())
        if s > best_s:
            best_s = s
            best_c = c.copy()
            best_r = r.copy()

    return best_c, best_r


def _relax(c, n, rng, iters=400):
    """Iteratively push circles apart and recompute radii to grow the sum."""
    c = c.astype(float).copy()
    step = 0.02
    for it in range(iters):
        r = max_radii(c)
        # Compute a push direction for each circle: away from its tightest
        # constraint. If the tightest constraint is a wall, push inward.
        push = np.zeros_like(c)
        active = np.zeros(n, dtype=bool)

        # Wall constraints: distance to each wall vs radius.
        for k, (wall_d, axis, sign) in enumerate([
            (c[:, 0], 0, +1.0),          # left wall, push +x
            (1 - c[:, 0], 0, -1.0),      # right wall, push -x
            (c[:, 1], 1, +1.0),          # bottom wall, push +y
            (1 - c[:, 1], 1, -1.0),      # top wall, push -y
        ]):
            tight = wall_d <= r + 1e-9
            push[tight, axis] += sign * (r[tight] - wall_d[tight] + 1e-3)
            active |= tight

        # Pairwise constraints (only near pairs matter).
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(c[i] - c[j])
                if d < r[i] + r[j] + 1e-3:
                    if d < 1e-9:
                        d = 1e-9
                    dir_ij = (c[i] - c[j]) / d
                    overlap = (r[i] + r[j]) - d
                    # Push i and j apart proportionally to overlap.
                    push[i] += dir_ij * overlap
                    push[j] -= dir_ij * overlap
                    active[i] = True
                    active[j] = True

        # Add small random jitter to escape symmetric traps.
        push += rng.normal(0, step * 0.1, size=c.shape)

        # Normalise push magnitudes and apply.
        norms = np.linalg.norm(push, axis=1)
        norms[norms < 1e-12] = 1.0
        c += (push / norms[:, None]) * step * active[:, None]
        c = np.clip(c, 1e-4, 1 - 1e-4)

        # Decay step size.
        step *= 0.995
        if step < 1e-4:
            step = 1e-4
    return c


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END