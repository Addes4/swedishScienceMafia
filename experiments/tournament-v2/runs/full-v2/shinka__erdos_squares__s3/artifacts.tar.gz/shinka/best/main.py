# EVOLVE-BLOCK-START
"""Shelf packing: mix square sizes across rows of different heights.

Partition the unit square into horizontal shelves of heights h_1..h_m with
sum(h_i) <= 1.  A shelf of height h holds floor(1/h) squares of side h.
Collect all such squares, keep the largest n, and report their sum.  Search
over all non-increasing sequences of unit-fraction heights via DFS.
"""
import math
import time


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    eps = 1e-9
    # Candidate shelf heights: unit fractions 1/k.
    heights = [1.0 / k for k in range(1, n + 2)]

    def eval_shelves(shelves):
        sizes = []
        for h in shelves:
            c = int(round(1.0 / h))
            if c < 1:
                c = 1
            sizes.extend([h] * c)
        sizes.sort(reverse=True)
        return sum(sizes[:n])

    best_sum = [-1.0]
    best_shelves = [[]]
    counter = [0]
    LIMIT = 400000
    t0 = time.time()
    TIME_LIMIT = 8.0

    def dfs(shelves, used_h, min_idx):
        if counter[0] > LIMIT or time.time() - t0 > TIME_LIMIT:
            return
        counter[0] += 1
        s = eval_shelves(shelves)
        if s > best_sum[0]:
            best_sum[0] = s
            best_shelves[0] = list(shelves)
        if len(shelves) >= n:
            return
        for idx in range(min_idx, len(heights)):
            h = heights[idx]
            if used_h + h <= 1.0 + eps:
                dfs(shelves + [h], used_h + h, idx)

    dfs([], 0.0, 0)

    # Build squares from the best shelf configuration.
    shelves = best_shelves[0]
    all_squares = []
    y = 0.0
    for h in shelves:
        c = int(round(1.0 / h))
        if c < 1:
            c = 1
        for i in range(c):
            x = i * h
            all_squares.append((x + h / 2.0, y + h / 2.0, 0.0, h))
        y += h

    # Keep the n largest squares (omitting others is allowed).
    all_squares.sort(key=lambda t: -t[3])
    result = all_squares[:n]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END