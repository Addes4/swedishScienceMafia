# EVOLVE-BLOCK-START
"""Recursive guillotine-cut packing: split regions adaptively instead of using a fixed grid."""
import math
from functools import lru_cache


def _best_split(w, h, k, memo):
    """Return (value, tree) where tree is ('leaf',) or ('h', frac, left, right) or ('v', frac, left, right).
    value is the maximum total side length for placing k squares in a w x h rectangle (axis-aligned)."""
    if k == 0:
        return 0.0, ('leaf',)
    # Place k equal squares in a k-grid inside this rectangle as a baseline.
    # The best axis-aligned grid for k squares in w x h: choose rows r, cols c with r*c >= k.
    best_val = 0.0
    best_tree = ('leaf',)
    # Baseline: grid with r rows, c cols (r*c >= k), side = min(w/c, h/r), use k of them.
    for r in range(1, k + 1):
        c = (k + r - 1) // r
        s = min(w / c, h / r)
        v = s * k
        if v > best_val:
            best_val = v
            best_tree = ('grid', r, c, s, w, h)

    if k == 1:
        s = min(w, h)
        if s > best_val:
            best_val = s
            best_tree = ('grid', 1, 1, s, w, h)
        return best_val, best_tree

    key = (round(w, 9), round(h, 9), k)
    if key in memo:
        return memo[key]

    # Try guillotine splits: cut vertically at fraction f, or horizontally.
    # Candidate fractions from simple ratios and recursive halving.
    fracs = [0.5, 1.0/3.0, 2.0/3.0, 0.25, 0.75, 0.4, 0.6, 1.0/5.0, 4.0/5.0, 0.3, 0.7]
    for f in fracs:
        # vertical cut: left part w*f, right part w*(1-f)
        wl = w * f
        wr = w * (1.0 - f)
        if wl < 1e-12 or wr < 1e-12:
            continue
        for i in range(1, k):
            vl, tl = _best_split(wl, h, i, memo)
            vr, tr = _best_split(wr, h, k - i, memo)
            v = vl + vr
            if v > best_val + 1e-12:
                best_val = v
                best_tree = ('v', f, tl, tr)
        # horizontal cut
        hl = h * f
        hr = h * (1.0 - f)
        if hl < 1e-12 or hr < 1e-12:
            continue
        for i in range(1, k):
            vl, tl = _best_split(w, hl, i, memo)
            vr, tr = _best_split(w, hr, k - i, memo)
            v = vl + vr
            if v > best_val + 1e-12:
                best_val = v
                best_tree = ('h', f, tl, tr)

    memo[key] = (best_val, best_tree)
    return best_val, best_tree


def _emit(tree, x, y, w, h, out):
    """Emit squares from a guillotine tree into out, given the rectangle (x, y, w, h)."""
    kind = tree[0]
    if kind == 'leaf':
        return
    if kind == 'grid':
        _, r, c, s, _, _ = tree
        # place r rows, c cols, centered
        total_w = c * s
        total_h = r * s
        ox = x + (w - total_w) / 2.0
        oy = y + (h - total_h) / 2.0
        for i in range(r):
            for j in range(c):
                cx = ox + (j + 0.5) * s
                cy = oy + (i + 0.5) * s
                out.append((cx, cy, 0.0, s))
        return
    if kind == 'v':
        _, f, tl, tr = tree
        wl = w * f
        wr = w * (1.0 - f)
        _emit(tl, x, y, wl, h, out)
        _emit(tr, x + wl, y, wr, h, out)
        return
    if kind == 'h':
        _, f, tl, tr = tree
        hl = h * f
        hr = h * (1.0 - f)
        _emit(tl, x, y, w, hl, out)
        _emit(tr, x, y + hl, w, hr, out)
        return


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    memo = {}
    val, tree = _best_split(1.0, 1.0, n, memo)
    out = []
    _emit(tree, 0.0, 0.0, 1.0, 1.0, out)
    # Pad with zero-size squares if we emitted fewer than n (shouldn't normally happen).
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    out = out[:n]
    # Clamp to [0,1] for safety.
    cleaned = []
    for (cx, cy, ang, s) in out:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = max(0.0, min(s, 1.0))
        cleaned.append((cx, cy, ang, s))
    return cleaned
# EVOLVE-BLOCK-END
