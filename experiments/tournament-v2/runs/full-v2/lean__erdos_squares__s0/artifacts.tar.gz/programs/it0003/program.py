# EVOLVE-BLOCK-START
"""Improved packing: combine the best rectangular equal-grid solution with a
greedy multi-size packing.  For each n we try many size compositions (a few
big squares plus many small ones), pack them greedily using a bottom-left
strategy (free-rectangle / skyline style) and keep the best total side length.

This is a general method that works for every n and is not a lookup table.
"""
import math
import random


def _grid_solution(n):
    """Best rectangular grid of equal squares, as in the baseline."""
    best_total = -1.0
    best = None
    for b in range(1, n + 1):
        c = (n + b - 1) // b
        side = min(1.0 / c, 1.0 / b)
        total = side * n
        if total > best_total:
            best_total = total
            best = (b, c, side)
    b, c, side = best
    squares = []
    count = 0
    for j in range(b):
        for i in range(c):
            if count >= n:
                break
            cx = (i + 0.5) * (1.0 / c)
            cy = (j + 0.5) * (1.0 / b)
            squares.append((cx, cy, 0.0, side))
            count += 1
    return squares[:n]


def _can_place(rect, others, tol=1e-12):
    """Check an axis-aligned square 'rect' = (x0, y0, s) fits without overlap."""
    x0, y0, s = rect
    if x0 < -tol or y0 < -tol or x0 + s > 1 + tol or y0 + s > 1 + tol:
        return False
    x1, y1 = x0 + s, y0 + s
    for (a, b, t) in others:
        ax1, by1 = a + t, b + t
        # overlap in interior?
        if x0 < ax1 - tol and a < x1 - tol and y0 < by1 - tol and b < y1 - tol:
            return False
    return True


def _greedy_pack(sizes):
    """Greedily place squares (largest first) using bottom-left skyline points.

    Returns list of (x0, y0, s) or None if it fails.
    """
    placed = []  # list of (x0, y0, s)
    # candidate bottom-left anchor points grow as we place squares
    for s in sizes:
        if s <= 1e-12:
            continue
        best_pt = None
        # candidate positions: corners of the domain and of placed squares
        xs = {0.0}
        ys = {0.0}
        for (a, b, t) in placed:
            xs.add(a + t)
            ys.add(b + t)
            xs.add(a)
            ys.add(b)
        cand = []
        for X in xs:
            for Y in ys:
                if _can_place((X, Y, s), placed):
                    cand.append((X, Y))
        if not cand:
            return None
        # bottom-left: minimise y then x
        cand.sort(key=lambda p: (p[1], p[0]))
        X, Y = cand[0]
        placed.append((X, Y, s))
    return placed


def _seq_to_squares(placed):
    out = []
    for (x0, y0, s) in placed:
        out.append((x0 + s / 2.0, y0 + s / 2.0, 0.0, s))
    return out


def _try_sequences(n, rng, tries):
    """Try random size sequences and greedy-pack them; keep the best."""
    best = None
    best_total = -1.0
    for _ in range(tries):
        sizes = []
        remaining = n
        # a few random "big" squares then fill with smaller
        k_big = rng.randint(0, max(0, min(3, n)))
        for _ in range(k_big):
            sizes.append(rng.uniform(0.3, 1.0))
        while len(sizes) < n:
            sizes.append(rng.uniform(0.05, 0.6))
        sizes = sizes[:n]
        sizes.sort(reverse=True)
        placed = _greedy_pack(sizes)
        if placed is None:
            continue
        total = sum(p[2] for p in placed)
        if total > best_total:
            best_total = total
            best = placed
    return best


def solve(n):
    if n <= 0:
        return []
    squares = _grid_solution(n)
    best_total = sum(s[3] for s in squares)

    rng = random.Random(12345 + n)
    # multi-start random sequences
    for tries in (200, 200):
        placed = _try_sequences(n, rng, tries)
        if placed is not None:
            total = sum(p[2] for p in placed)
            if total > best_total:
                best_total = total
                squares = _seq_to_squares(placed)
    return squares[:n]
# EVOLVE-BLOCK-END
