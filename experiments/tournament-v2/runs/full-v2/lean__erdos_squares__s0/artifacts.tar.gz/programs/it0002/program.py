# EVOLVE-BLOCK-START
"""Baseline: pick the rectangular grid of unit squares (all the same size) that
maximises the total side length over all placements of n equal squares."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    best_total = -1.0
    best = None
    # Try rectangular grids b rows x c cols of equal squares, b*c >= n.
    for b in range(1, n + 1):
        c = (n + b - 1) // b  # columns needed so that b*c >= n
        # to fit: c squares across width, b down height, each side = min(1/c, 1/b)
        side = min(1.0 / c, 1.0 / b)
        # only keep it if we can actually fit c columns and b rows
        total = side * n
        if total > best_total:
            best_total = total
            best = (b, c, side)
    b, c, side = best
    squares = []
    # place n squares in a b x c grid, filling row by row
    count = 0
    for j in range(b):
        for i in range(c):
            if count >= n:
                break
            cx = (i + 0.5) * (1.0 / c)
            cy = (j + 0.5) * (1.0 / b)
            squares.append((cx, cy, 0.0, side))
            count += 1
    return squares[:n]
# EVOLVE-BLOCK-END

