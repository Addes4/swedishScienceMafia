# EVOLVE-BLOCK-START
"""Grid initial guess plus physics relaxation: push apart overlaps and grow squares."""
import math
import random


def _overlap_penalty(a, b):
    """Approximate overlap between two axis-aligned squares (cx, cy, s)."""
    dx = abs(a[0] - b[0]) - (a[2] + b[2]) * 0.5
    dy = abs(a[1] - b[1]) - (a[2] + b[2]) * 0.5
    if dx < 0.0 and dy < 0.0:
        return -dx * -dy
    return 0.0


def solve(n):
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)][:n]
    # initial: rows/cols grid that fits
    cols = max(1, int(math.ceil(math.sqrt(n))))
    rows = max(1, int(math.ceil(n / cols)))
    while rows * cols < n:
        rows += 1
    # try to balance
    best = None
    for r in range(1, n + 1):
        c = int(math.ceil(n / r))
        if r * c >= n:
            s = min(1.0 / r, 1.0 / c)
            if best is None or s > best[0]:
                best = (s, r, c)
    s0, rows, cols = best
    sq = []
    idx = 0
    for i in range(rows):
        for j in range(cols):
            if idx >= n:
                break
            cx = (j + 0.5) / cols
            cy = (i + 0.5) / rows
            sq.append([cx, cy, s0])
            idx += 1
    sq = sq[:n]

    # Physics relaxation: increase sizes and resolve overlap.
    random.seed(12345)
    for it in range(4000):
        # grow
        grow = 0.0015 * (1.0 - it / 4000.0) + 0.00005
        for a in sq:
            a[2] += grow
            # keep inside
            a[2] = min(a[2], 1.0)
            h = a[2] * 0.5
            if a[0] < h:
                a[0] = h
            if a[0] > 1.0 - h:
                a[0] = 1.0 - h
            if a[1] < h:
                a[1] = h
            if a[1] > 1.0 - h:
                a[1] = 1.0 - h
        # separate overlaps
        for i in range(n):
            for j in range(i + 1, n):
                a = sq[i]
                b = sq[j]
                dx = b[0] - a[0]
                dy = b[1] - a[1]
                ox = (a[2] + b[2]) * 0.5 - abs(dx)
                oy = (a[2] + b[2]) * 0.5 - abs(dy)
                if ox > 0 and oy > 0:
                    # minimal separation axis
                    if ox < oy:
                        push = ox * 0.5
                        if dx >= 0:
                            a[0] -= push
                            b[0] += push
                        else:
                            a[0] += push
                            b[0] -= push
                    else:
                        push = oy * 0.5
                        if dy >= 0:
                            a[1] -= push
                            b[1] += push
                        else:
                            a[1] += push
                            b[1] -= push
        # keep inside again
        for a in sq:
            h = min(a[2] * 0.5, 0.5)
            a[0] = min(max(a[0], h), 1.0 - h)
            a[1] = min(max(a[1], h), 1.0 - h)

    return [(a[0], a[1], 0.0, max(a[2], 0.0)) for a in sq]
# EVOLVE-BLOCK-END

