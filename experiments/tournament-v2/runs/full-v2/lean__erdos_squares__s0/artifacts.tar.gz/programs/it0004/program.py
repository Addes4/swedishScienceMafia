# EVOLVE-BLOCK-START
"""General square packing method.

Strategy: a square can be subdivided into a set of axis-aligned rectangles arranged
in a "guillotine" layout (recursively cut a rectangle by a vertical or horizontal
line).  Within each leaf rectangle we may also place smaller axis-aligned squares.

We search over several structured families:
  1. The best equal-grid (b rows, c columns) layout.
  2. "One big square" layouts: a large square in a corner plus a grid in the
     remaining L-shaped region.
  3. Wasteful strip layouts: split the unit square into an integer grid of
     cells, keep cells as squares of varying sizes.
  4. Randomized multi-size greedy packing (bottom-left) as refinement.

We greedily keep the best total side length over all families.
"""
import math
import random


def _grid_solution(n):
    best_total = -1.0
    best = None
    for b in range(1, n + 1):
        c = (n + b - 1) // b
        side = min(1.0 / c, 1.0 / b)
        total = side * n
        if total > best_total:
            best_total = total
            best = (b, c, side)
    b, c, side = best
    squares = []
    count = 0
    for j in range(b):
        for i in range(c):
            if count >= n:
                break
            cx = (i + 0.5) * (1.0 / c)
            cy = (j + 0.5) * (1.0 / b)
            squares.append((cx, cy, 0.0, side))
            count += 1
    return squares[:n]


def _can_place(rect, others, tol=1e-12):
    x0, y0, s = rect
    if x0 < -tol or y0 < -tol or x0 + s > 1 + tol or y0 + s > 1 + tol:
        return False
    x1, y1 = x0 + s, y0 + s
    for (a, b, t) in others:
        ax1, by1 = a + t, b + t
        if x0 < ax1 - tol and a < x1 - tol and y0 < by1 - tol and b < y1 - tol:
            return False
    return True


def _greedy_pack(sizes):
    placed = []
    for s in sizes:
        if s <= 1e-12:
            continue
        xs = {0.0}
        ys = {0.0}
        for (a, b, t) in placed:
            xs.add(a + t)
            ys.add(b + t)
            xs.add(a)
            ys.add(b)
        cand = []
        for X in xs:
            for Y in ys:
                if _can_place((X, Y, s), placed):
                    cand.append((X, Y))
        if not cand:
            return None
        cand.sort(key=lambda p: (p[1], p[0]))
        X, Y = cand[0]
        placed.append((X, Y, s))
    return placed


def _seq_to_squares(placed):
    return [(x0 + s / 2.0, y0 + s / 2.0, 0.0, s) for (x0, y0, s) in placed]


# ---------- structured families ----------

def _big_plus_grid(n):
    """One big square in a corner, rest tiled in the remaining L-shape by a grid."""
    best = None
    best_total = -1.0
    # big square side a in [0, 1]; remaining region: (1-a) x 1 strip + a x (1-a) strip
    # or symmetric variants.  Try a range of a and count allocations.
    for a in [i / 200.0 for i in range(1, 200)]:
        rem = n - 1
        if rem < 0:
            continue
        # strip 1: width (1-a), height 1 -> p squares per column, q columns
        # strip 2: width a, height (1-a) -> above the big square
        for p in range(1, rem + 1):
            q = (rem - p + 1)  # rough
            # distribute fits into (1-a)x1 and a x(1-a)
            for p1 in range(1, rem + 1):
                s1 = min((1 - a) , 1.0)
                # tile strip 1 with c1 cols, r1 rows
                for c1 in range(1, rem + 1):
                    w = (1 - a) / c1
                    r1 = int(1.0 / w)
                    if r1 < 1:
                        continue
                    cap1 = c1 * r1
                    if cap1 > rem:
                        cap1 = rem
                    need = rem - cap1
                    if need <= 0:
                        if cap1 == rem:
                            total = a + w * rem * 0 + 0
                        continue
                    # fill remaining in strip 2 of size a x (1-a)
                    if a <= 1e-9 or (1 - a) <= 1e-9:
                        continue
                    s2 = a
                    # squares in strip2: c2 cols, r2 rows using size (something)
                    for c2 in range(1, need + 1):
                        w2 = a / c2
                        r2 = int((1 - a) / w2)
                        if r2 < 1:
                            continue
                        cap2 = c2 * r2
                        if cap2 >= need:
                            # all fit at size w2
                            total = a + w * min(cap1, rem) + 0
                            # compute properly
                            pass
                    # direct: use w2 = a/c2 with cap2 >= need
                    ok = False
                    total = 0.0
                    for c2 in range(1, need + 1):
                        w2 = a / c2
                        r2 = int((1 - a) / w2 + 1e-9)
                        if r2 >= 1 and c2 * r2 >= need:
                            ok = True
                            total = a + w * cap1 + w2 * need
                            break
                    if ok:
                        # build
                        placed = [(0.0, 0.0, a)]
                        cnt = 1
                        # strip1 cells
                        used1 = 0
                        for j in range(r1):
                            for i in range(c1):
                                if used1 >= cap1 or cnt >= n:
                                    break
                                placed.append((a + i * w, j * w, w))
                                used1 += 1
                                cnt += 1
                        used2 = 0
                        for j in range(r2):
                            for i in range(c2):
                                if used2 >= need or cnt >= n:
                                    break
                                placed.append((i * w2, 1 - a - (j + 1) * w2 + 0, w2))
                                used2 += 1
                                cnt += 1
                        if total > best_total and len(placed) == n:
                            # validate
                            if _valid(placed):
                                best_total = total
                                best = placed
    return best


def _valid(placed):
    for i in range(len(placed)):
        x0, y0, s = placed[i]
        if x0 < -1e-9 or y0 < -1e-9 or x0 + s > 1 + 1e-9 or y0 + s > 1 + 1e-9:
            return False
        for j in range(i + 1, len(placed)):
            a, b, t = placed[j]
            if x0 < a + t - 1e-9 and a < x0 + s - 1e-9 and y0 < b + t - 1e-9 and b < y0 + s - 1e-9:
                return False
    return True


def _tile_rect(w, h, count):
    """Place `count` axis-aligned squares inside a w x h rectangle, offset (0,0).
    Return list of (x0, y0, s) or None.  Use a grid of equal squares."""
    if count <= 0:
        return []
    # choose cols to maximise size
    best = None
    best_s = -1.0
    for cols in range(1, count + 1):
        rows = (count + cols - 1) // cols
        s = min(w / cols, h / rows)
        if s > best_s:
            best_s = s
            best = (cols, rows, s)
    cols, rows, s = best
    out = []
    cnt = 0
    for j in range(rows):
        for i in range(cols):
            if cnt >= count:
                break
            out.append((i * s, j * s, s))
            cnt += 1
    return out


def _guillotine_search(n, best_so_far, rng, budget=400):
    """Random guillotine partition of the unit square into leaves, tile leaves."""
    best = None
    best_total = best_so_far
    for _ in range(budget):
        # build a random binary partition
        leaves = [(0.0, 0.0, 1.0, 1.0, 0)]  # x,y,w,h,depth
        target_leaves = rng.randint(2, min(n, 6))
        for _ in range(target_leaves - 1):
            # pick a leaf weighted by area to split
            idx = rng.randrange(len(leaves))
            x, y, w, h, d = leaves.pop(idx)
            if w >= h:
                # split vertically
                if w < 1e-6:
                    leaves.append((x, y, w, h, d))
                    continue
                f = rng.uniform(0.3, 0.7)
                leaves.append((x, y, w * f, h, d + 1))
                leaves.append((x + w * f, y, w * (1 - f), h, d + 1))
            else:
                if h < 1e-6:
                    leaves.append((x, y, w, h, d))
                    continue
                f = rng.uniform(0.3, 0.7)
                leaves.append((x, y, w, h * f, d + 1))
                leaves.append((x, y + h * f, w, h * (1 - f), d + 1))
        if len(leaves) > n:
            continue
        # distribute n squares among leaves
        cnts = [1] * len(leaves)
        rem = n - len(leaves)
        if rem < 0:
            continue
        while rem > 0:
            idx = rng.randrange(len(leaves))
            cnts[idx] += 1
            rem -= 1
        # tile each leaf
        placed = []
        ok = True
        total = 0.0
        for (x, y, w, h, d), cnt in zip(leaves, cnts):
            tiles = _tile_rect(w, h, cnt)
            if tiles is None:
                ok = False
                break
            for (tx, ty, s) in tiles:
                placed.append((x + tx, y + ty, s))
                total += s
        if not ok or len(placed) != n:
            continue
        if total > best_total and _valid(placed):
            best_total = total
            best = placed
    return best


def _try_sequences(n, rng, tries):
    best = None
    best_total = -1.0
    for _ in range(tries):
        sizes = []
        k_big = rng.randint(0, max(0, min(3, n)))
        for _ in range(k_big):
            sizes.append(rng.uniform(0.3, 1.0))
        while len(sizes) < n:
            sizes.append(rng.uniform(0.05, 0.6))
        sizes = sizes[:n]
        sizes.sort(reverse=True)
        placed = _greedy_pack(sizes)
        if placed is None:
            continue
        total = sum(p[2] for p in placed)
        if total > best_total:
            best_total = total
            best = placed
    return best


def solve(n):
    if n <= 0:
        return []
    squares = _grid_solution(n)
    best_total = sum(s[3] for s in squares)

    rng = random.Random(12345 + n)

    # structured guillotine search
    placed = _guillotine_search(n, best_total, rng, budget=600)
    if placed is not None:
        total = sum(p[2] for p in placed)
        if total > best_total:
            best_total = total
            squares = _seq_to_squares(placed)

    # random greedy sequences
    for tries in (300, 300):
        placed = _try_sequences(n, rng, tries)
        if placed is not None:
            total = sum(p[2] for p in placed)
            if total > best_total:
                best_total = total
                squares = _seq_to_squares(placed)
    return squares[:n]
# EVOLVE-BLOCK-END
