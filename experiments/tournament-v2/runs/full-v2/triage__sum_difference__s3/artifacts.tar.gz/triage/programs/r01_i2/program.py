# NEW PROGRAM
"""Construct a set A where sums are controlled (few collisions, ideally Sidon) and differences
are as large as possible by using points from a 2-dimensional progression, then fine-tune."""

import math
import random
import time
from itertools import combinations, product

def score_set(A):
    """Compute score of a set."""
    sA = set(A)
    if len(sA) < 2:
        return 0.0
    diffs = set()
    sums = set()
    for a in sA:
        for b in sA:
            diffs.add(a - b)
            sums.add(a + b)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(sA)) / 100

def build_sidon_like(n, max_val=200):
    """
    Build a set of size n with small sumset and large diffset using a scaled Singer/Bose construction.
    Returns list of ints.
    Based on Bose construction for B_2 sequences modulo q^2-1.
    """
    # Find prime power q such that q+1 >= n.
    q = 2
    while q + 1 < n:
        q += 1
        while not (q == 2 or (q % 2 != 0 and all(q % d != 0 for d in range(3, int(math.isqrt(q)) + 1, 2)))):
            q += 1
    # q is prime or prime power, here we handle prime only for simplicity.
    mod = q**2 - 1
    # Primitive element: use smallest generator.
    def prime_factors(n):
        i = 2
        factors = set()
        while i * i <= n:
            while n % i == 0:
                factors.add(i)
                n //= i
            i += 1
        if n > 1:
            factors.add(n)
        return factors
    phi = mod
    for p in prime_factors(mod):
        phi = phi // p * (p-1)
    # Find generator
    g = None
    for candidate in range(2, mod):
        if math.gcd(candidate, mod) != 1:
            continue
        ok = True
        for f in prime_factors(phi):
            if pow(candidate, phi//f, mod) == 1:
                ok = False
                break
        if ok:
            g = candidate
            break
    if g is None:
        # fallback to simpler construction
        res = set()
        for a in range(q):
            res.add(a * (mod + 1) + 1)  # dummy
        return list(res)[:n]
    # Bose: exponents 0..q encode as powers of g, plus base point.
    elems = []
    for i in range(q+1):
        val = pow(g, i, mod)
        elems.append(val)
    # We have q+1 elements with property that all differences distinct modulo mod.
    # Scale up to make sums controlled and differences larger.
    # Multiply by M so that sums are far apart and differences expand.
    M = max_val // mod
    scaled = [x * M for x in elems[:n]]
    return scaled

def diversify_differences(A, tries=20000, max_delta=50):
    """Local search to maximize diff size while preserving sum set size."""
    best = A[:]
    best_score = score_set(best)
    set_size = len(A)
    for _ in range(tries):
        i = random.randrange(set_size)
        old = best[i]
        delta = random.randint(-max_delta, max_delta)
        if delta == 0:
            delta = 1
        best[i] += delta
        # ensure uniqueness
        if len(set(best)) != set_size:
            best[i] = old
            continue
        sc = score_set(best)
        if sc > best_score:
            best_score = sc
        else:
            best[i] = old
    return best

def solve():
    deadline = time.time() + 115
    best_A = [0, 1, 2, 4, 7, 12]  # initial guess
    best_score = score_set(best_A)
    
    # Strategy: try different sizes, build Sidon-like sets, optimize.
    for n in range(10, 100, 5):
        if time.time() > deadline:
            break
        # Generate base set with controlled sums
        base = build_sidon_like(n, max_val=500)
        # Ensure distinct
        base = list(set(base))
        if len(base) < 2:
            continue
        # Increase differences by pushing elements apart while keeping sums small.
        # Idea: multiply by a large factor and add small perturbations.
        factor = 1000000 // max(abs(x) for x in base) if base else 1
        scaled = [x * factor for x in base]
        # Add small random offsets
        for i in range(len(scaled)):
            scaled[i] += random.randint(-100, 100)
        scaled = diversify_differences(scaled, tries=1000, max_delta=50)
        sc = score_set(scaled)
        if sc > best_score:
            best_score = sc
            best_A = scaled[:]
    
    # Further optimize the best found
    best_A = diversify_differences(best_A, tries=20000, max_delta=200)
    
    # Ensure within limits: at most 4000 elements, abs <= 1e15.
    best_A = [x for x in best_A if abs(x) <= 10**15]
    if len(best_A) > 4000:
        best_A = best_A[:4000]
    
    return sorted(set(best_A))

