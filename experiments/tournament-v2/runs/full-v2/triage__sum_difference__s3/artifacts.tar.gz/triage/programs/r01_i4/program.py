import math
import random
import time

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _initial_set():
    """Generate a good initial set using a Ruzsa-style construction.
    Based on: A = { floor(alpha * i) % M : i in range(N) } where alpha is irrational.
    This often yields a set with many differences but relatively few sums."""
    n = 300  # target size, will be pruned for uniqueness
    M = 10**12
    alpha = (math.sqrt(5) - 1) / 2  # golden ratio conjugate
    a = []
    seen = set()
    for i in range(2 * n):  # oversample to get enough unique values
        val = int(math.floor(alpha * i * M) % M) - M // 2  # center around 0
        if val not in seen:
            seen.add(val)
            a.append(val)
            if len(a) >= n:
                break
    # Also add some smaller variations to increase size
    for i in range(len(a)):
        if random.random() < 0.3:
            a.append(a[i] + random.randint(-10, 10))
    return sorted(set(a))[:600]  # limit to 600 to keep computation manageable

def solve():
    random.seed(42)  # for reproducibility
    best = _initial_set()
    best_score = _score(best)
    cur = best[:]
    
    start_temp = 0.2
    end_temp = 0.001
    deadline = time.time() + 119  # slight margin
    
    # Simulated annealing
    while time.time() < deadline:
        # Adaptive temperature based on remaining time
        elapsed = 119 - (deadline - time.time())
        progress = elapsed / 119
        temp = start_temp * (end_temp / start_temp) ** progress
        
        cand = cur[:]
        
        # Higher mutation rates for broader exploration
        for _ in range(random.randint(1, len(cand) // 20 + 1)):
            i = random.randrange(len(cand))
            cand[i] += random.randint(-10, 10)
        
        if random.random() < 0.1:
            cand.append(random.randint(-1000, 1000))
        if random.random() < 0.05 and len(cand) > 200:
            cand.pop(random.randrange(len(cand)))
        
        # Occasionally add small structured perturbations (like a mini Ruzsa shift)
        if random.random() < 0.02:
            shift = random.randint(1, 50)
            cand = [(x + shift) for x in cand]
        
        # Deduplicate while preserving order
        cand = list(set(cand))
        if len(cand) < 10:
            cand = best[:]  # avoid degenerate sets
            continue
            
        s = _score(cand)
        delta = s - best_score
        
        if delta > 0:
            best = cand[:]
            best_score = s
            cur = cand[:]
        elif random.random() < math.exp(delta / temp):
            cur = cand[:]
        else:
            # Occasionally reset to best to avoid getting stuck
            if random.random() < 0.01:
                cur = best[:]
    
    # Final cleanup: ensure distinct, within limits
    final = sorted(set(best))
    return final[:4000]  # respect max size constraint