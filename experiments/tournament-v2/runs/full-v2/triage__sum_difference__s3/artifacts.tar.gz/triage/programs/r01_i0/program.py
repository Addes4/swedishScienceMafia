# EVOLVE-BLOCK-START
"""Geometric-progression style construction with tuning and pruning."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            bj = a[j]
            diffs.add(ai - bj)
            sums.add(ai + bj)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(d, base, mult):
    """A = { sum a_j * base^(j) * mult : 0<=a_j<mult } with digit sum balancing."""
    A = [0]
    step = 1
    for _ in range(d):
        newA = []
        w = step * base
        for x in A:
            for k in range(mult):
                newA.append(x + k * w)
        A = newA
        step = w * mult
    return A


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 110

    # Try a range of parameters for the geometric / mixed-radix progression.
    trials = []
    for d in range(1, 10):
        for base in range(2, 14):
            maxn = 4000
            # choose n so |A| = n^d <= 4000
            n = 2
            while (n + 1) ** d <= maxn:
                n += 1
            if n < 2:
                continue
            trials.append((d, base, n))

    random.seed(12345)
    random.shuffle(trials)

    for d, base, n in trials:
        if time.time() > deadline:
            break
        # Build progression: digits distinct primes scaling won't help score; use
        # powers of a base but allow a rational shift to compress sums.
        A = _build(d, base, n)
        # Normalize/perturb
        for attempt in range(3):
            cand = A[:]
            if attempt:
                # small random perturbation to break worst collisions
                k = len(cand)
                for _ in range(k // 20 + 1):
                    idx = random.randrange(k)
                    cand[idx] += random.randint(-2, 2)
                cand = list(set(cand))
            s = _score(cand)
            if s > best_score:
                best_score = s
                best = cand[:]

    # Greedy pruning: try removing elements that reduce sum-set size without
    # hurting difference-set too much.
    if best is not None and time.time() < deadline:
        cur = sorted(set(best))
        cur_score = _score(cur)
        for _ in range(2000):
            if time.time() > deadline:
                break
            if len(cur) < 3:
                break
            idx = random.randrange(len(cur))
            trial = cur[:idx] + cur[idx + 1:]
            s = _score(trial)
            if s > cur_score:
                cur, cur_score = trial, s
            elif random.random() < 0.05:
                cur, cur_score = trial, s
        if cur_score > best_score:
            best, best_score = cur, cur_score

    if best is None:
        best = [0, 1]
    return sorted(set(best))
# EVOLVE-BLOCK-END
