import math
import random
import time
from functools import lru_cache


def _score(a):
    """Calculate objective function value for a set A."""
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    ratio = math.log(len(diffs)) / math.log(len(sums))
    size_bonus = (1 - 1 / len(a)) / 100
    return ratio + size_bonus


def score_set(a):
    """Score evaluation with caching."""
    a_sorted = tuple(sorted(a))
    @lru_cache(maxsize=1000)
    def helper(a_tuple):
        if len(a_tuple) < 2:
            return 0.0, {}, {}
        score = _score(list(a_tuple))
        return score, {x - y: set() for x in a_tuple for y in a_tuple}, {x + y: set() for x in a_tuple for y in a_tuple}
    return helper(a_sorted)[0]


def generate_random_set(n, base, max_val):
    """Generate a random structured set."""
    values = set()
    base = base
    max_val = max_val
    for _ in range(n):
        candidate = base * random.randint(1, max_val // base + 1)
        if candidate in values:
            continue
        values.add(candidate)
    return list(values)


def generate_arithmetic_set(start, diff, n):
    """Generate an arithmetic progression set."""
    return sorted([start + i * diff for i in range(n)])


def generate_mixed_set(n):
    """Generate a mixed structured set."""
    elements = set()
    for k in range(n):
        v = 2**random.randint(4, 6) * (2 * k + 1)
        elements.add(v)
    return sorted(elements)


def score_crossover(parent_a, parent_b):
    """Crossover: union of random subsets of parents."""
    if len(parent_a) < 2 or len(parent_b) < 2:
        return parent_a[:]
    p_a = set(parent_a)
    p_b = set(parent_b)
    n = (len(p_a) + len(p_b)) // 2
    cand = random.sample(list(p_a.union(p_b)), min(n, len(p_a.union(p_b))))
    if random.random() < 0.5:
        cand = sorted(p_a.intersection(p_b))[:n]
    return sorted(set(cand))


def mutate_set(cand):
    """Apply small mutations to the set."""
    result = set(cand)
    n = random.randint(0, 3)
    for _ in range(n):
        if result:
            idx = random.randint(0, len(result) - 1)
            val = result[idx]
            if random.random() < 0.4:
                val += random.randint(-10, 10)
            else:
                val *= random.choice([-1, 1]) + 1
            if abs(val) <= 1e15 and val not in result:
                result[idx] = val
    if random.random() < 0.2:
        if random.random() < 0.5:
            result.add(random.randint(1000, 100000))
        else:
            result.discard(random.choice(list(result)) if result else None)
    return sorted(set(result))


def generate_pool_elements(n):
    """Generate a pool of structured elements."""
    base = random.choice([3, 5, 7, 11, 13])
    vals = set()
    for i in range(n):
        val = base * (i + 1)
        if val > 1e15:
            break
        vals.add(val)
    if random.random() < 0.5:
        vals.update(generate_random_set(n // 2, 2, 1e13))
    return sorted(list(vals))


def solve():
    """Main genetic algorithm solver."""
    limit = 120.0
    deadline = time.time() + limit
    pool = generate_pool_elements(50)
    
    # Initial population creation
    pop_size = 40
    population = []
    best_score = -1
    best_set = []
    
    random.seed(42)
    initial_sets = []
    for k in range(pop_size):
        if k % 5 == 0:
            s = generate_arithmetic_set(random.randint(1, 100), random.choice([1, 2, 5]), random.randint(5, 20))
        elif k % 3 == 0:
            s = generate_mixed_set(random.randint(5, 25))
        else:
            s = generate_random_set(random.randint(5, 25), random.choice([3, 5, 7]), random.randint(100, 1000))
        s = sorted(set(s))
        if 5 <= len(s) <= 40 and max(abs(x) for x in s) <= 1e15:
            population.append(s)
            if _score(s) > best_score:
                best_score = _score(s)
                best_set = s[:]
    
    iteration = 0
    while time.time() < deadline:
        # Evaluate population
        fitness = []
        for s in population:
            sc = _score(s)
            fitness.append((sc, s))
        
        sorted_fitness = sorted(fitness, reverse=True)
        best_score, best_set = sorted_fitness[0]
        
        # Inject new elements from pool occasionally
        if random.random() < 0.05:
            new_pool_set = random.sample(pool, min(30, len(pool)))
            for s in population[:min(5, len(population))]:
                s.extend(new_pool_set)
                s = sorted(set(s))
            population = population[-pop_size:]
        
        # Generate new sets from crossover + mutation
        new_pop = []
        iterations_since_pool = 0
        
        # Elitism: keep top performers
        top_k = 5
        for i in range(top_k):
            if i < all_sets:
                new_pop.append(sorted(set(suffix[i])))
        
        # Age selection: crossover parents
        for _ in range(pop_size - top_k):
            p1 = sorted_fitness[random.randint(0, len(sorted_fitness) - 1)][1]
            p2 = sorted_fitness[random.randint(0, len(sorted_fitness) - 1)][1]
            child = score_crossover(p1, p2)
            if child and 5 <= len(child) <= 40:
                child = mutate_set(child)
            if child and 5 <= len(child) <= 40 and max(abs(x) for x in child) <= 1e15:
                new_pop.append(child)
        
        population = new_pop
        
        # Accept new best if improved
        if _score(best_set) > best_score:
            best_score = _score(best_set)
            
        # Continue optimization
        if random.random() < 0.01:
            for _ in range(10):
                m = mutate_set(best_set)
                if m and _score(m) > best_score:
                    best_score = _score(m)
                    best_set = m
        
        iteration += 1
        if iteration % 10 == 0:
            print(f"Iteration {iteration}, Score: {best_score:.6f}, Size: {len(best_set)}")
    
    # Final refinement
    final_best = best_set[:]
    for attempt in range(100):
        mutant = mutate_set(final_best)
        if mutant:
            if _score(mutant) > _score(final_best):
                final_best = mutant[:]
                continue
    
    return final_best


if __name__ == "__main__":
    result = solve()
    print(f"Result set: {result}")
    print(f"Length: {len(result)}")
    print(f"Max abs value: {max(abs(x) for x in result)}")
    print(f"Score: {_score(result)}")
