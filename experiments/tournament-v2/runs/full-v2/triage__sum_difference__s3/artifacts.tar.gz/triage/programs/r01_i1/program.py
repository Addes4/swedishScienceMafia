import math
import random
import time
import numpy as np
from sympy import sieve, isprime
from itertools import combinations, product

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    """
    Finds a finite set A of integers maximizing log|A - A| / log|A + A|.
    Uses a modular construction based on Singer difference sets 
    or quadratic residues in Z/pZ, then lifts to integers 
    with a carefully chosen interval to minimize sum collisions.
    """
    best_list = None
    best_score = 0.0
    deadline = time.time() + 110  # leave some margin

    # We'll try several strategies: Singer difference sets and quadratic residues
    # For each found modular set, we'll optimize the lift using local search
    
    # Strategy 1: Quadratic residues modulo a prime p where p ≡ 3 mod 4
    # This gives a set B with B - B covering all of Z/pZ except 0, and B + B = Z/pZ
    # But we can choose a subset to reduce sum set size while keeping diff set large
    
    def generate_quadratic_residue_set(p):
        """Returns set of quadratic residues modulo p (excluding 0)."""
        residues = set()
        for x in range(1, (p+1)//2):
            residues.add((x*x) % p)
        return residues

    # Strategy 2: Try to find a difference set with parameters (v, k, lambda)
    # For a (v, k, λ) difference set, every non-zero element appears exactly λ times as a difference
    # So diff set size = v, sum set size depends on structure
    # Singer difference sets: v = (q^{d+1}-1)/(q-1), k = (q^d-1)/(q-1), λ = (q^{d-1}-1)/(q-1)
    # For q=2, d=2: v=7, k=3, λ=1 (the Fano plane)
    # For q=3, d=2: v=13, k=4, λ=1
    # For q=2, d=3: v=15, k=7, λ=3
    # For q=2, d=4: v=31, k=15, λ=7
    # For q=3, d=3: v=40, k=13, λ=4
    # Let's generate some Singer sets
    
    def generate_singer_set(q, d):
        """Generate Singer difference set in Z/vZ where v = (q^{d+1}-1)/(q-1)."""
        # Using finite field GF(q^{d+1}) and its multiplicative group
        # The points of PG(d, q) correspond to lines through origin
        v = (q**(d+1) - 1) // (q - 1)
        
        # We need a primitive polynomial to construct the field
        # For simplicity, we'll use known Singer sets for small parameters
        known_singer = {
            (2, 2): [0, 1, 3],  # v=7
            (2, 3): [0, 1, 2, 4, 5, 8, 10],  # v=15
            (2, 4): [0, 1, 2, 3, 5, 7, 8, 11, 12, 13, 17, 19, 20, 26, 29],  # v=31
            (3, 2): [0, 1, 3, 9],  # v=13
        }
        
        if (q, d) in known_singer:
            return set(known_singer[(q, d)])
        
        # For other parameters, we'll construct using finite field arithmetic
        mod = v
        # Find primitive root modulo v? Actually need field of size q^{d+1}
        # This is complex; we'll skip for now and use known sets
        return None

    # Actually, we can construct multiplicative subgroups in Z/pZ for a prime p
    # Let H be a subgroup of order k in (Z/pZ)^*. Then H is a (p, k, λ) difference set where
    # λ = k(k-1)/(p-1). But we want a set with small sum set.
    # Instead, we can take a set of the form {g^i : i in I} for some generator g and index set I
    # With careful choice of I, we can get good ratio

    def evaluate_modular_set(p, B):
        """Evaluate a set B in Z/pZ by lifting to integers with an interval parameter L."""
        # We try different lifts: mapping each residue to an integer in [c*p, c*p + L]
        # where L < p. This ensures differences are roughly preserved but sums can collide.
        n = len(B)
        if n < 2:
            return None, 0.0
        
        # Convert B to list
        B_list = sorted(B)
        
        best_lift_score = 0.0
        best_lift_set = None
        
        # Try several center positions and interval sizes
        # The idea: translate B by some offset t, then map to [t, t+L] mod p
        # Actually, we want each element x in B to be mapped to an integer f(x) such that
        # f(x) is close to some base * p + x, to preserve differences mod p
        # More precisely, let f(x) = x + k_x * p where k_x are chosen to minimize |f(x) - f(y)| for sums
        # We can set f(x) = x + c * p where c is a common constant. This preserves differences exactly!
        # But then A - A size = p (all non-zero diffs appear) and A + A size = 2p-1 (all sums appear twice)
        # That gives log(p)/log(2p-1) ≈ 1. Not great.
        
        # Better: we can choose k_x not all equal. For instance, take residues in [0, p-1]
        # and add multiples of p to make sums collide.
        # Let's think: we want small sum set. If we take all f(x) in a short interval [M, M+L] with L < p,
        # then sums lie in [2M, 2M+2L], size at most 2L+1, while differences lie in [-L, L], size 2L+1.
        # But we want many differences! So we need L large enough.
        # Actually, if we map B to a set A of integers that are all congruent to elements of B mod p,
        # and A is contained in an interval of length L, then:
        # - Differences: for each d in Z/pZ that can be represented as b1 - b2, the corresponding difference
        #   in A is (b1 + k1*p) - (b2 + k2*p) = (b1 - b2) + (k1 - k2)*p. If we restrict k_i to a small set,
        #   each modular difference can appear with several integer differences.
        # - Sums: sums are (b1 + b2) + (k1 + k2)*p. To minimize sum set size, we want many pairs to have
        #   same (b1+b2 mod p) and also same (k1+k2).
        
        # Approach: Use a small number of "levels". Choose a base M, and for each b in B, 
        # assign a level L_b from a small set S, and set a = M + b + L_b * p.
        # Then differences are (b1 - b2) + (L1 - L2)*p
        # Sums are (b1 + b2) + (L1 + L2)*p + 2M
        # The sum set size depends on collisions in (b1+b2, L1+L2).
        # We can optimize the assignment of levels.
        
        # For now, let's try a simpler approach: take B itself as a subset of [0, p-1], then
        # shift by a multiple of p to separate differences into distinct congruence classes.
        # That is, A = {b + k*b*p : b in B} for some integer k? That's not good.
        
        # Actually, the Singer difference sets have the property that every non-zero difference appears
        # exactly once. So if we lift them directly, diff set size = v, sum set size is about 2v.
        # Ratio log(v)/log(2v) ≈ 1 (since log(v)/log(2v) ~ 1 for large v).
        # But we can do better by using a smaller subset of the Singer set? No, that reduces diff size.
        
        # We need a set where differences cover many values but sums cover few.
        # In Z/pZ, consider set B = {0, 1, 3} mod 7. 
        # Differences: ±1, ±2, ±3, mod 7 -> {1,2,3,4,5,6} (6 diffs)
        # Sums: {0,1,2,3,4,5,6} (all 7 sums) -> log6/log7 ≈ 0.92
        # With lifting, if we take A = B + 7*{0,1} = B ∪ (B+7), then sums have many collisions.
        # Let's implement a systematic search over levels.
        
        # Brute force approach for small B: try all assignments of levels from {0,1} and evaluate actual integer set.
        # But B might be large. We'll use a heuristic: 
        # Given B, we construct A = {b + level[b]*p} where level[b] is chosen to minimize sum collisions.
        # Since p is large, differences with different (level1 - level2) are far apart.
        # This means A - A size ≈ |B - B| * |L - L| where L is the set of levels used.
        # And A + A size = |{ (b1+b2 mod p, l1+l2) }|. If we can make l1+l2 take few values, 
        # and also b1+b2 take few values mod p, sum set is small.
        # With levels {0,1}, L-L = {-1,0,1} (3 values), L+L = {0,1,2} (3 values).
        # So A-A size ≈ 3 * |B - B|, A+A size ≈ 3 * |B + B| (if no coincidences mod p).
        # Ratio ~ log(3|D|)/log(3|S|). Slightly better if |S| smaller than |D|.
        # With more levels, we can tune.
        
        # For B being a Singer set (v large, D = v, S ≈ 2v), ratio log(v*3)/log(2v*3) ~ 1.
        # Need B such that |B+B| / |B-B| is very small. 
        # In Z/pZ, the set of quadratic residues has B-B = whole non-zero if p ≡ 3 mod 4, B+B = whole set.
        # But we can take a subset that breaks the additive structure.
        
        # Let's try to find sets where sumset is small by using arithmetic progression structure?
        
        # Alternative idea: Use a set that is an arithmetic progression modulo p.
        # If B = {0, d, 2d, ..., (k-1)d}, then B-B = { - (k-1)d, ..., (k-1)d } mod p. Size min(2k-1, p).
        # B+B = {0, d, 2d, ..., 2(k-1)d} mod p. Size min(2k-1, p). Same size! Ratio 1.
        
        # Need B such that sumset is collapsed. This happens if B is a sum-free set (but we need sums, just few).
        # Actually, we need |B+B| as small as possible relative to |B|. The minimal possible is 2|B|-1 (if B is an arithmetic progression).
        # So ratio ~ log(|B-B|)/log(2|B|-1). To maximize, we need |B-B| large.
        # Maximum |B-B| for given |B| is when B is a Sidon set (all differences distinct). Then |B-B| = |B|(|B|-1)+1.
        # But then B+B is usually large, roughly |B|^2/2. Ratio log(|B|^2)/log(|B|^2) ~ 1.
        # So we need something in between.
        
        # Known construction: consider B = {x_i} where x_i are elements of a finite field with small sumset.
        # For instance, in Z/pZ, take B as a geometric progression: {g^i : 0 <= i < k} for a primitive root g.
        # Then B-B has size about k^2 (Sidon-like for differences?), B+B also about k^2.
        # Not great.
        
        # Let's look at the known best score 1.28155. For reference, log|A-A|/log|A+A| = 1.28155 means
        # if |A-A| = D, |A+A| = S, then D = S^{1.28155}. So D is considerably larger than S.
        # Example: S=200, D ≈ 200^{1.28155} ≈ 200^{1.28} ≈ 200 * 200^{0.28} ≈ 200 * 4.2 ≈ 840. So |A-A|/|A+A| ~ 4.
        # In the modular construction with levels, if L-L = levels, and B-B large, we can get ratio.
        
        # Let's search over primes p and subsets B systematically using optimization.
        
        for L in range(2, min(6, n+1)):
            # Levels: we'll assign each element one of L consecutive integers (e.g., 0..L-1) 
            # and optimize assignment to minimize sumset.
            
            # Convert to an optimization problem: 
            # We want to maximize D/S ratio. D = |{b1 - b2 + (l1 - l2)*p}|
            # Since p is large, differences with different (l1 - l2) don't overlap.
            # So D = sum_{d in levels diff} |{ (b1 - b2) mod p : l1 - l2 = d }|
            # Actually, because p > max possible difference in b, and levels diff multiplies p,
            # the differences fall into separate intervals. So D = sum_{d} |B -_d B| where B -_d B = {b1 - b2 mod p : l1 - l2 = d}.
            # Similarly, sums S = sum_{s in level sum} |B +_s B| where B +_s B = {b1 + b2 mod p : l1 + l2 = s}.
            
            # So we can compute these counts independently for each level difference/sum.
            # The overall log-ratio is log(sum_d |B -_d B|) / log(sum_s |B +_s B|).
            
            # We can brute-force assignments for small n, but n up to ~4000. 
            # Instead, we can use a random assignment and then local optimization: swap levels to improve score.
            
            # Actually, the level assignment problem: given B (list of residues mod p), 
            # assign each b a level l(b) in [0, L-1] to maximize log(D)/log(S).
            
            # Since D and S are sums of sizes of difference/sum sets, we can compute quickly.
            # We'll use random start + hill climbing.
            
            # Precompute pairwise sums and differences mod p for all pairs (i,j) in B.
            # Then for a level assignment, for each d in diff set, we collect the set of (b_i - b_j) for pairs with l_i - l_j = d.
            # This can be done efficiently by iterating over all pairs? n up to 4000, pairs ~ 8e6, feasible within time if careful.
            
            # But we'll limit to smaller B for this exhaustive approach. We can also use the fact that 
            # if B is a difference set with λ=1, then every non-zero difference appears exactly once.
            # Then for any level assignment, |B -_d B| is exactly the number of pairs (i,j) with l_i - l_j = d and b_i ≠ b_j (plus 1 for 0 difference).
            # Actually, each non-zero difference mod p appears exactly once, so for each d, the set of b_i - b_j mod p is exactly the set of all non-zero elements that appear for some pair with level diff d.
            # That means |B -_d B| = min(v, number of pairs with l_i - l_j = d) approximately.
            # Similar for sums? Not necessarily.
            
            # For a general B, we can still compute.
            
            # Because of time constraints, we'll try a few primes and Singer-like sets.
            pass  # we'll handle later
        
        # Simplified direct approach: take B as a set of residues, then lift to integers 
        # by adding random multiples of p in a small range, and use local search to optimize the actual score.
        # This might be more efficient for moderate sizes.
        
    # Strategy: Generate a good set in Z/pZ, then lift to integers using a small number of levels,
    # and further optimize the integer set using local search (mutations).
    
    # We'll test several primes and modular sets.
    
    # First, some precomputed good modular sets:
    # For each prime p, we'll try subsets that have large difference set and small sum set.
    # We can search for them using random subsets and local search mod p, but that's time-consuming.
    # Known fact: The set of squares is a difference set when p ≡ 3 mod 4. For p ≡ 1 mod 4, -1 is a square, so differences don't cover all.
    # Let's use Singer sets and quadratic residues.
    
    # Also, we can use the set of "Paley difference set": quadratic residues in GF(q) for q ≡ 3 mod 4.
    # For q prime p, B = QR(p) has size (p-1)/2. B-B = all non-zero elements (each appears (p-3)/4 times?) Actually, for p≡3 mod 4, -1 is non-residue, so difference of two residues is a residue? Wait:
    # For p≡3 mod 4, the Legendre symbol (-1) = -1. The difference set property: every non-zero element appears exactly (p-3)/4 times as difference of two distinct squares. Wait, let's verify:
    # The number of pairs (x,y) of residues is ((p-1)/2)^2. The number of non-zero elements is p-1. If each appears equally often, appearance count = ((p-1)/2)^2 / (p-1) = (p-1)/4. But 0 difference appears (p-1)/2 times. So average non-zero appearance is (p-1)/4. For p≡3 mod 4, it's indeed a difference set? No, a difference set requires every non-zero element appear the same number of times. For Paley construction, it's a difference set with parameters (p, (p-1)/2, (p-3)/4) when p≡3 mod 4. So it's a difference set!
    # So B = QR(p) is a (p, (p-1)/2, (p-3)/4) difference set. Then |B-B| = p (since every non-zero appears, and 0 appears). |B+B| ? Not a difference set for sums.
    # For a Paley difference set, we can compute sum set size mod p. Often it's large.
    
    # Let's compute for a given p, the sumset of QR(p).
    
    def compute_mod_sizes(p, B):
        """Given a set B mod p, compute size of B-B and B+B mod p."""
        B_set = set(B)
        diff_set = set()
        sum_set = set()
        B_list = list(B_set)
        for i in range(len(B_list)):
            bi = B_list[i]
            for j in range(i, len(B_list)):
                bj = B_list[j]
                diff_set.add((bi - bj) % p)
                diff_set.add((bj - bi) % p)
                sum_set.add((bi + bj) % p)
        return len(diff_set), len(sum_set)
    
    # Test some primes:
    candidates = []
    # Only consider primes that are not too large (B size manageable for lifting)
    # We'll generate primes up to ~2000
    primes = list(sieve.primerange(7, 1000))
    # Filter those ≡3 mod 4 for Paley
    paley_primes = [p for p in primes if p % 4 == 3]
    
    best_mod_ratio = 0
    best_mod_set = None
    best_p = None
    
    for p in paley_primes[:200]:  # limit for time
        B = generate_quadratic_residue_set(p)  # excludes 0, but we can add 0?
        # Adding 0 often improves difference set size but may affect sums.
        # Let's test with and without 0.
        for include_zero in [False, True]:
            test_B = set(B)
            if include_zero:
                test_B.add(0)
            if len(test_B) < 2:
                continue
            d_size, s_size = compute_mod_sizes(p, test_B)
            if s_size == 0: 
                continue
            ratio = math.log(d_size) / math.log(s_size)
            if ratio > best_mod_ratio:
                best_mod_ratio = ratio
                best_mod_set = test_B
                best_p = p
    
    # Also try Singer sets
    singer_params = [(2,2), (2,3), (2,4), (3,2)]
    for q,d in singer_params:
        B = generate_singer_set(q, d)
        if B is None:
            continue
        v = (q**(d+1) - 1)//(q - 1)
        d_size, s_size = compute_mod_sizes(v, B)
        if s_size == 0:
            continue
        ratio = math.log(d_size) / math.log(s_size)
        if ratio > best_mod_ratio:
            best_mod_ratio = ratio
            best_mod_set = B
            best_p = v
    
    if best_mod_set is None:
        # fallback
        best_mod_set = {0,1,3}
        best_p = 7
    
    B_list = list(best_mod_set)
    n = len(B_list)
    p = best_p
    
    # Now we have a good modular set B in Z/pZ. We'll lift it to integers.
    # We'll use a small number of levels, say L = 5, and we'll try to assign levels to each element
    # to minimize sumset and maximize diffset in the lifted integer set.
    # Since n is moderate (up to ~500), we can afford to do some optimization.
    
    # The integer set will be A = { b + level[b]*p }  (we'll also add an offset to center)
    # We'll then apply local search to further improve score.
    
    # First, we need an initial level assignment. We'll start with random assignment, then hill climb.
    # To reduce complexity, we'll limit L to small values.
    
    max_L = min(20, n)
    best_lifted_score = 0
    best_A = None
    
    # Instead of exhaustive search, we'll try several random assignments and pick the best.
    for _ in range(50):  # number of restarts
        levels = [random.randrange(max_L) for _ in range(n)]
        # Convert to integer set
        A = [b + l * p for b, l in zip(B_list, levels)]
        # Add a global offset to shift around 0? Not needed, but can help if we later add mutations.
        # Score it
        s = _score(A)
        if s > best_lifted_score:
            best_lifted_score = s
            best_A = A[:]
    
    # Now perform local search on the best lifted set to refine
    # We'll do random mutations: change individual elements slightly, add/remove elements,
    # adjusting levels.
    
    if best_A is None:
        best_A = [0, 1]
    
    cur = best_A[:]
    cur_score = _score(cur)
    best_cur = cur[:]
    best_cur_score = cur_score
    
    # Local search parameters
    start_time = time.time()
    iter_count = 0
    while time.time() < deadline:
        cand = cur[:]
        # Random mutation
        idx = random.randrange(len(cand))
        old_val = cand[idx]
        # Change by a small multiple of p, or by small delta
        if random.random() < 0.5:
            cand[idx] += random.choice([-1, 1]) * random.randint(1, 3)  # small drift
        else:
            cand[idx] += random.choice([-1, 1]) * p * random.randint(1, 3)  # change level
        
        # Occasionally add an element
        if random.random() < 0.1 and len(cand) < 4000:
            # Add a new element derived from existing modulo p with a new level
            new_b = random.choice(B_list)
            new_level = random.randrange(max_L)
            cand.append(new_b + new_level * p)
        
        # Occasionally remove an element
        if random.random() < 0.05 and len(cand) > 5:
            cand.pop(random.randrange(len(cand)))
        
        # Ensure distinct
        if len(set(cand)) != len(cand):
            # Duplicates, skip
            continue
        
        s = _score(cand)
        if s > cur_score:
            cur = cand[:]
            cur_score = s
            if s > best_cur_score:
                best_cur = cand[:]
                best_cur_score = s
        elif random.random() < 0.2:
            # Allow downhill to escape local optimum
            cur = cand[:]
            cur_score = s
        
        iter_count += 1
        # Periodically restart from best_cur
        if iter_count % 1000 == 0:
            cur = best_cur[:]
            cur_score = best_cur_score
    
    # Final optimization: maybe we can improve by tweaking levels globally
    # Recompute levels assignment given current B modular structure
    
    # One more pass: try to balance size vs score
    candidate_set = best_cur
    return sorted(set(candidate_set))

if __name__ == "__main__":
    A = solve()
    print(f"Returned set of size {len(A)}, score {_score(A):.6f}")
