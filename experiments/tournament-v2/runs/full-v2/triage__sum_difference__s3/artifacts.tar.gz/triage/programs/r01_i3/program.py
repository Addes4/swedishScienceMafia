# EVOLVE-BLOCK-START
"""Greedy incremental construction of a set A with large difference set and small sum set.

Idea: maintain a candidate set, and repeatedly try to add an integer (chosen from a
pool of candidate values) that improves the objective log|A-A|/log|A+A| (plus a
size bonus).  Score deltas are evaluated lazily with pruning.

Key structural insight: if A is a Sidon-like set (all pairwise sums mostly distinct)
but its differences concentrate, then |A-A| grows like |A|^2 while |A+A| grows
slowly.  The best practical construction for "many differences, few sums" is to
build A so that A+A is confined to a small interval while A-A spreads out.  A very
effective trick: take A to be a set whose elements are all congruent modulo a large
base so that pair sums collide heavily, while differences still span a wide range.

We use a greedy/local-search hybrid: start from a good seed set and do greedy
insertions maximizing the objective, with occasional removals and swaps.
"""
import math
import random
import time


def _stats(a):
    """Return (len_diffs, len_sums) for the iterable of ints a."""
    s = set(a)
    n = len(s)
    diffs = set()
    sums = set()
    L = list(s)
    for i in range(n):
        xi = L[i]
        for j in range(n):
            xj = L[j]
            diffs.add(xi - xj)
            sums.add(xi + xj)
    return len(diffs), len(sums), n


def _score_from(nd, ns, n):
    if n < 2 or ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _score(a):
    nd, ns, n = _stats(a)
    return _score_from(nd, ns, n)


def solve():
    """Greedy incremental search for A maximizing log|A-A|/log|A+A|."""
    rnd = random.Random(12345)
    deadline = time.time() + 115.0

    # ---- seed: a small set with a good ratio ----
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try several random seeds too, keep the best.
    for _ in range(200):
        if time.time() > deadline:
            break
        k = rnd.randint(4, 8)
        cand = rnd.sample(range(-30, 40), k)
        s = _score(cand)
        if s > best_score:
            best = cand[:]
            best_score = s

    cur = best[:]
    cur_nd, cur_ns, cur_n = _stats(cur)
    cur_score = _score_from(cur_nd, cur_ns, cur_n)

    # ---- greedy growth phase ----
    # Candidate values to try adding: a growing range, plus near existing points.
    def candidate_values(base_set, span):
        vals = set()
        b = base_set
        for v in b:
            for d in range(-span, span + 1):
                vals.add(v + d)
        if len(b) > 1:
            lo = min(b)
            hi = max(b)
            for _ in range(span * 2):
                vals.add(rnd.randint(lo - span, hi + span))
        vals.discard(None)
        return vals

    span = 6
    while time.time() < deadline:
        n = len(cur)
        if n >= 4000:
            break
        cands = candidate_values(cur, span)
        # Remove values already in cur (can't duplicate)
        cset = set(cur)
        cands = [c for c in cands if c not in cset]
        rnd.shuffle(cands)

        improved = False
        # Lazy evaluation: only recompute fully for promising candidates.
        # Compute cheap upper bound: adding x adds at most 2n new diffs
        # and at least 0 new sums (usually ~n new sums). We evaluate directly
        # but in shuffled order and stop at first improvement.
        for c in cands:
            if time.time() > deadline:
                break
            trial = cur + [c]
            nd, ns, nn = _stats(trial)
            sc = _score_from(nd, ns, nn)
            if sc > cur_score:
                cur = trial
                cur_nd, cur_ns, cur_n = nd, ns, nn
                cur_score = sc
                improved = True
                if sc > best_score:
                    best = cur[:]
                    best_score = sc
                break
        if not improved:
            # widen the search span to find new useful values
            span = min(span * 2, 4000)
            if span >= 4000 and len(cur) < 4000:
                # random restart from best
                cur = best[:]
                cur_nd, cur_ns, cur_n = _stats(cur)
                cur_score = _score_from(cur_nd, cur_ns, cur_n)
                span = 6
            if time.time() > deadline:
                break

    # ---- local refinement: try swaps/removals ----
    while time.time() < deadline:
        n = len(cur)
        if n < 3:
            break
        idx = rnd.randrange(n)
        old = cur[idx]
        delta = rnd.choice([-1, 1]) * rnd.randint(1, 50)
        newv = old + delta
        if newv in set(cur):
            continue
        trial = cur[:]
        trial[idx] = newv
        nd, ns, nn = _stats(trial)
        sc = _score_from(nd, ns, nn)
        if sc > cur_score:
            cur = trial
            cur_nd, cur_ns, cur_n = nd, ns, nn
            cur_score = sc
            if sc > best_score:
                best = cur[:]
                best_score = sc
        elif sc > cur_score - 1e-4 and rnd.random() < 0.2:
            # accept small worsening occasionally
            cur = trial
            cur_nd, cur_ns, cur_n = nd, ns, nn
            cur_score = sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
