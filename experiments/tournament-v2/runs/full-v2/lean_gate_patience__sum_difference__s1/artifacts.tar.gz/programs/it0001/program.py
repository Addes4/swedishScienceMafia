# EVOLVE-BLOCK-START
"""Search for a set A with large difference set and small sum set.

Strategy:
  1) Build a structured candidate: take a few base values and combine them so that
     sums are heavily repeated but differences remain mostly distinct.
     A classic trick: A = { i*b + c } patterns, or use an arithmetic progression
     with a multiplicative offset to force sum collisions.
  2) Refine with hill climbing + simulated annealing using incremental scoring.
"""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score_vals(nd, ns, n):
    if ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    a = list(set(a))
    nd, ns = _stats(a)
    return _score_vals(nd, ns, len(a))


def solve():
    deadline = time.time() + 110
    random.seed(12345)

    # Candidate constructions.  We want sums small, diffs large.
    # A multiplicative set A = { x_i } where x_i are chosen so that the sums
    # x_i + x_j collide a lot but differences x_i - x_j are distinct.
    # One effective family: take a set that is nearly a Sidon set in differences
    # (B_2 for differences) and small in sums.

    def score_set(s):
        s = sorted(set(s))
        nd, ns = _stats(s)
        return _score_vals(nd, ns, len(s))

    best = None
    best_score = -1.0

    # --- structured seeds ---
    seeds = []

    # Seed 1: arithmetic-ish progression with small perturbations
    for k in (6, 7, 8, 9, 10):
        base = [i * 3 for i in range(k)]
        seeds.append(base)

    # Seed 2: geometric-like powers giving distinct differences
    for k in (6, 7, 8, 9):
        seeds.append([2 ** i for i in range(k)])

    # Seed 3: Sidon-like sets (all pairwise sums distinct-ish) -> actually we
    # want the opposite; try dense small sets
    seeds.append([0, 1, 2, 4, 8, 13])
    seeds.append([0, 1, 3, 7, 12, 20])

    for s in seeds:
        sc = score_set(s)
        if sc > best_score:
            best_score = sc
            best = sorted(set(s))

    # --- hill climbing with SA ---
    cur = best[:]
    cur_score = best_score
    t_start = time.time()

    while time.time() < deadline:
        frac = (time.time() - t_start) / max(0.001, deadline - t_start)
        # temperature schedule
        T = 0.02 * (1.0 - frac) + 0.0001

        cand = cur[:]
        r = random.random()
        if r < 0.35:
            # perturb an element
            i = random.randrange(len(cand))
            cand[i] += random.choice([-3, -2, -1, 1, 2, 3])
        elif r < 0.6:
            # add a new element near the existing range
            lo = min(cand)
            hi = max(cand)
            cand.append(random.randint(lo - 5, hi + 5))
        elif r < 0.75:
            # shift element far
            i = random.randrange(len(cand))
            cand[i] += random.randint(-30, 30)
        elif r < 0.9 and len(cand) > 4:
            # remove an element
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # duplicate-free random small tweak on multiple elements
            for _ in range(random.randint(1, 3)):
                i = random.randrange(len(cand))
                cand[i] += random.choice([-1, 1])

        cand = list(set(cand))
        if len(cand) < 4:
            continue
        s = score_set(cand)
        if s >= cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-9)) if s < cur_score else True:
            if s >= cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-9)):
                cur = cand
                cur_score = s
                if s > best_score:
                    best_score = s
                    best = cand[:]

        # occasional restart from best
        if random.random() < 0.01:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END

