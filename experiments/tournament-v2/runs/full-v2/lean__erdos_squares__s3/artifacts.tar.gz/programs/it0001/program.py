# EVOLVE-BLOCK-START
"""Greedy largest-square packing with rotation, plus local size refinement."""
import math
import random


def _corners(cx, cy, ang, s):
    c = math.cos(2 * math.pi * ang)
    sn = math.sin(2 * math.pi * ang)
    h = s / 2.0
    pts = []
    for dx, dy in ((h, h), (h, -h), (-h, -h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _inside(pts):
    for x, y in pts:
        if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
            return False
    return True


def _overlap(a, b):
    # SAT for two convex polygons
    for poly in (a, b):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            ax, ay = -ey, ex
            la = math.hypot(ax, ay)
            if la < 1e-12:
                continue
            ax, ay = ax / la, ay / la
            amin = amax = bmin = bmax = None
            for px, py in a:
                d = px * ax + py * ay
                amin = d if amin is None else min(amin, d)
                amax = d if amax is None else max(amax, d)
            for px, py in b:
                d = px * ax + py * ay
                bmin = d if bmin is None else min(bmin, d)
                bmax = d if bmax is None else max(bmax, d)
            if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
                return False
    return True


def _fits(cx, cy, ang, s, placed):
    p = _corners(cx, cy, ang, s)
    if not _inside(p):
        return False
    for q in placed:
        if _overlap(p, q):
            return False
    return True


def solve(n):
    if n <= 0:
        return []
    k = math.isqrt(n)
    side = 1.0 / k
    # initial grid packing as a good starting layout
    placed = []
    count = 0
    for i in range(k):
        for j in range(k):
            if count >= n:
                break
            cx = (i + 0.5) * side
            cy = (j + 0.5) * side
            placed.append((cx, cy, 0.0, side))
            count += 1
        if count >= n:
            break
    squares = [list(p) for p in placed]

    # Try to enlarge each square in turn (coordinate ascent on side length),
    # re-searching centre/angle for the enlarged size.
    rng = random.Random(12345)
    for _ in range(6):
        improved = False
        order = list(range(len(squares)))
        # shuffle small deterministic pattern
        order.sort(key=lambda i: -squares[i][3])
        for idx in order:
            cx0, cy0, ang0, s0 = squares[idx]
            best = [cx0, cy0, ang0, s0]
            others = [_corners(*squares[j]) for j in range(len(squares)) if j != idx]
            # try candidate sizes
            for scale in (1.5, 1.25, 1.1, 1.0):
                target = s0 * scale
                if target > 1.0 + 1e-12:
                    target = 1.0
                # search grid over centre and angle, coarsening as we narrow
                found = None
                for res in (12, 24, 48):
                    step = 1.0 / res
                    rng_ang = [0.0, 0.25] if res < 24 else [0.0, 0.125, 0.25]
                    for ai in rng_ang:
                        for gx in range(res + 1):
                            for gy in range(res + 1):
                                cx = gx * step
                                cy = gy * step
                                p = _corners(cx, cy, ai, target)
                                if not _inside(p):
                                    continue
                                ok = True
                                for q in others:
                                    if _overlap(p, q):
                                        ok = False
                                        break
                                if ok:
                                    found = (cx, cy, ai, target)
                                    break
                            if found:
                                break
                        if found:
                            break
                    if found:
                        break
                if found:
                    best = list(found)
                    break
            if best[3] > s0 + 1e-9:
                squares[idx] = best
                improved = True
            else:
                squares[idx] = [cx0, cy0, ang0, s0]
        if not improved:
            break

    # fill remaining slots with size zero squares if fewer than n
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return [tuple(s) for s in squares[:n]]
# EVOLVE-BLOCK-END

