# EVOLVE-BLOCK-START
"""Grid init + local search: grow sides and jiggle centres to push total perimeter up."""
import math
import random
import time


def _feasible(squares):
    """Check no two squares overlap in interior, all inside the unit square.
    squares: list of (cx, cy, ang, s).  ang in turns."""
    n = len(squares)
    for i in range(n):
        cx, cy, a, s = squares[i]
        if s <= 0.0:
            continue
        if cx < 0.0 or cx > 1.0 or cy < 0.0 or cy > 1.0:
            return False
        h = s * 0.5
        # bounding half-extent along axes for a rotated square
        ca = math.cos(2.0 * math.pi * a)
        sa = math.sin(2.0 * math.pi * a)
        ex = h * (abs(ca) + abs(sa))
        ey = ex
        if cx - ex < -1e-12 or cx + ex > 1.0 + 1e-12:
            return False
        if cy - ey < -1e-12 or cy + ey > 1.0 + 1e-12:
            return False
    for i in range(n):
        for j in range(i + 1, n):
            cxi, cyi, ai, si = squares[i]
            cxj, cyj, aj, sj = squares[j]
            if si <= 0.0 or sj <= 0.0:
                continue
            # SAT for two convex polygons
            if _sep(cxi, cyi, ai, si, cxj, cyj, aj, sj):
                continue
            # one separating axis found -> OK; else overlap
            return False
    return True


def _rot_pts(cx, cy, a, s):
    h = s * 0.5
    ca = math.cos(2.0 * math.pi * a)
    sa = math.sin(2.0 * math.pi * a)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = dx * ca - dy * sa + cx
        y = dx * sa + dy * ca + cy
        pts.append((x, y))
    return pts


def _axis_sep(A, B, ax, ay):
    amin = min(p[0] * ax + p[1] * ay for p in A)
    amax = max(p[0] * ax + p[1] * ay for p in A)
    bmin = min(p[0] * ax + p[1] * ay for p in B)
    bmax = max(p[0] * ax + p[1] * ay for p in B)
    return amax <= bmin + 1e-12 or bmax <= amin + 1e-12


def _sep(cxi, cyi, ai, si, cxj, cyj, aj, sj):
    A = _rot_pts(cxi, cyi, ai, si)
    B = _rot_pts(cxj, cyj, aj, sj)
    for k in range(4):
        ax = A[(k + 1) % 4][0] - A[k][0]
        ay = A[(k + 1) % 4][1] - A[k][1]
        if _axis_sep(A, B, -ay, ax):
            return True
        bx = B[(k + 1) % 4][0] - B[k][0]
        by = B[(k + 1) % 4][1] - B[k][1]
        if _axis_sep(A, B, -by, bx):
            return True
    return False


def _pair_ok(a, b):
    return _sep(a[0], a[1], a[2], a[3], b[0], b[1], b[2], b[3])


def _inside(cx, cy, a, s):
    if s <= 0.0:
        return True
    h = s * 0.5
    ca = abs(math.cos(2.0 * math.pi * a))
    sa = abs(math.sin(2.0 * math.pi * a))
    ex = h * (ca + sa)
    return (cx - ex >= -1e-12 and cx + ex <= 1.0 + 1e-12 and
            cy - ex >= -1e-12 and cy + ex <= 1.0 + 1e-12)


def _init_grid(n):
    k = max(1, int(round(math.sqrt(n))))
    # choose grid dims rf x rc with rf*rc >= n and close to a good pack
    best = None
    for rf in range(1, n + 1):
        rc = max(1, -(-n // rf))
        if rf * rc < n:
            continue
        # sum if we use unit grid of rf rows and rc cols, all side min(1/rf,1/rc)
        # prefer maximal min-side among near-square; but cells must fit n
        side = 1.0 / max(rf, rc)
        if best is None:
            best = (side, rf, rc)
        else:
            # estimate: for balances, choose the one that fills n best
            pass
    rf = int(math.ceil(math.sqrt(n)))
    rc = int(math.ceil(n / rf))
    # better: minimise max dims => maximise side, subject rf*rc>=n
    best_side = -1.0
    best_cfg = (1, n)
    for rf in range(1, n + 1):
        rc = -(-n // rf)
        s = 1.0 / max(rf, rc)
        if s > best_side + 1e-15:
            best_side = s
            best_cfg = (rf, rc)
    rf, rc = best_cfg
    side = 1.0 / max(rf, rc)
    squares = []
    for i in range(rf):
        for j in range(rc):
            if len(squares) >= n:
                break
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
        if len(squares) >= n:
            break
    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _total(squares):
    return sum(s[3] for s in squares)


def solve(n):
    if n <= 0:
        return []
    random.seed(1234 + n)
    t0 = time.time()
    budget = 55.0

    squares = _init_grid(n)
    best = [list(s) for s in squares]
    best_val = _total(best)

    # local search: repeatedly try to grow sides and jiggle centres
    cur = [list(s) for s in best]
    step_c = 0.04
    step_s = 0.02
    it = 0
    while time.time() - t0 < budget:
        it += 1
        improved = False
        order = list(range(n))
        random.shuffle(order)
        for i in order:
            # try growing square i
            for ds in (step_s, step_s * 0.5, step_s * 0.25):
                s = cur[i][3]
                if s <= 0.0 and step_s < 1e-9:
                    continue
                ns = s + ds
                if ns > 1.0 + 1e-12:
                    ns = 1.0
                if ns <= s + 1e-15:
                    continue
                if _inside(cur[i][0], cur[i][1], cur[i][2], ns):
                    ok = True
                    for j in range(n):
                        if j == i:
                            continue
                        a = (cur[i][0], cur[i][1], cur[i][2], ns)
                        b = (cur[j][0], cur[j][1], cur[j][2], cur[j][3])
                        if not _sep(a[0], a[1], a[2], a[3], b[0], b[1], b[2], b[3]):
                            ok = False
                            break
                    if ok:
                        cur[i][3] = ns
                        improved = True
            # try shifting centre
            for _ in range(6):
                dx = random.uniform(-step_c, step_c)
                dy = random.uniform(-step_c, step_c)
                ncx = min(1.0, max(0.0, cur[i][0] + dx))
                ncy = min(1.0, max(0.0, cur[i][1] + dy))
                if not _inside(ncx, ncy, cur[i][2], cur[i][3]):
                    continue
                ok = True
                a = (ncx, ncy, cur[i][2], cur[i][3])
                for j in range(n):
                    if j == i:
                        continue
                    b = (cur[j][0], cur[j][1], cur[j][2], cur[j][3])
                    if not _sep(a[0], a[1], a[2], a[3], b[0], b[1], b[2], b[3]):
                        ok = False
                        break
                if ok:
                    cur[i][0] = ncx
                    cur[i][1] = ncy
                    improved = True
        val = _total(cur)
        if val > best_val + 1e-12:
            best_val = val
            best = [list(s) for s in cur]
        if not improved:
            step_c *= 0.6
            step_s *= 0.6
            if step_c < 1e-5:
                # random restart from best with perturbation
                cur = [list(s) for s in best]
                for i in range(n):
                    if random.random() < 0.5 and cur[i][3] > 1e-6:
                        cur[i][0] = min(1.0, max(0.0, cur[i][0] + random.uniform(-0.05, 0.05)))
                        cur[i][1] = min(1.0, max(0.0, cur[i][1] + random.uniform(-0.05, 0.05)))
                step_c = 0.04
                step_s = 0.02

    # clamp output to [0,1]
    out = []
    for cx, cy, a, s in best:
        a = a % 1.0
        if a < 0:
            a += 1.0
        out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a, max(0.0, min(1.0, s))))
    return out
# EVOLVE-BLOCK-END
