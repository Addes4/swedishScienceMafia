# EVOLVE-BLOCK-START
"""Grid-based packings: skyline DP over integer-size squares in an m x m grid,
plus a block-merge family; pick the best sum of sides."""
import math
import time
import sys


class _Timeout(Exception):
    pass


def _dp_grid(n, m, deadline):
    sys.setrecursionlimit(10000)
    memo = {}

    def f(sky, k):
        if k == 0:
            return 0, None
        h = min(sky)
        if h == m:
            return 0, None
        key = (sky, k)
        r = memo.get(key)
        if r is not None:
            return r
        if time.time() > deadline:
            raise _Timeout()
        i = sky.index(h)
        w = 1
        while i + w < m and sky[i + w] == h:
            w += 1
        nb = []
        if i > 0:
            nb.append(sky[i - 1])
        if i + w < m:
            nb.append(sky[i + w])
        t = min(nb) if nb else m
        best = -1
        bc = None
        for s in range(min(w, m - h), 0, -1):
            new = sky[:i] + (h + s,) * s + sky[i + s:]
            v = s + f(new, k - 1)[0]
            if v > best:
                best = v
                bc = s
        new = sky[:i] + (t,) * w + sky[i + w:]
        v = f(new, k)[0]
        if v > best:
            best = v
            bc = 0
        r = (best, bc)
        memo[key] = r
        return r

    start = tuple([0] * m)
    val, _ = f(start, n)
    # reconstruct
    sky = start
    k = n
    out = []
    while k > 0 and min(sky) < m:
        v, c = f(sky, k)
        h = min(sky)
        i = sky.index(h)
        w = 1
        while i + w < m and sky[i + w] == h:
            w += 1
        if c == 0:
            nb = []
            if i > 0:
                nb.append(sky[i - 1])
            if i + w < m:
                nb.append(sky[i + w])
            t = min(nb) if nb else m
            sky = sky[:i] + (t,) * w + sky[i + w:]
        else:
            out.append((i, h, c))
            sky = sky[:i] + (h + c,) * c + sky[i + c:]
            k -= 1
    return val, out


def _family(n, m, s, j):
    """Value (in cells) of j blocks of size s + unit cells, truncated to n squares."""
    cnt = j + m * m - j * s * s
    val = j * s + m * m - j * s * s
    if cnt > n:
        val -= (cnt - n)
    return val


def _family_build(n, m, s, j):
    per = m // s
    covered = [[False] * m for _ in range(m)]
    sq = []
    c = 0
    for a in range(per):
        for b in range(per):
            if c < j:
                sq.append((a * s, b * s, s))
                for x in range(a * s, a * s + s):
                    for y in range(b * s, b * s + s):
                        covered[x][y] = True
                c += 1
    units = []
    for x in range(m):
        for y in range(m):
            if not covered[x][y]:
                units.append((x, y, 1))
    allsq = sq + units
    if len(allsq) > n:
        # drop units
        allsq = sq + units[:max(0, n - len(sq))]
        allsq = allsq[:n]
    return allsq


def solve(n):
    t0 = time.time()
    best_val = -1.0
    best_m = 1
    best_sq = None

    # block family
    for m in range(1, 41):
        for s in range(1, m + 1):
            per = m // s
            for j in range(0, per * per + 1):
                if s == 1 and j > 0:
                    continue
                cnt = j + m * m - j * s * s
                if cnt < n and j > 0:
                    pass
                v = _family(n, m, s, j) / m
                # if cnt < n squares are padded with zeros: still valid
                if v > best_val + 1e-12:
                    best_val = v
                    best_m = m
                    best_sq = ("fam", m, s, j)
    # DP
    total_deadline = t0 + 40.0
    m0 = max(1, math.isqrt(max(n - 1, 0)))
    for m in range(max(1, m0), 9):
        if time.time() > total_deadline:
            break
        dl = min(total_deadline, time.time() + 15.0)
        try:
            val, out = _dp_grid(n, m, dl)
        except _Timeout:
            continue
        v = val / m
        if v > best_val + 1e-12:
            best_val = v
            best_m = m
            best_sq = ("dp", m, out)

    if best_sq[0] == "fam":
        _, m, s, j = best_sq
        cells = _family_build(n, m, s, j)
    else:
        _, m, cells = best_sq
    res = []
    for (x, y, s) in cells[:n]:
        res.append(((x + s / 2.0) / m, (y + s / 2.0) / m, 0.0, s / m))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
# EVOLVE-BLOCK-END
