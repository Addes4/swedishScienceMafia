# EVOLVE-BLOCK-START
"""Recursive grid/block DP: f(m) = best sum of sides for m squares in a unit square,
built from k x k grids whose cells (or aligned b x b blocks of cells) are recursively packed.
Knapsack table is built incrementally (one column per m)."""
import math
import time
import numpy as np

KMAX = 10
JMAX = KMAX * KMAX


def solve(n):
    t0 = time.time()
    f = np.zeros(n + 1)
    choice = [None] * (n + 1)
    K = np.full((JMAX + 1, n + 1), -np.inf)
    A = np.zeros((JMAX + 1, n + 1), dtype=np.int64)
    K[:, 0] = 0.0
    Aex = [None] * (n + 1)

    for m in range(1, n + 1):
        # excluded column (no cell holds all m squares)
        fm = f[:m]
        for j in range(1, JMAX + 1):
            cand = K[j - 1][m:0:-1] + fm  # s = 0..m-1 -> K[j-1][m-s] + f[s]
            s = int(np.argmax(cand))
            K[j][m] = cand[s]
            A[j][m] = s
        Aex[m] = A[:, m].copy()
        if m == 1:
            f[1] = 1.0
            choice[1] = ('one',)
        else:
            f[m] = f[m - 1]
            choice[m] = ('pad',)
            if time.time() - t0 < 50:
                kmax = min(KMAX, math.isqrt(m) + 3)
                for k in range(2, kmax + 1):
                    for b in range(1, k):
                        if b == 1:
                            cs = [0]
                        else:
                            cs = range(1, (k // b) ** 2 + 1)
                        for c in cs:
                            J2 = k * k - c * b * b
                            if J2 < 0:
                                continue
                            if c == 0:
                                v = K[J2][m] / k
                                tb = 0
                            else:
                                vals = b * K[c][:m + 1] + K[J2][m::-1]
                                tb = int(np.argmax(vals))
                                v = vals[tb] / k
                            if v > f[m] + 1e-12:
                                f[m] = v
                                choice[m] = ('grid', k, b, c, tb)
        # make column full: one cell may hold all m squares
        upd = K[1:, m] < f[m]
        idx = np.nonzero(upd)[0] + 1
        K[idx, m] = f[m]
        A[idx, m] = m

    squares = []

    def backtrack(m, j, T):
        out = []
        for jj in range(j, 0, -1):
            if T == m:
                s = int(Aex[m][jj])
            else:
                s = int(A[jj][T])
            out.append(s)
            T -= s
        return out

    def build(m, x0, y0, size):
        if m <= 0:
            return
        ch = choice[m]
        if ch[0] == 'one':
            squares.append((x0 + size / 2, y0 + size / 2, 0.0, size))
            return
        if ch[0] == 'pad':
            build(m - 1, x0, y0, size)
            return
        _, k, b, c, tb = ch
        J2 = k * k - c * b * b
        bc = backtrack(m, c, tb) if c > 0 else []
        cc = backtrack(m, J2, m - tb)
        cell = size / k
        covered = [[False] * k for _ in range(k)]
        per = k // b if b > 0 else 1
        for i in range(c):
            bx = (i % per) * b
            by = (i // per) * b
            for u in range(b):
                for w in range(b):
                    covered[bx + u][by + w] = True
            build(bc[i], x0 + bx * cell, y0 + by * cell, b * cell)
        ci = 0
        for u in range(k):
            for w in range(k):
                if not covered[u][w]:
                    if ci < len(cc):
                        build(cc[ci], x0 + u * cell, y0 + w * cell, cell)
                    ci += 1

    import sys
    sys.setrecursionlimit(10000)
    if n >= 1:
        build(n, 0.0, 0.0, 1.0)
    res = []
    for (x, y, a, s) in squares:
        s2 = s * (1 - 1e-12)
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), 0.0, min(1.0, max(0.0, s2))))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
# EVOLVE-BLOCK-END
