# EVOLVE-BLOCK-START
"""Recursive grid/block DP: f(m) = best sum of sides for m squares in a unit square,
built from k x k grids whose cells (or aligned blocks of cells, possibly of two sizes)
are recursively packed."""
import math
import time
import numpy as np


def _knap(J, T, fv):
    cap = len(fv) - 1
    s = np.arange(cap + 1)
    t = np.arange(T + 1)
    idx = t[:, None] - s[None, :]
    valid = idx >= 0
    idxc = np.clip(idx, 0, None)
    K = np.full((J + 1, T + 1), -np.inf)
    K[0, 0] = 0.0
    A = np.zeros((J + 1, T + 1), dtype=int)
    for j in range(1, J + 1):
        cand = np.where(valid, K[j - 1][idxc] + fv[None, :], -np.inf)
        K[j] = cand.max(axis=1)
        A[j] = cand.argmax(axis=1)
    return K, A


def _backtrack(A, J, T):
    out = []
    for j in range(J, 0, -1):
        s = int(A[j][T])
        out.append(s)
        T -= s
    return out


def _mix_positions(k, b1, b2):
    pos = []
    per = k // b2
    for i in range(per):
        for j in range(per):
            px = k - b2 * (i + 1)
            py = k - b2 * (j + 1)
            if px < b1 and py < b1:
                continue
            pos.append((px, py))
    return pos


def solve(n):
    t0 = time.time()
    f = np.zeros(n + 1)
    choice = [None] * (n + 1)
    if n >= 1:
        f[1] = 1.0
        choice[1] = ('one',)
    for m in range(2, n + 1):
        f[m] = f[m - 1]
        choice[m] = ('pad',)
        if time.time() - t0 > 40:
            continue
        kmax = min(10, math.isqrt(m) + 3)
        K, A = _knap(kmax * kmax, m, f[:m])
        for k in range(2, kmax + 1):
            for b in range(1, k):
                if b == 1:
                    cs = [0]
                else:
                    cs = range(1, (k // b) ** 2 + 1)
                for c in cs:
                    J2 = k * k - c * b * b
                    if J2 < 0:
                        continue
                    if c == 0:
                        v = K[J2][m] / k
                        tb = 0
                    else:
                        vals = b * K[c][:m + 1] + K[J2][::-1]
                        tb = int(np.argmax(vals))
                        v = vals[tb] / k
                    if v > f[m] + 1e-12:
                        f[m] = v
                        choice[m] = ('grid', k, b, c, tb)
        # mixed: one big block b1 at origin + c2 blocks of size b2 anchored far corner
        if m <= 100 and time.time() - t0 < 30:
            ar = np.arange(m + 1)
            idx = ar[:, None] - ar[None, :]
            valid = idx >= 0
            idxc = np.clip(idx, 0, None)
            tarr = m - np.arange(m)
            for k in range(3, min(8, kmax) + 1):
                for b1 in range(2, k):
                    for b2 in range(2, k):
                        pos = _mix_positions(k, b1, b2)
                        for c2 in range(1, len(pos) + 1):
                            J2 = k * k - b1 * b1 - c2 * b2 * b2
                            if J2 < 0:
                                break
                            Kc = b2 * K[c2][:m + 1]
                            Kr = K[J2][:m + 1]
                            M = np.where(valid, Kc[None, :] + Kr[idxc], -np.inf)
                            # M[T, t2] = Kc[t2] + Kr[T - t2]; need idx = T - t2
                            # rows T, cols t2: idx[T, t2] = T - t2  (matches)
                            G = M.max(axis=1)
                            vals = b1 * f[:m] + G[tarr]
                            t1 = int(np.argmax(vals))
                            v = vals[t1] / k
                            if v > f[m] + 1e-12:
                                f[m] = v
                                choice[m] = ('mix', k, b1, b2, c2, t1)

    squares = []

    def build(m, x0, y0, size):
        if m <= 0:
            return
        ch = choice[m]
        if ch[0] == 'one':
            squares.append((x0 + size / 2, y0 + size / 2, 0.0, size))
            return
        if ch[0] == 'pad':
            build(m - 1, x0, y0, size)
            return
        if ch[0] == 'mix':
            _, k, b1, b2, c2, t1 = ch
            K, A = _knap(k * k, m, f[:m])
            J2 = k * k - b1 * b1 - c2 * b2 * b2
            T = m - t1
            Kc = b2 * K[c2][:T + 1]
            Kr = K[J2][:T + 1][::-1]
            t2 = int(np.argmax(Kc + Kr))
            bc = _backtrack(A, c2, t2)
            cc = _backtrack(A, J2, T - t2)
            cell = size / k
            covered = [[False] * k for _ in range(k)]
            for u in range(b1):
                for w in range(b1):
                    covered[u][w] = True
            build(t1, x0, y0, b1 * cell)
            pos = _mix_positions(k, b1, b2)
            for i in range(c2):
                px, py = pos[i]
                for u in range(b2):
                    for w in range(b2):
                        covered[px + u][py + w] = True
                build(bc[i], x0 + px * cell, y0 + py * cell, b2 * cell)
            ci = 0
            for u in range(k):
                for w in range(k):
                    if not covered[u][w]:
                        if ci < len(cc):
                            build(cc[ci], x0 + u * cell, y0 + w * cell, cell)
                        ci += 1
            return
        _, k, b, c, tb = ch
        K, A = _knap(k * k, m, f[:m])
        J2 = k * k - c * b * b
        bc = _backtrack(A, c, tb) if c > 0 else []
        cc = _backtrack(A, J2, m - tb)
        cell = size / k
        covered = [[False] * k for _ in range(k)]
        per = k // b if b > 0 else 1
        for i in range(c):
            bx = (i % per) * b
            by = (i // per) * b
            for u in range(b):
                for w in range(b):
                    covered[bx + u][by + w] = True
            build(bc[i], x0 + bx * cell, y0 + by * cell, b * cell)
        ci = 0
        for u in range(k):
            for w in range(k):
                if not covered[u][w]:
                    if ci < len(cc):
                        build(cc[ci], x0 + u * cell, y0 + w * cell, cell)
                    ci += 1

    if n >= 1:
        build(n, 0.0, 0.0, 1.0)
    res = []
    for (x, y, a, s) in squares:
        s2 = s * (1 - 1e-12)
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), 0.0, min(1.0, max(0.0, s2))))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
# EVOLVE-BLOCK-END
