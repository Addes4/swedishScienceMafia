# Research notebook: circle_packing

Ranker `random`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.382119.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Mock idea 319: retune constant 4 of the construction. | 0.71 | favourite | opus-5-5 | not_better | 0.349947 |
| 5 | Mock idea 5635: retune constant 5 of the construction. | 0.52 | favourite | opus-5-5 | not_better | 0.379377 |
| 2 | Mock idea 6451: retune constant 2 of the construction. | 0.45 | middle | sonnet-5-5 | not_better | 0.351082 |
| 0 | Mock idea 9482: retune constant 0 of the construction. | 0.43 | middle | sonnet-5-5 | not_better | 0.352620 |
| 1 | Mock idea 7239: retune constant 1 of the construction. | 0.36 | long_shot | haiku-4-5 | not_better | 0.373055 |
| 3 | Mock idea 4117: retune constant 3 of the construction. | 0.32 | long_shot | haiku-4-5 | not_better | 0.361670 |

Best after round 1: **0.382119** (spent $0.23)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Mock idea 4099: retune constant 1 of the construction. | 0.73 | favourite | opus-5-5 | not_better | 0.370781 |
| 3 | Mock idea 8002: retune constant 3 of the construction. | 0.57 | favourite | opus-5-5 | not_better | 0.347179 |
| 0 | Mock idea 3617: retune constant 0 of the construction. | 0.56 | middle | sonnet-5-5 | api_error |  |
| 5 | Mock idea 6111: retune constant 5 of the construction. | 0.56 | middle | sonnet-5-5 | not_better | 0.361080 |
| 4 | Mock idea 850: retune constant 4 of the construction. | 0.21 | long_shot | haiku-4-5 | not_better | 0.330744 |
| 2 | Mock idea 2660: retune constant 2 of the construction. | 0.21 | long_shot | haiku-4-5 | not_better | 0.342012 |

Best after round 2: **0.382119** (spent $0.47)

