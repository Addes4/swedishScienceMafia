# Research notebook: erdos_squares

Ranker `random`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.856172.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Mock idea 319: retune constant 4 of the construction. | 0.71 | favourite | opus-5-5 | not_better | 0.856172 |
| 5 | Mock idea 5635: retune constant 5 of the construction. | 0.52 | favourite | opus-5-5 | not_better | 0.856172 |
| 2 | Mock idea 6451: retune constant 2 of the construction. | 0.45 | middle | sonnet-5-5 | invalid | 0.000000 |
| 0 | Mock idea 9482: retune constant 0 of the construction. | 0.43 | middle | sonnet-5-5 | not_better | 0.856172 |
| 1 | Mock idea 7239: retune constant 1 of the construction. | 0.36 | long_shot | haiku-4-5 | not_better | 0.856172 |
| 3 | Mock idea 4117: retune constant 3 of the construction. | 0.32 | long_shot | haiku-4-5 | invalid | 0.000000 |

Best after round 1: **0.856172** (spent $0.27)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Mock idea 4099: retune constant 1 of the construction. | 0.73 | favourite | opus-5-5 | invalid | 0.000000 |
| 3 | Mock idea 8002: retune constant 3 of the construction. | 0.57 | favourite | opus-5-5 | api_error |  |
| 0 | Mock idea 3617: retune constant 0 of the construction. | 0.56 | middle | sonnet-5-5 | not_better | 0.856172 |
| 5 | Mock idea 6111: retune constant 5 of the construction. | 0.56 | middle | sonnet-5-5 | not_better | 0.856172 |
| 4 | Mock idea 850: retune constant 4 of the construction. | 0.21 | long_shot | haiku-4-5 | api_error |  |
| 2 | Mock idea 2660: retune constant 2 of the construction. | 0.21 | long_shot | haiku-4-5 | api_error |  |

Best after round 2: **0.856172** (spent $0.47)

