# Research notebook: erdos_squares

Ranker `random`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.856172.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Mock idea 7961: retune constant 3 of the construction. | 0.68 | favourite | sonnet-5-5 (swapped) | invalid | 0.000000 |
| 1 | Mock idea 1832: retune constant 1 of the construction. | 0.62 | favourite | opus-5-5 | invalid | 0.000000 |
| 5 | Mock idea 2434: retune constant 5 of the construction. | 0.29 | middle | sonnet-5-5 | not_better | 0.856172 |
| 0 | Mock idea 8105: retune constant 0 of the construction. | 0.29 | middle | sonnet-5-5 | invalid | 0.000000 |
| 2 | Mock idea 1455: retune constant 2 of the construction. | 0.27 | long_shot | haiku-4-5 | not_better | 0.856172 |
| 4 | Mock idea 9564: retune constant 4 of the construction. | 0.18 | long_shot | haiku-4-5 | not_better | 0.856172 |

Best after round 1: **0.856172** (spent $0.26)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Mock idea 1574: retune constant 4 of the construction. | 0.53 | favourite | sonnet-5-5 (swapped) | not_better | 0.856172 |
| 5 | Mock idea 2397: retune constant 5 of the construction. | 0.44 | favourite | opus-5-5 | not_better | 0.856172 |
| 0 | Mock idea 8849: retune constant 0 of the construction. | 0.43 | middle | sonnet-5-5 | api_error |  |
| 1 | Mock idea 2432: retune constant 1 of the construction. | 0.41 | middle | sonnet-5-5 | not_better | 0.856172 |
| 3 | Mock idea 2565: retune constant 3 of the construction. | 0.37 | long_shot | haiku-4-5 | api_error |  |
| 2 | Mock idea 3348: retune constant 2 of the construction. | 0.24 | long_shot | haiku-4-5 | api_error |  |

Best after round 2: **0.856172** (spent $0.49)

