# Research notebook: erdos_squares

Ranker `jev`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.856172.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Use a recursive quadtree construction. Start from the unit square, and while there are fewer than n squares, split one existing square of side s into a 2×2 grid | 0.68 | favourite | opus-5-5 | improved | 1.000000 |
| 4 | Post-process the best combinatorial layout with a continuous optimiser. Parameterise the axis-aligned squares' positions and sides, maximise the side-sum under  | 0.68 | favourite | opus-5-5 | no_code |  |
| 0 | Enumerate an m×m grid for every m up to about 2√n+4, merge disjoint a×a blocks of cells into single squares (each merge removes a²−1 squares and adds a cells' w | 0.67 | middle | sonnet-5-5 | api_error |  |
| 3 | Use the "big square plus L-border" family. Take one large square of side a/m in a corner, fill the remaining L-shaped strip with an m×m grid's leftover cells, a | 0.62 | middle | sonnet-5-5 | improved | 0.992100 |
| 5 | Bold attempt for n = k²+1 and similar near-square counts: start from the k×k grid and insert one extra square tilted at 45°, carving room by shrinking a row and | 0.61 | long_shot | haiku-4-5 | api_error |  |
| 2 | Use a guillotine DP over rectangles with rational sides on a fine lattice, e.g. denominators up to 12. Define best(w, h, c) as the max side-sum of c squares pac | 0.52 | long_shot | haiku-4-5 | api_error |  |

Best after round 1: **1.000000** (spent $0.44)

