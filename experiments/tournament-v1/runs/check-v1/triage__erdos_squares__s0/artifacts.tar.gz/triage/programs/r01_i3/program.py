# EVOLVE-BLOCK-START
"""Big corner square + grid cells, optionally merging 2x2 blocks, dropping extras."""
import math


def _blocks(m, s):
    """Greedy placement of 2x2 blocks in free cells of m x m grid with s x s corner block."""
    used = [[False] * m for _ in range(m)]
    for i in range(s):
        for j in range(s):
            used[i][j] = True
    blocks = []
    for i in range(m - 1):
        for j in range(m - 1):
            if not (used[i][j] or used[i + 1][j] or used[i][j + 1] or used[i + 1][j + 1]):
                for a in (0, 1):
                    for b in (0, 1):
                        used[i + a][j + b] = True
                blocks.append((i, j))
    return blocks, used


def solve(n):
    best = None  # (sum, m, s, t)
    k0 = max(1, math.isqrt(n))
    for m in range(1, k0 + 7):
        for s in range(0, m):
            if s == 1:
                continue
            blocks, _ = _blocks(m, s)
            big = 1 if s > 0 else 0
            for t in range(0, len(blocks) + 1):
                u = m * m - s * s - 4 * t
                if u < 0:
                    continue
                count = big + t + u
                d = max(0, count - n)
                if d > u:
                    continue
                total = (s * big + 2 * t + u - d) / m
                if best is None or total > best[0] + 1e-12:
                    best = (total, m, s, t)
    _, m, s, t = best
    blocks, used = _blocks(m, s)
    h = 1.0 / m
    sq = []
    if s > 0:
        sq.append((s * h / 2, s * h / 2, 0.0, s * h))
    covered = [[False] * m for _ in range(m)]
    for i in range(s):
        for j in range(s):
            covered[i][j] = True
    for (i, j) in blocks[:t]:
        sq.append(((i + 1) * h, (j + 1) * h, 0.0, 2 * h))
        for a in (0, 1):
            for b in (0, 1):
                covered[i + a][j + b] = True
    units = []
    for i in range(m):
        for j in range(m):
            if not covered[i][j]:
                units.append(((i + 0.5) * h, (j + 0.5) * h, 0.0, h))
    d = max(0, len(sq) + len(units) - n)
    if d:
        units = units[:len(units) - d]
    sq += units
    sq = sq[:n]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq
# EVOLVE-BLOCK-END
