# EVOLVE-BLOCK-START
"""Recursive grid DP: grids with merged blocks and recursively subdivided cells."""
import math
import numpy as np


def _build(desc, k, x0, y0, s):
    d = desc[k]
    kind = d[0]
    out = []
    if k == 0:
        return out
    if kind == 'one':
        return [(x0 + s / 2, y0 + s / 2, 0.0, s)]
    if kind == 'pad':
        out = _build(desc, k - 1, x0, y0, s)
        out.append((x0 + s / 2, y0 + s / 2, 0.0, 0.0))
        return out
    _, m, j, t, counts = d
    cs = s / m
    occupied = set()
    per = m // j if j > 0 else 0
    for idx in range(t):
        p, q = idx // per, idx % per
        for a in range(j):
            for b in range(j):
                occupied.add((p * j + a, q * j + b))
        out.append((x0 + (q * j + j / 2) * cs, y0 + (p * j + j / 2) * cs, 0.0, j * cs))
    ci = 0
    for r in range(m):
        for c in range(m):
            if (r, c) in occupied:
                continue
            a = counts[ci]
            ci += 1
            if a > 0:
                out.extend(_build(desc, a, x0 + c * cs, y0 + r * cs, cs))
    return out


def _plan(N):
    NEG = -1e18
    f = [0.0, 1.0] + [0.0] * max(0, N - 1)
    desc = [('none',), ('one',)] + [None] * max(0, N - 1)
    for n in range(2, N + 1):
        f[n] = f[n - 1]
        desc[n] = ('pad',)
        mmax = math.isqrt(n) + 2
        Rmax = mmax * mmax
        H = np.full((Rmax + 1, n + 1), NEG)
        H[0][0] = 0.0
        A = np.zeros((Rmax + 1, n + 1), dtype=np.int64)
        for r in range(1, Rmax + 1):
            prev = H[r - 1]
            cur = np.full(n + 1, NEG)
            arg = np.zeros(n + 1, dtype=np.int64)
            for a in range(0, n):
                cand = np.full(n + 1, NEG)
                cand[a:] = prev[:n + 1 - a] + f[a]
                mask = cand > cur
                cur = np.where(mask, cand, cur)
                arg = np.where(mask, a, arg)
            H[r] = cur
            A[r] = arg
        best = f[n]
        bp = None
        for m in range(2, mmax + 1):
            for j in range(1, m):
                if j == 1:
                    ts = [0]
                else:
                    ts = range(0, min(n, (m // j) ** 2) + 1)
                for t in ts:
                    R = m * m - t * j * j
                    if R < 0 or n - t < 0:
                        continue
                    h = H[R][n - t]
                    if h < -1e17:
                        continue
                    v = (t * j + h) / m
                    if v > best + 1e-12:
                        best = v
                        bp = (m, j, t, R)
        if bp is not None:
            m, j, t, R = bp
            c = n - t
            counts = []
            for r in range(R, 0, -1):
                a = int(A[r][c])
                counts.append(a)
                c -= a
            counts.sort(reverse=True)
            f[n] = best
            desc[n] = ('grid', m, j, t, counts)
    return f, desc


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    f, desc = _plan(n)
    squares = _build(desc, n, 0.0, 0.0, 1.0)
    squares = squares[:n]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares
# EVOLVE-BLOCK-END