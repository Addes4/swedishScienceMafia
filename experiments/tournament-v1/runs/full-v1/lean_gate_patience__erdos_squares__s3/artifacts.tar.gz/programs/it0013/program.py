# EVOLVE-BLOCK-START
"""Guillotine-partition dynamic program over an integer grid of cut positions."""
import math
import time
import numpy as np


def _dp(n, G):
    F = np.zeros((n + 1, G + 1, G + 1))
    D = np.zeros((n + 1, G + 1, G + 1), dtype=np.int8)
    CC = np.zeros((n + 1, G + 1, G + 1), dtype=np.int16)
    MM = np.zeros((n + 1, G + 1, G + 1), dtype=np.int16)
    ar = np.arange(n + 1)
    for a in range(1, G + 1):
        for b in range(1, G + 1):
            As, Bs, cuts, dirs = [], [], [], []
            if a >= 2:
                cs = np.arange(1, a // 2 + 1)
                As.append(F[:, cs, b]); Bs.append(F[:, a - cs, b])
                cuts.append(cs); dirs.append(np.zeros(len(cs), dtype=np.int8))
            if b >= 2:
                cs = np.arange(1, b // 2 + 1)
                As.append(F[:, a, cs]); Bs.append(F[:, a, b - cs])
                cuts.append(cs); dirs.append(np.ones(len(cs), dtype=np.int8))
            res = np.full(n + 1, -1.0)
            res[0] = 0.0
            rd = np.zeros(n + 1, dtype=np.int8)
            rc = np.zeros(n + 1, dtype=np.int16)
            rm = np.zeros(n + 1, dtype=np.int16)
            if n >= 1:
                res[1] = min(a, b)
                rd[1] = 3
            if As and n >= 2:
                A = np.hstack(As)
                B = np.hstack(Bs)
                cutv = np.concatenate(cuts)
                dirv = np.concatenate(dirs)
                for m1 in range(1, n):
                    vals = A[m1][None, :] + B[1:n - m1 + 1]
                    idx = vals.argmax(1)
                    best = vals[ar[:n - m1], idx]
                    tgt = res[m1 + 1:]
                    imp = best > tgt + 1e-12
                    if imp.any():
                        tgt[imp] = best[imp]
                        rd[m1 + 1:][imp] = dirv[idx[imp]]
                        rc[m1 + 1:][imp] = cutv[idx[imp]]
                        rm[m1 + 1:][imp] = m1
            for m in range(2, n + 1):
                if res[m - 1] >= res[m]:
                    res[m] = res[m - 1]
                    rd[m] = 2
            F[:, a, b] = res
            D[:, a, b] = rd
            CC[:, a, b] = rc
            MM[:, a, b] = rm
    return F, D, CC, MM


def _build(n, G, D, CC, MM):
    out = []
    stack = [(n, G, G, 0, 0)]
    while stack:
        m, a, b, x, y = stack.pop()
        if m <= 0:
            continue
        d = int(D[m, a, b])
        if d == 3:
            s = min(a, b)
            out.append(((x + s / 2) / G, (y + s / 2) / G, 0.0, s / G))
        elif d == 2:
            stack.append((m - 1, a, b, x, y))
        elif d == 0:
            c = int(CC[m, a, b]); m1 = int(MM[m, a, b])
            stack.append((m1, c, b, x, y))
            stack.append((m - m1, a - c, b, x + c, y))
        else:
            c = int(CC[m, a, b]); m1 = int(MM[m, a, b])
            stack.append((m1, a, c, x, y))
            stack.append((m - m1, a, b - c, x, y + c))
    return out


def _grid_baseline(n):
    k = max(1, math.isqrt(n))
    out = []
    for i in range(k):
        for j in range(k):
            if len(out) < n:
                out.append(((i + 0.5) / k, (j + 0.5) / k, 0.0, 1.0 / k))
    return out, k * 1.0 if n >= k * k else 0.0


def _est(G, n):
    return 2e-8 * G ** 3 * n * n + 5e-5 * G * G * n


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    t0 = time.time()
    k = max(1, math.isqrt(n))
    base, base_val = _grid_baseline(n)
    best_val = base_val
    best_sq = base
    cand = [k, k + 1, 2 * k, 2 * k + 2, 3 * k, 3 * k + 3, 12, 16, 20, 24, 30]
    cand += list(range(1, 41))
    seen = set()
    order = []
    for g in cand:
        if 1 <= g <= 40 and g not in seen:
            seen.add(g)
            order.append(g)
    budget = 38.0
    for G in order:
        if time.time() - t0 + _est(G, n) * 1.3 > budget:
            continue
        F, D, CC, MM = _dp(n, G)
        val = F[n, G, G] / G
        if val > best_val + 1e-12:
            best_val = val
            best_sq = _build(n, G, D, CC, MM)
        if time.time() - t0 > budget:
            break
    squares = best_sq or []
    squares = [(min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0, min(1.0, max(0.0, s)))
               for cx, cy, _, s in squares]
    squares = squares[:n]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares
# EVOLVE-BLOCK-END
