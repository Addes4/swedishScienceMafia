# EVOLVE-BLOCK-START
"""DP over recursive grid / big-corner-square constructions."""
import math


def solve(n):
    M = 8
    C = M * M
    NEG = -1e18
    F = [0.0] * (n + 1)
    ch = [None] * (n + 1)
    H = [[NEG] * (n + 1) for _ in range(C + 1)]
    J = [[0] * (n + 1) for _ in range(C + 1)]
    for c in range(C + 1):
        H[c][0] = 0.0
    for t in range(1, n + 1):
        for c in range(1, C + 1):
            best = NEG
            bj = 0
            Hp = H[c - 1]
            for j in range(0, t):
                v = Hp[t - j]
                if v < -1e17:
                    continue
                v += F[j]
                if v > best:
                    best = v
                    bj = j
            H[c][t] = best
            J[c][t] = bj
        if t == 1:
            F[t] = 1.0
            ch[t] = ('one',)
        else:
            best = F[t - 1]
            bc = ('pad',)
            for k in range(2, M + 1):
                h = H[k * k][t]
                if h > -1e17 and h / k > best + 1e-12:
                    best = h / k
                    bc = ('grid', k)
            for m in range(3, M + 1):
                for a in range(2, m):
                    c = m * m - a * a
                    h = H[c][t - 1]
                    if h < -1e17:
                        continue
                    v = a / m + h / m
                    if v > best + 1e-12:
                        best = v
                        bc = ('big', m, a)
            F[t] = best
            ch[t] = bc
        for c in range(1, C + 1):
            if F[t] > H[c][t]:
                H[c][t] = F[t]
                J[c][t] = t

    out = []

    def distribute(cells, rem):
        counts = [0] * cells
        for c in range(cells, 0, -1):
            j = J[c][rem]
            counts[c - 1] = j
            rem -= j
        return counts

    def emit(t, x, y, s):
        if t <= 0:
            return
        c = ch[t]
        if c[0] == 'one':
            out.append((x + s / 2, y + s / 2, 0.0, s))
        elif c[0] == 'pad':
            emit(t - 1, x, y, s)
        elif c[0] == 'grid':
            k = c[1]
            counts = distribute(k * k, t)
            cs = s / k
            idx = 0
            for i in range(k):
                for j in range(k):
                    emit(counts[idx], x + i * cs, y + j * cs, cs)
                    idx += 1
        else:
            m, a = c[1], c[2]
            cs = s / m
            out.append((x + a * cs / 2, y + a * cs / 2, 0.0, a * cs))
            cells = [(i, j) for i in range(m) for j in range(m) if not (i < a and j < a)]
            counts = distribute(len(cells), t - 1)
            for idx, (i, j) in enumerate(cells):
                emit(counts[idx], x + i * cs, y + j * cs, cs)

    emit(n, 0.0, 0.0, 1.0)
    res = []
    for (cx, cy, ang, s) in out[:n]:
        res.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), ang, min(1.0, max(0.0, s))))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
# EVOLVE-BLOCK-END
