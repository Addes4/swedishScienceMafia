# EVOLVE-BLOCK-START
"""Guillotine-partition dynamic program over an integer grid of cut positions,
plus a top-level pinwheel (5-rectangle) partition using the DP tables."""
import math
import time
import numpy as np


def _dp(n, G):
    F = np.zeros((n + 1, G + 1, G + 1))
    D = np.zeros((n + 1, G + 1, G + 1), dtype=np.int8)
    CC = np.zeros((n + 1, G + 1, G + 1), dtype=np.int16)
    MM = np.zeros((n + 1, G + 1, G + 1), dtype=np.int16)
    ar = np.arange(n + 1)
    for a in range(1, G + 1):
        for b in range(1, G + 1):
            As, Bs, cuts, dirs = [], [], [], []
            if a >= 2:
                cs = np.arange(1, a // 2 + 1)
                As.append(F[:, cs, b]); Bs.append(F[:, a - cs, b])
                cuts.append(cs); dirs.append(np.zeros(len(cs), dtype=np.int8))
            if b >= 2:
                cs = np.arange(1, b // 2 + 1)
                As.append(F[:, a, cs]); Bs.append(F[:, a, b - cs])
                cuts.append(cs); dirs.append(np.ones(len(cs), dtype=np.int8))
            res = np.full(n + 1, -1.0)
            res[0] = 0.0
            rd = np.zeros(n + 1, dtype=np.int8)
            rc = np.zeros(n + 1, dtype=np.int16)
            rm = np.zeros(n + 1, dtype=np.int16)
            if n >= 1:
                res[1] = min(a, b)
                rd[1] = 3
            if As and n >= 2:
                A = np.hstack(As)
                B = np.hstack(Bs)
                cutv = np.concatenate(cuts)
                dirv = np.concatenate(dirs)
                for m1 in range(1, n):
                    vals = A[m1][None, :] + B[1:n - m1 + 1]
                    idx = vals.argmax(1)
                    best = vals[ar[:n - m1], idx]
                    tgt = res[m1 + 1:]
                    imp = best > tgt + 1e-12
                    if imp.any():
                        tgt[imp] = best[imp]
                        rd[m1 + 1:][imp] = dirv[idx[imp]]
                        rc[m1 + 1:][imp] = cutv[idx[imp]]
                        rm[m1 + 1:][imp] = m1
            for m in range(2, n + 1):
                if res[m - 1] >= res[m]:
                    res[m] = res[m - 1]
                    rd[m] = 2
            F[:, a, b] = res
            D[:, a, b] = rd
            CC[:, a, b] = rc
            MM[:, a, b] = rm
    return F, D, CC, MM


def _build(n, G, D, CC, MM, start=None, out=None):
    if out is None:
        out = []
    stack = [start] if start is not None else [(n, G, G, 0, 0)]
    while stack:
        m, a, b, x, y = stack.pop()
        if m <= 0:
            continue
        d = int(D[m, a, b])
        if d == 3:
            s = min(a, b)
            out.append(((x + s / 2) / G, (y + s / 2) / G, 0.0, s / G))
        elif d == 2:
            stack.append((m - 1, a, b, x, y))
        elif d == 0:
            c = int(CC[m, a, b]); m1 = int(MM[m, a, b])
            stack.append((m1, c, b, x, y))
            stack.append((m - m1, a - c, b, x + c, y))
        else:
            c = int(CC[m, a, b]); m1 = int(MM[m, a, b])
            stack.append((m1, a, c, x, y))
            stack.append((m - m1, a, b - c, x, y + c))
    return out


def _conv(u, v, n, want_arg=False):
    out = u + v[0]
    arg = np.zeros(n + 1, dtype=np.int32) if want_arg else None
    for j in range(1, n + 1):
        cand = u[:n + 1 - j] + v[j]
        tgt = out[j:]
        if want_arg:
            imp = cand > tgt + 1e-12
            arg[j:][imp] = j
            tgt[imp] = cand[imp]
        else:
            np.maximum(tgt, cand, out=tgt)
    return out, arg


def _pinwheel(n, G, tabs, t0, limit):
    F, D, CC, MM = tabs
    best = -1.0
    barg = None
    for x1 in range(1, G - 1):
        if time.time() - t0 > limit:
            break
        for x2 in range(x1 + 1, G):
            for y1 in range(1, G - 1):
                for y2 in range(y1 + 1, G):
                    v = [F[:, x2, y1], F[:, G - x2, y2], F[:, G - x1, G - y2],
                         F[:, x1, G - y1], F[:, x2 - x1, y2 - y1]]
                    r, _ = _conv(v[0], v[1], n)
                    r, _ = _conv(r, v[2], n)
                    r, _ = _conv(r, v[3], n)
                    r, _ = _conv(r, v[4], n)
                    if r[n] > best + 1e-12:
                        best = r[n]
                        barg = (x1, x2, y1, y2)
    if barg is None:
        return -1.0, None
    x1, x2, y1, y2 = barg
    v = [F[:, x2, y1], F[:, G - x2, y2], F[:, G - x1, G - y2],
         F[:, x1, G - y1], F[:, x2 - x1, y2 - y1]]
    r1, a1 = _conv(v[0], v[1], n, True)
    r2, a2 = _conv(r1, v[2], n, True)
    r3, a3 = _conv(r2, v[3], n, True)
    r4, a4 = _conv(r3, v[4], n, True)
    m5 = int(a4[n]); rem = n - m5
    m4 = int(a3[rem]); rem -= m4
    m3 = int(a2[rem]); rem -= m3
    m2 = int(a1[rem]); m1 = rem - m2
    rects = [(m1, x2, y1, 0, 0), (m2, G - x2, y2, x2, 0),
             (m3, G - x1, G - y2, x1, y2), (m4, x1, G - y1, 0, y1),
             (m5, x2 - x1, y2 - y1, x1, y1)]
    out = []
    for r in rects:
        _build(n, G, D, CC, MM, start=r, out=out)
    return best / G, out


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    t0 = time.time()
    k = max(1, math.isqrt(n))
    cand = {k, k + 1, 2 * k, 2 * k + 2, 3 * k, 3 * k + 3, 12, 16, 20, 24, 30}
    cand = sorted(g for g in cand if 1 <= g <= 40)
    best_val = -1.0
    best_sq = None
    last = None  # (G, time)
    budget = 40.0
    tables = {}
    for G in cand:
        if last is not None:
            est = last[1] * (G / last[0]) ** 3 * 1.4
            if time.time() - t0 + est > budget:
                continue
        ts = time.time()
        F, D, CC, MM = _dp(n, G)
        last = (G, max(time.time() - ts, 1e-3))
        if G <= 16 and n <= 40:
            tables[G] = (F, D, CC, MM)
        val = F[n, G, G] / G
        if val > best_val + 1e-12:
            best_val = val
            best_sq = _build(n, G, D, CC, MM)
        if time.time() - t0 > budget:
            break
    if n <= 40 and n >= 5:
        for G in sorted(tables.keys(), reverse=True):
            if time.time() - t0 > 45:
                break
            try:
                val, sq = _pinwheel(n, G, tables[G], t0, 52)
            except Exception:
                continue
            if sq is not None and len(sq) <= n and val > best_val + 1e-9:
                best_val = val
                best_sq = sq
    squares = best_sq or []
    squares = [(min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0, min(1.0, max(0.0, s)))
               for cx, cy, _, s in squares]
    squares = squares[:n]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares
# EVOLVE-BLOCK-END
