# EVOLVE-BLOCK-START
"""Guillotine-partition DP over integer resolutions G: best sum of sides for m squares
in each a x b integer rectangle, using all cuts and all splits of m."""
import time
import numpy as np


def _dp(G, n):
    F = np.zeros((G + 1, G + 1, n + 1))
    TY = np.zeros((G + 1, G + 1, n + 1), dtype=np.int8)
    CP = np.zeros((G + 1, G + 1, n + 1), dtype=np.int32)
    M1 = np.zeros((G + 1, G + 1, n + 1), dtype=np.int32)
    for a in range(1, G + 1):
        for b in range(1, G + 1):
            best = np.full(n + 1, float(min(a, b)))
            best[0] = 0.0
            ty = np.zeros(n + 1, dtype=np.int8)
            cp = np.zeros(n + 1, dtype=np.int32)
            mm = np.zeros(n + 1, dtype=np.int32)
            if n >= 2:
                for kind in (1, 2):
                    L = a if kind == 1 else b
                    K = L // 2
                    if K < 1:
                        continue
                    xs = np.arange(1, K + 1)
                    if kind == 1:
                        A = F[xs, b, :]
                        B = F[a - xs, b, :]
                    else:
                        A = F[a, xs, :]
                        B = F[a, b - xs, :]
                    for m1 in range(1, n):
                        vals = A[:, m1][:, None] + B[:, 1:n + 1 - m1]
                        idx = vals.argmax(axis=0)
                        cmax = vals[idx, np.arange(vals.shape[1])]
                        sl = slice(m1 + 1, n + 1)
                        mask = cmax > best[sl] + 1e-12
                        if mask.any():
                            bs = best[sl]
                            bs[mask] = cmax[mask]
                            ts = ty[sl]
                            ts[mask] = kind
                            cs = cp[sl]
                            cs[mask] = xs[idx][mask]
                            ms = mm[sl]
                            ms[mask] = m1
            for m in range(1, n + 1):
                if best[m] < best[m - 1] - 1e-12:
                    best[m] = best[m - 1]
                    ty[m] = 3
            F[a, b, :] = best
            TY[a, b, :] = ty
            CP[a, b, :] = cp
            M1[a, b, :] = mm
    return F, TY, CP, M1


def _reconstruct(G, n, TY, CP, M1):
    out = []
    stack = [(G, G, n, 0, 0)]
    while stack:
        a, b, m, x0, y0 = stack.pop()
        if m == 0:
            continue
        t = TY[a, b, m]
        if t == 0:
            s = min(a, b)
            out.append(((x0 + a / 2.0) / G, (y0 + b / 2.0) / G, 0.0, s / G * (1 - 1e-9)))
        elif t == 3:
            stack.append((a, b, m - 1, x0, y0))
        elif t == 1:
            x = int(CP[a, b, m]); m1 = int(M1[a, b, m])
            stack.append((x, b, m1, x0, y0))
            stack.append((a - x, b, m - m1, x0 + x, y0))
        else:
            y = int(CP[a, b, m]); m1 = int(M1[a, b, m])
            stack.append((a, y, m1, x0, y0))
            stack.append((a, b - y, m - m1, x0, y0 + y))
    return out


def solve(n):
    t0 = time.time()
    budget = 30.0
    best_val = -1.0
    best_layout = None
    last_t = None
    lastG = None
    G = 1
    while G <= 64:
        if last_t is not None:
            est = last_t * (G / lastG) ** 3
            if time.time() - t0 + est > budget:
                break
        ts = time.time()
        F, TY, CP, M1 = _dp(G, n)
        val = F[G, G, n] / G
        if val > best_val + 1e-12:
            lay = _reconstruct(G, n, TY, CP, M1)
            best_val = val
            best_layout = lay
        last_t = max(time.time() - ts, 1e-4)
        lastG = G
        G += 1
    res = list(best_layout)[:n]
    res = [(min(1.0, max(0.0, float(x))), min(1.0, max(0.0, float(y))), 0.0,
            min(1.0, max(0.0, float(s)))) for (x, y, _, s) in res]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
# EVOLVE-BLOCK-END
