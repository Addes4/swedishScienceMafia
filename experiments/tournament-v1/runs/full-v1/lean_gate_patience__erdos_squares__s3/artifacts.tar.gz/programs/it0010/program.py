# EVOLVE-BLOCK-START
"""Guillotine-partition dynamic program over an integer grid of cut positions,
followed by an LP polish with continuous positions/sizes for the fixed topology."""
import math
import time
import numpy as np


def _dp(n, G):
    F = np.zeros((n + 1, G + 1, G + 1))
    D = np.zeros((n + 1, G + 1, G + 1), dtype=np.int8)
    CC = np.zeros((n + 1, G + 1, G + 1), dtype=np.int16)
    MM = np.zeros((n + 1, G + 1, G + 1), dtype=np.int16)
    ar = np.arange(n + 1)
    for a in range(1, G + 1):
        for b in range(1, G + 1):
            As, Bs, cuts, dirs = [], [], [], []
            if a >= 2:
                cs = np.arange(1, a // 2 + 1)
                As.append(F[:, cs, b]); Bs.append(F[:, a - cs, b])
                cuts.append(cs); dirs.append(np.zeros(len(cs), dtype=np.int8))
            if b >= 2:
                cs = np.arange(1, b // 2 + 1)
                As.append(F[:, a, cs]); Bs.append(F[:, a, b - cs])
                cuts.append(cs); dirs.append(np.ones(len(cs), dtype=np.int8))
            res = np.full(n + 1, -1.0)
            res[0] = 0.0
            rd = np.zeros(n + 1, dtype=np.int8)
            rc = np.zeros(n + 1, dtype=np.int16)
            rm = np.zeros(n + 1, dtype=np.int16)
            if n >= 1:
                res[1] = min(a, b)
                rd[1] = 3
            if As and n >= 2:
                A = np.hstack(As)
                B = np.hstack(Bs)
                cutv = np.concatenate(cuts)
                dirv = np.concatenate(dirs)
                for m1 in range(1, n):
                    vals = A[m1][None, :] + B[1:n - m1 + 1]
                    idx = vals.argmax(1)
                    best = vals[ar[:n - m1], idx]
                    tgt = res[m1 + 1:]
                    imp = best > tgt + 1e-12
                    if imp.any():
                        tgt[imp] = best[imp]
                        rd[m1 + 1:][imp] = dirv[idx[imp]]
                        rc[m1 + 1:][imp] = cutv[idx[imp]]
                        rm[m1 + 1:][imp] = m1
            for m in range(2, n + 1):
                if res[m - 1] >= res[m]:
                    res[m] = res[m - 1]
                    rd[m] = 2
            F[:, a, b] = res
            D[:, a, b] = rd
            CC[:, a, b] = rc
            MM[:, a, b] = rm
    return F, D, CC, MM


def _build(n, G, D, CC, MM):
    out = []
    stack = [(n, G, G, 0, 0)]
    while stack:
        m, a, b, x, y = stack.pop()
        if m <= 0:
            continue
        d = int(D[m, a, b])
        if d == 3:
            s = min(a, b)
            out.append(((x + s / 2) / G, (y + s / 2) / G, 0.0, s / G))
        elif d == 2:
            stack.append((m - 1, a, b, x, y))
        elif d == 0:
            c = int(CC[m, a, b]); m1 = int(MM[m, a, b])
            stack.append((m1, c, b, x, y))
            stack.append((m - m1, a - c, b, x + c, y))
        else:
            c = int(CC[m, a, b]); m1 = int(MM[m, a, b])
            stack.append((m1, a, c, x, y))
            stack.append((m - m1, a, b - c, x, y + c))
    return out


def _polish(squares):
    """LP over positions/sizes with the pairwise separation topology fixed."""
    try:
        from scipy.optimize import linprog
        from scipy.sparse import coo_matrix
    except Exception:
        return None
    pos = [(cx - s / 2, cy - s / 2, s) for cx, cy, _, s in squares if s > 1e-12]
    k = len(pos)
    if k < 2 or k > 200:
        return None
    P = np.array(pos)
    x, y, s = P[:, 0], P[:, 1], P[:, 2]
    rows, cols, vals, rhs = [], [], [], []
    r = 0
    I, J = np.triu_indices(k, 1)
    # gaps: i left of j, j left of i, i below j, j below i
    g = np.stack([x[J] - (x[I] + s[I]), x[I] - (x[J] + s[J]),
                  y[J] - (y[I] + s[I]), y[I] - (y[J] + s[J])], 1)
    c = g.argmax(1)
    for t in range(len(I)):
        i, j = int(I[t]), int(J[t])
        ct = c[t]
        if ct == 0:
            a, b, off = i, j, 0
        elif ct == 1:
            a, b, off = j, i, 0
        elif ct == 2:
            a, b, off = i, j, 1
        else:
            a, b, off = j, i, 1
        # coord_a + s_a - coord_b <= 0 ; variable layout: x(0..k), y(k..2k), s(2k..3k)
        base = off * k
        rows += [r, r, r]
        cols += [base + a, 2 * k + a, base + b]
        vals += [1.0, 1.0, -1.0]
        rhs.append(0.0)
        r += 1
    # containment: x_i + s_i <= 1 ; y_i + s_i <= 1
    for i in range(k):
        rows += [r, r]; cols += [i, 2 * k + i]; vals += [1.0, 1.0]; rhs.append(1.0); r += 1
        rows += [r, r]; cols += [k + i, 2 * k + i]; vals += [1.0, 1.0]; rhs.append(1.0); r += 1
    A = coo_matrix((vals, (rows, cols)), shape=(r, 3 * k)).tocsr()
    cost = np.zeros(3 * k)
    cost[2 * k:] = -1.0
    bounds = [(0, 1)] * (2 * k) + [(0, 1)] * k
    try:
        res = linprog(cost, A_ub=A, b_ub=np.array(rhs), bounds=bounds, method="highs")
    except Exception:
        return None
    if res.status != 0 or res.x is None:
        return None
    X = res.x
    eps = 1e-9
    out = []
    for i in range(k):
        si = max(0.0, X[2 * k + i] - eps)
        out.append((X[i] + X[2 * k + i] / 2, X[k + i] + X[2 * k + i] / 2, 0.0, si))
    return out


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    t0 = time.time()
    k = max(1, math.isqrt(n))
    cand = {k, k + 1, 2 * k, 2 * k + 2, 3 * k, 3 * k + 3, 12, 16, 20, 24, 30}
    cand = sorted(g for g in cand if 1 <= g <= 40)
    best_val = -1.0
    best_sq = None
    last = None  # (G, time)
    budget = 35.0
    for G in cand:
        if last is not None:
            est = last[1] * (G / last[0]) ** 3 * 1.4
            if time.time() - t0 + est > budget:
                continue
        ts = time.time()
        F, D, CC, MM = _dp(n, G)
        last = (G, max(time.time() - ts, 1e-3))
        val = F[n, G, G] / G
        if val > best_val + 1e-12:
            best_val = val
            best_sq = _build(n, G, D, CC, MM)
        if time.time() - t0 > budget:
            break
    squares = best_sq or []
    squares = [(min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0, min(1.0, max(0.0, s)))
               for cx, cy, _, s in squares]
    squares = squares[:n]
    try:
        if time.time() - t0 < 50.0:
            pol = _polish(squares)
            if pol is not None:
                old = sum(q[3] for q in squares)
                new = sum(q[3] for q in pol)
                if new > old + 1e-7:
                    pol = [(min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0,
                            min(1.0, max(0.0, s))) for cx, cy, _, s in pol]
                    squares = pol
    except Exception:
        pass
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
# EVOLVE-BLOCK-END
