import math
import time
import numpy as np


def _gen(d, n):
    pts = []

    def rec(i, rem, cur):
        if i == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def _score_arr(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    m = len(a)
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / m) / 100


def solve():
    t0 = time.time()
    budget = 85
    cands = []
    for d in range(2, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if size >= 150 and (B ** d) * 2 < 1e15:
                cands.append((size, d, n))
    cands.sort()
    best = None
    best_s = -1
    last_t = 0.0
    for size, d, n in cands:
        el = time.time() - t0
        est = last_t * (size / 4000.0) ** 2 if last_t else 0
        if el > budget:
            break
        pts = _gen(d, n)
        B = 2 * n + 1
        pw = [B ** i for i in range(d)]
        vals = [sum(c * p for c, p in zip(pt, pw)) for pt in pts]
        ts = time.time()
        s = _score_arr(vals)
        last_t = time.time() - ts
        last_t = last_t * (4000.0 / size) ** 2
        if s > best_s:
            best_s = s
            best = vals
        if time.time() - t0 + last_t * (size / 4000.0) ** 2 * 2 > 110:
            break
    if best is None:
        best = [0, 1, 3]
    return sorted(set(int(x) for x in best))
