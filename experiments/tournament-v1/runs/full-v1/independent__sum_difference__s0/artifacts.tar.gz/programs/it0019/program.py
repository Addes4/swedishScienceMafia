import math
import itertools


def _counts(d, n):
    size = math.comb(n + d, d)
    s = math.comb(2 * n + d, d)
    df = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            df += math.comb(d, i) * math.comb(d - i, j) * math.comb(n, i) * math.comb(n, j)
    return size, s, df


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(pos, remaining, val):
        if pos == d:
            res.append(val)
            return
        w = B ** pos
        for x in range(remaining + 1):
            rec(pos + 1, remaining - x, val + x * w)

    rec(0, n, 0)
    return res


def solve():
    best = None
    best_sc = -1
    for d in range(1, 80):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d > 10 ** 15:
                break
            sz, s, df = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / sz) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
