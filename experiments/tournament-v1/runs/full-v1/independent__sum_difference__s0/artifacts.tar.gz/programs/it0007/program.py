import math
from math import comb


def _counts(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for p in range(0, min(d, n) + 1):
        cp = comb(d, p) * comb(n, p)
        for q in range(0, min(d - p, n) + 1):
            diffs += cp * comb(d - p, q) * comb(n, q)
    return size, sums, diffs


def solve():
    best = None
    best_sc = -1
    for d in range(1, 60):
        for n in range(1, 60):
            if comb(n + d, d) > 4000:
                break
            if (2 * n + 1) ** d > 10 ** 15:
                break
            size, sums, diffs = _counts(d, n)
            if size < 2:
                continue
            sc = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return sorted(set(pts))
