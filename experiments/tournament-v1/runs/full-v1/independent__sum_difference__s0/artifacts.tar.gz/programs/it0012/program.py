import math
from math import comb, factorial


def _gen(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def _diff_count(d, n):
    tot = 0
    for p in range(0, d + 1):
        for q in range(0, d - p + 1):
            m = factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))
            tot += m * comb(n, p) * comb(n, q)
    return tot


def solve():
    best = None
    best_sc = -1
    for d in range(1, 40):
        for n in range(1, 80):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * B ** d > 10 ** 15:
                break
            D = _diff_count(d, n)
            S = comb(2 * n + d, d)
            if S < 2:
                continue
            sc = math.log(D) / math.log(S) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for i, x in enumerate(p):
            v += x * B ** i
        out.append(v)
    return sorted(set(out))
