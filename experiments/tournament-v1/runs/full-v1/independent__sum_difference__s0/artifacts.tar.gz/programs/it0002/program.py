import math
import itertools


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for i in range(0, d + 1):
        for j in range(0, d - i + 1):
            if i > n or j > n:
                continue
            diffs += math.comb(d, i) * math.comb(d - i, j) * math.comb(n, i) * math.comb(n, j)
    return size, sums, diffs


def _build(d, n):
    B = 2 * n + 1
    pts = []

    def rec(pos, remaining, val):
        if pos == d:
            pts.append(val)
            return
        w = B ** pos
        for x in range(remaining + 1):
            rec(pos + 1, remaining - x, val + x * w)

    rec(0, n, 0)
    return pts


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 4000):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            if n * (2 * n + 1) ** (d - 1) > 10 ** 14:
                break
            _, s, df = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    pts = _build(d, n)
    return sorted(set(pts))
