import math
import time
import itertools
import numpy as np


def _build(d, n):
    b = 2 * n + 1
    pts = set()
    for comb in itertools.combinations_with_replacement(range(d + 1), n):
        v = 0
        for c in comb:
            if c < d:
                v += b ** c
        pts.add(v)
    return sorted(pts)


def _score(a):
    arr = np.array(a, dtype=np.int64)
    if len(arr) < 2:
        return 0.0
    diffs = np.unique((arr[:, None] - arr[None, :]).ravel())
    sums = np.unique((arr[:, None] + arr[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(arr)) / 100


def solve():
    start = time.time()
    best = [0, 1, 7]
    best_s = _score(best)
    cands = []
    for n in range(1, 12):
        for d in range(2, 40):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 6:
                continue
            b = 2 * n + 1
            if (b ** d) * n > 5e14:
                break
            cands.append((size, d, n))
    cands.sort()
    for size, d, n in cands:
        if time.time() - start > 90:
            break
        a = _build(d, n)
        if len(a) > 4000:
            continue
        s = _score(a)
        if s > best_s:
            best_s = s
            best = a
    return [int(x) for x in best]
