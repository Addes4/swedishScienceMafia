import math


def _binom(n, k):
    return math.comb(n, k) if 0 <= k <= n else 0


def _counts(d, n):
    s = _binom(2 * n + d, d)
    df = 0
    for j in range(d + 1):
        for k in range(d - j + 1):
            mult = math.factorial(d) // (math.factorial(j) * math.factorial(k) * math.factorial(d - j - k))
            df += mult * _binom(n, j) * _binom(n, k)
    return df, s


def _gen(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 400):
            size = _binom(n + d, d)
            if size > 4000:
                break
            B = 4 * n + 1
            if (B ** d) // 2 > 10 ** 15:
                break
            if size < 2:
                continue
            df, s = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    B = 4 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for c in p:
            v = v * B + c
        out.append(v)
    return sorted(set(out))
