import math
import time
import itertools
import numpy as np


def _score_arr(a):
    a = np.asarray(a, dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    s = np.unique((a[:, None] + a[None, :]).ravel())
    d = np.unique((a[:, None] - a[None, :]).ravel())
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / n) / 100


def _points(d, n, m):
    res = []

    def rec(prefix, rem, k):
        if k == d:
            res.append(tuple(prefix))
            return
        for v in range(min(rem, m) + 1):
            prefix.append(v)
            rec(prefix, rem - v, k + 1)
            prefix.pop()

    rec([], n, 0)
    return res


def _count(d, n, m):
    # count points with sum<=n and each coord<=m (DP)
    poly = [1]
    for _ in range(d):
        new = [0] * (n + 1)
        for s, c in enumerate(poly):
            if c == 0:
                continue
            for v in range(min(m, n - s) + 1):
                new[s + v] += c
        poly = new
    return sum(poly)


def _encode(pts, n):
    base = 2 * n + 1
    out = []
    for p in pts:
        v = 0
        for x in p:
            v = v * base + x
        out.append(v)
    return out


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 12):
        for n in range(2, 40):
            for m in range(max(1, n // 2), n + 1):
                if m != n and m not in (n - 1, n // 2 + 1, (2 * n) // 3):
                    continue
                c = _count(d, n, m)
                if 300 <= c <= 4000 and (2 * n + 1) ** d < 10 ** 15:
                    cands.append((d, n, m, c))
    # prioritise large sets, simplex (m==n) first
    cands.sort(key=lambda t: (t[2] != t[1], -t[3]))
    best = None
    best_score = -1
    for d, n, m, c in cands:
        if time.time() - t0 > 85:
            break
        pts = _points(d, n, m)
        a = _encode(pts, n)
        sc = _score_arr(a)
        if sc > best_score:
            best_score = sc
            best = a
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(int(x) for x in best))
