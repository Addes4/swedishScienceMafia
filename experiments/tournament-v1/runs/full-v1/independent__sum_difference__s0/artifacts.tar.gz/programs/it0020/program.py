import math


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for j in range(0, min(d, n) + 1):
        for m in range(0, min(d - j, n) + 1):
            diffs += (math.comb(d, j) * math.comb(d - j, m)
                      * math.comb(n, j) * math.comb(n, m))
    return size, sums, diffs


def _points(d, n):
    b = 2 * n + 1
    res = []

    def rec(pos, remaining, val):
        if pos == d:
            res.append(val)
            return
        w = b ** pos
        for x in range(remaining + 1):
            rec(pos + 1, remaining - x, val + x * w)

    rec(0, n, 0)
    return res


def solve():
    best = None
    best_sc = -1.0
    for d in range(1, 40):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            b = 2 * n + 1
            if b ** d > 10 ** 15 // 4:
                break
            _, s, df = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    pts = _points(d, n)
    return sorted(set(pts))
