import math
from math import comb, log


def _counts(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        ci = comb(d, i) * comb(n, i)
        for j in range(0, min(d - i, n) + 1):
            diffs += ci * comb(d - i, j) * comb(n, j)
    return size, sums, diffs


def _gen(d, n):
    res = []

    def rec(pos, rem, cur):
        if pos == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(pos + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    best_s = -1
    for d in range(1, 41):
        for n in range(1, 80):
            size = comb(n + d, d)
            if size > 4000:
                break
            base = 2 * n + 1
            if base ** d * n > 1e15:
                break
            sz, su, di = _counts(d, n)
            s = log(di) / log(su) + (1 - 1 / sz) / 100
            if s > best_s:
                best_s = s
                best = (d, n)
    if best is None:
        return [0, 1, 3]
    d, n = best
    base = 2 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for x in p:
            v = v * base + x
        out.append(v)
    return sorted(set(out))
