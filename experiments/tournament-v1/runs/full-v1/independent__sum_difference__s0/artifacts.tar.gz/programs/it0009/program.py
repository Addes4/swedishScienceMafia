import math


def _counts(d, n):
    a = math.comb(n + d, d)
    s = math.comb(2 * n + d, d)
    df = 0
    for i in range(d + 1):
        ci = math.comb(n, i)
        if ci == 0:
            continue
        for j in range(d - i + 1):
            cj = math.comb(n, j)
            if cj == 0:
                continue
            df += (math.factorial(d) // (math.factorial(i) * math.factorial(j)
                                         * math.factorial(d - i - j))) * ci * cj
    return a, s, df


def _build(d, n):
    base = 2 * n + 1
    pts = []

    def rec(pos, rem, val):
        if pos == d:
            pts.append(val)
            return
        w = base ** pos
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return pts


def solve():
    best = None
    best_sc = -1
    for d in range(1, 60):
        for n in range(1, 4000):
            a = math.comb(n + d, d)
            if a > 4000:
                break
            if a < 2:
                continue
            base = 2 * n + 1
            if n * base ** (d - 1) * d > 1e15 or base ** d > 1e15:
                continue
            a, s, df = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / a) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    return sorted(_build(d, n))
