import math
from math import comb, factorial


def _counts(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, d + 1):
        for j in range(0, d - i + 1):
            diffs += (factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))) * comb(n, i) * comb(n, j)
    return size, sums, diffs


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(pos, rem, val):
        if pos == d:
            res.append(val)
            return
        p = B ** pos
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val + x * p)

    rec(0, n, 0)
    return res


def solve():
    best = None
    best_score = -1
    for d in range(1, 60):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * B ** (d - 1) * 2 >= 1e15 or B ** d >= 1e15:
                break
            s, su, di = _counts(d, n)
            sc = math.log(di) / math.log(su) + (1 - 1 / s) / 100
            if sc > best_score:
                best_score = sc
                best = (d, n)
    d, n = best
    return sorted(_gen(d, n))
