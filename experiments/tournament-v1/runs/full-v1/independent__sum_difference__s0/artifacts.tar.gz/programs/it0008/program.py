import math
import time
import numpy as np


def _build(d, n, m, limit=4000):
    # points with coords in [0,m], sum<=n ; encoded base B=2m+1
    B = 2 * m + 1
    cur = [(0, 0)]
    for _ in range(d):
        nxt = []
        for s, c in cur:
            for v in range(0, min(m, n - s) + 1):
                nxt.append((s + v, c * B + v))
        if len(nxt) > limit:
            return None
        cur = nxt
    return [c for s, c in cur]


def _score_arr(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    k = len(a)
    if k < 2:
        return 0.0
    ns = len(np.unique((a[:, None] + a[None, :]).ravel()))
    nd = len(np.unique((a[:, None] - a[None, :]).ravel()))
    return math.log(nd) / math.log(ns) + (1 - 1 / k) / 100


def solve():
    start = time.time()
    budget = 90
    cands = []
    for d in range(2, 22):
        for n in range(1, 40):
            for m in range(1, n + 1):
                B = 2 * m + 1
                if B ** d > 1.5e15:
                    continue
                # quick monotonic skip: cap larger than n irrelevant
                cands.append((d, n, m))
    # estimate sizes cheaply by building (aborting if too big)
    built = []
    for d, n, m in cands:
        if time.time() - start > 30:
            break
        if m == n or m < n:
            # skip trivially large combos quickly
            if n > 12 and d > 8:
                continue
        a = _build(d, n, m)
        if a is None or len(a) < 100:
            continue
        built.append((len(a), d, n, m, a))
    # remove duplicates by (size, set) approx: dedupe by tuple of sorted codes hash
    seen = set()
    uniq = []
    for item in sorted(built, key=lambda t: -t[0]):
        key = (item[0], item[1], min(item[2], item[3] * item[1]), item[3])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(item)
    best = [0, 1, 3]
    best_s = _score_arr(best)
    # evaluate: mix sizes; use time guard
    # prefer evaluating in order of descending size but interleave smaller ones
    order = uniq
    for sz, d, n, m, a in order:
        if time.time() - start > budget:
            break
        s = _score_arr(a)
        if s > best_s:
            best_s, best = s, a
    return sorted(set(int(x) for x in best))
