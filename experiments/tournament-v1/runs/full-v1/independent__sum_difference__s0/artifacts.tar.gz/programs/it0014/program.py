import math
from math import comb, factorial, log


def _counts(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for j in range(0, d + 1):
        for k in range(0, d - j + 1):
            if j > n or k > n:
                continue
            multi = factorial(d) // (factorial(j) * factorial(k) * factorial(d - j - k))
            diffs += multi * comb(n, j) * comb(n, k)
    return size, diffs, sums


def _gen(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    best_sc = -1
    for d in range(1, 40):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            B = 2 * n + 1
            if B ** d > 10 ** 14:
                break
            s, df, sm = _counts(d, n)
            sc = log(df) / log(sm) + (1 - 1 / s) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for c in p:
            v = v * B + c
        out.append(v)
    return sorted(set(out))
