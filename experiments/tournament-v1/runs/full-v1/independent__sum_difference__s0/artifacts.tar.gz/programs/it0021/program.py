import math
import time
import numpy as np


def _gen(d, n):
    pts = []

    def rec(i, rem, cur):
        if i == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def _encode(pts, d, n):
    B = 2 * n + 1
    out = []
    for p in pts:
        v = 0
        for i, x in enumerate(p):
            v += x * (B ** i)
        out.append(v)
    return out


def _score_np(vals):
    a = np.array(vals, dtype=np.int64)
    s = np.unique((a[:, None] + a[None, :]).ravel())
    df = np.unique((a[:, None] - a[None, :]).ravel())
    return math.log(len(df)) / math.log(len(s)) + (1 - 1 / len(a)) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 16):
        n = 1
        while True:
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d * n < 5e14 and size >= 20:
                cands.append((size, d, n))
            n += 1
    cands.sort()
    best = None
    best_s = -1
    # evaluate small ones first, big ones afterwards
    for size, d, n in cands:
        if time.time() - t0 > 85:
            break
        if best is not None and size > 1500 and time.time() - t0 > 70:
            break
        pts = _gen(d, n)
        vals = _encode(pts, d, n)
        try:
            sc = _score_np(vals)
        except MemoryError:
            continue
        if sc > best_s:
            best_s = sc
            best = vals
    if best is None:
        return [7, 15, 18, 22, -3, -2]
    return sorted(set(int(x) for x in best))
