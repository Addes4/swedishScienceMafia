import math
from math import comb, factorial


def _gen(d, n):
    pts = []

    def rec(i, rem, cur):
        if i == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def _counts(d, n):
    s = comb(2 * n + d, d)
    t = 0
    for k in range(0, min(d, n) + 1):
        for l in range(0, min(d - k, n) + 1):
            t += (factorial(d) // (factorial(k) * factorial(l) * factorial(d - k - l))) * comb(n, k) * comb(n, l)
    return t, s


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * B ** (d - 1) * d > 1e15:
                continue
            if size < 2:
                continue
            t, s = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    res = []
    for p in pts:
        v = 0
        for x in p:
            v = v * B + x
        res.append(v)
    return sorted(set(res))
