import math
from math import comb


def _counts(d, n):
    S = comb(2 * n + d, d)
    D = 0
    for i in range(0, d + 1):
        for j in range(0, d - i + 1):
            D += (math.factorial(d) // (math.factorial(i) * math.factorial(j) * math.factorial(d - i - j))) \
                * comb(n, i) * comb(n, j)
    return D, S


def _gen(d, n):
    res = []

    def rec(pos, rem, val, mult):
        if pos == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val + x * mult, mult * (2 * n + 1))

    rec(0, n, 0, 1)
    return res


def solve():
    best = None
    best_sc = -1
    for n in range(1, 40):
        B = 2 * n + 1
        for d in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            if n * (B ** d) > 1e15:
                break
            D, S = _counts(d, n)
            sc = math.log(D) / math.log(S) + (1 - 1.0 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
