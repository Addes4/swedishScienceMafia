import math
from math import comb


def _counts(d, n):
    s = comb(2 * n + d, d)
    def c(k):
        return 1 if k == 0 else comb(n, k)
    diff = 0
    for k in range(0, d + 1):
        ck = c(k)
        if ck == 0:
            continue
        for m in range(0, d - k + 1):
            cm = c(m)
            if cm == 0:
                continue
            diff += comb(d, k) * comb(d - k, m) * ck * cm
    return s, diff


def _gen(d, n):
    res = []
    base = 2 * n + 1
    def rec(i, rem, val, mult):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * mult, mult * base)
    rec(0, n, 0, 1)
    return res


def solve():
    best = None
    best_score = -1
    for n in range(1, 60):
        for d in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            if n * (2 * n + 1) ** (d - 1) > 10 ** 15:
                break
            if size < 2:
                continue
            s, df = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_score:
                best_score = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
