import math
import time
import numpy as np


def _gen(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def _score_np(arr):
    n = len(arr)
    s = np.unique((arr[:, None] + arr[None, :]).ravel()).size
    dd = np.unique((arr[:, None] - arr[None, :]).ravel()).size
    return math.log(dd) / math.log(s) + (1 - 1 / n) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 16):
        for n in range(1, 40):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 30:
                continue
            B = 2 * n + 1
            if n * B ** (d - 1) * d > 1e15 or B ** d > 1e15:
                continue
            cands.append((size, d, n))
    cands.sort()
    best = None
    best_s = -1
    for size, d, n in cands:
        if time.time() - t0 > 85:
            break
        B = 2 * n + 1
        pts = _gen(d, n)
        arr = np.array([sum(v * B ** i for i, v in enumerate(p)) for p in pts],
                       dtype=np.int64)
        s = _score_np(arr)
        if s > best_s:
            best_s = s
            best = arr
    if best is None:
        return [0, 1, 3]
    return [int(x) for x in best]
