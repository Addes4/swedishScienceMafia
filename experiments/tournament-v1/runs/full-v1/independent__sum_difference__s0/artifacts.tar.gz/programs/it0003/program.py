import math
from math import comb, factorial


def _ratio(d, n):
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            mult = factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))
            diffs += mult * comb(n, i) * comb(n, j)
    size = comb(n + d, d)
    return math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100


def _gen(d, n):
    pts = []

    def rec(pos, rem, cur):
        if pos == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(pos + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def solve():
    best = None
    bs = -1.0
    for n in range(1, 60):
        for d in range(1, 400):
            size = comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            B = 2 * n + 1
            if 2 * n * B ** d > 4e14:
                break
            s = _ratio(d, n)
            if s > bs:
                bs = s
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    res = []
    for p in pts:
        v = 0
        for x in p:
            v = v * B + x
        res.append(v)
    return sorted(set(res))
