# EVOLVE-BLOCK-START
"""Max-sum-of-sides squares in a square: best of a recursive grid DP and an
integer-lattice guillotine-cut DP."""
import math


def _solve_dp(n):
    M = 6 if n <= 150 else 4
    Fmax = M * M
    V = [0.0] * (n + 1)
    plan = [None] * (n + 1)
    h = [[None] * (n + 1) for _ in range(Fmax + 1)]
    for F in range(Fmax + 1):
        for t in range(n + 1):
            if F == 0 or t == 0:
                h[F][t] = (0.0, ())
    eps = 1e-12
    for N in range(1, n + 1):
        hr = [None] * (Fmax + 1)
        hr[0] = (0.0, ())
        for F in range(1, Fmax + 1):
            best = hr[F - 1]
            for c in range(1, N):
                pv, pd = h[F - 1][N - c]
                v = pv + V[c]
                if v > best[0] + eps:
                    best = (v, pd + (c,))
            hr[F] = best
        if N == 1:
            V[1] = 1.0
            plan[1] = ('one',)
        else:
            bv = V[N - 1]
            bp = plan[N - 1]
            for m in range(2, M + 1):
                v0, d0 = hr[m * m]
                if v0 / m > bv + eps:
                    bv = v0 / m
                    bp = (m, 1, 0, d0)
                for j in range(2, m):
                    per = m // j
                    for b in range(1, per * per + 1):
                        t = N - b
                        if t < 0:
                            break
                        F = m * m - b * j * j
                        hv, hd = h[F][t]
                        v = (b * j + hv) / m
                        if v > bv + eps:
                            bv = v
                            bp = (m, j, b, hd)
            V[N] = bv
            plan[N] = bp
        for F in range(1, Fmax + 1):
            if V[N] > hr[F][0] + eps:
                h[F][N] = (V[N], (N,))
            else:
                h[F][N] = hr[F]

    memo = {}

    def build(c):
        if c in memo:
            return memo[c]
        p = plan[c]
        if p[0] == 'one':
            res = [(0.5, 0.5, 0.0, 1.0)]
        else:
            m, j, b, dist = p
            res = []
            covered = set()
            if b > 0:
                per = m // j
                for idx in range(b):
                    pp = idx % per
                    qq = idx // per
                    res.append(((pp * j + j / 2.0) / m, (qq * j + j / 2.0) / m, 0.0, j / m))
                    for a in range(j):
                        for d in range(j):
                            covered.add((pp * j + a, qq * j + d))
            free = [(x, y) for y in range(m) for x in range(m) if (x, y) not in covered]
            for (x, y), cc in zip(free, dist):
                if cc <= 0:
                    continue
                for (sx, sy, ang, sd) in build(cc):
                    res.append(((x + sx) / m, (y + sy) / m, ang, sd / m))
        memo[c] = res
        return res

    squares = list(build(n))
    squares = [tuple(min(1.0, max(0.0, float(v))) for v in s) for s in squares]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _guillotine(n, L):
    """Guillotine DP on an L x L integer lattice. Returns (sum, squares)."""
    eps = 1e-12
    F = [[None] * (L + 1) for _ in range(L + 1)]
    C = [[None] * (L + 1) for _ in range(L + 1)]
    for w in range(1, L + 1):
        for h in range(1, L + 1):
            s = float(min(w, h))
            val = [0.0] + [s] * n
            ch = [None] + [('o',)] * n
            for x in range(1, w // 2 + 1):
                A = F[x][h]
                B = F[w - x][h]
                for k in range(2, n + 1):
                    bv = val[k]
                    bc = None
                    for a in range(1, k):
                        v = A[a] + B[k - a]
                        if v > bv + eps:
                            bv = v
                            bc = a
                    if bc is not None:
                        val[k] = bv
                        ch[k] = ('v', x, bc)
            for y in range(1, h // 2 + 1):
                A = F[w][y]
                B = F[w][h - y]
                for k in range(2, n + 1):
                    bv = val[k]
                    bc = None
                    for a in range(1, k):
                        v = A[a] + B[k - a]
                        if v > bv + eps:
                            bv = v
                            bc = a
                    if bc is not None:
                        val[k] = bv
                        ch[k] = ('h', y, bc)
            for k in range(1, n + 1):
                if val[k - 1] > val[k] + eps:
                    val[k] = val[k - 1]
                    ch[k] = ('m',)
            F[w][h] = val
            C[w][h] = ch
    total = F[L][L][n] / L
    res = []
    stack = [(0, 0, L, L, n)]
    while stack:
        x0, y0, w, h, k = stack.pop()
        if k <= 0:
            continue
        c = C[w][h][k]
        while c[0] == 'm':
            k -= 1
            c = C[w][h][k]
        if c[0] == 'o':
            s = min(w, h)
            res.append(((x0 + s / 2.0) / L, (y0 + s / 2.0) / L, 0.0, s / L))
        elif c[0] == 'v':
            x, a = c[1], c[2]
            stack.append((x0, y0, x, h, a))
            stack.append((x0 + x, y0, w - x, h, k - a))
        else:
            y, a = c[1], c[2]
            stack.append((x0, y0, w, y, a))
            stack.append((x0, y0 + y, w, h - y, k - a))
    return total, res


def _total(sq):
    return sum(s[3] for s in sq)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    best = _solve_dp(n)
    bs = _total(best)
    if n <= 30:
        Ls = (12, 10, 14, 15, 16, 18)
    elif n <= 60:
        Ls = (12, 10, 15)
    elif n <= 100:
        Ls = (12,)
    else:
        Ls = ()
    for L in Ls:
        try:
            tot, sq = _guillotine(n, L)
        except Exception:
            continue
        if tot > bs + 1e-9:
            sq = [tuple(min(1.0, max(0.0, float(v))) for v in s) for s in sq]
            sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
            sq = sq[:n]
            if _total(sq) > bs + 1e-9:
                best = sq
                bs = _total(sq)
    return best
# EVOLVE-BLOCK-END