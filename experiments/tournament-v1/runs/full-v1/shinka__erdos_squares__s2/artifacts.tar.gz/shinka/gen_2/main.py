# EVOLVE-BLOCK-START
"""Baseline: the largest k x k grid that fits, plus size-zero squares for the rest."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    MAXM = 6
    K = MAXM * MAXM
    NEG = -1e18
    f = [0.0] * (n + 1)
    choice = [None] * (n + 1)
    h = [[0.0] * (n + 1) for _ in range(K + 1)]  # h[c][s]
    for t in range(1, n + 1):
        best = 1.0
        ch = ('single',)
        if f[t - 1] > best + 1e-12:
            best = f[t - 1]
            ch = ('same',)
        if t >= 2:
            for m in range(2, MAXM + 1):
                # corner big square j x j cells, rest cells recursive
                for j in range(1, m):
                    c = m * m - j * j
                    v = (j + h[c][t - 1]) / m
                    if v > best + 1e-12:
                        best = v
                        ch = ('big', m, j)
                # plain grid, first cell gets x1 in 1..t-1
                c1 = m * m - 1
                for x1 in range(1, t):
                    v = (f[x1] + h[c1][t - x1]) / m
                    if v > best + 1e-12:
                        best = v
                        ch = ('grid', m, x1)
        f[t] = best
        choice[t] = ch
        for k in range(1, K + 1):
            hk1 = h[k - 1]
            bv = NEG
            for x in range(t + 1):
                v = f[x] + hk1[t - x]
                if v > bv:
                    bv = v
            h[k][t] = bv

    def alloc(c, s):
        counts = []
        for k in range(c, 0, -1):
            target = h[k][s]
            pick = 0
            for x in range(s + 1):
                if abs(f[x] + h[k - 1][s - x] - target) < 1e-9:
                    pick = x
                    break
            counts.append(pick)
            s -= pick
        return counts

    out = []
    shrink = 1.0 - 1e-12

    def build(t, x0, y0, size):
        if t <= 0:
            return
        ch = choice[t]
        if ch[0] == 'single':
            out.append((x0 + size / 2, y0 + size / 2, 0.0, size * shrink))
        elif ch[0] == 'same':
            build(t - 1, x0, y0, size)
        elif ch[0] == 'big':
            _, m, j = ch
            cs = size / m
            out.append((x0 + j * cs / 2, y0 + j * cs / 2, 0.0, j * cs * shrink))
            cells = [(a, b) for a in range(m) for b in range(m) if not (a < j and b < j)]
            counts = alloc(len(cells), t - 1)
            for (a, b), cnt in zip(cells, counts):
                build(cnt, x0 + a * cs, y0 + b * cs, cs)
        else:
            _, m, x1 = ch
            cs = size / m
            cells = [(a, b) for a in range(m) for b in range(m)]
            counts = [x1] + alloc(m * m - 1, t - x1)
            for (a, b), cnt in zip(cells, counts):
                build(cnt, x0 + a * cs, y0 + b * cs, cs)

    build(n, 0.0, 0.0, 1.0)
    out = out[:n]
    out = [(min(1.0, max(0.0, a)), min(1.0, max(0.0, b)), 0.0, min(1.0, max(0.0, s)))
           for (a, b, _, s) in out]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out
# EVOLVE-BLOCK-END