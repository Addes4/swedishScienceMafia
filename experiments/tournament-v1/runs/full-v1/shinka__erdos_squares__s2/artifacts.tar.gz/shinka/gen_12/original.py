# EVOLVE-BLOCK-START
"""Baseline: the largest k x k grid that fits, plus size-zero squares for the rest."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    M = 6 if n <= 150 else 4
    Fmax = M * M
    V = [0.0] * (n + 1)
    plan = [None] * (n + 1)
    h = [[None] * (n + 1) for _ in range(Fmax + 1)]
    for F in range(Fmax + 1):
        for t in range(n + 1):
            if F == 0 or t == 0:
                h[F][t] = (0.0, ())
    eps = 1e-12
    for N in range(1, n + 1):
        # restricted table: no single cell holds all N squares
        hr = [None] * (Fmax + 1)
        hr[0] = (0.0, ())
        for F in range(1, Fmax + 1):
            best = hr[F - 1]
            for c in range(1, N):
                pv, pd = h[F - 1][N - c]
                v = pv + V[c]
                if v > best[0] + eps:
                    best = (v, pd + (c,))
            hr[F] = best
        if N == 1:
            V[1] = 1.0
            plan[1] = ('one',)
        else:
            bv = V[N - 1]
            bp = plan[N - 1]
            for m in range(2, M + 1):
                v0, d0 = hr[m * m]
                if v0 / m > bv + eps:
                    bv = v0 / m
                    bp = (m, 1, 0, d0)
                for j in range(2, m):
                    per = m // j
                    for b in range(1, per * per + 1):
                        t = N - b
                        if t < 0:
                            break
                        F = m * m - b * j * j
                        hv, hd = h[F][t]
                        v = (b * j + hv) / m
                        if v > bv + eps:
                            bv = v
                            bp = (m, j, b, hd)
            for m in range(2, M + 1):
                for j in range(2, m):
                    F = m * m - j * j
                    if F > Fmax:
                        continue
                    for c in range(1, N):
                        hv, hd = h[F][N - c]
                        v = (j * V[c] + hv) / m
                        if v > bv + eps:
                            bv = v
                            bp = (m, j, -c, hd)
            V[N] = bv
            plan[N] = bp
        for F in range(1, Fmax + 1):
            if V[N] > hr[F][0] + eps:
                h[F][N] = (V[N], (N,))
            else:
                h[F][N] = hr[F]

    memo = {}

    def build(c):
        if c in memo:
            return memo[c]
        p = plan[c]
        if p[0] == 'one':
            res = [(0.5, 0.5, 0.0, 1.0)]
        else:
            m, j, b, dist = p
            res = []
            covered = set()
            if b < 0:
                cbig = -b
                for (sx, sy, ang, sd) in build(cbig):
                    res.append((sx * j / m, sy * j / m, ang, sd * j / m))
                for a in range(j):
                    for d in range(j):
                        covered.add((a, d))
            if b > 0:
                per = m // j
                for idx in range(b):
                    pp = idx % per
                    qq = idx // per
                    res.append(((pp * j + j / 2.0) / m, (qq * j + j / 2.0) / m, 0.0, j / m))
                    for a in range(j):
                        for d in range(j):
                            covered.add((pp * j + a, qq * j + d))
            free = [(x, y) for y in range(m) for x in range(m) if (x, y) not in covered]
            for (x, y), cc in zip(free, dist):
                if cc <= 0:
                    continue
                for (sx, sy, ang, sd) in build(cc):
                    res.append(((x + sx) / m, (y + sy) / m, ang, sd / m))
        memo[c] = res
        return res

    squares = list(build(n))
    squares = [tuple(min(1.0, max(0.0, float(v))) for v in s) for s in squares]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
# EVOLVE-BLOCK-END