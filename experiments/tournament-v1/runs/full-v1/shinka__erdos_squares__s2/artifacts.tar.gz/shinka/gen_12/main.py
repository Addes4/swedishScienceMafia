# EVOLVE-BLOCK-START
"""Max-sum-of-sides squares in a square: best of a recursive grid DP and a
numpy-vectorised integer-lattice guillotine-cut DP."""
import math
import time


def _solve_dp(n):
    M = 6 if n <= 150 else 4
    Fmax = M * M
    V = [0.0] * (n + 1)
    plan = [None] * (n + 1)
    h = [[None] * (n + 1) for _ in range(Fmax + 1)]
    for F in range(Fmax + 1):
        for t in range(n + 1):
            if F == 0 or t == 0:
                h[F][t] = (0.0, ())
    eps = 1e-12
    for N in range(1, n + 1):
        hr = [None] * (Fmax + 1)
        hr[0] = (0.0, ())
        for F in range(1, Fmax + 1):
            best = hr[F - 1]
            for c in range(1, N):
                pv, pd = h[F - 1][N - c]
                v = pv + V[c]
                if v > best[0] + eps:
                    best = (v, pd + (c,))
            hr[F] = best
        if N == 1:
            V[1] = 1.0
            plan[1] = ('one',)
        else:
            bv = V[N - 1]
            bp = plan[N - 1]
            for m in range(2, M + 1):
                v0, d0 = hr[m * m]
                if v0 / m > bv + eps:
                    bv = v0 / m
                    bp = (m, 1, 0, d0)
                for j in range(2, m):
                    per = m // j
                    for b in range(1, per * per + 1):
                        t = N - b
                        if t < 0:
                            break
                        F = m * m - b * j * j
                        hv, hd = h[F][t]
                        v = (b * j + hv) / m
                        if v > bv + eps:
                            bv = v
                            bp = (m, j, b, hd)
            for m in range(2, M + 1):
                for j in range(2, m):
                    F = m * m - j * j
                    if F > Fmax:
                        continue
                    for c in range(1, N):
                        hv, hd = h[F][N - c]
                        v = (j * V[c] + hv) / m
                        if v > bv + eps:
                            bv = v
                            bp = (m, j, -c, hd)
            V[N] = bv
            plan[N] = bp
        for F in range(1, Fmax + 1):
            if V[N] > hr[F][0] + eps:
                h[F][N] = (V[N], (N,))
            else:
                h[F][N] = hr[F]

    memo = {}

    def build(c):
        if c in memo:
            return memo[c]
        p = plan[c]
        if p[0] == 'one':
            res = [(0.5, 0.5, 0.0, 1.0)]
        else:
            m, j, b, dist = p
            res = []
            covered = set()
            if b < 0:
                cbig = -b
                for (sx, sy, ang, sd) in build(cbig):
                    res.append((sx * j / m, sy * j / m, ang, sd * j / m))
                for a in range(j):
                    for d in range(j):
                        covered.add((a, d))
            if b > 0:
                per = m // j
                for idx in range(b):
                    pp = idx % per
                    qq = idx // per
                    res.append(((pp * j + j / 2.0) / m, (qq * j + j / 2.0) / m, 0.0, j / m))
                    for a in range(j):
                        for d in range(j):
                            covered.add((pp * j + a, qq * j + d))
            free = [(x, y) for y in range(m) for x in range(m) if (x, y) not in covered]
            for (x, y), cc in zip(free, dist):
                if cc <= 0:
                    continue
                for (sx, sy, ang, sd) in build(cc):
                    res.append(((x + sx) / m, (y + sy) / m, ang, sd / m))
        memo[c] = res
        return res

    squares = list(build(n))
    squares = [tuple(min(1.0, max(0.0, float(v))) for v in s) for s in squares]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _guillotine(n, L, deadline):
    """Guillotine DP on an L x L integer lattice (numpy-vectorised)."""
    import numpy as np
    eps = 1e-12
    F = [[None] * (L + 1) for _ in range(L + 1)]
    C = [[None] * (L + 1) for _ in range(L + 1)]
    for w in range(1, L + 1):
        if time.time() > deadline:
            raise TimeoutError
        for h in range(1, L + 1):
            s = float(min(w, h))
            val = np.full(n + 1, s)
            val[0] = 0.0
            ch = [None] + [('o',)] * n
            splits = []
            for x in range(1, w // 2 + 1):
                splits.append(('v', x, F[x][h], F[w - x][h]))
            for y in range(1, h // 2 + 1):
                splits.append(('h', y, F[w][y], F[w][h - y]))
            for kind, pos, A, B in splits:
                for k in range(2, n + 1):
                    seg = A[1:k] + B[k - 1:0:-1]
                    i = int(np.argmax(seg))
                    v = seg[i]
                    if v > val[k] + eps:
                        val[k] = v
                        ch[k] = (kind, pos, i + 1)
            for k in range(1, n + 1):
                if val[k - 1] > val[k] + eps:
                    val[k] = val[k - 1]
                    ch[k] = ('m',)
            F[w][h] = val
            C[w][h] = ch
    total = float(F[L][L][n]) / L
    res = []
    stack = [(0, 0, L, L, n)]
    while stack:
        x0, y0, w, h, k = stack.pop()
        if k <= 0:
            continue
        c = C[w][h][k]
        while c[0] == 'm':
            k -= 1
            if k <= 0:
                break
            c = C[w][h][k]
        if k <= 0:
            continue
        if c[0] == 'o':
            s = min(w, h)
            res.append(((x0 + s / 2.0) / L, (y0 + s / 2.0) / L, 0.0, s / L))
        elif c[0] == 'v':
            x, a = c[1], c[2]
            stack.append((x0, y0, x, h, a))
            stack.append((x0 + x, y0, w - x, h, k - a))
        else:
            y, a = c[1], c[2]
            stack.append((x0, y0, w, y, a))
            stack.append((x0, y0 + y, w, h - y, k - a))
    return total, res


def _total(sq):
    return sum(s[3] for s in sq)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n > 1500:
        k = math.isqrt(n)
        m = k if k * k >= n else k + 1
        if n / m > k:
            side = 1.0 / m
            return [((i % m + 0.5) * side, (i // m + 0.5) * side, 0.0, side)
                    for i in range(n)]
        side = 1.0 / k
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
              for i in range(k) for j in range(k)]
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        return sq[:n]
    t_start = time.time()
    best = _solve_dp(n)
    bs = _total(best)
    if n <= 250:
        Ls = (12, 10, 14, 15, 16, 18, 20, 21, 24, 28, 30)
    else:
        Ls = ()
    deadline = t_start + 40.0
    for L in Ls:
        if time.time() > deadline - 2.0:
            break
        try:
            tot, sq = _guillotine(n, L, deadline)
        except Exception:
            continue
        if tot > bs + 1e-9:
            sq = [tuple(min(1.0, max(0.0, float(v))) for v in s) for s in sq]
            sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
            sq = sq[:n]
            if _total(sq) > bs + 1e-9:
                best = sq
                bs = _total(sq)
    return best
# EVOLVE-BLOCK-END