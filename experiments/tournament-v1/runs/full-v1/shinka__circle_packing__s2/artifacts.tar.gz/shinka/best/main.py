# EVOLVE-BLOCK-START
"""Baseline: a centre circle with two rings, radii shrunk until nothing overlaps.
Layout follows the ShinkaEvolve circle_packing example (Apache-2.0)."""
import numpy as np


def _optimize(n, start, iters=300):
    from scipy.optimize import minimize
    I, J = np.triu_indices(n, 1)
    m = len(I)
    rows = np.arange(m)

    def cons_f(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        d = np.sqrt((x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 + 1e-18)
        return d - r[I] - r[J]

    def cons_j(v):
        x, y = v[:n], v[n:2 * n]
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        d = np.sqrt(dx ** 2 + dy ** 2 + 1e-18)
        Jm = np.zeros((m, 3 * n))
        Jm[rows, I] = dx / d
        Jm[rows, J] = -dx / d
        Jm[rows, n + I] = dy / d
        Jm[rows, n + J] = -dy / d
        Jm[rows, 2 * n + I] = -1
        Jm[rows, 2 * n + J] = -1
        return Jm

    # wall constraints (linear): x-r>=0, 1-x-r>=0, y-r>=0, 1-y-r>=0
    eye = np.eye(n)
    Z = np.zeros((n, n))
    A = np.vstack([
        np.hstack([eye, Z, -eye]),
        np.hstack([-eye, Z, -eye]),
        np.hstack([Z, eye, -eye]),
        np.hstack([Z, -eye, -eye]),
    ])
    b = np.concatenate([np.zeros(n), np.ones(n), np.zeros(n), np.ones(n)])
    # b - sign: rows 2 and 4 have constant 1: 1 - x - r >= 0 -> -x - r + 1 >= 0
    cons = [
        {"type": "ineq", "fun": cons_f, "jac": cons_j},
        {"type": "ineq", "fun": lambda v: A @ v + b * np.repeat([0, 1, 0, 1], n),
         "jac": lambda v: A},
    ]
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    grad = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    res = minimize(lambda v: -np.sum(v[2 * n:]), start, jac=lambda v: grad,
                   bounds=bounds, constraints=cons, method="SLSQP",
                   options={"maxiter": iters, "ftol": 1e-10})
    return res.x


def _finalize(n, v):
    c = np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0.0, 1.0)
    return c, max_radii(c, np.maximum(v[2 * n:], 0.0))


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    try:
        t0 = time.time()
        budget = 150.0
        rng = np.random.default_rng(0)
        best_v, best_s = None, -1.0
        it = 0
        while time.time() - t0 < budget:
            if best_v is not None and it % 3 != 0:
                # basin hopping: perturb best
                v0 = best_v.copy()
                k = rng.integers(1, 5)
                idx = rng.choice(n, k, replace=False)
                v0[idx] = rng.random(k)
                v0[n + idx] = rng.random(k)
                v0[:2 * n] += rng.normal(0, 0.02, 2 * n)
                v0[2 * n:] = 0.03
            else:
                if it % 2 == 0:
                    g = np.array([[(i + 0.5) / 5, (j + 0.5) / 5] for i in range(5) for j in range(5)])
                    g = np.vstack([g, rng.random((n - 25, 2))]) if n > 25 else g[:n]
                    g = g + rng.normal(0, 0.03, g.shape)
                else:
                    g = rng.random((n, 2))
                v0 = np.concatenate([g[:, 0], g[:, 1], np.full(n, 0.03)])
            v0[:2 * n] = np.clip(v0[:2 * n], 0.0, 1.0)
            it += 1
            try:
                v = _optimize(n, v0)
                c, r = _finalize(n, v)
            except Exception:
                continue
            s = r.sum()
            if s > best_s:
                best_s, best_v = s, np.concatenate([c[:, 0], c[:, 1], r])
        if best_v is not None:
            c = np.stack([best_v[:n], best_v[n:2 * n]], axis=1)
            return c, max_radii(c, best_v[2 * n:])
    except Exception:
        pass
    return _baseline(n)


def _baseline(n=26):
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    centers += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()] for _ in range(n - len(centers))]
    centers = np.clip(np.array(centers[:n]), 0.01, 0.99)
    return centers, max_radii(centers)


def max_radii(centers, r0=None):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    if r0 is not None:
        radii = np.minimum(radii, r0)
    for _ in range(200 if r0 is not None else 50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d * (1 - 1e-12 if r0 is not None else 1):
                    scale = d * (1 - 1e-12 if r0 is not None else 1) / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END