# EVOLVE-BLOCK-START
"""Adaptive basin hopping (SLSQP) with exact LP radii polish for circle packing."""
import numpy as np


def _optimize(n, start, iters=300):
    from scipy.optimize import minimize
    I, J = np.triu_indices(n, 1)
    m = len(I)
    rows = np.arange(m)

    def cons_f(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        d = np.sqrt((x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 + 1e-18)
        return d - r[I] - r[J]

    def cons_j(v):
        x, y = v[:n], v[n:2 * n]
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        d = np.sqrt(dx ** 2 + dy ** 2 + 1e-18)
        Jm = np.zeros((m, 3 * n))
        Jm[rows, I] = dx / d
        Jm[rows, J] = -dx / d
        Jm[rows, n + I] = dy / d
        Jm[rows, n + J] = -dy / d
        Jm[rows, 2 * n + I] = -1
        Jm[rows, 2 * n + J] = -1
        return Jm

    eye = np.eye(n)
    Z = np.zeros((n, n))
    A = np.vstack([
        np.hstack([eye, Z, -eye]),
        np.hstack([-eye, Z, -eye]),
        np.hstack([Z, eye, -eye]),
        np.hstack([Z, -eye, -eye]),
    ])
    bconst = np.concatenate([np.zeros(n), np.ones(n), np.zeros(n), np.ones(n)])
    cons = [
        {"type": "ineq", "fun": cons_f, "jac": cons_j},
        {"type": "ineq", "fun": lambda v: A @ v + bconst, "jac": lambda v: A},
    ]
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    grad = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    res = minimize(lambda v: -np.sum(v[2 * n:]), start, jac=lambda v: grad,
                   bounds=bounds, constraints=cons, method="SLSQP",
                   options={"maxiter": iters, "ftol": 1e-10})
    return res.x


def _lp_radii(c):
    """Exact optimal radii for fixed centres via linear programming."""
    from scipy.optimize import linprog
    n = len(c)
    I, J = np.triu_indices(n, 1)
    m = len(I)
    d = np.linalg.norm(c[I] - c[J], axis=1)
    A = np.zeros((m, n))
    A[np.arange(m), I] = 1
    A[np.arange(m), J] = 1
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    wall = np.maximum(wall, 0.0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d,
                  bounds=[(0, w) for w in wall], method="highs")
    if res.status == 0:
        return np.maximum(res.x, 0.0)
    return None


def _finalize(n, v):
    c = np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0.0, 1.0)
    r0 = np.maximum(v[2 * n:], 0.0)
    r = max_radii(c, r0)
    try:
        rl = _lp_radii(c)
        if rl is not None:
            rl = max_radii(c, rl)
            if rl.sum() > r.sum():
                r = rl
    except Exception:
        pass
    return c, r


def _largest_hole(C, R, rng, samples=3000):
    P = rng.random((samples, 2))
    if len(C) > 0:
        D = np.linalg.norm(P[:, None, :] - C[None, :, :], axis=2) - R[None, :]
        clear = D.min(axis=1)
    else:
        clear = np.full(samples, 1.0)
    wall = np.minimum.reduce([P[:, 0], P[:, 1], 1 - P[:, 0], 1 - P[:, 1]])
    sc = np.minimum(clear, wall)
    return P[int(np.argmax(sc))]


def _perturb(n, best_v, move, sigma, rng):
    x = best_v[:n].copy()
    y = best_v[n:2 * n].copy()
    r = best_v[2 * n:].copy()
    rinit = np.full(n, 0.03)
    if move == 0:
        k = int(rng.integers(1, 5))
        idx = rng.choice(n, k, replace=False)
        x[idx] = rng.random(k)
        y[idx] = rng.random(k)
    elif move == 1:
        k = int(rng.integers(1, 3))
        order = np.argsort(r)
        for t in range(k):
            i = order[t]
            mask = np.ones(n, bool)
            mask[i] = False
            C = np.stack([x[mask], y[mask]], axis=1)
            p = _largest_hole(C, r[mask], rng)
            x[i], y[i] = p
    else:
        # swap a small circle with a larger neighbour; keep radii as init
        order = np.argsort(r)
        i = int(order[rng.integers(0, max(1, n // 3))])
        d = np.hypot(x - x[i], y - y[i])
        d[i] = 9.0
        cand = np.argsort(d)[:5]
        cand = [j for j in cand if r[j] > r[i]]
        if not cand:
            cand = [int(np.argmin(d))]
        j = int(cand[rng.integers(0, len(cand))])
        x[i], x[j] = x[j], x[i]
        y[i], y[j] = y[j], y[i]
        rinit = r.copy()
        rinit[i], rinit[j] = r[j], r[i]
        rinit *= 0.8
    x += rng.normal(0, sigma, n)
    y += rng.normal(0, sigma, n)
    v0 = np.concatenate([np.clip(x, 0, 1), np.clip(y, 0, 1), rinit])
    return v0


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    try:
        t0 = time.time()
        budget = 240.0
        target = 2.63598 if n == 26 else 1e9
        rng = np.random.default_rng(1)
        best_v, best_s = None, -1.0
        it = 0
        sigmas = [0.005, 0.02, 0.05]
        move_score = np.ones(3)
        sig_score = np.ones(3)
        while time.time() - t0 < budget:
            it += 1
            mv = sg = -1
            if best_v is not None and it % 5 != 0:
                mv = int(rng.choice(3, p=move_score / move_score.sum()))
                sg = int(rng.choice(3, p=sig_score / sig_score.sum()))
                v0 = _perturb(n, best_v, mv, sigmas[sg], rng)
            else:
                if it % 2 == 0 and n >= 25:
                    g = np.array([[(i + 0.5) / 5, (j + 0.5) / 5] for i in range(5) for j in range(5)])
                    g = np.vstack([g, rng.random((n - 25, 2))])
                    g = g + rng.normal(0, 0.03, g.shape)
                else:
                    g = rng.random((n, 2))
                v0 = np.concatenate([g[:, 0], g[:, 1], np.full(n, 0.03)])
                v0[:2 * n] = np.clip(v0[:2 * n], 0.0, 1.0)
            try:
                v = _optimize(n, v0)
                c, r = _finalize(n, v)
            except Exception:
                continue
            s = r.sum()
            if s > best_s + 1e-10:
                if mv >= 0:
                    move_score[mv] += 3.0
                    sig_score[sg] += 3.0
                best_s, best_v = s, np.concatenate([c[:, 0], c[:, 1], r])
                if best_s >= target:
                    break
        if best_v is not None:
            c = np.stack([best_v[:n], best_v[n:2 * n]], axis=1)
            return c, max_radii(c, best_v[2 * n:])
    except Exception:
        pass
    return _baseline(n)


def _baseline(n=26):
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    centers += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()] for _ in range(n - len(centers))]
    centers = np.clip(np.array(centers[:n]), 0.01, 0.99)
    return centers, max_radii(centers)


def max_radii(centers, r0=None):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    if r0 is not None:
        radii = np.minimum(radii, r0)
    for _ in range(200 if r0 is not None else 50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d * (1 - 1e-12 if r0 is not None else 1):
                    scale = d * (1 - 1e-12 if r0 is not None else 1) / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END