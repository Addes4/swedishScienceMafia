# EVOLVE-BLOCK-START
"""Baseline: a centre circle with two rings, radii shrunk until nothing overlaps.
Layout follows the ShinkaEvolve circle_packing example (Apache-2.0)."""
import numpy as np


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    from scipy.optimize import minimize, linprog
    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    m = len(I)
    rows = np.arange(m)

    def lp_radii(c):
        d = np.linalg.norm(c[I] - c[J], axis=1)
        wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
        wall = np.maximum(wall, 0)
        A = np.zeros((m, n))
        A[rows, I] = 1
        A[rows, J] = 1
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
        if res.status == 0:
            return np.maximum(res.x, 0)
        return max_radii(c)

    def cons_f(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        pair = (x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 - (r[I] + r[J]) ** 2
        return np.concatenate([pair, x - r, 1 - x - r, y - r, 1 - y - r])

    wall_jac = np.zeros((4 * n, 3 * n))
    ar = np.arange(n)
    wall_jac[ar, ar] = 1; wall_jac[ar, 2 * n + ar] = -1
    wall_jac[n + ar, ar] = -1; wall_jac[n + ar, 2 * n + ar] = -1
    wall_jac[2 * n + ar, n + ar] = 1; wall_jac[2 * n + ar, 2 * n + ar] = -1
    wall_jac[3 * n + ar, n + ar] = -1; wall_jac[3 * n + ar, 2 * n + ar] = -1

    def cons_j(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        Jm = np.zeros((m, 3 * n))
        dx = 2 * (x[I] - x[J]); dy = 2 * (y[I] - y[J]); s = -2 * (r[I] + r[J])
        Jm[rows, I] = dx; Jm[rows, J] = -dx
        Jm[rows, n + I] = dy; Jm[rows, n + J] = -dy
        Jm[rows, 2 * n + I] = s; Jm[rows, 2 * n + J] = s
        return np.vstack([Jm, wall_jac])

    gobj = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def optimize(c0, maxiter=300):
        r0 = lp_radii(c0)
        v0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
        try:
            res = minimize(lambda v: -np.sum(v[2 * n:]), v0, jac=lambda v: gobj,
                           bounds=bounds, constraints=[{"type": "ineq", "fun": cons_f, "jac": cons_j}],
                           method="SLSQP", options={"maxiter": maxiter, "ftol": 1e-10})
            v = res.x
        except Exception:
            v = v0
        c = np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0, 1)
        r = lp_radii(c)
        return c, r

    def init(kind):
        if kind == 0:
            return rng.random((n, 2))
        # jittered rows layout
        rowsn = [5, 5, 6, 5, 5]
        pts = []
        for k, cnt in enumerate(rowsn):
            for q in range(cnt):
                pts.append([(q + 0.5 + 0.5 * (k % 2) * (cnt < 6)) / (cnt + (0.5 if cnt < 6 else 0)),
                            (k + 0.5) / len(rowsn)])
        pts = np.array(pts[:n])
        return np.clip(pts + rng.normal(0, 0.03, pts.shape), 0.02, 0.98)

    best_c, best_r, best_s = None, None, -1
    it = 0
    while time.time() - t0 < budget:
        if best_c is None or it % 3 == 0:
            c0 = init(it % 2)
        else:
            c0 = best_c.copy()
            k = rng.integers(1, 4)
            idx = rng.choice(n, k, replace=False)
            if rng.random() < 0.5:
                c0[idx] = rng.random((k, 2))
            else:
                c0 += rng.normal(0, 0.02, c0.shape)
            c0 = np.clip(c0, 0.01, 0.99)
        it += 1
        c, r = optimize(c0)
        s = r.sum()
        if s > best_s:
            best_c, best_r, best_s = c, r, s
    centers = best_c
    radii = np.maximum(best_r - 1e-12, 0.0)
    return centers, radii


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END