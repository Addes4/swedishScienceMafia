# EVOLVE-BLOCK-START
"""Multistart SLSQP circle packing (max sum of radii), with ring-layout initialisation
from the baseline and a final polish of the best solution."""
import numpy as np


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    from scipy.optimize import minimize

    t0 = time.time()
    budget = 120.0
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    m = len(I)
    ar = np.arange(m)
    an = np.arange(n)

    def obj(v):
        return -v[2 * n:].sum()

    gobj = np.zeros(3 * n)
    gobj[2 * n:] = -1.0

    def jobj(v):
        return gobj

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        c1 = (x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 - (r[I] + r[J]) ** 2
        return np.concatenate([c1, x - r, 1 - x - r, y - r, 1 - y - r])

    def jcons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        Jm = np.zeros((m + 4 * n, 3 * n))
        dx = x[I] - x[J]; dy = y[I] - y[J]; s = r[I] + r[J]
        Jm[ar, I] = 2 * dx
        Jm[ar, J] = -2 * dx
        Jm[ar, n + I] = 2 * dy
        Jm[ar, n + J] = -2 * dy
        Jm[ar, 2 * n + I] = -2 * s
        Jm[ar, 2 * n + J] = -2 * s
        o = m
        Jm[o + an, an] = 1; Jm[o + an, 2 * n + an] = -1
        o += n
        Jm[o + an, an] = -1; Jm[o + an, 2 * n + an] = -1
        o += n
        Jm[o + an, n + an] = 1; Jm[o + an, 2 * n + an] = -1
        o += n
        Jm[o + an, n + an] = -1; Jm[o + an, 2 * n + an] = -1
        return Jm

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    constraints = [{"type": "ineq", "fun": cons, "jac": jcons}]

    def finalize(v):
        c = np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0, 1)
        r = np.maximum(v[2 * n:], 0)
        r = np.minimum(r, np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]]))
        d = np.sqrt(((c[I] - c[J]) ** 2).sum(1))
        for _ in range(200):
            over = r[I] + r[J] - d
            if over.max() <= 0:
                break
            for k in np.nonzero(over > 0)[0]:
                i, j = I[k], J[k]
                s = r[i] + r[j]
                if s > d[k]:
                    f = d[k] / s
                    r[i] *= f; r[j] *= f
        r = np.maximum(r * (1 - 1e-12) - 1e-13, 0)
        return c, r

    def init(k):
        mode = k % 4
        if mode == 0:
            pts = rng.random((n, 2))
        elif mode == 1:
            rows = int(rng.integers(5, 7))
            pts = []
            per = [5, 5, 5, 5, 6] if rows == 5 else [4, 5, 4, 5, 4, 4]
            for ri, cnt in enumerate(per):
                for ci in range(cnt):
                    pts.append([(ci + 0.5 + 0.5 * (ri % 2) * (cnt < 6)) / (max(per) + 0.5),
                                (ri + 0.5) / len(per)])
            pts = np.array(pts)
            if len(pts) > n:
                pts = pts[rng.permutation(len(pts))[:n]]
            while len(pts) < n:
                pts = np.vstack([pts, rng.random((1, 2))])
            pts = pts + rng.normal(0, 0.03, pts.shape)
        elif mode == 2:
            g = 5
            xs = (np.arange(g) + 0.5) / g
            pts = np.array([[a, b] for a in xs for b in xs])
            pts = np.vstack([pts, rng.random((max(n - 25, 0), 2))])[:n]
            pts = pts + rng.normal(0, 0.04, pts.shape)
        else:
            pl = [[0.5, 0.5]]
            pl += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
            pl += [[0.5 + 0.42 * np.cos(2 * np.pi * i / 16), 0.5 + 0.42 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
            pts = np.array(pl)
            if len(pts) > n:
                pts = pts[:n]
            while len(pts) < n:
                pts = np.vstack([pts, rng.random((1, 2))])
            pts = pts + rng.normal(0, 0.03, pts.shape)
        pts = np.clip(pts, 0.03, 0.97)
        r0 = np.full(n, 0.05) * rng.uniform(0.5, 1.0, n)
        return np.concatenate([pts[:, 0], pts[:, 1], r0])

    best_val = -1.0
    best = None
    best_x = None
    k = 0
    while time.time() - t0 < budget:
        v0 = init(k)
        k += 1
        try:
            res = minimize(obj, v0, jac=jobj, method="SLSQP", bounds=bounds,
                           constraints=constraints,
                           options={"maxiter": 300, "ftol": 1e-10})
        except Exception:
            continue
        c, r = finalize(res.x)
        val = r.sum()
        if val > best_val:
            best_val = val
            best = (c, r)
            best_x = res.x.copy()

    if best is None:
        centers = np.clip(rng.random((n, 2)), 0.05, 0.95)
        return centers, max_radii(centers)

    # polish the best solution
    try:
        res = minimize(obj, best_x, jac=jobj, method="SLSQP", bounds=bounds,
                       constraints=constraints,
                       options={"maxiter": 500, "ftol": 1e-14})
        c, r = finalize(res.x)
        if r.sum() > best_val:
            best = (c, r)
    except Exception:
        pass
    return best


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END