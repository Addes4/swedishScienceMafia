# EVOLVE-BLOCK-START
"""Layered simplex sets {x>=0 in Z^d : |x| in S}, closed-form search over (d,n,S),
random-weight integer embedding, exact verification of the top candidates."""
import math
import time
import heapq
import random
from math import comb, factorial
from itertools import combinations_with_replacement

import numpy as np

MAXSIZE = 4000


def _comp(a, j):
    if a == 0:
        return 1 if j == 0 else 0
    if j == 0:
        return 0
    return comb(a - 1, j - 1)


def _gtable(d, n):
    g = [[0] * (n + 1) for _ in range(n + 1)]
    fd = factorial(d)
    for a in range(n + 1):
        for b in range(n + 1):
            tot = 0
            for j in range(0, min(a, d) + 1):
                ca = _comp(a, j)
                if ca == 0:
                    continue
                for k in range(0, min(b, d - j) + 1):
                    cb = _comp(b, k)
                    if cb == 0:
                        continue
                    tot += fd // (factorial(j) * factorial(k) * factorial(d - j - k)) * ca * cb
            g[a][b] = tot
    return g


def _search(tlimit):
    t0 = time.time()
    heap = []
    for n in range(1, 11):
        for d in range(2, 61):
            if time.time() - t0 > tlimit:
                break
            L = [comb(s + d - 1, d - 1) for s in range(n + 1)]
            if L[n] > MAXSIZE and n > 1 and False:
                continue
            g = None
            nm = 1 << (n + 1)
            size = [0] * nm
            for m in range(1, nm):
                low = (m & -m).bit_length() - 1
                size[m] = size[m & (m - 1)] + L[low]
            for S in range(1, nm):
                sz = size[S]
                if sz > MAXSIZE or sz < 3:
                    continue
                if not (S >> n) & 1:
                    continue  # require top layer n present (normalisation)
                if g is None:
                    g = _gtable(d, n)
                elems = [s for s in range(n + 1) if (S >> s) & 1]
                ts = set()
                for x in elems:
                    for y in elems:
                        ts.add(x + y)
                N = sum(comb(t + d - 1, d - 1) for t in ts)
                D = 0
                for a in range(n + 1):
                    Sa = S >> a
                    ga = g[a]
                    for b in range(n + 1):
                        if Sa & (S >> b):
                            D += ga[b]
                if N < 2 or D < 2:
                    continue
                sc = math.log(D) / math.log(N) + (1 - 1.0 / sz) / 100
                item = (sc, d, n, S)
                if len(heap) < 12:
                    heapq.heappush(heap, item)
                elif sc > heap[0][0]:
                    heapq.heapreplace(heap, item)
    return sorted(heap, reverse=True)


def _build(d, n, S, rng):
    W = 10 ** 15 // max(n, 1)
    w = [rng.randint(1, W) for _ in range(d)]
    pts = set()
    for s in range(n + 1):
        if (S >> s) & 1:
            if s == 0:
                pts.add(0)
            else:
                for c in combinations_with_replacement(range(d), s):
                    pts.add(sum(w[i] for i in c))
    return sorted(pts)


def _score(A):
    arr = np.array(A, dtype=np.int64)
    m = len(arr)
    if m < 2:
        return -1.0
    s = (arr[:, None] + arr[None, :]).ravel()
    s.sort()
    ns = 1 + int(np.count_nonzero(s[1:] != s[:-1]))
    del s
    df = (arr[:, None] - arr[None, :]).ravel()
    df.sort()
    nd = 1 + int(np.count_nonzero(df[1:] != df[:-1]))
    del df
    return math.log(nd) / math.log(ns) + (1 - 1.0 / m) / 100


def solve():
    t0 = time.time()
    cands = _search(45.0)
    rng = random.Random(12345)
    best_sc, best_A = -1.0, None
    for (sc, d, n, S) in cands:
        for _ in range(2):
            if time.time() - t0 > 100:
                break
            A = _build(d, n, S, rng)
            if len(A) > MAXSIZE or len(A) < 2:
                continue
            if max(abs(x) for x in A) > 10 ** 15:
                continue
            a_sc = _score(A)
            if a_sc > best_sc:
                best_sc, best_A = a_sc, A
    if best_A is None:
        d, n = 15, 4
        best_A = _build(d, n, (1 << (n + 1)) - 1, rng)
    return [int(x) for x in best_A]
# EVOLVE-BLOCK-END
