# EVOLVE-BLOCK-START
"""Simplex lattice points and 0/1 Hamming-ball sets embedded in integers; exact formulas."""
import math
from math import comb, factorial
from itertools import combinations


def _counts(d, n):
    sums = comb(2 * n + d, d)
    diffs = 0
    for j in range(0, min(n, d) + 1):
        for k in range(0, min(n, d - j) + 1):
            multi = factorial(d) // (factorial(j) * factorial(k) * factorial(d - j - k))
            diffs += multi * comb(n, j) * comb(n, k)
    return diffs, sums


def _counts01(d, n):
    sums = 0
    for c2 in range(0, min(n, d) + 1):
        for c1 in range(0, d - c2 + 1):
            if c1 + 2 * c2 > 2 * n:
                break
            sums += factorial(d) // (factorial(c1) * factorial(c2) * factorial(d - c1 - c2))
    diffs = 0
    for j in range(0, min(n, d) + 1):
        for k in range(0, min(n, d - j) + 1):
            diffs += (factorial(d) // (factorial(j) * factorial(k) * factorial(d - j - k))
                      * 1)
    # diffs: P,N disjoint with |P|<=n,|N|<=n (each vector has weight ≤ n; any such pair realizable)
    return diffs, sums


def _simplex(d, n):
    B = 2 * n + 1
    states = [(0, 0)]
    for i in range(d):
        w = B ** i
        new = []
        for v, u in states:
            for x in range(0, n - u + 1):
                new.append((v + x * w, u + x))
        states = new
    return [v for v, u in states]


def _ball01(d, n):
    ws = [3 ** i for i in range(d)]
    out = []
    for k in range(0, n + 1):
        for c in combinations(range(d), k):
            out.append(sum(ws[i] for i in c))
    return out


def solve():
    best_s, best = -1.0, None
    for d in range(1, 80):
        for n in range(1, 80):
            size = comb(n + d, d)
            if size < 3 or size > 4000:
                continue
            B = 2 * n + 1
            if n * (B ** (d - 1)) > 9.9e14:
                continue
            df, sm = _counts(d, n)
            if sm < 2:
                continue
            s = math.log(df) / math.log(sm) + (1 - 1 / size) / 100
            if s > best_s:
                best_s, best = s, ("s", d, n)
    for d in range(2, 32):
        for n in range(1, d):
            size = sum(comb(d, i) for i in range(n + 1))
            if size < 3 or size > 4000:
                continue
            df, sm = _counts01(d, n)
            if sm < 2:
                continue
            s = math.log(df) / math.log(sm) + (1 - 1 / size) / 100
            if s > best_s:
                best_s, best = s, ("b", d, n)
    t, d, n = best
    a = _simplex(d, n) if t == "s" else _ball01(d, n)
    return sorted(set(int(x) for x in a))
# EVOLVE-BLOCK-END
