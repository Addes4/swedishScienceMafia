import math


def _counts(d, n):
    s = math.comb(2 * n + d, d)
    t = 0
    for j in range(0, min(d, n) + 1):
        cj = math.comb(n, j)
        for m in range(0, min(d - j, n) + 1):
            t += (math.factorial(d) // (math.factorial(j) * math.factorial(m)
                                        * math.factorial(d - j - m))) * cj * math.comb(n, m)
    return t, s


def _build(d, n):
    B = 2 * n + 1
    pts = [(n, 0)]
    for i in range(d):
        w = B ** i
        new = []
        for rem, val in pts:
            for x in range(rem + 1):
                new.append((rem - x, val + x * w))
        pts = new
    return sorted(v for _, v in pts)


def solve():
    best = None
    best_sc = -1.0
    for d in range(1, 60):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 5 * 10 ** 14:
                break
            if size < 2:
                continue
            t, s = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    if best is None:
        return [7, 15, 18, 22, -3, -2]
    return _build(*best)
