# EVOLVE-BLOCK-START
"""Simplex lattice points embedded in integers, then local search toggling pool points."""
import math
import random
import time
from math import comb, factorial


def _counts(d, n):
    sums = comb(2 * n + d, d)
    diffs = 0
    for j in range(0, min(n, d) + 1):
        for k in range(0, min(n, d - j) + 1):
            multi = factorial(d) // (factorial(j) * factorial(k) * factorial(d - j - k))
            diffs += multi * comb(n, j) * comb(n, k)
    return diffs, sums


def _simplex(d, n, B):
    states = [(0, 0)]
    for i in range(d):
        w = B ** i
        new = []
        for v, u in states:
            for x in range(0, n - u + 1):
                new.append((v + x * w, u + x))
        states = new
    return [v for v, u in states]


def _score(D, S, size):
    return math.log(D) / math.log(S) + (1 - 1 / size) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(1, 80):
        for n in range(1, 80):
            size = comb(n + d, d)
            if size < 3 or size > 4000:
                continue
            B = 2 * n + 1
            if n * (B ** (d - 1)) > 9.9e14:
                continue
            df, sm = _counts(d, n)
            if sm < 2:
                continue
            s = _score(df, sm, size)
            cands.append((s, d, n))
    cands.sort(reverse=True)
    s0, d, n = cands[0]
    base = sorted(_simplex(d, n, 2 * n + 1))

    # try local search with pool of radius n+1
    n2 = n + 1
    B2 = 2 * n2 + 1
    ok = (n2 * (B2 ** (d - 1)) <= 9.9e14) and comb(n2 + d, d) <= 60000
    if not ok:
        return base

    pool = _simplex(d, n2, B2)
    init = _simplex(d, n, B2)
    A = list(init)
    inA = set(A)
    poolrest = [p for p in pool if p not in inA]

    cs = {}
    cd = {}
    nS = 0
    nD = 0

    def addsum(s, sign):
        nonlocal nS
        c = cs.get(s, 0)
        c2 = c + sign
        cs[s] = c2
        if c == 0 and c2 > 0:
            nS += 1
        elif c > 0 and c2 == 0:
            nS -= 1

    def adddiff(s, sign):
        nonlocal nD
        c = cd.get(s, 0)
        c2 = c + sign
        cd[s] = c2
        if c == 0 and c2 > 0:
            nD += 1
        elif c > 0 and c2 == 0:
            nD -= 1

    # initial counts
    for i, a in enumerate(A):
        addsum(2 * a, 1)
        adddiff(0, 1)
        for b in A[i + 1:]:
            addsum(a + b, 1)
            adddiff(a - b, 1)
            adddiff(b - a, 1)

    def op_add(x):
        for a in A:
            addsum(a + x, 1)
            adddiff(x - a, 1)
            adddiff(a - x, 1)
        addsum(2 * x, 1)
        adddiff(0, 1)
        A.append(x)

    def op_remove_idx(i):
        x = A[i]
        A[i] = A[-1]
        A.pop()
        for a in A:
            addsum(a + x, -1)
            adddiff(x - a, -1)
            adddiff(a - x, -1)
        addsum(2 * x, -1)
        adddiff(0, -1)
        return x

    cur = _score(nD, nS, len(A))
    best = cur
    bestA = list(A)
    inA = set(A)
    outlist = list(poolrest)
    limit = 100.0
    rng = random.Random(1)
    while time.time() - t0 < limit:
        if rng.random() < 0.5 and len(A) > 3:
            i = rng.randrange(len(A))
            x = op_remove_idx(i)
            new = _score(nD, nS, len(A)) if nS > 1 else -1
            if new >= cur:
                cur = new
                inA.discard(x)
                outlist.append(x)
            else:
                op_add(x)
        else:
            if len(A) >= 4000 or not outlist:
                continue
            j = rng.randrange(len(outlist))
            x = outlist[j]
            op_add(x)
            new = _score(nD, nS, len(A))
            if new >= cur:
                cur = new
                outlist[j] = outlist[-1]
                outlist.pop()
                inA.add(x)
            else:
                op_remove_idx(len(A) - 1)
        if cur > best + 1e-12:
            best = cur
            bestA = list(A)
    if best > s0 + 1e-12:
        return sorted(set(int(x) for x in bestA))
    return base
# EVOLVE-BLOCK-END
