# EVOLVE-BLOCK-START
"""Simplex lattice points embedded in integers; search over (d, n)."""
import math
import time
import numpy as np
from math import comb


def _score_arr(a):
    a = np.asarray(a, dtype=np.int64)
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _simplex(d, n):
    B = 2 * n + 1
    pts = [0]
    # build recursively: dimension by dimension with remaining budget
    # state: (value, used)
    states = [(0, 0)]
    for i in range(d):
        w = B ** i
        new = []
        for v, u in states:
            for x in range(0, n - u + 1):
                new.append((v + x * w, u + x))
        states = new
    return [v for v, u in states]


def solve():
    start = time.time()
    best, best_s = [0, 1], -1.0
    cands = []
    for d in range(2, 40):
        for n in range(1, 40):
            size = comb(n + d, d)
            if size < 20 or size > 2500:
                continue
            B = 2 * n + 1
            if n * (B ** d) > 4e14:
                continue
            cands.append((size, d, n))
    cands.sort()
    for size, d, n in cands:
        if time.time() - start > 80:
            break
        a = _simplex(d, n)
        s = _score_arr(a)
        if s > best_s:
            best_s, best = s, a
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
