# EVOLVE-BLOCK-START
"""Simplex lattice points (optionally with coordinate caps) embedded in integers."""
import math
import time
import numpy as np
from math import comb, factorial


def _counts(d, n):
    sums = comb(2 * n + d, d)
    diffs = 0
    for j in range(0, min(n, d) + 1):
        for k in range(0, min(n, d - j) + 1):
            multi = factorial(d) // (factorial(j) * factorial(k) * factorial(d - j - k))
            diffs += multi * comb(n, j) * comb(n, k)
    return diffs, sums


def _capped_size(d, n, m):
    poly = [1] + [0] * n
    base = [1 if i <= m else 0 for i in range(n + 1)]
    for _ in range(d):
        new = [0] * (n + 1)
        for i, a in enumerate(poly):
            if a == 0:
                continue
            for j in range(0, min(m, n - i) + 1):
                new[i + j] += a
        poly = new
        if sum(poly) > 10 ** 7:
            return 10 ** 7
    return sum(poly)


def _points(d, n, m):
    B = 2 * m + 1
    vals = np.zeros(1, dtype=np.int64)
    us = np.zeros(1, dtype=np.int64)
    for i in range(d):
        w = B ** i
        nv, nu = [], []
        for x in range(0, m + 1):
            mask = us + x <= n
            nv.append(vals[mask] + x * w)
            nu.append(us[mask] + x)
        vals = np.concatenate(nv)
        us = np.concatenate(nu)
    return vals


def _uniq_count(a, sign):
    parts = []
    N = len(a)
    ch = max(1, 1500000 // N)
    for s in range(0, N, ch):
        blk = a[s:s + ch]
        if sign > 0:
            r = (blk[:, None] + a[None, :]).ravel()
        else:
            r = (blk[:, None] - a[None, :]).ravel()
        parts.append(np.unique(r))
    return len(np.unique(np.concatenate(parts)))


def _score(a):
    a = np.asarray(a, dtype=np.int64)
    S = _uniq_count(a, 1)
    D = _uniq_count(a, -1)
    return math.log(D) / math.log(S) + (1 - 1 / len(a)) / 100


def solve():
    t0 = time.time()
    best_s, best_dn = -1.0, (2, 2)
    for d in range(1, 80):
        for n in range(1, 80):
            size = comb(n + d, d)
            if size < 3 or size > 4000:
                continue
            B = 2 * n + 1
            if n * (B ** (d - 1)) > 9.9e14:
                continue
            df, sm = _counts(d, n)
            if sm < 2:
                continue
            s = math.log(df) / math.log(sm) + (1 - 1 / size) / 100
            if s > best_s:
                best_s, best_dn = s, (d, n)
    d0, n0 = best_dn
    best_set = _points(d0, n0, n0)
    best_val = best_s

    cands = []
    for d in range(max(2, d0 - 2), d0 + 4):
        for n in range(2, 70):
            for m in range(max(2, (n + 2) // 3), n):
                B = 2 * m + 1
                if B ** d > 9e14:
                    continue
                sz = _capped_size(d, n, m)
                if 2000 <= sz <= 4000:
                    cands.append((sz, d, n, m))
    cands.sort(reverse=True)
    for sz, d, n, m in cands:
        if time.time() - t0 > 95:
            break
        try:
            pts = _points(d, n, m)
            if len(pts) > 4000:
                continue
            s = _score(pts)
        except Exception:
            continue
        if s > best_val:
            best_val = s
            best_set = pts
    return sorted(set(int(x) for x in best_set))
# EVOLVE-BLOCK-END
