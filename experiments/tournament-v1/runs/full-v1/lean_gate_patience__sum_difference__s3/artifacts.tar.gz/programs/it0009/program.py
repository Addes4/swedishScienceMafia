import math
import time
import numpy as np


def _counts(d, n):
    s = math.comb(2 * n + d, d)
    t = 0
    for j in range(0, min(d, n) + 1):
        cj = math.comb(n, j)
        for m in range(0, min(d - j, n) + 1):
            t += (math.factorial(d) // (math.factorial(j) * math.factorial(m)
                                        * math.factorial(d - j - m))) * cj * math.comb(n, m)
    return t, s


def _build(d, n):
    B = 2 * n + 1
    pts = [(n, 0)]
    for i in range(d):
        w = B ** i
        new = []
        for rem, val in pts:
            for x in range(rem + 1):
                new.append((rem - x, val + x * w))
        pts = new
    return sorted(v for _, v in pts)


def _coords(d, n):
    rem = np.array([n], dtype=np.int16)
    X = np.zeros((1, 0), dtype=np.int16)
    for i in range(d):
        rs = []
        Xs = []
        for x in range(n + 1):
            m = rem >= x
            if not m.any():
                break
            Xm = X[m]
            col = np.full((Xm.shape[0], 1), x, dtype=np.int16)
            Xs.append(np.hstack([Xm, col]))
            rs.append(rem[m] - x)
        X = np.vstack(Xs)
        rem = np.concatenate(rs)
    return X


def _ucount(arr):
    arr.sort()
    return 1 + int(np.count_nonzero(arr[1:] != arr[:-1]))


def _score_vals(vals):
    a = np.sort(vals.astype(np.int64))
    k = len(a)
    s = (a[:, None] + a[None, :]).ravel()
    ns = _ucount(s)
    del s
    df = (a[:, None] - a[None, :]).ravel()
    nd = _ucount(df)
    del df
    return math.log(nd) / math.log(ns) + (1 - 1 / k) / 100


def solve():
    t0 = time.time()
    best = None
    best_sc = -1.0
    for d in range(1, 60):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 5 * 10 ** 14:
                break
            if size < 2:
                continue
            t, s = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    base = _build(*best) if best else [7, 15, 18, 22, -3, -2]
    result = base
    result_sc = best_sc

    rng = np.random.default_rng(12345)
    configs = []
    for d in range(5, 14):
        for n in range(3, 20):
            size = math.comb(n + d, d)
            if size < 6000 or size > 300000:
                continue
            if (2 * n + 1) ** d > 5 * 10 ** 14:
                continue
            configs.append((d, n))
    if not configs:
        return result
    cache = {}
    deadline = t0 + 95
    trial = 0
    while time.time() < deadline - 6:
        trial += 1
        d, n = configs[int(rng.integers(len(configs)))]
        size = math.comb(n + d, d)
        if (d, n) not in cache:
            if len(cache) > 6:
                cache.clear()
            X = _coords(d, n)
            B = 2 * n + 1
            w = np.array([B ** i for i in range(d)], dtype=np.int64)
            vals = X.astype(np.int64) @ w
            cache[(d, n)] = (X.astype(np.int64), vals)
        X, vals = cache[(d, n)]
        pmin = max(2, size // 4000)
        pmax = max(pmin + 1, size // 1500)
        p = int(rng.integers(pmin, pmax + 1))
        c = rng.integers(0, p, size=d)
        if not c.any():
            continue
        f = (X @ c) % p
        cnt = np.bincount(f, minlength=p)
        ok = np.nonzero((cnt >= 1000) & (cnt <= 4000))[0]
        if len(ok) == 0:
            continue
        r = int(ok[int(rng.integers(len(ok)))])
        sel = vals[f == r]
        if time.time() > deadline - 6:
            break
        sc = _score_vals(sel)
        if sc > result_sc:
            result_sc = sc
            result = sorted(int(v) for v in sel)
    return result
