# EVOLVE-BLOCK-START
"""Simplex lattice points embedded in integers; exact (d,n) search, then weighted-simplex hill climb."""
import math
import time
import random
from math import comb, factorial
import numpy as np


def _counts(d, n):
    sums = comb(2 * n + d, d)
    diffs = 0
    for j in range(0, min(n, d) + 1):
        for k in range(0, min(n, d - j) + 1):
            multi = factorial(d) // (factorial(j) * factorial(k) * factorial(d - j - k))
            diffs += multi * comb(n, j) * comb(n, k)
    return diffs, sums


def _gen(w, T):
    mc = T // min(w)
    B = 2 * mc + 1
    states = [(0, 0)]
    for i, wi in enumerate(w):
        p = B ** i
        new = []
        for v, u in states:
            for x in range(0, (T - u) // wi + 1):
                new.append((v + x * p, u + x * wi))
        states = new
    return [v for v, u in states]


def _maxT(w, cap=4000, Tmax=80):
    dp = [0] * (Tmax + 1)
    dp[0] = 1
    for wi in w:
        for s in range(wi, Tmax + 1):
            dp[s] += dp[s - wi]
    tot = 0
    best = 0
    for T in range(0, Tmax + 1):
        tot += dp[T]
        if tot > cap:
            break
        best = T
    return best


def _eval(vals):
    arr = np.array(sorted(vals), dtype=np.int64)
    m = len(arr)
    sums = np.unique(np.concatenate([arr[i] + arr[i:] for i in range(m)]))
    diffs = np.unique(np.concatenate([arr[i + 1:] - arr[i] for i in range(m - 1)]))
    ns = len(sums)
    nd = 2 * len(diffs) + 1
    return math.log(nd) / math.log(ns) + (1 - 1 / m) / 100


def solve():
    t0 = time.time()
    best_s, best_dn = -1.0, (2, 2)
    for d in range(1, 80):
        for n in range(1, 80):
            size = comb(n + d, d)
            if size < 3 or size > 4000:
                continue
            B = 2 * n + 1
            if n * (B ** (d - 1)) > 9.9e14:
                continue
            df, sm = _counts(d, n)
            if sm < 2:
                continue
            s = math.log(df) / math.log(sm) + (1 - 1 / size) / 100
            if s > best_s:
                best_s, best_dn = s, (d, n)
    d, n = best_dn
    base = sorted(set(int(x) for x in _gen([1] * d, n)))
    best_set = base
    cur_w, cur_T, cur_s = tuple([1] * d), n, best_s
    best_total = best_s
    cache = {}
    rng = random.Random(1)
    limit = 95.0
    last_dt = 1.0
    while time.time() - t0 + 2 * last_dt < limit:
        w = list(cur_w)
        r = rng.random()
        if r < 0.5:
            i = rng.randrange(len(w))
            w[i] = max(1, min(6, w[i] + rng.choice([-1, 1])))
        elif r < 0.7 and len(w) < 14:
            w.append(rng.randint(1, 4))
        elif r < 0.85 and len(w) > 2:
            w.pop(rng.randrange(len(w)))
        else:
            i = rng.randrange(len(w))
            j = rng.randrange(len(w))
            w[i] = max(1, min(6, w[i] + rng.choice([-1, 1])))
            w[j] = max(1, min(6, w[j] + rng.choice([-1, 1])))
        w = tuple(sorted(w))
        T = _maxT(w)
        if T < 1:
            continue
        key = (w, T)
        if key in cache:
            continue
        cache[key] = None
        ts = time.time()
        vals = _gen(list(w), T)
        if len(vals) < 500 or len(vals) > 4000 or max(vals) > 9.9e14:
            continue
        s = _eval(vals)
        last_dt = time.time() - ts
        cache[key] = s
        if s > cur_s - 0.002 * rng.random():
            cur_w, cur_T, cur_s = w, T, s
        if s > best_total:
            best_total = s
            best_set = sorted(set(int(x) for x in vals))
    return best_set
# EVOLVE-BLOCK-END
