import numpy as np
import time
from scipy.optimize import minimize, linprog

N_DEFAULT = 26


def lp_radii(centers):
    n = len(centers)
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    iu, ju = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[iu] - centers[ju], axis=1)
    m = len(iu)
    A = np.zeros((m, n))
    A[np.arange(m), iu] = 1
    A[np.arange(m), ju] = 1
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status != 0:
        return np.zeros(n)
    return np.maximum(res.x, 0)


def optimize(x0, n, iu, ju, maxiter=300):
    m = len(iu)

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]; s = r[iu] + r[ju]
        return np.concatenate([dx * dx + dy * dy - s * s, x - r, y - r, 1 - x - r, 1 - y - r])

    def jac(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        J = np.zeros((m + 4 * n, 3 * n))
        k = np.arange(m)
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]; s = r[iu] + r[ju]
        J[k, iu] = 2 * dx; J[k, ju] = -2 * dx
        J[k, n + iu] = 2 * dy; J[k, n + ju] = -2 * dy
        J[k, 2 * n + iu] = -2 * s; J[k, 2 * n + ju] = -2 * s
        a = np.arange(n)
        J[m + a, a] = 1; J[m + a, 2 * n + a] = -1
        J[m + n + a, n + a] = 1; J[m + n + a, 2 * n + a] = -1
        J[m + 2 * n + a, a] = -1; J[m + 2 * n + a, 2 * n + a] = -1
        J[m + 3 * n + a, n + a] = -1; J[m + 3 * n + a, 2 * n + a] = -1
        return J

    g = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    res = minimize(lambda v: -np.sum(v[2 * n:]), x0, jac=lambda v: g, method="SLSQP",
                   bounds=[(0, 1)] * (2 * n) + [(0, 0.5)] * n,
                   constraints=[{"type": "ineq", "fun": cons, "jac": jac}],
                   options={"maxiter": maxiter, "ftol": 1e-12})
    v = res.x
    c = np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0, 1)
    return c


def solve(n=26):
    t0 = time.time()
    budget = 230.0
    rng = np.random.default_rng(12345)
    iu, ju = np.triu_indices(n, 1)
    best_c, best_r, best_s = None, None, -1

    def evaluate(c):
        r = lp_radii(c)
        return r, r.sum()

    def init_random():
        c = rng.uniform(0.05, 0.95, (n, 2))
        return c

    def init_grid():
        # jittered grid-like start with mixed rows
        rows = int(rng.integers(4, 7))
        pts = []
        per = np.full(rows, n // rows)
        per[:n - per.sum()] += 1
        rng.shuffle(per)
        for i, k in enumerate(per):
            yy = (i + 0.5) / rows
            for j in range(k):
                pts.append([(j + 0.5 + 0.5 * (i % 2) * 0.5) / k, yy])
        c = np.array(pts[:n]) + rng.normal(0, 0.02, (n, 2))
        return np.clip(c, 0.03, 0.97)

    it = 0
    while time.time() - t0 < budget:
        it += 1
        if best_c is None or it <= 8 or rng.random() < 0.2:
            c0 = init_random() if rng.random() < 0.6 else init_grid()
        else:
            c0 = best_c.copy()
            mode = rng.random()
            if mode < 0.4:
                c0 += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), c0.shape)
            elif mode < 0.8:
                k = int(rng.integers(1, 4))
                idx = rng.choice(n, k, replace=False)
                c0[idx] = rng.uniform(0.05, 0.95, (k, 2))
            else:
                i, j = rng.choice(n, 2, replace=False)
                # swap a small and a large circle
                c0[[i, j]] = c0[[j, i]]
                c0 += rng.normal(0, 0.01, c0.shape)
            c0 = np.clip(c0, 0.02, 0.98)
        r0 = np.full(n, 0.03)
        x0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
        try:
            c = optimize(x0, n, iu, ju)
            r, s = evaluate(c)
        except Exception:
            continue
        if s > best_s:
            best_s, best_c, best_r = s, c, r
    r = np.maximum(best_r - 1e-9, 0)
    return best_c, r
