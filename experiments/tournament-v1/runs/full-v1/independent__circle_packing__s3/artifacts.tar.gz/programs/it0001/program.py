import time
import numpy as np
from scipy.optimize import minimize, linprog


def _lp_radii(centers):
    n = len(centers)
    x, y = centers[:, 0], centers[:, 1]
    wall = np.minimum.reduce([x, y, 1 - x, 1 - y])
    wall = np.maximum(wall, 0)
    iu, ju = np.triu_indices(n, 1)
    d = np.hypot(x[iu] - x[ju], y[iu] - y[ju])
    m = len(iu)
    A = np.zeros((m, n))
    A[np.arange(m), iu] = 1
    A[np.arange(m), ju] = 1
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall],
                  method="highs")
    if res.status != 0:
        return np.zeros(n)
    return np.maximum(res.x, 0)


def solve(n=26):
    t0 = time.time()
    budget = 240.0
    rng = np.random.default_rng(12345)
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    ar = np.arange(m)
    I = np.arange(n)

    def cons(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        d = np.sqrt(dx * dx + dy * dy)
        return np.concatenate([d - r[iu] - r[ju], x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(v):
        x, y = v[:n], v[n:2 * n]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        d = np.sqrt(dx * dx + dy * dy) + 1e-12
        J = np.zeros((m + 4 * n, 3 * n))
        J[ar, iu] = dx / d
        J[ar, ju] = -dx / d
        J[ar, n + iu] = dy / d
        J[ar, n + ju] = -dy / d
        J[ar, 2 * n + iu] = -1
        J[ar, 2 * n + ju] = -1
        o = m
        J[o + I, I] = 1; J[o + I, 2 * n + I] = -1
        o += n
        J[o + I, I] = -1; J[o + I, 2 * n + I] = -1
        o += n
        J[o + I, n + I] = 1; J[o + I, 2 * n + I] = -1
        o += n
        J[o + I, n + I] = -1; J[o + I, 2 * n + I] = -1
        return J

    obj = lambda v: -np.sum(v[2 * n:])
    gobj = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    gradf = lambda v: gobj
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def optimize(c, maxiter=300):
        v0 = np.concatenate([c[:, 0], c[:, 1], np.full(n, 0.03)])
        try:
            res = minimize(obj, v0, jac=gradf, bounds=bounds, method="SLSQP",
                           constraints=[{"type": "ineq", "fun": cons, "jac": jac}],
                           options={"maxiter": maxiter, "ftol": 1e-10})
        except Exception:
            return None, -1
        v = res.x
        c2 = np.clip(np.stack([v[:n], v[n:2 * n]], 1), 0, 1)
        r = _lp_radii(c2)
        return c2, r.sum()

    def rand_start():
        k = rng.integers(3)
        if k == 0:
            return rng.random((n, 2))
        if k == 1:
            # jittered grid-ish layout
            g = int(np.ceil(np.sqrt(n)))
            pts = [((i + 0.5) / g, (j + 0.5) / g) for i in range(g) for j in range(g)]
            pts = np.array(pts)
            pts = pts[rng.permutation(len(pts))[:n]]
            return np.clip(pts + rng.normal(0, 0.03, pts.shape), 0.02, 0.98)
        # rows with staggering
        rows = rng.integers(5, 7)
        pts = []
        per = int(np.ceil(n / rows))
        for i in range(rows):
            for j in range(per):
                off = 0.5 / per if i % 2 else 0
                pts.append(((j + 0.5) / per * 0.9 + 0.05 + off * 0.9, (i + 0.5) / rows))
        pts = np.array(pts)
        pts = pts[rng.permutation(len(pts))[:n]]
        return np.clip(pts + rng.normal(0, 0.02, pts.shape), 0.02, 0.98)

    best_c, best_s = None, -1
    cur_c, cur_s = None, -1
    it = 0
    while time.time() - t0 < budget:
        it += 1
        if cur_c is None or it % 4 == 0 and rng.random() < 0.5 or rng.random() < 0.2:
            c0 = rand_start()
        else:
            c0 = cur_c.copy()
            mode = rng.integers(3)
            if mode == 0:
                c0 += rng.normal(0, 0.03, c0.shape)
            elif mode == 1:
                r = _lp_radii(c0)
                k = rng.integers(1, 4)
                idx = np.argsort(r)[:k]
                c0[idx] = rng.random((len(idx), 2))
            else:
                k = rng.integers(2, 6)
                idx = rng.choice(n, k, replace=False)
                c0[idx] += rng.normal(0, 0.1, (k, 2))
            c0 = np.clip(c0, 0.01, 0.99)
        c, s = optimize(c0)
        if c is None:
            continue
        if s > cur_s - 0.01 * rng.random() * 0 or cur_c is None:
            if s > cur_s:
                cur_c, cur_s = c, s
        elif rng.random() < 0.02:
            cur_c, cur_s = c, s
        if s > best_s:
            best_c, best_s = c, s
            cur_c, cur_s = c, s
        if it % 40 == 0 and best_c is not None:
            cur_c, cur_s = best_c, best_s

    radii = _lp_radii(best_c) * (1 - 1e-12)
    return best_c, radii
