import time
import numpy as np
from scipy.optimize import minimize, linprog


def _setup(n):
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    rows = np.arange(m)

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        pair = (x[iu] - x[ju]) ** 2 + (y[iu] - y[ju]) ** 2 - (r[iu] + r[ju]) ** 2
        return np.concatenate([pair, x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        J = np.zeros((m + 4 * n, 3 * n))
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]; s = r[iu] + r[ju]
        J[rows, iu] = 2 * dx
        J[rows, ju] = -2 * dx
        J[rows, n + iu] = 2 * dy
        J[rows, n + ju] = -2 * dy
        J[rows, 2 * n + iu] = -2 * s
        J[rows, 2 * n + ju] = -2 * s
        k = np.arange(n)
        J[m + k, k] = 1; J[m + k, 2 * n + k] = -1
        J[m + n + k, k] = -1; J[m + n + k, 2 * n + k] = -1
        J[m + 2 * n + k, n + k] = 1; J[m + 2 * n + k, 2 * n + k] = -1
        J[m + 3 * n + k, n + k] = -1; J[m + 3 * n + k, 2 * n + k] = -1
        return J

    return cons, jac


def _lp_radii(c):
    n = len(c)
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    A = np.zeros((m, n))
    A[np.arange(m), iu] = 1
    A[np.arange(m), ju] = 1
    d = np.linalg.norm(c[iu] - c[ju], axis=1)
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    wall = np.maximum(wall, 0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status == 0:
        return np.maximum(res.x, 0)
    return None


def _fallback(c):
    n = len(c)
    r = np.maximum(np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]]), 0)
    for _ in range(100):
        ch = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(c[i] - c[j])
                if r[i] + r[j] > d:
                    s = d / (r[i] + r[j]) if r[i] + r[j] > 0 else 0
                    r[i] *= s; r[j] *= s; ch = True
        if not ch:
            break
    return r


def solve(n=26):
    t0 = time.time()
    budget = 220.0
    rng = np.random.default_rng(12345)
    cons, jac = _setup(n)
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    constraints = [{"type": "ineq", "fun": cons, "jac": jac}]

    def run(c, r0, maxiter=300):
        v0 = np.concatenate([c[:, 0], c[:, 1], r0])
        try:
            res = minimize(lambda v: -np.sum(v[2 * n:]), v0,
                           jac=lambda v: np.concatenate([np.zeros(2 * n), -np.ones(n)]),
                           bounds=bounds, constraints=constraints, method="SLSQP",
                           options={"maxiter": maxiter, "ftol": 1e-12})
        except Exception:
            return None, -1
        v = res.x
        if cons(v).min() < -1e-7:
            # slight violation: evaluate via LP later; approximate score
            pass
        c2 = np.stack([v[:n], v[n:2 * n]], axis=1)
        return c2, np.sum(v[2 * n:]) if cons(v).min() > -1e-6 else -1

    best_c, best_s = None, -1
    it = 0
    while time.time() - t0 < budget:
        it += 1
        if best_c is None or rng.random() < 0.4:
            mode = rng.integers(3)
            if mode == 0:
                c = rng.random((n, 2))
            elif mode == 1:
                k = 5
                g = np.array([[(i + 0.5) / k, (j + 0.5) / k] for i in range(k) for j in range(k)])
                g = np.vstack([g, rng.random((n - len(g), 2))])[:n]
                c = g + rng.normal(0, 0.03, (n, 2))
            else:
                # rings
                c = [[0.5, 0.5]]
                c += [[0.5 + 0.25 * np.cos(2 * np.pi * i / 7 + 0.3), 0.5 + 0.25 * np.sin(2 * np.pi * i / 7 + 0.3)] for i in range(7)]
                c += [[0.5 + 0.42 * np.cos(2 * np.pi * i / 18), 0.5 + 0.42 * np.sin(2 * np.pi * i / 18)] for i in range(18)]
                c = np.array(c[:n]) + rng.normal(0, 0.03, (n, 2))
            c = np.clip(c, 0.02, 0.98)
            r0 = np.full(n, 0.05)
        else:
            c = best_c.copy()
            kind = rng.integers(3)
            if kind == 0:
                c += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), c.shape)
            elif kind == 1:
                k = rng.integers(1, 4)
                idx = rng.choice(n, k, replace=False)
                c[idx] = rng.random((k, 2))
            else:
                i, j = rng.choice(n, 2, replace=False)
                c[[i, j]] = c[[j, i]]
                c += rng.normal(0, 0.01, c.shape)
            c = np.clip(c, 0.01, 0.99)
            r0 = np.full(n, 0.03)
        c2, s = run(c, r0)
        if c2 is not None and s > best_s:
            best_s, best_c = s, np.clip(c2, 0, 1)

    if best_c is None:
        best_c = np.clip(rng.random((n, 2)), 0.05, 0.95)
    r = _lp_radii(best_c)
    if r is None:
        r = _fallback(best_c)
    r = np.maximum(r - 1e-12, 0)
    return best_c, r
