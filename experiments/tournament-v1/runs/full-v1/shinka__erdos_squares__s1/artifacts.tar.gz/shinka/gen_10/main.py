# EVOLVE-BLOCK-START
"""Guillotine DP over integer grids with 'at most c squares' semantics."""
import math
import time


def _grid_dp(g, n):
    """Guillotine DP on a g x g grid. Returns (value/g, squares list)."""
    best = [[None] * (g + 1) for _ in range(g + 1)]
    ch = [[None] * (g + 1) for _ in range(g + 1)]
    for w in range(1, g + 1):
        for h in range(1, g + 1):
            b = [0.0] * (n + 1)
            c_ = [None] * (n + 1)
            c_[0] = ('skip',)
            for c in range(1, n + 1):
                bv = b[c - 1]
                bc = ('skip',)
                if w == h and w > bv:
                    bv = float(w)
                    bc = ('sq',)
                for x in range(1, w // 2 + 1):
                    A = best[x][h]
                    B = best[w - x][h]
                    for c1 in range(0, c + 1):
                        v = A[c1] + B[c - c1]
                        if v > bv + 1e-12:
                            bv = v
                            bc = ('v', x, c1)
                for y in range(1, h // 2 + 1):
                    A = best[w][y]
                    B = best[w][h - y]
                    for c1 in range(0, c + 1):
                        v = A[c1] + B[c - c1]
                        if v > bv + 1e-12:
                            bv = v
                            bc = ('h', y, c1)
                b[c] = bv
                c_[c] = bc
            best[w][h] = b
            ch[w][h] = c_
    out = []

    def gen(w, h, c, ox, oy):
        if c <= 0:
            return
        t = ch[w][h][c]
        if t[0] == 'skip':
            gen(w, h, c - 1, ox, oy)
        elif t[0] == 'sq':
            out.append(((ox + w / 2.0) / g, (oy + h / 2.0) / g, 0.0, w / g))
        elif t[0] == 'v':
            x, c1 = t[1], t[2]
            gen(x, h, c1, ox, oy)
            gen(w - x, h, c - c1, ox + x, oy)
        else:
            y, c1 = t[1], t[2]
            gen(w, y, c1, ox, oy)
            gen(w, h - y, c - c1, ox, oy + y)

    gen(g, g, n, 0, 0)
    return best[g][g][n] / g, out


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    start = time.time()
    budget = 30.0
    k = math.isqrt(n)
    side = 1.0 / k
    bestval = k * k * side
    bestsq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    g = 1
    last_t = 0.0
    while g <= 24:
        est = last_t * ((g / max(g - 1, 1)) ** 3.5) if last_t > 0 else 0.0
        if time.time() - start + est > budget:
            break
        t0 = time.time()
        val, sq = _grid_dp(g, n)
        last_t = max(time.time() - t0, 1e-6)
        if val > bestval + 1e-9 and len(sq) <= n:
            bestval, bestsq = val, sq
        g += 1
    squares = list(bestsq)
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
# EVOLVE-BLOCK-END