# EVOLVE-BLOCK-START
"""Baseline: the largest k x k grid that fits, plus size-zero squares for the rest."""
import math
import time
import numpy as np


def _baseline(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _grid_dp(n, g):
    """Guillotine DP on a g x g integer grid; returns (value, squares)."""
    F = {}
    C = {}
    for w in range(1, g + 1):
        for h in range(1, g + 1):
            f = np.zeros(n + 1)
            ch = [None] * (n + 1)
            for m in range(1, n + 1):
                best = -1.0
                bc = None
                if w == h:
                    best = float(w)
                    bc = ('s',)
                for c in range(1, w // 2 + 1):
                    A = F[(c, h)]
                    B = F[(w - c, h)]
                    v = A[:m + 1] + B[m::-1]
                    a = int(np.argmax(v))
                    if v[a] > best + 1e-9:
                        best = float(v[a])
                        bc = ('v', c, a)
                for c in range(1, h // 2 + 1):
                    A = F[(w, c)]
                    B = F[(w, h - c)]
                    v = A[:m + 1] + B[m::-1]
                    a = int(np.argmax(v))
                    if v[a] > best + 1e-9:
                        best = float(v[a])
                        bc = ('h', c, a)
                if bc is None:
                    best = 0.0
                f[m] = best
                ch[m] = bc
            F[(w, h)] = f
            C[(w, h)] = ch
    squares = []
    stack = [(0, 0, g, g, n)]
    while stack:
        x, y, w, h, m = stack.pop()
        if m <= 0:
            continue
        bc = C[(w, h)][m]
        if bc is None:
            continue
        if bc[0] == 's':
            squares.append(((x + w / 2.0) / g, (y + h / 2.0) / g, 0.0, w / g))
        elif bc[0] == 'v':
            c, a = bc[1], bc[2]
            stack.append((x, y, c, h, a))
            stack.append((x + c, y, w - c, h, m - a))
        else:
            c, a = bc[1], bc[2]
            stack.append((x, y, w, c, a))
            stack.append((x, y + c, w, h - c, m - a))
    return F[(g, g)][n] / g, squares


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    t0 = time.time()
    best_val = -1.0
    best_sq = None
    k = max(1, math.isqrt(n))
    g0 = k if k * k == n else k + 1
    for g in range(g0, g0 + 4):
        if g ** 3 * n > 3e7 and best_sq is not None:
            break
        if g ** 3 * n > 6e7:
            break
        if time.time() - t0 > 30:
            break
        try:
            val, sq = _grid_dp(n, g)
        except Exception:
            continue
        if val > best_val and len(sq) <= n:
            best_val, best_sq = val, sq
    base = _baseline(n)
    base_val = sum(s[3] for s in base)
    if best_sq is None or best_val < base_val:
        return base
    best_sq = list(best_sq)
    best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))
    return best_sq[:n]
# EVOLVE-BLOCK-END