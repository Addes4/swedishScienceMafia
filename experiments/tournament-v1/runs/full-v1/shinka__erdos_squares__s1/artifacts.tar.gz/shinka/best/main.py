# EVOLVE-BLOCK-START
"""Guillotine DP on integer grids + branch-and-bound skyline search (non-guillotine)."""
import math
import time
import sys
import numpy as np


def _baseline(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _grid_dp(n, g):
    """Guillotine DP on a g x g integer grid; returns (value, squares)."""
    F = {}
    C = {}
    for w in range(1, g + 1):
        for h in range(1, g + 1):
            f = np.zeros(n + 1)
            ch = [None] * (n + 1)
            for m in range(1, n + 1):
                best = -1.0
                bc = None
                if w == h:
                    best = float(w)
                    bc = ('s',)
                for c in range(1, w // 2 + 1):
                    A = F[(c, h)]
                    B = F[(w - c, h)]
                    v = A[:m + 1] + B[m::-1]
                    a = int(np.argmax(v))
                    if v[a] > best + 1e-9:
                        best = float(v[a])
                        bc = ('v', c, a)
                for c in range(1, h // 2 + 1):
                    A = F[(w, c)]
                    B = F[(w, h - c)]
                    v = A[:m + 1] + B[m::-1]
                    a = int(np.argmax(v))
                    if v[a] > best + 1e-9:
                        best = float(v[a])
                        bc = ('h', c, a)
                if bc is None:
                    best = 0.0
                f[m] = best
                ch[m] = bc
            F[(w, h)] = f
            C[(w, h)] = ch
    squares = []
    stack = [(0, 0, g, g, n)]
    while stack:
        x, y, w, h, m = stack.pop()
        if m <= 0:
            continue
        bc = C[(w, h)][m]
        if bc is None:
            continue
        if bc[0] == 's':
            squares.append(((x + w / 2.0) / g, (y + h / 2.0) / g, 0.0, w / g))
        elif bc[0] == 'v':
            c, a = bc[1], bc[2]
            stack.append((x, y, c, h, a))
            stack.append((x + c, y, w - c, h, m - a))
        else:
            c, a = bc[1], bc[2]
            stack.append((x, y, w, c, a))
            stack.append((x, y + c, w, h - c, m - a))
    return F[(g, g)][n] / g, squares


class _Timeout(Exception):
    pass


def _skyline_search(n, g, best_units, deadline):
    """Branch and bound over integer-sided squares on a g x g grid.
    Returns (units, placements) with units > best_units, or (best_units, None)."""
    heights = [0] * g
    placed = []
    state = {'best': best_units, 'sol': None, 'cnt': 0}
    sqrt = math.sqrt
    INF = 10 ** 9

    def rec(used, cursum, free):
        state['cnt'] += 1
        if (state['cnt'] & 1023) == 0 and time.time() > deadline:
            raise _Timeout()
        if cursum > state['best']:
            state['best'] = cursum
            state['sol'] = list(placed)
        r = n - used
        if r <= 0 or free <= 0:
            return
        if int(cursum + sqrt(r * free) + 1e-9) <= state['best']:
            return
        # lowest, leftmost run
        h = INF
        x = 0
        for i in range(g):
            if heights[i] < h:
                h = heights[i]
                x = i
        if h >= g:
            return
        w = 1
        while x + w < g and heights[x + w] == h:
            w += 1
        maxs = min(w, g - h)
        for s in range(maxs, 0, -1):
            for i in range(x, x + s):
                heights[i] = h + s
            placed.append((x, h, s))
            rec(used + 1, cursum + s, free - s * s)
            placed.pop()
            for i in range(x, x + s):
                heights[i] = h
        # waste the run
        left = heights[x - 1] if x > 0 else INF
        right = heights[x + w] if x + w < g else INF
        t = min(left, right)
        if t >= INF:
            t = min(g, h + 1)
        if t > h:
            for i in range(x, x + w):
                heights[i] = t
            rec(used, cursum, free - w * (t - h))
            for i in range(x, x + w):
                heights[i] = h

    old = sys.getrecursionlimit()
    sys.setrecursionlimit(max(old, 10000))
    try:
        rec(0, 0, g * g)
    except _Timeout:
        pass
    finally:
        sys.setrecursionlimit(old)
    return state['best'], state['sol']


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    t0 = time.time()
    best_val = -1.0
    best_sq = None
    k = max(1, math.isqrt(n))
    g0 = k if k * k == n else k + 1

    # Phase 1: guillotine DP
    for g in range(g0, g0 + 4):
        if g ** 3 * n > 3e7 and best_sq is not None:
            break
        if g ** 3 * n > 6e7:
            break
        if time.time() - t0 > 15:
            break
        try:
            val, sq = _grid_dp(n, g)
        except Exception:
            continue
        if val > best_val and len(sq) <= n:
            best_val, best_sq = val, sq
    base = _baseline(n)
    base_val = sum(s[3] for s in base)
    if best_sq is None or best_val < base_val:
        best_val, best_sq = base_val, list(base)
    best_sq = list(best_sq)

    # Phase 2: non-guillotine skyline branch and bound
    T_end = t0 + 45.0
    gs = list(range(max(2, g0), g0 + 7))
    for idx, g in enumerate(gs):
        now = time.time()
        if now >= T_end - 0.5:
            break
        remaining = len(gs) - idx
        deadline = now + (T_end - now) / remaining
        start = int(math.floor(best_val * g + 1e-9))
        try:
            units, sol = _skyline_search(n, g, start, deadline)
        except Exception:
            continue
        if sol is not None and units > start and units / g > best_val + 1e-9:
            best_val = units / g
            best_sq = [((x + s / 2.0) / g, (y + s / 2.0) / g, 0.0, s / g) for (x, y, s) in sol]

    best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))
    return best_sq[:n]
# EVOLVE-BLOCK-END