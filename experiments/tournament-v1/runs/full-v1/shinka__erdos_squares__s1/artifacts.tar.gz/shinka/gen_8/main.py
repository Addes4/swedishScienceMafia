# EVOLVE-BLOCK-START
"""Guillotine DP on a g x g integer grid (numpy-vectorised over square counts),
swept over grid resolutions g under a time budget."""
import math
import time

import numpy as np


class _GridTable:
    """DP table for rectangles w x h (in grid units), indexed by max count c."""

    EMPTY, SQUARE, VSPLIT, HSPLIT = 0, 1, 2, 3

    def __init__(self, g, n):
        self.g, self.n = g, n
        self.val = [[None] * (g + 1) for _ in range(g + 1)]
        self.kind = [[None] * (g + 1) for _ in range(g + 1)]
        self.par = [[None] * (g + 1) for _ in range(g + 1)]
        self.cut = [[None] * (g + 1) for _ in range(g + 1)]

    def _relax(self, res, kind, par, cut, A, B, t, pos):
        n = self.n
        for c1 in range(1, n):
            seg = A[c1] + B[: n + 1 - c1]
            tgt = res[c1:]
            m = seg > tgt + 1e-12
            if m.any():
                tgt[m] = seg[m]
                kind[c1:][m] = t
                par[c1:][m] = pos
                cut[c1:][m] = c1

    def build(self):
        g, n = self.g, self.n
        for w in range(1, g + 1):
            for h in range(1, g + 1):
                res = np.zeros(n + 1)
                kind = np.zeros(n + 1, dtype=np.int32)
                par = np.zeros(n + 1, dtype=np.int32)
                cut = np.zeros(n + 1, dtype=np.int32)
                s = float(min(w, h))
                res[1:] = s
                kind[1:] = self.SQUARE
                for x in range(1, w // 2 + 1):
                    self._relax(res, kind, par, cut,
                                self.val[x][h], self.val[w - x][h],
                                self.VSPLIT, x)
                for y in range(1, h // 2 + 1):
                    self._relax(res, kind, par, cut,
                                self.val[w][y], self.val[w][h - y],
                                self.HSPLIT, y)
                self.val[w][h] = res
                self.kind[w][h] = kind
                self.par[w][h] = par
                self.cut[w][h] = cut
        return float(self.val[g][g][n]) / g

    def extract(self):
        g, n = self.g, self.n
        out = []

        def gen(w, h, c, ox, oy):
            if c <= 0:
                return
            k = int(self.kind[w][h][c])
            if k == self.EMPTY:
                return
            if k == self.SQUARE:
                s = min(w, h)
                out.append(((ox + s / 2.0) / g, (oy + s / 2.0) / g, 0.0, s / g))
                return
            p = int(self.par[w][h][c])
            c1 = int(self.cut[w][h][c])
            if k == self.VSPLIT:
                gen(p, h, c1, ox, oy)
                gen(w - p, h, c - c1, ox + p, oy)
            else:
                gen(w, p, c1, ox, oy)
                gen(w, h - p, c - c1, ox, oy + p)

        gen(g, g, n, 0, 0)
        return out


def _baseline(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
          for i in range(k) for j in range(k)]
    return k * k * side, sq


def _sweep(n, budget=35.0, gmax=90):
    start = time.time()
    bestval, bestsq = _baseline(n)
    last_t = 0.0
    g = 1
    while g <= gmax:
        if last_t > 0:
            est = last_t * ((g / (g - 1.0)) ** 3.3) * 1.1
            if time.time() - start + est > budget:
                break
        t0 = time.time()
        table = _GridTable(g, n)
        val = table.build()
        last_t = time.time() - t0
        if val > bestval + 1e-9:
            sq = table.extract()
            if len(sq) <= n:
                bestval, bestsq = val, sq
        g += 1
    return bestsq


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    sq = list(_sweep(n))
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]
# EVOLVE-BLOCK-END