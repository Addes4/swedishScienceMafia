# EVOLVE-BLOCK-START
"""Guillotine DP over integer grids with 'at most c squares' semantics."""
import math
import time
from operator import add as _add


def _pw_parts(best, w, h, x1, x2, y1, y2):
    return [best[x2][y1], best[w - x2][y2], best[w - x1][h - y2],
            best[x1][h - y1], best[x2 - x1][y2 - y1]]


def _conv(A, B, n):
    return [max(map(_add, A[:c + 1], B[c::-1])) for c in range(n + 1)]


def _conv_arg(A, B, n):
    C = [0.0] * (n + 1)
    arg = [0] * (n + 1)
    for c in range(n + 1):
        bv = -1.0
        bi = 0
        for i in range(c + 1):
            v = A[i] + B[c - i]
            if v > bv:
                bv = v
                bi = i
        C[c] = bv
        arg[c] = bi
    return C, arg


def _pw_alloc(best, w, h, x1, x2, y1, y2, c, n):
    P = _pw_parts(best, w, h, x1, x2, y1, y2)
    T1, a1 = _conv_arg(P[0], P[1], n)
    T2, a2 = _conv_arg(T1, P[2], n)
    T3, a3 = _conv_arg(T2, P[3], n)
    T4, a4 = _conv_arg(T3, P[4], n)
    cnt = [0] * 5
    cnt[4] = c - a4[c]
    r = a4[c]
    cnt[3] = r - a3[r]
    r = a3[r]
    cnt[2] = r - a2[r]
    r = a2[r]
    cnt[1] = r - a1[r]
    cnt[0] = a1[r]
    return cnt


def _grid_dp(g, n):
    pw = (g <= 8 and n <= 20)
    """Guillotine DP on a g x g grid. Returns (value/g, squares list)."""
    best = [[None] * (g + 1) for _ in range(g + 1)]
    ch = [[None] * (g + 1) for _ in range(g + 1)]
    for w in range(1, g + 1):
        for h in range(1, g + 1):
            b = [0.0] * (n + 1)
            c_ = [None] * (n + 1)
            c_[0] = ('skip',)
            m = min(n, w * h)
            for c in range(1, m + 1):
                bv = b[c - 1]
                bc = ('skip',)
                if w == h and w > bv:
                    bv = float(w)
                    bc = ('sq',)
                for x in range(1, w // 2 + 1):
                    A = best[x][h]
                    B = best[w - x][h]
                    aA = x * h
                    aB = (w - x) * h
                    for c1 in range(max(0, c - aB), min(c, aA) + 1):
                        v = A[c1] + B[c - c1]
                        if v > bv + 1e-12:
                            bv = v
                            bc = ('v', x, c1)
                for y in range(1, h // 2 + 1):
                    A = best[w][y]
                    B = best[w][h - y]
                    aA = y * w
                    aB = (h - y) * w
                    for c1 in range(max(0, c - aB), min(c, aA) + 1):
                        v = A[c1] + B[c - c1]
                        if v > bv + 1e-12:
                            bv = v
                            bc = ('h', y, c1)
                b[c] = bv
                c_[c] = bc
            for c in range(m + 1, n + 1):
                b[c] = b[m]
                c_[c] = ('skip',)
            if pw and w >= 3 and h >= 3:
                for x1 in range(1, w - 1):
                    for x2 in range(x1 + 1, w):
                        for y1 in range(1, h - 1):
                            for y2 in range(y1 + 1, h):
                                P = _pw_parts(best, w, h, x1, x2, y1, y2)
                                T = _conv(P[0], P[1], n)
                                T = _conv(T, P[2], n)
                                T = _conv(T, P[3], n)
                                T = _conv(T, P[4], n)
                                for c in range(1, n + 1):
                                    if T[c] > b[c] + 1e-12:
                                        b[c] = T[c]
                                        c_[c] = ('p', x1, x2, y1, y2)
                for c in range(1, n + 1):
                    if b[c] < b[c - 1]:
                        b[c] = b[c - 1]
                        c_[c] = ('skip',)
            best[w][h] = b
            ch[w][h] = c_
    out = []

    def gen(w, h, c, ox, oy):
        if c <= 0:
            return
        t = ch[w][h][c]
        if t[0] == 'skip':
            gen(w, h, c - 1, ox, oy)
        elif t[0] == 'sq':
            out.append(((ox + w / 2.0) / g, (oy + h / 2.0) / g, 0.0, w / g))
        elif t[0] == 'v':
            x, c1 = t[1], t[2]
            gen(x, h, c1, ox, oy)
            gen(w - x, h, c - c1, ox + x, oy)
        elif t[0] == 'h':
            y, c1 = t[1], t[2]
            gen(w, y, c1, ox, oy)
            gen(w, h - y, c - c1, ox, oy + y)
        else:
            _, x1, x2, y1, y2 = t
            cnt = _pw_alloc(best, w, h, x1, x2, y1, y2, c, n)
            gen(x2, y1, cnt[0], ox, oy)
            gen(w - x2, y2, cnt[1], ox + x2, oy)
            gen(w - x1, h - y2, cnt[2], ox + x1, oy + y2)
            gen(x1, h - y1, cnt[3], ox, oy + y1)
            gen(x2 - x1, y2 - y1, cnt[4], ox + x1, oy + y1)

    gen(g, g, n, 0, 0)
    return best[g][g][n] / g, out


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    start = time.time()
    budget = 30.0
    k = math.isqrt(n)
    side = 1.0 / k
    bestval = k * k * side
    bestsq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    g = 1
    last_t = 0.0
    while g <= 24:
        est = last_t * ((g / max(g - 1, 1)) ** 3.5) if last_t > 0 else 0.0
        if time.time() - start + est > budget:
            break
        t0 = time.time()
        val, sq = _grid_dp(g, n)
        last_t = max(time.time() - t0, 1e-6)
        if val > bestval + 1e-9 and len(sq) <= n:
            bestval, bestsq = val, sq
        g += 1
    squares = list(bestsq)
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
# EVOLVE-BLOCK-END