# EVOLVE-BLOCK-START
"""Recursive merge DP + guillotine DP on integer grids + branch-and-bound skyline search."""
import math
import time
import sys
import numpy as np


def _baseline(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _recursive_dp(n):
    """Recursive grid / merged-grid DP (nested structures). Returns list of squares."""
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)] * n
    K = math.isqrt(n) + 2
    C = K * K
    best = [0.0] * (n + 1)
    plan = [None] * (n + 1)
    best[1] = 1.0
    plan[1] = ('one',)
    g = [[0.0] * (n + 1) for _ in range(C + 1)]
    pg = [[0] * (n + 1) for _ in range(C + 1)]
    for c in range(1, C + 1):
        g[c][1] = 1.0
        pg[c][1] = 1

    def walk(c, t, pex, ex):
        res = []
        while c > 0 and t > 0:
            m = pex[c] if ex else pg[c][t]
            if m > 0:
                res.append(m)
                t -= m
                ex = False
            c -= 1
        return res

    for t in range(2, n + 1):
        gex = [0.0] * (C + 1)
        pex = [0] * (C + 1)
        for c in range(1, C + 1):
            bv = gex[c - 1]
            bm = 0
            prev = g[c - 1]
            for m in range(1, t):
                v = prev[t - m] + best[m]
                if v > bv + 1e-12:
                    bv = v
                    bm = m
            gex[c] = bv
            pex[c] = bm
        bv = best[t - 1]
        cand = ('pad',)
        for k in range(2, K + 1):
            val = gex[k * k] / k
            if val > bv + 1e-12:
                bv = val
                cand = ('grid', k, 0, 0)
            for a in range(2, k):
                c = k * k - a * a
                for mb in range(1, t):
                    val = (a * best[mb] + g[c][t - mb]) / k
                    if val > bv + 1e-12:
                        bv = val
                        cand = ('merge', k, a, mb)
        if cand[0] == 'pad':
            plan[t] = ('pad',)
        elif cand[0] == 'grid':
            k = cand[1]
            plan[t] = ('grid', k, walk(k * k, t, pex, True))
        else:
            _, k, a, mb = cand
            c = k * k - a * a
            plan[t] = ('merge', k, a, mb, walk(c, t - mb, pex, False))
        best[t] = bv
        for c in range(1, C + 1):
            if bv > gex[c] + 1e-12:
                g[c][t] = bv
                pg[c][t] = t
            else:
                g[c][t] = gex[c]
                pg[c][t] = pex[c]

    out = []

    def build(t, x0, y0, size):
        p = plan[t]
        if p[0] == 'one':
            out.append((x0, y0, size))
        elif p[0] == 'pad':
            build(t - 1, x0, y0, size)
        elif p[0] == 'grid':
            k = p[1]
            s = size / k
            for idx, m in enumerate(p[2]):
                i, j = divmod(idx, k)
                build(m, x0 + i * s, y0 + j * s, s)
        else:
            _, k, a, mb, counts = p
            s = size / k
            build(mb, x0, y0, a * s)
            cells = [(i, j) for i in range(k) for j in range(k) if not (i < a and j < a)]
            for (i, j), m in zip(cells, counts):
                build(m, x0 + i * s, y0 + j * s, s)

    build(n, 0.0, 0.0, 1.0)
    shrink = 1.0 - 1e-9
    squares = []
    for (x0, y0, s) in out[:n]:
        squares.append((x0 + s / 2.0, y0 + s / 2.0, 0.0, s * shrink))
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _grid_dp(n, g):
    """Guillotine DP on a g x g integer grid; returns (value, squares)."""
    F = {}
    C = {}
    for w in range(1, g + 1):
        for h in range(1, g + 1):
            f = np.zeros(n + 1)
            ch = [None] * (n + 1)
            for m in range(1, n + 1):
                best = -1.0
                bc = None
                if w == h:
                    best = float(w)
                    bc = ('s',)
                for c in range(1, w // 2 + 1):
                    A = F[(c, h)]
                    B = F[(w - c, h)]
                    v = A[:m + 1] + B[m::-1]
                    a = int(np.argmax(v))
                    if v[a] > best + 1e-9:
                        best = float(v[a])
                        bc = ('v', c, a)
                for c in range(1, h // 2 + 1):
                    A = F[(w, c)]
                    B = F[(w, h - c)]
                    v = A[:m + 1] + B[m::-1]
                    a = int(np.argmax(v))
                    if v[a] > best + 1e-9:
                        best = float(v[a])
                        bc = ('h', c, a)
                if bc is None:
                    best = 0.0
                f[m] = best
                ch[m] = bc
            F[(w, h)] = f
            C[(w, h)] = ch
    final_val = F[(g, g)][n]
    squares = []
    stack = [(0, 0, g, g, n)]

    def _mp(A, B):
        res = np.full(n + 1, -1e18)
        arg = np.zeros(n + 1, dtype=int)
        for a in range(n + 1):
            cand = A[a] + B[:n + 1 - a]
            seg = res[a:]
            mask = cand > seg
            seg[mask] = cand[mask]
            arg[a:][mask] = a
        return res, arg

    if g >= 3 and n >= 5 and g <= 9 and n <= 60:
        tp = time.time()
        bestp = final_val + 1e-9
        bestcfg = None
        for x1 in range(1, g - 1):
            for x2 in range(x1 + 1, g):
                for y1 in range(1, g - 1):
                    for y2 in range(y1 + 1, g):
                        if time.time() - tp > 8.0:
                            break
                        R1 = F[(x2, y1)]
                        R2 = F[(g - x2, y2)]
                        R3 = F[(g - x1, g - y2)]
                        R4 = F[(x1, g - y1)]
                        R5 = F[(x2 - x1, y2 - y1)]
                        c12, a12 = _mp(R1, R2)
                        c34, a34 = _mp(R3, R4)
                        d, ad = _mp(c12, R5)
                        tot = d + c34[::-1]
                        a = int(np.argmax(tot))
                        if tot[a] > bestp:
                            bestp = float(tot[a])
                            m34 = n - a
                            q12 = int(ad[a])
                            m5 = a - q12
                            m1 = int(a12[q12])
                            m2 = q12 - m1
                            m3 = int(a34[m34])
                            m4 = m34 - m3
                            bestcfg = (x1, x2, y1, y2, m1, m2, m3, m4, m5)
        if bestcfg is not None:
            x1, x2, y1, y2, m1, m2, m3, m4, m5 = bestcfg
            final_val = bestp
            stack = [(0, 0, x2, y1, m1), (x2, 0, g - x2, y2, m2),
                     (x1, y2, g - x1, g - y2, m3), (0, y1, x1, g - y1, m4),
                     (x1, y1, x2 - x1, y2 - y1, m5)]
    while stack:
        x, y, w, h, m = stack.pop()
        if m <= 0:
            continue
        bc = C[(w, h)][m]
        if bc is None:
            continue
        if bc[0] == 's':
            squares.append(((x + w / 2.0) / g, (y + h / 2.0) / g, 0.0, w / g))
        elif bc[0] == 'v':
            c, a = bc[1], bc[2]
            stack.append((x, y, c, h, a))
            stack.append((x + c, y, w - c, h, m - a))
        else:
            c, a = bc[1], bc[2]
            stack.append((x, y, w, c, a))
            stack.append((x, y + c, w, h - c, m - a))
    return final_val / g, squares


class _Timeout(Exception):
    pass


def _skyline_search(n, g, best_units, deadline):
    """Branch and bound over integer-sided squares on a g x g grid.
    Returns (units, placements) with units > best_units, or (best_units, None)."""
    heights = [0] * g
    placed = []
    state = {'best': best_units, 'sol': None, 'cnt': 0}
    sqrt = math.sqrt
    INF = 10 ** 9

    def rec(used, cursum, free):
        state['cnt'] += 1
        if (state['cnt'] & 1023) == 0 and time.time() > deadline:
            raise _Timeout()
        if cursum > state['best']:
            state['best'] = cursum
            state['sol'] = list(placed)
        r = n - used
        if r <= 0 or free <= 0:
            return
        if int(cursum + sqrt(r * free) + 1e-9) <= state['best']:
            return
        h = INF
        x = 0
        for i in range(g):
            if heights[i] < h:
                h = heights[i]
                x = i
        if h >= g:
            return
        w = 1
        while x + w < g and heights[x + w] == h:
            w += 1
        maxs = min(w, g - h)
        for s in range(maxs, 0, -1):
            for i in range(x, x + s):
                heights[i] = h + s
            placed.append((x, h, s))
            rec(used + 1, cursum + s, free - s * s)
            placed.pop()
            for i in range(x, x + s):
                heights[i] = h
        left = heights[x - 1] if x > 0 else INF
        right = heights[x + w] if x + w < g else INF
        t = min(left, right)
        if t >= INF:
            t = min(g, h + 1)
        if t > h:
            for i in range(x, x + w):
                heights[i] = t
            rec(used, cursum, free - w * (t - h))
            for i in range(x, x + w):
                heights[i] = h

    old = sys.getrecursionlimit()
    sys.setrecursionlimit(max(old, 10000))
    try:
        rec(0, 0, g * g)
    except _Timeout:
        pass
    finally:
        sys.setrecursionlimit(old)
    return state['best'], state['sol']


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    t0 = time.time()
    best_val = -1.0
    best_sq = None
    k = max(1, math.isqrt(n))
    g0 = k if k * k == n else k + 1

    # Phase 0: recursive grid/merge DP (cheap, any n up to a limit)
    if n <= 250:
        try:
            sq = _recursive_dp(n)
            val = sum(s[3] for s in sq)
            if len(sq) <= n and val > best_val:
                best_val, best_sq = val, sq
        except Exception:
            pass

    # Phase 1: guillotine DP
    for g in range(g0, g0 + 4):
        if g ** 3 * n > 3e7 and best_sq is not None:
            break
        if g ** 3 * n > 6e7:
            break
        if time.time() - t0 > 15:
            break
        try:
            val, sq = _grid_dp(n, g)
        except Exception:
            continue
        if val > best_val + 1e-8 and len(sq) <= n:
            best_val, best_sq = val, sq
    base = _baseline(n)
    base_val = sum(s[3] for s in base)
    if best_sq is None or best_val < base_val:
        best_val, best_sq = base_val, list(base)
    best_sq = list(best_sq)

    # Phase 2: non-guillotine skyline branch and bound
    T_end = t0 + 45.0
    gs = list(range(max(2, g0), g0 + 7))
    for idx, g in enumerate(gs):
        now = time.time()
        if now >= T_end - 0.5:
            break
        remaining = len(gs) - idx
        deadline = now + (T_end - now) / remaining
        start = int(math.floor(best_val * g + 1e-9))
        try:
            units, sol = _skyline_search(n, g, start, deadline)
        except Exception:
            continue
        if sol is not None and units > start and units / g > best_val + 1e-9:
            best_val = units / g
            best_sq = [((x + s / 2.0) / g, (y + s / 2.0) / g, 0.0, s / g) for (x, y, s) in sol]

    best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))
    return best_sq[:n]
# EVOLVE-BLOCK-END