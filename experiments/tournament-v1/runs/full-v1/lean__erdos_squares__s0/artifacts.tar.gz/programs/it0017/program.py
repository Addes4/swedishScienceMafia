# EVOLVE-BLOCK-START
"""DP over recursive grid constructions (with optional merged corner block holding a sub-packing)."""
import math
import numpy as np

NEG = -1e18


def _ms_for(n):
    if n <= 400:
        return list(range(2, 10))
    if n <= 1500:
        return list(range(2, 8))
    if n <= 4000:
        return list(range(2, 5))
    return None


def _build(N, ms):
    Vn = np.zeros(N + 1)
    choice = [None] * (N + 1)
    g = {}
    ga = {}
    for m in ms:
        C = m * m
        arr = np.full((C + 1, N + 1), NEG)
        arr[:, 0] = 0.0
        g[m] = arr
        ga[m] = np.zeros((C + 1, N + 1), dtype=np.int64)
    for n in range(1, N + 1):
        best = float(Vn[n - 1])
        bch = ('same',)
        if n == 1:
            best = 1.0
            bch = ('one',)
        gex = {}
        gexa = {}
        for m in ms:
            C = m * m
            ex = [NEG] * (C + 1)
            exa = [0] * (C + 1)
            gm = g[m]
            Vs = Vn[1:n] / m
            for c in range(1, C + 1):
                bv = ex[c - 1]
                ba = 0
                if n >= 2:
                    pvs = gm[c - 1][n - 1:0:-1]
                    vals = np.where(pvs > NEG / 2, Vs + pvs, NEG)
                    i = int(np.argmax(vals))
                    if vals[i] > bv:
                        bv = float(vals[i])
                        ba = i + 1
                ex[c] = bv
                exa[c] = ba
            gex[m] = np.array(ex)
            gexa[m] = np.array(exa, dtype=np.int64)
            if n >= 2 and ex[C] > best + 1e-12:
                best = ex[C]
                bch = ('grid', m)
            if n >= 2:
                for j in range(2, m):
                    c = C - j * j
                    pvs = gm[c][n - 1:0:-1]
                    vals = np.where(pvs > NEG / 2, Vn[1:n] * j / m + pvs, NEG)
                    i = int(np.argmax(vals))
                    if vals[i] > best + 1e-12:
                        best = float(vals[i])
                        bch = ('block', m, j, i + 1)
        Vn[n] = best
        choice[n] = bch
        for m in ms:
            val = best / m
            ex = gex[m]
            exa = gexa[m]
            mask = val > ex + 1e-12
            g[m][1:, n] = np.where(mask[1:], val, ex[1:])
            ga[m][1:, n] = np.where(mask[1:], n, exa[1:])
    return Vn, choice, ga


def _dist(ga, m, c, t):
    ks = []
    while c > 0:
        k = int(ga[m][c][t])
        ks.append(k)
        t -= k
        c -= 1
    return ks


def _place(n, x0, y0, s, choice, ga, out):
    while n > 0 and choice[n][0] == 'same':
        n -= 1
    if n <= 0:
        return
    ch = choice[n]
    if ch[0] == 'one':
        out.append((x0 + s / 2, y0 + s / 2, 0.0, s))
    elif ch[0] == 'grid':
        m = ch[1]
        ks = _dist(ga, m, m * m, n)
        cs = s / m
        for i, k in enumerate(ks):
            _place(k, x0 + (i % m) * cs, y0 + (i // m) * cs, cs, choice, ga, out)
    else:
        m, j, kb = ch[1], ch[2], ch[3]
        cs = s / m
        _place(kb, x0, y0, j * cs, choice, ga, out)
        cells = [(a, b) for b in range(m) for a in range(m) if not (a < j and b < j)]
        ks = _dist(ga, m, len(cells), n - kb)
        for (a, b), k in zip(cells, ks):
            _place(k, x0 + a * cs, y0 + b * cs, cs, choice, ga, out)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    ms = _ms_for(n)
    out = []
    if ms is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        for i in range(k * k):
            if len(out) >= n:
                break
            out.append(((i % k + 0.5) * s, (i // k + 0.5) * s, 0.0, s))
    else:
        Vn, choice, ga = _build(n, ms)
        _place(n, 0.0, 0.0, 1.0, choice, ga, out)
    out = out[:n]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    res = []
    for (x, y, a, s) in out:
        s = min(max(s, 0.0), 1.0)
        res.append((min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0), a, s))
    return res
# EVOLVE-BLOCK-END
