# EVOLVE-BLOCK-START
"""DP over recursive grid constructions (with optional merged corner block holding a sub-packing),
vectorised with numpy."""
import math
import numpy as np

NEG = -1e18


def _build(N, ms):
    V = np.zeros(N + 1)
    choice = [None] * (N + 1)
    g = {}
    ga = {}
    for m in ms:
        C = m * m
        g[m] = np.full((C + 1, N + 1), NEG)
        ga[m] = np.zeros((C + 1, N + 1), dtype=np.int64)
        g[m][:, 0] = 0.0
    for n in range(1, N + 1):
        best = V[n - 1]
        bch = ('same',)
        if n == 1:
            best = 1.0
            bch = ('one',)
        gex = {}
        gexa = {}
        Vk = V[1:n]
        for m in ms:
            C = m * m
            ex = [NEG] * (C + 1)
            exa = [0] * (C + 1)
            gm = g[m]
            invm = 1.0 / m
            base = Vk * invm if n > 1 else None
            for c in range(1, C + 1):
                bv = ex[c - 1]
                ba = 0
                if n > 1:
                    pv = gm[c - 1, n - 1:0:-1]
                    vals = base + pv
                    i = int(np.argmax(vals))
                    v = float(vals[i])
                    if pv[i] > NEG / 2 and v > bv:
                        bv = v
                        ba = i + 1
                ex[c] = bv
                exa[c] = ba
            gex[m] = ex
            gexa[m] = exa
            if n >= 2 and ex[C] > best + 1e-12:
                best = ex[C]
                bch = ('grid', m)
            if n > 1:
                for j in range(2, m):
                    c = C - j * j
                    pv = gm[c, n - 1:0:-1]
                    vals = Vk * (j / m) + pv
                    i = int(np.argmax(vals))
                    v = float(vals[i])
                    if pv[i] > NEG / 2 and v > best + 1e-12:
                        best = v
                        bch = ('block', m, j, i + 1)
        V[n] = best
        choice[n] = bch
        for m in ms:
            C = m * m
            vm = best / m
            for c in range(1, C + 1):
                e = gex[m][c]
                if vm > e + 1e-12:
                    g[m][c, n] = vm
                    ga[m][c, n] = n
                else:
                    g[m][c, n] = e
                    ga[m][c, n] = gexa[m][c]
    return V, choice, ga


def _dist(ga, m, c, t):
    ks = []
    while c > 0:
        k = int(ga[m][c, t])
        ks.append(k)
        t -= k
        c -= 1
    return ks


def _place(n, x0, y0, s, choice, ga, out):
    if n <= 0:
        return
    ch = choice[n]
    if ch[0] == 'same':
        _place(n - 1, x0, y0, s, choice, ga, out)
    elif ch[0] == 'one':
        out.append((x0 + s / 2, y0 + s / 2, 0.0, s))
    elif ch[0] == 'grid':
        m = ch[1]
        ks = _dist(ga, m, m * m, n)
        cs = s / m
        for i, k in enumerate(ks):
            _place(k, x0 + (i % m) * cs, y0 + (i // m) * cs, cs, choice, ga, out)
    else:
        m, j, kb = ch[1], ch[2], ch[3]
        cs = s / m
        _place(kb, x0, y0, j * cs, choice, ga, out)
        cells = [(a, b) for b in range(m) for a in range(m) if not (a < j and b < j)]
        ks = _dist(ga, m, len(cells), n - kb)
        for (a, b), k in zip(cells, ks):
            _place(k, x0 + a * cs, y0 + b * cs, cs, choice, ga, out)


def _plain(n):
    m = max(1, int(math.isqrt(n)))
    cs = 1.0 / m
    out = []
    for i in range(m * m):
        if len(out) >= n:
            break
        out.append(((i % m + 0.5) * cs, (i // m + 0.5) * cs, 0.0, cs))
    return out


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 400:
        ms = list(range(2, 10))
    elif n <= 1500:
        ms = list(range(2, 8))
    elif n <= 4000:
        ms = [2, 3, 4]
    else:
        ms = None
    if ms is None:
        out = _plain(n)
    else:
        V, choice, ga = _build(n, ms)
        out = []
        _place(n, 0.0, 0.0, 1.0, choice, ga, out)
    out = out[:n]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    res = []
    for (x, y, a, s) in out:
        s = min(max(float(s), 0.0), 1.0)
        res.append((min(max(float(x), 0.0), 1.0), min(max(float(y), 0.0), 1.0), a, s))
    return res
# EVOLVE-BLOCK-END
