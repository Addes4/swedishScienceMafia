import math
import time
import numpy as np


def _run(K, n):
    V = [[None] * (K + 1) for _ in range(K + 1)]
    for w in range(1, K + 1):
        for h in range(1, w + 1):
            base = np.full(n + 1, min(w, h), dtype=np.int64)
            base[0] = 0
            best = base.copy()
            for (a_dim, other, vert) in ((w, h, True), (h, w, False)):
                for c1 in range(1, a_dim // 2 + 1):
                    c2 = a_dim - c1
                    if vert:
                        A = V[max(c1, h)][min(c1, h)]
                        B = V[max(c2, h)][min(c2, h)]
                    else:
                        A = V[max(w, c1)][min(w, c1)]
                        B = V[max(w, c2)][min(w, c2)]
                    res = np.zeros(n + 1, dtype=np.int64)
                    for a in range(n + 1):
                        np.maximum(res[a:], A[a] + B[:n + 1 - a], out=res[a:])
                    np.maximum(best, res, out=best)
            # monotone (at most c squares)
            best = np.maximum.accumulate(best)
            V[w][h] = best
    return V


def _get(V, w, h):
    return V[max(w, h)][min(w, h)]


def _recon(V, w, h, c, x, y, out):
    if c <= 0:
        return
    val = _get(V, w, h)[c]
    if val == min(w, h):
        s = min(w, h)
        out.append((x, y, s))
        return
    for vert in (True, False):
        dim = w if vert else h
        for c1 in range(1, dim):
            c2 = dim - c1
            if vert:
                A = _get(V, c1, h)
                B = _get(V, c2, h)
            else:
                A = _get(V, w, c1)
                B = _get(V, w, c2)
            for a in range(0, c + 1):
                if A[a] + B[c - a] == val:
                    if vert:
                        _recon(V, c1, h, a, x, y, out)
                        _recon(V, c2, h, c - a, x + c1, y, out)
                    else:
                        _recon(V, w, c1, a, x, y, out)
                        _recon(V, w, c2, c - a, x, y + c1, out)
                    return
    out.append((x, y, min(w, h)))


def solve(n):
    t0 = time.time()
    budget = 35.0
    r = math.sqrt(n)
    Kmax = int(math.ceil(2 * r)) + 1
    Ks = sorted(range(1, Kmax + 1), key=lambda k: abs(k - 1.3 * r))
    best = None
    last = 0.0
    for K in Ks:
        if best is not None:
            est = last * (K / max(1, bestK_prev)) ** 3.5 if False else last * 2.0
            if time.time() - t0 + min(est, 1e9) > budget and K > 1:
                # skip expensive ones, but still try if cheap
                if K * K * K > 0 and (time.time() - t0) > budget * 0.5:
                    continue
        ts = time.time()
        V = _run(K, n)
        last = time.time() - ts
        val = V[K][K][n] / K
        if best is None or val > best[0] + 1e-12:
            best = (val, K, V)
        if time.time() - t0 > budget:
            break
    val, K, V = best
    out = []
    _recon(V, K, K, n, 0, 0, out)
    res = []
    for (x, y, s) in out[:n]:
        res.append(((x + s / 2.0) / K, (y + s / 2.0) / K, 0.0, s / K))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
