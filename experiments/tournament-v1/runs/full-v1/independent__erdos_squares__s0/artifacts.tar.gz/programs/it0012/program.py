import math


def _plan(n, k):
    d = k * k - n
    blocks = []
    if d > 0:
        INF = float('inf')
        items = [(j, j * j - 1, j * j - j) for j in range(2, k + 1)]
        dp = [INF] * (d + 1)
        par = [None] * (d + 1)
        dp[0] = 0
        for r in range(d):
            if dp[r] == INF:
                continue
            for j, g, c in items:
                t = min(d, r + g)
                if dp[r] + c < dp[t]:
                    dp[t] = dp[r] + c
                    par[t] = (r, j)
        if dp[d] == INF:
            return None
        t = d
        while t != 0:
            r, j = par[t]
            blocks.append(j)
            t = r
    blocks.sort(reverse=True)
    occ = [[False] * k for _ in range(k)]
    placed = []
    for j in blocks:
        ok = False
        for y in range(k - j + 1):
            for x in range(k - j + 1):
                if all(not occ[yy][xx] for yy in range(y, y + j) for xx in range(x, x + j)):
                    for yy in range(y, y + j):
                        for xx in range(x, x + j):
                            occ[yy][xx] = True
                    placed.append((x, y, j))
                    ok = True
                    break
            if ok:
                break
        if not ok:
            return None
    for y in range(k):
        for x in range(k):
            if not occ[y][x]:
                placed.append((x, y, 1))
    if len(placed) > n:
        return None
    total = sum(j for _, _, j in placed) / k
    return total, placed


def solve(n):
    if n <= 0:
        return []
    k0 = math.isqrt(n)
    best = None
    for k in range(max(1, k0), k0 + 6):
        r = _plan(n, k)
        if r is None:
            continue
        if best is None or r[0] > best[0] + 1e-12:
            best = (r[0], r[1], k)
    _, placed, k = best
    res = []
    eps = 1 - 1e-12
    for x, y, j in placed:
        res.append(((x + j / 2) / k, (y + j / 2) / k, 0.0, j / k * eps))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
