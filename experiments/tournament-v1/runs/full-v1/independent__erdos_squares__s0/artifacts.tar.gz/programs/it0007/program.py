import math
import numpy as np

NEG = -1e18
_f = [0.0, 1.0]
_k = [0, 1]


def _conv(a, b):
    L = len(a)
    I = np.arange(L)
    D = I[:, None] - I[None, :]  # m - i
    Bm = np.where(D >= 0, b[np.clip(D, 0, L - 1)], NEG)
    return (a[None, :] + Bm).max(axis=1)


def _compute(n):
    while len(_f) <= n:
        m = len(_f)
        g = np.full(m + 1, NEG)
        g[:m] = np.array(_f[:m])
        best = _f[m - 1]
        bk = 0
        for k in range(2, math.isqrt(m) + 2):
            c = k * k
            res = np.full(m + 1, NEG)
            res[0] = 0.0
            base = g.copy()
            e = c
            while e:
                if e & 1:
                    res = _conv(res, base)
                e >>= 1
                if e:
                    base = _conv(base, base)
            v = res.max() / k
            if v > best + 1e-12:
                best = v
                bk = k
        _f.append(best)
        _k.append(bk)


def _place(n, x0, y0, size, out):
    if n <= 0:
        return
    if n == 1:
        s = size * (1 - 1e-9)
        out.append((x0 + size / 2, y0 + size / 2, 0.0, s))
        return
    while _k[n] == 0:
        n -= 1
        if n <= 1:
            _place(n, x0, y0, size, out)
            return
    k = _k[n]
    c = k * k
    g = np.full(n + 1, NEG)
    g[:n] = np.array(_f[:n])
    dp = [np.full(n + 1, NEG) for _ in range(c + 1)]
    dp[0][0] = 0.0
    arg = [None] * (c + 1)
    for ci in range(1, c + 1):
        prev = dp[ci - 1]
        L = n + 1
        I = np.arange(L)
        D = I[:, None] - I[None, :]  # m - j
        # S[m,j] = prev[m-j] + g[j]
        P = np.where(D >= 0, prev[np.clip(D, 0, L - 1)], NEG)
        S = P + g[None, :]
        arg[ci] = S.argmax(axis=1)
        dp[ci] = S.max(axis=1)
    t = int(np.argmax(dp[c]))
    counts = []
    for ci in range(c, 0, -1):
        j = int(arg[ci][t])
        counts.append(j)
        t -= j
    cs = size / k
    idx = 0
    for r in range(k):
        for q in range(k):
            _place(counts[idx], x0 + q * cs, y0 + r * cs, cs, out)
            idx += 1


def solve(n):
    if n <= 0:
        return []
    _compute(n)
    out = []
    _place(n, 0.0, 0.0, 1.0, out)
    res = []
    for (x, y, a, s) in out:
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        res.append((x, y, a, s))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
