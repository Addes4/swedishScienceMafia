import math
import numpy as np


def _conv(A, B):
    n1 = len(A)
    C = np.full(n1, -1e18)
    Arg = np.zeros(n1, dtype=np.int64)
    for a in range(n1):
        cand = A[a] + B[:n1 - a]
        seg = C[a:]
        mask = cand > seg
        if mask.any():
            seg[mask] = cand[mask]
            Arg[a:][mask] = a
    return C, Arg


class _Tables:
    def __init__(self, f):
        self.f = f
        self.memo = {}

    def get(self, t):
        if t in self.memo:
            return self.memo[t]
        if t == 1:
            res = (self.f, None)
        else:
            a = t // 2
            b = t - a
            Pa = self.get(a)[0]
            Pb = self.get(b)[0]
            res = _conv(Pa, Pb)
        self.memo[t] = res
        return res

    def alloc(self, t, c):
        if t == 1:
            return [c]
        a = t // 2
        ca = int(self.get(t)[1][c])
        return self.alloc(a, ca) + self.alloc(t - a, c - ca)


def solve(n):
    if n <= 0:
        return []
    Jfull = math.isqrt(n) + 1
    Jin = min(Jfull, 8)
    f = np.array([0.0] + [1.0] * n)
    for _ in range(8):
        T = _Tables(f)
        newf = f.copy()
        for j in range(2, Jin + 1):
            P = T.get(j * j)[0]
            newf = np.maximum(newf, P / j)
        if np.allclose(newf, f, atol=1e-12):
            f = newf
            break
        f = newf
    T = _Tables(f)
    out = []

    def place(c, x0, y0, size, depth):
        if c <= 0:
            return
        if depth > 8 or c == 1:
            out.append((x0 + size / 2, y0 + size / 2, 0.0, size))
            return
        top = (depth == 0)
        jmax = Jfull if top else Jin
        bestv = 1.0
        bestj = 0
        for j in range(2, jmax + 1):
            v = T.get(j * j)[0][c] / j
            if v > bestv + 1e-12:
                bestv = v
                bestj = j
        if bestj == 0:
            out.append((x0 + size / 2, y0 + size / 2, 0.0, size))
            return
        j = bestj
        counts = T.alloc(j * j, c)
        cs = size / j
        for i, ci in enumerate(counts):
            if ci > 0:
                r, col = divmod(i, j)
                place(ci, x0 + col * cs, y0 + r * cs, cs, depth + 1)

    place(n, 0.0, 0.0, 1.0, 0)
    res = []
    for (x, y, a, s) in out[:n]:
        s2 = max(0.0, min(1.0, s * (1 - 1e-10)))
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), 0.0, s2))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
