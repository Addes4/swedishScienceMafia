import math


def solve(n):
    best = None
    mmax = 2 * math.isqrt(n) + 3
    for m in range(1, mmax + 1):
        tmax = (m // 2) ** 2
        t0 = max(0, -(-(m * m - n) // 3))
        for t in range(max(0, t0 - 2), min(tmax, t0 + 2) + 1):
            cnt = m * m - 3 * t
            d = max(0, cnt - n)
            unm = m * m - 4 * t
            if d > unm:
                continue
            val = (unm - d) / m + 2.0 * t / m
            if best is None or val > best[0] + 1e-12:
                best = (val, m, t, d)
    _, m, t, d = best
    h = m // 2
    used = [[False] * m for _ in range(m)]
    sq = []
    shrink = 1 - 1e-9
    k = 0
    for bi in range(h):
        for bj in range(h):
            if k >= t:
                break
            i, j = 2 * bi, 2 * bj
            for a in range(2):
                for b in range(2):
                    used[i + a][j + b] = True
            s = 2.0 / m
            sq.append(((j + 1) / m, (i + 1) / m, 0.0, s * shrink))
            k += 1
    dropped = 0
    s = 1.0 / m
    for i in range(m):
        for j in range(m):
            if used[i][j]:
                continue
            if dropped < d:
                dropped += 1
                continue
            sq.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s * shrink))
    sq = sq[:n]
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq
