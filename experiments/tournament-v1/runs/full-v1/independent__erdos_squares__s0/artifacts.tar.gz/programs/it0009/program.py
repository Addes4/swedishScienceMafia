import math


def solve(n):
    r = math.isqrt(n)
    if r * r < n:
        r += 1
    K = 2 * r + 2
    best = (-1.0, 1, 1, 0)
    for k in range(1, K + 1):
        kk = k * k
        for a in range(1, k + 1):
            slots = (k // a) ** 2
            if a == 1:
                ts = [0]
            else:
                ts = range(0, slots + 1)
            a2 = a * a
            for t in ts:
                free = kk - t * a2
                count = t + free
                drops = max(0, count - n)
                if drops > free:
                    continue
                s = (t * a + free - drops) / k
                if s > best[0] + 1e-12:
                    best = (s, k, a, t)
    _, k, a, t = best
    side = 1.0 / k
    shrink = 1.0 - 1e-12
    squares = []
    covered = [[False] * k for _ in range(k)]
    per = k // a
    placed = 0
    for q in range(per):
        for p in range(per):
            if placed >= t:
                break
            for dx in range(a):
                for dy in range(a):
                    covered[p * a + dx][q * a + dy] = True
            squares.append(((p * a + a / 2.0) * side, (q * a + a / 2.0) * side, 0.0, a * side * shrink))
            placed += 1
    free_cells = [(i, j) for i in range(k) for j in range(k) if not covered[i][j]]
    need = n - len(squares)
    for (i, j) in free_cells[:max(need, 0)]:
        squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side * shrink))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
