import math
import sys


def solve(n):
    sys.setrecursionlimit(10000)
    if n <= 0:
        return []
    g = [0.0] * (n + 1)
    ch = [None] * (n + 1)
    for N in range(1, n + 1):
        k = math.isqrt(N)
        if k * k < N:
            k += 1
        best = N / k
        choice = ("grid", k)
        qmax = 2 * math.isqrt(N) + 3
        for q in range(2, qmax + 1):
            lo = max(1, N - (2 * q - 1))
            f = 1.0 - 1.0 / q
            for m in range(lo, N):
                v = f * g[m] + (N - m) / q
                if v > best + 1e-12:
                    best = v
                    choice = ("rec", q, m)
        g[N] = best
        ch[N] = choice

    out = []

    def place(N, x0, y0, s):
        while N > 0:
            c = ch[N]
            if c[0] == "grid":
                k = c[1]
                cell = s / k
                cnt = 0
                for j in range(k):
                    for i in range(k):
                        if cnt >= N:
                            break
                        out.append((x0 + (i + 0.5) * cell, y0 + (j + 0.5) * cell, 0.0, cell))
                        cnt += 1
                return
            _, q, m = c
            t = s / q
            big = s - t
            cnt = N - m
            # right column
            placed = 0
            for j in range(q):
                if placed >= cnt:
                    break
                out.append((x0 + big + t / 2, y0 + (j + 0.5) * t, 0.0, t))
                placed += 1
            for i in range(q - 1):
                if placed >= cnt:
                    break
                out.append((x0 + (i + 0.5) * t, y0 + big + t / 2, 0.0, t))
                placed += 1
            N = m
            s = big

    place(n, 0.0, 0.0, 1.0)
    res = []
    for (x, y, a, s) in out:
        s2 = s * (1 - 1e-9)
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        res.append((x, y, a, s2))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
