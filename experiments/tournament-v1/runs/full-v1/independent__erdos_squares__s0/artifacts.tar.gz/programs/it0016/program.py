import math
import numpy as np


def solve(n):
    NEG = -1e18
    T = min(n, 150)
    M = math.isqrt(T) + 2
    F = np.zeros(T + 1)
    choice = [None] * (T + 1)
    Hf = {}
    for m in range(2, M + 1):
        m2 = m * m
        H = np.full((m2 + 1, T + 1), NEG)
        H[:, 0] = 0.0
        Hf[m] = H
    if T >= 1:
        F[1] = 1.0
        choice[1] = ('one',)
        for m in Hf:
            Hf[m][1:, 1] = 1.0 / m
    for t in range(2, T + 1):
        best = 1.0
        ch = ('one',)
        if F[t - 1] > best + 1e-12:
            best = F[t - 1]
            ch = ('copy',)
        Hps = {}
        for m in Hf:
            m2 = m * m
            H = Hf[m]
            X = (H[:m2, t - 1:0:-1] + F[1:t] / m).max(axis=1)
            Hp = np.maximum.accumulate(X)
            Hps[m] = Hp
            if Hp[m2 - 1] > best + 1e-12:
                best = Hp[m2 - 1]
                ch = ('grid', m)
            for b in range(2, m):
                c = m2 - b * b
                if c < 1:
                    continue
                vals = H[c, t - 1:0:-1] + F[1:t] * b / m
                k = int(np.argmax(vals))
                if vals[k] > best + 1e-12:
                    best = vals[k]
                    ch = ('block', m, b, k + 1)
        F[t] = best
        choice[t] = ch
        for m in Hf:
            m2 = m * m
            Hf[m][1:, t] = np.maximum(Hps[m], best / m)

    out = []

    def distribute(m, t, cells, x0, y0, s):
        c = len(cells)
        tt = t
        H = Hf[m]
        for idx in range(c, 0, -1):
            if tt <= 0:
                break
            js = np.arange(0, tt + 1)
            vals = H[idx - 1][tt - js] + F[js] / m
            j = int(np.argmax(vals))
            r, cc = cells[idx - 1]
            if j > 0:
                build(j, x0 + cc * s / m, y0 + r * s / m, s / m)
            tt -= j

    def build(t, x0, y0, s):
        if t <= 0:
            return
        ch = choice[t]
        if ch[0] == 'one':
            out.append((x0 + s / 2, y0 + s / 2, 0.0, s))
        elif ch[0] == 'copy':
            build(t - 1, x0, y0, s)
        elif ch[0] == 'grid':
            m = ch[1]
            cells = [(r, c) for r in range(m) for c in range(m)]
            distribute(m, t, cells, x0, y0, s)
        else:
            _, m, b, j = ch
            build(j, x0, y0, b * s / m)
            cells = [(r, c) for r in range(m) for c in range(m) if not (r < b and c < b)]
            distribute(m, t - j, cells, x0, y0, s)

    if n <= T:
        build(n, 0.0, 0.0, 1.0)
    elif n > 5000:
        k = math.isqrt(n)
        if k * k < n:
            k += 1
        s = 1.0 / k
        out = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)][:n]
    else:
        JT = min(T, 40)
        bestv = -1.0
        bestsol = None
        r0 = math.isqrt(n)
        for m in range(max(2, r0 - 1), r0 + 3):
            m2 = m * m
            Fv = F[:JT + 1] / m
            Hh = np.full(n + 1, NEG)
            Hh[0] = 0.0
            chs = []
            for c in range(1, m2 + 1):
                newH = Hh.copy()
                arg = np.zeros(n + 1, dtype=np.int16)
                for j in range(1, JT + 1):
                    if j > n:
                        break
                    cand = Hh[:n + 1 - j] + Fv[j]
                    seg = newH[j:]
                    mask = cand > seg
                    seg[mask] = cand[mask]
                    arg[j:][mask] = j
                Hh = newH
                chs.append(arg)
            if Hh[n] > bestv:
                bestv = Hh[n]
                bestsol = (m, chs)
        if bestsol is None:
            k = math.isqrt(n)
            k = k + 1 if k * k < n else k
            s = 1.0 / k
            out = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)][:n]
        else:
            m, chs = bestsol
            tt = n
            s = 1.0 / m
            for c in range(m * m, 0, -1):
                if tt <= 0:
                    break
                j = int(chs[c - 1][tt])
                if j > 0:
                    r, cc = divmod(c - 1, m)
                    build(j, cc * s, r * s, s)
                tt -= j

    res = []
    for (x, y, a, s) in out:
        s2 = max(0.0, s * (1 - 1e-9))
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), 0.0, min(1.0, s2)))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
