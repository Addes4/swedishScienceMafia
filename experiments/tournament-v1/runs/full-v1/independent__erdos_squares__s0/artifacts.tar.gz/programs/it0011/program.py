import math
import time
import numpy as np


def solve(n):
    t_start = time.time()
    g = [0.0] * (n + 1)
    desc = [None] * (n + 1)
    kmax = 4 if n <= 150 else 3

    def simple_best(c):
        best = (-1.0, None)
        K = math.isqrt(c) + 3
        for k in range(1, K + 1):
            # no block
            nc = min(c, k * k)
            v = nc / k
            if v > best[0] + 1e-12:
                best = (v, ('s', k, 0, nc, False))
            for j in range(2, k):
                nc = min(c - 1, k * k - j * j)
                v = (j + nc) / k
                if v > best[0] + 1e-12:
                    best = (v, ('s', k, j, nc, True))
        return best

    def pieces_of(k, j):
        if j >= 2:
            return [j / k] + [1.0 / k] * (k * k - j * j)
        return [1.0 / k] * (k * k)

    for c in range(1, n + 1):
        v, d = simple_best(c)
        if c == 1:
            v, d = 1.0, ('s', 1, 0, 1, False)
        if c >= 2 and time.time() - t_start < 35:
            garr = np.array(g[:c], dtype=float)  # counts 0..c-1
            for k in range(2, kmax + 1):
                for j in range(1, k):
                    pcs = pieces_of(k, j)
                    dp = np.zeros(c + 1)
                    choices = []
                    for a in pcs:
                        val = a * garr
                        new = dp.copy()
                        ch = np.zeros(c + 1, dtype=np.int32)
                        for s in range(1, c):
                            cand = dp[:c + 1 - s] + val[s]
                            seg = new[s:]
                            m = cand > seg + 1e-12
                            if m.any():
                                seg[m] = cand[m]
                                ch[s:][m] = s
                        dp = new
                        choices.append(ch)
                    if dp[c] > v + 1e-12:
                        v = float(dp[c])
                        counts = []
                        t = c
                        for p in range(len(pcs) - 1, -1, -1):
                            s = int(choices[p][t])
                            counts.append(s)
                            t -= s
                        counts.reverse()
                        d = ('n', k, j, counts)
        if c > 1 and g[c - 1] >= v - 1e-12:
            g[c] = g[c - 1]
            desc[c] = ('m',)
        else:
            g[c] = v
            desc[c] = d

    out = []

    def cells_list(k, j):
        res = []
        for a in range(k):
            for b in range(k):
                if j >= 2 and a < j and b < j:
                    continue
                res.append((a, b))
        return res

    def build(c, x0, y0, size):
        if c <= 0:
            return
        d = desc[c]
        while d[0] == 'm':
            c -= 1
            d = desc[c]
        if c <= 0:
            return
        if d[0] == 's':
            _, k, j, nc, ub = d
            cell = size / k
            if ub:
                out.append((x0 + j * cell / 2, y0 + j * cell / 2, 0.0, j * cell))
            cl = cells_list(k, j if ub else 0)
            for (a, b) in cl[:nc]:
                out.append((x0 + (a + 0.5) * cell, y0 + (b + 0.5) * cell, 0.0, cell))
        else:
            _, k, j, counts = d
            cell = size / k
            idx = 0
            if j >= 2:
                build(counts[0], x0, y0, j * cell)
                idx = 1
            for (a, b) in cells_list(k, j):
                build(counts[idx], x0 + a * cell, y0 + b * cell, cell)
                idx += 1

    build(n, 0.0, 0.0, 1.0)
    res = []
    for (x, y, a, s) in out[:n]:
        x = min(1.0, max(0.0, x))
        y = min(1.0, max(0.0, y))
        s = min(1.0, max(0.0, s))
        res.append((x, y, a, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
