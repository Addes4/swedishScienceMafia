import math
import numpy as np


def solve(n):
    NEG = -1e18
    kmax = 10
    C = kmax * kmax
    N = n
    f = [0.0] * (N + 1)
    method = [0] * (N + 1)  # 0 = single square, k>=2 = grid k
    g = np.full((C + 1, N + 1), NEG)
    g[0][0] = 0.0
    choice = np.zeros((C + 1, N + 1), dtype=np.int64)
    farr = np.zeros(N + 1)
    for m in range(1, N + 1):
        # pass 1: exclude any cell holding all m
        if m >= 2:
            for c in range(1, C + 1):
                prev = g[c - 1]
                arr = prev[m:0:-1] + farr[0:m]  # j = 0..m-1 : prev[m-j] + f[j]
                j = int(np.argmax(arr))
                g[c][m] = arr[j]
                choice[c][m] = j
        if m == 1:
            f[1] = 1.0
            method[1] = 0
        else:
            best = 1.0
            bk = 0
            for k in range(2, kmax + 1):
                v = g[k * k][m] / k
                if v > best + 1e-12:
                    best = v
                    bk = k
            f[m] = best
            method[m] = bk
        farr[m] = f[m]
        for c in range(1, C + 1):
            if f[m] > g[c][m]:
                g[c][m] = f[m]
                choice[c][m] = m

    out = []

    def build(m, x0, y0, size):
        if m <= 0:
            return
        k = method[m]
        if m == 1 or k == 0:
            out.append((x0 + size / 2, y0 + size / 2, 0.0, size))
            return
        cell = size / k
        rem = m
        for c in range(k * k, 0, -1):
            j = int(choice[c][rem])
            if j > 0:
                idx = c - 1
                r, q = divmod(idx, k)
                build(j, x0 + q * cell, y0 + r * cell, cell)
            rem -= j
            if rem <= 0:
                break

    build(n, 0.0, 0.0, 1.0)
    res = []
    shrink = 1.0 - 1e-9
    for (cx, cy, a, s) in out:
        res.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a, s * shrink))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
