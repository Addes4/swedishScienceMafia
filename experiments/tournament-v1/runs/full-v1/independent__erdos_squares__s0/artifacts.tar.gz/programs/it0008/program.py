import math
import numpy as np


def _place_single(K, j, q):
    occ = np.zeros((K, K), dtype=bool)
    sq = []
    m = K // j
    for idx in range(q):
        r = (idx // m) * j
        c = (idx % m) * j
        occ[r:r + j, c:c + j] = True
        sq.append((r, c, j))
    return occ, sq


def _place_greedy(K, spec):
    occ = np.zeros((K, K), dtype=bool)
    sq = []
    for j, q in spec:
        for _ in range(q):
            found = False
            for r in range(K - j + 1):
                for c in range(K - j + 1):
                    if not occ[r:r + j, c:c + j].any():
                        occ[r:r + j, c:c + j] = True
                        sq.append((r, c, j))
                        found = True
                        break
                if found:
                    break
            if not found:
                return None, None
    return occ, sq


def _value(K, spec, n):
    A = sum(q * j * j for j, q in spec)
    if A > K * K:
        return None
    cnt_big = sum(q for j, q in spec)
    if cnt_big > n:
        return None
    units = K * K - A
    count = cnt_big + units
    s = sum(q * j for j, q in spec) + units
    d = max(0, count - n)
    if d > units:
        return None
    return (s - d) / K, d


def solve(n):
    k0 = max(1, math.isqrt(n))
    best = (k0 * 1.0 / k0 * k0 / k0 if False else float(k0), k0, [], 0)
    # baseline: k0 x k0 grid
    best = ((min(n, k0 * k0)) / k0, k0, [], max(0, k0 * k0 - n))
    for K in range(k0, k0 + 5):
        v = _value(K, [], n)
        if v and v[0] > best[0] + 1e-12:
            best = (v[0], K, [], v[1])
        for j in range(2, K):
            mq = (K // j) ** 2
            for q in range(1, mq + 1):
                v = _value(K, [(j, q)], n)
                if v is None:
                    continue
                if v[0] > best[0] + 1e-12:
                    best = (v[0], K, [(j, q)], v[1])
        if K <= 10:
            for j1 in range(3, K):
                for q1 in range(1, (K // j1) ** 2 + 1):
                    for j2 in range(2, j1):
                        for q2 in range(1, 9):
                            spec = [(j1, q1), (j2, q2)]
                            v = _value(K, spec, n)
                            if v is None:
                                continue
                            if v[0] > best[0] + 1e-12:
                                occ, sq = _place_greedy(K, spec)
                                if occ is not None:
                                    best = (v[0], K, spec, v[1])
    val, K, spec, d = best
    if len(spec) == 0:
        occ = np.zeros((K, K), dtype=bool)
        sq = []
    elif len(spec) == 1:
        occ, sq = _place_single(K, spec[0][0], spec[0][1])
    else:
        occ, sq = _place_greedy(K, spec)
    units = [(r, c, 1) for r in range(K) for c in range(K) if not occ[r, c]]
    if d > 0:
        units = units[:len(units) - d]
    allsq = sq + units
    allsq = allsq[:n]
    out = []
    shrink = 1 - 1e-9
    for r, c, s in allsq:
        out.append(((c + s / 2) / K, (r + s / 2) / K, 0.0, s / K * shrink))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
