import math
import time
import numpy as np


def _grid(n):
    k = max(1, math.isqrt(n))
    best = None
    for kk in (k, k + 1):
        cnt = min(n, kk * kk)
        val = cnt / kk
        if best is None or val > best[0]:
            best = (val, kk, cnt)
    _, kk, cnt = best
    s = 1.0 / kk
    sq = []
    for i in range(kk):
        for j in range(kk):
            if len(sq) < cnt:
                sq.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return best[0], sq


def solve(n):
    t0 = time.time()
    gval, gsq = _grid(n)
    r = math.isqrt(n)
    M = 0
    for cand in range(1, r + 9):
        cost = 0
        for w in range(1, cand + 1):
            for h in range(1, cand + 1):
                cost += (w // 2 + h // 2) * (n + 1) ** 2
        if cost <= 1.2e8:
            M = cand
    if M < 2:
        return _pad(gsq, n)
    N = n + 1
    K = np.arange(N)
    diff = K[:, None] - K[None, :]
    valid = diff >= 0
    dclip = np.maximum(diff, 0)
    NEG = -1e9
    g = {}
    ch = {}
    zero = np.zeros(N)
    for w in range(1, M + 1):
        for h in range(1, M + 1):
            best = np.full(N, float(min(w, h)))
            best[0] = 0.0
            kind = np.zeros(N, dtype=np.int8)
            kind[0] = -1
            pos = np.zeros(N, dtype=np.int32)
            jj = np.zeros(N, dtype=np.int32)
            for typ in (1, 2):
                lim = (w if typ == 1 else h)
                for p in range(1, lim // 2 + 1):
                    if typ == 1:
                        A = g[(p, h)]
                        B = g[(w - p, h)]
                    else:
                        A = g[(w, p)]
                        B = g[(w, h - p)]
                    V = np.where(valid, A[None, :] + B[dclip], NEG)
                    am = V.argmax(1)
                    mx = V[K, am]
                    upd = mx > best + 1e-9
                    if upd.any():
                        best = np.where(upd, mx, best)
                        kind = np.where(upd, typ, kind).astype(np.int8)
                        pos = np.where(upd, p, pos).astype(np.int32)
                        jj = np.where(upd, am, jj).astype(np.int32)
            g[(w, h)] = best
            ch[(w, h)] = (kind, pos, jj)
        if time.time() - t0 > 45:
            return _pad(gsq, n)
    bm, bv = 1, -1
    for m in range(1, M + 1):
        v = g[(m, m)][n] / m
        if v > bv + 1e-12:
            bv, bm = v, m
    if bv <= gval + 1e-12:
        return _pad(gsq, n)
    out = []
    stack = [(0, 0, bm, bm, n)]
    s = 1.0 / bm
    while stack:
        x0, y0, w, h, k = stack.pop()
        if k <= 0:
            continue
        kind, pos, jj = ch[(w, h)]
        kd = int(kind[k])
        if kd == 0:
            side = min(w, h)
            out.append(((x0 + side / 2) * s, (y0 + side / 2) * s, 0.0, side * s))
        elif kd == 1:
            p = int(pos[k]); j = int(jj[k])
            stack.append((x0, y0, p, h, j))
            stack.append((x0 + p, y0, w - p, h, k - j))
        elif kd == 2:
            p = int(pos[k]); j = int(jj[k])
            stack.append((x0, y0, w, p, j))
            stack.append((x0, y0 + p, w, h - p, k - j))
    if len(out) > n:
        out.sort(key=lambda t: -t[3])
        out = out[:n]
    return _pad(out, n)


def _pad(sq, n):
    sq = list(sq)
    res = []
    for (x, y, a, s) in sq[:n]:
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), a, min(1.0, max(0.0, s))))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
