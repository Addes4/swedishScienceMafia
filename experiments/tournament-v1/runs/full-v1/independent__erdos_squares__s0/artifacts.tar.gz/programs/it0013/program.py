import math
import numpy as np

_memo = {0: (0.0, None, None), 1: (1.0, None, None)}


def _dp(N, m):
    cells = m * m
    J = min(N - 1, 2 * (-(-N // cells)) + 3)
    if J < 1:
        return None
    gv = [0.0] + [_g(j)[0] / m for j in range(1, J + 1)]
    dp = np.full(N + 1, -np.inf)
    dp[0] = 0.0
    choices = []
    for _ in range(cells):
        new = dp.copy()
        ch = np.zeros(N + 1, dtype=np.int32)
        for j in range(1, min(J, N) + 1):
            cand = np.full(N + 1, -np.inf)
            cand[j:] = dp[:N + 1 - j] + gv[j]
            mask = cand > new
            new[mask] = cand[mask]
            ch[mask] = j
        dp = new
        choices.append(ch)
    if not np.isfinite(dp[N]):
        return None
    counts = []
    t = N
    for c in range(cells - 1, -1, -1):
        j = int(choices[c][t])
        counts.append(j)
        t -= j
    counts.reverse()
    return float(dp[N]), counts


def _g(N):
    if N in _memo:
        return _memo[N]
    s = math.isqrt(N)
    best = (-1.0, None, None)
    ms = set()
    for m in (s - 1, s, s + 1):
        if m >= 2:
            ms.add(m)
    if not ms:
        ms.add(2)
    for m in sorted(ms):
        r = _dp(N, m)
        if r is None:
            continue
        if r[0] > best[0]:
            best = (r[0], m, r[1])
    _memo[N] = best
    return best


def _place(N, x0, y0, size, out):
    if N <= 0:
        return
    if N == 1:
        out.append((x0 + size / 2, y0 + size / 2, 0.0, size))
        return
    val, m, counts = _g(N)
    cs = size / m
    for idx, j in enumerate(counts):
        if j == 0:
            continue
        r, c = divmod(idx, m)
        _place(j, x0 + c * cs, y0 + r * cs, cs, out)


def solve(n):
    out = []
    if n >= 1:
        _place(n, 0.0, 0.0, 1.0, out)
    out = out[:n]
    out = [(min(1.0, max(0.0, a)), min(1.0, max(0.0, b)), 0.0, min(1.0, max(0.0, d)))
           for a, b, _, d in out]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
