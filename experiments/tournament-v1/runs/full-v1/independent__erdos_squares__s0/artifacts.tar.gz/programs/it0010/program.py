import math


def _build(m, n, a3t, a2t):
    occ = [[False] * m for _ in range(m)]
    blocks = []
    p3 = 0
    if m >= 3:
        for i in range(m // 3):
            for j in range(m // 3):
                if p3 >= a3t:
                    break
                for x in range(3):
                    for y in range(3):
                        occ[3 * i + x][3 * j + y] = True
                blocks.append((3 * i, 3 * j, 3))
                p3 += 1
    p2 = 0
    if m >= 2 and a2t > 0:
        for r in range(m - 1):
            for c in range(m - 1):
                if p2 >= a2t:
                    break
                if not (occ[r][c] or occ[r + 1][c] or occ[r][c + 1] or occ[r + 1][c + 1]):
                    occ[r][c] = occ[r + 1][c] = occ[r][c + 1] = occ[r + 1][c + 1] = True
                    blocks.append((r, c, 2))
                    p2 += 1
    count = m * m - 3 * p2 - 8 * p3
    rem = max(0, count - n)
    free = [(r, c) for r in range(m) for c in range(m) if not occ[r][c]]
    if rem > len(free):
        return None
    removed = set(free[len(free) - rem:]) if rem > 0 else set()
    cells = [(r, c, 1) for (r, c) in free if (r, c) not in removed]
    total = (len(cells) + 2 * p2 + 3 * p3) / m
    return total, blocks + cells


def solve(n):
    if n <= 0:
        return []
    k = math.isqrt(n)
    if k * k < n:
        ms = [k, k + 1, k + 2]
    else:
        ms = [k]
    best = None
    for m in ms:
        if m < 1:
            continue
        if m * m <= n:
            res = _build(m, n, 0, 0)
            if res and (best is None or res[0] > best[0] + 1e-12):
                best = (res[0], res[1], m)
            continue
        e = m * m - n
        for a3 in range(0, min(8, (m // 3) ** 2) + 1):
            need = e - 8 * a3
            a2base = max(0, -(-need // 3))
            for a2 in {a2base, max(0, a2base - 1), max(0, a2base - 2), a2base + 1}:
                res = _build(m, n, a3, a2)
                if res and (best is None or res[0] > best[0] + 1e-12):
                    best = (res[0], res[1], m)
    if best is None:
        side = 1.0 / max(k, 1)
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
              for i in range(k) for j in range(k)]
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        return sq[:n]
    _, items, m = best
    out = []
    for (r, c, t) in items:
        s = t / m
        cx = (c + t / 2.0) / m
        cy = (r + t / 2.0) / m
        out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0, min(1.0, s * (1 - 1e-12))))
    out = out[:n]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out
