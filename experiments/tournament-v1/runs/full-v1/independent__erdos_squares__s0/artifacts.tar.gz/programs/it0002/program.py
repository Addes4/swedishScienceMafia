import math


def solve(n):
    best_val = -1.0
    best_spec = None
    eps = 1e-12
    for a in range(1, n + 1):
        for ca in range(1, min(a, n // a) + 1):
            used_a = ca * a
            ha = ca / a
            if ha > 1 + eps:
                break
            # single-value case
            left = n - used_a
            rem = 1 - ha
            val = ca
            if left > 0 and rem > eps:
                val += min(left * rem, 1.0)
            if val > best_val + 1e-12:
                best_val = val
                best_spec = ([(a, ca)], left, rem)
            for b in range(1, a):
                maxcb = min((n - used_a) // b, b)
                for cb in range(1, maxcb + 1):
                    h = ha + cb / b
                    if h > 1 + eps:
                        break
                    left = n - used_a - cb * b
                    rem = max(0.0, 1 - h)
                    val = ca + cb
                    if left > 0 and rem > eps:
                        val += min(left * rem, 1.0)
                    if val > best_val + 1e-12:
                        best_val = val
                        best_spec = ([(a, ca), (b, cb)], left, rem)
    rows_spec, left, rem = best_spec
    rows = []
    for m, c in rows_spec:
        for _ in range(c):
            rows.append((m, 1.0 / m))
    if left > 0 and rem > eps:
        rows.append((left, min(rem, 1.0 / left)))
    shrink = 1 - 1e-10
    res = []
    y = 0.0
    for m, h in rows:
        for i in range(m):
            if len(res) >= n:
                break
            s = h * shrink
            cx = (i + 0.5) * h
            cy = y + h / 2
            res.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0, s))
        y += h
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
