import numpy as np
import time
from scipy.optimize import minimize, linprog


def _max_radii(centers, iu=None, ju=None):
    n = len(centers)
    if iu is None:
        iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    d = np.sqrt(((centers[iu] - centers[ju]) ** 2).sum(1))
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    A = np.zeros((m, n))
    k = np.arange(m)
    A[k, iu] = 1
    A[k, ju] = 1
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method='highs')
        if res.status == 0:
            return np.maximum(res.x - 1e-12, 0)
    except Exception:
        pass
    r = wall.copy()
    for _ in range(50):
        ch = False
        for a in range(m):
            i, j = iu[a], ju[a]
            if r[i] + r[j] > d[a]:
                s = d[a] / (r[i] + r[j] + 1e-18)
                r[i] *= s
                r[j] *= s
                ch = True
        if not ch:
            break
    return r


def _optimize(x0, n, iu, ju, maxiter=300):
    def obj(x):
        return -np.sum(x[2 * n:])

    def obj_grad(x):
        g = np.zeros_like(x)
        g[2 * n:] = -1
        return g

    m = len(iu)
    k = np.arange(m)
    a = np.arange(n)

    def cons(x):
        c = x[:2 * n].reshape(n, 2)
        r = x[2 * n:]
        d = np.sqrt(((c[iu] - c[ju]) ** 2).sum(1))
        pair = d - r[iu] - r[ju]
        return np.concatenate([pair, c[:, 0] - r, c[:, 1] - r, 1 - c[:, 0] - r, 1 - c[:, 1] - r])

    def cons_jac(x):
        c = x[:2 * n].reshape(n, 2)
        J = np.zeros((m + 4 * n, 3 * n))
        diff = c[iu] - c[ju]
        d = np.sqrt((diff ** 2).sum(1)) + 1e-12
        u = diff / d[:, None]
        J[k, 2 * iu] = u[:, 0]
        J[k, 2 * iu + 1] = u[:, 1]
        J[k, 2 * ju] = -u[:, 0]
        J[k, 2 * ju + 1] = -u[:, 1]
        J[k, 2 * n + iu] = -1
        J[k, 2 * n + ju] = -1
        J[m + a, 2 * a] = 1
        J[m + a, 2 * n + a] = -1
        J[m + n + a, 2 * a + 1] = 1
        J[m + n + a, 2 * n + a] = -1
        J[m + 2 * n + a, 2 * a] = -1
        J[m + 2 * n + a, 2 * n + a] = -1
        J[m + 3 * n + a, 2 * a + 1] = -1
        J[m + 3 * n + a, 2 * n + a] = -1
        return J

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    res = minimize(obj, x0, jac=obj_grad, method='SLSQP', bounds=bounds,
                   constraints=[{'type': 'ineq', 'fun': cons, 'jac': cons_jac}],
                   options={'maxiter': maxiter, 'ftol': 1e-10})
    return res.x


def _init(it, n, rng):
    if it % 3 == 0:
        return rng.random((n, 2)) * 0.9 + 0.05
    if it % 3 == 1:
        k = int(np.ceil(np.sqrt(n)))
        g = [((i + 0.5) / k, (j + 0.5) / k) for i in range(k) for j in range(k)]
        idx = rng.permutation(len(g))[:n]
        c0 = np.array(g)[idx] + rng.normal(0, 0.03, (n, 2))
        return np.clip(c0, 0.03, 0.97)
    c0 = [[0.5, 0.5]]
    c0 += [[0.5 + 0.25 * np.cos(2 * np.pi * i / 8 + 0.3), 0.5 + 0.25 * np.sin(2 * np.pi * i / 8 + 0.3)] for i in range(8)]
    c0 += [[0.5 + 0.43 * np.cos(2 * np.pi * i / 17), 0.5 + 0.43 * np.sin(2 * np.pi * i / 17)] for i in range(n - 9)]
    return np.clip(np.array(c0) + rng.normal(0, 0.02, (n, 2)), 0.03, 0.97)


def solve(n=26):
    t0 = time.time()
    rng = np.random.default_rng(1)
    iu, ju = np.triu_indices(n, 1)
    best_s, best = -1, None
    cur_s, cur = -1, None
    it = 0
    T1, T = 70, 235

    def run(c0):
        r0 = _max_radii(c0, iu, ju)
        x0 = np.concatenate([c0.ravel(), r0])
        x = _optimize(x0, n, iu, ju)
        c = np.clip(x[:2 * n].reshape(n, 2), 0, 1)
        r = _max_radii(c, iu, ju)
        return r.sum(), c, r

    while time.time() - t0 < T:
        elapsed = time.time() - t0
        if elapsed < T1 or best is None:
            c0 = _init(it, n, rng)
        else:
            c0 = best[0].copy()
            mode = rng.integers(3)
            if mode == 0:
                c0 += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), c0.shape)
            elif mode == 1:
                kk = rng.integers(1, 4)
                idx = rng.choice(n, kk, replace=False)
                c0[idx] = rng.random((kk, 2)) * 0.9 + 0.05
                c0 += rng.normal(0, 0.005, c0.shape)
            else:
                # swap two circles with different radii
                i, j = rng.choice(n, 2, replace=False)
                c0[[i, j]] = c0[[j, i]]
                c0[i] += rng.normal(0, 0.03, 2)
                c0[j] += rng.normal(0, 0.03, 2)
            c0 = np.clip(c0, 0.02, 0.98)
        it += 1
        try:
            s, c, r = run(c0)
        except Exception:
            continue
        if s > best_s:
            best_s, best = s, (c.copy(), r.copy())
    return best[0], best[1]
