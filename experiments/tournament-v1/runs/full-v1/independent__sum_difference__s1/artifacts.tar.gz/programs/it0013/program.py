import math
import time
import numpy as np
from math import comb


def _gen(d, n):
    # all points in N^d with coordinate sum <= n, encoded in base 2n+1
    base = 2 * n + 1
    pts = [np.zeros(0, dtype=np.int64)]
    # build iteratively: list of (value, remaining sum)
    vals = np.zeros(1, dtype=np.int64)
    rem = np.full(1, n, dtype=np.int64)
    for _ in range(d):
        nv = []
        nr = []
        for c in range(n + 1):
            mask = rem >= c
            nv.append(vals[mask] * base + c)
            nr.append(rem[mask] - c)
        vals = np.concatenate(nv)
        rem = np.concatenate(nr)
    return vals


def _score_arr(a):
    a = np.unique(a)
    m = len(a)
    if m < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / m) / 100


def solve():
    t0 = time.time()
    cands = []
    for n in range(2, 40):
        for d in range(2, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            if size < 30:
                continue
            if (2 * n + 1) ** d > 10 ** 15:
                break
            cands.append((size, d, n))
    cands.sort(reverse=True)
    best = None
    best_s = -1
    for size, d, n in cands:
        if time.time() - t0 > 85:
            break
        a = _gen(d, n)
        s = _score_arr(a)
        if s > best_s:
            best_s = s
            best = a
    if best is None:
        return [0, 1, 3, 7]
    return [int(x) for x in np.unique(best)]
