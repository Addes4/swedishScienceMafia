import math


def _count(d, n):
    sums = math.comb(2 * n + d, d)
    tot = 0
    for a in range(0, d + 1):
        ca = math.comb(n, a)
        if ca == 0:
            continue
        for b in range(0, d - a + 1):
            cb = math.comb(n, b)
            if cb == 0:
                continue
            tot += math.factorial(d) // (math.factorial(a) * math.factorial(b) * math.factorial(d - a - b)) * ca * cb
    return tot, sums


def _gen(d, n):
    base = 2 * n + 1
    res = []

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        p = base ** i
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * p)

    rec(0, n, 0)
    return res


def solve():
    best = None
    best_s = -1
    for d in range(1, 60):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            base = 2 * n + 1
            if n * base ** d >= 10 ** 15:
                break
            diffs, sums = _count(d, n)
            s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if s > best_s:
                best_s = s
                best = (d, n)
    d, n = best
    return sorted(_gen(d, n))
