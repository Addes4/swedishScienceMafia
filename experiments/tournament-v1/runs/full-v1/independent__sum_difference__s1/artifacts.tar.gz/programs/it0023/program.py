import math
import time
import numpy as np
from math import comb


def _gen(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def _score_arr(a):
    a = np.unique(np.array(a, dtype=np.int64))
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 16):
        for n in range(1, 200):
            s = comb(n + d, d)
            if s > 4000:
                break
            if s < 10:
                continue
            B = 2 * n + 1
            if (B ** d) * n * 2 > 5e14:
                continue
            cands.append((s, d, n))
    cands.sort(reverse=True)
    best = None
    best_sc = -1
    for s, d, n in cands:
        if time.time() - t0 > 90:
            break
        B = 2 * n + 1
        pts = _gen(d, n)
        arr = [sum(v * (B ** i) for i, v in enumerate(p)) for p in pts]
        sc = _score_arr(arr)
        if sc > best_sc:
            best_sc = sc
            best = arr
    if best is None:
        return [0, 1, 3]
    return sorted(set(int(x) for x in best))
