import math
from math import comb, factorial


def _sizes(d, n):
    sums = comb(2 * n + d, d)
    diffs = 0
    for p in range(0, min(n, d) + 1):
        for q in range(0, min(n, d - p) + 1):
            mult = factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))
            diffs += mult * comb(n, p) * comb(n, q)
    return diffs, sums


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return res


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d > 1e15:
                break
            df, sm = _sizes(d, n)
            s = math.log(df) / math.log(sm) + (1 - 1 / size) / 100
            if s > bs:
                bs = s
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
