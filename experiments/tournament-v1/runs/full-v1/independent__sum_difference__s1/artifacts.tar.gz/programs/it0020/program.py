import math
from itertools import product


def _counts(d, n):
    size = math.comb(n + d, d)
    s = math.comb(2 * n + d, d)
    diff = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            diff += (math.factorial(d) // (math.factorial(i) * math.factorial(j)
                     * math.factorial(d - i - j))) * math.comb(n, i) * math.comb(n, j)
    return size, s, diff


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 300):
            if (2 * n + 1) ** d > 10 ** 15:
                break
            size = math.comb(n + d, d)
            if size > 4000:
                break
            size, s, diff = _counts(d, n)
            if s < 2:
                continue
            sc = math.log(diff) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    base = 2 * n + 1
    res = []

    def rec(pos, remaining, val):
        if pos == d:
            res.append(val)
            return
        w = base ** pos
        for x in range(remaining + 1):
            rec(pos + 1, remaining - x, val + x * w)

    rec(0, n, 0)
    return sorted(res)
