import math


def _best_params():
    best = None
    for d in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 5e14:
                break
            s = math.comb(2 * n + d, d)
            df = 0
            for j in range(0, min(d, n) + 1):
                for k in range(0, min(d - j, n) + 1):
                    df += (math.factorial(d) // (math.factorial(j) * math.factorial(k)
                           * math.factorial(d - j - k))) * math.comb(n, j) * math.comb(n, k)
            if s < 2:
                continue
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if best is None or sc > best[0]:
                best = (sc, d, n)
    return best


def _gen(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    sc, d, n = _best_params()
    base = 2 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for c in p:
            v = v * base + c
        out.append(v)
    return sorted(set(out))
