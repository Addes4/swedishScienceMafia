import math


def _eval(d, n):
    a = math.comb(n + d, d)
    s = math.comb(2 * n + d, d)
    df = 0
    for k in range(0, min(d, n) + 1):
        for l in range(0, min(d - k, n) + 1):
            df += math.comb(d, k) * math.comb(d - k, l) * math.comb(n, k) * math.comb(n, l)
    return a, math.log(df) / math.log(s) + (1 - 1 / a) / 100


def _gen(d, n):
    res = []
    base = 2 * n + 1

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        p = base ** i
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * p)

    rec(0, n, 0)
    return res


def solve():
    best = None
    bs = -1
    for d in range(1, 60):
        for n in range(1, 60):
            if math.comb(n + d, d) > 4000:
                break
            if (2 * n + 1) ** d > 4e14:
                break
            a, sc = _eval(d, n)
            if a >= 2 and sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    return sorted(_gen(d, n))
