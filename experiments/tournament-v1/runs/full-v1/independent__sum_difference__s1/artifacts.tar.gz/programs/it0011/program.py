import math
from math import comb, factorial


def _counts(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for p in range(0, min(d, n) + 1):
        for q in range(0, min(d - p, n) + 1):
            multi = factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))
            diffs += multi * comb(n, p) * comb(n, q)
    return size, sums, diffs


def _gen(d, n):
    pts = []

    def rec(i, rem, cur):
        if i == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def solve():
    best = None
    best_sc = -1
    for n in range(1, 60):
        B = 2 * n + 1
        for d in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            mx = n * (B ** d - 1) // (B - 1)
            if mx > 10 ** 15 // 2:
                break
            if size < 2:
                continue
            s, su, di = _counts(d, n)
            sc = math.log(di) / math.log(su) + (1 - 1 / s) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    res = []
    for p in pts:
        v = 0
        for i, x in enumerate(p):
            v += x * B ** i
        res.append(v)
    return sorted(set(res))
