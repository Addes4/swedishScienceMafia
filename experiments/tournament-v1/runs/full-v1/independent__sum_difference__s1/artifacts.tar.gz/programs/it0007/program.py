import math
from math import comb


def _counts(d, n):
    s = comb(2 * n + d, d)
    t = 0
    for p in range(0, d + 1):
        cp = comb(n, p)
        if cp == 0:
            continue
        for q in range(0, d - p + 1):
            t += comb(d, p) * comb(d - p, q) * cp * comb(n, q)
    return s, t


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(i, rem, val, mult):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * mult, mult * B)

    rec(0, n, 0, 1)
    return res


def solve():
    best = None
    bs = -1.0
    for d in range(1, 40):
        for n in range(1, 4000):
            size = comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 10 ** 15:
                break
            if size < 2:
                continue
            s, t = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
