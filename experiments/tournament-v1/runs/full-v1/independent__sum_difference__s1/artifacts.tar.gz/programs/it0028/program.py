import math
from math import comb


def _counts(d, n):
    s = comb(2 * n + d, d)
    df = 0
    for a in range(0, d + 1):
        ca = comb(d, a) * comb(n, a)
        if ca == 0:
            continue
        for b in range(0, d - a + 1):
            df += ca * comb(d - a, b) * comb(n, b)
    return df, s


def _gen(d, n):
    pts = []

    def rec(i, rem, cur):
        if i == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            B = 2 * n + 2
            if B ** d > 10 ** 15:
                continue
            df, s = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    B = 2 * n + 2
    pts = _gen(d, n)
    res = []
    for p in pts:
        v = 0
        for x in reversed(p):
            v = v * B + x
        res.append(v)
    return sorted(set(res))
