import math


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for k in range(d + 1):
        ck = math.comb(n, k)
        if ck == 0:
            continue
        for l in range(d - k + 1):
            cl = math.comb(n, l)
            if cl == 0:
                continue
            m = math.factorial(d) // (math.factorial(k) * math.factorial(l) * math.factorial(d - k - l))
            diffs += m * ck * cl
    return size, sums, diffs


def _gen(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    for d in range(1, 30):
        n = 1
        while True:
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d < 5e14 and size >= 2:
                s, su, di = _counts(d, n)
                sc = math.log(di) / math.log(su) + (1 - 1 / s) / 100
                if best is None or sc > best[0]:
                    best = (sc, d, n)
            n += 1
    if best is None:
        return [0, 1, 3]
    _, d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for c in reversed(p):
            v = v * B + c
        out.append(v)
    return sorted(set(out))
