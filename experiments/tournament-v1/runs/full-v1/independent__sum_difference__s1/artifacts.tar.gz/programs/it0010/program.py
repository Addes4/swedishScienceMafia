import math
import time
import numpy as np
from math import comb


def _gen(d, rem, B):
    if d == 0:
        return [0]
    res = []
    sub_cache = {}
    for x in range(rem + 1):
        r = rem - x
        if r not in sub_cache:
            sub_cache[r] = _gen(d - 1, r, B)
        base = x * B ** (d - 1)
        res.extend(base + v for v in sub_cache[r])
    return res


def _score(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    iu = np.triu_indices(n)
    sums = np.unique((a[iu[0]] + a[iu[1]]))
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 16):
        for n in range(1, 40):
            s = comb(n + d, d)
            if s > 4000:
                break
            if s < 30:
                continue
            B = 2 * n + 1
            if B ** d * n > 5e14:
                continue
            cands.append((s, d, n))
    cands.sort(reverse=True)
    best = None
    best_score = -1
    for s, d, n in cands:
        if time.time() - t0 > 90:
            break
        B = 2 * n + 1
        a = _gen(d, n, B)
        try:
            sc = _score(a)
        except Exception:
            continue
        if sc > best_score:
            best_score = sc
            best = a
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(int(x) for x in best))
