import math
from math import comb, factorial


def _counts(d, n):
    s = comb(2 * n + d, d)
    diff = 0
    for i in range(0, d + 1):
        for j in range(0, d - i + 1):
            if i > n or j > n:
                continue
            diff += (factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))) * comb(n, i) * comb(n, j)
    return s, diff


def _gen(d, n):
    res = []

    def rec(pos, remaining, cur):
        if pos == d:
            res.append(tuple(cur))
            return
        for v in range(remaining + 1):
            cur.append(v)
            rec(pos + 1, remaining - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    best_sc = -1
    for d in range(1, 30):
        for n in range(1, 80):
            size = comb(n + d, d)
            if size > 4000:
                break
            base = 2 * n + 1
            if base ** d > 10 ** 15:
                break
            s, df = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    base = 2 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for x in reversed(p):
            v = v * base + x
        out.append(v)
    return sorted(set(out))
