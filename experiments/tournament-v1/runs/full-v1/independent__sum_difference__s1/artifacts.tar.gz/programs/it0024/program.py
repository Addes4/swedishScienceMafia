import math
import time
import numpy as np


def _simplex(d, n):
    B = 2 * n + 1
    vals = np.zeros(1, dtype=np.int64)
    sums = np.zeros(1, dtype=np.int64)
    for k in range(d):
        nv = []
        ns = []
        w = B ** k
        for x in range(n + 1):
            m = sums + x <= n
            if not m.any():
                break
            nv.append(vals[m] + x * w)
            ns.append(sums[m] + x)
        vals = np.concatenate(nv)
        sums = np.concatenate(ns)
    return vals


def _count(a):
    a = np.asarray(a, dtype=np.int64)
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sm = np.unique((a[:, None] + a[None, :]).ravel())
    return len(diffs), len(sm)


def _score(a):
    D, S = _count(a)
    return math.log(D) / math.log(S) + (1 - 1 / len(a)) / 100


def solve():
    t0 = time.time()
    best = None
    best_score = -1
    cands = []
    for d in range(2, 14):
        # find max n with C(n+d,d) <= 4000
        n = 1
        while math.comb(n + 1 + d, d) <= 4000:
            n += 1
        if math.comb(n + d, d) > 4000:
            continue
        if (2 * n + 1) ** d > 5e14:
            # reduce n until fits
            while n > 1 and (2 * n + 1) ** d > 5e14:
                n -= 1
        for nn in (n, n - 1):
            if nn >= 1 and (2 * nn + 1) ** d <= 5e14:
                cands.append((d, nn))
    # try larger-size first
    cands.sort(key=lambda c: -math.comb(c[0] + c[1], c[0]))
    for d, n in cands:
        if time.time() - t0 > 90:
            break
        if math.comb(n + d, d) > 4000:
            continue
        a = _simplex(d, n)
        if len(a) > 4000:
            continue
        try:
            s = _score(a)
        except MemoryError:
            continue
        if s > best_score:
            best_score = s
            best = a
    if best is None:
        return [0, 1, 3, 7]
    a = best - int(best.min())
    return [int(x) for x in sorted(set(a.tolist()))]
