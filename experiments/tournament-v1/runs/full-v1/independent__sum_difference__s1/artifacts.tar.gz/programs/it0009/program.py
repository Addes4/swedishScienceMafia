import math
from itertools import combinations_with_replacement


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for p in range(0, d + 1):
        for q in range(0, d - p + 1):
            if p > n or q > n:
                continue
            multi = math.factorial(d) // (math.factorial(p) * math.factorial(q) * math.factorial(d - p - q))
            diffs += multi * math.comb(n, p) * math.comb(n, q)
    return size, sums, diffs


def _gen(d, n):
    base = 2 * n + 1
    res = []

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return res


def solve():
    best = None
    best_score = -1
    for d in range(1, 40):
        n = 1
        while True:
            if math.comb(n + d, d) > 4000:
                break
            if (2 * n + 1) ** d * 2 <= 10 ** 15:
                size, sums, diffs = _counts(d, n)
                if size >= 2:
                    sc = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
                    if sc > best_score:
                        best_score = sc
                        best = (d, n)
            n += 1
    d, n = best
    return sorted(set(_gen(d, n)))
