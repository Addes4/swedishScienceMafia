import math


def _counts(d, n):
    s = math.comb(2 * n + d, d)
    t = 0
    for i in range(0, min(d, n) + 1):
        ci = math.comb(n, i)
        for j in range(0, min(d - i, n) + 1):
            t += math.factorial(d) // (math.factorial(i) * math.factorial(j) * math.factorial(d - i - j)) * ci * math.comb(n, j)
    return t, s


def solve():
    best = None
    best_sc = -1
    for d in range(1, 60):
        for n in range(1, 4000):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            b = 2 * n + 1
            if n * b ** (d - 1) * d > 1e15 and (n * (b ** d)) > 1e15:
                continue
            if (b ** d) > 1e15:
                continue
            t, s = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    b = 2 * n + 1
    pts = [(0, 0)]
    for i in range(d):
        w = b ** i
        new = []
        for s_, v in pts:
            for x in range(0, n - s_ + 1):
                new.append((s_ + x, v + x * w))
        pts = new
    return sorted(v for _, v in pts)
