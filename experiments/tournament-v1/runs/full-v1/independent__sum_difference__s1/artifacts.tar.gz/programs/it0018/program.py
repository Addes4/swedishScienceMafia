from math import comb, factorial, log


def _counts(d, n):
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(d + 1):
        for j in range(d - i + 1):
            diffs += (factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))) \
                * comb(n, i) * comb(n, j)
    return diffs, sums


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d > 10 ** 15 // 2:
                break
            df, sm = _counts(d, n)
            if sm < 2:
                continue
            sc = log(df) / log(sm) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    pts = []

    def rec(pos, rem, val):
        if pos == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return sorted(set(pts))
