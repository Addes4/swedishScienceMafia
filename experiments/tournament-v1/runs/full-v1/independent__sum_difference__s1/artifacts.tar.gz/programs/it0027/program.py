import math
from itertools import combinations_with_replacement


def _comb(a, b):
    return math.comb(a, b) if 0 <= b <= a else 0


def _counts(d, n):
    size = _comb(n + d, d)
    sums = _comb(2 * n + d, d)
    diffs = 0
    for i in range(0, d + 1):
        for j in range(0, d - i + 1):
            if i > n or j > n:
                continue
            diffs += _comb(d, i) * _comb(d - i, j) * _comb(n, i) * _comb(n, j)
    return size, sums, diffs


def _gen(d, n):
    # all vectors in N^d with sum <= n
    res = []

    def rec(pos, remaining, cur):
        if pos == d:
            res.append(tuple(cur))
            return
        for v in range(remaining + 1):
            cur.append(v)
            rec(pos + 1, remaining - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    best_sc = -1
    for d in range(1, 20):
        for n in range(1, 60):
            size = _comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            if (2 * n + 1) ** d > 10 ** 15 // 2:
                continue
            s, su, di = _counts(d, n)
            sc = math.log(di) / math.log(su) + (1 - 1 / s) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    base = 2 * n + 1
    out = []
    for v in _gen(d, n):
        x = 0
        for c in v:
            x = x * base + c
        out.append(x)
    return sorted(set(out))
