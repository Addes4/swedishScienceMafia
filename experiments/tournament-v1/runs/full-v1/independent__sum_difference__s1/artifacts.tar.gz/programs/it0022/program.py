import math
from itertools import product


def _sizes(d, n):
    A = math.comb(n + d, d)
    S = math.comb(2 * n + d, d)
    D = 0
    for j in range(0, min(d, n) + 1):
        for k in range(0, min(d - j, n) + 1):
            D += (math.factorial(d) // (math.factorial(j) * math.factorial(k) * math.factorial(d - j - k))) \
                 * math.comb(n, j) * math.comb(n, k)
    return A, S, D


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return res


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 80):
            if math.comb(n + d, d) > 4000:
                break
            if (2 * n + 1) ** d > 10 ** 15 // 2:
                break
            A, S, D = _sizes(d, n)
            if A < 2:
                continue
            sc = math.log(D) / math.log(S) + (1 - 1 / A) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
