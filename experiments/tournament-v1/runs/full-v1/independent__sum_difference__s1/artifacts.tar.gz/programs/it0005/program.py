import math
from itertools import combinations_with_replacement


def _counts(d, n):
    s = math.comb(2 * n + d, d)
    diff = 0
    for k in range(0, min(d, n) + 1):
        for l in range(0, min(d - k, n) + 1):
            diff += math.comb(d, k) * math.comb(d - k, l) * math.comb(n, k) * math.comb(n, l)
    return s, diff


def _gen(d, n):
    # enumerate all nonnegative integer vectors of length d with sum <= n
    res = []
    B = 2 * n + 1
    pw = [B ** i for i in range(d)]

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * pw[i])

    rec(0, n, 0)
    return res


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 10 ** 14:
                break
            if size < 2:
                continue
            s, df = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    return _gen(d, n)
