import math


def _counts(d, n):
    s = math.comb(2 * n + d, d)
    diff = 0
    for p in range(0, min(d, n) + 1):
        for q in range(0, min(d - p, n) + 1):
            diff += (math.factorial(d) // (math.factorial(p) * math.factorial(q) * math.factorial(d - p - q))
                     * math.comb(n, p) * math.comb(n, q))
    return s, diff


def solve():
    best = None
    best_sc = -1
    for n in range(1, 40):
        for d in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * B ** (d - 1) > 10 ** 15:
                break
            s, df = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    if best is None:
        return [0, 1, 3]
    d, n = best
    B = 2 * n + 1
    pts = [(0, [])]
    res = []

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        mult = B ** i
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * mult)

    rec(0, n, 0)
    return sorted(set(res))
