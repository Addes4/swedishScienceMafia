import math
from itertools import product


def _best_params():
    best = None
    for n in range(1, 40):
        B = 2 * n + 1
        for d in range(2, 80):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if n * B ** (d - 1) > 10 ** 15:
                break
            sums = math.comb(2 * n + d, d)
            diffs = 0
            for j in range(0, min(d, n) + 1):
                for k in range(0, min(d - j, n) + 1):
                    diffs += (math.factorial(d) // (math.factorial(j) * math.factorial(k)
                              * math.factorial(d - j - k))) * math.comb(n, j) * math.comb(n, k)
            sc = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if best is None or sc > best[0]:
                best = (sc, n, d)
    return best


def _gen(n, d):
    B = 2 * n + 1
    res = []

    def rec(pos, rem, val):
        if pos == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return res


def solve():
    sc, n, d = _best_params()
    return sorted(set(_gen(n, d)))
