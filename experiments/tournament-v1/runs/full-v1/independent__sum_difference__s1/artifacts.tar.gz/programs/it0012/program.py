import math
import time
import numpy as np


def _gen(d, n):
    pts = []

    def rec(i, rem, cur):
        if i == d:
            pts.append(cur)
            return
        for v in range(rem + 1):
            rec(i + 1, rem - v, cur + [v])
    rec(0, n, [])
    return pts


def _count(a):
    a = np.array(sorted(a), dtype=np.int64)
    s = len(np.unique((a[:, None] + a[None, :]).ravel()))
    df = (a[:, None] - a[None, :]).ravel()
    df = df[df > 0]
    dd = 2 * len(np.unique(df)) + 1
    return dd, s


def _score(a):
    dd, s = _count(a)
    return math.log(dd) / math.log(s) + (1 - 1 / len(a)) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 90):
        for n in range(1, 40):
            size = math.comb(n + d, d)
            if size > 4000 or size < 3:
                continue
            base = 2 * n + 1
            if n * base ** (d - 1) * 2 > 9e14 and base ** d > 9e14:
                continue
            if (base ** d) > 9e14:
                continue
            cands.append((size, d, n))
    cands.sort()
    best = None
    best_score = -1
    for size, d, n in cands:
        if time.time() - t0 > 85:
            break
        base = 2 * n + 1
        pts = _gen(d, n)
        arr = []
        for p in pts:
            v = 0
            for c in p:
                v = v * base + c
            arr.append(v)
        try:
            sc = _score(arr)
        except MemoryError:
            continue
        if sc > best_score:
            best_score = sc
            best = arr
    if best is None:
        best = [0, 1, 3]
    return sorted(set(int(x) for x in best))
