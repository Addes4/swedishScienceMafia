import math
from math import comb, factorial
from itertools import combinations_with_replacement


def _counts(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for j in range(0, d + 1):
        cj = comb(n, j)
        if cj == 0:
            continue
        for l in range(0, d - j + 1):
            cl = comb(n, l)
            if cl == 0:
                continue
            m = factorial(d) // (factorial(j) * factorial(l) * factorial(d - j - l))
            diffs += m * cj * cl
    return size, sums, diffs


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(i, rem, val, mult):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * mult, mult * B)

    rec(0, n, 0, 1)
    return res


def solve():
    best = None
    best_sc = -1
    for d in range(1, 40):
        for n in range(1, 80):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * B ** (d - 1) * 2 > 10 ** 15 or B ** d > 10 ** 15:
                break
            if size < 2:
                continue
            s, su, di = _counts(d, n)
            sc = math.log(di) / math.log(su) + (1 - 1 / s) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
