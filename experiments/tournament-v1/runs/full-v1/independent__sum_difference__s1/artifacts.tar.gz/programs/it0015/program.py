import math
from itertools import product


def _counts(d, n):
    s = math.comb(2 * n + d, d)
    df = 0
    for p in range(d + 1):
        for q in range(d - p + 1):
            df += math.comb(d, p) * math.comb(d - p, q) * math.comb(n, p) * math.comb(n, q)
    return df, s


def _gen(d, n):
    pts = []
    B = 2 * n + 1

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return pts


def solve():
    best = None
    best_sc = -1
    for d in range(1, 16):
        n = 1
        while math.comb(n + d, d) <= 4000:
            size = math.comb(n + d, d)
            if size >= 2 and (2 * n + 1) ** d < 10 ** 14:
                df, s = _counts(d, n)
                sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
                if sc > best_sc:
                    best_sc = sc
                    best = (d, n)
            n += 1
    d, n = best
    return sorted(_gen(d, n))
