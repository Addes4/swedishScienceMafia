import math


def _gen(d, n):
    res = []

    def rec(pos, rem, cur):
        if pos == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(pos + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def _diff_count(d, n):
    tot = 0
    for j in range(0, min(d, n) + 1):
        for k in range(0, min(d - j, n) + 1):
            m = math.factorial(d) // (math.factorial(j) * math.factorial(k) * math.factorial(d - j - k))
            tot += m * math.comb(n, j) * math.comb(n, k)
    return tot


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d * n > 5e14:
                break
            if size < 2:
                continue
            sums = math.comb(2 * n + d, d)
            diffs = _diff_count(d, n)
            s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if s > bs:
                bs = s
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for c in p:
            v = v * B + c
        out.append(v)
    return sorted(set(out))
