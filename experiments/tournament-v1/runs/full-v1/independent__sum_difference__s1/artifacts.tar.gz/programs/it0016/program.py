import math
import time
import numpy as np


def _points(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def _encode(d, n):
    B = 2 * n + 1
    pts = _points(d, n)
    return [sum(c * B ** i for i, c in enumerate(p)) for p in pts]


def _score_np(a):
    arr = np.array(a, dtype=np.int64)
    s = np.unique((arr[:, None] + arr[None, :]).ravel()).size
    df = np.unique((arr[:, None] - arr[None, :]).ravel()).size
    return math.log(df) / math.log(s) + (1 - 1 / len(a)) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 200:
                continue
            B = 2 * n + 1
            if n * B ** (d - 1) * 2 > 1e15 or B ** d > 1e15:
                continue
            cands.append((d, n, size))
    best, best_sc = None, -1
    # evaluate larger sets last-ish; order by size ascending to ensure some result
    cands.sort(key=lambda t: t[2])
    for d, n, size in cands:
        if time.time() - t0 > 85:
            break
        a = _encode(d, n)
        if max(abs(x) for x in a) > 1e15:
            continue
        sc = _score_np(a)
        if sc > best_sc:
            best_sc, best = sc, a
    if best is None:
        best = _encode(3, 5)
    return sorted(set(int(x) for x in best))
