# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    from math import comb, factorial

    def counts(d, n):
        size = comb(n + d, d)
        sums = comb(2 * n + d, d)
        diffs = 0
        for p in range(0, min(d, n) + 1):
            for q in range(0, min(d - p, n) + 1):
                m = factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))
                diffs += m * comb(n, p) * comb(n, q)
        return size, sums, diffs

    best_s, best_dn = -1.0, (2, 2)
    for d in range(1, 40):
        for n in range(1, 40):
            if comb(n + d, d) > 4000:
                break
            if (4 * n + 1) ** d > 10 ** 15 // 2:
                continue
            size, sums, diffs = counts(d, n)
            if size < 2:
                continue
            s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if s > best_s:
                best_s, best_dn = s, (d, n)
    d, n = best_dn
    base = 4 * n + 1
    pts = []

    def gen(i, remaining, val, mult):
        if i == d:
            pts.append(val)
            return
        for x in range(remaining + 1):
            gen(i + 1, remaining - x, val + x * mult, mult * base)

    gen(0, n, 0, 1)
    return sorted(set(pts))
# EVOLVE-BLOCK-END