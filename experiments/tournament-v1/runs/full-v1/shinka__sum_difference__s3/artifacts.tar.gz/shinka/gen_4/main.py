# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    comb = math.comb
    best_val, best_dn = -1.0, None
    for d in range(2, 14):
        for n in range(1, 400):
            size = comb(n + d, d)
            if size > 4000:
                break
            sums = comb(2 * n + d, d)
            diffs = 0
            for k in range(0, d + 1):
                inner = 0
                for p in range(0, k + 1):
                    inner += comb(k, p) * comb(n, p) * comb(n, k - p)
                diffs += comb(d, k) * inner
            val = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if val > best_val:
                best_val, best_dn = val, (d, n)
    d, n = best_dn
    base = 2 * n + 1
    pts = []

    def rec(pos, rem, val):
        if pos == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return sorted(set(pts))
# EVOLVE-BLOCK-END