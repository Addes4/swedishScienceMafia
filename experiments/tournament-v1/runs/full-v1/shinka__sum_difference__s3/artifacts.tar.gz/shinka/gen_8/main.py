# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    import numpy as np

    def window(arr, axis, lo, hi):
        # res[P] = sum_{k=lo..hi} arr[P-k] along axis
        c = np.cumsum(arr, axis=axis)
        N = arr.shape[axis]
        res = np.zeros_like(arr)
        sl = [slice(None)] * arr.ndim
        sl2 = [slice(None)] * arr.ndim
        # + c[P-lo] for P>=lo
        if lo < N:
            sl[axis] = slice(lo, N)
            sl2[axis] = slice(0, N - lo)
            res[tuple(sl)] += c[tuple(sl2)]
        # - c[P-hi-1] for P>=hi+1
        if hi + 1 < N:
            sl[axis] = slice(hi + 1, N)
            sl2[axis] = slice(0, N - hi - 1)
            res[tuple(sl)] -= c[tuple(sl2)]
        return res

    def size_count(d, n, m):
        a = np.zeros(n + 1)
        a[0] = 1.0
        for _ in range(d):
            a = window(a, 0, 0, m)
        return a.sum()

    def sums_count(d, n, m):
        a = np.zeros(2 * n + 1)
        a[0] = 1.0
        for _ in range(d):
            a = window(a, 0, 0, 2 * m)
        return a.sum()

    def diffs_count(d, n, m):
        a = np.zeros((n + 1, n + 1))
        a[0, 0] = 1.0
        for _ in range(d):
            a = a + window(a, 0, 1, m) + window(a, 1, 1, m)
        return a.sum()

    best_val, best = -1.0, None
    for d in range(2, 40):
        for n in range(1, 61):
            for m in range(1, n + 1):
                base = 2 * m + 1
                if base ** d > 10 ** 15:
                    break
                size = size_count(d, n, m)
                if size > 4000:
                    break
                if size < 3:
                    continue
                s = sums_count(d, n, m)
                df = diffs_count(d, n, m)
                val = math.log(df) / math.log(s) + (1 - 1 / size) / 100
                if val > best_val:
                    best_val, best = val, (d, n, m)
    d, n, m = best
    base = 2 * m + 1
    pts = []

    def rec(pos, rem, val):
        if pos == d:
            pts.append(val)
            return
        for x in range(min(rem, m) + 1):
            rec(pos + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return sorted(set(pts))
# EVOLVE-BLOCK-END