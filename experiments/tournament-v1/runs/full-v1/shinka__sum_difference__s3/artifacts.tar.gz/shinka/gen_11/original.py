# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    import numpy as np

    def one_d(d, cap, tot):
        a = np.zeros(tot + 1, dtype=np.float64)
        a[0] = 1.0
        for _ in range(d):
            b = a.copy()
            for k in range(1, min(cap, tot) + 1):
                b[k:] += a[:-k]
            a = b
        return a.sum()

    def diff_count(d, n, m):
        a = np.zeros((n + 1, n + 1), dtype=np.float64)
        a[0, 0] = 1.0
        for _ in range(d):
            b = a.copy()
            for k in range(1, min(m, n) + 1):
                b[k:, :] += a[:n + 1 - k, :]
                b[:, k:] += a[:, :n + 1 - k]
            a = b
        return a.sum()

    def build(d, n, m):
        B = 2 * m + 1
        s = np.zeros(1, dtype=np.int64)
        c = np.zeros(1, dtype=np.int64)
        for i in range(d):
            ns, nc = [], []
            w = B ** i
            for x in range(0, m + 1):
                mask = s + x <= n
                if not mask.any():
                    break
                ns.append(s[mask] + x)
                nc.append(c[mask] + x * w)
            s = np.concatenate(ns)
            c = np.concatenate(nc)
        return np.unique(c)

    def real_score(A):
        A = np.unique(A)
        N = len(A)
        S = np.zeros(0, dtype=np.int64)
        D = np.zeros(0, dtype=np.int64)
        step = max(1, 1500000 // N)
        for i in range(0, N, step):
            blk = A[i:i + step]
            S = np.union1d(S, np.unique((blk[:, None] + A[None, :]).ravel()))
            D = np.union1d(D, np.unique((blk[:, None] - A[None, :]).ravel()))
        return math.log(len(D)) / math.log(len(S)) + (1 - 1 / N) / 100

    t0 = time.time()
    cands = []
    for d in range(2, 40):
        for n in range(1, 40):
            if (2 * 1 + 1) ** d > 10 ** 15:
                break
            if one_d(d, 1, n) > 4000:
                break
            for m in range(1, n + 1):
                if (2 * m + 1) ** d > 10 ** 15:
                    break
                size = one_d(d, m, n)
                if size > 4000:
                    break
                if size < 30:
                    continue
                if time.time() - t0 > 40:
                    break
                sums = one_d(d, 2 * m, 2 * n)
                diffs = diff_count(d, n, m)
                est = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
                cands.append((est, d, n, m))
    cands.sort(reverse=True)
    best_val, best_set, best_par = -1.0, None, None
    for est, d, n, m in cands[:4]:
        if time.time() - t0 > 60:
            break
        try:
            A = build(d, n, m)
            v = real_score(A)
        except Exception:
            continue
        if v > best_val:
            best_val, best_set, best_par = v, A, (d, n, m)
    if best_set is not None:
        base_list = [int(x) for x in best_set]
        try:
            d, n, m = best_par
            B = 2 * m + 1
            N0 = len(base_list)
            if N0 <= 2000 and time.time() - t0 < 80:
                arr = np.array(base_list, dtype=np.int64)
                sk, sc = np.unique((arr[:, None] + arr[None, :]).ravel(), return_counts=True)
                dk, dc = np.unique((arr[:, None] - arr[None, :]).ravel(), return_counts=True)
                sums = dict(zip(sk.tolist(), sc.tolist()))
                diffs = dict(zip(dk.tolist(), dc.tolist()))
                del sk, sc, dk, dc
                Alist = list(base_list)
                Aset = set(Alist)
                ws = [B ** i for i in range(d)]

                def bump(dct, k, sg):
                    c = dct.get(k, 0) + sg
                    if c == 0:
                        del dct[k]
                    else:
                        dct[k] = c

                def upd(x, sg):
                    # Alist must not contain x
                    for a in Alist:
                        bump(sums, x + a, sg)
                        bump(sums, x + a, sg)
                        bump(diffs, x - a, sg)
                        bump(diffs, a - x, sg)
                    bump(sums, 2 * x, sg)
                    bump(diffs, 0, sg)

                def cur():
                    N = len(Alist)
                    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / N) / 100

                cur_v = cur()
                rnd = random.Random(12345)
                while time.time() - t0 < 105:
                    if rnd.random() < 0.75:
                        if len(Alist) >= 4000:
                            continue
                        p = Alist[rnd.randrange(len(Alist))]
                        i = rnd.randrange(d)
                        w = ws[i]
                        dig = (p // w) % B
                        if rnd.random() < 0.5:
                            if dig >= m:
                                continue
                            q = p + w
                        else:
                            if dig <= 0:
                                continue
                            q = p - w
                        if q in Aset:
                            continue
                        upd(q, 1)
                        Alist.append(q)
                        Aset.add(q)
                        nv = cur()
                        if nv > cur_v:
                            cur_v = nv
                        else:
                            Alist.pop()
                            Aset.discard(q)
                            upd(q, -1)
                    else:
                        if len(Alist) <= 10:
                            continue
                        idx = rnd.randrange(len(Alist))
                        q = Alist[idx]
                        Alist[idx] = Alist[-1]
                        Alist.pop()
                        Aset.discard(q)
                        upd(q, -1)
                        nv = cur()
                        if nv > cur_v:
                            cur_v = nv
                        else:
                            upd(q, 1)
                            Alist.append(q)
                            Aset.add(q)
                if cur_v > best_val:
                    return sorted(int(x) for x in Alist)
        except Exception:
            pass
        return base_list
    from math import comb, factorial

    def counts(d, n):
        size = comb(n + d, d)
        sums = comb(2 * n + d, d)
        diffs = 0
        for p in range(0, min(d, n) + 1):
            for q in range(0, min(d - p, n) + 1):
                m = factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))
                diffs += m * comb(n, p) * comb(n, q)
        return size, sums, diffs

    best_s, best_dn = -1.0, (2, 2)
    for d in range(1, 40):
        for n in range(1, 40):
            if comb(n + d, d) > 4000:
                break
            if (4 * n + 1) ** d > 10 ** 15 // 2:
                continue
            size, sums, diffs = counts(d, n)
            if size < 2:
                continue
            s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if s > best_s:
                best_s, best_dn = s, (d, n)
    d, n = best_dn
    base = 4 * n + 1
    pts = []

    def gen(i, remaining, val, mult):
        if i == d:
            pts.append(val)
            return
        for x in range(remaining + 1):
            gen(i + 1, remaining - x, val + x * mult, mult * base)

    gen(0, n, 0, 1)
    return sorted(set(pts))
# EVOLVE-BLOCK-END