# EVOLVE-BLOCK-START
"""Staged pipeline: plan simplex params -> build indexed universe -> annealing over dense count tables -> verify."""
import math
import random
import time

import numpy as np


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


# ---------------------------------------------------------------- planner
def _plan():
    comb = math.comb
    best_val, best = -1.0, None
    for d in range(1, 60):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d > 10 ** 15:
                break
            nd = 0
            for j in range(0, min(d, n) + 1):
                for k in range(0, min(d - j, n) + 1):
                    nd += comb(d, j) * comb(d - j, k) * comb(n, j) * comb(n, k)
            ns = comb(2 * n + d, d)
            if ns < 2 or nd < 2:
                continue
            val = math.log(nd) / math.log(ns) + (1 - 1 / size) / 100
            if val > best_val:
                best_val, best = val, (d, n)
    return best


# ---------------------------------------------------------------- universe
def _build_universe(d, nu):
    B = 2 * nu + 1
    V = np.zeros((1, 0), dtype=np.int64)
    for _ in range(d):
        s = V.sum(axis=1)
        parts = []
        for x in range(nu + 1):
            sel = s + x <= nu
            if not sel.any():
                break
            sub = V[sel]
            parts.append(np.hstack([sub, np.full((sub.shape[0], 1), x, dtype=np.int64)]))
        V = np.vstack(parts)
    w = np.array([B ** i for i in range(d)], dtype=np.int64)
    enc = V @ w
    return V, enc


def _all_keys(enc, op):
    U = len(enc)
    step = max(1, 2000000 // U)
    keys = np.zeros(0, dtype=np.int64)
    for i in range(0, U, step):
        blk = enc[i:i + step]
        k = np.unique(op(blk[:, None], enc[None, :]).ravel())
        keys = np.union1d(keys, k)
    return keys


def _full_counts(keys, encA, op):
    cnt = np.zeros(len(keys), dtype=np.int64)
    N = len(encA)
    step = max(1, 2000000 // max(N, 1))
    for i in range(0, N, step):
        blk = encA[i:i + step]
        idx = np.searchsorted(keys, op(blk[:, None], encA[None, :]).ravel())
        cnt += np.bincount(idx, minlength=len(keys))
    return cnt


# ---------------------------------------------------------------- verifier
def _real_score(A):
    A = np.unique(np.asarray(A, dtype=np.int64))
    N = len(A)
    S = np.zeros(0, dtype=np.int64)
    D = np.zeros(0, dtype=np.int64)
    step = max(1, 1500000 // N)
    for i in range(0, N, step):
        blk = A[i:i + step]
        S = np.union1d(S, np.unique((blk[:, None] + A[None, :]).ravel()))
        D = np.union1d(D, np.unique((blk[:, None] - A[None, :]).ravel()))
    return math.log(len(D)) / math.log(len(S)) + (1 - 1 / N) / 100


# ---------------------------------------------------------------- state
class _State:
    def __init__(self, enc, inA):
        self.enc = enc
        self.inA = inA
        self.skeys = _all_keys(enc, np.add)
        self.dkeys = _all_keys(enc, np.subtract)
        encA = enc[inA]
        self.sc = _full_counts(self.skeys, encA, np.add)
        self.dc = _full_counts(self.dkeys, encA, np.subtract)
        self.Sn = int(np.count_nonzero(self.sc))
        self.Dn = int(np.count_nonzero(self.dc))
        self.N = int(inA.sum())
        self.zero = np.array([np.searchsorted(self.dkeys, 0)], dtype=np.int64)

    def value(self, Sn=None, Dn=None, N=None):
        Sn = self.Sn if Sn is None else Sn
        Dn = self.Dn if Dn is None else Dn
        N = self.N if N is None else N
        if Sn < 2 or Dn < 2 or N < 2:
            return -1.0
        return math.log(Dn) / math.log(Sn) + (1 - 1 / N) / 100

    def _indices(self, u, others):
        e = int(self.enc[u])
        sk, dk = self.skeys, self.dkeys
        si = np.searchsorted(sk, others + e)
        s0 = np.searchsorted(sk, np.array([2 * e], dtype=np.int64))
        d1 = np.searchsorted(dk, e - others)
        d2 = np.searchsorted(dk, others - e)
        return si, s0, d1, d2

    def _change(self, sign, idxs):
        si, s0, d1, d2 = idxs
        dS = 0
        dD = 0
        sc, dc = self.sc, self.dc
        for idx, w in ((si, 2), (s0, 1)):
            if sign > 0:
                dS += int(np.count_nonzero(sc[idx] == 0))
                sc[idx] += w
            else:
                sc[idx] -= w
                dS -= int(np.count_nonzero(sc[idx] == 0))
        for idx in (d1, d2, self.zero):
            if sign > 0:
                dD += int(np.count_nonzero(dc[idx] == 0))
                dc[idx] += 1
            else:
                dc[idx] -= 1
                dD -= int(np.count_nonzero(dc[idx] == 0))
        return dS, dD

    def toggle_preview(self, u):
        """Apply toggle of universe point u; return (undo_info, new_value)."""
        inA = self.inA
        if inA[u]:
            inA[u] = False
            sign = -1
        else:
            sign = 1
        others = self.enc[inA]
        idxs = self._indices(u, others)
        dS, dD = self._change(sign, idxs)
        return (u, sign, idxs, dS, dD)

    def commit(self, info):
        u, sign, idxs, dS, dD = info
        self.Sn += dS
        self.Dn += dD
        self.N += sign
        if sign > 0:
            self.inA[u] = True

    def undo(self, info):
        u, sign, idxs, dS, dD = info
        self._change(-sign, idxs)
        if sign < 0:
            self.inA[u] = True
        else:
            self.inA[u] = False

    def preview_value(self, info):
        u, sign, idxs, dS, dD = info
        return self.value(self.Sn + dS, self.Dn + dD, self.N + sign)


# ---------------------------------------------------------------- annealer
def _anneal(state, deadline, max_size=4000):
    rnd = random.Random(2024)
    U = len(state.enc)
    cur = state.value()
    best = cur
    best_mask = state.inA.copy()
    t_start = time.time()
    span = max(1e-9, deadline - t_start)
    T0 = 2e-4
    it = 0
    T = T0
    while True:
        it += 1
        if (it & 15) == 0:
            now = time.time()
            if now >= deadline:
                break
            T = T0 * max(0.0, 1.0 - (now - t_start) / span)
        u = rnd.randrange(U)
        if (not state.inA[u]) and state.N >= max_size:
            continue
        if state.inA[u] and state.N <= 10:
            continue
        info = state.toggle_preview(u)
        nv = state.preview_value(info)
        if nv >= cur or (T > 1e-12 and rnd.random() < math.exp((nv - cur) / T)):
            state.commit(info)
            cur = nv
            if cur > best + 1e-12:
                best = cur
                best_mask = state.inA.copy()
        else:
            state.undo(info)
    return best, best_mask


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    t0 = time.time()
    plan = _plan()
    if plan is None:
        return [0, 1, 3]
    d, n = plan

    # base simplex (always valid fallback)
    V0, enc0 = _build_universe(d, n)
    base_list = sorted(int(x) for x in enc0)

    try:
        nu = n
        B1 = 2 * (n + 1) + 1
        if math.comb(n + 1 + d, d) <= 7000 and B1 ** d <= 10 ** 15:
            nu = n + 1
        if math.comb(nu + d, d) > 7000:
            return base_list
        V, enc = _build_universe(d, nu)
        inA = V.sum(axis=1) <= n
        state = _State(enc, inA)
        deadline = t0 + 85.0
        if time.time() > deadline - 5:
            return base_list
        best, mask = _anneal(state, deadline)
        cand = sorted(int(x) for x in enc[mask])
        if len(cand) > 4000 or len(cand) < 2:
            return base_list
        v_c = _real_score(cand)
        v_b = _real_score(base_list)
        if v_c > v_b:
            return cand
        return base_list
    except Exception:
        return base_list
# EVOLVE-BLOCK-END