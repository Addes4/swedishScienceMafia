# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    from math import comb, factorial

    def counts(d, n):
        size = comb(n + d, d)
        sums = comb(2 * n + d, d)
        diffs = 0
        for p in range(0, min(d, n) + 1):
            for q in range(0, min(d - p, n) + 1):
                m = factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))
                diffs += m * comb(n, p) * comb(n, q)
        return size, sums, diffs

    best_s, best_dn = -1.0, (2, 2)
    for d in range(1, 40):
        for n in range(1, 40):
            if comb(n + d, d) > 4000:
                break
            if (4 * n + 1) ** d > 10 ** 15 // 2:
                continue
            size, sums, diffs = counts(d, n)
            if size < 2:
                continue
            s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if s > best_s:
                best_s, best_dn = s, (d, n)
    d, n = best_dn
    base = 4 * n + 1
    pts = []

    def gen(i, remaining, val, mult):
        if i == d:
            pts.append(val)
            return
        for x in range(remaining + 1):
            gen(i + 1, remaining - x, val + x * mult, mult * base)

    gen(0, n, 0, 1)
    import numpy as np

    def true_score(arr):
        arr = np.unique(np.asarray(arr, dtype=np.int64))
        k = len(arr)
        if k < 2:
            return 0.0
        nd = len(np.unique((arr[:, None] - arr[None, :]).ravel()))
        ns = len(np.unique((arr[:, None] + arr[None, :]).ravel()))
        return math.log(nd) / math.log(ns) + (1 - 1 / k) / 100

    best_pts = sorted(set(pts))
    try:
        t_end = time.time() + 85
        best_val = true_score(best_pts)

        def gen_trunc(dd, nn, mm):
            B = 2 * nn + 1
            s = np.zeros(1, dtype=np.int64)
            c = np.zeros(1, dtype=np.int64)
            for i in range(dd):
                w = B ** i
                ss = []
                cc = []
                for x in range(0, min(mm, nn) + 1):
                    mask = s + x <= nn
                    if not mask.any():
                        break
                    ss.append(s[mask] + x)
                    cc.append(c[mask] + x * w)
                s = np.concatenate(ss)
                c = np.concatenate(cc)
                if len(s) > 4000:
                    return None
            return c

        cands = []
        for dd in range(2, 17):
            for nn in range(2, 31):
                if (2 * nn + 1) ** dd > 4 * 10 ** 14:
                    continue
                for mm in range(1, nn + 1):
                    cands.append((dd, nn, mm))
        random.shuffle(cands)
        for dd, nn, mm in cands:
            if time.time() > t_end:
                break
            c = gen_trunc(dd, nn, mm)
            if c is None or len(c) < 200:
                continue
            v = true_score(c)
            if v > best_val:
                best_val = v
                best_pts = sorted(set(int(x) for x in c))
    except Exception:
        pass
    return best_pts
# EVOLVE-BLOCK-END