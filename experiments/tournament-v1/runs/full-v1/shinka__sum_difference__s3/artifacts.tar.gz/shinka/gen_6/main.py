# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    comb = math.comb
    best_val, best_dn = -1.0, None
    for d in range(2, 14):
        for n in range(1, 400):
            size = comb(n + d, d)
            if size > 4000:
                break
            sums = comb(2 * n + d, d)
            diffs = 0
            for k in range(0, d + 1):
                inner = 0
                for p in range(0, k + 1):
                    inner += comb(k, p) * comb(n, p) * comb(n, k - p)
                diffs += comb(d, k) * inner
            val = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if val > best_val:
                best_val, best_dn = val, (d, n)
    import numpy as np

    t0 = time.time()
    d0, n0 = best_dn

    def gen(d, n, m):
        base = 2 * n + 1
        pts = []

        def rec(pos, rem, val):
            if pos == d:
                pts.append(val)
                return
            for x in range(min(rem, m) + 1):
                rec(pos + 1, rem - x, val * base + x)

        rec(0, n, 0)
        return sorted(set(pts))

    def ev(pts):
        arr = np.array(pts, dtype=np.int64)
        k = len(arr)
        if k < 2:
            return 0.0
        ds, ss = [], []
        step = 400
        for i in range(0, k, step):
            blk = arr[i:i + step]
            ds.append(np.unique((blk[:, None] - arr[None, :]).ravel()))
            ss.append(np.unique((blk[:, None] + arr[None, :]).ravel()))
        nd = len(np.unique(np.concatenate(ds)))
        ns = len(np.unique(np.concatenate(ss)))
        return math.log(nd) / math.log(ns) + (1 - 1 / k) / 100

    def count(d, n, m):
        dp = [1] + [0] * n
        for _ in range(d):
            new = [0] * (n + 1)
            pre = 0
            # new[s] = sum dp[s-m .. s]
            for s in range(n + 1):
                pre += dp[s]
                if s - m - 1 >= 0:
                    pre -= dp[s - m - 1]
                new[s] = pre
            dp = new
        return sum(dp)

    best_pts = gen(d0, n0, n0)
    try:
        best_sc = ev(best_pts)
    except Exception:
        return best_pts

    cands = []
    for d in range(2, 13):
        for n in range(2, 41):
            for m in range(1, n):
                sz = count(d, n, m)
                if 1200 <= sz <= 4000:
                    cands.append((d, n, m, sz))
    random.seed(1)
    random.shuffle(cands)
    cands.sort(key=lambda c: 0 if c[3] >= 2200 else 1)
    for d, n, m, sz in cands:
        if time.time() - t0 > 85:
            break
        try:
            pts = gen(d, n, m)
            sc = ev(pts)
        except Exception:
            continue
        if sc > best_sc:
            best_sc, best_pts = sc, pts
    return best_pts
# EVOLVE-BLOCK-END