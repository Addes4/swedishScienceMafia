# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    comb = math.comb
    best_val, best_dn = -1.0, None
    for d in range(1, 60):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d * n > 10 ** 15:
                break
            nd = 0
            for j in range(0, min(d, n) + 1):
                for k in range(0, min(d - j, n) + 1):
                    nd += comb(d, j) * comb(d - j, k) * comb(n, j) * comb(n, k)
            ns = comb(2 * n + d, d)
            if ns < 2:
                continue
            val = math.log(nd) / math.log(ns) + (1 - 1 / size) / 100
            if val > best_val:
                best_val, best_dn = val, (d, n)
    if best_dn is None:
        return [0, 1, 3]
    d, n = best_dn
    B = 2 * n + 1
    pts = [(0, 0)]  # (remaining-sum used, encoded value)
    # build all vectors of length d with sum <= n
    vecs = [(0, 0)]  # (sum, code)
    for i in range(d):
        w = B ** i
        new = []
        for s, c in vecs:
            for x in range(0, n - s + 1):
                new.append((s + x, c + x * w))
        vecs = new
    return sorted(set(c for _, c in vecs))
# EVOLVE-BLOCK-END