import math
import random
import time
import itertools
import numpy as np


def _counts(e):
    e = np.asarray(e, dtype=np.int64)
    s = np.unique((e[:, None] + e[None, :]).ravel()).size
    d = np.unique((e[:, None] - e[None, :]).ravel()).size
    return d, s


def _score_counts(D, S, k):
    if k < 2 or S < 2:
        return 0.0
    return math.log(D) / math.log(S) + (1 - 1 / k) / 100


def _score(a):
    a = sorted(set(a))
    if len(a) < 2:
        return 0.0
    D, S = _counts(np.array(a, dtype=np.int64))
    return _score_counts(D, S, len(a))


def _simplex_counts(d, n):
    size = math.comb(n + d, d)
    S = math.comb(2 * n + d, d)
    D = 0
    for k in range(0, min(d, n) + 1):
        for j in range(0, min(d - k, n) + 1):
            D += math.comb(d, k) * math.comb(d - k, j) * math.comb(n, k) * math.comb(n, j)
    return size, D, S


def _partitions(s, maxpart, maxlen):
    if s == 0:
        yield ()
        return
    if maxlen == 0:
        return
    for p in range(min(s, maxpart), 0, -1):
        for rest in _partitions(s - p, p, maxlen - 1):
            yield (p,) + rest


def _multiset_perms(vals):
    cnt = {}
    for v in vals:
        cnt[v] = cnt.get(v, 0) + 1
    keys = list(cnt.keys())
    L = len(vals)
    out = []
    cur = []

    def rec():
        if len(cur) == L:
            out.append(tuple(cur))
            return
        for kk in keys:
            if cnt[kk] > 0:
                cnt[kk] -= 1
                cur.append(kk)
                rec()
                cur.pop()
                cnt[kk] += 1
    rec()
    return out


def _orbit_search(d, n, extra, time_budget):
    t0 = time.time()
    smax = n + extra
    vmax = smax
    M = 2 * vmax + 1
    if M ** d > 1e15:
        return None
    pw = np.array([M ** i for i in range(d)], dtype=np.int64)
    classes = []
    for s in range(0, smax + 1):
        for p in _partitions(s, vmax, d):
            vals = list(p) + [0] * (d - len(p))
            perms = _multiset_perms(vals)
            if len(perms) > 4000:
                continue
            arr = np.array(perms, dtype=np.int64)
            classes.append((s, arr @ pw))
    nc = len(classes)
    incl = [classes[i][0] <= n for i in range(nc)]

    def ev(inc):
        parts = [classes[i][1] for i in range(nc) if inc[i]]
        if not parts:
            return 0.0, None
        e = np.concatenate(parts)
        if e.size > 4000 or e.size < 2:
            return 0.0, None
        D, S = _counts(e)
        return _score_counts(D, S, e.size), (D, S, e)

    best, info = ev(incl)
    if info is None:
        return None
    improved = True
    while improved and time.time() - t0 < time_budget:
        improved = False
        order = list(range(nc))
        random.shuffle(order)
        for i in order:
            if time.time() - t0 > time_budget:
                break
            incl[i] = not incl[i]
            sc, inf = ev(incl)
            if inf is not None and sc > best + 1e-12:
                best, info = sc, inf
                improved = True
            else:
                incl[i] = not incl[i]
    D, S, e = info
    return best, D, S, sorted(int(x) for x in e)


def _anneal_small(time_budget):
    t0 = time.time()
    best = [7, 15, 18, 22, -3, -2]
    bs = _score(best)
    cur, cs = best[:], bs
    while time.time() - t0 < time_budget:
        cand = cur[:]
        r = random.random()
        if r < 0.6:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-4, 4)
        elif r < 0.8:
            cand.append(random.randint(-30, 50))
        elif len(cand) > 4:
            cand.pop(random.randrange(len(cand)))
        cand = sorted(set(cand))
        s = _score(cand)
        if s >= cs or random.random() < 0.02:
            cur, cs = cand, s
            if s > bs:
                best, bs = cand[:], s
    return best


def solve():
    T0 = time.time()
    random.seed(12345)
    # analytic scan of simplex sets
    cands = []
    for d in range(1, 30):
        for n in range(1, 60):
            size, D, S = _simplex_counts(d, n)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 1e15:
                break
            cands.append((_score_counts(D, S, size), d, n))
    cands.sort(reverse=True)

    library = []  # (D, S, size, elements)
    small = _anneal_small(5.0)
    sD, sS = _counts(np.array(small))
    library.append((sD, sS, len(small), small))
    base = [7, 15, 18, 22, -3, -2]
    bD, bS = _counts(np.array(base))
    library.append((bD, bS, len(base), sorted(base)))

    top = cands[:6]
    budget_total = 85.0
    per = budget_total / max(1, len(top))
    for sc, d, n in top:
        if time.time() - T0 > 95:
            break
        for extra in (1,):
            res = _orbit_search(d, n, extra, per)
            if res is not None:
                s2, D, S, e = res
                library.append((D, S, len(e), e))

    # products over singletons, pairs, triples
    def mag_ok(parts):
        # parts: list of element lists; build B + M*C iteratively
        return True

    best_combo = None
    best_sc = -1.0
    L = len(library)
    for r in (1, 2, 3):
        for combo in itertools.product(range(L), repeat=r):
            D = 1; S = 1; k = 1
            for i in combo:
                D *= library[i][0]; S *= library[i][1]; k *= library[i][2]
            if k > 4000:
                continue
            sc = _score_counts(D, S, k)
            if sc > best_sc:
                # check magnitude
                span = 0
                ok = True
                for i in combo:
                    el = library[i][3]
                    w = max(el) - min(el)
                    # new span = w*Mprev + span where Mprev = 2*span+1
                    Mp = 2 * span + 1
                    span = w * Mp + span
                    if span > 9e14:
                        ok = False
                        break
                if ok:
                    best_sc = sc
                    best_combo = combo

    def build(combo):
        A = [0]
        for idx, i in enumerate(combo):
            el = library[i][3]
            mn = min(el)
            el = [x - mn for x in el]
            spanA = max(A) - min(A)
            Mp = 2 * spanA + 1
            A = [x * Mp + a for x in el for a in A]
        return sorted(set(A))

    result = build(best_combo) if best_combo is not None else sorted(set(base))
    # verify; fallback to best singleton if mismatch
    try:
        if len(result) <= 4000 and max(abs(x) for x in result) <= 1e15:
            real = _score(result)
            if real + 1e-9 < best_sc:
                bestlib = max(library, key=lambda t: _score_counts(t[0], t[1], t[2]))
                if _score(bestlib[3]) > real:
                    result = bestlib[3]
        else:
            result = sorted(set(base))
    except Exception:
        result = sorted(set(base))
    return [int(x) for x in result]
