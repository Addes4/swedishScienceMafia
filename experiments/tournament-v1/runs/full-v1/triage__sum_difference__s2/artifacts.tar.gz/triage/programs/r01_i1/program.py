"""
Generalize convex-body idea: enumerate lattice points from highly asymmetric convex bodies.
Try dilated simplices, simplex-cube products, and truncated cones.
"""
import math
import time
from itertools import product


def _score(a):
    """Score function: log|A-A| / log|A+A| with bonus for larger sets."""
    a_set = set(a)
    if len(a_set) < 2:
        return 0.0
    diffs = {x - y for x in a_set for y in a_set}
    sums = {x + y for x in a_set for y in a_set}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a_set)) / 100


def _embed_with_base(points_2d, base=10**9):
    """Embed 2D lattice points into 1D integers using a large base."""
    return [p[0] + base * p[1] for p in points_2d]


def _simplex_points(n, scale):
    """Generate lattice points in a simplex with unequal edge scaling.
    Simplex: x1 + x2 + ... + xn <= scale, xi >= 0."""
    points = []
    
    def gen(coords, remaining, d):
        if d == n - 1:
            if remaining >= 0:
                points.append(tuple(coords + [remaining]))
            return
        for i in range(remaining + 1):
            gen(coords + [i], remaining - i, d + 1)
    
    gen([], scale, 0)
    return points


def _simplex_product_points(scales_1d, max_coord=None):
    """Product of 1D simplices with different scales."""
    if max_coord is None:
        max_coord = max(scales_1d)
    
    ranges = [range(s + 1) for s in scales_1d]
    return list(product(*ranges))


def _truncated_cone_points(height, base_min, base_max, steps):
    """Lattice points in a truncated cone (frustum).
    Parametrized from base_min to base_max over height steps."""
    points = []
    for h in range(steps + 1):
        t = h / max(1, steps)
        radius = base_min + t * (base_max - base_min)
        max_r_int = int(radius)
        for r in range(-max_r_int, max_r_int + 1):
            for theta_idx in range(max(1, int(2 * math.pi * radius / (2 * steps)))):
                angle = 2 * math.pi * theta_idx / max(1, int(2 * math.pi * radius / (2 * steps)))
                x = int(r * math.cos(angle))
                y = int(r * math.sin(angle))
                points.append((x, y, h))
    return points


def _scale_and_embed_points(points, base=10**9):
    """Embed high-dimensional lattice points into 1D using large base."""
    if not points:
        return []
    
    # Normalize points to be near origin
    dim = len(points[0])
    result = []
    for p in points:
        val = sum(p[i] * (base ** i) for i in range(dim))
        result.append(val)
    return result


def solve():
    """Return a set A maximizing log|A-A| / log|A+A|."""
    deadline = time.time() + 110
    best_set = None
    best_score = -1.0
    
    candidates = []
    
    # Strategy 1: Simplex with unequal scaling
    for scale in [8, 10, 12, 15]:
        if time.time() > deadline:
            break
        pts = _simplex_points(3, scale)
        embedded = _scale_and_embed_points(pts, base=10**10)
        s = _score(embedded)
        candidates.append((s, embedded))
    
    # Strategy 2: Simplex products with different aspect ratios
    for s1 in [6, 8, 10, 12]:
        for s2 in [2, 3, 4, 5]:
            if time.time() > deadline:
                break
            pts = _simplex_product_points([s1, s2])
            embedded = _embed_with_base(pts, base=10**9)
            s = _score(embedded)
            candidates.append((s, embedded))
    
    # Strategy 3: Simplex with 4 dimensions
    for scale in [6, 7, 8]:
        if time.time() > deadline:
            break
        pts = _simplex_points(4, scale)
        if len(pts) > 4000:
            pts = pts[:4000]
        embedded = _scale_and_embed_points(pts, base=10**9)
        s = _score(embedded)
        candidates.append((s, embedded))
    
    # Strategy 4: Mixed simplex-cube products
    for s1 in [5, 7, 9]:
        for s2 in [3, 4, 5]:
            if time.time() > deadline:
                break
            pts = _simplex_product_points([s1, s2, 2])
            embedded = _scale_and_embed_points(pts, base=10**8)
            s = _score(embedded)
            candidates.append((s, embedded))
    
    # Strategy 5: Sparse simplices with larger dimensions
    for scale in [5, 6]:
        if time.time() > deadline:
            break
        pts = _simplex_points(5, scale)
        if len(pts) > 4000:
            # Sample uniformly
            step = len(pts) // 4000 + 1
            pts = pts[::step]
        embedded = _scale_and_embed_points(pts, base=10**8)
        s = _score(embedded)
        candidates.append((s, embedded))
    
    # Pick best from candidates
    for s, a in candidates:
        if s > best_score:
            best_score = s
            best_set = a
    
    if best_set is None:
        best_set = [0, 1, 2, 3, 5, 8]
    
    # Light refinement with random perturbations
    cur = best_set[:]
    while time.time() < deadline - 2:
        if len(cur) > 1:
            # Try small modifications
            idx = __import__('random').randrange(len(cur))
            old_val = cur[idx]
            cur[idx] += __import__('random').randint(-100, 100)
            new_score = _score(cur)
            if new_score >= best_score:
                best_score = new_score
                best_set = cur[:]
            else:
                cur[idx] = old_val
    
    return sorted(set(best_set))
