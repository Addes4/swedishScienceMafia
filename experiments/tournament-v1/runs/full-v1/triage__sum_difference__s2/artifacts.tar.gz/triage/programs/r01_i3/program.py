# EVOLVE-BLOCK-START
import math
import random
import time
import itertools
import numpy as np


def _ratio_of(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    d = {x - y for x in a for y in a}
    s = {x + y for x in a for y in a}
    return math.log(len(d)) / math.log(len(s))


class St:
    def __init__(self, N, A):
        self.N = N
        self.sc = [0] * (2 * N + 1)
        self.dc = [0] * (2 * N + 1)
        self.occ = [False] * (N + 1)
        self.S = 0
        self.D = 0
        self.el = []
        self.pos = {}
        for a in A:
            self.add(a)

    def add(self, x):
        sc = self.sc; dc = self.dc; N = self.N
        S = self.S; D = self.D
        for a in self.el:
            i = x + a
            if sc[i] == 0:
                S += 1
            sc[i] += 2
            j = x - a + N
            if dc[j] == 0:
                D += 1
            dc[j] += 1
            j = a - x + N
            if dc[j] == 0:
                D += 1
            dc[j] += 1
        i = 2 * x
        if sc[i] == 0:
            S += 1
        sc[i] += 1
        if dc[N] == 0:
            D += 1
        dc[N] += 1
        self.S = S; self.D = D
        self.pos[x] = len(self.el)
        self.el.append(x)
        self.occ[x] = True

    def remove(self, x):
        el = self.el
        p = self.pos.pop(x)
        last = el.pop()
        if last != x:
            el[p] = last
            self.pos[last] = p
        self.occ[x] = False
        sc = self.sc; dc = self.dc; N = self.N
        S = self.S; D = self.D
        for a in el:
            i = x + a
            sc[i] -= 2
            if sc[i] == 0:
                S -= 1
            j = x - a + N
            dc[j] -= 1
            if dc[j] == 0:
                D -= 1
            j = a - x + N
            dc[j] -= 1
            if dc[j] == 0:
                D -= 1
        i = 2 * x
        sc[i] -= 1
        if sc[i] == 0:
            S -= 1
        dc[N] -= 1
        if dc[N] == 0:
            D -= 1
        self.S = S; self.D = D

    def r(self):
        if len(self.el) < 2:
            return 0.0
        return math.log(self.D) / math.log(self.S)


def _simplex_seeds():
    seeds = []
    for d in range(2, 9):
        for k in range(1, 5):
            for t in range(1, k + 1):
                pts = [p for p in itertools.product(range(t + 1), repeat=d) if sum(p) <= k]
                if len(pts) < 3 or len(pts) > 220:
                    continue
                B = 2 * k + 1
                if k * B ** (d - 1) > 6000:
                    continue
                A = sorted({sum(c * B ** i for i, c in enumerate(p)) for p in pts})
                seeds.append((_ratio_of(A), A))
    return seeds


def _sa(A0, N, dur, T0, T1, nmin=3, nmax=200):
    st = St(N, A0)
    cur = st.r()
    best = cur
    bestA = list(st.el)
    t0 = time.time()
    end = t0 + dur
    it = 0
    T = T0
    rnd = random.random
    rr = random.randrange
    while True:
        it += 1
        if (it & 127) == 0:
            now = time.time()
            if now >= end:
                break
            fr = (now - t0) / dur
            T = T0 * (T1 / T0) ** fr
        n = len(st.el)
        u = rnd()
        if u < 0.85 or (n <= nmin and u < 0.925) or (n >= nmax and u >= 0.925):
            x = st.el[rr(n)]
            if u < 0.65:
                y = rr(N + 1)
            else:
                y = x + rr(-4, 5)
            if y < 0 or y > N or st.occ[y]:
                continue
            st.remove(x); st.add(y)
            new = st.r()
            if new >= cur or rnd() < math.exp((new - cur) / T):
                cur = new
            else:
                st.remove(y); st.add(x)
                continue
        elif u < 0.925:
            if n >= nmax:
                continue
            y = rr(N + 1)
            if st.occ[y]:
                continue
            st.add(y)
            new = st.r()
            if new >= cur or rnd() < math.exp((new - cur) / T):
                cur = new
            else:
                st.remove(y)
                continue
        else:
            if n <= nmin:
                continue
            x = st.el[rr(n)]
            st.remove(x)
            new = st.r()
            if new >= cur or rnd() < math.exp((new - cur) / T):
                cur = new
            else:
                st.add(x)
                continue
        if cur > best + 1e-12:
            best = cur
            bestA = list(st.el)
    return best, sorted(bestA)


def _normalize(A):
    m = min(A)
    return sorted(a - m for a in A)


def _power(B, k):
    m = max(B)
    M = 2 * m + 1
    cur = [0]
    mult = 1
    for _ in range(k):
        cur = [c + mult * b for c in cur for b in B]
        mult *= M
    return cur


def _final_choice(B):
    B = _normalize(B)
    n = len(B)
    m = max(B)
    M = 2 * m + 1
    bestk = 1
    for k in range(1, 20):
        if n ** k > 4000:
            break
        maxval = m * sum(M ** i for i in range(k))
        if maxval > 9e14:
            break
        bestk = k
    return bestk


def _full_score(A):
    a = np.array(sorted(set(A)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    s = (a[:, None] + a[None, :]).ravel()
    d = (a[:, None] - a[None, :]).ravel()
    S = len(np.unique(s))
    D = len(np.unique(d))
    return math.log(D) / math.log(S) + (1 - 1 / n) / 100


def solve():
    tstart = time.time()
    budget = 100.0
    random.seed(12345)
    seeds = _simplex_seeds()
    base0 = _normalize([7, 15, 18, 22, -3, -2])
    seeds.append((_ratio_of(base0), base0))
    seeds.sort(key=lambda z: -z[0])
    top = seeds[:8]

    pool = []  # (ratio, set)
    for r, A in top:
        pool.append((r, A))
    best_r, best_A = max(pool, key=lambda z: z[0])

    run = 0
    while time.time() - tstart < budget - 2:
        remaining = budget - (time.time() - tstart)
        dur = min(7.0, remaining - 1.5)
        if dur < 0.5:
            break
        u = random.random()
        if run < len(top):
            A0 = top[run][1]
        elif u < 0.5:
            A0 = best_A
        else:
            cand = sorted(pool, key=lambda z: -z[0])[:6]
            A0 = random.choice(cand)[1]
        A0 = _normalize(A0)
        mx = max(A0)
        N = max(mx + 5, int(mx * random.choice([1.0, 1.1, 1.3])) + 5)
        N = min(N, 20000)
        if mx > N:
            N = mx
        r, A = _sa(A0, N, dur, 0.004, 0.0002)
        A = _normalize(A)
        pool.append((r, A))
        if r > best_r:
            best_r, best_A = r, A
        run += 1

    # choose final with tensor power for size bonus
    cands = sorted(pool, key=lambda z: -z[0])[:5]
    best_final = None
    best_fs = -1
    for r, B in cands:
        B = _normalize(B)
        k = _final_choice(B)
        n = len(B) ** k
        fs = r + (1 - 1 / n) / 100
        if fs > best_fs:
            best_fs = fs
            best_final = (B, k)
    B, k = best_final
    A = _power(B, k)
    try:
        sc = _full_score(A)
        sb = _full_score(B)
        if sc < sb:
            A = B
    except Exception:
        A = B
    return sorted(set(int(x) for x in A))
# EVOLVE-BLOCK-END
