import math
import random
import time
import itertools
import numpy as np


def _counts(e):
    e = np.asarray(e, dtype=np.int64)
    s = np.unique((e[:, None] + e[None, :]).ravel()).size
    d = np.unique((e[:, None] - e[None, :]).ravel()).size
    return d, s


def _score_counts(D, S, k):
    if k < 2 or S < 2:
        return 0.0
    return math.log(D) / math.log(S) + (1 - 1 / k) / 100


def _score(a):
    a = sorted(set(a))
    if len(a) < 2:
        return 0.0
    D, S = _counts(np.array(a, dtype=np.int64))
    return _score_counts(D, S, len(a))


def _simplex_counts(d, n):
    size = math.comb(n + d, d)
    S = math.comb(2 * n + d, d)
    D = 0
    for k in range(0, min(d, n) + 1):
        for j in range(0, min(d - k, n) + 1):
            D += math.comb(d, k) * math.comb(d - k, j) * math.comb(n, k) * math.comb(n, j)
    return size, D, S


def _partitions(s, maxpart, maxlen):
    if s == 0:
        yield ()
        return
    if maxlen == 0:
        return
    for p in range(min(s, maxpart), 0, -1):
        for rest in _partitions(s - p, p, maxlen - 1):
            yield (p,) + rest


def _multiset_perms(vals):
    cnt = {}
    for v in vals:
        cnt[v] = cnt.get(v, 0) + 1
    keys = list(cnt.keys())
    L = len(vals)
    out = []
    cur = []

    def rec():
        if len(cur) == L:
            out.append(tuple(cur))
            return
        for kk in keys:
            if cnt[kk] > 0:
                cnt[kk] -= 1
                cur.append(kk)
                rec()
                cur.pop()
                cnt[kk] += 1
    rec()
    return out


def _nperms(vals):
    cnt = {}
    for v in vals:
        cnt[v] = cnt.get(v, 0) + 1
    r = math.factorial(len(vals))
    for c in cnt.values():
        r //= math.factorial(c)
    return r


def _encode(X, lo, B, d):
    if B ** d < 2 ** 62:
        pw = np.array([B ** i for i in range(d)], dtype=np.int64)
        return (X.astype(np.int64) - lo) @ pw
    Xc = np.ascontiguousarray(X.astype(np.int16))
    return Xc.view(np.dtype((np.void, 2 * d))).ravel()


def _orbsizes(R, d):
    K = R.shape[0]
    t = np.ones(K, dtype=np.int64)
    prod = np.ones(K, dtype=np.int64)
    for p in range(1, d):
        t = np.where(R[:, p] == R[:, p - 1], t + 1, 1)
        prod *= t
    return np.int64(math.factorial(d)) // prod


class _St:
    def __init__(self, nc, sizeS, sizeD, sj, sid, dj, did, csize):
        self.nc = nc
        self.incl = np.zeros(nc, dtype=bool)
        self.cS = np.zeros(len(sizeS), dtype=np.int32)
        self.cD = np.zeros(len(sizeD), dtype=np.int32)
        self.sizeS = sizeS
        self.sizeD = sizeD
        self.sj, self.sid, self.dj, self.did = sj, sid, dj, did
        self.csize = csize
        self.S = 0
        self.D = 0
        self.k = 0

    def toggle(self, i):
        if not self.incl[i]:
            self.incl[i] = True
            m = self.incl[self.sj[i]]
            u, c = np.unique(self.sid[i][m], return_counts=True)
            z = self.cS[u] == 0
            self.S += int(self.sizeS[u[z]].sum())
            self.cS[u] += c.astype(np.int32)
            m = self.incl[self.dj[i]]
            u, c = np.unique(self.did[i][m], return_counts=True)
            z = self.cD[u] == 0
            self.D += int(self.sizeD[u[z]].sum())
            self.cD[u] += c.astype(np.int32)
            self.k += self.csize[i]
        else:
            m = self.incl[self.sj[i]]
            u, c = np.unique(self.sid[i][m], return_counts=True)
            self.cS[u] -= c.astype(np.int32)
            z = self.cS[u] == 0
            self.S -= int(self.sizeS[u[z]].sum())
            m = self.incl[self.dj[i]]
            u, c = np.unique(self.did[i][m], return_counts=True)
            self.cD[u] -= c.astype(np.int32)
            z = self.cD[u] == 0
            self.D -= int(self.sizeD[u[z]].sum())
            self.incl[i] = False
            self.k -= self.csize[i]

    def score(self):
        if self.k < 2 or self.k > 4000 or self.S < 2:
            return -1.0
        return math.log(self.D) / math.log(self.S) + (1 - 1 / self.k) / 100

    def set_to(self, target):
        diff = np.nonzero(self.incl != target)[0]
        for i in diff:
            self.toggle(int(i))


def _local(st, deadline, use_pairs=True):
    cur = st.score()
    nc = st.nc
    while time.time() < deadline:
        improved = False
        order = list(range(nc))
        random.shuffle(order)
        for i in order:
            if time.time() > deadline:
                break
            st.toggle(i)
            s = st.score()
            if s > cur + 1e-12:
                cur = s
                improved = True
            else:
                st.toggle(i)
        if improved:
            continue
        if not use_pairs:
            break
        found = False
        order = list(range(nc))
        random.shuffle(order)
        for pa in range(len(order)):
            if time.time() > deadline or found:
                break
            a = order[pa]
            st.toggle(a)
            for pb in range(pa + 1, len(order)):
                b = order[pb]
                st.toggle(b)
                s = st.score()
                if s > cur + 1e-12:
                    cur = s
                    found = True
                    break
                st.toggle(b)
            if not found:
                st.toggle(a)
        if not found:
            break
    return cur


def _orbit_search(d, n, extra, time_budget):
    t0 = time.time()
    deadline = t0 + time_budget
    if d > 20 or (2 * n + 1) ** d > 1e15:
        return None
    smax = n + extra
    if 2 * smax > 30000:
        return None
    blocks = []
    cs = []
    for s in range(0, smax + 1):
        for p in _partitions(s, smax, d):
            vals = list(p) + [0] * (d - len(p))
            if _nperms(vals) > 4000:
                continue
            perms = _multiset_perms(vals)
            blocks.append(np.array(perms, dtype=np.int16).reshape(-1, d))
            cs.append(s)
        if time.time() > deadline:
            return None
    nc = len(blocks)
    if nc < 1:
        return None
    V = np.vstack(blocks)
    U = V.shape[0]
    if nc * U > 3000000:
        return None
    csize = [b.shape[0] for b in blocks]
    cls = np.repeat(np.arange(nc), csize)
    starts = np.concatenate([[0], np.cumsum(csize)[:-1]]).astype(np.int64)
    rep = V[starts]

    allS = np.sort(rep[:, None, :] + V[None, :, :], axis=2).reshape(-1, d)
    B = 2 * smax + 1
    codeS = _encode(allS, 0, B, d)
    uS, idxS, invS = np.unique(codeS, return_index=True, return_inverse=True)
    invS = np.asarray(invS).ravel()
    Ks = len(uS)
    sizeS = _orbsizes(allS[idxS].astype(np.int64), d)
    del allS, codeS
    if time.time() > deadline:
        return None

    Dp = np.sort(rep[:, None, :] - V[None, :, :], axis=2)
    Dn = np.sort(V[None, :, :] - rep[:, None, :], axis=2)
    allD = np.concatenate([Dp, Dn], axis=1).reshape(-1, d)
    del Dp, Dn
    codeD = _encode(allD, -smax, B, d)
    uD, idxD, invD = np.unique(codeD, return_index=True, return_inverse=True)
    invD = np.asarray(invD).ravel()
    Kd = len(uD)
    sizeD = _orbsizes(allD[idxD].astype(np.int64), d)
    del allD, codeD

    cls64 = cls.astype(np.int64)
    cls2 = np.concatenate([cls64, cls64])
    sj, sid, dj, did = [], [], [], []
    invS = invS.reshape(nc, U)
    invD = invD.reshape(nc, 2 * U)
    for i in range(nc):
        key = np.unique(cls64 * Ks + invS[i])
        sj.append(key // Ks)
        sid.append(key % Ks)
        key = np.unique(cls2 * Kd + invD[i])
        dj.append(key // Kd)
        did.append(key % Kd)
    if time.time() > deadline:
        return None

    st = _St(nc, sizeS, sizeD, sj, sid, dj, did, csize)
    for i in range(nc):
        if cs[i] <= n:
            st.toggle(i)
    best_sc = _local(st, deadline, True)
    best_incl = st.incl.copy()
    while time.time() < deadline:
        st.set_to(best_incl)
        r = random.randint(2, max(2, min(6, nc)))
        for i in random.sample(range(nc), min(r, nc)):
            st.toggle(i)
        s = _local(st, deadline, random.random() < 0.35)
        if s > best_sc + 1e-12:
            best_sc = s
            best_incl = st.incl.copy()
    st.set_to(best_incl)
    if st.k < 2 or st.k > 4000:
        return None
    rows = V[np.isin(cls, np.nonzero(best_incl)[0])].astype(np.int64)
    m = int(rows.max()) if rows.size else 0
    M = 2 * m + 1
    if M ** d > 1e15:
        return None
    pw = np.array([M ** i for i in range(d)], dtype=np.int64)
    e = rows @ pw
    return best_sc, st.D, st.S, sorted(int(x) for x in e)


def _anneal_small(time_budget):
    t0 = time.time()
    best = [7, 15, 18, 22, -3, -2]
    bs = _score(best)
    cur, cs = best[:], bs
    while time.time() - t0 < time_budget:
        cand = cur[:]
        r = random.random()
        if r < 0.6:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-4, 4)
        elif r < 0.8:
            cand.append(random.randint(-30, 50))
        elif len(cand) > 4:
            cand.pop(random.randrange(len(cand)))
        cand = sorted(set(cand))
        s = _score(cand)
        if s >= cs or random.random() < 0.02:
            cur, cs = cand, s
            if s > bs:
                best, bs = cand[:], s
    return best


def solve():
    T0 = time.time()
    random.seed(12345)
    cands = []
    for d in range(1, 30):
        for n in range(1, 60):
            size, D, S = _simplex_counts(d, n)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 1e15:
                break
            cands.append((_score_counts(D, S, size), d, n))
    cands.sort(reverse=True)

    library = []
    small = _anneal_small(3.0)
    sD, sS = _counts(np.array(small))
    library.append((sD, sS, len(small), small))
    base = [7, 15, 18, 22, -3, -2]
    bD, bS = _counts(np.array(base))
    library.append((bD, bS, len(base), sorted(base)))

    plan = []
    for idx, (sc, d, n) in enumerate(cands[:6]):
        if idx < 2:
            for ex in (1, 2, 3):
                plan.append((d, n, ex, 12.0))
        else:
            for ex in (1, 2):
                plan.append((d, n, ex, 2.5))
    for d, n, ex, bud in plan:
        rem = 98.0 - (time.time() - T0)
        if rem < 1.0:
            break
        try:
            res = _orbit_search(d, n, ex, min(bud, rem))
        except Exception:
            res = None
        if res is not None:
            s2, D, S, e = res
            if len(e) >= 2:
                library.append((D, S, len(e), e))

    best_combo = None
    best_sc = -1.0
    L = len(library)
    for r in (1, 2, 3):
        for combo in itertools.product(range(L), repeat=r):
            D = 1; S = 1; k = 1
            for i in combo:
                D *= library[i][0]; S *= library[i][1]; k *= library[i][2]
            if k > 4000:
                continue
            sc = _score_counts(D, S, k)
            if sc > best_sc:
                span = 0
                ok = True
                for i in combo:
                    el = library[i][3]
                    w = max(el) - min(el)
                    Mp = 2 * span + 1
                    span = w * Mp + span
                    if span > 9e14:
                        ok = False
                        break
                if ok:
                    best_sc = sc
                    best_combo = combo

    def build(combo):
        A = [0]
        for i in combo:
            el = library[i][3]
            mn = min(el)
            el = [x - mn for x in el]
            spanA = max(A) - min(A)
            Mp = 2 * spanA + 1
            A = [x * Mp + a for x in el for a in A]
        return sorted(set(A))

    result = build(best_combo) if best_combo is not None else sorted(set(base))
    try:
        if len(result) <= 4000 and max(abs(x) for x in result) <= 1e15:
            real = _score(result)
            if real + 1e-9 < best_sc:
                order = sorted(range(L), key=lambda t: -_score_counts(library[t][0], library[t][1], library[t][2]))
                for t in order[:4]:
                    if time.time() - T0 > 115:
                        break
                    s = _score(library[t][3])
                    if s > real:
                        real = s
                        result = library[t][3]
        else:
            result = sorted(set(base))
    except Exception:
        result = sorted(set(base))
    return [int(x) for x in result]
