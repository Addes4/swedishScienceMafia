"""
Local search in d-dimensional lattice with greedy optimization and carry-free base embedding.
"""
import math
import random
import time
from itertools import combinations


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _lattice_to_integers(lattice_points, base=1000000):
    """Map d-dimensional lattice points to integers using carry-free base representation."""
    if not lattice_points:
        return []
    
    d = len(lattice_points[0])
    result = []
    
    for point in lattice_points:
        # Carry-free base: each coordinate contributes independently
        val = 0
        for i, coord in enumerate(point):
            val += coord * (base ** i)
        result.append(val)
    
    return result


def _neighbors_in_simplex(point, n, max_dist=1):
    """Generate neighbors of a lattice point within simplex {x ≥ 0, Σx ≤ n}."""
    d = len(point)
    neighbors = []
    
    # Try all single coordinate changes
    for i in range(d):
        for delta in [-max_dist, max_dist]:
            new_point = list(point)
            new_point[i] += delta
            if all(x >= 0 for x in new_point) and sum(new_point) <= n:
                neighbors.append(tuple(new_point))
    
    return neighbors


def _greedy_lattice_search(d, n, time_limit=60):
    """Greedy local search in d-dimensional simplex lattice."""
    start_time = time.time()
    
    # Start with simplex vertices (corners)
    current = [tuple([0] * d)]
    
    # Add standard basis vectors
    for i in range(d):
        point = [0] * d
        point[i] = min(n, 1)
        current.append(tuple(point))
    
    best_current = current[:]
    best_score = _evaluate_lattice(best_current)
    
    iteration = 0
    while time.time() - start_time < time_limit:
        iteration += 1
        improved = False
        
        # Try adding new points
        candidates = set()
        for point in current:
            for neighbor in _neighbors_in_simplex(point, n, max_dist=1):
                if neighbor not in current:
                    candidates.add(neighbor)
        
        for cand_point in candidates:
            test_set = current + [cand_point]
            score = _evaluate_lattice(test_set)
            if score > best_score:
                best_current = test_set[:]
                best_score = score
                current = test_set[:]
                improved = True
                break
        
        if not improved:
            # Try removing points (except initial ones)
            if len(current) > d + 1:
                for i in range(d + 1, len(current)):
                    test_set = current[:i] + current[i+1:]
                    score = _evaluate_lattice(test_set)
                    if score > best_score:
                        best_current = test_set[:]
                        best_score = score
                        current = test_set[:]
                        improved = True
                        break
        
        if not improved:
            break
    
    return best_current, best_score


def _evaluate_lattice(lattice_points):
    """Evaluate score of lattice point configuration."""
    if len(lattice_points) < 2:
        return 0.0
    
    d = len(lattice_points[0])
    
    # Count differences in lattice space
    diffs = set()
    for i in range(len(lattice_points)):
        for j in range(len(lattice_points)):
            diff = tuple(lattice_points[i][k] - lattice_points[j][k] for k in range(d))
            diffs.add(diff)
    
    # Count sums in lattice space
    sums = set()
    for i in range(len(lattice_points)):
        for j in range(len(lattice_points)):
            s = tuple(lattice_points[i][k] + lattice_points[j][k] for k in range(d))
            sums.add(s)
    
    if len(sums) < 2:
        return 0.0
    
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(lattice_points)) / 100
    return score


def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    best_solution = [7, 15, 18, 22, -3, -2]
    best_score = _score(best_solution)
    
    deadline = time.time() + 115
    
    # Try different dimensions and search budgets
    for d in [2, 3, 4, 5]:
        if time.time() > deadline - 10:
            break
        
        for n in [20, 30, 40]:
            if time.time() > deadline - 5:
                break
            
            time_left = deadline - time.time()
            if time_left < 5:
                break
            
            lattice_points, lattice_score = _greedy_lattice_search(d, n, time_limit=min(15, time_left / 3))
            
            # Map to integers with carry-free base
            base = 10**9
            integers = _lattice_to_integers(lattice_points, base=base)
            
            # Add negative versions for symmetry
            integers_extended = integers + [-x for x in integers]
            
            score = _score(integers_extended)
            
            if score > best_score:
                best_solution = integers_extended[:]
                best_score = score
    
    # Final local search in integer space
    if time.time() < deadline - 2:
        cur = best_solution[:]
        time_left = deadline - time.time()
        local_deadline = time.time() + min(10, time_left - 1)
        
        while time.time() < local_deadline:
            improved = False
            
            # Try modifying existing elements
            for i in range(len(cur)):
                for delta in [-1, 1]:
                    test = cur[:]
                    test[i] += delta
                    test = list(set(test))
                    s = _score(test)
                    if s > best_score:
                        cur = test
                        best_solution = test[:]
                        best_score = s
                        improved = True
                        break
                if improved:
                    break
            
            if not improved:
                break
    
    return sorted(set(best_solution))
