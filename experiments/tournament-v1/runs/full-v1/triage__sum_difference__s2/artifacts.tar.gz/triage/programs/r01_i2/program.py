# EVOLVE-BLOCK-START
import math
import random
import time
from math import gcd


def _norm(B):
    B = sorted(set(B))
    m0 = B[0]
    B = [b - m0 for b in B]
    g = 0
    for b in B:
        g = gcd(g, b)
    if g > 1:
        B = [b // g for b in B]
    return B


def _ds(B):
    D = len({x - y for x in B for y in B})
    S = len({x + y for x in B for y in B})
    return D, S


def _sa(N, tlimit, rec, LOG, BON):
    cs = [0] * (2 * N + 1)
    cd = [0] * (2 * N + 1)
    B = []
    pos = [-1] * (N + 1)
    st = [0, 0]  # S, D

    def add(x):
        ds = 0
        dd = 0
        for b in B:
            i = x + b
            if cs[i] == 0:
                ds += 1
            cs[i] += 1
            j = x - b + N
            if cd[j] == 0:
                dd += 1
            cd[j] += 1
            k = b - x + N
            if cd[k] == 0:
                dd += 1
            cd[k] += 1
        i = 2 * x
        if cs[i] == 0:
            ds += 1
        cs[i] += 1
        if cd[N] == 0:
            dd += 1
        cd[N] += 1
        pos[x] = len(B)
        B.append(x)
        st[0] += ds
        st[1] += dd

    def rem(x):
        p = pos[x]
        last = B.pop()
        if last != x:
            B[p] = last
            pos[last] = p
        pos[x] = -1
        ds = 0
        dd = 0
        for b in B:
            i = x + b
            cs[i] -= 1
            if cs[i] == 0:
                ds += 1
            j = x - b + N
            cd[j] -= 1
            if cd[j] == 0:
                dd += 1
            k = b - x + N
            cd[k] -= 1
            if cd[k] == 0:
                dd += 1
        i = 2 * x
        cs[i] -= 1
        if cs[i] == 0:
            ds += 1
        cd[N] -= 1
        if cd[N] == 0:
            dd += 1
        st[0] -= ds
        st[1] -= dd

    k0 = random.randint(3, max(3, min(N, random.randint(4, 30))))
    init = random.sample(range(N + 1), k0)
    for x in init:
        add(x)

    def f():
        n = len(B)
        return LOG[st[1]] / LOG[st[0]] + BON[n]

    cur = f()
    t0 = time.time()
    T0, T1 = 0.03, 0.0003
    it = 0
    T = T0
    rnd = random.random
    rint = random.randint
    while True:
        it += 1
        if (it & 255) == 0:
            el = (time.time() - t0) / tlimit
            if el >= 1:
                break
            T = T0 * (T1 / T0) ** el
        n = len(B)
        r = rnd()
        if r < 0.25 and n < N + 1:
            y = rint(0, N)
            if pos[y] >= 0:
                continue
            add(y)
            new = f()
            if new >= cur or rnd() < math.exp((new - cur) / T):
                cur = new
            else:
                rem(y)
                continue
        elif r < 0.5 and n > 3:
            x = B[rint(0, n - 1)]
            rem(x)
            new = f()
            if new >= cur or rnd() < math.exp((new - cur) / T):
                cur = new
            else:
                add(x)
                continue
        else:
            x = B[rint(0, n - 1)]
            if rnd() < 0.5:
                y = x + rint(-3, 3)
                if y < 0 or y > N:
                    continue
            else:
                y = rint(0, N)
            if pos[y] >= 0:
                continue
            rem(x)
            add(y)
            new = f()
            if new >= cur or rnd() < math.exp((new - cur) / T):
                cur = new
            else:
                rem(y)
                add(x)
                continue
        n = len(B)
        ratio = LOG[st[1]] / LOG[st[0]]
        if n not in rec or ratio > rec[n][0] + 1e-12:
            rec[n] = (ratio, list(B))


def solve():
    start = time.time()
    total = 95.0
    random.seed(12345)
    NMAX = 60
    LOG = [0.0] + [math.log(i) if i > 1 else 1e-9 for i in range(1, 4 * NMAX + 10)]
    LOG[1] = 1e-9
    BON = [0.0] * (NMAX + 3)
    for n in range(2, NMAX + 3):
        k = 1
        while n ** (k + 1) <= 4000:
            k += 1
        BON[n] = (1 - 1 / n ** k) / 100
    rec = {}
    rec[3] = (math.log(7) / math.log(6), [0, 1, 3])
    while time.time() - start < total:
        rem_t = total - (time.time() - start)
        tl = min(rem_t, random.uniform(2.0, 5.0))
        if tl < 0.3:
            break
        N = random.randint(8, NMAX)
        _sa(N, tl, rec, LOG, BON)

    # Normalize and compute exact stats
    cands = []
    for n, (r, B) in rec.items():
        Bn = _norm(B)
        if len(Bn) != n or n < 2:
            continue
        D, S = _ds(Bn)
        M = 2 * max(Bn) + 1
        cands.append((n, math.log(D), math.log(S), math.log(M), M, Bn))
    cands.append((2, math.log(3), math.log(3), math.log(3), 3, [0, 1]))
    # Keep best ratio per size
    best_by = {}
    for c in cands:
        n = c[0]
        if n not in best_by or c[1] / c[2] > best_by[n][1] / best_by[n][2]:
            best_by[n] = c
    cl = sorted(best_by.values(), key=lambda c: c[0])
    LIM = math.log(1e15) - 0.01
    best = [-1.0, None]

    def dfs(i, prod, sD, sS, sM, chosen):
        if chosen:
            sc = sD / sS + (1 - 1 / prod) / 100
            if sc > best[0]:
                best[0] = sc
                best[1] = list(chosen)
        for j in range(i, len(cl)):
            c = cl[j]
            if prod * c[0] > 4000:
                break
            if sM + c[3] > LIM:
                continue
            chosen.append(c)
            dfs(j, prod * c[0], sD + c[1], sS + c[2], sM + c[3], chosen)
            chosen.pop()

    dfs(0, 1, 0.0, 0.0, 0.0, [])
    chosen = best[1]
    A = [0]
    W = 1
    for c in chosen:
        Bn = c[5]
        A = [a + W * b for a in A for b in Bn]
        W *= c[4]
    return sorted(set(A))
# EVOLVE-BLOCK-END
