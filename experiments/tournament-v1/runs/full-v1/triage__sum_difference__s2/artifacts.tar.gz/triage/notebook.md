# Research notebook: sum_difference

Ranker `jev`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.887449.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 2 | Use tensor-power amplification: search hard (simulated annealing for ~60s) for a small base set B ⊂ [0,60] maximizing log/B−B//log/B+B/, then output B + M·B + M | 0.72 | favourite | opus-5-5 | improved | 0.888561 |
| 3 | Run simulated annealing directly on a medium-size set (/A/ ~ 30–200) inside an interval [0,N], with incremental bookkeeping: maintain multiplicity counters for  | 0.70 | favourite | opus-5-5 | improved | 0.911651 |
| 5 | Try product constructions of two different good sets, A = B + M·C with B ≠ C (e.g., a 2-D simplex set and a 3-D simplex set, or a simplex set combined with an a | 0.64 | middle | opus-5-5 (swapped) | improved | 0.946948 |
| 0 | Replace the baseline with a lattice-simplex construction: take the points x in Z_{≥0}^d with x_1+…+x_d ≤ n, map them to integers via x ↦ Σ x_i·B^i with a large  | 0.60 | middle | sonnet-5-5 | improved | 0.946948 |
| 4 | Perform local search in the d-dimensional lattice before embedding: start from simplex points {x ≥ 0, Σx ≤ n}, then greedily add or remove lattice points (e.g., | 0.57 | long_shot | haiku-4-5 | not_better | 0.886624 |
| 1 | Generalize the convex-body idea: enumerate lattice points of other highly asymmetric convex bodies in Z^d, such as dilated simplices with unequal edge lengths,  | 0.55 | long_shot | haiku-4-5 | rejected | 0.000000 |

Best after round 1: **0.946948** (spent $0.61)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Speed up the orbit-class toggle search using permutation symmetry. Because every candidate set is S_d-invariant, sums and differences can be enumerated per orbi | 0.41 | favourite | opus-5-5 | not_better | 0.946948 |
| 0 | Remove the (2n+1)^d ≤ 1e15 limit on the simplex dimension by using a generic Freiman 2-isomorphic embedding instead of a carry-free base. Pick integer weights w | 0.35 | favourite | opus-5-5 | api_error |  |
| 2 | Use layered simplex sets: build A from the simplex points whose coordinate sum Σx lies in a chosen subset L ⊆ {0..n}, e.g. {0, n−1, n} or {0, 1, n}. Compute /A+ | 0.35 | middle | sonnet-5-5 | api_error |  |
| 5 | Run a final element-level polishing stage directly on the full embedded best set (~1000–4000 integers), using incremental sum/difference multiplicity counters.  | 0.29 | middle | opus-5-5 (swapped) | api_error |  |
| 1 | Treat the projection vector itself as the object to optimise. Map simplex (or orbit-searched) lattice points by x ↦ Σ v_i x_i with small integer v_i, and hill-c | 0.27 | long_shot | haiku-4-5 | api_error |  |
| 4 | Stack non-isomorphic simplex dimensions inside one lattice using a "joined simplex" construction. Let A = {(x,y) ∈ Z^{d1}×Z^{d2}: x,y ≥ 0, Σx ≤ n1, Σy ≤ n2, Σx  | 0.20 | long_shot | haiku-4-5 | api_error |  |

Best after round 2: **0.946948** (spent $1.07)

