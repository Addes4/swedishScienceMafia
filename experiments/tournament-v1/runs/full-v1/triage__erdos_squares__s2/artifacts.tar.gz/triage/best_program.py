# EVOLVE-BLOCK-START
"""Recursive grid / L-band constructions with knapsack budget allocation."""
import math
import numpy as np


def _plan(n):
    NEG = -1e18
    g = np.zeros(n + 1)
    F = np.zeros((n + 1, n + 1))   # F[j][b]: best with j cells, budget b
    G = np.zeros((n + 1, n + 1))   # same but no cell gets the full budget b
    Gch = {}
    Ffull = {}
    choice = [None] * (n + 1)
    for b in range(1, n + 1):
        # G[j][b]
        for j in range(1, b + 1):
            best = G[j - 1][b]
            bx = 0
            if b > 1:
                vals = F[j - 1, b - 1:0:-1] + g[1:b]  # x = 1..b-1
                ix = int(np.argmax(vals))
                if vals[ix] > best + 1e-12:
                    best = vals[ix]
                    bx = ix + 1
            G[j][b] = best
            Gch[(j, b)] = bx
        # options for g[b]
        bestv = 1.0
        bestc = ('single',)
        kmax = math.isqrt(b) + 2
        for k in range(2, kmax + 1):
            N = min(k * k, b)
            v = G[N][b] / k
            if v > bestv + 1e-12:
                bestv = v
                bestc = ('grid', k)
        kmax2 = min(b, int(2 * math.sqrt(b)) + 4)
        if b >= 2:
            for k in range(3, kmax2 + 1):
                for a in range(2, k):
                    N = min(k * k - a * a, n)
                    ys = np.arange(1, b)
                    vals = (a / k) * g[1:b] + F[N, b - ys] / k
                    ix = int(np.argmax(vals))
                    if vals[ix] > bestv + 1e-12:
                        bestv = vals[ix]
                        bestc = ('merge', k, a, int(ys[ix]))
        g[b] = bestv
        choice[b] = bestc
        for j in range(1, b + 1):
            if g[b] > G[j][b] + 1e-12:
                F[j][b] = g[b]
                Ffull[(j, b)] = True
            else:
                F[j][b] = G[j][b]
                Ffull[(j, b)] = False
        for j in range(b + 1, n + 1):
            F[j][b] = F[b][b]
    return g, choice, Gch, Ffull


def solve(n):
    if n <= 0:
        return []
    g, choice, Gch, Ffull = _plan(n)

    def allocF(j, b):
        jj = min(j, b)
        if jj == 0 or b == 0:
            return [0] * j
        if Ffull[(jj, b)]:
            res = [b] + [0] * (jj - 1)
        else:
            res = allocG(jj, b)
        return res + [0] * (j - jj)

    def allocG(j, b):
        if j == 0:
            return []
        x = Gch[(j, b)]
        if x == 0:
            return allocG(j - 1, b) + [0]
        return allocF(j - 1, b - x) + [x]

    out = []

    def build(c, x0, y0, s):
        if c <= 0:
            return
        ch = choice[c]
        if ch[0] == 'single':
            out.append((x0 + s / 2, y0 + s / 2, 0.0, s))
        elif ch[0] == 'grid':
            k = ch[1]
            N = min(k * k, c)
            al = allocG(N, c)
            cs = s / k
            for idx, bud in enumerate(al):
                if bud > 0:
                    cx, cy = idx % k, idx // k
                    build(bud, x0 + cx * cs, y0 + cy * cs, cs)
        else:
            _, k, a, y = ch
            cs = s / k
            build(y, x0, y0, cs * a)
            cells = [(i, j) for j in range(k) for i in range(k) if not (i < a and j < a)]
            N = min(len(cells), n)
            al = allocF(N, c - y)
            for idx, bud in enumerate(al):
                if bud > 0:
                    i, j = cells[idx]
                    build(bud, x0 + i * cs, y0 + j * cs, cs)

    build(n, 0.0, 0.0, 1.0)
    cl = lambda v: min(1.0, max(0.0, v))
    res = [(cl(a), cl(b), 0.0, cl(d)) for (a, b, _, d) in out]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
# EVOLVE-BLOCK-END
