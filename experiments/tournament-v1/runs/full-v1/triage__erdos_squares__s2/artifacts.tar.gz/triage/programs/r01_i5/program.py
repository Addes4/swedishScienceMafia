# EVOLVE-BLOCK-START
import math
import random
import time
from fractions import Fraction

import numpy as np


def _dp(N):
    G = np.zeros(N + 1)
    H = np.zeros((N + 1, N + 1))
    Hj = np.zeros((N + 1, N + 1), dtype=np.int64)
    Hr = np.zeros((N + 1, N + 1), dtype=np.int64)
    choice = [None] * (N + 1)
    ar = np.arange(N)
    kcap = N + 1 if N <= 400 else 60
    for b in range(1, N + 1):
        if b >= 2:
            sub = H[0:N, b - 1:0:-1]
            M = sub + G[1:b][None, :]
            jarg = np.argmax(M, axis=1)
            T = M[ar, jarg]
            best = -1.0
            bestr = 0
            bj = 0
            for r in range(1, N + 1):
                if T[r - 1] > best + 1e-12:
                    best = T[r - 1]
                    bestr = r
                    bj = int(jarg[r - 1]) + 1
                H[r, b] = best
                Hr[r, b] = bestr
                Hj[r, b] = bj
        bestG = 1.0
        ch = ('leaf',)
        if b >= 2 and G[b - 1] > bestG + 1e-12:
            bestG = G[b - 1]
            ch = ('mono',)
        if b >= 2:
            Grev = G[0:b]
            for k in range(2, min(b + 1, kcap) + 1):
                k2 = k * k
                # p = 0
                r0 = min(k2, N)
                v = H[r0, b] / k
                if v > bestG + 1e-12:
                    bestG = v
                    ch = ('grid', k, 0, 0, r0)
                for p in range(k - 1, 1, -1):
                    r = k2 - p * p
                    rr = min(r, N)
                    vals = (p * Grev + H[rr, b:0:-1]) / k
                    i = int(np.argmax(vals))
                    if vals[i] > bestG + 1e-12:
                        bestG = float(vals[i])
                        ch = ('grid', k, p, i, rr)
                    if r >= N:
                        break
        G[b] = bestG
        choice[b] = ch
        mask = G[b] > H[1:, b] + 1e-12
        idx = np.nonzero(mask)[0] + 1
        H[idx, b] = G[b]
        Hr[idx, b] = idx
        Hj[idx, b] = b
    return G, H, Hj, Hr, choice


def _build_dp(n):
    G, H, Hj, Hr, choice = _dp(n)

    def alloc(r, B):
        res = []
        while r > 0 and B > 0:
            rr = int(Hr[r, B])
            j = int(Hj[r, B])
            if j <= 0:
                break
            res.append(j)
            r = rr - 1
            B -= j
        return res

    def build(b, x, y, s):
        if b <= 0:
            return []
        ch = choice[b]
        if ch[0] == 'leaf':
            return [(x, y, s)]
        if ch[0] == 'mono':
            return build(b - 1, x, y, s)
        _, k, p, b1, rr = ch
        u = s / k
        out = []
        if p >= 2:
            out += build(b1, x, y, p * u)
        else:
            b1 = 0
        cells = [(i, j) for i in range(k) for j in range(k) if not (p >= 2 and i < p and j < p)]
        budgets = alloc(rr, b - b1)
        for idx, bb in enumerate(budgets):
            if idx >= len(cells):
                break
            i, j = cells[idx]
            out += build(bb, x + i * u, y + j * u, u)
        return out

    sq = build(n, Fraction(0), Fraction(0), Fraction(1))
    return float(G[n]), sq


def _sa(init_sq, L, n, tlimit, rng):
    own = np.full((L, L), -1, dtype=np.int64)
    sq = {}
    nid = 0
    for (x, y, s) in init_sq:
        if s <= 0:
            continue
        own[x:x + s, y:y + s] = nid
        sq[nid] = (x, y, s)
        nid += 1
    for i in range(L):
        for j in range(L):
            if own[i, j] == -1:
                own[i, j] = nid
                sq[nid] = (i, j, 1)
                nid += 1
    hist = [0] * (L + 1)
    for (_, _, s) in sq.values():
        hist[s] += 1

    def topn(h):
        rem = n
        tot = 0
        for s in range(L, 0, -1):
            c = h[s]
            if c:
                take = c if c < rem else rem
                tot += take * s
                rem -= take
                if rem == 0:
                    break
        return tot

    cur = topn(hist)
    best = cur
    bestsq = dict(sq)
    qmax = math.isqrt(n) + 1
    divs = [[q for q in range(1, t + 1) if t % q == 0 and q <= qmax] if t > 0 else [1]
            for t in range(L + 1)]
    T0, T1 = 2.0, 0.05
    T = T0
    start = time.time()
    it = 0
    while True:
        if (it & 255) == 0:
            el = time.time() - start
            if el > tlimit:
                break
            T = T0 * (T1 / T0) ** (el / tlimit)
        it += 1
        cx = rng.randrange(L)
        cy = rng.randrange(L)
        a = int(own[cx, cy])
        ax, ay, s = sq[a]
        if rng.random() < 0.3:
            t = s
        else:
            t = rng.randint(s, min(L, 2 * s + 2))
        x0 = rng.randint(max(0, ax + s - t), min(ax, L - t))
        y0 = rng.randint(max(0, ay + s - t), min(ay, L - t))
        ids = np.unique(own[x0:x0 + t, y0:y0 + t])
        ok = True
        for i in ids:
            bx, by, bs = sq[int(i)]
            if bx < x0 or by < y0 or bx + bs > x0 + t or by + bs > y0 + t:
                ok = False
                break
        if not ok:
            continue
        q = rng.choice(divs[t])
        ns = t // q
        if len(ids) == 1 and q == 1:
            continue
        removed = [sq[int(i)][2] for i in ids]
        for rs in removed:
            hist[rs] -= 1
        hist[ns] += q * q
        new = topn(hist)
        if new >= cur or rng.random() < math.exp((new - cur) / T):
            for i in ids:
                del sq[int(i)]
            for aa in range(q):
                for bb in range(q):
                    px = x0 + aa * ns
                    py = y0 + bb * ns
                    own[px:px + ns, py:py + ns] = nid
                    sq[nid] = (px, py, ns)
                    nid += 1
            cur = new
            if cur > best:
                best = cur
                bestsq = dict(sq)
        else:
            hist[ns] -= q * q
            for rs in removed:
                hist[rs] += 1
    return best / L, list(bestsq.values())


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    t_start = time.time()
    dpval, sqf = _build_dp(n)
    best_val = sum(float(s) for (_, _, s) in sqf)
    best_list = [(float(x + s / 2), float(y + s / 2), float(s)) for (x, y, s) in sqf]

    # Simulated annealing on grid partitions seeded by the DP solution
    try:
        L = 1
        for (x, y, s) in sqf:
            for f in (x, y, s):
                L = L * f.denominator // math.gcd(L, f.denominator)
        Ls = []
        if L <= 48:
            Ls.append(L)
            if 2 * L <= 48:
                Ls.append(2 * L)
        rng = random.Random(12345 + n)
        remaining = max(0.0, 40.0 - (time.time() - t_start))
        per = min(5.0, remaining / max(1, len(Ls)))
        for LL in Ls:
            mult = LL // L
            init = [(int(x * L) * mult, int(y * L) * mult, int(s * L) * mult) for (x, y, s) in sqf]
            val, sql = _sa(init, LL, n, per, rng)
            if val > best_val + 1e-9:
                sql = sorted(sql, key=lambda z: -z[2])[:n]
                best_val = val
                best_list = [((x + s / 2) / LL, (y + s / 2) / LL, s / LL) for (x, y, s) in sql]
    except Exception:
        pass

    best_list = sorted(best_list, key=lambda z: -z[2])[:n]
    out = []
    for (cx, cy, s) in best_list:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, 0.0, s))
    while len(out) < n:
        out.append((0.0, 0.0, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
