import math
from functools import lru_cache

def solve(n):
    """
    Use dynamic programming on guillotine packings with integer coordinates.
    For each rectangle dimension (w, h) and square count m, compute the maximum
    sum of side lengths by either:
    1. Placing a single square and recursing on the remainder
    2. Splitting horizontally or vertically and combining solutions
    """
    
    best_solution = None
    best_sum = 0
    
    # Try different grid resolutions k
    for k in range(1, min(41, n + 5)):
        result = solve_with_k(n, k)
        if result is not None:
            current_sum = sum(s[3] for s in result)
            if current_sum > best_sum:
                best_sum = current_sum
                best_solution = result
    
    if best_solution is None:
        # Fallback
        best_solution = [(0.5, 0.5, 0.0, 0.0)] * n
    
    return best_solution

def solve_with_k(n, k):
    """Solve using grid resolution 1/k."""
    
    # Memoization: (w, h, m) -> (max_sum, list of (x, y, angle, side) in unit coords)
    memo = {}
    
    def dp(w, h, m):
        """
        Compute maximum side-sum for rectangle of size (w/k) x (h/k) using m squares.
        Returns (max_sum, placements) where placements is a list of (x, y, angle, side).
        """
        if m == 0:
            return (0.0, [])
        if w <= 0 or h <= 0:
            return (0.0, [])
        
        key = (w, h, m)
        if key in memo:
            return memo[key]
        
        best_val = 0.0
        best_placements = []
        
        scale = 1.0 / k
        
        # Option 1: Place a square of maximum size that fits, in bottom-left
        max_side_units = min(w, h)
        if max_side_units > 0:
            square_side = max_side_units * scale
            
            # Remaining space after placing square
            remainder_sum = 0.0
            remainder_placements = []
            
            if w > max_side_units or h > max_side_units:
                # We have remainder to fill with m-1 squares
                if w > max_side_units and h > max_side_units:
                    # Can split both ways; try both
                    for split_w in range(max_side_units, w + 1):
                        for split_h in range(max_side_units, h + 1):
                            right_w = w - split_w
                            bottom_h = h - split_h
                            
                            # Try combinations
                            for m1 in range(m):
                                m2 = m - 1 - m1
                                
                                val_right, place_right = dp(right_w, split_h, m1) if right_w > 0 else (0.0, [])
                                val_bottom, place_bottom = dp(split_w, bottom_h, m2) if bottom_h > 0 else (0.0, [])
                                
                                cand_val = square_side + val_right + val_bottom
                                if cand_val > best_val:
                                    best_val = cand_val
                                    # Transform placements to absolute coords
                                    p1 = [(scale * max_side_units * 0.5, scale * split_h * 0.5, 0.0, square_side)]
                                    p2 = [(scale * (max_side_units + x + dx * right_w * scale * 0.5), 
                                           scale * (split_h * 0.5 + y), a, s) 
                                          for x, y, a, s in place_right]
                                    p3 = [(scale * (x + split_w * scale * 0.5), scale * y, a, s) 
                                          for x, y, a, s in place_bottom]
                                    best_placements = p1 + p2 + p3
                else:
                    # Only one direction has remainder
                    if w > max_side_units:
                        right_w = w - max_side_units
                        val_r, place_r = dp(right_w, h, m - 1) if right_w > 0 else (0.0, [])
                        cand = square_side + val_r
                        if cand > best_val:
                            best_val = cand
                            p1 = [(scale * max_side_units * 0.5, scale * h * 0.5, 0.0, square_side)]
                            p2 = [(scale * (max_side_units + x + right_w * scale * 0.5), scale * y, a, s) 
                                  for x, y, a, s in place_r]
                            best_placements = p1 + p2
                    elif h > max_side_units:
                        bottom_h = h - max_side_units
                        val_b, place_b = dp(w, bottom_h, m - 1) if bottom_h > 0 else (0.0, [])
                        cand = square_side + val_b
                        if cand > best_val:
                            best_val = cand
                            p1 = [(scale * w * 0.5, scale * max_side_units * 0.5, 0.0, square_side)]
                            p2 = [(scale * x, scale * (max_side_units + y + bottom_h * scale * 0.5), a, s) 
                                  for x, y, a, s in place_b]
                            best_placements = p1 + p2
            else:
                if square_side > best_val:
                    best_val = square_side
                    best_placements = [(scale * w * 0.5, scale * h * 0.5, 0.0, square_side)]
        
        # Option 2: Split horizontally
        for split_h in range(1, h):
            for m1 in range(m):
                m2 = m - m1
                val1, place1 = dp(w, split_h, m1)
                val2, place2 = dp(w, h - split_h, m2)
                cand = val1 + val2
                if cand > best_val:
                    best_val = cand
                    p1 = [(x, scale * split_h * 0.5 + y, a, s) for x, y, a, s in place1]
                    p2 = [(x, scale * split_h + y, a, s) for x, y, a, s in place2]
                    best_placements = p1 + p2
        
        # Option 3: Split vertically
        for split_w in range(1, w):
            for m1 in range(m):
                m2 = m - m1
                val1, place1 = dp(split_w, h, m1)
                val2, place2 = dp(w - split_w, h, m2)
                cand = val1 + val2
                if cand > best_val:
                    best_val = cand
                    p1 = [(scale * split_w * 0.5 + x, y, a, s) for x, y, a, s in place1]
                    p2 = [(scale * split_w + x, y, a, s) for x, y, a, s in place2]
                    best_placements = p1 + p2
        
        memo[key] = (best_val, best_placements)
        return (best_val, best_placements)
    
    _, placements = dp(k, k, n)
    if len(placements) == n:
        return placements
    return None
