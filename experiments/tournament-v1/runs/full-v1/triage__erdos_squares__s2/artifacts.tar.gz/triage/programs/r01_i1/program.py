import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    
    best_squares = None
    best_sum = -1
    
    # Scan over k (grid size), a (corner merge size), and b (number of 2x2 blocks)
    for k in range(1, min(n + 2, 20)):  # Reasonable upper bound for k
        side = 1.0 / k
        
        # Maximum a is limited by the corner size
        for a in range(0, k + 1):
            # Maximum b is limited by available space
            max_b = (k - a) // 2
            for b in range(0, max_b + 1):
                # Calculate count and sum for this configuration
                count = k * k - (a * a - 1) - 3 * b
                
                if count > n:
                    continue
                
                if count < 0:
                    continue
                
                total_sum = (k * k - a * a + a - 2 * b) / k
                
                # Generate the squares for this configuration
                squares = []
                
                # Add the a×a corner block (merged into one square of side a/k)
                if a > 0:
                    corner_side = a * side
                    corner_pos = corner_side / 2
                    squares.append((corner_pos, corner_pos, 0.0, corner_side))
                
                # Add b 2×2 blocks (each becomes one square of side 2/k)
                block_side = 2 * side
                block_offset = a
                for block_idx in range(b):
                    row = block_idx // ((k - a) // 2)
                    col = block_idx % ((k - a) // 2)
                    x = (block_offset + 2 * col + 1) * side
                    y = (block_offset + 2 * row + 1) * side
                    squares.append((x, y, 0.0, block_side))
                
                # Add remaining 1×1 grid squares
                for i in range(k):
                    for j in range(k):
                        # Skip if in corner block
                        if i < a and j < a:
                            continue
                        # Skip if in 2×2 blocks
                        skip = False
                        if i >= a and j >= a:
                            block_row = (i - a) // 2
                            block_col = (j - a) // 2
                            if (i - a) % 2 == 0 and (j - a) % 2 == 0:
                                if block_row < b and block_col < ((k - a) // 2):
                                    skip = True
                        if not skip:
                            x = (i + 0.5) * side
                            y = (j + 0.5) * side
                            squares.append((x, y, 0.0, side))
                
                # Trim to exactly n squares if needed
                if len(squares) > n:
                    # Sort by side length and remove smallest
                    squares.sort(key=lambda s: s[3])
                    squares = squares[-(n):]
                
                # Add zero-size squares to reach n
                while len(squares) < n:
                    squares.append((0.5, 0.5, 0.0, 0.0))
                
                squares = squares[:n]
                
                # Calculate actual sum
                actual_sum = sum(s[3] for s in squares)
                
                if actual_sum > best_sum:
                    best_sum = actual_sum
                    best_squares = squares
    
    # Fallback: simple grid
    if best_squares is None:
        k = math.isqrt(n)
        side = 1.0 / k
        best_squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) 
                        for i in range(k) for j in range(k)]
        best_squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_squares))
        best_squares = best_squares[:n]
    
    return best_squares
