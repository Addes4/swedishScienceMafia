# EVOLVE-BLOCK-START
import math
import time
import numpy as np


def _dp(L, n, deadline):
    K = n + 1
    NEG = -1e18
    G = np.zeros((L + 1, L + 1, K))
    KD = np.zeros((L + 1, L + 1, K), np.int8)
    CC = np.zeros((L + 1, L + 1, K), np.int32)
    CI = np.zeros((L + 1, L + 1, K), np.int32)
    IDX = np.full((K, K), K, dtype=np.int64)
    for i in range(K):
        for k in range(i, K):
            IDX[i, k] = k - i
    rects = sorted(((a, b) for a in range(1, L + 1) for b in range(a, L + 1)),
                   key=lambda r: r[0] * r[1])
    ar = np.arange(K)
    for cnt, (a, b) in enumerate(rects):
        if (cnt & 63) == 0 and time.time() > deadline:
            return None
        val = np.zeros(K)
        kd = np.zeros(K, np.int8)
        cc = np.zeros(K, np.int32)
        ci = np.zeros(K, np.int32)
        val[1:] = a
        kd[1:] = 1
        tv = np.arange(1, a // 2 + 1)
        th = np.arange(1, b // 2 + 1)
        if len(tv) + len(th) > 0:
            parts1 = []
            parts2 = []
            if len(tv):
                parts1.append(G[tv, b])
                parts2.append(G[a - tv, b])
            if len(th):
                parts1.append(G[a, th])
                parts2.append(G[a, b - th])
            G1 = np.concatenate(parts1, 0)
            G2 = np.concatenate(parts2, 0)
            c = G1.shape[0]
            G2e = np.concatenate([G2, np.full((c, 1), NEG)], 1)
            A = G1[:, :, None] + G2e[:, IDX]
            A = A.reshape(c * K, K)
            arg = A.argmax(0)
            best = A[arg, ar]
            better = best > val + 1e-12
            val = np.where(better, best, val)
            kd = np.where(better, 2, kd).astype(np.int8)
            cc = (arg // K).astype(np.int32)
            ci = (arg % K).astype(np.int32)
        for k in range(1, K):
            if val[k - 1] > val[k] + 1e-12:
                val[k] = val[k - 1]
                kd[k] = 3
        G[a, b] = val
        G[b, a] = val
        KD[a, b] = kd
        CC[a, b] = cc
        CI[a, b] = ci

    out = []

    def place(gx, gy, gw, gh, k):
        if gw <= gh:
            rec(gw, gh, k, gx, gy, False)
        else:
            rec(gh, gw, k, gx, gy, True)

    def rec(a, b, k, X0, Y0, tr):
        while k > 0 and KD[a, b, k] == 3:
            k -= 1
        t = KD[a, b, k]
        if k == 0 or t == 0:
            return
        if t == 1:
            out.append((X0 + a / 2.0, Y0 + a / 2.0, a))
            return
        c = int(CC[a, b, k])
        i = int(CI[a, b, k])
        nv = a // 2
        if c < nv:
            tc = c + 1
            pieces = [(0, 0, tc, b, i), (tc, 0, a - tc, b, k - i)]
        else:
            tc = c - nv + 1
            pieces = [(0, 0, a, tc, i), (0, tc, a, b - tc, k - i)]
        for du, dv, w, h, kk in pieces:
            if kk <= 0:
                continue
            if tr:
                place(X0 + dv, Y0 + du, h, w, kk)
            else:
                place(X0 + du, Y0 + dv, w, h, kk)

    place(0, 0, L, L, n)
    sq = [(x / L, y / L, s / L) for (x, y, s) in out]
    return G[L, L, n] / L, sq


def _geom(X):
    x, y, th, s = X[:, 0], X[:, 1], X[:, 2], X[:, 3]
    ang = 2 * math.pi * th
    c, sn = np.cos(ang), np.sin(ang)
    h = s / 2.0
    loc = np.array([[1, 1], [1, -1], [-1, -1], [-1, 1]], float)
    u = np.stack([c, sn], 1)
    v = np.stack([-sn, c], 1)
    cor = (np.stack([x, y], 1)[:, None, :]
           + (loc[None, :, 0:1] * h[:, None, None]) * u[:, None, :]
           + (loc[None, :, 1:2] * h[:, None, None]) * v[:, None, :])
    axes = np.stack([u, v], 1)
    return cor, axes


def _depths(X, I, J):
    cor, axes = _geom(X)
    ax = np.concatenate([axes[I], axes[J]], 1)  # (P,4,2)
    pI = np.einsum('pad,pcd->pac', ax, cor[I])
    pJ = np.einsum('pad,pcd->pac', ax, cor[J])
    ov = np.minimum(pI.max(2), pJ.max(2)) - np.maximum(pI.min(2), pJ.min(2))
    return ov.min(1), cor


def _penalty(X, I, J):
    d, cor = _depths(X, I, J)
    d = np.maximum(d, 0)
    b = np.maximum(-cor, 0) ** 2 + np.maximum(cor - 1, 0) ** 2
    return (d ** 2).sum() + b.sum()


def _legalize(X, I, J):
    X = X.copy()
    X[:, :2] = np.clip(X[:, :2], 0, 1)
    X[:, 3] = np.clip(X[:, 3], 0, 1)
    ang = 2 * math.pi * X[:, 2]
    ext = np.abs(np.cos(ang)) + np.abs(np.sin(ang))
    lim = 2 * np.minimum.reduce([X[:, 0], 1 - X[:, 0], X[:, 1], 1 - X[:, 1]]) / ext
    X[:, 3] = np.minimum(X[:, 3], lim * (1 - 1e-9))
    for _ in range(3000):
        d, _c = _depths(X, I, J)
        bad = d > -1e-12
        bad &= (X[I, 3] > 0) & (X[J, 3] > 0)
        if not bad.any():
            return X
        idx = np.unique(np.concatenate([I[bad], J[bad]]))
        X[idx, 3] *= 0.999
    return None


def _optimize(base, n, tend):
    from scipy.optimize import minimize
    rng = np.random.default_rng(12345)
    if n < 2:
        return None
    I, J = np.triu_indices(n, 1)
    best_val = base[:, 3].sum()
    best = None
    while time.time() < tend - 1.0:
        X0 = base.copy()
        X0[:, :2] += rng.normal(0, 0.01, (n, 2))
        X0[:, 2] = (X0[:, 2] + rng.normal(0, 0.01, n)) % 0.25
        X0[:, 3] *= 0.97
        z = X0[:, 3] < 1e-9
        X0[z, 0:2] = rng.random((z.sum(), 2))
        X0 = np.clip(X0, 0, 1)
        v = X0.ravel()
        ok = True
        for mu in [10.0, 100.0, 1e3, 1e4, 1e5]:
            if time.time() > tend:
                ok = False
                break
            f = lambda w, mu=mu: -w.reshape(n, 4)[:, 3].sum() + mu * _penalty(w.reshape(n, 4), I, J)
            r = minimize(f, v, method='L-BFGS-B', bounds=[(0, 1)] * (4 * n),
                         options={'maxiter': 150})
            v = r.x
        if not ok:
            break
        Xl = _legalize(v.reshape(n, 4), I, J)
        if Xl is None:
            continue
        val = Xl[:, 3].sum()
        if val > best_val + 1e-9:
            best_val = val
            best = Xl
    return best


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    dp_deadline = t0 + 30.0
    Ls = [1, 2, 3, 4, 6, 8, 12, 24, 36, 48, 60, 72, 84, 120, 144, 168, 180, 240, 360, 420, 504, 720]
    best_val, best_sq = -1.0, None
    prevL, prevT = None, None
    for L in Ls:
        now = time.time()
        if now > dp_deadline:
            break
        if prevL is not None and prevT is not None:
            pred = max(prevT, 1e-3) * (L / prevL) ** 3
            if now + pred > dp_deadline:
                continue
        ts = time.time()
        res = _dp(L, n, dp_deadline)
        te = time.time() - ts
        if res is None:
            break
        prevL, prevT = L, te
        val, sq = res
        if val > best_val + 1e-12:
            best_val, best_sq = val, sq
    if best_sq is None:
        k = math.isqrt(n)
        best_sq = [((i + 0.5) / k, (j + 0.5) / k, 1.0 / k) for i in range(k) for j in range(k)]
    base = [(x, y, 0.0, s) for (x, y, s) in best_sq]
    while len(base) < n:
        base.append((0.5, 0.5, 0.0, 0.0))
    base = base[:n]
    result = [(min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0), 0.0,
               min(max(s * (1 - 1e-9), 0.0), 1.0)) for (x, y, a, s) in base]

    # continuous rotation-aware post-process
    try:
        if 2 <= n <= 40:
            tend = t0 + 52.0
            B = np.array(base, float)
            opt = _optimize(B, n, tend)
            if opt is not None and opt[:, 3].sum() > sum(r[3] for r in result) + 1e-9:
                result = [(float(min(max(a, 0), 1)), float(min(max(b, 0), 1)),
                           float(c % 1.0), float(min(max(d, 0), 1))) for a, b, c, d in opt]
    except Exception:
        pass
    return result
# EVOLVE-BLOCK-END
