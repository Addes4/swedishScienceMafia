# Research notebook: erdos_squares

Ranker `jev`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.856172.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Add a continuous local optimizer with rotation as a post-process. Start from the best combinatorial construction (plus random jitter and zero-size squares place | 0.69 | favourite | opus-5-5 | improved | 1.000000 |
| 4 | Try non-uniform strip constructions. Split the unit square into a top-left big square of side t and two L-shaped bands, then fill each band with a row/column of | 0.65 | favourite | opus-5-5 | improved | 1.000000 |
| 5 | Run a stochastic search (simulated annealing) directly over grid partitions for fixed k. Moves merge four adjacent equal squares into one, split a square into f | 0.58 | middle | opus-5-5 (swapped) | improved | 1.000000 |
| 0 | Replace the plain k×k grid with an exhaustive search over "merged-block" grid tilings: for every grid resolution k from ceil(sqrt(n)) up to about 3·sqrt(n), par | 0.58 | middle | sonnet-5-5 | improved | 1.000000 |
| 1 | Use a closed-form family as a fast candidate generator. Take the k×k grid of side 1/k and merge an a×a corner block plus any number b of disjoint 2×2 blocks, gi | 0.55 | long_shot | haiku-4-5 | invalid | 0.000000 |
| 2 | Do a guillotine dynamic program on rectangles with integer dimensions (w, h) in units of 1/k, for several k up to ~40. Define best[w][h][m] as the maximum side- | 0.53 | long_shot | haiku-4-5 | invalid | 0.000000 |

Best after round 1: **1.000000** (spent $1.08)

