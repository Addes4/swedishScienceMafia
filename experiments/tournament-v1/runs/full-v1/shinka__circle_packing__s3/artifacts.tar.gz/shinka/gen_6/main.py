# EVOLVE-BLOCK-START
"""Multi-start SLSQP followed by basin hopping around the incumbent, with an exact radii LP polish."""
import numpy as np


def _lp_radii(centers):
    """Optimal radii for fixed centres via LP; returns None on failure."""
    from scipy.optimize import linprog
    n = len(centers)
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    if np.any(wall < 0):
        return None
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    A = np.zeros((m, n))
    k = np.arange(m)
    A[k, iu] = 1
    A[k, ju] = 1
    b = np.linalg.norm(centers[iu] - centers[ju], axis=1)
    res = linprog(-np.ones(n), A_ub=A, b_ub=b,
                  bounds=[(0, w) for w in wall], method="highs")
    if not res.success:
        return None
    return np.maximum(res.x - 1e-12, 0.0)


def _optimize(x0, n, iu, ju, maxiter=400):
    from scipy.optimize import minimize
    m = len(iu)
    k = np.arange(m)
    a = np.arange(n)

    def obj(z):
        return -np.sum(z[2 * n:])

    def obj_jac(z):
        g = np.zeros(3 * n)
        g[2 * n:] = -1
        return g

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        s = r[iu] + r[ju]
        pair = dx * dx + dy * dy - s * s
        return np.concatenate([pair, x - r, 1 - x - r, y - r, 1 - y - r])

    def cons_jac(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        s = r[iu] + r[ju]
        J = np.zeros((m + 4 * n, 3 * n))
        J[k, iu] = 2 * dx
        J[k, ju] = -2 * dx
        J[k, n + iu] = 2 * dy
        J[k, n + ju] = -2 * dy
        J[k, 2 * n + iu] = -2 * s
        J[k, 2 * n + ju] = -2 * s
        J[m + a, a] = 1
        J[m + a, 2 * n + a] = -1
        J[m + n + a, a] = -1
        J[m + n + a, 2 * n + a] = -1
        J[m + 2 * n + a, n + a] = 1
        J[m + 2 * n + a, 2 * n + a] = -1
        J[m + 3 * n + a, n + a] = -1
        J[m + 3 * n + a, 2 * n + a] = -1
        return J

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    res = minimize(obj, x0, jac=obj_jac, bounds=bounds, method="SLSQP",
                   constraints=[{"type": "ineq", "fun": cons, "jac": cons_jac}],
                   options={"maxiter": maxiter, "ftol": 1e-12})
    return res.x


def _init(n, rng, k):
    mode = k % 3
    if mode == 0:
        side = int(np.ceil(np.sqrt(n)))
        g = (np.arange(side) + 0.5) / side
        pts = np.array([[a, b] for a in g for b in g])
        pts = pts[rng.permutation(len(pts))[:n]]
        pts = pts + rng.normal(0, 0.03, pts.shape)
    elif mode == 1:
        rows = [5, 5, 5, 5, 6] if n == 26 else None
        if rows is None:
            pts = rng.random((n, 2))
        else:
            rows = list(rng.permutation(rows))
            pts = []
            for ri, c in enumerate(rows):
                yy = (ri + 0.5) / len(rows)
                for ci in range(c):
                    pts.append([(ci + 0.5 + 0.5 * (ri % 2) * 0.5) / (c + 0.25), yy])
            pts = np.array(pts) + rng.normal(0, 0.02, (n, 2))
    else:
        pts = rng.random((n, 2))
    pts = np.clip(pts, 0.03, 0.97)
    r = np.full(n, 0.05)
    return np.concatenate([pts[:, 0], pts[:, 1], r])


def _perturb(c, r, rng):
    n = len(c)
    c = c.copy()
    r = r.copy()
    move = rng.integers(4)
    if move == 0:
        c += rng.normal(0, rng.uniform(0.01, 0.06), c.shape)
    elif move == 1:
        k = rng.integers(1, 4)
        idx = np.argsort(r)[:max(k + 3, 4)]
        idx = rng.choice(idx, size=k, replace=False)
        c[idx] = rng.uniform(0.05, 0.95, (k, 2))
        r[idx] = 0.02
    elif move == 2:
        i, j = rng.choice(n, 2, replace=False)
        c[[i, j]] = c[[j, i]]
        c += rng.normal(0, 0.005, c.shape)
    else:
        i = rng.integers(n)
        d = np.linalg.norm(c - c[i], axis=1)
        idx = np.argsort(d)[:rng.integers(3, 8)]
        c[idx] += rng.normal(0, 0.05, (len(idx), 2))
    c = np.clip(c, 0.02, 0.98)
    r = np.clip(r * 0.8, 0.005, 0.4)
    return np.concatenate([c[:, 0], c[:, 1], r])


def _valid(c, r):
    n = len(c)
    if np.any(r < 0):
        return False
    if np.any(c - r[:, None] < -1e-12) or np.any(c + r[:, None] > 1 + 1e-12):
        return False
    iu, ju = np.triu_indices(n, 1)
    d = np.linalg.norm(c[iu] - c[ju], axis=1)
    return bool(np.all(r[iu] + r[ju] <= d + 1e-12))


def solve(n=26):
    """Multi-start SLSQP then basin hopping, polished by an exact radii LP."""
    import time
    t0 = time.time()
    budget = 200.0
    phase1 = 0.35 * budget
    try:
        iu, ju = np.triu_indices(n, 1)
        rng = np.random.default_rng(0)
        best, best_val = None, -1.0
        k = 0
        while time.time() - t0 < phase1:
            try:
                z = _optimize(_init(n, rng, k), n, iu, ju)
                c = np.clip(np.stack([z[:n], z[n:2 * n]], axis=1), 0.0, 1.0)
                r = _lp_radii(c)
                if r is not None and r.sum() > best_val:
                    best_val, best = r.sum(), (c, r)
            except Exception:
                pass
            k += 1
        # basin hopping
        if best is not None:
            cur = best
            cur_val = best_val
            fails = 0
            while time.time() - t0 < budget:
                try:
                    z0 = _perturb(cur[0], cur[1], rng)
                    z = _optimize(z0, n, iu, ju)
                    c = np.clip(np.stack([z[:n], z[n:2 * n]], axis=1), 0.0, 1.0)
                    r = _lp_radii(c)
                    if r is not None:
                        v = r.sum()
                        if v > best_val + 1e-12:
                            best_val, best = v, (c, r)
                            cur, cur_val = best, best_val
                            fails = 0
                        elif v > cur_val - 0.01 and fails > 40:
                            cur, cur_val = (c, r), v
                            fails = 0
                        else:
                            fails += 1
                    else:
                        fails += 1
                except Exception:
                    fails += 1
                if fails > 80:
                    cur, cur_val = best, best_val
                    fails = 0
        if best is not None and _valid(best[0], best[1]):
            return best[0], best[1]
        if best is not None:
            return best[0], best[1] * (1 - 1e-9)
    except Exception:
        pass
    return _baseline(n)


def _baseline(n=26):
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    centers += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()] for _ in range(n - len(centers))]
    centers = np.clip(np.array(centers[:n]), 0.01, 0.99)
    return centers, max_radii(centers)


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END