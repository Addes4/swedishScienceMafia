# EVOLVE-BLOCK-START
"""Staged search: layout generators -> SLSQP joint optimisation -> basin hopping -> LP radii polish."""
import time
import numpy as np
from scipy.optimize import minimize, linprog


# ---------------------------------------------------------------- layouts
def _random_layout(n, rng):
    return rng.uniform(0.08, 0.92, size=(n, 2))


def _row_layout(n, rng):
    options = [[5, 5, 6, 5, 5], [6, 5, 5, 5, 5], [5, 6, 5, 6, 4], [4, 5, 4, 5, 4, 4],
               [5, 5, 5, 5, 6], [6, 5, 6, 5, 4], [4, 4, 5, 4, 5, 4]]
    while True:
        counts = options[rng.integers(len(options))]
        if sum(counts) == n:
            break
        counts = list(counts)
        diff = n - sum(counts)
        counts[rng.integers(len(counts))] += diff
        if min(counts) > 0:
            break
    k = len(counts)
    pts = []
    for ri, c in enumerate(counts):
        y = (ri + 0.5) / k
        off = 0.0 if rng.random() < 0.5 else 0.3 / c
        for ci in range(c):
            pts.append([(ci + 0.5) / c + (off if ri % 2 else -off) * 0.5, y])
    pts = np.array(pts[:n])
    pts += rng.normal(0, 0.02, pts.shape)
    return np.clip(pts, 0.05, 0.95)


def _ring_layout(n, rng):
    pts = [[0.5, 0.5]]
    n_in = int(rng.integers(5, 9))
    n_out = n - 1 - n_in
    for i in range(n_in):
        a = 2 * np.pi * i / n_in + rng.uniform(0, 0.3)
        pts.append([0.5 + 0.25 * np.cos(a), 0.5 + 0.25 * np.sin(a)])
    for i in range(n_out):
        a = 2 * np.pi * i / n_out + rng.uniform(0, 0.3)
        pts.append([0.5 + 0.42 * np.cos(a), 0.5 + 0.42 * np.sin(a)])
    pts = np.array(pts[:n]) + rng.normal(0, 0.015, (n, 2))
    return np.clip(pts, 0.05, 0.95)


def _initial_layout(n, rng, k):
    gens = [_row_layout, _random_layout, _ring_layout]
    return gens[k % 3](n, rng)


# ---------------------------------------------------------------- optimiser
class _Problem:
    def __init__(self, n):
        self.n = n
        self.I, self.J = np.triu_indices(n, 1)
        m = len(self.I)
        self.m = m
        self.rows = np.arange(m)

    def cons(self, v):
        n = self.n
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        I, J = self.I, self.J
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        s = r[I] + r[J]
        return np.concatenate([dx * dx + dy * dy - s * s, x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(self, v):
        n, m = self.n, self.m
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        I, J, k = self.I, self.J, self.rows
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        s = r[I] + r[J]
        Jm = np.zeros((m + 4 * n, 3 * n))
        Jm[k, I] = 2 * dx
        Jm[k, J] = -2 * dx
        Jm[k, n + I] = 2 * dy
        Jm[k, n + J] = -2 * dy
        Jm[k, 2 * n + I] = -2 * s
        Jm[k, 2 * n + J] = -2 * s
        a = np.arange(n)
        Jm[m + a, a] = 1;          Jm[m + a, 2 * n + a] = -1
        Jm[m + n + a, a] = -1;     Jm[m + n + a, 2 * n + a] = -1
        Jm[m + 2 * n + a, n + a] = 1;  Jm[m + 2 * n + a, 2 * n + a] = -1
        Jm[m + 3 * n + a, n + a] = -1; Jm[m + 3 * n + a, 2 * n + a] = -1
        return Jm

    def solve(self, centers, radii, maxiter=250):
        n = self.n
        v0 = np.concatenate([centers[:, 0], centers[:, 1], radii])
        grad = np.concatenate([np.zeros(2 * n), -np.ones(n)])
        bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
        try:
            res = minimize(lambda v: -v[2 * n:].sum(), v0, jac=lambda v: grad,
                           bounds=bounds, method="SLSQP",
                           constraints=[{"type": "ineq", "fun": self.cons, "jac": self.jac}],
                           options={"maxiter": maxiter, "ftol": 1e-11})
            v = res.x
        except Exception:
            return centers, radii, -1e9
        c = np.stack([v[:n], v[n:2 * n]], axis=1)
        r = v[2 * n:]
        viol = max(0.0, -self.cons(v).min())
        score = r.sum() - 10 * viol
        return c, r, score


# ---------------------------------------------------------------- finalisation
def lp_radii(centers):
    """Optimal radii for fixed centres (exact LP), guaranteed feasible."""
    n = len(centers)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    A = np.zeros((len(I), n))
    A[np.arange(len(I)), I] = 1
    A[np.arange(len(I)), J] = 1
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status == 0:
        r = np.maximum(res.x, 0)
    else:
        r = wall * 0.0
    # safety shrink for strict feasibility
    r = r * (1 - 1e-12)
    for _ in range(5):
        bad = r[I] + r[J] > d
        if not bad.any():
            break
        for i, j in zip(I[bad], J[bad]):
            s = d[(I == i) & (J == j)][0] / (r[i] + r[j])
            r[i] *= s
            r[j] *= s
    return r


# ---------------------------------------------------------------- search
def _perturb(centers, radii, rng):
    c = centers.copy()
    n = len(c)
    mode = rng.integers(3)
    if mode == 0:
        c += rng.normal(0, 0.02, c.shape)
    elif mode == 1:
        k = int(rng.integers(1, 4))
        idx = rng.choice(n, k, replace=False)
        c[idx] = rng.uniform(0.05, 0.95, (k, 2))
    else:
        # relocate smallest circle(s) and jitter others slightly
        idx = np.argsort(radii)[:int(rng.integers(1, 3))]
        c[idx] = rng.uniform(0.05, 0.95, (len(idx), 2))
        c += rng.normal(0, 0.008, c.shape)
    c = np.clip(c, 0.02, 0.98)
    return c


def solve(n=26, time_budget=170.0):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    t0 = time.time()
    rng = np.random.default_rng(12345)
    prob = _Problem(n)

    best = (None, None, -1e9)
    r_init = 0.5 / np.sqrt(n) * 0.8

    # phase 1: multi-start
    phase1_end = t0 + 0.4 * time_budget
    k = 0
    while time.time() < phase1_end:
        c0 = _initial_layout(n, rng, k)
        k += 1
        c, r, s = prob.solve(c0, np.full(n, r_init))
        if s > best[2]:
            best = (c, r, s)

    # phase 2: basin hopping around the best
    cur = best
    while time.time() - t0 < time_budget:
        c0 = _perturb(cur[0], cur[1], rng)
        c, r, s = prob.solve(c0, np.full(n, r_init * 0.7))
        if s > cur[2] - 1e-4 * rng.random():
            cur = (c, r, s)
        if s > best[2]:
            best = (c, r, s)
            cur = best

    centers = np.clip(best[0], 0.0, 1.0)
    radii = lp_radii(centers)
    return centers, radii
# EVOLVE-BLOCK-END
