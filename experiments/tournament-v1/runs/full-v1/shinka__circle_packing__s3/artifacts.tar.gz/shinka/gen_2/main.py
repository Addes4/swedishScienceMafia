# EVOLVE-BLOCK-START
"""Baseline: a centre circle with two rings, radii shrunk until nothing overlaps.
Layout follows the ShinkaEvolve circle_packing example (Apache-2.0)."""
import numpy as np


def _lp_radii(centers):
    """Optimal radii for fixed centres via LP (falls back to greedy shrink)."""
    n = len(centers)
    try:
        from scipy.optimize import linprog
        I, J = np.triu_indices(n, 1)
        d = np.hypot(*(centers[I] - centers[J]).T)
        m = len(I)
        A = np.zeros((m, n))
        A[np.arange(m), I] = 1
        A[np.arange(m), J] = 1
        wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
        wall = np.maximum(wall, 0)
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
        if res.success:
            r = np.maximum(res.x, 0) * (1 - 1e-11)
            return r
    except Exception:
        pass
    return max_radii(centers) * (1 - 1e-11)


def _optimize(v0, n, I, J, minimize):
    m = len(I)
    ar = np.arange(m)
    ia = np.arange(n)

    def fun(v):
        return -np.sum(v[2 * n:])

    def grad(v):
        g = np.zeros(3 * n)
        g[2 * n:] = -1
        return g

    def cons(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        d = np.hypot(x[I] - x[J], y[I] - y[J])
        return np.concatenate([d - r[I] - r[J], x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(v):
        x, y = v[:n], v[n:2 * n]
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        d = np.sqrt(dx * dx + dy * dy) + 1e-14
        Jm = np.zeros((m + 4 * n, 3 * n))
        Jm[ar, I] = dx / d
        Jm[ar, J] = -dx / d
        Jm[ar, n + I] = dy / d
        Jm[ar, n + J] = -dy / d
        Jm[ar, 2 * n + I] = -1
        Jm[ar, 2 * n + J] = -1
        Jm[m + ia, ia] = 1
        Jm[m + ia, 2 * n + ia] = -1
        Jm[m + n + ia, ia] = -1
        Jm[m + n + ia, 2 * n + ia] = -1
        Jm[m + 2 * n + ia, n + ia] = 1
        Jm[m + 2 * n + ia, 2 * n + ia] = -1
        Jm[m + 3 * n + ia, n + ia] = -1
        Jm[m + 3 * n + ia, 2 * n + ia] = -1
        return Jm

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(fun, v0, jac=grad, bounds=bounds, method="SLSQP",
                       constraints=[{"type": "ineq", "fun": cons, "jac": jac}],
                       options={"maxiter": 300, "ftol": 1e-10})
    except Exception:
        return None, -1.0
    v = res.x
    c = np.stack([v[:n], v[n:2 * n]], axis=1)
    c = np.clip(c, 0, 1)
    r = _lp_radii(c)
    return c, float(np.sum(r))


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    t0 = time.time()
    budget = 230.0
    rng = np.random.default_rng(12345)
    try:
        from scipy.optimize import minimize
    except Exception:
        c = np.clip(rng.random((n, 2)), 0.05, 0.95)
        return c, max_radii(c)

    I, J = np.triu_indices(n, 1)
    best_c, best_s = None, -1.0

    def pack(c, r):
        return np.concatenate([c[:, 0], c[:, 1], r])

    it = 0
    while time.time() - t0 < budget:
        it += 1
        if best_c is None or it % 3 == 1 and time.time() - t0 < 0.4 * budget:
            c0 = rng.random((n, 2)) * 0.9 + 0.05
            r0 = np.full(n, 0.03)
        else:
            c0 = best_c.copy()
            mode = rng.random()
            if mode < 0.6:
                k = rng.integers(1, 4)
                idx = rng.choice(n, k, replace=False)
                c0[idx] = rng.random((k, 2)) * 0.9 + 0.05
            else:
                c0 += rng.normal(0, 0.03, c0.shape)
            c0 = np.clip(c0, 0.02, 0.98)
            r0 = np.full(n, 0.03)
        c, s = _optimize(pack(c0, r0), n, I, J, minimize)
        if c is not None and s > best_s:
            best_c, best_s = c, s

    radii = _lp_radii(best_c)
    return best_c, radii


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END