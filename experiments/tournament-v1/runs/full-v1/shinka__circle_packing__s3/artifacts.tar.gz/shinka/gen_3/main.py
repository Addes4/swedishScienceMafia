# EVOLVE-BLOCK-START
"""Baseline: a centre circle with two rings, radii shrunk until nothing overlaps.
Layout follows the ShinkaEvolve circle_packing example (Apache-2.0)."""
import numpy as np


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    centers += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()] for _ in range(n - len(centers))]
    centers = np.clip(np.array(centers[:n]), 0.01, 0.99)
    return centers, max_radii(centers)


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


import time
from scipy.optimize import minimize, linprog


def _layout(n, rng, k):
    mode = k % 3
    if mode == 0:
        options = [[5, 5, 6, 5, 5], [6, 5, 5, 5, 5], [5, 6, 5, 6, 4], [4, 5, 4, 5, 4, 4],
                   [5, 5, 5, 5, 6], [6, 5, 6, 5, 4], [4, 4, 5, 4, 5, 4]]
        counts = options[rng.integers(len(options))]
        counts = [c for c in counts]
        counts[-1] += n - sum(counts)
        kk = len(counts)
        pts = []
        for ri, c in enumerate(counts):
            y = (ri + 0.5) / kk
            for ci in range(c):
                pts.append([(ci + 0.5) / c, y])
        pts = np.array(pts[:n]) + rng.normal(0, 0.02, (n, 2))
    elif mode == 1:
        pts = rng.uniform(0.08, 0.92, size=(n, 2))
    else:
        pts = [[0.5, 0.5]]
        n_in = int(rng.integers(5, 9))
        n_out = n - 1 - n_in
        for i in range(n_in):
            a = 2 * np.pi * i / n_in + rng.uniform(0, 0.3)
            pts.append([0.5 + 0.25 * np.cos(a), 0.5 + 0.25 * np.sin(a)])
        for i in range(n_out):
            a = 2 * np.pi * i / n_out + rng.uniform(0, 0.3)
            pts.append([0.5 + 0.42 * np.cos(a), 0.5 + 0.42 * np.sin(a)])
        pts = np.array(pts[:n]) + rng.normal(0, 0.015, (n, 2))
    return np.clip(pts, 0.05, 0.95)


class _Prob:
    def __init__(self, n):
        self.n = n
        self.I, self.J = np.triu_indices(n, 1)
        self.m = len(self.I)
        self.rows = np.arange(self.m)

    def cons(self, v):
        n = self.n
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        I, J = self.I, self.J
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        s = r[I] + r[J]
        return np.concatenate([dx * dx + dy * dy - s * s, x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(self, v):
        n, m = self.n, self.m
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        I, J, k = self.I, self.J, self.rows
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        s = r[I] + r[J]
        Jm = np.zeros((m + 4 * n, 3 * n))
        Jm[k, I] = 2 * dx
        Jm[k, J] = -2 * dx
        Jm[k, n + I] = 2 * dy
        Jm[k, n + J] = -2 * dy
        Jm[k, 2 * n + I] = -2 * s
        Jm[k, 2 * n + J] = -2 * s
        a = np.arange(n)
        Jm[m + a, a] = 1;              Jm[m + a, 2 * n + a] = -1
        Jm[m + n + a, a] = -1;         Jm[m + n + a, 2 * n + a] = -1
        Jm[m + 2 * n + a, n + a] = 1;  Jm[m + 2 * n + a, 2 * n + a] = -1
        Jm[m + 3 * n + a, n + a] = -1; Jm[m + 3 * n + a, 2 * n + a] = -1
        return Jm

    def run(self, centers, radii, maxiter=200):
        n = self.n
        v0 = np.concatenate([centers[:, 0], centers[:, 1], radii])
        grad = np.concatenate([np.zeros(2 * n), -np.ones(n)])
        bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
        try:
            res = minimize(lambda v: -v[2 * n:].sum(), v0, jac=lambda v: grad,
                           bounds=bounds, method="SLSQP",
                           constraints=[{"type": "ineq", "fun": self.cons, "jac": self.jac}],
                           options={"maxiter": maxiter, "ftol": 1e-11})
            v = res.x
        except Exception:
            return centers, radii, -1e9
        c = np.stack([v[:n], v[n:2 * n]], axis=1)
        r = v[2 * n:]
        viol = max(0.0, -self.cons(v).min())
        return c, r, r.sum() - 10 * viol


def _finalize(centers):
    """LP-optimal radii for fixed centres, then strict feasibility safeguard."""
    n = len(centers)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    wall = np.maximum(np.minimum.reduce([centers[:, 0], centers[:, 1],
                                         1 - centers[:, 0], 1 - centers[:, 1]]), 0)
    A = np.zeros((len(I), n))
    A[np.arange(len(I)), I] = 1
    A[np.arange(len(I)), J] = 1
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
        r = np.maximum(res.x, 0) if res.status == 0 else wall * 0.5
    except Exception:
        r = wall * 0.5
    r = np.minimum(r, wall) * (1 - 1e-10)
    for _ in range(200):
        bad = r[I] + r[J] > d * (1 - 1e-13)
        if not bad.any():
            break
        for i, j in zip(I[bad], J[bad]):
            s = d[(I == i) & (J == j)][0] / (r[i] + r[j]) * (1 - 1e-12)
            if s < 1:
                r[i] *= s
                r[j] *= s
    return r


def _perturb(centers, radii, rng):
    c = centers.copy()
    n = len(c)
    mode = rng.integers(3)
    if mode == 0:
        c += rng.normal(0, 0.02, c.shape)
    elif mode == 1:
        k = int(rng.integers(1, 4))
        idx = rng.choice(n, k, replace=False)
        c[idx] = rng.uniform(0.05, 0.95, (k, 2))
    else:
        idx = np.argsort(radii)[:int(rng.integers(1, 3))]
        c[idx] = rng.uniform(0.05, 0.95, (len(idx), 2))
        c += rng.normal(0, 0.008, c.shape)
    return np.clip(c, 0.02, 0.98)


def solve(n=26, time_budget=110.0):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    t0 = time.time()
    rng = np.random.default_rng(12345)
    prob = _Prob(n)
    r_init = 0.5 / np.sqrt(n) * 0.8
    best = (None, None, -1e9)

    k = 0
    while time.time() - t0 < 0.4 * time_budget or best[0] is None:
        c, r, s = prob.run(_layout(n, rng, k), np.full(n, r_init))
        k += 1
        if s > best[2]:
            best = (c, r, s)

    cur = best
    while time.time() - t0 < time_budget:
        c, r, s = prob.run(_perturb(cur[0], cur[1], rng), np.full(n, r_init * 0.7))
        if s > cur[2] - 1e-4 * rng.random():
            cur = (c, r, s)
        if s > best[2]:
            best = (c, r, s)
            cur = best

    centers = np.clip(best[0], 0.0, 1.0)
    return centers, _finalize(centers)
# EVOLVE-BLOCK-END