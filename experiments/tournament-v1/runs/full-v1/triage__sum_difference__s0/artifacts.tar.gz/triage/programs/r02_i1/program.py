# EVOLVE-BLOCK-START
"""Grid-subset annealing (Freiman-embedded) + tensor powering, with simplex fallback."""
import math
import time
import random
import numpy as np


def _formula_counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for p in range(0, d + 1):
        cp = math.comb(d, p) * math.comb(n, p)
        if cp == 0:
            continue
        for q in range(0, d - p + 1):
            diffs += cp * math.comb(d - p, q) * math.comb(n, q)
    return size, sums, diffs


def _score_counts(size, sums, diffs):
    if size < 2 or sums < 2:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100


def _simplex_points(d, n):
    pts = []

    def rec(prefix, remaining, k):
        if k == d:
            pts.append(tuple(prefix))
            return
        for v in range(remaining + 1):
            prefix.append(v)
            rec(prefix, remaining - v, k + 1)
            prefix.pop()

    rec([], n, 0)
    return pts


def _build(d, n):
    M = 2 * n + 1
    pts = _simplex_points(d, n)
    out = []
    for x in pts:
        v = 0
        for i in range(d):
            v = v * M + x[i]
        out.append(v)
    return sorted(set(out))


def _exact_score(a):
    arr = np.array(sorted(set(a)), dtype=np.int64)
    if len(arr) < 2:
        return 0.0
    s = np.unique((arr[:, None] + arr[None, :]).ravel()).size
    df = np.unique((arr[:, None] - arr[None, :]).ravel()).size
    return math.log(df) / math.log(s) + (1 - 1 / len(arr)) / 100


class _Annealer:
    def __init__(self, d, m, init_vals, cap=4000):
        self.d = d
        self.m = m
        M = 2 * m - 1
        self.M = M
        self.pw = [M ** i for i in range(d)]
        self.maxv = (m - 1) * sum(self.pw)
        L = 2 * self.maxv + 1
        self.cs = np.zeros(L, np.int16)
        self.cd = np.zeros(L, np.int16)
        self.pos = np.full(self.maxv + 1, -1, np.int32)
        self.cap = cap
        self.vals = np.zeros(cap + 5, np.int64)
        self.k = 0
        self.S = 0
        self.Dnz = 0
        for v in init_vals:
            if self.pos[v] < 0 and self.k < cap:
                self.add(int(v))

    def add(self, v):
        k = self.k
        a = self.vals[:k]
        cs, cd, mv = self.cs, self.cd, self.maxv
        idx = v + a
        self.S += int(np.count_nonzero(cs[idx] == 0))
        cs[idx] += 1
        if cs[2 * v] == 0:
            self.S += 1
        cs[2 * v] += 1
        di = v - a + mv
        self.Dnz += 2 * int(np.count_nonzero(cd[di] == 0))
        cd[di] += 1
        cd[2 * mv - di] += 1
        self.vals[k] = v
        self.pos[v] = k
        self.k = k + 1

    def remove(self, v):
        i = int(self.pos[v])
        k = self.k
        last = int(self.vals[k - 1])
        self.vals[i] = last
        self.pos[last] = i
        self.pos[v] = -1
        k -= 1
        self.k = k
        a = self.vals[:k]
        cs, cd, mv = self.cs, self.cd, self.maxv
        idx = v + a
        cs[idx] -= 1
        self.S -= int(np.count_nonzero(cs[idx] == 0))
        cs[2 * v] -= 1
        if cs[2 * v] == 0:
            self.S -= 1
        di = v - a + mv
        cd[di] -= 1
        self.Dnz -= 2 * int(np.count_nonzero(cd[di] == 0))
        cd[2 * mv - di] -= 1

    def add_delta(self, v):
        a = self.vals[:self.k]
        dS = int(np.count_nonzero(self.cs[v + a] == 0)) + (1 if self.cs[2 * v] == 0 else 0)
        dD = 2 * int(np.count_nonzero(self.cd[v - a + self.maxv] == 0))
        return dS, dD

    def rem_delta(self, v):
        a = self.vals[:self.k]
        dS = int(np.count_nonzero(self.cs[v + a] == 1))
        dD = 2 * int(np.count_nonzero(self.cd[v - a + self.maxv] == 1))
        return dS, dD

    def f(self, S=None, D=None):
        if S is None:
            S = self.S
            D = self.Dnz + 1
        if S < 2:
            return 0.0
        return math.log(D) / math.log(S)

    def neighbor(self, p):
        d, m, M, pw = self.d, self.m, self.M, self.pw
        i = random.randrange(d)
        di = (p // pw[i]) % M
        if random.random() < 0.5 or d == 1:
            if random.random() < 0.5:
                if di < m - 1:
                    return p + pw[i]
            else:
                if di > 0:
                    return p - pw[i]
            return None
        j = random.randrange(d)
        if j == i:
            return None
        dj = (p // pw[j]) % M
        if di < m - 1 and dj > 0:
            return p + pw[i] - pw[j]
        return None

    def run(self, budget):
        t_start = time.time()
        # calibrate temperature
        samples = []
        f0 = self.f()
        for _ in range(200):
            if self.k < 4:
                break
            p = int(self.vals[random.randrange(self.k)])
            dS, dD = self.rem_delta(p)
            nf = self.f(self.S - dS, self.Dnz - dD + 1)
            samples.append(abs(nf - f0))
        samples = [s for s in samples if s > 0]
        T0 = 0.3 * float(np.median(samples)) if samples else 1e-4
        T0 = max(T0, 1e-9)
        Tend = T0 * 0.003
        best_f = self.f()
        best_vals = self.vals[:self.k].copy()
        it = 0
        cur = best_f
        T = T0
        while True:
            it += 1
            if (it & 63) == 0:
                el = time.time() - t_start
                if el > budget:
                    break
                T = T0 * (Tend / T0) ** (el / budget)
            k = self.k
            r = random.random()
            if r < 0.3:
                if k <= 4:
                    continue
                p = int(self.vals[random.randrange(k)])
                dS, dD = self.rem_delta(p)
                nf = self.f(self.S - dS, self.Dnz - dD + 1)
                if nf >= cur or random.random() < math.exp((nf - cur) / T):
                    self.remove(p)
                    cur = nf
            elif r < 0.65:
                if k >= self.cap:
                    continue
                p = int(self.vals[random.randrange(k)])
                q = self.neighbor(p)
                if q is None or self.pos[q] >= 0:
                    continue
                dS, dD = self.add_delta(q)
                nf = self.f(self.S + dS, self.Dnz + dD + 1)
                if nf >= cur or random.random() < math.exp((nf - cur) / T):
                    self.add(q)
                    cur = nf
            else:
                if k <= 4:
                    continue
                p = int(self.vals[random.randrange(k)])
                q = self.neighbor(p)
                if q is None or self.pos[q] >= 0:
                    continue
                self.remove(p)
                dS, dD = self.add_delta(q)
                nf = self.f(self.S + dS, self.Dnz + dD + 1)
                if nf >= cur or random.random() < math.exp((nf - cur) / T):
                    self.add(q)
                    cur = nf
                else:
                    self.add(p)
            if cur > best_f + 1e-12:
                best_f = cur
                best_vals = self.vals[:self.k].copy()
        return best_f, sorted(int(x) for x in best_vals)


def _power(B, limit_size=4000, limit_val=10 ** 15):
    B = sorted(B)
    mn = B[0]
    B = [b - mn for b in B]
    W = 2 * B[-1] + 1
    k = 1
    while len(B) ** (k + 1) <= limit_size and W ** (k + 1) <= limit_val // 2:
        k += 1
    A = [0]
    for j in range(k):
        mult = W ** j
        A = [x + b * mult for x in A for b in B]
    return sorted(set(A))


def solve():
    t0 = time.time()
    random.seed(12345)
    # baseline simplex
    cands = []
    for d in range(1, 60):
        n = 1
        while True:
            size = math.comb(n + d, d)
            if size > 4000:
                break
            M = 2 * n + 1
            if n * M ** (d - 1) > 10 ** 15 // 2:
                break
            sz, su, di = _formula_counts(d, n)
            cands.append((_score_counts(sz, su, di), d, n))
            n += 1
    cands.sort(reverse=True)
    _, bd, bn = cands[0]
    baseline = _build(bd, bn)

    # dense-feasible simplex starts
    LIMIT = 2 * 10 ** 7
    dense = []
    for d in range(2, 30):
        for n in range(1, 60):
            if (2 * n + 1) ** d > LIMIT:
                break
            sz = math.comb(n + d, d)
            if sz > 3500 or sz < 6:
                continue
            _, su, di = _formula_counts(d, n)
            dense.append((math.log(di) / math.log(su), d, n))
    dense.sort(reverse=True)

    results = []
    # small grid random searches
    for (d, m) in [(3, 4), (4, 3), (5, 3)]:
        try:
            M = 2 * m - 1
            allv = []
            for idx in range(m ** d):
                v, t = 0, idx
                for i in range(d):
                    v += (t % m) * M ** i
                    t //= m
                allv.append(v)
            init = random.sample(allv, max(5, len(allv) // 3))
            an = _Annealer(d, m, init)
            results.append(an.run(2.5))
        except Exception:
            pass

    picks = dense[:3]
    remaining = 100 - (time.time() - t0)
    per = max(3.0, remaining / max(1, len(picks)) - 1.0)
    for _, d, n in picks:
        if time.time() - t0 > 100:
            break
        try:
            m = n + 1
            M = 2 * m - 1
            pts = _simplex_points(d, n)
            init = []
            for x in pts:
                v = 0
                for i in range(d):
                    v += x[i] * M ** i
                init.append(v)
            an = _Annealer(d, m, init)
            budget = min(per, 105 - (time.time() - t0))
            if budget < 1:
                break
            results.append(an.run(budget))
            del an
        except Exception:
            pass

    best = baseline
    try:
        best_score = _exact_score(baseline)
    except MemoryError:
        best_score = 0.0
    if results:
        results.sort(key=lambda r: r[0], reverse=True)
        bf, B = results[0]
        if bf + 0.0101 > best_score:
            A = _power(B)
            if 2 <= len(A) <= 4000 and max(abs(x) for x in A) <= 10 ** 15:
                try:
                    s = _exact_score(A)
                except MemoryError:
                    s = 0.0
                if s > best_score:
                    best_score = s
                    best = A
    return [int(x) for x in best]
# EVOLVE-BLOCK-END
