# EVOLVE-BLOCK-START
"""Weighted (two-scale) simplex lattice sets Freiman-embedded into Z."""
import math
import time
import numpy as np

LIM = 4000


def _count(ws, n):
    ways = [0] * (n + 1)
    ways[0] = 1
    for w in ws:
        new = [0] * (n + 1)
        for r in range(n + 1):
            if ways[r]:
                for k in range(0, (n - r) // w + 1):
                    new[r + k * w] += ways[r]
        ways = new
        if sum(ways) > 10 ** 7:
            return 10 ** 7
    return sum(ways)


def _build(ws, n):
    M = 2 * n + 1
    vals = np.zeros(1, dtype=np.int64)
    rem = np.full(1, n, dtype=np.int64)
    mult = 1
    for w in ws:
        nv = []
        nr = []
        maxk = n // w
        for k in range(maxk + 1):
            mask = rem >= k * w
            if not mask.any():
                break
            nv.append(vals[mask] + k * mult)
            nr.append(rem[mask] - k * w)
        vals = np.concatenate(nv)
        rem = np.concatenate(nr)
        mult *= M
    return np.unique(vals)


def _score_arr(arr):
    m = len(arr)
    if m < 2:
        return 0.0
    s = np.add.outer(arr, arr).ravel()
    s.sort()
    ns = 1 + int(np.count_nonzero(np.diff(s)))
    del s
    iu = np.triu_indices(m, 1)
    d = (arr[iu[1]] - arr[iu[0]])
    d.sort()
    nd_pos = 1 + int(np.count_nonzero(np.diff(d))) if len(d) else 0
    nd = 2 * nd_pos + 1
    return math.log(nd) / math.log(ns) + (1 - 1 / m) / 100


def _candidates():
    out = []
    for k1 in range(0, 13):
        for k2 in range(0, 8):
            for k3 in range(0, 5):
                d = k1 + k2 + k3
                if d < 1:
                    continue
                ws = [1] * k1 + [2] * k2 + [3] * k3
                for n in range(1, 40):
                    if (k2 and n < 2) or (k3 and n < 3):
                        continue
                    if (2 * n + 1) ** d > 5 * 10 ** 14:
                        break
                    c = _count(ws, n)
                    if c > LIM:
                        break
                    if c >= 30:
                        out.append((c, (k1, k2, k3), n, ws))
    return out


def solve():
    t0 = time.time()
    cands = _candidates()
    small = [c for c in cands if c[0] <= 1200]
    big = [c for c in cands if c[0] > 1200]
    small.sort(key=lambda c: -c[0])
    best = None
    best_s = -1.0
    results = []
    for c, key, n, ws in small:
        if time.time() - t0 > 35:
            break
        arr = _build(ws, n)
        s = _score_arr(arr)
        results.append((s, key))
        if s > best_s:
            best_s = s
            best = arr
    results.sort(reverse=True)
    tops = [k for _, k in results[:3]] or [(1, 0, 0)]

    def dist(c):
        k = c[1]
        return min(sum(abs(a - b) for a, b in zip(k, t)) for t in tops) - c[0] / 1e5

    big.sort(key=dist)
    for c, key, n, ws in big:
        if time.time() - t0 > 105:
            break
        arr = _build(ws, n)
        if len(arr) > LIM or int(np.abs(arr).max()) > 10 ** 15:
            continue
        s = _score_arr(arr)
        if s > best_s:
            best_s = s
            best = arr
    if best is None:
        return [0, 1, 3]
    return [int(x) for x in best]
# EVOLVE-BLOCK-END
