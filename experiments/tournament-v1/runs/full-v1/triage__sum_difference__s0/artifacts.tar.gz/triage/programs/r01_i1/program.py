# EVOLVE-BLOCK-START
"""Simplex lattice construction Freiman-embedded into Z."""
import math
import itertools
import numpy as np


def _formula_counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for p in range(0, d + 1):
        cp = math.comb(d, p) * math.comb(n, p)
        if cp == 0:
            continue
        for q in range(0, d - p + 1):
            diffs += cp * math.comb(d - p, q) * math.comb(n, q)
    return size, sums, diffs


def _score_counts(size, sums, diffs):
    if size < 2 or sums < 2:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100


def _simplex_points(d, n):
    pts = []

    def rec(prefix, remaining, k):
        if k == d:
            pts.append(tuple(prefix))
            return
        for v in range(remaining + 1):
            prefix.append(v)
            rec(prefix, remaining - v, k + 1)
            prefix.pop()

    rec([], n, 0)
    return pts


def _build(d, n):
    M = 2 * n + 1
    pts = _simplex_points(d, n)
    out = []
    for x in pts:
        v = 0
        for i in range(d):
            v = v * M + x[i]
        out.append(v)
    return sorted(set(out))


def _exact_score(a):
    arr = np.array(sorted(set(a)), dtype=np.int64)
    if len(arr) < 2:
        return 0.0
    s = np.unique((arr[:, None] + arr[None, :]).ravel()).size
    df = np.unique((arr[:, None] - arr[None, :]).ravel()).size
    return math.log(df) / math.log(s) + (1 - 1 / len(arr)) / 100


def solve():
    cands = []
    for d in range(1, 60):
        n = 1
        while True:
            size = math.comb(n + d, d)
            if size > 4000:
                break
            M = 2 * n + 1
            # max element approx n * M^(d-1)
            if n * M ** (d - 1) > 10 ** 15 // 2:
                break
            sz, su, di = _formula_counts(d, n)
            cands.append((_score_counts(sz, su, di), d, n))
            n += 1
    cands.sort(reverse=True)
    best = None
    best_score = -1.0
    for sc, d, n in cands[:3]:
        a = _build(d, n)
        if len(a) > 4000 or max(abs(x) for x in a) > 10 ** 15:
            continue
        try:
            s = _exact_score(a)
        except MemoryError:
            s = sc
        if s > best_score:
            best_score = s
            best = a
    if best is None:
        best = [0, 1, 3]
    return best
# EVOLVE-BLOCK-END
