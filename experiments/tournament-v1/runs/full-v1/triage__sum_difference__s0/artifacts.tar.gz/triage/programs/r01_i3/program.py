import math
import time
from collections import defaultdict


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _compute_set_sizes(points):
    """Compute |A+A| and |A-A| for a set of points."""
    diffs = set()
    sums = set()
    for p1 in points:
        for p2 in points:
            diffs.add(tuple(p1[i] - p2[i] for i in range(len(p1))))
            sums.add(tuple(p1[i] + p2[i] for i in range(len(p1))))
    return len(diffs), len(sums)


def _score_removal(points, idx):
    """Score the removal of point at index idx."""
    if len(points) < 2:
        return float('inf')
    
    points_without = points[:idx] + points[idx+1:]
    
    diffs_before, sums_before = _compute_set_sizes(points)
    diffs_after, sums_after = _compute_set_sizes(points_without)
    
    if sums_after == 0 or sums_before == 0:
        return float('inf')
    
    score_before = math.log(diffs_before) / math.log(sums_before)
    score_after = math.log(diffs_after) / math.log(sums_after)
    
    # Return improvement (higher is better)
    return score_after - score_before


def _simplex(dim, scale=10):
    """Generate a d-dimensional simplex scaled by scale."""
    points = []
    for i in range(dim + 1):
        p = [0] * dim
        p[i] = scale
        points.append(tuple(p))
    points.append(tuple([0] * dim))
    return points


def _greedy_prune(points, min_size=6):
    """Greedily prune points by removing those that hurt the score least."""
    points = list(points)
    
    while len(points) > min_size:
        best_idx = -1
        best_score = float('-inf')
        
        # Find the point whose removal gives best score improvement
        for i in range(len(points)):
            score_delta = _score_removal(points, i)
            if score_delta > best_score:
                best_score = score_delta
                best_idx = i
        
        # Remove if it improves or doesn't hurt too much
        if best_idx >= 0 and best_score >= -0.01:
            points.pop(best_idx)
        else:
            break
    
    return points


def _embed_to_integers(points, scale=100):
    """Embed points in Z^d to Z using a random projection or greedy embedding."""
    if not points:
        return []
    
    dim = len(points[0])
    
    # Use a greedy embedding: project onto a random direction with integer coefficients
    # Try several random projections and pick the best
    best_embedding = None
    best_score = -1
    
    for trial in range(min(10, dim + 5)):
        # Generate random direction
        direction = [1] * dim
        for i in range(dim):
            direction[i] = (i + 1) * (trial + 1) % 7 - 3
        
        # Project points
        embedding = []
        for p in points:
            val = sum(p[i] * direction[i] for i in range(dim))
            embedding.append(val * scale)
        
        # Score this embedding
        score = _score(embedding)
        if score > best_score:
            best_score = score
            best_embedding = embedding
    
    return best_embedding if best_embedding else [int(p[0] * scale) for p in points]


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    deadline = time.time() + 115
    best_result = []
    best_score = -1
    
    # Try multiple dimensions and configurations
    for dim in range(2, 8):
        if time.time() > deadline - 5:
            break
        
        for scale in [8, 10, 12, 15]:
            if time.time() > deadline - 5:
                break
            
            # Start with simplex
            points = _simplex(dim, scale)
            
            # Greedy prune
            points = _greedy_prune(points, min_size=max(6, dim + 2))
            
            # Embed to integers
            embedding = _embed_to_integers(points, scale=100)
            
            # Deduplicate and score
            embedding = sorted(set(embedding))
            score = _score(embedding)
            
            if score > best_score:
                best_score = score
                best_result = embedding
    
    # Local search refinement on best result
    if best_result:
        cur = best_result[:]
        cur_score = _score(cur)
        
        while time.time() < deadline:
            improved = False
            
            # Try modifying each element slightly
            for i in range(len(cur)):
                for delta in [-5, -2, -1, 1, 2, 5]:
                    cand = cur[:]
                    cand[i] += delta
                    cand = sorted(set(cand))
                    cand_score = _score(cand)
                    
                    if cand_score > cur_score:
                        cur = cand
                        cur_score = cand_score
                        improved = True
                        break
                
                if improved:
                    break
            
            if not improved:
                break
        
        best_result = cur
    
    return sorted(set(best_result)) if best_result else [0, 1, 2, 3]
