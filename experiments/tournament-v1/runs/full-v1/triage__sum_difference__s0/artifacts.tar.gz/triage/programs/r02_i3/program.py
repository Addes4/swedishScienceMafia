"""Non-generic linear projection of simplex into Z^2/Z^3 with optimized integer matrices."""
import math
import itertools
import numpy as np


def _simplex_points(d, n):
    """Generate all points in d-dimensional simplex with coordinate sum = n."""
    pts = []

    def rec(prefix, remaining, k):
        if k == d:
            pts.append(tuple(prefix))
            return
        for v in range(remaining + 1):
            prefix.append(v)
            rec(prefix, remaining - v, k + 1)
            prefix.pop()

    rec([], n, 0)
    return pts


def _project_and_embed(pts, matrix, base):
    """Project points using integer matrix and embed into Z via base."""
    d = len(matrix)
    embedded = []
    for pt in pts:
        # Project: multiply matrix * point
        proj = tuple(sum(matrix[i][j] * pt[j] for j in range(len(pt))) for i in range(d))
        # Embed into Z using base
        val = 0
        for coord in proj:
            val = val * base + coord
        embedded.append(val)
    return embedded


def _exact_score(a):
    """Compute exact score for set a."""
    arr = np.array(sorted(set(a)), dtype=np.int64)
    if len(arr) < 2:
        return 0.0
    try:
        s = np.unique((arr[:, None] + arr[None, :]).ravel()).size
        df = np.unique((arr[:, None] - arr[None, :]).ravel()).size
        return math.log(df) / math.log(s) + (1 - 1 / len(arr)) / 100
    except:
        return 0.0


def _random_matrix(d_in, d_out, scale=10):
    """Generate random integer matrix."""
    return np.random.randint(-scale, scale + 1, size=(d_out, d_in))


def _hill_climb_matrix(pts, d_in, d_out, base, iterations=100):
    """Hill-climb to find good projection matrix."""
    best_matrix = _random_matrix(d_in, d_out, scale=5)
    best_score = _exact_score(_project_and_embed(pts, best_matrix, base))

    for _ in range(iterations):
        # Random perturbation
        matrix = best_matrix + np.random.randint(-2, 3, size=(d_out, d_in))
        embedded = _project_and_embed(pts, matrix, base)
        embedded_set = sorted(set(embedded))
        if len(embedded_set) > 4000 or max(abs(x) for x in embedded_set) > 1e15:
            continue
        score = _exact_score(embedded_set)
        if score > best_score:
            best_score = score
            best_matrix = matrix

    return best_matrix, best_score


def solve():
    best = None
    best_score = -1.0

    # Try different simplex dimensions and coordinate sums
    for d in range(4, 35):
        for n in range(1, 25):
            size = math.comb(n + d, d)
            if size > 4000 or size < 10:
                continue

            M = 2 * n + 1
            if n * M ** (d - 1) > 1e15:
                continue

            pts = _simplex_points(d, n)

            # Try projections to 2D and 3D
            for d_out in [2, 3]:
                # Random search phase
                for trial in range(20):
                    matrix = _random_matrix(d, d_out, scale=8)
                    embedded = _project_and_embed(pts, matrix, base=M * 2)
                    embedded_set = sorted(set(embedded))

                    if len(embedded_set) > 4000 or (embedded_set and max(abs(x) for x in embedded_set) > 1e15):
                        continue

                    score = _exact_score(embedded_set)
                    if score > best_score:
                        best_score = score
                        best = embedded_set

                # Hill-climb phase on promising cases
                if best_score > 0.8:
                    matrix, score = _hill_climb_matrix(pts, d, d_out, base=M * 2, iterations=50)
                    embedded = _project_and_embed(pts, matrix, base=M * 2)
                    embedded_set = sorted(set(embedded))

                    if len(embedded_set) <= 4000 and (not embedded_set or max(abs(x) for x in embedded_set) <= 1e15):
                        score = _exact_score(embedded_set)
                        if score > best_score:
                            best_score = score
                            best = embedded_set

    # Fallback to simplex lattice
    if best is None or best_score < 0.8:
        M = 11
        pts = _simplex_points(8, 8)
        embedded = []
        for pt in pts:
            v = 0
            for coord in pt:
                v = v * M + coord
            embedded.append(v)
        best = sorted(set(embedded))

    return best if best else [0, 1, 3]
