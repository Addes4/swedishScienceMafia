import math
import random
import time
import itertools
import numpy as np


def _counts(arr):
    a = np.array(sorted(arr), dtype=np.int64)
    if len(a) > 4000:
        return None
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    return d, s


def _score_arr(arr):
    c = _counts(arr)
    n = len(arr)
    if c is None or c[1] < 2 or n < 2:
        return 0.0
    return math.log(c[0]) / math.log(c[1]) + (1 - 1 / n) / 100


def _simplex(d, n):
    pts = []

    def rec(i, rem, cur):
        if i == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()
    rec(0, n, [])
    M = 2 * n + 1
    out = []
    for p in pts:
        v = 0
        m = 1
        for x in p:
            v += x * m
            m *= M
        out.append(v)
    return out


def _small_search(seconds, seed):
    rnd = random.Random(seed)
    best = None
    bs = 0
    deadline = time.time() + seconds
    cur = sorted(rnd.sample(range(0, 25), 6))
    cs = _score_arr(cur)
    best, bs = cur[:], cs
    while time.time() < deadline:
        cand = cur[:]
        r = rnd.random()
        if r < 0.6:
            i = rnd.randrange(len(cand))
            cand[i] = rnd.randint(0, 30)
        elif r < 0.8 and len(cand) < 12:
            cand.append(rnd.randint(0, 30))
        elif len(cand) > 3:
            cand.pop(rnd.randrange(len(cand)))
        cand = sorted(set(cand))
        if len(cand) < 3:
            continue
        sc = _score_arr(cand)
        if sc >= cs or rnd.random() < 0.02:
            cur, cs = cand, sc
            if cs > bs:
                best, bs = cur[:], cs
    mn = min(best)
    return [x - mn for x in best]


def solve():
    t0 = time.time()
    LIM = 4000
    SPAN = 10 ** 15
    lib = []  # (arr, size, logD, logS)

    def add(arr):
        arr = sorted(set(arr))
        if len(arr) < 2 or len(arr) > LIM:
            return
        c = _counts(arr)
        if c is None or c[1] < 2:
            return
        lib.append((arr, len(arr), math.log(c[0]), math.log(c[1])))

    for d in range(1, 14):
        for n in range(1, 60):
            sz = math.comb(n + d, d)
            if sz > LIM:
                break
            if sz < 2:
                continue
            if (2 * n + 1) ** d > SPAN:
                break
            add(_simplex(d, n))
    for sd in range(3):
        try:
            add(_small_search(3, sd))
        except Exception:
            pass

    # prune library: keep by ratio
    lib.sort(key=lambda e: -e[2] / e[3])
    lib = lib[:40] + [e for e in lib[40:] if e[1] >= 200][:20]

    best = {"v": -1, "combo": None}

    def evalv(combo):
        ld = sum(lib[i][2] for i in combo)
        ls = sum(lib[i][3] for i in combo)
        size = 1
        for i in combo:
            size *= lib[i][1]
        return ld / ls + (1 - 1 / size) / 100

    def dfs(start, combo, size, span):
        if combo:
            v = evalv(combo)
            if v > best["v"]:
                best["v"] = v
                best["combo"] = combo[:]
        for i in range(start, len(lib)):
            e = lib[i]
            if size * e[1] > LIM:
                continue
            m = max(e[0]) - min(e[0])
            ns = span * (2 * m + 1)
            if ns > SPAN:
                continue
            combo.append(i)
            dfs(i, combo, size * e[1], ns)
            combo.pop()
            if time.time() - t0 > 60:
                return

    dfs(0, [], 1, 1)

    def build(combo):
        res = [0]
        R = 1
        for i in combo:
            arr = lib[i][0]
            mn = min(arr)
            arr = [x - mn for x in arr]
            m = max(arr)
            res = [r + x * R for r in res for x in arr]
            R *= (2 * m + 1)
        return res

    cands = []
    if best["combo"]:
        cands.append(build(best["combo"]))
    # single best entries as fallback
    if lib:
        cands.append(list(lib[0][0]))
    out = None
    os_ = -1
    for c in cands:
        if max(c) - min(c) > SPAN // 2 or len(set(c)) != len(c):
            continue
        s = _score_arr(c)
        if s > os_:
            os_, out = s, c
    if out is None:
        out = [0, 1, 3]
    return sorted(set(int(x) for x in out))
