# EVOLVE-BLOCK-START
"""Weighted simplex lattice construction Freiman-embedded into Z."""
import math
import time
import numpy as np


def _count(weights, n):
    cnt = [0] * (n + 1)
    cnt[0] = 1
    for w in weights:
        new = [0] * (n + 1)
        for s in range(n + 1):
            if cnt[s]:
                v = 0
                while s + v * w <= n:
                    new[s + v * w] += cnt[s]
                    v += 1
        cnt = new
    return sum(cnt)


def _build(weights, n):
    vals = np.zeros(1, dtype=np.int64)
    rem = np.full(1, n, dtype=np.int64)
    for w in weights:
        m = n // w
        base = 2 * m + 1
        nv = []
        nr = []
        for v in range(m + 1):
            mask = rem >= w * v
            if not mask.any():
                break
            nv.append(vals[mask] * base + v)
            nr.append(rem[mask] - w * v)
        vals = np.concatenate(nv)
        rem = np.concatenate(nr)
    return np.unique(vals)


def _span(weights, n):
    p = 1
    for w in weights:
        p *= 2 * (n // w) + 1
    return p


def _exact_score(arr):
    arr = np.unique(arr)
    N = len(arr)
    if N < 2:
        return 0.0
    sl = []
    dl = []
    B = 300
    for s in range(0, N, B):
        e = min(N, s + B)
        sl.append(np.unique((arr[s:e, None] + arr[None, s:]).ravel()))
        dl.append(np.unique((arr[None, s:] - arr[s:e, None]).ravel()))
    su = np.unique(np.concatenate(sl)).size
    del sl
    u = np.unique(np.concatenate(dl)).size
    df = 2 * (u - 1) + 1
    return math.log(df) / math.log(su) + (1 - 1 / N) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 15):
        per_d = []
        for c3 in range(d + 1):
            for c2 in range(d - c3 + 1):
                c1 = d - c2 - c3
                weights = [1] * c1 + [2] * c2 + [3] * c3
                for n in range(max(weights), 80):
                    if _span(weights, n) > 10 ** 15:
                        break
                    size = _count(weights, n)
                    if size > 4000:
                        break
                    if size >= 1500:
                        per_d.append((size, tuple(weights), n))
        per_d.sort(reverse=True)
        cands.extend(per_d[:3])
        if time.time() - t0 > 25:
            break
    cands.sort(key=lambda t: -t[0])
    # interleave: sizes descending already
    best = None
    best_score = -1.0
    for size, weights, n in cands:
        if time.time() - t0 > 80:
            break
        arr = _build(list(weights), n)
        if len(arr) > 4000 or (len(arr) and int(arr.max()) > 10 ** 15):
            continue
        try:
            s = _exact_score(arr)
        except MemoryError:
            continue
        if s > best_score:
            best_score = s
            best = arr
    if best is None:
        best = _build([1] * 6, 4)
    return [int(x) for x in best]
# EVOLVE-BLOCK-END
