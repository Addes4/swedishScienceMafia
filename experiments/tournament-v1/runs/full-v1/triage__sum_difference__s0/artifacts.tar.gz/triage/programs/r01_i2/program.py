# EVOLVE-BLOCK-START
import math
import random
import time
import itertools
import numpy as np


def _exact_ratio(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    if len(a) < 2:
        return 0.0
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    return math.log(d) / math.log(s)


class _SA:
    def __init__(self, L, init):
        self.L = L
        self.cntS = np.zeros(2 * L + 1, dtype=np.int64)
        self.cntD = np.zeros(2 * L + 1, dtype=np.int64)
        self.cntD[L] = 10 ** 12
        self.inA = np.zeros(L + 1, dtype=bool)
        self.A = np.zeros(4096, dtype=np.int64)
        self.n = 0
        self.nS = 0
        self.nD = 1
        for y in init:
            self.add(int(y))

    def add(self, y):
        n = self.n
        A = self.A
        A[n] = y
        n += 1
        self.n = n
        self.inA[y] = True
        a = A[:n]
        idx = a + y
        cS = self.cntS
        cS[idx] += 1
        self.nS += int(np.count_nonzero(cS[idx] == 1))
        cD = self.cntD
        L = self.L
        d1 = (y + L) - a
        cD[d1] += 1
        self.nD += int(np.count_nonzero(cD[d1] == 1))
        d2 = a + (L - y)
        cD[d2] += 1
        self.nD += int(np.count_nonzero(cD[d2] == 1))

    def remove(self, i):
        n = self.n
        A = self.A
        x = int(A[i])
        a = A[:n]
        idx = a + x
        cS = self.cntS
        cS[idx] -= 1
        self.nS -= int(np.count_nonzero(cS[idx] == 0))
        cD = self.cntD
        L = self.L
        d1 = (x + L) - a
        cD[d1] -= 1
        self.nD -= int(np.count_nonzero(cD[d1] == 0))
        d2 = a + (L - x)
        cD[d2] -= 1
        self.nD -= int(np.count_nonzero(cD[d2] == 0))
        A[i] = A[n - 1]
        self.n = n - 1
        self.inA[x] = False
        return x

    def ratio(self):
        return math.log(self.nD) / math.log(self.nS)

    def elements(self):
        return [int(v) for v in self.A[:self.n]]


def _anneal(L, init, T0, T1, tlimit, nmin=4, nmax=200):
    sa = _SA(L, init)
    cur = sa.ratio()
    best = cur
    best_set = sa.elements()
    t_start = time.time()
    T = T0
    it = 0
    rnd = random.random
    rint = random.randint
    inA = sa.inA
    while True:
        it += 1
        if (it & 255) == 0:
            el = time.time() - t_start
            if el > tlimit:
                break
            frac = el / tlimit
            T = T0 * (T1 / T0) ** frac
        r = rnd()
        n = sa.n
        if r < 0.75 or (r < 0.88 and n >= nmax) or (r >= 0.88 and n <= nmin):
            # move
            i = rint(0, n - 1)
            x = int(sa.A[i])
            if rnd() < 0.5:
                y = x + rint(-3, 3)
                if y < 0 or y > L or inA[y]:
                    continue
            else:
                y = rint(0, L)
                if inA[y]:
                    continue
            sa.remove(i)
            sa.add(y)
            new = sa.ratio()
            d = new - cur
            if d >= 0 or rnd() < math.exp(d / T):
                cur = new
                if cur > best:
                    best = cur
                    best_set = sa.elements()
            else:
                sa.remove(sa.n - 1)
                sa.add(x)
        elif r < 0.88:
            y = rint(0, L)
            if inA[y]:
                continue
            sa.add(y)
            new = sa.ratio()
            d = new - cur
            if d >= 0 or rnd() < math.exp(d / T):
                cur = new
                if cur > best:
                    best = cur
                    best_set = sa.elements()
            else:
                sa.remove(sa.n - 1)
        else:
            i = rint(0, n - 1)
            x = sa.remove(i)
            new = sa.ratio()
            d = new - cur
            if d >= 0 or rnd() < math.exp(d / T):
                cur = new
                if cur > best:
                    best = cur
                    best_set = sa.elements()
            else:
                sa.add(x)
    return best, best_set


def _tensor(base):
    base = sorted(set(base))
    mn = base[0]
    base = [v - mn for v in base]
    m = base[-1]
    n = len(base)
    B = 2 * m + 1
    k = 1
    while True:
        k2 = k + 1
        if n ** k2 > 4000:
            break
        if m * sum(B ** j for j in range(k2)) > 10 ** 15 - 1:
            break
        k = k2
    res = []
    pw = [B ** j for j in range(k)]
    for tup in itertools.product(base, repeat=k):
        res.append(sum(t * p for t, p in zip(tup, pw)))
    return sorted(set(res))


def solve():
    t0 = time.time()
    total = 100.0
    seed_set = [0, 1, 4, 10, 18, 23, 25]
    best_ratio = _exact_ratio(seed_set)
    best_set = seed_set[:]

    # phase 1: random restarts
    while time.time() - t0 < total - 20:
        remain = total - 20 - (time.time() - t0)
        tl = min(8.0, remain)
        if tl < 1.0:
            break
        L = random.choice([40, 60, 80, 120, 160, 250, 400])
        n0 = random.randint(6, min(60, L // 2))
        init = random.sample(range(L + 1), n0)
        T0 = random.choice([0.002, 0.004, 0.008])
        T1 = random.choice([0.0001, 0.0002, 0.0004])
        r, s = _anneal(L, init, T0, T1, tl)
        if r > best_ratio + 1e-12:
            best_ratio, best_set = r, s

    # phase 2: refine best
    remain = total - (time.time() - t0) - 3
    if remain > 1:
        bs = sorted(best_set)
        mn = bs[0]
        bs = [v - mn for v in bs]
        span = bs[-1]
        L = max(span + 20, int(span * 1.3))
        shift = (L - span) // 2
        init = [v + shift for v in bs]
        r, s = _anneal(L, init, 0.0015, 0.00005, remain)
        if r > best_ratio + 1e-12:
            best_ratio, best_set = r, s

    base = sorted(set(best_set))
    # sanity check
    br = _exact_ratio(base)
    try:
        final = _tensor(base)
        if len(final) > 4000 or max(abs(v) for v in final) > 10 ** 15:
            final = base
        else:
            if len(final) <= 2500:
                if abs(_exact_ratio(final) - br) > 1e-9:
                    final = base
    except Exception:
        final = base
    return final
# EVOLVE-BLOCK-END
