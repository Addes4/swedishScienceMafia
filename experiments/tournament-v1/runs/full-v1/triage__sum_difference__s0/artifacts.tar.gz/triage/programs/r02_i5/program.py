"""Simplex lattice construction with annealing on boundary points."""
import math
import itertools
import numpy as np
import time
import random


def _formula_counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for p in range(0, d + 1):
        cp = math.comb(d, p) * math.comb(n, p)
        if cp == 0:
            continue
        for q in range(0, d - p + 1):
            diffs += cp * math.comb(d - p, q) * math.comb(n, q)
    return size, sums, diffs


def _score_counts(size, sums, diffs):
    if size < 2 or sums < 2:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100


def _simplex_points(d, n):
    pts = []

    def rec(prefix, remaining, k):
        if k == d:
            pts.append(tuple(prefix))
            return
        for v in range(remaining + 1):
            prefix.append(v)
            rec(prefix, remaining - v, k + 1)
            prefix.pop()

    rec([], n, 0)
    return pts


def _build(d, n):
    M = 2 * n + 1
    pts = _simplex_points(d, n)
    out = []
    for x in pts:
        v = 0
        for i in range(d):
            v = v * M + x[i]
        out.append(v)
    return sorted(set(out))


def _exact_score(a):
    arr = np.array(sorted(set(a)), dtype=np.int64)
    if len(arr) < 2:
        return 0.0
    s = np.unique((arr[:, None] + arr[None, :]).ravel()).size
    df = np.unique((arr[:, None] - arr[None, :]).ravel()).size
    return math.log(df) / math.log(s) + (1 - 1 / len(arr)) / 100


def _boundary_neighbors(a_set, d, n):
    """Generate neighbor points near the simplex boundary."""
    M = 2 * n + 1
    a_list = sorted(a_set)
    neighbors = set()
    
    # Generate points close to boundary
    pts = _simplex_points(d, n)
    for x in pts:
        # Compute the lattice point value
        v = 0
        for i in range(d):
            v = v * M + x[i]
        if v not in a_set:
            neighbors.add(v)
        
        # Also try slight perturbations
        for i in range(d):
            if x[i] > 0:
                x_mod = list(x)
                x_mod[i] -= 1
                v_mod = 0
                for j in range(d):
                    v_mod = v_mod * M + x_mod[j]
                if v_mod not in a_set:
                    neighbors.add(v_mod)
            
            if x[i] < n:
                x_mod = list(x)
                x_mod[i] += 1
                if sum(x_mod) <= n:
                    v_mod = 0
                    for j in range(d):
                        v_mod = v_mod * M + x_mod[j]
                    if v_mod not in a_set:
                        neighbors.add(v_mod)
    
    return list(neighbors)


def _incremental_score(a_set, a_arr):
    """Fast score computation."""
    if len(a_set) < 2:
        return 0.0
    a_list = sorted(a_set)
    arr = np.array(a_list, dtype=np.int64)
    s = np.unique((arr[:, None] + arr[None, :]).ravel()).size
    df = np.unique((arr[:, None] - arr[None, :]).ravel()).size
    return math.log(df) / math.log(s) + (1 - 1 / len(a_set)) / 100


def _anneal(a_init, time_limit=60):
    """Simulated annealing on the initial set."""
    a = set(a_init)
    best_a = set(a)
    best_score = _incremental_score(a, np.array(sorted(a)))
    
    start_time = time.time()
    temperature = 1.0
    cooling_rate = 0.995
    
    iteration = 0
    while time.time() - start_time < time_limit:
        iteration += 1
        
        # Get boundary neighbors
        d = 3 if len(a) < 100 else (4 if len(a) < 500 else 5)
        n = 10
        neighbors = _boundary_neighbors(a, d, n)
        
        if not neighbors:
            break
        
        # Random move: add or remove
        if len(a) < 3500 and (not neighbors or random.random() < 0.6):
            # Try adding
            candidate = random.choice(neighbors)
            a_new = a | {candidate}
        else:
            # Try removing
            if len(a) > 10:
                candidate = random.choice(list(a))
                a_new = a - {candidate}
            else:
                continue
        
        if len(a_new) > 4000:
            continue
        if max(abs(x) for x in a_new) > 1e15:
            continue
        
        score_new = _incremental_score(a_new, np.array(sorted(a_new)))
        score_old = _incremental_score(a, np.array(sorted(a)))
        
        delta = score_new - score_old
        if delta > 0 or random.random() < math.exp(delta / max(temperature, 0.01)):
            a = a_new
            if score_new > best_score:
                best_score = score_new
                best_a = set(a_new)
        
        temperature *= cooling_rate
        
        if iteration % 100 == 0:
            elapsed = time.time() - start_time
            if elapsed > time_limit * 0.9:
                break
    
    return sorted(best_a)


def solve():
    cands = []
    for d in range(1, 60):
        n = 1
        while True:
            size = math.comb(n + d, d)
            if size > 4000:
                break
            M = 2 * n + 1
            if n * M ** (d - 1) > 10 ** 15 // 2:
                break
            sz, su, di = _formula_counts(d, n)
            cands.append((_score_counts(sz, su, di), d, n))
            n += 1
    cands.sort(reverse=True)
    
    best = None
    best_score = -1.0
    
    # Try top candidates with annealing
    for sc, d, n in cands[:5]:
        a = _build(d, n)
        if len(a) > 4000 or max(abs(x) for x in a) > 10 ** 15:
            continue
        
        # Anneal on this candidate
        time_remaining = 120 - (time.time() - time.time())
        annealed = _anneal(a, time_limit=min(60, time_remaining - 5))
        
        s = _exact_score(annealed)
        if s > best_score:
            best_score = s
            best = annealed
    
    if best is None:
        best = [0, 1, 3]
    return best
