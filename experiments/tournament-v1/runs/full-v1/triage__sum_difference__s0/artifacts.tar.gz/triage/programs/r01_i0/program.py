import math
import time
import numpy as np


def _gen(d, n):
    # all vectors in Z_{>=0}^d with coordinate sum <= n
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for x in range(rem + 1):
            cur.append(x)
            rec(i + 1, rem - x, cur)
            cur.pop()

    rec(0, n, [])
    return res


def _embed(pts, n, d):
    M = 4 * n + 1
    vals = []
    for p in pts:
        v = 0
        for i, x in enumerate(p):
            v += x * M ** i
        vals.append(v)
    return vals


def _score(vals):
    a = np.array(sorted(set(vals)), dtype=np.int64)
    m = len(a)
    if m < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel()).size
    sums = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(diffs) / math.log(sums) + (1 - 1 / m) / 100


def solve():
    start = time.time()
    best = [7, 15, 18, 22, -3, -2]
    best_score = -1.0
    cands = []
    for d in range(2, 12):
        # sizes C(n+d,d) <= 4000
        n = 1
        while math.comb(n + 1 + d, d) <= 4000:
            n += 1
        for nn in (n, n - 1):
            if nn >= 1 and math.comb(nn + d, d) <= 4000:
                cands.append((d, nn))
    # try larger d first? just evaluate all within time
    for d, n in cands:
        if time.time() - start > 100:
            break
        M = 4 * n + 1
        if n * M ** d > 1e15 or M ** d > 5e14:
            continue
        pts = _gen(d, n)
        if len(pts) > 4000 or len(pts) < 2:
            continue
        vals = _embed(pts, n, d)
        if max(abs(v) for v in vals) > 1e15:
            continue
        try:
            s = _score(vals)
        except MemoryError:
            continue
        if s > best_score:
            best_score = s
            best = vals
    return sorted(set(int(v) for v in best))
