import math
import random
import time
import numpy as np
from scipy.spatial import ConvexHull
from itertools import combinations


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def lattice_points_in_polytope(vertices, bounds=1000, max_points=10000):
    """Generate lattice points inside convex hull of vertices."""
    try:
        vertices = np.array(vertices, dtype=float)
        if len(vertices) < 2:
            return []
        
        hull = ConvexHull(vertices)
        
        # Find bounding box
        min_coords = vertices.min(axis=0)
        max_coords = vertices.max(axis=0)
        
        d = len(vertices[0])
        points = []
        
        # Sample lattice points
        ranges = [np.arange(int(np.floor(min_coords[i])), int(np.ceil(max_coords[i])) + 1) 
                  for i in range(d)]
        
        if d == 2:
            for x in ranges[0]:
                for y in ranges[1]:
                    pt = np.array([x, y], dtype=float)
                    if all(np.dot(hull.equations[i, :-1], pt) + hull.equations[i, -1] <= 1e-10 
                           for i in range(len(hull.equations))):
                        points.append(pt)
                        if len(points) >= max_points:
                            return points
        elif d == 3:
            for x in ranges[0]:
                for y in ranges[1]:
                    for z in ranges[2]:
                        pt = np.array([x, y, z], dtype=float)
                        if all(np.dot(hull.equations[i, :-1], pt) + hull.equations[i, -1] <= 1e-10 
                               for i in range(len(hull.equations))):
                            points.append(pt)
                            if len(points) >= max_points:
                                return points
        elif d == 4:
            step = max(1, len(ranges[0]) // 20)
            for x in ranges[0][::step]:
                for y in ranges[1][::step]:
                    for z in ranges[2][::step]:
                        for w in ranges[3][::step]:
                            pt = np.array([x, y, z, w], dtype=float)
                            if all(np.dot(hull.equations[i, :-1], pt) + hull.equations[i, -1] <= 1e-10 
                                   for i in range(len(hull.equations))):
                                points.append(pt)
                                if len(points) >= max_points:
                                    return points
        
        return points
    except:
        return []


def embed_to_1d(points, base=10**15):
    """Embed multi-dimensional points to 1D using a large base."""
    if not points:
        return []
    points = np.array(points, dtype=float)
    d = points.shape[1] if len(points.shape) > 1 else 1
    
    if d == 1:
        return [int(p[0]) for p in points]
    
    # Normalize to small integers
    min_coords = points.min(axis=0)
    points = points - min_coords
    max_coords = points.max(axis=0)
    max_coords[max_coords == 0] = 1
    scale = 100 / max_coords
    points = (points * scale).astype(int)
    
    # Embed using base
    result = []
    base_power = 1
    for i in range(d):
        for p in points:
            if i == 0:
                result.append(0)
            result[-len(points) + points.tolist().index(list(p))] += int(p[i]) * base_power
        base_power *= base
    
    return [int(sum(points[:, i] * (base ** i) for i in range(d))) for _ in range(len(points))]


def perturbed_simplex(d, scale=10):
    """Generate a perturbed d-simplex."""
    vertices = np.eye(d) * scale
    vertices = np.vstack([vertices, np.zeros(d)])
    
    # Add random perturbations
    for _ in range(d):
        perturbation = np.random.randn(d) * scale * 0.2
        vertices = np.vstack([vertices, vertices[0] + perturbation])
    
    return vertices


def solve():
    best_set = []
    best_score = 0.0
    deadline = time.time() + 110
    
    for attempt in range(20):
        if time.time() > deadline:
            break
        
        d = random.randint(2, 4)
        
        if random.random() < 0.5:
            vertices = perturbed_simplex(d, scale=15)
        else:
            # Random polytope
            num_vertices = random.randint(d + 1, 2 * d + 3)
            vertices = np.random.randn(num_vertices, d) * 20
        
        # Lattice points in polytope
        points = lattice_points_in_polytope(vertices, max_points=5000)
        
        if len(points) < 20:
            continue
        
        points = np.array(points)
        
        # Local optimization of vertices
        for opt_iter in range(30):
            if time.time() > deadline:
                break
            
            if len(points) > 4000:
                # Subsample
                idx = np.random.choice(len(points), 4000, replace=False)
                current_points = points[idx]
            else:
                current_points = points
            
            embedded = embed_to_1d(current_points, base=10**15)
            score = _score(embedded)
            
            if score > best_score:
                best_score = score
                best_set = embedded[:]
            
            # Perturb vertices
            if len(vertices) > 0:
                i = random.randint(0, len(vertices) - 1)
                vertices[i] += np.random.randn(d) * 2
                points = np.array(lattice_points_in_polytope(vertices, max_points=5000))
                if len(points) < 20:
                    break
    
    if not best_set:
        best_set = list(range(100))
    
    return sorted(list(set(best_set)))
