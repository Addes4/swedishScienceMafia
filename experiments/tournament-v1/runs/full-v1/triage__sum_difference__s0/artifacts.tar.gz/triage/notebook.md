# Research notebook: sum_difference

Ranker `jev`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.887449.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Simplex lattice construction: take A = {x ∈ Z_{≥0}^d : Σx_i ≤ n} and Freiman-embed it into Z via base M > 4n (x ↦ Σ x_i M^i). A+A is the simplex of size 2n, whi | 0.78 | favourite | opus-5-5 | improved | 0.946948 |
| 2 | Replace the toy search with simulated annealing on sets of 20–200 elements inside [0,L], keeping multiplicity counters for sums and differences. Each add, remov | 0.73 | favourite | opus-5-5 | improved | 0.888561 |
| 5 | Mixed-product construction: instead of a pure tensor power, combine different good base sets per coordinate (e.g., a 1D searched set × a simplex × a small MSTD- | 0.66 | middle | sonnet-5-5 | improved | 0.946948 |
| 0 | Tensor-power amplification: run the local search only to find a strong small base set B (size ~6–20), then output A = {Σ_i b_i·M^i : b_i ∈ B} with M > 4·max/B/. | 0.60 | middle | sonnet-5-5 | improved | 0.946948 |
| 4 | Search for asymmetric convex bodies K in low dimension (d = 2–5) to use as A = K ∩ Z^d. Candidates are perturbed simplices, truncated simplices, or polytopes gi | 0.49 | long_shot | haiku-4-5 | invalid | 0.000000 |
| 3 | Greedy pruning of lattice bodies: start from the d-dimensional simplex (or another convex lattice body) and repeatedly delete the point whose removal shrinks /A | 0.48 | long_shot | haiku-4-5 | invalid | 0.000000 |

Best after round 1: **0.946948** (spent $0.41)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 2 | Deliberately use a "lossy" embedding of the simplex (or the best mixed product) into Z with a base M chosen between n+1 and 4n, or with a modulus wrap. Search o | 0.32 | favourite | opus-5-5 | improved | 0.947080 |
| 1 | Run exhaustive or beam search for the best subset of small multidimensional grids, such as {0..3}^3 or {0..2}^4, scoring each candidate by the exact log/B−B//lo | 0.26 | favourite | opus-5-5 | not_better | 0.946948 |
| 4 | Build two-scale "simplex of simplices" sets A = {b + M·c : (b,c) ∈ S}, where S is itself a simplex-shaped coupling, such as Σ‖b‖ + λ‖c‖ ≤ n, rather than a full  | 0.24 | middle | sonnet-5-5 | not_better | 0.946948 |
| 0 | Replace the uniform simplex with an anisotropic or weighted simplex {x ∈ Z_{≥0}^d : Σ w_i x_i ≤ n}, with integer weights w_i ∈ {1,2,3}. Grid-search over (d, wei | 0.21 | middle | sonnet-5-5 | not_better | 0.942527 |
| 3 | Use a non-generic linear projection of a high-dimensional simplex into Z^2 or Z^3, with small integer projection matrices found by random search or hill-climbin | 0.17 | long_shot | haiku-4-5 | invalid | 0.000000 |
| 5 | Start from the best simplex and anneal on it with moves that add or remove whole lattice points near the boundary. Use incremental multiplicity counters for the | 0.12 | long_shot | haiku-4-5 | invalid | 0.000000 |

Best after round 2: **0.947080** (spent $1.04)

