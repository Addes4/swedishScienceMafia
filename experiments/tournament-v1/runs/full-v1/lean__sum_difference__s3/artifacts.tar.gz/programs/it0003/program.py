# EVOLVE-BLOCK-START
"""Simplex-lattice construction plus search over weighted simplices evaluated by brute force."""
import math
import random
import time
from math import comb, factorial
import numpy as np


def _score_np(a):
    a = np.asarray(a, dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _formula(n, d):
    size = comb(n + d, d)
    s = comb(2 * n + d, d)
    t = 0
    for p in range(0, min(d, n) + 1):
        for q in range(0, min(d - p, n) + 1):
            t += (factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))) * comb(n, p) * comb(n, q)
    return math.log(t) / math.log(s) + (1 - 1 / size) / 100, size


def _build_w(weights, N, limit=4000):
    d = len(weights)
    base = 2 * N + 1
    pts = []

    def rec(i, rem, val):
        if len(pts) > limit:
            return
        if i == d:
            pts.append(val)
            return
        w = weights[i]
        for x in range(rem // w + 1):
            rec(i + 1, rem - w * x, val * base + x)

    rec(0, N, 0)
    if len(pts) > limit:
        return None
    return pts


def _count(weights, N):
    # number of points with sum w_i x_i <= N
    dp = [1] * (N + 1)  # zero variables: any budget -> 1
    for w in weights:
        new = [0] * (N + 1)
        for b in range(N + 1):
            new[b] = sum(dp[b - w * x] for x in range(b // w + 1))
        dp = new
    return dp[N]


def solve():
    t0 = time.time()
    best_f = (0.0, None)
    for n in range(1, 60):
        for d in range(1, 60):
            if comb(n + d, d) > 4000:
                break
            if (2 * n + 1) ** d < 10 ** 15 // 2:
                f, size = _formula(n, d)
                if f > best_f[0]:
                    best_f = (f, (n, d))
    best_set = None
    best_score = 0.0
    if best_f[1] is not None:
        n, d = best_f[1]
        best_set = _build_w([1] * d, n)
        best_score = best_f[0]

    cands = []
    for d in range(2, 15):
        for N in range(1, 9):
            if (2 * N + 1) ** d >= 10 ** 15 // 2:
                continue
            for k2 in range(0, d + 1):
                weights = [1] * (d - k2) + [2] * k2
                if k2 == 0 and False:
                    continue
                try:
                    c = _count(weights, N)
                except Exception:
                    continue
                if 300 <= c <= 4000:
                    cands.append((weights, N, c))
    random.seed(1)
    random.shuffle(cands)
    limit_time = 95
    for weights, N, c in cands:
        el = time.time() - t0
        if el > limit_time:
            break
        est = 2.5 * (c / 4000.0) ** 2 + 0.1
        if el + est > limit_time + 10:
            continue
        pts = _build_w(weights, N)
        if pts is None:
            continue
        try:
            sc = _score_np(pts)
        except MemoryError:
            continue
        if sc > best_score:
            best_score = sc
            best_set = pts
    if best_set is None:
        return [0, 1, 3]
    return sorted(set(int(x) for x in best_set))
# EVOLVE-BLOCK-END
