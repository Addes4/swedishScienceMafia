# EVOLVE-BLOCK-START
"""Truncated-simplex lattice sets {x>=0, x_i<=m, sum x<=n}, chosen by exact DP counting formulas."""
import math
import time
import numpy as np
from math import comb, factorial


def _window(arr, w):
    # new[j] = sum_{k=0..w} arr[j-k]
    c = np.cumsum(arr)
    new = c.copy()
    if w + 1 < len(arr):
        new[w + 1:] -= c[:len(arr) - w - 1]
    return new


def _poly_count(n, d, m):
    arr = np.zeros(n + 1)
    arr[0] = 1.0
    for _ in range(d):
        arr = _window(arr, m)
    return arr.sum()


def _diff_count(n, d, m):
    f = np.zeros((n + 1, n + 1))
    f[0, 0] = 1.0
    for _ in range(d):
        g = f.copy()
        for k in range(1, min(m, n) + 1):
            g[k:, :] += f[:n + 1 - k, :]
            g[:, k:] += f[:, :n + 1 - k]
        f = g
    return f.sum()


def _build(n, d, m):
    base = 2 * m + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(min(m, rem) + 1):
            rec(i + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return pts


def _score(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    t0 = time.time()
    best = (0.0, None)
    for d in range(1, 41):
        for m in range(1, 16):
            if (2 * m + 1) ** d > 5 * 10 ** 14:
                break
            for n in range(1, 31):
                if n > d * m:
                    break
                if n < m:
                    continue  # m > n is same as m = n
                size = _poly_count(n, d, m)
                if size > 4000:
                    break
                if size < 30:
                    continue
                s = _poly_count(2 * n, d, 2 * m)
                t = _diff_count(n, d, m)
                f = math.log(t) / math.log(s) + (1 - 1 / size) / 100
                if f > best[0]:
                    best = (f, (n, d, m))
            if time.time() - t0 > 80:
                break
        if time.time() - t0 > 80:
            break
    if best[1] is None:
        return [0, 1, 3]
    n, d, m = best[1]
    pts = sorted(set(_build(n, d, m)))
    return pts
# EVOLVE-BLOCK-END
