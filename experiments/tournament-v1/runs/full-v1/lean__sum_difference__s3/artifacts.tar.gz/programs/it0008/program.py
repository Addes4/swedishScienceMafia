# EVOLVE-BLOCK-START
"""Simplex-lattice construction (exact formulas) plus simulated annealing in small boxes."""
import math
import random
import time
from math import comb, factorial
import numpy as np


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _formula(n, d):
    size = comb(n + d, d)
    s = comb(2 * n + d, d)
    t = 0
    for p in range(0, min(d, n) + 1):
        for q in range(0, min(d - p, n) + 1):
            t += (factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))) * comb(n, p) * comb(n, q)
    return math.log(t) / math.log(s) + (1 - 1 / size) / 100, size


def _build(n, d):
    base = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return pts


def base_ok(n, d):
    return (2 * n + 1) ** d < 10 ** 15 // 2


def _nsc(arr):
    s = np.unique((arr[:, None] + arr[None, :]).ravel()).size
    d = np.unique((arr[:, None] - arr[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / arr.size) / 100


def _simplex_points(n, d, B):
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return pts


def _anneal(d, m, tlimit, rng):
    B = 4 * m + 2
    # universe
    N = (m + 1) ** d
    uni = []
    for idx in range(N):
        v = 0
        k = idx
        for _ in range(d):
            v = v * B + (k % (m + 1))
            k //= (m + 1)
        uni.append(v)
    uni_arr = uni
    if comb(m + d, d) <= 250:
        cur = set(_simplex_points(m, d, B))
    else:
        cur = set(rng.sample(uni, min(30, N)))
    if len(cur) < 3:
        cur = set(rng.sample(uni, 3))
    cs = _nsc(np.array(sorted(cur), dtype=np.int64))
    best = set(cur)
    bs = cs
    t0 = time.time()
    it = 0
    while True:
        it += 1
        el = time.time() - t0
        if el > tlimit:
            break
        frac = el / tlimit
        temp = 0.004 * (1 - frac) + 0.0002
        r = rng.random()
        cand = set(cur)
        if r < 0.35 or len(cand) <= 4:
            cand.add(rng.choice(uni_arr))
        elif r < 0.65:
            cand.discard(rng.choice(tuple(cand)))
        else:
            cand.discard(rng.choice(tuple(cand)))
            cand.add(rng.choice(uni_arr))
        if len(cand) < 3 or len(cand) > 400 or cand == cur:
            continue
        s = _nsc(np.array(sorted(cand), dtype=np.int64))
        if s >= cs or rng.random() < math.exp((s - cs) / temp):
            cur, cs = cand, s
            if cs > bs:
                best, bs = set(cur), cs
    return bs, sorted(best)


def solve():
    t_start = time.time()
    best_f = (0.0, None)
    for n in range(1, 60):
        for d in range(1, 60):
            if comb(n + d, d) > 4000:
                break
            if comb(n + d, d) < 2:
                continue
            if base_ok(n, d):
                f, size = _formula(n, d)
                if f > best_f[0]:
                    best_f = (f, (n, d))
    cand_simplex = None
    simplex_score = 0.0
    if best_f[1] is not None:
        cand_simplex = _build(*best_f[1])
        simplex_score = best_f[0]

    rng = random.Random(12345)
    configs = [(3, 4), (4, 3), (3, 6), (5, 2), (4, 4), (6, 2), (2, 8), (5, 3)]
    budget = 85.0
    per = budget / len(configs)
    best_sa = (0.0, None)
    for d, m in configs:
        if time.time() - t_start > 100:
            break
        try:
            s, pts = _anneal(d, m, per, rng)
        except Exception:
            continue
        if s > best_sa[0]:
            best_sa = (s, pts)

    if best_sa[1] is not None and best_sa[0] > simplex_score:
        return sorted(set(int(x) for x in best_sa[1]))
    if cand_simplex is not None:
        return sorted(set(cand_simplex))
    return [0, 1, 3]
# EVOLVE-BLOCK-END
