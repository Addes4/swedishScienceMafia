# EVOLVE-BLOCK-START
"""Simplex-lattice construction with random-weight compact embedding, verified by exact counts."""
import math
import random
import time
from math import comb, factorial

import numpy as np


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _fast_score(vals):
    a = np.array(sorted(set(vals)), dtype=np.int64)
    m = len(a)
    if m < 2:
        return 0.0
    ds = []
    ss = []
    for i in range(m):
        ds.append(a[i + 1:] - a[i])
        ss.append(a[i:] + a[i])
    d = np.concatenate(ds)
    d.sort()
    ud = 1 + int(np.count_nonzero(d[1:] != d[:-1])) if len(d) else 0
    s = np.concatenate(ss)
    s.sort()
    us = 1 + int(np.count_nonzero(s[1:] != s[:-1]))
    nd = 2 * ud + 1
    return math.log(nd) / math.log(us) + (1 - 1 / m) / 100


def _formula(n, d):
    size = comb(n + d, d)
    s = comb(2 * n + d, d)
    t = 0
    fd = factorial(d)
    for p in range(0, min(d, n) + 1):
        for q in range(0, min(d - p, n) + 1):
            t += (fd // (factorial(p) * factorial(q) * factorial(d - p - q))) * comb(n, p) * comb(n, q)
    return math.log(t) / math.log(s) + (1 - 1 / size) / 100, size


def _vectors(n, d):
    out = []
    cur = [0] * d

    def rec(i, rem):
        if i == d:
            out.append(tuple(cur))
            return
        for x in range(rem + 1):
            cur[i] = x
            rec(i + 1, rem - x)
        cur[i] = 0

    rec(0, n)
    return out


def _build_exact(n, d):
    base = 2 * n + 1
    res = []
    for v in _vectors(n, d):
        val = 0
        for x in v:
            val = val * base + x
        res.append(val)
    return res


def _build_weights(vecs, n, d, rng):
    W = 10 ** 15 // n - 1
    w = [rng.randint(1, W) for _ in range(d)]
    return sorted(set(sum(x * y for x, y in zip(v, w)) for v in vecs))


def base_ok(n, d):
    return (2 * n + 1) ** d < 10 ** 15 // 2


def solve():
    t0 = time.time()
    cands = []
    for n in range(1, 41):
        for d in range(1, 400):
            if comb(n + d, d) > 4000:
                break
            if comb(n + d, d) < 4:
                continue
            f, size = _formula(n, d)
            cands.append((f, n, d))
    cands.sort(reverse=True)

    best_set = None
    best_val = 0.0
    # exact-encoded fallback
    for f, n, d in cands:
        if base_ok(n, d):
            best_set = sorted(set(_build_exact(n, d)))
            best_val = f
            break
    if best_set is None:
        best_set = [7, 15, 18, 22, -3, -2]
        best_val = _score(best_set)

    rng = random.Random(12345)
    for f, n, d in cands[:6]:
        if f <= best_val:
            break
        if time.time() - t0 > 80:
            break
        vecs = _vectors(n, d)
        for _ in range(2):
            if time.time() - t0 > 90:
                break
            vals = _build_weights(vecs, n, d, rng)
            if len(vals) > 4000 or len(vals) < 2:
                continue
            if max(abs(v) for v in vals) > 10 ** 15:
                continue
            sc = _fast_score(vals)
            if sc > best_val:
                best_val = sc
                best_set = vals
    return [int(x) for x in best_set]
# EVOLVE-BLOCK-END
