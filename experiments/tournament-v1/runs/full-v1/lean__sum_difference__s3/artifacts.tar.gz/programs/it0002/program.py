# EVOLVE-BLOCK-START
"""Simplex-lattice construction (chosen by exact counting formulas) plus incremental local search."""
import math
import random
import time
from math import comb, factorial


def _formula(n, d):
    size = comb(n + d, d)
    s = comb(2 * n + d, d)
    t = 0
    for p in range(0, min(d, n) + 1):
        for q in range(0, min(d - p, n) + 1):
            t += (factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))) * comb(n, p) * comb(n, q)
    return math.log(t) / math.log(s) + (1 - 1 / size) / 100, size


def _build(n, d):
    base = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return pts


def base_ok(n, d):
    return (2 * n + 1) ** d < 10 ** 15 // 2


class _State:
    def __init__(self):
        self.A = []
        self.pos = {}
        self.sums = {}
        self.diffs = {}

    def _upd(self, p, delta):
        sums = self.sums
        diffs = self.diffs
        sg = sums.get
        dg = diffs.get
        for a in self.A:
            s = a + p
            sums[s] = sg(s, 0) + 2 * delta
            if sums[s] == 0:
                del sums[s]
            d1 = a - p
            diffs[d1] = dg(d1, 0) + delta
            if diffs[d1] == 0:
                del diffs[d1]
            d2 = -d1
            diffs[d2] = dg(d2, 0) + delta
            if diffs[d2] == 0:
                del diffs[d2]
        s = 2 * p
        sums[s] = sg(s, 0) + delta
        if sums[s] == 0:
            del sums[s]
        diffs[0] = dg(0, 0) + delta
        if diffs[0] == 0:
            del diffs[0]

    def add(self, p):
        self._upd(p, 1)
        self.pos[p] = len(self.A)
        self.A.append(p)

    def remove(self, p):
        i = self.pos.pop(p)
        last = self.A.pop()
        if last != p:
            self.A[i] = last
            self.pos[last] = i
        self._upd(p, -1)

    def score(self):
        n = len(self.A)
        if n < 2:
            return 0.0
        ls = len(self.sums)
        if ls < 2:
            return 0.0
        return math.log(len(self.diffs)) / math.log(ls) + (1 - 1 / n) / 100


def solve():
    best_f = (0.0, None)
    for n in range(1, 60):
        for d in range(1, 60):
            if comb(n + d, d) > 4000:
                break
            if comb(n + d, d) < 2:
                continue
            if base_ok(n, d):
                f, size = _formula(n, d)
                if f > best_f[0]:
                    best_f = (f, (n, d))
    if best_f[1] is None:
        return [0, 1, 3]
    n, d = best_f[1]
    pts = sorted(set(_build(n, d)))
    base = 2 * n + 1
    units = [base ** k for k in range(d)]

    t0 = time.time()
    deadline = t0 + 95
    st = _State()
    for p in pts:
        st.add(p)
        if time.time() > t0 + 40:
            return pts
    cur = st.score()
    best_score = cur
    best_set = list(st.A)
    LIM = 10 ** 15 - 1
    it = 0
    while True:
        it += 1
        if (it & 15) == 0 and time.time() > deadline:
            break
        r = random.random()
        undo = []
        ok = True
        A = st.A
        if r < 0.4 and len(A) < 4000:
            a = random.choice(A)
            k = random.randrange(d)
            p = a + units[k] * random.choice((1, 1, -1))
            if p in st.pos or abs(p) > LIM:
                continue
            st.add(p)
            undo.append(("r", p))
        elif r < 0.7 and len(A) > 10:
            p = random.choice(A)
            st.remove(p)
            undo.append(("a", p))
        else:
            if len(A) < 10:
                continue
            q = random.choice(A)
            a = random.choice(A)
            k = random.randrange(d)
            p = a + units[k] * random.choice((1, 1, -1))
            if p in st.pos or abs(p) > LIM or p == q:
                continue
            st.remove(q)
            undo.append(("a", q))
            st.add(p)
            undo.append(("r", p))
        sc = st.score()
        if sc >= cur:
            cur = sc
            if sc > best_score:
                best_score = sc
                best_set = list(st.A)
        else:
            for op, p in reversed(undo):
                if op == "r":
                    st.remove(p)
                else:
                    st.add(p)
    return sorted(set(best_set))
# EVOLVE-BLOCK-END
