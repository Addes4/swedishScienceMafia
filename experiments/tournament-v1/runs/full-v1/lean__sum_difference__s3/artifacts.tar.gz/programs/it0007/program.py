# EVOLVE-BLOCK-START
"""Simplex-lattice construction (chosen by exact counting formulas) plus fast numpy toggle local search."""
import math
import random
import time
from math import comb, factorial

import numpy as np


def _formula(n, d):
    size = comb(n + d, d)
    s = comb(2 * n + d, d)
    t = 0
    for p in range(0, min(d, n) + 1):
        for q in range(0, min(d - p, n) + 1):
            t += (factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))) * comb(n, p) * comb(n, q)
    return math.log(t) / math.log(s) + (1 - 1 / size) / 100, size


def _build(n, d):
    base = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return pts


def base_ok(n, d):
    return (2 * n + 1) ** d < 10 ** 15 // 2


def _local_search(pts, tlimit):
    t0 = time.time()
    P = np.array(sorted(set(pts)), dtype=np.int64)
    m = len(P)
    sums = []
    diffs = []
    for i in range(m):
        sums.append(P[i] + P[i:])
        if i + 1 < m:
            diffs.append(P[i + 1:] - P[i])
    allS = np.concatenate(sums)
    del sums
    US, cs = np.unique(allS, return_counts=True)
    del allS
    allD = np.concatenate(diffs)
    del diffs
    UD, cd = np.unique(allD, return_counts=True)
    del allD
    cs = cs.astype(np.int64)
    cd = cd.astype(np.int64)
    S = len(US)
    D = 2 * len(UD) + 1
    mask = np.ones(m, dtype=bool)
    cur = math.log(D) / math.log(S)
    size = m
    while time.time() - t0 < tlimit:
        i = random.randrange(m)
        p = P[i]
        if mask[i]:
            if size <= 3:
                continue
            mask[i] = False
            mem = P[mask]
            ks = np.concatenate((mem + p, np.array([2 * p], dtype=np.int64)))
            kd = np.abs(mem - p)
            isx = np.searchsorted(US, ks)
            idx = np.searchsorted(UD, kd)
            dS = -int((cs[isx] == 1).sum())
            dD = -2 * int((cd[idx] == 1).sum())
            nS, nD = S + dS, D + dD
            if nS > 1 and nD > 1:
                new = math.log(nD) / math.log(nS)
            else:
                new = -1
            if new >= cur:
                cs[isx] -= 1
                cd[idx] -= 1
                S, D, cur = nS, nD, new
                size -= 1
            else:
                mask[i] = True
        else:
            mem = P[mask]
            ks = np.concatenate((mem + p, np.array([2 * p], dtype=np.int64)))
            kd = np.abs(mem - p)
            isx = np.searchsorted(US, ks)
            idx = np.searchsorted(UD, kd)
            dS = int((cs[isx] == 0).sum())
            dD = 2 * int((cd[idx] == 0).sum())
            nS, nD = S + dS, D + dD
            new = math.log(nD) / math.log(nS)
            if new >= cur:
                cs[isx] += 1
                cd[idx] += 1
                S, D, cur = nS, nD, new
                mask[i] = True
                size += 1
    return [int(x) for x in P[mask]]


def solve():
    best_f = (0.0, None)
    for n in range(1, 60):
        for d in range(1, 60):
            if comb(n + d, d) > 4000:
                break
            if comb(n + d, d) < 2:
                continue
            if base_ok(n, d):
                f, size = _formula(n, d)
                if f > best_f[0]:
                    best_f = (f, (n, d))
    if best_f[1] is None:
        return [0, 1, 3]
    simplex = sorted(set(_build(*best_f[1])))
    try:
        res = _local_search(simplex, 85)
        if len(res) >= 2 and len(res) <= 4000:
            return sorted(set(res))
    except Exception:
        pass
    return simplex
# EVOLVE-BLOCK-END
