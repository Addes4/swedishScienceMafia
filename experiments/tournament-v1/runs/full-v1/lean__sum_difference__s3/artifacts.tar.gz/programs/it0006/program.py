# EVOLVE-BLOCK-START
"""Slab-simplex lattice sets {x>=0 : a <= sum x <= b} chosen by exact counting formulas."""
import math
from math import comb, factorial

import numpy as np


def _simplex_formula(n, d):
    size = comb(n + d, d)
    s = comb(2 * n + d, d)
    t = 0
    for p in range(0, min(d, n) + 1):
        for q in range(0, min(d - p, n) + 1):
            t += (factorial(d) // (factorial(p) * factorial(q) * factorial(d - p - q))) * comb(n, p) * comb(n, q)
    return math.log(t) / math.log(s) + (1 - 1 / size) / 100, size


def _W(i, P):
    if i == 0:
        return 1 if P == 0 else 0
    if P < i:
        return 0
    return comb(P - 1, i - 1)


def _slab_counts(a, b, d):
    size = sum(comb(s + d - 1, d - 1) for s in range(a, b + 1))
    sums = sum(comb(s + d - 1, d - 1) for s in range(2 * a, 2 * b + 1))
    tot = 0
    m = min(d, b)
    for i in range(0, m + 1):
        for j in range(0, min(d - i, b) + 1):
            w = comb(d, i) * comb(d - i, j)
            inner = 0
            for P in range(i, b + 1):
                wp = _W(i, P)
                if wp == 0:
                    continue
                for Q in range(j, b + 1):
                    wq = _W(j, Q)
                    if wq == 0:
                        continue
                    if abs(P - Q) <= b - a:
                        inner += wp * wq
            tot += w * inner
    return size, sums, tot


def _build(a, b, d):
    base = 2 * b + 1
    pts = []

    def rec(i, s, val):
        if i == d:
            if s >= a:
                pts.append(val)
            return
        for x in range(b - s + 1):
            rec(i + 1, s + x, val * base + x)

    rec(0, 0, 0)
    return pts


def _exact(pts):
    arr = np.array(sorted(set(pts)), dtype=np.int64)
    sm = np.unique((arr[:, None] + arr[None, :]).ravel())
    df = np.unique((arr[:, None] - arr[None, :]).ravel())
    return math.log(len(df)) / math.log(len(sm)) + (1 - 1 / len(arr)) / 100


def solve():
    LIM = 10 ** 15
    cands = []
    for b in range(1, 45):
        for d in range(1, 120):
            if comb(b + d, d) > 200000:
                break
            if (2 * b + 1) ** d >= LIM:
                break
            for a in range(0, b + 1):
                size = sum(comb(s + d - 1, d - 1) for s in range(a, b + 1))
                if size < 3 or size > 4000:
                    continue
                size, sums, t = _slab_counts(a, b, d)
                if t <= 1 or sums <= 1:
                    continue
                sc = math.log(t) / math.log(sums) + (1 - 1 / size) / 100
                cands.append((sc, a, b, d))
    cands.sort(reverse=True)

    # fallback plain simplex
    fb = None
    fbs = 0.0
    for n in range(1, 45):
        for d in range(1, 120):
            if comb(n + d, d) > 4000:
                break
            if (2 * n + 1) ** d >= LIM:
                break
            sc, _ = _simplex_formula(n, d)
            if sc > fbs:
                fbs, fb = sc, (n, d)
    fb_pts = _build(0, fb[0], fb[1]) if fb else [0, 1]

    best_pts, best_val = None, -1.0
    for sc, a, b, d in cands[:3]:
        try:
            pts = _build(a, b, d)
            if len(pts) > 4000:
                continue
            v = _exact(pts)
        except Exception:
            continue
        if v > best_val:
            best_val, best_pts = v, pts
    try:
        fv = _exact(fb_pts)
    except Exception:
        fv = 0.0
    if best_pts is None or fv >= best_val:
        return sorted(set(fb_pts))
    return sorted(set(best_pts))
# EVOLVE-BLOCK-END
