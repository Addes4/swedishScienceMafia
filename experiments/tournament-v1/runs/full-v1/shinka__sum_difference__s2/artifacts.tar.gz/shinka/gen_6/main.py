# EVOLVE-BLOCK-START
"""Simplex lattice construction refined by simulated annealing in a lattice box."""
import math
import random
import time

import numpy as np


def _simplex_points(d, n, b):
    pts = []

    def rec(pos, rem, val):
        if pos == d:
            pts.append(val)
            return
        w = b ** pos
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return pts


def _params_score(d, n):
    size = math.comb(n + d, d)
    ns = math.comb(2 * n + d, d)
    nd = 0
    for j in range(0, d + 1):
        for k in range(0, d - j + 1):
            nd += (math.comb(d, j) * math.comb(d - j, k)
                   * math.comb(n, j) * math.comb(n, k))
    return math.log(nd) / math.log(ns) + (1 - 1 / size) / 100


def _anneal(d, m, start, tl, seed):
    rnd = random.Random(seed)
    B = 2 * m + 1
    pw = [B ** i for i in range(d)]
    U = B ** d
    off = sum(m * p for p in pw)
    cs = np.zeros(U, dtype=np.int32)
    cd = np.zeros(U, dtype=np.int32)
    mem = np.zeros(U, dtype=bool)
    cap = min((m + 1) ** d, 4000) + 5
    arr = np.zeros(cap, dtype=np.int64)
    st = {"n": 0, "S": 0, "D": 0}

    def add(e):
        n = st["n"]
        q = arr[:n]
        idx = q + e
        st["S"] += int(np.count_nonzero(cs[idx] == 0))
        cs[idx] += 1
        s2 = 2 * e
        if cs[s2] == 0:
            st["S"] += 1
        cs[s2] += 1
        for di in (e - q + off, q - e + off):
            st["D"] += int(np.count_nonzero(cd[di] == 0))
            cd[di] += 1
        if cd[off] == 0:
            st["D"] += 1
        cd[off] += 1
        arr[n] = e
        st["n"] = n + 1
        mem[e] = True

    def remove_pos(pos):
        n = st["n"]
        e = int(arr[pos])
        arr[pos] = arr[n - 1]
        n -= 1
        st["n"] = n
        q = arr[:n]
        idx = q + e
        cs[idx] -= 1
        st["S"] -= int(np.count_nonzero(cs[idx] == 0))
        s2 = 2 * e
        cs[s2] -= 1
        if cs[s2] == 0:
            st["S"] -= 1
        for di in (e - q + off, q - e + off):
            cd[di] -= 1
            st["D"] -= int(np.count_nonzero(cd[di] == 0))
        cd[off] -= 1
        if cd[off] == 0:
            st["D"] -= 1
        mem[e] = False
        return e

    def remove_val(e):
        pos = int(np.flatnonzero(arr[:st["n"]] == e)[0])
        remove_pos(pos)

    def f():
        n = st["n"]
        if n < 2 or st["S"] < 2:
            return 0.0
        return math.log(st["D"]) / math.log(st["S"]) + (1 - 1 / n) / 100

    for e in start:
        add(e)
    cur = f()
    bestf = cur
    best = arr[:st["n"]].copy()
    T0, T1 = 0.004, 0.0002
    t_start = time.time()
    it = 0
    T = T0
    while True:
        it += 1
        if (it & 31) == 1:
            frac = (time.time() - t_start) / tl
            if frac >= 1:
                break
            T = T0 * (T1 / T0) ** frac
        n = st["n"]
        r = rnd.random()
        ops = []  # applied ops for reverting
        ok = True

        def propose():
            if rnd.random() < 0.2:
                e = 0
                for i in range(d):
                    e += rnd.randint(0, m) * pw[i]
                return e
            base = int(arr[rnd.randrange(st["n"])])
            i = rnd.randrange(d)
            dig = (base // pw[i]) % B
            nd = dig + rnd.choice((-1, 1))
            if nd < 0 or nd > m:
                return -1
            return base + (nd - dig) * pw[i]

        if r < 0.3:
            if n >= 4000:
                continue
            e = propose()
            if e < 0 or mem[e]:
                continue
            add(e)
            ops.append(("a", e))
        elif r < 0.5:
            if n <= 6:
                continue
            e = remove_pos(rnd.randrange(n))
            ops.append(("r", e))
        else:
            if n <= 6:
                continue
            e = remove_pos(rnd.randrange(n))
            ops.append(("r", e))
            e2 = propose()
            if e2 < 0 or mem[e2] or e2 == e:
                ok = False
            else:
                add(e2)
                ops.append(("a", e2))
        if ok:
            new = f()
            if new >= cur or rnd.random() < math.exp((new - cur) / T):
                cur = new
                if cur > bestf:
                    bestf = cur
                    best = arr[:st["n"]].copy()
                continue
        # revert
        for kind, e in reversed(ops):
            if kind == "a":
                remove_val(e)
            else:
                add(e)
    return bestf, [int(x) for x in best]


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    t0 = time.time()
    # best large simplex (fallback)
    best_p, best_s = None, -1.0
    for n in range(1, 80):
        for d in range(1, 4000):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            b = 2 * n + 1
            if size < 2 or b ** d > 5 * 10 ** 14:
                continue
            s = _params_score(d, n)
            if s > best_s:
                best_s, best_p = s, (d, n)
    d, n = best_p
    big = sorted(set(_simplex_points(d, n, 2 * n + 1)))

    # candidate starts for annealing
    cands = []
    for dd in range(2, 11):
        for nn in range(1, 9):
            size = math.comb(nn + dd, dd)
            if size < 20 or size > 700:
                continue
            m = nn + 1
            if (2 * m + 1) ** dd > 2 * 10 ** 7:
                continue
            cands.append((_params_score(dd, nn), dd, nn, m))
    cands.sort(reverse=True)
    cands = cands[:4]

    best_val, best_set = best_s, big
    total = 85.0 - (time.time() - t0)
    if cands and total > 5:
        per = total / len(cands)
        for k, (_, dd, nn, m) in enumerate(cands):
            B = 2 * m + 1
            start = _simplex_points(dd, nn, B)
            try:
                val, pts = _anneal(dd, m, start, per, 1234 + k)
            except MemoryError:
                continue
            if val > best_val and len(set(pts)) == len(pts):
                best_val, best_set = val, sorted(set(pts))
    return sorted(set(int(x) for x in best_set))
# EVOLVE-BLOCK-END