# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _simplex_params():
    import numpy as np
    best = None
    t_end = time.time() + 30
    for n in range(1, 31):
        for m in range(1, n + 1):
            if time.time() > t_end:
                return best
            B = 2 * m + 1
            f = np.zeros(n + 1, dtype=np.int64)
            f[0] = 1
            g = np.zeros(2 * n + 1, dtype=np.int64)
            g[0] = 1
            D = np.zeros((n + 1, n + 1), dtype=np.int64)
            D[0, 0] = 1
            for d in range(1, 80):
                if B ** d > 5 * 10 ** 14:
                    break
                nf = f.copy()
                for k in range(1, min(m, n) + 1):
                    nf[k:] += f[:n + 1 - k]
                ng = g.copy()
                for k in range(1, min(2 * m, 2 * n) + 1):
                    ng[k:] += g[:2 * n + 1 - k]
                nD = D.copy()
                for k in range(1, min(m, n) + 1):
                    nD[k:, :] += D[:n + 1 - k, :]
                    nD[:, k:] += D[:, :n + 1 - k]
                f, g, D = nf, ng, nD
                size = int(f.sum())
                if size > 4000:
                    break
                sums = int(g.sum())
                diffs = int(D.sum())
                if sums < 2 or size < 2:
                    continue
                sc = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
                if best is None or sc > best[0]:
                    best = (sc, d, n, m)
    return best


def _simplex_set(d, n, m=None):
    if m is None:
        m = n
    B = 2 * m + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        w = B ** i
        for x in range(min(rem, m) + 1):
            rec(i + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return pts


def _stats(n, ms, max_size=4000, max_mag=4 * 10 ** 14):
    import numpy as np
    mag = 1
    for m in ms:
        mag *= 2 * min(m, n) + 1
        if mag > max_mag:
            return None
    f = np.zeros(n + 1, dtype=np.int64)
    f[0] = 1
    g = np.zeros(2 * n + 1, dtype=np.int64)
    g[0] = 1
    D = np.zeros((n + 1, n + 1), dtype=np.int64)
    D[0, 0] = 1
    for m in ms:
        m = min(m, n)
        nf = f.copy()
        for k in range(1, m + 1):
            nf[k:] += f[:n + 1 - k]
        f = nf
        if int(f.sum()) > max_size:
            return None
        ng = g.copy()
        for k in range(1, min(2 * m, 2 * n) + 1):
            ng[k:] += g[:2 * n + 1 - k]
        g = ng
        nD = D.copy()
        for k in range(1, m + 1):
            nD[k:, :] += D[:n + 1 - k, :]
            nD[:, k:] += D[:, :n + 1 - k]
        D = nD
    size = int(f.sum())
    sums = int(g.sum())
    diffs = int(D.sum())
    if size < 2 or sums < 2 or size > max_size:
        return None
    return math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100


def _refine(n, ms, tlimit):
    cur_n, cur = n, list(ms)
    cur_sc = _stats(cur_n, cur)
    best = (cur_sc, cur_n, list(cur))
    t_end = time.time() + tlimit
    while time.time() < t_end:
        nn, nm = cur_n, list(cur)
        r = random.random()
        if r < 0.5:
            i = random.randrange(len(nm))
            nm[i] = max(1, min(nn, nm[i]) + random.choice((-1, 1)))
        elif r < 0.62:
            nn = max(1, nn + random.choice((-1, 1)))
        elif r < 0.78:
            nm.append(random.randint(1, nn))
        elif r < 0.9:
            if len(nm) > 1:
                nm.pop(random.randrange(len(nm)))
        else:
            i = random.randrange(len(nm))
            j = random.randrange(len(nm))
            nm[i] = max(1, min(nn, nm[i]) + 1)
            nm[j] = max(1, min(nn, nm[j]) - 1)
        sc = _stats(nn, nm)
        if sc is None:
            continue
        if sc >= cur_sc or random.random() < 0.01:
            cur_n, cur, cur_sc = nn, nm, sc
            if sc > best[0]:
                best = (sc, nn, list(nm))
    return best


def _general_set(n, ms):
    ms = [min(m, n) for m in ms]
    ws = []
    w = 1
    for m in ms:
        ws.append(w)
        w *= 2 * m + 1
    d = len(ms)
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(min(rem, ms[i]) + 1):
            rec(i + 1, rem - x, val + x * ws[i])

    rec(0, n, 0)
    return pts


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    try:
        p = _simplex_params()
        if p is not None:
            base = sorted(set(_simplex_set(p[1], p[2], p[3])))
            try:
                ms0 = [p[3]] * p[1]
                sc0 = _stats(p[2], ms0)
                if sc0 is not None:
                    sc, n1, ms1 = _refine(p[2], ms0, 40)
                    if sc > sc0 + 1e-12:
                        cand = sorted(set(_general_set(n1, ms1)))
                        if len(cand) <= 4000 and max(abs(x) for x in cand) <= 10 ** 15:
                            return cand
            except Exception:
                pass
            return base
    except Exception:
        pass
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    cur = best[:]
    deadline = time.time() + 5
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-3, 3)
        if random.random() < 0.05:
            cand.append(random.randint(1, 20))
        if random.random() < 0.03 and len(cand) > 5:
            cand = cand[1:]
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.1:
            cur = best[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END