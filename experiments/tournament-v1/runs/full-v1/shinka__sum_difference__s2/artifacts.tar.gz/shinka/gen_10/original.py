# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    def params_score(d, n):
        size = math.comb(n + d, d)
        ns = math.comb(2 * n + d, d)
        nd = 0
        for j in range(0, d + 1):
            for k in range(0, d - j + 1):
                nd += (math.comb(d, j) * math.comb(d - j, k)
                       * math.comb(n, j) * math.comb(n, k))
        return math.log(nd) / math.log(ns) + (1 - 1 / size) / 100

    best_p, best_s = None, -1.0
    for n in range(1, 80):
        for d in range(1, 4000):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            b = 2 * n + 1
            if size < 2 or b ** d > 5 * 10 ** 14:
                continue
            s = params_score(d, n)
            if s > best_s:
                best_s, best_p = s, (d, n)
    d, n = best_p
    b = 2 * n + 1

    pts = []

    def rec(pos, rem, val):
        if pos == d:
            pts.append(val)
            return
        w = b ** pos
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return sorted(set(pts))
# EVOLVE-BLOCK-END