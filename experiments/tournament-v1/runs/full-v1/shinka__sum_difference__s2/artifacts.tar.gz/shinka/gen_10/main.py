# EVOLVE-BLOCK-START
"""Simplex lattice family with per-coordinate caps, searched with exact scoring."""
import math
import random
import time

import numpy as np


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _np_score(pts):
    a = np.array(sorted(pts), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    S = None
    D = None
    step = 128
    for i in range(0, n, step):
        blk = a[i:i + step]
        s = np.unique((blk[:, None] + a[None, :]).ravel())
        dd = np.unique((blk[:, None] - a[None, :]).ravel())
        S = s if S is None else np.unique(np.concatenate((S, s)))
        D = dd if D is None else np.unique(np.concatenate((D, dd)))
    return math.log(len(D)) / math.log(len(S)) + (1 - 1 / n) / 100


def _gen(d, n, L, b):
    pts = []
    pw = [b ** i for i in range(d)]

    def rec(pos, rem, val):
        if pos == d:
            pts.append(val)
            return
        w = pw[pos]
        for x in range(min(rem, L) + 1):
            rec(pos + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return pts


def _size(d, n, L):
    ways = [1] + [0] * n
    for _ in range(d):
        new = [0] * (n + 1)
        for s in range(n + 1):
            if ways[s]:
                for x in range(min(L, n - s) + 1):
                    new[s + x] += ways[s]
        ways = new
    return sum(ways)


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    t0 = time.time()

    def params_score(d, n):
        size = math.comb(n + d, d)
        ns = math.comb(2 * n + d, d)
        nd = 0
        for j in range(0, min(d, n) + 1):
            for k in range(0, min(d - j, n) + 1):
                nd += (math.comb(d, j) * math.comb(d - j, k)
                       * math.comb(n, j) * math.comb(n, k))
        return math.log(nd) / math.log(ns) + (1 - 1 / size) / 100

    best_p, best_s = None, -1.0
    for n in range(1, 80):
        for d in range(1, 4000):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            b = 2 * n + 1
            if size < 2 or b ** d > 5 * 10 ** 14:
                continue
            s = params_score(d, n)
            if s > best_s:
                best_s, best_p = s, (d, n)
    d0, n0 = best_p
    b0 = 2 * n0 + 1
    best_set = sorted(set(_gen(d0, n0, n0, b0)))
    best_val = best_s

    # variant family: caps per coordinate
    cands = []
    for n in range(2, 16):
        for L in range(1, n + 1):
            b = 2 * L + 1
            for d in range(2, 70):
                if b ** d > 5 * 10 ** 14:
                    break
                if L == n and (d, n) == (d0, n0):
                    continue
                sz = _size(d, n, L)
                if sz > 4000:
                    break
                if sz < 1000:
                    continue
                key = abs(n - n0) + 0.3 * abs(d - d0) + 0.3 * (n - L)
                cands.append((key, d, n, L))
    cands.sort()
    for key, d, n, L in cands:
        if time.time() - t0 > 85:
            break
        b = 2 * L + 1
        try:
            pts = sorted(set(_gen(d, n, L, b)))
            if len(pts) > 4000 or max(pts) * 2 > 10 ** 15:
                continue
            v = _np_score(pts)
        except MemoryError:
            continue
        if v > best_val + 1e-12:
            best_val, best_set = v, pts
    return sorted(set(int(x) for x in best_set))
# EVOLVE-BLOCK-END