# EVOLVE-BLOCK-START
"""Hill climbing over weighted/truncated simplex families with exact evaluation."""
import math
import random
import time

import numpy as np

MAXN = 4000
LIM = 2 * 10 ** 15


def _params_score(d, n):
    size = math.comb(n + d, d)
    ns = math.comb(2 * n + d, d)
    nd = 0
    for j in range(0, d + 1):
        for k in range(0, d - j + 1):
            nd += (math.comb(d, j) * math.comb(d - j, k)
                   * math.comb(n, j) * math.comb(n, k))
    return math.log(nd) / math.log(ns) + (1 - 1 / size) / 100


def _build(w, c, N):
    prod = 1
    for ci in c:
        prod *= (2 * ci + 1)
    if prod > LIM:
        return None
    pts = np.zeros(1, dtype=np.int64)
    ws = np.zeros(1, dtype=np.int64)
    R = 1
    for wi, ci in zip(w, c):
        pp = []
        ww = []
        for x in range(ci + 1):
            w2 = ws + wi * x
            mask = w2 <= N
            if not mask.any():
                break
            pp.append(pts[mask] + x * R)
            ww.append(w2[mask])
        pts = np.concatenate(pp)
        ws = np.concatenate(ww)
        if len(pts) > MAXN:
            return None
        R *= (2 * ci + 1)
    return pts


def _eval(pts):
    a = np.sort(pts)
    n = len(a)
    if n < 3:
        return -1.0
    sums = np.empty(n * (n + 1) // 2, dtype=np.int64)
    p = 0
    for i in range(n):
        k = n - i
        sums[p:p + k] = a[i:] + a[i]
        p += k
    sums.sort()
    S = 1 + int(np.count_nonzero(sums[1:] != sums[:-1]))
    del sums
    df = np.empty(n * (n - 1) // 2, dtype=np.int64)
    p = 0
    for i in range(n - 1):
        k = n - 1 - i
        df[p:p + k] = a[i + 1:] - a[i]
        p += k
    df.sort()
    u = 1 + int(np.count_nonzero(df[1:] != df[:-1]))
    D = 2 * u + 1
    if S < 2:
        return -1.0
    return math.log(D) / math.log(S) + (1 - 1 / n) / 100


def _mutate(w, c, N, rnd):
    w = list(w)
    c = list(c)
    for _ in range(rnd.choice((1, 1, 2))):
        r = rnd.random()
        d = len(w)
        if r < 0.2:
            N = max(1, N + rnd.choice((-1, 1)))
        elif r < 0.45:
            i = rnd.randrange(d)
            w[i] = max(1, min(5, w[i] + rnd.choice((-1, 1))))
        elif r < 0.7:
            i = rnd.randrange(d)
            c[i] = max(1, c[i] + rnd.choice((-1, 1)))
        elif r < 0.85:
            w.append(rnd.choice((1, 1, 2)))
            c.append(max(1, min(N, rnd.randint(1, max(1, N)))))
        else:
            if d > 2:
                i = rnd.randrange(d)
                del w[i]
                del c[i]
    c = [min(ci, N) for ci in c]
    return w, c, N


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    t0 = time.time()
    budget = 88.0
    rnd = random.Random(12345)

    best_p, best_s = None, -1.0
    for n in range(1, 80):
        for d in range(1, 4000):
            size = math.comb(n + d, d)
            if size > MAXN:
                break
            if size < 2 or (2 * n + 1) ** d > 5 * 10 ** 14:
                continue
            s = _params_score(d, n)
            if s > best_s:
                best_s, best_p = s, (d, n)
    d, n = best_p
    w = [1] * d
    c = [n] * d
    N = n
    pts = _build(w, c, N)
    cur = _eval(pts)
    best = cur
    best_pts = pts.copy()
    cw, cc, cN = w, c, N
    seen = {}
    last_eval = time.time() - t0
    while True:
        el = time.time() - t0
        if el + 3.0 > budget:
            break
        nw, nc, nN = _mutate(cw, cc, cN, rnd)
        key = (tuple(nw), tuple(nc), nN)
        if key in seen:
            continue
        seen[key] = 1
        p = _build(nw, nc, nN)
        if p is None or len(p) < 3:
            continue
        s = _eval(p)
        if s >= cur:
            cur = s
            cw, cc, cN = nw, nc, nN
            if s > best:
                best = s
                best_pts = p.copy()
    res = sorted(set(int(x) for x in best_pts))
    return res
# EVOLVE-BLOCK-END