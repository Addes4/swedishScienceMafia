# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    from math import comb, factorial

    def counts(d, n):
        s = comb(2 * n + d, d)
        t = 0
        for i in range(0, min(d, n) + 1):
            for j in range(0, min(d - i, n) + 1):
                t += (factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))
                      * comb(n, i) * comb(n, j))
        return t, s

    bestp = None
    bestv = -1
    for d in range(1, 40):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * (B ** d - 1) // (B - 1) > 10 ** 15:
                continue
            t, s = counts(d, n)
            v = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if v > bestv:
                bestv, bestp = v, (d, n)
    d, n = bestp
    B = 2 * n + 1
    pts = []

    def gen(prefix, left, k):
        if k == 0:
            pts.append(prefix)
            return
        for v in range(left + 1):
            gen(prefix + [v], left - v, k - 1)

    gen([], n, d)
    simplex = [sum(c * B ** i for i, c in enumerate(p)) for p in pts]
    best = simplex
    best_score = _score(best)
    cur = best[:]
    deadline = time.time() + 0
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-3, 3)
        if random.random() < 0.05:
            cand.append(random.randint(1, 20))
        if random.random() < 0.03 and len(cand) > 5:
            cand = cand[1:]
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.1:
            cur = best[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END