# EVOLVE-BLOCK-START
"""Simplex construction refined by exact incremental simulated annealing."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _simplex_params(max_size=4000, margin=0):
    from math import comb, factorial
    best = None
    for d in range(1, 40):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > max_size:
                break
            B = 2 * (n + margin) + 1
            if (B ** d) * (n + margin) * 2 > 10 ** 15:
                break
            sums = comb(2 * n + d, d)
            diffs = 0
            for k in range(0, min(d, n) + 1):
                for j in range(0, min(d - k, n) + 1):
                    diffs += (factorial(d) // (factorial(k) * factorial(j) * factorial(d - k - j))) \
                        * comb(n, k) * comb(n, j)
            if sums < 2:
                continue
            sc = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if best is None or sc > best[0]:
                best = (sc, d, n)
    return best


def _simplex_set(d, n):
    B = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        w = B ** i
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return pts


def _fast_score(pts):
    import numpy as np
    arr = np.array(sorted(set(pts)), dtype=np.int64)
    nd = len(np.unique((arr[:, None] - arr[None, :]).ravel()))
    ns = len(np.unique((arr[:, None] + arr[None, :]).ravel()))
    return math.log(nd) / math.log(ns) + (1 - 1 / len(arr)) / 100


def _local_search(d, n, tlimit):
    import numpy as np
    B = 2 * (n + 1) + 1
    pts = []

    def rec(i, rem, val, s):
        if i == d:
            pts.append((val, s))
            return
        w = B ** i
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * w, s + x)

    rec(0, n + 1, 0, 0)
    pts.sort()
    m = len(pts)
    if m > 2600:
        return None
    vals = np.array([p[0] for p in pts], dtype=np.int64)
    mask = np.array([p[1] <= n for p in pts], dtype=bool)

    sums = (vals[:, None] + vals[None, :]).ravel()
    us, inv = np.unique(sums, return_inverse=True)
    SI = np.asarray(inv).reshape(m, m).astype(np.int32)
    nS = len(us)
    del sums, us, inv
    diffs = (vals[:, None] - vals[None, :]).ravel()
    ud, inv = np.unique(diffs, return_inverse=True)
    DI = np.asarray(inv).reshape(m, m).astype(np.int32)
    nD = len(ud)
    del diffs, ud, inv

    A0 = np.flatnonzero(mask)
    ix = np.ix_(A0, A0)
    cS = np.bincount(SI[ix].ravel(), minlength=nS).astype(np.int32)
    cD = np.bincount(DI[ix].ravel(), minlength=nD).astype(np.int32)
    S = int(np.count_nonzero(cS))
    D = int(np.count_nonzero(cD))
    k = int(mask.sum())

    def apply(u, sign):
        mask[u] = False
        others = np.flatnonzero(mask)
        ids = SI[u, others]
        iuu = SI[u, u]
        i1 = DI[u, others]
        i2 = DI[others, u]
        izero = DI[u, u]
        if sign > 0:
            dS = int(np.count_nonzero(cS[ids] == 0)) + int(cS[iuu] == 0)
            cS[ids] += 2
            cS[iuu] += 1
            z1 = i1[cD[i1] == 0]
            z2 = i2[cD[i2] == 0]
            dD = len(np.union1d(z1, z2))
            cD[i1] += 1
            cD[i2] += 1
            cD[izero] += 1
            mask[u] = True
        else:
            cS[ids] -= 2
            cS[iuu] -= 1
            dS = -(int(np.count_nonzero(cS[ids] == 0)) + int(cS[iuu] == 0))
            cD[i1] -= 1
            cD[i2] -= 1
            cD[izero] -= 1
            z1 = i1[cD[i1] == 0]
            z2 = i2[cD[i2] == 0]
            dD = -len(np.union1d(z1, z2))
        return dS, dD

    def fval(S_, D_, k_):
        return math.log(D_) / math.log(S_) + (1 - 1 / k_) / 100

    cur_f = fval(S, D, k)
    best_f = cur_f
    best_mask = mask.copy()
    t0 = time.time()
    T0, T1 = 3e-4, 2e-6
    T = T0
    it = 0
    while True:
        it += 1
        if it % 25 == 1:
            el = time.time() - t0
            if el > tlimit:
                break
            T = T0 * (T1 / T0) ** (el / tlimit)
        inA = np.flatnonzero(mask)
        out = np.flatnonzero(~mask)
        if len(out) == 0:
            break
        r = random.random()
        ops = []
        S0, D0, k0 = S, D, k
        if r < 0.25:
            if k <= 4:
                continue
            u = int(inA[random.randrange(len(inA))])
            ops.append((u, -1))
        elif r < 0.5:
            v = int(out[random.randrange(len(out))])
            ops.append((v, 1))
        else:
            u = int(inA[random.randrange(len(inA))])
            v = int(out[random.randrange(len(out))])
            ops.append((u, -1))
            ops.append((v, 1))
        for (x, sg) in ops:
            dS, dD = apply(x, sg)
            S += dS
            D += dD
            k += sg
        nf = fval(S, D, k)
        if nf >= cur_f or random.random() < math.exp((nf - cur_f) / T):
            cur_f = nf
            if nf > best_f:
                best_f = nf
                best_mask = mask.copy()
        else:
            for (x, sg) in reversed(ops):
                apply(x, -sg)
            S, D, k = S0, D0, k0
    return [int(x) for x in vals[best_mask]]


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    start = time.time()
    try:
        p = _simplex_params()
        if p is not None:
            best_sc, d0, n0 = p
            best_set = sorted(set(_simplex_set(d0, n0)))
            try:
                for cap in (900,):
                    q = _simplex_params(cap, 1)
                    if q is None:
                        continue
                    _, d, n = q
                    remaining = 85 - (time.time() - start)
                    if remaining < 10:
                        break
                    res = _local_search(d, n, min(75, remaining))
                    if res is None or len(res) < 3:
                        continue
                    sc = _fast_score(res)
                    if sc > best_sc:
                        best_sc = sc
                        best_set = sorted(set(res))
            except Exception:
                pass
            return best_set
    except Exception:
        pass
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    cur = best[:]
    deadline = time.time() + 5
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-3, 3)
        if random.random() < 0.05:
            cand.append(random.randint(1, 20))
        if random.random() < 0.03 and len(cand) > 5:
            cand = cand[1:]
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.1:
            cur = best[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END