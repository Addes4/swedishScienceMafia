# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _simplex_params():
    from math import comb, factorial
    best = None
    for d in range(1, 40):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if (B ** d) * n * 2 > 10 ** 15:
                break
            sums = comb(2 * n + d, d)
            diffs = 0
            for k in range(0, min(d, n) + 1):
                for j in range(0, min(d - k, n) + 1):
                    diffs += (factorial(d) // (factorial(k) * factorial(j) * factorial(d - k - j))) \
                        * comb(n, k) * comb(n, j)
            if sums < 2:
                continue
            sc = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if best is None or sc > best[0]:
                best = (sc, d, n)
    return best


def _simplex_set(d, n):
    B = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        w = B ** i
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return pts


def _trunc_count(d, n, c):
    # number of x in [0,c]^d with sum <= n
    dp = [1] + [0] * n
    for _ in range(d):
        new = [0] * (n + 1)
        for s in range(n + 1):
            if dp[s]:
                for x in range(0, min(c, n - s) + 1):
                    new[s + x] += dp[s]
        dp = new
    return sum(dp)


def _trunc_set(d, n, c):
    B = 2 * c + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        w = B ** i
        for x in range(min(c, rem) + 1):
            rec(i + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return pts


def _w_count(w, n):
    dp = [1] + [0] * n
    for wi in w:
        new = [0] * (n + 1)
        for s in range(n + 1):
            v = dp[s]
            if v:
                for t in range(s, n + 1, wi):
                    new[t] += v
        dp = new
    return sum(dp)


def _w_set(w, n):
    d = len(w)
    B = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        wt = B ** i
        for x in range(rem // w[i] + 1):
            rec(i + 1, rem - x * w[i], val + x * wt)

    rec(0, n, 0)
    return pts


def _fast_score(pts):
    import numpy as np
    arr = np.array(sorted(set(pts)), dtype=np.int64)
    nd = len(np.unique((arr[:, None] - arr[None, :]).ravel()))
    ns = len(np.unique((arr[:, None] + arr[None, :]).ravel()))
    return math.log(nd) / math.log(ns) + (1 - 1 / len(arr)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    try:
        p = _simplex_params()
        if p is not None:
            best_sc, d0, n0 = p
            best_set = sorted(set(_simplex_set(d0, n0)))
            try:
                t_end = time.time() + 35
                cands = []
                for d in range(max(1, d0 - 3), d0 + 4):
                    for n in range(max(1, n0 - 4), n0 + 8):
                        for c in range(max(1, n // 2), n):
                            B = 2 * c + 1
                            if (B ** d) * 2 > 10 ** 15:
                                continue
                            sz = _trunc_count(d, n, c)
                            if sz < 200 or sz > 4000:
                                continue
                            cands.append((sz, d, n, c))
                cands.sort(reverse=True)
                for sz, d, n, c in cands:
                    if time.time() > t_end:
                        break
                    pts = _trunc_set(d, n, c)
                    sc = _fast_score(pts)
                    if sc > best_sc:
                        best_sc = sc
                        best_set = sorted(set(pts))
            except Exception:
                pass
            try:
                t_end2 = time.time() + 40
                wc = []
                for d in range(max(2, d0 - 3), d0 + 4):
                    for n in range(2, 16):
                        if ((2 * n + 1) ** d) * 2 > 10 ** 15:
                            continue
                        for k in range(1, d):
                            w = [1] * (d - k) + [2] * k
                            sz = _w_count(w, n)
                            if sz < 300 or sz > 4000:
                                continue
                            wc.append((sz, w, n))
                wc.sort(key=lambda t: -t[0])
                for sz, w, n in wc:
                    if time.time() > t_end2:
                        break
                    pts = _w_set(w, n)
                    sc = _fast_score(pts)
                    if sc > best_sc:
                        best_sc = sc
                        best_set = sorted(set(pts))
            except Exception:
                pass
            return best_set
    except Exception:
        pass
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    cur = best[:]
    deadline = time.time() + 5
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-3, 3)
        if random.random() < 0.05:
            cand.append(random.randint(1, 20))
        if random.random() < 0.03 and len(cand) > 5:
            cand = cand[1:]
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.1:
            cur = best[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END