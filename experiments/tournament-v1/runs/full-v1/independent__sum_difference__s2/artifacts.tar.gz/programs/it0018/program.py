import math
from math import comb


def _counts(d, n):
    s = comb(2 * n + d, d)
    df = 0
    for p in range(0, d + 1):
        for q in range(0, d - p + 1):
            df += comb(d, p) * comb(d - p, q) * comb(n, p) * comb(n, q)
    return s, df


def _points(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    for d in range(1, 60):
        for n in range(1, 400):
            size = comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            base = 2 * n + 1
            if n * (base ** d - 1) // (base - 1) > 10 ** 15:
                continue
            s, df = _counts(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if best is None or sc > best[0]:
                best = (sc, d, n)
    if best is None:
        return [0, 1, 3]
    _, d, n = best
    base = 2 * n + 1
    pts = _points(d, n)
    out = []
    for p in pts:
        v = 0
        for c in p:
            v = v * base + c
        out.append(v)
    return sorted(set(out))
