import math
from math import comb, factorial


def _counts(d, n):
    s = comb(2 * n + d, d)
    t = 0
    for i in range(d + 1):
        for j in range(d - i + 1):
            m = factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))
            t += m * comb(n, i) * comb(n, j)
    return t, s


def _gen(d, n, b):
    res = []

    def rec(pos, rem, val):
        if pos == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val * b + x)

    rec(0, n, 0)
    return res


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            b = 2 * n + 1
            if b ** d > 1e15:
                break
            if size < 2:
                continue
            t, s = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    b = 2 * n + 1
    return sorted(set(_gen(d, n, b)))
