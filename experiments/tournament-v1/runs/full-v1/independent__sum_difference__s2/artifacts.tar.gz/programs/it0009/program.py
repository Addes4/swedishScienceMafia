import math
from itertools import combinations_with_replacement


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for i in range(d + 1):
        for j in range(d + 1 - i):
            diffs += (math.factorial(d) // (math.factorial(i) * math.factorial(j)
                      * math.factorial(d - i - j))) * math.comb(n, i) * math.comb(n, j)
    return size, sums, diffs


def _gen(d, n):
    B = 2 * n + 1
    pts = [0]
    # build all vectors with sum <= n via recursion
    res = []

    def rec(pos, remaining, val):
        if pos == d:
            res.append(val)
            return
        w = B ** pos
        for x in range(remaining + 1):
            rec(pos + 1, remaining - x, val + x * w)

    rec(0, n, 0)
    return res


def solve():
    best = None
    best_score = -1
    for d in range(1, 40):
        for n in range(1, 4000):
            size, sums, diffs = _counts(d, n)
            if size > 4000:
                break
            if size < 2:
                continue
            if (2 * n + 1) ** d > 10 ** 14:
                break
            sc = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if sc > best_score:
                best_score = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
