import math
from math import comb, log


def _counts(d, n):
    s = comb(2 * n + d, d)
    t = 0
    for p in range(0, d + 1):
        for q in range(0, d - p + 1):
            if p > n or q > n:
                continue
            t += comb(d, p) * comb(d - p, q) * comb(n, p) * comb(n, q)
    return t, s


def _gen(d, n):
    base = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return pts


def solve():
    best = None
    best_sc = -1
    for d in range(1, 40):
        for n in range(1, 4000):
            size = comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 10 ** 15:
                break
            if size < 2:
                continue
            t, s = _counts(d, n)
            sc = log(t) / log(s) + (1 - 1.0 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    return sorted(_gen(d, n))
