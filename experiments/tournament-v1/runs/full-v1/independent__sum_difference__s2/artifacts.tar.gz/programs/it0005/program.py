import math
from math import comb, factorial


def _counts(d, n):
    sums = comb(2 * n + d, d)
    diffs = 0
    for j in range(0, min(d, n) + 1):
        for m in range(0, min(d - j, n) + 1):
            mult = factorial(d) // (factorial(j) * factorial(m) * factorial(d - j - m))
            diffs += mult * comb(n, j) * comb(n, m)
    return diffs, sums


def _gen(d, n):
    # all x in N^d with sum <= n
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    best_sc = -1
    for d in range(1, 200):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            B = 2 * n + 1
            if (B ** d) * 2 >= 10 ** 15:
                continue
            df, sm = _counts(d, n)
            sc = math.log(df) / math.log(sm) + (1 - 1.0 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    if best is None:
        return [0, 1, 3]
    d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for c in reversed(p):
            v = v * B + c
        out.append(v)
    return sorted(set(out))
