import math


def _binom(a, b):
    return math.comb(a, b) if 0 <= b <= a else 0


def _ratio(d, n):
    sums = _binom(2 * n + d, d)
    diffs = 0
    for i in range(0, d + 1):
        for j in range(0, d - i + 1):
            diffs += (math.factorial(d) // (math.factorial(i) * math.factorial(j)
                                            * math.factorial(d - i - j))
                      * _binom(n, i) * _binom(n, j))
    if sums < 2:
        return 0.0
    return math.log(diffs) / math.log(sums)


def _gen(d, n):
    pts = []

    def rec(pos, rem, cur):
        if pos == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(pos + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def solve():
    best = None
    for d in range(1, 40):
        n = 1
        while _binom(n + d, d) <= 4000:
            B = 2 * n + 1
            if n * B ** (d - 1) <= 10 ** 15 and _binom(n + d, d) >= 2:
                r = _ratio(d, n) + (1 - 1 / _binom(n + d, d)) / 100
                if best is None or r > best[0]:
                    best = (r, d, n)
            n += 1
    if best is None:
        return [0, 1, 3]
    _, d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    res = []
    for p in pts:
        v = 0
        for c in p:
            v = v * B + c
        res.append(v)
    return sorted(set(res))
