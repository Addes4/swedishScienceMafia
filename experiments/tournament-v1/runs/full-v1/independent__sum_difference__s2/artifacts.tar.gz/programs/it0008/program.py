import math
import time
import itertools
import numpy as np


def _score_arr(a):
    a = np.asarray(a, dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _gen(d, n, cap):
    # all vectors in N^d with sum<=n and each coord<=cap
    res = []
    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(min(rem, cap) + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()
    rec(0, n, [])
    return res


def _count(d, n, cap):
    # count via DP
    poly = [1] + [0] * n
    for _ in range(d):
        new = [0] * (n + 1)
        for s in range(n + 1):
            if poly[s]:
                for v in range(min(cap, n - s) + 1):
                    new[s + v] += poly[s]
        poly = new
    return sum(poly)


def solve():
    t0 = time.time()
    limit = 95
    cands = []
    for n in range(1, 13):
        for cap in range(1, n + 1):
            for d in range(2, 40):
                B = 2 * n + 1
                if float(B) ** d > 4e14:
                    break
                c = _count(d, n, cap)
                if c < 20:
                    continue
                if c > 4000:
                    break
                cands.append((c, d, n, cap))
    cands.sort()
    best = [0, 1, 3]
    best_score = 0.0
    for c, d, n, cap in cands:
        if time.time() - t0 > limit:
            break
        if c > 2500 and time.time() - t0 > limit - 20:
            continue
        pts = _gen(d, n, cap)
        B = 2 * n + 1
        w = np.array([B ** i for i in range(d)], dtype=np.int64)
        arr = np.array(pts, dtype=np.int64) @ w
        sc = _score_arr(arr)
        if sc > best_score:
            best_score = sc
            best = [int(x) for x in arr]
    return sorted(set(best))
