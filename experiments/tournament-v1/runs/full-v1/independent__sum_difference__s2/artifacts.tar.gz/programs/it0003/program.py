import math
from math import comb, factorial


def _counts(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for j in range(0, d + 1):
        for l in range(0, d - j + 1):
            mult = factorial(d) // (factorial(j) * factorial(l) * factorial(d - j - l))
            diffs += mult * comb(n, j) * comb(n, l)
    return size, diffs, sums


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(i, remaining, val, mult):
        if i == d:
            res.append(val)
            return
        for x in range(remaining + 1):
            rec(i + 1, remaining - x, val + x * mult, mult * B)

    rec(0, n, 0, 1)
    return res


def solve():
    best = None
    best_score = -1
    for d in range(1, 30):
        for n in range(1, 4000):
            size = comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 10 ** 15:
                break
            if size < 2:
                continue
            s, df, sm = _counts(d, n)
            sc = math.log(df) / math.log(sm) + (1 - 1 / s) / 100
            if sc > best_score:
                best_score = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
