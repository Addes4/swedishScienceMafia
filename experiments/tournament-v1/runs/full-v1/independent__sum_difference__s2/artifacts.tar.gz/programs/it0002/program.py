import math
from math import comb


def _gen(d, n):
    res = []

    def rec(i, rem, val, B):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x, B)

    rec(0, n, 0, 2 * n + 1)
    return res


def _value(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        ci = comb(d, i) * comb(n, i)
        for k in range(0, min(d - i, n) + 1):
            diffs += ci * comb(d - i, k) * comb(n, k)
    return math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100


def solve():
    best = None
    bestv = -1
    for n in range(1, 60):
        for d in range(1, 200):
            if comb(n + d, d) > 4000:
                break
            if (2 * n + 1) ** d > 5 * 10 ** 14:
                break
            if comb(n + d, d) < 3:
                continue
            v = _value(d, n)
            if v > bestv:
                bestv = v
                best = (d, n)
    d, n = best
    A = _gen(d, n)
    return sorted(set(A))
