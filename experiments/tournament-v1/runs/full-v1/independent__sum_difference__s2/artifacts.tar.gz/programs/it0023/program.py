import math
from math import comb
import itertools


def _comp(i, a):
    if i == 0 and a == 0:
        return 1
    if i < 1 or a < 1:
        return 0
    return comb(i - 1, a - 1)


def _diff_count(d, n):
    tot = 0
    for i in range(n + 1):
        for j in range(n + 1):
            f = 0
            for a in range(0, min(d, i) + 1):
                ca = _comp(i, a)
                if ca == 0:
                    continue
                for b in range(0, min(d - a, j) + 1):
                    cb = _comp(j, b)
                    if cb == 0:
                        continue
                    f += comb(d, a) * comb(d - a, b) * ca * cb
            tot += f
    return tot


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(pos, rem, val):
        if pos == d:
            res.append(val)
            return
        w = B ** pos
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return res


def solve():
    best = None
    bs = -1
    for d in range(1, 80):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * (B ** d - 1) // (B - 1) > 10 ** 15:
                break
            if size < 2:
                continue
            S = comb(2 * n + d, d)
            D = _diff_count(d, n)
            sc = math.log(D) / math.log(S) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    if best is None:
        return [0, 1, 3]
    d, n = best
    return sorted(set(_gen(d, n)))
