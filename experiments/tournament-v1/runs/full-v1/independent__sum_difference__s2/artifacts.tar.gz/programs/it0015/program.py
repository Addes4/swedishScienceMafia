import math
import itertools


def _diff_count(d, n):
    # number of z in Z^d with positive part sum <= n and negative part sum <= n
    dp = [[0] * (n + 1) for _ in range(n + 1)]
    dp[0][0] = 1
    for _ in range(d):
        new = [[0] * (n + 1) for _ in range(n + 1)]
        for p in range(n + 1):
            for q in range(n + 1):
                c = dp[p][q]
                if not c:
                    continue
                new[p][q] += c
                for v in range(1, n - p + 1):
                    new[p + v][q] += c
                for v in range(1, n - q + 1):
                    new[p][q + v] += c
        dp = new
    return sum(sum(r) for r in dp)


def _points(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    for d in range(1, 30):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if (n + 1) * B ** d > 10 ** 15:
                break
            S = math.comb(2 * n + d, d)
            D = _diff_count(d, n)
            if S < 2:
                continue
            sc = math.log(D) / math.log(S) + (1 - 1 / size) / 100
            if best is None or sc > best[0]:
                best = (sc, d, n)
    _, d, n = best
    B = 2 * n + 1
    pts = _points(d, n)
    out = []
    for p in pts:
        v = 0
        for x in reversed(p):
            v = v * B + x
        out.append(v)
    return sorted(set(out))
