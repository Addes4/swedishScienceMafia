import math
import time
import itertools
import numpy as np


def _score_np(vals):
    a = np.array(vals, dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(d, n):
    B = 2 * n + 1
    pw = [B ** i for i in range(d)]
    vals = set()
    for comb in itertools.combinations_with_replacement(range(d + 1), n):
        v = 0
        for c in comb:
            if c > 0:
                v += pw[c - 1]
        vals.add(v)
    return sorted(vals)


def solve():
    start = time.time()
    cands = []
    for n in range(1, 40):
        B = 2 * n + 1
        for d in range(2, 200):
            if B ** d * n > 5e14:
                break
            if math.comb(n + d, n) > 4000:
                break
            if math.comb(n + d, n) < 8:
                continue
            cands.append((d, n))
    best = [0, 1]
    best_s = 0.0
    # evaluate cheaper first
    cands.sort(key=lambda t: math.comb(t[0] + t[1], t[1]))
    for d, n in cands:
        if time.time() - start > 90:
            break
        sz = math.comb(n + d, n)
        if sz > 2500 and time.time() - start > 60:
            continue
        vals = _build(d, n)
        s = _score_np(vals)
        if s > best_s:
            best_s = s
            best = vals
    return [int(x) for x in best]
