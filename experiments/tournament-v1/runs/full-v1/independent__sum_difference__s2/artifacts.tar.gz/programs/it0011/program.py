import math
import itertools


def _gen(d, n):
    res = []

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B[0] + x)

    B = [2 * n + 1]
    rec(0, n, 0)
    return res


def _counts(d, n):
    s = math.comb(2 * n + d, d)
    t = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            t += (math.factorial(d) // (math.factorial(i) * math.factorial(j) * math.factorial(d - i - j))
                  * math.comb(n, i) * math.comb(n, j))
    return s, t


def solve():
    best = None
    bs = -1
    for d in range(1, 60):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            if (2 * n + 1) ** d > 10 ** 15:
                continue
            s, t = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    if best is None:
        return [0, 1, 3]
    d, n = best
    A = sorted(set(_gen(d, n)))
    return A
