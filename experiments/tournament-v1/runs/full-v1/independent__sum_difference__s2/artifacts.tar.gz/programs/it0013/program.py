import math
from math import comb, factorial


def _diff_count(d, n):
    tot = 0
    for j in range(0, min(d, n) + 1):
        cj = comb(n, j)
        for k in range(0, min(d - j, n) + 1):
            ways = factorial(d) // (factorial(j) * factorial(k) * factorial(d - j - k))
            tot += ways * cj * comb(n, k)
    return tot


def _gen(d, n):
    base = 2 * n + 1
    res = []

    def rec(pos, remaining, val):
        if pos == d:
            res.append(val)
            return
        w = base ** pos
        for x in range(remaining + 1):
            rec(pos + 1, remaining - x, val + x * w)

    rec(0, n, 0)
    return res


def solve():
    best = None
    best_sc = -1
    for n in range(1, 200):
        for d in range(1, 4000):
            size = comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 4e14:
                break
            if size < 2:
                continue
            s = comb(2 * n + d, d)
            df = _diff_count(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    if best is None:
        return [0, 1, 3]
    d, n = best
    return sorted(set(_gen(d, n)))
