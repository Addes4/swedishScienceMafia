import math
from math import comb, factorial


def _counts(d, n):
    S = comb(2 * n + d, d)
    D = 0
    for j in range(d + 1):
        for k in range(d + 1 - j):
            mult = factorial(d) // (factorial(j) * factorial(k) * factorial(d - j - k))
            D += mult * comb(n, j) * comb(n, k)
    return D, S


def _gen(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    for d in range(1, 16):
        n = 1
        while comb(n + d, d) <= 4000:
            B = 2 * n + 1
            if B ** d <= 10 ** 15 // 2:
                size = comb(n + d, d)
                D, S = _counts(d, n)
                if S > 1:
                    sc = math.log(D) / math.log(S) + (1 - 1 / size) / 100
                    if best is None or sc > best[0]:
                        best = (sc, d, n)
            n += 1
    _, d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for c in p:
            v = v * B + c
        out.append(v)
    return sorted(set(out))
