import math
import random
import time
from math import gcd


def _ratio(a):
    d = {x - y for x in a for y in a}
    s = {x + y for x in a for y in a}
    return math.log(len(d)) / math.log(len(s))


def _norm(a):
    m = min(a)
    a = [x - m for x in a]
    g = 0
    for x in a:
        g = gcd(g, x)
    if g > 1:
        a = [x // g for x in a]
    return a


def _bestk(a):
    # a normalized, min 0
    s = len(a)
    M = max(a)
    if s < 2 or M == 0:
        return 1
    B = 2 * M + 1
    k = 1
    while True:
        k2 = k + 1
        if s ** k2 > 4000:
            break
        mx = M * (B ** k2 - 1) // (B - 1)
        if mx > 10 ** 15:
            break
        k = k2
    return k


def _final(a):
    a = _norm(list(a))
    if len(set(a)) < 2:
        return -1.0, 1, a
    r = _ratio(a)
    k = _bestk(a)
    return r + (1 - 1.0 / len(a) ** k) / 100, k, a


def _simplex(d, n):
    pts = []

    def rec(i, rem, cur):
        if i == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()
    rec(0, n, [])
    B = 2 * n + 1
    out = []
    for p in pts:
        v = 0
        for x in p:
            v = v * B + x
        out.append(v)
    return out


def _build(a, k):
    M = max(a)
    B = 2 * M + 1
    res = [0]
    mul = 1
    for _ in range(k):
        res = [r + x * mul for r in res for x in a]
        mul *= B
    return sorted(set(res))


def solve():
    t0 = time.time()
    deadline = t0 + 70
    best = [0, 1, 3]
    bs, bk, bn = _final(best)
    best = bn

    # simplex seeds
    for d in range(2, 6):
        for n in range(1, 8):
            from math import comb
            if comb(n + d, d) > 70:
                continue
            a = _simplex(d, n)
            sc, k, an = _final(a)
            if sc > bs:
                bs, bk, best = sc, k, an

    cur_best_global = (bs, best)
    while time.time() < deadline:
        M = random.choice([12, 20, 30, 45, 70])
        size = random.randint(5, 12)
        cur = set(random.sample(range(M + 1), min(size, M + 1)))
        cs = _final(list(cur))[0]
        T0 = 0.02
        iters = 6000
        for it in range(iters):
            if time.time() > deadline:
                break
            T = T0 * (1 - it / iters) + 1e-5
            c = set(cur)
            r = random.random()
            if r < 0.5 and c:
                x = random.choice(list(c))
                c.discard(x)
                c.add(max(0, min(M, x + random.randint(-3, 3))))
            elif r < 0.75:
                c.add(random.randint(0, M))
            elif r < 0.9 and len(c) > 4:
                c.discard(random.choice(list(c)))
            else:
                x = random.choice(list(c))
                c.discard(x)
                c.add(random.randint(0, M))
            if len(c) < 3:
                continue
            s = _final(list(c))[0]
            if s >= cs or random.random() < math.exp((s - cs) / T):
                cur, cs = c, s
                if cs > cur_best_global[0]:
                    cur_best_global = (cs, _norm(list(cur)))
    bs, best = cur_best_global
    sc, k, an = _final(best)
    return _build(an, k)
