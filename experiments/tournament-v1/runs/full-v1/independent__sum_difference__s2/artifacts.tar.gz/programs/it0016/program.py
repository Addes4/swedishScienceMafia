import math
import time
import itertools
import numpy as np


def _gen(d, n):
    pts = []

    def rec(prefix, rem, k):
        if k == d:
            pts.append(prefix)
            return
        for v in range(rem + 1):
            rec(prefix + (v,), rem - v, k + 1)

    rec((), n, 0)
    return pts


def _eval(arr):
    m = len(arr)
    diffs = np.unique((arr[:, None] - arr[None, :]).ravel())
    sums = np.unique((arr[:, None] + arr[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / m) / 100


def solve():
    t0 = time.time()
    best = None
    best_s = -1
    cands = []
    for d in range(2, 11):
        for n in range(2, 80):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 150:
                continue
            B = 2 * n + 1
            if B ** d > 5e14:
                break
            cands.append((d, n, size))
    # larger sets first
    cands.sort(key=lambda c: -c[2])
    for d, n, size in cands:
        if time.time() - t0 > 80:
            break
        pts = _gen(d, n)
        B = 2 * n + 1
        vals = []
        for p in pts:
            v = 0
            for x in p:
                v = v * B + x
            vals.append(v)
        arr = np.array(sorted(set(vals)), dtype=np.int64)
        s = _eval(arr)
        if s > best_s:
            best_s = s
            best = arr
    if best is None:
        return [0, 1, 3]
    return [int(x) for x in best]
