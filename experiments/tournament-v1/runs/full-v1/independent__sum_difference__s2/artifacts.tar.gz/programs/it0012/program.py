import math
import time
import numpy as np


def _gen(d, n):
    # all nonnegative integer vectors of length d with sum <= n
    res = []

    def rec(pref, rem, k):
        if k == 0:
            res.append(tuple(pref))
            return
        for v in range(rem + 1):
            pref.append(v)
            rec(pref, rem - v, k - 1)
            pref.pop()

    rec([], n, d)
    return res


def _score_arr(a):
    m = len(a)
    if m < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / m) / 100


def solve():
    start = time.time()
    best = None
    best_score = -1.0
    cands = []
    for d in range(1, 14):
        for n in range(1, 60):
            sz = math.comb(n + d, d)
            if sz > 4000:
                break
            if sz < 30:
                continue
            cands.append((sz, d, n))
    cands.sort()
    for sz, d, n in cands:
        if time.time() - start > 95:
            break
        pts = _gen(d, n)
        B = 2 * n + 1
        w = [B ** i for i in range(d)]
        enc = np.array([sum(c * ww for c, ww in zip(p, w)) for p in pts], dtype=np.int64)
        s = _score_arr(enc)
        if s > best_score:
            best_score = s
            best = enc
    if best is None:
        return [0, 1, 3, 7, 12]
    return sorted(int(x) for x in best)
