import math
from math import comb


def _counts(d, n):
    s = comb(2 * n + d, d)
    t = 0
    for j in range(0, d + 1):
        for k in range(0, d - j + 1):
            if j > n or k > n:
                continue
            t += comb(d, j) * comb(d - j, k) * comb(n, j) * comb(n, k)
    return t, s


def _gen(d, n, base):
    res = []

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return res


def solve():
    best = None
    for d in range(1, 40):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            base = 2 * n + 1
            if base ** d > 10 ** 15:
                break
            if size < 2:
                continue
            t, s = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if best is None or sc > best[0]:
                best = (sc, d, n)
    _, d, n = best
    return sorted(set(_gen(d, n, 2 * n + 1)))
