import math
import time
import numpy as np


def _gen(d, n):
    pts = []

    def rec(i, rem, cur):
        if i == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def _encode(pts, B, d):
    w = [B ** i for i in range(d)]
    return [sum(p[i] * w[i] for i in range(d)) for p in pts]


def _score_np(a):
    arr = np.array(sorted(set(a)), dtype=np.int64)
    k = len(arr)
    if k < 2:
        return 0.0
    diffs = np.unique((arr[:, None] - arr[None, :]).ravel())
    sums = np.unique((arr[:, None] + arr[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / k) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 40):
        for n in range(1, 40):
            size = math.comb(n + d, d)
            if size > 4000 or size < 20:
                continue
            B = 2 * n + 1
            if B ** d > 4e14:
                continue
            cands.append((size, d, n))
    # prioritize larger sizes first (generally better), but guard time
    cands.sort(key=lambda t: -t[0])
    best = [0, 1, 3]
    best_s = _score_np(best)
    for size, d, n in cands:
        if time.time() - t0 > 85:
            break
        pts = _gen(d, n)
        B = 2 * n + 1
        a = _encode(pts, B, d)
        s = _score_np(a)
        if s > best_s:
            best_s, best = s, a
    return sorted(set(int(x) for x in best))
