import math
import itertools


def _build(d, n):
    B = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        w = B ** i
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return pts


def _counts(d, n):
    s = math.comb(2 * n + d, d)
    t = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            t += (math.factorial(d) // (math.factorial(i) * math.factorial(j) * math.factorial(d - i - j))
                  * math.comb(n, i) * math.comb(n, j))
    return s, t


def solve():
    best = None
    best_sc = -1
    for d in range(1, 200):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if n * (2 * n + 1) ** (d - 1) > 10 ** 15:
                break
            if size < 2:
                continue
            s, t = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    return sorted(set(_build(d, n)))
