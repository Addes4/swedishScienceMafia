import math
from math import comb, log
import itertools


def _counts(d, n):
    s = comb(2 * n + d, d)
    t = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            t += comb(d, i) * comb(d - i, j) * comb(n, i) * comb(n, j)
    return t, s


def _build(d, n):
    base = 2 * n + 1
    pts = []

    def rec(pos, remaining, val):
        if pos == d:
            pts.append(val)
            return
        w = base ** pos
        for x in range(remaining + 1):
            rec(pos + 1, remaining - x, val + x * w)

    rec(0, n, 0)
    return pts


def solve():
    best = None
    best_sc = -1
    for d in range(1, 60):
        for n in range(1, 4000):
            size = comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            if n * (2 * n + 1) ** d > 10 ** 15:
                break
            t, s = _counts(d, n)
            sc = log(t) / log(s) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    if best is None:
        return [0, 1, 3]
    d, n = best
    return sorted(set(_build(d, n)))
