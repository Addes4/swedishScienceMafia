import math


def _best_params():
    best = None
    for d in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * (B ** d) > 10 ** 15:
                break
            s = math.comb(2 * n + d, d)
            df = 0
            for i in range(0, min(n, d) + 1):
                for j in range(0, min(n, d - i) + 1):
                    df += (math.factorial(d) // (math.factorial(i) * math.factorial(j)
                           * math.factorial(d - i - j))) * math.comb(n, i) * math.comb(n, j)
            if s < 2 or size < 2:
                continue
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if best is None or sc > best[0]:
                best = (sc, d, n)
    return best


def solve():
    _, d, n = _best_params()
    B = 2 * n + 1
    pts = [()]
    for _ in range(d):
        new = []
        for p in pts:
            r = n - sum(p)
            for v in range(r + 1):
                new.append(p + (v,))
        pts = new
    res = []
    for p in pts:
        v = 0
        for i, x in enumerate(p):
            v += x * (B ** i)
        res.append(v)
    return sorted(set(res))
