import numpy as np
import time
from scipy.optimize import minimize


def _feasible_radii(centers):
    n = len(centers)
    r = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    r = np.maximum(r, 0)
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.hypot(*(centers[i] - centers[j]))
                if r[i] + r[j] > d:
                    s = d / (r[i] + r[j] + 1e-18)
                    r[i] *= s
                    r[j] *= s
                    changed = True
        if not changed:
            break
    return r


def solve(n=26):
    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(1)
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    ar = np.arange(m)

    def obj(v):
        return -np.sum(v[2 * n:])

    def obj_grad(v):
        g = np.zeros(3 * n)
        g[2 * n:] = -1
        return g

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]
        pair = dx * dx + dy * dy - (r[iu] + r[ju]) ** 2
        return np.concatenate([pair, x - r, 1 - x - r, y - r, 1 - y - r])

    def cons_jac(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        J = np.zeros((m + 4 * n, 3 * n))
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]
        s = r[iu] + r[ju]
        J[ar, iu] = 2 * dx
        J[ar, ju] = -2 * dx
        J[ar, n + iu] = 2 * dy
        J[ar, n + ju] = -2 * dy
        J[ar, 2 * n + iu] = -2 * s
        J[ar, 2 * n + ju] = -2 * s
        k = np.arange(n)
        J[m + k, k] = 1; J[m + k, 2 * n + k] = -1
        J[m + n + k, k] = -1; J[m + n + k, 2 * n + k] = -1
        J[m + 2 * n + k, n + k] = 1; J[m + 2 * n + k, 2 * n + k] = -1
        J[m + 3 * n + k, n + k] = -1; J[m + 3 * n + k, 2 * n + k] = -1
        return J

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    best = (-1, None, None)
    it = 0
    while time.time() - t0 < budget:
        it += 1
        mode = it % 3
        if mode == 0:
            c = rng.random((n, 2)) * 0.9 + 0.05
        elif mode == 1:
            k = 5
            g = np.array([[(i + 0.5) / k, (j + 0.5) / k] for i in range(k) for j in range(k)])
            g = np.vstack([g, [[0.5, 0.5]]])[:n]
            c = g + rng.normal(0, 0.04, g.shape)
        else:
            c = rng.random((n, 2)) * 0.9 + 0.05
        c = np.clip(c, 0.03, 0.97)
        r0 = np.full(n, 0.05) * (0.5 + rng.random(n))
        v0 = np.concatenate([c[:, 0], c[:, 1], r0])
        try:
            res = minimize(obj, v0, jac=obj_grad, method='SLSQP', bounds=bounds,
                           constraints=[{'type': 'ineq', 'fun': cons, 'jac': cons_jac}],
                           options={'maxiter': 300, 'ftol': 1e-10})
        except Exception:
            continue
        v = res.x
        cc = np.clip(np.stack([v[:n], v[n:2 * n]], 1), 0, 1)
        rr = _feasible_radii(cc)
        tot = rr.sum()
        if tot > best[0]:
            best = (tot, cc, rr)
        if time.time() - t0 > budget:
            break
    return best[1], best[2]
