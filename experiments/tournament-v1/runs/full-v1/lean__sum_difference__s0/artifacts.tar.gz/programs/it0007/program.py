# EVOLVE-BLOCK-START
"""Simplex lattice start + fast incremental local search on exact sum/diff counts."""
import math
import time
import random
import numpy as np


def _points(d, n):
    pts = [()]
    for _ in range(d):
        new = []
        for p in pts:
            s = sum(p)
            for v in range(n - s + 1):
                new.append(p + (v,))
        pts = new
    return np.array(pts, dtype=np.int64).reshape(len(pts), d)


def _count(arr):
    arr = arr.ravel()
    arr.sort()
    return int(1 + np.count_nonzero(arr[1:] != arr[:-1]))


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    s = _count(a[:, None] + a[None, :])
    d = _count(a[:, None] - a[None, :])
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


class _State:
    def __init__(self, d, M, cap):
        self.d = d
        self.M = M
        self.W = 2 * M + 1
        self.w = np.array([self.W ** i for i in range(d)], dtype=np.int64)
        box = self.W ** d
        self.off = int(M * self.w.sum())
        self.cs = np.zeros(box, dtype=np.int16)
        self.cd = np.zeros(box, dtype=np.int16)
        self.inset = np.zeros(box, dtype=np.bool_)
        self.vA = np.zeros(cap, dtype=np.int64)
        self.P = np.zeros((cap, d), dtype=np.int64)
        self.m = 0
        self.S = 0
        self.D = 0

    def add(self, v, coords):
        m = self.m
        vv = self.vA[:m]
        cs, cd, off = self.cs, self.cd, self.off
        ids = vv + v
        c = cs[ids]
        self.S += int(np.count_nonzero(c == 0))
        cs[ids] = c + 1
        if cs[2 * v] == 0:
            self.S += 1
        cs[2 * v] += 1
        i1 = v - vv + off
        c = cd[i1]
        self.D += int(np.count_nonzero(c == 0))
        cd[i1] = c + 1
        i2 = vv - v + off
        c = cd[i2]
        self.D += int(np.count_nonzero(c == 0))
        cd[i2] = c + 1
        if cd[off] == 0:
            self.D += 1
        cd[off] += 1
        self.vA[m] = v
        self.P[m] = coords
        self.m = m + 1
        self.inset[v] = True

    def remove(self, j):
        v = int(self.vA[j])
        coords = self.P[j].copy()
        m = self.m
        self.vA[j] = self.vA[m - 1]
        self.P[j] = self.P[m - 1]
        m -= 1
        self.m = m
        vv = self.vA[:m]
        cs, cd, off = self.cs, self.cd, self.off
        ids = vv + v
        c = cs[ids] - 1
        cs[ids] = c
        self.S -= int(np.count_nonzero(c == 0))
        cs[2 * v] -= 1
        if cs[2 * v] == 0:
            self.S -= 1
        i1 = v - vv + off
        c = cd[i1] - 1
        cd[i1] = c
        self.D -= int(np.count_nonzero(c == 0))
        i2 = vv - v + off
        c = cd[i2] - 1
        cd[i2] = c
        self.D -= int(np.count_nonzero(c == 0))
        cd[off] -= 1
        if cd[off] == 0:
            self.D -= 1
        self.inset[v] = False
        return v, coords

    def score(self):
        return math.log(self.D) / math.log(self.S)

    def neighbor(self, rng, m):
        j = rng.randrange(m)
        i = rng.randrange(self.d)
        sg = 1 if rng.random() < 0.5 else -1
        c = self.P[j].copy()
        c[i] += sg
        if c[i] < 0 or c[i] > self.M:
            return None
        v = int(self.vA[j]) + sg * int(self.w[i])
        if self.inset[v]:
            return None
        return v, c


def solve():
    start = time.time()
    rng = random.Random(12345)
    cands = []
    for d in range(3, 8):
        for n in range(1, 60):
            sz = math.comb(n + d, d)
            if sz > 3900:
                break
            M = n + 2
            if sz >= 800 and (2 * M + 1) ** d <= 25_000_000:
                cands.append((sz, d, n))
    cands.sort(reverse=True)
    best_a, best_score, best_dn = [0, 1, 3], -1, None
    for sz, d, n in cands:
        if time.time() - start > 25:
            break
        pts = _points(d, n)
        W = 2 * (n + 2) + 1
        w = np.array([W ** i for i in range(d)], dtype=np.int64)
        a = pts @ w
        sc = _eval(a)
        if sc > best_score:
            best_score, best_a, best_dn = sc, [int(x) for x in a], (d, n)
    if best_dn is None:
        return sorted(set(best_a))

    d, n = best_dn
    M = n + 2
    cap = 4000
    st = _State(d, M, cap)
    pts = _points(d, n)
    for p in pts:
        st.add(int(p @ st.w), p)
    cur = st.score()
    best_loc = cur
    best_set = st.vA[:st.m].copy()
    it = 0
    tlimit = 100
    while True:
        it += 1
        if (it & 63) == 0 and time.time() - start > tlimit:
            break
        r = rng.random()
        m = st.m
        if r < 0.3 and m < cap:
            nb = st.neighbor(rng, m)
            if nb is None:
                continue
            v, c = nb
            st.add(v, c)
            new = st.score()
            if new >= cur - 1e-12:
                cur = new
            else:
                st.remove(st.m - 1)
        elif r < 0.45 and m > 200:
            j = rng.randrange(m)
            v, c = st.remove(j)
            new = st.score()
            if new >= cur - 1e-12:
                cur = new
            else:
                st.add(v, c)
        else:
            j = rng.randrange(m)
            v0, c0 = st.remove(j)
            nb = st.neighbor(rng, st.m)
            if nb is None:
                st.add(v0, c0)
                continue
            v, c = nb
            st.add(v, c)
            new = st.score()
            if new >= cur - 1e-12:
                cur = new
            else:
                st.remove(st.m - 1)
                st.add(v0, c0)
        if cur > best_loc + 1e-12:
            best_loc = cur
            best_set = st.vA[:st.m].copy()
    cand = sorted(set(int(x) for x in best_set))
    try:
        if _eval(cand) > best_score:
            return cand
    except Exception:
        pass
    return sorted(set(best_a))
# EVOLVE-BLOCK-END
