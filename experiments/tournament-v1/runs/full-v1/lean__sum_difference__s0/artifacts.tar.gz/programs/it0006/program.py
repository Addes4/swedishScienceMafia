# EVOLVE-BLOCK-START
"""Simplex lattice construction embedded in Z, then hill-climb on embedding weights
(non-injective projections merge sums/differences and can raise the log ratio)."""
import math
import time
import random
import numpy as np


def _points(d, n):
    pts = [()]
    for _ in range(d):
        new = []
        for p in pts:
            s = sum(p)
            for v in range(n - s + 1):
                new.append(p + (v,))
        pts = new
    return np.array(pts, dtype=np.int64).reshape(len(pts), d)


def _count(arr):
    arr = arr.ravel()
    arr.sort()
    return int(1 + np.count_nonzero(arr[1:] != arr[:-1]))


def _eval(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    if len(a) < 2:
        return -1.0
    s = _count(a[:, None] + a[None, :])
    d = _count(a[:, None] - a[None, :])
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def solve():
    start = time.time()
    rng = random.Random(12345)
    cands = []
    for d in range(2, 14):
        for n in range(1, 60):
            sz = math.comb(n + d, d)
            if sz > 4000:
                break
            if sz >= 400 and n * (2 * n + 1) ** (d - 1) < 10 ** 14:
                cands.append((sz, d, n))
    cands.sort()
    best, best_score = [0, 1, 3], -1.0
    scored = []
    for sz, d, n in cands:
        if time.time() - start > 40:
            break
        pts = _points(d, n)
        B = 2 * n + 1
        w = np.array([B ** i for i in range(d)], dtype=np.int64)
        a = pts @ w
        sc = _eval(a)
        scored.append((sc, sz, d, n))
        if sc > best_score:
            best_score, best = sc, [int(x) for x in np.unique(a)]

    # hill-climb on weights for a mid-size candidate
    mid = [t for t in scored if t[1] <= 1600]
    if mid:
        mid.sort(reverse=True)
        sc0, sz, d, n = mid[0]
        pts = _points(d, n)
        B = 2 * n + 1
        w = [B ** i for i in range(d)]
        cur = _eval(pts @ np.array(w, dtype=np.int64))
        # try varied bases first
        for Bp in range(n + 1, 2 * n + 1):
            if time.time() - start > 60:
                break
            wp = [Bp ** i for i in range(d)]
            sc = _eval(pts @ np.array(wp, dtype=np.int64))
            if sc > cur:
                cur, w = sc, wp
        maxw = max(w) * 2
        while time.time() - start < 105:
            w2 = list(w)
            k = rng.choice([1, 1, 2])
            for _ in range(k):
                i = rng.randrange(d)
                scale = max(1, int(w2[i] * 10 ** (-rng.random() * 3)))
                w2[i] = max(1, min(maxw, w2[i] + rng.randint(-scale, scale)))
            a = pts @ np.array(w2, dtype=np.int64)
            sc = _eval(a)
            if sc >= cur:
                cur, w = sc, w2
        a = np.unique(pts @ np.array(w, dtype=np.int64))
        if cur > best_score:
            best_score, best = cur, [int(x) for x in a]
    return sorted(set(best))
# EVOLVE-BLOCK-END
