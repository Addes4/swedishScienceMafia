# EVOLVE-BLOCK-START
"""Capped simplex lattice: A = {x in Z^d_{>=0}: sum x <= n, x_i <= m} embedded in Z via base 2m+1."""
import math
import time
import numpy as np


def _count_pts(d, n, m):
    # number of points with d coords in [0,m], sum <= n
    dp = [0] * (n + 1)
    dp[0] = 1
    for _ in range(d):
        new = [0] * (n + 1)
        for s, c in enumerate(dp):
            if c:
                for v in range(min(m, n - s) + 1):
                    new[s + v] += c
        dp = new
    return sum(dp)


def _points(d, n, m):
    pts = np.zeros((1, 0), dtype=np.int64)
    sums = np.zeros(1, dtype=np.int64)
    for _ in range(d):
        parts = []
        sparts = []
        for v in range(m + 1):
            mask = sums + v <= n
            if not mask.any():
                break
            p = pts[mask]
            parts.append(np.hstack([p, np.full((p.shape[0], 1), v, dtype=np.int64)]))
            sparts.append(sums[mask] + v)
        pts = np.vstack(parts)
        sums = np.concatenate(sparts)
    return pts


def _count(arr):
    arr = arr.ravel()
    arr.sort()
    return int(1 + np.count_nonzero(arr[1:] != arr[:-1]))


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    s = _count(a[:, None] + a[None, :])
    d = _count(a[:, None] - a[None, :])
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def solve():
    start = time.time()
    full = []
    capped = []
    for d in range(2, 16):
        for n in range(1, 40):
            if math.comb(n + d, d) < 1500 and False:
                continue
            for m in range(1, n + 1):
                if m * 2 + 1 > 2 * n + 1:
                    continue
                if (2 * m + 1) ** (d - 1) * m > 3 * 10 ** 14:
                    break
                sz = _count_pts(d, n, m)
                if sz < 1500 or sz > 4000:
                    continue
                if m == n:
                    full.append((-sz, d, n, m))
                else:
                    capped.append((-sz, d, n, m))
    full.sort()
    capped.sort()
    order = full[:8]
    rest = capped
    # interleave capped candidates after the plain simplices
    order = order + rest + full[8:]
    best, best_score = [0, 1, 3], -1
    for _, d, n, m in order:
        if time.time() - start > 95:
            break
        pts = _points(d, n, m)
        B = 2 * m + 1
        w = np.array([B ** i for i in range(d)], dtype=np.int64)
        a = pts @ w
        if len(a) > 4000:
            continue
        sc = _eval(a)
        if sc > best_score:
            best_score, best = sc, [int(x) for x in a]
    return sorted(set(best))
# EVOLVE-BLOCK-END
