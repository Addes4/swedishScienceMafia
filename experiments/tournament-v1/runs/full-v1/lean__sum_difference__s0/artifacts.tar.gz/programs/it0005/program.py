# EVOLVE-BLOCK-START
"""Weighted simplex lattice sets, hill-climbed over weights and threshold."""
import math
import time
import random
import numpy as np


def _count(arr):
    arr = arr.ravel()
    arr.sort()
    return int(1 + np.count_nonzero(arr[1:] != arr[:-1]))


def _score(a):
    a = np.asarray(a, dtype=np.int64)
    s = _count(a[:, None] + a[None, :])
    d = _count(a[:, None] - a[None, :])
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _build(w, T, cap=4000):
    d = len(w)
    M = [T // wi for wi in w]
    prod = 1
    for m in M:
        prod *= (2 * m + 1)
        if prod > 10 ** 14:
            return None
    code = np.zeros(1, dtype=np.int64)
    ws = np.zeros(1, dtype=np.int64)
    mult = 1
    for i in range(d):
        cs = []
        wss = []
        for v in range(M[i] + 1):
            nw = ws + v * w[i]
            mask = nw <= T
            if not mask.any():
                break
            cs.append(code[mask] + v * mult)
            wss.append(nw[mask])
        code = np.concatenate(cs)
        ws = np.concatenate(wss)
        if len(code) > cap:
            return None
        mult *= (2 * M[i] + 1)
    return code


def solve():
    start = time.time()
    best_set = [0, 1, 3]
    best_score = -1.0
    cur = None

    # starting simplex candidates
    cands = []
    for d in range(3, 13):
        for n in range(2, 40):
            sz = math.comb(n + d, d)
            if sz > 4000:
                break
            if sz >= 1500:
                cands.append((sz, d, n))
    cands.sort(reverse=True)
    for sz, d, n in cands[:10]:
        if time.time() - start > 25:
            break
        w = [1] * d
        a = _build(w, n)
        if a is None:
            continue
        sc = _score(a)
        if sc > best_score:
            best_score = sc
            best_set = a
            cur = (w, n)

    if cur is None:
        return [0, 1, 3]
    # rescale weights for granularity
    k = 3
    w = [x * k for x in cur[0]]
    T = cur[1] * k
    cur_w, cur_T, cur_sc = w, T, best_score
    rng = random.Random(1)
    while time.time() - start < 100:
        nw = list(cur_w)
        nT = cur_T
        r = rng.random()
        if r < 0.25:
            nT += rng.choice([-1, 1])
        elif r < 0.85:
            i = rng.randrange(len(nw))
            nw[i] += rng.choice([-1, 1])
        else:
            i = rng.randrange(len(nw))
            nw[i] += rng.choice([-1, 1])
            nT += rng.choice([-2, -1, 0, 1, 2])
        if min(nw) < 1 or nT < 2:
            continue
        a = _build(nw, nT)
        if a is None or len(a) < 800:
            continue
        sc = _score(a)
        if sc >= cur_sc:
            cur_w, cur_T, cur_sc = nw, nT, sc
            if sc > best_score:
                best_score = sc
                best_set = a
    return sorted(set(int(x) for x in best_set))
# EVOLVE-BLOCK-END
