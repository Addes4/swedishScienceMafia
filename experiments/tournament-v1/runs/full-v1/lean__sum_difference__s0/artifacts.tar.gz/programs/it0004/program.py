# EVOLVE-BLOCK-START
"""Simplex lattice construction in base 2n+1, followed by exact-count local search
(remove / re-add points of the simplex pool) to improve log|A-A|/log|A+A|."""
import math
import time
import numpy as np


def _points(d, n):
    pts = [()]
    for _ in range(d):
        new = []
        for p in pts:
            s = sum(p)
            for v in range(n - s + 1):
                new.append(p + (v,))
        pts = new
    return np.array(pts, dtype=np.int64).reshape(len(pts), d)


def _count(arr):
    arr = arr.ravel()
    arr.sort()
    return int(1 + np.count_nonzero(arr[1:] != arr[:-1]))


def _eval(a):
    a = np.asarray(a, dtype=np.int64)
    s = _count(a[:, None] + a[None, :])
    d = _count(a[:, None] - a[None, :])
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _local_search(P, t_end):
    P = np.sort(np.asarray(P, dtype=np.int64))
    m = len(P)
    sumsU, Cs = np.unique((P[:, None] + P[None, :]).ravel(), return_counts=True)
    Cs = Cs.astype(np.int64)
    difU, Cd = np.unique((P[:, None] - P[None, :]).ravel(), return_counts=True)
    Cd = Cd.astype(np.int64)
    inA = np.ones(m, dtype=bool)
    S = int(np.count_nonzero(Cs))
    D = int(np.count_nonzero(Cd))
    n = m

    def score(S_, D_, n_):
        return math.log(D_) / math.log(S_) + (1 - 1 / n_) / 100

    cur = score(S, D, n)
    best_cur = cur
    best_mask = inA.copy()
    rng = np.random.default_rng(1)
    Ac = P[inA]
    while time.time() < t_end:
        for _ in range(50):
            i = int(rng.integers(m))
            x = int(P[i])
            rem = bool(inA[i])
            if rem and n <= 100:
                continue
            others = Ac[Ac != x]
            svals = np.append(x + others, 2 * x)
            sred = np.full(len(svals), 2, dtype=np.int64)
            sred[-1] = 1
            dvals = np.concatenate([x - others, others - x, np.zeros(1, dtype=np.int64)])
            si = np.searchsorted(sumsU, svals)
            di = np.searchsorted(difU, dvals)
            if rem:
                dS = -int(np.count_nonzero(Cs[si] == sred))
                dD = -int(np.count_nonzero(Cd[di] == 1))
                n2 = n - 1
            else:
                dS = int(np.count_nonzero(Cs[si] == 0))
                dD = int(np.count_nonzero(Cd[di] == 0))
                n2 = n + 1
            S2 = S + dS
            D2 = D + dD
            if S2 <= 1 or D2 <= 1:
                continue
            sc = score(S2, D2, n2)
            if sc > cur + 1e-12:
                sign = -1 if rem else 1
                Cs[si] += sign * sred
                Cd[di] += sign
                S, D, n, cur = S2, D2, n2, sc
                inA[i] = not rem
                Ac = P[inA]
                if cur > best_cur:
                    best_cur = cur
                    best_mask = inA.copy()
    return P[best_mask], best_cur


def solve():
    start = time.time()
    cands = []
    for d in range(2, 14):
        for n in range(1, 60):
            sz = math.comb(n + d, d)
            if sz > 4000:
                break
            if sz >= 1000 and (2 * n + 1) ** d < 10 ** 14:
                cands.append((sz, d, n))
    cands.sort(reverse=True)
    best, best_score = [0, 1, 3], -1
    best_arr = None
    for sz, d, n in cands:
        if time.time() - start > 45:
            break
        pts = _points(d, n)
        B = 2 * n + 1
        w = np.array([B ** i for i in range(d)], dtype=np.int64)
        a = pts @ w
        sc = _eval(a)
        if sc > best_score:
            best_score, best = sc, [int(x) for x in a]
            best_arr = a
    try:
        if best_arr is not None and len(best_arr) <= 4000:
            res, sc = _local_search(best_arr, start + 100)
            if sc > best_score and len(res) >= 3:
                best = [int(x) for x in res]
    except Exception:
        pass
    return sorted(set(best))
# EVOLVE-BLOCK-END
