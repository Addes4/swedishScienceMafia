import numpy as np
from scipy.optimize import minimize
import math


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    
    # Initialize with a good configuration
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    centers += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()] for _ in range(n - len(centers))]
    centers = np.clip(np.array(centers[:n], dtype=np.float64), 0.01, 0.99)
    
    # Initial optimization
    best_centers = centers.copy()
    best_radii = max_radii(best_centers)
    best_score = np.sum(best_radii)
    
    # Basin hopping with local removal and reinsertion
    temperature = 0.1
    cooling = 0.995
    max_iterations = 100
    
    for iteration in range(max_iterations):
        # Find smallest circle (or one to move)
        radii = max_radii(best_centers)
        idx_to_move = np.argmin(radii)
        
        # Remove it temporarily
        remaining_centers = np.delete(best_centers, idx_to_move, axis=0)
        
        # Find the largest empty hole via sampling
        best_hole = None
        best_clearance = 0
        
        # Sample many random points
        n_samples = 500
        for _ in range(n_samples):
            x = np.random.uniform(0.05, 0.95)
            y = np.random.uniform(0.05, 0.95)
            point = np.array([x, y])
            
            # Clearance is the distance to nearest obstacle
            clearance = min(x, y, 1-x, 1-y)  # distance to walls
            
            if len(remaining_centers) > 0:
                dists = np.linalg.norm(remaining_centers - point, axis=1)
                remaining_radii = max_radii(remaining_centers)
                # Clearance is distance to nearest circle boundary
                clearance = np.min(dists - remaining_radii)
            
            if clearance > best_clearance:
                best_clearance = clearance
                best_hole = point
        
        # If no good hole found, try a grid search
        if best_hole is None or best_clearance < 0.01:
            grid_size = 8
            for i in range(grid_size):
                for j in range(grid_size):
                    x = 0.1 + (i + 0.5) / grid_size * 0.8
                    y = 0.1 + (j + 0.5) / grid_size * 0.8
                    point = np.array([x, y])
                    
                    clearance = min(x, y, 1-x, 1-y)
                    if len(remaining_centers) > 0:
                        dists = np.linalg.norm(remaining_centers - point, axis=1)
                        remaining_radii = max_radii(remaining_centers)
                        clearance = np.min(dists - remaining_radii)
                    
                    if clearance > best_clearance:
                        best_clearance = clearance
                        best_hole = point
        
        if best_hole is None:
            best_hole = np.array([0.5, 0.5])
        
        # Create new configuration with moved circle
        new_centers = remaining_centers.copy()
        new_centers = np.vstack([new_centers, best_hole])
        
        # Optimize with SLSQP
        new_centers = optimize_centers(new_centers)
        new_radii = max_radii(new_centers)
        new_score = np.sum(new_radii)
        
        # Metropolis acceptance
        delta = new_score - best_score
        if delta > 0 or np.random.rand() < np.exp(delta / max(temperature, 0.001)):
            best_centers = new_centers.copy()
            best_score = new_score
        
        temperature *= cooling
    
    final_radii = max_radii(best_centers)
    return best_centers, final_radii


def optimize_centers(centers):
    """Optimize circle centers using SLSQP to maximize sum of radii."""
    n = len(centers)
    
    def objective(x):
        c = x.reshape((n, 2))
        r = max_radii(c)
        return -np.sum(r)
    
    def constraint_bounds(x):
        c = x.reshape((n, 2))
        return np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]]) - 0.001
    
    x0 = centers.flatten()
    
    result = minimize(
        objective,
        x0,
        method='SLSQP',
        constraints={'type': 'ineq', 'fun': constraint_bounds},
        bounds=[(0.001, 0.999) for _ in range(2*n)],
        options={'maxiter': 50, 'ftol': 1e-4}
    )
    
    return np.clip(result.x.reshape((n, 2)), 0.001, 0.999)


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d + 1e-9:
                    scale = (d - 1e-9) / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    
    return np.maximum(radii, 0.0)
