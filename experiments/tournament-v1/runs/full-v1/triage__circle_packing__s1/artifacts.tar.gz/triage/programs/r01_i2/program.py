# EVOLVE-BLOCK-START
"""LP-optimal radii for fixed centres, wrapped in a basin-hopping / annealing
search over centres, with SLSQP joint polishing of promising candidates."""
import time
import numpy as np
from scipy.optimize import linprog, minimize


def _setup(n):
    I, J = np.triu_indices(n, 1)
    m = len(I)
    A = np.zeros((m, n))
    A[np.arange(m), I] = 1.0
    A[np.arange(m), J] = 1.0
    return I, J, A


def lp_radii(c, I, J, A):
    n = len(c)
    d = np.sqrt(((c[I] - c[J]) ** 2).sum(1))
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    wall = np.maximum(wall, 0.0)
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d,
                      bounds=list(zip(np.zeros(n), wall)), method="highs")
        if res.status == 0:
            r = np.clip(res.x, 0, None)
            return r, r.sum()
    except Exception:
        pass
    return np.zeros(n), 0.0


def polish(c, r, I, J, maxiter=300):
    n = len(c)
    m = len(I)
    x0 = np.concatenate([c.ravel(), r])

    def obj(x):
        return -x[2 * n:].sum()

    def obj_jac(x):
        g = np.zeros(3 * n)
        g[2 * n:] = -1.0
        return g

    def cons(x):
        p = x[:2 * n].reshape(n, 2)
        rr = x[2 * n:]
        diff = p[I] - p[J]
        d = np.sqrt((diff ** 2).sum(1)) + 1e-15
        g1 = d - rr[I] - rr[J]
        g2 = np.concatenate([p[:, 0] - rr, p[:, 1] - rr,
                             1 - p[:, 0] - rr, 1 - p[:, 1] - rr])
        return np.concatenate([g1, g2])

    rowsm = np.arange(m)

    def cons_jac(x):
        p = x[:2 * n].reshape(n, 2)
        diff = p[I] - p[J]
        d = np.sqrt((diff ** 2).sum(1)) + 1e-15
        u = diff / d[:, None]
        Jm = np.zeros((m + 4 * n, 3 * n))
        Jm[rowsm, 2 * I] = u[:, 0]
        Jm[rowsm, 2 * I + 1] = u[:, 1]
        Jm[rowsm, 2 * J] = -u[:, 0]
        Jm[rowsm, 2 * J + 1] = -u[:, 1]
        Jm[rowsm, 2 * n + I] = -1
        Jm[rowsm, 2 * n + J] = -1
        k = np.arange(n)
        Jm[m + k, 2 * k] = 1
        Jm[m + n + k, 2 * k + 1] = 1
        Jm[m + 2 * n + k, 2 * k] = -1
        Jm[m + 3 * n + k, 2 * k + 1] = -1
        for q in range(4):
            Jm[m + q * n + k, 2 * n + k] = -1
        return Jm

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(obj, x0, jac=obj_jac, method="SLSQP", bounds=bounds,
                       constraints=[{"type": "ineq", "fun": cons, "jac": cons_jac}],
                       options={"maxiter": maxiter, "ftol": 1e-12})
        return np.clip(res.x[:2 * n].reshape(n, 2), 0, 1)
    except Exception:
        return c


def make_feasible(c, r):
    c = np.clip(c, 0, 1)
    r = np.clip(r, 0, None)
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    r = np.minimum(r, wall)
    r = np.maximum(r - 1e-10, 0)
    n = len(c)
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(c[i] - c[j])
                if r[i] + r[j] > d:
                    s = d / (r[i] + r[j]) * (1 - 1e-12)
                    r[i] *= s
                    r[j] *= s
                    changed = True
        if not changed:
            break
    return r


def solve(n=26):
    t0 = time.time()
    budget = 220.0
    rng = np.random.default_rng(12345)
    I, J, A = _setup(n)

    def evaluate(c):
        r, s = lp_radii(c, I, J, A)
        return r, s

    def full(c):
        r, _ = evaluate(c)
        c2 = polish(c, r, I, J)
        r2, s2 = evaluate(c2)
        return c2, r2, s2

    best_c, best_r, best_s = None, None, -1.0

    def starts():
        while True:
            kind = rng.integers(3)
            if kind == 0:
                yield rng.uniform(0.05, 0.95, (n, 2))
            elif kind == 1:
                g = np.linspace(0.1, 0.9, 5)
                X, Y = np.meshgrid(g, g)
                p = np.c_[X.ravel(), Y.ravel()]
                extra = rng.uniform(0.1, 0.9, (n - 25, 2))
                p = np.vstack([p, extra])[:n]
                yield np.clip(p + rng.normal(0, 0.03, p.shape), 0.02, 0.98)
            else:
                pts = []
                rows = [5, 6, 5, 6, 5] if rng.random() < 0.5 else [6, 5, 6, 5, 6]
                ys = np.linspace(0.1, 0.9, len(rows))
                for y, k in zip(ys, rows):
                    for x in np.linspace(0.1, 0.9, k):
                        pts.append([x, y])
                p = np.array(pts)
                if len(p) < n:
                    p = np.vstack([p, rng.uniform(0.1, 0.9, (n - len(p), 2))])
                p = p[rng.permutation(len(p))[:n]] if len(p) > n else p
                yield np.clip(p + rng.normal(0, 0.03, p.shape), 0.02, 0.98)

    # Phase 1: multistart
    gen = starts()
    pool = []
    while time.time() - t0 < 0.3 * budget:
        c = next(gen)
        c2, r2, s2 = full(c)
        pool.append((s2, c2))
        if s2 > best_s:
            best_s, best_c, best_r = s2, c2.copy(), r2.copy()

    # Phase 2: basin hopping / annealing with LP objective + polish
    cur_c, cur_s = best_c.copy(), best_s
    T = 0.01
    it = 0
    while time.time() - t0 < budget:
        it += 1
        c = cur_c.copy()
        mv = rng.random()
        if mv < 0.35:
            c += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), c.shape)
        elif mv < 0.6:
            k = rng.integers(1, 4)
            idx = rng.choice(n, k, replace=False)
            c[idx] += rng.normal(0, 0.1, (k, 2))
        elif mv < 0.85:
            r_cur, _ = evaluate(cur_c)
            k = rng.integers(1, 3)
            idx = np.argsort(r_cur)[:k + 1]
            idx = rng.choice(idx, k, replace=False)
            c[idx] = rng.uniform(0.05, 0.95, (k, 2))
        else:
            k = rng.integers(1, 3)
            idx = rng.choice(n, k, replace=False)
            c[idx] = rng.uniform(0.05, 0.95, (k, 2))
        c = np.clip(c, 0.0, 1.0)
        # quick LP screening, then polish
        _, s_lp = evaluate(c)
        c2, r2, s2 = full(c)
        if s2 > best_s + 1e-9:
            best_s, best_c, best_r = s2, c2.copy(), r2.copy()
        if s2 > cur_s or rng.random() < np.exp((s2 - cur_s) / T):
            cur_c, cur_s = c2, s2
        T = max(0.002, T * 0.995)
        if it % 60 == 0:
            cur_c, cur_s = best_c.copy(), best_s
            T = 0.01

    # final polish for precision
    c2 = polish(best_c, best_r, I, J, maxiter=1000)
    r2, s2 = evaluate(c2)
    if s2 > best_s:
        best_c, best_r, best_s = c2, r2, s2

    r_final = make_feasible(best_c, best_r)
    return np.array(best_c), np.array(r_final)


def max_radii(centers):
    I, J, A = _setup(len(centers))
    r, _ = lp_radii(np.asarray(centers, float), I, J, A)
    return make_feasible(np.asarray(centers, float), r)
# EVOLVE-BLOCK-END
