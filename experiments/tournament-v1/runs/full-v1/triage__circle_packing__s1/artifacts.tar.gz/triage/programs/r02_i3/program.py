import time
import numpy as np
from scipy.optimize import minimize, linprog


def _lp_radii(centers):
    """Best radii for fixed centres via LP (max sum r)."""
    n = len(centers)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    A = np.zeros((len(I), n))
    A[np.arange(len(I)), I] = 1
    A[np.arange(len(I)), J] = 1
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status != 0:
        return None
    return np.maximum(res.x, 0)


def _safe_radii(centers):
    r = _lp_radii(centers)
    if r is None:
        r = np.zeros(len(centers))
    r = r * (1 - 1e-12)
    n = len(centers)
    for _ in range(5):
        bad = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if r[i] + r[j] > d:
                    s = d / (r[i] + r[j]) * (1 - 1e-13)
                    r[i] *= s
                    r[j] *= s
                    bad = True
        if not bad:
            break
    return r


def solve(n=26):
    t0 = time.time()
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    npair = len(I)
    ar = np.arange(npair)

    Wj = np.zeros((4 * n, 3 * n))
    for i in range(n):
        Wj[i, i] = 1; Wj[i, 2 * n + i] = -1
        Wj[n + i, i] = -1; Wj[n + i, 2 * n + i] = -1
        Wj[2 * n + i, n + i] = 1; Wj[2 * n + i, 2 * n + i] = -1
        Wj[3 * n + i, n + i] = -1; Wj[3 * n + i, 2 * n + i] = -1
    Wc = np.concatenate([np.zeros(n), np.ones(n), np.zeros(n), np.ones(n)])

    def cons(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        dx = x[I] - x[J]; dy = y[I] - y[J]; sr = r[I] + r[J]
        g = dx * dx + dy * dy - sr * sr
        return np.concatenate([g, Wj @ v + Wc])

    def cjac(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        dx = x[I] - x[J]; dy = y[I] - y[J]; sr = r[I] + r[J]
        Jm = np.zeros((npair, 3 * n))
        Jm[ar, I] = 2 * dx; Jm[ar, J] = -2 * dx
        Jm[ar, n + I] = 2 * dy; Jm[ar, n + J] = -2 * dy
        Jm[ar, 2 * n + I] = -2 * sr; Jm[ar, 2 * n + J] = -2 * sr
        return np.vstack([Jm, Wj])

    obj = lambda v: -np.sum(v[2 * n:])
    gj = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    ojac = lambda v: gj
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def run(v0, maxiter=250):
        try:
            res = minimize(obj, v0, jac=ojac, method="SLSQP", bounds=bounds,
                           constraints=[{"type": "ineq", "fun": cons, "jac": cjac}],
                           options={"maxiter": maxiter, "ftol": 1e-10})
            return res.x
        except Exception:
            return None

    def eval_centers(v):
        c = np.column_stack([np.clip(v[:n], 0, 1), np.clip(v[n:2 * n], 0, 1)])
        r = _lp_radii(c)
        if r is None:
            return -1, c
        return r.sum(), c

    # ---------- symmetric parametrisation ----------
    def make_sym(k, m):
        # p = [xs(k), ys(k), rs(k), ya(m), ra(m)]
        P = 3 * k + 2 * m
        M = np.zeros((3 * n, P))
        b = np.zeros(3 * n)
        for i in range(k):
            M[i, i] = 1                      # x_i
            M[k + i, i] = -1; b[k + i] = 1   # 1 - x_i
            M[n + i, k + i] = 1              # y
            M[n + k + i, k + i] = 1
            M[2 * n + i, 2 * k + i] = 1      # r
            M[2 * n + k + i, 2 * k + i] = 1
        for a in range(m):
            idx = 2 * k + a
            b[idx] = 0.5
            M[n + idx, 3 * k + a] = 1
            M[2 * n + idx, 3 * k + m + a] = 1
        sb = [(0, 0.5)] * k + [(0, 1)] * k + [(0, 0.5)] * k + [(0, 1)] * m + [(0, 0.5)] * m
        return M, b, sb

    sym_cfg = {}
    for (k, m) in [(13, 0), (12, 2), (11, 4)]:
        sym_cfg[(k, m)] = make_sym(k, m)

    def run_sym(k, m, maxiter=200):
        M, b, sb = sym_cfg[(k, m)]
        xs = rng.uniform(0.03, 0.5, k)
        ys = rng.uniform(0.05, 0.95, k)
        rs = rng.uniform(0.03, 0.1, k)
        ya = rng.uniform(0.05, 0.95, m)
        ra = rng.uniform(0.03, 0.1, m)
        p0 = np.concatenate([xs, ys, rs, ya, ra])
        sobj = lambda p: -np.sum((M @ p + b)[2 * n:])
        sg = M.T @ gj
        sjac = lambda p: sg
        scons = lambda p: cons(M @ p + b)
        scjac = lambda p: cjac(M @ p + b) @ M
        try:
            res = minimize(sobj, p0, jac=sjac, method="SLSQP", bounds=sb,
                           constraints=[{"type": "ineq", "fun": scons, "jac": scjac}],
                           options={"maxiter": maxiter, "ftol": 1e-10})
            return M @ res.x + b
        except Exception:
            return None

    best_val, best_c, best_v = -1, None, None

    def consider(v):
        nonlocal best_val, best_c, best_v
        val, c = eval_centers(v)
        if val > best_val:
            best_val, best_c, best_v = val, c, v
        return val

    # ---------- phase 1: symmetric search + polish ----------
    sym_limit = 90.0
    cfgs = [(13, 0), (12, 2), (11, 4)]
    best_sym = -1
    it = 0
    while time.time() - t0 < sym_limit:
        k, m = cfgs[it % 3] if it % 4 != 3 else cfgs[0]
        it += 1
        v = run_sym(k, m)
        if v is None:
            continue
        val, _ = eval_centers(v)
        if val > best_sym:
            best_sym = val
        if val > 0.985 * max(best_sym, 2.55):
            # release symmetry: perturb slightly and polish full problem
            v1 = v.copy()
            v1[:2 * n] += rng.normal(0, 0.003, 2 * n)
            v1[:2 * n] = np.clip(v1[:2 * n], 0.0, 1.0)
            vp = run(v1, 300)
            if vp is not None:
                consider(vp)
            vp = run(v, 300)
            if vp is not None:
                consider(vp)
        else:
            consider(v)

    # ---------- phase 2: general random / perturbation search ----------
    def rows_seed(pattern, jit):
        pts = []
        k = len(pattern)
        for ri, mm in enumerate(pattern):
            y = (ri + 0.5) / k
            for j in range(mm):
                pts.append([(j + 0.5) / mm, y])
        pts = np.array(pts[:n], dtype=float)
        while len(pts) < n:
            pts = np.vstack([pts, rng.random(2)])
        pts += rng.normal(0, jit, pts.shape)
        return np.clip(pts, 0.03, 0.97)

    patterns = [[5, 5, 6, 5, 5], [5, 6, 5, 6, 4], [6, 5, 5, 5, 5], [4, 5, 4, 5, 4, 4],
                [5, 5, 5, 5, 6], [5, 4, 5, 4, 5, 3]]

    def make_seed(kind):
        if kind == 0:
            pts = rows_seed(patterns[rng.integers(len(patterns))], rng.choice([0.01, 0.03, 0.05]))
        elif kind == 1:
            pts = [[0.1, 0.1], [0.9, 0.1], [0.1, 0.9], [0.9, 0.9],
                   [0.5, 0.08], [0.5, 0.92], [0.08, 0.5], [0.92, 0.5],
                   [0.3, 0.3], [0.7, 0.3], [0.3, 0.7], [0.7, 0.7], [0.5, 0.5]]
            pts = np.array(pts)
            extra = rng.random((n - len(pts), 2)) * 0.9 + 0.05
            pts = np.vstack([pts, extra])[:n]
            pts += rng.normal(0, 0.03, pts.shape)
            pts = np.clip(pts, 0.03, 0.97)
        else:
            pts = rng.random((n, 2)) * 0.9 + 0.05
        r0 = rng.uniform(0.03, 0.1, n)
        return np.concatenate([pts[:, 0], pts[:, 1], r0])

    limit = 200.0
    it = 0
    while time.time() - t0 < limit:
        if best_v is not None and it % 3 != 0:
            v0 = best_v.copy()
            s = rng.choice([0.01, 0.03, 0.06])
            v0[:2 * n] += rng.normal(0, s, 2 * n)
            if rng.random() < 0.3:
                for _ in range(rng.integers(1, 3)):
                    kk = rng.integers(n)
                    v0[kk] = rng.random(); v0[n + kk] = rng.random()
            v0[:2 * n] = np.clip(v0[:2 * n], 0.02, 0.98)
            v0[2 * n:] = np.maximum(v0[2 * n:] * 0.7, 0.01)
        else:
            v0 = make_seed(rng.integers(3))
        it += 1
        v = run(v0)
        if v is None:
            continue
        consider(v)

    if best_c is None:
        c = rows_seed([5, 5, 6, 5, 5], 0.0)
        return c, _safe_radii(c)
    radii = _safe_radii(best_c)
    return best_c, radii
