# EVOLVE-BLOCK-START
"""Joint SLSQP optimisation of centres and radii with multi-start initialisation."""
import time
import numpy as np
from scipy.optimize import minimize


def _repair(centers, radii):
    """Make radii strictly feasible (walls and pairs) by shrinking."""
    n = len(centers)
    r = np.maximum(np.asarray(radii, float), 0.0)
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    r = np.minimum(r, np.maximum(wall, 0.0))
    D = np.sqrt(((centers[:, None, :] - centers[None, :, :]) ** 2).sum(-1))
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                if r[i] + r[j] > D[i, j]:
                    s = D[i, j] / (r[i] + r[j])
                    r[i] *= s
                    r[j] *= s
                    changed = True
        if not changed:
            break
    r = np.maximum(r - 1e-12, 0.0)
    return r


def _initial(n, rng, k):
    mode = k % 4
    if mode == 0:
        c = rng.random((n, 2)) * 0.9 + 0.05
    elif mode == 1:
        # jittered row layout
        rows = rng.choice([[5, 5, 6, 5, 5], [5, 6, 5, 6, 4], [6, 5, 5, 5, 5], [4, 5, 5, 6, 6]])
        pts = []
        nr = len(rows)
        for ri, m in enumerate(rows):
            y = (ri + 0.5) / nr
            for ci in range(m):
                pts.append([(ci + 0.5) / m, y])
        c = np.array(pts[:n], float)
        while len(c) < n:
            c = np.vstack([c, rng.random((1, 2))])
        c += rng.normal(0, 0.03, c.shape)
    elif mode == 2:
        # rings
        n_in = rng.integers(1, 3)
        n_mid = rng.integers(5, 9)
        n_out = n - n_in - n_mid
        pts = [[0.5 + 0.05 * rng.normal(), 0.5 + 0.05 * rng.normal()] for _ in range(n_in)]
        ph = rng.random() * 6.28
        pts += [[0.5 + 0.25 * np.cos(ph + 2 * np.pi * i / n_mid), 0.5 + 0.25 * np.sin(ph + 2 * np.pi * i / n_mid)] for i in range(n_mid)]
        ph = rng.random() * 6.28
        pts += [[0.5 + 0.42 * np.cos(ph + 2 * np.pi * i / n_out), 0.5 + 0.42 * np.sin(ph + 2 * np.pi * i / n_out)] for i in range(n_out)]
        c = np.array(pts) + rng.normal(0, 0.02, (n, 2))
    else:
        # perimeter + random interior
        m = min(n - 4, 12)
        pts = [[0.08, 0.08], [0.92, 0.08], [0.08, 0.92], [0.92, 0.92]]
        for i in range(m):
            t = (i + 0.5) / m * 4
            s = int(t)
            f = t - s
            p = [[f, 0.08], [0.92, f], [1 - f, 0.92], [0.08, 1 - f]][s]
            pts.append([min(max(p[0], 0.08), 0.92), min(max(p[1], 0.08), 0.92)])
        c = np.array(pts)
        c = np.vstack([c, rng.random((n - len(c), 2)) * 0.6 + 0.2])
    return np.clip(c, 0.03, 0.97)


def solve(n=26):
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    P = len(I)
    nw = 4 * n
    ar = np.arange(n)
    ar_p = np.arange(P)

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        d = np.sqrt((x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2)
        return np.concatenate([d - r[I] - r[J], x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(z):
        x, y = z[:n], z[n:2 * n]
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        d = np.sqrt(dx * dx + dy * dy) + 1e-14
        Jm = np.zeros((P + nw, 3 * n))
        Jm[ar_p, I] = dx / d
        Jm[ar_p, J] = -dx / d
        Jm[ar_p, n + I] = dy / d
        Jm[ar_p, n + J] = -dy / d
        Jm[ar_p, 2 * n + I] = -1
        Jm[ar_p, 2 * n + J] = -1
        o = P
        Jm[o + ar, ar] = 1;  Jm[o + ar, 2 * n + ar] = -1
        o += n
        Jm[o + ar, ar] = -1; Jm[o + ar, 2 * n + ar] = -1
        o += n
        Jm[o + ar, n + ar] = 1;  Jm[o + ar, 2 * n + ar] = -1
        o += n
        Jm[o + ar, n + ar] = -1; Jm[o + ar, 2 * n + ar] = -1
        return Jm

    def obj(z):
        return -np.sum(z[2 * n:])

    gradv = np.zeros(3 * n)
    gradv[2 * n:] = -1.0

    def grad(z):
        return gradv

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    best_s, best = -1.0, None
    t0 = time.time()
    budget = 200.0
    k = 0
    last = 0.0
    while True:
        el = time.time() - t0
        if k > 0 and el + 2.5 * last > budget:
            break
        ts = time.time()
        c = _initial(n, rng, k)
        k += 1
        # initial radii: half nearest neighbour dist, bounded by walls
        D = np.sqrt(((c[:, None] - c[None]) ** 2).sum(-1)) + np.eye(n) * 9
        r0 = np.minimum(0.5 * D.min(1), np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]]))
        z0 = np.concatenate([c[:, 0], c[:, 1], r0])
        try:
            res = minimize(obj, z0, jac=grad, method='SLSQP', bounds=bounds,
                           constraints=[{'type': 'ineq', 'fun': cons, 'jac': jac}],
                           options={'maxiter': 400, 'ftol': 1e-11})
            z = res.x
            cc = np.clip(np.stack([z[:n], z[n:2 * n]], 1), 0, 1)
            rr = _repair(cc, z[2 * n:])
            s = rr.sum()
            if s > best_s:
                best_s, best = s, (cc, rr)
        except Exception:
            pass
        last = time.time() - ts
    if best is None:
        c = _initial(n, rng, 0)
        return c, _repair(c, np.zeros(n))
    return best
# EVOLVE-BLOCK-END
