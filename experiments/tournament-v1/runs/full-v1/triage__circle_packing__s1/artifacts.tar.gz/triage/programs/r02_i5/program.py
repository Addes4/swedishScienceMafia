import time
import numpy as np
from scipy.optimize import minimize, linprog


def _lp_radii(centers):
    """Best radii for fixed centres via LP (max sum r)."""
    n = len(centers)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    A = np.zeros((len(I), n))
    A[np.arange(len(I)), I] = 1
    A[np.arange(len(I)), J] = 1
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status != 0:
        return None
    return np.maximum(res.x, 0)


def _safe_radii(centers):
    r = _lp_radii(centers)
    if r is None:
        r = np.zeros(len(centers))
    r = r * (1 - 1e-12)
    n = len(centers)
    for i in range(n):
        wall = min(centers[i, 0], centers[i, 1], 1 - centers[i, 0], 1 - centers[i, 1])
        r[i] = max(0.0, min(r[i], wall))
    for _ in range(5):
        bad = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if r[i] + r[j] > d:
                    s = d / (r[i] + r[j]) * (1 - 1e-13)
                    r[i] *= s
                    r[j] *= s
                    bad = True
        if not bad:
            break
    return r


def solve(n=26):
    t0 = time.time()
    rng = np.random.default_rng(12345)
    IA, JA = np.triu_indices(n, 1)

    # linear wall constraints
    Wj = np.zeros((4 * n, 3 * n))
    for i in range(n):
        Wj[i, i] = 1; Wj[i, 2 * n + i] = -1
        Wj[n + i, i] = -1; Wj[n + i, 2 * n + i] = -1
        Wj[2 * n + i, n + i] = 1; Wj[2 * n + i, 2 * n + i] = -1
        Wj[3 * n + i, n + i] = -1; Wj[3 * n + i, 2 * n + i] = -1
    Wc = np.concatenate([np.zeros(n), np.ones(n), np.zeros(n), np.ones(n)])

    def make_cons(I, J):
        m = len(I)
        ar = np.arange(m)

        def cons(v):
            x, y, r = v[:n], v[n:2 * n], v[2 * n:]
            dx = x[I] - x[J]; dy = y[I] - y[J]; sr = r[I] + r[J]
            g = dx * dx + dy * dy - sr * sr
            return np.concatenate([g, Wj @ v + Wc])

        def cjac(v):
            x, y, r = v[:n], v[n:2 * n], v[2 * n:]
            dx = x[I] - x[J]; dy = y[I] - y[J]; sr = r[I] + r[J]
            Jm = np.zeros((m, 3 * n))
            Jm[ar, I] = 2 * dx; Jm[ar, J] = -2 * dx
            Jm[ar, n + I] = 2 * dy; Jm[ar, n + J] = -2 * dy
            Jm[ar, 2 * n + I] = -2 * sr; Jm[ar, 2 * n + J] = -2 * sr
            return np.vstack([Jm, Wj])

        return cons, cjac

    obj = lambda v: -np.sum(v[2 * n:])
    gj = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    ojac = lambda v: gj
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def slsqp(v0, I, J, maxiter):
        cons, cjac = make_cons(I, J)
        try:
            res = minimize(obj, v0, jac=ojac, method="SLSQP", bounds=bounds,
                           constraints=[{"type": "ineq", "fun": cons, "jac": cjac}],
                           options={"maxiter": maxiter, "ftol": 1e-10})
            return res.x
        except Exception:
            return None

    def gaps(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        d = np.sqrt((x[IA] - x[JA]) ** 2 + (y[IA] - y[JA]) ** 2)
        return d, r[IA] + r[JA]

    def run(v0, maxiter=250, rounds=6):
        v = v0.copy()
        mask = np.zeros(len(IA), dtype=bool)
        for k in range(rounds):
            d, sr = gaps(v)
            margin = 0.25 if k == 0 else 0.15
            mask |= d < sr + margin
            vn = slsqp(v, IA[mask], JA[mask], maxiter)
            if vn is None:
                return None
            v = vn
            d, sr = gaps(v)
            viol = (d < sr - 1e-9) & ~mask
            if not viol.any():
                return v
            mask |= viol
        return v

    def eval_centers(v):
        c = np.column_stack([np.clip(v[:n], 0, 1), np.clip(v[n:2 * n], 0, 1)])
        r = _lp_radii(c)
        if r is None:
            return -1, c
        return r.sum(), c

    def rows_seed(pattern, jit):
        pts = []
        k = len(pattern)
        for ri, m in enumerate(pattern):
            y = (ri + 0.5) / k
            for j in range(m):
                x = (j + 0.5) / m
                pts.append([x, y])
        pts = np.array(pts[:n], dtype=float)
        while len(pts) < n:
            pts = np.vstack([pts, rng.random(2)])
        pts += rng.normal(0, jit, pts.shape)
        return np.clip(pts, 0.03, 0.97)

    patterns = [[5, 5, 6, 5, 5], [5, 6, 5, 6, 4], [6, 5, 5, 5, 5], [4, 5, 4, 5, 4, 4],
                [5, 5, 5, 5, 6], [5, 4, 5, 4, 5, 3]]

    def make_seed(kind):
        if kind == 0:
            pts = rows_seed(patterns[rng.integers(len(patterns))], rng.choice([0.01, 0.03, 0.05]))
        elif kind == 1:
            pts = []
            pts += [[0.1, 0.1], [0.9, 0.1], [0.1, 0.9], [0.9, 0.9]]
            pts += [[0.5, 0.08], [0.5, 0.92], [0.08, 0.5], [0.92, 0.5]]
            pts += [[0.3, 0.3], [0.7, 0.3], [0.3, 0.7], [0.7, 0.7], [0.5, 0.5]]
            pts = np.array(pts)
            extra = rng.random((n - len(pts), 2)) * 0.9 + 0.05
            pts = np.vstack([pts, extra])[:n]
            pts += rng.normal(0, 0.03, pts.shape)
            pts = np.clip(pts, 0.03, 0.97)
        else:
            pts = rng.random((n, 2)) * 0.9 + 0.05
        r0 = rng.uniform(0.03, 0.1, n)
        return np.concatenate([pts[:, 0], pts[:, 1], r0])

    best_val, best_c = -1, None
    best_v = None
    limit = 200.0
    it = 0
    while time.time() - t0 < limit:
        if best_v is not None and it % 3 == 2:
            v0 = best_v.copy()
            s = rng.choice([0.01, 0.03, 0.06])
            v0[:2 * n] += rng.normal(0, s, 2 * n)
            if rng.random() < 0.3:
                for _ in range(rng.integers(1, 3)):
                    k = rng.integers(n)
                    v0[k] = rng.random(); v0[n + k] = rng.random()
            v0[:2 * n] = np.clip(v0[:2 * n], 0.02, 0.98)
            v0[2 * n:] = np.maximum(v0[2 * n:] * 0.7, 0.01)
        else:
            v0 = make_seed(it % 3 if it < 30 else rng.integers(3))
        it += 1
        v = run(v0)
        if v is None:
            continue
        val, c = eval_centers(v)
        if val > best_val:
            best_val, best_c, best_v = val, c, v

    # final polish with the full constraint set
    if best_v is not None and time.time() - t0 < 270:
        vp = slsqp(best_v, IA, JA, 500)
        if vp is not None:
            val, c = eval_centers(vp)
            if val > best_val:
                best_val, best_c, best_v = val, c, vp

    if best_c is None:
        c = rows_seed([5, 5, 6, 5, 5], 0.0)
        return c, _safe_radii(c)
    radii = _safe_radii(best_c)
    return best_c, radii
