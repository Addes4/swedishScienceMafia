"""Physics-based circle packing with inflation and SLSQP optimization."""
import numpy as np
from scipy.optimize import minimize


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    best_sum = 0.0
    best_centers = None
    best_radii = None
    
    # Run multiple random starts with physics simulation
    num_trials = 40
    for trial in range(num_trials):
        # Initialize with random centers
        np.random.seed(trial)
        centers = np.random.rand(n, 2) * 0.8 + 0.1
        
        # Physics-based inflation simulation
        centers, radii = inflate_simulation(centers, n, num_iters=200)
        
        # Polish with SLSQP
        centers, radii = slsqp_polish(centers, radii, n)
        
        # Check if this is the best
        total = np.sum(radii)
        if total > best_sum:
            best_sum = total
            best_centers = centers.copy()
            best_radii = radii.copy()
    
    return best_centers, best_radii


def inflate_simulation(centers, n, num_iters=200):
    """Physics simulation: grow all circles while applying repulsion forces."""
    centers = centers.copy().astype(float)
    radii = np.ones(n) * 0.01
    
    for iteration in range(num_iters):
        # Compute pairwise distances
        diffs = centers[:, np.newaxis, :] - centers[np.newaxis, :, :]
        dists = np.linalg.norm(diffs, axis=2)
        np.fill_diagonal(dists, np.inf)
        
        # Wall distances
        wall_dists = np.minimum.reduce([
            centers[:, 0], centers[:, 1],
            1.0 - centers[:, 0], 1.0 - centers[:, 1]
        ])
        
        # Compute maximum feasible radius for each circle
        max_radii_wall = wall_dists
        for i in range(n):
            for j in range(n):
                if i != j:
                    max_radii_wall[i] = min(max_radii_wall[i], max(0, dists[i, j] - radii[j]))
        
        # Grow radii proportionally towards feasible limits
        growth_factor = 1.02
        new_radii = np.minimum(radii * growth_factor, max_radii_wall)
        
        # If no growth possible, switch to force-based repositioning
        if np.allclose(new_radii, radii):
            forces = np.zeros_like(centers)
            
            # Repulsion from other circles
            for i in range(n):
                for j in range(i + 1, n):
                    d = dists[i, j]
                    min_dist = radii[i] + radii[j]
                    if d < min_dist:
                        direction = diffs[i, j] / (d + 1e-10)
                        overlap = min_dist - d
                        force = overlap * 0.01
                        forces[i] += direction * force
                        forces[j] -= direction * force
            
            # Repulsion from walls
            margin = 0.01
            for i in range(n):
                wall_force = 0.01
                if centers[i, 0] - radii[i] < margin:
                    forces[i, 0] += wall_force
                if centers[i, 0] + radii[i] > 1.0 - margin:
                    forces[i, 0] -= wall_force
                if centers[i, 1] - radii[i] < margin:
                    forces[i, 1] += wall_force
                if centers[i, 1] + radii[i] > 1.0 - margin:
                    forces[i, 1] -= wall_force
            
            # Update positions
            centers = centers + forces * 0.001
            centers = np.clip(centers, 0.001, 0.999)
        
        radii = new_radii
        
        # Early exit if converged
        if iteration > 50 and np.sum(radii) < 1e-6:
            break
    
    return centers, np.maximum(radii, 0.0)


def slsqp_polish(centers, radii, n):
    """Polish solution using constrained optimization."""
    def objective(x):
        r = x[2*n:]
        return -np.sum(r)
    
    def pack_state(c, r):
        return np.concatenate([c.flatten(), r])
    
    def unpack_state(x):
        c = x[:2*n].reshape(n, 2)
        r = x[2*n:]
        return c, r
    
    x0 = pack_state(centers, radii)
    
    def constraint_func(x):
        c, r = unpack_state(x)
        constraints = []
        
        # Wall constraints
        for i in range(n):
            constraints.append(c[i, 0] - r[i])
            constraints.append(c[i, 1] - r[i])
            constraints.append(1.0 - c[i, 0] - r[i])
            constraints.append(1.0 - c[i, 1] - r[i])
        
        # Circle overlap constraints
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(c[i] - c[j])
                constraints.append(d - r[i] - r[j])
        
        return np.array(constraints)
    
    cons = {'type': 'ineq', 'fun': constraint_func}
    bounds = [(0.001, 0.999)] * (2 * n) + [(0.0, 0.5)] * n
    
    result = minimize(objective, x0, method='SLSQP', bounds=bounds,
                      constraints=cons, options={'maxiter': 100, 'ftol': 1e-6})
    
    final_c, final_r = unpack_state(result.x)
    return final_c, np.maximum(final_r, 0.0)
