# EVOLVE-BLOCK-START
"""Recursive grid DP: F(m) = best sum of sides for m squares in a unit square, built from
k x k grids with an optional j x j merged corner block, each cell filled recursively.
Inner maximisations are vectorised with numpy."""
import numpy as np

NEG = -1e18


def solve(n):
    K = 10 if n <= 400 else 8
    C = K * K
    F = np.zeros(n + 1)
    G = np.full((C + 1, n + 1), NEG)
    G[:, 0] = 0.0
    P = np.zeros((C + 1, n + 1), dtype=np.int64)
    Pc = {}
    choice = {}
    for m in range(1, n + 1):
        if m == 1:
            F[1] = 1.0
            choice[1] = ('one',)
        else:
            Gc = [NEG] * (C + 1)
            par = [0] * (C + 1)
            Fm = F[0:m]
            for c in range(1, C + 1):
                prevs = np.concatenate(([Gc[c - 1]], G[c - 1][m - 1:0:-1])) + Fm
                bt = int(np.argmax(prevs))
                best = float(prevs[bt])
                if best <= NEG / 2:
                    best = NEG
                    bt = 0
                Gc[c] = best
                par[c] = bt
            Pc[m] = par
            bestv = float(F[m - 1])
            bestc = ('waste',)
            F1 = F[1:m]
            for k in range(2, K + 1):
                for j in range(0, k):
                    if j == 1:
                        continue
                    cells = k * k - j * j
                    if j == 0:
                        v = Gc[cells] / k
                        if Gc[cells] > NEG / 2 and v > bestv + 1e-12:
                            bestv = v
                            bestc = (k, 0, 0)
                    else:
                        vals = (j * F1 + G[cells][m - 1:0:-1]) / k
                        i = int(np.argmax(vals))
                        v = float(vals[i])
                        if v > bestv + 1e-12 and v > NEG / 4:
                            bestv = v
                            bestc = (k, j, i + 1)
            F[m] = bestv
            choice[m] = bestc
        Ft = F[0:m + 1]
        for c in range(1, C + 1):
            vals = G[c - 1][m::-1] + Ft
            bt = int(np.argmax(vals))
            best = float(vals[bt])
            if best <= NEG / 2:
                best = NEG
                bt = 0
            G[c][m] = best
            P[c][m] = bt

    out = []

    def counts_for(cells, m):
        cnt = [0] * cells
        s = m
        for c in range(cells, 0, -1):
            if s == m and m in Pc:
                t = Pc[m][c]
            else:
                t = int(P[c][s])
            cnt[c - 1] = t
            s -= t
        return cnt

    def build(m, x, y, size):
        if m <= 0:
            return
        ch = choice[m]
        if ch[0] == 'one':
            out.append((x + size / 2, y + size / 2, 0.0, size))
            return
        if ch[0] == 'waste':
            build(m - 1, x, y, size)
            return
        k, j, m0 = ch
        u = size / k
        cells = k * k - j * j
        cnt = counts_for(cells, m - m0)
        if j > 0:
            build(m0, x, y, j * u)
        idx = 0
        for a in range(k):
            for b in range(k):
                if a < j and b < j:
                    continue
                build(cnt[idx], x + a * u, y + b * u, u)
                idx += 1

    build(n, 0.0, 0.0, 1.0)
    res = []
    for (cx, cy, an, s) in out[:n]:
        res.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), an, min(1.0, max(0.0, s))))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
# EVOLVE-BLOCK-END
