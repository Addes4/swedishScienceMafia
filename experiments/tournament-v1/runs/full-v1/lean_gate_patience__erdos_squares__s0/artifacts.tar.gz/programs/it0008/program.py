# EVOLVE-BLOCK-START
"""Guillotine-partition DP: F[w][h][m] = max sum of sides of m squares packed in a w x h
integer rectangle, via recursive cuts (max-plus convolution over the split of m)."""
import math
import time
import numpy as np


def _run(N, n):
    M = n + 1
    NEG = -1e9
    F = np.zeros((N + 1, N + 1, M))
    ct = np.zeros((N + 1, N + 1, M), dtype=np.int8)
    ca = np.zeros((N + 1, N + 1, M), dtype=np.int32)
    ci = np.zeros((N + 1, N + 1, M), dtype=np.int32)
    mm = np.arange(M)[:, None]
    ii = np.arange(M)[None, :]
    idxM = np.where(mm - ii >= 0, mm - ii, M)  # M -> padded -inf column
    for w in range(1, N + 1):
        for h in range(w, N + 1):
            nv = w // 2
            nh = h // 2
            val = np.zeros(M)
            t = np.zeros(M, dtype=np.int8)
            pa = np.zeros(M, dtype=np.int32)
            pi = np.zeros(M, dtype=np.int32)
            if nv + nh > 0:
                av = np.arange(1, nv + 1)
                bh = np.arange(1, nh + 1)
                ia = np.concatenate([av, np.full(nh, w)])
                ja = np.concatenate([np.full(nv, h), bh])
                ib = np.concatenate([w - av, np.full(nh, w)])
                jb = np.concatenate([np.full(nv, h), h - bh])
                A = F[ia, ja]
                B = F[ib, jb]
                K = A.shape[0]
                Bp = np.concatenate([B, np.full((K, 1), NEG)], axis=1)
                G = A[:, None, :] + Bp[:, idxM]  # (K, m, i)
                G = G.transpose(1, 0, 2).reshape(M, K * M)
                f = G.argmax(axis=1)
                val = G[np.arange(M), f]
                k = f // M
                pi = (f % M).astype(np.int32)
                isv = k < nv
                t = np.where(isv, 1, 2).astype(np.int8)
                pa = np.where(isv, k + 1, k - nv + 1).astype(np.int32)
            s = float(min(w, h))
            if val[1] < s:
                val[1] = s
                t[1] = 0
            for m in range(1, M):
                if val[m] < val[m - 1]:
                    val[m] = val[m - 1]
                    t[m] = 3
            val[0] = 0.0
            t[0] = 3
            F[w, h] = val
            F[h, w] = val
            ct[w, h] = t
            ca[w, h] = pa
            ci[w, h] = pi
            ct[h, w] = np.where(t == 1, 2, np.where(t == 2, 1, t))
            ca[h, w] = pa
            ci[h, w] = pi
    return F, ct, ca, ci


def _recon(N, n, ct, ca, ci):
    out = []
    stack = [(0, 0, N, N, n)]
    while stack:
        x, y, w, h, m = stack.pop()
        if m <= 0:
            continue
        t = ct[w, h, m]
        if t == 3:
            if m == 0:
                continue
            stack.append((x, y, w, h, m - 1))
        elif t == 0:
            s = min(w, h)
            out.append((x, y, s))
        elif t == 1:
            a = int(ca[w, h, m])
            i = int(ci[w, h, m])
            stack.append((x, y, a, h, i))
            stack.append((x + a, y, w - a, h, m - i))
        else:
            a = int(ca[w, h, m])
            i = int(ci[w, h, m])
            stack.append((x, y, w, a, i))
            stack.append((x, y + a, w, h - a, m - i))
    return out


def solve(n):
    t0 = time.time()
    k = max(1, math.isqrt(max(n - 1, 0)) + 1)
    cands = []
    for N in range(k, 200):
        if (N % k == 0 or N % max(1, k - 1) == 0 or N % (k + 1) == 0
                or N % 6 == 0 or N % 5 == 0 or N % 7 == 0 or N == k):
            cands.append(N)
    best = None
    bestv = -1.0
    for idx, N in enumerate(cands):
        est = N ** 3 * (n + 1) ** 2 / 4 * 4e-8
        if idx > 0 and time.time() - t0 + est > 40:
            if N > 2 * k:
                break
            continue
        F, ct, ca, ci = _run(N, n)
        v = F[N, N, n] / N
        if v > bestv + 1e-12:
            bestv = v
            best = (N, _recon(N, n, ct, ca, ci))
        if time.time() - t0 > 40:
            break
    N, items = best
    res = []
    for (x, y, s) in items:
        side = s / N
        c = side * (1 - 1e-9)
        res.append(((x / N) + side / 2, (y / N) + side / 2, 0.0, c))
    res = res[:n]
    res += [(0.5, 0.5, 0.0, 0.0)] * (n - len(res))
    return res
# EVOLVE-BLOCK-END
