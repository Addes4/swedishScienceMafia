# EVOLVE-BLOCK-START
"""Penalty-L-BFGS seeding + SLSQP polish + hole-filling basin hopping."""
import numpy as np


def solve(n=26):
    import time
    from scipy.optimize import minimize, linprog
    from scipy.sparse import coo_matrix

    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(2024)

    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    rows = np.arange(m)
    kk = np.arange(n)
    A_lp = coo_matrix((np.ones(2 * m), (np.concatenate([rows, rows]), np.concatenate([iu, ju]))),
                      shape=(m, n)).tocsr()

    def wall_dist(c):
        return np.maximum(np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]]), 0.0)

    def lp_radii(c):
        d = np.linalg.norm(c[iu] - c[ju], axis=1)
        w = wall_dist(c)
        try:
            res = linprog(-np.ones(n), A_ub=A_lp, b_ub=d, bounds=[(0, a) for a in w], method="highs")
            if res.status == 0:
                return np.maximum(res.x, 0.0)
        except Exception:
            pass
        return max_radii(c)

    # ---------- penalty objective ----------
    def pen(v, mu):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]
        d = np.sqrt(dx * dx + dy * dy + 1e-12)
        ov = np.maximum(r[iu] + r[ju] - d, 0.0)
        a1 = np.maximum(r - x, 0.0)
        a2 = np.maximum(r + x - 1, 0.0)
        a3 = np.maximum(r - y, 0.0)
        a4 = np.maximum(r + y - 1, 0.0)
        f = -np.sum(r) + mu * (np.sum(ov ** 2) + np.sum(a1 ** 2 + a2 ** 2 + a3 ** 2 + a4 ** 2))
        g = np.zeros(3 * n)
        gx = np.zeros(n); gy = np.zeros(n); gr = -np.ones(n)
        co = 2 * mu * ov
        # d(ov)/dr = 1 ; d(ov)/dx_i = -dx/d
        np.add.at(gr, iu, co)
        np.add.at(gr, ju, co)
        t = co * dx / d
        np.add.at(gx, iu, -t)
        np.add.at(gx, ju, t)
        t = co * dy / d
        np.add.at(gy, iu, -t)
        np.add.at(gy, ju, t)
        gr += 2 * mu * (a1 + a2 + a3 + a4)
        gx += 2 * mu * (-a1 + a2)
        gy += 2 * mu * (-a3 + a4)
        g[:n] = gx; g[n:2 * n] = gy; g[2 * n:] = gr
        return f, g

    pbounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def seed(c0, r0=None):
        if r0 is None:
            r0 = np.full(n, 0.04)
        v = np.concatenate([c0[:, 0], c0[:, 1], r0])
        for mu in (20.0, 300.0, 5000.0):
            try:
                res = minimize(pen, v, args=(mu,), jac=True, method="L-BFGS-B",
                               bounds=pbounds, options={"maxiter": 300})
                v = res.x
            except Exception:
                break
        return np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0.0, 1.0)

    # ---------- exact polish ----------
    def fun(v):
        return -np.sum(v[2 * n:])

    gobj = np.concatenate([np.zeros(2 * n), -np.ones(n)])

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]; sr = r[iu] + r[ju]
        return np.concatenate([dx * dx + dy * dy - sr * sr, x - r, 1 - x - r, y - r, 1 - y - r])

    def jcons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]; sr = r[iu] + r[ju]
        J = np.zeros((m + 4 * n, 3 * n))
        J[rows, iu] = 2 * dx; J[rows, ju] = -2 * dx
        J[rows, n + iu] = 2 * dy; J[rows, n + ju] = -2 * dy
        J[rows, 2 * n + iu] = -2 * sr; J[rows, 2 * n + ju] = -2 * sr
        J[m + kk, kk] = 1; J[m + kk, 2 * n + kk] = -1
        J[m + n + kk, kk] = -1; J[m + n + kk, 2 * n + kk] = -1
        J[m + 2 * n + kk, n + kk] = 1; J[m + 2 * n + kk, 2 * n + kk] = -1
        J[m + 3 * n + kk, n + kk] = -1; J[m + 3 * n + kk, 2 * n + kk] = -1
        return J

    sbounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def polish(c0):
        r0 = lp_radii(c0)
        v0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
        try:
            res = minimize(fun, v0, jac=lambda v: gobj, method="SLSQP", bounds=sbounds,
                           constraints=[{"type": "ineq", "fun": cons, "jac": jcons}],
                           options={"maxiter": 250, "ftol": 1e-11})
            v = res.x
        except Exception:
            v = v0
        c = np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0.0, 1.0)
        r = lp_radii(c)
        return c, r

    def init(k):
        kind = k % 4
        if kind == 0:
            return rng.random((n, 2)) * 0.9 + 0.05
        if kind == 1:
            s = int(np.ceil(np.sqrt(n)))
            g = (np.arange(s) + 0.5) / s
            pts = np.array([[a, b] for a in g for b in g])
            pts = pts[rng.permutation(len(pts))[:n]]
            return np.clip(pts + rng.normal(0, 0.04, pts.shape), 0.03, 0.97)
        if kind == 2:
            k1 = int(rng.integers(5, 9))
            k2 = n - 1 - k1
            pts = [[0.5, 0.5]]
            pts += [[0.5 + 0.25 * np.cos(2 * np.pi * i / k1), 0.5 + 0.25 * np.sin(2 * np.pi * i / k1)] for i in range(k1)]
            pts += [[0.5 + 0.42 * np.cos(2 * np.pi * i / k2), 0.5 + 0.42 * np.sin(2 * np.pi * i / k2)] for i in range(k2)]
            pts = np.array(pts) + rng.normal(0, 0.03, (n, 2))
            return np.clip(pts, 0.03, 0.97)
        rowsn = int(rng.integers(5, 7))
        per = int(np.ceil(n / rowsn))
        pts = []
        for i in range(rowsn):
            off = 0.5 / per if i % 2 else 0.0
            for j in range(per):
                pts.append([(j + 0.5) / per * 0.95 + off * 0.5 + 0.02, (i + 0.5) / rowsn])
        pts = np.array(pts)
        pts = pts[rng.permutation(len(pts))[:n]]
        return np.clip(pts + rng.normal(0, 0.03, pts.shape), 0.03, 0.97)

    def largest_hole(c, skip):
        mask = np.ones(n, bool); mask[skip] = False
        cs = c[mask]
        P = rng.random((600, 2))
        d = np.sqrt(((P[:, None, :] - cs[None, :, :]) ** 2).sum(-1))
        # clearance = distance to nearest centre (roughly) and walls
        clear = np.minimum(d.min(1) , 3 * np.minimum.reduce([P[:, 0], P[:, 1], 1 - P[:, 0], 1 - P[:, 1]]) + 0.02)
        top = np.argsort(-clear)[:10]
        return P[rng.choice(top)]

    best_c, best_r, best_s = None, None, -1.0

    def consider(c, r):
        nonlocal best_c, best_r, best_s
        s = float(np.sum(r))
        if s > best_s:
            best_c, best_r, best_s = c.copy(), r.copy(), s
            return True
        return False

    seed_end = 0.35 * budget
    k = 0
    while time.time() - t0 < seed_end:
        try:
            c = seed(init(k))
            c, r = polish(c)
            consider(c, r)
        except Exception:
            pass
        k += 1

    cur_c, cur_r, cur_s = best_c, best_r, best_s
    stall = 0
    while time.time() - t0 < budget and best_c is not None:
        c0 = cur_c.copy()
        mv = rng.random()
        if mv < 0.4:
            nm = int(rng.integers(1, 4))
            idx = np.argsort(cur_r)[:nm] if rng.random() < 0.5 else rng.choice(n, nm, replace=False)
            for i in idx:
                c0[i] = largest_hole(c0, [i]) if rng.random() < 0.6 else rng.random(2) * 0.9 + 0.05
        elif mv < 0.6:
            i, j = rng.choice(n, 2, replace=False)
            c0[[i, j]] = c0[[j, i]]
            c0 += rng.normal(0, 0.01, c0.shape)
        else:
            c0 += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), c0.shape)
        c0 = np.clip(c0, 0.02, 0.98)
        try:
            if rng.random() < 0.5:
                c0 = seed(c0, np.maximum(cur_r * 0.7, 0.02))
            c, r = polish(c0)
        except Exception:
            continue
        s = float(np.sum(r))
        if s > cur_s - 1e-12 or (rng.random() < 0.03 and s > cur_s - 0.02):
            cur_c, cur_r, cur_s = c, r, s
            stall = 0
        else:
            stall += 1
        consider(c, r)
        if stall > 60:
            cur_c, cur_r, cur_s = best_c, best_r, best_s
            stall = 0

    if best_c is None:
        centers = np.clip(rng.random((n, 2)), 0.05, 0.95)
        return centers, max_radii(centers)

    c = best_c
    radii = np.maximum(lp_radii(c) - 1e-10, 0.0)
    radii = np.minimum(radii, wall_dist(c))
    d = np.linalg.norm(c[iu] - c[ju], axis=1)
    for _ in range(5):
        bad = radii[iu] + radii[ju] > d
        if not bad.any():
            break
        for a, b in zip(iu[bad], ju[bad]):
            s = radii[a] + radii[b]
            if s > d[np.where((iu == a) & (ju == b))[0][0]]:
                f = d[np.where((iu == a) & (ju == b))[0][0]] / s * (1 - 1e-12)
                radii[a] *= f
                radii[b] *= f
    return c, radii


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END