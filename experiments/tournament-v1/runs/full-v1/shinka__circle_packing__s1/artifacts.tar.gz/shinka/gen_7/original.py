# EVOLVE-BLOCK-START
"""Circle packing via multi-start SLSQP + basin hopping + LP radius polish."""
import time
import numpy as np


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _lp_radii(centers):
    from scipy.optimize import linprog
    n = len(centers)
    iu, ju = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[iu] - centers[ju], axis=1)
    m = len(iu)
    A = np.zeros((m, n))
    A[np.arange(m), iu] = 1
    A[np.arange(m), ju] = 1
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status != 0:
        return None
    return np.maximum(res.x - 1e-12, 0.0)


def _valid(c, r, tol=1e-12):
    if np.any(r < 0):
        return False
    if np.any(c[:, 0] - r < -tol) or np.any(c[:, 1] - r < -tol):
        return False
    if np.any(c[:, 0] + r > 1 + tol) or np.any(c[:, 1] + r > 1 + tol):
        return False
    n = len(r)
    iu, ju = np.triu_indices(n, 1)
    d = np.linalg.norm(c[iu] - c[ju], axis=1)
    return bool(np.all(d - r[iu] - r[ju] >= -tol))


def _make_optimizer(n):
    from scipy.optimize import minimize
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    ar = np.arange(m)

    def obj(v):
        return -np.sum(v[2 * n:])

    def obj_jac(v):
        g = np.zeros_like(v)
        g[2 * n:] = -1
        return g

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]
        d = np.sqrt(dx * dx + dy * dy + 1e-18)
        pair = d - r[iu] - r[ju]
        return np.concatenate([pair, x - r, y - r, 1 - x - r, 1 - y - r])

    def cons_jac(v):
        x = v[:n]; y = v[n:2 * n]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]
        d = np.sqrt(dx * dx + dy * dy + 1e-18)
        J = np.zeros((m + 4 * n, 3 * n))
        ux = dx / d; uy = dy / d
        J[ar, iu] = ux
        J[ar, ju] = -ux
        J[ar, n + iu] = uy
        J[ar, n + ju] = -uy
        J[ar, 2 * n + iu] = -1
        J[ar, 2 * n + ju] = -1
        k = np.arange(n)
        J[m + k, k] = 1; J[m + k, 2 * n + k] = -1
        J[m + n + k, n + k] = 1; J[m + n + k, 2 * n + k] = -1
        J[m + 2 * n + k, k] = -1; J[m + 2 * n + k, 2 * n + k] = -1
        J[m + 3 * n + k, n + k] = -1; J[m + 3 * n + k, 2 * n + k] = -1
        return J

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def run(c0, r0=None, maxiter=250):
        if r0 is None:
            r0 = np.full(n, 0.03)
        v0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
        try:
            res = minimize(obj, v0, jac=obj_jac, method="SLSQP", bounds=bounds,
                           constraints=[{"type": "ineq", "fun": cons, "jac": cons_jac}],
                           options={"maxiter": maxiter, "ftol": 1e-11})
        except Exception:
            return None
        v = res.x
        return np.stack([v[:n], v[n:2 * n]], axis=1), v[2 * n:].copy()

    return run


def _ring_init(n, rng):
    pts = [[0.5, 0.5]]
    k1 = int(rng.integers(5, 9))
    pts += [[0.5 + 0.2 * np.cos(2 * np.pi * i / k1), 0.5 + 0.2 * np.sin(2 * np.pi * i / k1)] for i in range(k1)]
    k2 = n - len(pts)
    pts += [[0.5 + 0.4 * np.cos(2 * np.pi * i / k2), 0.5 + 0.4 * np.sin(2 * np.pi * i / k2)] for i in range(k2)]
    c = np.array(pts[:n]) + rng.normal(0, 0.03, (n, 2))
    return np.clip(c, 0.02, 0.98)


def _grid_init(n, rng):
    # staggered rows with random row counts
    rows = int(rng.integers(4, 7))
    pts = []
    per = int(np.ceil(n / rows))
    for i in range(rows):
        for j in range(per):
            off = 0.5 / per if i % 2 else 0
            pts.append([(j + 0.5) / per * 0.95 + off * 0.5, (i + 0.5) / rows])
    pts = np.array(pts)
    idx = rng.permutation(len(pts))[:n]
    c = pts[idx] + rng.normal(0, 0.02, (n, 2))
    return np.clip(c, 0.02, 0.98)


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    rng = np.random.default_rng(12345)
    t0 = time.time()
    budget = 150.0

    best_c = None
    best_r = None
    best_s = -1.0

    try:
        run = _make_optimizer(n)
        have = True
    except Exception:
        have = False

    if have:
        it = 0
        while time.time() - t0 < budget:
            it += 1
            if best_c is not None and it > 8 and rng.random() < 0.65:
                c0 = best_c.copy()
                mode = rng.random()
                if mode < 0.5:
                    k = int(rng.integers(1, 4))
                    idx = rng.choice(n, k, replace=False)
                    c0[idx] = rng.uniform(0.05, 0.95, (k, 2))
                elif mode < 0.8:
                    c0 += rng.normal(0, 0.03, c0.shape)
                else:
                    # swap-like: relocate smallest circle
                    i = int(np.argmin(best_r))
                    c0[i] = rng.uniform(0.05, 0.95, 2)
                    c0 += rng.normal(0, 0.01, c0.shape)
                c0 = np.clip(c0, 0.01, 0.99)
                r0 = np.full(n, 0.03)
            else:
                u = rng.random()
                if u < 0.4:
                    c0 = _ring_init(n, rng)
                elif u < 0.6:
                    c0 = _grid_init(n, rng)
                else:
                    c0 = rng.uniform(0.05, 0.95, (n, 2))
                r0 = np.full(n, 0.03)
            out = run(c0, r0)
            if out is None:
                continue
            c, r = out
            c = np.clip(c, 0, 1)
            s_est = r.sum()
            if s_est < best_s - 0.05:
                continue
            try:
                rr = _lp_radii(c)
            except Exception:
                rr = None
            if rr is None:
                rr = max_radii(c)
            if not _valid(c, rr):
                continue
            s = rr.sum()
            if s > best_s:
                best_s, best_c, best_r = s, c.copy(), rr.copy()

    if best_c is None:
        centers = [[0.5, 0.5]]
        centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
        centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
        centers += [[0.1 + 0.8 * rng.random(), 0.1 + 0.8 * rng.random()] for _ in range(n - len(centers))]
        centers = np.clip(np.array(centers[:n]), 0.01, 0.99)
        return centers, max_radii(centers)
    return best_c, best_r
# EVOLVE-BLOCK-END