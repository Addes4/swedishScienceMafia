# EVOLVE-BLOCK-START
"""Baseline: a centre circle with two rings, radii shrunk until nothing overlaps.
Layout follows the ShinkaEvolve circle_packing example (Apache-2.0)."""
import numpy as np


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(12345)
    try:
        from scipy.optimize import minimize, linprog
    except Exception:
        minimize = None

    if minimize is None:
        centers = np.clip(rng.random((n, 2)), 0.05, 0.95)
        return centers, max_radii(centers)

    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    rows = np.arange(m)

    def lp_radii(c):
        d = np.linalg.norm(c[iu] - c[ju], axis=1)
        wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
        wall = np.maximum(wall, 0.0)
        from scipy.sparse import coo_matrix
        data = np.ones(2 * m)
        ri = np.concatenate([rows, rows])
        ci = np.concatenate([iu, ju])
        A = coo_matrix((data, (ri, ci)), shape=(m, n)).tocsr()
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
        if res.status != 0:
            return max_radii(c)
        return np.maximum(res.x, 0.0)

    def fun(v):
        return -np.sum(v[2 * n:])

    def gfun(v):
        g = np.zeros(3 * n)
        g[2 * n:] = -1.0
        return g

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]; sr = r[iu] + r[ju]
        pair = dx * dx + dy * dy - sr * sr
        wall = np.concatenate([x - r, 1 - x - r, y - r, 1 - y - r])
        return np.concatenate([pair, wall])

    def jcons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]; sr = r[iu] + r[ju]
        J = np.zeros((m + 4 * n, 3 * n))
        J[rows, iu] = 2 * dx
        J[rows, ju] = -2 * dx
        J[rows, n + iu] = 2 * dy
        J[rows, n + ju] = -2 * dy
        J[rows, 2 * n + iu] = -2 * sr
        J[rows, 2 * n + ju] = -2 * sr
        k = np.arange(n)
        J[m + k, k] = 1; J[m + k, 2 * n + k] = -1
        J[m + n + k, k] = -1; J[m + n + k, 2 * n + k] = -1
        J[m + 2 * n + k, n + k] = 1; J[m + 2 * n + k, 2 * n + k] = -1
        J[m + 3 * n + k, n + k] = -1; J[m + 3 * n + k, 2 * n + k] = -1
        return J

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def optimise(c0):
        r0 = lp_radii(c0)
        v0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
        try:
            res = minimize(fun, v0, jac=gfun, bounds=bounds, method="SLSQP",
                           constraints=[{"type": "ineq", "fun": cons, "jac": jcons}],
                           options={"maxiter": 300, "ftol": 1e-10})
            v = res.x
        except Exception:
            v = v0
        c = np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0.0, 1.0)
        r = lp_radii(c)
        return c, r

    def init(k):
        kind = k % 4
        if kind == 0:
            return rng.random((n, 2)) * 0.9 + 0.05
        if kind == 1:
            s = int(np.ceil(np.sqrt(n)))
            g = (np.arange(s) + 0.5) / s
            pts = np.array([[a, b] for a in g for b in g])
            pts = pts[rng.permutation(len(pts))[:n]]
            return np.clip(pts + rng.normal(0, 0.03, pts.shape), 0.03, 0.97)
        if kind == 2:
            pts = [[0.5, 0.5]]
            k1 = int(rng.integers(5, 9))
            k2 = n - 1 - k1
            pts += [[0.5 + 0.25 * np.cos(2 * np.pi * i / k1), 0.5 + 0.25 * np.sin(2 * np.pi * i / k1)] for i in range(k1)]
            pts += [[0.5 + 0.42 * np.cos(2 * np.pi * i / k2), 0.5 + 0.42 * np.sin(2 * np.pi * i / k2)] for i in range(k2)]
            pts = np.array(pts) + rng.normal(0, 0.02, (n, 2))
            return np.clip(pts, 0.03, 0.97)
        # hex-like rows
        rowsn = int(rng.integers(5, 7))
        pts = []
        per = int(np.ceil(n / rowsn))
        for i in range(rowsn):
            off = 0.5 / per if i % 2 else 0.0
            for j in range(per):
                pts.append([(j + 0.5) / per * 0.95 + off * 0.5 + 0.02, (i + 0.5) / rowsn])
        pts = np.array(pts)
        pts = pts[rng.permutation(len(pts))[:n]]
        return np.clip(pts + rng.normal(0, 0.02, pts.shape), 0.03, 0.97)

    best_c, best_r, best_s = None, None, -1.0
    k = 0
    while time.time() - t0 < budget:
        if best_c is None or k < 30 or k % 5 == 0:
            c0 = init(k)
        else:
            c0 = best_c.copy()
            nm = int(rng.integers(1, 5))
            idx = rng.choice(n, nm, replace=False)
            if rng.random() < 0.5:
                c0[idx] = rng.random((nm, 2)) * 0.9 + 0.05
            else:
                c0 += rng.normal(0, 0.02, c0.shape)
            c0 = np.clip(c0, 0.02, 0.98)
        k += 1
        try:
            c, r = optimise(c0)
        except Exception:
            continue
        s = float(np.sum(r))
        if s > best_s:
            best_c, best_r, best_s = c, r, s

    radii = np.maximum(best_r - 1e-10, 0.0)
    return best_c, radii


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END