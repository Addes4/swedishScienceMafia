# EVOLVE-BLOCK-START
"""Penalty-method L-BFGS multistart screening + LP radii + SLSQP polish + basin hopping."""
import numpy as np


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    t0 = time.time()
    budget = 190.0
    rng = np.random.default_rng(2024)
    from scipy.optimize import minimize, linprog
    from scipy.sparse import coo_matrix

    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    rows = np.arange(m)
    A_lp = coo_matrix((np.ones(2 * m), (np.concatenate([rows, rows]), np.concatenate([iu, ju]))),
                      shape=(m, n)).tocsr()

    def wall_d(c):
        return np.maximum(np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]]), 0.0)

    def lp_radii(c):
        d = np.linalg.norm(c[iu] - c[ju], axis=1)
        w = wall_d(c)
        try:
            res = linprog(-np.ones(n), A_ub=A_lp, b_ub=d, bounds=list(zip(np.zeros(n), w)), method="highs")
            if res.status == 0:
                return np.maximum(res.x, 0.0)
        except Exception:
            pass
        return max_radii(c)

    # ---------- penalty relaxation ----------
    def pen(v, mu):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]
        d = np.sqrt(dx * dx + dy * dy + 1e-18)
        ov = np.maximum(r[iu] + r[ju] - d, 0.0)
        w1 = np.maximum(r - x, 0.0); w2 = np.maximum(r + x - 1, 0.0)
        w3 = np.maximum(r - y, 0.0); w4 = np.maximum(r + y - 1, 0.0)
        f = -r.sum() + mu * (np.sum(ov ** 2) + np.sum(w1 ** 2 + w2 ** 2 + w3 ** 2 + w4 ** 2))
        g = np.zeros(3 * n)
        t = 2 * mu * ov
        cx = t * dx / d
        cy = t * dy / d
        g[:n] = -np.bincount(iu, cx, n) + np.bincount(ju, cx, n) + 2 * mu * (-w1 + w2)
        g[n:2 * n] = -np.bincount(iu, cy, n) + np.bincount(ju, cy, n) + 2 * mu * (-w3 + w4)
        g[2 * n:] = -1 + np.bincount(iu, t, n) + np.bincount(ju, t, n) + 2 * mu * (w1 + w2 + w3 + w4)
        return f, g

    pb = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def relax(c0):
        v = np.concatenate([c0[:, 0], c0[:, 1], np.full(n, 0.05)])
        for mu in (10.0, 100.0, 1000.0, 10000.0):
            res = minimize(pen, v, args=(mu,), jac=True, method="L-BFGS-B", bounds=pb,
                           options={"maxiter": 400})
            v = res.x
        return np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0.0, 1.0)

    # ---------- SLSQP polish ----------
    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        pair = (x[iu] - x[ju]) ** 2 + (y[iu] - y[ju]) ** 2 - (r[iu] + r[ju]) ** 2
        return np.concatenate([pair, x - r, 1 - x - r, y - r, 1 - y - r])

    def jcons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]; sr = r[iu] + r[ju]
        J = np.zeros((m + 4 * n, 3 * n))
        J[rows, iu] = 2 * dx; J[rows, ju] = -2 * dx
        J[rows, n + iu] = 2 * dy; J[rows, n + ju] = -2 * dy
        J[rows, 2 * n + iu] = -2 * sr; J[rows, 2 * n + ju] = -2 * sr
        k = np.arange(n)
        J[m + k, k] = 1; J[m + k, 2 * n + k] = -1
        J[m + n + k, k] = -1; J[m + n + k, 2 * n + k] = -1
        J[m + 2 * n + k, n + k] = 1; J[m + 2 * n + k, 2 * n + k] = -1
        J[m + 3 * n + k, n + k] = -1; J[m + 3 * n + k, 2 * n + k] = -1
        return J

    gobj = np.concatenate([np.zeros(2 * n), -np.ones(n)])

    def polish(c0):
        r0 = lp_radii(c0)
        v0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
        try:
            res = minimize(lambda v: -np.sum(v[2 * n:]), v0, jac=lambda v: gobj, method="SLSQP",
                           bounds=pb, constraints=[{"type": "ineq", "fun": cons, "jac": jcons}],
                           options={"maxiter": 300, "ftol": 1e-11})
            v = res.x
        except Exception:
            v = v0
        c = np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0.0, 1.0)
        return c, lp_radii(c)

    # ---------- starts ----------
    def init(k):
        kind = k % 3
        if kind == 0:
            return rng.random((n, 2)) * 0.94 + 0.03
        if kind == 1:
            rowsn = int(rng.integers(5, 7))
            per = int(np.ceil(n / rowsn))
            pts = []
            for i in range(rowsn):
                off = 0.5 / per if i % 2 else 0.0
                for j in range(per):
                    pts.append([(j + 0.5) / per * 0.95 + off * 0.5 + 0.02, (i + 0.5) / rowsn])
            pts = np.array(pts)
            pts = pts[rng.permutation(len(pts))[:n]]
            return np.clip(pts + rng.normal(0, 0.03, pts.shape), 0.02, 0.98)
        k1 = int(rng.integers(5, 10))
        k2 = n - 1 - k1
        pts = [[0.5, 0.5]]
        pts += [[0.5 + 0.25 * np.cos(2 * np.pi * i / k1), 0.5 + 0.25 * np.sin(2 * np.pi * i / k1)] for i in range(k1)]
        pts += [[0.5 + 0.42 * np.cos(2 * np.pi * i / k2), 0.5 + 0.42 * np.sin(2 * np.pi * i / k2)] for i in range(k2)]
        pts = np.array(pts) + rng.normal(0, 0.03, (n, 2))
        return np.clip(pts, 0.02, 0.98)

    best_c, best_r, best_s = None, None, -1.0
    elites = []  # (score, centers)
    k = 0
    explore_end = 0.35 * budget
    while time.time() - t0 < budget:
        el = time.time() - t0
        if el < explore_end or not elites or k % 4 == 0:
            c0 = init(k)
        else:
            base = elites[int(rng.integers(0, min(len(elites), 4)))][1].copy()
            mode = rng.random()
            if mode < 0.5:
                nm = int(rng.integers(1, 5))
                idx = rng.choice(n, nm, replace=False)
                base[idx] = rng.random((nm, 2)) * 0.9 + 0.05
            elif mode < 0.8:
                base += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), base.shape)
            else:
                i, j = rng.choice(n, 2, replace=False)
                base[i], base[j] = base[j].copy(), base[i].copy()
                base += rng.normal(0, 0.01, base.shape)
            c0 = np.clip(base, 0.02, 0.98)
        k += 1
        try:
            c1 = relax(c0)
            r1 = lp_radii(c1)
            s1 = float(r1.sum())
            thresh = (best_s - 0.08) if best_s > 0 else -1
            if s1 >= thresh:
                c2, r2 = polish(c1)
                s2 = float(r2.sum())
                if s2 < s1:
                    c2, r2, s2 = c1, r1, s1
            else:
                continue
        except Exception:
            continue
        elites.append((s2, c2))
        elites.sort(key=lambda t: -t[0])
        elites = elites[:8]
        if s2 > best_s:
            best_c, best_r, best_s = c2, r2, s2

    if best_c is None:
        centers = np.clip(rng.random((n, 2)), 0.05, 0.95)
        return centers, max_radii(centers)

    radii = np.maximum(best_r - 1e-10, 0.0)
    radii = np.minimum(radii, wall_d(best_c))
    return best_c, radii


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END