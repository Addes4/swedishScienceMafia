# EVOLVE-BLOCK-START
"""Baseline: a centre circle with two rings, radii shrunk until nothing overlaps.
Layout follows the ShinkaEvolve circle_packing example (Apache-2.0)."""
import numpy as np


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    from scipy.optimize import minimize

    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(0)
    iu, ju = np.triu_indices(n, 1)
    P = len(iu)
    ar = np.arange(P)

    def cons(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        pair = (x[iu] - x[ju]) ** 2 + (y[iu] - y[ju]) ** 2 - (r[iu] + r[ju]) ** 2
        return np.concatenate([pair, x - r, 1 - x - r, y - r, 1 - y - r])

    def cjac(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        J = np.zeros((P + 4 * n, 3 * n))
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        s = r[iu] + r[ju]
        J[ar, iu] = 2 * dx
        J[ar, ju] = -2 * dx
        J[ar, n + iu] = 2 * dy
        J[ar, n + ju] = -2 * dy
        J[ar, 2 * n + iu] = -2 * s
        J[ar, 2 * n + ju] = -2 * s
        k = np.arange(n)
        J[P + k, k] = 1
        J[P + k, 2 * n + k] = -1
        J[P + n + k, k] = -1
        J[P + n + k, 2 * n + k] = -1
        J[P + 2 * n + k, n + k] = 1
        J[P + 2 * n + k, 2 * n + k] = -1
        J[P + 3 * n + k, n + k] = -1
        J[P + 3 * n + k, 2 * n + k] = -1
        return J

    def obj(v):
        return -np.sum(v[2 * n:])

    gobj = np.concatenate([np.zeros(2 * n), -np.ones(n)])

    def lp_radii(c):
        from scipy.optimize import linprog
        from scipy.sparse import coo_matrix
        d = np.linalg.norm(c[iu] - c[ju], axis=1)
        wall = np.maximum(np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]]), 0.0)
        A = coo_matrix((np.ones(2 * P), (np.concatenate([ar, ar]), np.concatenate([iu, ju]))),
                       shape=(P, n)).tocsr()
        try:
            res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
            if res.status == 0:
                return np.maximum(res.x, 0.0)
        except Exception:
            pass
        return max_radii(c)

    def init(k):
        kind = k % 4
        if kind == 0:
            return rng.random((n, 2)) * 0.9 + 0.05
        if kind == 1:
            s = int(np.ceil(np.sqrt(n)))
            g = (np.arange(s) + 0.5) / s
            pts = np.array([[a, b] for a in g for b in g])
            pts = pts[rng.permutation(len(pts))[:n]]
            return np.clip(pts + rng.normal(0, 0.03, pts.shape), 0.03, 0.97)
        if kind == 2:
            k1 = int(rng.integers(5, 9))
            k2 = n - 1 - k1
            pts = [[0.5, 0.5]]
            pts += [[0.5 + 0.25 * np.cos(2 * np.pi * i / k1), 0.5 + 0.25 * np.sin(2 * np.pi * i / k1)] for i in range(k1)]
            pts += [[0.5 + 0.42 * np.cos(2 * np.pi * i / k2), 0.5 + 0.42 * np.sin(2 * np.pi * i / k2)] for i in range(k2)]
            pts = np.array(pts) + rng.normal(0, 0.02, (n, 2))
            return np.clip(pts, 0.03, 0.97)
        rowsn = int(rng.integers(5, 7))
        per = int(np.ceil(n / rowsn))
        pts = []
        for i in range(rowsn):
            off = 0.5 / per if i % 2 else 0.0
            for j in range(per):
                pts.append([(j + 0.5) / per * 0.95 + off * 0.5 + 0.02, (i + 0.5) / rowsn])
        pts = np.array(pts)
        pts = pts[rng.permutation(len(pts))[:n]]
        return np.clip(pts + rng.normal(0, 0.02, pts.shape), 0.03, 0.97)

    def run(c0):
        v0 = np.concatenate([c0[:, 0], c0[:, 1], lp_radii(c0)])
        try:
            res = minimize(obj, v0, jac=lambda v: gobj, method="SLSQP",
                           bounds=[(0, 1)] * (2 * n) + [(0, 0.5)] * n,
                           constraints=[{"type": "ineq", "fun": cons, "jac": cjac}],
                           options={"maxiter": 300, "ftol": 1e-10})
        except Exception:
            return None
        v = res.x
        c = np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0.0, 1.0)
        return c

    best_c, best_s = None, -1.0
    it = 0
    while time.time() - t0 < budget:
        if best_c is None or it < 30 or it % 3 == 0:
            c0 = init(it)
        else:
            c0 = best_c + rng.normal(0, rng.choice([0.02, 0.05, 0.1]), best_c.shape)
            k = rng.integers(0, n)
            if rng.random() < 0.5:
                c0[k] = rng.random(2)
            c0 = np.clip(c0, 0.02, 0.98)
        it += 1
        c = run(c0)
        if c is None:
            continue
        r = lp_radii(c)
        s = float(np.sum(r))
        if s > best_s:
            best_s, best_c = s, c
    if best_c is None:
        best_c = np.clip(rng.random((n, 2)), 0.05, 0.95)
    return best_c, np.maximum(lp_radii(best_c) - 1e-10, 0.0)


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END