import numpy as np
import time
from scipy.optimize import minimize


def _feasible_radii(c):
    n = len(c)
    r = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    r = np.maximum(r, 0)
    for _ in range(200):
        ch = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.hypot(*(c[i] - c[j]))
                if r[i] + r[j] > d + 1e-15:
                    s = d / (r[i] + r[j])
                    r[i] *= s
                    r[j] *= s
                    ch = True
        if not ch:
            break
    return r


def _optimize(x0, n, iu):
    i_idx, j_idx = iu

    def obj(x):
        return -np.sum(x[2 * n:])

    def obj_g(x):
        g = np.zeros_like(x)
        g[2 * n:] = -1
        return g

    def cons(x):
        c = x[:2 * n].reshape(n, 2)
        r = x[2 * n:]
        d = c[i_idx] - c[j_idx]
        dist = np.sqrt((d ** 2).sum(1) + 1e-18)
        pair = dist - r[i_idx] - r[j_idx]
        wall = np.concatenate([c[:, 0] - r, 1 - c[:, 0] - r, c[:, 1] - r, 1 - c[:, 1] - r])
        return np.concatenate([pair, wall])

    m = len(i_idx)

    def cons_j(x):
        c = x[:2 * n].reshape(n, 2)
        d = c[i_idx] - c[j_idx]
        dist = np.sqrt((d ** 2).sum(1) + 1e-18)
        u = d / dist[:, None]
        J = np.zeros((m + 4 * n, 3 * n))
        k = np.arange(m)
        J[k, 2 * i_idx] = u[:, 0]
        J[k, 2 * i_idx + 1] = u[:, 1]
        J[k, 2 * j_idx] = -u[:, 0]
        J[k, 2 * j_idx + 1] = -u[:, 1]
        J[k, 2 * n + i_idx] = -1
        J[k, 2 * n + j_idx] = -1
        a = np.arange(n)
        J[m + a, 2 * a] = 1
        J[m + a, 2 * n + a] = -1
        J[m + n + a, 2 * a] = -1
        J[m + n + a, 2 * n + a] = -1
        J[m + 2 * n + a, 2 * a + 1] = 1
        J[m + 2 * n + a, 2 * n + a] = -1
        J[m + 3 * n + a, 2 * a + 1] = -1
        J[m + 3 * n + a, 2 * n + a] = -1
        return J

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    res = minimize(obj, x0, jac=obj_g, method='SLSQP', bounds=bounds,
                   constraints=[{'type': 'ineq', 'fun': cons, 'jac': cons_j}],
                   options={'maxiter': 300, 'ftol': 1e-10})
    return res.x


def solve(n=26):
    t0 = time.time()
    rng = np.random.default_rng(1)
    iu = np.triu_indices(n, 1)
    best = None
    best_s = -1
    it = 0
    while time.time() - t0 < 200:
        mode = it % 3
        if mode == 0:
            c = rng.uniform(0.05, 0.95, (n, 2))
        elif mode == 1:
            # jittered grid-ish start
            k = int(np.ceil(np.sqrt(n)))
            g = [(0.1 + 0.8 * (a + 0.5) / k, 0.1 + 0.8 * (b + 0.5) / k)
                 for a in range(k) for b in range(k)]
            idx = rng.permutation(len(g))[:n]
            c = np.array(g)[idx] + rng.normal(0, 0.04, (n, 2))
        else:
            c = [[0.5, 0.5]]
            c += [[0.5 + 0.25 * np.cos(2 * np.pi * i / 8), 0.5 + 0.25 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
            c += [[0.5 + 0.43 * np.cos(2 * np.pi * i / 17), 0.5 + 0.43 * np.sin(2 * np.pi * i / 17)] for i in range(17)]
            c = np.array(c[:n]) + rng.normal(0, 0.03, (n, 2))
        c = np.clip(c, 0.02, 0.98)
        r0 = np.full(n, 0.05)
        x0 = np.concatenate([c.ravel(), r0])
        try:
            x = _optimize(x0, n, iu)
        except Exception:
            it += 1
            continue
        cc = np.clip(x[:2 * n].reshape(n, 2), 0, 1)
        r = _feasible_radii(cc)
        s = r.sum()
        if s > best_s:
            best_s = s
            best = (cc.copy(), r.copy())
        it += 1
    c, r = best
    return c, r * (1 - 1e-12)
