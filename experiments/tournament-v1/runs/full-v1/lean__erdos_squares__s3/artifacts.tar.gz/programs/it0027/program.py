# EVOLVE-BLOCK-START
"""Recursive grid DP: split a square into a k x k grid, optionally merge corner blocks
(one m x m block, or r equal blocks in corners), and recursively fill blocks and cells with
the best arrangement for their counts."""
import math
import numpy as np

_best = [0.0, 1.0]
_choice = [None, ("single",)]
NEG = -1e18


def _corners(k, m, r):
    if r == 1:
        return [(0, 0)]
    if r == 2:
        return [(0, 0), (k - m, k - m)]
    return [(0, 0), (0, k - m), (k - m, 0), (k - m, k - m)]


def _compute(n):
    for N in range(len(_best), n + 1):
        bestarr = np.array(_best[:N], dtype=float)
        kmax = min(int(math.ceil(math.sqrt(N))) + 2, 12)
        J = kmax * kmax
        G = np.full((J + 1, N + 1), NEG)
        G[0, 0] = 0.0
        arg = np.zeros((J + 1, N + 1), dtype=int)
        for j in range(1, J + 1):
            prev = G[j - 1]
            for c in range(N + 1):
                cp = min(c, N - 1)
                a = prev[c - cp:c + 1][::-1] + bestarr[:cp + 1]
                i = int(np.argmax(a))
                G[j, c] = a[i]
                arg[j, c] = i

        def counts(j, c):
            out = []
            while j > 0:
                cc = int(arg[j, c])
                out.append(cc)
                c -= cc
                j -= 1
            return out

        bv = 1.0
        bc = ("single",)
        for k in range(2, kmax + 1):
            v = G[k * k, N] / k
            if v > bv + 1e-12:
                bv = v
                bc = (k, 1, 0, counts(k * k, N), 1)
            for m in range(2, k):
                j = k * k - m * m
                for b in range(1, N):
                    r = N - b
                    if G[j, r] < -1e17:
                        continue
                    v = (m * _best[b] + G[j, r]) / k
                    if v > bv + 1e-12:
                        bv = v
                        bc = (k, m, b, counts(j, r), 1)
            for rr in (2, 4):
                for m in range(2, k // 2 + 1):
                    j = k * k - rr * m * m
                    if j < 0:
                        continue
                    for b in range(1, N):
                        rest = N - rr * b
                        if rest < 0:
                            break
                        if G[j, rest] < -1e17:
                            continue
                        v = (rr * m * _best[b] + G[j, rest]) / k
                        if v > bv + 1e-12:
                            bv = v
                            bc = (k, m, b, counts(j, rest), rr)
        _best.append(bv)
        _choice.append(bc)


def _place(N, x0, y0, s, out):
    if N == 0:
        return
    ch = _choice[N]
    if ch[0] == "single":
        side = max(0.0, s - 2e-14)
        out.append((x0 + s / 2, y0 + s / 2, 0.0, side))
        for _ in range(N - 1):
            out.append((x0 + s / 2, y0 + s / 2, 0.0, 0.0))
        return
    k, m, b, cnts, r = ch
    cell = s / k
    blocked = set()
    if m >= 2:
        for (ci, cj) in _corners(k, m, r):
            _place(b, x0 + ci * cell, y0 + cj * cell, m * cell, out)
            for i in range(ci, ci + m):
                for j in range(cj, cj + m):
                    blocked.add((i, j))
    idx = 0
    for i in range(k):
        for j in range(k):
            if (i, j) in blocked:
                continue
            c = cnts[idx]
            idx += 1
            if c > 0:
                _place(c, x0 + i * cell, y0 + j * cell, cell, out)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    _compute(n)
    out = []
    _place(n, 0.0, 0.0, 1.0, out)
    out = [(min(1.0, max(0.0, a)), min(1.0, max(0.0, b)), 0.0, min(1.0, max(0.0, s)))
           for a, b, _, s in out]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
