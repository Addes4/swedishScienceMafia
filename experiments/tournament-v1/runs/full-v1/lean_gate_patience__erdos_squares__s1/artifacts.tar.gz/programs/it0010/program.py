import math
import numpy as np

_cache = {}


def _build(N):
    amax = math.isqrt(N) + 1
    C = amax * amax
    NEG = -1e18
    f = np.zeros(N + 1)
    typ = [None] * (N + 1)
    H = np.full((C + 1, N + 1), NEG)
    H[0, 0] = 0.0
    ch = np.zeros((C + 1, N + 1), dtype=np.int32)
    Lc = {a: 2 * a - 1 for a in range(2, amax + 1)}
    if N >= 1:
        f[1] = 1.0
        typ[1] = ('one',)
    for n in range(0, N + 1):
        if n == 0:
            for c in range(1, C + 1):
                H[c, 0] = 0.0
                ch[c, 0] = 0
            continue
        # partial H[c][n] excluding single-cell-all config
        for c in range(1, C + 1):
            cand = H[c - 1, n:0:-1] + f[0:n]
            m = int(np.argmax(cand))
            H[c, n] = cand[m]
            ch[c, n] = m
        if n >= 2:
            best = f[n - 1]
            bt = ('prev',)
            for a in range(2, amax + 1):
                v = H[a * a, n] / a
                if v > best + 1e-12:
                    best = v
                    bt = ('grid', a)
                c = Lc[a]
                if n >= 2:
                    vals = (a - 1) / a * f[1:n] + H[c, n - 1:0:-1] / a
                    j = int(np.argmax(vals))
                    if vals[j] > best + 1e-12:
                        best = vals[j]
                        bt = ('L', a, j + 1)
            f[n] = best
            typ[n] = bt
        # finalize
        for c in range(1, C + 1):
            if f[n] >= H[c, n]:
                H[c, n] = f[n]
                ch[c, n] = n
    return f, typ, ch


def _split(ch, c, t):
    # distribute t among c cells
    res = []
    for cc in range(c, 0, -1):
        m = int(ch[cc, t])
        res.append(m)
        t -= m
    return res


def _gen(x0, y0, s, k, typ, ch, out):
    if k <= 0:
        return
    if k == 1:
        out.append((x0 + s / 2, y0 + s / 2, 0.0, s))
        return
    t = typ[k]
    if t[0] == 'prev':
        _gen(x0, y0, s, k - 1, typ, ch, out)
        return
    if t[0] == 'grid':
        a = t[1]
        parts = _split(ch, a * a, k)
        cs = s / a
        idx = 0
        for i in range(a):
            for j in range(a):
                _gen(x0 + i * cs, y0 + j * cs, cs, parts[idx], typ, ch, out)
                idx += 1
        return
    if t[0] == 'L':
        a, m = t[1], t[2]
        cs = s / a
        _gen(x0, y0, s * (a - 1) / a, m, typ, ch, out)
        parts = _split(ch, 2 * a - 1, k - m)
        idx = 0
        for j in range(a):
            _gen(x0 + s * (a - 1) / a, y0 + j * cs, cs, parts[idx], typ, ch, out)
            idx += 1
        for i in range(a - 1):
            _gen(x0 + i * cs, y0 + s * (a - 1) / a, cs, parts[idx], typ, ch, out)
            idx += 1
        return


def _grid_fallback(n):
    k = math.isqrt(n)
    m = k if k * k == n else k + 1
    # option A: k x k grid, sum k ; option B: n squares in m x m grid, sum n/m
    if k >= n / m:
        g, cnt = k, k * k
    else:
        g, cnt = m, n
    cs = 1.0 / g
    res = []
    for i in range(g):
        for j in range(g):
            if len(res) >= cnt:
                break
            res.append(((i + 0.5) * cs, (j + 0.5) * cs, 0.0, cs))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


def solve(n):
    if n <= 0:
        return []
    if n > 800:
        return _grid_fallback(n)
    key = n
    if key not in _cache:
        _cache[key] = _build(n)
    f, typ, ch = _cache[key]
    out = []
    _gen(0.0, 0.0, 1.0, n, typ, ch, out)
    res = []
    for (x, y, a, s) in out:
        s = min(max(s, 0.0), 1.0)
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        res.append((x, y, a, s))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
