# EVOLVE-BLOCK-START
"""DP over recursive grid layouts: m x m grid, one or two corner blocks (opposite
corners) merged into sub-squares (recursively filled), remaining cells recursively filled."""
import math
import numpy as np

_cache = {}


def _prepare(N):
    M = math.isqrt(N) + 3
    Cmax = M * M
    NEG = -1e18
    f = np.zeros(N + 1)
    choice = [None] * (N + 1)
    h = np.full((Cmax + 1, N + 1), NEG)
    harg = np.zeros((Cmax + 1, N + 1), dtype=int)
    h[:, 0] = 0.0

    def fill(n, upto):
        for c in range(1, Cmax + 1):
            u = np.arange(0, upto + 1)
            cand = f[u] + h[c - 1][n - u]
            k = int(np.argmax(cand))
            h[c][n] = cand[k]
            harg[c][n] = k

    f[0] = 0.0
    choice[0] = ('zero',)
    use2 = N <= 60
    for n in range(1, N + 1):
        if n == 1:
            f[1] = 1.0
            choice[1] = ('one',)
            fill(1, 1)
            continue
        fill(n, n - 1)
        best = f[n - 1]
        ch = ('zero',)
        idx = np.arange(0, n)
        for m in range(2, M + 1):
            for j in range(1, m):
                c = m * m - j * j
                vals = f[idx] * j / m + h[c][n - idx] / m
                k = int(np.argmax(vals))
                if vals[k] > best + 1e-12:
                    best = vals[k]
                    ch = ('grid', m, j, k)
        if use2:
            A = idx[:, None]
            B = idx[None, :]
            T = n - A - B
            valid = T >= 0
            Tc = np.where(valid, T, 0)
            fa = f[idx][:, None]
            fb = f[idx][None, :]
            for m in range(3, M + 1):
                for j1 in range(1, m):
                    for j2 in range(1, min(j1, m - j1) + 1):
                        c = m * m - j1 * j1 - j2 * j2
                        if c < 1:
                            continue
                        vals = (fa * j1 + fb * j2 + h[c][Tc]) / m
                        vals = np.where(valid, vals, -1e18)
                        k = int(np.argmax(vals))
                        if vals.flat[k] > best + 1e-12:
                            best = vals.flat[k]
                            a, b = divmod(k, n)
                            ch = ('grid2', m, j1, j2, a, b)
        f[n] = best
        choice[n] = ch
        fill(n, n)
    return f, choice, harg


def _fill_cells(cells, t, x0, y0, cs, harg, choice, out):
    cc = len(cells)
    while cc > 0 and t > 0:
        u = int(harg[cc][t])
        r, c = cells[cc - 1]
        if u > 0:
            _build(u, x0 + c * cs, y0 + r * cs, cs, choice, harg, out)
        t -= u
        cc -= 1


def _build(n, x0, y0, size, choice, harg, out):
    if n <= 0 or size <= 0:
        return
    ch = choice[n]
    if ch[0] == 'one':
        out.append((x0 + size / 2, y0 + size / 2, 0.0, size))
        return
    if ch[0] == 'zero':
        _build(n - 1, x0, y0, size, choice, harg, out)
        return
    if ch[0] == 'grid2':
        _, m, j1, j2, a, b = ch
        cs = size / m
        _build(a, x0, y0, cs * j1, choice, harg, out)
        off = m - j2
        _build(b, x0 + off * cs, y0 + off * cs, cs * j2, choice, harg, out)
        cells = [(r, c) for r in range(m) for c in range(m)
                 if not (r < j1 and c < j1) and not (r >= off and c >= off)]
        _fill_cells(cells, n - a - b, x0, y0, cs, harg, choice, out)
        return
    _, m, j, n1 = ch
    cs = size / m
    _build(n1, x0, y0, cs * j, choice, harg, out)
    cells = [(r, c) for r in range(m) for c in range(m) if not (r < j and c < j)]
    _fill_cells(cells, n - n1, x0, y0, cs, harg, choice, out)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n not in _cache:
        _cache[n] = _prepare(n)
    f, choice, harg = _cache[n]
    out = []
    _build(n, 0.0, 0.0, 1.0, choice, harg, out)
    res = []
    eps = 1e-10
    for (x, y, a, s) in out:
        s2 = max(s - eps, 0.0)
        res.append((min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0), 0.0, s2))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
# EVOLVE-BLOCK-END
