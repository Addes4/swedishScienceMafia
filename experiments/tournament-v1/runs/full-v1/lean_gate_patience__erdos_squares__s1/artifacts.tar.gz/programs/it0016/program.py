import math
import numpy as np

_cache = {}
NEG = -1e18


def _build(N):
    C = N + 2 * math.isqrt(N) + 4
    H = np.full((C + 1, N + 1), NEG)
    G = np.full((C + 1, N + 1), NEG)
    H[:, 0] = 0.0
    G[:, 0] = 0.0
    f = np.zeros(N + 1)
    choice = [None] * (N + 1)
    for m in range(1, N + 1):
        if m == 1:
            f[1] = 1.0
            choice[1] = ('one',)
            H[1:, 1] = 1.0
            continue
        Hs = H[0:C, m - 1:0:-1]
        pre = (Hs + f[1:m]).max(axis=1)
        G[1:, m] = np.maximum.accumulate(pre)
        G[0, m] = NEG
        best = f[m - 1]
        ch = ('prev',)
        for a in range(2, math.isqrt(m) + 2):
            if a * a <= C:
                v = G[a * a, m] / a
                if v > best + 1e-12:
                    best = v
                    ch = ('grid', a)
        nb = np.arange(1, m)
        for a in range(2, m // 2 + 2):
            c = 2 * a - 1
            if c > C:
                break
            vals = (a - 1) / a * f[nb] + H[c, m - nb] / a
            k = int(np.argmax(vals))
            if vals[k] > best + 1e-12:
                best = float(vals[k])
                ch = ('L', a, int(nb[k]))
        f[m] = best
        choice[m] = ch
        H[1:, m] = np.maximum(G[1:, m], f[m])
        H[0, m] = NEG
    return {'N': N, 'C': C, 'H': H, 'G': G, 'f': f, 'choice': choice}


def _distribute(D, c, m):
    H, f = D['H'], D['f']
    counts = []
    while m > 0 and c > 0:
        if c == 1:
            counts.append(m)
            c = 0
            m = 0
            break
        js = np.arange(0, m + 1)
        vals = H[c - 1][m - js] + f[js]
        j = int(np.argmax(vals))
        counts.append(j)
        m -= j
        c -= 1
    return counts


def _distribute_strict(D, c, m):
    H, G, f = D['H'], D['G'], D['f']
    counts = []
    js = np.arange(1, m)
    while c > 1:
        pre = H[c - 1][m - js] + f[js]
        if G[c - 1, m] >= pre.max() - 1e-12 and c - 1 > 1:
            counts.append(0)
            c -= 1
            continue
        j = int(np.argmax(pre)) + 1
        counts.append(j)
        counts += _distribute(D, c - 1, m - j)
        return counts
    return counts


def _place(D, m, x, y, s, out):
    if m <= 0 or s <= 0:
        return
    if m == 1:
        out.append((x + s / 2, y + s / 2, 0.0, s))
        return
    ch = D['choice'][m]
    if ch[0] == 'prev':
        _place(D, m - 1, x, y, s, out)
    elif ch[0] == 'grid':
        a = ch[1]
        counts = _distribute_strict(D, a * a, m)
        cs = s / a
        for idx, cnt in enumerate(counts):
            if cnt > 0:
                i, j = divmod(idx, a)
                _place(D, cnt, x + i * cs, y + j * cs, cs, out)
    else:
        a, nb = ch[1], ch[2]
        bs = s * (a - 1) / a
        _place(D, nb, x, y, bs, out)
        cs = s / a
        counts = _distribute(D, 2 * a - 1, m - nb)
        cells = []
        for i in range(a):
            cells.append((x + bs, y + i * cs))
        for i in range(a - 1):
            cells.append((x + i * cs, y + bs))
        for idx, cnt in enumerate(counts):
            if cnt > 0:
                cx, cy = cells[idx]
                _place(D, cnt, cx, cy, cs, out)


def solve(n):
    if n <= 0:
        return []
    D = _cache.get('D')
    if D is None or D['N'] < n:
        D = _build(n)
        _cache['D'] = D
    out = []
    _place(D, n, 0.0, 0.0, 1.0, out)
    shrink = 1.0 - 1e-13
    res = []
    for (cx, cy, ang, sd) in out[:n]:
        res.append((min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), 0.0,
                    min(max(sd * shrink, 0.0), 1.0)))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
