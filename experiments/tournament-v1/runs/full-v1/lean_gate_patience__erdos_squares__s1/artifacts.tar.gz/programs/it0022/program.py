# EVOLVE-BLOCK-START
"""DP over recursive axis-aligned layouts (grid / corner block + L border)."""
import math
import numpy as np


def _grid_fallback(n):
    best = None
    for k in (math.isqrt(n), math.isqrt(n) + 1):
        if k < 1 or k * k < 1:
            continue
        cnt = min(n, k * k)
        val = cnt / k
        if best is None or val > best[0]:
            best = (val, k)
    k = best[1]
    res = []
    for i in range(n):
        if i < k * k:
            r, c = divmod(i, k)
            res.append(((c + 0.5) / k, (r + 0.5) / k, 0.0, 1.0 / k * (1 - 1e-12)))
        else:
            res.append((0.5, 0.5, 0.0, 0.0))
    return res


def solve(n):
    if n <= 0:
        return []
    if n > 2000:
        return _grid_fallback(n)
    NEG = -1e18
    amax = max(2, min(math.isqrt(n) + 2, 10))
    As = list(range(2, amax + 1))
    G = {}
    argP = {}
    single = {}
    for a in As:
        K = a * a
        g = np.full((K + 1, n + 1), NEG)
        g[:, 0] = 0.0
        G[a] = g
        argP[a] = np.zeros((K + 1, n + 1), dtype=np.int64)
        single[a] = np.zeros((K + 1, n + 1), dtype=bool)

    ff = np.zeros(n + 1)
    typ = [None] * (n + 1)
    typ[0] = ('zero',)
    for m in range(1, n + 1):
        best = ff[m - 1]
        bt = ('mono',)
        for a in As:
            K = a * a
            g = G[a]
            ap = argP[a]
            fa = ff[:m] / a
            for k in range(1, K + 1):
                vals = g[k - 1, m:0:-1] + fa
                j = int(np.argmax(vals))
                g[k, m] = vals[j]
                ap[k, m] = j
            if m >= 2:
                v = g[K, m]
                if v > best + 1e-12:
                    best = v
                    bt = ('grid', a)
                for b in range(2, a):
                    L = a * a - b * b
                    vv = (b / a) * ff[1:m] + g[L, m - 1:0:-1]
                    j = int(np.argmax(vv))
                    if vv[j] > best + 1e-12:
                        best = vv[j]
                        bt = ('corner', a, b, j + 1)
        if m == 1:
            best = 1.0
            bt = ('one',)
        ff[m] = best
        typ[m] = bt
        for a in As:
            K = a * a
            g = G[a]
            s = best / a
            for k in range(1, K + 1):
                if s > g[k, m]:
                    g[k, m] = s
                    single[a][k, m] = True

    out = []

    def cells(a, k0, j, mtop):
        res = []
        k = k0
        while k >= 1 and j > 0:
            if j < mtop and single[a][k, j]:
                t = j
            else:
                t = int(argP[a][k, j])
            res.append((k, t))
            j -= t
            k -= 1
        return res

    def build(m, x, y, s):
        if m <= 0:
            return
        t = typ[m]
        if t[0] == 'one':
            out.append((x + s / 2, y + s / 2, 0.0, s))
        elif t[0] == 'mono':
            build(m - 1, x, y, s)
        elif t[0] == 'grid':
            a = t[1]
            cs = s / a
            for k, tt in cells(a, a * a, m, m):
                c = k - 1
                r, co = divmod(c, a)
                build(tt, x + co * cs, y + r * cs, cs)
        elif t[0] == 'corner':
            a, b, m0 = t[1], t[2], t[3]
            cs = s / a
            build(m0, x, y, s * b / a)
            pos = [(r, co) for r in range(a) for co in range(a)
                   if not (r < b and co < b)]
            L = a * a - b * b
            for k, tt in cells(a, L, m - m0, m):
                r, co = pos[k - 1]
                build(tt, x + co * cs, y + r * cs, cs)

    build(n, 0.0, 0.0, 1.0)
    res = []
    for (cx, cy, ang, sd) in out[:n]:
        res.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0, min(1.0, max(0.0, sd))))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
# EVOLVE-BLOCK-END
