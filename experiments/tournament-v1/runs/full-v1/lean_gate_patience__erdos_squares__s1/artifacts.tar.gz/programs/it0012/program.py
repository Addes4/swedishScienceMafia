import math
import numpy as np

_cache = {}


def _build(N):
    amax = math.isqrt(N) + 1
    C = amax * amax
    NEG = -1e18
    f = np.zeros(N + 1)
    typ = [None] * (N + 1)
    H = np.full((C + 1, N + 1), NEG)
    H[0, 0] = 0.0
    ch = np.zeros((C + 1, N + 1), dtype=np.int32)
    Lc = {a: 2 * a - 1 for a in range(2, amax + 1)}
    if N >= 1:
        f[1] = 1.0
        typ[1] = ('one',)
    for n in range(0, N + 1):
        if n == 0:
            for c in range(1, C + 1):
                H[c, 0] = 0.0
                ch[c, 0] = 0
            continue
        for c in range(1, C + 1):
            cand = H[c - 1, n:0:-1] + f[0:n]
            m = int(np.argmax(cand))
            H[c, n] = cand[m]
            ch[c, n] = m
        if n >= 2:
            best = f[n - 1]
            bt = ('prev',)
            for a in range(2, amax + 1):
                v = H[a * a, n] / a
                if v > best + 1e-12:
                    best = v
                    bt = ('grid', a)
                c = Lc[a]
                vals = (a - 1) / a * f[1:n] + H[c, n - 1:0:-1] / a
                j = int(np.argmax(vals))
                if vals[j] > best + 1e-12:
                    best = vals[j]
                    bt = ('L', a, j + 1)
            f[n] = best
            typ[n] = bt
        for c in range(1, C + 1):
            if f[n] >= H[c, n]:
                H[c, n] = f[n]
                ch[c, n] = n
    return f, typ, ch


def _split(ch, c, t):
    res = []
    for cc in range(c, 0, -1):
        m = int(ch[cc, t])
        res.append(m)
        t -= m
    return res


def _gen(x0, y0, s, k, typ, ch, out):
    if k <= 0:
        return
    if k == 1:
        out.append((x0 + s / 2, y0 + s / 2, 0.0, s))
        return
    t = typ[k]
    if t[0] == 'prev':
        _gen(x0, y0, s, k - 1, typ, ch, out)
        return
    if t[0] == 'grid':
        a = t[1]
        parts = _split(ch, a * a, k)
        cs = s / a
        idx = 0
        for i in range(a):
            for j in range(a):
                _gen(x0 + i * cs, y0 + j * cs, cs, parts[idx], typ, ch, out)
                idx += 1
        return
    if t[0] == 'L':
        a, m = t[1], t[2]
        cs = s / a
        _gen(x0, y0, s * (a - 1) / a, m, typ, ch, out)
        parts = _split(ch, 2 * a - 1, k - m)
        idx = 0
        for j in range(a):
            _gen(x0 + s * (a - 1) / a, y0 + j * cs, cs, parts[idx], typ, ch, out)
            idx += 1
        for i in range(a - 1):
            _gen(x0 + i * cs, y0 + s * (a - 1) / a, cs, parts[idx], typ, ch, out)
            idx += 1
        return


def _grid_fallback(n):
    k = math.isqrt(n)
    if k * k < n:
        # candidates: k x k grid (k*k squares, use n? only k*k placed) vs
        # (k+1) grid with n squares
        a = k + 1
        v1 = k * k * (1.0 / k) if k > 0 else 0.0
        v2 = n * (1.0 / a)
        if v1 >= v2 and k > 0:
            a = k
    else:
        a = k
    cs = 1.0 / a
    res = []
    for i in range(a):
        for j in range(a):
            if len(res) < n:
                res.append(((i + 0.5) * cs, (j + 0.5) * cs, 0.0, cs))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res


def solve(n):
    if n <= 0:
        return []
    if n > 500:
        return _grid_fallback(n)
    if n not in _cache:
        _cache[n] = _build(n)
    f, typ, ch = _cache[n]
    out = []
    _gen(0.0, 0.0, 1.0, n, typ, ch, out)
    res = []
    for (x, y, a, s) in out:
        s = min(max(s, 0.0), 1.0)
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        res.append((x, y, a, s))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
