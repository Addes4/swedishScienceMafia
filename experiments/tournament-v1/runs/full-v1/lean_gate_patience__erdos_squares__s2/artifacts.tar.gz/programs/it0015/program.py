# EVOLVE-BLOCK-START
"""DP over recursive subdivision: a cell is cut into an m x m grid, optionally with one
j x j block merged into a single bigger cell; every cell is filled recursively.
g(t) = best sum of sides for t squares in a unit cell, computed for all t <= n by
vectorised max-plus convolutions iterated to a fixpoint."""
import math
import time
import sys
import numpy as np

NEG = -1e18
SH = 1e-12


def _conv(A, B, N, arg=None):
    out = np.full(N + 1, NEG)
    for a in range(N + 1):
        b = B[a]
        if b <= NEG / 2:
            continue
        cand = A[:N + 1 - a] + b
        view = out[a:]
        if arg is None:
            np.maximum(view, cand, out=view)
        else:
            better = cand > view
            view[better] = cand[better]
            arg[a:][better] = a
    return out


def _tables(g, N, Kmax, want_arg):
    Hs = [None, g.copy()]
    args = [None, np.arange(N + 1)]
    for K in range(2, Kmax + 1):
        if want_arg:
            ar = np.zeros(N + 1, dtype=np.int64)
            Hs.append(_conv(Hs[-1], g, N, ar))
            args.append(ar)
        else:
            Hs.append(_conv(Hs[-1], g, N))
    return Hs, args


def solve(n):
    sys.setrecursionlimit(20000)
    t0 = time.time()
    if n <= 0:
        return []
    if n > 20000:
        k = math.isqrt(n)
        s = 1.0 / k
        sq = [((i + .5) * s, (j + .5) * s, 0.0, s * (1 - SH)) for i in range(k) for j in range(k)]
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        return sq[:n]
    N = n
    M = 10 if n <= 1500 else (6 if n <= 6000 else 4)
    configs = []
    for m in range(2, M + 1):
        configs.append((m, 0))
        for j in range(2, m):
            configs.append((m, j))
    Kmax = M * M
    g = np.array([math.isqrt(t) for t in range(N + 1)], dtype=float)

    def update(g):
        Hs, _ = _tables(g, N, Kmax, False)
        newg = g.copy()
        for (m, j) in configs:
            if j == 0:
                cand = Hs[m * m] / m
            else:
                cand = _conv(Hs[m * m - j * j], j * g, N) / m
            np.maximum(newg, cand, out=newg)
        newg = np.maximum.accumulate(newg)
        return newg

    for it in range(15):
        if time.time() - t0 > 30:
            break
        newg = update(g)
        diff = np.max(newg - g)
        g = newg
        if diff < 1e-12:
            break

    Hs, args = _tables(g, N, Kmax, True)
    cache = {}

    def resolve(t):
        while True:
            if t <= 1:
                return t, ('leaf',)
            if t in cache:
                d = cache[t]
            else:
                best = g[t - 1]
                d = ('mono',)
                k = math.isqrt(t)
                if k > best + 1e-12:
                    best = k
                    d = ('grid', k)
                for (m, j) in configs:
                    if j == 0:
                        v = Hs[m * m][t] / m
                        if v > best + 1e-12:
                            best = v
                            d = ('cfg', m, 0, 0)
                    else:
                        K = m * m - j * j
                        vec = j * g[:t + 1] + Hs[K][t::-1]
                        c = int(np.argmax(vec))
                        v = vec[c] / m
                        if v > best + 1e-12:
                            best = v
                            d = ('cfg', m, j, c)
                cache[t] = d
            if d[0] == 'mono':
                t -= 1
                continue
            return t, d

    out = []

    def emit(t, x0, y0, s):
        if t <= 0:
            return
        t, d = resolve(t)
        if d[0] == 'leaf':
            if t == 1:
                sd = s * (1 - SH)
                out.append((x0 + s / 2, y0 + s / 2, 0.0, sd))
            return
        if d[0] == 'grid':
            k = d[1]
            cs = s / k
            for i in range(k):
                for jj in range(k):
                    out.append((x0 + (i + .5) * cs, y0 + (jj + .5) * cs, 0.0, cs * (1 - SH)))
            return
        _, m, j, c = d
        cs = s / m
        cells = []
        for r in range(m):
            for q in range(m):
                if r < j and q < j:
                    continue
                cells.append((r, q))
        K = len(cells)
        rem = t - c
        if j:
            emit(c, x0, y0, cs * j)
        counts = [0] * K
        for k in range(K, 0, -1):
            a = int(args[k][rem])
            counts[k - 1] = a
            rem -= a
        for (r, q), a in zip(cells, counts):
            if a > 0:
                emit(a, x0 + r * cs, y0 + q * cs, cs)

    emit(n, 0.0, 0.0, 1.0)
    res = []
    for (x, y, a, s) in out[:n]:
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), a, min(1.0, max(0.0, s))))
    res += [(0.5, 0.5, 0.0, 0.0)] * (n - len(res))
    return res[:n]
# EVOLVE-BLOCK-END
