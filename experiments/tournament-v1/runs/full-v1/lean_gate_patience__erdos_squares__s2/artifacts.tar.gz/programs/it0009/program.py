import math
import numpy as np


def solve(n):
    if n <= 0:
        return []
    N = n
    M = max(2, min(math.isqrt(N) + 4, 12))
    NEG = -np.inf
    F = {}
    CH = {}
    for m in range(2, M + 1):
        K = m * m
        f = np.full((K, N + 1), NEG)
        f[:, 0] = 0.0
        F[m] = f
        CH[m] = np.zeros((K, N + 1), dtype=np.int32)
    g = np.zeros(N + 1)
    typ = [None] * (N + 1)

    for nn in range(1, N + 1):
        if nn == 1:
            best = 1.0
            choice = ('s',)
        else:
            best = g[nn - 1]
            choice = ('p',)
        for m in range(2, M + 1):
            K = m * m
            Fm = F[m]
            if nn >= 2:
                Tm = Fm[:K - 1, nn - 1:0:-1] + g[1:nn] / m
                arg = Tm.argmax(axis=1)
                T = Tm[np.arange(K - 1), arg]
                cm = np.maximum.accumulate(T)
                prev = np.concatenate(([NEG], cm[:-1]))
                Fm[1:, nn] = cm
                CH[m][1:, nn] = np.where(T > prev, arg + 1, 0)
            js = np.arange(1, m)
            cs = K - js * js
            Mat = Fm[cs, nn:0:-1] + (js[:, None] * g[None, :nn]) / m
            ar = Mat.argmax(axis=1)
            vals = Mat[np.arange(len(js)), ar]
            k = int(vals.argmax())
            if vals[k] > best + 1e-12:
                best = float(vals[k])
                choice = ('x', m, int(js[k]), int(ar[k]))
        g[nn] = best
        typ[nn] = choice
        for m in range(2, M + 1):
            Fm = F[m]
            v = best / m
            cur = Fm[1:, nn]
            mask = v > cur
            Fm[1:, nn] = np.where(mask, v, cur)
            CH[m][1:, nn] = np.where(mask, nn, CH[m][1:, nn])

    out = []

    def build(k, ox, oy, s):
        if k <= 0 or s <= 0:
            return
        t = typ[k]
        if t[0] == 's':
            out.append((ox + s / 2, oy + s / 2, 0.0, s))
            return
        if t[0] == 'p':
            build(k - 1, ox, oy, s)
            return
        _, m, j, nb = t
        cell = s / m
        build(nb, ox, oy, j * cell)
        cells = []
        for r in range(m):
            for c in range(m):
                if r < j and c < j:
                    continue
                cells.append((ox + c * cell, oy + r * cell))
        cur = k - nb
        ch = CH[m]
        for cc in range(len(cells), 0, -1):
            a = int(ch[cc, cur])
            if a > 0:
                px, py = cells[cc - 1]
                build(a, px, py, cell)
            cur -= a

    build(N, 0.0, 0.0, 1.0)
    res = []
    shrink = 1.0 - 1e-12
    for (x, y, a, s) in out[:N]:
        s2 = s * shrink
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), 0.0, min(1.0, max(0.0, s2))))
    while len(res) < N:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
