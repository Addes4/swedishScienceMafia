import math
import numpy as np


def solve(n):
    if n <= 0:
        return []
    N = n
    M = max(2, min(math.isqrt(N) + 2, 12))
    NEG = -np.inf
    F = {}
    CH = {}
    for m in range(2, M + 1):
        K = m * m
        f = np.full((K, N + 1), NEG)
        f[:, 0] = 0.0
        F[m] = f
        CH[m] = np.zeros((K, N + 1), dtype=np.int32)
    g = np.zeros(N + 1)
    h = np.full(N + 1, NEG)
    h[0] = 0.0
    typ = [None] * (N + 1)

    for nn in range(1, N + 1):
        if nn == 1:
            best = 1.0
            choice = ('s',)
        else:
            best = g[nn - 1]
            choice = ('p',)
        if nn >= 2:
            h[nn] = float(np.max(g[1:nn] + g[nn - 1:0:-1]))
        for m in range(2, M + 1):
            K = m * m
            Fm = F[m]
            if nn >= 2:
                Tm = Fm[:K - 1, nn - 1:0:-1] + g[1:nn] / m
                arg = Tm.argmax(axis=1)
                T = Tm[np.arange(K - 1), arg]
                cm = np.maximum.accumulate(T)
                prev = np.concatenate(([NEG], cm[:-1]))
                Fm[1:, nn] = cm
                CH[m][1:, nn] = np.where(T > prev, arg + 1, 0)
            js = np.arange(1, m)
            cs = K - js * js
            Mat = Fm[cs, nn:0:-1] + (js[:, None] * g[None, :nn]) / m
            ar = Mat.argmax(axis=1)
            vals = Mat[np.arange(len(js)), ar]
            k = int(vals.argmax())
            if vals[k] > best + 1e-12:
                best = float(vals[k])
                choice = ('x', m, int(js[k]), int(ar[k]))
            # two equal blocks in opposite corners
            for j in range(2, m // 2 + 1):
                c2 = K - 2 * j * j
                row = Fm[c2, nn - 1::-1] + j * h[1:nn + 1] / m
                t0 = int(row.argmax())
                v = float(row[t0])
                if v > best + 1e-12:
                    best = v
                    choice = ('y', m, j, t0 + 1)
        g[nn] = best
        typ[nn] = choice
        h[nn] = max(h[nn], best)
        for m in range(2, M + 1):
            Fm = F[m]
            v = best / m
            cur = Fm[1:, nn]
            mask = v > cur
            Fm[1:, nn] = np.where(mask, v, cur)
            CH[m][1:, nn] = np.where(mask, nn, CH[m][1:, nn])

    out = []

    def fill(m, cells, cur, ch, cell):
        for cc in range(len(cells), 0, -1):
            a = int(ch[cc, cur])
            if a > 0:
                px, py = cells[cc - 1]
                build(a, px, py, cell)
            cur -= a

    def build(k, ox, oy, s):
        if k <= 0 or s <= 0:
            return
        t = typ[k]
        if t[0] == 's':
            out.append((ox + s / 2, oy + s / 2, 0.0, s))
            return
        if t[0] == 'p':
            build(k - 1, ox, oy, s)
            return
        if t[0] == 'x':
            _, m, j, nb = t
            cell = s / m
            build(nb, ox, oy, j * cell)
            cells = []
            for r in range(m):
                for c in range(m):
                    if r < j and c < j:
                        continue
                    cells.append((ox + c * cell, oy + r * cell))
            fill(m, cells, k - nb, CH[m], cell)
            return
        _, m, j, tt = t
        cell = s / m
        best_a = 0
        best_v = -np.inf
        for a in range(0, tt + 1):
            v = g[a] + g[tt - a]
            if v > best_v:
                best_v = v
                best_a = a
        build(best_a, ox, oy, j * cell)
        build(tt - best_a, ox + (m - j) * cell, oy + (m - j) * cell, j * cell)
        cells = []
        for r in range(m):
            for c in range(m):
                if r < j and c < j:
                    continue
                if r >= m - j and c >= m - j:
                    continue
                cells.append((ox + c * cell, oy + r * cell))
        fill(m, cells, k - tt, CH[m], cell)

    build(N, 0.0, 0.0, 1.0)
    res = []
    shrink = 1.0 - 1e-12
    for (x, y, a, s) in out[:N]:
        s2 = s * shrink
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), 0.0, min(1.0, max(0.0, s2))))
    while len(res) < N:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
