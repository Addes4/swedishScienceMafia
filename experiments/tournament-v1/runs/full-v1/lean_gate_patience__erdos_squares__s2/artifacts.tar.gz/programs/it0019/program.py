# EVOLVE-BLOCK-START
"""Dynamic program over recursive subdivision of a square cell."""
import math
import time
import numpy as np

MMAX = 10


def solve(n):
    if n <= 0:
        return []
    t_start = time.time()
    N = n
    Cmax = min(100, n)
    r = np.arange(N + 1)
    idx = r[:, None] - r[None, :]
    valid = idx >= 0
    idxc = np.where(valid, idx, 0)
    inv = ~valid

    def conv(A, B):
        M = A[idxc] + B[None, :]
        M[inv] = -1e18
        arg = M.argmax(axis=1)
        return M[r, arg], arg

    def build_H(g):
        H = np.zeros((Cmax + 1, N + 1))
        ARG = np.zeros((Cmax + 1, N + 1), dtype=np.int64)
        for c in range(1, Cmax + 1):
            H[c], ARG[c] = conv(H[c - 1], g)
        return H, ARG

    g = np.ones(N + 1)
    g[0] = 0.0
    budget = 30.0
    H, ARG = build_H(g)
    for _ in range(40):
        new = g.copy()
        for m in range(2, MMAX + 1):
            ce = min(m * m, Cmax)
            new = np.maximum(new, H[ce] / m)
            for j in range(2, m):
                c = m * m - j * j
                ce = min(c, Cmax)
                val, _a = conv(H[ce] / m, g * (j / m))
                new = np.maximum(new, val)
        new = np.maximum.accumulate(new)
        if np.all(new <= g + 1e-12):
            break
        g = new
        if time.time() - t_start > budget:
            H, ARG = build_H(g)
            break
        H, ARG = build_H(g)

    out = []
    stack = [(n, 0.0, 0.0, 1.0, 0)]
    shrink = 1.0 - 1e-9
    while stack:
        t, x0, y0, s, depth = stack.pop()
        if t <= 0 or s <= 0:
            continue
        if t == 1 or depth > 30:
            sd = s * shrink
            out.append((min(1.0, max(0.0, x0 + s / 2)), min(1.0, max(0.0, y0 + s / 2)), 0.0, min(1.0, sd)))
            continue
        best_val = 1.0
        best = ("single",)
        if g[t - 1] > best_val + 1e-12:
            best_val = g[t - 1]
            best = ("mono",)
        for m in range(2, MMAX + 1):
            ce = min(m * m, Cmax)
            v = H[ce][t] / m
            if v > best_val + 1e-12:
                best_val = v
                best = ("grid", m, 0, 0, ce)
            for j in range(2, m):
                c = m * m - j * j
                ce = min(c, Cmax)
                vals = (j / m) * g[:t + 1] + H[ce][t::-1] / m
                tb = int(vals.argmax())
                v = vals[tb]
                if v > best_val + 1e-12:
                    best_val = v
                    best = ("grid", m, j, tb, ce)
        if best[0] == "single":
            sd = s * shrink
            out.append((min(1.0, max(0.0, x0 + s / 2)), min(1.0, max(0.0, y0 + s / 2)), 0.0, min(1.0, sd)))
        elif best[0] == "mono":
            stack.append((t - 1, x0, y0, s, depth + 1))
        else:
            _, m, j, tb, ce = best
            cs = s / m
            rem = t - tb
            # distribute among first ce cells
            alloc = []
            rr = rem
            for k in range(ce, 0, -1):
                a = int(ARG[k][rr])
                alloc.append(a)
                rr -= a
            cells = []
            for p in range(m):
                for q in range(m):
                    if j >= 2 and p < j and q < j:
                        continue
                    cells.append((p, q))
            if j >= 2 and tb > 0:
                stack.append((tb, x0, y0, s * j / m, depth + 1))
            for (p, q), a in zip(cells, alloc):
                if a > 0:
                    stack.append((a, x0 + q * cs, y0 + p * cs, cs, depth + 1))
    out = out[:n]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END
