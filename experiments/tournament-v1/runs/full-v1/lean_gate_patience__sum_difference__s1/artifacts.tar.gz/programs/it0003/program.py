# EVOLVE-BLOCK-START
"""Truncated simplex-lattice construction: {x in N^k : sum x <= n, x_i <= m}."""
import math
import time
import numpy as np


def _count(k, n, m):
    # number of x in [0,m]^k with sum <= n
    dp = [1] + [0] * n
    for _ in range(k):
        new = [0] * (n + 1)
        for s in range(n + 1):
            if dp[s]:
                for v in range(min(m, n - s) + 1):
                    new[s + v] += dp[s]
        dp = new
    return sum(dp)


def _gen(k, n, m):
    pts = []

    def rec(prefix, remaining, dims):
        if dims == 0:
            pts.append(tuple(prefix))
            return
        for v in range(min(m, remaining) + 1):
            prefix.append(v)
            rec(prefix, remaining - v, dims - 1)
            prefix.pop()

    rec([], n, k)
    return pts


def _embed(pts, B):
    vals = []
    for p in pts:
        v = 0
        for x in reversed(p):
            v = v * B + x
        vals.append(v)
    return vals


def _score_arr(arr):
    a = np.array(arr, dtype=np.int64)
    d = np.unique((a[:, None] - a[None, :]).ravel())
    s = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / len(a)) / 100


def solve():
    start = time.time()
    best = [0, 1, 3]
    best_score = -1.0
    cands = []
    for n in range(1, 16):
        for m in range(1, n + 1):
            B = 2 * m + 1
            for k in range(1, 41):
                if B ** k > 3.8e15:
                    break
                size = _count(k, n, m)
                if size > 4000:
                    break
                lo = 800 if m == n else 1500
                if size < lo:
                    continue
                cands.append((m != n, -size, k, n, m))
    cands.sort()
    for trunc, nsize, k, n, m in cands:
        lim = 50 if not trunc else 100
        if time.time() - start > lim:
            if trunc:
                break
            continue
        pts = _gen(k, n, m)
        vals = _embed(pts, 2 * m + 1)
        mx = max(vals)
        mn = min(vals)
        shift = (mx + mn) // 2
        vals = [v - shift for v in vals]
        if max(abs(v) for v in vals) > 10**15:
            continue
        try:
            sc = _score_arr(vals)
        except MemoryError:
            continue
        if sc > best_score:
            best_score = sc
            best = vals
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END
