# EVOLVE-BLOCK-START
"""Simplex-lattice construction with base-tuning of the integer embedding on top candidates."""
import math
import time
import numpy as np


def _simplex(k, n):
    pts = []

    def rec(prefix, remaining, dims):
        if dims == 0:
            pts.append(tuple(prefix))
            return
        for v in range(remaining + 1):
            prefix.append(v)
            rec(prefix, remaining - v, dims - 1)
            prefix.pop()

    rec([], n, k)
    return np.array(pts, dtype=np.int64)


def _embed(P, B):
    k = P.shape[1]
    mult = np.array([B ** i for i in range(k)], dtype=np.int64)
    v = np.unique(P @ mult)
    return v


def _score_arr(a):
    a = np.asarray(a, dtype=np.int64)
    d = np.unique((a[:, None] - a[None, :]).ravel())
    s = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / len(a)) / 100


def _center(v):
    shift = (int(v.max()) + int(v.min())) // 2
    return v - shift


def solve():
    start = time.time()
    best = np.array([0, 1, 3], dtype=np.int64)
    best_score = -1.0
    cands = []
    for k in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + k, k)
            if size < 4 or size > 4000:
                continue
            B = 2 * n + 1
            if n * B ** (k - 1) * 1.2 > 1.9e15:
                continue
            cands.append((size, k, n))
    cands.sort()
    scored = []
    for size, k, n in cands:
        if time.time() - start > 45:
            break
        P = _simplex(k, n)
        vals = _center(_embed(P, 2 * n + 1))
        if int(np.abs(vals).max()) > 10**15:
            continue
        try:
            sc = _score_arr(vals)
        except MemoryError:
            continue
        scored.append((sc, k, n))
        if sc > best_score:
            best_score = sc
            best = vals

    scored.sort(reverse=True)
    top = scored[:3]
    t_start = time.time()
    for idx, (sc0, k, n) in enumerate(top):
        remaining_cands = len(top) - idx
        deadline = time.time() + (105 - time.time() + start) / remaining_cands
        P = _simplex(k, n)
        for B in range(2 * n, n, -1):
            if time.time() > deadline or time.time() - start > 105:
                break
            vals = _embed(P, B)
            if len(vals) < 4:
                continue
            vals = _center(vals)
            if int(np.abs(vals).max()) > 10**15:
                continue
            try:
                sc = _score_arr(vals)
            except MemoryError:
                continue
            if sc > best_score:
                best_score = sc
                best = vals
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END
