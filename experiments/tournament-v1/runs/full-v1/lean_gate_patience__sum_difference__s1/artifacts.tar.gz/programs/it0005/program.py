# EVOLVE-BLOCK-START
"""Weighted simplex-lattice constructions embedded in integers."""
import math
import time
import numpy as np


def _count(ws, n):
    cnt = [0] * (n + 1)
    cnt[0] = 1
    for w in ws:
        new = [0] * (n + 1)
        for t in range(n + 1):
            if cnt[t]:
                j = t
                while j <= n:
                    new[j] += cnt[t]
                    j += w
        cnt = new
    return sum(cnt)


def _points_vals(ws, n):
    bases = [2 * (n // w) + 1 for w in ws]
    mult = []
    m = 1
    for b in bases:
        mult.append(m)
        m *= b
    vals = []
    k = len(ws)

    def rec(i, rem, cur):
        if i == k:
            vals.append(cur)
            return
        w = ws[i]
        for x in range(rem // w + 1):
            rec(i + 1, rem - w * x, cur + x * mult[i])

    rec(0, n, 0)
    return vals


def _score_arr(arr):
    a = np.array(arr, dtype=np.int64)
    d = np.unique((a[:, None] - a[None, :]).ravel())
    s = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / len(a)) / 100


def solve():
    start = time.time()
    best = [0, 1, 3]
    best_score = -1.0
    cands = []
    seen = set()
    for k1 in range(0, 40):
        for k2 in range(0, 10):
            for k3 in range(0, 6):
                k = k1 + k2 + k3
                if k == 0:
                    continue
                for n in range(2, 16):
                    if k2 == 0 and k3 == 0:
                        lo = 1500
                    else:
                        lo = 2500
                    ws = tuple([1] * k1 + [2] * k2 + [3] * k3)
                    # quick prune: size lower bound check via count
                    if (k1 + k2 + k3) > 40:
                        continue
                    size = _count(ws, n)
                    if size < lo or size > 4000:
                        continue
                    key = (ws, n)
                    if key in seen:
                        continue
                    seen.add(key)
                    mag = 1
                    for w in ws:
                        mag *= 2 * (n // w) + 1
                    if mag > 3.8e15:
                        continue
                    pure = (k2 == 0 and k3 == 0)
                    cands.append((0 if pure else 1, -size, ws, n))
    cands.sort(key=lambda c: (c[0], c[1]))
    for pr, nsize, ws, n in cands:
        if time.time() - start > 95:
            break
        vals = _points_vals(list(ws), n)
        mx = max(vals)
        mn = min(vals)
        shift = (mx + mn) // 2
        vals = [v - shift for v in vals]
        if max(abs(v) for v in vals) > 10**15:
            continue
        try:
            sc = _score_arr(vals)
        except MemoryError:
            continue
        if sc > best_score:
            best_score = sc
            best = vals
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END
