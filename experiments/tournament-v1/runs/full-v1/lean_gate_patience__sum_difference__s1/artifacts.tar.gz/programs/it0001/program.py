# EVOLVE-BLOCK-START
"""Simplex-lattice construction: A = {x in N^k : sum x <= n} embedded in integers."""
import math
import time
import itertools
import numpy as np


def _simplex(k, n):
    pts = []

    def rec(prefix, remaining, dims):
        if dims == 0:
            pts.append(tuple(prefix))
            return
        for v in range(remaining + 1):
            prefix.append(v)
            rec(prefix, remaining - v, dims - 1)
            prefix.pop()

    rec([], n, k)
    return pts


def _embed(pts, n):
    B = 2 * n + 1
    vals = []
    for p in pts:
        v = 0
        for x in reversed(p):
            v = v * B + x
        vals.append(v)
    return vals


def _score_arr(arr):
    a = np.array(arr, dtype=np.int64)
    d = np.unique((a[:, None] - a[None, :]).ravel())
    s = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / len(a)) / 100


def solve():
    start = time.time()
    best = [0, 1, 3]
    best_score = -1.0
    cands = []
    for k in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + k, k)
            if size < 4 or size > 3000:
                continue
            if (2 * n + 1) ** k > 5e14:
                continue
            cands.append((size, k, n))
    cands.sort()
    for size, k, n in cands:
        if time.time() - start > 90:
            break
        pts = _simplex(k, n)
        vals = _embed(pts, n)
        try:
            sc = _score_arr(vals)
        except MemoryError:
            continue
        if sc > best_score:
            best_score = sc
            best = vals
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END
