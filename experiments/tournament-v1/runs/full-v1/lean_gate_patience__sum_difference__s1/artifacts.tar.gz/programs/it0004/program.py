# EVOLVE-BLOCK-START
"""Simplex-lattice construction followed by greedy point-removal local search."""
import math
import time
import numpy as np


def _simplex(k, n):
    pts = []

    def rec(prefix, remaining, dims):
        if dims == 0:
            pts.append(tuple(prefix))
            return
        for v in range(remaining + 1):
            prefix.append(v)
            rec(prefix, remaining - v, dims - 1)
            prefix.pop()

    rec([], n, k)
    return pts


def _embed(pts, n):
    B = 2 * n + 1
    vals = []
    for p in pts:
        v = 0
        for x in reversed(p):
            v = v * B + x
        vals.append(v)
    return vals


def _score_arr(arr):
    a = np.array(arr, dtype=np.int64)
    d = np.unique((a[:, None] - a[None, :]).ravel())
    s = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / len(a)) / 100


def _stats(a, with_loss=True):
    n = len(a)
    uS, cS = np.unique((a[:, None] + a[None, :]).ravel(), return_counts=True)
    uD, cD = np.unique((a[:, None] - a[None, :]).ravel(), return_counts=True)
    S = len(uS)
    D = len(uD)
    r = math.log(D) / math.log(S)
    if not with_loss:
        return S, D, r, None, None
    lS = np.zeros(n, dtype=np.int64)
    lD = np.zeros(n, dtype=np.int64)
    ch = 256
    for i in range(0, n, ch):
        rows = a[i:i + ch]
        ms = rows[:, None] + a[None, :]
        c = cS[np.searchsorted(uS, ms)]
        lS[i:i + ch] = (c <= 2).sum(1)
        md = rows[:, None] - a[None, :]
        c = cD[np.searchsorted(uD, md)]
        lD[i:i + ch] = 2 * (c == 1).sum(1)
    return S, D, r, lS, lD


def _local_search(vals, deadline):
    a = np.array(sorted(vals), dtype=np.int64)
    if len(a) < 20:
        return a
    t0 = time.time()
    S, D, r, lS, lD = _stats(a)
    pass_time = time.time() - t0
    m = max(1, len(a) // 100)
    while time.time() + 1.3 * pass_time < deadline and m >= 1:
        rn = np.log(np.maximum(D - lD, 2)) / np.log(np.maximum(S - lS, 2))
        order = np.argsort(-rn)
        sel = order[:m]
        sel = sel[rn[sel] > r]
        if len(sel) == 0:
            m //= 2
            if m == 0:
                break
            sel = order[:m]
            sel = sel[rn[sel] > r]
            if len(sel) == 0:
                break
        keep = np.ones(len(a), dtype=bool)
        keep[sel] = False
        b = a[keep]
        t0 = time.time()
        S2, D2, r2, lS2, lD2 = _stats(b)
        pass_time = max(pass_time * 0.5, time.time() - t0)
        sc_old = r + (1 - 1 / len(a)) / 100
        sc_new = r2 + (1 - 1 / len(b)) / 100
        if sc_new > sc_old:
            a, S, D, r, lS, lD = b, S2, D2, r2, lS2, lD2
        else:
            m //= 2
    return a


def solve():
    start = time.time()
    best = [0, 1, 3]
    best_score = -1.0
    cands = []
    for k in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + k, k)
            if size < 4 or size > 4000:
                continue
            B = 2 * n + 1
            if n * B ** (k - 1) * 1.2 > 1.9e15:
                continue
            cands.append((size, k, n))
    cands.sort()
    for size, k, n in cands:
        if time.time() - start > 55:
            break
        pts = _simplex(k, n)
        vals = _embed(pts, n)
        mx = max(vals)
        mn = min(vals)
        shift = (mx + mn) // 2
        vals = [v - shift for v in vals]
        if max(abs(v) for v in vals) > 10**15:
            continue
        try:
            sc = _score_arr(vals)
        except MemoryError:
            continue
        if sc > best_score:
            best_score = sc
            best = vals
    base = sorted(set(int(v) for v in best))
    try:
        res = _local_search(base, start + 105)
        res = sorted(set(int(v) for v in res))
        if len(res) >= 3 and _score_arr(res) >= best_score:
            return res
    except Exception:
        pass
    return base
# EVOLVE-BLOCK-END
