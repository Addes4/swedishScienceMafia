# EVOLVE-BLOCK-START
"""Simplex construction A = {x in N^d : sum x <= n} embedded by integer weights,
plus simulated annealing on small sets whose Cartesian power keeps the ratio."""
import math
import time
import random
import itertools
import numpy as np


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for k in range(d + 1):
        for j in range(d - k + 1):
            diffs += math.comb(d, k) * math.comb(d - k, j) * math.comb(n, k) * math.comb(n, j)
    return size, sums, diffs


def _coords(d, n):
    res = []

    def rec(i, remaining, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for x in range(remaining + 1):
            cur.append(x)
            rec(i + 1, remaining - x, cur)
            cur.pop()

    rec(0, n, [])
    return np.array(res, dtype=np.int64)


def _eval(arr):
    m = len(arr)
    bs = 256
    su = []
    du = []
    for s in range(0, m, bs):
        e = min(m, s + bs)
        blk = arr[s:e, None] + arr[None, s:]
        su.append(np.unique(blk))
        dd = arr[s:e, None] - arr[None, :e]
        du.append(np.unique(dd[dd > 0]))
    S = np.unique(np.concatenate(su)).size
    D = 2 * np.unique(np.concatenate(du)).size + 1
    return S, D


def _score_w(X, w):
    vals = X @ np.array(w, dtype=np.int64)
    arr = np.unique(vals)
    if len(arr) != len(vals):
        return None, None
    S, D = _eval(arr)
    if S <= 1 or D <= 1:
        return None, None
    return math.log(D) / math.log(S) + (1 - 1 / len(arr)) / 100, arr


def _small_sd(elems, L):
    a = np.fromiter(elems, dtype=np.int64)
    seen = np.zeros(2 * L + 2, dtype=bool)
    seen[(a[:, None] + a[None, :]).ravel()] = True
    S = int(seen.sum())
    seen2 = np.zeros(2 * L + 2, dtype=bool)
    seen2[(a[:, None] - a[None, :]).ravel() + L] = True
    D = int(seen2.sum())
    return S, D


def _anneal(m, L, tlimit, rng):
    """Return (ratio, sorted list) of best set of size m in [0,L]."""
    elems = rng.sample(range(L + 1), m)
    S, D = _small_sd(elems, L)
    cur = math.log(D) / math.log(S)
    best = cur
    best_el = sorted(elems)
    start = time.time()
    T0, T1 = 0.02, 0.0005
    inset = set(elems)
    it = 0
    frac = 0.0
    while True:
        it += 1
        if it % 50 == 1:
            frac = (time.time() - start) / tlimit
            if frac >= 1:
                break
        T = T0 * (T1 / T0) ** frac
        i = rng.randrange(m)
        old = elems[i]
        new = rng.randint(0, L)
        if new in inset:
            continue
        elems[i] = new
        S, D = _small_sd(elems, L)
        r = math.log(D) / math.log(S)
        if r >= cur or rng.random() < math.exp((r - cur) / T):
            inset.discard(old)
            inset.add(new)
            cur = r
            if r > best:
                best = r
                best_el = sorted(elems)
        else:
            elems[i] = old
    return best, best_el


def _power_set(base_el, k):
    mn = min(base_el)
    a = [x - mn for x in base_el]
    B = 2 * max(a) + 1
    res = []
    for tup in itertools.product(a, repeat=k):
        v = 0
        for x in tup:
            v = v * B + x
        res.append(v)
    return sorted(res)


def solve():
    t0 = time.time()
    cands = []
    for d in range(1, 30):
        n = 1
        while True:
            size = math.comb(n + d, d)
            if size > 4000 or n * (2 * n + 1) ** (d - 1) > 9e14:
                break
            if size >= 2:
                sz, sums, diffs = _counts(d, n)
                s = math.log(diffs) / math.log(sums) + (1 - 1 / sz) / 100
                cands.append((s, d, n))
            n += 1
    cands.sort(reverse=True)
    best_s, d0, n0 = cands[0]
    X0 = _coords(d0, n0)
    w0 = [(2 * n0 + 1) ** i for i in range(d0)]
    best_set = sorted(int(v) for v in X0 @ np.array(w0, dtype=np.int64))
    best_info = (d0, n0, X0, w0)

    scan_deadline = t0 + 25
    for s0, d, n in cands[:3]:
        if n < 2:
            continue
        X = None
        for B in range(2 * n, n, -1):
            if time.time() > scan_deadline:
                break
            if n * B ** (d - 1) * 2 > 9e14:
                continue
            if X is None:
                X = _coords(d, n)
            w = [B ** i for i in range(d)]
            t1 = time.time()
            sc, arr = _score_w(X, w)
            if sc is not None and sc > best_s:
                best_s = sc
                best_set = [int(v) for v in arr]
                best_info = (d, n, X, w)
            if time.time() + 2 * (time.time() - t1) > scan_deadline:
                break

    # hill-climb on weights
    deadline = t0 + 45
    d, n, X, w = best_info
    w = list(w)
    rng = random.Random(12345)
    cur_s = best_s
    last = 1.0
    maxcoord = n
    while d >= 2:
        now = time.time()
        if now + 1.5 * last > deadline:
            break
        nw = list(w)
        k = 1 if rng.random() < 0.7 else 2
        for _ in range(k):
            i = rng.randrange(d)
            scale = 10 ** (-rng.uniform(0.3, 3.0))
            r = max(1, int(nw[i] * scale))
            delta = rng.randint(1, r) * rng.choice((-1, 1))
            nw[i] = nw[i] + delta
        if min(nw) < 1 or maxcoord * sum(nw) > 9e14:
            continue
        t1 = time.time()
        sc, arr = _score_w(X, nw)
        last = time.time() - t1
        if sc is not None and sc >= cur_s:
            cur_s = sc
            w = nw
            if sc > best_s:
                best_s = sc
                best_set = [int(v) for v in arr]

    # annealing on small sets + Cartesian power
    sa_end = t0 + 100
    sizes = [6, 8, 10, 12, 14, 16, 20, 25, 30, 40, 50, 60]
    rng2 = random.Random(777)
    best_small = None
    rounds = 0
    while time.time() < sa_end - 1:
        remaining = sa_end - time.time()
        per = max(1.0, min(4.0, remaining / max(1, len(sizes))))
        for m in sizes:
            if time.time() + per > sa_end:
                break
            L = int(m * rng2.choice((2, 3, 4, 6)))
            r, el = _anneal(m, L, per, rng2)
            el0 = [x - el[0] for x in el]
            mx = max(el0)
            k = 1
            while (m ** (k + 1) <= 4000 and
                   (2 * mx + 1) ** k * mx < 9e14):
                k += 1
            S, D = _small_sd(el0, mx)
            sc = math.log(D) / math.log(S) + (1 - 1 / (m ** k)) / 100
            if sc > best_s:
                best_s = sc
                best_small = (el0, k)
        rounds += 1
        if rounds >= 3:
            break
    if best_small is not None:
        el0, k = best_small
        cand = _power_set(el0, k)
        if len(set(cand)) == len(cand) and len(cand) <= 4000 and max(cand) <= 1e15:
            best_set = cand
    return best_set
# EVOLVE-BLOCK-END
