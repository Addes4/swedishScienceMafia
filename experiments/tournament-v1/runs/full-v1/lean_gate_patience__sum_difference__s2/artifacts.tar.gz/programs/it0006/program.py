# EVOLVE-BLOCK-START
"""Simplex construction with exact base scanning: A = {x in N^d : sum x <= n}
embedded with base B in [n+1, 2n+1]; smaller bases create carries that may merge
more sums than differences."""
import math
import time
import numpy as np


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for k in range(d + 1):
        for j in range(d - k + 1):
            diffs += math.comb(d, k) * math.comb(d - k, j) * math.comb(n, k) * math.comb(n, j)
    return size, sums, diffs


def _gen(d, n, B):
    res = []

    def rec(i, remaining, val):
        if i == d:
            res.append(val)
            return
        p = B ** i
        for x in range(remaining + 1):
            rec(i + 1, remaining - x, val + x * p)

    rec(0, n, 0)
    return res


def _eval(arr):
    """arr: sorted unique int64 array. Return (|A+A|, |A-A|)."""
    m = len(arr)
    bs = 256
    su = []
    du = []
    for s in range(0, m, bs):
        e = min(m, s + bs)
        blk = arr[s:e, None] + arr[None, s:]
        su.append(np.unique(blk))
        dd = arr[s:e, None] - arr[None, :e]
        du.append(np.unique(dd[dd > 0]))
    S = np.unique(np.concatenate(su)).size
    D = 2 * np.unique(np.concatenate(du)).size + 1
    return S, D


def solve():
    t0 = time.time()
    cands = []
    for d in range(1, 30):
        n = 1
        while True:
            size = math.comb(n + d, d)
            if size > 4000 or n * (2 * n + 1) ** (d - 1) > 9e14:
                break
            if size >= 2:
                sz, sums, diffs = _counts(d, n)
                s = math.log(diffs) / math.log(sums) + (1 - 1 / sz) / 100
                cands.append((s, d, n))
            n += 1
    cands.sort(reverse=True)
    best_s, d0, n0 = cands[0]
    best_set = sorted(_gen(d0, n0, 2 * n0 + 1))

    deadline = t0 + 95
    for s0, d, n in cands[:3]:
        if n < 2:
            continue
        for B in range(2 * n, n, -1):
            if time.time() > deadline:
                break
            if n * B ** (d - 1) * 2 > 9e14:
                continue
            vals = _gen(d, n, B)
            arr = np.array(sorted(set(vals)), dtype=np.int64)
            if len(arr) != len(vals):
                continue
            t1 = time.time()
            S, D = _eval(arr)
            if S > 1 and D > 1:
                sc = math.log(D) / math.log(S) + (1 - 1 / len(arr)) / 100
                if sc > best_s:
                    best_s = sc
                    best_set = [int(v) for v in arr]
            if time.time() + 2 * (time.time() - t1) > deadline:
                break
    return best_set
# EVOLVE-BLOCK-END
