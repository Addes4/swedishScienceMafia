# EVOLVE-BLOCK-START
"""Simplex construction: A = {x in N^d : sum x <= n} embedded in integers with base 2n+1."""
import math


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for k in range(d + 1):
        for j in range(d - k + 1):
            diffs += math.comb(d, k) * math.comb(d - k, j) * math.comb(n, k) * math.comb(n, j)
    return size, sums, diffs


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(i, remaining, val):
        if i == d:
            res.append(val)
            return
        p = B ** i
        for x in range(remaining + 1):
            rec(i + 1, remaining - x, val + x * p)

    rec(0, n, 0)
    return res


def solve():
    best = None
    best_s = -1
    for d in range(1, 12):
        n = 1
        while True:
            size, sums, diffs = _counts(d, n)
            if size > 4000 or (2 * n + 1) ** d > 5e14:
                break
            if size >= 2 and sums > 1:
                s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
                if s > best_s:
                    best_s, best = s, (d, n)
            n += 1
    d, n = best
    return sorted(_gen(d, n))
# EVOLVE-BLOCK-END
