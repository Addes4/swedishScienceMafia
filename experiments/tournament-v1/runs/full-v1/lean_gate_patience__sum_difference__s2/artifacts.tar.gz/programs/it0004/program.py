# EVOLVE-BLOCK-START
"""Simplex construction plus local search (add/remove points) on exact sum/diff counts."""
import math
import random
import time


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for k in range(d + 1):
        for j in range(d - k + 1):
            diffs += math.comb(d, k) * math.comb(d - k, j) * math.comb(n, k) * math.comb(n, j)
    return size, sums, diffs


def _gen(d, n, B, exact=False):
    res = []

    def rec(i, remaining, val):
        if i == d - 1 and exact:
            res.append(val + remaining * B ** i)
            return
        if i == d:
            res.append(val)
            return
        p = B ** i
        for x in range(remaining + 1):
            rec(i + 1, remaining - x, val + x * p)

    rec(0, n, 0)
    return res


def _score(A):
    S = set()
    D = set()
    for a in A:
        for b in A:
            S.add(a + b)
            D.add(a - b)
    return math.log(len(D)) / math.log(len(S)) + (1 - 1 / len(A)) / 100


def solve():
    t0 = time.time()
    best = None
    best_s = -1
    for d in range(1, 12):
        n = 1
        while True:
            size, sums, diffs = _counts(d, n)
            if size > 4000 or (2 * n + 1) ** d > 5e14:
                break
            if size >= 2 and sums > 1:
                s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
                if s > best_s:
                    best_s, best = s, (d, n)
            n += 1
    d, n = best
    base_set = sorted(_gen(d, n, 2 * n + 1))
    try:
        B = 2 * n + 5
        if B ** d * (n + 2) > 9e14 or d < 2:
            return base_set
        rnd = random.Random(1)
        A = _gen(d, n, B)
        Aset = set(A)
        shell = _gen(d, n + 1, B, exact=True)
        pool = [p for p in shell if p not in Aset]
        sc = {}
        dc = {}
        for i, a in enumerate(A):
            for b in A[i:]:
                s = a + b
                sc[s] = sc.get(s, 0) + 1
            for b in A:
                k = a - b
                dc[k] = dc.get(k, 0) + 1

        def add(x):
            for a in A:
                s = x + a
                sc[s] = sc.get(s, 0) + 1
                k = x - a
                dc[k] = dc.get(k, 0) + 1
                k = a - x
                dc[k] = dc.get(k, 0) + 1
            s = 2 * x
            sc[s] = sc.get(s, 0) + 1
            dc[0] = dc.get(0, 0) + 1
            A.append(x)

        def remove_last_or(idx):
            # remove element at index idx from A
            x = A[idx]
            A[idx] = A[-1]
            A.pop()
            for a in A:
                s = x + a
                c = sc[s] - 1
                if c:
                    sc[s] = c
                else:
                    del sc[s]
                k = x - a
                c = dc[k] - 1
                if c:
                    dc[k] = c
                else:
                    del dc[k]
                k = a - x
                c = dc[k] - 1
                if c:
                    dc[k] = c
                else:
                    del dc[k]
            s = 2 * x
            c = sc[s] - 1
            if c:
                sc[s] = c
            else:
                del sc[s]
            c = dc[0] - 1
            if c:
                dc[0] = c
            else:
                del dc[0]
            return x

        def f():
            return math.log(len(dc)) / math.log(len(sc))

        cur = f()
        TL = 75.0
        while time.time() - t0 < TL:
            if (rnd.random() < 0.5 or not pool) and len(A) > 10:
                idx = rnd.randrange(len(A))
                x = remove_last_or(idx)
                new = f()
                if new >= cur:
                    cur = new
                    pool.append(x)
                else:
                    add(x)
            elif pool and len(A) < 4000:
                j = rnd.randrange(len(pool))
                x = pool[j]
                add(x)
                new = f()
                if new >= cur:
                    cur = new
                    pool[j] = pool[-1]
                    pool.pop()
                else:
                    remove_last_or(len(A) - 1)
        cand = sorted(A)
        if len(cand) <= 4000 and _score(cand) > _score(base_set):
            return cand
        return base_set
    except Exception:
        return base_set
# EVOLVE-BLOCK-END
