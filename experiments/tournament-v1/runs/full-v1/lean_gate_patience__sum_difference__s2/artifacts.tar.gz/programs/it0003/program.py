# EVOLVE-BLOCK-START
"""Weighted simplex constructions, evaluated exactly, with the plain simplex as fallback."""
import math
import time
import random
import numpy as np


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for k in range(d + 1):
        for j in range(d - k + 1):
            diffs += math.comb(d, k) * math.comb(d - k, j) * math.comb(n, k) * math.comb(n, j)
    return size, sums, diffs


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(i, remaining, val):
        if i == d:
            res.append(val)
            return
        p = B ** i
        for x in range(remaining + 1):
            rec(i + 1, remaining - x, val + x * p)

    rec(0, n, 0)
    return res


def _wsize(ws, n):
    dp = [1] + [0] * n
    # dp[s] = number of ways with weighted sum exactly s
    for w in ws:
        new = [0] * (n + 1)
        for s in range(n + 1):
            t = 0
            k = s
            while k >= 0:
                t += dp[k]
                k -= w
            new[s] = t
        dp = new
    return sum(dp)


def _wgen(ws, n):
    bases = [2 * (n // w) + 1 for w in ws]
    mults = []
    m = 1
    for b in bases:
        mults.append(m)
        m *= b
    res = []
    d = len(ws)

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        p = mults[i]
        for x in range(rem // ws[i] + 1):
            rec(i + 1, rem - x * ws[i], val + x * p)

    rec(0, n, 0)
    return res, m


def _eval(A):
    A = np.array(sorted(A), dtype=np.int64)
    N = len(A)
    su = []
    du = []
    blk = max(1, 1500000 // N)
    for r in range(0, N, blk):
        a = A[r:r + blk, None]
        s = (a + A[None, :]).ravel()
        su.append(np.unique(s))
        dd = (A[None, :] - a).ravel()
        du.append(np.unique(dd[dd > 0]))
        if len(su) >= 8:
            su = [np.unique(np.concatenate(su))]
            du = [np.unique(np.concatenate(du))]
    S = len(np.unique(np.concatenate(su)))
    D = 2 * len(np.unique(np.concatenate(du))) + 1
    return math.log(D) / math.log(S) + (1 - 1 / N) / 100


def solve():
    t0 = time.time()
    best = None
    best_s = -1
    for d in range(1, 12):
        n = 1
        while True:
            size, sums, diffs = _counts(d, n)
            if size > 4000 or (2 * n + 1) ** d > 5e14:
                break
            if size >= 2 and sums > 1:
                s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
                if s > best_s:
                    best_s, best = s, (d, n)
            n += 1
    d, n = best
    best_set = sorted(_gen(d, n))

    # weighted candidates
    cands = []
    for k1 in range(0, 11):
        for k2 in range(0, 6):
            for k3 in range(0, 4):
                d = k1 + k2 + k3
                if d < 2 or d > 11 or k1 + k2 + k3 == 0:
                    continue
                ws = [1] * k1 + [2] * k2 + [3] * k3
                for n in range(2, 16):
                    if (k1 > 0 and False):
                        pass
                    prod = 1
                    for w in ws:
                        prod *= 2 * (n // w) + 1
                    if prod > 5e14:
                        break
                    sz = _wsize(ws, n)
                    if sz > 4000:
                        break
                    if sz >= 1800 and (k2 + k3) > 0:
                        cands.append((sz, ws, n))
    random.seed(1)
    random.shuffle(cands)
    cands.sort(key=lambda c: -(c[0] >= 3000))
    deadline = t0 + 85
    for sz, ws, n in cands:
        if time.time() > deadline:
            break
        try:
            A, mx = _wgen(ws, n)
            if mx > 4e14:
                continue
            sc = _eval(A)
        except Exception:
            continue
        if sc > best_s:
            best_s = sc
            best_set = sorted(A)
    return best_set
# EVOLVE-BLOCK-END
