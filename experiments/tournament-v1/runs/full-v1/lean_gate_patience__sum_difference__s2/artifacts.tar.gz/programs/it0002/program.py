# EVOLVE-BLOCK-START
"""Truncated simplex: {x in N^d : sum x <= n, x_i <= m}, embedded with base 2m+1."""
import math
import time
import numpy as np


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for k in range(d + 1):
        for j in range(d - k + 1):
            diffs += math.comb(d, k) * math.comb(d - k, j) * math.comb(n, k) * math.comb(n, j)
    return size, sums, diffs


def _size(d, n, m):
    poly = [1] + [0] * n
    for _ in range(d):
        new = [0] * (n + 1)
        for s in range(n + 1):
            if poly[s]:
                for x in range(0, min(m, n - s) + 1):
                    new[s + x] += poly[s]
        poly = new
    return sum(poly)


def _gen(d, n, m):
    B = 2 * m + 1
    sums = np.zeros(1, dtype=np.int64)
    vals = np.zeros(1, dtype=np.int64)
    for i in range(d):
        p = B ** i
        ns, nv = [], []
        for x in range(m + 1):
            mask = sums + x <= n
            ns.append(sums[mask] + x)
            nv.append(vals[mask] + x * p)
        sums = np.concatenate(ns)
        vals = np.concatenate(nv)
    return np.sort(vals)


def _score(arr):
    s = len(np.unique((arr[:, None] + arr[None, :]).ravel()))
    df = len(np.unique((arr[:, None] - arr[None, :]).ravel()))
    return math.log(df) / math.log(s) + (1 - 1 / len(arr)) / 100


def solve():
    t0 = time.time()
    best = None
    best_s = -1
    for d in range(1, 12):
        n = 1
        while True:
            size, sums, diffs = _counts(d, n)
            if size > 4000 or n * (2 * n + 1) ** max(d - 1, 0) > 9e14:
                break
            if size >= 2 and sums > 1:
                s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
                if s > best_s:
                    best_s, best = s, (d, n, n)
            n += 1
    cands = []
    for d in range(3, 15):
        for n in range(2, 12):
            for m in range(1, n):
                if m * (2 * m + 1) ** (d - 1) > 9e14:
                    continue
                sz = _size(d, n, m)
                if 1500 <= sz <= 4000:
                    cands.append((-sz, d, n, m))
    cands.sort()
    for _, d, n, m in cands:
        if time.time() - t0 > 85:
            break
        try:
            arr = _gen(d, n, m)
            s = _score(arr)
        except Exception:
            continue
        if s > best_s:
            best_s, best = s, (d, n, m)
    d, n, m = best
    return [int(v) for v in _gen(d, n, m)]
# EVOLVE-BLOCK-END
