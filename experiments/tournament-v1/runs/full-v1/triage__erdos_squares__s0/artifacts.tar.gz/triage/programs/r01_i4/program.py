# EVOLVE-BLOCK-START
"""Guillotine DP on grids (exact rational layouts) + LP-based local search on
separating-axis relations as continuous polishing, with exact verification."""
import math
import time
import random
import numpy as np

try:
    from scipy.optimize import linprog
    _HAVE_SCIPY = True
except Exception:  # pragma: no cover
    _HAVE_SCIPY = False


def _dp(n, N, idx):
    F = {}
    for w in range(1, N + 1):
        for h in range(1, N + 1):
            if h < w:
                F[(w, h)] = F[(h, w)]
                continue
            if w == h:
                best = np.full(n + 1, float(w))
                best[0] = 0.0
            else:
                best = np.zeros(n + 1)
            Ls, Rs = [], []
            for w1 in range(1, w // 2 + 1):
                Ls.append(F[(w1, h)]); Rs.append(F[(w - w1, h)])
            for h1 in range(1, h // 2 + 1):
                Ls.append(F[(w, h1)]); Rs.append(F[(w, h - h1)])
            if Ls:
                L = np.array(Ls)
                R = np.array(Rs)
                Rext = np.concatenate([R, np.full((R.shape[0], 1), -np.inf)], axis=1)
                P = L[:, :, None] + Rext[:, idx]
                cand = P.max(axis=1).max(axis=0)
                best = np.maximum(best, cand)
            F[(w, h)] = best
    return F


def _reconstruct(F, w, h, c, x, y, out):
    v = F[(w, h)][c]
    eps = 1e-9
    if c == 0:
        return
    if v <= eps:
        for _ in range(c):
            out.append((x, y, 0))
        return
    if w == h and abs(v - w) < eps:
        out.append((x, y, w))
        for _ in range(c - 1):
            out.append((x, y, 0))
        return
    for w1 in range(1, w // 2 + 1):
        A = F[(w1, h)]; B = F[(w - w1, h)]
        for i in range(c + 1):
            if abs(A[i] + B[c - i] - v) < eps:
                _reconstruct(F, w1, h, i, x, y, out)
                _reconstruct(F, w - w1, h, c - i, x + w1, y, out)
                return
    for h1 in range(1, h // 2 + 1):
        A = F[(w, h1)]; B = F[(w, h - h1)]
        for i in range(c + 1):
            if abs(A[i] + B[c - i] - v) < eps:
                _reconstruct(F, w, h1, i, x, y, out)
                _reconstruct(F, w, h - h1, c - i, x, y + h1, out)
                return
    # should not happen
    for _ in range(c):
        out.append((x, y, 0))


def _verify(sq):
    # sq: list of (cx, cy, angle, side), axis-aligned
    n = len(sq)
    lo = []
    for (cx, cy, a, s) in sq:
        if not (0 <= cx <= 1 and 0 <= cy <= 1 and 0 <= s <= 1):
            return False
        x0, y0, x1, y1 = cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2
        if x0 < 0 or y0 < 0 or x1 > 1 or y1 > 1:
            return False
        lo.append((x0, y0, x1, y1, s))
    for i in range(n):
        a = lo[i]
        if a[4] <= 0:
            continue
        for j in range(i + 1, n):
            b = lo[j]
            if b[4] <= 0:
                continue
            if a[2] <= b[0] or b[2] <= a[0] or a[3] <= b[1] or b[3] <= a[1]:
                continue
            return False
    return True


def _to_output(llx, lly, s, shrink):
    out = []
    for x, y, t in zip(llx, lly, s):
        cx = x + t / 2.0
        cy = y + t / 2.0
        t2 = max(0.0, t - shrink) if t > 0 else 0.0
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        out.append((float(cx), float(cy), 0.0, float(min(1.0, t2))))
    return out


class _LP:
    def __init__(self, n):
        self.n = n
        pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
        self.pi = np.array([p[0] for p in pairs], dtype=int)
        self.pj = np.array([p[1] for p in pairs], dtype=int)
        self.P = len(pairs)
        self.c = np.concatenate([np.zeros(2 * n), -np.ones(n)])
        nb = self.P + 2 * n
        self.b = np.concatenate([np.zeros(self.P), np.ones(2 * n)])
        base = np.zeros((2 * n, 3 * n))
        for i in range(n):
            base[i, i] = 1; base[i, 2 * n + i] = 1
            base[n + i, n + i] = 1; base[n + i, 2 * n + i] = 1
        self.base = base
        self.bounds = [(0, 1)] * (3 * n)

    def build(self, R):
        n = self.n
        Ap = np.zeros((self.P, 3 * n))
        swap = (R == 1) | (R == 3)
        a = np.where(swap, self.pj, self.pi)
        b = np.where(swap, self.pi, self.pj)
        off = np.where(R >= 2, n, 0)
        rows = np.arange(self.P)
        Ap[rows, off + a] = 1.0
        Ap[rows, 2 * n + a] = 1.0
        Ap[rows, off + b] = -1.0
        return Ap

    def solve(self, R):
        Ap = self.build(R)
        A = np.vstack([Ap, self.base])
        try:
            res = linprog(self.c, A_ub=A, b_ub=self.b, bounds=self.bounds, method="highs")
        except Exception:
            return None, None, None
        if res.status != 0:
            return None, None, None
        z = res.x
        slack = -(Ap @ z)
        return -res.fun, z, slack

    def relations_from(self, llx, lly, s):
        llx = np.asarray(llx); lly = np.asarray(lly); s = np.asarray(s)
        i, j = self.pi, self.pj
        g = np.stack([llx[j] - (llx[i] + s[i]), llx[i] - (llx[j] + s[j]),
                      lly[j] - (lly[i] + s[i]), lly[i] - (lly[j] + s[j])], axis=1)
        return np.argmax(g, axis=1)


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    k = math.isqrt(n)
    side = 1.0 / k
    fallback = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    fallback += [(0.5, 0.5, 0.0, 0.0)] * (n - len(fallback))
    fallback = fallback[:n]

    # ---- Stage 1: guillotine DP on N x N grids ----
    idx = np.empty((n + 1, n + 1), dtype=int)
    for i in range(n + 1):
        for c in range(n + 1):
            idx[i, c] = c - i if c >= i else n + 1
    best_val, best_N, best_F = -1.0, None, None
    dp_budget = 14.0
    N = 1
    last_dt = 0.0
    while N <= 48:
        el = time.time() - t0
        if el + last_dt * 1.6 > dp_budget:
            break
        ts = time.time()
        F = _dp(n, N, idx)
        last_dt = time.time() - ts
        v = F[(N, N)][n] / N
        if v > best_val + 1e-12:
            best_val, best_N, best_F = v, N, F
        N += 1

    dp_out = None
    if best_F is not None:
        lst = []
        _reconstruct(best_F, best_N, best_N, n, 0, 0, lst)
        if len(lst) == n:
            llx = [p[0] / best_N for p in lst]
            lly = [p[1] / best_N for p in lst]
            ss = [p[2] / best_N for p in lst]
            cand = _to_output(llx, lly, ss, 1e-12)
            if _verify(cand):
                dp_out = (best_val, llx, lly, ss, cand)

    result = dp_out[4] if dp_out is not None else fallback
    result_val = dp_out[0] if dp_out is not None else float(k)

    # ---- Stage 2: LP local search over separating-axis relations ----
    if _HAVE_SCIPY and n >= 2 and n <= 60:
        try:
            lp = _LP(n)
            if dp_out is not None:
                llx, lly, ss = dp_out[1], dp_out[2], dp_out[3]
            else:
                llx = [c[0] - c[3] / 2 for c in fallback]
                lly = [c[1] - c[3] / 2 for c in fallback]
                ss = [c[3] for c in fallback]
            R = lp.relations_from(llx, lly, ss)
            val, z, slack = lp.solve(R)
            if val is not None:
                rng = random.Random(12345 + n)
                cur_R, cur_val, cur_slack = R.copy(), val, slack
                best_R, best_lp_val, best_z = R.copy(), val, z
                lp_end = t0 + 40.0
                it = 0
                stall = 0
                while time.time() < lp_end:
                    it += 1
                    Rn = cur_R.copy()
                    m = 1
                    while rng.random() < 0.4 and m < 6:
                        m += 1
                    tight = np.nonzero(cur_slack < 1e-7)[0]
                    for _ in range(m):
                        if len(tight) > 0 and rng.random() < 0.75:
                            p = int(tight[rng.randrange(len(tight))])
                        else:
                            p = rng.randrange(lp.P)
                        r = rng.randrange(3)
                        if r >= Rn[p]:
                            r += 1
                        Rn[p] = r
                    v2, z2, s2 = lp.solve(Rn)
                    if v2 is None:
                        continue
                    if v2 >= cur_val - 1e-9:
                        if v2 > cur_val + 1e-7:
                            stall = 0
                        cur_R, cur_val, cur_slack = Rn, v2, s2
                        if v2 > best_lp_val + 1e-9:
                            best_R, best_lp_val, best_z = Rn.copy(), v2, z2
                    stall += 1
                    if stall > 400:
                        # restart from best with a larger kick
                        cur_R = best_R.copy()
                        for _ in range(rng.randint(3, 10)):
                            p = rng.randrange(lp.P)
                            cur_R[p] = rng.randrange(4)
                        v3, z3, s3 = lp.solve(cur_R)
                        if v3 is None:
                            cur_R, cur_val = best_R.copy(), best_lp_val
                            _, _, cur_slack = lp.solve(cur_R)
                        else:
                            cur_val, cur_slack = v3, s3
                        stall = 0
                if best_lp_val > result_val + 1e-5:
                    zz = best_z
                    lx = list(zz[:n]); ly = list(zz[n:2 * n]); sv = list(np.clip(zz[2 * n:], 0, 1))
                    for shrink in (1e-7, 1e-6, 1e-5):
                        cand = _to_output(lx, ly, sv, shrink)
                        if _verify(cand):
                            val_c = sum(c[3] for c in cand)
                            if val_c > result_val:
                                result, result_val = cand, val_c
                            break
        except Exception:
            pass

    if len(result) != n or not _verify(result):
        result = fallback
    return result
# EVOLVE-BLOCK-END
