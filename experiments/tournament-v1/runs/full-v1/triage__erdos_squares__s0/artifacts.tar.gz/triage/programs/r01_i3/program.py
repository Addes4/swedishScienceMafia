import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    
    def grid_config(k):
        """Generate k*k grid configuration."""
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) 
                   for i in range(k) for j in range(k)]
        return squares
    
    def get_config(count):
        """Get a configuration for exactly 'count' squares."""
        if count == 0:
            return []
        
        k = math.isqrt(count)
        
        # Try perfect grids first
        candidates = []
        
        # Perfect square grids
        for grid_k in range(1, int(math.sqrt(count)) + 2):
            grid_size = grid_k * grid_k
            if grid_size == count:
                candidates.append((count, grid_config(grid_k)))
            elif grid_size > count:
                # Use grid_k x grid_k grid, delete smallest squares
                config = grid_config(grid_k)
                config_sorted = sorted(config, key=lambda x: x[3])  # Sort by side length
                # Keep largest count squares
                kept = config_sorted[grid_size - count:]
                candidates.append((count, kept))
        
        # If no perfect match, use largest grid smaller than count, pad with zeros
        k_small = math.isqrt(count)
        if k_small * k_small < count:
            config = grid_config(k_small)
            zeros_needed = count - len(config)
            config = config + [(0.5, 0.5, 0.0, 0.0)] * zeros_needed
            candidates.append((count, config))
        
        if candidates:
            return max(candidates, key=lambda x: sum(sq[3] for sq in x[1]))[1]
        
        return [(0.5, 0.5, 0.0, 0.0)] * count
    
    # Generate candidates from different grid sizes
    best_config = None
    best_sum = -1.0
    
    # Try grids that could cover n or nearby sizes
    max_k = math.isqrt(n) + 2
    
    for grid_k in range(1, max_k + 1):
        grid_size = grid_k * grid_k
        config = grid_config(grid_k)
        
        # Option 1: Delete smallest squares to get exactly n
        if grid_size >= n:
            config_sorted = sorted(config, key=lambda x: x[3])
            kept = config_sorted[grid_size - n:]
            current_sum = sum(sq[3] for sq in kept)
            if current_sum > best_sum:
                best_sum = current_sum
                best_config = kept
        
        # Option 2: Keep all and pad with zeros if grid_size < n
        if grid_size < n:
            padded = config + [(0.5, 0.5, 0.0, 0.0)] * (n - grid_size)
            current_sum = sum(sq[3] for sq in padded)
            if current_sum > best_sum:
                best_sum = current_sum
                best_config = padded
    
    if best_config is None:
        best_config = [(0.5, 0.5, 0.0, 0.0)] * n
    
    return best_config[:n]
