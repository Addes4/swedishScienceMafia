import math
import numpy as np
from scipy.optimize import minimize


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    
    # Try baseline grid solution
    best_solution = _baseline_grid(n)
    best_score = sum(s[3] for s in best_solution)
    
    # For n close to perfect squares, try mixed rotated constructions
    k = math.isqrt(n)
    if k * k == n:
        # Already a perfect square
        return best_solution
    
    # Try n = k² - 1, k² - 2, etc. with rotated squares in gap
    for gap_size in range(1, min(4, n)):
        if k * k - gap_size == n:
            sol = _try_rotated_gap(n, k, gap_size)
            score = sum(s[3] for s in sol)
            if score > best_score:
                best_solution = sol
                best_score = score
            break
    
    return best_solution


def _baseline_grid(n):
    """Original baseline: largest k x k grid plus zero-size squares."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _try_rotated_gap(n, k, gap_size):
    """Try (k+1) x (k+1) grid with rotated squares in gap."""
    base_side = 1.0 / (k + 1)
    
    # Start with k x k grid
    squares = [((i + 0.5) * base_side, (j + 0.5) * base_side, 0.0, base_side) 
               for i in range(k) for j in range(k)]
    
    # Identify gap positions (bottom-right corner area for simplicity)
    gap_positions = []
    for i in range(k, k + 1):
        for j in range(k, k + 1):
            if len(gap_positions) < gap_size:
                gap_positions.append((i, j))
    
    # Try to fill gaps with rotated squares
    remaining = n - len(squares)
    
    if remaining > 0 and len(gap_positions) > 0:
        # Try different rotation angles and optimize
        best_rotated = []
        best_rotated_score = 0
        
        for angle_deg in [0, 22.5, 30, 45]:
            angle = angle_deg / 360.0
            
            # Simple placement: try each gap position
            rotated_squares = []
            for idx, (gi, gj) in enumerate(gap_positions[:remaining]):
                cx = (gi + 0.5) * base_side
                cy = (gj + 0.5) * base_side
                side = base_side * 0.95  # Slightly smaller to fit safely
                
                rotated_squares.append((cx, cy, angle, side))
            
            # Check if valid (non-overlapping with grid squares)
            if _all_disjoint(squares + rotated_squares):
                score = sum(s[3] for s in rotated_squares)
                if score > best_rotated_score:
                    best_rotated = rotated_squares
                    best_rotated_score = score
        
        # Add best rotated squares
        squares.extend(best_rotated)
    
    # Fill remaining with zero-size squares
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    
    return squares[:n]


def _all_disjoint(squares):
    """Check if all squares have disjoint interiors."""
    for i in range(len(squares)):
        for j in range(i + 1, len(squares)):
            if _squares_overlap(squares[i], squares[j]):
                return False
    return True


def _squares_overlap(sq1, sq2):
    """Check if two squares have overlapping interiors (not just touching)."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    
    if s1 < 1e-9 or s2 < 1e-9:
        return False  # Zero-size squares don't overlap
    
    # Convert to corners
    corners1 = _get_corners(cx1, cy1, a1, s1)
    corners2 = _get_corners(cx2, cy2, a2, s2)
    
    # Use separating axis theorem for rotated rectangles
    return _sat_overlap(corners1, corners2)


def _get_corners(cx, cy, angle, side):
    """Get corners of a square given center, rotation angle, and side length."""
    angle_rad = angle * 2 * math.pi
    cos_a = math.cos(angle_rad)
    sin_a = math.sin(angle_rad)
    half_side = side / 2
    
    corners = []
    for dx, dy in [(-1, -1), (1, -1), (1, 1), (-1, 1)]:
        x = cx + half_side * (dx * cos_a - dy * sin_a)
        y = cy + half_side * (dx * sin_a + dy * cos_a)
        corners.append((x, y))
    
    return corners


def _sat_overlap(corners1, corners2):
    """Separating Axis Theorem: check if two convex polygons overlap."""
    def get_axes(corners):
        axes = []
        for i in range(len(corners)):
            p1 = corners[i]
            p2 = corners[(i + 1) % len(corners)]
            edge = (p2[0] - p1[0], p2[1] - p1[1])
            axes.append((-edge[1], edge[0]))
        return axes
    
    def project(corners, axis):
        dots = [c[0] * axis[0] + c[1] * axis[1] for c in corners]
        return min(dots), max(dots)
    
    axes = get_axes(corners1) + get_axes(corners2)
    
    for axis in axes:
        norm = math.sqrt(axis[0]**2 + axis[1]**2)
        if norm < 1e-9:
            continue
        axis = (axis[0] / norm, axis[1] / norm)
        
        min1, max1 = project(corners1, axis)
        min2, max2 = project(corners2, axis)
        
        if max1 < min2 - 1e-9 or max2 < min1 - 1e-9:
            return False
    
    return True
