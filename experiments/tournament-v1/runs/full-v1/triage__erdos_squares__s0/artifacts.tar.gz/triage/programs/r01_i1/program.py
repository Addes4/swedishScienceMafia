import math
import time
import numpy as np


def _run(L, n):
    NEG = -1e18
    F = np.zeros((L + 1, L + 1, n + 1))
    ct = np.zeros((L + 1, L + 1, n + 1), dtype=np.int8)
    ca = np.zeros((L + 1, L + 1, n + 1), dtype=np.int16)
    ck = np.zeros((L + 1, L + 1, n + 1), dtype=np.int16)
    ks = np.arange(n + 1)
    for h in range(1, L + 1):
        for w in range(1, h + 1):
            best = np.full(n + 1, float(min(w, h)))
            best[0] = 0.0
            bt = np.zeros(n + 1, dtype=np.int8)
            ba = np.zeros(n + 1, dtype=np.int16)
            bk = np.zeros(n + 1, dtype=np.int16)
            for typ, size in ((1, w), (2, h)):
                for a in range(1, size // 2 + 1):
                    if typ == 1:
                        A = F[a, h]
                        B = F[w - a, h]
                    else:
                        A = F[w, a]
                        B = F[w, h - a]
                    cand = np.full(n + 1, NEG)
                    arg = np.zeros(n + 1, dtype=np.int16)
                    for k1 in range(n + 1):
                        t = A[k1] + B[:n + 1 - k1]
                        seg = cand[k1:]
                        m = t > seg
                        seg[m] = t[m]
                        arg[k1:][m] = k1
                    m2 = cand > best + 1e-12
                    if m2.any():
                        best[m2] = cand[m2]
                        bt[m2] = typ
                        ba[m2] = a
                        bk[m2] = arg[m2]
            for k in range(1, n + 1):
                if best[k] < best[k - 1]:
                    best[k] = best[k - 1]
                    bt[k] = 3
            F[w, h] = best
            ct[w, h] = bt
            ca[w, h] = ba
            ck[w, h] = bk
            if w != h:
                F[h, w] = best
                bt2 = bt.copy()
                bt2[bt == 1] = 2
                bt2[bt == 2] = 1
                ct[h, w] = bt2
                ca[h, w] = ba
                ck[h, w] = bk
    out = []

    def rec(x, y, w, h, k):
        while True:
            if k <= 0:
                return
            t = ct[w, h, k]
            if t == 3:
                k -= 1
                continue
            break
        if t == 0:
            s = min(w, h)
            out.append(((x + s / 2) / L, (y + s / 2) / L, 0.0, s / L))
            return
        a = int(ca[w, h, k])
        k1 = int(ck[w, h, k])
        if t == 1:
            rec(x, y, a, h, k1)
            rec(x + a, y, w - a, h, k - k1)
        else:
            rec(x, y, w, a, k1)
            rec(x, y + a, w, h - a, k - k1)

    rec(0, 0, L, L, n)
    return F[L, L, n] / L, out


def solve(n):
    t0 = time.time()
    budget = 40.0
    Ls = [2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 15, 16, 18, 20, 24, 30, 36, 40, 48, 60]
    best_val, best_sol = -1.0, None
    last_t, last_L = None, None
    for L in Ls:
        now = time.time() - t0
        if last_t is not None:
            est = last_t * (L / last_L) ** 3
            if now + est > budget:
                break
        ts = time.time()
        val, sol = _run(L, n)
        last_t = max(time.time() - ts, 1e-4)
        last_L = L
        if val > best_val + 1e-12 and len(sol) <= n:
            best_val, best_sol = val, sol
    if best_sol is None:
        k = math.isqrt(n)
        s = 1.0 / k
        best_sol = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    res = []
    for (x, y, a, s) in best_sol:
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), a, min(1.0, max(0.0, s))))
    res += [(0.5, 0.5, 0.0, 0.0)] * (n - len(res))
    return res[:n]
