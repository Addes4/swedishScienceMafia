# EVOLVE-BLOCK-START
"""Hierarchical grid constructions via guillotine DP over grid rectangles.

R[(w,h)][k] = best sum of sides (in cell units) for k squares (zeros allowed)
inside a w x h rectangle of grid cells. A w x w tile can hold a scaled copy of
the best k-square construction (F[k]), and rectangles can be cut in two.
F[k] = max_m R[(m,m)][k] / m. Iterate to a fixed point, then reconstruct.
"""
import math
from fractions import Fraction
import numpy as np


def _key(w, h):
    return (w, h) if w <= h else (h, w)


def solve(n):
    if n <= 0:
        return []
    N = n + 1
    M = max(16, int(2 * math.sqrt(n)) + 4)
    while M > 2 and (M ** 3) * (N ** 2) > 5e8:
        M -= 1

    NEG = -1e18
    J = np.empty((N, N), dtype=np.int64)
    for i in range(N):
        for k in range(N):
            J[i, k] = k - i if k >= i else N

    def conv(A, B):
        Bp = np.append(B, NEG)
        T = A[:, None] + Bp[J]
        return T.max(axis=0)

    F = np.zeros(N)
    src = [None] * N
    src[0] = 'zero'
    if n >= 1:
        F[1] = 1.0
        src[1] = 'one'
    for k in range(2, N):
        F[k] = F[k - 1]
        src[k] = 'pad'

    R = {}
    for _pass in range(30):
        changed = False
        for h in range(1, M + 1):
            for w in range(1, h + 1):
                if w == h:
                    best = w * F.copy()
                else:
                    best = np.full(N, NEG)
                    best[0] = 0.0
                for a in range(1, w // 2 + 1):
                    best = np.maximum(best, conv(R[_key(a, h)], R[_key(w - a, h)]))
                for a in range(1, h // 2 + 1):
                    best = np.maximum(best, conv(R[_key(w, a)], R[_key(w, h - a)]))
                R[(w, h)] = best
                if w == h and w > 1:
                    cand = best / w
                    for k in range(2, N):
                        if cand[k] > F[k] + 1e-12:
                            F[k] = cand[k]
                            src[k] = ('grid', w)
                            changed = True
                    for k in range(2, N):
                        if F[k - 1] > F[k] + 1e-12:
                            F[k] = F[k - 1]
                            src[k] = 'pad'
                            changed = True
        if not changed:
            break

    memoF = {}

    def build_F(k):
        # returns list of (x, y, s) lower-left corners, Fractions, in unit square
        if k in memoF:
            return memoF[k]
        s = src[k]
        if s == 'zero':
            res = []
        elif s == 'one':
            res = [(Fraction(0), Fraction(0), Fraction(1))]
        elif s == 'pad':
            res = build_F(k - 1)
        else:
            m = s[1]
            res = build(m, m, k, Fraction(0), Fraction(0), Fraction(1, m), False)
        memoF[k] = res
        return res

    def build(W, H, k, x0, y0, cell, allow_sq):
        if k == 0:
            return []
        target = R[_key(W, H)][k]
        if allow_sq and W == H and W * F[k] >= target - 1e-9:
            side = W * cell
            return [(x0 + x * side, y0 + y * side, s * side) for (x, y, s) in build_F(k)]
        bestv = NEG
        bestopt = None
        for a in range(1, W):
            A = R[_key(a, H)]
            B = R[_key(W - a, H)]
            for k1 in range(0, k + 1):
                v = A[k1] + B[k - k1]
                if v > bestv + 1e-12:
                    bestv = v
                    bestopt = ('x', a, k1)
            if bestv >= target - 1e-9:
                break
        if bestv < target - 1e-9:
            for a in range(1, H):
                A = R[_key(W, a)]
                B = R[_key(W, H - a)]
                for k1 in range(0, k + 1):
                    v = A[k1] + B[k - k1]
                    if v > bestv + 1e-12:
                        bestv = v
                        bestopt = ('y', a, k1)
                if bestv >= target - 1e-9:
                    break
        if bestopt is None or (W == H and allow_sq is False and W * F[k] > bestv + 1e-9 and False):
            return []
        if W == H and allow_sq and W * F[k] > bestv:
            side = W * cell
            return [(x0 + x * side, y0 + y * side, s * side) for (x, y, s) in build_F(k)]
        d, a, k1 = bestopt
        if d == 'x':
            return (build(a, H, k1, x0, y0, cell, True) +
                    build(W - a, H, k - k1, x0 + a * cell, y0, cell, True))
        else:
            return (build(W, a, k1, x0, y0, cell, True) +
                    build(W, H - a, k - k1, x0, y0 + a * cell, cell, True))

    sq = build_F(n)
    out = []
    for (x, y, s) in sq[:n]:
        if s <= 0:
            continue
        out.append((float(x + s / 2), float(y + s / 2), 0.0, float(s)))
    while len(out) < n:
        out.append((0.0, 0.0, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
