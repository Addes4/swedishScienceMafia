# EVOLVE-BLOCK-START
import time
import numpy as np
from scipy.optimize import minimize


def solve(n=26):
    t0 = time.time()
    TIME_BUDGET = 250.0
    rng = np.random.default_rng(12345)
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)

    def obj(z):
        return -np.sum(z[2 * n:])

    gobj = np.zeros(3 * n)
    gobj[2 * n:] = -1.0

    def objg(z):
        return gobj

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        rs = r[iu] + r[ju]
        return np.concatenate([x - r, 1 - x - r, y - r, 1 - y - r,
                               dx * dx + dy * dy - rs * rs])

    # static part of wall jacobian
    Jw = np.zeros((4 * n, 3 * n))
    ar = np.arange(n)
    Jw[ar, ar] = 1; Jw[ar, 2 * n + ar] = -1
    Jw[n + ar, ar] = -1; Jw[n + ar, 2 * n + ar] = -1
    Jw[2 * n + ar, n + ar] = 1; Jw[2 * n + ar, 2 * n + ar] = -1
    Jw[3 * n + ar, n + ar] = -1; Jw[3 * n + ar, 2 * n + ar] = -1
    pr = np.arange(m)

    def consj(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        rs = r[iu] + r[ju]
        Jp = np.zeros((m, 3 * n))
        Jp[pr, iu] = 2 * dx
        Jp[pr, ju] = -2 * dx
        Jp[pr, n + iu] = 2 * dy
        Jp[pr, n + ju] = -2 * dy
        Jp[pr, 2 * n + iu] = -2 * rs
        Jp[pr, 2 * n + ju] = -2 * rs
        return np.vstack([Jw, Jp])

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def optimize(z0, maxiter=400):
        try:
            res = minimize(obj, z0, jac=objg, method='SLSQP', bounds=bounds,
                           constraints=[{'type': 'ineq', 'fun': cons, 'jac': consj}],
                           options={'maxiter': maxiter, 'ftol': 1e-12})
            return res.x
        except Exception:
            return z0

    def repair(z):
        x = np.clip(z[:n], 0, 1)
        y = np.clip(z[n:2 * n], 0, 1)
        r = np.maximum(z[2 * n:], 0)
        r = np.minimum.reduce([r, x, 1 - x, y, 1 - y])
        for _ in range(200):
            changed = False
            for i in range(n):
                for j in range(i + 1, n):
                    d = np.hypot(x[i] - x[j], y[i] - y[j])
                    if r[i] + r[j] > d:
                        s = d / (r[i] + r[j]) if r[i] + r[j] > 0 else 0
                        r[i] *= s
                        r[j] *= s
                        changed = True
            if not changed:
                break
        r = np.maximum(r - 1e-12, 0)
        return np.concatenate([x, y, r])

    def score(z):
        zz = repair(z)
        return zz[2 * n:].sum(), zz

    def row_seed(rows, jitter=0.02):
        k = len(rows)
        pts = []
        for ri, c in enumerate(rows):
            yv = (ri + 0.5) / k
            off = (0.5 / max(c, 1)) * (0.5 if ri % 2 else 0.0)
            for ci in range(c):
                xv = (ci + 0.5) / c + rng.uniform(-1, 1) * off
                pts.append([xv, yv])
        pts = np.array(pts)
        if len(pts) > n:
            pts = pts[rng.permutation(len(pts))[:n]]
        while len(pts) < n:
            pts = np.vstack([pts, rng.uniform(0.05, 0.95, 2)])
        pts += rng.normal(0, jitter, pts.shape)
        pts = np.clip(pts, 0.03, 0.97)
        r0 = np.full(n, 0.5 / max(max(rows), k) * 0.8)
        return np.concatenate([pts[:, 0], pts[:, 1], r0])

    def random_seed():
        pts = rng.uniform(0.05, 0.95, (n, 2))
        r0 = rng.uniform(0.02, 0.08, n)
        # few large circles
        big = rng.choice(n, 8, replace=False)
        r0[big] = 0.12
        return np.concatenate([pts[:, 0], pts[:, 1], r0])

    row_patterns = [
        [5, 5, 6, 5, 5], [5, 6, 5, 6, 4], [6, 5, 4, 5, 6], [5, 5, 5, 5, 6],
        [4, 5, 4, 5, 4, 4], [5, 4, 5, 4, 5, 3], [6, 5, 5, 5, 5], [5, 6, 4, 6, 5],
        [4, 6, 6, 6, 4], [6, 4, 6, 4, 6], [5, 5, 6, 5, 5], [4, 5, 4, 4, 5, 4],
    ]

    best_val, best_z = -1.0, None
    seed_phase_end = min(110.0, TIME_BUDGET * 0.7)
    it = 0
    while time.time() - t0 < seed_phase_end:
        if it < 3 * len(row_patterns) or rng.random() < 0.6:
            z0 = row_seed(row_patterns[it % len(row_patterns)], jitter=0.01 + 0.02 * rng.random())
        else:
            z0 = random_seed()
        it += 1
        z = optimize(z0)
        z = optimize(z, 200)
        v, zr = score(z)
        if v > best_val:
            best_val, best_z = v, zr

    # Basin hopping
    cur_z, cur_val = best_z.copy(), best_val
    T = 0.002
    stall = 0
    while time.time() - t0 < TIME_BUDGET:
        z = cur_z.copy()
        mode = rng.random()
        if mode < 0.4:
            k = rng.integers(1, 5)
            idx = rng.choice(n, k, replace=False, p=None)
            # prefer small circles
            rr = z[2 * n:]
            w = 1.0 / (rr + 0.02)
            idx = rng.choice(n, k, replace=False, p=w / w.sum())
            z[idx] = rng.uniform(0.05, 0.95, k)
            z[n + idx] = rng.uniform(0.05, 0.95, k)
            z[2 * n + idx] = 0.01
        elif mode < 0.8:
            s = 0.005 + 0.03 * rng.random()
            z[:2 * n] += rng.normal(0, s, 2 * n)
            z[2 * n:] *= 0.95
        else:
            # swap a large and small circle
            i, j = rng.choice(n, 2, replace=False)
            z[[i, j]] = z[[j, i]]
            z[[n + i, n + j]] = z[[n + j, n + i]]
            z[2 * n:] *= 0.97
        z[:2 * n] = np.clip(z[:2 * n], 0.01, 0.99)
        z = optimize(z)
        v, zr = score(z)
        if v > best_val + 1e-9:
            best_val, best_z = v, zr.copy()
            stall = 0
        else:
            stall += 1
        if v > cur_val or rng.random() < np.exp((v - cur_val) / T):
            cur_z, cur_val = zr, v
        if stall > 40:
            cur_z, cur_val = best_z.copy(), best_val
            stall = 0

    z = repair(best_z)
    centers = np.stack([z[:n], z[n:2 * n]], axis=1)
    radii = z[2 * n:]
    return centers, radii
# EVOLVE-BLOCK-END
