import time
import numpy as np
from scipy.optimize import linprog, minimize

# EVOLVE-BLOCK-START


def _pairs(n):
    I, J = np.triu_indices(n, 1)
    return I, J


def lp_radii(centers, I, J):
    """Optimal radii for fixed centres via LP."""
    n = len(centers)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0.0)
    m = len(I)
    A = np.zeros((m, n))
    A[np.arange(m), I] = 1
    A[np.arange(m), J] = 1
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=np.column_stack([np.zeros(n), wall]),
                      method="highs")
        if res.status == 0:
            return np.maximum(res.x, 0.0)
    except Exception:
        pass
    return np.zeros(n)


def slsqp_polish(centers, r0, I, J, maxiter=300):
    n = len(centers)
    m = len(I)
    z0 = np.concatenate([centers[:, 0], centers[:, 1], r0])

    def f(z):
        return -np.sum(z[2 * n:])

    def g(z):
        gr = np.zeros(3 * n)
        gr[2 * n:] = -1
        return gr

    ar = np.arange(m)
    an = np.arange(n)

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        pc = (x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 - (r[I] + r[J]) ** 2
        return np.concatenate([pc, x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        Jm = np.zeros((m + 4 * n, 3 * n))
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        s = r[I] + r[J]
        Jm[ar, I] = 2 * dx
        Jm[ar, J] = -2 * dx
        Jm[ar, n + I] = 2 * dy
        Jm[ar, n + J] = -2 * dy
        Jm[ar, 2 * n + I] = -2 * s
        Jm[ar, 2 * n + J] = -2 * s
        o = m
        Jm[o + an, an] = 1; Jm[o + an, 2 * n + an] = -1
        o += n
        Jm[o + an, an] = -1; Jm[o + an, 2 * n + an] = -1
        o += n
        Jm[o + an, n + an] = 1; Jm[o + an, 2 * n + an] = -1
        o += n
        Jm[o + an, n + an] = -1; Jm[o + an, 2 * n + an] = -1
        return Jm

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(f, z0, jac=g, bounds=bounds,
                       constraints=[{"type": "ineq", "fun": cons, "jac": jac}],
                       method="SLSQP", options={"maxiter": maxiter, "ftol": 1e-10})
        z = res.x
    except Exception:
        return centers
    return np.clip(np.column_stack([z[:n], z[n:2 * n]]), 0.0, 1.0)


def make_start(n, rng):
    kind = rng.integers(0, 3)
    if kind == 0:
        return rng.uniform(0.05, 0.95, (n, 2))
    if kind == 1:
        # jittered grid
        k = int(np.ceil(np.sqrt(n)))
        g = (np.arange(k) + 0.5) / k
        pts = np.array([[a, b] for a in g for b in g])
        idx = rng.permutation(len(pts))[:n]
        return np.clip(pts[idx] + rng.normal(0, 0.03, (n, 2)), 0.03, 0.97)
    # rings
    pts = [[0.5, 0.5]]
    for cnt, rad in [(8, 0.25), (16, 0.42)]:
        ph = rng.uniform(0, 2 * np.pi)
        for i in range(cnt):
            a = ph + 2 * np.pi * i / cnt
            pts.append([0.5 + rad * np.cos(a), 0.5 + rad * np.sin(a)])
    pts = np.array(pts[:n])
    if len(pts) < n:
        pts = np.vstack([pts, rng.uniform(0.1, 0.9, (n - len(pts), 2))])
    return np.clip(pts + rng.normal(0, 0.03, pts.shape), 0.03, 0.97)


def solve(n=26):
    t0 = time.time()
    budget = 230.0
    rng = np.random.default_rng(12345)
    I, J = _pairs(n)

    best_s, best_c, best_r = -1.0, None, None
    while time.time() - t0 < budget:
        c = make_start(n, rng)
        r = lp_radii(c, I, J)
        # short LP hill-climb on centres
        s = r.sum()
        sigma = 0.05
        for _ in range(25):
            c2 = c.copy()
            k = rng.integers(1, 4)
            idx = rng.choice(n, k, replace=False)
            c2[idx] += rng.normal(0, sigma, (k, 2))
            c2 = np.clip(c2, 0.0, 1.0)
            r2 = lp_radii(c2, I, J)
            if r2.sum() > s:
                c, r, s = c2, r2, r2.sum()
            else:
                sigma = max(0.005, sigma * 0.95)
        # joint polish
        c = slsqp_polish(c, r, I, J)
        r = lp_radii(c, I, J)
        s = r.sum()
        if s > best_s:
            best_s, best_c, best_r = s, c.copy(), r.copy()

    # final refinement: polish best again, then LP
    if time.time() - t0 < 285:
        c = slsqp_polish(best_c, best_r, I, J, maxiter=500)
        r = lp_radii(c, I, J)
        if r.sum() > best_s:
            best_s, best_c, best_r = r.sum(), c, r

    centers = best_c
    radii = np.maximum(best_r - 2e-9, 0.0)
    # safety: enforce feasibility
    for _ in range(5):
        d = np.linalg.norm(centers[I] - centers[J], axis=1)
        viol = radii[I] + radii[J] - d
        bad = viol > 0
        if not bad.any():
            break
        for i, j, v in zip(I[bad], J[bad], viol[bad]):
            radii[i] = max(0.0, radii[i] - v / 2 - 1e-12)
            radii[j] = max(0.0, radii[j] - v / 2 - 1e-12)
    return centers, radii
# EVOLVE-BLOCK-END
