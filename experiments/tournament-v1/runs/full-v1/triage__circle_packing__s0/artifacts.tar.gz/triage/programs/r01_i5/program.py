import numpy as np
from scipy.optimize import minimize
import itertools


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    
    best_score = -np.inf
    best_result = None
    
    # Generate row-size compositions summing to n
    compositions = generate_compositions(n, min_rows=3, max_rows=8)
    
    # Limit to top promising compositions
    compositions = compositions[:50]
    
    for row_sizes in compositions:
        result = optimize_layout(n, row_sizes)
        centers, radii = result
        score = np.sum(radii)
        
        if score > best_score:
            best_score = score
            best_result = (centers, radii)
    
    if best_result is None:
        # Fallback
        centers = np.random.rand(n, 2)
        radii = np.ones(n) * 0.01
        best_result = (centers, radii)
    
    return best_result


def generate_compositions(n, min_rows=3, max_rows=8):
    """Generate row-size compositions summing to n, sorted by balance."""
    compositions = []
    
    for num_rows in range(min_rows, min(max_rows + 1, n + 1)):
        # Generate all compositions of n into num_rows parts
        for comp in _compositions_helper(n, num_rows):
            balance = np.std(comp)
            compositions.append((balance, comp))
    
    # Sort by balance (prefer balanced layouts)
    compositions.sort(key=lambda x: x[0])
    return [comp for _, comp in compositions]


def _compositions_helper(n, k):
    """Generate all compositions of n into k positive parts."""
    if k == 1:
        yield [n]
    else:
        for i in range(1, n - k + 2):
            for comp in _compositions_helper(n - i, k - 1):
                yield [i] + comp


def optimize_layout(n, row_sizes):
    """Build initial staggered layout and optimize with SLSQP."""
    
    # Create initial centers and radii
    centers_init, radii_init = create_staggered_layout(n, row_sizes)
    
    # Pack into flat array
    x0 = np.concatenate([centers_init.flatten(), radii_init])
    
    # Optimize
    def objective(x):
        radii = x[2*n:]
        return -np.sum(radii)
    
    def constraint_bounds(x):
        """All circles within bounds and non-negative radii."""
        centers = x[:2*n].reshape(n, 2)
        radii = x[2*n:]
        
        constraints = []
        # Bounds constraints
        for i in range(n):
            constraints.append(centers[i, 0] - radii[i])  # x >= r
            constraints.append(1 - centers[i, 0] - radii[i])  # x + r <= 1
            constraints.append(centers[i, 1] - radii[i])  # y >= r
            constraints.append(1 - centers[i, 1] - radii[i])  # y + r <= 1
        
        # Non-overlap constraints
        for i in range(n):
            for j in range(i + 1, n):
                dx = centers[i, 0] - centers[j, 0]
                dy = centers[i, 1] - centers[j, 1]
                dist = np.sqrt(dx**2 + dy**2)
                constraints.append(dist - radii[i] - radii[j] - 1e-6)
        
        return np.array(constraints)
    
    constraints = {'type': 'ineq', 'fun': constraint_bounds}
    
    result = minimize(
        objective,
        x0,
        method='SLSQP',
        constraints=constraints,
        options={'ftol': 1e-6, 'maxiter': 200}
    )
    
    x_opt = result.x
    centers = np.clip(x_opt[:2*n].reshape(n, 2), 0, 1)
    radii = np.maximum(x_opt[2*n:], 0)
    
    # Final constraint satisfaction pass
    radii = enforce_constraints(centers, radii)
    
    return centers, radii


def create_staggered_layout(n, row_sizes):
    """Create staggered row layout with initial radii."""
    centers = []
    radii = []
    
    num_rows = len(row_sizes)
    row_height = 1.0 / (num_rows + 1)
    
    for row_idx, row_size in enumerate(row_sizes):
        y = (row_idx + 1) * row_height
        
        # Horizontal spacing
        if row_size == 1:
            xs = [0.5]
        else:
            xs = np.linspace(0.1, 0.9, row_size)
        
        # Stagger every other row
        if row_idx % 2 == 1:
            xs = xs + 0.05
            xs = np.clip(xs, 0.05, 0.95)
        
        for x in xs:
            centers.append([x, y])
            # Initial radius based on row and spacing
            r = row_height * 0.35 / (1.0 + 0.1 * row_idx)
            radii.append(r)
    
    # Add remaining circles as small interstitial circles
    while len(centers) < n:
        centers.append([np.random.rand(), np.random.rand()])
        radii.append(0.02)
    
    return np.array(centers[:n]), np.array(radii[:n])


def enforce_constraints(centers, radii):
    """Iteratively enforce non-overlap and boundary constraints."""
    n = len(radii)
    
    for iteration in range(100):
        changed = False
        
        # Boundary constraints
        for i in range(n):
            max_r = min(centers[i, 0], centers[i, 1], 1 - centers[i, 0], 1 - centers[i, 1])
            if radii[i] > max_r:
                radii[i] = max(0, max_r)
                changed = True
        
        # Non-overlap constraints
        for i in range(n):
            for j in range(i + 1, n):
                dist = np.linalg.norm(centers[i] - centers[j])
                min_dist = radii[i] + radii[j]
                if min_dist > dist:
                    scale = dist / (min_dist + 1e-10)
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        
        if not changed:
            break
    
    return np.maximum(radii, 0.0)
