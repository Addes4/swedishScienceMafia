# EVOLVE-BLOCK-START
"""Penalty method (L-BFGS-B, increasing mu) with many random restarts,
SLSQP polishing, and a final LP radius step for exact feasibility."""
import time
import numpy as np
from scipy.optimize import minimize, linprog


def _pair_idx(n):
    return np.triu_indices(n, 1)


def _penalty_obj(z, n, mu, I, J):
    x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
    dx = x[I] - x[J]; dy = y[I] - y[J]
    d = np.sqrt(dx * dx + dy * dy + 1e-14)
    ov = np.maximum(0.0, r[I] + r[J] - d)
    b1 = np.maximum(0.0, r - x); b2 = np.maximum(0.0, x + r - 1.0)
    b3 = np.maximum(0.0, r - y); b4 = np.maximum(0.0, y + r - 1.0)
    f = -r.sum() + mu * (np.dot(ov, ov) + np.dot(b1, b1) + np.dot(b2, b2)
                         + np.dot(b3, b3) + np.dot(b4, b4))
    gx = np.zeros(n); gy = np.zeros(n); gr = -np.ones(n)
    c = 2 * mu * ov
    ux = c * dx / d; uy = c * dy / d
    np.add.at(gx, I, -ux); np.add.at(gx, J, ux)
    np.add.at(gy, I, -uy); np.add.at(gy, J, uy)
    np.add.at(gr, I, c); np.add.at(gr, J, c)
    gr += 2 * mu * (b1 + b2 + b3 + b4)
    gx += 2 * mu * (-b1 + b2)
    gy += 2 * mu * (-b3 + b4)
    return f, np.concatenate([gx, gy, gr])


def _penalty_run(z0, n, I, J, mus=(10, 100, 1e3, 1e4, 1e5, 1e6)):
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    z = z0.copy()
    for mu in mus:
        res = minimize(_penalty_obj, z, args=(n, mu, I, J), jac=True,
                       method="L-BFGS-B", bounds=bounds,
                       options={"maxiter": 3000, "ftol": 1e-12, "gtol": 1e-9})
        z = res.x
    return z


def _slsqp_polish(z0, n, I, J):
    m = len(I)
    rows = np.arange(m)

    def cons(z):
        x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
        dx = x[I] - x[J]; dy = y[I] - y[J]
        d = np.sqrt(dx * dx + dy * dy + 1e-14)
        return np.concatenate([d - r[I] - r[J], x - r, 1 - x - r, y - r, 1 - y - r])

    def cjac(z):
        x = z[:n]; y = z[n:2 * n]
        dx = x[I] - x[J]; dy = y[I] - y[J]
        d = np.sqrt(dx * dx + dy * dy + 1e-14)
        Jm = np.zeros((m + 4 * n, 3 * n))
        Jm[rows, I] = dx / d; Jm[rows, J] = -dx / d
        Jm[rows, n + I] = dy / d; Jm[rows, n + J] = -dy / d
        Jm[rows, 2 * n + I] = -1; Jm[rows, 2 * n + J] = -1
        k = np.arange(n)
        Jm[m + k, k] = 1; Jm[m + k, 2 * n + k] = -1
        Jm[m + n + k, k] = -1; Jm[m + n + k, 2 * n + k] = -1
        Jm[m + 2 * n + k, n + k] = 1; Jm[m + 2 * n + k, 2 * n + k] = -1
        Jm[m + 3 * n + k, n + k] = -1; Jm[m + 3 * n + k, 2 * n + k] = -1
        return Jm

    obj = lambda z: -z[2 * n:].sum()
    g = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(obj, z0, jac=lambda z: g, method="SLSQP", bounds=bounds,
                       constraints=[{"type": "ineq", "fun": cons, "jac": cjac}],
                       options={"maxiter": 500, "ftol": 1e-14})
        return res.x
    except Exception:
        return z0


def _lp_radii(centers):
    n = len(centers)
    I, J = _pair_idx(n)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    A = np.zeros((len(I), n))
    A[np.arange(len(I)), I] = 1; A[np.arange(len(I)), J] = 1
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1],
                              1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d,
                      bounds=list(zip(np.zeros(n), wall)), method="highs")
        r = res.x if res.success else None
    except Exception:
        r = None
    if r is None:
        r = _shrink_radii(centers)
    r = np.maximum(r - 1e-11, 0)
    return _make_feasible(centers, r)


def _shrink_radii(centers):
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1],
                               1 - centers[:, 0], 1 - centers[:, 1]])
    radii = np.maximum(radii, 0)
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                dd = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > dd:
                    s = dd / (radii[i] + radii[j])
                    radii[i] *= s; radii[j] *= s
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _make_feasible(centers, r):
    n = len(centers)
    r = r.copy()
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1],
                              1 - centers[:, 0], 1 - centers[:, 1]])
    r = np.minimum(r, np.maximum(wall, 0))
    for _ in range(100):
        bad = False
        for i in range(n):
            for j in range(i + 1, n):
                dd = np.linalg.norm(centers[i] - centers[j])
                if r[i] + r[j] > dd:
                    s = dd / (r[i] + r[j]) * (1 - 1e-12)
                    r[i] *= s; r[j] *= s
                    bad = True
        if not bad:
            break
    return np.maximum(r, 0)


def _score(z, n):
    c = np.stack([np.clip(z[:n], 0, 1), np.clip(z[n:2 * n], 0, 1)], axis=1)
    return c


def _random_init(rng, n):
    mode = rng.integers(3)
    if mode == 0:
        x = rng.uniform(0.05, 0.95, n); y = rng.uniform(0.05, 0.95, n)
        r = rng.uniform(0.02, 0.12, n)
    elif mode == 1:
        x = rng.uniform(0.0, 1.0, n); y = rng.uniform(0.0, 1.0, n)
        r = np.full(n, 0.05) + rng.uniform(0, 0.05, n)
        k = rng.integers(1, 5)
        r[rng.choice(n, k, replace=False)] = rng.uniform(0.12, 0.2, k)
    else:
        # jittered grid
        g = int(np.ceil(np.sqrt(n)))
        pts = [((i + 0.5) / g, (j + 0.5) / g) for i in range(g) for j in range(g)]
        pts = np.array(pts)[rng.permutation(g * g)[:n]]
        x = np.clip(pts[:, 0] + rng.normal(0, 0.04, n), 0.02, 0.98)
        y = np.clip(pts[:, 1] + rng.normal(0, 0.04, n), 0.02, 0.98)
        r = rng.uniform(0.03, 0.1, n)
    return np.concatenate([x, y, r])


def solve(n=26):
    t0 = time.time()
    rng = np.random.default_rng(12345)
    I, J = _pair_idx(n)

    def evaluate(z):
        c = _score(z, n)
        r = _lp_radii(c)
        return r.sum(), c, r

    cands = []
    restart_budget = 110.0
    while time.time() - t0 < restart_budget:
        z = _penalty_run(_random_init(rng, n), n, I, J)
        s = z[2 * n:].sum()
        cands.append((s, z))
    cands.sort(key=lambda t: -t[0])

    best_s, best_c, best_r = -1, None, None
    best_z = None
    for s, z in cands[:15]:
        if time.time() - t0 > 170:
            break
        zp = _slsqp_polish(z, n, I, J)
        val, c, r = evaluate(zp)
        if val > best_s:
            best_s, best_c, best_r, best_z = val, c, r, np.concatenate([c[:, 0], c[:, 1], r])

    # basin hopping around the best
    while time.time() - t0 < 235 and best_z is not None:
        z = best_z.copy()
        sigma = rng.choice([0.01, 0.03, 0.07])
        z[:2 * n] = np.clip(z[:2 * n] + rng.normal(0, sigma, 2 * n), 0, 1)
        if rng.random() < 0.5:
            # swap/relocate a small circle
            k = np.argmin(z[2 * n:])
            z[k] = rng.uniform(0.05, 0.95); z[n + k] = rng.uniform(0.05, 0.95)
        z[2 * n:] *= 0.9
        z = _penalty_run(z, n, I, J, mus=(1e3, 1e4, 1e5, 1e6))
        z = _slsqp_polish(z, n, I, J)
        val, c, r = evaluate(z)
        if val > best_s:
            best_s, best_c, best_r, best_z = val, c, r, np.concatenate([c[:, 0], c[:, 1], r])

    if best_c is None:
        c = rng.uniform(0.1, 0.9, (n, 2))
        return c, _shrink_radii(c)
    return best_c, best_r
# EVOLVE-BLOCK-END
