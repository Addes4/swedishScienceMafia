import numpy as np
from scipy.optimize import minimize


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    
    # Phase 1: Billiards/growth simulation with soft repulsion
    centers, radii = billiards_growth(n, iterations=5000, dt=0.01)
    
    # Phase 2: Individual growth until jammed
    centers, radii = individual_growth(centers, radii, iterations=1000)
    
    # Phase 3: SLSQP polishing
    centers, radii = slsqp_polish(centers, radii, max_iterations=500)
    
    return centers, radii


def billiards_growth(n, iterations=5000, dt=0.01):
    """Growth simulation with soft repulsion and wall reflection."""
    np.random.seed(42)
    centers = np.random.rand(n, 2)
    radii = np.ones(n) * 0.01
    
    growth_rate = 0.0005
    
    for iteration in range(iterations):
        # Grow all radii
        radii += growth_rate
        
        # Soft repulsion between overlapping circles
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                min_dist = radii[i] + radii[j]
                
                if d < min_dist:
                    # Push apart with soft repulsion
                    direction = (centers[i] - centers[j]) / (d + 1e-8)
                    overlap = min_dist - d
                    repulsion = overlap * 0.5
                    centers[i] += direction * repulsion * dt
                    centers[j] -= direction * repulsion * dt
        
        # Wall reflection and boundary enforcement
        for i in range(n):
            # Reflect off walls
            if centers[i, 0] - radii[i] < 0:
                centers[i, 0] = radii[i]
            elif centers[i, 0] + radii[i] > 1:
                centers[i, 0] = 1 - radii[i]
            
            if centers[i, 1] - radii[i] < 0:
                centers[i, 1] = radii[i]
            elif centers[i, 1] + radii[i] > 1:
                centers[i, 1] = 1 - radii[i]
        
        # Ensure centers stay in bounds
        centers = np.clip(centers, 0.0, 1.0)
        
        # Reduce growth rate if many overlaps
        overlap_count = 0
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if d < radii[i] + radii[j]:
                    overlap_count += 1
        
        if overlap_count > n * 0.5:
            growth_rate *= 0.9995
    
    # Final constraint satisfaction
    radii = constraint_satisfaction(centers, radii)
    return centers, radii


def individual_growth(centers, radii, iterations=1000):
    """Allow individual circles to grow until jammed."""
    n = len(centers)
    
    for _ in range(iterations):
        for i in range(n):
            # Try to grow this circle
            old_radius = radii[i]
            radii[i] *= 1.001
            
            # Check if valid
            valid = True
            
            # Check wall constraint
            if centers[i, 0] - radii[i] < 0 or centers[i, 0] + radii[i] > 1:
                valid = False
            if centers[i, 1] - radii[i] < 0 or centers[i, 1] + radii[i] > 1:
                valid = False
            
            # Check overlap constraint
            for j in range(n):
                if i != j:
                    d = np.linalg.norm(centers[i] - centers[j])
                    if radii[i] + radii[j] > d + 1e-9:
                        valid = False
                        break
            
            if not valid:
                radii[i] = old_radius
    
    return centers, radii


def constraint_satisfaction(centers, radii):
    """Ensure no overlaps and stay within bounds."""
    n = len(centers)
    radii = np.clip(radii, 0, 1.0)
    
    # Respect walls
    for i in range(n):
        radii[i] = min(radii[i], centers[i, 0], centers[i, 1], 
                       1 - centers[i, 0], 1 - centers[i, 1])
    
    # Resolve overlaps
    for _ in range(100):
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d + 1e-9:
                    scale = d / (radii[i] + radii[j] + 1e-9)
                    radii[i] *= scale
                    radii[j] *= scale
    
    return np.maximum(radii, 0.0)


def slsqp_polish(centers, radii, max_iterations=500):
    """Final polishing with SLSQP optimization."""
    n = len(centers)
    
    # Pack variables: [x0, y0, r0, x1, y1, r1, ...]
    x0 = np.concatenate([centers.flatten(), radii])
    
    def objective(x):
        # Negative sum of radii (minimize negative = maximize)
        r = x[2*n:]
        return -np.sum(r)
    
    def constraint_overlaps(x):
        """Constraint: all pairs of circles must not overlap."""
        c = x[2*n:]
        centers_x = x[:2*n].reshape(n, 2)
        constraints = []
        
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers_x[i] - centers_x[j])
                # d >= r_i + r_j => d - r_i - r_j >= 0
                constraints.append(d - c[i] - c[j])
        
        return np.array(constraints)
    
    def constraint_walls(x):
        """Constraint: circles must fit in unit square."""
        centers_x = x[:2*n].reshape(n, 2)
        c = x[2*n:]
        constraints = []
        
        for i in range(n):
            constraints.append(centers_x[i, 0] - c[i])  # x - r >= 0
            constraints.append(centers_x[i, 1] - c[i])  # y - r >= 0
            constraints.append(1 - centers_x[i, 0] - c[i])  # 1 - x - r >= 0
            constraints.append(1 - centers_x[i, 1] - c[i])  # 1 - y - r >= 0
        
        return np.array(constraints)
    
    from scipy.optimize import NonlinearConstraint
    
    overlap_constraint = NonlinearConstraint(constraint_overlaps, 0, np.inf)
    wall_constraint = NonlinearConstraint(constraint_walls, 0, np.inf)
    
    bounds = [(0.01, 0.99)] * (2 * n) + [(0, 1)] * n
    
    result = minimize(
        objective,
        x0,
        method='SLSQP',
        bounds=bounds,
        constraints=[overlap_constraint, wall_constraint],
        options={'ftol': 1e-6, 'maxiter': max_iterations}
    )
    
    x_opt = result.x
    centers_opt = x_opt[:2*n].reshape(n, 2)
    radii_opt = x_opt[2*n:]
    
    return centers_opt, np.maximum(radii_opt, 0.0)
