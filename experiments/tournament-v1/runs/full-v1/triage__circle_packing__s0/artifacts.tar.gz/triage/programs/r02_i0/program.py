import time
import numpy as np
from scipy.optimize import minimize, linprog

# EVOLVE-BLOCK-START


def _lp_radii(centers):
    """Optimal radii for fixed centres (LP); always feasible."""
    n = len(centers)
    c = np.clip(centers, 0.0, 1.0)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(c[I] - c[J], axis=1)
    A = np.zeros((len(I), n))
    A[np.arange(len(I)), I] = 1.0
    A[np.arange(len(I)), J] = 1.0
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    wall = np.maximum(wall, 0.0)
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d,
                      bounds=[(0, w) for w in wall], method="highs")
        if res.status == 0:
            r = np.maximum(res.x, 0.0)
        else:
            raise RuntimeError
    except Exception:
        r = wall.copy()
    return c, r


def _repair(c, r):
    """Make (c, r) exactly feasible by shrinking radii."""
    n = len(c)
    r = np.array(r, dtype=float)
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    r = np.minimum(r, np.maximum(wall, 0.0))
    r = np.maximum(r * (1 - 1e-12) - 1e-13, 0.0)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(c[I] - c[J], axis=1)
    for _ in range(200):
        s = r[I] + r[J]
        bad = np.where(s > d)[0]
        if len(bad) == 0:
            break
        for k in bad:
            i, j = I[k], J[k]
            tot = r[i] + r[j]
            if tot > d[k] and tot > 0:
                f = d[k] / tot * (1 - 1e-12)
                r[i] *= f
                r[j] *= f
    return np.maximum(r, 0.0)


def _score_safe(centers):
    c, r = _lp_radii(centers)
    r = _repair(c, r)
    return c, r, r.sum()


def _make_init(rng, n, kind):
    if kind == 0:
        g = (np.arange(5) + 0.5) / 5
        pts = [[x, y] for x in g for y in g]
        pts.append(rng.random(2))
        pts = np.array(pts[:n]) + rng.normal(0, 0.02, (min(len(pts), n), 2))
        while len(pts) < n:
            pts = np.vstack([pts, rng.random(2)])
    elif kind == 1:
        patterns = [[5, 5, 6, 5, 5], [5, 6, 5, 6, 4], [4, 5, 4, 5, 4, 4],
                    [6, 5, 5, 5, 5], [5, 5, 5, 5, 6], [4, 5, 5, 5, 4, 3]]
        pat = patterns[rng.integers(len(patterns))]
        pts = []
        k = len(pat)
        for ri, m in enumerate(pat):
            y = (ri + 0.5) / k
            off = 0.0 if ri % 2 == 0 else 0.5 / m
            for ci in range(m):
                pts.append([(ci + 0.5) / m * (1 - off) + off * 0.5 * (1 if ri % 2 else 0), y])
        pts = np.array(pts[:n])
        while len(pts) < n:
            pts = np.vstack([pts, rng.random(2)])
        pts = pts + rng.normal(0, 0.02, pts.shape)
    elif kind == 2:
        n1 = int(rng.integers(5, 9))
        n2 = n - 1 - n1
        pts = [[0.5, 0.5]]
        pts += [[0.5 + 0.25 * np.cos(2 * np.pi * i / n1), 0.5 + 0.25 * np.sin(2 * np.pi * i / n1)] for i in range(n1)]
        pts += [[0.5 + 0.42 * np.cos(2 * np.pi * i / n2 + 0.3), 0.5 + 0.42 * np.sin(2 * np.pi * i / n2 + 0.3)] for i in range(n2)]
        pts = np.array(pts) + rng.normal(0, 0.02, (n, 2))
    else:
        pts = rng.random((n, 2))
    return np.clip(pts, 0.03, 0.97)


def _optimize(pts, n, I, J, Alin, rows, r0=None, maxiter=250, ftol=1e-10):
    m = len(I)

    def obj(x):
        return -x[2 * n:].sum()

    gobj = np.zeros(3 * n)
    gobj[2 * n:] = -1.0

    def jobj(x):
        return gobj

    def pair(x):
        dx = x[I] - x[J]
        dy = x[n + I] - x[n + J]
        s = x[2 * n + I] + x[2 * n + J]
        return dx * dx + dy * dy - s * s

    def pair_jac(x):
        dx = x[I] - x[J]
        dy = x[n + I] - x[n + J]
        s = x[2 * n + I] + x[2 * n + J]
        Jm = np.zeros((m, 3 * n))
        Jm[rows, I] = 2 * dx
        Jm[rows, J] = -2 * dx
        Jm[rows, n + I] = 2 * dy
        Jm[rows, n + J] = -2 * dy
        Jm[rows, 2 * n + I] = -2 * s
        Jm[rows, 2 * n + J] = -2 * s
        return Jm

    def lin(x):
        return Alin[0] @ x + Alin[1]

    def lin_jac(x):
        return Alin[0]

    if r0 is None:
        r0 = np.full(n, 0.05)
    x0 = np.concatenate([pts[:, 0], pts[:, 1], r0])
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(obj, x0, jac=jobj, method="SLSQP", bounds=bounds,
                       constraints=[{"type": "ineq", "fun": pair, "jac": pair_jac},
                                    {"type": "ineq", "fun": lin, "jac": lin_jac}],
                       options={"maxiter": maxiter, "ftol": ftol})
        x = res.x
        if not np.all(np.isfinite(x)):
            return pts
    except Exception:
        return pts
    return np.stack([x[:n], x[n:2 * n]], axis=1)


def _newton_kkt(c, r, tol, iters=40):
    """Newton on the KKT system with active constraints as equalities."""
    n = len(c)
    N = 3 * n
    x = np.concatenate([c[:, 0], c[:, 1], r]).astype(float)
    pairs = []
    for i in range(n):
        for j in range(i + 1, n):
            d = np.hypot(c[i, 0] - c[j, 0], c[i, 1] - c[j, 1])
            if d - r[i] - r[j] < tol:
                pairs.append((i, j))
    walls = []
    for i in range(n):
        for a in range(2):
            if c[i, a] - r[i] < tol:
                walls.append((i, a, 0))
            if 1 - c[i, a] - r[i] < tol:
                walls.append((i, a, 1))
    m = len(pairs) + len(walls)
    if m == 0:
        return None
    gf = np.zeros(N)
    gf[2 * n:] = 1.0

    def evalg(x):
        g = np.zeros(m)
        Jm = np.zeros((m, N))
        H = []
        k = 0
        for (i, j) in pairs:
            dx = x[i] - x[j]
            dy = x[n + i] - x[n + j]
            d = np.hypot(dx, dy)
            if d < 1e-14:
                d = 1e-14
            g[k] = d - x[2 * n + i] - x[2 * n + j]
            ux, uy = dx / d, dy / d
            Jm[k, i] = ux; Jm[k, j] = -ux
            Jm[k, n + i] = uy; Jm[k, n + j] = -uy
            Jm[k, 2 * n + i] = -1; Jm[k, 2 * n + j] = -1
            Hp = (np.eye(2) - np.outer([ux, uy], [ux, uy])) / d
            H.append((k, i, j, Hp))
            k += 1
        for (i, a, s) in walls:
            if s == 0:
                g[k] = x[a * n + i] - x[2 * n + i]
                Jm[k, a * n + i] = 1
            else:
                g[k] = 1 - x[a * n + i] - x[2 * n + i]
                Jm[k, a * n + i] = -1
            Jm[k, 2 * n + i] = -1
            k += 1
        return g, Jm, H

    g, Jm, H = evalg(x)
    try:
        lam = np.linalg.lstsq(Jm.T, gf, rcond=None)[0]
    except Exception:
        return None
    best = None
    for _ in range(iters):
        g, Jm, H = evalg(x)
        F1 = gf - Jm.T @ lam
        F = np.concatenate([F1, g])
        HL = np.zeros((N, N))
        for (k, i, j, Hp) in H:
            idx_i = [i, n + i]
            idx_j = [j, n + j]
            B = -lam[k] * Hp
            HL[np.ix_(idx_i, idx_i)] += B
            HL[np.ix_(idx_j, idx_j)] += B
            HL[np.ix_(idx_i, idx_j)] -= B
            HL[np.ix_(idx_j, idx_i)] -= B
        K = np.zeros((N + m, N + m))
        K[:N, :N] = HL
        K[:N, N:] = -Jm.T
        K[N:, :N] = Jm
        try:
            step = np.linalg.lstsq(K, -F, rcond=None)[0]
        except Exception:
            break
        if not np.all(np.isfinite(step)):
            break
        dx = step[:N]
        if np.max(np.abs(dx)) > 0.05:
            dx = dx * (0.05 / np.max(np.abs(dx)))
            step = np.concatenate([dx, step[N:] * (0.05 / max(np.max(np.abs(step[:N])), 1e-300))])
        x = x + step[:N]
        lam = lam + step[N:]
        if np.max(np.abs(step[:N])) < 1e-16:
            break
    if not np.all(np.isfinite(x)):
        return None
    cn = np.stack([x[:n], x[n:2 * n]], axis=1)
    if np.any(cn < 0) or np.any(cn > 1):
        return None
    return cn, np.maximum(x[2 * n:], 0.0)


def solve(n=26):
    t0 = time.time()
    budget = 170.0
    hard = 230.0
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    rows = np.arange(len(I))
    A = np.zeros((4 * n, 3 * n))
    b = np.zeros(4 * n)
    for i in range(n):
        A[i, i] = 1; A[i, 2 * n + i] = -1
        A[n + i, i] = -1; A[n + i, 2 * n + i] = -1; b[n + i] = 1
        A[2 * n + i, n + i] = 1; A[2 * n + i, 2 * n + i] = -1
        A[3 * n + i, n + i] = -1; A[3 * n + i, 2 * n + i] = -1; b[3 * n + i] = 1
    Alin = (A, b)

    best_c = np.full((n, 2), 0.5)
    best_r = np.zeros(n)
    best_s = -1.0
    it = 0
    while time.time() - t0 < budget:
        el = time.time() - t0
        if el < budget * 0.55 or best_s < 0:
            kind = it % 4
            pts = _make_init(rng, n, kind)
        else:
            sig = rng.choice([0.01, 0.03, 0.06])
            pts = np.clip(best_c + rng.normal(0, sig, best_c.shape), 0.02, 0.98)
            if rng.random() < 0.3:
                k = rng.integers(n)
                pts[k] = rng.random(2)
        it += 1
        ts = time.time()
        out = _optimize(pts, n, I, J, Alin, rows)
        c, r, s = _score_safe(out)
        if s > best_s:
            best_s, best_c, best_r = s, c, r
        last = time.time() - ts
        if time.time() - t0 + 2 * last > budget:
            break

    # Final polish: warm-started SLSQP from the incumbent with tight tolerance.
    for _ in range(3):
        if time.time() - t0 > hard:
            break
        out = _optimize(best_c.copy(), n, I, J, Alin, rows,
                        r0=best_r.copy(), maxiter=600, ftol=1e-14)
        c, r, s = _score_safe(out)
        if s > best_s + 1e-13:
            best_s, best_c, best_r = s, c, r
        else:
            break

    # Newton-KKT refinement on the active contact graph.
    for _round in range(2):
        improved = False
        for tol in [1e-9, 1e-8, 1e-7, 1e-6]:
            if time.time() - t0 > hard + 30:
                break
            try:
                res = _newton_kkt(best_c.copy(), best_r.copy(), tol)
            except Exception:
                res = None
            if res is None:
                continue
            cn, rn = res
            rr = _repair(cn, rn)
            s1 = rr.sum()
            if s1 > best_s + 1e-15:
                best_s, best_c, best_r = s1, cn, rr
                improved = True
            try:
                c2, r2, s2 = _score_safe(cn)
                if s2 > best_s + 1e-15:
                    best_s, best_c, best_r = s2, c2, r2
                    improved = True
            except Exception:
                pass
        if not improved:
            break

    best_r = _repair(best_c, best_r)
    return best_c, best_r
# EVOLVE-BLOCK-END
