# EVOLVE-BLOCK-START
"""Grid with merged blocks: choose grid size k and a set of j x j merged squares
so that at most n squares are used and the sum of sides is maximal."""
import math


def _pack(k, sizes):
    """Greedy bottom-left placement of square blocks (sizes sorted descending)
    on a k x k cell grid. Returns list of (r, c, j) or None."""
    occ = [[False] * k for _ in range(k)]
    placed = []
    for j in sizes:
        done = False
        for r in range(k - j + 1):
            for c in range(k - j + 1):
                ok = True
                for rr in range(r, r + j):
                    row = occ[rr]
                    for cc in range(c, c + j):
                        if row[cc]:
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    for rr in range(r, r + j):
                        for cc in range(c, c + j):
                            occ[rr][cc] = True
                    placed.append((r, c, j))
                    done = True
                    break
            if done:
                break
        if not done:
            return None
    return placed


def _search_k(k, n, incumbent_sum):
    """Search merged-block multisets for grid size k. Returns (sum, blocks) or None."""
    R0 = k * k - n
    best = {"loss": None, "blocks": None}
    # loss threshold from incumbent: need (k*k - loss)/k > incumbent
    max_loss = k * k - incumbent_sum * k - 1e-9
    best["loss"] = max_loss
    nodes = [0]
    LIMIT = 150000

    def dfs(jmax, R, loss, blocks, area):
        nodes[0] += 1
        if nodes[0] > LIMIT:
            return
        cand = loss + max(R, 0)
        if cand < best["loss"] - 1e-12:
            p = _pack(k, blocks)
            if p is not None:
                best["loss"] = cand
                best["blocks"] = list(blocks)
        if R <= 0:
            return
        if loss + (2.0 / 3.0) * R >= best["loss"] - 1e-12:
            return
        for j in range(jmax, 1, -1):
            if area + j * j > k * k:
                continue
            blocks.append(j)
            dfs(j, R - (j * j - 1), loss + (j * j - j), blocks, area + j * j)
            blocks.pop()

    if R0 <= 0:
        if k * k - 0 > incumbent_sum * k + 1e-9:
            return (k * k / k, [])
        return None
    dfs(k, R0, 0, [], 0)
    if best["blocks"] is None:
        return None
    return ((k * k - best["loss"]) / k, best["blocks"])


def _build(k, n, sizes):
    placed = _pack(k, sizes) or []
    occ = [[False] * k for _ in range(k)]
    out = []
    for (r, c, j) in placed:
        for rr in range(r, r + j):
            for cc in range(c, c + j):
                occ[rr][cc] = True
        out.append(((c + j / 2.0) / k, (r + j / 2.0) / k, 0.0, j / k))
    for r in range(k):
        for c in range(k):
            if not occ[r][c]:
                out.append(((c + 0.5) / k, (r + 0.5) / k, 0.0, 1.0 / k))
    return out


import time


def _pack2(k, sizes, budget=20000):
    """Exact-ish backtracking packing of integer squares on a k x k cell grid.
    Returns list of (r, c, s) or None."""
    cnt = {}
    for s in sizes:
        cnt[s] = cnt.get(s, 0) + 1
    order = sorted(cnt.keys(), reverse=True)
    total = sum(s * s * c for s, c in cnt.items())
    slack0 = k * k - total
    if slack0 < 0:
        return None
    occ = [False] * (k * k)
    placed = []
    remaining = [len(sizes)]
    nodes = [0]

    def rec(pos, slack):
        if remaining[0] == 0:
            return True
        nodes[0] += 1
        if nodes[0] > budget:
            return False
        idx = pos
        while idx < k * k and occ[idx]:
            idx += 1
        if idx >= k * k:
            return False
        r, c = divmod(idx, k)
        for s in order:
            if cnt[s] <= 0 or r + s > k or c + s > k:
                continue
            ok = True
            for rr in range(r, r + s):
                base = rr * k
                for cc in range(c, c + s):
                    if occ[base + cc]:
                        ok = False
                        break
                if not ok:
                    break
            if not ok:
                continue
            for rr in range(r, r + s):
                base = rr * k
                for cc in range(c, c + s):
                    occ[base + cc] = True
            cnt[s] -= 1
            remaining[0] -= 1
            placed.append((r, c, s))
            if rec(idx + 1, slack):
                return True
            placed.pop()
            remaining[0] += 1
            cnt[s] += 1
            for rr in range(r, r + s):
                base = rr * k
                for cc in range(c, c + s):
                    occ[base + cc] = False
            if nodes[0] > budget:
                return False
        if slack > 0:
            occ[idx] = True
            if rec(idx + 1, slack - 1):
                return True
            occ[idx] = False
        return False

    if rec(0, slack0):
        return list(placed)
    return None


def _build_dp(n, kmax):
    A = kmax * kmax
    dp = [[[0] * (A + 1) for _ in range(n + 1)]]
    for s in range(1, kmax + 1):
        prev = dp[s - 1]
        cur = [row[:] for row in prev]
        s2 = s * s
        for m in range(1, n + 1):
            cm = cur[m]
            cm1 = cur[m - 1]
            for a in range(s2, A + 1):
                v = s + cm1[a - s2]
                if v > cm[a]:
                    cm[a] = v
        dp.append(cur)
    return dp


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    t0 = time.time()
    deadline = t0 + 40.0
    k0 = max(1, math.isqrt(n))
    best = {"sum": float(k0), "k": k0, "placed": None}
    kmax = k0 + 8
    while kmax > k0 and n * kmax ** 3 > 6e6:
        kmax -= 1
    if n * k0 ** 3 > 1.5e7:
        kmax = 0  # fallback to baseline grid
    if kmax >= 1:
        dp = _build_dp(n, kmax)
        for k in range(1, kmax + 1):
            if time.time() > deadline:
                break
            if dp[k][n][k * k] / k <= best["sum"] + 1e-9:
                continue
            nodes = [0]

            def dfs(s, m, a, cur, blocks):
                if time.time() > deadline or nodes[0] > 30000:
                    return
                thr = best["sum"] * k + 1e-9
                if cur + dp[s][m][a] <= thr:
                    return
                if s == 0 or m == 0:
                    nodes[0] += 1
                    if cur > thr:
                        p = _pack2(k, blocks)
                        if p is not None:
                            best["sum"] = cur / k
                            best["k"] = k
                            best["placed"] = p
                    return
                s2 = s * s
                cmax = min(m, a // s2)
                if s == 1:
                    cmax_list = [cmax]
                else:
                    cmax_list = range(cmax, -1, -1)
                for c in cmax_list:
                    if cur + c * s + dp[s - 1][m - c][a - c * s2] <= best["sum"] * k + 1e-9:
                        continue
                    dfs(s - 1, m - c, a - c * s2, cur + c * s, blocks + [s] * c)

            dfs(k, n, k * k, 0, [])
    k = best["k"]
    squares = []
    if best["placed"] is not None:
        for (r, c, s) in best["placed"]:
            squares.append(((c + s / 2.0) / k, (r + s / 2.0) / k, 0.0, s / k))
    else:
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
    squares = squares[:n]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares
# EVOLVE-BLOCK-END