# EVOLVE-BLOCK-START
"""Guillotine lattice DP with max-plus convolution over rectangles."""
import math
import time
import numpy as np

NEG = -1e18


def _run_lattice(K, n, deadline):
    idx = np.arange(n + 1)[None, :] - np.arange(n + 1)[:, None]  # N-m
    valid = idx >= 0
    idxc = np.where(valid, idx, 0)
    V = {}
    CH = {}
    for w in range(1, K + 1):
        for h in range(1, K + 1):
            if time.time() > deadline:
                return None
            best = np.full(n + 1, NEG)
            best[0] = 0.0
            ch = np.zeros((n + 1, 3), dtype=np.int64)  # dir(0 leaf,1 v,2 h), c, m
            if w == h:
                best[1:] = float(w)
            cuts = []
            for c in range(1, w // 2 + 1):
                cuts.append((1, c, V[(c, h)], V[(w - c, h)]))
            for c in range(1, h // 2 + 1):
                cuts.append((2, c, V[(w, c)], V[(w, h - c)]))
            for d, c, A, B in cuts:
                T = A[:, None] + B[idxc]
                T = np.where(valid, T, NEG)
                am = T.argmax(axis=0)
                val = T[am, np.arange(n + 1)]
                better = val > best + 1e-12
                if better.any():
                    best = np.where(better, val, best)
                    ch[better, 0] = d
                    ch[better, 1] = c
                    ch[better, 2] = am[better]
            V[(w, h)] = best
            CH[(w, h)] = ch
    return V[(K, K)][n], V, CH


def _place(K, CH, w, h, N, x0, y0, out):
    if N <= 0:
        return
    d, c, m = CH[(w, h)][N]
    if d == 0:
        out.append(((x0 + w / 2.0) / K, (y0 + h / 2.0) / K, 0.0, w / K))
    elif d == 1:
        _place(K, CH, c, h, int(m), x0, y0, out)
        _place(K, CH, w - c, h, N - int(m), x0 + c, y0, out)
    else:
        _place(K, CH, w, c, int(m), x0, y0, out)
        _place(K, CH, w, h - c, N - int(m), x0, y0 + c, out)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    start = time.time()
    budget = 40.0
    k0 = max(1, math.isqrt(n))
    best_val = float(k0)
    best_out = None
    # fallback grid
    grid = []
    for i in range(k0):
        for j in range(k0):
            grid.append(((i + 0.5) / k0, (j + 0.5) / k0, 0.0, 1.0 / k0))
    best_out = grid
    if n >= 2:
        Ks = []
        for K in range(max(2, k0), min(26, 2 * k0 + 3) + 1):
            Ks.append(K)
        for K in Ks:
            now = time.time()
            if now - start > budget * 0.7:
                break
            res = _run_lattice(K, n, start + budget)
            if res is None:
                break
            val, V, CH = res
            if val / K > best_val + 1e-9:
                out = []
                _place(K, CH, K, K, n, 0, 0, out)
                best_val = val / K
                best_out = out
    out = list(best_out)[:n]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    res = []
    for (x, y, a, s) in out:
        s = min(max(s, 0.0), 1.0)
        res.append((min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0), a, s))
    return res
# EVOLVE-BLOCK-END