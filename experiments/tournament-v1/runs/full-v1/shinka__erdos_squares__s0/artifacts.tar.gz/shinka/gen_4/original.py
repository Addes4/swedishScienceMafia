# EVOLVE-BLOCK-START
"""Grid with merged blocks: choose grid size k and a set of j x j merged squares
so that at most n squares are used and the sum of sides is maximal."""
import math


def _pack(k, sizes):
    """Greedy bottom-left placement of square blocks (sizes sorted descending)
    on a k x k cell grid. Returns list of (r, c, j) or None."""
    occ = [[False] * k for _ in range(k)]
    placed = []
    for j in sizes:
        done = False
        for r in range(k - j + 1):
            for c in range(k - j + 1):
                ok = True
                for rr in range(r, r + j):
                    row = occ[rr]
                    for cc in range(c, c + j):
                        if row[cc]:
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    for rr in range(r, r + j):
                        for cc in range(c, c + j):
                            occ[rr][cc] = True
                    placed.append((r, c, j))
                    done = True
                    break
            if done:
                break
        if not done:
            return None
    return placed


def _search_k(k, n, incumbent_sum):
    """Search merged-block multisets for grid size k. Returns (sum, blocks) or None."""
    R0 = k * k - n
    best = {"loss": None, "blocks": None}
    # loss threshold from incumbent: need (k*k - loss)/k > incumbent
    max_loss = k * k - incumbent_sum * k - 1e-9
    best["loss"] = max_loss
    nodes = [0]
    LIMIT = 150000

    def dfs(jmax, R, loss, blocks, area):
        nodes[0] += 1
        if nodes[0] > LIMIT:
            return
        cand = loss + max(R, 0)
        if cand < best["loss"] - 1e-12:
            p = _pack(k, blocks)
            if p is not None:
                best["loss"] = cand
                best["blocks"] = list(blocks)
        if R <= 0:
            return
        if loss + (2.0 / 3.0) * R >= best["loss"] - 1e-12:
            return
        for j in range(jmax, 1, -1):
            if area + j * j > k * k:
                continue
            blocks.append(j)
            dfs(j, R - (j * j - 1), loss + (j * j - j), blocks, area + j * j)
            blocks.pop()

    if R0 <= 0:
        if k * k - 0 > incumbent_sum * k + 1e-9:
            return (k * k / k, [])
        return None
    dfs(k, R0, 0, [], 0)
    if best["blocks"] is None:
        return None
    return ((k * k - best["loss"]) / k, best["blocks"])


def _build(k, n, sizes):
    placed = _pack(k, sizes) or []
    occ = [[False] * k for _ in range(k)]
    out = []
    for (r, c, j) in placed:
        for rr in range(r, r + j):
            for cc in range(c, c + j):
                occ[rr][cc] = True
        out.append(((c + j / 2.0) / k, (r + j / 2.0) / k, 0.0, j / k))
    for r in range(k):
        for c in range(k):
            if not occ[r][c]:
                out.append(((c + 0.5) / k, (r + 0.5) / k, 0.0, 1.0 / k))
    return out


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    k0 = max(1, math.isqrt(n))
    best_sum = k0 * 1.0 if k0 * k0 <= n else 0.0
    best_cfg = (k0, [])
    kmax = min(k0 + 5, 40)
    for k in range(1, kmax + 1):
        # optimistic bound: all merges at ratio 2/3
        R0 = max(k * k - n, 0)
        if (k * k - (2.0 / 3.0) * R0) / k <= best_sum + 1e-9:
            continue
        res = _search_k(k, n, best_sum)
        if res is not None and res[0] > best_sum + 1e-9:
            best_sum, best_cfg = res[0], (k, res[1])
    k, sizes = best_cfg
    squares = _build(k, n, sizes)
    squares = squares[:n]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares
# EVOLVE-BLOCK-END