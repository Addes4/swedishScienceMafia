# EVOLVE-BLOCK-START
"""Recursive merged-grid dynamic program.

g(t) = best sum of sides using t squares in a unit square.  Candidates: one
square, or a k x k grid (k<=6) with some j x j merged blocks, every block/cell
recursively filled with its own number of squares (knapsack over counts)."""
import math
import time
from operator import add

_SHRINK = 1e-9
_NEG = float("-inf")


def _multisets(k):
    res = []
    cur = []

    def rec(maxj, area):
        res.append(list(cur))
        for j in range(maxj, 1, -1):
            if area + j * j <= k * k:
                cur.append(j)
                rec(j, area + j * j)
                cur.pop()

    rec(k - 1, 0)
    return res


def _pack(k, sizes):
    """Backtracking placement of square blocks on a k x k grid.
    Returns list of (r, c) aligned with sizes, or None."""
    grid = [[False] * k for _ in range(k)]
    pos = [None] * len(sizes)

    def free(r, c, j):
        for rr in range(r, r + j):
            row = grid[rr]
            for cc in range(c, c + j):
                if row[cc]:
                    return False
        return True

    def mark(r, c, j, v):
        for rr in range(r, r + j):
            row = grid[rr]
            for cc in range(c, c + j):
                row[cc] = v

    def rec(i, start):
        if i == len(sizes):
            return True
        j = sizes[i]
        sp = start if (i > 0 and sizes[i] == sizes[i - 1]) else 0
        for p in range(sp, k * k):
            r, c = divmod(p, k)
            if r + j > k or c + j > k:
                continue
            if free(r, c, j):
                mark(r, c, j, True)
                pos[i] = (r, c)
                if rec(i + 1, p + 1):
                    return True
                mark(r, c, j, False)
        return False

    if rec(0, 0):
        occ = [row[:] for row in grid]
        return pos, occ
    return None


def _build_layouts(n, budget):
    layouts = []
    total = 0.0
    stop = False
    for k in range(2, 7):
        if stop:
            break
        for blocks in _multisets(k):
            if not blocks and k in (4, 6):
                continue
            if blocks:
                pk = _pack(k, blocks)
                if pk is None:
                    continue
                pl, occ = pk
            else:
                pl = []
                occ = [[False] * k for _ in range(k)]
            elems = [(pl[i][0], pl[i][1], blocks[i]) for i in range(len(blocks))]
            for r in range(k):
                for c in range(k):
                    if not occ[r][c]:
                        elems.append((r, c, 1))
            E = len(elems)
            cost = E * (n * n / 2.0 * 6e-8 + n * 2e-6)
            if k > 3 and total + cost > budget:
                stop = True
                break
            total += cost
            sizes_set = sorted(set(e[2] for e in elems))
            L = {
                "k": k,
                "elems": elems,
                "E": E,
                "H": [[_NEG] * (n + 1) for _ in range(E + 1)],
                "ch": [[0] * (n + 1) for _ in range(E + 1)],
                "sgl": {s: [0.0] for s in sizes_set},
            }
            for i in range(E + 1):
                L["H"][i][0] = 0.0
            layouts.append(L)
    return layouts


def _solve_dp(n):
    layouts = _build_layouts(n, 15.0)
    g = [0.0]
    kind = [None]
    for u in range(1, n + 1):
        gb = g[u - 1]
        kd = "less"
        if u == 1:
            gb = 1.0
            kd = "single"
        for L in layouts:
            H = L["H"]
            ch = L["ch"]
            sgl = L["sgl"]
            elems = L["elems"]
            E = L["E"]
            for i in range(1, E + 1):
                prev = H[i - 1]
                sg = sgl[elems[i - 1][2]]
                best = prev[u]
                bx = 0
                if u >= 2:
                    vals = list(map(add, prev[u - 1:0:-1], sg[1:u]))
                    m = max(vals)
                    if m > best:
                        best = m
                        bx = vals.index(m) + 1
                H[i][u] = best
                ch[i][u] = bx
            cand = H[E][u]
            if cand > gb + 1e-12:
                gb = cand
                kd = L
        g.append(gb)
        kind.append(kd)
        for L in layouts:
            k = L["k"]
            sgl = L["sgl"]
            for s, lst in sgl.items():
                lst.append(s / k * gb)
            H = L["H"]
            ch = L["ch"]
            elems = L["elems"]
            for i in range(1, L["E"] + 1):
                if H[i - 1][u] > H[i][u]:
                    H[i][u] = H[i - 1][u]
                    ch[i][u] = 0
                sgu = sgl[elems[i - 1][2]][u]
                if sgu > H[i][u]:
                    H[i][u] = sgu
                    ch[i][u] = u

    out = []

    def emit(t, x0, y0, s, depth):
        if t <= 0:
            return
        while t > 0 and kind[t] == "less":
            t -= 1
        if t <= 0:
            return
        kd = kind[t]
        if kd == "single" or depth > 8:
            out.append((x0 + s / 2.0, y0 + s / 2.0, 0.0, s))
            return
        L = kd
        k = L["k"]
        E = L["E"]
        counts = [0] * E
        uu = t
        for i in range(E, 0, -1):
            x = L["ch"][i][uu]
            counts[i - 1] = x
            uu -= x
        for idx, (r, c, j) in enumerate(L["elems"]):
            if counts[idx] > 0:
                emit(counts[idx], x0 + c * s / k, y0 + r * s / k, j * s / k, depth + 1)

    emit(n, 0.0, 0.0, 1.0, 0)
    return out


def _solve_simple(n):
    best = None
    for k in range(1, math.isqrt(n) + 3):
        R = k * k - n
        if R <= 0:
            if k * k > n:
                continue
            val = float(k)
            b = 0
        else:
            maxb = (k // 2) ** 2
            bl = None
            for bb in range(0, maxb + 1):
                loss = 2 * bb + max(0, R - 3 * bb)
                if bl is None or loss < bl[0]:
                    bl = (loss, bb)
            val = (k * k - bl[0]) / k
            b = bl[1]
        if best is None or val > best[0]:
            best = (val, k, b)
    _, k, b = best
    out = []
    occ = [[False] * k for _ in range(k)]
    cnt = 0
    for a in range(b):
        r = (a // (k // 2)) * 2
        c = (a % (k // 2)) * 2
        for rr in range(r, r + 2):
            for cc in range(c, c + 2):
                occ[rr][cc] = True
        out.append(((c + 1.0) / k, (r + 1.0) / k, 0.0, 2.0 / k))
    for r in range(k):
        for c in range(k):
            if not occ[r][c] and len(out) < n:
                out.append(((c + 0.5) / k, (r + 0.5) / k, 0.0, 1.0 / k))
    return out


def _finish(sq, n):
    sq = sq[:n]
    res = [(x, y, a, s * (1.0 - _SHRINK)) for (x, y, a, s) in sq]
    res += [(0.0, 0.0, 0.0, 0.0)] * (n - len(res))
    return res


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    cands = []
    if n <= 150:
        try:
            cands.append(_solve_dp(n))
        except Exception:
            pass
    try:
        cands.append(_solve_simple(n))
    except Exception:
        pass
    if not cands:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    best = max(cands, key=lambda c: sum(s[3] for s in c[:n]))
    return _finish(best, n)
# EVOLVE-BLOCK-END