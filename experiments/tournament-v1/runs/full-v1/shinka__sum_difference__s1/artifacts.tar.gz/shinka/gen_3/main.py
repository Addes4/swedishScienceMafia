# EVOLVE-BLOCK-START
"""Weighted-simplex family with exact numpy evaluation, falling back to the plain simplex."""
import math
import random
import time

import numpy as np


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _count_size(weights, n):
    dp = [0] * (n + 1)
    dp[0] = 1  # dp[s] = number of ways with exact weight sum s
    for w in weights:
        new = [0] * (n + 1)
        for s in range(n + 1):
            if dp[s]:
                t = s
                while t <= n:
                    new[t] += dp[s]
                    t += w
        dp = new
    return sum(dp)


def _gen_points(weights, n, B):
    d = len(weights)
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        w = weights[i]
        pw = B ** i
        for x in range(rem // w + 1):
            rec(i + 1, rem - x * w, val + x * pw)

    rec(0, n, 0)
    return pts


def _exact_score(pts):
    v = np.array(sorted(set(pts)), dtype=np.int64)
    m = len(v)
    if m < 2:
        return 0.0
    iu, ju = np.triu_indices(m, 0)
    s = np.unique(v[iu] + v[ju]).size
    iu, ju = np.triu_indices(m, 1)
    dd = np.unique(v[ju] - v[iu]).size * 2 + 1
    return math.log(dd) / math.log(s) + (1 - 1 / m) / 100


def solve():
    fact = math.factorial
    comb = math.comb
    t0 = time.time()

    def diff_count(d, n):
        t = 0
        for j in range(d + 1):
            for m in range(d - j + 1):
                t += (fact(d) // (fact(j) * fact(m) * fact(d - j - m))) * comb(n, j) * comb(n, m)
        return t

    best_par, best_sc = None, -1.0
    for d in range(1, 16):
        n = 1
        while True:
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 4 * n + 1
            if n * B ** (d - 1) <= 10 ** 15 and size >= 2:
                s = math.log(diff_count(d, n)) / math.log(comb(2 * n + d, d)) + (1 - 1 / size) / 100
                if s > best_sc:
                    best_sc, best_par = s, (d, n)
            n += 1

    best_pts = [0, 1, 3]
    if best_par is not None:
        d, n = best_par
        B = 4 * n + 1
        best_pts = sorted(set(_gen_points([1] * d, n, B)))

    # weighted simplex candidates
    cands = []
    for d in range(2, 14):
        for k in range(0, d + 1):
            weights = [2] * k + [1] * (d - k)
            for n in range(2, 60):
                B = 2 * n + 1
                if n * B ** (d - 1) > 10 ** 15:
                    break
                size = _count_size(weights, n)
                if size > 4000:
                    break
                if size >= 150:
                    cands.append((size, d, k, n))
    cands.sort()
    # prefer a spread: evaluate all in ascending size under time budget
    deadline = t0 + 85
    for size, d, k, n in cands:
        if time.time() > deadline:
            break
        if size > 2500 and time.time() > t0 + 60:
            continue
        weights = [2] * k + [1] * (d - k)
        B = 2 * n + 1
        pts = _gen_points(weights, n, B)
        if max(pts) > 10 ** 15:
            continue
        try:
            sc = _exact_score(pts)
        except MemoryError:
            continue
        if sc > best_sc:
            best_sc = sc
            best_pts = sorted(set(pts))

    return [int(x) for x in best_pts]
# EVOLVE-BLOCK-END