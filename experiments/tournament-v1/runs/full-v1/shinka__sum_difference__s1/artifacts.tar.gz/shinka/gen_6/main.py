# EVOLVE-BLOCK-START
"""Simplex seeds + incremental ratio-driven greedy growth in an integer-encoded lattice."""
import math
import time
import random
import numpy as np


def _score_np(arr):
    a = np.array(sorted(set(int(v) for v in arr)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _simplex(d, n, B):
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return pts


def _ratio(nd, ns):
    return math.log(nd) / math.log(ns)


def _in_sorted(S, v):
    idx = np.searchsorted(S, v)
    idx[idx >= len(S)] = len(S) - 1
    return S[idx] == v


def _greedy(seed, d, B, K, deadline, maxN, M=60):
    order = sorted(set(seed))
    A = np.array(order, dtype=np.int64)
    S = np.unique((A[:, None] + A[None, :]).ravel())
    D = np.unique((A[:, None] - A[None, :]).ravel())
    units = [B ** i for i in range(d)]
    members = set(order)
    best_score = _ratio(len(D), len(S))
    best_len = len(order)
    while time.time() < deadline and len(order) < maxN:
        cands = set()
        tries = 0
        while len(cands) < M and tries < M * 6:
            tries += 1
            a = order[random.randrange(len(order))]
            i = random.randrange(d)
            s = random.choice((-1, 1))
            dig = (a // units[i]) % B
            if not (0 <= dig + s < K):
                continue
            x = a + s * units[i]
            if x in members or x < 0:
                continue
            cands.add(x)
        if not cands:
            break
        bx = None
        bsc = -1.0
        bnew = None
        for x in cands:
            sv = np.unique(np.append(A + x, 2 * x))
            sv = sv[~_in_sorted(S, sv)]
            dv = np.unique(x - A)
            dv = dv[~_in_sorted(D, dv)]
            sc = _ratio(len(D) + 2 * len(dv), len(S) + len(sv))
            sc += random.random() * 1e-6
            if sc > bsc:
                bsc, bx, bnew = sc, x, (sv, dv)
        sv, dv = bnew
        if len(sv):
            S = np.insert(S, np.searchsorted(S, sv), sv)
        if len(dv):
            full = np.unique(np.concatenate((dv, -dv)))
            D = np.insert(D, np.searchsorted(D, full), full)
        pos = np.searchsorted(A, bx)
        A = np.insert(A, pos, bx)
        order.append(bx)
        members.add(bx)
        cur = _ratio(len(D), len(S))
        if cur > best_score:
            best_score = cur
            best_len = len(order)
    return order[:best_len], best_score


def solve():
    start = time.time()
    total = 100.0
    # Phase 1: simplex scan
    cands = []
    for d in range(2, 40):
        for n in range(1, 40):
            size = math.comb(n + d, d)
            if size < 8 or size > 700:
                continue
            if (2 * n + 1) ** d > 5e14:
                continue
            cands.append((size, d, n))
    cands.sort()
    results = []
    for size, d, n in cands:
        if time.time() - start > 25:
            break
        pts = _simplex(d, n, 2 * n + 1)
        results.append((_score_np(pts), d, n, pts))
    results.sort(key=lambda r: -r[0])
    best = [0, 1, 3]
    best_score = _score_np(best)
    if results:
        best_score, _, _, best = results[0]
    # Phase 2: greedy growth from top seeds
    tops = results[:5]
    for idx, (sc, d, n, pts) in enumerate(tops):
        now = time.time()
        remaining = start + total - now
        if remaining < 3:
            break
        slice_t = remaining / (len(tops) - idx)
        K = n + 1
        while K < n + 4 and (2 * (K + 1)) ** d <= 5e14:
            K += 1
        B = 2 * K
        seed = _simplex(d, n, B)
        try:
            grown, gs = _greedy(seed, d, B, K, now + slice_t, 2500)
        except Exception:
            continue
        if len(grown) <= 4000 and max(grown) <= 10 ** 15:
            if len(grown) <= 2500:
                es = _score_np(grown)
                if es > best_score:
                    best_score, best = es, grown
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END