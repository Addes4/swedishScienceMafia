# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    from itertools import product
    fact = math.factorial
    comb = math.comb

    def diff_count(d, n):
        t = 0
        for j in range(d + 1):
            for m in range(d - j + 1):
                t += (fact(d) // (fact(j) * fact(m) * fact(d - j - m))) * comb(n, j) * comb(n, m)
        return t

    best_par, best_sc = None, -1.0
    for d in range(1, 16):
        n = 1
        while True:
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 4 * n + 1
            if n * B ** (d - 1) <= 10 ** 15 and size >= 2:
                s = math.log(diff_count(d, n)) / math.log(comb(2 * n + d, d)) + (1 - 1 / size) / 100
                if s > best_sc:
                    best_sc, best_par = s, (d, n)
            n += 1
    if best_par is None:
        return [0, 1, 3]
    d, n = best_par
    B = 4 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * B ** i)

    rec(0, n, 0)
    return sorted(set(pts))
# EVOLVE-BLOCK-END