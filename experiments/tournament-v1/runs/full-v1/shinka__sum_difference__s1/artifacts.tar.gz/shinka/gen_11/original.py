# EVOLVE-BLOCK-START
"""Weighted-simplex family with exact numpy evaluation, followed by incremental local search."""
import math
import random
import time

import numpy as np


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _count_size(weights, n):
    dp = [0] * (n + 1)
    dp[0] = 1
    for w in weights:
        new = [0] * (n + 1)
        for s in range(n + 1):
            if dp[s]:
                t = s
                while t <= n:
                    new[t] += dp[s]
                    t += w
        dp = new
    return sum(dp)


def _gen_points(weights, n, B):
    d = len(weights)
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        w = weights[i]
        pw = B ** i
        for x in range(rem // w + 1):
            rec(i + 1, rem - x * w, val + x * pw)

    rec(0, n, 0)
    return pts


def _exact_score(pts):
    v = np.array(sorted(set(pts)), dtype=np.int64)
    m = len(v)
    if m < 2:
        return 0.0
    iu, ju = np.triu_indices(m, 0)
    s = np.unique(v[iu] + v[ju]).size
    iu, ju = np.triu_indices(m, 1)
    dd = np.unique(v[ju] - v[iu]).size * 2 + 1
    return math.log(dd) / math.log(s) + (1 - 1 / m) / 100


def _local_search(pts, B, ndim, deadline):
    A = sorted(set(pts))
    S = set(A)
    v = np.array(A, dtype=np.int64)
    m = len(v)
    iu, ju = np.triu_indices(m, 0)
    u, c = np.unique(v[iu] + v[ju], return_counts=True)
    sc = dict(zip(u.tolist(), c.tolist()))
    iu, ju = np.triu_indices(m, 1)
    u, c = np.unique(v[ju] - v[iu], return_counts=True)
    dc = dict(zip(u.tolist(), c.tolist()))
    del iu, ju, u, c, v
    steps = []
    for i in range(ndim):
        steps.append(B ** i)
        steps.append(-(B ** i))

    def add_pt(p):
        g = sc.get
        h = dc.get
        for q in A:
            s = p + q
            sc[s] = g(s, 0) + 1
            k = p - q
            if k < 0:
                k = -k
            dc[k] = h(k, 0) + 1
        s = 2 * p
        sc[s] = g(s, 0) + 1
        A.append(p)
        S.add(p)

    def rem_pt(p):
        for q in A:
            s = p + q
            c1 = sc[s] - 1
            if c1:
                sc[s] = c1
            else:
                del sc[s]
            k = p - q
            if k < 0:
                k = -k
            c2 = dc[k] - 1
            if c2:
                dc[k] = c2
            else:
                del dc[k]
        s = 2 * p
        c1 = sc[s] - 1
        if c1:
            sc[s] = c1
        else:
            del sc[s]

    def cur_score():
        return math.log(2 * len(dc) + 1) / math.log(len(sc)) + (1 - 1 / len(A)) / 100

    cur = cur_score()
    best = cur
    best_set = list(A)
    it = 0
    while True:
        it += 1
        if (it & 15) == 0 and time.time() > deadline:
            break
        if random.random() < 0.5 and len(A) < 4000:
            q = A[random.randrange(len(A))]
            p = q + random.choice(steps)
            if p in S:
                continue
            add_pt(p)
            new = cur_score()
            if new >= cur:
                cur = new
                if new > best:
                    best = new
                    best_set = list(A)
            else:
                A.pop()
                S.discard(p)
                rem_pt(p)
        else:
            if len(A) <= 50:
                continue
            i = random.randrange(len(A))
            p = A[i]
            A[i] = A[-1]
            A.pop()
            S.discard(p)
            rem_pt(p)
            new = cur_score()
            if new >= cur:
                cur = new
                if new > best:
                    best = new
                    best_set = list(A)
            else:
                add_pt(p)
    return best_set


def solve():
    fact = math.factorial
    comb = math.comb
    t0 = time.time()

    def diff_count(d, n):
        t = 0
        for j in range(d + 1):
            for m in range(d - j + 1):
                t += (fact(d) // (fact(j) * fact(m) * fact(d - j - m))) * comb(n, j) * comb(n, m)
        return t

    best_par, best_sc = None, -1.0
    for d in range(1, 16):
        n = 1
        while True:
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 4 * n + 1
            if n * B ** (d - 1) <= 10 ** 15 and size >= 2:
                s = math.log(diff_count(d, n)) / math.log(comb(2 * n + d, d)) + (1 - 1 / size) / 100
                if s > best_sc:
                    best_sc, best_par = s, (d, n)
            n += 1

    best_pts = [0, 1, 3]
    best_cfg = None  # (weights, n)
    if best_par is not None:
        d, n = best_par
        B = 4 * n + 1
        best_pts = sorted(set(_gen_points([1] * d, n, B)))
        best_cfg = ([1] * d, n)

    # capped simplex family: x in [0,c]^d, sum x <= n, exact counts via DP
    def _capped_counts(d, n, c):
        a = np.zeros(n + 1)
        a[0] = 1.0
        for _ in range(d):
            new = a.copy()
            for k in range(1, min(c, n) + 1):
                new[k:] += a[:n + 1 - k]
            a = new
        size = a.sum()
        a = np.zeros(2 * n + 1)
        a[0] = 1.0
        for _ in range(d):
            new = a.copy()
            for k in range(1, min(2 * c, 2 * n) + 1):
                new[k:] += a[:2 * n + 1 - k]
            a = new
        ssum = a.sum()
        return size, ssum

    def _capped_diff(d, n, c):
        a = np.zeros((n + 1, n + 1))
        a[0, 0] = 1.0
        for _ in range(d):
            new = a.copy()
            for k in range(1, min(c, n) + 1):
                new[k:, :] += a[:n + 1 - k, :]
                new[:, k:] += a[:, :n + 1 - k]
            a = new
        return a.sum()

    try:
        cap_best = None
        for d in range(2, 41):
            for n in range(1, 15):
                stop = False
                for c in range(1, n + 1):
                    B = 2 * c + 1
                    if c * (B ** d - 1) // (B - 1) > 10 ** 15:
                        continue
                    size, ssum = _capped_counts(d, n, c)
                    if size > 4000:
                        if c == 1:
                            stop = True
                        continue
                    if size < 100:
                        continue
                    dsum = _capped_diff(d, n, c)
                    s = math.log(dsum) / math.log(ssum) + (1 - 1 / size) / 100
                    if cap_best is None or s > cap_best[0]:
                        cap_best = (s, d, n, c)
                if stop:
                    break
        if cap_best is not None and cap_best[0] > best_sc:
            s, d, n, c = cap_best
            B = 2 * c + 1
            pts = []

            def rec2(i, rem, val):
                if i == d:
                    pts.append(val)
                    return
                pw = B ** i
                for x in range(min(c, rem) + 1):
                    rec2(i + 1, rem - x, val + x * pw)

            rec2(0, n, 0)
            if len(pts) <= 4000 and max(pts) <= 10 ** 15:
                best_sc = s
                best_pts = sorted(set(pts))
                best_cfg = ([1] * d, n) if c == n else None
    except Exception:
        pass

    cands = []
    for d in range(2, 14):
        for k in range(0, d + 1):
            weights = [2] * k + [1] * (d - k)
            for n in range(2, 60):
                B = 2 * n + 1
                if n * B ** (d - 1) > 10 ** 15:
                    break
                size = _count_size(weights, n)
                if size > 4000:
                    break
                if size >= 1500:
                    cands.append((size, d, k, n))
    cands.sort(reverse=True)
    deadline = t0 + 55
    for size, d, k, n in cands:
        if time.time() > deadline:
            break
        weights = [2] * k + [1] * (d - k)
        B = 2 * n + 1
        pts = _gen_points(weights, n, B)
        if max(pts) > 10 ** 15:
            continue
        try:
            sc = _exact_score(pts)
        except MemoryError:
            continue
        if sc > best_sc:
            best_sc = sc
            best_pts = sorted(set(pts))
            best_cfg = (weights, n)

    final = [int(x) for x in best_pts]

    # local search refinement
    try:
        if best_cfg is not None:
            weights, n = best_cfg
            nd = len(weights)
            Bl = 4 * n + 5
            if (n + 3) * Bl ** (nd - 1) * 4 < 10 ** 15 and time.time() < t0 + 100:
                base_pts = _gen_points(weights, n, Bl)
                res = _local_search(base_pts, Bl, nd, t0 + 108)
                if res and max(abs(x) for x in res) <= 10 ** 15 and len(set(res)) <= 4000:
                    sc2 = _exact_score(res)
                    if sc2 > best_sc:
                        final = [int(x) for x in sorted(set(res))]
    except Exception:
        pass

    return final
# EVOLVE-BLOCK-END