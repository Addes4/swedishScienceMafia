# EVOLVE-BLOCK-START
"""Simplex lattice construction encoded into integers, with exhaustive (d, n) search."""
import math
import time
import itertools
import numpy as np


def _score_np(arr):
    a = np.array(sorted(set(int(v) for v in arr)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _simplex(d, n, m=None):
    if m is None or m > n:
        m = n
    B = 2 * m + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(min(rem, m) + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return pts


def _count(d, n, m):
    # number of x in [0,m]^d with sum <= n
    cur = [1] * (n + 1)  # d = 0: only sum 0 -> cumulative handled below
    cur = [1] + [0] * n
    for _ in range(d):
        new = [0] * (n + 1)
        for s in range(n + 1):
            if cur[s]:
                for x in range(0, min(m, n - s) + 1):
                    new[s + x] += cur[s]
        cur = new
    return sum(cur)


def _polish(pts, B, deadline):
    import random
    cur = sorted(set(pts))
    cur_s = _score_np(cur)
    d_units = []
    p = 1
    while p < 10 ** 15 and len(d_units) < 40:
        d_units.append(p)
        p *= B
    while time.time() < deadline:
        cand = list(cur)
        r = random.random()
        if r < 0.3 and len(cand) > 4:
            cand.pop(random.randrange(len(cand)))
        else:
            base = random.choice(cand)
            u = random.choice(d_units)
            cand.append(base + random.choice((-1, 1)) * u)
        if max(abs(v) for v in cand) > 10 ** 15:
            continue
        s = _score_np(cand)
        if s > cur_s:
            cur, cur_s = sorted(set(cand)), s
    return cur, cur_s


def solve():
    start = time.time()
    budget = 55.0
    cands = []
    for d in range(1, 40):
        for n in range(1, 40):
            for m in range(1, n + 1):
                if m < n and m * d <= n:
                    continue  # same as m == n shape cap-free
                if (2 * m + 1) ** d > 5e14:
                    continue
                if math.comb(n + d, d) > 4000 and m == n:
                    continue
                if m < n and (m + 1) ** d < 4:
                    continue
                size = _count(d, n, m) if m < n else math.comb(n + d, d)
                if size > 4000 or size < 4:
                    continue
                cands.append((size, d, n, m))
    cands.sort()
    best = [0, 1, 3]
    best_B = 3
    best_score = _score_np(best)
    for size, d, n, m in cands:
        if time.time() - start > budget:
            break
        pts = _simplex(d, n, m)
        s = _score_np(pts)
        if s > best_score:
            best_score = s
            best = pts
            best_B = 2 * m + 1
    if len(best) <= 400:
        try:
            pol, ps = _polish(best, best_B, start + 90.0)
            if ps > best_score:
                best, best_score = pol, ps
        except Exception:
            pass
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END