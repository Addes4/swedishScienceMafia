# EVOLVE-BLOCK-START
"""Simplex lattice construction encoded into integers, with exhaustive (d, n) search."""
import math
import time
import itertools
import numpy as np


def _score_np(arr):
    a = np.array(sorted(set(int(v) for v in arr)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _simplex(d, n):
    B = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return pts


def solve():
    start = time.time()
    budget = 70.0
    cands = []
    for d in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000 or size < 4:
                continue
            if (2 * n + 1) ** d > 5e14:
                continue
            cands.append((size, d, n))
    cands.sort()
    best = [0, 1, 3]
    best_score = _score_np(best)
    for size, d, n in cands:
        if time.time() - start > budget:
            break
        pts = _simplex(d, n)
        s = _score_np(pts)
        if s > best_score:
            best_score = s
            best = pts
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END