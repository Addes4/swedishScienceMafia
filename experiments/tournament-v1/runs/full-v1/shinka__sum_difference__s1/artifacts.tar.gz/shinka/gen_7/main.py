# EVOLVE-BLOCK-START
"""Simplex lattice construction encoded into integers, with exhaustive (d, n) search."""
import math
import time
import itertools
import numpy as np


def _score_np(arr):
    a = np.array(sorted(set(int(v) for v in arr)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _simplex(d, n):
    B = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return pts


def _formula(d, n):
    ns = math.comb(2 * n + d, d)
    nd = 0
    for p in range(0, min(d, n) + 1):
        for q in range(0, min(d - p, n) + 1):
            nd += math.comb(d, p) * math.comb(d - p, q) * math.comb(n, p) * math.comb(n, q)
    return math.log(nd) / math.log(ns)


def _local_search(pts, B, d, deadline):
    import random
    A = list(pts)
    Aset = set(A)
    sums = {}
    diffs = {}
    for i, x in enumerate(A):
        for y in A[:i + 1]:
            s = x + y
            sums[s] = sums.get(s, 0) + 1
        for y in A:
            t = x - y
            diffs[t] = diffs.get(t, 0) + 1
    units = [B ** j for j in range(d)]

    def add(p):
        for a in A:
            s = p + a
            sums[s] = sums.get(s, 0) + 1
            t = p - a
            diffs[t] = diffs.get(t, 0) + 1
            t = a - p
            diffs[t] = diffs.get(t, 0) + 1
        s = 2 * p
        sums[s] = sums.get(s, 0) + 1
        diffs[0] = diffs.get(0, 0) + 1
        A.append(p)
        Aset.add(p)

    def rem(p):
        A.remove(p)
        Aset.discard(p)
        for a in A:
            for s in (p + a,):
                c = sums[s] - 1
                if c:
                    sums[s] = c
                else:
                    del sums[s]
            for t in (p - a, a - p):
                c = diffs[t] - 1
                if c:
                    diffs[t] = c
                else:
                    del diffs[t]
        s = 2 * p
        c = sums[s] - 1
        if c:
            sums[s] = c
        else:
            del sums[s]
        c = diffs[0] - 1
        if c:
            diffs[0] = c
        else:
            del diffs[0]

    def sc():
        return math.log(len(diffs)) / math.log(len(sums))

    cur = sc()
    while time.time() < deadline:
        r = random.random()
        ops = []
        if r < 0.4 and len(A) < 4000:
            a = random.choice(A)
            q = a + random.choice((-1, 1)) * random.choice(units)
            if q in Aset or abs(q) > 10 ** 15:
                continue
            add(q)
            ops = [('a', q)]
        elif r < 0.7 and len(A) > 10:
            p = random.choice(A)
            rem(p)
            ops = [('r', p)]
        else:
            if len(A) <= 10:
                continue
            p = random.choice(A)
            rem(p)
            ops = [('r', p)]
            a = random.choice(A)
            q = a + random.choice((-1, 1)) * random.choice(units)
            if q in Aset or q == p or abs(q) > 10 ** 15:
                add(p)
                continue
            add(q)
            ops.append(('a', q))
        new = sc()
        if new > cur + 1e-12:
            cur = new
        else:
            for op, v in reversed(ops):
                if op == 'a':
                    rem(v)
                else:
                    add(v)
    return list(A), cur


def solve():
    start = time.time()
    cands = []
    for d in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000 or size < 4:
                continue
            if (2 * n + 1) ** d > 5e14:
                continue
            cands.append((_formula(d, n), size, d, n))
    cands.sort(reverse=True)
    _, _, bd, bn = cands[0]
    best = _simplex(bd, bn)
    best_score = _score_np(best)

    small = [c for c in cands if c[1] <= 1500 and c[2] >= 2]
    if small:
        _, _, sd, sn = small[0]
        try:
            pts = _simplex(sd, sn)
            res, _ = _local_search(pts, 2 * sn + 1, sd, start + 85.0)
            s = _score_np(res)
            if s > best_score and len(set(res)) <= 4000:
                best, best_score = res, s
        except Exception:
            pass
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END