# EVOLVE-BLOCK-START
"""Simplex lattice construction encoded into integers, with exhaustive (d, n) search."""
import math
import time
import itertools
import numpy as np


def _score_np(arr):
    a = np.array(sorted(set(int(v) for v in arr)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _simplex(d, n):
    B = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return pts


def _formula_score(d, n):
    S = math.comb(2 * n + d, d)
    D = 0
    for j in range(0, min(d, n) + 1):
        for k in range(0, min(d - j, n) + 1):
            D += (math.factorial(d) // (math.factorial(j) * math.factorial(k)
                                        * math.factorial(d - j - k))
                  * math.comb(n, j) * math.comb(n, k))
    return math.log(D) / math.log(S)


def _hill(pts, d, B, deadline):
    import random
    A = list(pts)
    a = np.array(A, dtype=np.int64)
    u, c = np.unique((a[:, None] + a[None, :]).ravel(), return_counts=True)
    sums = dict(zip(u.tolist(), c.tolist()))
    u, c = np.unique((a[:, None] - a[None, :]).ravel(), return_counts=True)
    diffs = dict(zip(u.tolist(), c.tolist()))
    del u, c, a
    S = set(A)
    units = [B ** i for i in range(d)]

    def change(p, sg):
        # A excludes p
        sg2 = 2 * sg
        for q in A:
            s = p + q
            c = sums.get(s, 0) + sg2
            if c:
                sums[s] = c
            else:
                del sums[s]
            k = p - q
            c = diffs.get(k, 0) + sg
            if c:
                diffs[k] = c
            else:
                del diffs[k]
            k = -k
            c = diffs.get(k, 0) + sg
            if c:
                diffs[k] = c
            else:
                del diffs[k]
        s = 2 * p
        c = sums.get(s, 0) + sg
        if c:
            sums[s] = c
        else:
            del sums[s]
        c = diffs.get(0, 0) + sg
        if c:
            diffs[0] = c
        else:
            del diffs[0]

    cur = math.log(len(diffs)) / math.log(len(sums))
    it = 0
    while time.time() < deadline:
        it += 1
        if random.random() < 0.5 and len(A) > 8:
            i = random.randrange(len(A))
            A[i], A[-1] = A[-1], A[i]
            p = A.pop()
            S.discard(p)
            change(p, -1)
            new = math.log(len(diffs)) / math.log(len(sums))
            if new >= cur and len(sums) > 1:
                cur = new
            else:
                change(p, 1)
                A.append(p)
                S.add(p)
        else:
            if len(A) >= 4000:
                continue
            base = random.choice(A)
            p = base + random.choice((-1, 1)) * random.choice(units)
            if p in S or abs(p) > 10 ** 14:
                continue
            change(p, 1)
            A.append(p)
            S.add(p)
            new = math.log(len(diffs)) / math.log(len(sums))
            if new >= cur:
                cur = new
            else:
                A.pop()
                S.discard(p)
                change(p, -1)
    return A


def solve():
    start = time.time()
    cands = []
    for d in range(1, 40):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000 or size < 4:
                continue
            if (2 * n + 3) ** d > 1e14:
                continue
            cands.append((_formula_score(d, n), d, n))
    cands.sort(reverse=True)
    if not cands:
        return [0, 1, 3]
    _, d, n = cands[0]
    base_pts = _simplex(d, n)
    base_score = _score_np(base_pts)
    best, best_score = base_pts, base_score
    try:
        B = 2 * n + 1
        res = _hill(base_pts, d, B, start + 95.0)
        res = sorted(set(int(v) for v in res))
        if all(abs(v) <= 10 ** 15 for v in res) and len(res) <= 4000:
            s = _score_np(res)
            if s > best_score:
                best, best_score = res, s
    except Exception:
        pass
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END