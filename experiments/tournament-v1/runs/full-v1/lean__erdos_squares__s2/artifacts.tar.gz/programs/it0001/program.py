# EVOLVE-BLOCK-START
"""Recursive grid/merge construction maximising sum of sides."""
import math
from functools import lru_cache


@lru_cache(maxsize=None)
def _f(n):
    """Return (value, descriptor) for n squares in a unit square."""
    if n == 0:
        return 0.0, ("empty",)
    if n == 1:
        return 1.0, ("one",)
    best = (-1.0, None)
    r = math.isqrt(n)
    if r * r < n:
        r += 1
    # grid with merged big squares
    for m in range(r, r + 7):
        for a in range(1, m):
            maxt = (m // a) ** 2
            for t in range(0, maxt + 1):
                units = m * m - t * a * a
                need = n - t
                if need < 0 or need > units:
                    continue
                val = (t * a + need) / m
                if val > best[0] + 1e-12:
                    best = (val, ("grid", m, a, t, need))
    # block splits
    for k in range(2, 6):
        B = k * k
        NEG = -1e18
        dp = [[NEG] * (n + 1) for _ in range(B + 1)]
        ch = [[0] * (n + 1) for _ in range(B + 1)]
        dp[0][0] = 0.0
        for j in range(1, B + 1):
            for c in range(n + 1):
                bv = NEG
                bc = 0
                for ni in range(0, min(c, n - 1) + 1):
                    p = dp[j - 1][c - ni]
                    if p <= NEG / 2:
                        continue
                    v = p + _f(ni)[0] / k
                    if v > bv:
                        bv = v
                        bc = ni
                dp[j][c] = bv
                ch[j][c] = bc
        if dp[B][n] > best[0] + 1e-12:
            alloc = []
            c = n
            for j in range(B, 0, -1):
                alloc.append(ch[j][c])
                c -= ch[j][c]
            best = (dp[B][n], ("split", k, tuple(alloc)))
    return best


def _build(n):
    """List of (cx, cy, side) in unit square."""
    val, d = _f(n)
    kind = d[0]
    if kind == "empty":
        return []
    if kind == "one":
        return [(0.5, 0.5, 1.0)]
    out = []
    if kind == "grid":
        _, m, a, t, need = d
        s = 1.0 / m
        covered = [[False] * m for _ in range(m)]
        per = m // a
        cnt = 0
        for bi in range(per):
            for bj in range(per):
                if cnt >= t:
                    break
                cnt += 1
                for x in range(a):
                    for y in range(a):
                        covered[bi * a + x][bj * a + y] = True
                out.append(((bi * a + a / 2) * s, (bj * a + a / 2) * s, a * s))
        u = 0
        for i in range(m):
            for j in range(m):
                if not covered[i][j] and u < need:
                    out.append(((i + 0.5) * s, (j + 0.5) * s, s))
                    u += 1
        return out
    _, k, alloc = d
    idx = 0
    for i in range(k):
        for j in range(k):
            ni = alloc[idx]
            idx += 1
            for (cx, cy, sd) in _build(ni):
                out.append(((i + cx) / k, (j + cy) / k, sd / k))
    return out


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    sq = _build(n)
    res = [(min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0, min(1.0, s)) for cx, cy, s in sq]
    res = res[:n]
    res += [(0.5, 0.5, 0.0, 0.0)] * (n - len(res))
    return res
# EVOLVE-BLOCK-END
