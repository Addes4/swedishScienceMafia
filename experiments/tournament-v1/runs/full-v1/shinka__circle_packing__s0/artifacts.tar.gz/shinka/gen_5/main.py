# EVOLVE-BLOCK-START
"""Baseline: a centre circle with two rings, radii shrunk until nothing overlaps.
Layout follows the ShinkaEvolve circle_packing example (Apache-2.0)."""
import numpy as np


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    from scipy.optimize import minimize
    t0 = time.time()
    budget = 240.0
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    m = len(I)
    ar = np.arange(m)

    def obj(z):
        return -np.sum(z[2 * n:])

    def obj_jac(z):
        g = np.zeros(3 * n)
        g[2 * n:] = -1.0
        return g

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        pair = (x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 - (r[I] + r[J]) ** 2
        return np.concatenate([pair, x - r, 1 - x - r, y - r, 1 - y - r])

    def cons_jac(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        Jm = np.zeros((m + 4 * n, 3 * n))
        dx = 2 * (x[I] - x[J])
        dy = 2 * (y[I] - y[J])
        dr = -2 * (r[I] + r[J])
        Jm[ar, I] = dx
        Jm[ar, J] = -dx
        Jm[ar, n + I] = dy
        Jm[ar, n + J] = -dy
        Jm[ar, 2 * n + I] = dr
        Jm[ar, 2 * n + J] = dr
        k = np.arange(n)
        Jm[m + k, k] = 1
        Jm[m + k, 2 * n + k] = -1
        Jm[m + n + k, k] = -1
        Jm[m + n + k, 2 * n + k] = -1
        Jm[m + 2 * n + k, n + k] = 1
        Jm[m + 2 * n + k, 2 * n + k] = -1
        Jm[m + 3 * n + k, n + k] = -1
        Jm[m + 3 * n + k, 2 * n + k] = -1
        return Jm

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def init(k):
        if best_c is not None and time.time() - t0 > 0.35 * budget and rng.random() < 0.85:
            c = best_c.copy()
            r = best_r.copy()
            mode = rng.integers(0, 3)
            if mode == 0:
                c = c + rng.normal(0, 0.005 + 0.05 * rng.random() ** 2, c.shape)
            elif mode == 1:
                kk = rng.integers(1, 4)
                order = np.argsort(r)
                for _ in range(kk):
                    if rng.random() < 0.6:
                        idx = order[rng.integers(0, min(8, n))]
                    else:
                        idx = rng.integers(0, n)
                    c[idx] = rng.random(2)
                    r[idx] = 0.02
                c = c + rng.normal(0, 0.003, c.shape)
            else:
                a, b = rng.choice(n, 2, replace=False)
                c[[a, b]] = c[[b, a]]
                c = c + rng.normal(0, 0.005, c.shape)
            c = np.clip(c, 0.02, 0.98)
            r = np.clip(r * 0.9, 0.01, 0.4)
            return np.concatenate([c[:, 0], c[:, 1], r])
        if k % 2 == 0:
            # jittered row layout
            rows = [5, 5, 6, 5, 5] if n == 26 else None
            if rows is None:
                c = rng.random((n, 2))
            else:
                pts = []
                for ri, cnt in enumerate(rows):
                    y = (ri + 0.5) / len(rows)
                    for ci in range(cnt):
                        pts.append([(ci + 0.5) / cnt, y])
                c = np.array(pts)
                c += rng.normal(0, 0.03 + 0.03 * rng.random(), c.shape)
        else:
            c = rng.random((n, 2))
        c = np.clip(c, 0.02, 0.98)
        r = np.full(n, 0.05) * (0.5 + rng.random(n))
        return np.concatenate([c[:, 0], c[:, 1], r])

    best_c, best_r, best_s = None, None, -1.0
    k = 0
    while time.time() - t0 < budget:
        z0 = init(k)
        k += 1
        try:
            res = minimize(obj, z0, jac=obj_jac, bounds=bounds, method='SLSQP',
                           constraints=[{'type': 'ineq', 'fun': cons, 'jac': cons_jac}],
                           options={'maxiter': 300, 'ftol': 1e-10})
        except Exception:
            continue
        z = res.x
        c = np.clip(np.stack([z[:n], z[n:2 * n]], axis=1), 0.0, 1.0)
        r = max_radii(c, np.clip(z[2 * n:], 0, None))
        s = float(np.sum(r))
        if s > best_s:
            best_c, best_r, best_s = c, r, s
    if best_c is None:
        c = rng.random((n, 2))
        return c, max_radii(c)
    return best_c, best_r


def max_radii(centers, init=None):
    """Largest radii for fixed centres: start from the wall distance (and optional init),
    then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    if init is not None:
        radii = np.minimum(radii, init)
    radii = np.maximum(radii, 0.0)
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j]) * (1 - 1e-13)
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END