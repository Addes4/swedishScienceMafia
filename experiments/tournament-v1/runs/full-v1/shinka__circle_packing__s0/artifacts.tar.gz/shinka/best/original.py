# EVOLVE-BLOCK-START
"""Baseline: a centre circle with two rings, radii shrunk until nothing overlaps.
Layout follows the ShinkaEvolve circle_packing example (Apache-2.0)."""
import numpy as np


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    t0 = time.time()
    budget = 120.0
    rng = np.random.default_rng(12345)

    base = [[0.5, 0.5]]
    base += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    base += [[0.5 + 0.4 * np.cos(2 * np.pi * i / 16), 0.5 + 0.4 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    base = np.array(base)

    def init(k):
        mode = k % 3
        if mode == 0 and n == 26:
            c = base + rng.normal(0, 0.04, base.shape)
        elif mode == 1:
            m = int(np.ceil(np.sqrt(n)))
            g = (np.arange(m) + 0.5) / m
            pts = np.array([[a, b] for a in g for b in g])
            idx = rng.permutation(len(pts))[:n]
            c = pts[idx] + rng.normal(0, 0.03, (n, 2))
        else:
            c = rng.uniform(0.08, 0.92, (n, 2))
        return np.clip(c, 0.02, 0.98)

    try:
        from scipy.optimize import minimize
    except Exception:
        return _fallback(n)

    iu, ju = np.triu_indices(n, 1)
    P = len(iu)
    ar = np.arange(P)

    def cons(v):
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        d = np.hypot(x[iu] - x[ju], y[iu] - y[ju])
        return np.concatenate([d - r[iu] - r[ju], x - r, 1 - x - r, y - r, 1 - y - r])

    def cjac(v):
        x, y = v[:n], v[n:2 * n]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        d = np.maximum(np.hypot(dx, dy), 1e-12)
        J = np.zeros((P + 4 * n, 3 * n))
        J[ar, iu] = dx / d
        J[ar, ju] = -dx / d
        J[ar, n + iu] = dy / d
        J[ar, n + ju] = -dy / d
        J[ar, 2 * n + iu] = -1
        J[ar, 2 * n + ju] = -1
        k = np.arange(n)
        J[P + k, k] = 1
        J[P + k, 2 * n + k] = -1
        J[P + n + k, k] = -1
        J[P + n + k, 2 * n + k] = -1
        J[P + 2 * n + k, n + k] = 1
        J[P + 2 * n + k, 2 * n + k] = -1
        J[P + 3 * n + k, n + k] = -1
        J[P + 3 * n + k, 2 * n + k] = -1
        return J

    gobj = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    best_s, best_c, best_r = -1.0, None, None
    k = 0
    while time.time() - t0 < budget:
        c0 = init(k)
        k += 1
        r0 = np.full(n, 0.03)
        v0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
        try:
            res = minimize(lambda v: -np.sum(v[2 * n:]), v0, jac=lambda v: gobj,
                           bounds=bounds, method='SLSQP',
                           constraints=[{'type': 'ineq', 'fun': cons, 'jac': cjac}],
                           options={'maxiter': 300, 'ftol': 1e-10})
        except Exception:
            continue
        v = res.x
        c = np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0, 1)
        r = _feasible_radii(c)
        s = r.sum()
        if s > best_s:
            best_s, best_c, best_r = s, c, r
    if best_c is None:
        return _fallback(n)
    return best_c, best_r


def _feasible_radii(c):
    """LP-optimal radii for fixed centres, then made strictly feasible."""
    n = len(c)
    try:
        from scipy.optimize import linprog
        iu, ju = np.triu_indices(n, 1)
        d = np.hypot(c[iu, 0] - c[ju, 0], c[iu, 1] - c[ju, 1])
        P = len(iu)
        A = np.zeros((P, n))
        A[np.arange(P), iu] = 1
        A[np.arange(P), ju] = 1
        wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, max(w, 0)) for w in wall],
                      method='highs')
        if res.success:
            r = np.maximum(res.x - 1e-12, 0.0)
            return max_radii_fix(c, r)
    except Exception:
        pass
    return max_radii(c)


def max_radii_fix(c, r):
    """Final safety shrink for any residual overlap."""
    n = len(c)
    r = r.copy()
    for _ in range(20):
        changed = False
        for i in range(n):
            d = np.hypot(c[i, 0] - c[i + 1:, 0], c[i, 1] - c[i + 1:, 1])
            over = r[i] + r[i + 1:] - d
            if np.any(over > 0):
                j = int(np.argmax(over))
                s = d[j] / (r[i] + r[i + 1 + j])
                r[i] *= s
                r[i + 1 + j] *= s
                changed = True
        if not changed:
            break
    return r


def _fallback(n):
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    centers += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()] for _ in range(n - len(centers))]
    centers = np.clip(np.array(centers[:n]), 0.01, 0.99)
    return centers, max_radii(centers)


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END