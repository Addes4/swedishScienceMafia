# EVOLVE-BLOCK-START
"""Baseline: a centre circle with two rings, radii shrunk until nothing overlaps.
Layout follows the ShinkaEvolve circle_packing example (Apache-2.0)."""
import numpy as np


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    import time
    from scipy.optimize import minimize, linprog

    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    P = len(I)
    rows = np.arange(P)

    def fun(z):
        return -np.sum(z[2 * n:])

    def fgrad(z):
        g = np.zeros(3 * n)
        g[2 * n:] = -1.0
        return g

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        s = r[I] + r[J]
        pair = dx * dx + dy * dy - s * s
        return np.concatenate([pair, x - r, 1 - x - r, y - r, 1 - y - r])

    def cjac(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        s = r[I] + r[J]
        Jm = np.zeros((P + 4 * n, 3 * n))
        Jm[rows, I] = 2 * dx
        Jm[rows, J] = -2 * dx
        Jm[rows, n + I] = 2 * dy
        Jm[rows, n + J] = -2 * dy
        Jm[rows, 2 * n + I] = -2 * s
        Jm[rows, 2 * n + J] = -2 * s
        k = np.arange(n)
        Jm[P + k, k] = 1
        Jm[P + k, 2 * n + k] = -1
        Jm[P + n + k, k] = -1
        Jm[P + n + k, 2 * n + k] = -1
        Jm[P + 2 * n + k, n + k] = 1
        Jm[P + 2 * n + k, 2 * n + k] = -1
        Jm[P + 3 * n + k, n + k] = -1
        Jm[P + 3 * n + k, 2 * n + k] = -1
        return Jm

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def run(c0):
        z0 = np.concatenate([c0[:, 0], c0[:, 1], np.full(n, 0.03)])
        try:
            res = minimize(fun, z0, jac=fgrad, bounds=bounds,
                           constraints=[{'type': 'ineq', 'fun': cons, 'jac': cjac}],
                           method='SLSQP', options={'maxiter': 300, 'ftol': 1e-10})
        except Exception:
            return None, -1.0
        z = res.x
        if cons(z).min() < -1e-7:
            return None, -1.0
        return z, float(np.sum(z[2 * n:]))

    best_z, best_s = None, -1.0
    while time.time() - t0 < budget:
        elapsed = time.time() - t0
        if best_z is None or elapsed < 0.35 * budget:
            c0 = rng.random((n, 2)) * 0.9 + 0.05
        else:
            c0 = np.stack([best_z[:n], best_z[n:2 * n]], axis=1).copy()
            r = best_z[2 * n:]
            k = rng.integers(1, 4)
            w = 1.0 / (r + 0.02)
            idx = rng.choice(n, size=k, replace=False, p=w / w.sum())
            c0[idx] = rng.random((k, 2)) * 0.9 + 0.05
            c0 += rng.normal(0, 0.01 * rng.random(), c0.shape)
            c0 = np.clip(c0, 0.02, 0.98)
        z, s = run(c0)
        if z is not None and s > best_s:
            best_z, best_s = z, s

    if best_z is None:
        c0 = rng.random((n, 2)) * 0.9 + 0.05
        return c0, max_radii(c0)

    centers = np.clip(np.stack([best_z[:n], best_z[n:2 * n]], axis=1), 0.0, 1.0)
    # optimal radii for fixed centres via LP
    try:
        D = np.linalg.norm(centers[I] - centers[J], axis=1)
        A = np.zeros((P, n))
        A[rows, I] = 1
        A[rows, J] = 1
        wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
        res = linprog(-np.ones(n), A_ub=A, b_ub=D, bounds=[(0, max(w_, 0)) for w_ in wall], method='highs')
        if res.status == 0:
            radii = np.maximum(res.x * (1 - 1e-12) - 1e-13, 0.0)
            return centers, radii
    except Exception:
        pass
    return centers, max_radii(centers) * (1 - 1e-12)


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END