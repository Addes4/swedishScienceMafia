import time
import numpy as np
from scipy.optimize import minimize, linprog


def _lp_radii(centers):
    n = len(centers)
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    iu, ju = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[iu] - centers[ju], axis=1)
    m = len(iu)
    A = np.zeros((m, n))
    A[np.arange(m), iu] = 1
    A[np.arange(m), ju] = 1
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status == 0:
        r = np.maximum(res.x, 0)
    else:
        r = np.zeros(n)
    return r


def _make(n):
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    ar = np.arange(m)
    idx = np.arange(n)

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        s = r[iu] + r[ju]
        return np.concatenate([dx * dx + dy * dy - s * s, x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        s = r[iu] + r[ju]
        J = np.zeros((m + 4 * n, 3 * n))
        J[ar, iu] = 2 * dx
        J[ar, ju] = -2 * dx
        J[ar, n + iu] = 2 * dy
        J[ar, n + ju] = -2 * dy
        J[ar, 2 * n + iu] = -2 * s
        J[ar, 2 * n + ju] = -2 * s
        o = m
        J[o + idx, idx] = 1; J[o + idx, 2 * n + idx] = -1
        o += n
        J[o + idx, idx] = -1; J[o + idx, 2 * n + idx] = -1
        o += n
        J[o + idx, n + idx] = 1; J[o + idx, 2 * n + idx] = -1
        o += n
        J[o + idx, n + idx] = -1; J[o + idx, 2 * n + idx] = -1
        return J

    return cons, jac


def solve(n=26):
    t0 = time.time()
    budget = 230.0
    rng = np.random.default_rng(12345)
    cons, jac = _make(n)
    c = np.zeros(3 * n)
    c[2 * n:] = -1
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    constraints = [{"type": "ineq", "fun": cons, "jac": jac}]

    def opt(xy, maxiter=200):
        r0 = np.full(n, 0.03)
        z0 = np.concatenate([xy[:, 0], xy[:, 1], r0])
        try:
            res = minimize(lambda z: -z[2 * n:].sum(), z0, jac=lambda z: c, bounds=bounds,
                           constraints=constraints, method="SLSQP",
                           options={"maxiter": maxiter, "ftol": 1e-11})
        except Exception:
            return None, -1
        z = res.x
        viol = cons(z).min()
        if viol < -1e-6:
            return z, z[2 * n:].sum() - 10 * (-viol)
        return z, z[2 * n:].sum()

    def init():
        k = rng.integers(0, 3)
        if k == 0:
            return rng.random((n, 2))
        if k == 1:
            # perturbed hex-ish grid
            rows = [5, 5, 5, 5, 6][:5]
            pts = []
            for i, cnt in enumerate([5, 5, 5, 5, 5, 1]):
                pass
            g = int(np.ceil(np.sqrt(n)))
            pts = [((i + 0.5 + 0.5 * (j % 2)) / (g + 0.5), (j + 0.5) / g) for j in range(g) for i in range(g)]
            pts = np.array(pts)
            pts = pts[rng.permutation(len(pts))[:n]]
            return pts + rng.normal(0, 0.03, pts.shape)
        g = int(np.ceil(np.sqrt(n)))
        pts = np.array([((i + 0.5) / g, (j + 0.5) / g) for i in range(g) for j in range(g)])
        pts = pts[rng.permutation(len(pts))[:n]]
        return pts + rng.normal(0, 0.04, pts.shape)

    best_z, best_v = None, -1
    cur_z, cur_v = None, -1
    it = 0
    while time.time() - t0 < budget:
        it += 1
        if best_z is None or it % 4 == 0 and it < 40 or rng.random() < 0.15:
            xy = np.clip(init(), 0.02, 0.98)
        else:
            base = best_z if rng.random() < 0.7 or cur_z is None else cur_z
            xy = np.stack([base[:n], base[n:2 * n]], 1).copy()
            r = base[2 * n:]
            mode = rng.integers(0, 3)
            if mode == 0:
                xy += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), xy.shape)
            elif mode == 1:
                k = rng.integers(1, 4)
                order = np.argsort(r)
                pick = order[:k + 2][rng.permutation(k + 2)[:k]]
                xy[pick] = rng.random((k, 2))
            else:
                i, j = rng.choice(n, 2, replace=False)
                if abs(r[i] - r[j]) > 1e-3:
                    xy[[i, j]] = xy[[j, i]]
                xy += rng.normal(0, 0.01, xy.shape)
            xy = np.clip(xy, 0.01, 0.99)
        z, v = opt(xy)
        if z is None:
            continue
        if v > best_v:
            best_v, best_z = v, z
        if v > cur_v - 0.02 or rng.random() < 0.1:
            cur_z, cur_v = z, v

    centers = np.stack([best_z[:n], best_z[n:2 * n]], 1)
    centers = np.clip(centers, 0, 1)
    radii = _lp_radii(centers) * (1 - 1e-12)
    return centers, radii
