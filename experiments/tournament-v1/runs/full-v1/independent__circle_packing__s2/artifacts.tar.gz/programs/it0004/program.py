import numpy as np
import time
from scipy.optimize import minimize, linprog

N_DEFAULT = 26


def lp_radii(c):
    n = len(c)
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    wall = np.maximum(wall, 0)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(c[I] - c[J], axis=1)
    m = len(I)
    A = np.zeros((m, n))
    A[np.arange(m), I] = 1
    A[np.arange(m), J] = 1
    res = linprog(-np.ones(n), A_ub=A, b_ub=d,
                  bounds=[(0, w) for w in wall], method="highs")
    if res.status != 0:
        return np.zeros(n)
    return np.maximum(res.x, 0)


def make_opt(n):
    I, J = np.triu_indices(n, 1)
    m = len(I)
    ar = np.arange(m)
    # wall constraints (linear): x-r, 1-x-r, y-r, 1-y-r
    W = np.zeros((4 * n, 3 * n))
    b = np.zeros(4 * n)
    for i in range(n):
        W[4 * i, 3 * i] = 1; W[4 * i, 3 * i + 2] = -1
        W[4 * i + 1, 3 * i] = -1; W[4 * i + 1, 3 * i + 2] = -1; b[4 * i + 1] = 1
        W[4 * i + 2, 3 * i + 1] = 1; W[4 * i + 2, 3 * i + 2] = -1
        W[4 * i + 3, 3 * i + 1] = -1; W[4 * i + 3, 3 * i + 2] = -1; b[4 * i + 3] = 1
    obj_g = np.zeros(3 * n)
    obj_g[2::3] = -1

    def fun(x):
        return -np.sum(x[2::3])

    def jac(x):
        return obj_g

    def cons(x):
        X = x[0::3]; Y = x[1::3]; R = x[2::3]
        dx = X[I] - X[J]; dy = Y[I] - Y[J]
        dist = np.sqrt(dx * dx + dy * dy) + 1e-300
        return np.concatenate([dist - R[I] - R[J], W @ x + b])

    def cjac(x):
        X = x[0::3]; Y = x[1::3]
        dx = X[I] - X[J]; dy = Y[I] - Y[J]
        dist = np.sqrt(dx * dx + dy * dy) + 1e-300
        Jm = np.zeros((m, 3 * n))
        Jm[ar, 3 * I] = dx / dist
        Jm[ar, 3 * J] = -dx / dist
        Jm[ar, 3 * I + 1] = dy / dist
        Jm[ar, 3 * J + 1] = -dy / dist
        Jm[ar, 3 * I + 2] = -1
        Jm[ar, 3 * J + 2] = -1
        return np.vstack([Jm, W])

    bounds = [(0, 1), (0, 1), (0, 0.5)] * n

    def run(c, r, maxiter=200):
        x0 = np.zeros(3 * n)
        x0[0::3] = c[:, 0]; x0[1::3] = c[:, 1]; x0[2::3] = r
        try:
            res = minimize(fun, x0, jac=jac, bounds=bounds, method="SLSQP",
                           constraints=[{"type": "ineq", "fun": cons, "jac": cjac}],
                           options={"maxiter": maxiter, "ftol": 1e-10})
            x = res.x
        except Exception:
            x = x0
        cc = np.stack([np.clip(x[0::3], 0, 1), np.clip(x[1::3], 0, 1)], axis=1)
        rr = lp_radii(cc)
        return cc, rr
    return run


def init_struct(n, rng):
    # perturbed row-based layouts
    kind = rng.integers(0, 3)
    pts = []
    if kind == 0:
        rows = [5, 5, 6, 5, 5]
        rows = list(rng.permutation(rows))
    elif kind == 1:
        rows = [4, 5, 4, 5, 4, 4]
    else:
        k = rng.integers(5, 7)
        rows = [n // k + (1 if i < n % k else 0) for i in range(k)]
        rows = list(rng.permutation(rows))
    nr = len(rows)
    for ri, cnt in enumerate(rows):
        y = (ri + 0.5) / nr
        for j in range(cnt):
            pts.append([(j + 0.5) / cnt, y])
    pts = np.array(pts[:n])
    while len(pts) < n:
        pts = np.vstack([pts, rng.random((1, 2))])
    pts += rng.normal(0, 0.03, pts.shape)
    return np.clip(pts, 0.03, 0.97)


def solve(n=26):
    t0 = time.time()
    TL = 235.0
    rng = np.random.default_rng(12345)
    run = make_opt(n)
    best = None
    best_s = -1

    def consider(c, r):
        nonlocal best, best_s
        s = r.sum()
        if s > best_s:
            best_s = s
            best = (c.copy(), r.copy())
        return s

    it = 0
    # initial multi-start phase
    while time.time() - t0 < TL * 0.35:
        if it % 2 == 0:
            c = init_struct(n, rng)
        else:
            c = rng.random((n, 2)) * 0.9 + 0.05
        r = np.full(n, 0.5 / np.sqrt(n) * 0.6)
        cc, rr = run(c, r)
        consider(cc, rr)
        it += 1
    # basin hopping from best
    cur_c, cur_r = best
    cur_s = best_s
    while time.time() - t0 < TL:
        c = cur_c.copy()
        r = cur_r.copy()
        mode = rng.integers(0, 3)
        if mode == 0:
            k = rng.integers(1, 4)
            idx = rng.choice(n, k, replace=False)
            c[idx] = rng.random((k, 2)) * 0.9 + 0.05
            r[idx] = 0.03
        elif mode == 1:
            c += rng.normal(0, 0.03, c.shape)
            c = np.clip(c, 0.02, 0.98)
        else:
            i, j = rng.choice(n, 2, replace=False)
            c[[i, j]] = c[[j, i]]
            c += rng.normal(0, 0.01, c.shape)
            c = np.clip(c, 0.02, 0.98)
        r = r * 0.7
        cc, rr = run(c, r)
        s = consider(cc, rr)
        if s > cur_s - 0.002 * rng.random():
            cur_c, cur_r, cur_s = cc, rr, s
        if rng.random() < 0.05:
            cur_c, cur_r = best
            cur_s = best_s
    c, r = best
    r = np.maximum(r - 1e-12, 0)
    return c, r
