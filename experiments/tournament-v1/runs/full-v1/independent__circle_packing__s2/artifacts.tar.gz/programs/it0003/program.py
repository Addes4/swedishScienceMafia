import time
import numpy as np
from scipy.optimize import minimize, linprog


def _lp_radii(c):
    n = len(c)
    I, J = np.triu_indices(n, 1)
    d = np.hypot(c[I, 0] - c[J, 0], c[I, 1] - c[J, 1])
    m = len(I)
    A = np.zeros((m, n))
    A[np.arange(m), I] = 1
    A[np.arange(m), J] = 1
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    wall = np.maximum(wall, 0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status == 0:
        return np.maximum(res.x, 0)
    return None


def solve(n=26):
    t0 = time.time()
    budget = 230.0
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    m = len(I)
    ar = np.arange(m)

    def obj(z):
        return -np.sum(z[2 * n:])

    def gobj(z):
        g = np.zeros(3 * n)
        g[2 * n:] = -1
        return g

    def cons(z):
        x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
        dx = x[I] - x[J]; dy = y[I] - y[J]; s = r[I] + r[J]
        return np.concatenate([x - r, 1 - x - r, y - r, 1 - y - r,
                               dx * dx + dy * dy - s * s])

    def jac(z):
        x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
        Jm = np.zeros((4 * n + m, 3 * n))
        k = np.arange(n)
        Jm[k, k] = 1; Jm[k, 2 * n + k] = -1
        Jm[n + k, k] = -1; Jm[n + k, 2 * n + k] = -1
        Jm[2 * n + k, n + k] = 1; Jm[2 * n + k, 2 * n + k] = -1
        Jm[3 * n + k, n + k] = -1; Jm[3 * n + k, 2 * n + k] = -1
        dx = x[I] - x[J]; dy = y[I] - y[J]; s = r[I] + r[J]
        rows = 4 * n + ar
        Jm[rows, I] = 2 * dx; Jm[rows, J] = -2 * dx
        Jm[rows, n + I] = 2 * dy; Jm[rows, n + J] = -2 * dy
        Jm[rows, 2 * n + I] = -2 * s; Jm[rows, 2 * n + J] = -2 * s
        return Jm

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def run(z0, maxiter=250):
        try:
            res = minimize(obj, z0, jac=gobj, bounds=bounds, method="SLSQP",
                           constraints=[{"type": "ineq", "fun": cons, "jac": jac}],
                           options={"maxiter": maxiter, "ftol": 1e-10})
            z = res.x
        except Exception:
            return None, -1
        c = np.column_stack([z[:n], z[n:2 * n]])
        c = np.clip(c, 0, 1)
        r = _lp_radii(c)
        if r is None:
            return None, -1
        return c, r.sum()

    best_c, best_s = None, -1
    it = 0
    while time.time() - t0 < budget:
        it += 1
        if best_c is None or it % 3 == 0:
            c0 = rng.uniform(0.05, 0.95, (n, 2))
            r0 = np.full(n, 0.05)
        else:
            c0 = best_c.copy()
            mode = rng.integers(3)
            if mode == 0:
                c0 += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), c0.shape)
            elif mode == 1:
                rb = _lp_radii(best_c)
                k = rng.integers(1, 4)
                idx = np.argsort(rb)[:k + 2]
                pick = rng.choice(idx, k, replace=False)
                c0[pick] = rng.uniform(0.05, 0.95, (k, 2))
                c0 += rng.normal(0, 0.01, c0.shape)
            else:
                a, b = rng.choice(n, 2, replace=False)
                c0[a] = rng.uniform(0.05, 0.95, 2)
                c0[b] += rng.normal(0, 0.05, 2)
            c0 = np.clip(c0, 0.02, 0.98)
            r0 = np.full(n, 0.06)
        z0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
        c, s = run(z0)
        if c is not None and s > best_s:
            best_c, best_s = c, s

    r = _lp_radii(best_c)
    r = np.maximum(r - 1e-12, 0)
    return best_c, r
