# EVOLVE-BLOCK-START
import math
import random
import time
import itertools


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _anneal(N, seed, tlimit, T0=0.012, T1=0.0006):
    cs = [0] * (2 * N + 1)
    cd = [0] * (2 * N + 1)
    A = []
    inA = [False] * (N + 1)
    st = [0, 0]  # ns, nd

    def add(x):
        ns, nd = st
        for a in A:
            s = x + a
            if cs[s] == 0:
                ns += 1
            cs[s] += 1
            d = x - a + N
            if cd[d] == 0:
                nd += 1
            cd[d] += 1
            d = a - x + N
            if cd[d] == 0:
                nd += 1
            cd[d] += 1
        s = 2 * x
        if cs[s] == 0:
            ns += 1
        cs[s] += 1
        if cd[N] == 0:
            nd += 1
        cd[N] += 1
        st[0], st[1] = ns, nd
        A.append(x)
        inA[x] = True

    def remove_at(i):
        x = A[i]
        A[i] = A[-1]
        A.pop()
        inA[x] = False
        ns, nd = st
        for a in A:
            s = x + a
            cs[s] -= 1
            if cs[s] == 0:
                ns -= 1
            d = x - a + N
            cd[d] -= 1
            if cd[d] == 0:
                nd -= 1
            d = a - x + N
            cd[d] -= 1
            if cd[d] == 0:
                nd -= 1
        s = 2 * x
        cs[s] -= 1
        if cs[s] == 0:
            ns -= 1
        cd[N] -= 1
        if cd[N] == 0:
            nd -= 1
        st[0], st[1] = ns, nd
        return x

    def f():
        if st[0] <= 1 or len(A) < 2:
            return 0.0
        return math.log(st[1]) / math.log(st[0])

    for x in seed:
        if 0 <= x <= N and not inA[x]:
            add(x)
    while len(A) < 4:
        x = random.randint(0, N)
        if not inA[x]:
            add(x)

    cur = f()
    best = cur
    bestA = A[:]
    start = time.time()
    it = 0
    T = T0
    frac = 0.0
    while True:
        it += 1
        if (it & 255) == 0:
            frac = (time.time() - start) / tlimit
            if frac >= 1:
                break
            T = T0 * (T1 / T0) ** frac
        r = random.random()
        n = len(A)
        if r < 0.15 and n < N:
            x = random.randint(0, N)
            if inA[x]:
                continue
            add(x)
            new = f()
            if new >= cur or random.random() < math.exp((new - cur) / T):
                cur = new
            else:
                remove_at(len(A) - 1)
        elif r < 0.30 and n > 4:
            i = random.randrange(n)
            x = remove_at(i)
            new = f()
            if new >= cur or random.random() < math.exp((new - cur) / T):
                cur = new
            else:
                add(x)
        else:
            i = random.randrange(n)
            old = A[i]
            if random.random() < 0.5:
                y = old + random.randint(-2, 2)
            else:
                y = random.randint(0, N)
            if y < 0 or y > N or inA[y]:
                continue
            remove_at(i)
            add(y)
            new = f()
            if new >= cur or random.random() < math.exp((new - cur) / T):
                cur = new
            else:
                remove_at(len(A) - 1)
                add(old)
        if cur > best + 1e-12:
            best = cur
            bestA = A[:]
    return best, bestA


def _simplex_seed(N, d, n, b):
    pts = set()
    for x in itertools.product(range(n + 1), repeat=d):
        if sum(x) <= n:
            v = sum(xi * (b ** i) for i, xi in enumerate(x))
            if v <= N:
                pts.add(v)
    return sorted(pts)


def _tensor(A, N):
    A = sorted(set(A))
    m = A[0]
    A = [a - m for a in A]
    N = A[-1]
    M = 2 * N + 2
    k = 1
    while (len(A) ** (k + 1) <= 4000) and (N * sum(M ** i for i in range(k + 1)) <= 1e15):
        k += 1
    res = [0]
    for i in range(k):
        res = [r + a * (M ** i) for r in res for a in A]
    return res


def solve():
    t0 = time.time()
    total = 105.0
    configs = [
        (40, "rand"), (60, "s3"), (50, "rand"), (80, "s2"),
        (70, "s3"), (60, "rand"), (45, "s2"), (80, "rand"),
    ]
    per = total / len(configs)
    best_s, best_A = -1.0, [0, 1, 3]
    for N, kind in configs:
        if time.time() - t0 > total:
            break
        if kind == "rand":
            seed = [x for x in range(N + 1) if random.random() < 0.3]
        elif kind == "s3":
            seed = _simplex_seed(N, 3, random.choice([3, 4, 5]), random.choice([3, 4, 5, 6]))
        else:
            seed = _simplex_seed(N, 2, random.choice([4, 5, 6, 7]), random.choice([3, 4, 5, 6, 8]))
        _, A = _anneal(N, seed, per)
        s = _score(A)
        if s > best_s:
            best_s, best_A = s, A[:]
    cand = _tensor(best_A, max(best_A))
    if len(cand) <= 4000 and _score(cand) >= best_s - 1e-9 if len(cand) < 1500 else True:
        return cand
    return sorted(set(best_A))
# EVOLVE-BLOCK-END
