# EVOLVE-BLOCK-START
import math
import random
import time
from itertools import combinations_with_replacement

import numpy as np


def _score(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    if len(a) < 2:
        return 0.0
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _sizes(d, k):
    nA = math.comb(k + d, d)
    nS = math.comb(2 * k + d, d)
    nD = 0
    for p in range(0, min(d, k) + 1):
        for n in range(0, min(d - p, k) + 1):
            mult = math.comb(d, p) * math.comb(d - p, n)
            nD += mult * math.comb(k - 1, p - 1) * math.comb(k - 1, n - 1) if (p > 0 and n > 0) else \
                mult * (math.comb(k, p) if n == 0 and p > 0 else 0) if False else 0
    # exact count: positive part sums to <=k with p positive coords: sum_{s<=k} C(s-1,p-1) = C(k,p)
    nD = 0
    for p in range(0, min(d, k) + 1):
        for n in range(0, min(d - p, k) + 1):
            mult = math.comb(d, p) * math.comb(d - p, n)
            nD += mult * math.comb(k, p) * math.comb(k, n)
    return nA, nS, nD


def _build(d, k, w):
    # w[0] = 0 (dummy), w[1..d] weights
    vals = set()
    for c in combinations_with_replacement(range(d + 1), k):
        vals.add(sum(w[i] for i in c))
    return sorted(vals)


def solve():
    LIMIT_N = 4000
    LIMIT_V = 10 ** 15
    t0 = time.time()
    cands = []
    for k in range(1, LIMIT_N):
        if math.comb(k + 1, 1) > LIMIT_N:
            break
        d = 1
        while True:
            nA = math.comb(k + d, d)
            if nA > LIMIT_N:
                break
            if nA >= 2:
                nA_, nS, nD = _sizes(d, k)
                ratio = math.log(nD) / math.log(nS)
                cands.append((ratio + (1 - 1 / nA) / 100, d, k))
            d += 1
    fallback = [7, 15, 18, 22, -3, -2]
    best_A = None
    best_sc = _score(fallback)
    best_A = sorted(set(fallback))
    try:
        cands.sort(reverse=True)
        rng = random.Random(12345)
        tries = 0
        for _, d, k in cands[:3]:
            for _ in range(3):
                if time.time() - t0 > 60 and tries > 0:
                    break
                wmax = LIMIT_V // k
                w = [0] + [rng.randint(1, wmax) for _ in range(d)]
                A = _build(d, k, w)
                if len(A) > LIMIT_N:
                    continue
                off = (A[0] + A[-1]) // 2
                A = [x - off for x in A]
                if max(abs(x) for x in A) > LIMIT_V:
                    continue
                tries += 1
                sc = _score(A)
                if sc > best_sc:
                    best_sc = sc
                    best_A = A
            if time.time() - t0 > 60:
                break
    except Exception:
        pass
    return best_A
# EVOLVE-BLOCK-END
