"""Local search in Z^d lattice to optimize difference vs sum sets."""
import math
import random
import time
from itertools import combinations


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _lattice_to_integers(points, basis):
    """Convert lattice points (tuples) to integers via basis."""
    result = []
    for p in points:
        val = sum(p[i] * basis[i] for i in range(len(p)))
        result.append(val)
    return result


def _search_in_dimension(d, max_coord, time_limit):
    """Local search in Z^d lattice."""
    best_score = -float('inf')
    best_set = None
    
    # Create a basis that spreads out well
    basis = []
    for i in range(d):
        basis.append(2 ** (10 * i) + random.randint(1, 100))
    
    deadline = time.time() + time_limit
    
    # Start with simplex lattice
    current_points = set()
    for i in range(d):
        current_points.add(tuple([1 if j == i else 0 for j in range(d)]))
    current_points.add(tuple([0] * d))
    
    current_integers = _lattice_to_integers(list(current_points), basis)
    current_score = _score(current_integers)
    best_score = current_score
    best_set = current_points.copy()
    best_integers = current_integers
    
    iterations = 0
    no_improve = 0
    max_no_improve = 100
    
    while time.time() < deadline and no_improve < max_no_improve:
        iterations += 1
        
        # Try adding a neighbor point
        if random.random() < 0.6 and len(current_points) < 40:
            # Generate a candidate neighbor
            p = random.choice(list(current_points))
            direction = tuple([random.randint(-1, 1) for _ in range(d)])
            candidate_point = tuple(p[i] + direction[i] for i in range(d))
            
            if candidate_point not in current_points and all(-max_coord <= candidate_point[i] <= max_coord for i in range(d)):
                candidate_points = current_points | {candidate_point}
                candidate_integers = _lattice_to_integers(list(candidate_points), basis)
                candidate_score = _score(candidate_integers)
                
                if candidate_score > current_score:
                    current_points = candidate_points
                    current_integers = candidate_integers
                    current_score = candidate_score
                    no_improve = 0
                    if candidate_score > best_score:
                        best_score = candidate_score
                        best_set = candidate_points.copy()
                        best_integers = candidate_integers
                else:
                    no_improve += 1
            else:
                no_improve += 1
        else:
            # Try removing a point
            if len(current_points) > 2:
                p = random.choice(list(current_points))
                candidate_points = current_points - {p}
                candidate_integers = _lattice_to_integers(list(candidate_points), basis)
                candidate_score = _score(candidate_integers)
                
                if candidate_score > current_score:
                    current_points = candidate_points
                    current_integers = candidate_integers
                    current_score = candidate_score
                    no_improve = 0
                    if candidate_score > best_score:
                        best_score = candidate_score
                        best_set = candidate_points.copy()
                        best_integers = candidate_integers
                else:
                    no_improve += 1
            else:
                no_improve += 1
    
    return best_integers, best_score


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    deadline = time.time() + 110
    
    best_overall = None
    best_overall_score = -float('inf')
    
    # Try different dimensions
    for d in range(2, 6):
        if time.time() >= deadline:
            break
        
        remaining = deadline - time.time()
        time_for_d = remaining / (6 - d)
        
        for trial in range(3):
            if time.time() >= deadline:
                break
            
            result, score = _search_in_dimension(d, max_coord=15, time_limit=time_for_d / 3)
            
            if score > best_overall_score:
                best_overall_score = score
                best_overall = result
    
    # Final refinement with direct random search
    if best_overall is not None:
        cur = best_overall[:]
        cur_score = _score(cur)
        
        while time.time() < deadline:
            cand = cur[:]
            if random.random() < 0.5 and len(cand) < 100:
                cand.append(random.randint(-1000, 1000))
            elif random.random() < 0.3 and len(cand) > 5:
                cand.pop(random.randrange(len(cand)))
            else:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-10, 10)
            
            s = _score(cand)
            if s >= cur_score:
                cur = cand[:]
                cur_score = s
                if cur_score > best_overall_score:
                    best_overall = cur[:]
                    best_overall_score = cur_score
    
    return sorted(set(best_overall if best_overall else [0, 1, 3, 7]))
