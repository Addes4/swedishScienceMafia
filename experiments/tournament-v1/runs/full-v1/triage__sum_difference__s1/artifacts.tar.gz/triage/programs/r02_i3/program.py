# EVOLVE-BLOCK-START
import math
import random
import time

import numpy as np


def _score(a):
    a = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    if len(a) < 2:
        return 0.0
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _sizes(d, k):
    nA = math.comb(k + d, d)
    nS = math.comb(2 * k + d, d)
    nD = 0
    fd = math.factorial(d)
    for p in range(0, min(d, k) + 1):
        for n in range(0, min(d - p, k) + 1):
            mult = fd // (math.factorial(p) * math.factorial(n) * math.factorial(d - p - n))
            nD += mult * math.comb(k, p) * math.comb(k, n)
    return nA, nS, nD


def _gen_simplex(d, k):
    vec = np.zeros((1, 0), dtype=np.int64)
    tot = np.zeros(1, dtype=np.int64)
    for _ in range(d):
        vs, ts = [], []
        for v in range(0, k + 1):
            m = tot + v <= k
            if not m.any():
                break
            c = vec[m]
            vs.append(np.concatenate([c, np.full((c.shape[0], 1), v, dtype=np.int64)], axis=1))
            ts.append(tot[m] + v)
        vec = np.concatenate(vs)
        tot = np.concatenate(ts)
    return vec


def _gen_diff(d, k):
    vec = np.zeros((1, 0), dtype=np.int64)
    pos = np.zeros(1, dtype=np.int64)
    neg = np.zeros(1, dtype=np.int64)
    for _ in range(d):
        vs, ps, ns = [], [], []
        for v in range(-k, k + 1):
            if v >= 0:
                m = pos + v <= k
                np_, nn_ = pos[m] + v, neg[m]
            else:
                m = neg - v <= k
                np_, nn_ = pos[m], neg[m] - v
            c = vec[m]
            vs.append(np.concatenate([c, np.full((c.shape[0], 1), v, dtype=np.int64)], axis=1))
            ps.append(np_)
            ns.append(nn_)
        vec = np.concatenate(vs)
        pos = np.concatenate(ps)
        neg = np.concatenate(ns)
    return vec


def _ratio_from(S, D, w):
    s = np.unique(S @ w).size
    dd = np.unique(D @ w).size
    if s < 2:
        return 0.0
    return math.log(dd) / math.log(s)


def _anneal(d, k, P, S, D, t_end, rng):
    M = 2 * k + 1
    Wmax = max(10, min(10 ** 14 // k, 10 ** 12))
    cands = []
    if M ** d <= 10 ** 14:
        cands.append(np.array([M ** i for i in range(d)], dtype=np.int64))
    nS = S.shape[0]
    for R in (nS, 4 * nS, 30 * nS, 1000 * nS):
        R = min(R, Wmax)
        cands.append(np.array([rng.randint(1, R) for _ in range(d)], dtype=np.int64))
    best_w, best_f = None, -1
    for w in cands:
        f = _ratio_from(S, D, w)
        if f > best_f:
            best_f, best_w = f, w.copy()
        if time.time() > t_end:
            break
    cur_w, cur_f = best_w.copy(), best_f
    t0 = time.time()
    total = max(1e-3, t_end - t0)
    logW = math.log(Wmax)
    while True:
        now = time.time()
        if now > t_end:
            break
        frac = (now - t0) / total
        T = 0.004 * (1 - frac) + 0.0002
        w = cur_w.copy()
        i = rng.randrange(d)
        if rng.random() < 0.4:
            R = int(math.exp(rng.uniform(0, logW)))
            w[i] = rng.randint(-R, R)
        else:
            dl = int(math.exp(rng.uniform(0, logW)))
            w[i] = w[i] + rng.randint(-dl, dl)
        if abs(int(w[i])) > Wmax:
            continue
        f = _ratio_from(S, D, w)
        if f >= cur_f or rng.random() < math.exp((f - cur_f) / T):
            cur_w, cur_f = w, f
            if f > best_f:
                best_f, best_w = f, w.copy()
    return best_f, best_w


def _exact_set(d, k):
    M = 2 * k + 1
    P = _gen_simplex(d, k)
    w = np.array([M ** i for i in range(d)], dtype=np.int64)
    return sorted(set((P @ w).tolist()))


def solve():
    t_start = time.time()
    rng = random.Random(12345)
    LIMIT_N = 4000
    fallback = sorted(set([7, 15, 18, 22, -3, -2]))

    configs = []
    for d in range(2, 14):
        for k in range(2, 14):
            nA, nS, nD = _sizes(d, k)
            if nA > LIMIT_N or nA < 20 or nD > 120000:
                continue
            ratio = math.log(nD) / math.log(nS)
            configs.append((ratio + (1 - 1 / nA) / 100, d, k, nA, nS, nD))
    configs.sort(reverse=True)
    # diversify: top few by exact ratio
    chosen = configs[:4]

    # baseline: best exact config
    best_set = fallback
    best_sc = _score(fallback)
    results = []
    budget = 95.0
    for idx, (sc, d, k, nA, nS, nD) in enumerate(chosen):
        remaining = budget - (time.time() - t_start)
        if remaining <= 2:
            break
        share = remaining / (len(chosen) - idx)
        t_end = time.time() + share
        try:
            P = _gen_simplex(d, k)
            S = _gen_simplex(d, 2 * k)
            D = _gen_diff(d, k)
            f, w = _anneal(d, k, P, S, D, t_end, rng)
            A = np.unique(P @ w)
            bonus = (1 - 1 / len(A)) / 100
            results.append((f + bonus, w, P, d, k))
        except Exception:
            continue

    results.sort(key=lambda r: -r[0])
    for est, w, P, d, k in results[:2]:
        try:
            A = sorted(set(int(x) for x in (P @ w)))
            off = (A[0] + A[-1]) // 2
            A = [x - off for x in A]
            if len(A) <= LIMIT_N and max(abs(x) for x in A) <= 10 ** 15:
                s = _score(A)
                if s > best_sc:
                    best_sc, best_set = s, A
        except Exception:
            pass

    # also try exact encoding of the best exact config as safety
    try:
        if chosen:
            _, d, k, nA, nS, nD = chosen[0]
            A = _exact_set(d, k)
            off = (A[0] + A[-1]) // 2
            A = [x - off for x in A]
            if len(A) <= LIMIT_N and max(abs(x) for x in A) <= 10 ** 15:
                s = _score(A)
                if s > best_sc:
                    best_sc, best_set = s, A
    except Exception:
        pass
    return best_set
# EVOLVE-BLOCK-END
