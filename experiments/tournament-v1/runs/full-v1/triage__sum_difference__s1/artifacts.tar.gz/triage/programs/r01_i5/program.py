# EVOLVE-BLOCK-START
import math
import itertools


def _simplex_stats(d, n):
    size = math.comb(n + d, d)
    S = math.comb(2 * n + d, d)
    D = 0
    for a in range(0, min(d, n) + 1):
        for b in range(0, min(d - a, n) + 1):
            D += (math.factorial(d) // (math.factorial(a) * math.factorial(b)
                  * math.factorial(d - a - b))) * math.comb(n, a) * math.comb(n, b)
    return size, S, D


def _gen_simplex(d, n):
    res = []

    def rec(pos, rem, cur):
        if pos == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(pos + 1, rem - v, cur)
            cur.pop()
    rec(0, n, [])
    return res


def _embed(d, n):
    base = 2 * n + 1
    pts = _gen_simplex(d, n)
    out = []
    for p in pts:
        v = 0
        for x in reversed(p):
            v = v * base + x
        out.append(v)
    return out, base ** d


def solve():
    LIM = 10 ** 15
    MAXSIZE = 4000
    singles = []
    for n in range(1, 200):
        for d in range(1, 60):
            size = math.comb(n + d, d)
            if size > MAXSIZE:
                break
            rng = (2 * n + 1) ** d
            if rng > LIM:
                break
            if size < 2:
                continue
            s, S, D = _simplex_stats(d, n)
            singles.append((d, n, size, rng, math.log(D), math.log(S)))

    best = None
    best_sc = -1.0

    def consider(combo):
        nonlocal best, best_sc
        size = 1
        lD = 0.0
        lS = 0.0
        for f in combo:
            size *= f[2]
            lD += f[4]
            lS += f[5]
        sc = lD / lS + (1 - 1 / size) / 100
        if sc > best_sc:
            best_sc = sc
            best = list(combo)

    def rec(start, combo, size, rng):
        if combo:
            consider(combo)
        if len(combo) >= 3:
            return
        for i in range(start, len(singles)):
            f = singles[i]
            if size * f[2] > MAXSIZE or rng * f[3] > LIM:
                continue
            combo.append(f)
            rec(i, combo, size * f[2], rng * f[3])
            combo.pop()

    rec(0, [], 1, 1)
    if best is None:
        return [0, 1, 3]

    A = [0]
    mult = 1
    for f in best:
        pts, rng = _embed(f[0], f[1])
        A = [a + mult * p for a in A for p in pts]
        mult *= rng
    A = sorted(set(A))
    return A
# EVOLVE-BLOCK-END
