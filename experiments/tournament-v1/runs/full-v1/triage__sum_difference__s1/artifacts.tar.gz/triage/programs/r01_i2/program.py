"""
Generalized simplex polytope search with sumset/difference-set optimization.
"""
import math
import random
import time
from itertools import combinations


def _score(a):
    """Score based on log|A - A| / log|A + A|."""
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _generate_simplex(n, k, weights=None):
    """Generate points on a simplex: sum of coordinates <= k."""
    if weights is None:
        weights = [1] * n
    points = []
    
    def generate(idx, remaining, current):
        if idx == n:
            if remaining >= 0:
                points.append(current[:])
            return
        for val in range(min(remaining // weights[idx] + 1, 20) if weights[idx] > 0 else 1):
            current.append(val)
            generate(idx + 1, remaining - val * weights[idx], current)
            current.pop()
    
    generate(0, k, [])
    return points


def _generate_product_simplex(dims, k):
    """Generate product of simplices with different dimensions."""
    points = []
    
    def generate(dim_idx, remaining, current):
        if dim_idx == len(dims):
            if remaining >= 0:
                points.append(current[:])
            return
        d = dims[dim_idx]
        for val in range(min(remaining + 1, 15)):
            current.append(val)
            generate(dim_idx + 1, remaining - val, current)
            current.pop()
    
    generate(0, k, [])
    return points


def _polytope_to_integers(points, base=10, offset_base=1000):
    """Convert polytope points to integers using mixed radix encoding."""
    if not points:
        return []
    
    # Encode each point as a unique integer
    integers = []
    for point in points:
        val = 0
        for i, coord in enumerate(point):
            val = val * (base + 1) + coord
        integers.append(val)
    
    # Also add negatives for asymmetry
    integers.extend([-x for x in integers if x > 0])
    return sorted(set(integers))


def _amplify_set(a, rounds=3, perturbation=5):
    """Amplify a good set by local search and duplication."""
    a = sorted(set(a))
    best = a[:]
    best_score = _score(best)
    
    for _ in range(rounds):
        # Try adding scaled copies
        for scale in [2, 3, -1, -2]:
            cand = best + [x * scale for x in a if x * scale not in best]
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s
        
        # Try local perturbations
        for _ in range(10):
            cand = best[:]
            if random.random() < 0.5 and len(cand) > 2:
                idx = random.randrange(len(cand))
                cand[idx] += random.randint(-perturbation, perturbation)
            else:
                cand.append(random.randint(1, 50))
            
            cand = sorted(set(cand))
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s
    
    return best, best_score


def solve():
    """Find optimal set using generalized simplex polytopes."""
    deadline = time.time() + 110
    best_overall = []
    best_overall_score = 0.0
    
    # Try different polytope configurations
    configs = [
        # Single simplex of increasing size
        (1, [5], None),
        (1, [6], None),
        (1, [7], None),
        # Product of simplices
        (2, [3, 3], None),
        (2, [4, 3], None),
        (2, [3, 4], None),
        (3, [2, 2, 2], None),
        (3, [3, 2, 2], None),
        # Weighted simplices
        (2, [5], [1, 2]),
        (2, [6], [1, 2]),
        (3, [6], [1, 1, 2]),
    ]
    
    for config_idx, config in enumerate(configs):
        if time.time() > deadline:
            break
        
        if len(config) == 3:
            n, ks, weights = config
            if weights:
                points = _generate_simplex(n, ks[0], weights)
            else:
                points = _generate_simplex(n, ks[0])
        else:
            dims, k = config[:2]
            dims_list = [dims] * k if isinstance(dims, int) else dims
            points = _generate_product_simplex(dims_list, 5)
        
        # Convert to integers
        integers = _polytope_to_integers(points, base=7 + config_idx % 3)
        
        if len(integers) > 2:
            # Amplify the set
            amp_set, amp_score = _amplify_set(integers, rounds=2)
            
            if amp_score > best_overall_score:
                best_overall = amp_set[:]
                best_overall_score = amp_score
    
    # Final intensive local search
    if best_overall:
        cur = best_overall[:]
        deadline_final = time.time() + 15
        
        while time.time() < deadline_final:
            cand = cur[:]
            
            # Mix of operations
            r = random.random()
            if r < 0.4:
                # Modify existing element
                i = random.randrange(len(cand))
                cand[i] += random.randint(-2, 2)
            elif r < 0.6:
                # Add new element
                new_val = random.randint(-100, 100)
                if new_val not in cand:
                    cand.append(new_val)
            elif r < 0.8 and len(cand) > 3:
                # Remove element
                cand.pop(random.randrange(len(cand)))
            else:
                # Scale operation
                scale = random.choice([2, 3, -1])
                for x in list(cand):
                    if x * scale not in cand and abs(x * scale) < 1e15:
                        cand.append(x * scale)
            
            cand = sorted(list(set(cand)))
            s = _score(cand)
            
            if s > best_overall_score:
                best_overall, best_overall_score = cand, s
                cur = cand[:]
            elif random.random() < 0.15:
                cur = best_overall[:]
    
    return sorted(list(set(best_overall)))
