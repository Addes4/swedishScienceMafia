# EVOLVE-BLOCK-START
import math
import random
import time

import numpy as np


def _score(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    if len(a) < 2:
        return 0.0
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _count(d, k, c):
    # number of d-tuples with entries in [0,c], sum <= k (capped)
    CAP = 10 ** 12
    dp = np.zeros(k + 1, dtype=np.int64)
    dp[0] = 1
    for _ in range(d):
        cs = np.cumsum(dp)
        new = cs.copy()
        if k + 1 > c + 1:
            new[c + 1:] -= cs[:k - c]
        dp = np.minimum(new, CAP)
    return int(dp.sum())


def _build(d, k, c):
    M = 2 * c + 1
    v = np.zeros(1, dtype=np.int64)
    s = np.zeros(1, dtype=np.int64)
    for i in range(d):
        w = M ** i
        vs = []
        ss = []
        for x in range(c + 1):
            mask = s + x <= k
            if not mask.any():
                break
            vs.append(v[mask] + x * w)
            ss.append(s[mask] + x)
        v = np.concatenate(vs)
        s = np.concatenate(ss)
    return v


def _ratio(v):
    n = len(v)
    D = np.unique((v[:, None] - v[None, :]).ravel()).size
    S = np.unique((v[:, None] + v[None, :]).ravel()).size
    return math.log(D) / math.log(S) + (1 - 1 / n) / 100


def solve():
    t0 = time.time()
    LIMIT_N = 4000
    LIMIT_V = 10 ** 15
    TL = 95.0
    cands = []
    for c in range(1, 13):
        M = 2 * c + 1
        for d in range(2, 60):
            if M ** d > LIMIT_V:
                break
            if _count(d, c, c) > LIMIT_N:
                break
            for k in range(c, c * d + 1):
                n = _count(d, k, c)
                if n > LIMIT_N:
                    break
                if n >= 20:
                    cands.append((n, d, k, c))
                if k == c * d:
                    break
    best = None
    bestv = None

    def run(cand):
        nonlocal best, bestv
        n, d, k, c = cand
        try:
            v = _build(d, k, c)
            if len(v) < 2 or len(v) > LIMIT_N:
                return
            sc = _ratio(v)
        except Exception:
            return
        if best is None or sc > best:
            best = sc
            bestv = v

    small = [x for x in cands if x[0] <= 600]
    large = [x for x in cands if x[0] > 600]
    random.seed(1)
    random.shuffle(small)
    random.shuffle(large)
    for cand in small:
        if time.time() - t0 > 30:
            break
        run(cand)
    for cand in large:
        el = time.time() - t0
        n = cand[0]
        est = n * n * 2.5e-7 + 0.05
        if el + est > TL:
            continue
        run(cand)

    fallback = [7, 15, 18, 22, -3, -2]
    try:
        A = sorted(set(int(x) for x in bestv))
        off = (A[0] + A[-1]) // 2
        A = [x - off for x in A]
        if len(A) <= LIMIT_N and max(abs(x) for x in A) <= LIMIT_V:
            if best is not None and best >= _score(fallback):
                return A
    except Exception:
        pass
    return sorted(set(fallback))
# EVOLVE-BLOCK-END
