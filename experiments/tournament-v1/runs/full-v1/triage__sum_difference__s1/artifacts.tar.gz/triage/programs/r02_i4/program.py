import math
import random
import time
from itertools import product

import numpy as np


def _score(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    if len(a) < 2:
        return 0.0
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _simplex_points(d, k):
    """Generate simplex points: tuples summing to k in d dimensions."""
    pts = []
    
    def rec(prefix, rem, left):
        if left == 0:
            pts.append(tuple(prefix))
            return
        for v in range(rem + 1):
            prefix.append(v)
            rec(prefix, rem - v, left - 1)
            prefix.pop()
    
    rec([], k, d)
    return pts


def _thinned_simplex(d, k, thin_factor=1):
    """Generate thinned simplex points by sampling."""
    pts = _simplex_points(d, k)
    if thin_factor <= 1:
        return pts
    step = max(1, len(pts) // thin_factor)
    return pts[::step]


def _estimate_size(d, k):
    """Estimate |A| for simplex with d dimensions, weight k."""
    return math.comb(d + k, k)


def _estimate_diff_size(d, k):
    """Estimate |A - A| for simplex."""
    nA = math.comb(d + k, k)
    if nA < 2:
        return 1
    fd = math.factorial(d)
    nD = 0
    for p in range(min(d, k) + 1):
        for n in range(min(d - p, k) + 1):
            mult = fd // (math.factorial(p) * math.factorial(n) * math.factorial(d - p - n))
            nD += mult * math.comb(k, p) * math.comb(k, n)
    return nD


def _estimate_sum_size(d, k):
    """Estimate |A + A| for simplex."""
    return math.comb(2 * (d + k), d)


def _build_simplex(d, k, base_val=1):
    """Build simplex points scaled by base_val."""
    pts = _simplex_points(d, k)
    return [base_val * sum(x * (10 ** i) for i, x in enumerate(p)) for p in pts]


def _build_multilevel(levels):
    """
    Build multi-level set from list of (d, k) tuples.
    Each level is a separate base-multiplied simplex.
    levels: list of (d, k) tuples
    """
    all_vals = []
    base_multiplier = 1
    
    for d, k in levels:
        pts = _simplex_points(d, k)
        for p in pts:
            val = base_multiplier * sum(x * (10 ** i) for i, x in enumerate(p))
            all_vals.append(val)
        
        # Scale base multiplier for next level
        max_val = base_multiplier * sum(k * (10 ** i) for i in range(d))
        base_multiplier = max_val * 100
    
    return sorted(set(all_vals))


def _find_best_config():
    """Find best configuration respecting constraints."""
    LIMIT_N = 4000
    LIMIT_V = 10 ** 15
    
    best_score = -1
    best_config = None
    
    # Try single-level configurations
    for d in range(1, 50):
        for k in range(1, 40):
            nA = _estimate_size(d, k)
            if nA > LIMIT_N or nA < 2:
                continue
            
            # Estimate magnitude
            M = 10 ** d
            if M > LIMIT_V:
                continue
            
            nD = _estimate_diff_size(d, k)
            nS = _estimate_sum_size(d, k)
            
            if nS < 2:
                continue
            
            score = math.log(nD) / math.log(nS) + (1 - 1 / nA) / 100
            
            if score > best_score:
                best_score = score
                best_config = [(d, k)]
    
    # Try two-level configurations
    for d1 in range(1, 25):
        for k1 in range(1, 20):
            nA1 = _estimate_size(d1, k1)
            if nA1 < 2 or nA1 > 500:
                continue
            
            for d2 in range(1, 25):
                for k2 in range(1, 20):
                    nA2 = _estimate_size(d2, k2)
                    total_nA = nA1 * nA2
                    
                    if total_nA > LIMIT_N or total_nA < 2:
                        continue
                    
                    M1 = 10 ** d1
                    M2 = 10 ** d2 * (M1 * k1 * 100) ** nA1
                    
                    if M2 > LIMIT_V:
                        continue
                    
                    nD1 = _estimate_diff_size(d1, k1)
                    nD2 = _estimate_diff_size(d2, k2)
                    nD = nD1 * nD2
                    
                    nS1 = _estimate_sum_size(d1, k1)
                    nS2 = _estimate_sum_size(d2, k2)
                    nS = nS1 * nS2
                    
                    if nS < 2:
                        continue
                    
                    score = math.log(nD) / math.log(nS) + (1 - 1 / total_nA) / 100
                    
                    if score > best_score:
                        best_score = score
                        best_config = [(d1, k1), (d2, k2)]
    
    return best_config if best_config else [(3, 3)]


def solve():
    LIMIT_N = 4000
    LIMIT_V = 10 ** 15
    
    fallback = [7, 15, 18, 22, -3, -2]
    
    try:
        config = _find_best_config()
        A = _build_multilevel(config)
        
        # Center and validate
        if A:
            off = (A[0] + A[-1]) // 2
            A = [x - off for x in A]
        
        if len(A) <= LIMIT_N and max(abs(x) for x in A) <= LIMIT_V and len(A) >= 2:
            if _score(A) >= _score(fallback):
                return A
    except Exception:
        pass
    
    return sorted(set(fallback))
