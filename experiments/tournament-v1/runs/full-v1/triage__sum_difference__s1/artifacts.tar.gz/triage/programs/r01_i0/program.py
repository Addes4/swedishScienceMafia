import math
import itertools
import numpy as np


def _points(d, n):
    res = []

    def rec(pref, rem, left):
        if left == 0:
            res.append(tuple(pref))
            return
        for v in range(rem + 1):
            pref.append(v)
            rec(pref, rem - v, left - 1)
            pref.pop()

    rec([], n, d)
    return res


def _counts(d, n):
    s = math.comb(2 * n + d, d)
    df = 0
    for i in range(d + 1):
        for j in range(d - i + 1):
            df += math.comb(d, i) * math.comb(d - i, j) * math.comb(n, i) * math.comb(n, j)
    return df, s


def solve():
    best = None
    for d in range(1, 16):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            df, s = _counts(d, n)
            ratio = math.log(df) / math.log(s)
            base = 2 * n + 1
            k = 1
            while True:
                if size ** k > 4000 or base ** (d * k) > 1e15:
                    break
                tot = size ** k
                sc = ratio + (1 - 1 / tot) / 100
                if best is None or sc > best[0]:
                    best = (sc, d, n, k)
                k += 1
    _, d, n, k = best
    base = 2 * n + 1
    pts = _points(d, n)
    vals = np.array([sum(x * base ** i for i, x in enumerate(p)) for p in pts], dtype=np.int64)
    cur = np.array([0], dtype=np.int64)
    shift = base ** d
    for j in range(k):
        cur = (cur[:, None] + vals[None, :] * (shift ** j)).ravel()
    return [int(x) for x in np.unique(cur)]
