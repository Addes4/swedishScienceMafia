import math
import random
import time
from collections import defaultdict
import numpy as np


def _score(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    if len(a) < 2:
        return 0.0
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _simplex_points(d, k):
    """Generate all points in kΔ ⊂ Z^d: non-negative integers summing to k."""
    pts = []
    
    def rec(prefix, rem, left):
        if left == 0:
            pts.append(tuple(prefix))
            return
        for v in range(rem + 1):
            prefix.append(v)
            rec(prefix, rem - v, left - 1)
            prefix.pop()
    
    rec([], k, d)
    return pts


def _points_to_integers(pts, base_mult):
    """Convert simplex points to integers using mixed radix."""
    return [sum(x * (base_mult ** i) for i, x in enumerate(p)) for p in pts]


def _compute_diffs_sums(A):
    """Compute |A - A| and |A + A| directly."""
    A = sorted(set(A))
    diffs = set()
    sums = set()
    for i, a in enumerate(A):
        for b in A:
            diffs.add(a - b)
            sums.add(a + b)
    return len(diffs), len(sums)


def _simulated_annealing(initial_set, max_time=60):
    """Optimize subset of simplex points using simulated annealing."""
    best_set = sorted(set(initial_set))
    best_score = _score(best_set)
    
    current_set = best_set[:]
    current_score = best_score
    
    candidate_pool = sorted(set(initial_set))
    start_time = time.time()
    iteration = 0
    
    temperature = 1.0
    cooling_rate = 0.995
    min_temp = 0.01
    
    while time.time() - start_time < max_time and temperature > min_temp:
        iteration += 1
        
        # Propose move: add or remove a point
        if random.random() < 0.6 and len(current_set) < len(candidate_pool):
            # Add a random candidate not in current set
            candidates = [x for x in candidate_pool if x not in current_set]
            if candidates:
                new_point = random.choice(candidates)
                new_set = sorted(set(current_set + [new_point]))
            else:
                continue
        else:
            # Remove a random point (keep at least 2)
            if len(current_set) > 2:
                idx = random.randint(0, len(current_set) - 1)
                new_set = current_set[:idx] + current_set[idx+1:]
            else:
                continue
        
        new_score = _score(new_set)
        
        delta = new_score - current_score
        if delta > 0 or random.random() < math.exp(delta / max(temperature, 0.01)):
            current_set = new_set
            current_score = new_score
            
            if current_score > best_score:
                best_set = current_set[:]
                best_score = current_score
        
        temperature *= cooling_rate
    
    return best_set, best_score


def _greedy_build(pts, max_size=500):
    """Greedily select points that maximize |A-A|/|A+A|."""
    A = []
    int_pts = _points_to_integers(pts, max(abs(x) for p in pts for x in p) + 2)
    candidates = list(zip(int_pts, pts))
    random.shuffle(candidates)
    
    for int_val, pt in candidates:
        if len(A) >= max_size:
            break
        test_set = A + [int_val]
        d, s = _compute_diffs_sums(test_set)
        if s > 0:
            ratio = math.log(d) / math.log(s)
            if len(A) < 5 or ratio > 0.8:  # Accept if promising
                A.append(int_val)
    
    return A if len(A) >= 2 else [0, 1]


def solve():
    LIMIT_N = 4000
    LIMIT_V = 10 ** 15
    best_overall = None
    best_score_overall = -1.0
    
    start_time = time.time()
    time_per_config = 2.0
    
    # Try configurations with moderate-to-large d and small k
    configs = []
    for d in range(8, 16):
        for k in range(1, 6):
            base_mult = 2 * k + 3
            if base_mult ** d > LIMIT_V:
                break
            configs.append((d, k, base_mult))
    
    for config_idx, (d, k, base_mult) in enumerate(configs):
        if time.time() - start_time > 110:  # Leave margin
            break
        
        pts = _simplex_points(d, k)
        if len(pts) > LIMIT_N:
            pts = random.sample(pts, min(LIMIT_N // 2, len(pts)))
        
        if len(pts) < 2:
            continue
        
        # Greedy initialization
        initial = _greedy_build(pts, max_size=min(500, len(pts)))
        
        # Simulated annealing optimization
        time_left = 110 - (time.time() - start_time)
        time_budget = min(time_per_config, time_left / max(1, len(configs) - config_idx))
        
        result, score = _simulated_annealing(initial, max_time=time_budget)
        
        if score > best_score_overall:
            best_score_overall = score
            best_overall = result
    
    if best_overall is not None and len(best_overall) >= 2:
        # Center and return
        best_overall = sorted(set(best_overall))
        off = (best_overall[0] + best_overall[-1]) // 2
        best_overall = [x - off for x in best_overall]
        
        if max(abs(x) for x in best_overall) <= LIMIT_V and len(best_overall) <= LIMIT_N:
            return best_overall
    
    return [0, 1, 3, 5, 11, 18, 26]
