# Research notebook: sum_difference

Ranker `jev`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.887449.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Replace the toy ±3 hill‑climb with simulated annealing over subsets of [0,N] (N≈40–80) using incremental multiplicity arrays for sums and differences. Each add/ | 0.74 | favourite | sonnet-5-5 (swapped) | improved | 0.888561 |
| 1 | Use lattice points in a d‑dimensional simplex, {x ∈ Z^d_{≥0} : Σx_i ≤ k}, flattened to integers by a base‑M encoding. Here A+A is just the simplex of side 2k, w | 0.72 | favourite | opus-5-5 | improved | 0.946948 |
| 5 | Mixed products: combine two or three different good base sets, e.g. B1 + M·B2 + M²·B3 with B1 a simplex set and B2 a searched 1‑D set. The ratio of a mixed prod | 0.71 | middle | sonnet-5-5 | improved | 0.946948 |
| 0 | Tensor-power amplification: take the best small base set B and encode A = {b0 + M·b1 + M²·b2 + …} with M > 2·(max B − min B), choosing as many digits as fit und | 0.66 | middle | sonnet-5-5 | improved | 0.946948 |
| 2 | Generalise the simplex idea to other asymmetric lattice polytopes, such as products of simplices of different dimensions or truncated/weighted simplices {Σw_i x | 0.54 | long_shot | haiku-4-5 | not_better | 0.887449 |
| 4 | Use local search directly in Z^d (d=2..5), starting from a simplex lattice set and adding or removing individual lattice points. This lets boundary points that  | 0.50 | long_shot | haiku-4-5 | not_better | 0.887449 |

Best after round 1: **0.946948** (spent $0.26)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Replace the base-M encoding with a compact Freiman 2-isomorphism. Pick integer weights w_i by greedy or random search, from small to large, so that x ↦ Σ w_i x_ | 0.38 | favourite | sonnet-5-5 (swapped) | not_better | 0.946948 |
| 2 | Thin a large simplex. Take a subset B of kΔ whose sumset still equals all of 2kΔ and whose difference set still equals the full difference body. Build it either | 0.32 | favourite | opus-5-5 | no_code |  |
| 0 | Make a map of the exact simplex ratio log/D//log/S/ from the existing _sizes formula over a wide (d,k) grid, with d up to about 40 and k up to about 15, ignorin | 0.32 | middle | sonnet-5-5 | not_better | 0.945420 |
| 3 | Deliberately allow collisions when projecting to 1-D. Encode a high-dimensional simplex with small weights that are not Freiman-isomorphic, and hill-climb or an | 0.26 | middle | sonnet-5-5 | not_better | 0.938202 |
| 4 | Use multi-level (non-uniform) digit products. Encode the set as tuples where each "digit" is itself a separately optimised moderate-dimensional thinned simplex, | 0.18 | long_shot | haiku-4-5 | not_better | 0.886624 |
| 5 | Run simulated annealing directly on subsets of the lattice simplex kΔ ⊂ Z^d at moderately large d (8–15), using incremental multiplicity hash tables. The object | 0.18 | long_shot | haiku-4-5 | invalid | 0.000000 |

Best after round 2: **0.946948** (spent $1.08)

