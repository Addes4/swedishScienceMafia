import math
import numpy as np


def _grid(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]


def solve(n):
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)] * n
    # choose N by cost estimate
    N = 1
    while N < 48:
        M = N + 1
        est = 0
        for w in range(1, M + 1):
            for h in range(1, M + 1):
                est += (w // 2 + h // 2) * min(n, w * h)
        if est > 1.2e6:
            break
        N = M
    F = {}
    CH = {}
    for w in range(1, N + 1):
        for h in range(1, N + 1):
            best = np.full(n + 1, min(w, h), dtype=np.int64)
            best[0] = 0
            typ = np.zeros(n + 1, dtype=np.int8)
            ii = np.zeros(n + 1, dtype=np.int16)
            cc = np.zeros(n + 1, dtype=np.int32)
            for t in (1, 2):
                rng = range(1, w // 2 + 1) if t == 1 else range(1, h // 2 + 1)
                for i in rng:
                    if t == 1:
                        A = F[(i, h)]
                        B = F[(w - i, h)]
                        area = i * h
                    else:
                        A = F[(w, i)]
                        B = F[(w, h - i)]
                        area = w * i
                    for c1 in range(0, min(n, area) + 1):
                        cand = A[c1] + B[:n + 1 - c1]
                        sl = best[c1:]
                        mask = cand > sl
                        if mask.any():
                            sl[mask] = cand[mask]
                            typ[c1:][mask] = t
                            ii[c1:][mask] = i
                            cc[c1:][mask] = c1
            F[(w, h)] = best
            CH[(w, h)] = (typ, ii, cc)
    bestval = -1.0
    bn = 1
    for m in range(1, N + 1):
        v = F[(m, m)][n] / m
        if v > bestval + 1e-12:
            bestval = v
            bn = m
    if bestval < math.isqrt(n) - 1e-9:
        return _grid(n)
    out = []
    stack = [(bn, bn, n, 0, 0)]
    while stack:
        w, h, c, x, y = stack.pop()
        if c <= 0:
            continue
        typ, ii, cc = CH[(w, h)]
        t = int(typ[c])
        if t == 0:
            s = min(w, h)
            out.append(((x + s / 2) / bn, (y + s / 2) / bn, 0.0, s / bn))
        elif t == 1:
            i = int(ii[c]); c1 = int(cc[c])
            stack.append((i, h, c1, x, y))
            stack.append((w - i, h, c - c1, x + i, y))
        else:
            i = int(ii[c]); c1 = int(cc[c])
            stack.append((w, i, c1, x, y))
            stack.append((w, h - i, c - c1, x, y + i))
    out = out[:n]
    out = [(min(1.0, max(0.0, a)), min(1.0, max(0.0, b)), 0.0, min(1.0, max(0.0, s)))
           for a, b, _, s in out]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out
