import math
import numpy as np


def _formula(n):
    best = None
    r = math.isqrt(n)
    for K in range(max(1, r), r + 4):
        for j in range(1, K + 1):
            cnt = K * K - j * j + 1
            if cnt > n:
                continue
            val = (K * K - j * j) / K + j / K
            if best is None or val > best[0]:
                best = (val, K, j)
    _, K, j = best
    sq = [((j / 2) / K, (j / 2) / K, 0.0, j / K)]
    for x in range(K):
        for y in range(K):
            if x < j and y < j:
                continue
            sq.append(((x + 0.5) / K, (y + 0.5) / K, 0.0, 1.0 / K))
    return sq


def _dp(n):
    K = min(int(math.ceil(math.sqrt(n))) + 2, 17)
    T = n
    NEG = -1e9
    ar = np.arange(T + 1)
    idx = ar[None, :] - ar[:, None]
    mask = idx < 0
    idxc = np.where(mask, 0, idx)

    def conv(A, B):
        S = A[:, None] + B[idxc]
        S[mask] = NEG
        return S.max(0), S.argmax(0)

    f = {}
    ch = {}
    for a in range(1, K + 1):
        for b in range(1, K + 1):
            best = np.full(T + 1, NEG)
            typ = np.zeros(T + 1, dtype=int)
            cc = np.zeros(T + 1, dtype=int)
            ii = np.zeros(T + 1, dtype=int)
            if a == b:
                v = np.full(T + 1, float(a))
                v[0] = 0.0
                best = v
            else:
                best[0] = 0.0
            for c in range(1, a // 2 + 1):
                h, arg = conv(f[(c, b)], f[(a - c, b)])
                m = h > best + 1e-12
                best = np.where(m, h, best)
                typ = np.where(m, 1, typ)
                cc = np.where(m, c, cc)
                ii = np.where(m, arg, ii)
            for c in range(1, b // 2 + 1):
                h, arg = conv(f[(a, c)], f[(a, b - c)])
                m = h > best + 1e-12
                best = np.where(m, h, best)
                typ = np.where(m, 2, typ)
                cc = np.where(m, c, cc)
                ii = np.where(m, arg, ii)
            f[(a, b)] = best
            ch[(a, b)] = (typ, cc, ii)
    bestK = max(range(1, K + 1), key=lambda k: f[(k, k)][n] / k)
    out = []

    def place(a, b, t, x0, y0):
        if t <= 0:
            return
        typ, cc, ii = ch[(a, b)]
        ty = typ[t]
        if ty == 0:
            if a == b:
                out.append((x0 + a / 2.0, y0 + a / 2.0, a))
            return
        c = int(cc[t])
        i = int(ii[t])
        if ty == 1:
            place(c, b, i, x0, y0)
            place(a - c, b, t - i, x0 + c, y0)
        else:
            place(a, c, i, x0, y0)
            place(a, b - c, t - i, x0, y0 + c)

    place(bestK, bestK, n, 0, 0)
    return [(x / bestK, y / bestK, 0.0, s / bestK) for x, y, s in out]


def solve(n):
    if n <= 200:
        sq = _dp(n)
    else:
        sq = _formula(n)
    res = []
    shrink = 1 - 1e-12
    for x, y, an, s in sq[:n]:
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), 0.0, s * shrink))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
