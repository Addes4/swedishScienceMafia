import math
import random
import time


def _eval(parts):
    budget = 1.0
    val = 0.0
    for c in sorted(parts, reverse=True):
        if budget <= 1e-15:
            break
        h = min(1.0 / c, budget)
        val += c * h
        budget -= h
    return val


def _equal_split(n, r):
    q, m = divmod(n, r)
    return [q + 1] * m + [q] * (r - m)


def solve(n):
    t0 = time.time()
    rng = random.Random(12345)
    best = None
    bv = -1.0
    rmax = min(n, int(3 * math.sqrt(n)) + 3)
    for r in range(1, rmax + 1):
        p = _equal_split(n, r)
        v = _eval(p)
        if v > bv + 1e-12:
            bv, best = v, p
    # hill climbing
    cur = list(best)
    cv = bv
    limit = 4.0
    it = 0
    while time.time() - t0 < limit and it < 200000:
        it += 1
        p = list(cur)
        mv = rng.random()
        i = rng.randrange(len(p))
        if mv < 0.7 and len(p) > 1:
            j = rng.randrange(len(p))
            if i == j:
                continue
            k = 1 if rng.random() < 0.8 else rng.randint(1, p[i])
            p[i] -= k
            p[j] += k
        elif mv < 0.85:
            if p[i] < 2:
                continue
            k = rng.randint(1, p[i] - 1)
            p[i] -= k
            p.append(k)
        else:
            if len(p) < 2:
                continue
            j = rng.randrange(len(p))
            if i == j:
                continue
            p[i] += p[j]
            p.pop(j)
        p = [x for x in p if x > 0]
        v = _eval(p)
        if v >= cv - 1e-15:
            cur, cv = p, v
            if cv > bv + 1e-12:
                bv, best = cv, list(cur)

    parts = sorted(best, reverse=True)
    res = []
    y = 0.0
    budget = 1.0
    shrink = 1.0 - 1e-9
    for c in parts:
        if budget <= 1e-15:
            break
        h = min(1.0 / c, budget)
        for j in range(c):
            if len(res) >= n:
                break
            cx = (j + 0.5) * h
            cy = y + 0.5 * h
            res.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0, h * shrink))
        y += h
        budget -= h
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
