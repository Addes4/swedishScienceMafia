import math


def solve(n):
    best = None
    k = max(1, math.isqrt(n))
    for m in range(k, 2 * k + 3):
        R = m * m - n
        h = m // 2
        B = h * h
        if R <= 0:
            val = m / m * m * 1.0 / 1.0
            t = 0
            val = float(m) / m * m / m * m  # = m? keep simple below
            val = 1.0 * (m * m) / m  # m
            # but only n squares available
            val = n / m if n < m * m else float(m)
        else:
            if R > 3 * B:
                continue
            t = (R + 2) // 3
            val = (m * m - 3 * t - 0) / m
            # count of squares: m*m-3t (<= n); sum = (m*m - 4t)/m + 2t/m
            val = ((m * m - 4 * t) + 2 * t) / m
        if best is None or val > best[0]:
            best = (val, m, max(R, 0) and t)
    val, m, t = best
    s = 1.0 / m
    shrink = 1e-10
    squares = []
    used = set()
    cnt = 0
    if m * m <= n:
        t = 0
    h = m // 2
    merged = 0
    for bi in range(h):
        for bj in range(h):
            if merged < t:
                i, j = 2 * bi, 2 * bj
                for a in (0, 1):
                    for b in (0, 1):
                        used.add((i + a, j + b))
                squares.append(((i + 1) * s, (j + 1) * s, 0.0, 2 * s * (1 - shrink)))
                merged += 1
    for i in range(m):
        for j in range(m):
            if (i, j) not in used:
                squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s * (1 - shrink)))
    if len(squares) > n:
        squares.sort(key=lambda q: -q[3])
        squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares
