import math
import numpy as np

NEG = -1e18


def _steps(f, m, k):
    a = np.full(m + 1, NEG)
    a[:m] = f[:m]
    cur = a.copy()
    steps = [cur]
    for _ in range(k * k - 1):
        new = np.full(m + 1, NEG)
        for i in range(m + 1):
            if cur[i] <= NEG / 2:
                continue
            seg = cur[i] + a[:m + 1 - i]
            np.maximum(new[i:], seg, out=new[i:])
        cur = new
        steps.append(cur)
    return a, steps


def _table(N):
    f = np.zeros(N + 1)
    bestk = [0] * (N + 1)
    if N >= 1:
        f[1] = 1.0
        bestk[1] = 1
    for m in range(2, N + 1):
        f[m] = 1.0
        bestk[m] = 1
        for k in range(2, 6):
            if k * k > 2 * m:
                break
            a, steps = _steps(f, m, k)
            v = steps[-1][m] / k
            if v > f[m] + 1e-12:
                f[m] = v
                bestk[m] = k
    return f, bestk


def _partition(f, m, k):
    a, steps = _steps(f, m, k)
    counts = []
    t = m
    for j in range(len(steps) - 1, 0, -1):
        prev = steps[j - 1]
        idx = np.arange(t + 1)
        vals = prev[t - idx] + a[idx]
        i = int(np.argmax(vals))
        counts.append(i)
        t -= i
    counts.append(t)
    return counts[::-1]


def solve(n):
    N = min(n, 150)
    f, bestk = _table(N)
    out = []

    def build(m, x0, y0, s):
        if m <= 0:
            return
        k = bestk[m]
        if k <= 1:
            out.append((x0 + s / 2, y0 + s / 2, 0.0, s))
            return
        counts = _partition(f, m, k)
        cs = s / k
        for idx, c in enumerate(counts):
            if c > 0:
                r, q = divmod(idx, k)
                build(c, x0 + q * cs, y0 + r * cs, cs)

    if n <= N:
        build(n, 0.0, 0.0, 1.0)
    else:
        k = math.isqrt(max(1, (n - 1) // N)) + 1
        while -(-n // (k * k)) > N:
            k += 1
        cells = k * k
        base, extra = divmod(n, cells)
        cs = 1.0 / k
        for idx in range(cells):
            c = base + (1 if idx < extra else 0)
            r, q = divmod(idx, k)
            build(c, q * cs, r * cs, cs)
    res = []
    for (x, y, ang, s) in out:
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), ang, min(1.0, max(0.0, s))))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
