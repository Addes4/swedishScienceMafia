import math
import numpy as np


def solve(n):
    M = min(int(math.ceil(math.sqrt(n))) + 2, 16)
    M = max(M, 1)
    C = min(n, M * M)
    F = {}
    T = {}
    P = {}
    K = {}
    for w in range(1, M + 1):
        for h in range(1, M + 1):
            best = np.zeros(C + 1)
            typ = np.zeros(C + 1, dtype=np.int8)
            pos = np.zeros(C + 1, dtype=np.int32)
            c1s = np.zeros(C + 1, dtype=np.int32)
            if w == h and C >= 1:
                best[1:] = w
                typ[1:] = 1
            for t, lim in ((2, w), (3, h)):
                for i in range(1, lim // 2 + 1):
                    if t == 2:
                        A = F[(i, h)]
                        B = F[(w - i, h)]
                    else:
                        A = F[(w, i)]
                        B = F[(w, h - i)]
                    for c1 in range(C + 1):
                        cand = A[c1] + B[:C + 1 - c1]
                        sl = best[c1:]
                        mask = cand > sl + 1e-12
                        if mask.any():
                            sl[mask] = cand[mask]
                            typ[c1:][mask] = t
                            pos[c1:][mask] = i
                            c1s[c1:][mask] = c1
            F[(w, h)] = best
            T[(w, h)] = typ
            P[(w, h)] = pos
            K[(w, h)] = c1s

    bm, bv = 1, -1.0
    for m in range(1, M + 1):
        v = F[(m, m)][min(C, m * m)] / m
        if v > bv + 1e-12:
            bv, bm = v, m

    m = bm
    out = []

    def build(w, h, c, x, y):
        c = min(c, C)
        t = T[(w, h)][c]
        if t == 0:
            return
        if t == 1:
            out.append((x, y, w))
            return
        i = int(P[(w, h)][c])
        c1 = int(K[(w, h)][c])
        c2 = c - c1
        if t == 2:
            build(i, h, c1, x, y)
            build(w - i, h, c2, x + i, y)
        else:
            build(w, i, c1, x, y)
            build(w, h - i, c2, x, y + i)

    build(m, m, min(n, C), 0, 0)
    res = []
    for (x, y, s) in out:
        cx = (x + s / 2.0) / m
        cy = (y + s / 2.0) / m
        res.append((cx, cy, 0.0, (s / m) * (1 - 1e-12)))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
