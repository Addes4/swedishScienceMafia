import time
import numpy as np


def _run(n, M):
    cap = min(n, M * M)
    F = {}
    CH = {}
    for a in range(1, M + 1):
        for b in range(1, M + 1):
            g = np.zeros(cap + 1)
            dim = np.zeros(cap + 1, dtype=np.int8)
            pos = np.zeros(cap + 1, dtype=np.int32)
            c1a = np.zeros(cap + 1, dtype=np.int32)
            if a == b:
                g[1:] = a
            for d in (1, 2):
                L = a if d == 1 else b
                for p in range(1, L // 2 + 1):
                    if d == 1:
                        f1 = F[(p, b)]
                        f2 = F[(a - p, b)]
                    else:
                        f1 = F[(a, p)]
                        f2 = F[(a, b - p)]
                    for k in range(cap + 1):
                        if k > 0 and f1[k] <= f1[k - 1] + 1e-12:
                            continue
                        cand = f1[k] + f2[:cap + 1 - k]
                        seg = g[k:]
                        m = cand > seg + 1e-12
                        if m.any():
                            seg[m] = cand[m]
                            dim[k:][m] = d
                            pos[k:][m] = p
                            c1a[k:][m] = k
            # enforce monotone
            F[(a, b)] = g
            CH[(a, b)] = (dim, pos, c1a)
    val = F[(M, M)][cap]
    return val, F, CH, cap


def _build(M, CH, cap):
    res = []
    stack = [(0, 0, M, M, cap)]
    while stack:
        x, y, a, b, c = stack.pop()
        if c <= 0:
            continue
        dim, pos, c1a = CH[(a, b)]
        d = int(dim[c])
        if d == 0:
            if a == b:
                res.append((x + a / 2.0, y + a / 2.0, a))
            continue
        p = int(pos[c])
        k = int(c1a[c])
        if d == 1:
            stack.append((x, y, p, b, k))
            stack.append((x + p, y, a - p, b, c - k))
        else:
            stack.append((x, y, a, p, k))
            stack.append((x, y + p, a, b - p, c - k))
    return res


def solve(n):
    t0 = time.time()
    budget = 35.0
    best = None
    bestval = -1.0
    last = None
    for M in range(1, 41):
        if last is not None:
            pred = last * (((M) / (M - 1.0)) ** 5)
            if time.time() - t0 + pred > budget:
                break
        ts = time.time()
        val, F, CH, cap = _run(n, M)
        last = max(time.time() - ts, 1e-4)
        v = val / M
        if v > bestval + 1e-12:
            bestval = v
            best = (M, _build(M, CH, cap))
    M, lst = best
    eps = 1e-9
    out = []
    for (cx, cy, s) in lst:
        side = max(s / M - eps, 0.0)
        out.append((min(max(cx / M, 0.0), 1.0), min(max(cy / M, 0.0), 1.0), 0.0, side))
    out = out[:n]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
