import math

_cache = {}


def _table(N):
    best = [0.0] * (N + 1)
    ch = [None] * (N + 1)
    for n in range(1, N + 1):
        b = best[n - 1]
        c = ('prev',)
        jmax = 2 * math.isqrt(n) + 3
        for j in range(1, jmax + 1):
            for i in range(0, j):
                cells = j * j - i * i
                if cells > n:
                    continue
                m1 = n - cells
                if i == 0:
                    val = cells / j
                else:
                    val = (cells + i * best[m1]) / j
                if val > b + 1e-12:
                    b = val
                    c = ('blk', j, i, m1)
        best[n] = b
        ch[n] = c
    return best, ch


def _build(n, x0, y0, size, ch, out):
    if n <= 0:
        return
    c = ch[n]
    if c[0] == 'prev':
        _build(n - 1, x0, y0, size, ch, out)
        return
    _, j, i, m1 = c
    s = size / j
    for a in range(j):
        for b in range(j):
            if a >= i or b >= i:
                out.append((x0 + (a + 0.5) * s, y0 + (b + 0.5) * s, 0.0, s))
    if i > 0 and m1 > 0:
        _build(m1, x0, y0, size * i / j, ch, out)


def solve(n):
    best, ch = _table(n)
    out = []
    _build(n, 0.0, 0.0, 1.0, ch, out)
    out = out[:n]
    res = []
    f = 1 - 1e-12
    for (x, y, a, s) in out:
        s2 = s * f
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), 0.0, min(1.0, max(0.0, s2))))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
