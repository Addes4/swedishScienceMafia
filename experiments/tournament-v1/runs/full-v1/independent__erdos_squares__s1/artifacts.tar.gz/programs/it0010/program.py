import math
import time
import numpy as np


def _baseline(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n], float(k)


def _dp(N, n, deadline):
    NEG = -10**9
    idx = (n + np.arange(n + 1)[None, :] - np.arange(n + 1)[:, None])
    dp = [[None] * (N + 1) for _ in range(N + 1)]

    def conv(A, B):
        P = np.concatenate([np.full(n, NEG, dtype=np.int64), B])
        return (A[:, None] + P[idx]).max(axis=0)

    for w in range(1, N + 1):
        if time.time() > deadline:
            return None
        for h in range(1, w + 1):
            m = min(w, h)
            base = np.full(n + 1, m, dtype=np.int64)
            base[0] = 0
            best = base
            for xc in range(1, w // 2 + 1):
                best = np.maximum(best, conv(dp[xc][h], dp[w - xc][h]))
            for yc in range(1, h // 2 + 1):
                best = np.maximum(best, conv(dp[w][yc], dp[w][h - yc]))
            best = np.maximum.accumulate(best)
            dp[w][h] = best
            dp[h][w] = best
    return dp


def _reconstruct(dp, N, n):
    res = []
    import sys
    sys.setrecursionlimit(10000)

    def rec(w, h, c, x, y):
        if c <= 0:
            return
        target = int(dp[w][h][c])
        if target <= 0:
            return
        m = min(w, h)
        if target == m:
            res.append((x, y, m))
            return
        for xc in range(1, w):
            A = dp[xc][h]
            B = dp[w - xc][h]
            for a in range(0, c + 1):
                if int(A[a]) + int(B[c - a]) == target:
                    rec(xc, h, a, x, y)
                    rec(w - xc, h, c - a, x + xc, y)
                    return
        for yc in range(1, h):
            A = dp[w][yc]
            B = dp[w][h - yc]
            for a in range(0, c + 1):
                if int(A[a]) + int(B[c - a]) == target:
                    rec(w, yc, a, x, y)
                    rec(w, h - yc, c - a, x, y + yc)
                    return

    rec(N, N, n, 0, 0)
    return res


def solve(n):
    t0 = time.time()
    budget = 45.0
    best_sq, best_val = _baseline(n)
    k = max(1, math.isqrt(n))
    best_N = None
    best_dp = None
    N = k
    Nmax = 4 * k + 4
    while N <= Nmax:
        remaining = budget - (time.time() - t0)
        cuts = (N * N / 2.0) * N
        est = 1.2e-8 * cuts * (n + 1) ** 2
        if est > remaining:
            break
        dp = _dp(N, n, t0 + budget)
        if dp is None:
            break
        val = int(dp[N][N][n]) / N
        if val > best_val + 1e-12:
            best_val = val
            best_N = N
            best_dp = dp
        N += 1
    if best_N is not None:
        try:
            pl = _reconstruct(best_dp, best_N, n)
            sq = []
            shrink = 1 - 1e-12
            for (x, y, s) in pl:
                side = s / best_N
                cx = (x + s / 2.0) / best_N
                cy = (y + s / 2.0) / best_N
                sq.append((cx, cy, 0.0, side * shrink))
            if len(sq) <= n:
                sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
                tot = sum(s[3] for s in sq)
                if tot >= best_val - 1e-6:
                    return sq[:n]
        except Exception:
            pass
    return best_sq
