import math
import time
import heapq
import numpy as np


def _pack(m, sizes):
    occ = np.zeros((m, m), dtype=bool)
    pos = []
    for s in sizes:
        placed = False
        for y in range(m - s + 1):
            for x in range(m - s + 1):
                if not occ[y:y + s, x:x + s].any():
                    occ[y:y + s, x:x + s] = True
                    pos.append((x, y, s))
                    placed = True
                    break
            if placed:
                break
        if not placed:
            return None, None
    return occ, pos


def solve(n):
    t0 = time.time()
    k0 = math.isqrt(n)
    if k0 * k0 < n:
        k0 += 1
    cands = []  # (score, m, sizes tuple)
    for m in range(k0, k0 + 5):
        M2 = m * m
        heap = []
        cnt = 0

        def consider(sizes_sum, A, cntB, key):
            nonlocal cnt
            if cntB > n or A > M2:
                return
            u = min(M2 - A, n - cntB)
            sc = (sizes_sum + u) / m
            cnt += 1
            item = (sc, cnt, key)
            if len(heap) < 40:
                heapq.heappush(heap, item)
            elif sc > heap[0][0]:
                heapq.heapreplace(heap, item)

        consider(0, 0, 0, ())
        for j in range(2, m + 1):
            amax = min((m // j) ** 2, n)
            for a in range(1, amax + 1):
                consider(a * j, a * j * j, a, ((j, a),))
                if time.time() - t0 > 35:
                    continue
                for j2 in range(2, j):
                    rem = M2 - a * j * j
                    if rem < j2 * j2:
                        break
                    bmax = min(rem // (j2 * j2), (m // j2) ** 2, n - a)
                    for b in range(1, bmax + 1):
                        consider(a * j + b * j2, a * j * j + b * j2 * j2, a + b,
                                 ((j, a), (j2, b)))
        for sc, _, key in heap:
            cands.append((sc, m, key))
    cands.sort(key=lambda t: -t[0])
    best = None
    for sc, m, key in cands:
        sizes = []
        for j, a in key:
            sizes += [j] * a
        sizes.sort(reverse=True)
        occ, pos = _pack(m, sizes)
        if occ is None:
            continue
        best = (m, occ, pos)
        break
    if best is None:
        m = k0
        occ = np.zeros((m, m), dtype=bool)
        pos = []
        best = (m, occ, pos)
    m, occ, pos = best
    res = []
    for x, y, s in pos:
        res.append(((x + s / 2) / m, (y + s / 2) / m, 0.0, s / m))
    need = n - len(res)
    for y in range(m):
        for x in range(m):
            if need <= 0:
                break
            if not occ[y, x]:
                res.append(((x + 0.5) / m, (y + 0.5) / m, 0.0, 1.0 / m))
                need -= 1
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
