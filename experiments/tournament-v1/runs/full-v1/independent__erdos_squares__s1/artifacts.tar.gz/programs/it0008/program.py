import math
import time
import numpy as np


def _fallback(n):
    best = (-1.0, None)
    kmax = int(math.isqrt(n)) + 2
    for k in range(1, kmax + 1):
        for j in range(0, k):
            cnt = k * k - j * j + (1 if j > 0 else 0)
            if cnt <= n:
                v = (k * k - j * j + j) / k
                if v > best[0]:
                    best = (v, (k, j))
    v, (k, j) = best
    sq = []
    s = 1.0 / k
    if j > 0:
        sq.append(((j / k) / 2, (j / k) / 2, 0.0, j / k))
    for x in range(k):
        for y in range(k):
            if x < j and y < j:
                continue
            sq.append(((x + 0.5) * s, (y + 0.5) * s, 0.0, s))
    return v, sq


def _dp(n, K):
    M = n
    ar = np.arange(M + 1)
    idx = ar[:, None] - ar[None, :]
    mask = idx < 0
    idxc = np.where(mask, 0, idx)
    F = {}
    CH = {}

    def key(p, q):
        return (p, q) if p <= q else (q, p)

    for a in range(1, K + 1):
        for b in range(a, K + 1):
            val = np.zeros(M + 1)
            typ = np.full(M + 1, -1, dtype=np.int8)
            pos = np.zeros(M + 1, dtype=np.int32)
            m1s = np.zeros(M + 1, dtype=np.int32)
            if a == b:
                val[1:] = a
                typ[1:] = 0
            cands = []
            for p in range(1, a // 2 + 1):
                cands.append((1, p, key(p, b), key(a - p, b)))
            for q in range(1, b // 2 + 1):
                cands.append((2, q, key(a, q), key(a, b - q)))
            for t, p, k1, k2 in cands:
                A = F[k1]
                B = F[k2]
                S = A[None, :] + B[idxc]
                S[mask] = -1e18
                am = S.argmax(axis=1)
                cv = S[ar, am]
                better = cv > val + 1e-12
                if better.any():
                    val = np.where(better, cv, val)
                    typ = np.where(better, t, typ).astype(np.int8)
                    pos = np.where(better, p, pos)
                    m1s = np.where(better, am, m1s)
            F[(a, b)] = val
            CH[(a, b)] = (typ, pos, m1s)

    def rec(a, b, m):
        # returns list of (x, y, s) in rectangle width a height b at origin
        if m <= 0:
            return []
        if a > b:
            return [(y, x, s) for (x, y, s) in rec(b, a, m)]
        typ, pos, m1s = CH[(a, b)]
        t = int(typ[m])
        if t == -1:
            return []
        if t == 0:
            return [(0, 0, a)]
        p = int(pos[m])
        m1 = int(m1s[m])
        m2 = m - m1
        if t == 1:
            r = rec(p, b, m1)
            r2 = rec(a - p, b, m2)
            return r + [(x + p, y, s) for (x, y, s) in r2]
        else:
            r = rec(a, p, m1)
            r2 = rec(a, b - p, m2)
            return r + [(x, y + p, s) for (x, y, s) in r2]

    total = F[(K, K)][M] / K
    return total, rec(K, K, M)


def solve(n):
    t0 = time.time()
    fv, fsq = _fallback(n)
    best_v, best_sq = fv, fsq
    K = max(1, math.isqrt(n))
    if K * K < n:
        K += 1
    last = 0.0
    while K <= 40:
        cost = (K ** 3) * (n ** 2) / 2.0
        if cost > 5e8:
            break
        el = time.time() - t0
        if last > 0 and el + last * 2.6 > 45:
            break
        ts = time.time()
        try:
            v, tiles = _dp(n, K)
        except MemoryError:
            break
        last = time.time() - ts
        if v > best_v + 1e-12:
            sc = []
            for (x, y, s) in tiles:
                sc.append(((x + s / 2.0) / K, (y + s / 2.0) / K, 0.0,
                           (s / K) * (1 - 1e-10)))
            best_v, best_sq = v, sc
        K += 1
    sq = []
    for (cx, cy, ang, s) in best_sq:
        sq.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), ang, min(1.0, max(0.0, s))))
    sq.sort(key=lambda t: -t[3])
    sq = sq[:n]
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq
