import math


def solve(n):
    if n <= 0:
        return []
    S = [0.0] * (n + 1)
    choice = [None] * (n + 1)
    for m in range(1, n + 1):
        best = S[m - 1]
        ch = None
        lim = int(2 * math.sqrt(m)) + 3
        for c1 in range(1, min(lim, m) + 1):
            w = 1.0 / c1
            for c2 in range(0, c1):
                t = c1 + c2
                if t > m:
                    break
                v = (1 - w) * S[m - t] + t * w
                if v > best + 1e-12:
                    best = v
                    ch = (c1, c2)
        S[m] = best
        choice[m] = ch

    res = []
    x0, y0, L = 0.0, 0.0, 1.0
    m = n
    while m > 0:
        ch = choice[m]
        if ch is None:
            m -= 1
            continue
        c1, c2 = ch
        w = 1.0 / c1
        sw = w * L
        # right column
        xr = x0 + (1 - w) * L
        for i in range(c1):
            res.append((xr + sw / 2, y0 + (i + 0.5) * sw, 0.0, sw))
        # bottom row
        for i in range(c2):
            res.append((x0 + (i + 0.5) * sw, y0 + sw / 2, 0.0, sw))
        m -= c1 + c2
        # remaining region: [x0, x0+(1-w)L] x [y0+sw, y0+L]
        y0 = y0 + sw
        L = (1 - w) * L
    out = []
    for (cx, cy, a, s) in res:
        s = min(max(s, 0.0), 1.0)
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
