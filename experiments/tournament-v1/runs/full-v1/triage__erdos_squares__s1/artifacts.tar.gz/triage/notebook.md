# Research notebook: erdos_squares

Ranker `jev`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.856172.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Add a continuous post-optimisation stage. Take the best combinatorial layout as the start, with free parameters (x, y, angle, side) and zero-size squares made s | 0.69 | favourite | sonnet-5-5 (swapped) | improved | 1.000000 |
| 0 | Replace the k×k grid with an m×m grid of cells of side 1/m in which one j×j block of cells is merged into a single big square. This gives m²−j²+1 squares with t | 0.66 | favourite | opus-5-5 | improved | 0.953532 |
| 4 | Try strip/mixed-scale constructions. Split the unit square into a top rectangle of height h filled by a row of squares of side h, plus a bottom region filled by | 0.65 | middle | sonnet-5-5 | improved | 0.990586 |
| 1 | Generalise to exact tilings of an m×m cell grid by axis-aligned integer-sized squares, including several merged blocks of different sizes. Run a DFS/branch-and- | 0.60 | middle | sonnet-5-5 | improved | 0.996549 |
| 2 | Use a recursive split/merge dynamic programme on quadtree-like refinements. Start from any square tiling, and allow two moves: split a square of side s into a t | 0.58 | long_shot | haiku-4-5 | not_better | 0.856172 |
| 5 | As a long shot for counts just above a perfect square (n = k²+1, k²+2), try rotated constructions. Take the best known Erdős-type packings in which a few square | 0.36 | long_shot | haiku-4-5 | not_better | 0.658369 |

Promotion: claude-sonnet-5-5 found an improvement; claude-opus-5-5 refined it -> improved (1.000000).

Best after round 1: **1.000000** (spent $0.43)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 2 | Replace the finite-difference L-BFGS with an analytic gradient of the penalty. Use the minimising separating axis for each overlapping pair and the active bound | 0.56 | favourite | sonnet-5-5 (swapped) | not_better | 1.000000 |
| 0 | Replace the square-only recursive DP with a guillotine DP over axis-aligned sub-rectangles of an L×L lattice (L chosen adaptively, e.g. lcm-friendly values like | 0.46 | favourite | opus-5-5 | not_better | 1.000000 |
| 5 | Treat counts n = k²+1 and k²+2 differently: keep the k×k grid and insert the extra square(s) by locally shrinking one row and one column of the grid. Parametris | 0.30 | middle | sonnet-5-5 | api_error |  |
| 1 | Make the existing DP scale to large n so hidden test sizes don't time out. Vectorise the inner loops as numpy max-plus convolutions, where G[j][n] = max_t (G[j- | 0.29 | middle | sonnet-5-5 | api_error |  |
| 3 | Add a combinatorial local search on top of the DP layout. Repeatedly pick a random axis-aligned sub-square region made of whole pieces, take its piece count c,  | 0.29 | long_shot | haiku-4-5 | not_better | 1.000000 |
| 4 | Long shot: enumerate non-grid exact tilings of a square by unequal squares, i.e. squared squares and squared rectangles, using Bouwkamp/Tutte electrical-network | 0.10 | long_shot | haiku-4-5 | not_better | 1.000000 |

Best after round 2: **1.000000** (spent $0.95)

