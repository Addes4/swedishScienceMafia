"""
Hybrid approach: use axis-aligned grid for base case, and for n just above perfect squares,
try rotated/tilted constructions optimized numerically.
"""
import math
import numpy as np
from scipy.optimize import minimize, differential_evolution


def solve(n):
    """Return n squares maximizing sum of side lengths."""
    
    # Base case: axis-aligned grid
    k = math.isqrt(n)
    
    # Try axis-aligned solution
    best_solution = axis_aligned_grid(n, k)
    best_score = sum(s[3] for s in best_solution)
    
    # For n slightly above perfect squares, try tilted constructions
    remainder = n - k * k
    if remainder > 0 and remainder <= 2 * k and k >= 2:
        tilted = try_tilted_construction(n, k, remainder)
        if tilted is not None:
            tilted_score = sum(s[3] for s in tilted)
            if tilted_score > best_score:
                best_solution = tilted
                best_score = tilted_score
    
    return best_solution


def axis_aligned_grid(n, k):
    """Place k×k grid of axis-aligned squares, pad with zero-size squares."""
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) 
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def try_tilted_construction(n, k, remainder):
    """Try tilted constructions for n = k² + remainder where remainder is small."""
    
    if remainder == 1:
        # Try placing one tilted square in a corner or gap
        return optimize_single_tilted(n, k)
    elif remainder == 2:
        # Try placing two tilted squares
        return optimize_two_tilted(n, k)
    elif remainder <= k:
        # Try a band of tilted squares
        return optimize_tilted_band(n, k, remainder)
    
    return None


def optimize_single_tilted(n, k):
    """Optimize placement and tilt of one additional square."""
    base_side = 1.0 / k
    base_squares = [((i + 0.5) * base_side, (j + 0.5) * base_side, 0.0, base_side) 
                    for i in range(k) for j in range(k)]
    
    def objective(params):
        cx, cy, angle = params
        # Extra square side is limited by space available
        max_side = compute_max_side(cx, cy, angle, base_squares, [])
        # Negative because we minimize
        return -max_side
    
    # Try multiple starting points
    best_result = None
    best_score = -sum(s[3] for s in base_squares)
    
    for cx_start in [0.1, 0.5, 0.9]:
        for cy_start in [0.1, 0.5, 0.9]:
            for angle_start in [0.0, 0.125, 0.25]:
                x0 = [cx_start, cy_start, angle_start]
                result = minimize(objective, x0, bounds=[(0, 1), (0, 1), (0, 0.5)], method='L-BFGS-B')
                if result.success:
                    cx, cy, angle = result.x
                    extra_side = -result.fun
                    total_score = sum(s[3] for s in base_squares) + extra_side
                    if total_score > best_score:
                        best_score = total_score
                        best_result = (cx, cy, angle, extra_side)
    
    if best_result is not None:
        return base_squares + [best_result]
    return None


def optimize_two_tilted(n, k):
    """Optimize placement of two tilted squares."""
    base_side = 1.0 / k
    base_squares = [((i + 0.5) * base_side, (j + 0.5) * base_side, 0.0, base_side) 
                    for i in range(k) for j in range(k)]
    base_score = sum(s[3] for s in base_squares)
    
    def objective(params):
        cx1, cy1, ang1, cx2, cy2, ang2 = params
        s1 = compute_max_side(cx1, cy1, ang1, base_squares, [])
        s2 = compute_max_side(cx2, cy2, ang2, base_squares + [(cx1, cy1, ang1, s1)])
        return -(s1 + s2)
    
    best_result = None
    best_score_found = base_score
    
    # Random search with several starting points
    for attempt in range(5):
        x0 = [np.random.uniform(0.1, 0.9), np.random.uniform(0.1, 0.9), np.random.uniform(0, 0.25),
              np.random.uniform(0.1, 0.9), np.random.uniform(0.1, 0.9), np.random.uniform(0, 0.25)]
        result = minimize(objective, x0, bounds=[(0, 1), (0, 1), (0, 0.5)] * 2, method='L-BFGS-B')
        if result.success:
            cx1, cy1, ang1, cx2, cy2, ang2 = result.x
            s1 = compute_max_side(cx1, cy1, ang1, base_squares, [])
            s2 = compute_max_side(cx2, cy2, ang2, base_squares + [(cx1, cy1, ang1, s1)])
            total = base_score + s1 + s2
            if total > best_score_found:
                best_score_found = total
                best_result = [(cx1, cy1, ang1, s1), (cx2, cy2, ang2, s2)]
    
    if best_result is not None:
        return base_squares + best_result
    return None


def optimize_tilted_band(n, k, remainder):
    """Optimize a band of tilted squares between grid cells."""
    base_side = 1.0 / k
    base_squares = [((i + 0.5) * base_side, (j + 0.5) * base_side, 0.0, base_side) 
                    for i in range(k) for j in range(k)]
    base_score = sum(s[3] for s in base_squares)
    
    best_solution = base_squares + [(0.5, 0.5, 0.0, 0.0)] * remainder
    best_score = base_score
    
    # Try placing tilted squares in a band
    for band_pos in np.linspace(0.1, 0.9, 5):
        for tilt in [0.1, 0.125, 0.15, 0.25]:
            squares = base_squares.copy()
            y_center = band_pos
            for i in range(remainder):
                x_center = 0.1 + (0.8 * i / max(1, remainder - 1))
                max_s = compute_max_side(x_center, y_center, tilt, base_squares + squares[len(base_squares):], [])
                if max_s > 0:
                    squares.append((x_center, y_center, tilt, max_s))
            
            score = sum(s[3] for s in squares)
            if score > best_score:
                best_score = score
                best_solution = squares
    
    return best_solution + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_solution))


def compute_max_side(cx, cy, angle, placed_squares, candidate_sides):
    """Compute maximum side length for a square at (cx, cy) with given angle."""
    # Simple conservative estimate: distance to boundary
    angle_rad = angle * 2 * math.pi
    max_side = min(cx, cy, 1 - cx, 1 - cy)
    
    # Account for placed squares (simplified collision detection)
    for px, py, pa, ps in placed_squares:
        dist = math.sqrt((cx - px) ** 2 + (cy - py) ** 2)
        buffer = (ps / math.sqrt(2)) + 0.01
        if dist < buffer:
            max_side = min(max_side, max(0, dist - buffer) * 0.9)
    
    return max(0, max_side * 0.95)
