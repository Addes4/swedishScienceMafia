# EVOLVE-BLOCK-START
"""Hierarchical grid layouts (DP) + augmented-Lagrangian post-optimisation
with analytic gradients (separating-axis penalty), pruned pairs and restarts."""
import math
import time
import numpy as np

NEG = -1e18
TWO_PI = 2.0 * math.pi
HALF_PI = math.pi / 2.0
SHRINK = 1e-8


def _build_plans(N, kmax=6):
    F = [0.0] * (N + 1)
    PL = [None] * (N + 1)
    ks = list(range(2, kmax + 1))
    G = {}
    CH = {}
    for k in ks:
        K2 = k * k
        G[k] = [[NEG] * (N + 1) for _ in range(K2 + 1)]
        CH[k] = [[0] * (N + 1) for _ in range(K2 + 1)]
        for j in range(K2 + 1):
            G[k][j][0] = 0.0
    for n in range(1, N + 1):
        best = 1.0
        plan = None
        for k in ks:
            K2 = k * k
            Gk = G[k]
            gp = [NEG] * (K2 + 1)
            cp = [0] * (K2 + 1)
            for j in range(1, K2 + 1):
                bv = NEG
                bt = 0
                for t in range(0, n):
                    prev = gp[j - 1] if t == 0 else Gk[j - 1][n - t]
                    if prev < -1e17:
                        continue
                    v = prev + F[t] / k
                    if v > bv:
                        bv = v
                        bt = t
                gp[j] = bv
                cp[j] = bt
            if gp[K2] > best + 1e-12:
                best = gp[K2]
                plan = (k, 0, 0, cp)
            for m in range(2, k):
                r = K2 - m * m
                for tb in range(1, n):
                    base = Gk[r][n - tb]
                    if base < -1e17:
                        continue
                    v = base + (m / k) * F[tb]
                    if v > best + 1e-12:
                        best = v
                        plan = (k, m, tb, cp)
        F[n] = best
        PL[n] = plan
        for k in ks:
            K2 = k * k
            Gk = G[k]
            for j in range(1, K2 + 1):
                bv = NEG
                bt = 0
                for t in range(0, n + 1):
                    prev = Gk[j - 1][n - t]
                    if prev < -1e17:
                        continue
                    v = prev + F[t] / k
                    if v > bv:
                        bv = v
                        bt = t
                Gk[j][n] = bv
                CH[k][j][n] = bt
    return F, PL, CH


def _place(n, x0, y0, size, PL, CH, out):
    if n <= 0:
        return
    plan = PL[n]
    if plan is None:
        out.append((x0 + size / 2, y0 + size / 2, 0.0, size))
        return
    k, m, tb, cp = plan
    cell = size / k
    r = k * k - m * m
    c = n - tb
    counts = []
    for j in range(r, 0, -1):
        if c == n:
            t = cp[j]
        else:
            t = CH[k][j][c]
        counts.append(t)
        c -= t
    idx = 0
    if m > 0:
        _place(tb, x0, y0, m * cell, PL, CH, out)
    for i in range(k):
        for j in range(k):
            if m > 0 and i < m and j < m:
                continue
            t = counts[idx]
            idx += 1
            _place(t, x0 + i * cell, y0 + j * cell, cell, PL, CH, out)


_TRIU = {}


def _triu(n):
    r = _TRIU.get(n)
    if r is None:
        r = np.triu_indices(n, 1)
        _TRIU[n] = r
    return r


def _pair_terms(P, I, J):
    th = TWO_PI * P[:, 2]
    c = np.cos(th)
    s = np.sin(th)
    U = np.stack([c, s], 1)
    V = np.stack([-s, c], 1)
    h = P[:, 3] / 2
    C = P[:, :2]
    axes = np.stack([U[I], V[I], U[J], V[J]], 1)
    d = C[J] - C[I]
    dist = np.abs(np.einsum('mac,mc->ma', axes, d))
    ri = h[I, None] * (np.abs(np.einsum('mac,mc->ma', axes, U[I])) +
                       np.abs(np.einsum('mac,mc->ma', axes, V[I])))
    rj = h[J, None] * (np.abs(np.einsum('mac,mc->ma', axes, U[J])) +
                       np.abs(np.einsum('mac,mc->ma', axes, V[J])))
    return dist, ri + rj


def _pair_depth(P, I, J):
    dist, rs = _pair_terms(P, I, J)
    return (rs - dist).min(1)


def _bviol(P):
    th = TWO_PI * P[:, 2]
    ext = P[:, 3] / 2 * (np.abs(np.cos(th)) + np.abs(np.sin(th)))
    v = 0.0
    for q in (0, 1):
        x = P[:, q]
        v = v + np.maximum(ext - x, 0) + np.maximum(x + ext - 1, 0)
    return v


def _feasible(P, tol=1e-12):
    m = P[:, 3] > 1e-12
    Q = P[m]
    q = len(Q)
    if q == 0:
        return True
    if np.any(_bviol(Q) > 0):
        return False
    if np.any(Q[:, :2] < 0) or np.any(Q[:, :2] > 1):
        return False
    if q > 1:
        I, J = np.triu_indices(q, 1)
        if np.max(_pair_depth(Q, I, J)) > -tol:
            return False
    return True


def _repair(P):
    """Shrink each square individually so that everything is strictly feasible."""
    P = P.copy()
    n = len(P)
    P[:, 0:2] = np.clip(P[:, 0:2], 0, 1)
    P[:, 2] = np.mod(P[:, 2], 1.0)
    P[:, 3] = np.clip(P[:, 3], 0, 1)
    th = TWO_PI * P[:, 2]
    h = P[:, 3] / 2
    ext = h * (np.abs(np.cos(th)) + np.abs(np.sin(th)))
    allow = np.minimum(np.minimum(P[:, 0], 1 - P[:, 0]),
                       np.minimum(P[:, 1], 1 - P[:, 1]))
    with np.errstate(divide='ignore', invalid='ignore'):
        tb = np.where(ext > 1e-300, allow / ext, 1.0)
    scale = np.minimum(1.0, tb)
    if n > 1:
        I, J = _triu(n)
        dx = P[J, 0] - P[I, 0]
        dy = P[J, 1] - P[I, 1]
        hs = h[I] + h[J]
        idx = np.nonzero(dx * dx + dy * dy < 2 * hs * hs)[0]
        if idx.size:
            ii = I[idx]
            jj = J[idx]
            dist, rs = _pair_terms(P, ii, jj)
            with np.errstate(divide='ignore', invalid='ignore'):
                ratio = np.where(rs > 1e-300, dist / rs, np.inf)
            t = np.minimum(ratio.max(1), 1.0)
            np.minimum.at(scale, ii, t)
            np.minimum.at(scale, jj, t)
    scale = np.clip(scale, 0.0, 1.0)
    P[:, 3] = P[:, 3] * scale * (1 - SHRINK)
    return P


class _Timeout(Exception):
    pass


_OWN = np.array([True, True, False, False])


def _core(xv, n, I, J, mu, LamP, LamB):
    P = xv.reshape(n, 4)
    x = P[:, 0]
    y = P[:, 1]
    A = TWO_PI * P[:, 2]
    h = 0.5 * P[:, 3]
    c = np.cos(A)
    s = np.sin(A)
    w = np.abs(c) + np.abs(s)
    ext = h * w
    gb = np.stack([ext - x, x + ext - 1, ext - y, y + ext - 1], 1)
    mb = np.maximum(0.0, LamB + mu * gb)
    val = -P[:, 3].sum() + ((mb * mb - LamB * LamB).sum()) / (2 * mu)
    Gext = mb.sum(1)
    dext = h * (-np.sign(c) * s + np.sign(s) * c)
    G = np.zeros((n, 4))
    G[:, 0] = mb[:, 1] - mb[:, 0]
    G[:, 1] = mb[:, 3] - mb[:, 2]
    G[:, 2] = Gext * dext * TWO_PI
    G[:, 3] = -1.0 + 0.5 * Gext * w
    idx = np.zeros(0, dtype=int)
    d = np.zeros(0)
    if n > 1:
        dxa = x[J] - x[I]
        dya = y[J] - y[I]
        hs = h[I] + h[J]
        mask = (dxa * dxa + dya * dya < 2 * hs * hs) | (LamP > 0)
        idx = np.nonzero(mask)[0]
        if idx.size:
            ii = I[idx]
            jj = J[idx]
            Dx = dxa[idx]
            Dy = dya[idx]
            Ai = A[ii]
            Aj = A[jj]
            hi = h[ii]
            hj = h[jj]
            mm = idx.size
            alpha = np.stack([Ai, Ai + HALF_PI, Aj, Aj + HALF_PI], 1)
            cal = np.cos(alpha)
            sal = np.sin(alpha)
            p = cal * Dx[:, None] + sal * Dy[:, None]
            gam = alpha - np.where(_OWN, Aj[:, None], Ai[:, None])
            hA = np.where(_OWN, hi[:, None], hj[:, None])
            hB = np.where(_OWN, hj[:, None], hi[:, None])
            wg = np.abs(np.cos(gam)) + np.abs(np.sin(gam))
            dd = hA + hB * wg - np.abs(p)
            k = np.argmin(dd, 1)
            r = np.arange(mm)
            d = dd[r, k]
            ca = cal[r, k]
            sa = sal[r, k]
            pk = p[r, k]
            gk = gam[r, k]
            hBk = hB[r, k]
            wk = wg[r, k]
            oi = _OWN[k]
            lam = LamP[idx]
            mv = np.maximum(0.0, lam + mu * d)
            val += ((mv * mv - lam * lam).sum()) / (2 * mu)
            sg = np.sign(pk)
            cg = np.cos(gk)
            sgm = np.sin(gk)
            T = hBk * (-np.sign(cg) * sgm + np.sign(sgm) * cg)
            perp = -sa * Dy * 0.0 + (-sa * Dx + ca * Dy)
            tA = T - sg * perp
            dhi = np.where(oi, 1.0, wk)
            dhj = np.where(oi, wk, 1.0)
            dti = np.where(oi, tA, -T)
            dtj = np.where(oi, -T, tA)
            ax = ca * sg * mv
            ay = sa * sg * mv
            bc = np.bincount
            G[:, 0] += bc(ii, weights=ax, minlength=n) - bc(jj, weights=ax, minlength=n)
            G[:, 1] += bc(ii, weights=ay, minlength=n) - bc(jj, weights=ay, minlength=n)
            G[:, 2] += TWO_PI * (bc(ii, weights=mv * dti, minlength=n) +
                                 bc(jj, weights=mv * dtj, minlength=n))
            G[:, 3] += 0.5 * (bc(ii, weights=mv * dhi, minlength=n) +
                              bc(jj, weights=mv * dhj, minlength=n))
    return val, G.ravel(), idx, d, gb


def _al_solve(P0, n, deadline):
    from scipy.optimize import minimize
    I, J = _triu(n)
    npairs = len(I)
    bounds = [(0.0, 1.0), (0.0, 1.0), (None, None), (0.0, 1.0)] * n
    x = P0.flatten().astype(float).copy()
    LamP = np.zeros(npairs)
    LamB = np.zeros((n, 4))
    mu = 10.0
    best = None
    bestval = -1.0
    prev = np.inf
    last = [x.copy()]

    def fun(xv, mu_, LP, LB):
        if time.time() > deadline:
            raise _Timeout()
        last[0] = xv.copy()
        val, G, _, _, _ = _core(xv, n, I, J, mu_, LP, LB)
        return val, G

    def consider(xx):
        nonlocal best, bestval
        Q = _repair(xx.reshape(n, 4))
        v = Q[:, 3].sum()
        if v > bestval:
            bestval = v
            best = Q

    try:
        for outer in range(10):
            res = minimize(fun, x, args=(mu, LamP, LamB), jac=True,
                           method='L-BFGS-B', bounds=bounds,
                           options={'maxiter': 150 if outer == 0 else 100,
                                    'ftol': 1e-13, 'gtol': 1e-9,
                                    'maxfun': 400})
            x = res.x
            last[0] = x.copy()
            val, G, idx, d, gb = _core(x, n, I, J, mu, LamP, LamB)
            viol = max(float(d.max()) if d.size else 0.0, float(gb.max()), 0.0)
            newL = np.zeros(npairs)
            if idx.size:
                newL[idx] = np.maximum(0.0, LamP[idx] + mu * d)
            LamP = newL
            LamB = np.maximum(0.0, LamB + mu * gb)
            consider(x)
            if viol < 1e-10:
                break
            if viol > 0.25 * prev:
                mu = min(mu * 5.0, 1e6)
            prev = viol
    except _Timeout:
        try:
            consider(last[0])
        except Exception:
            pass
    except Exception:
        pass
    return best, bestval


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    t_start = time.time()
    F, PL, CH = _build_plans(n)
    out = []
    _place(n, 0.0, 0.0, 1.0, PL, CH, out)
    out = out[:n]
    base = np.zeros((n, 4))
    for i, (x, y, a, s) in enumerate(out):
        base[i] = (x, y, a, s * (1 - SHRINK))
    base_val = base[:, 3].sum()
    result = base

    root = int(round(math.sqrt(n)))
    is_square = root * root == n
    if n >= 2 and n <= 400 and not is_square:
        try:
            deadline = t_start + 40.0
            rng = np.random.default_rng(12345)
            P_base = base.copy()
            P_base[:, 3] = P_base[:, 3] / (1 - SHRINK)
            zero = P_base[:, 3] < 1e-12
            trial = 0
            last_dur = 0.0
            while True:
                now = time.time()
                if now + 0.5 * last_dur > deadline - 0.2:
                    break
                mode = trial % 5
                P0 = P_base.copy()
                if trial == 0:
                    pass
                elif mode == 4:
                    # random start
                    P0[:, :2] = rng.random((n, 2))
                    P0[:, 2] = rng.random(n) * 0.25
                    P0[:, 3] = (0.3 + 0.7 * rng.random(n)) * 0.7 / math.sqrt(n)
                else:
                    sigma = (0.01, 0.03, 0.08, 0.15)[mode % 4] * (0.5 + rng.random())
                    nz = ~zero
                    cnt = int(nz.sum())
                    P0[nz, :2] += rng.normal(0, sigma * 0.5, (cnt, 2))
                    P0[nz, 2] += rng.normal(0, sigma, cnt)
                    P0[nz, 3] *= (1 - 0.1 * rng.random())
                P0[:, :2] = np.clip(P0[:, :2], 0, 1)
                if trial > 0 and mode != 4:
                    zz = zero
                    P0[zz, :2] = rng.random((int(zz.sum()), 2))
                    P0[zz, 3] = 0.0
                t0 = time.time()
                Q, v = _al_solve(P0, n, deadline)
                last_dur = time.time() - t0
                if Q is not None and v > base_val + 1e-9 and _feasible(Q, 1e-13):
                    result = Q
                    base_val = v
                trial += 1
        except Exception:
            pass
    return [(float(min(max(r[0], 0.0), 1.0)), float(min(max(r[1], 0.0), 1.0)),
             float(min(max(r[2], 0.0), 1.0)), float(min(max(r[3], 0.0), 1.0)))
            for r in result]
# EVOLVE-BLOCK-END
