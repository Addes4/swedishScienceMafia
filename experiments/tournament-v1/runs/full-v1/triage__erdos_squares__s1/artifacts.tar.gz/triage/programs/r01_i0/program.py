# EVOLVE-BLOCK-START
"""Grid of m x m cells with one j x j block merged into a single big square."""
import math
from fractions import Fraction


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    best_val = Fraction(-1)
    best_mj = (1, 1)
    limit = int(2 * math.isqrt(max(n, 1)) + 4)
    for m in range(1, limit + 1):
        for j in range(1, m + 1):
            cnt = m * m - j * j + 1
            if cnt > n:
                continue
            val = Fraction(m * m - j * j + j, m)
            if val > best_val:
                best_val = val
                best_mj = (m, j)
    m, j = best_mj
    s = 1.0 / m
    squares = []
    # big merged square in the corner
    big = j / m
    squares.append((big / 2.0, big / 2.0, 0.0, min(1.0, big)))
    for i in range(m):
        for k in range(m):
            if i < j and k < j:
                continue
            cx = min(1.0, (i + 0.5) * s)
            cy = min(1.0, (k + 0.5) * s)
            squares.append((cx, cy, 0.0, s))
    while len(squares) < n:
        squares.append((0.0, 0.0, 0.0, 0.0))
    return squares[:n]
# EVOLVE-BLOCK-END
