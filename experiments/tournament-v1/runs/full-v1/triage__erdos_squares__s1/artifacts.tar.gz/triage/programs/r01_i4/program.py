import math
import time


def solve(n):
    t0 = time.time()
    # F[m] = list of (x, y, s) in unit square (corner x,y), at most m squares
    F = [None] * (n + 1)
    V = [0.0] * (n + 1)
    F[0] = []
    V[0] = 0.0
    if n >= 1:
        F[1] = [(0.0, 0.0, 1.0)]
        V[1] = 1.0

    def place(sub, ox, oy, sc):
        return [(ox + x * sc, oy + y * sc, s * sc) for (x, y, s) in sub]

    for m in range(2, n + 1):
        best_v = V[m - 1]
        best_l = F[m - 1]
        if time.time() - t0 > 40:
            F[m] = best_l
            V[m] = best_v
            continue
        for k in range(2, 12):
            for j in range(0, k):
                if j == 1:
                    continue
                if j == 0:
                    mincount = k * k
                else:
                    mincount = k * k - j * j + 1
                if mincount > m:
                    continue
                e = m - mincount
                C = k * k - j * j
                # items
                items = []  # (scale, kind)
                if j >= 1:
                    items.append((j / k, 'B'))
                ncell = min(C, e)
                for _ in range(ncell):
                    items.append((1.0 / k, 'C'))
                base = (C / k) + (j / k if j >= 1 else 0.0)
                NI = len(items)
                dp = [[0.0] * (e + 1) for _ in range(NI + 1)]
                ch = [[0] * (e + 1) for _ in range(NI + 1)]
                for i in range(NI):
                    sc = items[i][0]
                    for b in range(e + 1):
                        bv = -1.0
                        bx = 0
                        for x in range(b + 1):
                            g = sc * (V[1 + x] - 1.0)
                            v = dp[i][b - x] + g
                            if v > bv + 1e-12:
                                bv = v
                                bx = x
                        dp[i + 1][b] = bv
                        ch[i + 1][b] = bx
                total = base + dp[NI][e]
                if total > best_v + 1e-9:
                    # reconstruct
                    xs = []
                    b = e
                    for i in range(NI, 0, -1):
                        x = ch[i][b]
                        xs.append(x)
                        b -= x
                    xs.reverse()
                    lst = []
                    idx = 0
                    if j >= 1:
                        lst += place(F[1 + xs[0]], 0.0, 0.0, j / k)
                        idx = 1
                    cell_i = 0
                    for r in range(k):
                        for c in range(k):
                            if r < j and c < j:
                                continue
                            x = 0
                            if idx < NI and cell_i < ncell:
                                x = xs[idx]
                                idx += 1
                            cell_i += 1
                            lst += place(F[1 + x], c / k, r / k, 1.0 / k)
                    best_v = total
                    best_l = lst
        F[m] = best_l
        V[m] = best_v

    res = []
    for (x, y, s) in F[n][:n]:
        res.append((min(1.0, max(0.0, x + s / 2)), min(1.0, max(0.0, y + s / 2)), 0.0, min(1.0, max(0.0, s))))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
