import math
import heapq
from collections import defaultdict


def solve(n):
    """
    Use a best-first search over a state space where each state represents
    a configuration of squares. We explore moves that split or merge squares
    to find high-value packings.
    """
    
    def get_state_key(squares):
        """Convert a list of squares to a hashable key."""
        return tuple(sorted((x, y, a, s) for x, y, a, s in squares))
    
    def split_square(x, y, angle, side, t):
        """Split a square into a t×t grid of smaller squares."""
        if t <= 1:
            return []
        new_side = side / t
        new_squares = []
        # Create a t×t grid of squares within the original square
        offset = side * (t - 1) / (2 * t)
        for i in range(t):
            for j in range(t):
                # Position in the local coordinate system
                local_x = (i + 0.5) * new_side - side / 2
                local_y = (j + 0.5) * new_side - side / 2
                # Rotate if needed (for angle=0, no rotation needed)
                new_x = x + local_x
                new_y = y + local_y
                new_squares.append((new_x, new_y, angle, new_side))
        return new_squares
    
    def is_valid_placement(squares):
        """Check if squares fit within [0,1]x[0,1] with disjoint interiors."""
        for x, y, angle, side in squares:
            # Check bounds (with small tolerance)
            if x - side/2 < -1e-9 or x + side/2 > 1 + 1e-9:
                return False
            if y - side/2 < -1e-9 or y + side/2 > 1 + 1e-9:
                return False
        # Check disjoint interiors (simplified: axis-aligned bounding boxes)
        for i, (x1, y1, a1, s1) in enumerate(squares):
            for x2, y2, a2, s2 in squares[i+1:]:
                # Simple AABB check
                if not (x1 + s1/2 <= x2 - s2/2 - 1e-9 or 
                        x2 + s2/2 <= x1 - s1/2 - 1e-9 or
                        y1 + s1/2 <= y2 - s2/2 - 1e-9 or
                        y2 + s2/2 <= y1 - s1/2 - 1e-9):
                    return False
        return True
    
    def sum_of_sides(squares):
        return sum(s for _, _, _, s in squares)
    
    # Start with a grid-based initial solution
    k = max(1, math.isqrt(n))
    initial_side = 1.0 / k
    initial_squares = [
        ((i + 0.5) * initial_side, (j + 0.5) * initial_side, 0.0, initial_side)
        for i in range(k) for j in range(k)
    ]
    initial_squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(initial_squares))
    initial_squares = initial_squares[:n]
    
    # BFS/best-first search
    best_sum_for_count = defaultdict(float)
    best_sum_for_count[len(initial_squares)] = sum_of_sides(initial_squares)
    
    visited = set()
    queue = [(-sum_of_sides(initial_squares), len(initial_squares), tuple(initial_squares))]
    heapq.heapify(queue)
    
    iterations = 0
    max_iterations = 100000
    
    while queue and iterations < max_iterations:
        iterations += 1
        neg_sum, count, state = heapq.heappop(queue)
        current_sum = -neg_sum
        
        if state in visited:
            continue
        visited.add(state)
        
        # Try splitting each square
        squares = list(state)
        for idx in range(len(squares)):
            x, y, angle, side = squares[idx]
            if side < 1e-9:
                continue
            
            # Try splitting into 2x2 (adds 3 new squares)
            if count + 3 <= n:
                new_squares = split_square(x, y, angle, side, 2)
                modified = squares[:idx] + new_squares + squares[idx+1:]
                
                if is_valid_placement(modified):
                    new_count = len(modified)
                    new_sum = sum_of_sides(modified)
                    
                    if new_sum > best_sum_for_count.get(new_count, -1):
                        best_sum_for_count[new_count] = new_sum
                        state_tuple = tuple(modified)
                        if state_tuple not in visited:
                            heapq.heappush(queue, (-new_sum, new_count, state_tuple))
    
    # Find best solution for count <= n
    best_count = max((c for c in best_sum_for_count if c <= n), default=n)
    
    # Return a valid solution with the best count
    if best_count == len(initial_squares):
        return initial_squares
    
    # Fall back to grid solution
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    result = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]
