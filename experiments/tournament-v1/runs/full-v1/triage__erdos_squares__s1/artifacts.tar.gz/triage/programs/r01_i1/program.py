# EVOLVE-BLOCK-START
"""Exact tilings of an m x m grid by integer squares (DFS / branch and bound),
then splitting of largest pieces, padded with zero squares."""
import math
import time
import heapq


def _search(m, n, best_score, deadline):
    h = [0] * m
    stack = []
    result = [best_score, None]
    counter = [0]
    timed_out = [False]
    total = m * m

    def rec(cnt, area_left, cur):
        if timed_out[0]:
            return
        counter[0] += 1
        if (counter[0] & 2047) == 0 and time.time() > deadline:
            timed_out[0] = True
            return
        if area_left == 0:
            sc = cur / m
            if sc > result[0] + 1e-12:
                result[0] = sc
                result[1] = list(stack)
            return
        r = n - cnt
        if r <= 0:
            return
        if (cur + math.sqrt(r * area_left)) / m <= result[0] + 1e-12:
            return
        # lowest-leftmost
        hm = m
        idx = 0
        for i in range(m):
            if h[i] < hm:
                hm = h[i]
                idx = i
        w = 0
        while idx + w < m and h[idx + w] == hm:
            w += 1
        maxs = min(w, m - hm)
        for s in range(maxs, 0, -1):
            for j in range(idx, idx + s):
                h[j] += s
            stack.append((idx, hm, s))
            rec(cnt + 1, area_left - s * s, cur + s)
            stack.pop()
            for j in range(idx, idx + s):
                h[j] -= s
            if timed_out[0]:
                return

    rec(0, total, 0)
    return result[0], result[1]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    t0 = time.time()
    total_time = 40.0
    k = max(1, math.isqrt(n))
    best = float(k)
    best_m = k
    best_t = [(i, j, 1) for i in range(k) for j in range(k)]
    best_m = k
    maxm = 12
    ms = list(range(2, maxm + 1))
    for pos, m in enumerate(ms):
        now = time.time()
        remaining = total_time - (now - t0)
        if remaining <= 0:
            break
        share = remaining / (len(ms) - pos)
        sc, til = _search(m, n, best, now + share)
        if til is not None and sc > best + 1e-12:
            best = sc
            best_m = m
            best_t = til
    m = best_m
    # pieces in unit coords
    pieces = [(x / m, y / m, s / m) for (x, y, s) in best_t]
    # split largest pieces into 4 while room remains
    extra = n - len(pieces)
    if extra >= 3:
        heap = [(-s, x, y) for (x, y, s) in pieces]
        heapq.heapify(heap)
        while extra >= 3:
            ns, x, y = heapq.heappop(heap)
            s = -ns
            hs = s / 2
            for dx in (0, hs):
                for dy in (0, hs):
                    heapq.heappush(heap, (-hs, x + dx, y + dy))
            extra -= 3
        pieces = [(x, y, -ns) for (ns, x, y) in heap]
    out = []
    for (x, y, s) in pieces[:n]:
        out.append((x + s / 2, y + s / 2, 0.0, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
