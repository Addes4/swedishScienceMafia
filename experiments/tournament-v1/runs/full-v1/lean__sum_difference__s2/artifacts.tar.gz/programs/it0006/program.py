# EVOLVE-BLOCK-START
import math
import random
import time
import numpy as np


def _count(ws, n):
    dp = [0] * (n + 1)
    dp[0] = 1
    for w in ws:
        for s in range(w, n + 1):
            dp[s] += dp[s - w]
    return sum(dp)


def _choose_n(ws, cap):
    best = 0
    n = 1
    while n < 60:
        prod = 1
        for w in ws:
            prod *= 2 * (n // w) + 1
        if prod > 4e14:
            break
        if _count(ws, n) > cap:
            break
        best = n
        n += 1
    return best


def _gen(ws, n):
    cur = [(0, n)]
    B = 1
    for w in ws:
        m = n // w
        new = []
        for v, r in cur:
            for x in range(r // w + 1):
                new.append((v + x * B, r - x * w))
        cur = new
        B *= 2 * m + 1
    return [v for v, _ in cur]


def _eval_vals(vals):
    v = np.array(sorted(set(vals)), dtype=np.int64)
    N = len(v)
    if N < 2:
        return 0.0
    tot = N * (N + 1) // 2
    arr = np.empty(tot, dtype=np.int64)
    p = 0
    for i in range(N):
        L = N - i
        arr[p:p + L] = v[i] + v[i:]
        p += L
    arr.sort()
    S = int(np.count_nonzero(arr[1:] != arr[:-1])) + 1
    tot = N * (N - 1) // 2
    arr = np.empty(tot, dtype=np.int64)
    p = 0
    for i in range(N - 1):
        L = N - 1 - i
        arr[p:p + L] = v[i + 1:] - v[i]
        p += L
    arr.sort()
    D = 2 * (int(np.count_nonzero(arr[1:] != arr[:-1])) + 1) + 1
    return math.log(D) / math.log(S) + (1 - 1 / N) / 100


_cache = {}


def _evaluate(ws, cap):
    key = (tuple(ws), cap)
    if key in _cache:
        return _cache[key]
    n = _choose_n(ws, cap)
    if n < 1:
        _cache[key] = (0.0, None)
        return _cache[key]
    vals = _gen(ws, n)
    s = _eval_vals(vals)
    _cache[key] = (s, vals)
    return _cache[key]


def solve():
    t0 = time.time()
    random.seed(1)
    small_cap = 1200
    # baselines: plain simplex
    pool = {}
    for d in range(3, 16):
        ws = tuple([1] * d)
        s, _ = _evaluate(ws, small_cap)
        pool[ws] = s
    cur = max(pool, key=lambda k: pool[k])
    cur_s = pool[cur]
    phase1_end = t0 + 45
    while time.time() < phase1_end:
        ws = list(cur)
        r = random.random()
        if r < 0.5:
            i = random.randrange(len(ws))
            ws[i] = max(1, min(5, ws[i] + random.choice([-1, 1])))
        elif r < 0.75 and len(ws) < 16:
            ws.append(random.randint(1, 4))
        elif len(ws) > 2:
            ws.pop(random.randrange(len(ws)))
        ws = tuple(sorted(ws))
        if ws not in pool:
            s, _ = _evaluate(ws, small_cap)
            pool[ws] = s
        s = pool[ws]
        if s >= cur_s - 0.002 * random.random():
            cur, cur_s = ws, s
        if random.random() < 0.05:
            cur = max(pool, key=lambda k: pool[k])
            cur_s = pool[cur]
    ranked = sorted(pool, key=lambda k: -pool[k])
    # always include plain simplex baselines
    cands = ranked[:10]
    for d in range(4, 12):
        w = tuple([1] * d)
        if w not in cands:
            cands.append(w)
    best_s, best_vals = 0.0, None
    deadline = t0 + 100
    for ws in cands:
        if time.time() > deadline:
            break
        s, vals = _evaluate(ws, 4000)
        if vals is not None and s > best_s:
            best_s, best_vals = s, vals
    if best_vals is None:
        return [0, 1, 3]
    return sorted(set(int(x) for x in best_vals))
# EVOLVE-BLOCK-END
