# EVOLVE-BLOCK-START
import math
import random
import time
from math import comb, factorial
from itertools import combinations_with_replacement

import numpy as np


def _simplex_stats(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    fd = factorial(d)
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            m = fd // (factorial(i) * factorial(j) * factorial(d - i - j))
            diffs += m * comb(n, i) * comb(n, j)
    return size, sums, diffs


def _np_score(vals):
    a = np.unique(np.array(vals, dtype=np.int64))
    if len(a) < 2:
        return 0.0
    s = np.unique((a[:, None] + a[None, :]).ravel())
    ns = len(s)
    del s
    dd = np.unique((a[:, None] - a[None, :]).ravel())
    nd = len(dd)
    return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100


def _build(d, n, rng):
    cmax = 10 ** 15 // n
    c = [rng.randint(cmax // 2, cmax) for _ in range(d)] + [0]
    res = set()
    for comb_ in combinations_with_replacement(range(d + 1), n):
        res.add(sum(c[k] for k in comb_))
    return sorted(res)


def solve():
    t0 = time.time()
    cands = []
    for d in range(1, 400):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            if n == 1 and d > 60:
                continue
            sz, su, di = _simplex_stats(d, n)
            s = math.log(di) / math.log(su) + (1 - 1 / sz) / 100
            cands.append((s, d, n))
    cands.sort(reverse=True)
    rng = random.Random(12345)
    best = None
    bs = -1.0
    for s, d, n in cands[:4]:
        if time.time() - t0 > 80:
            break
        try:
            A = _build(d, n, rng)
            if len(A) > 4000 or max(abs(x) for x in A) > 10 ** 15:
                continue
            sc = _np_score(A)
        except Exception:
            continue
        if sc > bs:
            bs, best = sc, A
    if best is None:
        return [0, 1, 3]
    return best
# EVOLVE-BLOCK-END
