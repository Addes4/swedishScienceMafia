# EVOLVE-BLOCK-START
import math
import random
import time
from math import comb, factorial


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _simplex_stats(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            m = factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))
            diffs += m * comb(n, i) * comb(n, j)
    return size, sums, diffs


def _simplex_set(d, n):
    B = 2 * n + 1
    res = []

    def rec(pos, rem, val):
        if pos == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return res


def solve():
    best_simplex = None
    best_s = 0.0
    for d in range(1, 40):
        for n in range(1, 40):
            size = comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 5e14:
                break
            sz, su, di = _simplex_stats(d, n)
            s = math.log(di) / math.log(su) + (1 - 1 / sz) / 100
            if s > best_s:
                best_s, best_simplex = s, (d, n)
    result = None
    if best_simplex:
        result = _simplex_set(*best_simplex)

    # small local-search fallback
    best = [7, 15, 18, 22, -3, -2]
    bs = _score(best)
    cur = best[:]
    deadline = time.time() + 5
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-3, 3)
        if random.random() < 0.05:
            cand.append(random.randint(1, 20))
        if random.random() < 0.03 and len(cand) > 5:
            cand = cand[1:]
        s = _score(cand)
        if s >= bs:
            best, bs, cur = cand[:], s, cand
        elif random.random() < 0.1:
            cur = best[:]
    if result is not None and best_s >= bs:
        return sorted(set(result))
    return sorted(set(best))
# EVOLVE-BLOCK-END
