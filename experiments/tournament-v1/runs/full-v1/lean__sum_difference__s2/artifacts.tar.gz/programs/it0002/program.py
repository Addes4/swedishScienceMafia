# EVOLVE-BLOCK-START
import math
import time
from math import comb, factorial
import numpy as np


def _simplex_stats(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            m = factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))
            diffs += m * comb(n, i) * comb(n, j)
    return size, sums, diffs


def _points(d, n, lo):
    B = 2 * n + 1
    res = []

    def rec(pos, rem, val, used):
        if pos == d:
            if used >= lo:
                res.append(val)
            return
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val * B + x, used + x)

    rec(0, n, 0, 0)
    return res


def _exact(vals):
    a = np.array(sorted(set(vals)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    ds = set()
    s_all = []
    d_all = []
    # chunked unique to limit memory
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(1, 40):
        for n in range(1, 40):
            size = comb(n + d, d)
            if size > 8000:
                break
            if (2 * n + 1) ** d > 5e14:
                break
            if size > 4000:
                continue
            sz, su, di = _simplex_stats(d, n)
            s = math.log(di) / math.log(su) + (1 - 1 / sz) / 100
            cands.append((s, d, n))
    cands.sort(reverse=True)
    best_s, best_set = 0.0, None
    if cands:
        s, d, n = cands[0]
        best_s, best_set = s, _points(d, n, 0)

    # try shell variants for a few top simplex params (also slightly larger ones)
    extra = []
    for d in range(1, 40):
        for n in range(1, 40):
            size = comb(n + d, d)
            if size > 8000:
                break
            if (2 * n + 1) ** d > 5e14:
                break
            extra.append((d, n, size))
    top = [(d, n) for _, d, n in cands[:5]]
    # add bigger full simplices whose shells could fit within 4000
    for d, n, size in extra:
        if size > 4000 and size < 8000 and (d, n) not in top:
            top.append((d, n))
    tried = 0
    for d, n in top:
        for lo in range(1, n):
            if time.time() - t0 > 90:
                break
            pts = _points(d, n, lo)
            if len(pts) > 4000 or len(pts) < 50:
                continue
            try:
                s = _exact(pts)
            except MemoryError:
                continue
            if s > best_s:
                best_s, best_set = s, pts
    return sorted(set(int(x) for x in best_set))
# EVOLVE-BLOCK-END
