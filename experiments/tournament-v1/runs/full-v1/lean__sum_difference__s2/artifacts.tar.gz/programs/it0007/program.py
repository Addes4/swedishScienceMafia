# EVOLVE-BLOCK-START
import math
import random
import time
from math import comb, factorial
import numpy as np


def _simplex_stats(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            m = factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))
            diffs += m * comb(n, i) * comb(n, j)
    return size, sums, diffs


def _points(d, n):
    res = []

    def rec(pos, rem, cur):
        if pos == d:
            res.append(tuple(cur))
            return
        for x in range(rem + 1):
            cur.append(x)
            rec(pos + 1, rem - x, cur)
            cur.pop()

    rec(0, n, [])
    return np.array(res, dtype=np.int64)


def _eval(a):
    a = np.unique(a)
    k = len(a)
    if k < 2:
        return 0.0
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    dd = np.unique((a[:, None] - a[None, :]).ravel()).size
    return math.log(dd) / math.log(s) + (1 - 1 / k) / 100


def solve():
    t0 = time.time()
    deadline = t0 + 95
    cands = []
    for d in range(1, 40):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 5e14:
                break
            sz, su, di = _simplex_stats(d, n)
            s = math.log(di) / math.log(su) + (1 - 1 / sz) / 100
            cands.append((s, d, n))
    cands.sort(reverse=True)
    top = cands[:3]
    d0, n0 = top[0][1], top[0][2]
    P0 = _points(d0, n0)
    base_coef = np.array([(2 * n0 + 1) ** i for i in range(d0)], dtype=np.int64)
    best_a = P0 @ base_coef
    best_s = top[0][0]  # exact formula score
    best_state = (P0, base_coef)

    def est_time(P):
        k = len(P)
        return 2.5e-7 * k * k * 2 + 0.01

    # scan bases for top candidates
    for (_, d, n) in top:
        P = _points(d, n)
        for B in range(2 * n, max(1, n - 1), -1):
            if time.time() + est_time(P) * 1.5 > deadline - 30:
                break
            if n * B ** (d - 1) * 2 > 5e14:
                continue
            c = np.array([B ** i for i in range(d)], dtype=np.int64)
            s = _eval(P @ c)
            if s > best_s + 1e-12:
                best_s = s
                best_state = (P, c)

    # coefficient hill climb on best state
    P, c = best_state
    c = c.copy()
    cur_s = best_s
    n_max = int(P.max()) if len(P) else 1
    while time.time() + est_time(P) * 1.5 < deadline:
        c2 = c.copy()
        i = random.randrange(len(c2))
        r = random.random()
        if r < 0.5:
            c2[i] += random.choice([-1, 1]) * random.randint(1, max(1, int(c2[i]) // 8))
        elif r < 0.8:
            c2[i] += random.choice([-1, 1])
        else:
            j = random.randrange(len(c2))
            c2[i], c2[j] = c2[j], c2[i]
        if c2.min() < 1 or int(c2.max()) * n_max * 2 > 5e14:
            continue
        s = _eval(P @ c2)
        if s >= cur_s:
            if s > best_s + 1e-12:
                best_s = s
                best_state = (P, c2.copy())
            cur_s = s
            c = c2

    P, c = best_state
    res = np.unique(P @ c)
    res = res - res.min()
    return [int(x) for x in res]
# EVOLVE-BLOCK-END
