# EVOLVE-BLOCK-START
import math
import random
import time
import numpy as np


def _count(d, m, n):
    poly = [1]
    base = [1] * (m + 1)
    for _ in range(d):
        new = [0] * min(len(poly) + m, n + 1)
        for i, c in enumerate(poly):
            if c == 0:
                continue
            for j in range(m + 1):
                if i + j > n:
                    break
                new[i + j] += c
        poly = new
    return sum(poly)


def _gen(d, m, n):
    B = 2 * m + 1
    res = []

    def rec(pos, rem, val):
        if pos == d:
            res.append(val)
            return
        for x in range(min(m, rem) + 1):
            rec(pos + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return res


def _fscore(vals):
    a = np.array(sorted(vals), dtype=np.int64)
    k = len(a)
    iu = np.triu_indices(k)
    s = np.unique(a[iu[0]] + a[iu[1]]).size
    il = np.tril_indices(k, -1)
    dd = np.unique(a[il[0]] - a[il[1]]).size
    nd = 2 * dd + 1
    return math.log(nd) / math.log(s) + (1 - 1 / k) / 100


def solve():
    start = time.time()
    budget = 95
    cands = []
    for d in range(2, 16):
        for n in range(2, 14):
            for m in range(max(1, (n + 1) // 2), n + 1):
                if (2 * m + 1) ** d > 5e14:
                    continue
                if m * d < n and m < n:
                    continue
                size = _count(d, m, n)
                if size > 4000 or size < 600:
                    continue
                cands.append((size, d, m, n))
    simplex = [c for c in cands if c[2] == c[3]]
    others = [c for c in cands if c[2] != c[3]]
    simplex.sort(reverse=True)
    random.seed(1)
    random.shuffle(others)
    order = simplex[:4] + others
    # interleave: also keep large-size ones early
    best_vals = None
    best_s = -1.0
    for size, d, m, n in order:
        if time.time() - start > budget:
            break
        vals = _gen(d, m, n)
        s = _fscore(vals)
        if s > best_s:
            best_s, best_vals = s, vals
    if best_vals is None:
        return [0, 1, 3, 7]
    return sorted(set(int(v) for v in best_vals))
# EVOLVE-BLOCK-END
