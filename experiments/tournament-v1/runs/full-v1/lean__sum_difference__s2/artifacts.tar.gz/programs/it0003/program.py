# EVOLVE-BLOCK-START
import math
import random
import time
from math import comb, factorial
import numpy as np


def _simplex_stats(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            m = factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))
            diffs += m * comb(n, i) * comb(n, j)
    return size, sums, diffs


def _simplex_points(d, n):
    res = []

    def rec(pos, rem, val):
        if pos == d:
            res.append(tuple(val))
            return
        for x in range(rem + 1):
            val.append(x)
            rec(pos + 1, rem - x, val)
            val.pop()

    rec(0, n, [])
    return res


def _climb(d, n, deadline):
    m = n
    B = 2 * m + 1
    pw = [B ** i for i in range(d)]
    off = sum(m * p for p in pw)
    size = B ** d
    cs = np.zeros(size, dtype=np.int16)
    cd = np.zeros(size, dtype=np.int16)
    pts = _simplex_points(d, n)
    codes = [sum(c[i] * pw[i] for i in range(d)) for c in pts]
    buf = np.zeros(4100, dtype=np.int64)
    k = len(codes)
    buf[:k] = codes
    E = buf[:k]
    for a in codes:
        cs[a + E] += 1
        cd[a - E + off] += 1
    st = {"S": int(np.count_nonzero(cs)), "D": int(np.count_nonzero(cd)), "k": k}
    inA = set(codes)

    def add(ep):
        k = st["k"]
        Ek = buf[:k]
        idx = ep + Ek
        st["S"] += int((cs[idx] == 0).sum())
        cs[idx] += 1
        if cs[2 * ep] == 0:
            st["S"] += 1
        cs[2 * ep] += 1
        idx = ep - Ek + off
        st["D"] += int((cd[idx] == 0).sum())
        cd[idx] += 1
        idx = Ek - ep + off
        st["D"] += int((cd[idx] == 0).sum())
        cd[idx] += 1
        if cd[off] == 0:
            st["D"] += 1
        cd[off] += 1
        buf[k] = ep
        st["k"] = k + 1
        inA.add(int(ep))

    def remove(i):
        k = st["k"]
        ep = int(buf[i])
        buf[i] = buf[k - 1]
        k -= 1
        st["k"] = k
        Ek = buf[:k]
        idx = ep + Ek
        cs[idx] -= 1
        st["S"] -= int((cs[idx] == 0).sum())
        cs[2 * ep] -= 1
        if cs[2 * ep] == 0:
            st["S"] -= 1
        idx = ep - Ek + off
        cd[idx] -= 1
        st["D"] -= int((cd[idx] == 0).sum())
        idx = Ek - ep + off
        cd[idx] -= 1
        st["D"] -= int((cd[idx] == 0).sum())
        cd[off] -= 1
        if cd[off] == 0:
            st["D"] -= 1
        inA.discard(ep)
        return ep

    def f():
        k = st["k"]
        return math.log(st["D"]) / math.log(st["S"]) + (1 - 1 / k) / 100

    cur = f()
    it = 0
    rnd = random.random
    while True:
        it += 1
        if it % 30 == 0 and time.time() > deadline:
            break
        k = st["k"]
        r = rnd()
        # propose point
        j = random.randrange(k)
        c = int(buf[j])
        coords = []
        for i in range(d):
            coords.append((c // pw[i]) % B)
        nch = 1 if rnd() < 0.6 else 2
        ok = True
        for _ in range(nch):
            i = random.randrange(d)
            coords[i] += random.choice((-1, 1))
            if coords[i] < 0 or coords[i] > m:
                ok = False
                break
        if not ok:
            continue
        p = sum(coords[i] * pw[i] for i in range(d))
        if p in inA:
            continue
        if r < 0.75:
            i = random.randrange(k)
            q = remove(i)
            add(p)
            new = f()
            if new >= cur:
                cur = new
            else:
                remove(st["k"] - 1)
                add(q)
        elif r < 0.92:
            if st["k"] >= 4000:
                continue
            add(p)
            new = f()
            if new >= cur:
                cur = new
            else:
                remove(st["k"] - 1)
        else:
            if k <= 3:
                continue
            i = random.randrange(k)
            q = remove(i)
            new = f()
            if new >= cur:
                cur = new
            else:
                add(q)
    return cur, [int(x) for x in buf[:st["k"]]]


def solve():
    t0 = time.time()
    cands = []
    for d in range(1, 40):
        for n in range(1, 40):
            size = comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 5e14:
                break
            sz, su, di = _simplex_stats(d, n)
            s = math.log(di) / math.log(su) + (1 - 1 / sz) / 100
            cands.append((s, d, n))
    cands.sort(reverse=True)
    best_s, bd, bn = cands[0]
    base = None
    # best simplex fitting in the count-array budget
    pick = None
    for s, d, n in cands:
        if (2 * n + 1) ** d <= 2.5e7:
            pick = (s, d, n)
            break
    result = None
    if pick is not None:
        s, d, n = pick
        try:
            deadline = t0 + 100
            sc, res = _climb(d, n, deadline)
            result = (sc, res)
        except Exception:
            result = None
    B = 2 * bn + 1
    simplex = []
    for c in _simplex_points(bd, bn):
        v = 0
        for x in c:
            v = v * B + x
        simplex.append(v)
    if result is not None and result[0] > best_s:
        return sorted(set(result[1]))
    return sorted(set(simplex))
# EVOLVE-BLOCK-END
