# EVOLVE-BLOCK-START
import time
import numpy as np
from scipy.optimize import minimize


def _feasible_radii(centers):
    n = len(centers)
    r = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    r = np.maximum(r, 0)
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if r[i] + r[j] > d:
                    s = d / (r[i] + r[j]) if r[i] + r[j] > 0 else 0
                    r[i] *= s
                    r[j] *= s
                    changed = True
        if not changed:
            break
    return r


def _optimize(x0, n, iu, ju, maxiter=300):
    def obj(x):
        return -np.sum(x[2 * n:])

    def grad(x):
        g = np.zeros(3 * n)
        g[2 * n:] = -1
        return g

    def cons(x):
        c = x[:2 * n].reshape(n, 2)
        r = x[2 * n:]
        d = np.sqrt(((c[iu] - c[ju]) ** 2).sum(1))
        pair = d - r[iu] - r[ju]
        wall = np.concatenate([c[:, 0] - r, 1 - c[:, 0] - r, c[:, 1] - r, 1 - c[:, 1] - r])
        return np.concatenate([pair, wall])

    def cjac(x):
        c = x[:2 * n].reshape(n, 2)
        m = len(iu)
        J = np.zeros((m + 4 * n, 3 * n))
        diff = c[iu] - c[ju]
        d = np.sqrt((diff ** 2).sum(1)) + 1e-12
        u = diff / d[:, None]
        k = np.arange(m)
        J[k, 2 * iu] = u[:, 0]
        J[k, 2 * iu + 1] = u[:, 1]
        J[k, 2 * ju] = -u[:, 0]
        J[k, 2 * ju + 1] = -u[:, 1]
        J[k, 2 * n + iu] = -1
        J[k, 2 * n + ju] = -1
        a = np.arange(n)
        J[m + a, 2 * a] = 1
        J[m + a, 2 * n + a] = -1
        J[m + n + a, 2 * a] = -1
        J[m + n + a, 2 * n + a] = -1
        J[m + 2 * n + a, 2 * a + 1] = 1
        J[m + 2 * n + a, 2 * n + a] = -1
        J[m + 3 * n + a, 2 * a + 1] = -1
        J[m + 3 * n + a, 2 * n + a] = -1
        return J

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    res = minimize(obj, x0, jac=grad, method='SLSQP', bounds=bounds,
                   constraints=[{'type': 'ineq', 'fun': cons, 'jac': cjac}],
                   options={'maxiter': maxiter, 'ftol': 1e-10})
    return res.x


def solve(n=26):
    rng = np.random.default_rng(12345)
    t0 = time.time()
    budget = 200
    iu, ju = np.triu_indices(n, 1)
    best = None
    best_s = -1
    it = 0
    while time.time() - t0 < budget:
        mode = it % 3
        if mode == 0:
            c = rng.random((n, 2)) * 0.9 + 0.05
        elif mode == 1:
            # jittered grid-ish
            k = 6
            g = np.array([[(i + 0.5) / k, (j + 0.5) / k] for i in range(k) for j in range(k)])
            idx = rng.permutation(len(g))[:n]
            c = g[idx] + rng.normal(0, 0.03, (n, 2))
        else:
            c = [[0.5, 0.5]]
            c += [[0.5 + 0.25 * np.cos(2 * np.pi * i / 8), 0.5 + 0.25 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
            c += [[0.5 + 0.43 * np.cos(2 * np.pi * i / 17), 0.5 + 0.43 * np.sin(2 * np.pi * i / 17)] for i in range(17)]
            c = np.array(c[:n]) + rng.normal(0, 0.03, (n, 2))
        c = np.clip(c, 0.03, 0.97)
        r0 = np.full(n, 0.05)
        x0 = np.concatenate([c.ravel(), r0])
        try:
            x = _optimize(x0, n, iu, ju)
        except Exception:
            it += 1
            continue
        cc = np.clip(x[:2 * n].reshape(n, 2), 0, 1)
        r = x[2 * n:].copy()
        # make strictly feasible
        r = np.maximum(r, 0)
        r = np.minimum(r, np.minimum.reduce([cc[:, 0], cc[:, 1], 1 - cc[:, 0], 1 - cc[:, 1]]))
        d = np.sqrt(((cc[iu] - cc[ju]) ** 2).sum(1))
        for _ in range(5):
            viol = r[iu] + r[ju] - d
            if viol.max() <= 0:
                break
            for k in np.where(viol > 0)[0]:
                i, j = iu[k], ju[k]
                s = d[k] / (r[i] + r[j])
                r[i] *= s
                r[j] *= s
        s = r.sum()
        if np.all(r[iu] + r[ju] <= d + 1e-12) and s > best_s:
            best_s = s
            best = (cc.copy(), r.copy())
        it += 1
    if best is None:
        c = rng.random((n, 2)) * 0.9 + 0.05
        return c, _feasible_radii(c)
    return best
# EVOLVE-BLOCK-END
