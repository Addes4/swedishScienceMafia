# EVOLVE-BLOCK-START
"""Search over capped simplex-like lattice sets embedded into integers."""
import math
import time
import numpy as np


def _score_arr(a):
    n = len(a)
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _count(d, n, c):
    f = [1] * (n + 1)  # k=0: only left>=0 gives 1 (point set of empty dims)
    for _ in range(d):
        g = [0] * (n + 1)
        for left in range(n + 1):
            t = 0
            for v in range(min(c, left) + 1):
                t += f[left - v]
            g[left] = t
        f = g
    return f[n]


def _embed(d, n, c):
    B = 2 * c + 1
    res = []

    def rec(k, left, val, mult):
        if k == d:
            res.append(val)
            return
        for v in range(min(c, left) + 1):
            rec(k + 1, left - v, val + v * mult, mult * B)

    rec(0, n, 0, 1)
    return res


def solve():
    start = time.time()
    cands = []
    for d in range(1, 40):
        for n in range(1, 80):
            for c in range(1, n + 1):
                if (2 * c + 1) ** d > 4e14:
                    break
                if c < n and c * d <= n:
                    continue  # cap inactive-ish duplicates of c==n would be wasteful
                size = _count(d, n, c)
                if size > 4000:
                    break
                if size < 4:
                    continue
                cands.append((size, d, n, c))
    cands = sorted(set(cands))
    best, best_s = [0, 1, 3], -1
    for size, d, n, c in cands:
        el = time.time() - start
        est = size * size * 1.5e-7 + 0.002
        if el + est > 100:
            continue
        vals = _embed(d, n, c)
        a = np.array(vals, dtype=np.int64)
        s = _score_arr(a)
        if s > best_s:
            best_s, best = s, vals
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END
