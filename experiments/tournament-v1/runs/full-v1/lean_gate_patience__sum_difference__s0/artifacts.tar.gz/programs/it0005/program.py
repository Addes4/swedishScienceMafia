# EVOLVE-BLOCK-START
"""Simplex-like lattice sets embedded into integers, refined by annealing."""
import math
import time
import random
import numpy as np


def _score_arr(a):
    n = len(a)
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _points(d, n):
    res = []

    def rec(pref, left, k):
        if k == d:
            res.append(tuple(pref))
            return
        for v in range(left + 1):
            pref.append(v)
            rec(pref, left - v, k + 1)
            pref.pop()

    rec([], n, 0)
    return res


def _embed(d, n, nb=None):
    pts = _points(d, n)
    if nb is None:
        nb = n
    B = 2 * nb + 1
    w = [B ** i for i in range(d)]
    vals = [sum(c * x for c, x in zip(p, w)) for p in pts]
    return vals


def _anneal(d, n, start, deadline):
    n2 = n + 1
    U = math.comb(n2 + d, d)
    if U > 3500:
        n2 = n
        U = math.comb(n2 + d, d)
        if U > 3500:
            return None
    pts = _points(d, n2)
    B = 2 * n2 + 1
    w = [B ** i for i in range(d)]
    vals = np.array([sum(c * x for c, x in zip(p, w)) for p in pts], dtype=np.int64)
    if vals.max() > 10 ** 15:
        return None
    sums_pts = [sum(p) for p in pts]
    S = vals[:, None] + vals[None, :]
    us, sidx = np.unique(S.ravel(), return_inverse=True)
    sidx = sidx.reshape(U, U).astype(np.int32)
    del S
    Dm = vals[:, None] - vals[None, :]
    ud, didx = np.unique(Dm.ravel(), return_inverse=True)
    didx = didx.reshape(U, U).astype(np.int32)
    del Dm
    cs = np.zeros(len(us), dtype=np.int32)
    cd = np.zeros(len(ud), dtype=np.int32)
    inset = np.zeros(U, dtype=bool)
    mem = np.zeros(U, dtype=np.int64)
    pos = np.full(U, -1, dtype=np.int64)
    cnt = 0
    nS = 0
    nD = 0

    def add_state(k):
        nonlocal cnt, nS, nD
        m = mem[:cnt]
        si = np.concatenate((sidx[k, m], sidx[k:k + 1, k]))
        di = np.concatenate((didx[k, m], didx[m, k], didx[k:k + 1, k]))
        zs = si[cs[si] == 0]
        zd = di[cd[di] == 0]
        ns = np.unique(zs).size
        nd = np.unique(zd).size
        cs[si] += 1
        np.add.at(cd, di, 1)
        mem[cnt] = k
        pos[k] = cnt
        cnt += 1
        inset[k] = True
        nS += ns
        nD += nd

    def rem_state(k):
        nonlocal cnt, nS, nD
        p = pos[k]
        last = mem[cnt - 1]
        mem[p] = last
        pos[last] = p
        pos[k] = -1
        cnt -= 1
        inset[k] = False
        m = mem[:cnt]
        si = np.concatenate((sidx[k, m], sidx[k:k + 1, k]))
        di = np.concatenate((didx[k, m], didx[m, k], didx[k:k + 1, k]))
        cs[si] -= 1
        np.subtract.at(cd, di, 1)
        ns = np.unique(si[cs[si] == 0]).size
        nd = np.unique(di[cd[di] == 0]).size
        nS -= ns
        nD -= nd

    for i in range(U):
        if sums_pts[i] <= n:
            add_state(i)

    def f():
        if cnt < 3 or nS < 2:
            return -1.0
        return math.log(nD) / math.log(nS) + (1 - 1 / cnt) / 100

    cur = f()
    best = cur
    best_mem = mem[:cnt].copy()
    t0 = time.time()
    total = max(deadline - t0, 1.0)
    T0, T1 = 1.5e-3, 3e-5
    rnd = random.Random(1)
    it = 0
    T = T0
    while True:
        it += 1
        if (it & 127) == 0:
            now = time.time()
            if now >= deadline:
                break
            fr = (now - t0) / total
            T = T0 * (T1 / T0) ** fr
        if rnd.random() < 0.5 and cnt > 3:
            k = int(mem[rnd.randrange(cnt)])
            rem_state(k)
            new = f()
            if new >= cur or rnd.random() < math.exp((new - cur) / T):
                cur = new
            else:
                add_state(k)
        else:
            if cnt >= 3990:
                continue
            k = rnd.randrange(U)
            tries = 0
            while inset[k] and tries < 20:
                k = rnd.randrange(U)
                tries += 1
            if inset[k]:
                continue
            add_state(k)
            new = f()
            if new >= cur or rnd.random() < math.exp((new - cur) / T):
                cur = new
            else:
                rem_state(k)
        if cur > best + 1e-12:
            best = cur
            best_mem = mem[:cnt].copy()
    return [int(v) for v in vals[best_mem]]


def solve():
    start = time.time()
    cands = []
    for d in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 4:
                continue
            if n * (2 * n + 1) ** (d - 1) > 9e14:
                break
            cands.append((size, d, n))
    cands.sort()
    best, best_s = [0, 1, 3], -1
    best_dn = None
    for size, d, n in cands:
        el = time.time() - start
        est = size * size * 1.2e-7
        if el + est > 60:
            continue
        vals = _embed(d, n)
        a = np.array(vals, dtype=np.int64)
        s = _score_arr(a)
        if s > best_s:
            best_s, best, best_dn = s, vals, (d, n)
    result = sorted(set(int(v) for v in best))
    if best_dn is not None:
        try:
            deadline = start + 90
            if deadline - time.time() > 5:
                cand = _anneal(best_dn[0], best_dn[1], best, deadline)
                if cand is not None and 3 <= len(cand) <= 4000:
                    cand = sorted(set(cand))
                    m = min(cand)
                    cand = [c - m for c in cand]
                    if max(cand) <= 10 ** 15:
                        sc = _score_arr(np.array(cand, dtype=np.int64))
                        if sc > best_s:
                            result = cand
        except Exception:
            pass
    return result
# EVOLVE-BLOCK-END
