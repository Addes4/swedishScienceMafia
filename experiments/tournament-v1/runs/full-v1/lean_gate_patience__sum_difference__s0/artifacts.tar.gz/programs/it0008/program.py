import math


def _counts(d, n):
    S = math.comb(2 * n + d, d)
    D = 0
    for a in range(0, min(d, n) + 1):
        for b in range(0, min(d - a, n) + 1):
            D += (math.factorial(d) // (math.factorial(a) * math.factorial(b)
                  * math.factorial(d - a - b))) * math.comb(n, a) * math.comb(n, b)
    return S, D


def _gen(d, n):
    B = 2 * n + 1
    pts = []

    def rec(i, rem, val, mult):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * mult, mult * B)

    rec(0, n, 0, 1)
    return pts


def solve():
    best = None
    best_score = -1.0
    for d in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d > 10 ** 14:
                break
            if size < 2:
                continue
            S, D = _counts(d, n)
            sc = math.log(D) / math.log(S) + (1 - 1 / size) / 100
            if sc > best_score:
                best_score = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
