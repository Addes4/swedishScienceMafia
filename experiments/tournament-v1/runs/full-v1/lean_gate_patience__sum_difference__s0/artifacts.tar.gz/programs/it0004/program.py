# EVOLVE-BLOCK-START
"""Search over simplex-like and slab-like lattice sets embedded into integers."""
import math
import time
import numpy as np


def _score_arr(a):
    n = len(a)
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _points(d, n):
    res = []

    def rec(pref, left, k):
        if k == d:
            res.append(tuple(pref))
            return
        for v in range(left + 1):
            pref.append(v)
            rec(pref, left - v, k + 1)
            pref.pop()

    rec([], n, 0)
    return res


def _embed(d, n):
    pts = _points(d, n)
    B = 2 * n + 1
    w = [B ** i for i in range(d)]
    vals = [sum(c * x for c, x in zip(p, w)) for p in pts]
    return vals


def solve():
    start = time.time()
    cands = []
    for d in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 4:
                continue
            if n * (2 * n + 1) ** (d - 1) > 9e14:
                break
            cands.append((size, d, n))
    cands.sort()
    best, best_s = [0, 1, 3], -1
    best_dn = (2, 2)
    for size, d, n in cands:
        el = time.time() - start
        est = size * size * 1.2e-7
        if el + est > 60:
            continue
        vals = _embed(d, n)
        a = np.array(vals, dtype=np.int64)
        s = _score_arr(a)
        if s > best_s:
            best_s, best = s, vals
            best_dn = (d, n)

    # Stage 2: slabs m <= sum <= n
    d0, n0 = best_dn
    pairs = []
    for d in range(2, 30):
        for n in range(2, 60):
            full = math.comb(n + d, d)
            if full <= 4000 or full > 40000:
                continue
            if n * (2 * n + 1) ** (d - 1) > 9e14:
                continue
            pairs.append((abs(d - d0) + abs(n - n0), d, n))
    pairs.sort()
    for _, d, n in pairs:
        if time.time() - start > 85:
            break
        pts = np.array(_points(d, n), dtype=np.int64)
        B = 2 * n + 1
        w = np.array([B ** i for i in range(d)], dtype=np.int64)
        vals = pts @ w
        sm = pts.sum(axis=1)
        cum = np.bincount(sm, minlength=n + 1)
        # slab sizes: number with sum >= m
        suffix = np.cumsum(cum[::-1])[::-1]
        ms = [m for m in range(1, n + 1) if 300 <= suffix[m] <= 4000]
        if len(ms) > 3:
            idx = [0, len(ms) // 2, len(ms) - 1]
            ms = [ms[i] for i in idx]
        for m in ms:
            size = int(suffix[m])
            el = time.time() - start
            if el + size * size * 1.2e-7 > 105:
                continue
            a = vals[sm >= m]
            s = _score_arr(a)
            if s > best_s:
                best_s, best = s, [int(v) for v in a]
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END
