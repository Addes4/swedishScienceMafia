# EVOLVE-BLOCK-START
"""Simplex-like lattice sets {x>=0, sum<=n} in Z^d, embedded into integers with
random large weights (allows large d), chosen by analytic sum/diff counts."""
import math
import time
import itertools
import random
import numpy as np


def _score_arr(a):
    n = len(a)
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _theory(d, n):
    S = math.comb(2 * n + d, d)
    D = 0
    for i in range(0, min(n, d) + 1):
        for j in range(0, min(n, d - i) + 1):
            D += (math.comb(d, i) * math.comb(d - i, j)
                  * math.comb(n, i) * math.comb(n, j))
    return D, S


def _build(d, n, w):
    vals = []
    ww = [0] + list(w)
    for ms in itertools.combinations_with_replacement(range(d + 1), n):
        vals.append(sum(ww[i] for i in ms))
    return vals


def solve():
    start = time.time()
    cands = []
    for n in range(1, 30):
        d = 1
        while True:
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size >= 4:
                D, S = _theory(d, n)
                sc = math.log(D) / math.log(S) + (1 - 1 / size) / 100
                cands.append((sc, d, n, size))
            d += 1
    cands.sort(reverse=True)
    best, best_s = [0, 1, 3], -1
    rng = random.Random(12345)
    tried = 0
    for sc, d, n, size in cands:
        if tried >= 8 or time.time() - start > 90:
            break
        tried += 1
        if n * (2 * n + 1) ** (d - 1) <= 9e14:
            w = [(2 * n + 1) ** i for i in range(d)]
            attempts = 1
        else:
            attempts = 3
            w = None
        for _ in range(attempts):
            if w is None or attempts > 1:
                if n * (2 * n + 1) ** (d - 1) > 9e14:
                    top = 900_000_000_000_000 // n
                    w = [rng.randint(top // 2, top) for _ in range(d)]
            vals = _build(d, n, w)
            if len(set(vals)) != len(vals) or max(vals) > 10 ** 15:
                continue
            a = np.array(vals, dtype=np.int64)
            s = _score_arr(a)
            if s > best_s:
                best_s, best = s, vals
            if s >= sc - 1e-9:
                break
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END
