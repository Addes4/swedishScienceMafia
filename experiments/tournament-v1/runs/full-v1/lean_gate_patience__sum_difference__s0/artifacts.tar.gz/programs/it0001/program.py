# EVOLVE-BLOCK-START
"""Search over simplex-like lattice sets embedded into integers."""
import math
import time
import numpy as np


def _score_arr(a):
    n = len(a)
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _points(d, n):
    res = []

    def rec(pref, left, k):
        if k == d:
            res.append(tuple(pref))
            return
        for v in range(left + 1):
            pref.append(v)
            rec(pref, left - v, k + 1)
            pref.pop()

    rec([], n, 0)
    return res


def _embed(d, n):
    pts = _points(d, n)
    B = 4 * n + 3
    w = [B ** i for i in range(d)]
    vals = [sum(c * x for c, x in zip(p, w)) for p in pts]
    return vals


def solve():
    start = time.time()
    cands = []
    for d in range(1, 14):
        for n in range(1, 40):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 4:
                continue
            if (4 * n + 3) ** d * n > 1e14:
                break
            cands.append((size, d, n))
    cands.sort()
    best, best_s = [0, 1, 3], -1
    for size, d, n in cands:
        if time.time() - start > 90:
            break
        if size > 1500 and time.time() - start > 60:
            continue
        vals = _embed(d, n)
        a = np.array(vals, dtype=np.int64)
        s = _score_arr(a)
        if s > best_s:
            best_s, best = s, vals
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END
