# EVOLVE-BLOCK-START
"""Search over simplex-like lattice sets (plain and weighted) embedded into integers."""
import math
import time
import numpy as np


def _score_arr(a):
    n = len(a)
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _points(d, n):
    res = []

    def rec(pref, left, k):
        if k == d:
            res.append(tuple(pref))
            return
        for v in range(left + 1):
            pref.append(v)
            rec(pref, left - v, k + 1)
            pref.pop()

    rec([], n, 0)
    return res


def _embed(d, n):
    pts = _points(d, n)
    B = 2 * n + 1
    w = [B ** i for i in range(d)]
    vals = [sum(c * x for c, x in zip(p, w)) for p in pts]
    return vals


def _weighted_vals(weights, T):
    vals = np.zeros(1, dtype=np.int64)
    wts = np.zeros(1, dtype=np.int64)
    mult = 1
    for w in weights:
        c = T // w
        if c == 0:
            continue
        nv = []
        nw = []
        for k in range(c + 1):
            m = wts + k * w <= T
            nv.append(vals[m] + k * mult)
            nw.append(wts[m] + k * w)
        vals = np.concatenate(nv)
        wts = np.concatenate(nw)
        mult *= (2 * c + 1)
    return vals


def _weighted_cands(limit=4000):
    out = []
    TM = 40
    for d3 in range(0, 9):
        for d2 in range(0, 16):
            for d1 in range(0, 31):
                if d2 == 0 and d3 == 0:
                    continue
                if d1 + d2 + d3 < 2:
                    continue
                cnt = [0] * (TM + 1)
                cnt[0] = 1
                for w, k in ((1, d1), (2, d2), (3, d3)):
                    for _ in range(k):
                        for t in range(w, TM + 1):
                            cnt[t] += cnt[t - w]
                tot = 0
                for T in range(TM + 1):
                    tot += cnt[T]
                    if tot > limit:
                        break
                    if tot < 200:
                        continue
                    prod = 1
                    for w, k in ((1, d1), (2, d2), (3, d3)):
                        c = T // w
                        if c > 0:
                            prod *= (2 * c + 1) ** k
                    if prod > 9e14:
                        continue
                    out.append((tot, d1, d2, d3, T))
    return out


def solve():
    start = time.time()
    cands = []
    for d in range(1, 40):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 4:
                continue
            if n * (2 * n + 1) ** (d - 1) > 9e14:
                break
            cands.append((size, d, n))
    cands.sort()
    best, best_s = [0, 1, 3], -1
    best_size = 4
    for size, d, n in cands:
        el = time.time() - start
        est = size * size * 1.2e-7
        if el + est > 60:
            continue
        vals = _embed(d, n)
        a = np.array(vals, dtype=np.int64)
        s = _score_arr(a)
        if s > best_s:
            best_s, best, best_size = s, vals, size

    # weighted simplices stage
    try:
        wc = _weighted_cands()
        wc.sort(key=lambda t: abs(math.log(t[0] / max(best_size, 1))))
        for size, d1, d2, d3, T in wc:
            el = time.time() - start
            est = size * size * 2.5e-7 + 0.05
            if el + est > 100:
                continue
            weights = [1] * d1 + [2] * d2 + [3] * d3
            a = _weighted_vals(weights, T)
            if len(a) < 4 or int(np.abs(a).max()) > 10 ** 15:
                continue
            s = _score_arr(a)
            if s > best_s:
                best_s, best = s, [int(v) for v in a]
    except Exception:
        pass
    return sorted(set(int(v) for v in best))
# EVOLVE-BLOCK-END
