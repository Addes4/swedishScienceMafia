import numpy as np
import time
from scipy.optimize import minimize, linprog

N_DEFAULT = 26


def _setup(n):
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    # linear wall constraints: A v + b >= 0
    A = np.zeros((4 * n, 3 * n))
    b = np.zeros(4 * n)
    for i in range(n):
        A[4 * i, i] = 1; A[4 * i, 2 * n + i] = -1               # x - r >= 0
        A[4 * i + 1, i] = -1; A[4 * i + 1, 2 * n + i] = -1; b[4 * i + 1] = 1  # 1-x-r
        A[4 * i + 2, n + i] = 1; A[4 * i + 2, 2 * n + i] = -1
        A[4 * i + 3, n + i] = -1; A[4 * i + 3, 2 * n + i] = -1; b[4 * i + 3] = 1
    return iu, ju, m, A, b


def _run(v0, n, S, maxiter=300):
    iu, ju, m, A, b = S
    rows = np.arange(m)

    def f(v):
        return -np.sum(v[2 * n:])

    def g(v):
        gr = np.zeros(3 * n)
        gr[2 * n:] = -1
        return gr

    def cp(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]; s = r[iu] + r[ju]
        return dx * dx + dy * dy - s * s

    def cpj(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]; s = r[iu] + r[ju]
        J = np.zeros((m, 3 * n))
        J[rows, iu] = 2 * dx; J[rows, ju] = -2 * dx
        J[rows, n + iu] = 2 * dy; J[rows, n + ju] = -2 * dy
        J[rows, 2 * n + iu] = -2 * s; J[rows, 2 * n + ju] = -2 * s
        return J

    cons = [{'type': 'ineq', 'fun': cp, 'jac': cpj},
            {'type': 'ineq', 'fun': lambda v: A @ v + b, 'jac': lambda v: A}]
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(f, v0, jac=g, constraints=cons, bounds=bounds,
                       method='SLSQP', options={'maxiter': maxiter, 'ftol': 1e-11})
    except Exception:
        return None, -1
    v = res.x
    # evaluate feasibility
    viol = max(0, -cp(v).min() if m else 0, -(A @ v + b).min())
    score = np.sum(v[2 * n:]) - 10 * viol
    return v, score


def _lp_radii(centers):
    n = len(centers)
    iu, ju = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[iu] - centers[ju], axis=1)
    m = len(iu)
    Aub = np.zeros((m, n))
    Aub[np.arange(m), iu] = 1
    Aub[np.arange(m), ju] = 1
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    res = linprog(-np.ones(n), A_ub=Aub, b_ub=d, bounds=[(0, w) for w in wall], method='highs')
    if res.status == 0:
        r = res.x
    else:
        r = np.zeros(n)
    return r


def _finalize(centers, r):
    centers = np.clip(centers, 0, 1)
    r = np.minimum(r, np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]]))
    r = np.maximum(r * (1 - 1e-12) - 1e-13, 0)
    n = len(r)
    for _ in range(100):
        ok = True
        for i in range(n):
            for j in range(i + 1, n):
                d = np.hypot(*(centers[i] - centers[j]))
                if r[i] + r[j] > d:
                    ex = r[i] + r[j] - d
                    r[i] = max(0, r[i] - ex / 2 - 1e-14)
                    r[j] = max(0, r[j] - ex / 2 - 1e-14)
                    ok = False
        if ok:
            break
    return centers, r


def _init(n, rng):
    t = rng.integers(3)
    if t == 0:
        c = rng.random((n, 2)) * 0.9 + 0.05
    elif t == 1:
        # jittered grid-ish
        k = int(np.ceil(np.sqrt(n)))
        pts = [((i + 0.5) / k, (j + 0.5) / k) for i in range(k) for j in range(k)]
        idx = rng.permutation(len(pts))[:n]
        c = np.array(pts)[idx] + rng.normal(0, 0.03, (n, 2))
    else:
        # rings
        c = [[0.5, 0.5]]
        c += [[0.5 + 0.28 * np.cos(2 * np.pi * i / 8 + 0.3), 0.5 + 0.28 * np.sin(2 * np.pi * i / 8 + 0.3)] for i in range(8)]
        c += [[0.5 + 0.42 * np.cos(2 * np.pi * i / 17), 0.5 + 0.42 * np.sin(2 * np.pi * i / 17)] for i in range(n - 9)]
        c = np.array(c[:n]) + rng.normal(0, 0.03, (n, 2))
    c = np.clip(c, 0.03, 0.97)
    return np.concatenate([c[:, 0], c[:, 1], np.full(n, 0.03 + 0.03 * rng.random())])


def solve(n=26):
    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(12345)
    S = _setup(n)
    best_v, best_s = None, -1
    it = 0
    while time.time() - t0 < budget:
        it += 1
        if best_v is None or it < 15 or rng.random() < 0.3:
            v0 = _init(n, rng)
        else:
            v0 = best_v.copy()
            mode = rng.integers(3)
            if mode == 0:
                v0[:2 * n] += rng.normal(0, 0.02, 2 * n)
            elif mode == 1:
                k = rng.integers(1, 4)
                for i in rng.choice(n, k, replace=False):
                    v0[i] = rng.random(); v0[n + i] = rng.random()
                    v0[2 * n + i] = 0.02
            else:
                i, j = rng.choice(n, 2, replace=False)
                for o in (0, n, 2 * n):
                    v0[o + i], v0[o + j] = v0[o + j], v0[o + i]
                v0[:2 * n] += rng.normal(0, 0.005, 2 * n)
            v0[:2 * n] = np.clip(v0[:2 * n], 0.01, 0.99)
            v0[2 * n:] = np.clip(v0[2 * n:] * 0.8, 0.005, 0.4)
        v, s = _run(v0, n, S)
        if v is not None and s > best_s:
            best_s, best_v = s, v
    centers = np.stack([best_v[:n], best_v[n:2 * n]], axis=1)
    centers = np.clip(centers, 0, 1)
    r = _lp_radii(centers)
    if r.sum() < 1e-6:
        r = np.maximum(best_v[2 * n:], 0)
    centers, r = _finalize(centers, r)
    return centers, r
