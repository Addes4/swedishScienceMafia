import time
import numpy as np
from scipy.optimize import minimize, linprog


def _lp_radii(c):
    n = len(c)
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    wall = np.maximum(wall, 0)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(c[I] - c[J], axis=1)
    A = np.zeros((len(I), n))
    A[np.arange(len(I)), I] = 1
    A[np.arange(len(I)), J] = 1
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status == 0:
        return np.maximum(res.x, 0)
    return np.zeros(n)


def solve(n=26):
    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    m = len(I)
    ar = np.arange(m)

    # linear wall constraints
    Aw = np.zeros((4 * n, 3 * n))
    bw = np.zeros(4 * n)
    for i in range(n):
        Aw[4 * i, i] = 1; Aw[4 * i, 2 * n + i] = -1
        Aw[4 * i + 1, i] = -1; Aw[4 * i + 1, 2 * n + i] = -1; bw[4 * i + 1] = 1
        Aw[4 * i + 2, n + i] = 1; Aw[4 * i + 2, 2 * n + i] = -1
        Aw[4 * i + 3, n + i] = -1; Aw[4 * i + 3, 2 * n + i] = -1; bw[4 * i + 3] = 1

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        d = np.sqrt((x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 + 1e-18)
        return np.concatenate([d - r[I] - r[J], Aw @ v + bw])

    def jac(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[I] - x[J]; dy = y[I] - y[J]
        d = np.sqrt(dx ** 2 + dy ** 2 + 1e-18)
        P = np.zeros((m, 3 * n))
        P[ar, I] = dx / d
        P[ar, J] = -dx / d
        P[ar, n + I] = dy / d
        P[ar, n + J] = -dy / d
        P[ar, 2 * n + I] = -1
        P[ar, 2 * n + J] = -1
        return np.vstack([P, Aw])

    g = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def opt(c, r0=None):
        if r0 is None:
            r0 = np.full(n, 0.04)
        v0 = np.concatenate([c[:, 0], c[:, 1], r0])
        try:
            res = minimize(lambda v: -v[2 * n:].sum(), v0, jac=lambda v: g,
                           constraints=[{"type": "ineq", "fun": cons, "jac": jac}],
                           bounds=bounds, method="SLSQP",
                           options={"maxiter": 150, "ftol": 1e-10})
        except Exception:
            return None, -1
        v = res.x
        c = np.clip(np.stack([v[:n], v[n:2 * n]], 1), 0, 1)
        r = _lp_radii(c)
        return c, r.sum()

    best_c, best_s = None, -1
    it = 0
    while time.time() - t0 < budget:
        it += 1
        if best_c is None or it % 3 == 0:
            if it % 2 == 0:
                c = rng.random((n, 2))
            else:
                # jittered grid
                k = int(np.ceil(np.sqrt(n)))
                pts = [((i + 0.5) / k, (j + 0.5) / k) for i in range(k) for j in range(k)]
                idx = rng.permutation(len(pts))[:n]
                c = np.array(pts)[idx] + rng.normal(0, 0.03, (n, 2))
                c = np.clip(c, 0.02, 0.98)
        else:
            c = best_c.copy()
            k = rng.integers(1, 4)
            idx = rng.choice(n, k, replace=False)
            if rng.random() < 0.5:
                c[idx] = rng.random((k, 2))
            else:
                c += rng.normal(0, 0.03, c.shape)
            c = np.clip(c, 0.01, 0.99)
        c2, s = opt(c)
        if c2 is not None and s > best_s:
            best_s, best_c = s, c2
    r = _lp_radii(best_c)
    r = np.maximum(r - 1e-12, 0)
    return best_c, r
