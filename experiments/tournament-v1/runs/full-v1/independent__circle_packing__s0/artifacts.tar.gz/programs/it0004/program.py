import numpy as np
import time
from scipy.optimize import minimize


def _feasible_radii(centers):
    n = len(centers)
    r = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    r = np.maximum(r, 0.0)
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.hypot(*(centers[i] - centers[j]))
                s = r[i] + r[j]
                if s > d:
                    f = d / s if s > 0 else 0
                    r[i] *= f
                    r[j] *= f
                    changed = True
        if not changed:
            break
    return np.maximum(r * (1 - 1e-12) - 1e-13, 0.0)


def solve(n=26):
    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    m = len(I)
    rows = np.arange(m)
    ar = np.arange(n)

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        pair = (x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 - (r[I] + r[J]) ** 2
        return np.concatenate([pair, x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        Jm = np.zeros((m + 4 * n, 3 * n))
        dx = x[I] - x[J]; dy = y[I] - y[J]; s = r[I] + r[J]
        Jm[rows, I] = 2 * dx
        Jm[rows, J] = -2 * dx
        Jm[rows, n + I] = 2 * dy
        Jm[rows, n + J] = -2 * dy
        Jm[rows, 2 * n + I] = -2 * s
        Jm[rows, 2 * n + J] = -2 * s
        b = m
        Jm[b + ar, ar] = 1; Jm[b + ar, 2 * n + ar] = -1
        b += n
        Jm[b + ar, ar] = -1; Jm[b + ar, 2 * n + ar] = -1
        b += n
        Jm[b + ar, n + ar] = 1; Jm[b + ar, 2 * n + ar] = -1
        b += n
        Jm[b + ar, n + ar] = -1; Jm[b + ar, 2 * n + ar] = -1
        return Jm

    obj = lambda v: -np.sum(v[2 * n:])
    g = np.concatenate([np.zeros(2 * n), -np.ones(n)])
    gj = lambda v: g
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def run(c0, maxiter=300):
        v0 = np.concatenate([c0[:, 0], c0[:, 1], np.full(n, 0.03)])
        try:
            res = minimize(obj, v0, jac=gj, bounds=bounds,
                           constraints=[{'type': 'ineq', 'fun': cons, 'jac': jac}],
                           method='SLSQP', options={'maxiter': maxiter, 'ftol': 1e-10})
        except Exception:
            return None, -1
        v = res.x
        c = np.stack([v[:n], v[n:2 * n]], axis=1)
        c = np.clip(c, 0, 1)
        rr = _feasible_radii(c)
        return c, rr.sum()

    def hex_init():
        rows_ = rng.integers(4, 7)
        pts = []
        per = int(np.ceil(n / rows_))
        for a in range(rows_):
            k = per if a % 2 == 0 else per - rng.integers(0, 2)
            for b in range(k):
                pts.append([(b + 0.5 + (0.5 if a % 2 else 0) * rng.random()) / k,
                            (a + 0.5) / rows_])
        pts = np.array(pts)
        idx = rng.permutation(len(pts))[:n] if len(pts) >= n else None
        if idx is None:
            pts = np.vstack([pts, rng.random((n - len(pts), 2))])
            idx = np.arange(n)
        pts = pts[idx] + rng.normal(0, 0.02, (n, 2))
        return np.clip(pts, 0.03, 0.97)

    best_c, best_s = None, -1
    # phase 1: random starts
    while time.time() - t0 < budget * 0.4:
        if rng.random() < 0.5:
            c0 = rng.random((n, 2)) * 0.9 + 0.05
        else:
            c0 = hex_init()
        c, s = run(c0)
        if c is not None and s > best_s:
            best_c, best_s = c, s
    # phase 2: basin hopping
    cur_c, cur_s = best_c, best_s
    while time.time() - t0 < budget:
        c0 = cur_c.copy()
        mode = rng.random()
        if mode < 0.4:
            c0 += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), c0.shape)
        elif mode < 0.8:
            k = rng.integers(1, 4)
            idx = rng.choice(n, k, replace=False)
            c0[idx] = rng.random((k, 2)) * 0.9 + 0.05
        else:
            i, j = rng.choice(n, 2, replace=False)
            c0[[i, j]] = c0[[j, i]]
            c0 += rng.normal(0, 0.01, c0.shape)
        c0 = np.clip(c0, 0.02, 0.98)
        c, s = run(c0)
        if c is None:
            continue
        if s > cur_s - 0.003 * rng.random():
            cur_c, cur_s = c, s
        if s > best_s:
            best_c, best_s = c, s
            cur_c, cur_s = c, s
    radii = _feasible_radii(best_c)
    return best_c, radii
