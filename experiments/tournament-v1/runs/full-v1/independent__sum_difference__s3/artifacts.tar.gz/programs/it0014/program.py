import math
import time
import numpy as np


def _count(d, n, m):
    # number of x in [0,m]^d with sum<=n
    poly = [1] + [0] * n
    for _ in range(d):
        new = [0] * (n + 1)
        for s, c in enumerate(poly):
            if c:
                for v in range(0, min(m, n - s) + 1):
                    new[s + v] += c
        poly = new
    return sum(poly)


def _points(d, n, m):
    P = np.zeros((1, 0), dtype=np.int64)
    S = np.zeros(1, dtype=np.int64)
    for _ in range(d):
        parts = []
        sp = []
        for v in range(0, m + 1):
            mask = S + v <= n
            if not mask.any():
                break
            q = P[mask]
            parts.append(np.hstack([q, np.full((q.shape[0], 1), v, dtype=np.int64)]))
            sp.append(S[mask] + v)
        P = np.vstack(parts)
        S = np.concatenate(sp)
    return P


def _score_arr(v):
    N = len(v)
    iu, ju = np.triu_indices(N)
    sums = np.unique(v[iu] + v[ju])
    del iu, ju
    il, jl = np.triu_indices(N, 1)
    dd = np.unique(np.abs(v[il] - v[jl]))
    nd = 2 * len(dd) + 1
    ns = len(sums)
    return math.log(nd) / math.log(ns) + (1 - 1 / N) / 100


def solve():
    t0 = time.time()
    budget = 85
    cands = []
    for d in range(2, 16):
        for n in range(2, 30):
            B = 2 * n + 1
            if float(B) ** d >= 1e15:
                continue
            for m in range(1, n + 1):
                if m < n and m > 8:
                    continue
                c = _count(d, n, m)
                if 150 <= c <= 4000:
                    cands.append((c, d, n, m))
    cands.sort(reverse=True)
    # prefer diverse: evaluate largest first but limited
    best = [0, 1, 3, 4, 10]
    best_sc = -1
    for c, d, n, m in cands:
        if time.time() - t0 > budget:
            break
        if c > 2500 and time.time() - t0 > budget - 12:
            continue
        P = _points(d, n, m)
        B = 2 * n + 1
        w = np.array([B ** i for i in range(d)], dtype=np.int64)
        v = P @ w
        if len(np.unique(v)) != len(v):
            continue
        sc = _score_arr(v)
        if sc > best_sc:
            best_sc = sc
            best = [int(x) for x in v]
    return sorted(set(best))
