import math
from math import comb, factorial


def _counts(d, n):
    s = comb(2 * n + d, d)
    t = 0
    fd = factorial(d)
    for p in range(0, min(n, d) + 1):
        for q in range(0, min(n, d - p) + 1):
            t += (fd // (factorial(p) * factorial(q) * factorial(d - p - q))) * comb(n, p) * comb(n, q)
    return t, s


def _gen(d, n, B):
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return pts


def solve():
    best = None
    best_score = -1
    for n in range(1, 40):
        B = 2 * n + 1
        for d in range(1, 80):
            size = comb(n + d, d)
            if size > 4000:
                break
            if n * B ** (d - 1) > 10 ** 15 or B ** d > 10 ** 15 * 2:
                break
            if B ** d > 10 ** 15:
                # elements bounded by n*B^(d-1) anyway; keep safe
                pass
            t, s = _counts(d, n)
            if s < 2 or size < 2:
                continue
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_score:
                best_score = sc
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    pts = _gen(d, n, B)
    return sorted(set(pts))
