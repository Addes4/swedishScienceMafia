import math
from math import comb
import itertools


def _formula(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            diffs += comb(d, i) * comb(d - i, j) * comb(n, i) * comb(n, j)
    return size, sums, diffs


def _points(d, n):
    res = []

    def rec(pos, remaining, cur):
        if pos == d:
            res.append(cur)
            return
        for v in range(remaining + 1):
            rec(pos + 1, remaining - v, cur)  # placeholder replaced below
            break

    # iterative generation with base encoding
    b = 2 * n + 1
    pts = [(0, 0)]  # (value, used)
    for _ in range(d):
        new = []
        for val, used in pts:
            for v in range(n - used + 1):
                new.append((val * b + v, used + v))
        pts = new
    return [p[0] for p in pts]


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            b = 2 * n + 1
            if b ** d * 2 > 10 ** 15:
                continue
            sz, s, df = _formula(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / sz) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    pts = _points(d, n)
    return sorted(set(pts))
