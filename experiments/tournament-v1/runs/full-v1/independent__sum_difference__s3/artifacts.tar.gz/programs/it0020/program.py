import math


def _gen(d, n):
    pts = []
    base = 2 * n + 1
    pw = [base ** i for i in range(d)]

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * pw[i])

    rec(0, n, 0)
    return pts


def _eval(d, n):
    size = math.comb(n + d, d)
    s = math.comb(2 * n + d, d)
    diff = 0
    for k in range(0, min(d, n) + 1):
        for j in range(0, min(d - k, n) + 1):
            diff += (math.factorial(d) // (math.factorial(k) * math.factorial(j)
                                           * math.factorial(d - k - j))) * math.comb(n, k) * math.comb(n, j)
    return size, math.log(diff) / math.log(s) + (1 - 1 / size) / 100


def solve():
    best = None
    best_sc = -1
    for d in range(1, 60):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 5 * 10 ** 14:
                break
            if size < 2:
                continue
            sz, sc = _eval(d, n)
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
