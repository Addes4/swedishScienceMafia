import math
from math import comb


def _gen(d, n):
    res = []

    def rec(i, rem, cur):
        if i == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def _formula(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for j in range(0, min(d, n) + 1):
        cj = comb(d, j) * comb(n, j)
        for k in range(0, min(d - j, n) + 1):
            diffs += cj * comb(d - j, k) * comb(n, k)
    return size, sums, diffs


def solve():
    best = None
    best_sc = -1
    for d in range(1, 40):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            base = 2 * n + 1
            if n * (base ** d) // (base - 1) * 1 > 10 ** 15:
                continue
            _, s, df = _formula(d, n)
            sc = math.log(df) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    base = 2 * n + 1
    pts = _gen(d, n)
    out = []
    for p in pts:
        v = 0
        for c in p:
            v = v * base + c
        out.append(v)
    return sorted(set(out))
