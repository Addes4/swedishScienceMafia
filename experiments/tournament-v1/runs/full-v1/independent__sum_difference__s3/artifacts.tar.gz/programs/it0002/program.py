import math


def _eval(d, n):
    s = math.comb(2 * n + d, d)
    df = 0
    for k in range(0, min(d, n) + 1):
        for j in range(0, min(d - k, n) + 1):
            df += (math.factorial(d) // (math.factorial(k) * math.factorial(j) * math.factorial(d - k - j))
                   * math.comb(n, k) * math.comb(n, j))
    size = math.comb(n + d, d)
    return math.log(df) / math.log(s) + (1 - 1 / size) / 100


def _gen(d, n, B):
    res = []

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        p = B ** i
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * p)

    rec(0, n, 0)
    return res


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 60):
            if math.comb(n + d, d) > 4000:
                break
            B = 2 * n + 1
            if B ** d > 10 ** 15:
                break
            if math.comb(n + d, d) < 2:
                continue
            sc = _eval(d, n)
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    return sorted(_gen(d, n, 2 * n + 1))
