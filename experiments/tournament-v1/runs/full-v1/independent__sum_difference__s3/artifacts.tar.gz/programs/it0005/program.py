import math
from math import comb, factorial


def _counts(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            multi = factorial(d) // (factorial(i) * factorial(j) * factorial(d - i - j))
            diffs += multi * comb(n, i) * comb(n, j)
    return size, sums, diffs


def _gen(d, n):
    pts = []

    def rec(pos, rem, cur):
        if pos == d:
            pts.append(cur[:])
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(pos + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def solve():
    best = None
    best_s = -1
    for d in range(1, 60):
        for n in range(1, 40):
            size, sums, diffs = _counts(d, n)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * B ** (d - 1) > 10 ** 15:
                continue
            if size < 2:
                continue
            s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if s > best_s:
                best_s = s
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    pts = _gen(d, n)
    res = []
    for p in pts:
        v = 0
        for x in reversed(p):
            v = v * B + x
        res.append(v)
    return sorted(set(res))
