import math
import time
import itertools
import numpy as np


def _score(a):
    a = np.array(sorted(set(int(v) for v in a)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    dd = np.unique((a[:, None] - a[None, :]).ravel()).size
    return math.log(dd) / math.log(s) + (1 - 1 / n) / 100


def _simplex(d, n):
    base = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return pts


def solve():
    t0 = time.time()
    best = None
    best_s = -1
    cands = []
    for d in range(2, 30):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 15:
                continue
            if (2 * n + 1) ** d > 1e14:
                break
            cands.append((size, d, n))
    cands.sort()
    for size, d, n in cands:
        if time.time() - t0 > 85:
            break
        pts = _simplex(d, n)
        s = _score(pts)
        if s > best_s:
            best_s = s
            best = pts
    if best is None:
        best = [0, 1, 3, 7, 12, 20]
    return sorted(set(best))
