import math


def _counts(d, n):
    sums = math.comb(2 * n + d, d)
    diffs = 0
    f = math.factorial
    for k in range(0, min(d, n) + 1):
        for l in range(0, min(d - k, n) + 1):
            diffs += (f(d) // (f(k) * f(l) * f(d - k - l))) * math.comb(n, k) * math.comb(n, l)
    return diffs, sums


def _gen(d, n):
    pts = []
    base = 4 * n + 2

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * base + x)

    rec(0, n, 0)
    return pts


def solve():
    best = None
    best_sc = -1
    for d in range(1, 40):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            base = 4 * n + 2
            if base ** d > 5e14:
                break
            df, sm = _counts(d, n)
            sc = math.log(df) / math.log(sm) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    pts = _gen(d, n)
    return sorted(set(pts))
