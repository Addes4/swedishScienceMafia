import math
import time
import numpy as np


def _gen(d, n):
    B = 2 * n + 1
    vals = np.array([0], dtype=np.int64)
    sums = np.array([0], dtype=np.int64)
    for _ in range(d):
        nv = []
        ns = []
        for c in range(n + 1):
            m = sums + c <= n
            nv.append(vals[m] * B + c)
            ns.append(sums[m] + c)
        vals = np.concatenate(nv)
        sums = np.concatenate(ns)
    return vals


def _score_np(a):
    a = np.asarray(a, dtype=np.int64)
    m = len(a)
    if m < 2:
        return 0.0
    s = np.unique((a[:, None] + a[None, :]).ravel())
    df = np.unique((a[:, None] - a[None, :]).ravel())
    return math.log(len(df)) / math.log(len(s)) + (1 - 1 / m) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 30):
        for n in range(1, 40):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size >= 30:
                B = 2 * n + 1
                if B ** d * n < 4e14:
                    cands.append((size, d, n))
    cands.sort(reverse=True)
    best = None
    best_s = -1
    for size, d, n in cands:
        if time.time() - t0 > 85:
            break
        a = _gen(d, n)
        a = a - a.min()
        sc = _score_np(a)
        if sc > best_s:
            best_s = sc
            best = a
    if best is None:
        return [0, 1, 3, 4, 7]
    return [int(x) for x in best]
