import math
from itertools import combinations
from math import comb


def _counts(d, n):
    s = comb(2 * n + d, d)
    t = 0
    for k in range(0, min(d, n) + 1):
        for j in range(0, min(d - k, n) + 1):
            t += comb(d, k) * comb(d - k, j) * comb(n, k) * comb(n, j)
    return t, s


def _gen(d, n):
    # enumerate all nonneg integer vectors of length d with sum <= n, encoded in base 2n+1
    B = 2 * n + 1
    res = []

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        w = B ** i
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return res


def solve():
    best = None
    bs = -1
    for d in range(1, 40):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 10 ** 15:
                break
            if size < 2:
                continue
            t, s = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    return sorted(_gen(d, n))
