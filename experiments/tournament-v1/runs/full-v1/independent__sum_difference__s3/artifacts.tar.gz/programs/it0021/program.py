import math
import time
import itertools
import numpy as np


def _gen(d, n):
    pts = []

    def rec(prefix, remaining, k):
        if k == d:
            pts.append(tuple(prefix))
            return
        for v in range(remaining + 1):
            prefix.append(v)
            rec(prefix, remaining - v, k + 1)
            prefix.pop()

    rec([], n, 0)
    return pts


def _embed(pts, n):
    b = 2 * n + 1
    out = []
    for p in pts:
        v = 0
        for c in p:
            v = v * b + c
        out.append(v)
    return out


def _score_arr(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    m = len(a)
    if m < 2:
        return 0.0
    s = np.unique((a[:, None] + a[None, :]).ravel())
    ns = len(s)
    del s
    dd = np.unique((a[:, None] - a[None, :]).ravel())
    nd = len(dd)
    return math.log(nd) / math.log(ns) + (1 - 1 / m) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 9):
        n = 1
        while math.comb(n + 1 + d, d) <= 4000:
            n += 1
        # largest n and a couple smaller
        for nn in (n, n - 1):
            if nn >= 1 and math.comb(nn + d, d) >= 4:
                cands.append((d, nn))
    # prioritize mid dimensions
    order = {3: 0, 4: 0, 5: 0, 6: 1, 2: 2, 7: 1, 8: 2}
    cands.sort(key=lambda c: (order.get(c[0], 3), -c[1]))
    best = None
    best_s = -1
    for d, n in cands:
        if time.time() - t0 > 80:
            break
        pts = _gen(d, n)
        if len(pts) > 4000:
            continue
        a = _embed(pts, n)
        if max(abs(x) for x in a) > 10**15:
            continue
        s = _score_arr(a)
        if s > best_s:
            best_s = s
            best = a
    if best is None:
        best = [0, 1, 3]
    return sorted(set(int(x) for x in best))
