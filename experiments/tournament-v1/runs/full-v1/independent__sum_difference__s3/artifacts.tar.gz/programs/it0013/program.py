import math


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for p in range(d + 1):
        for q in range(d - p + 1):
            ways = math.factorial(d) // (math.factorial(p) * math.factorial(q) * math.factorial(d - p - q))
            diffs += ways * math.comb(n, p) * math.comb(n, q)
    return size, diffs, sums


def _gen(d, n):
    B = 2 * n + 1
    res = []

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val * B + x)

    rec(0, n, 0)
    return res


def solve():
    best = None
    bs = -1
    for d in range(1, 16):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d > 10 ** 15:
                break
            s, df, sm = _counts(d, n)
            if sm <= 1 or s < 2:
                continue
            sc = math.log(df) / math.log(sm) + (1 - 1 / s) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    return sorted(set(_gen(d, n)))
