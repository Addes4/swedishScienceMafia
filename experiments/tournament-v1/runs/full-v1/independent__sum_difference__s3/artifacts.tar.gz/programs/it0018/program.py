import math
import time
import numpy as np


def _gen(d, n):
    pts = []

    def rec(i, rem, cur):
        if i == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def _size(d, n):
    return math.comb(n + d, d)


def _eval_arr(a):
    a = np.asarray(a, dtype=np.int64)
    diffs = np.unique((a[:, None] - a[None, :]).ravel()).size
    iu = np.triu_indices(a.size)
    s = np.unique((a[:, None] + a[None, :])[iu]).size
    return math.log(diffs) / math.log(s) + (1 - 1 / a.size) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 16):
        for n in range(1, 40):
            sz = _size(d, n)
            if sz > 3600:
                break
            B = 2 * n + 1
            if B ** d > 4e14:
                break
            if sz >= 60:
                cands.append((sz, d, n))
    cands.sort(reverse=True)
    best = None
    best_s = -1
    for sz, d, n in cands:
        if time.time() - t0 > 85:
            break
        pts = _gen(d, n)
        B = 2 * n + 1
        w = np.array([B ** i for i in range(d)], dtype=np.int64)
        arr = np.array(pts, dtype=np.int64) @ w
        s = _eval_arr(arr)
        if s > best_s:
            best_s = s
            best = arr
    if best is None:
        return [0, 1, 3, 7, 12, 20]
    return [int(x) for x in sorted(set(best.tolist()))]
