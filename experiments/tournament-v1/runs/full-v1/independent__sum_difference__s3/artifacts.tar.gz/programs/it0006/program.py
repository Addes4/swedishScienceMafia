import math
import time
import numpy as np


def _gen(d, n):
    res = []

    def rec(pos, rem, cur):
        if pos == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(pos + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def _score_arr(a):
    a = np.asarray(a, dtype=np.int64)
    k = len(a)
    D = a[:, None] - a[None, :]
    pos = D[D > 0]
    nd = 2 * len(np.unique(pos)) + 1
    del D, pos
    S = (a[:, None] + a[None, :]).ravel()
    ns = len(np.unique(S))
    del S
    return math.log(nd) / math.log(ns) + (1 - 1 / k) / 100


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 60):
        for n in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d > 2e15:
                break
            if size >= 20:
                cands.append((size, d, n))
    cands.sort()
    best = None
    best_score = -1
    for size, d, n in cands:
        if time.time() - t0 > 95:
            break
        pts = _gen(d, n)
        B = 2 * n + 1
        mult = [B ** i for i in range(d)]
        vals = [sum(p[i] * mult[i] for i in range(d)) for p in pts]
        try:
            sc = _score_arr(vals)
        except MemoryError:
            continue
        if sc > best_score:
            best_score = sc
            best = vals
    if best is None:
        return [0, 1, 3, 7, 12, 20]
    return sorted(set(int(v) for v in best))
