import math
from math import comb, factorial


def _counts(d, n):
    s = comb(2 * n + d, d)
    t = 0
    for j in range(0, d + 1):
        cj = comb(n, j)
        if cj == 0:
            continue
        for m in range(0, d - j + 1):
            cm = comb(n, m)
            if cm == 0:
                continue
            mult = factorial(d) // (factorial(j) * factorial(m) * factorial(d - j - m))
            t += mult * cj * cm
    return t, s


def _gen(d, n, B):
    pts = []

    def rec(i, rem, val, mul):
        if i == d:
            pts.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * mul, mul * B)

    rec(0, n, 0, 1)
    return pts


def solve():
    best = None
    bs = -1
    for d in range(1, 60):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d > 10 ** 15:
                break
            if size < 2:
                continue
            t, s = _counts(d, n)
            sc = math.log(t) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    B = 2 * n + 1
    return sorted(set(_gen(d, n, B)))
