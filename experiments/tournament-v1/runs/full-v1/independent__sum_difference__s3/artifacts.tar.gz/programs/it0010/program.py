import math
from math import comb


def _counts(n, d):
    s = comb(2 * n + d, d)
    diff = 0
    for i in range(0, min(d, n) + 1):
        ci = comb(d, i) * comb(n, i)
        for j in range(0, min(d - i, n) + 1):
            diff += ci * comb(d - i, j) * comb(n, j)
    return diff, s


def _gen(n, d):
    B = 2 * n + 1
    res = []

    def rec(pos, rem, val):
        if pos == d:
            res.append(val)
            return
        w = B ** pos
        for x in range(rem + 1):
            rec(pos + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return res


def solve():
    best = None
    best_score = -1
    for n in range(1, 80):
        for d in range(1, 4000):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * B ** (d - 1) > 10 ** 15 or size < 2:
                continue
            diff, s = _counts(n, d)
            sc = math.log(diff) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_score:
                best_score = sc
                best = (n, d)
    if best is None:
        return [0, 1, 3]
    n, d = best
    return sorted(set(_gen(n, d)))
