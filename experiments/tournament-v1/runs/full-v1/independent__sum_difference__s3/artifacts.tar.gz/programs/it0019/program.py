import math
import time
import numpy as np


def _gen(d, n):
    pts = []
    def rec(i, rem, cur):
        if i == d:
            pts.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(i + 1, rem - v, cur)
            cur.pop()
    rec(0, n, [])
    return pts


def _embed(d, n):
    base = 2 * n + 1
    pts = _gen(d, n)
    vals = []
    for p in pts:
        v = 0
        for c in p:
            v = v * base + c
        vals.append(v)
    return vals


def _score_np(vals):
    a = np.array(vals, dtype=np.int64)
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    return math.log(d) / math.log(s) + (1 - 1 / len(vals)) / 100


def solve():
    start = time.time()
    best = None
    best_score = -1
    cands = []
    for d in range(2, 16):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            if size < 30:
                continue
            if (2 * n + 1) ** d > 5e14:
                continue
            cands.append((d, n, size))
    for d, n, size in cands:
        if time.time() - start > 100:
            break
        vals = _embed(d, n)
        sc = _score_np(vals)
        if sc > best_score:
            best_score = sc
            best = vals
    if best is None:
        best = [0, 1, 3, 7, 12]
    m = min(best)
    return sorted(set(int(x) - m for x in best))
