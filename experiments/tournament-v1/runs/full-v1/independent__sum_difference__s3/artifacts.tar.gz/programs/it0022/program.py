import math
from math import comb


def _counts(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for j in range(0, d + 1):
        for k in range(0, d - j + 1):
            # j positive coords, k negative coords; compositions of <=n into j positive parts = C(n,j)
            diffs += comb(d, j) * comb(d - j, k) * comb(n, j) * comb(n, k)
    return size, sums, diffs


def _gen(d, n):
    res = []
    base = 2 * n + 1
    pw = [base ** i for i in range(d)]

    def rec(i, rem, val):
        if i == d:
            res.append(val)
            return
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * pw[i])

    rec(0, n, 0)
    return res


def solve():
    best = None
    best_s = -1
    for d in range(1, 40):
        for n in range(1, 200):
            size = comb(n + d, d)
            if size > 4000:
                break
            if size < 2:
                continue
            if (2 * n + 1) ** d * n > 10 ** 15 // 2:
                break
            size, sums, diffs = _counts(d, n)
            s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if s > best_s:
                best_s = s
                best = (d, n)
    d, n = best
    A = _gen(d, n)
    return sorted(set(A))
