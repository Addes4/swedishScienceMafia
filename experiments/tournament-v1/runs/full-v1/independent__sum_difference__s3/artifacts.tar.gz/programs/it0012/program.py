import math
from math import comb


def _counts(d, n):
    size = comb(n + d, d)
    sums = comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            diffs += (math.factorial(d) // (math.factorial(i) * math.factorial(j) * math.factorial(d - i - j))) * comb(n, i) * comb(n, j)
    return size, sums, diffs


def _gen(d, n):
    pts = []

    def rec(pos, remaining, cur):
        if pos == d:
            pts.append(tuple(cur))
            return
        for v in range(remaining + 1):
            cur.append(v)
            rec(pos + 1, remaining - v, cur)
            cur.pop()

    rec(0, n, [])
    return pts


def solve():
    best = None
    best_s = -1
    for d in range(1, 40):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            if (2 * n + 1) ** d > 5e14:
                break
            if size < 2:
                continue
            sz, su, di = _counts(d, n)
            s = math.log(di) / math.log(su) + (1 - 1 / sz) / 100
            if s > best_s:
                best_s = s
                best = (d, n)
    d, n = best
    base = 2 * n + 1
    res = []
    for p in _gen(d, n):
        v = 0
        for c in p:
            v = v * base + c
        res.append(v)
    return sorted(set(res))
