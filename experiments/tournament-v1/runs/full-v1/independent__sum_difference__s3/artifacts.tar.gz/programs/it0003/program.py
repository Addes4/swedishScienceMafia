import math
import numpy as np


def _points(d, n):
    res = []

    def rec(prefix, remaining, k):
        if k == 0:
            res.append(tuple(prefix))
            return
        for v in range(remaining + 1):
            prefix.append(v)
            rec(prefix, remaining - v, k - 1)
            prefix.pop()

    rec([], n, d)
    return res


def _encode(pts, n):
    B = 2 * n + 1
    out = []
    for p in pts:
        v = 0
        for c in p:
            v = v * B + c
        out.append(v)
    return out


def _score_arr(a):
    arr = np.array(sorted(set(a)), dtype=np.int64)
    m = len(arr)
    d = (arr[:, None] - arr[None, :]).ravel()
    nd = len(np.unique(d))
    del d
    s = (arr[:, None] + arr[None, :]).ravel()
    ns = len(np.unique(s))
    del s
    return math.log(nd) / math.log(ns) + (1 - 1 / m) / 100


def solve():
    best = None
    best_s = -1
    cands = []
    for d in range(2, 13):
        n = 1
        while math.comb(n + 1 + d, d) <= 4000:
            n += 1
        cands.append((d, n))
        if n > 1:
            cands.append((d, n - 1))
    for d, n in cands:
        if math.comb(n + d, d) > 4000:
            continue
        B = 2 * n + 1
        if n * B ** (d - 1) * 2 > 1e15:
            continue
        pts = _points(d, n)
        enc = _encode(pts, n)
        if len(set(enc)) != len(enc):
            continue
        try:
            s = _score_arr(enc)
        except MemoryError:
            continue
        if s > best_s:
            best_s = s
            best = enc
    if best is None:
        best = [0, 1, 3]
    return sorted(set(int(x) for x in best))
