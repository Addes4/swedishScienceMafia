import math
from itertools import combinations


def _counts(d, n):
    s = math.comb(2 * n + d, d)
    diff = 0
    for j in range(0, d + 1):
        for m in range(0, d - j + 1):
            diff += (math.factorial(d) // (math.factorial(j) * math.factorial(m) * math.factorial(d - j - m))
                     * math.comb(n, j) * math.comb(n, m))
    return diff, s


def _build(d, n):
    B = 2 * n + 1
    pts = []

    def rec(i, rem, val):
        if i == d:
            pts.append(val)
            return
        w = B ** i
        for x in range(rem + 1):
            rec(i + 1, rem - x, val + x * w)

    rec(0, n, 0)
    return pts


def solve():
    best = None
    bs = -1
    for n in range(1, 30):
        for d in range(1, 60):
            size = math.comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if B ** d > 5e14:
                break
            if size < 2:
                continue
            diff, s = _counts(d, n)
            sc = math.log(diff) / math.log(s) + (1 - 1 / size) / 100
            if sc > bs:
                bs = sc
                best = (d, n)
    d, n = best
    return sorted(set(_build(d, n)))
