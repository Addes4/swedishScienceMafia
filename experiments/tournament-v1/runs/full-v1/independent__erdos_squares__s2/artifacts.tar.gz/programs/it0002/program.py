import math


def solve(n):
    best = None
    mmax = math.isqrt(n) + 6
    for m in range(1, mmax + 1):
        r = m * m - n
        if r <= 0:
            val = float(m)
            cand = (val, m, 0, 0)
        else:
            tmax = (m // 2) ** 2
            cand = None
            for t in range(0, tmax + 1):
                d = max(0, r - 3 * t)
                if d > m * m - 4 * t:
                    continue
                val = m - (2 * t + d) / m
                if cand is None or val > cand[0]:
                    cand = (val, m, t, d)
            if cand is None:
                continue
        if best is None or cand[0] > best[0]:
            best = cand
    val, m, t, d = best
    s = 1.0 / m
    shrink = 1.0 - 1e-9
    squares = []
    used = set()
    cnt = 0
    half = m // 2
    for a in range(half):
        for b in range(half):
            if cnt >= t:
                break
            cnt += 1
            for di in range(2):
                for dj in range(2):
                    used.add((2 * a + di, 2 * b + dj))
            squares.append(((2 * a + 1) * s, (2 * b + 1) * s, 0.0, 2 * s * shrink))
    free = [(i, j) for i in range(m) for j in range(m) if (i, j) not in used]
    keep = free[:len(free) - d] if d > 0 else free
    for (i, j) in keep:
        squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s * shrink))
    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares
