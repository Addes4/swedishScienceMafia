import math


def solve(n):
    best = None
    kmax = math.isqrt(n) + 4
    for k in range(1, kmax + 1):
        maxt = (k // 2) ** 2
        for t in range(0, maxt + 1):
            c = k * k - 3 * t
            if c <= 0:
                break
            rem = max(0, c - n)
            # removed squares must be unmerged cells
            if rem > k * k - 4 * t:
                continue
            val = (k * k - 2 * t - rem) / k
            if best is None or val > best[0] + 1e-12:
                best = (val, k, t, rem)
    _, k, t, rem = best
    s = 1.0 / k
    shrink = 1 - 1e-9
    squares = []
    used = [[False] * k for _ in range(k)]
    cnt = 0
    h = k // 2
    for bi in range(h):
        for bj in range(h):
            if cnt >= t:
                break
            i, j = 2 * bi, 2 * bj
            used[i][j] = used[i + 1][j] = used[i][j + 1] = used[i + 1][j + 1] = True
            squares.append(((i + 1) * s, (j + 1) * s, 0.0, 2 * s * shrink))
            cnt += 1
    z = rem
    cells = []
    for i in range(k):
        for j in range(k):
            if not used[i][j]:
                cells.append((i, j))
    # zero out the last `rem` cells
    keep = cells[:len(cells) - z] if z > 0 else cells
    for (i, j) in keep:
        squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s * shrink))
    if len(squares) > n:
        squares.sort(key=lambda q: -q[3])
        squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares
