import math
import time
import random
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix


def _lp(X0, Y0, S0, thr, rng):
    m = len(S0)
    I, J = np.triu_indices(m, 1)
    while True:
        gx = np.maximum(X0[J] - (X0[I] + S0[I]), X0[I] - (X0[J] + S0[J]))
        gy = np.maximum(Y0[J] - (Y0[I] + S0[I]), Y0[I] - (Y0[J] + S0[J]))
        noise = rng.random(len(I)) * 1e-7
        usex = (gx + noise) >= gy
        best = np.where(usex, gx, gy)
        sel = best < thr
        Is, Js, ux = I[sel], J[sel], usex[sel]
        # orientation: i left of j or j left of i
        lo = np.where(ux, X0[Is] <= X0[Js], Y0[Is] <= Y0[Js])
        a = np.where(lo, Is, Js)  # lower one
        b = np.where(lo, Js, Is)  # upper one
        k = len(a)
        rows = []
        cols = []
        vals = []
        r = np.arange(k)
        off_a = np.where(ux, 0, m)
        # a_pos + s_a - b_pos <= 0
        rows += [r, r, r]
        cols += [off_a + a, 2 * m + a, off_a + b]
        vals += [np.ones(k), np.ones(k), -np.ones(k)]
        # boundary
        r2 = k + np.arange(m)
        r3 = k + m + np.arange(m)
        ar = np.arange(m)
        rows += [r2, r2, r3, r3]
        cols += [ar, 2 * m + ar, m + ar, 2 * m + ar]
        vals += [np.ones(m)] * 4
        A = coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))),
                       shape=(k + 2 * m, 3 * m)).tocsr()
        bub = np.concatenate([np.zeros(k), np.ones(2 * m)])
        c = np.concatenate([np.zeros(2 * m), -np.ones(m)])
        res = linprog(c, A_ub=A, b_ub=bub, bounds=(0, 1), method="highs")
        if res.status != 0 or res.x is None:
            return None
        x = res.x[:m]
        y = res.x[m:2 * m]
        s = res.x[2 * m:]
        ox = np.minimum(x[I] + s[I], x[J] + s[J]) - np.maximum(x[I], x[J])
        oy = np.minimum(y[I] + s[I], y[J] + s[J]) - np.maximum(y[I], y[J])
        if np.any((ox > 1e-9) & (oy > 1e-9)):
            thr *= 2
            if thr > 4:
                return None
            continue
        return x, y, s


def _grid_cfg(cells, g):
    h = 1.0 / g
    cells = list(cells)
    X0 = np.array([(c % g) * h for c in cells])
    Y0 = np.array([(c // g) * h for c in cells])
    S0 = np.full(len(cells), h)
    return X0, Y0, S0


def solve(n):
    t0 = time.time()
    budget = 35.0
    rng = np.random.default_rng(1)
    random.seed(1)
    k = math.isqrt(n)
    if k * k == n:
        side = 1.0 / k
        return [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    # baseline
    side = 1.0 / k
    base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    base += [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
    base_val = k

    g = k + 1
    thr = 2.0 / g

    def evaluate(kept):
        X0, Y0, S0 = _grid_cfg(kept, g)
        r = _lp(X0, Y0, S0, thr, rng)
        if r is None:
            return -1, None
        return float(r[2].sum()), r

    allc = list(range(g * g))
    cur_kept = allc[:n]
    cur_val, cur_sol = evaluate(cur_kept)
    best_val, best_sol = cur_val, cur_sol
    # a few random starts
    starts = 0
    while time.time() - t0 < budget * 0.25 and starts < 6:
        kp = random.sample(allc, n)
        v, s = evaluate(kp)
        starts += 1
        if v > cur_val:
            cur_val, cur_kept, cur_sol = v, kp, s
    best_val, best_sol, best_kept = cur_val, cur_sol, list(cur_kept)
    while time.time() - t0 < budget:
        kept = list(cur_kept)
        nm = 1 if random.random() < 0.7 else 2
        ks = set(kept)
        for _ in range(nm):
            a = random.choice(list(ks))
            rest = [c for c in allc if c not in ks]
            b = random.choice(rest)
            ks.remove(a)
            ks.add(b)
        kept = sorted(ks)
        v, s = evaluate(kept)
        if v >= cur_val - 1e-12:
            cur_val, cur_kept, cur_sol = v, kept, s
            if v > best_val:
                best_val, best_sol, best_kept = v, s, list(kept)
    # polish
    sol = best_sol
    val = best_val
    if sol is not None:
        for _ in range(4):
            if time.time() - t0 > 55:
                break
            x, y, s = sol
            r = _lp(x, y, s, thr, rng)
            if r is None:
                break
            if r[2].sum() >= val - 1e-12:
                sol = r
                val = float(r[2].sum())
    if sol is None or val <= base_val + 1e-12:
        return base
    x, y, s = sol
    out = []
    for i in range(len(s)):
        si = max(0.0, float(s[i]) - 2e-9)
        cx = min(1.0, max(0.0, float(x[i]) + float(s[i]) / 2))
        cy = min(1.0, max(0.0, float(y[i]) + float(s[i]) / 2))
        out.append((cx, cy, 0.0, si))
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]
