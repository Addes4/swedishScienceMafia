import math


def _place(k, a3, a2):
    occ = [[False] * k for _ in range(k)]
    blocks = []
    for m, cnt in ((3, a3), (2, a2)):
        placed = 0
        if cnt == 0:
            continue
        for i in range(k - m + 1):
            if placed >= cnt:
                break
            for j in range(k - m + 1):
                if placed >= cnt:
                    break
                ok = True
                for di in range(m):
                    row = occ[i + di]
                    for dj in range(m):
                        if row[j + dj]:
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    for di in range(m):
                        for dj in range(m):
                            occ[i + di][j + dj] = True
                    blocks.append((i, j, m))
                    placed += 1
        if placed < cnt:
            return None
    return blocks, occ


def _plan(n, k):
    budget = k * k - n
    if budget < 0:
        return None
    best = None
    max3 = min(budget // 8, (k // 3) ** 2, 12)
    for a3 in range(0, max3 + 1):
        a2 = min((budget - 8 * a3) // 3, (k // 2) ** 2)
        while a2 >= 0:
            r = _place(k, a3, a2)
            if r is not None:
                val = (n + a2 + 2 * a3) / k
                if best is None or val > best[0] + 1e-12:
                    best = (val, r)
                break
            a2 -= 1
    return best


def solve(n):
    if n <= 0:
        return []
    k0 = math.isqrt(n)
    if k0 * k0 < n:
        k0 += 1
    best = None
    bestk = None
    for k in range(k0, k0 + 7):
        p = _plan(n, k)
        if p is None:
            continue
        if best is None or p[0] > best[0] + 1e-12:
            best = p
            bestk = k
    # fallback: floor grid
    kf = math.isqrt(n)
    fval = kf
    if best is None or fval > best[0] + 1e-12:
        side = 1.0 / kf
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
              for i in range(kf) for j in range(kf)]
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        return sq[:n]
    k = bestk
    blocks, occ = best[1]
    s = 1.0 / k
    res = []
    for (i, j, m) in blocks:
        res.append(((i + m / 2.0) * s, (j + m / 2.0) * s, 0.0, m * s))
    for i in range(k):
        for j in range(k):
            if not occ[i][j] and len(res) < n:
                res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
