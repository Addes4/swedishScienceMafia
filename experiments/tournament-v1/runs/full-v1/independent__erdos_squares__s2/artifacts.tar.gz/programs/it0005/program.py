import math
import numpy as np


def _place(m, b4, b3, a2, units):
    occ = np.zeros((m, m), dtype=bool)
    res = []
    for t, cnt in ((4, b4), (3, b3), (2, a2)):
        for _ in range(cnt):
            done = False
            for i in range(m - t + 1):
                for j in range(m - t + 1):
                    if not occ[i:i + t, j:j + t].any():
                        occ[i:i + t, j:j + t] = True
                        res.append((i, j, t))
                        done = True
                        break
                if done:
                    break
            if not done:
                return None
    free = [(i, j) for i in range(m) for j in range(m) if not occ[i, j]]
    if len(free) < units:
        return None
    for (i, j) in free[:units]:
        res.append((i, j, 1))
    return res


def solve(n):
    k = max(1, math.isqrt(n))
    best_grid = k
    out_grid = None

    cands = []
    for m in range(k + 1, k + 4):
        d = m * m - n
        if d < 0:
            continue
        for b4 in range(0, min(d // 15, (m // 4) ** 2 + 1) + 1):
            r4 = 15 * b4
            for b3 in range(0, (d - r4) // 8 + 1):
                r3 = r4 + 8 * b3
                for a2 in range(0, (d - r3) // 3 + 1):
                    r = r3 + 3 * a2
                    drops = d - r
                    area = 16 * b4 + 9 * b3 + 4 * a2
                    units = m * m - area - drops
                    if units < 0:
                        continue
                    val = (4 * b4 + 3 * b3 + 2 * a2 + units) / m
                    if val > best_grid + 1e-12:
                        cands.append((val, m, b4, b3, a2, units))
    cands.sort(reverse=True)
    tries = 0
    for val, m, b4, b3, a2, units in cands:
        tries += 1
        if tries > 60:
            break
        pl = _place(m, b4, b3, a2, units)
        if pl is None or len(pl) != n:
            continue
        shrink = 1 - 1e-9
        out = []
        for (i, j, t) in pl:
            out.append(((j + t / 2) / m, (i + t / 2) / m, 0.0, t / m * shrink))
        return out

    side = 1.0 / k * (1 - 1e-9)
    squares = [((i + 0.5) / k, (j + 0.5) / k, 0.0, side) for i in range(k) for j in range(k)]
    squares = squares[:n]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
