import math


def solve(n):
    best = None
    for m in range(1, math.isqrt(n) + 4):
        cells = m * m
        maxc = (m // 2) ** 2
        for c in range(0, maxc + 1):
            base = cells - 3 * c
            if base > n:
                continue
            free = cells - 4 * c
            for b in range(0, free + 1):
                cnt = base + 8 * b
                if cnt > n:
                    break
                a = min((n - cnt) // 3, free - b)
                if a < 0:
                    continue
                val = m + (a + 2 * b - 2 * c) / m
                if best is None or val > best[0] + 1e-12:
                    best = (val, m, a, b, c)
    _, m, a, b, c = best
    s = 1.0 / m
    used = set()
    sq = []
    bi = bj = 0
    for k in range(c):
        bi, bj = divmod(k, m // 2)
        for di in range(2):
            for dj in range(2):
                used.add((2 * bi + di, 2 * bj + dj))
        sq.append(((2 * bj + 1) * s, (2 * bi + 1) * s, 0.0, 2 * s))
    free_cells = [(i, j) for i in range(m) for j in range(m) if (i, j) not in used]
    idx = 0
    for _ in range(b):
        i, j = free_cells[idx]
        idx += 1
        t = s / 3
        for p in range(3):
            for q in range(3):
                sq.append((j * s + (q + 0.5) * t, i * s + (p + 0.5) * t, 0.0, t))
    for _ in range(a):
        i, j = free_cells[idx]
        idx += 1
        t = s / 2
        for p in range(2):
            for q in range(2):
                sq.append((j * s + (q + 0.5) * t, i * s + (p + 0.5) * t, 0.0, t))
    for i, j in free_cells[idx:]:
        sq.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    sq = sq[:n] if len(sq) > n else sq
    out = []
    for x, y, ang, sd in sq:
        out.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), ang, min(1.0, max(0.0, sd))))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
