import math
import numpy as np


def solve(n):
    best = (-1.0, None)
    rmax = int(math.isqrt(n)) + 3
    for r in range(1, rmax + 1):
        for t in range(1, 3 * r + 4):
            for d in range(0, 7):
                u = t + d
                if d == 0:
                    a = np.array([r])
                else:
                    a = np.arange(0, r + 1)
                S = a * t + (r - a) * u
                H = a / t + (r - a) / u
                ok = (S <= n) & (H <= 1.0 + 1e-12)
                if not ok.any():
                    continue
                L = 1.0 - H
                rem = n - S
                with np.errstate(divide='ignore', invalid='ignore'):
                    mp = np.where(L > 1e-9, np.minimum(rem, np.floor(1.0 / np.maximum(L, 1e-12) + 1e-9)), 0)
                gain = r + mp * np.where(L > 1e-9, L, 0.0)
                gain = np.where(ok, gain, -1.0)
                i = int(np.argmax(gain))
                if gain[i] > best[0] + 1e-12:
                    best = (float(gain[i]), (r, t, u, int(a[i]), int(mp[i]), float(L[i])))
    squares = []
    if best[1] is not None:
        r, t, u, a, mp, L = best[1]
        ms = [t] * a + [u] * (r - a)
        y = 0.0
        shrink = 1.0 - 1e-11
        for m in ms:
            s = 1.0 / m
            for i in range(m):
                squares.append(((i + 0.5) * s, y + 0.5 * s, 0.0, s * shrink))
            y += s
        if mp > 0 and L > 1e-9:
            for i in range(mp):
                squares.append(((i + 0.5) * L, y + 0.5 * L, 0.0, L * shrink))
    squares = squares[:n]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    out = []
    for cx, cy, ang, s in squares:
        out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), ang, min(1.0, max(0.0, s))))
    return out
