import time
import numpy as np
from scipy.optimize import minimize, linprog


def _lp_radii(centers):
    n = len(centers)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    m = len(I)
    A = np.zeros((m, n))
    A[np.arange(m), I] = 1
    A[np.arange(m), J] = 1
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status != 0:
        return np.zeros(n)
    return np.maximum(res.x - 1e-12, 0)


def _slsqp(x0, n, I, J, maxiter=300):
    m = len(I)
    ar = np.arange(m)

    def obj(v):
        return -np.sum(v[2 * n:])

    def gobj(v):
        g = np.zeros(3 * n)
        g[2 * n:] = -1
        return g

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        d = np.sqrt((x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 + 1e-18)
        return np.concatenate([d - r[I] - r[J], x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(v):
        x = v[:n]; y = v[n:2 * n]
        dx = x[I] - x[J]; dy = y[I] - y[J]
        d = np.sqrt(dx ** 2 + dy ** 2 + 1e-18)
        Jm = np.zeros((m + 4 * n, 3 * n))
        Jm[ar, I] = dx / d
        Jm[ar, J] = -dx / d
        Jm[ar, n + I] = dy / d
        Jm[ar, n + J] = -dy / d
        Jm[ar, 2 * n + I] = -1
        Jm[ar, 2 * n + J] = -1
        k = np.arange(n)
        Jm[m + k, k] = 1; Jm[m + k, 2 * n + k] = -1
        Jm[m + n + k, k] = -1; Jm[m + n + k, 2 * n + k] = -1
        Jm[m + 2 * n + k, n + k] = 1; Jm[m + 2 * n + k, 2 * n + k] = -1
        Jm[m + 3 * n + k, n + k] = -1; Jm[m + 3 * n + k, 2 * n + k] = -1
        return Jm

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(obj, x0, jac=gobj, bounds=bounds,
                       constraints=[{"type": "ineq", "fun": cons, "jac": jac}],
                       method="SLSQP", options={"maxiter": maxiter, "ftol": 1e-10})
        v = res.x
    except Exception:
        v = x0
    return np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0, 1)


def _start(n, rng, kind):
    if kind == 0:
        c = rng.random((n, 2))
    elif kind == 1:
        # jittered grid
        k = int(np.ceil(np.sqrt(n)))
        pts = [((i + 0.5) / k, (j + 0.5) / k) for i in range(k) for j in range(k)]
        idx = rng.permutation(len(pts))[:n]
        c = np.array(pts)[idx] + rng.normal(0, 0.03, (n, 2))
    else:
        # staggered rows 5-5-6-5-5 style
        rows = [5, 5, 5, 5, 6]
        rng.shuffle(rows)
        pts = []
        for ri, cnt in enumerate(rows):
            for q in range(cnt):
                pts.append(((q + 0.5 + 0.3 * (ri % 2)) / (cnt + 0.3), (ri + 0.5) / len(rows)))
        c = np.array(pts[:n])
        if len(c) < n:
            c = np.vstack([c, rng.random((n - len(c), 2))])
        c = c + rng.normal(0, 0.03, c.shape)
    return np.clip(c, 0.02, 0.98)


def solve(n=26):
    t0 = time.time()
    budget = 230
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)

    best_c, best_r, best_s = None, None, -1

    def evaluate(c):
        nonlocal best_c, best_r, best_s
        r = _lp_radii(c)
        s = r.sum()
        if s > best_s:
            best_c, best_r, best_s = c.copy(), r, s
        return s, r

    def run(c):
        r0 = _lp_radii(c)
        v0 = np.concatenate([c[:, 0], c[:, 1], r0])
        c2 = _slsqp(v0, n, I, J)
        return c2

    it = 0
    # phase 1: multistart
    while time.time() - t0 < budget * 0.45:
        c = run(_start(n, rng, it % 3))
        evaluate(c)
        it += 1
    # phase 2: basin hopping from best
    while time.time() - t0 < budget:
        c = best_c.copy()
        mode = rng.integers(3)
        if mode == 0:
            k = rng.integers(1, 4)
            idx = np.argsort(best_r)[:k] if rng.random() < 0.5 else rng.choice(n, k, replace=False)
            c[idx] = rng.random((len(idx), 2))
        elif mode == 1:
            c += rng.normal(0, 0.03, c.shape)
        else:
            i, j = rng.choice(n, 2, replace=False)
            c[[i, j]] = c[[j, i]]
            c += rng.normal(0, 0.01, c.shape)
        c = np.clip(c, 0.01, 0.99)
        c2 = run(c)
        evaluate(c2)
    return best_c, best_r
