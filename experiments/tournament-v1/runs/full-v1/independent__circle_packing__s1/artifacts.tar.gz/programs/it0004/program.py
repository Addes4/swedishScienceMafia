import numpy as np
import time
from scipy.optimize import minimize, linprog


def _lp_radii(centers):
    n = len(centers)
    x, y = centers[:, 0], centers[:, 1]
    wall = np.minimum.reduce([x, y, 1 - x, 1 - y])
    wall = np.maximum(wall, 0)
    I, J = np.triu_indices(n, 1)
    d = np.hypot(x[I] - x[J], y[I] - y[J])
    m = len(I)
    A = np.zeros((m, n))
    A[np.arange(m), I] = 1
    A[np.arange(m), J] = 1
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status == 0:
        return np.maximum(res.x - 1e-12, 0)
    return np.maximum(wall * 0.0, 0)


def _optimize(c0, r0, n, I, J, maxiter=300):
    m = len(I)
    ar = np.arange(m)

    def f(v):
        return -np.sum(v[2 * n:])

    def fg(v):
        g = np.zeros(3 * n)
        g[2 * n:] = -1
        return g

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        pair = (x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 - (r[I] + r[J]) ** 2
        return np.concatenate([pair, x - r, 1 - x - r, y - r, 1 - y - r])

    def cjac(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        Jm = np.zeros((m + 4 * n, 3 * n))
        dx = x[I] - x[J]; dy = y[I] - y[J]; s = r[I] + r[J]
        Jm[ar, I] = 2 * dx
        Jm[ar, J] = -2 * dx
        Jm[ar, n + I] = 2 * dy
        Jm[ar, n + J] = -2 * dy
        Jm[ar, 2 * n + I] = -2 * s
        Jm[ar, 2 * n + J] = -2 * s
        k = np.arange(n)
        Jm[m + k, k] = 1; Jm[m + k, 2 * n + k] = -1
        Jm[m + n + k, k] = -1; Jm[m + n + k, 2 * n + k] = -1
        Jm[m + 2 * n + k, n + k] = 1; Jm[m + 2 * n + k, 2 * n + k] = -1
        Jm[m + 3 * n + k, n + k] = -1; Jm[m + 3 * n + k, 2 * n + k] = -1
        return Jm

    v0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(f, v0, jac=fg, bounds=bounds,
                       constraints=[{"type": "ineq", "fun": cons, "jac": cjac}],
                       method="SLSQP", options={"maxiter": maxiter, "ftol": 1e-12})
    except Exception:
        return None
    v = res.x
    c = np.stack([np.clip(v[:n], 0, 1), np.clip(v[n:2 * n], 0, 1)], axis=1)
    return c


def _init(n, rng, kind):
    if kind == 0:
        c = rng.random((n, 2))
    elif kind == 1:
        # jittered grid-ish layout
        k = int(np.ceil(np.sqrt(n)))
        pts = [((i + 0.5) / k, (j + 0.5) / k) for i in range(k) for j in range(k)]
        idx = rng.permutation(len(pts))[:n]
        c = np.array(pts)[idx] + rng.normal(0, 0.03, (n, 2))
    else:
        # hex-like rows
        rows = rng.choice([5, 6])
        pts = []
        for j in range(rows):
            cnt = 5 if j % 2 == 0 else 6
            if rng.random() < 0.5:
                cnt = 6 if j % 2 == 0 else 5
            for i in range(cnt):
                pts.append(((i + 0.5 + 0.5 * (j % 2) * 0) / cnt, (j + 0.5) / rows))
        pts = np.array(pts)
        idx = rng.permutation(len(pts))[:n] if len(pts) >= n else np.arange(len(pts))
        c = pts[idx]
        if len(c) < n:
            c = np.vstack([c, rng.random((n - len(c), 2))])
        c = c + rng.normal(0, 0.03, (n, 2))
    return np.clip(c, 0.02, 0.98)


def solve(n=26):
    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(12345)
    I, J = np.triu_indices(n, 1)
    best_c, best_r, best_s = None, None, -1

    def evaluate(c):
        r = _lp_radii(c)
        return r, r.sum()

    it = 0
    while time.time() - t0 < budget:
        it += 1
        if best_c is None or it % 3 == 1 and rng.random() < 0.5:
            c0 = _init(n, rng, rng.integers(0, 3))
        else:
            c0 = best_c.copy()
            mode = rng.integers(0, 3)
            if mode == 0:
                c0 += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), c0.shape)
            elif mode == 1:
                k = rng.integers(1, 4)
                ids = rng.choice(n, k, replace=False)
                c0[ids] = rng.random((k, 2))
            else:
                ids = np.argsort(best_r)[:rng.integers(1, 4)]
                c0[ids] = rng.random((len(ids), 2))
                c0 += rng.normal(0, 0.01, c0.shape)
            c0 = np.clip(c0, 0.02, 0.98)
        r0 = _lp_radii(c0)
        c = _optimize(c0, r0 * 0.9, n, I, J)
        if c is None:
            continue
        r, s = evaluate(c)
        if s > best_s:
            best_s, best_c, best_r = s, c, r
    if best_c is None:
        best_c = _init(n, rng, 0)
        best_r = _lp_radii(best_c)
    return best_c, best_r
