import time
import numpy as np
from scipy.optimize import minimize, linprog


def _lp_radii(c):
    n = len(c)
    iu, ju = np.triu_indices(n, 1)
    d = np.linalg.norm(c[iu] - c[ju], axis=1)
    m = len(iu)
    A = np.zeros((m, n))
    A[np.arange(m), iu] = 1
    A[np.arange(m), ju] = 1
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    wall = np.maximum(wall, 0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall],
                  method="highs")
    if res.status != 0:
        return None
    r = np.maximum(res.x - 1e-12, 0)
    return r


def _optimize(c0, r0, n, iu, ju, maxiter=300):
    m = len(iu)
    rows = np.arange(m)

    def fobj(v):
        return -np.sum(v[2 * n:])

    def gobj(v):
        g = np.zeros(3 * n)
        g[2 * n:] = -1
        return g

    def cons(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        d = np.sqrt((x[iu] - x[ju]) ** 2 + (y[iu] - y[ju]) ** 2 + 1e-18)
        return np.concatenate([d - r[iu] - r[ju], x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(v):
        x = v[:n]; y = v[n:2 * n]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]
        d = np.sqrt(dx ** 2 + dy ** 2 + 1e-18)
        J = np.zeros((m + 4 * n, 3 * n))
        J[rows, iu] = dx / d
        J[rows, ju] = -dx / d
        J[rows, n + iu] = dy / d
        J[rows, n + ju] = -dy / d
        J[rows, 2 * n + iu] = -1
        J[rows, 2 * n + ju] = -1
        k = np.arange(n)
        J[m + k, k] = 1; J[m + k, 2 * n + k] = -1
        J[m + n + k, k] = -1; J[m + n + k, 2 * n + k] = -1
        J[m + 2 * n + k, n + k] = 1; J[m + 2 * n + k, 2 * n + k] = -1
        J[m + 3 * n + k, n + k] = -1; J[m + 3 * n + k, 2 * n + k] = -1
        return J

    v0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(fobj, v0, jac=gobj, bounds=bounds, method="SLSQP",
                       constraints=[{"type": "ineq", "fun": cons, "jac": jac}],
                       options={"maxiter": maxiter, "ftol": 1e-10})
    except Exception:
        return None
    v = res.x
    return np.clip(np.stack([v[:n], v[n:2 * n]], axis=1), 0, 1)


def solve(n=26):
    t0 = time.time()
    budget = 230.0
    rng = np.random.default_rng(12345)
    iu, ju = np.triu_indices(n, 1)
    best_c, best_r, best_s = None, None, -1

    def evaluate(c):
        nonlocal best_c, best_r, best_s
        r = _lp_radii(c)
        if r is None:
            return -1
        s = r.sum()
        if s > best_s:
            best_s, best_c, best_r = s, c.copy(), r.copy()
        return s

    it = 0
    last_run = 1.0
    while time.time() - t0 < budget - last_run * 1.5:
        ts = time.time()
        if best_c is None or it < 12 or rng.random() < 0.25:
            c0 = rng.random((n, 2)) * 0.9 + 0.05
        else:
            c0 = best_c.copy()
            mode = rng.random()
            if mode < 0.5:
                k = rng.integers(1, 5)
                idx = rng.choice(n, k, replace=False)
                c0[idx] = rng.random((k, 2)) * 0.9 + 0.05
            else:
                c0 += rng.normal(0, rng.choice([0.01, 0.03, 0.06]), c0.shape)
            c0 = np.clip(c0, 0.02, 0.98)
        r0 = np.full(n, 0.5 / np.sqrt(n) * 0.6)
        c = _optimize(c0, r0, n, iu, ju)
        if c is not None:
            evaluate(c)
        it += 1
        last_run = time.time() - ts

    if best_c is None:
        c = np.clip(rng.random((n, 2)), 0.05, 0.95)
        r = _lp_radii(c)
        return c, r
    return best_c, best_r
