import math
import time


def solve(n):
    t0 = time.time()
    k = max(1, math.isqrt(n))
    cap = 3 * k + 3
    memo = {}
    LIMIT = 25.0
    sys_rec = None
    try:
        import sys
        sys.setrecursionlimit(10000)
    except Exception:
        pass

    def best(nleft, hleft, maxc):
        # returns value; choice stored in memo
        if nleft <= 0 or hleft < 1e-9:
            return 0.0
        key = (nleft, int(round(hleft * 1e9)), maxc)
        if key in memo:
            return memo[key][0]
        # terminal partial row
        cf = min(nleft, int(math.floor(1.0 / hleft + 1e-9)))
        bv = cf * hleft if cf > 0 else 0.0
        bch = ('p', cf, hleft)
        if time.time() - t0 < LIMIT:
            cmin = max(1, int(math.ceil(1.0 / hleft - 1e-9)))
            cmax = min(maxc, nleft, cap)
            for c in range(cmin, cmax + 1):
                h = 1.0 / c
                if h > hleft + 1e-12:
                    continue
                v = 1.0 + best(nleft - c, hleft - h, c)
                if v > bv + 1e-12:
                    bv = v
                    bch = ('f', c, h)
        memo[key] = (bv, bch)
        return bv

    total = best(n, 1.0, n)

    rows = []
    nleft, hleft, maxc = n, 1.0, n
    while nleft > 0 and hleft >= 1e-9:
        key = (nleft, int(round(hleft * 1e9)), maxc)
        if key not in memo:
            break
        v, ch = memo[key]
        kind, c, h = ch
        if c <= 0:
            break
        rows.append((c, h))
        if kind == 'p':
            break
        nleft -= c
        hleft -= h
        maxc = c

    squares = []
    y = 0.0
    for c, h in rows:
        for j in range(c):
            s = h * (1 - 1e-12)
            squares.append(((j + 0.5) * h, y + h / 2, 0.0, s))
        y += h
    val = sum(s[3] for s in squares)

    # baseline grid
    g = k
    gside = 1.0 / g
    gs = [((i + 0.5) * gside, (j + 0.5) * gside, 0.0, gside * (1 - 1e-12))
          for i in range(g) for j in range(g)][:n]
    gval = sum(s[3] for s in gs)
    if gval > val or len(squares) > n:
        squares = gs
    squares = squares[:n]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    out = []
    for cx, cy, a, s in squares:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        out.append((cx, cy, a, min(1.0, max(0.0, s))))
    return out
