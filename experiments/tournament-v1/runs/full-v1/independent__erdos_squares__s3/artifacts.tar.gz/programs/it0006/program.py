import math
import time
import numpy as np


def _baseline(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]


def _dp(m, n):
    N = n + 1
    NEG = -np.inf
    F = np.zeros((m + 1, m + 1, N))
    for a in range(1, m + 1):
        for b in range(1, m + 1):
            best = np.zeros(N)
            best[1:] = min(a, b)
            if a >= 2:
                h = a // 2
                i1 = np.arange(1, h + 1)
                i2 = a - i1
                A = F[i1, b, :]
                B = F[i2, b, :]
                S = (A[:, :, None] + B[:, None, :]).max(0)
                best = np.maximum(best, _skew(S, N))
            if b >= 2:
                h = b // 2
                i1 = np.arange(1, h + 1)
                i2 = b - i1
                A = F[a, i1, :]
                B = F[a, i2, :]
                S = (A[:, :, None] + B[:, None, :]).max(0)
                best = np.maximum(best, _skew(S, N))
            F[a, b, :] = best
    return F


def _skew(S, N):
    P = np.full((N, 2 * N), -np.inf)
    P[:, :N] = S
    flat = P.ravel()[:N * (2 * N - 1)].reshape(N, 2 * N - 1)
    return flat[:, :N].max(0)


def _build(F, m, n):
    out = []
    stack = [(m, m, n, 0, 0)]
    eps = 1e-9
    while stack:
        a, b, c, x, y = stack.pop()
        if c <= 0 or F[a, b, c] < eps:
            continue
        v = F[a, b, c]
        if v <= min(a, b) + eps:
            s = min(a, b)
            out.append((x, y, s))
            continue
        found = False
        for a1 in range(1, a):
            f1 = F[a1, b]
            f2 = F[a - a1, b]
            for c1 in range(0, c + 1):
                if f1[c1] + f2[c - c1] >= v - eps:
                    stack.append((a1, b, c1, x, y))
                    stack.append((a - a1, b, c - c1, x + a1, y))
                    found = True
                    break
            if found:
                break
        if found:
            continue
        for b1 in range(1, b):
            f1 = F[a, b1]
            f2 = F[a, b - b1]
            for c1 in range(0, c + 1):
                if f1[c1] + f2[c - c1] >= v - eps:
                    stack.append((a, b1, c1, x, y))
                    stack.append((a, b - b1, c - c1, x, y + b1))
                    found = True
                    break
            if found:
                break
    return out


def solve(n):
    t0 = time.time()
    best_val = math.isqrt(n)
    best_sq = _baseline(n)
    if n > 250:
        return best_sq
    k = max(1, math.isqrt(n))
    mmax = min(3 * k + 4, 40)
    last_t = 0.0
    last_m = 0
    for m in range(1, mmax + 1):
        if last_m > 0:
            est = last_t * ((m / last_m) ** 4)
            if time.time() - t0 + est > 35:
                break
        ts = time.time()
        F = _dp(m, n)
        last_t = max(time.time() - ts, 1e-4)
        last_m = m
        val = F[m, m, n] / m
        if val > best_val + 1e-9:
            items = _build(F, m, n)
            if len(items) <= n:
                tot = sum(s for _, _, s in items) / m
                if tot > best_val:
                    sq = []
                    for (x, y, s) in items:
                        side = s / m * (1 - 1e-12)
                        sq.append(((x + s / 2.0) / m, (y + s / 2.0) / m, 0.0, side))
                    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
                    best_sq = sq
                    best_val = tot
    return best_sq[:n]
