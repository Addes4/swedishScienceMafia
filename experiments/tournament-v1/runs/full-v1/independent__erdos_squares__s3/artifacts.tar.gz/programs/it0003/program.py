import math
import time


def solve(n):
    t0 = time.time()
    k = math.isqrt(n)
    if k * k < n:
        k += 1
    best = None  # (value, m, blocks, drops)

    for m in range(k, k + 4):
        r = m * m - n
        if r < 0:
            continue
        state = {"best": -1.0, "blocks": [], "nodes": 0}

        def first_fit(grid, j):
            for y in range(m - j + 1):
                for x in range(m - j + 1):
                    ok = True
                    for yy in range(y, y + j):
                        row = grid[yy]
                        for xx in range(x, x + j):
                            if row[xx]:
                                ok = False
                                break
                        if not ok:
                            break
                    if ok:
                        return x, y
            return None

        def dfs(j, R, cost, grid, blocks):
            state["nodes"] += 1
            d = max(0, r - R)
            val = m - cost - d
            if val > state["best"]:
                state["best"] = val
                state["blocks"] = list(blocks)
            if R >= r or state["nodes"] > 20000 or time.time() - t0 > 40:
                return
            for jj in range(min(j, m), 1, -1):
                pos = first_fit(grid, jj)
                if pos is None:
                    continue
                x, y = pos
                ng = [row[:] for row in grid]
                for yy in range(y, y + jj):
                    for xx in range(x, x + jj):
                        ng[yy][xx] = 1
                blocks.append((x, y, jj))
                dfs(jj, R + jj * jj - 1, cost + jj * jj - jj, ng, blocks)
                blocks.pop()

        grid0 = [[0] * m for _ in range(m)]
        dfs(m, 0, 0, grid0, [])
        v = state["best"] / m
        if best is None or v > best[0]:
            best = (v, m, state["blocks"])

    v, m, blocks = best
    r = m * m - n
    R = sum(j * j - 1 for _, _, j in blocks)
    d = max(0, r - R)
    occ = [[0] * m for _ in range(m)]
    squares = []
    shrink = 1 - 1e-9
    for x, y, j in blocks:
        for yy in range(y, y + j):
            for xx in range(x, x + j):
                occ[yy][xx] = 1
        squares.append(((x + j / 2) / m, (y + j / 2) / m, 0.0, j / m * shrink))
    dropped = 0
    for y in range(m):
        for x in range(m):
            if occ[y][x]:
                continue
            if dropped < d:
                dropped += 1
                continue
            squares.append(((x + 0.5) / m, (y + 0.5) / m, 0.0, shrink / m))
    squares = squares[:n] if len(squares) > n else squares
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares
