import math
import time
import numpy as np


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    NEG = -1e18
    f = [0.0] * (n + 1)
    choice = [None] * (n + 1)
    f[1] = 1.0
    choice[1] = ('one',)
    mmax_all = math.isqrt(n) + 3
    jmax = mmax_all - 1
    pairs = [(a, b) for a in range(1, jmax + 1) for b in range(a, jmax + 1)]
    G = {p: np.full(n + 1, NEG) for p in pairs}
    GA = {p: [0] * (n + 1) for p in pairs}
    farr = np.zeros(n + 1)
    farr[1] = 1.0
    two_ok = n <= 200
    for k in range(2, n + 1):
        best = f[k - 1]
        bc = ('copy',)
        late = time.time() - t0 > 40
        if late:
            f[k] = best
            choice[k] = bc
            farr[k] = best
            continue
        mmax = math.isqrt(k) + 3
        use_two = two_ok and (time.time() - t0 < 25)
        if use_two:
            for p in pairs:
                if p[1] > mmax - 1:
                    break if False else None
                j1, j2 = p
                vals = j1 * farr[1:k] + j2 * farr[k - 1:0:-1]
                i = int(np.argmax(vals))
                G[p][k] = vals[i]
                GA[p][k] = i + 1
        for m in range(2, mmax + 1):
            for j in range(1, m):
                cap = m * m - j * j
                cmax = min(cap, k)
                if cmax < 1:
                    continue
                cs = np.arange(1, cmax + 1)
                vals = (cs + j * farr[k - cs]) / m
                i = int(np.argmax(vals))
                if vals[i] > best + 1e-12:
                    best = float(vals[i])
                    bc = ('one', m, j, int(cs[i]), k - int(cs[i]))
            if use_two:
                for (j1, j2) in pairs:
                    if j1 + j2 > m:
                        continue
                    cap = m * m - j1 * j1 - j2 * j2
                    cmax = min(cap, k - 2)
                    if cmax < 0:
                        continue
                    seg = G[(j1, j2)][k - cmax:k + 1][::-1]  # c=0..cmax
                    vals = (np.arange(0, cmax + 1) + seg) / m
                    i = int(np.argmax(vals))
                    if vals[i] > best + 1e-12:
                        best = float(vals[i])
                        c = i
                        N = k - c
                        n1 = GA[(j1, j2)][N]
                        bc = ('two', m, j1, j2, c, n1, N - n1)
        f[k] = best
        choice[k] = bc
        farr[k] = best

    out = []
    shrink = 1 - 1e-9

    def build(k, x0, y0, s):
        if k <= 0:
            return
        ch = choice[k]
        if ch[0] == 'copy':
            out.append((x0 + s / 2, y0 + s / 2, 0.0, 0.0))
            build(k - 1, x0, y0, s)
            return
        if ch[0] == 'one' and len(ch) == 1:
            out.append((x0 + s / 2, y0 + s / 2, 0.0, s))
            return
        if ch[0] == 'one':
            _, m, j, c, N = ch
            blocks = [(j, N)]
        else:
            _, m, j1, j2, c, n1, n2 = ch
            blocks = [(j1, n1), (j2, n2)]
        cell = s / m
        covered = set()
        offs = []
        if len(blocks) == 1:
            offs = [0]
        else:
            offs = [0, m - blocks[1][0]]
        for (jj, nn), o in zip(blocks, offs):
            for a in range(o, o + jj):
                for b in range(o, o + jj):
                    covered.add((a, b))
            build(nn, x0 + o * cell, y0 + o * cell, jj * cell)
        cnt = 0
        for a in range(m):
            for b in range(m):
                if cnt >= c:
                    break
                if (a, b) in covered:
                    continue
                out.append((x0 + (a + 0.5) * cell, y0 + (b + 0.5) * cell, 0.0, cell))
                cnt += 1

    build(n, 0.0, 0.0, 1.0)
    res = []
    for (x, y, a, s) in out:
        s2 = min(1.0, max(0.0, s * shrink))
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), a, s2))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
