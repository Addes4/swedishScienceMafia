import math


def solve(n):
    best = (-1.0, None)
    pmax = min(n, int(4 * math.sqrt(n)) + 4)
    for p in range(1, pmax + 1):
        for a in range(1, min(p, n // p) + 1):
            h1 = a / p
            if h1 > 1 + 1e-12:
                continue
            for q in range(1, p + 1):
                bmax = 0 if q == p else (n - a * p) // q
                for b in range(0, bmax + 1):
                    H = 1.0 - h1 - b / q
                    if H < -1e-12:
                        break
                    H = max(H, 0.0)
                    R = n - a * p - b * q
                    if R < 0:
                        break
                    val = a * 1.0 + b * 1.0
                    mp, hp = 0, 0.0
                    if R > 0 and H > 1e-12:
                        f = int(math.floor(1.0 / H + 1e-12))
                        for mm in (f, f + 1):
                            mm = min(mm, R)
                            if mm < 1:
                                continue
                            hh = min(H, 1.0 / mm)
                            if mm * hh > mp * hp:
                                mp, hp = mm, hh
                    tot = val + mp * hp
                    if tot > best[0] + 1e-12:
                        best = (tot, (p, a, q, b, mp, hp))
    p, a, q, b, mp, hp = best[1]
    rows = [(p, 1.0 / p)] * a + ([(q, 1.0 / q)] * b if q != p or b else [])
    if mp > 0:
        rows.append((mp, hp))
    shrink = 1 - 1e-10
    squares = []
    y = 0.0
    for m, h in rows:
        for i in range(m):
            s = h * shrink
            cx = (i + 0.5) * h
            cy = y + h / 2
            squares.append((min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), 0.0, s))
        y += h
    squares = squares[:n]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares
