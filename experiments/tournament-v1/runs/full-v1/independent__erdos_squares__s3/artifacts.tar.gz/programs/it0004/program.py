import math
import numpy as np


def _pack(K, blocks):
    occ = np.zeros((K, K), dtype=bool)
    placed = []
    for m in blocks:
        ok = False
        for i in range(K - m + 1):
            for j in range(K - m + 1):
                if not occ[i:i + m, j:j + m].any():
                    occ[i:i + m, j:j + m] = True
                    placed.append((i, j, m))
                    ok = True
                    break
            if ok:
                break
        if not ok:
            return None, None
    return placed, occ


def solve(n):
    k = max(1, math.isqrt(n))
    cands = []
    for K in range(k, k + 3):
        if K * K < 1:
            continue
        maxm = min(K, 6 if K <= 12 else 4)
        sizes = list(range(maxm, 1, -1))
        area_total = K * K

        def rec(idx, area, cnt, sm, blocks):
            if idx == len(sizes):
                u = min(area_total - area, n - cnt)
                if u < 0:
                    return
                cands.append((sm + u, K, tuple(blocks)))
                return
            m = sizes[idx]
            a = 0
            while True:
                if area + a * m * m > area_total or cnt + a > n:
                    break
                rec(idx + 1, area + a * m * m, cnt + a, sm + a * m,
                    blocks + [m] * a)
                a += 1
                if m == K and a > 1:
                    break
        if K > 1:
            rec(0, 0, 0, 0, [])
        else:
            cands.append((min(1, n), 1, ()))
    cands.sort(key=lambda t: -t[0] / t[1])
    for val, K, blocks in cands[:20000]:
        placed, occ = _pack(K, list(blocks))
        if placed is None:
            continue
        cnt = len(placed)
        u = min(K * K - sum(m * m for m in blocks), n - cnt)
        res = []
        for (i, j, m) in placed:
            res.append(((j + m / 2) / K, (i + m / 2) / K, 0.0, m / K))
        c = 0
        if u > 0:
            for i in range(K):
                for j in range(K):
                    if c >= u:
                        break
                    if not occ[i, j]:
                        res.append(((j + 0.5) / K, (i + 0.5) / K, 0.0, 1.0 / K))
                        c += 1
                if c >= u:
                    break
        while len(res) < n:
            res.append((0.5, 0.5, 0.0, 0.0))
        return res[:n]
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
