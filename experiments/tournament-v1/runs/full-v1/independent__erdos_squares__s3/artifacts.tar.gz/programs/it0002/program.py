import math


def _try_m(n, m):
    E = m * m - n
    if E < 0:
        return None
    # knapsack: remove exactly E squares at min cost
    INF = float("inf")
    dp = [INF] * (E + 1)
    ch = [0] * (E + 1)
    dp[0] = 0
    for r in range(1, E + 1):
        for j in range(1, m + 1):
            rem = j * j - 1 if j > 1 else 1
            cost = j * j - j if j > 1 else 1
            if rem <= r and dp[r - rem] + cost < dp[r]:
                dp[r] = dp[r - rem] + cost
                ch[r] = j
    if dp[E] == INF:
        return None
    blocks = []
    r = E
    e = 0
    while r > 0:
        j = ch[r]
        if j == 1:
            e += 1
            r -= 1
        else:
            blocks.append(j)
            r -= j * j - 1
    total = (m * m - e - sum(j * j for j in blocks) + sum(blocks)) / m
    return total, blocks, e


def _build(n, m, blocks, e):
    occ = [[False] * m for _ in range(m)]
    res = []
    s = 1.0 / m
    sh = s * (1 - 1e-9)
    for j in sorted(blocks, reverse=True):
        placed = False
        for y in range(m - j + 1):
            for x in range(m - j + 1):
                ok = True
                for yy in range(y, y + j):
                    row = occ[yy]
                    for xx in range(x, x + j):
                        if row[xx]:
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    for yy in range(y, y + j):
                        for xx in range(x, x + j):
                            occ[yy][xx] = True
                    res.append(((x + j / 2.0) * s, (y + j / 2.0) * s, 0.0, j * sh))
                    placed = True
                    break
            if placed:
                break
        if not placed:
            return None
    free = [(x, y) for y in range(m) for x in range(m) if not occ[y][x]]
    if e > len(free):
        return None
    free = free[:len(free) - e]
    for x, y in free:
        res.append(((x + 0.5) * s, (y + 0.5) * s, 0.0, sh))
    return res


def solve(n):
    k = math.isqrt(n)
    if k * k < n:
        k0 = k + 1
    else:
        k0 = k
    # baseline
    best_sum = float(k)
    best = None
    s = 1.0 / k
    base = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s * (1 - 1e-9))
            for i in range(k) for j in range(k)]
    best = base
    for m in range(k0, k0 + 5):
        if m > 400:
            break
        r = _try_m(n, m)
        if r is None:
            continue
        tot, blocks, e = r
        if tot > best_sum + 1e-12:
            built = _build(n, m, blocks, e)
            if built is not None and len(built) <= n:
                best_sum = tot
                best = built
    res = list(best)[:n]
    res += [(0.5, 0.5, 0.0, 0.0)] * (n - len(res))
    return res
