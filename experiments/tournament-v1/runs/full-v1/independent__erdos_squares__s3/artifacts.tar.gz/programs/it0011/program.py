import math


def _place(k, blocks):
    grid = [[False] * k for _ in range(k)]
    placed = []
    for j in blocks:
        done = False
        for r in range(k - j + 1):
            for c in range(k - j + 1):
                ok = True
                for rr in range(r, r + j):
                    row = grid[rr]
                    for cc in range(c, c + j):
                        if row[cc]:
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    for rr in range(r, r + j):
                        for cc in range(c, c + j):
                            grid[rr][cc] = True
                    placed.append((r, c, j))
                    done = True
                    break
            if done:
                break
        if not done:
            return None, None
    return grid, placed


def solve(n):
    k0 = math.isqrt(n)
    if k0 * k0 < n:
        k0 += 1
    best = None
    for k in range(k0, k0 + 5):
        d = k * k - n
        if d < 0:
            continue
        cands = []
        for b4 in range(0, d // 15 + 1):
            if 4 * b4 > k * k:
                break
            for b3 in range(0, (d - 15 * b4) // 8 + 1):
                for b2 in range(0, (d - 15 * b4 - 8 * b3) // 3 + 1):
                    B = b2 + b3 + b4
                    A = 4 * b2 + 9 * b3 + 16 * b4
                    if A > k * k:
                        continue
                    units = min(n - B, k * k - A)
                    if units < 0:
                        continue
                    s = (units + 2 * b2 + 3 * b3 + 4 * b4) / k
                    cands.append((s, b4, b3, b2))
        cands.sort(reverse=True)
        tried = 0
        for s, b4, b3, b2 in cands:
            if best is not None and s <= best[0]:
                break
            blocks = [4] * b4 + [3] * b3 + [2] * b2
            grid, placed = _place(k, blocks)
            tried += 1
            if grid is not None:
                best = (s, k, grid, placed)
                break
            if tried > 30:
                break
    if best is None:
        k = k0
        grid = [[False] * k for _ in range(k)]
        placed = []
        best = (0, k, grid, placed)
    s, k, grid, placed = best
    sq = []
    for r, c, j in placed:
        sq.append(((c + j / 2.0) / k, (r + j / 2.0) / k, 0.0, j / k))
    left = n - len(sq)
    for r in range(k):
        for c in range(k):
            if left <= 0:
                break
            if not grid[r][c]:
                sq.append(((c + 0.5) / k, (r + 0.5) / k, 0.0, 1.0 / k))
                left -= 1
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq[:n]
