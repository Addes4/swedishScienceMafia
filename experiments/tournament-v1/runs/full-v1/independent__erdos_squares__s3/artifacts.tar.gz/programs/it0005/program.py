import math
import numpy as np


def solve(n):
    if n <= 0:
        return []
    s0 = math.isqrt(n)
    Cmax = (s0 + 3) ** 2
    NEG = -1e18
    h = np.zeros((Cmax + 1, n + 1))
    Q = np.full((Cmax + 1, n + 1), NEG)
    Q[:, 0] = 0.0
    arg = np.zeros((Cmax + 1, n + 1), dtype=np.int64)
    single = np.zeros((Cmax + 1, n + 1), dtype=bool)
    f = np.zeros(n + 1)
    choice = [None] * (n + 1)

    for t in range(1, n + 1):
        if t >= 2:
            H = h[1:Cmax, t - 1:0:-1] + f[1:t]
            M = H.max(axis=1)
            A = H.argmax(axis=1) + 1
            cm = np.maximum.accumulate(M)
            Q[2:Cmax + 1, t] = cm
            prev = np.concatenate(([NEG], cm[:-1]))
            arg[2:Cmax + 1, t] = np.where(cm > prev, A, 0)
        Q[1, t] = NEG
        best = f[t - 1]
        bdesc = ('pad',)
        if t == 1:
            best = 1.0
            bdesc = ('single',)
        s = math.isqrt(t)
        mmax = min(s + 3, math.isqrt(Cmax))
        for m in range(2, mmax + 1):
            c = m * m
            if Q[c, t] > -1e17:
                v = Q[c, t] / m
                if v > best + 1e-12:
                    best = v
                    bdesc = ('grid', m)
        for m in range(max(3, s - 2), mmax + 1):
            for j in range(2, min(m - 1, 8) + 1):
                c = m * m - j * j
                if c >= 1:
                    vals = (h[c, 0:t] + j * f[t:0:-1]) / m
                    a = int(vals.argmax())
                    v = vals[a]
                    if v > best + 1e-12:
                        best = v
                        bdesc = ('block', m, j, a, t - a)
                q = m // j
                if j <= 6:
                    for r in range(2, min(8, q * q) + 1):
                        c = m * m - r * j * j
                        if c >= 1 and t - r >= 0:
                            v = (h[c, t - r] + r * j) / m
                            if v > best + 1e-12:
                                best = v
                                bdesc = ('blocks', m, j, r)
        f[t] = best
        choice[t] = bdesc
        h[:, t] = np.maximum(Q[:, t], best)
        single[:, t] = best >= Q[:, t]

    def rec(c, t, kind):
        counts = []
        while c > 0:
            if t == 0:
                counts += [0] * c
                break
            if kind == 'h' and single[c, t]:
                counts.append(t)
                counts += [0] * (c - 1)
                break
            a = int(arg[c, t])
            if a == 0:
                counts.append(0)
                c -= 1
                kind = 'Q'
            else:
                counts.append(a)
                c -= 1
                t -= a
                kind = 'h'
        return counts

    out = []

    def build(cnt, x0, y0, s):
        if cnt <= 0:
            return
        if cnt == 1:
            out.append((x0 + s / 2, y0 + s / 2, 0.0, s))
            return
        d = choice[cnt]
        if d[0] == 'pad':
            build(cnt - 1, x0, y0, s)
        elif d[0] == 'single':
            out.append((x0 + s / 2, y0 + s / 2, 0.0, s))
        elif d[0] == 'grid':
            m = d[1]
            counts = rec(m * m, cnt, 'Q')
            for i, ci in enumerate(counts):
                build(ci, x0 + (i % m) * s / m, y0 + (i // m) * s / m, s / m)
        elif d[0] == 'block':
            _, m, j, a, b = d
            cells = [(x, y) for y in range(m) for x in range(m) if not (x < j and y < j)]
            counts = rec(len(cells), a, 'Q' if a == cnt else 'h')
            for (x, y), ci in zip(cells, counts):
                build(ci, x0 + x * s / m, y0 + y * s / m, s / m)
            build(b, x0, y0, j * s / m)
        elif d[0] == 'blocks':
            _, m, j, r = d
            q = m // j
            covered = set()
            for k in range(r):
                bx, by = (k % q) * j, (k // q) * j
                for dx in range(j):
                    for dy in range(j):
                        covered.add((bx + dx, by + dy))
                build(1, x0 + bx * s / m, y0 + by * s / m, j * s / m)
            cells = [(x, y) for y in range(m) for x in range(m) if (x, y) not in covered]
            counts = rec(len(cells), cnt - r, 'h')
            for (x, y), ci in zip(cells, counts):
                build(ci, x0 + x * s / m, y0 + y * s / m, s / m)

    build(n, 0.0, 0.0, 1.0)
    shrink = 1.0 - 1e-10
    res = []
    for (cx, cy, ang, sd) in out[:n]:
        res.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0, sd * shrink))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
