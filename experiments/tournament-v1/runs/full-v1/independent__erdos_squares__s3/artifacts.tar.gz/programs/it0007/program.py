import math


def _place(m, items):
    occ = [[False] * m for _ in range(m)]
    res = []
    for j in sorted(items, reverse=True):
        found = False
        for y in range(m - j + 1):
            for x in range(m - j + 1):
                ok = True
                for yy in range(y, y + j):
                    row = occ[yy]
                    for xx in range(x, x + j):
                        if row[xx]:
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    for yy in range(y, y + j):
                        for xx in range(x, x + j):
                            occ[yy][xx] = True
                    res.append((x, y, j))
                    found = True
                    break
            if found:
                break
        if not found:
            return None
    return occ, res


def _best_for_m(n, m):
    r = max(0, m * m - n)
    if r == 0:
        return float(m * m) / m, []
    jmax = min(m, 6)
    INF = float('inf')
    dp = [INF] * (r + 1)
    par = [0] * (r + 1)
    dp[0] = 0
    for x in range(1, r + 1):
        for j in range(1, jmax + 1):
            red = j * j - 1 if j > 1 else 1
            loss = j * (j - 1) if j > 1 else 1
            if red <= x and dp[x - red] + loss < dp[x]:
                dp[x] = dp[x - red] + loss
                par[x] = j
    if dp[r] == INF:
        return None
    items = []
    x = r
    while x > 0:
        j = par[x]
        items.append(j)
        x -= (j * j - 1) if j > 1 else 1
    return (m * m - dp[r]) / m, items


def solve(n):
    k = math.isqrt(n)
    if k * k < n:
        k_hi = k + 1
    else:
        k_hi = k
    cands = []
    for m in range(max(1, k), k_hi + 7):
        b = _best_for_m(n, m)
        if b is None:
            continue
        cands.append((b[0], m, b[1]))
    cands.sort(key=lambda t: -t[0])
    chosen = None
    for val, m, items in cands:
        p = _place(m, items)
        if p is not None:
            chosen = (m, items, p)
            break
    squares = []
    if chosen is None:
        m = k_hi
        squares = []
        kk = max(1, k)
        s = 1.0 / kk
        for i in range(kk):
            for j in range(kk):
                squares.append(((i + .5) * s, (j + .5) * s, 0.0, s * (1 - 1e-9)))
    else:
        m, items, (occ, res) = chosen
        s = 1.0 / m
        shr = 1 - 1e-9
        for (x, y, j) in res:
            if j > 1:
                squares.append(((x + j / 2.0) * s, (y + j / 2.0) * s, 0.0, j * s * shr))
        for y in range(m):
            for x in range(m):
                if not occ[y][x]:
                    squares.append(((x + .5) * s, (y + .5) * s, 0.0, s * shr))
    squares.sort(key=lambda t: -t[3])
    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    out = []
    for cx, cy, a, sd in squares:
        out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a, min(1.0, max(0.0, sd))))
    return out
