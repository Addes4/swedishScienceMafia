import math
import numpy as np


def _pack(sizes, K):
    occ = np.zeros((K, K), dtype=bool)
    res = []
    for s in sorted(sizes, reverse=True):
        placed = False
        for y in range(K - s + 1):
            for x in range(K - s + 1):
                if not occ[y:y + s, x:x + s].any():
                    occ[y:y + s, x:x + s] = True
                    res.append((x, y, s))
                    placed = True
                    break
            if placed:
                break
        if not placed:
            return None
    return res


def solve(n):
    k0 = math.isqrt(n)
    if k0 * k0 < n:
        k0 += 1
    best_val = -1.0
    best_sol = None
    # baseline
    kb = math.isqrt(n)
    best_val = float(kb)
    side = 1.0 / kb
    best_sol = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(kb) for j in range(kb)]
    best_sol = best_sol[:n]

    Kmax = min(k0 + 4, 40)
    for K in range(max(1, k0 - 1), Kmax + 1):
        A = K * K
        S = min(4, K)
        NEG = -1e9
        dp = np.zeros((n + 1, A + 1))
        ch = np.zeros((n + 1, A + 1), dtype=np.int8)
        for c in range(1, n + 1):
            prev = dp[c - 1]
            cur = prev.copy()
            chc = np.zeros(A + 1, dtype=np.int8)
            for j in range(1, S + 1):
                w = j * j
                if w > A:
                    break
                cand = prev[:A + 1 - w] + j
                seg = cur[w:]
                m = cand > seg + 1e-12
                seg[m] = cand[m]
                chc[w:][m] = j
            dp[c] = cur
            ch[c] = chc
        val = dp[n][A] / K
        if val <= best_val + 1e-12:
            continue
        sizes = []
        c, a = n, A
        while c > 0:
            j = int(ch[c][a])
            if j == 0:
                c -= 1
            else:
                sizes.append(j)
                a -= j * j
                c -= 1
        pk = _pack(sizes, K)
        if pk is None:
            continue
        sol = [((x + s / 2.0) / K, (y + s / 2.0) / K, 0.0, s / K) for x, y, s in pk]
        sol += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sol))
        best_val = val
        best_sol = sol
    return best_sol[:n]
