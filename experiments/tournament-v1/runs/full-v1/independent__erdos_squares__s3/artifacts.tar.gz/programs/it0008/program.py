import math


def _plan(n):
    best = None
    k = max(1, math.isqrt(n))
    for m in range(k, 2 * k + 3):
        cap = (m // 2) ** 2
        excess = m * m - n
        if excess <= 0:
            val = m * m / m if m * m <= n else 0
            # m*m <= n: plain grid
            cand = (m * m / m, m, 0, 0)
            if best is None or cand[0] > best[0] + 1e-12:
                best = cand
            continue
        for t in range(0, cap + 1):
            d = max(0, excess - 3 * t)
            cells = m * m - 4 * t
            if d > cells:
                continue
            val = (m * m - 2 * t - d) / m
            if best is None or val > best[0] + 1e-12:
                best = (val, m, t, d)
    return best


def solve(n):
    if n <= 0:
        return []
    val, m, t, d = _plan(n)
    s = 1.0 / m
    shrink = 1 - 1e-9
    res = []
    covered = set()
    h = m // 2
    cnt = 0
    for a in range(h):
        for b in range(h):
            if cnt >= t:
                break
            cnt += 1
            covered.update([(2 * a, 2 * b), (2 * a + 1, 2 * b),
                            (2 * a, 2 * b + 1), (2 * a + 1, 2 * b + 1)])
            res.append(((2 * a + 1) * s, (2 * b + 1) * s, 0.0, 2 * s * shrink))
    rest = [(i, j) for i in range(m) for j in range(m) if (i, j) not in covered]
    keep = len(rest) - d
    for idx, (i, j) in enumerate(rest):
        if idx >= keep:
            break
        res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s * shrink))
    # sort by size descending, trim/pad
    res.sort(key=lambda r: -r[3])
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
