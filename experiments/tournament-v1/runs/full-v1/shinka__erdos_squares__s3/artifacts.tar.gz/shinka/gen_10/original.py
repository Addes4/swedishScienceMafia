# EVOLVE-BLOCK-START
"""Baseline: the largest k x k grid that fits, plus size-zero squares for the rest."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    NEG = -1e18
    g = [0.0] * (n + 1)
    spec = [None] * (n + 1)
    for t in range(1, n + 1):
        best = g[t - 1]
        bspec = spec[t - 1]
        if t == 1:
            best, bspec = 1.0, (1, 0, [1])
        # closed-form big grids with an optional merged block
        for m in range(2, math.isqrt(t) + 4):
            for b in range(0, m):
                C = m * m - b * b
                r = t - (1 if b > 0 else 0)
                if r < 0:
                    continue
                used = min(r, C)
                val = (used + b) / m
                if val > best + 1e-12:
                    best = val
                    bspec = (m, b, [1] * used + [0] * (C - used))
        # recursive small grids
        for m in range(2, 5):
            for b in range(0, m):
                C = m * m - b * b
                r = t - (1 if b > 0 else 0)
                if r < 0:
                    continue
                dp = [[NEG] * (r + 1) for _ in range(C + 1)]
                ch = [[0] * (r + 1) for _ in range(C + 1)]
                dp[0][0] = 0.0
                cap = min(r, t - 1)
                for j in range(1, C + 1):
                    prev = dp[j - 1]
                    cur = dp[j]
                    cc = ch[j]
                    for s in range(r + 1):
                        bv = NEG
                        bc = 0
                        for c in range(min(s, cap) + 1):
                            pv = prev[s - c]
                            if pv <= NEG / 2:
                                continue
                            v = pv + g[c] / m
                            if v > bv:
                                bv = v
                                bc = c
                        cur[s] = bv
                        cc[s] = bc
                if dp[C][r] <= NEG / 2:
                    continue
                val = dp[C][r] + (b / m if b > 0 else 0.0)
                if val > best + 1e-12:
                    counts = []
                    s = r
                    for j in range(C, 0, -1):
                        c = ch[j][s]
                        counts.append(c)
                        s -= c
                    best = val
                    bspec = (m, b, counts[::-1])
        g[t] = best
        spec[t] = bspec

    def build(t):
        # returns list of (x, y, side) in the unit square
        if t <= 0 or spec[t] is None:
            return []
        m, b, counts = spec[t]
        if m == 1:
            return [(0.0, 0.0, 1.0)]
        res = []
        step = 1.0 / m
        if b > 0:
            res.append((0.0, 0.0, b * step))
        idx = 0
        for i in range(m):
            for j in range(m):
                if i < b and j < b:
                    continue
                c = counts[idx]
                idx += 1
                if c > 0:
                    for (x, y, s) in build(c):
                        res.append((i * step + x * step, j * step + y * step, s * step))
        return res

    sq = build(n)
    sq.sort(key=lambda q: -q[2])
    sq = sq[:n]
    squares = [(min(1.0, x + s / 2), min(1.0, y + s / 2), 0.0, s) for (x, y, s) in sq]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
# EVOLVE-BLOCK-END