# EVOLVE-BLOCK-START
"""Guillotine-cut DP over lattice rectangles, max-plus convolution over square counts."""
import math
import time
import numpy as np


def _cuts_count(L):
    c = 0
    for w in range(1, L + 1):
        for h in range(1, w + 1):
            c += w // 2 + h // 2
    return c


def _run(L, n, Jk, Kc, P):
    F = {}
    CT = {}
    CP = {}
    CJ = {}
    idx = np.arange(n + 1)
    for w in range(1, L + 1):
        for h in range(1, w + 1):
            s = float(min(w, h))
            best = np.full(n + 1, s)
            best[0] = 0.0
            ct = np.full(n + 1, -1, dtype=np.int32)
            cp = np.zeros(n + 1, dtype=np.int32)
            cj = np.zeros(n + 1, dtype=np.int32)
            cap = min(n, w * h)
            c1 = cap + 1
            if n >= 2:
                for typ in (0, 1):
                    lim = (w // 2) if typ == 0 else (h // 2)
                    for pos in range(1, lim + 1):
                        if typ == 0:
                            A = F[(pos, h)]
                            B = F[(w - pos, h)]
                            ja = min(cap, pos * h)
                            jb = min(cap, (w - pos) * h)
                        else:
                            A = F[(w, pos)]
                            B = F[(w, h - pos)]
                            ja = min(cap, pos * w)
                            jb = min(cap, (h - pos) * w)
                        V = A[None, :ja + 1] + B[np.minimum(Kc[:c1, :ja + 1], jb)] + P[:c1, :ja + 1]
                        arg = V.argmax(axis=1)
                        val = V[idx[:c1], arg]
                        bs = best[:c1]
                        m = val > bs + 1e-12
                        if m.any():
                            best[:c1] = np.where(m, val, bs)
                            ct[:c1] = np.where(m, typ, ct[:c1])
                            cp[:c1] = np.where(m, pos, cp[:c1])
                            cj[:c1] = np.where(m, arg, cj[:c1])
                if cap < n:
                    best[c1:] = best[cap]
                    ct[c1:] = ct[cap]
                    cp[c1:] = cp[cap]
                    cj[c1:] = cj[cap]
            F[(w, h)] = best
            CT[(w, h)] = ct
            CP[(w, h)] = cp
            CJ[(w, h)] = cj
            if w != h:
                F[(h, w)] = best
                CT[(h, w)] = np.where(ct >= 0, 1 - ct, ct)
                CP[(h, w)] = cp
                CJ[(h, w)] = cj
    return F, CT, CP, CJ


def _build(L, n, F, CT, CP, CJ):
    out = []
    stack = [(L, L, n, 0, 0)]
    while stack:
        w, h, k, x, y = stack.pop()
        if k <= 0:
            continue
        t = int(CT[(w, h)][k])
        if t < 0:
            out.append((x, y, min(w, h)))
            continue
        p = int(CP[(w, h)][k])
        j = int(CJ[(w, h)][k])
        if t == 0:
            stack.append((p, h, j, x, y))
            stack.append((w - p, h, k - j, x + p, y))
        else:
            stack.append((w, p, j, x, y))
            stack.append((w, h - p, k - j, x, y + p))
    return out


def _grid(n):
    g = max(1, math.isqrt(n))
    out = []
    s = 1.0 / g
    for i in range(g):
        for j in range(g):
            if len(out) < n:
                out.append((i * s + s / 2, j * s + s / 2, 0.0, s))
    return out, float(g)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    t0 = time.time()
    budget = 40.0
    out, best_score = _grid(n)
    if n <= 300:
        g = math.isqrt(n)
        cands = set(list(range(2, 13)) + [15, 16, 18, 20, 24, 30, 36, 48, 60])
        cands.update([g, g + 1, g + 2])
        cands = sorted(c for c in cands if c >= 1)
        idx = np.arange(n + 1)
        Kraw = idx[:, None] - idx[None, :]
        P = np.where(Kraw >= 0, 0.0, -1e18)
        Kc = np.clip(Kraw, 0, None)
        rate = None
        for L in cands:
            cc = _cuts_count(L)
            if rate is not None:
                if time.time() - t0 + rate * cc > budget:
                    continue
            ts = time.time()
            F, CT, CP, CJ = _run(L, n, None, Kc, P)
            el = time.time() - ts
            rate = max(el / max(cc, 1), 1e-9) if rate is None else max(rate, el / max(cc, 1))
            sc = float(F[(L, L)][n]) / L
            if sc > best_score + 1e-12:
                sq = _build(L, n, F, CT, CP, CJ)
                res = [((x + s / 2) / L, (y + s / 2) / L, 0.0, s / L) for (x, y, s) in sq]
                best_score = sc
                out = res
    out = [(min(1.0, max(0.0, a)), min(1.0, max(0.0, b)), 0.0, min(1.0, max(0.0, d)))
           for (a, b, _, d) in out]
    out = out[:n]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out
# EVOLVE-BLOCK-END