# EVOLVE-BLOCK-START
"""DP over recursive grids, plus a lattice skyline branch-and-bound search for small n."""
import math
import time


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    t_start = time.time()
    NEG = -1e18
    g = [0.0] * (n + 1)
    spec = [None] * (n + 1)
    if n <= 40:
        mmax = 6
    elif n <= 70:
        mmax = 5
    elif n <= 110:
        mmax = 4
    elif n <= 160:
        mmax = 3
    else:
        mmax = 2  # no recursive DP for very large n
    for t in range(1, n + 1):
        best = g[t - 1]
        bspec = spec[t - 1]
        if t == 1:
            best, bspec = 1.0, (1, 0, [1])
        for m in range(2, math.isqrt(t) + 4):
            for b in range(0, m):
                C = m * m - b * b
                r = t - (1 if b > 0 else 0)
                if r < 0:
                    continue
                used = min(r, C)
                val = (used + b) / m
                if val > best + 1e-12:
                    best = val
                    bspec = (m, b, [1] * used + [0] * (C - used))
        for m in range(2, mmax):
            for b in range(0, m):
                C = m * m - b * b
                r = t - (1 if b > 0 else 0)
                if r < 0:
                    continue
                dp = [[NEG] * (r + 1) for _ in range(C + 1)]
                ch = [[0] * (r + 1) for _ in range(C + 1)]
                dp[0][0] = 0.0
                cap = min(r, t - 1)
                for j in range(1, C + 1):
                    prev = dp[j - 1]
                    cur = dp[j]
                    cc = ch[j]
                    for s in range(r + 1):
                        bv = NEG
                        bc = 0
                        for c in range(min(s, cap) + 1):
                            pv = prev[s - c]
                            if pv <= NEG / 2:
                                continue
                            v = pv + g[c] / m
                            if v > bv:
                                bv = v
                                bc = c
                        cur[s] = bv
                        cc[s] = bc
                if dp[C][r] <= NEG / 2:
                    continue
                val = dp[C][r] + (b / m if b > 0 else 0.0)
                if val > best + 1e-12:
                    counts = []
                    s = r
                    for j in range(C, 0, -1):
                        c = ch[j][s]
                        counts.append(c)
                        s -= c
                    best = val
                    bspec = (m, b, counts[::-1])
        g[t] = best
        spec[t] = bspec

    def build(t):
        if t <= 0 or spec[t] is None:
            return []
        m, b, counts = spec[t]
        if m == 1:
            return [(0.0, 0.0, 1.0)]
        res = []
        step = 1.0 / m
        if b > 0:
            res.append((0.0, 0.0, b * step))
        idx = 0
        for i in range(m):
            for j in range(m):
                if i < b and j < b:
                    continue
                c = counts[idx]
                idx += 1
                if c > 0:
                    for (x, y, s) in build(c):
                        res.append((i * step + x * step, j * step + y * step, s * step))
        return res

    sq = build(n)
    sq.sort(key=lambda q: -q[2])
    sq = sq[:n]
    dp_val = sum(q[2] for q in sq)

    # ---- lattice skyline branch and bound for small n ----
    if 3 <= n <= 30:
        total_budget = 40.0
        end_all = t_start + total_budget
        Ns = list(range(3, 13))
        for idx_N, N in enumerate(Ns):
            now = time.time()
            if now >= end_all:
                break
            slice_t = (end_all - now) / (len(Ns) - idx_N)
            deadline = now + slice_t
            bestu = [dp_val * N + 1e-7]
            found = [None]
            h = [0] * N
            placed = []
            counter = [0]
            timeout = [False]
            sqrt = math.sqrt

            def rec(cnt, sumu, area_rem):
                if sumu > bestu[0]:
                    bestu[0] = sumu
                    found[0] = list(placed)
                if cnt == n or area_rem <= 0 or timeout[0]:
                    return
                if sumu + sqrt((n - cnt) * area_rem) <= bestu[0] + 1e-9:
                    return
                counter[0] += 1
                if (counter[0] & 1023) == 0 and time.time() > deadline:
                    timeout[0] = True
                    return
                m = min(h)
                if m >= N:
                    return
                x = h.index(m)
                w = 1
                while x + w < N and h[x + w] == m:
                    w += 1
                smax = min(w, N - m)
                for s in range(smax, 0, -1):
                    for k in range(x, x + s):
                        h[k] = m + s
                    placed.append((x, m, s))
                    rec(cnt + 1, sumu + s, area_rem - s * s)
                    placed.pop()
                    for k in range(x, x + s):
                        h[k] = m
                    if timeout[0]:
                        return

            try:
                rec(0, 0, N * N)
            except RecursionError:
                pass
            if found[0] is not None:
                cand = [(x / N, y / N, s / N) for (x, y, s) in found[0]]
                val = sum(c[2] for c in cand)
                if val > dp_val + 1e-9:
                    cand.sort(key=lambda q: -q[2])
                    sq = cand[:n]
                    dp_val = val

    squares = [(min(1.0, x + s / 2), min(1.0, y + s / 2), 0.0, s) for (x, y, s) in sq]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
# EVOLVE-BLOCK-END