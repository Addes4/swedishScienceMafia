# EVOLVE-BLOCK-START
"""Recursive L-shaped grid decomposition with a knapsack DP over square budgets."""
import math
import numpy as np


def _plan(n):
    NEG = -1e18
    M = math.isqrt(n) + 3
    CM = M * M
    F = np.zeros(n + 1)
    desc = [None] * (n + 1)
    H = np.full((CM + 1, n + 1), NEG)
    chF = np.zeros((CM + 1, n + 1), dtype=np.int32)
    chR = np.zeros((CM + 1, n + 1), dtype=np.int32)
    H[:, 0] = 0.0

    def sweep(r, upto, ch):
        # j ranges over 0..upto-1 ; j>=1 vectorised, j=0 is prefix-max chain
        if upto - 1 >= 1:
            sub = H[:CM, r - upto + 1:r][:, ::-1]
            vals = F[1:upto][None, :] + sub
            Gj = vals.argmax(axis=1) + 1
            G = vals.max(axis=1)
        else:
            G = np.full(CM, NEG)
            Gj = np.zeros(CM, dtype=np.int64)
        cm = np.maximum.accumulate(G)
        prev = np.concatenate(([NEG], cm[:-1]))
        ch[1:, r] = np.where(prev >= G, 0, Gj)
        H[1:, r] = cm

    for r in range(1, n + 1):
        F[r] = NEG
        sweep(r, r, chR)  # restricted: no cell holds all r squares
        Hr = H[:, r].copy()
        if r == 1:
            F[1] = 1.0
            desc[1] = ('one',)
        else:
            best = float(F[r - 1])
            d = ('same',)
            Fs = F[1:r]
            for m in range(2, M + 1):
                for a in range(0, m):
                    c = m * m - a * a
                    if a == 0:
                        v = float(Hr[c]) / m
                        if v > best + 1e-12:
                            best = v
                            d = ('grid', m, 0, 0)
                    else:
                        vals = (a / m) * Fs + H[c, 1:r][::-1] / m
                        k = int(vals.argmax())
                        v = float(vals[k])
                        if v > best + 1e-12:
                            best = v
                            d = ('grid', m, a, k + 1)
            F[r] = best
            desc[r] = d
        sweep(r, r + 1, chF)  # full pass with F[r] known
    return F, desc, chF, chR


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    F, desc, chF, chR = _plan(n)
    out = []

    def build(r, x0, y0, size):
        while r > 0 and desc[r][0] == 'same':
            r -= 1
        if r == 0:
            return
        d = desc[r]
        if d[0] == 'one':
            out.append((x0 + size / 2, y0 + size / 2, 0.0, size))
        else:
            _, m, a, j1 = d
            s = size / m
            cells = [(i, j) for i in range(m) for j in range(m) if not (i < a and j < a)]
            if a > 0:
                build(j1, x0, y0, a * s)
            rr = r - j1
            c = len(cells)
            for (i, j) in cells:
                ch = chR if rr == r else chF
                jj = int(ch[c][rr])
                build(jj, x0 + i * s, y0 + j * s, s)
                rr -= jj
                c -= 1

    build(n, 0.0, 0.0, 1.0)
    out = [(min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), 0.0, min(1.0, max(0.0, sd)))
           for (x, y, _, sd) in out]
    out = out[:n]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out
# EVOLVE-BLOCK-END