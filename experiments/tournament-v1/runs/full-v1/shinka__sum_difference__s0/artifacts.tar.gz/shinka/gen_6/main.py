# EVOLVE-BLOCK-START
"""Hill climbing over simplex lattice sets with per-coordinate caps and shell bounds."""
import math
import random
import time

import numpy as np


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _gen(n, n1, caps):
    """Sorted centred integer encoding of {x: 0<=x_i<=caps_i, n1<=sum<=n}, or None."""
    d = len(caps)
    if d < 1 or n < 1 or n1 < 0 or n1 > n or min(caps) < 1:
        return None
    B = 2 * max(caps) + 1
    if B ** d > 2 * 10 ** 15:
        return None
    suffix = [0] * (d + 1)
    for k in range(d - 1, -1, -1):
        suffix[k] = suffix[k + 1] + caps[k]
    if suffix[0] < n1:
        return None
    codes = np.zeros(1, dtype=np.int64)
    used = np.zeros(1, dtype=np.int64)
    mult = 1
    for k in range(d):
        rem = suffix[k + 1]
        cl, ul = [], []
        for x in range(0, caps[k] + 1):
            m = (used + x <= n) & (used + x + rem >= n1)
            if m.any():
                cl.append(codes[m] + x * mult)
                ul.append(used[m] + x)
        if not cl:
            return None
        codes = np.concatenate(cl)
        used = np.concatenate(ul)
        if len(codes) > 200000:
            return None
        mult *= B
    N = len(codes)
    if N < 20 or N > 4000:
        return None
    codes = np.sort(codes)
    shift = (int(codes[-1]) + int(codes[0])) // 2
    codes = codes - shift
    if max(abs(int(codes[0])), abs(int(codes[-1]))) > 10 ** 15:
        return None
    return codes


def _fast_score(v):
    N = len(v)
    chunk = max(1, 1500000 // N)
    sums_parts = []
    diff_parts = []
    for i0 in range(0, N, chunk):
        i1 = min(N, i0 + chunk)
        s = np.add.outer(v[i0:i1], v[i0:]).ravel()
        sums_parts.append(np.unique(s))
        df = np.subtract.outer(v[i0:i1], v[:]).ravel()
        df = df[df > 0]
        diff_parts.append(np.unique(df))
    ns = len(np.unique(np.concatenate(sums_parts)))
    nd = 2 * len(np.unique(np.concatenate(diff_parts))) + 1
    return math.log(nd) / math.log(ns) + (1 - 1 / N) / 100


def _simplex_formula(d, n):
    c = math.comb
    ns = c(2 * n + d, d)
    nd = 0
    for s in range(0, min(d, n) + 1):
        for t in range(0, min(d - s, n) + 1):
            nd += c(d, s) * c(d - s, t) * c(n, s) * c(n, t)
    return math.log(nd) / math.log(ns)


def _canon(n, n1, caps):
    caps = tuple(sorted((min(max(1, c), n) for c in caps), reverse=True))
    n1 = max(0, min(n1, n))
    return (n, n1, caps)


def solve():
    t0 = time.time()
    deadline = t0 + 88
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    best_params = None
    cache = {}

    def evaluate(p):
        nonlocal best, best_score, best_params
        if p in cache:
            return cache[p]
        if time.time() > deadline:
            return -1.0
        v = _gen(*p)
        if v is None:
            cache[p] = -1.0
            return -1.0
        s = _fast_score(v)
        cache[p] = s
        if s > best_score:
            best_score = s
            best = [int(x) for x in v]
            best_params = p
        return s

    starts = []
    for d in range(2, 60):
        for n in range(1, 40):
            c = math.comb(n + d, d)
            if c > 4000 or c < 100:
                continue
            starts.append((_simplex_formula(d, n), d, n))
    starts.sort(reverse=True)
    starts = [_canon(n, 0, (n,) * d) for _, d, n in starts[:10]]

    def neighbors(p):
        n, n1, caps = p
        d = len(caps)
        res = []
        res.append(_canon(n + 1, n1, caps))
        res.append(_canon(n - 1, n1, caps))
        res.append(_canon(n + 1, n1, [c + 1 for c in caps]))
        res.append(_canon(n - 1, n1, [c - 1 for c in caps]))
        res.append(_canon(n, n1 + 1, caps))
        res.append(_canon(n, n1 - 1, caps))
        res.append(_canon(n, n1, [c + 1 for c in caps]))
        res.append(_canon(n, n1, [c - 1 for c in caps]))
        res.append(_canon(n, n1, list(caps) + [caps[-1]]))
        res.append(_canon(n, n1, list(caps) + [max(1, caps[-1] - 1)]))
        res.append(_canon(n, n1, list(caps) + [n]))
        if d > 1:
            res.append(_canon(n, n1, caps[:-1]))
            res.append(_canon(n, n1, caps[1:]))
        seen = set()
        for i in range(d):
            if caps[i] in seen:
                continue
            seen.add(caps[i])
            for dc in (-1, 1):
                cl = list(caps)
                cl[i] += dc
                res.append(_canon(n, n1, cl))
        # dimension up, n down / dimension down, n up
        res.append(_canon(n - 1, n1, list(caps) + [n - 1]))
        if d > 1:
            res.append(_canon(n + 1, n1, caps[:-1]))
        out = []
        for q in res:
            if q != p and len(q[2]) >= 1 and q[0] >= 1:
                out.append(q)
        return list(dict.fromkeys(out))

    for p in starts[:3]:
        evaluate(p)

    restart_i = 0
    cur = best_params if best_params else starts[0]
    cur_s = evaluate(cur)
    while time.time() < deadline:
        improved = False
        nb = neighbors(cur)
        random.shuffle(nb)
        for q in nb:
            if time.time() > deadline:
                break
            s = evaluate(q)
            if s > cur_s:
                cur, cur_s = q, s
                improved = True
                break
        if not improved:
            restart_i += 1
            if restart_i < len(starts):
                cur = starts[restart_i]
            else:
                base = best_params if best_params else starts[0]
                n, n1, caps = base
                cl = [c + random.randint(-1, 1) for c in caps]
                if random.random() < 0.5:
                    cl.append(random.randint(1, n))
                cur = _canon(n + random.randint(-1, 1), n1 + random.randint(-1, 1), cl)
            cur_s = evaluate(cur)
    return sorted(set(best))
# EVOLVE-BLOCK-END