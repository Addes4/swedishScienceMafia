# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    import numpy as np

    def simplex(d, n):
        B = 2 * n + 1
        pts = [(0, 0)]  # (code, used)
        mult = 1
        for _ in range(d):
            new = []
            for code, used in pts:
                for x in range(n - used + 1):
                    new.append((code + x * mult, used + x))
            pts = new
            mult *= B
            if len(pts) > 4000:
                return None
        return [c for c, _ in pts]

    def fast_score(a):
        arr = np.array(a, dtype=np.int64)
        nd = len(np.unique((arr[:, None] - arr[None, :]).ravel()))
        ns = len(np.unique((arr[:, None] + arr[None, :]).ravel()))
        return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100

    t0 = time.time()

    def analytic(d, n):
        size = math.comb(n + d, d)
        ns = math.comb(2 * n + d, d)
        nd = 0
        for i in range(0, min(d, n) + 1):
            for j in range(0, min(d - i, n) + 1):
                nd += math.comb(d, i) * math.comb(d - i, j) * math.comb(n, i) * math.comb(n, j)
        return math.log(nd) / math.log(ns) + (1 - 1 / size) / 100

    cands = []
    for d in range(2, 60):
        for n in range(1, 60):
            sz = math.comb(n + d, d)
            if sz > 4000 or sz < 30:
                continue
            if (2 * n + 1) ** d > 5e14:
                continue
            cands.append((analytic(d, n), sz, d, n))
    cands.sort(reverse=True)
    best_simplex = None
    for sc, sz, d, n in cands:
        a = simplex(d, n)
        if a is not None:
            best_simplex = a
            best_sc = fast_score(a)
            break
    if best_simplex is None:
        return [7, 15, 18, 22, -3, -2]
    best = best_simplex

    # local search starting from a medium-sized simplex
    mid = [c for c in cands if 100 <= c[1] <= 600 and (6 * c[3] + 30) ** c[2] < 5e14]
    if mid:
        _, sz, d, n = mid[0]
        try:
            res = local_search(d, n, time.time() + 10)
            if res is not None:
                s2 = fast_score(res)
                if s2 > best_sc:
                    best, best_sc = res, s2
        except Exception:
            pass
    try:
        pr = prune_set(best, fast_score, t0 + 88)
        if pr is not None and fast_score(pr) > best_sc:
            best = pr
    except Exception:
        pass
    return sorted(set(int(x) for x in best))


def prune_set(vals, score_fn, deadline):
    import numpy as np
    v = np.array(sorted(set(int(x) for x in vals)), dtype=np.int64)
    cur = score_fn(v)
    frac = 0.03
    while len(v) > 30:
        t1 = time.time()
        N = len(v)
        s = (v[:, None] + v[None, :]).ravel()
        us, cs = np.unique(s, return_counts=True)
        del s
        dm = (v[:, None] - v[None, :]).ravel()
        ud, cd = np.unique(dm, return_counts=True)
        del dm
        ns = len(us)
        nd = len(ud)
        lostS = np.zeros(N)
        lostD = np.zeros(N)
        ch = max(1, 400000 // N)
        for i0 in range(0, N, ch):
            i1 = min(N, i0 + ch)
            blk = v[i0:i1, None] + v[None, :]
            cnt = cs[np.searchsorted(us, blk)]
            lostS[i0:i1] = (cnt == 2).sum(1)
            blk = v[i0:i1, None] - v[None, :]
            cnt = cd[np.searchsorted(ud, blk)]
            lostD[i0:i1] = 2 * (cnt == 1).sum(1)
        dg = cs[np.searchsorted(us, 2 * v)]
        lostS += (dg == 1)
        f = math.log(nd) / math.log(ns)
        newf = np.log(np.maximum(nd - lostD, 2)) / np.log(np.maximum(ns - lostS, 2))
        gain = newf - f
        order = np.argsort(-gain)
        accepted = False
        while True:
            k = max(1, int(frac * N))
            sel = order[:k]
            sel = sel[gain[sel] > 0]
            if len(sel) == 0:
                break
            mask = np.ones(N, dtype=bool)
            mask[sel] = False
            nv = v[mask]
            if len(nv) < 30:
                break
            sc_new = score_fn(nv)
            if sc_new > cur:
                v, cur = nv, sc_new
                frac = min(0.1, frac * 1.3)
                accepted = True
                break
            if k == 1:
                break
            frac = frac / 2
            if time.time() > deadline:
                break
        if not accepted:
            break
        el = time.time() - t1
        if time.time() + 2.5 * el > deadline:
            break
    return [int(x) for x in v]


def local_search(d, n, deadline):
    B = 6 * n + 30
    units = [B ** i for i in range(d)]
    pts = [()]
    for _ in range(d):
        new = []
        for t in pts:
            u = sum(t)
            for x in range(n - u + 1):
                new.append(t + (x,))
        pts = new
    coords = {}
    for t in pts:
        coords[sum(x * u for x, u in zip(t, units))] = t
    A = list(coords.keys())
    inA = set(A)
    S = {}
    D = {}

    def add(c):
        for q in A:
            k = c + q
            S[k] = S.get(k, 0) + 1
            k = c - q
            D[k] = D.get(k, 0) + 1
            k = q - c
            D[k] = D.get(k, 0) + 1
        k = 2 * c
        S[k] = S.get(k, 0) + 1
        D[0] = D.get(0, 0) + 1
        A.append(c)
        inA.add(c)

    def remove(c):
        A.remove(c)
        inA.discard(c)
        for q in A:
            for dct, k in ((S, c + q), (D, c - q), (D, q - c)):
                v = dct[k] - 1
                if v:
                    dct[k] = v
                else:
                    del dct[k]
        k = 2 * c
        v = S[k] - 1
        if v:
            S[k] = v
        else:
            del S[k]
        D[0] -= 1

    # initialise
    items = A[:]
    A.clear()
    inA.clear()
    for c in items:
        add(c)

    def sc():
        return math.log(len(D)) / math.log(len(S))

    cur = sc()
    best = cur
    best_set = A[:]
    T0 = 0.003
    start = time.time()
    total = max(deadline - start, 1.0)
    maxc = n + 2
    it = 0
    while True:
        it += 1
        now = time.time()
        if now > deadline:
            break
        T = T0 * max(0.02, 1 - (now - start) / total)
        r = random.random()
        # generate new point
        p = random.choice(A)
        t = coords[p]
        i = random.randrange(d)
        dx = random.choice((-1, 1))
        nx = t[i] + dx
        if nx < 0 or nx > maxc:
            continue
        nt = t[:i] + (nx,) + t[i + 1:]
        nc = p + dx * units[i]
        if nc in inA:
            continue
        coords[nc] = nt
        if r < 0.5:
            # shift p -> nc
            remove(p)
            add(nc)
            new = sc()
            if new >= cur or random.random() < math.exp((new - cur) / T):
                cur = new
            else:
                remove(nc)
                add(p)
        elif r < 0.8:
            # add nc
            add(nc)
            new = sc()
            if new >= cur or random.random() < math.exp((new - cur) / T):
                cur = new
            else:
                remove(nc)
        else:
            # remove p
            if len(A) < 20:
                continue
            remove(p)
            new = sc()
            if new >= cur or random.random() < math.exp((new - cur) / T):
                cur = new
            else:
                add(p)
        if cur > best + 1e-12:
            best = cur
            best_set = A[:]
    return best_set
# EVOLVE-BLOCK-END