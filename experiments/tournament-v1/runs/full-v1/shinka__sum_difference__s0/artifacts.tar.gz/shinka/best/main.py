# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    from math import comb
    import itertools

    def counts(d, n):
        ns = comb(2 * n + d, d)
        nd = 0
        for j in range(0, d + 1):
            cj = comb(d, j) * comb(n, j)
            if cj == 0:
                continue
            for l in range(0, d - j + 1):
                nd += cj * comb(d - j, l) * comb(n, l)
        return nd, ns

    best = None
    best_sc = -1.0
    for d in range(1, 60):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * B ** (d - 1) * d > 4e14:
                break
            if size < 2:
                continue
            nd, ns = counts(d, n)
            sc = math.log(nd) / math.log(ns) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)

    d, n = best
    B = 2 * n + 1
    pts = []

    def gen(i, remaining, val):
        if i == d:
            pts.append(val)
            return
        w = B ** i
        for x in range(remaining + 1):
            gen(i + 1, remaining - x, val + x * w)

    gen(0, n, 0)
    return sorted(set(pts))
# EVOLVE-BLOCK-END