# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    import numpy as np

    def simplex(d, n):
        B = 2 * n + 1
        pts = [(0, 0)]  # (code, used)
        mult = 1
        for _ in range(d):
            new = []
            for code, used in pts:
                for x in range(n - used + 1):
                    new.append((code + x * mult, used + x))
            pts = new
            mult *= B
            if len(pts) > 4000:
                return None
        return [c for c, _ in pts]

    def fast_score(a):
        arr = np.array(a, dtype=np.int64)
        nd = len(np.unique((arr[:, None] - arr[None, :]).ravel()))
        ns = len(np.unique((arr[:, None] + arr[None, :]).ravel()))
        return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    deadline = time.time() + 90
    cands = []
    for d in range(2, 40):
        for n in range(1, 40):
            if math.comb(n + d, d) > 4000 or math.comb(n + d, d) < 30:
                continue
            if (2 * n + 1) ** d > 5e14:
                continue
            cands.append((d, n))
    cands.sort(key=lambda t: math.comb(t[0] + t[1], t[0]))
    for d, n in cands:
        if time.time() > deadline:
            break
        a = simplex(d, n)
        if a is None or len(a) > 4000:
            continue
        s = fast_score(a)
        if s > best_score:
            best, best_score = a, s
    return sorted(set(best))
# EVOLVE-BLOCK-END