# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    from math import comb
    import itertools

    def counts(d, n):
        ns = comb(2 * n + d, d)
        nd = 0
        for j in range(0, d + 1):
            cj = comb(d, j) * comb(n, j)
            if cj == 0:
                continue
            for l in range(0, d - j + 1):
                nd += cj * comb(d - j, l) * comb(n, l)
        return nd, ns

    best = None
    best_sc = -1.0
    for d in range(1, 60):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * B ** (d - 1) * d > 4e14:
                break
            if size < 2:
                continue
            nd, ns = counts(d, n)
            sc = math.log(nd) / math.log(ns) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)

    d, n = best
    B = 2 * n + 1
    pts = []

    def gen(i, remaining, val):
        if i == d:
            pts.append(val)
            return
        w = B ** i
        for x in range(remaining + 1):
            gen(i + 1, remaining - x, val + x * w)

    gen(0, n, 0)
    base_pts = sorted(set(pts))

    try:
        import numpy as np
    except Exception:
        return base_pts

    t_end = time.time() + 35

    def build(d, n, cap, lo):
        B = 2 * n + 1
        out = []

        def rec(i, s, val):
            if i == d:
                if s >= lo:
                    out.append(val)
                return
            w = B ** i
            for x in range(min(cap, n - s) + 1):
                rec(i + 1, s + x, val + x * w)

        rec(0, 0, 0)
        return out

    def sc(vals):
        v = np.array(vals, dtype=np.int64)
        k = len(v)
        if k < 2:
            return -1.0
        nd = len(np.unique((v[:, None] - v[None, :]).ravel()))
        ns = len(np.unique((v[:, None] + v[None, :]).ravel()))
        if ns < 2:
            return -1.0
        return math.log(nd) / math.log(ns) + (1 - 1 / k) / 100

    best_vals = base_pts
    best_s = sc(base_pts)

    cands = []
    for dd in range(2, 12):
        for nn in range(2, 40):
            if comb(nn + dd, dd) > 6000:
                break
            if (2 * nn + 1) ** dd > 1e14:
                break
            for cap in range(max(1, nn // 2), nn + 1):
                for lo in range(0, 4):
                    cands.append((dd, nn, cap, lo))
    random.shuffle(cands)
    for (dd, nn, cap, lo) in cands:
        if time.time() > t_end:
            break
        if comb(nn + dd, dd) > 6000:
            continue
        vals = build(dd, nn, cap, lo)
        k = len(vals)
        if k < 50 or k > 2500:
            continue
        s = sc(vals)
        if s > best_s:
            best_s = s
            best_vals = vals

    # Phase 2: weighted simplices {x>=0 : w.x <= n}
    def wsize(ws, n):
        f = [0] * (n + 1)
        f[0] = 1
        for w in ws:
            g = [0] * (n + 1)
            for s in range(n + 1):
                if f[s]:
                    for t in range(s, n + 1, w):
                        g[t] += f[s]
            f = g
        return sum(f)

    def build_w(ws, n):
        B = 2 * (n // min(ws)) + 1
        vals = np.zeros(1, dtype=np.int64)
        rem = np.array([n], dtype=np.int64)
        for i, w in enumerate(ws):
            mx = n // w
            nv = []
            nr = []
            for x in range(mx + 1):
                m = rem >= x * w
                if not m.any():
                    break
                nv.append(vals[m] + x * (B ** i))
                nr.append(rem[m] - x * w)
            vals = np.concatenate(nv)
            rem = np.concatenate(nr)
        return vals

    t_end2 = time.time() + 45
    seen = set()
    while time.time() < t_end2:
        try:
            d = random.randint(3, 9)
            probs = random.choice([(1, 0, 0), (3, 1, 0), (2, 1, 1), (1, 1, 0), (4, 2, 1)])
            ws = sorted(random.choices([1, 2, 3], weights=[p + 1e-9 for p in probs], k=d))
            n = random.randint(2, 40)
            key = (tuple(ws), n)
            if key in seen:
                continue
            seen.add(key)
            B = 2 * (n // ws[0]) + 1
            if B ** d > 4e14:
                continue
            k = wsize(ws, n)
            if k < 100 or k > 2600:
                continue
            vals = build_w(ws, n)
            s = sc(vals)
            if s > best_s:
                best_s = s
                best_vals = [int(x) for x in vals]
        except Exception:
            continue
    return sorted(set(int(x) for x in best_vals))
# EVOLVE-BLOCK-END