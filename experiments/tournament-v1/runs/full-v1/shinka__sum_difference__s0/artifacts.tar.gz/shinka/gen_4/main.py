# EVOLVE-BLOCK-START
"""Hill climbing over capped / shelled simplex lattice sets, encoded into integers."""
import math
import random
import time

import numpy as np


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _gen(d, n, n1, cap):
    """Return sorted centred integer encoding of the point set, or None."""
    B = 2 * n + 1
    if cap < 1 or cap > n or n1 < 0 or n1 > n or d < 1:
        return None
    codes = np.zeros(1, dtype=np.int64)
    used = np.zeros(1, dtype=np.int64)
    mult = 1
    for k in range(d):
        rem = (d - k - 1) * cap
        cl, ul = [], []
        for x in range(0, cap + 1):
            m = (used + x <= n) & (used + x + rem >= n1)
            if m.any():
                cl.append(codes[m] + x * mult)
                ul.append(used[m] + x)
        if not cl:
            return None
        codes = np.concatenate(cl)
        used = np.concatenate(ul)
        if len(codes) > 300000:
            return None
        mult *= B
        if mult > 4e18 // max(1, B):
            return None
    N = len(codes)
    if N < 10 or N > 4000:
        return None
    codes = np.sort(codes)
    shift = (int(codes[-1]) + int(codes[0])) // 2
    codes = codes - shift
    if max(abs(int(codes[0])), abs(int(codes[-1]))) > 10 ** 15:
        return None
    return codes


def _fast_score(v):
    N = len(v)
    chunk = max(1, 1500000 // N)
    sums_parts = []
    diff_parts = []
    for i0 in range(0, N, chunk):
        i1 = min(N, i0 + chunk)
        s = np.add.outer(v[i0:i1], v[i0:]).ravel()
        sums_parts.append(np.unique(s))
        df = np.subtract.outer(v[i0:i1], v[:]).ravel()
        df = df[df > 0]
        diff_parts.append(np.unique(df))
    ns = len(np.unique(np.concatenate(sums_parts)))
    nd = 2 * len(np.unique(np.concatenate(diff_parts))) + 1
    return math.log(nd) / math.log(ns) + (1 - 1 / N) / 100


def _simplex_formula(d, n):
    c = math.comb
    ns = c(2 * n + d, d)
    nd = 0
    for s in range(0, min(d, n) + 1):
        for t in range(0, min(d - s, n) + 1):
            nd += c(d, s) * c(d - s, t) * c(n, s) * c(n, t)
    return math.log(nd) / math.log(ns)


def solve():
    t0 = time.time()
    deadline = t0 + 95
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    best_params = None

    cache = {}
    sets = {}

    def evaluate(p):
        nonlocal best, best_score, best_params
        if p in cache:
            return cache[p]
        v = _gen(*p)
        if v is None:
            cache[p] = -1.0
            return -1.0
        s = _fast_score(v)
        cache[p] = s
        if s > best_score:
            best_score = s
            best = [int(x) for x in v]
            best_params = p
        return s

    # starting simplices ranked by formula
    starts = []
    for d in range(1, 80):
        for n in range(1, 60):
            if math.comb(n + d, d) > 4000 or math.comb(n + d, d) < 100:
                continue
            starts.append((_simplex_formula(d, n), d, n))
    starts.sort(reverse=True)
    starts = [(d, n, 0, n) for _, d, n in starts[:8]]

    for p in starts[:3]:
        if time.time() > deadline:
            break
        evaluate(p)

    def neighbors(p):
        d, n, n1, cap = p
        res = []
        for dd in (-1, 1):
            res.append((d + dd, n, n1, cap))
        for dn in (-1, 1):
            res.append((d, n + dn, n1, min(cap, n + dn)))
            res.append((d, n + dn, min(n1, n + dn), cap if cap <= n + dn else n + dn))
            res.append((d + dn, n - dn, n1, cap))
        for d1 in (-1, 1):
            res.append((d, n, n1 + d1, cap))
            res.append((d, n, n1, cap + d1))
            res.append((d, n + 1, n1 + d1 * 1, cap))
            res.append((d - 1, n + 1, n1, cap))
            res.append((d + 1, n, n1, cap - 1))
            res.append((d + 1, n, n1 + 1, cap))
        out = []
        for q in res:
            if q[0] >= 1 and q[1] >= 1 and 0 <= q[2] <= q[1] and 1 <= q[3] <= q[1]:
                out.append(q)
        return list(dict.fromkeys(out))

    restart_i = 0
    cur = best_params if best_params else starts[0]
    cur_s = evaluate(cur)
    while time.time() < deadline:
        improved = False
        nb = neighbors(cur)
        random.shuffle(nb)
        for q in nb:
            if time.time() > deadline:
                break
            s = evaluate(q)
            if s > cur_s:
                cur, cur_s = q, s
                improved = True
                break
        if not improved:
            # restart
            restart_i += 1
            if restart_i < len(starts):
                cur = starts[restart_i]
            else:
                base = best_params if best_params else starts[0]
                d, n, n1, cap = base
                cur = (max(1, d + random.randint(-2, 2)), max(1, n + random.randint(-2, 2)),
                       max(0, n1 + random.randint(-2, 2)), max(1, cap + random.randint(-2, 2)))
                dd, nn, a, c = cur
                cur = (dd, nn, min(a, nn), min(c, nn))
            cur_s = evaluate(cur)
    return sorted(set(best))
# EVOLVE-BLOCK-END