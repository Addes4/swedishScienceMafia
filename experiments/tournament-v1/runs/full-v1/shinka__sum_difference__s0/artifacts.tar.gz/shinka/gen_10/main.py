# EVOLVE-BLOCK-START
"""Weighted down-set construction with exact counting and simulated annealing."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    from math import comb

    t_start = time.time()

    def counts(d, n):
        ns = comb(2 * n + d, d)
        nd = 0
        for j in range(0, d + 1):
            cj = comb(d, j) * comb(n, j)
            if cj == 0:
                continue
            for l in range(0, d - j + 1):
                nd += cj * comb(d - j, l) * comb(n, l)
        return nd, ns

    best = None
    best_sc = -1.0
    for d in range(1, 60):
        for n in range(1, 60):
            size = comb(n + d, d)
            if size > 4000:
                break
            B = 2 * n + 1
            if n * B ** (d - 1) * d > 4e14:
                break
            if size < 2:
                continue
            nd, ns = counts(d, n)
            sc = math.log(nd) / math.log(ns) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)

    d0, n0 = best

    def build_points(wlist, n):
        pts = [(0, n)]
        place = 1
        for w in wlist:
            m = n // w
            rad = 2 * m + 1
            new = []
            for (val, rem) in pts:
                for x in range(rem // w + 1):
                    new.append((val + x * place, rem - x * w))
            pts = new
            place *= rad
        return sorted(set(p[0] for p in pts))

    base_pts = build_points([1] * d0, n0)

    try:
        import numpy as np
    except Exception:
        return base_pts

    NMAX = 12
    LIM = 4e14
    cache = {}

    def evaluate(n, items):
        key = (n, items)
        if key in cache:
            return cache[key]
        res = None
        try:
            res = _evaluate(n, items)
        except Exception:
            res = None
        cache[key] = res
        return res

    def _evaluate(n, items):
        prod = 1
        for (w, m) in items:
            prod *= (2 * (n // w) + 1) ** m
            if prod > LIM:
                return None
        T = np.zeros((n + 1, n + 1), dtype=np.int64)
        T[0, 0] = 1
        for (w, m) in items:
            for _ in range(m):
                new = T.copy()
                for j in range(1, n // w + 1):
                    s = w * j
                    new[s:, :] += T[:n + 1 - s, :]
                    new[:, s:] += T[:, :n + 1 - s]
                T = new
                if int(T[:, 0].sum()) > 4000:
                    return None
        size = int(T[:, 0].sum())
        if size < 2:
            return None
        D = int(T.sum())
        mask = (1 << (n + 1)) - 1
        cl = list(items)
        ncl = len(cl)

        def rec(ci, budget, reach, W):
            if ci == ncl:
                lo = W - n
                if lo < 0:
                    lo = 0
                return 1 if (reach >> lo) else 0
            w, m = cl[ci]
            res = 0
            R = reach
            for t in range(budget // w + 1):
                if t > 0:
                    R = R | ((reach << (w * t)) & mask)
                coef = comb(t + m - 1, m - 1)
                res += coef * rec(ci + 1, budget - w * t, R, W + w * t)
            return res

        S = rec(0, 2 * n, 1, 0)
        if S < 2 or D < 2:
            return None
        sc = math.log(D) / math.log(S) + (1 - 1 / size) / 100
        return (sc, size, D, S)

    def normalize(n, dct):
        items = tuple(sorted((w, m) for w, m in dct.items() if m > 0 and w <= n and w >= 1))
        return items

    def neighbor(n, dct):
        dct = dict(dct)
        r = random.random()
        if r < 0.1:
            n = max(2, min(NMAX, n + random.choice([-1, 1])))
        elif r < 0.4:
            if dct and random.random() < 0.8:
                w = random.choice(list(dct.keys()))
            else:
                w = random.randint(1, max(1, min(n, 6)))
            dct[w] = dct.get(w, 0) + random.choice([-2, -1, 1, 1, 2])
        elif r < 0.7:
            if dct:
                w = random.choice(list(dct.keys()))
                if random.random() < 0.7:
                    w2 = w + random.choice([-1, 1])
                else:
                    w2 = random.randint(1, n)
                if 1 <= w2 <= n and w2 != w:
                    dct[w] -= 1
                    dct[w2] = dct.get(w2, 0) + 1
        else:
            if random.random() < 0.6 or not dct:
                w = random.randint(1, n) if random.random() < 0.3 else random.randint(1, max(1, min(n, 5)))
                dct[w] = dct.get(w, 0) + 1
            else:
                w = random.choice(list(dct.keys()))
                dct[w] -= 1
        dct = {w: m for w, m in dct.items() if m > 0 and w <= n}
        return n, dct

    cur_n, cur_d = n0, {1: d0}
    cur_items = normalize(cur_n, cur_d)
    ev = evaluate(cur_n, cur_items)
    cur_s = ev[0] if ev else -1.0
    best_state = (cur_n, cur_items)
    best_s = cur_s

    search_time = 70.0
    t_end = t_start + search_time
    it = 0
    last_improve = 0
    while True:
        now = time.time()
        if now > t_end:
            break
        frac = (now - t_start) / search_time
        temp = 0.004 * (1 - frac) + 0.0002
        it += 1
        nn, nd_ = neighbor(cur_n, dict(cur_items))
        if not nd_:
            continue
        items = normalize(nn, nd_)
        if not items:
            continue
        e = evaluate(nn, items)
        if e is None:
            continue
        s = e[0]
        delta = s - cur_s
        if delta > 0 or random.random() < math.exp(delta / temp):
            cur_n, cur_items, cur_s = nn, items, s
            if s > best_s + 1e-12:
                best_s = s
                best_state = (nn, items)
                last_improve = it
        if it - last_improve > 3000:
            cur_n, cur_items = best_state
            cur_s = best_s
            last_improve = it

    def actual(vals):
        v = np.array(sorted(set(int(x) for x in vals)), dtype=np.int64)
        k = len(v)
        if k < 2:
            return -1.0
        sums = np.concatenate([v[i] + v[i:] for i in range(k)])
        ns = len(np.unique(sums))
        del sums
        diffs = np.concatenate([v[i + 1:] - v[i] for i in range(k - 1)])
        nd = 2 * len(np.unique(diffs)) + 1
        del diffs
        return math.log(nd) / math.log(ns) + (1 - 1 / k) / 100

    try:
        n_b, items_b = best_state
        wlist = []
        for (w, m) in items_b:
            wlist.extend([w] * m)
        cand = build_points(wlist, n_b)
        if len(cand) <= 4000 and max(abs(x) for x in cand) <= 10 ** 15 and best_s > best_sc + 1e-9:
            a = actual(cand)
            if a > best_sc + 1e-9:
                return [int(x) for x in cand]
    except Exception:
        pass
    return base_pts
# EVOLVE-BLOCK-END