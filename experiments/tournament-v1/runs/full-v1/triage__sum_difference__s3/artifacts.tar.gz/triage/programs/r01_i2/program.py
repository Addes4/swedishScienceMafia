import math
import random
import time
import itertools
import numpy as np


def _build_points(d, N):
    pts = []
    for p in itertools.product(range(N + 1), repeat=d):
        if sum(p) <= N:
            pts.append(p)
    return pts


def _enc(p, B):
    v = 0
    m = 1
    for x in p:
        v += x * m
        m *= B
    return v


def _scan_score(d, n):
    B = 2 * n + 1
    pts = _build_points(d, n)
    vals = np.array([_enc(p, B) for p in pts], dtype=np.int64)
    sums = np.unique((vals[:, None] + vals[None, :]).ravel())
    diffs = np.unique((vals[:, None] - vals[None, :]).ravel())
    return math.log(len(diffs)) / math.log(len(sums)), len(pts)


def solve():
    t0 = time.time()
    TL = 90.0
    # choose best simplex config
    best_cfg, best_sc = None, -1
    for d in range(2, 9):
        for n in range(1, 12):
            size = math.comb(n + d, d)
            if size > 1500 or size < 6:
                continue
            if math.comb(n + 1 + d, d) > 6000:
                continue
            if (2 * (n + 1) + 1) ** d > 30_000_000:
                continue
            try:
                sc, _ = _scan_score(d, n)
            except Exception:
                continue
            if sc > best_sc:
                best_sc, best_cfg = sc, (d, n)
    if best_cfg is None:
        best_cfg = (3, 3)
    d, n = best_cfg
    N = n + 1
    B = 2 * N + 1
    upts = _build_points(d, N)
    uvals = [_enc(p, B) for p in upts]
    usum = [sum(p) for p in upts]
    U = len(uvals)
    base = sum(N * B ** i for i in range(d))
    off = base
    size = B ** d
    S = np.zeros(size + 1, dtype=np.int32)
    D = np.zeros(2 * off + 2, dtype=np.int32)

    arr = np.zeros(U + 2, dtype=np.int64)
    m = 0
    pos = {}
    state = {"m": 0, "ns": 0, "nd": 0}

    def add(x):
        m = state["m"]
        a = arr[:m]
        dn_s = 0
        dn_d = 0
        idx = x + a
        S[idx] += 1
        dn_s += int(np.count_nonzero(S[idx] == 1))
        S[2 * x] += 1
        if S[2 * x] == 1:
            dn_s += 1
        i1 = x - a + off
        D[i1] += 1
        dn_d += int(np.count_nonzero(D[i1] == 1))
        i2 = a - x + off
        D[i2] += 1
        dn_d += int(np.count_nonzero(D[i2] == 1))
        D[off] += 1
        if D[off] == 1:
            dn_d += 1
        arr[m] = x
        pos[x] = m
        state["m"] = m + 1
        state["ns"] += dn_s
        state["nd"] += dn_d

    def remove(x):
        m = state["m"]
        i = pos.pop(x)
        last = int(arr[m - 1])
        if last != x:
            arr[i] = last
            pos[last] = i
        m -= 1
        state["m"] = m
        a = arr[:m]
        dn_s = 0
        dn_d = 0
        idx = x + a
        S[idx] -= 1
        dn_s += int(np.count_nonzero(S[idx] == 0))
        S[2 * x] -= 1
        if S[2 * x] == 0:
            dn_s += 1
        i1 = x - a + off
        D[i1] -= 1
        dn_d += int(np.count_nonzero(D[i1] == 0))
        i2 = a - x + off
        D[i2] -= 1
        dn_d += int(np.count_nonzero(D[i2] == 0))
        D[off] -= 1
        if D[off] == 0:
            dn_d += 1
        state["ns"] -= dn_s
        state["nd"] -= dn_d

    inA = [False] * U
    for k in range(U):
        if usum[k] <= n:
            add(uvals[k])
            inA[k] = True

    def f():
        ns, nd, m = state["ns"], state["nd"], state["m"]
        if m < 2 or ns < 2:
            return 0.0
        return math.log(nd) / math.log(ns) + (1 - 1 / m) / 100

    cur = f()
    best = cur
    best_set = [int(v) for v in arr[:state["m"]]]
    T0, T1 = 2e-3, 1e-5
    it = 0
    T = T0
    start = time.time()
    while True:
        it += 1
        if (it & 63) == 0:
            el = time.time() - start
            if el > TL - (start - t0):
                break
            T = T0 * (T1 / T0) ** (el / (TL - (start - t0)))
        k = random.randrange(U)
        x = uvals[k]
        if inA[k]:
            if state["m"] <= 3:
                continue
            remove(x)
            new = f()
            if new >= cur or random.random() < math.exp((new - cur) / T):
                inA[k] = False
                cur = new
            else:
                add(x)
        else:
            add(x)
            new = f()
            if new >= cur or random.random() < math.exp((new - cur) / T):
                inA[k] = True
                cur = new
            else:
                remove(x)
        if cur > best:
            best = cur
            best_set = [int(v) for v in arr[:state["m"]]]
    return sorted(set(best_set))
