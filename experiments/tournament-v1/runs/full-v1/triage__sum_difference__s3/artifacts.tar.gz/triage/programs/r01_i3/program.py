import math
import random
import time
import numpy as np


def _simplex(d, n):
    pts = np.zeros((1, 0), dtype=np.int64)
    for i in range(d):
        rows = []
        s = pts.sum(axis=1) if pts.shape[1] else np.zeros(1, dtype=np.int64)
        for val in range(n + 1):
            m = s + val <= n
            if m.any():
                sub = pts[m]
                col = np.full((sub.shape[0], 1), val, dtype=np.int64)
                rows.append(np.hstack([sub, col]))
        pts = np.vstack(rows)
    return pts


def _score_arr(a):
    a = np.unique(a)
    if len(a) < 2:
        return 0.0
    D = a[:, None] - a[None, :]
    nd = len(np.unique(D))
    S = a[:, None] + a[None, :]
    ns = len(np.unique(S))
    return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100


def _fallback_score(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    return _score_arr(a)


def solve():
    t0 = time.time()
    total = 95.0
    best_set = [7, 15, 18, 22, -3, -2]
    best_score = _fallback_score(best_set)

    configs = []
    for d in range(2, 9):
        for n in range(1, 30):
            sz = math.comb(n + d, d)
            if 20 <= sz <= 1500:
                configs.append((d, n, sz))
    random.shuffle(configs)
    pts_cache = {}

    def get_pts(d, n):
        if (d, n) not in pts_cache:
            pts_cache[(d, n)] = _simplex(d, n)
        return pts_cache[(d, n)]

    state = {}  # config -> (score, v)

    def evaluate(P, v):
        a = np.unique(P @ np.array(v, dtype=np.int64))
        return _score_arr(a), a

    def climb(cfg, tlimit):
        nonlocal best_set, best_score
        d, n, sz = cfg
        P = get_pts(d, n)
        if cfg in state:
            sc, v = state[cfg]
        else:
            v = [(2 * n + 1) ** i for i in range(d)]
            sc, a = evaluate(P, v)
            state[cfg] = (sc, v)
            if sc > best_score:
                best_score, best_set = sc, [int(x) for x in a]
        end = time.time() + tlimit
        while time.time() < end and time.time() - t0 < total:
            r = random.random()
            if r < 0.25:
                R = random.choice([3, 6, 12, 30, 100])
                w = [random.randint(-R, R) or 1 for _ in range(d)]
            else:
                w = list(v)
                k = random.randrange(d)
                if random.random() < 0.5:
                    w[k] += random.choice([-2, -1, 1, 2])
                else:
                    w[k] = random.randint(-max(3, abs(w[k]) + 3), max(3, abs(w[k]) + 3))
                if w[k] == 0:
                    w[k] = 1
            s, a = evaluate(P, w)
            if len(a) < 2:
                continue
            if s >= state[cfg][0]:
                state[cfg] = (s, w)
                v = w
                if s > best_score and np.abs(a).max() <= 10**15:
                    best_score, best_set = s, [int(x) for x in a]

    slice1 = max(1.0, 45.0 / max(1, len(configs)))
    for cfg in configs:
        if time.time() - t0 > 50:
            break
        climb(cfg, slice1)
    ranked = sorted(state.items(), key=lambda kv: -kv[1][0])[:3]
    while time.time() - t0 < total and ranked:
        for cfg, _ in ranked:
            if time.time() - t0 >= total:
                break
            climb(cfg, 8.0)
    return sorted(set(best_set))
