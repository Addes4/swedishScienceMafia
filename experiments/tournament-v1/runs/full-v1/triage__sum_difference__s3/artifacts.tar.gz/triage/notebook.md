# Research notebook: sum_difference

Ranker `jev`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.887449.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 5 | Implement fast exact scoring with numpy: put the indicator vector of A on [0, max] and use FFT convolution with itself and with its reverse, counting nonzero en | 0.70 | favourite | opus-5-5 | no_code |  |
| 4 | Build asymmetric unions such as S ∪ (t + ε·S') or nested simplices of different dilations sharing a vertex, chosen so the extra pieces add many new differences  | 0.67 | favourite | opus-5-5 | no_code |  |
| 2 | Start from the best simplex-type set and run a lattice-level local search that deletes or adds individual lattice points, for example trimming corners or adding | 0.63 | middle | sonnet-5-5 | improved | 0.934615 |
| 3 | Map the d-dimensional structured set to integers through a deliberately non-injective linear projection x ↦ v·x with small coordinates in v. Search over v (rand | 0.63 | middle | sonnet-5-5 | improved | 0.940149 |
| 0 | Replace the random search with a structured construction: take the lattice points of the d-dimensional simplex {x ∈ Z_{≥0}^d : Σx_i ≤ k} and map them to integer | 0.60 | long_shot | haiku-4-5 | improved | 0.946948 |
| 1 | Generalize the simplex to weighted or truncated corner bodies, either {x ≥ 0 : Σ w_i x_i ≤ k} with small integer weights w_i, or simplices intersected with boxe | 0.39 | long_shot | opus-5-5 (swapped) | api_error |  |

Promotion: claude-haiku-4-5 found an improvement; claude-opus-5-5 refined it -> api_error (0.000000).

Best after round 1: **0.946948** (spent $1.09)

