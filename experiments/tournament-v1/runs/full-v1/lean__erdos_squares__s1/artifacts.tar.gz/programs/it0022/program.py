# EVOLVE-BLOCK-START
"""Recursive grid / merged-block construction found by dynamic programming."""
import math
import numpy as np

_G = [0.0, 1.0]
_DESC = {}


def _compute(n):
    NEG = -1e18
    Gt = np.array(_G[:n] + [NEG], dtype=float)
    K = math.isqrt(n) + 2
    C = K * K
    h = np.full((C + 1, n + 1), NEG)
    h[0, 0] = 0.0
    ch = np.zeros((C + 1, n + 1), dtype=int)
    m_idx = np.arange(n + 1)[:, None]
    t_idx = np.arange(n + 1)[None, :]
    idx = m_idx - t_idx
    mask = idx >= 0
    idxc = np.where(mask, idx, 0)
    for c in range(1, C + 1):
        M = np.where(mask, h[c - 1][idxc] + Gt[None, :], NEG)
        h[c] = M.max(axis=1)
        ch[c] = M.argmax(axis=1)
    best = (_G[n - 1], None)
    Garr = np.array(_G, dtype=float)
    for k in range(2, K + 1):
        v = h[k * k][n] / k
        if v > best[0] + 1e-12:
            best = (v, (k, ()))
        mbs = np.arange(1, n)
        for j in range(2, k):
            c = k * k - j * j
            if len(mbs) == 0:
                continue
            vals = Garr[mbs] * j / k + h[c][n - mbs] / k
            i = int(vals.argmax())
            if vals[i] > best[0] + 1e-12:
                best = (float(vals[i]), (k, ((j, int(mbs[i]), 0, 0),)))
        # two blocks in opposite corners
        for j1 in range(2, k):
            for j2 in range(j1, k - j1 + 1):
                if j2 < 2:
                    continue
                c = k * k - j1 * j1 - j2 * j2
                if c < 0:
                    continue
                hc = h[c]
                for m1 in range(1, n - 1):
                    m2 = np.arange(1, n - m1 + 1)
                    rest = n - m1 - m2
                    vals = (Garr[m1] * j1 + Garr[m2] * j2 + hc[rest]) / k
                    i = int(vals.argmax())
                    if vals[i] > best[0] + 1e-12:
                        best = (float(vals[i]),
                                (k, ((j1, m1, 0, 0),
                                     (j2, int(m2[i]), k - j2, k - j2))))
    val, opt = best
    if opt is None:
        _G.append(_G[n - 1])
        _DESC[n] = ("copy",)
        return
    k, blocks = opt
    c = k * k - sum(b[0] ** 2 for b in blocks)
    m = n - sum(b[1] for b in blocks)
    assign = []
    while c > 0:
        t = int(ch[c][m])
        assign.append(t)
        m -= t
        c -= 1
    _G.append(val)
    _DESC[n] = ("grid", k, blocks, assign)


def _gen(n, x0, y0, s, out):
    if n <= 0:
        return
    if n == 1:
        sd = s * (1 - 1e-12)
        out.append((x0 + s / 2, y0 + s / 2, 0.0, sd))
        return
    d = _DESC[n]
    if d[0] == "copy":
        _gen(n - 1, x0, y0, s, out)
        return
    _, k, blocks, assign = d
    cs = s / k
    covered = set()
    for (j, mb, a0, b0) in blocks:
        _gen(mb, x0 + a0 * cs, y0 + b0 * cs, cs * j, out)
        for a in range(a0, a0 + j):
            for b in range(b0, b0 + j):
                covered.add((a, b))
    it = iter(assign)
    for a in range(k):
        for b in range(k):
            if (a, b) in covered:
                continue
            t = next(it, 0)
            _gen(t, x0 + a * cs, y0 + b * cs, cs, out)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    while len(_G) <= n:
        _compute(len(_G))
    out = []
    _gen(n, 0.0, 0.0, 1.0, out)
    out = out[:n]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    res = []
    for (x, y, a, s) in out:
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)),
                    min(1.0, max(0.0, a)), min(1.0, max(0.0, s))))
    return res
# EVOLVE-BLOCK-END
