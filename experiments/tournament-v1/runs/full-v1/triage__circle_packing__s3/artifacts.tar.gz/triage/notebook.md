# Research notebook: circle_packing

Ranker `jev`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.372434.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Use a penalty-based L-BFGS optimization over (x, y, r) with a quadratic overlap/wall penalty whose weight is increased geometrically over stages, run from hundr | 0.81 | favourite | opus-5-5 | improved | 0.999359 |
| 0 | Replace the heuristic with joint optimization of centers and radii: use scipy.optimize.minimize (SLSQP) maximizing sum(r) subject to pairwise non-overlap constr | 0.78 | favourite | opus-5-5 | improved | 0.997753 |
| 2 | Seed the optimizer with structured initial layouts known to work well for n=26, rather than random ones. Candidates include: a 5x5-like grid with one extra circ | 0.77 | middle | sonnet-5-5 | improved | 0.999359 |
| 3 | Basin-hopping around the best SLSQP solution, iterated until the time limit with only strict improvements accepted. Each step perturbs the configuration in one  | 0.72 | middle | sonnet-5-5 | improved | 0.997795 |
| 5 | Use a radius-growth "billiards" simulation (Lubachevsky–Stillinger style). Start with random tiny circles and grow each radius at a rate proportional to its ava | 0.72 | long_shot | haiku-4-5 | improved | 0.968475 |
| 4 | Exploit symmetry: restrict the search to configurations that are symmetric under reflection about the vertical axis (or the diagonal), which halves the variable | 0.66 | long_shot | opus-5-5 (swapped) | improved | 1.000000 |

Best after round 1: **1.000000** (spent $0.50)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 2 | Replace random-z initialization with a topology-aware search. Take the best packing's contact graph and generate neighbors by removing one circle and reinsertin | 0.41 | favourite | opus-5-5 | not_better | 1.000000 |
| 1 | Add 180° rotational (point) symmetry and both-axes (D2) symmetry classes to the symmetry-restricted multistart. Allow 0 or 2 fixed circles at the center or on t | 0.41 | favourite | opus-5-5 | not_better | 1.000000 |
| 0 | After the final SLSQP solution, identify the active set (pairs and walls with near-zero slack). Then solve the KKT/tangency system with Newton's method in exten | 0.40 | middle | sonnet-5-5 | not_better | 1.000000 |
| 3 | Speed up the full refinement by passing SLSQP only the pair constraints for neighbors within distance r_i+r_j+0.1 (recomputed per call from a Delaunay/cKDTree n | 0.38 | middle | sonnet-5-5 | no_code |  |
| 5 | Run the final polish as an LP-based sequential linear programming loop with a trust region. At each step, linearize the pair constraints at the current centers  | 0.37 | long_shot | haiku-4-5 | not_better | 1.000000 |
| 4 | Use a population-based approach: keep the top 8 distinct packings (deduplicated by sorted-radii fingerprint). Generate offspring by a cut-and-splice crossover:  | 0.23 | long_shot | haiku-4-5 | not_better | 1.000000 |

Best after round 2: **1.000000** (spent $1.09)

