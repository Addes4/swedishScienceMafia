# EVOLVE-BLOCK-START
"""Structured seeds (grid+1, hex rows 5-6-5-6-4, corner/edge big circles) polished with
SLSQP on (x, y, r), exact LP radii for final feasibility, then basin hopping on the best."""
import time
import numpy as np
from scipy.optimize import minimize, linprog


def lp_radii(centers):
    n = len(centers)
    c = np.clip(centers, 0.0, 1.0)
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(c[I] - c[J], axis=1)
    m = len(I)
    A = np.zeros((m, n))
    A[np.arange(m), I] = 1
    A[np.arange(m), J] = 1
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status == 0:
        return np.maximum(res.x, 0.0)
    return np.maximum(wall * 0.0, 0.0)


def polish(centers, n, I, J, maxiter=300):
    r0 = lp_radii(centers)
    v0 = np.concatenate([centers[:, 0], centers[:, 1], r0])
    m = len(I)
    rows = np.arange(m)

    def obj(v):
        return -np.sum(v[2 * n:])

    def gobj(v):
        g = np.zeros(3 * n)
        g[2 * n:] = -1
        return g

    def con(v):
        x = v[:n]; y = v[n:2 * n]; r = v[2 * n:]
        dx = x[I] - x[J]; dy = y[I] - y[J]
        d = np.sqrt(dx * dx + dy * dy)
        return np.concatenate([d - r[I] - r[J], x - r, 1 - x - r, y - r, 1 - y - r])

    def jac(v):
        x = v[:n]; y = v[n:2 * n]
        dx = x[I] - x[J]; dy = y[I] - y[J]
        d = np.sqrt(dx * dx + dy * dy) + 1e-12
        Jm = np.zeros((m + 4 * n, 3 * n))
        Jm[rows, I] = dx / d
        Jm[rows, J] = -dx / d
        Jm[rows, n + I] = dy / d
        Jm[rows, n + J] = -dy / d
        Jm[rows, 2 * n + I] = -1
        Jm[rows, 2 * n + J] = -1
        k = np.arange(n)
        Jm[m + k, k] = 1; Jm[m + k, 2 * n + k] = -1
        Jm[m + n + k, k] = -1; Jm[m + n + k, 2 * n + k] = -1
        Jm[m + 2 * n + k, n + k] = 1; Jm[m + 2 * n + k, 2 * n + k] = -1
        Jm[m + 3 * n + k, n + k] = -1; Jm[m + 3 * n + k, 2 * n + k] = -1
        return Jm

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(obj, v0, jac=gobj, bounds=bounds,
                       constraints=[{"type": "ineq", "fun": con, "jac": jac}],
                       method="SLSQP", options={"maxiter": maxiter, "ftol": 1e-10})
        v = res.x
    except Exception:
        v = v0
    cen = np.stack([v[:n], v[n:2 * n]], axis=1)
    cen = np.clip(cen, 0, 1)
    r = lp_radii(cen)
    return cen, r


def layout_grid(n, rng):
    pts = [[(i + 0.5) / 5, (j + 0.5) / 5] for i in range(5) for j in range(5)]
    pts.append([rng.uniform(0.1, 0.9), rng.uniform(0.1, 0.9)])
    return np.array(pts[:n])


def layout_hex(n, rng):
    counts = [5, 6, 5, 6, 4]
    if rng.random() < 0.5:
        counts = [6, 5, 6, 5, 4]
    if rng.random() < 0.3:
        counts = [5, 5, 6, 5, 5]
    ys = np.linspace(0.1, 0.9, len(counts))
    pts = []
    for cnt, y in zip(counts, ys):
        xs = (np.arange(cnt) + 0.5) / cnt
        for x in xs:
            pts.append([x, y])
    pts = np.array(pts)
    if len(pts) > n:
        pts = pts[:n]
    while len(pts) < n:
        pts = np.vstack([pts, rng.random(2)])
    return pts


def layout_corner(n, rng):
    pts = [[0.12, 0.12], [0.88, 0.12], [0.12, 0.88], [0.88, 0.88]]
    for t in (0.3, 0.5, 0.7):
        pts += [[t, 0.07], [t, 0.93], [0.07, t], [0.93, t]]
    while len(pts) < n:
        pts.append([rng.uniform(0.15, 0.85), rng.uniform(0.15, 0.85)])
    return np.array(pts[:n])


def layout_rand(n, rng):
    return rng.random((n, 2)) * 0.9 + 0.05


def solve(n=26):
    rng = np.random.default_rng(12345)
    t0 = time.time()
    budget = 170.0
    I, J = np.triu_indices(n, 1)
    best_c, best_r, best_s = None, None, -1.0
    gens = [layout_grid, layout_hex, layout_corner, layout_hex, layout_grid, layout_rand]

    def consider(c, r):
        nonlocal best_c, best_r, best_s
        s = r.sum()
        if s > best_s:
            best_c, best_r, best_s = c.copy(), r.copy(), s

    it = 0
    # phase 1: structured seeds with noise
    while time.time() - t0 < budget * 0.55:
        g = gens[it % len(gens)]
        base = g(n, rng)
        noise = [0.0, 0.01, 0.03, 0.05][it % 4] if it >= len(gens) else 0.0
        c = np.clip(base + rng.normal(0, noise, base.shape), 0.02, 0.98)
        try:
            c, r = polish(c, n, I, J)
            consider(c, r)
        except Exception:
            pass
        it += 1
    # phase 2: basin hopping from best
    while time.time() - t0 < budget:
        c = best_c.copy()
        mode = rng.random()
        if mode < 0.5:
            k = rng.integers(1, 4)
            idx = np.argsort(best_r)[:k + 2]
            sel = rng.choice(idx, size=min(k, len(idx)), replace=False)
            c[sel] = rng.random((len(sel), 2)) * 0.9 + 0.05
        elif mode < 0.8:
            c += rng.normal(0, 0.02, c.shape)
        else:
            i, j = rng.choice(n, 2, replace=False)
            c[[i, j]] = c[[j, i]]
            c += rng.normal(0, 0.01, c.shape)
        c = np.clip(c, 0.02, 0.98)
        try:
            c, r = polish(c, n, I, J)
            consider(c, r)
        except Exception:
            pass
    if best_c is None:
        c = layout_hex(n, rng)
        return c, lp_radii(c)
    return best_c, best_r
# EVOLVE-BLOCK-END
