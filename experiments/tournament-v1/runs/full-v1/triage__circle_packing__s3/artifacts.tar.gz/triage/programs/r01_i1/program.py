# EVOLVE-BLOCK-START
"""Penalty-based L-BFGS multistart over (x, y, r) with geometric penalty
continuation, finished by an exact LP for optimal radii given centres."""
import time
import numpy as np
from scipy.optimize import minimize, linprog


def _pen_obj(z, n, mu):
    x = z[:n]; y = z[n:2 * n]; r = z[2 * n:]
    dx = x[:, None] - x[None, :]
    dy = y[:, None] - y[None, :]
    d = np.sqrt(dx * dx + dy * dy + 1e-18)
    O = r[:, None] + r[None, :] - d
    np.fill_diagonal(O, 0.0)
    O = np.maximum(O, 0.0)
    P = 0.5 * np.sum(O * O)
    gr = 2.0 * O.sum(axis=1)
    coef = 2.0 * O / d
    gx = -(coef * dx).sum(axis=1)
    gy = -(coef * dy).sum(axis=1)
    w1 = np.maximum(r - x, 0); w2 = np.maximum(r + x - 1, 0)
    w3 = np.maximum(r - y, 0); w4 = np.maximum(r + y - 1, 0)
    P += np.sum(w1 ** 2 + w2 ** 2 + w3 ** 2 + w4 ** 2)
    gr += 2 * (w1 + w2 + w3 + w4)
    gx += -2 * w1 + 2 * w2
    gy += -2 * w3 + 2 * w4
    f = -np.sum(r) + mu * P
    g = np.concatenate([mu * gx, mu * gy, -1.0 + mu * gr])
    return f, g


def _lp_radii(centers):
    n = len(centers)
    iu, ju = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[iu] - centers[ju], axis=1)
    A = np.zeros((len(iu), n))
    A[np.arange(len(iu)), iu] = 1.0
    A[np.arange(len(iu)), ju] = 1.0
    ub = np.minimum.reduce([centers[:, 0], centers[:, 1],
                            1 - centers[:, 0], 1 - centers[:, 1]])
    ub = np.maximum(ub, 0.0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d,
                  bounds=list(zip(np.zeros(n), ub)), method="highs")
    if res.status != 0:
        return None
    r = np.clip(res.x, 0, ub) * (1 - 1e-9)
    return r


def _valid(c, r, tol=1e-12):
    if np.any(r < 0):
        return False
    if np.any(c[:, 0] - r < -tol) or np.any(c[:, 0] + r > 1 + tol):
        return False
    if np.any(c[:, 1] - r < -tol) or np.any(c[:, 1] + r > 1 + tol):
        return False
    n = len(r)
    iu, ju = np.triu_indices(n, 1)
    d = np.linalg.norm(c[iu] - c[ju], axis=1)
    return np.all(r[iu] + r[ju] <= d + tol)


def _init(n, rng):
    mode = rng.integers(0, 3)
    if mode == 0:
        x = rng.uniform(0.05, 0.95, n); y = rng.uniform(0.05, 0.95, n)
    elif mode == 1:
        k = int(np.ceil(np.sqrt(n)))
        pts = [((i + 0.5) / k, (j + 0.5) / k) for i in range(k) for j in range(k)]
        idx = rng.permutation(len(pts))[:n]
        p = np.array(pts)[idx] + rng.normal(0, 0.03, (n, 2))
        x, y = np.clip(p[:, 0], 0.02, 0.98), np.clip(p[:, 1], 0.02, 0.98)
    else:
        x = np.empty(n); y = np.empty(n)
        x[0], y[0] = 0.5 + rng.normal(0, 0.05), 0.5 + rng.normal(0, 0.05)
        m = n - 1
        for i in range(m):
            a = 2 * np.pi * i / m + rng.normal(0, 0.1)
            rad = rng.uniform(0.25, 0.48)
            x[i + 1] = 0.5 + rad * np.cos(a); y[i + 1] = 0.5 + rad * np.sin(a)
        x = np.clip(x, 0.02, 0.98); y = np.clip(y, 0.02, 0.98)
    r = rng.uniform(0.02, 0.1, n)
    return np.concatenate([x, y, r])


def _run_penalty(z0, n):
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    z = z0
    for mu in [10, 1e2, 1e3, 1e4, 1e5, 1e6, 1e7]:
        res = minimize(_pen_obj, z, args=(n, mu), jac=True, method="L-BFGS-B",
                       bounds=bounds, options={"maxiter": 3000, "ftol": 1e-15, "gtol": 1e-10})
        z = res.x
    return z


def _slsqp_polish(c, r):
    n = len(r)
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)

    def cons(z):
        x = z[:n]; y = z[n:2 * n]; rr = z[2 * n:]
        d = np.sqrt((x[iu] - x[ju]) ** 2 + (y[iu] - y[ju]) ** 2 + 1e-18)
        return np.concatenate([d - rr[iu] - rr[ju], x - rr, 1 - x - rr, y - rr, 1 - y - rr])

    def cjac(z):
        x = z[:n]; y = z[n:2 * n]
        dx = x[iu] - x[ju]; dy = y[iu] - y[ju]
        d = np.sqrt(dx * dx + dy * dy + 1e-18)
        J = np.zeros((m + 4 * n, 3 * n))
        k = np.arange(m)
        J[k, iu] = dx / d; J[k, ju] = -dx / d
        J[k, n + iu] = dy / d; J[k, n + ju] = -dy / d
        J[k, 2 * n + iu] = -1; J[k, 2 * n + ju] = -1
        a = np.arange(n)
        J[m + a, a] = 1; J[m + a, 2 * n + a] = -1
        J[m + n + a, a] = -1; J[m + n + a, 2 * n + a] = -1
        J[m + 2 * n + a, n + a] = 1; J[m + 2 * n + a, 2 * n + a] = -1
        J[m + 3 * n + a, n + a] = -1; J[m + 3 * n + a, 2 * n + a] = -1
        return J

    z0 = np.concatenate([c[:, 0], c[:, 1], r])
    obj = lambda z: -np.sum(z[2 * n:])
    gobj = lambda z: np.concatenate([np.zeros(2 * n), -np.ones(n)])
    try:
        res = minimize(obj, z0, jac=gobj, method="SLSQP",
                       bounds=[(0, 1)] * (2 * n) + [(0, 0.5)] * n,
                       constraints=[{"type": "ineq", "fun": cons, "jac": cjac}],
                       options={"maxiter": 500, "ftol": 1e-14})
        z = res.x
    except Exception:
        return c
    return np.column_stack([np.clip(z[:n], 0, 1), np.clip(z[n:2 * n], 0, 1)])


def solve(n=26):
    t0 = time.time()
    rng = np.random.default_rng(12345)
    cands = []
    best_s, best = -1, None
    while time.time() - t0 < 150:
        z = _run_penalty(_init(n, rng), n)
        c = np.column_stack([z[:n], z[n:2 * n]])
        r = _lp_radii(c)
        if r is None:
            continue
        s = r.sum()
        cands.append((s, c))
        if s > best_s and _valid(c, r):
            best_s, best = s, (c.copy(), r.copy())

    cands.sort(key=lambda t: -t[0])
    for s, c in cands[:8]:
        if time.time() - t0 > 260:
            break
        c2 = _slsqp_polish(c, _lp_radii(c))
        r2 = _lp_radii(c2)
        if r2 is not None and _valid(c2, r2) and r2.sum() > best_s:
            best_s, best = r2.sum(), (c2.copy(), r2.copy())

    if best is None:
        c = np.array([[(i % 6 + 0.5) / 6, (i // 6 + 0.5) / 6] for i in range(n)])
        return c, np.full(n, 1 / 12 * (1 - 1e-9))
    return best
# EVOLVE-BLOCK-END
