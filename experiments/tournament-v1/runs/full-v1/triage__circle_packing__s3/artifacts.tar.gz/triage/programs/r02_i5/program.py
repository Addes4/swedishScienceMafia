"""LP-based sequential linear programming with trust region for final polish."""
import time
import numpy as np
from scipy.optimize import minimize, linprog


class Prob:
    """Circle packing problem with full vector v = A z + b, v = [x(n), y(n), r(n)]."""

    def __init__(self, n, A, b, lo, hi, rtype, rng):
        self.n = n
        self.A = A
        self.b = b
        self.lo = lo
        self.hi = hi
        self.rtype = rtype  # boolean mask: variable is a radius
        self.bounds = list(zip(lo, hi))
        self.c = A[2 * n:3 * n, :].sum(axis=0)
        PI, PJ = np.triu_indices(n, 1)
        self.PI, self.PJ = PI, PJ
        npair = len(PI)
        self.npair = npair
        # wall constraints (linear in v)
        W = np.zeros((4 * n, 3 * n))
        wc = np.zeros(4 * n)
        for i in range(n):
            W[4 * i, i] = 1; W[4 * i, 2 * n + i] = -1; wc[4 * i] = 0
            W[4 * i + 1, i] = -1; W[4 * i + 1, 2 * n + i] = -1; wc[4 * i + 1] = 1
            W[4 * i + 2, n + i] = 1; W[4 * i + 2, 2 * n + i] = -1; wc[4 * i + 2] = 0
            W[4 * i + 3, n + i] = -1; W[4 * i + 3, 2 * n + i] = -1; wc[4 * i + 3] = 1
        self.W = W
        self.wc = wc
        self.WA = W @ A
        self.wcz = W @ b + wc
        self.rows = np.arange(npair)
        # dedupe constraints using a random point
        self.sel_w = np.arange(4 * n)
        self.sel_p = np.arange(npair)
        z0 = self.random_z(rng)
        gw = self.WA @ z0 + self.wcz
        gp, Jp = self._pairs_full(z0)
        G = np.concatenate([gw, gp])
        J = np.vstack([self.WA, Jp])
        key = np.round(np.hstack([G[:, None], J]), 9)
        # also drop trivially constant rows (zero gradient)
        _, idx = np.unique(key, axis=0, return_index=True)
        idx = np.sort(idx)
        nz_grad = np.abs(J[idx]).sum(axis=1) > 0
        idx = idx[nz_grad]
        self.sel_w = idx[idx < 4 * n]
        self.sel_p = idx[idx >= 4 * n] - 4 * n
        self.WAs = self.WA[self.sel_w]
        self.wczs = self.wcz[self.sel_w]
        self.PIs = self.PI[self.sel_p]
        self.PJs = self.PJ[self.sel_p]
        self._cache_z = None

    def random_z(self, rng):
        z = rng.uniform(self.lo, self.hi)
        z[self.rtype] = rng.uniform(0.01, 0.06, self.rtype.sum())
        return z

    def _pairs_full(self, z, PI=None, PJ=None):
        n = self.n
        if PI is None:
            PI, PJ = self.PI, self.PJ
        v = self.A @ z + self.b
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        dx = x[PI] - x[PJ]
        dy = y[PI] - y[PJ]
        rs = r[PI] + r[PJ]
        g = dx * dx + dy * dy - rs * rs
        m = len(PI)
        Jv = np.zeros((m, 3 * n))
        rows = np.arange(m)
        np.add.at(Jv, (rows, PI), 2 * dx)
        np.add.at(Jv, (rows, PJ), -2 * dx)
        np.add.at(Jv, (rows, n + PI), 2 * dy)
        np.add.at(Jv, (rows, n + PJ), -2 * dy)
        np.add.at(Jv, (rows, 2 * n + PI), -2 * rs)
        np.add.at(Jv, (rows, 2 * n + PJ), -2 * rs)
        return g, Jv @ self.A

    def _eval(self, z):
        if self._cache_z is not None and np.array_equal(z, self._cache_z):
            return
        gp, Jp = self._pairs_full(z, self.PIs, self.PJs)
        gw = self.WAs @ z + self.wczs
        self._g = np.concatenate([gw, gp])
        self._J = np.vstack([self.WAs, Jp])
        self._cache_z = z.copy()

    def g(self, z):
        self._eval(z)
        return self._g

    def jac(self, z):
        self._eval(z)
        return self._J

    def solve(self, z0, maxiter=400):
        cons = {'type': 'ineq', 'fun': self.g, 'jac': self.jac}
        c = self.c
        try:
            res = minimize(lambda z: -c @ z, z0, jac=lambda z: -c,
                           bounds=self.bounds, constraints=[cons], method='SLSQP',
                           options={'maxiter': maxiter, 'ftol': 1e-12})
            z = res.x
        except Exception:
            z = z0
        return z

    def full(self, z):
        v = self.A @ z + self.b
        n = self.n
        return np.stack([v[:n], v[n:2 * n]], axis=1), v[2 * n:].copy()


def build(n, kind, m, rng):
    if kind == 'full':
        A = np.eye(3 * n)
        b = np.zeros(3 * n)
        lo = np.zeros(3 * n)
        hi = np.concatenate([np.ones(2 * n), 0.5 * np.ones(n)])
        rtype = np.zeros(3 * n, bool); rtype[2 * n:] = True
        return Prob(n, A, b, lo, hi, rtype, rng)
    k = (n - m) // 2
    nz = 3 * k + 2 * m
    A = np.zeros((3 * n, nz))
    b = np.zeros(3 * n)
    lo = np.zeros(nz)
    hi = np.ones(nz)
    rtype = np.zeros(nz, bool)
    ci = 0
    for p in range(k):
        zx, zy, zr = 3 * p, 3 * p + 1, 3 * p + 2
        hi[zr] = 0.5; rtype[zr] = True
        a, s = ci, ci + 1
        ci += 2
        A[a, zx] = 1; A[n + a, zy] = 1; A[2 * n + a, zr] = 1
        A[2 * n + s, zr] = 1
        if kind == 'vert':
            hi[zx] = 0.5
            A[s, zx] = -1; b[s] = 1
            A[n + s, zy] = 1
        else:  # diag
            A[s, zy] = 1
            A[n + s, zx] = 1
    for q in range(m):
        zt, zr = 3 * k + 2 * q, 3 * k + 2 * q + 1
        hi[zr] = 0.5; rtype[zr] = True
        a = ci
        ci += 1
        A[2 * n + a, zr] = 1
        if kind == 'vert':
            b[a] = 0.5
            A[n + a, zt] = 1
        else:
            A[a, zt] = 1
            A[n + a, zt] = 1
    return Prob(n, A, b, lo, hi, rtype, rng)


def repair(c, r):
    c = np.clip(np.asarray(c, float), 0.0, 1.0)
    r = np.asarray(r, float).copy()
    r = np.minimum(r, np.min([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]], axis=0))
    r = np.maximum(r, 0.0)
    n = len(r)
    d = np.sqrt(((c[:, None, :] - c[None, :, :]) ** 2).sum(-1))
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                s = r[i] + r[j]
                if s > d[i, j] and s > 0:
                    sc = d[i, j] / s * (1 - 1e-13)
                    r[i] *= sc
                    r[j] *= sc
                    changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


def lp_polish(centers, radii, n, max_time=30.0, max_iter=500):
    """LP-based sequential linear programming with trust region."""
    t0 = time.time()
    c = centers.copy()
    r = radii.copy()
    
    delta = 0.05
    min_delta = 1e-6
    stall_count = 0
    best_score = r.sum()
    
    for iteration in range(max_iter):
        if time.time() - t0 > max_time:
            break
        
        # Compute pairwise distances and gradients
        PI, PJ = np.triu_indices(n, 1)
        dx_full = c[PI, 0] - c[PJ, 0]
        dy_full = c[PI, 1] - c[PJ, 1]
        d_sq = dx_full**2 + dy_full**2
        d = np.sqrt(np.maximum(d_sq, 1e-16))
        
        # Build LP: variables are [dx_0, ..., dx_{n-1}, dy_0, ..., dy_{n-1}, dr_0, ..., dr_{n-1}]
        # Objective: maximize sum of dr (minimize -sum of dr)
        num_vars = 3 * n
        c_lp = np.zeros(num_vars)
        c_lp[2*n:] = -1.0
        
        # Inequality constraints: A_ub @ x <= b_ub
        A_ub_list = []
        b_ub_list = []
        
        # Trust region: |dx_i| <= delta, |dy_i| <= delta
        for i in range(n):
            A_ub_list.append(np.eye(1, num_vars, i)[0])
            b_ub_list.append(delta)
            A_ub_list.append(-np.eye(1, num_vars, i)[0])
            b_ub_list.append(delta)
            A_ub_list.append(np.eye(1, num_vars, n+i)[0])
            b_ub_list.append(delta)
            A_ub_list.append(-np.eye(1, num_vars, n+i)[0])
            b_ub_list.append(delta)
        
        # Bounds on radii: dr_i in [-r_i, 0.5 - r_i]
        for i in range(n):
            A_ub_list.append(np.eye(1, num_vars, 2*n+i)[0])
            b_ub_list.append(0.5 - r[i])
            A_ub_list.append(-np.eye(1, num_vars, 2*n+i)[0])
            b_ub_list.append(r[i])
        
        # Pair constraints: linearized at current position
        # g_ij = (x_i - x_j)^2 + (y_i - y_j)^2 - (r_i + r_j)^2 >= 0
        # Linearization: g_ij + J @ [dx, dy, dr] >= 0
        for idx, (i, j) in enumerate(zip(PI, PJ)):
            dxi = c[i, 0] - c[j, 0]
            dyi = c[i, 1] - c[j, 1]
            ri_pj = r[i] + r[j]
            g_val = dxi**2 + dyi**2 - ri_pj**2
            
            # Gradient in [dx, dy, dr] space
            # dg/dx_i = 2*dxi, dg/dx_j = -2*dxi, dg/dy_i = 2*dyi, dg/dy_j = -2*dyi
            # dg/dr_i = -2*ri_pj, dg/dr_j = -2*ri_pj
            row = np.zeros(num_vars)
            row[i] = 2.0 * dxi
            row[j] -= 2.0 * dxi
            row[n+i] = 2.0 * dyi
            row[n+j] -= 2.0 * dyi
            row[2*n+i] = -2.0 * ri_pj
            row[2*n+j] = -2.0 * ri_pj
            
            A_ub_list.append(-row)
            b_ub_list.append(-g_val)
        
        # Wall constraints
        for i in range(n):
            # x_i - r_i >= 0: x_i >= r_i
            row = np.zeros(num_vars)
            row[i] = 1.0
            row[2*n+i] = -1.0
            A_ub_list.append(-row)
            b_ub_list.append(-0.0 + 1e-10)
            
            # x_i + r_i <= 1: x_i <= 1 - r_i
            row = np.zeros(num_vars)
            row[i] = 1.0
            row[2*n+i] = 1.0
            A_ub_list.append(row)
            b_ub_list.append(1.0 - r[i] + 1e-10)
            
            # y_i - r_i >= 0
            row = np.zeros(num_vars)
            row[n+i] = 1.0
            row[2*n+i] = -1.0
            A_ub_list.append(-row)
            b_ub_list.append(-0.0 + 1e-10)
            
            # y_i + r_i <= 1
            row = np.zeros(num_vars)
            row[n+i] = 1.0
            row[2*n+i] = 1.0
            A_ub_list.append(row)
            b_ub_list.append(1.0 - r[i] + 1e-10)
        
        A_ub = np.array(A_ub_list)
        b_ub = np.array(b_ub_list)
        
        # Solve LP
        try:
            res = linprog(c_lp, A_ub=A_ub, b_ub=b_ub, method='highs', bounds=None)
            if not res.success:
                break
            x_opt = res.x
            
            # Extract solution
            dx = x_opt[:n]
            dy = x_opt[n:2*n]
            dr = x_opt[2*n:]
            
            # Update
            c_new = c + np.stack([dx, dy], axis=1)
            r_new = r + dr
            
            # Clip to bounds
            c_new = np.clip(c_new, 0.0, 1.0)
            r_new = np.clip(r_new, 0.0, 0.5)
            
            # Repair for safety
            r_new = repair(c_new, r_new)
            
            new_score = r_new.sum()
            improvement = new_score - best_score
            
            if improvement > 1e-8:
                c = c_new
                r = r_new
                best_score = new_score
                stall_count = 0
            else:
                stall_count += 1
                if stall_count >= 3:
                    delta *= 0.5
                    stall_count = 0
                    if delta < min_delta:
                        break
        except Exception:
            break
    
    return c, r


def solve(n=26):
    t0 = time.time()
    T_SYM = 140.0
    T_END = 270.0
    rng = np.random.default_rng(12345)

    configs = []
    for kind in ('vert', 'diag'):
        for m in (0, 2, 4, 6):
            if (n - m) % 2 == 0 and n - m >= 0:
                try:
                    configs.append((kind, m, build(n, kind, m, rng)))
                except Exception:
                    pass

    sym_results = []  # (score, centers, radii)
    best = (-1.0, None, None)

    def consider(c, r):
        nonlocal best
        rr = repair(c, r)
        s = rr.sum()
        if s > best[0]:
            best = (s, c.copy(), rr.copy())
        return s, rr

    it = 0
    while time.time() - t0 < T_SYM and configs:
        kind, m, P = configs[it % len(configs)]
        it += 1
        z0 = P.random_z(rng)
        z = P.solve(z0)
        c, r = P.full(z)
        s, rr = consider(c, r)
        sym_results.append((s, c, rr))

    # full refinement
    F = build(n, 'full', 0, rng)

    def to_z(c, r):
        return np.concatenate([c[:, 0], c[:, 1], r])

    sym_results.sort(key=lambda t: -t[0])
    tops = []
    for s, c, r in sym_results:
        if all(abs(s - t[0]) > 1e-6 for t in tops):
            tops.append((s, c, r))
        if len(tops) >= 10:
            break

    if best[1] is None:
        z = F.solve(F.random_z(rng))
        c, r = F.full(z)
        consider(c, r)

    for s, c, r in tops:
        if time.time() - t0 > T_END:
            break
        z = F.solve(to_z(c, r))
        cc, rr = F.full(z)
        consider(cc, rr)

    # basin hopping on full problem
    while time.time() - t0 < T_END - 35.0 and best[1] is not None:
        c = best[1].copy()
        r = best[2].copy()
        sig = rng.choice([0.01, 0.03, 0.06])
        if rng.random() < 0.5:
            mask = rng.random(n) < 0.3
            c[mask] += rng.normal(0, sig, (mask.sum(), 2))
        else:
            c += rng.normal(0, sig * 0.5, c.shape)
        c = np.clip(c, 0.01, 0.99)
        r = r * 0.9
        z = F.solve(to_z(c, r))
        cc, rr = F.full(z)
        consider(cc, rr)

    # Final LP-based polish
    time_left = T_END - (time.time() - t0)
    if best[1] is not None and time_left > 5.0:
        c_final, r_final = lp_polish(best[1], best[2], n, max_time=max(5.0, time_left - 2.0))
        consider(c_final, r_final)

    centers = np.clip(best[1], 0.0, 1.0)
    radii = repair(centers, best[2])
    return centers, radii
