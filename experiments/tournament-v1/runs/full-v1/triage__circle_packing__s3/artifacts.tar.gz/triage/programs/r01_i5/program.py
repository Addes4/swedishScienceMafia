import numpy as np
from scipy.optimize import minimize


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii using billiards growth + SLSQP polish."""
    
    # Phase 1: Billiards-style growth simulation
    centers, radii = billiards_growth(n, iterations=3000, dt=0.01)
    
    # Phase 2: Polish with SLSQP constrained optimization
    centers, radii = polish_with_slsqp(centers, radii)
    
    return centers, radii


def billiards_growth(n, iterations=3000, dt=0.01):
    """Lubachevsky-Stillinger style billiards: grow circles while resolving overlaps."""
    np.random.seed(42)
    
    # Initialize: tiny circles at random positions
    centers = np.random.rand(n, 2)
    radii = np.ones(n) * 0.001
    
    growth_rate = 0.0015  # Growth rate per iteration
    
    for iteration in range(iterations):
        # Grow all radii
        radii = np.minimum(radii + growth_rate, 0.5)
        
        # Constrain to walls
        radii = np.minimum(radii, centers[:, 0])
        radii = np.minimum(radii, centers[:, 1])
        radii = np.minimum(radii, 1 - centers[:, 0])
        radii = np.minimum(radii, 1 - centers[:, 1])
        
        # Resolve overlaps by pushing centers apart
        for i in range(n):
            for j in range(i + 1, n):
                dx = centers[j] - centers[i]
                d = np.linalg.norm(dx)
                min_dist = radii[i] + radii[j]
                
                if d < min_dist and d > 1e-10:
                    # Push apart
                    direction = dx / d
                    overlap = min_dist - d
                    push = overlap * 0.5 + 0.001
                    centers[i] -= direction * push
                    centers[j] += direction * push
        
        # Constrain centers to be inside [0, 1]^2
        centers = np.clip(centers, 0.0, 1.0)
        
        # Mild random shaking every 50 iterations
        if iteration % 50 == 0 and iteration > 0:
            centers += np.random.randn(n, 2) * 0.0005
            centers = np.clip(centers, 0.0, 1.0)
    
    # Final constraint pass
    radii = np.minimum(radii, centers[:, 0])
    radii = np.minimum(radii, centers[:, 1])
    radii = np.minimum(radii, 1 - centers[:, 0])
    radii = np.minimum(radii, 1 - centers[:, 1])
    
    return centers, radii


def polish_with_slsqp(centers, radii):
    """Polish configuration using constrained SLSQP optimization."""
    n = len(centers)
    
    def pack_state(c, r):
        return np.concatenate([c.flatten(), r])
    
    def unpack_state(x):
        return x[:2*n].reshape(n, 2), x[2*n:]
    
    def objective(x):
        _, r = unpack_state(x)
        return -np.sum(r)  # Maximize sum of radii
    
    def constraint_wall(x):
        c, r = unpack_state(x)
        # All circles must be inside the unit square
        constraints = np.concatenate([
            c[:, 0] - r,  # x - r >= 0
            c[:, 1] - r,  # y - r >= 0
            (1 - c[:, 0]) - r,  # (1 - x) - r >= 0
            (1 - c[:, 1]) - r,  # (1 - y) - r >= 0
        ])
        return constraints
    
    def constraint_no_overlap(x):
        c, r = unpack_state(x)
        constraints = []
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(c[i] - c[j])
                constraints.append(d - (r[i] + r[j]))
        return np.array(constraints)
    
    x0 = pack_state(centers, radii)
    
    constraints = [
        {'type': 'ineq', 'fun': constraint_wall},
        {'type': 'ineq', 'fun': constraint_no_overlap},
    ]
    
    bounds = [(0.0, 1.0)] * (2*n) + [(0.0, 0.5)] * n
    
    result = minimize(
        objective,
        x0,
        method='SLSQP',
        bounds=bounds,
        constraints=constraints,
        options={'maxiter': 500, 'ftol': 1e-9}
    )
    
    centers, radii = unpack_state(result.x)
    radii = np.maximum(radii, 0.0)
    
    return centers, radii
