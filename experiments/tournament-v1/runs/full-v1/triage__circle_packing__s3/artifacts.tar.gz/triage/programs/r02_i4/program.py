"""Population-based circle packing with cut-and-splice crossover and repair."""
import time
import numpy as np
from scipy.optimize import minimize


class Prob:
    """Circle packing problem with full vector v = A z + b, v = [x(n), y(n), r(n)]."""

    def __init__(self, n, A, b, lo, hi, rtype, rng):
        self.n = n
        self.A = A
        self.b = b
        self.lo = lo
        self.hi = hi
        self.rtype = rtype
        self.bounds = list(zip(lo, hi))
        self.c = A[2 * n:3 * n, :].sum(axis=0)
        PI, PJ = np.triu_indices(n, 1)
        self.PI, self.PJ = PI, PJ
        npair = len(PI)
        self.npair = npair
        W = np.zeros((4 * n, 3 * n))
        wc = np.zeros(4 * n)
        for i in range(n):
            W[4 * i, i] = 1; W[4 * i, 2 * n + i] = -1; wc[4 * i] = 0
            W[4 * i + 1, i] = -1; W[4 * i + 1, 2 * n + i] = -1; wc[4 * i + 1] = 1
            W[4 * i + 2, n + i] = 1; W[4 * i + 2, 2 * n + i] = -1; wc[4 * i + 2] = 0
            W[4 * i + 3, n + i] = -1; W[4 * i + 3, 2 * n + i] = -1; wc[4 * i + 3] = 1
        self.W = W
        self.wc = wc
        self.WA = W @ A
        self.wcz = W @ b + wc
        self.rows = np.arange(npair)
        self.sel_w = np.arange(4 * n)
        self.sel_p = np.arange(npair)
        z0 = self.random_z(rng)
        gw = self.WA @ z0 + self.wcz
        gp, Jp = self._pairs_full(z0)
        G = np.concatenate([gw, gp])
        J = np.vstack([self.WA, Jp])
        key = np.round(np.hstack([G[:, None], J]), 9)
        _, idx = np.unique(key, axis=0, return_index=True)
        idx = np.sort(idx)
        nz_grad = np.abs(J[idx]).sum(axis=1) > 0
        idx = idx[nz_grad]
        self.sel_w = idx[idx < 4 * n]
        self.sel_p = idx[idx >= 4 * n] - 4 * n
        self.WAs = self.WA[self.sel_w]
        self.wczs = self.wcz[self.sel_w]
        self.PIs = self.PI[self.sel_p]
        self.PJs = self.PJ[self.sel_p]
        self._cache_z = None

    def random_z(self, rng):
        z = rng.uniform(self.lo, self.hi)
        z[self.rtype] = rng.uniform(0.01, 0.06, self.rtype.sum())
        return z

    def _pairs_full(self, z, PI=None, PJ=None):
        n = self.n
        if PI is None:
            PI, PJ = self.PI, self.PJ
        v = self.A @ z + self.b
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        dx = x[PI] - x[PJ]
        dy = y[PI] - y[PJ]
        rs = r[PI] + r[PJ]
        g = dx * dx + dy * dy - rs * rs
        m = len(PI)
        Jv = np.zeros((m, 3 * n))
        rows = np.arange(m)
        np.add.at(Jv, (rows, PI), 2 * dx)
        np.add.at(Jv, (rows, PJ), -2 * dx)
        np.add.at(Jv, (rows, n + PI), 2 * dy)
        np.add.at(Jv, (rows, n + PJ), -2 * dy)
        np.add.at(Jv, (rows, 2 * n + PI), -2 * rs)
        np.add.at(Jv, (rows, 2 * n + PJ), -2 * rs)
        return g, Jv @ self.A

    def _eval(self, z):
        if self._cache_z is not None and np.array_equal(z, self._cache_z):
            return
        gp, Jp = self._pairs_full(z, self.PIs, self.PJs)
        gw = self.WAs @ z + self.wczs
        self._g = np.concatenate([gw, gp])
        self._J = np.vstack([self.WAs, Jp])
        self._cache_z = z.copy()

    def g(self, z):
        self._eval(z)
        return self._g

    def jac(self, z):
        self._eval(z)
        return self._J

    def solve(self, z0, maxiter=400):
        cons = {'type': 'ineq', 'fun': self.g, 'jac': self.jac}
        c = self.c
        try:
            res = minimize(lambda z: -c @ z, z0, jac=lambda z: -c,
                           bounds=self.bounds, constraints=[cons], method='SLSQP',
                           options={'maxiter': maxiter, 'ftol': 1e-12})
            z = res.x
        except Exception:
            z = z0
        return z

    def full(self, z):
        v = self.A @ z + self.b
        n = self.n
        return np.stack([v[:n], v[n:2 * n]], axis=1), v[2 * n:].copy()


def repair(c, r):
    c = np.clip(np.asarray(c, float), 0.0, 1.0)
    r = np.asarray(r, float).copy()
    r = np.minimum(r, np.min([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]], axis=0))
    r = np.maximum(r, 0.0)
    n = len(r)
    d = np.sqrt(((c[:, None, :] - c[None, :, :]) ** 2).sum(-1))
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                s = r[i] + r[j]
                if s > d[i, j] and s > 0:
                    sc = d[i, j] / s * (1 - 1e-13)
                    r[i] *= sc
                    r[j] *= sc
                    changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


def crossover(c1, r1, c2, r2, rng, n):
    """Cut-and-splice crossover: split at random line, combine halves, adjust count."""
    # Random split direction and position
    if rng.random() < 0.5:
        # Vertical split
        split_x = rng.uniform(0.2, 0.8)
        mask1 = c1[:, 0] < split_x
        mask2 = c2[:, 0] >= split_x
    else:
        # Horizontal split
        split_y = rng.uniform(0.2, 0.8)
        mask1 = c1[:, 1] < split_y
        mask2 = c2[:, 1] >= split_y
    
    # Combine
    c_new = np.vstack([c1[mask1], c2[mask2]])
    r_new = np.concatenate([r1[mask1], r2[mask2]])
    
    # Adjust count
    if len(r_new) > n:
        # Remove smallest circles
        idx = np.argsort(r_new)
        idx = idx[:(len(r_new) - n)]
        keep = np.ones(len(r_new), bool)
        keep[idx] = False
        c_new = c_new[keep]
        r_new = r_new[keep]
    elif len(r_new) < n:
        # Add small circles at random positions
        n_add = n - len(r_new)
        c_add = rng.uniform(0.1, 0.9, (n_add, 2))
        r_add = rng.uniform(0.01, 0.05, n_add)
        c_new = np.vstack([c_new, c_add])
        r_new = np.concatenate([r_new, r_add])
    
    return c_new, r_new


def get_fingerprint(r):
    """Fingerprint for deduplication: sorted radii rounded."""
    return tuple(np.round(np.sort(r), 6))


def solve(n=26):
    t0 = time.time()
    T_SYM = 80.0
    T_CROSS = 200.0
    T_END = 270.0
    rng = np.random.default_rng(12345)

    # Initial setup with symmetry
    A = np.eye(3 * n)
    b = np.zeros(3 * n)
    lo = np.zeros(3 * n)
    hi = np.concatenate([np.ones(2 * n), 0.5 * np.ones(n)])
    rtype = np.zeros(3 * n, bool)
    rtype[2 * n:] = True
    F = Prob(n, A, b, lo, hi, rtype, rng)

    def to_z(c, r):
        return np.concatenate([c[:, 0], c[:, 1], r])

    def consider(c, r, population, seen_fp):
        c = np.clip(np.asarray(c, float), 0.0, 1.0)
        r = repair(c, r)
        s = r.sum()
        fp = get_fingerprint(r)
        if fp not in seen_fp:
            population.append((s, c.copy(), r.copy()))
            seen_fp.add(fp)
            population.sort(key=lambda t: -t[0])
            if len(population) > 8:
                population.pop()
                seen_fp.discard(get_fingerprint(population[-1][2]))
        return s, r

    population = []
    seen_fp = set()
    best = (-1.0, None, None)

    # Phase 1: Initial diversity with random restarts
    it = 0
    while time.time() - t0 < T_SYM:
        z0 = F.random_z(rng)
        z = F.solve(z0, maxiter=300)
        c, r = F.full(z)
        s, rr = consider(c, r, population, seen_fp)
        if s > best[0]:
            best = (s, c.copy(), rr.copy())
        it += 1

    if not population:
        z = F.solve(F.random_z(rng))
        c, r = F.full(z)
        consider(c, r, population, seen_fp)
        best = population[0]

    # Phase 2: Crossover breeding
    while time.time() - t0 < T_CROSS and len(population) >= 2:
        # Select two parents
        i1 = rng.choice(min(4, len(population)))
        i2 = rng.choice(min(4, len(population)))
        if i1 == i2:
            i2 = (i1 + 1) % len(population)

        c1, r1 = population[i1][1], population[i1][2]
        c2, r2 = population[i2][1], population[i2][2]

        c_child, r_child = crossover(c1, r1, c2, r2, rng, n)

        # Ensure we have exactly n circles
        if len(r_child) != n:
            continue

        # Polish with SLSQP
        z_child = F.solve(to_z(c_child, r_child), maxiter=350)
        cc, rr = F.full(z_child)
        s, rr = consider(cc, rr, population, seen_fp)
        if s > best[0]:
            best = (s, cc.copy(), rr.copy())

    # Phase 3: Refinement of best solutions
    while time.time() - t0 < T_END and best[1] is not None:
        c = best[1].copy()
        r = best[2].copy()
        sig = rng.choice([0.01, 0.03, 0.05])
        if rng.random() < 0.6:
            mask = rng.random(n) < 0.35
            c[mask] += rng.normal(0, sig, (mask.sum(), 2))
        else:
            c += rng.normal(0, sig * 0.4, c.shape)
        c = np.clip(c, 0.01, 0.99)
        r = r * 0.92
        z = F.solve(to_z(c, r), maxiter=350)
        cc, rr = F.full(z)
        s, rr = consider(cc, rr, population, seen_fp)
        if s > best[0]:
            best = (s, cc.copy(), rr.copy())

    centers = np.clip(best[1], 0.0, 1.0)
    radii = repair(centers, best[2])
    return centers, radii
