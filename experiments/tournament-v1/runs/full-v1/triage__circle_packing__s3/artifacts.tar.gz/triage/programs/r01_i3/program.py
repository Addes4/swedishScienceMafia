import time
import numpy as np
from scipy.optimize import minimize

N_DEFAULT = 26


def _fix_radii(centers, radii):
    """Make radii strictly feasible (walls and pairs) by shrinking."""
    n = len(centers)
    r = np.minimum(radii, np.minimum.reduce([centers[:, 0], centers[:, 1],
                                             1 - centers[:, 0], 1 - centers[:, 1]]))
    r = np.maximum(r, 0.0)
    D = np.sqrt(((centers[:, None, :] - centers[None, :, :]) ** 2).sum(-1))
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                s = r[i] + r[j]
                if s > D[i, j]:
                    f = D[i, j] / s * (1 - 1e-13)
                    r[i] *= f
                    r[j] *= f
                    changed = True
        if not changed:
            break
    return r


class _Opt:
    def __init__(self, n):
        self.n = n
        I, J = np.triu_indices(n, 1)
        self.I, self.J = I, J
        m = len(I)
        self.m = m
        # linear wall constraints: x-r>=0, 1-x-r>=0, y-r>=0, 1-y-r>=0
        A = np.zeros((4 * n, 3 * n))
        b = np.zeros(4 * n)
        for k in range(n):
            A[k, k] = 1; A[k, 2 * n + k] = -1
            A[n + k, k] = -1; A[n + k, 2 * n + k] = -1; b[n + k] = 1
            A[2 * n + k, n + k] = 1; A[2 * n + k, 2 * n + k] = -1
            A[3 * n + k, n + k] = -1; A[3 * n + k, 2 * n + k] = -1; b[3 * n + k] = 1
        self.A, self.b = A, b
        self.bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
        self.ar = np.arange(m)

    def cons(self, z):
        n = self.n
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        I, J = self.I, self.J
        c1 = (x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 - (r[I] + r[J]) ** 2
        return np.concatenate([c1, self.A @ z + self.b * 0 - self.b * 0 + self._off()])

    def _off(self):
        # A z + off >= 0 ; for rows with b=1 we need 1 - x - r so offset = b
        return self.b

    def jac(self, z):
        n = self.n
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        I, J = self.I, self.J
        Jm = np.zeros((self.m, 3 * n))
        dx = 2 * (x[I] - x[J]); dy = 2 * (y[I] - y[J]); ds = -2 * (r[I] + r[J])
        a = self.ar
        Jm[a, I] = dx; Jm[a, J] = -dx
        Jm[a, n + I] = dy; Jm[a, n + J] = -dy
        Jm[a, 2 * n + I] = ds; Jm[a, 2 * n + J] = ds
        return np.vstack([Jm, self.A])

    def solve(self, centers, radii, maxiter=150):
        n = self.n
        z0 = np.concatenate([centers[:, 0], centers[:, 1], radii])
        z0 = np.clip(z0, [b[0] for b in self.bounds], [b[1] for b in self.bounds])
        g = np.zeros(3 * n); g[2 * n:] = -1.0
        try:
            res = minimize(lambda z: -z[2 * n:].sum(), z0, jac=lambda z: g,
                           method='SLSQP', bounds=self.bounds,
                           constraints=[{'type': 'ineq', 'fun': self.cons, 'jac': self.jac}],
                           options={'maxiter': maxiter, 'ftol': 1e-11})
            z = res.x
        except Exception:
            z = z0
        c = np.stack([z[:n], z[n:2 * n]], 1)
        c = np.clip(c, 0.0, 1.0)
        r = _fix_radii(c, z[2 * n:])
        return c, r, r.sum()


def _init_config(n, rng, kind):
    if kind == 0:
        pts = rng.random((n, 2)) * 0.9 + 0.05
    elif kind == 1:
        k = int(np.ceil(np.sqrt(n)))
        g = [((i + 0.5) / k, (j + 0.5) / k) for i in range(k) for j in range(k)]
        idx = rng.permutation(len(g))[:n]
        pts = np.array(g)[idx] + rng.normal(0, 0.02, (n, 2))
    else:
        pts = [[0.5, 0.5]]
        pts += [[0.5 + 0.25 * np.cos(2 * np.pi * i / 8), 0.5 + 0.25 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
        pts += [[0.5 + 0.43 * np.cos(2 * np.pi * i / 16), 0.5 + 0.43 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
        pts = np.array(pts[:n], float)
        while len(pts) < n:
            pts = np.vstack([pts, rng.random(2) * 0.8 + 0.1])
        pts = pts + rng.normal(0, 0.02, pts.shape)
    pts = np.clip(pts, 0.03, 0.97)
    return pts, np.full(n, 0.05)


def _relocate(c, r, k, rng):
    n = len(c)
    c = c.copy(); r = r.copy()
    order = np.argsort(r)
    # choose among smallest few
    pool = order[:max(k + 2, 4)]
    rem = rng.choice(pool, size=k, replace=False)
    keep = np.ones(n, bool); keep[rem] = False
    for idx in rem:
        P = rng.random((3000, 2))
        dw = np.minimum.reduce([P[:, 0], P[:, 1], 1 - P[:, 0], 1 - P[:, 1]])
        act = np.where(keep)[0]
        if len(act):
            d = np.sqrt(((P[:, None, :] - c[act][None, :, :]) ** 2).sum(-1)) - r[act][None, :]
            dc = d.min(1)
            gap = np.minimum(dw, dc)
        else:
            gap = dw
        top = np.argsort(-gap)[:10]
        t = rng.choice(top)
        c[idx] = P[t]
        r[idx] = max(gap[t], 0.0) * 0.9
        keep[idx] = True
    return c, r


def _swap(c, r, rng):
    n = len(c)
    c = c.copy(); r = r.copy()
    for _ in range(20):
        i, j = rng.choice(n, 2, replace=False)
        if abs(r[i] - r[j]) > 0.02:
            break
    c[[i, j]] = c[[j, i]]
    return c, r


def solve(n=26):
    t0 = time.time()
    TOTAL = 255.0
    rng = np.random.default_rng(12345)
    opt = _Opt(n)

    best_c, best_r, best_s = None, None, -1.0
    t_init = 40.0
    k = 0
    while time.time() - t0 < t_init:
        c0, r0 = _init_config(n, rng, k % 3)
        k += 1
        c, r, s = opt.solve(c0, r0, maxiter=200)
        if s > best_s:
            best_c, best_r, best_s = c, r, s

    while time.time() - t0 < TOTAL:
        u = rng.random()
        if u < 0.6:
            c0, r0 = _relocate(best_c, best_r, int(rng.integers(1, 4)), rng)
        elif u < 0.85:
            c0, r0 = _swap(best_c, best_r, rng)
        else:
            c0, r0 = _relocate(best_c, best_r, 1, rng)
            c0 = np.clip(c0 + rng.normal(0, 0.01, c0.shape), 0.01, 0.99)
        c, r, s = opt.solve(c0, r0, maxiter=200)
        if s > best_s + 1e-9:
            best_c, best_r, best_s = c, r, s

    return best_c, best_r
