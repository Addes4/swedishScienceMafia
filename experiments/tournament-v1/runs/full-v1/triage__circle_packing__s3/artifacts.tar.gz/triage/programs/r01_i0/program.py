# EVOLVE-BLOCK-START
"""Joint optimisation of centres and radii with SLSQP, multi-start + basin hopping."""
import time
import numpy as np
from scipy.optimize import minimize, linprog


def _make_problem(n):
    iu, ju = np.triu_indices(n, 1)
    m = len(iu)
    rows = np.arange(m)

    def obj(z):
        return -np.sum(z[2 * n:])

    g = np.zeros(3 * n)
    g[2 * n:] = -1.0

    def obj_grad(z):
        return g

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        rs = r[iu] + r[ju]
        pair = dx * dx + dy * dy - rs * rs
        walls = np.concatenate([x - r, 1 - x - r, y - r, 1 - y - r])
        return np.concatenate([pair, walls])

    Jw = np.zeros((4 * n, 3 * n))
    I = np.arange(n)
    Jw[I, I] = 1; Jw[I, 2 * n + I] = -1
    Jw[n + I, I] = -1; Jw[n + I, 2 * n + I] = -1
    Jw[2 * n + I, n + I] = 1; Jw[2 * n + I, 2 * n + I] = -1
    Jw[3 * n + I, n + I] = -1; Jw[3 * n + I, 2 * n + I] = -1

    def cons_jac(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[iu] - x[ju]
        dy = y[iu] - y[ju]
        rs = r[iu] + r[ju]
        J = np.zeros((m, 3 * n))
        J[rows, iu] = 2 * dx
        J[rows, ju] = -2 * dx
        J[rows, n + iu] = 2 * dy
        J[rows, n + ju] = -2 * dy
        J[rows, 2 * n + iu] = -2 * rs
        J[rows, 2 * n + ju] = -2 * rs
        return np.vstack([J, Jw])

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    return obj, obj_grad, cons, cons_jac, bounds


def _lp_radii(centers):
    n = len(centers)
    iu, ju = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[iu] - centers[ju], axis=1)
    A = np.zeros((len(iu), n))
    A[np.arange(len(iu)), iu] = 1
    A[np.arange(len(iu)), ju] = 1
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=list(zip([0] * n, wall)), method="highs")
        if res.success:
            return np.maximum(res.x, 0)
    except Exception:
        pass
    return None


def _repair(centers, radii):
    centers = np.clip(np.asarray(centers, float), 0, 1)
    r = np.asarray(radii, float).copy()
    n = len(r)
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    r = np.clip(r, 0, wall)
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if r[i] + r[j] > d:
                    s = d / (r[i] + r[j]) if r[i] + r[j] > 0 else 0
                    r[i] *= s
                    r[j] *= s
                    changed = True
        if not changed:
            break
    r = np.maximum(r * (1 - 1e-9) - 1e-12, 0)
    return centers, r


def _feasible(centers, r, tol=0.0):
    n = len(r)
    if np.any(r < 0):
        return False
    if np.any(centers[:, 0] - r < -tol) or np.any(centers[:, 0] + r > 1 + tol):
        return False
    if np.any(centers[:, 1] - r < -tol) or np.any(centers[:, 1] + r > 1 + tol):
        return False
    for i in range(n):
        d = np.linalg.norm(centers[i + 1:] - centers[i], axis=1)
        if np.any(r[i] + r[i + 1:] > d + tol):
            return False
    return True


def _structured_inits(n, rng):
    inits = []
    # 5x5 grid + 1
    g = np.linspace(0.1, 0.9, 5)
    pts = np.array([[a, b] for a in g for b in g])
    for _ in range(3):
        extra = rng.uniform(0.1, 0.9, size=(n - 25, 2))
        p = np.vstack([pts, extra])[:n] + rng.normal(0, 0.02, (n, 2))
        inits.append(np.clip(p, 0.05, 0.95))
    # hex-ish rows
    for rows in ([5, 6, 5, 5, 5], [6, 5, 6, 5, 4], [5, 5, 6, 5, 5], [4, 5, 4, 5, 4, 4]):
        pts = []
        k = len(rows)
        for ri, c in enumerate(rows):
            yv = (ri + 0.5) / k
            off = 0.5 / c if ri % 2 else 0.0
            for ci in range(c):
                xv = (ci + 0.5) / c + rng.normal(0, 0.01)
                pts.append([xv, yv])
        pts = np.array(pts)
        if len(pts) < n:
            pts = np.vstack([pts, rng.uniform(0.1, 0.9, (n - len(pts), 2))])
        inits.append(np.clip(pts[:n] + rng.normal(0, 0.01, (n, 2)), 0.05, 0.95))
    # ring layout
    pts = [[0.5, 0.5]]
    pts += [[0.5 + 0.25 * np.cos(2 * np.pi * i / 8), 0.5 + 0.25 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    pts += [[0.5 + 0.45 * np.cos(2 * np.pi * i / 17), 0.5 + 0.45 * np.sin(2 * np.pi * i / 17)] for i in range(17)]
    inits.append(np.clip(np.array(pts[:n]), 0.05, 0.95))
    return inits


def solve(n=26):
    t0 = time.time()
    budget = 230.0
    rng = np.random.default_rng(12345)
    obj, obj_grad, cons, cons_jac, bounds = _make_problem(n)
    constraints = [{"type": "ineq", "fun": cons, "jac": cons_jac}]

    def run(c0, r0=None, maxiter=400):
        if r0 is None:
            r0 = np.full(n, 0.03)
        z0 = np.concatenate([c0[:, 0], c0[:, 1], r0])
        try:
            res = minimize(obj, z0, jac=obj_grad, method="SLSQP", bounds=bounds,
                           constraints=constraints, options={"maxiter": maxiter, "ftol": 1e-12})
        except Exception:
            return None, None, -1
        z = res.x
        viol = -np.min(cons(z))
        if viol > 1e-6:
            return None, None, -1
        c = np.stack([z[:n], z[n:2 * n]], axis=1)
        return c, z[2 * n:], np.sum(z[2 * n:])

    best_c, best_r, best_s = None, None, -1
    pool = []  # top solutions

    def consider(c, r, s):
        nonlocal best_c, best_r, best_s
        if c is None:
            return
        pool.append((s, c.copy(), r.copy()))
        pool.sort(key=lambda t: -t[0])
        del pool[8:]
        if s > best_s:
            best_c, best_r, best_s = c.copy(), r.copy(), s

    for c0 in _structured_inits(n, rng):
        if time.time() - t0 > budget * 0.3:
            break
        consider(*run(c0))

    it = 0
    while time.time() - t0 < budget:
        it += 1
        if best_c is None or rng.random() < 0.3:
            c0 = rng.uniform(0.08, 0.92, (n, 2))
            consider(*run(c0))
        else:
            # basin hopping from one of the top solutions
            idx = 0 if rng.random() < 0.6 or len(pool) == 1 else rng.integers(len(pool))
            _, pc, pr = pool[idx]
            sigma = rng.choice([0.01, 0.03, 0.06, 0.1])
            c0 = pc + rng.normal(0, sigma, (n, 2))
            r0 = pr * 0.9
            if rng.random() < 0.3:
                k = rng.integers(1, 4)
                sel = rng.choice(n, k, replace=False)
                c0[sel] = rng.uniform(0.05, 0.95, (k, 2))
                r0[sel] = 0.02
            c0 = np.clip(c0, 0.02, 0.98)
            consider(*run(c0, r0))

    if best_c is None:
        c0 = rng.uniform(0.1, 0.9, (n, 2))
        return _repair(c0, np.full(n, 0.01))

    # final polish: LP radii on best centres, then strict repair
    final_c, final_r, final_s = None, None, -1
    for s, c, r in pool[:4]:
        cc = np.clip(c, 0, 1)
        rl = _lp_radii(cc)
        cand = []
        if rl is not None:
            cand.append(rl)
        cand.append(r)
        for rr in cand:
            c2, r2 = _repair(cc, rr)
            if _feasible(c2, r2) and r2.sum() > final_s:
                final_c, final_r, final_s = c2, r2, r2.sum()
    if final_c is None:
        final_c, final_r = _repair(best_c, best_r)
    return final_c, final_r
# EVOLVE-BLOCK-END
