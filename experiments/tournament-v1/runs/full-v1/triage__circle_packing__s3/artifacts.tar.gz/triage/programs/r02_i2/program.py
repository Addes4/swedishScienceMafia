# EVOLVE-BLOCK-START
"""Symmetry-restricted SLSQP multistart, then topology-aware Metropolis search
(remove/reinsert into largest hole + large<->two-small exchange, LP radii, SLSQP polish)."""
import time
import numpy as np
from scipy.optimize import minimize, linprog


class Prob:
    """Circle packing problem with full vector v = A z + b, v = [x(n), y(n), r(n)]."""

    def __init__(self, n, A, b, lo, hi, rtype, rng):
        self.n = n
        self.A = A
        self.b = b
        self.lo = lo
        self.hi = hi
        self.rtype = rtype
        self.bounds = list(zip(lo, hi))
        self.c = A[2 * n:3 * n, :].sum(axis=0)
        PI, PJ = np.triu_indices(n, 1)
        self.PI, self.PJ = PI, PJ
        npair = len(PI)
        self.npair = npair
        W = np.zeros((4 * n, 3 * n))
        wc = np.zeros(4 * n)
        for i in range(n):
            W[4 * i, i] = 1; W[4 * i, 2 * n + i] = -1; wc[4 * i] = 0
            W[4 * i + 1, i] = -1; W[4 * i + 1, 2 * n + i] = -1; wc[4 * i + 1] = 1
            W[4 * i + 2, n + i] = 1; W[4 * i + 2, 2 * n + i] = -1; wc[4 * i + 2] = 0
            W[4 * i + 3, n + i] = -1; W[4 * i + 3, 2 * n + i] = -1; wc[4 * i + 3] = 1
        self.W = W
        self.wc = wc
        self.WA = W @ A
        self.wcz = W @ b + wc
        z0 = self.random_z(rng)
        gw = self.WA @ z0 + self.wcz
        gp, Jp = self._pairs_full(z0)
        G = np.concatenate([gw, gp])
        J = np.vstack([self.WA, Jp])
        key = np.round(np.hstack([G[:, None], J]), 9)
        _, idx = np.unique(key, axis=0, return_index=True)
        idx = np.sort(idx)
        nz_grad = np.abs(J[idx]).sum(axis=1) > 0
        idx = idx[nz_grad]
        self.sel_w = idx[idx < 4 * n]
        self.sel_p = idx[idx >= 4 * n] - 4 * n
        self.WAs = self.WA[self.sel_w]
        self.wczs = self.wcz[self.sel_w]
        self.PIs = PI[self.sel_p]
        self.PJs = PJ[self.sel_p]
        self._cache_z = None

    def random_z(self, rng):
        z = rng.uniform(self.lo, self.hi)
        z[self.rtype] = rng.uniform(0.01, 0.06, self.rtype.sum())
        return z

    def _pairs_full(self, z, PI=None, PJ=None):
        n = self.n
        if PI is None:
            PI, PJ = self.PI, self.PJ
        v = self.A @ z + self.b
        x, y, r = v[:n], v[n:2 * n], v[2 * n:]
        dx = x[PI] - x[PJ]
        dy = y[PI] - y[PJ]
        rs = r[PI] + r[PJ]
        g = dx * dx + dy * dy - rs * rs
        m = len(PI)
        Jv = np.zeros((m, 3 * n))
        rows = np.arange(m)
        np.add.at(Jv, (rows, PI), 2 * dx)
        np.add.at(Jv, (rows, PJ), -2 * dx)
        np.add.at(Jv, (rows, n + PI), 2 * dy)
        np.add.at(Jv, (rows, n + PJ), -2 * dy)
        np.add.at(Jv, (rows, 2 * n + PI), -2 * rs)
        np.add.at(Jv, (rows, 2 * n + PJ), -2 * rs)
        return g, Jv @ self.A

    def _eval(self, z):
        if self._cache_z is not None and np.array_equal(z, self._cache_z):
            return
        gp, Jp = self._pairs_full(z, self.PIs, self.PJs)
        gw = self.WAs @ z + self.wczs
        self._g = np.concatenate([gw, gp])
        self._J = np.vstack([self.WAs, Jp])
        self._cache_z = z.copy()

    def g(self, z):
        self._eval(z)
        return self._g

    def jac(self, z):
        self._eval(z)
        return self._J

    def solve(self, z0, maxiter=400):
        cons = {'type': 'ineq', 'fun': self.g, 'jac': self.jac}
        c = self.c
        try:
            res = minimize(lambda z: -c @ z, z0, jac=lambda z: -c,
                           bounds=self.bounds, constraints=[cons], method='SLSQP',
                           options={'maxiter': maxiter, 'ftol': 1e-12})
            z = res.x
        except Exception:
            z = z0
        return z

    def full(self, z):
        v = self.A @ z + self.b
        n = self.n
        return np.stack([v[:n], v[n:2 * n]], axis=1), v[2 * n:].copy()


def build(n, kind, m, rng):
    if kind == 'full':
        A = np.eye(3 * n)
        b = np.zeros(3 * n)
        lo = np.zeros(3 * n)
        hi = np.concatenate([np.ones(2 * n), 0.5 * np.ones(n)])
        rtype = np.zeros(3 * n, bool); rtype[2 * n:] = True
        return Prob(n, A, b, lo, hi, rtype, rng)
    k = (n - m) // 2
    nz = 3 * k + 2 * m
    A = np.zeros((3 * n, nz))
    b = np.zeros(3 * n)
    lo = np.zeros(nz)
    hi = np.ones(nz)
    rtype = np.zeros(nz, bool)
    ci = 0
    for p in range(k):
        zx, zy, zr = 3 * p, 3 * p + 1, 3 * p + 2
        hi[zr] = 0.5; rtype[zr] = True
        a, s = ci, ci + 1
        ci += 2
        A[a, zx] = 1; A[n + a, zy] = 1; A[2 * n + a, zr] = 1
        A[2 * n + s, zr] = 1
        if kind == 'vert':
            hi[zx] = 0.5
            A[s, zx] = -1; b[s] = 1
            A[n + s, zy] = 1
        else:
            A[s, zy] = 1
            A[n + s, zx] = 1
    for q in range(m):
        zt, zr = 3 * k + 2 * q, 3 * k + 2 * q + 1
        hi[zr] = 0.5; rtype[zr] = True
        a = ci
        ci += 1
        A[2 * n + a, zr] = 1
        if kind == 'vert':
            b[a] = 0.5
            A[n + a, zt] = 1
        else:
            A[a, zt] = 1
            A[n + a, zt] = 1
    return Prob(n, A, b, lo, hi, rtype, rng)


def repair(c, r):
    c = np.clip(np.asarray(c, float), 0.0, 1.0)
    r = np.asarray(r, float).copy()
    r = np.minimum(r, np.min([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]], axis=0))
    r = np.maximum(r, 0.0)
    n = len(r)
    d = np.sqrt(((c[:, None, :] - c[None, :, :]) ** 2).sum(-1))
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                s = r[i] + r[j]
                if s > d[i, j] and s > 0:
                    sc = d[i, j] / s * (1 - 1e-13)
                    r[i] *= sc
                    r[j] *= sc
                    changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


def lp_radii(c):
    """Optimal radii for fixed centers via LP."""
    c = np.clip(np.asarray(c, float), 0.0, 1.0)
    n = len(c)
    PI, PJ = np.triu_indices(n, 1)
    d = np.sqrt(((c[PI] - c[PJ]) ** 2).sum(1))
    m = len(PI)
    Aub = np.zeros((m, n))
    Aub[np.arange(m), PI] = 1
    Aub[np.arange(m), PJ] = 1
    wall = np.min([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]], axis=0)
    try:
        res = linprog(-np.ones(n), A_ub=Aub, b_ub=d,
                      bounds=[(0, max(w, 0.0)) for w in wall], method='highs')
        if res.status == 0:
            return repair(c, res.x)
    except Exception:
        pass
    return repair(c, np.full(n, 0.01))


def hole_value(P, c, r):
    """Largest empty-circle radius at points P given circles (c, r)."""
    wall = np.min([P[:, 0], P[:, 1], 1 - P[:, 0], 1 - P[:, 1]], axis=0)
    if len(c) == 0:
        return wall
    d = np.sqrt(((P[:, None, :] - c[None, :, :]) ** 2).sum(-1)) - r[None, :]
    return np.minimum(wall, d.min(axis=1))


def find_holes(c, r, rng, k=3):
    g = np.linspace(0.005, 0.995, 70)
    X, Y = np.meshgrid(g, g)
    P = np.vstack([np.stack([X.ravel(), Y.ravel()], 1), rng.uniform(0, 1, (1500, 2))])
    v = hole_value(P, c, r)
    order = np.argsort(-v)
    out = []
    for idx in order:
        p = P[idx]
        if all(np.linalg.norm(p - q) > 0.03 for q, _ in out):
            # local refinement
            best_p, best_v = p, v[idx]
            step = 0.02
            for _ in range(4):
                Q = best_p + rng.normal(0, step, (200, 2))
                Q = np.clip(Q, 0, 1)
                vq = hole_value(Q, c, r)
                j = np.argmax(vq)
                if vq[j] > best_v:
                    best_p, best_v = Q[j], vq[j]
                step *= 0.5
            out.append((best_p.copy(), best_v))
            if len(out) >= k:
                break
    return out


def solve(n=26):
    t0 = time.time()
    T_SYM = 110.0
    T_END = 268.0
    rng = np.random.default_rng(12345)

    configs = []
    for kind in ('vert', 'diag'):
        for m in (0, 2, 4, 6):
            if (n - m) % 2 == 0 and n - m >= 0:
                try:
                    configs.append((kind, m, build(n, kind, m, rng)))
                except Exception:
                    pass

    sym_results = []
    best = (-1.0, None, None)

    def consider(c, r):
        nonlocal best
        rr = repair(c, r)
        s = rr.sum()
        if s > best[0]:
            best = (s, np.clip(c, 0, 1).copy(), rr.copy())
        return s, rr

    it = 0
    while time.time() - t0 < T_SYM and configs:
        kind, m, P = configs[it % len(configs)]
        it += 1
        z0 = P.random_z(rng)
        z = P.solve(z0)
        c, r = P.full(z)
        s, rr = consider(c, r)
        sym_results.append((s, c, rr))

    F = build(n, 'full', 0, rng)

    def to_z(c, r):
        return np.concatenate([c[:, 0], c[:, 1], r])

    def polish(c, r):
        z = F.solve(to_z(np.clip(c, 0, 1), np.maximum(r, 0)))
        cc, rr = F.full(z)
        cc = np.clip(cc, 0, 1)
        s, rr2 = consider(cc, rr)
        return s, cc, rr2

    sym_results.sort(key=lambda t: -t[0])
    tops = []
    for s, c, r in sym_results:
        if all(abs(s - t[0]) > 1e-6 for t in tops):
            tops.append((s, c, r))
        if len(tops) >= 10:
            break

    if best[1] is None:
        z = F.solve(F.random_z(rng))
        c, r = F.full(z)
        consider(c, r)

    for s, c, r in tops:
        if time.time() - t0 > T_END:
            break
        polish(c, r)

    # ---------- topology-aware Metropolis search ----------
    def move_reinsert(c, r):
        c = c.copy(); r = r.copy()
        nrem = 1 if rng.random() < 0.65 else 2
        order = np.argsort(r)
        rem = []
        for _ in range(nrem):
            if rng.random() < 0.7:
                cand = [i for i in order[:8] if i not in rem]
            else:
                cand = [i for i in range(n) if i not in rem]
            if rem and rng.random() < 0.5:
                # pick a contact-graph neighbour of a removed one
                i0 = rem[0]
                dd = np.linalg.norm(c - c[i0], axis=1) - r - r[i0]
                nb = [j for j in np.argsort(dd)[1:6] if j not in rem]
                if nb:
                    cand = nb
            rem.append(int(rng.choice(cand)))
        keep = np.array([i for i in range(n) if i not in rem])
        cc, rk = c[keep], r[keep]
        for i in rem:
            holes = find_holes(cc, rk, rng, k=3)
            w = np.array([h[1] for h in holes]) ** 2 + 1e-12
            j = rng.choice(len(holes), p=w / w.sum()) if rng.random() < 0.4 else 0
            p, val = holes[j]
            c[i] = p
            r[i] = max(val, 0.0)
            cc = np.vstack([cc, p[None, :]])
            rk = np.append(rk, r[i])
        return c

    def move_exchange(c, r):
        c = c.copy()
        big = np.argsort(-r)[:8]
        L = int(rng.choice(big))
        small = np.argsort(r)[:12]
        pairs = []
        for a in small:
            for b in small:
                if a < b and a != L and b != L:
                    gap = np.linalg.norm(c[a] - c[b]) - r[a] - r[b]
                    if gap < 2e-3:
                        pairs.append((a, b))
        if pairs:
            a, b = pairs[rng.integers(len(pairs))]
        else:
            a, b = [int(x) for x in np.argsort(r)[:2] if x != L][:2]
        cL = c[L].copy()
        mid = 0.5 * (c[a] + c[b])
        ang = rng.uniform(0, 2 * np.pi)
        u = np.array([np.cos(ang), np.sin(ang)])
        off = 0.5 * r[L]
        c[L] = mid
        c[a] = cL + off * u
        c[b] = cL - off * u
        return np.clip(c, 0.0, 1.0)

    def move_shake(c, r):
        c = c.copy()
        sig = rng.choice([0.01, 0.03])
        mask = rng.random(n) < 0.3
        c[mask] += rng.normal(0, sig, (mask.sum(), 2))
        return np.clip(c, 0.01, 0.99)

    T = 1e-4
    cur_s, cur_c, cur_r = best[0], best[1].copy(), best[2].copy()
    since_best = 0
    while time.time() - t0 < T_END and best[1] is not None:
        u = rng.random()
        try:
            if u < 0.5:
                c_new = move_reinsert(cur_c, cur_r)
            elif u < 0.85:
                c_new = move_exchange(cur_c, cur_r)
            else:
                c_new = move_shake(cur_c, cur_r)
            c_new = c_new + rng.normal(0, 1e-4, c_new.shape)
            c_new = np.clip(c_new, 0.0, 1.0)
            r_new = lp_radii(c_new)
            s, cc, rr = polish(c_new, r_new)
        except Exception:
            continue
        prev_best = best[0]
        if s > cur_s or rng.random() < np.exp((s - cur_s) / T):
            cur_s, cur_c, cur_r = s, cc, rr
        if best[0] > prev_best + 1e-9:
            since_best = 0
        else:
            since_best += 1
        if since_best > 60:
            cur_s, cur_c, cur_r = best[0], best[1].copy(), best[2].copy()
            since_best = 0

    centers = np.clip(best[1], 0.0, 1.0)
    radii = repair(centers, best[2])
    return centers, radii
# EVOLVE-BLOCK-END
