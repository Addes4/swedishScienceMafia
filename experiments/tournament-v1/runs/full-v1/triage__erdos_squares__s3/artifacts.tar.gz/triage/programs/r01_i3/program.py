# EVOLVE-BLOCK-START
"""Grid-layout simulated annealing + LP rebalancing with fixed separation relations."""
import math
import random
import time
import numpy as np
from scipy.optimize import linprog


def _lp(sq):
    """sq: list of (x,y,s) ints. Returns (value, array of (x,y,s)) or (-1, None)."""
    k = len(sq)
    if k == 0:
        return 0.0, np.zeros((0, 3))
    rows = []
    for a in range(k):
        xa, ya, sa = sq[a]
        for b in range(a + 1, k):
            xb, yb, sb = sq[b]
            gx1 = xb - xa - sa  # a left of b
            gx2 = xa - xb - sb  # b left of a
            gy1 = yb - ya - sa
            gy2 = ya - yb - sb
            gx = max(gx1, gx2)
            gy = max(gy1, gy2)
            if gx >= gy:
                if gx1 >= gx2:
                    rows.append((0, a, b))
                else:
                    rows.append((0, b, a))
            else:
                if gy1 >= gy2:
                    rows.append((1, a, b))
                else:
                    rows.append((1, b, a))
    m = len(rows)
    A = np.zeros((m + 2 * k, 3 * k))
    bvec = np.zeros(m + 2 * k)
    # variables: x_i (0..k-1), y_i (k..2k-1), s_i (2k..3k-1)
    for r, (ax, a, b) in enumerate(rows):
        o = ax * k
        A[r, o + a] = 1.0
        A[r, 2 * k + a] = 1.0
        A[r, o + b] = -1.0
    for i in range(k):
        A[m + i, i] = 1.0
        A[m + i, 2 * k + i] = 1.0
        bvec[m + i] = 1.0
        A[m + k + i, k + i] = 1.0
        A[m + k + i, 2 * k + i] = 1.0
        bvec[m + k + i] = 1.0
    c = np.zeros(3 * k)
    c[2 * k:] = -1.0
    try:
        res = linprog(c, A_ub=A, b_ub=bvec, bounds=[(0, 1)] * (3 * k), method="highs")
    except Exception:
        return -1.0, None
    if res.status != 0:
        return -1.0, None
    v = res.x
    out = np.stack([v[:k], v[k:2 * k], v[2 * k:]], axis=1)
    return float(-res.fun), out


def _overlap(a, b):
    return a[0] < b[0] + b[2] and b[0] < a[0] + a[2] and a[1] < b[1] + b[2] and b[1] < a[1] + a[2]


def _free_cells(sq, m):
    occ = [[False] * m for _ in range(m)]
    for (x, y, s) in sq:
        for i in range(x, x + s):
            for j in range(y, y + s):
                occ[i][j] = True
    return [(i, j) for i in range(m) for j in range(m) if not occ[i][j]]


def _anneal(n, m, tlimit, rng, best_global):
    cells = [(i % m, i // m, 1) for i in range(min(n, m * m))]
    cur = cells
    cv, csol = _lp(cur)
    cache = {}
    best_v, best_sol = cv, csol
    t0 = time.time()
    while True:
        el = time.time() - t0
        if el > tlimit:
            break
        frac = el / tlimit
        T = 0.04 * (1 - frac) + 0.002
        new = list(cur)
        r = rng.random()
        if r < 0.5:
            s = rng.choice([1, 1, 2, 2, 3, 4, 5, 6][:max(1, 8)])
            s = min(s, m)
            x = rng.randint(0, m - s)
            y = rng.randint(0, m - s)
            rect = (x, y, s)
            new = [q for q in new if not _overlap(q, rect)]
            new.append(rect)
            if len(new) > n:
                continue
            if rng.random() < 0.5:
                fr = _free_cells(new, m)
                rng.shuffle(fr)
                for (i, j) in fr:
                    if len(new) >= n:
                        break
                    new.append((i, j, 1))
        elif r < 0.7:
            if not new:
                continue
            new.pop(rng.randrange(len(new)))
        else:
            fr = _free_cells(new, m)
            if not fr:
                continue
            if len(new) >= n:
                if not new:
                    continue
                new.pop(rng.randrange(len(new)))
                fr = _free_cells(new, m)
                if not fr:
                    continue
            i, j = rng.choice(fr)
            new.append((i, j, 1))
        key = frozenset(new)
        if key in cache:
            nv = cache[key]
            nsol = None
        else:
            nv, nsol = _lp(new)
            cache[key] = nv
        if nv < 0:
            continue
        if nv >= cv or rng.random() < math.exp((nv - cv) / T):
            if nsol is None:
                nv, nsol = _lp(new)
                if nv < 0:
                    continue
            cur, cv, csol = new, nv, nsol
            if cv > best_v:
                best_v, best_sol = cv, csol
    return best_v, best_sol


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    start = time.time()
    rng = random.Random(12345 + n)
    k = math.isqrt(n)
    # fallback grid
    side = 1.0 / k
    best_v = k * k * side
    best_sol = np.array([[i * side, j * side, side] for i in range(k) for j in range(k)])

    m0 = math.isqrt(n)
    if m0 * m0 < n:
        m0 += 1
    ms = [m0, m0 + 1, m0 + 2]
    total = 24.0
    for idx, m in enumerate(ms):
        remain = total - (time.time() - start)
        if remain <= 0.5:
            break
        tl = remain / (len(ms) - idx)
        v, sol = _anneal(n, m, tl, rng, best_v)
        if sol is not None and v > best_v:
            best_v, best_sol = v, sol

    eps = 2e-9
    out = []
    for (x, y, s) in best_sol:
        if s <= 2 * eps:
            continue
        s2 = s - eps * 2
        cx = x + s / 2
        cy = y + s / 2
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        out.append((float(cx), float(cy), 0.0, float(min(max(s2, 0.0), 1.0))))
    out = out[:n]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END
