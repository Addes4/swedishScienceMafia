# EVOLVE-BLOCK-START
"""Merged-block grid family: m x m grid with up to two corner blocks merged
into single big squares, extra cells discarded / zero squares added."""
import math


def _build(n, m, a, b):
    s = 1.0 / m
    squares = []
    # big block a x a at bottom-left
    if a >= 1:
        squares.append((a * s / 2.0, a * s / 2.0, 0.0, a * s))
    # big block b x b at top-right
    if b >= 1:
        squares.append((1.0 - b * s / 2.0, 1.0 - b * s / 2.0, 0.0, b * s))
    for i in range(m):
        for j in range(m):
            if a >= 1 and i < a and j < a:
                continue
            if b >= 1 and i >= m - b and j >= m - b:
                continue
            if len(squares) >= n:
                break
            squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.0, 0.0, 0.0, 0.0))
    return squares


def solve(n):
    if n <= 0:
        return []
    best = None
    best_val = -1.0
    r = max(1, math.isqrt(n))
    mmax = 2 * r + 6
    for m in range(1, mmax + 1):
        for a in range(1, m + 1):
            for b in range(0, m - a + 1):
                nbig = 1 + (1 if b >= 1 else 0)
                if nbig > n:
                    continue
                small = m * m - a * a - b * b
                kept = min(small, n - nbig)
                val = (a + b + kept) / m
                if val > best_val + 1e-12:
                    best_val = val
                    best = (m, a, b)
    m, a, b = best
    return _build(n, m, a, b)
# EVOLVE-BLOCK-END
