# EVOLVE-BLOCK-START
"""Exact memoized search over tilings of an m x m grid by integer squares
(holes allowed), maximising sum of sides with at most n pieces."""
import math
import sys
import time


class _Timeout(Exception):
    pass


def _search(m, n, deadline):
    memo = {}
    calls = [0]

    def f(h, k, A):
        if A == 0 or k == 0:
            return 0
        if k >= A:
            return A
        key = (h, k)
        v = memo.get(key)
        if v is not None:
            return v
        calls[0] += 1
        if (calls[0] & 4095) == 0 and time.monotonic() > deadline:
            raise _Timeout()
        hm = min(h)
        c = h.index(hm)
        best = -1
        # place squares (largest first for good values)
        smax = 0
        while c + smax < m and h[c + smax] == hm and hm + smax + 1 <= m:
            smax += 1
        for s in range(smax, 0, -1):
            # bound check
            ub = s + min(A - s * s, math.sqrt((k - 1) * (A - s * s)))
            if ub <= best:
                continue
            nh = h[:c] + (hm + s,) * s + h[c + s:]
            val = s + f(nh, k - 1, A - s * s)
            if val > best:
                best = val
        # empty cell
        ub = min(A - 1, math.sqrt(k * (A - 1)))
        if ub > best:
            nh = h[:c] + (hm + 1,) + h[c + 1:]
            val = f(nh, k, A - 1)
            if val > best:
                best = val
        memo[key] = best
        return best

    h0 = (0,) * m
    total = f(h0, n, m * m)

    # reconstruct
    squares = []
    h, k, A = h0, n, m * m
    while A > 0 and k > 0:
        target = f(h, k, A)
        if target == 0:
            break
        if k >= A:
            # fill all remaining cells with unit squares
            for col in range(m):
                for row in range(h[col], m):
                    squares.append(((col + 0.5) / m, (row + 0.5) / m, 0.0, 1.0 / m))
            break
        hm = min(h)
        c = h.index(hm)
        smax = 0
        while c + smax < m and h[c + smax] == hm and hm + smax + 1 <= m:
            smax += 1
        done = False
        for s in range(smax, 0, -1):
            nh = h[:c] + (hm + s,) * s + h[c + s:]
            if s + f(nh, k - 1, A - s * s) == target:
                squares.append(((c + s / 2.0) / m, (hm + s / 2.0) / m, 0.0, s / m))
                h, k, A = nh, k - 1, A - s * s
                done = True
                break
        if not done:
            nh = h[:c] + (hm + 1,) + h[c + 1:]
            h, A = nh, A - 1
    return total, squares


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    sys.setrecursionlimit(10000)
    start = time.monotonic()
    deadline = start + 50.0
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    best_val = float(k)
    best_sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    m = 1
    while m <= 30 and time.monotonic() < deadline:
        try:
            total, sq = _search(m, n, deadline)
        except _Timeout:
            break
        val = total / m
        if val > best_val + 1e-12 and len(sq) <= n:
            best_val = val
            best_sq = sq
        m += 1
    best_sq = [tuple(min(1.0, max(0.0, x)) for x in s) for s in best_sq]
    best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))
    return best_sq[:n]
# EVOLVE-BLOCK-END
