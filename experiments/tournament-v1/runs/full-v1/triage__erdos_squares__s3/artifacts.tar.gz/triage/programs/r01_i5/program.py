import math
import numpy as np
from scipy.optimize import minimize

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    
    # Start with best axis-aligned grid layout
    k = math.isqrt(n)
    side = 1.0 / k
    initial_squares = []
    for i in range(k):
        for j in range(k):
            if len(initial_squares) < n:
                initial_squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    
    # Fill remaining with zero-size squares at random positions
    np.random.seed(42)
    while len(initial_squares) < n:
        x = np.random.uniform(0.1, 0.9)
        y = np.random.uniform(0.1, 0.9)
        initial_squares.append((x, y, np.random.uniform(0, 0.5), 0.0))
    
    initial_squares = initial_squares[:n]
    
    # Convert to flat array for optimization
    def squares_to_array(squares):
        arr = []
        for cx, cy, angle, side in squares:
            arr.extend([cx, cy, angle, side])
        return np.array(arr)
    
    def array_to_squares(arr):
        squares = []
        for i in range(0, len(arr), 4):
            squares.append((arr[i], arr[i+1], arr[i+2], arr[i+3]))
        return squares
    
    def get_square_corners(cx, cy, angle, side):
        """Get corners of rotated square in CCW order from bottom-left."""
        half = side / 2
        rad = angle * 2 * math.pi
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        
        corners = [
            (-half, -half), (half, -half), (half, half), (-half, half)
        ]
        rotated = []
        for dx, dy in corners:
            rx = dx * cos_a - dy * sin_a + cx
            ry = dx * sin_a + dy * cos_a + cy
            rotated.append((rx, ry))
        return rotated
    
    def separating_axis_penetration(sq1, sq2):
        """Compute penetration depth using SAT, negative if separated."""
        cx1, cy1, angle1, side1 = sq1
        cx2, cy2, angle2, side2 = sq2
        
        corners1 = get_square_corners(cx1, cy1, angle1, side1)
        corners2 = get_square_corners(cx2, cy2, angle2, side2)
        
        def project_polygon(corners, axis):
            dots = [c[0] * axis[0] + c[1] * axis[1] for c in corners]
            return min(dots), max(dots)
        
        def get_axes(corners):
            axes = []
            for i in range(4):
                p1 = corners[i]
                p2 = corners[(i + 1) % 4]
                dx, dy = p2[0] - p1[0], p2[1] - p1[1]
                length = math.sqrt(dx*dx + dy*dy)
                if length > 1e-10:
                    axes.append((-dy/length, dx/length))
            return axes
        
        axes = get_axes(corners1) + get_axes(corners2)
        min_penetration = float('inf')
        
        for axis in axes:
            min1, max1 = project_polygon(corners1, axis)
            min2, max2 = project_polygon(corners2, axis)
            
            if max1 < min2 or max2 < min1:
                return -1.0  # Separated
            
            penetration = min(max1 - min2, max2 - min1)
            min_penetration = min(min_penetration, penetration)
        
        return min_penetration if min_penetration > 1e-10 else 0.0
    
    def check_bounds(squares):
        """Penalty for squares outside unit square."""
        penalty = 0.0
        for cx, cy, angle, side in squares:
            half = side / 2
            # Simple AABB check as approximation
            if cx - half < 0 or cx + half > 1:
                penalty += abs(min(cx - half, 0)) + abs(max(cx + half - 1, 0))
            if cy - half < 0 or cy + half > 1:
                penalty += abs(min(cy - half, 0)) + abs(max(cy + half - 1, 0))
        return penalty
    
    def objective(arr):
        squares = array_to_squares(arr)
        
        # Sum of sides (negative because we minimize)
        sum_sides = sum(s[3] for s in squares)
        
        # Overlap penalty
        overlap_penalty = 0.0
        for i in range(len(squares)):
            for j in range(i + 1, len(squares)):
                penetration = separating_axis_penetration(squares[i], squares[j])
                if penetration > 0:
                    overlap_penalty += penetration * penetration * 100
        
        # Bounds penalty
        bounds_penalty = check_bounds(squares) * 50
        
        return -sum_sides + overlap_penalty + bounds_penalty
    
    x0 = squares_to_array(initial_squares)
    
    # Constrain to [0,1] for positions and sides, [0,1] for angle
    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((0.0, 1.0))  # angle
        bounds.append((0.0, 1.0))  # side
    
    # Run optimization with restarts
    best_result = minimize(objective, x0, method='L-BFGS-B', bounds=bounds,
                          options={'maxiter': 500, 'ftol': 1e-8})
    best_arr = best_result.x
    best_val = best_result.fun
    
    # Random restarts
    time_budget = 50  # seconds, conservative
    import time
    start_time = time.time()
    
    for restart in range(10):
        if time.time() - start_time > time_budget:
            break
        
        # Perturb best solution
        x_pert = best_arr.copy()
        for i in range(len(x_pert)):
            if i % 4 == 3:  # side parameter
                x_pert[i] += np.random.normal(0, 0.05)
            else:
                x_pert[i] += np.random.normal(0, 0.02)
        x_pert = np.clip(x_pert, [b[0] for b in bounds], [b[1] for b in bounds])
        
        result = minimize(objective, x_pert, method='L-BFGS-B', bounds=bounds,
                         options={'maxiter': 500, 'ftol': 1e-8})
        
        if result.fun < best_val:
            best_val = result.fun
            best_arr = result.x
    
    return array_to_squares(best_arr)
