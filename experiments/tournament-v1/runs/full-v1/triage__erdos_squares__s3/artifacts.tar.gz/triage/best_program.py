import math
import time
import numpy as np


def _grid(n):
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]


def _run(n, K):
    f = {}
    ch = {}
    idx = np.arange(n + 1)
    for a in range(1, K + 1):
        for b in range(1, K + 1):
            res = np.where(idx >= 1, float(min(a, b)), 0.0)
            ct = np.zeros(n + 1, dtype=np.int8)
            cc = np.zeros(n + 1, dtype=np.int16)
            cm = np.zeros(n + 1, dtype=np.int32)
            for typ in (1, 2):
                dim = a if typ == 1 else b
                for c in range(1, dim // 2 + 1):
                    if typ == 1:
                        k1, k2 = (c, b), (a - c, b)
                    else:
                        k1, k2 = (a, c), (a, b - c)
                    f1 = f[k1]
                    f2 = f[k2]
                    cells1 = k1[0] * k1[1]
                    for m1 in range(0, min(n, cells1) + 1):
                        cand = f1[m1] + f2[:n + 1 - m1]
                        seg = res[m1:]
                        mask = cand > seg + 1e-12
                        if mask.any():
                            seg[mask] = cand[mask]
                            ct[m1:][mask] = typ
                            cc[m1:][mask] = c
                            cm[m1:][mask] = m1
            f[(a, b)] = res
            ch[(a, b)] = (ct, cc, cm)
    return f, ch


def _build(n, K, ch):
    out = []

    def rec(a, b, m, x, y):
        if m <= 0:
            return
        ct, cc, cm = ch[(a, b)]
        t = int(ct[m])
        if t == 0:
            s = min(a, b)
            out.append(((x + s / 2.0) / K, (y + s / 2.0) / K, 0.0, s / K))
            return
        c = int(cc[m])
        m1 = int(cm[m])
        m2 = m - m1
        if t == 1:
            rec(c, b, m1, x, y)
            rec(a - c, b, m2, x + c, y)
        else:
            rec(a, c, m1, x, y)
            rec(a, b - c, m2, x, y + c)

    rec(K, K, n, 0, 0)
    return out


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n > 200:
        return _grid(n)
    start = time.time()
    best_val = -1.0
    best_sq = None
    last = 0.0
    for K in range(1, 41):
        t0 = time.time()
        if K > 1 and (t0 - start) + last * 1.6 * ((K / (K - 1.0)) ** 3) > 40:
            break
        f, ch = _run(n, K)
        val = f[(K, K)][n] / K
        if val > best_val + 1e-12:
            sq = _build(n, K, ch)
            best_val = val
            best_sq = sq
        last = time.time() - t0
    sq = list(best_sq)
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    res = []
    for (x, y, an, s) in sq[:n]:
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), an, min(1.0, max(0.0, s))))
    return res
