# Research notebook: circle_packing

Ranker `jev`, tiers ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-4-5'], swap rate 0.15, initial score 0.393772.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 2 | Seed the optimiser with the known structure of best 26-circle packings: large circles in the corners and along the edges, a 5x5-like grid of mixed sizes, and on | 0.81 | favourite | opus-5-5 | improved | 0.999359 |
| 0 | Replace the fixed-centre radius shrinking with a joint optimisation over centres and radii. Use scipy.optimize.minimize with SLSQP to maximise sum(r) subject to | 0.79 | favourite | opus-5-5 | improved | 0.998387 |
| 1 | Run a penalty-method gradient optimisation in numpy, maximising sum(r) minus μ·(squared overlap and wall violations) with Adam, increasing μ over time. Use many | 0.76 | middle | opus-5-5 (swapped) | improved | 1.000000 |
| 5 | Use a billiards-style inflation (Lubachevsky–Stillinger-like) where circles start tiny with per-circle growth weights and grow while being pushed apart by soft  | 0.75 | middle | sonnet-5-5 | improved | 0.999359 |
| 3 | For any fixed set of centres, compute the optimal radii exactly with a linear program (scipy.optimize.linprog) instead of the multiplicative shrink. Wrap this i | 0.74 | long_shot | haiku-4-5 | invalid | 0.000000 |
| 4 | Use a "remove-and-reinsert" iterated local search around a joint-SLSQP optimum. Repeatedly delete the smallest circle (or the 1–3 smallest), reinsert it at the  | 0.72 | long_shot | haiku-4-5 | invalid | 0.000000 |

Best after round 1: **1.000000** (spent $0.43)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Add a final high-precision KKT polish. Identify the active contacts (gap < 1e-7) of the best solution and solve the resulting square system of equalities with N | 0.38 | favourite | opus-5-5 | not_better | 1.000000 |
| 5 | Replace SLSQP with an augmented-Lagrangian solver that handles only nearby pairs. Use scipy's trust-constr with sparse Jacobians over pairs within distance 0.35 | 0.35 | favourite | opus-5-5 | not_better | 0.997036 |
| 2 | Replace the uniform-random restarts with symmetry-constrained restarts. Optimise only configurations invariant under a mirror axis or 180° rotation (parameteris | 0.35 | middle | sonnet-5-5 | not_better | 1.000000 |
| 3 | Use a contact-graph "swap" move in the perturbation phase. Take the best solution and exchange the positions of a large and a small circle (or of two neighbours | 0.34 | middle | opus-5-5 (swapped) | not_better | 1.000000 |
| 4 | Run the Adam penalty stage with a radius-heterogeneity prior. Initialise R from structured distributions: a bimodal mix of roughly 0.13 and 0.09 radii, with a f | 0.34 | long_shot | haiku-4-5 | not_better | 0.999359 |
| 0 | Make the run deterministic and faster to reach the known optimum. Hard-code a seed list of near-optimal 26-circle configurations: the published Packomania-style | 0.33 | long_shot | haiku-4-5 | not_better | 1.000000 |

Best after round 2: **1.000000** (spent $1.03)

