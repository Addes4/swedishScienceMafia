# EVOLVE-BLOCK-START
"""Structured seeds (row patterns, 5x5 grid + gap circle) refined with SLSQP,
followed by basin-hopping perturbations and an LP radius polish."""
import time
import numpy as np
from scipy.optimize import minimize, linprog


def _setup(n):
    I, J = np.triu_indices(n, 1)
    m = len(I)
    # constant wall jacobian
    Wj = np.zeros((4 * n, 3 * n))
    ar = np.arange(n)
    Wj[ar, ar] = 1; Wj[ar, 2 * n + ar] = -1
    Wj[n + ar, ar] = -1; Wj[n + ar, 2 * n + ar] = -1
    Wj[2 * n + ar, n + ar] = 1; Wj[2 * n + ar, 2 * n + ar] = -1
    Wj[3 * n + ar, n + ar] = -1; Wj[3 * n + ar, 2 * n + ar] = -1
    rows = np.arange(m)

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[I] - x[J]; dy = y[I] - y[J]; s = r[I] + r[J]
        return np.concatenate([x - r, 1 - x - r, y - r, 1 - y - r,
                               dx * dx + dy * dy - s * s])

    def jac(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[I] - x[J]; dy = y[I] - y[J]; s = r[I] + r[J]
        P = np.zeros((m, 3 * n))
        P[rows, I] = 2 * dx; P[rows, J] = -2 * dx
        P[rows, n + I] = 2 * dy; P[rows, n + J] = -2 * dy
        P[rows, 2 * n + I] = -2 * s; P[rows, 2 * n + J] = -2 * s
        return np.vstack([Wj, P])

    return I, J, cons, jac


def _lp_radii(c, I, J):
    n = len(c)
    wall = np.minimum.reduce([c[:, 0], c[:, 1], 1 - c[:, 0], 1 - c[:, 1]])
    wall = np.maximum(wall, 0)
    d = np.sqrt(((c[I] - c[J]) ** 2).sum(1))
    m = len(I)
    A = np.zeros((m, n))
    A[np.arange(m), I] = 1; A[np.arange(m), J] = 1
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d,
                      bounds=list(zip(np.zeros(n), wall)), method="highs")
        if res.status == 0:
            r = np.maximum(res.x - 1e-12, 0)
        else:
            r = None
    except Exception:
        r = None
    if r is None:
        r = wall.copy()
    # final safety repair
    for _ in range(100):
        bad = False
        for k in range(m):
            i, j = I[k], J[k]
            if r[i] + r[j] > d[k]:
                sc = d[k] / (r[i] + r[j]) * (1 - 1e-12)
                r[i] *= sc; r[j] *= sc; bad = True
        if not bad:
            break
    r = np.minimum(r, wall)
    return np.maximum(r, 0)


def _rows_seed(counts, offset=False, rng=None):
    R = len(counts)
    pts = []
    for k, c in enumerate(counts):
        y = (k + 0.5) / R
        sh = 0.0
        if offset:
            sh = (0.25 / c) * (1 if k % 2 == 0 else -1)
        for i in range(c):
            x = (i + 0.5) / c + sh
            pts.append([x, y])
    return np.clip(np.array(pts), 0.02, 0.98)


def _grid_plus_gap(gap_idx):
    pts = [[(i + 0.5) / 5, (j + 0.5) / 5] for j in range(5) for i in range(5)]
    gx, gy = gap_idx % 4, gap_idx // 4
    pts.append([(gx + 1) / 5, (gy + 1) / 5])
    return np.array(pts)


def solve(n=26):
    t0 = time.time()
    budget = 240.0
    rng = np.random.default_rng(12345)
    I, J, cons, jac = _setup(n)

    def obj(z):
        return -z[2 * n:].sum()

    gobj = np.concatenate([np.zeros(2 * n), -np.ones(n)])

    def ojac(z):
        return gobj

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n

    def run(c, r0=None, maxiter=400):
        c = np.clip(c, 0.01, 0.99)
        if r0 is None:
            r0 = np.full(n, 0.04)
        z0 = np.concatenate([c[:, 0], c[:, 1], r0])
        try:
            res = minimize(obj, z0, jac=ojac, method="SLSQP", bounds=bounds,
                           constraints=[{"type": "ineq", "fun": cons, "jac": jac}],
                           options={"maxiter": maxiter, "ftol": 1e-12})
            z = res.x
        except Exception:
            return None, -1
        cc = np.stack([z[:n], z[n:2 * n]], 1)
        cc = np.clip(cc, 0, 1)
        r = _lp_radii(cc, I, J)
        return (cc, r), r.sum()

    best, best_s = None, -1
    pool = []

    def consider(sol, s):
        nonlocal best, best_s
        if sol is None:
            return
        pool.append((s, sol))
        if s > best_s:
            best, best_s = sol, s

    seeds = []
    if n == 26:
        for counts in ([5, 5, 6, 5, 5], [6, 5, 5, 5, 5], [5, 6, 5, 5, 5], [5, 5, 5, 6, 5]):
            for off in (False, True):
                seeds.append(_rows_seed(counts, off))
        for g in range(16):
            seeds.append(_grid_plus_gap(g))
    # generic hex-ish seeds
    for counts in ([4, 5, 4, 5, 4, 4],):
        if sum(counts) == n:
            seeds.append(_rows_seed(counts, True))

    # structured seeds, each with a few perturbations
    for s in seeds:
        for p in range(3):
            if time.time() - t0 > budget * 0.5:
                break
            c = s + (0 if p == 0 else rng.normal(0, 0.02 * p, s.shape))
            r0 = np.full(n, 0.5 / 6) * rng.uniform(0.6, 1.0, n)
            consider(*run(c, r0))

    # random seeds while time allows (a few)
    for _ in range(10):
        if time.time() - t0 > budget * 0.55:
            break
        k = int(np.ceil(np.sqrt(n)))
        g = np.array([[(i + 0.5) / k, (j + 0.5) / k] for j in range(k) for i in range(k)])
        idx = rng.permutation(len(g))[:n]
        c = g[idx] + rng.normal(0, 0.03, (n, 2))
        consider(*run(c, np.full(n, 0.05)))
        consider(*run(rng.uniform(0.1, 0.9, (n, 2)), np.full(n, 0.03)))

    # basin hopping from top solutions
    while time.time() - t0 < budget and best is not None:
        pool.sort(key=lambda t: -t[0])
        pool = pool[:8]
        if rng.random() < 0.6:
            base = best
        else:
            base = pool[rng.integers(len(pool))][1]
        c, r = base
        c = c.copy(); r = r.copy()
        mode = rng.random()
        if mode < 0.5:
            c += rng.normal(0, rng.choice([0.005, 0.01, 0.03]), c.shape)
        elif mode < 0.8:
            # relocate smallest circle(s)
            k = rng.integers(1, 3)
            idx = np.argsort(r)[:k]
            c[idx] = rng.uniform(0.05, 0.95, (k, 2))
            r[idx] = 0.01
            c += rng.normal(0, 0.003, c.shape)
        else:
            i, j = rng.choice(n, 2, replace=False)
            c[[i, j]] = c[[j, i]]
            c += rng.normal(0, 0.003, c.shape)
        consider(*run(c, r * 0.95))

    if best is None:
        c = _grid_plus_gap(0) if n == 26 else rng.uniform(0.1, 0.9, (n, 2))
        return c, _lp_radii(c, I, J)
    return best
# EVOLVE-BLOCK-END
