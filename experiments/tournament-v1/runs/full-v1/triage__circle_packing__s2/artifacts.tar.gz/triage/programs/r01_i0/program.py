# EVOLVE-BLOCK-START
"""Joint optimisation of centres and radii with SLSQP from multiple starts."""
import time
import numpy as np
from scipy.optimize import minimize, linprog


def _pairs(n):
    I, J = np.triu_indices(n, 1)
    return I, J


def _make_problem(n):
    I, J = _pairs(n)
    m = len(I)
    rows = np.arange(m)
    # wall constraint jacobian (constant)
    Jw = np.zeros((4 * n, 3 * n))
    for k in range(n):
        # x - r >= 0
        Jw[k, k] = 1.0; Jw[k, 2 * n + k] = -1.0
        # 1 - x - r >= 0
        Jw[n + k, k] = -1.0; Jw[n + k, 2 * n + k] = -1.0
        # y - r >= 0
        Jw[2 * n + k, n + k] = 1.0; Jw[2 * n + k, 2 * n + k] = -1.0
        # 1 - y - r >= 0
        Jw[3 * n + k, n + k] = -1.0; Jw[3 * n + k, 2 * n + k] = -1.0

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        wall = np.concatenate([x - r, 1 - x - r, y - r, 1 - y - r])
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        s = r[I] + r[J]
        pair = dx * dx + dy * dy - s * s
        return np.concatenate([wall, pair])

    def cons_jac(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        s = r[I] + r[J]
        Jp = np.zeros((m, 3 * n))
        Jp[rows, I] = 2 * dx
        Jp[rows, J] = -2 * dx
        Jp[rows, n + I] = 2 * dy
        Jp[rows, n + J] = -2 * dy
        Jp[rows, 2 * n + I] = -2 * s
        Jp[rows, 2 * n + J] = -2 * s
        return np.vstack([Jw, Jp])

    def obj(z):
        return -np.sum(z[2 * n:])

    g = np.zeros(3 * n)
    g[2 * n:] = -1.0

    def obj_jac(z):
        return g

    return obj, obj_jac, cons, cons_jac


def _optimize(centers, r0, prob, n, maxiter=400):
    obj, obj_jac, cons, cons_jac = prob
    z0 = np.concatenate([centers[:, 0], centers[:, 1], r0])
    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 0.5)] * n
    try:
        res = minimize(obj, z0, jac=obj_jac, method="SLSQP", bounds=bounds,
                       constraints=[{"type": "ineq", "fun": cons, "jac": cons_jac}],
                       options={"maxiter": maxiter, "ftol": 1e-12})
        z = res.x
    except Exception:
        return None
    c = np.stack([z[:n], z[n:2 * n]], axis=1)
    return np.clip(c, 0.0, 1.0)


def _lp_radii(centers):
    n = len(centers)
    I, J = _pairs(n)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0.0)
    A = np.zeros((len(I), n))
    A[np.arange(len(I)), I] = 1.0
    A[np.arange(len(I)), J] = 1.0
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=list(zip([0.0] * n, wall)), method="highs")
        if res.status != 0:
            return max_radii(centers)
        r = np.maximum(res.x - 1e-10, 0.0)
    except Exception:
        return max_radii(centers)
    return _make_safe(centers, r)


def _make_safe(centers, r):
    n = len(centers)
    r = r.copy()
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    r = np.minimum(r, np.maximum(wall, 0.0))
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if r[i] + r[j] > d:
                    if r[i] + r[j] > 0:
                        sc = d / (r[i] + r[j]) * (1 - 1e-12)
                        r[i] *= sc
                        r[j] *= sc
                    changed = True
        if not changed:
            break
    return np.maximum(r, 0.0)


def _row_layout(counts, rng=None, jitter=0.0):
    pts = []
    nr = len(counts)
    for k, c in enumerate(counts):
        y = (k + 0.5) / nr
        off = 0.0 if k % 2 == 0 else 0.5 / c * 0.5
        for i in range(c):
            x = (i + 0.5) / c + (off if c > 1 else 0)
            pts.append([x, y])
    pts = np.array(pts)
    if rng is not None and jitter > 0:
        pts += rng.normal(0, jitter, pts.shape)
    return np.clip(pts, 0.03, 0.97)


def _ring_layout(n, k1, rad1, rad2, rot, rng=None, jitter=0.0):
    pts = [[0.5, 0.5]]
    pts += [[0.5 + rad1 * np.cos(2 * np.pi * i / k1 + rot), 0.5 + rad1 * np.sin(2 * np.pi * i / k1 + rot)]
            for i in range(k1)]
    k2 = n - 1 - k1
    pts += [[0.5 + rad2 * np.cos(2 * np.pi * i / k2), 0.5 + rad2 * np.sin(2 * np.pi * i / k2)]
            for i in range(k2)]
    pts = np.array(pts)
    if rng is not None and jitter > 0:
        pts += rng.normal(0, jitter, pts.shape)
    return np.clip(pts, 0.03, 0.97)


def solve(n=26):
    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(12345)
    prob = _make_problem(n)

    best_c, best_r, best_s = None, None, -1.0

    def evaluate(c0, r0):
        nonlocal best_c, best_r, best_s
        c = _optimize(c0, r0, prob, n)
        if c is None or not np.all(np.isfinite(c)):
            return None
        r = _lp_radii(c)
        s = r.sum()
        if s > best_s:
            best_c, best_r, best_s = c.copy(), r.copy(), s
        return s

    starts = []
    for counts in ([5, 5, 6, 5, 5], [5, 6, 5, 6, 4], [6, 5, 5, 5, 5], [4, 5, 4, 5, 4, 4],
                   [5, 5, 5, 5, 6], [6, 5, 4, 5, 6], [5, 4, 5, 4, 4, 4]):
        if sum(counts) == n:
            starts.append(_row_layout(counts))
            starts.append(_row_layout(counts, rng, 0.02))
    for k1 in (6, 7, 8, 9):
        for rad2 in (0.38, 0.42):
            starts.append(_ring_layout(n, k1, 0.22, rad2, 0.0, rng, 0.01))
    g = np.linspace(0.1, 0.9, 5)
    grid = np.array([[a, b] for a in g for b in g])
    for _ in range(4):
        extra = rng.uniform(0.1, 0.9, (n - 25, 2))
        starts.append(np.clip(np.vstack([grid, extra]) + rng.normal(0, 0.03, (n, 2)), 0.03, 0.97))

    for c0 in starts:
        if len(c0) != n:
            continue
        if time.time() - t0 > budget:
            break
        evaluate(c0, np.full(n, 0.05))

    # basin hopping / random restarts
    it = 0
    while time.time() - t0 < budget:
        it += 1
        if best_c is not None and it % 3 != 0:
            c0 = best_c.copy()
            sigma = rng.choice([0.02, 0.05, 0.1])
            k = rng.integers(1, n + 1)
            idx = rng.choice(n, k, replace=False)
            c0[idx] += rng.normal(0, sigma, (k, 2))
            # occasionally relocate a small circle
            if rng.random() < 0.5:
                j = int(np.argmin(best_r))
                c0[j] = rng.uniform(0.05, 0.95, 2)
            c0 = np.clip(c0, 0.02, 0.98)
            r0 = np.maximum(best_r * 0.9, 0.01)
        else:
            c0 = rng.uniform(0.05, 0.95, (n, 2))
            r0 = np.full(n, 0.05)
        evaluate(c0, r0)

    if best_c is None:
        best_c = _row_layout([5, 5, 6, 5, 5])
        best_r = max_radii(best_c)
    best_r = _make_safe(best_c, best_r)
    return best_c, best_r


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)
# EVOLVE-BLOCK-END
