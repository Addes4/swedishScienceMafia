import time
import numpy as np
from scipy.optimize import minimize, linprog

# EVOLVE-BLOCK-START
"""Billiards-style (Lubachevsky-Stillinger-like) soft inflation with random growth weights,
followed by SLSQP refinement with analytic Jacobians, then basin hopping on the best."""


def _lp_radii(centers):
    n = len(centers)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    m = len(I)
    A = np.zeros((m, n))
    A[np.arange(m), I] = 1
    A[np.arange(m), J] = 1
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0)
    res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=[(0, w) for w in wall], method="highs")
    if res.status == 0:
        return np.maximum(res.x - 1e-12, 0)
    return np.zeros(n)


def _inflate(w, rng, iters=1500):
    n = len(w)
    pos = rng.uniform(0.1, 0.9, (n, 2))
    s = 0.01
    I, J = np.triu_indices(n, 1)
    growth = 1.01
    for it in range(iters):
        r = s * w
        for _ in range(3):
            diff = pos[I] - pos[J]
            dist = np.sqrt((diff ** 2).sum(1)) + 1e-12
            ov = r[I] + r[J] - dist
            mask = ov > 0
            if not mask.any():
                break
            u = diff[mask] / dist[mask, None]
            push = 0.5 * ov[mask, None] * u * 1.0
            np.add.at(pos, I[mask], push)
            np.add.at(pos, J[mask], -push)
            pos = np.clip(pos, r[:, None], 1 - r[:, None])
        diff = pos[I] - pos[J]
        dist = np.sqrt((diff ** 2).sum(1))
        mo = (r[I] + r[J] - dist).max()
        if mo < 1e-6:
            s *= growth
        else:
            s *= 0.9995
            growth = 1 + (growth - 1) * 0.995
    return pos


def _slsqp(centers, radii, n, maxiter=300):
    I, J = np.triu_indices(n, 1)
    m = len(I)
    ar = np.arange(m)
    an = np.arange(n)
    # linear wall constraints: x-r, 1-x-r, y-r, 1-y-r
    Jw = np.zeros((4 * n, 3 * n))
    Jw[an, an] = 1; Jw[an, 2 * n + an] = -1
    Jw[n + an, an] = -1; Jw[n + an, 2 * n + an] = -1
    Jw[2 * n + an, n + an] = 1; Jw[2 * n + an, 2 * n + an] = -1
    Jw[3 * n + an, n + an] = -1; Jw[3 * n + an, 2 * n + an] = -1
    cw = np.concatenate([np.zeros(n), np.ones(n), np.zeros(n), np.ones(n)])

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        g = (x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 - (r[I] + r[J]) ** 2
        return np.concatenate([g, Jw @ z + cw])

    def jac(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        Jp = np.zeros((m, 3 * n))
        dx = x[I] - x[J]; dy = y[I] - y[J]; sr = r[I] + r[J]
        Jp[ar, I] = 2 * dx; Jp[ar, J] = -2 * dx
        Jp[ar, n + I] = 2 * dy; Jp[ar, n + J] = -2 * dy
        Jp[ar, 2 * n + I] = -2 * sr; Jp[ar, 2 * n + J] = -2 * sr
        return np.vstack([Jp, Jw])

    g0 = np.zeros(3 * n); g0[2 * n:] = -1
    z0 = np.concatenate([centers[:, 0], centers[:, 1], radii])
    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(lambda z: -z[2 * n:].sum(), z0, jac=lambda z: g0, method="SLSQP",
                       bounds=bounds, constraints=[{"type": "ineq", "fun": cons, "jac": jac}],
                       options={"maxiter": maxiter, "ftol": 1e-12})
        z = res.x
    except Exception:
        z = z0
    c = np.clip(np.stack([z[:n], z[n:2 * n]], 1), 0, 1)
    return c


def solve(n=26):
    t0 = time.time()
    budget = 230.0
    rng = np.random.default_rng(12345)
    best = (-1.0, None, None)

    def consider(c):
        nonlocal best
        r = _lp_radii(c)
        sc = r.sum()
        if sc > best[0]:
            best = (sc, c.copy(), r.copy())
        return sc

    # fallback
    consider(rng.uniform(0.1, 0.9, (n, 2)))
    last = 0.0
    k = 0
    while time.time() - t0 < budget * 0.6:
        t1 = time.time()
        mode = k % 3
        if mode == 0:
            w = rng.uniform(0.5, 1.5, n)
        elif mode == 1:
            w = np.exp(rng.normal(0, 0.35, n))
        else:
            w = np.ones(n)
            idx = rng.choice(n, rng.integers(3, 9), replace=False)
            w[idx] = rng.uniform(1.4, 2.0, len(idx))
            w *= rng.uniform(0.8, 1.2, n)
        pos = _inflate(w, rng)
        r0 = _lp_radii(pos)
        c = _slsqp(pos, r0, n)
        consider(c)
        k += 1
        if time.time() - t1 > budget:
            break

    # basin hopping on best
    while time.time() - t0 < budget:
        c0 = best[1].copy()
        mode = rng.integers(0, 3)
        if mode == 0:
            c0 += rng.normal(0, 0.02, c0.shape)
        elif mode == 1:
            c0 += rng.normal(0, 0.05, c0.shape) * (rng.random((n, 1)) < 0.3)
        else:
            i = rng.integers(0, n)
            c0[i] = rng.uniform(0.05, 0.95, 2)
        c0 = np.clip(c0, 0.01, 0.99)
        r0 = _lp_radii(c0)
        c = _slsqp(c0, r0, n)
        consider(c)

    return best[1], best[2]
# EVOLVE-BLOCK-END
