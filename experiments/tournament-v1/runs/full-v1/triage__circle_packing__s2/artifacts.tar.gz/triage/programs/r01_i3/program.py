import numpy as np
from scipy.optimize import linprog, basinhopping, minimize
import warnings
warnings.filterwarnings('ignore')


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii."""
    
    # Initial layout: center circle with rings
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    centers += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()] for _ in range(n - len(centers))]
    centers = np.clip(np.array(centers[:n]), 0.01, 0.99)
    
    # Optimize centers using basin-hopping with LP-based objective
    def objective(x_flat):
        x = x_flat.reshape((n, 2))
        x = np.clip(x, 0.001, 0.999)
        radii = compute_optimal_radii_lp(x)
        return -np.sum(radii)  # Negative because we minimize
    
    # Basin hopping
    x0 = centers.flatten()
    minimizer_kwargs = {"method": "L-BFGS-B", "bounds": [(0.001, 0.999)] * (2*n)}
    result = basinhopping(objective, x0, minimizer_kwargs=minimizer_kwargs, 
                         niter=40, T=0.1, stepsize=0.01, seed=42)
    
    centers = np.clip(result.x.reshape((n, 2)), 0.001, 0.999)
    
    # Final refinement with SLSQP
    def objective_with_constraint(x_flat):
        x = x_flat.reshape((n, 2))
        x = np.clip(x, 0.001, 0.999)
        radii = compute_optimal_radii_lp(x)
        return -np.sum(radii)
    
    result = minimize(objective_with_constraint, centers.flatten(),
                     method='L-BFGS-B', 
                     bounds=[(0.001, 0.999)] * (2*n),
                     options={'maxiter': 200, 'ftol': 1e-6})
    
    centers = np.clip(result.x.reshape((n, 2)), 0.001, 0.999)
    radii = compute_optimal_radii_lp(centers)
    
    return centers, np.maximum(radii, 0.0)


def compute_optimal_radii_lp(centers):
    """Compute optimal radii for fixed centres using linear programming.
    
    Maximize sum of radii subject to:
    - r_i <= distance to each wall
    - r_i + r_j <= distance between centers i and j
    - r_i >= 0
    """
    n = len(centers)
    
    # Objective: maximize sum of radii = minimize negative sum
    c = np.zeros(n)
    c[:] = -1.0
    
    A_ub = []
    b_ub = []
    
    # Constraints: r_i <= min distance to walls
    wall_dists = np.minimum.reduce([centers[:, 0], centers[:, 1], 
                                     1 - centers[:, 0], 1 - centers[:, 1]])
    for i in range(n):
        a = np.zeros(n)
        a[i] = 1.0
        A_ub.append(a)
        b_ub.append(wall_dists[i])
    
    # Constraints: r_i + r_j <= distance between centers
    for i in range(n):
        for j in range(i + 1, n):
            d = np.linalg.norm(centers[i] - centers[j])
            # r_i + r_j <= d
            a = np.zeros(n)
            a[i] = 1.0
            a[j] = 1.0
            A_ub.append(a)
            b_ub.append(d)
    
    if len(A_ub) == 0:
        return np.full(n, 0.0)
    
    A_ub = np.array(A_ub)
    b_ub = np.array(b_ub)
    
    # Bounds: r_i >= 0
    bounds = [(0, None) for _ in range(n)]
    
    try:
        result = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
        if result.success:
            return np.maximum(result.x, 0.0)
    except:
        pass
    
    # Fallback: greedy shrinking
    radii = wall_dists.copy()
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    
    return np.maximum(radii, 0.0)
