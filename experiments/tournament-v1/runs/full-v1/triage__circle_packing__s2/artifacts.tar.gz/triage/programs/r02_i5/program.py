# EVOLVE-BLOCK-START
"""Penalty-method Adam optimisation (batched random restarts) + sparse trust-constr polish
over nearby pairs + LP radii."""
import time
import warnings
import numpy as np
from scipy.optimize import minimize, linprog, NonlinearConstraint, LinearConstraint, Bounds
from scipy.sparse import csr_matrix, coo_matrix


def _lp_radii(centers):
    n = len(centers)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    A = np.zeros((len(I), n))
    A[np.arange(len(I)), I] = 1.0
    A[np.arange(len(I)), J] = 1.0
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0.0)
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=list(zip(np.zeros(n), wall)), method="highs")
        if res.status == 0:
            return np.maximum(res.x, 0.0)
    except Exception:
        pass
    return _shrink_radii(centers, wall.copy())


def _shrink_radii(centers, radii):
    n = len(centers)
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    s = d / (radii[i] + radii[j])
                    radii[i] *= s
                    radii[j] *= s
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _valid(centers, radii, tol=1e-12):
    n = len(centers)
    if np.any(radii < 0):
        return False
    if np.any(centers[:, 0] - radii < -tol) or np.any(centers[:, 1] - radii < -tol):
        return False
    if np.any(centers[:, 0] + radii > 1 + tol) or np.any(centers[:, 1] + radii > 1 + tol):
        return False
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    return bool(np.all(radii[I] + radii[J] <= d + tol))


def _adam_batch(X, Y, R, iters, lr0, lr1, mu0, mu1):
    B, n = X.shape
    off = 1.0 - np.eye(n)[None]
    P = np.stack([X, Y, R])
    m = np.zeros_like(P)
    v = np.zeros_like(P)
    b1, b2, eps = 0.9, 0.999, 1e-8
    for t in range(iters):
        frac = t / max(iters - 1, 1)
        lr = lr0 * (lr1 / lr0) ** frac
        mu = mu0 * (mu1 / mu0) ** frac
        X, Y, R = P[0], P[1], P[2]
        dx = X[:, :, None] - X[:, None, :]
        dy = Y[:, :, None] - Y[:, None, :]
        d = np.sqrt(dx * dx + dy * dy + 1e-12)
        ov = np.maximum(R[:, :, None] + R[:, None, :] - d, 0.0) * off
        gR = 2 * ov.sum(2)
        coef = 2 * ov / d
        gX = -(coef * dx).sum(2)
        gY = -(coef * dy).sum(2)
        w = np.maximum(R - X, 0); gR += 2 * w; gX -= 2 * w
        w = np.maximum(R + X - 1, 0); gR += 2 * w; gX += 2 * w
        w = np.maximum(R - Y, 0); gR += 2 * w; gY -= 2 * w
        w = np.maximum(R + Y - 1, 0); gR += 2 * w; gY += 2 * w
        w = np.minimum(R, 0); gR += 2 * w
        g = mu * np.stack([gX, gY, gR])
        g[2] -= 1.0
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        mh = m / (1 - b1 ** (t + 1))
        vh = v / (1 - b2 ** (t + 1))
        P = P - lr * mh / (np.sqrt(vh) + eps)
        P[0] = np.clip(P[0], 0.0, 1.0)
        P[1] = np.clip(P[1], 0.0, 1.0)
    return P[0], P[1], P[2]


def _polish(centers, radii, cutoff=0.35, maxiter=800):
    """trust-constr polish with sparse constraints only for pairs within cutoff."""
    n = len(centers)
    N = 3 * n
    Ia, Ja = np.triu_indices(n, 1)
    d0 = np.linalg.norm(centers[Ia] - centers[Ja], axis=1)
    mask = d0 < cutoff
    I, J = Ia[mask], Ja[mask]
    m = len(I)
    z0 = np.concatenate([centers[:, 0], centers[:, 1], radii])
    ar = np.arange(m)

    gf = np.zeros(N)
    gf[2 * n:] = -1.0
    Hzero = csr_matrix((N, N))

    def f(z):
        return -np.sum(z[2 * n:])

    def fg(z):
        return gf

    def fh(z):
        return Hzero

    def geom(z):
        x, y = z[:n], z[n:2 * n]
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        d = np.sqrt(dx * dx + dy * dy + 1e-18)
        return dx, dy, d

    def cfun(z):
        r = z[2 * n:]
        _, _, d = geom(z)
        return d - r[I] - r[J]

    rows_j = np.concatenate([ar] * 6)
    cols_j = np.concatenate([I, J, n + I, n + J, 2 * n + I, 2 * n + J])

    def cjac(z):
        dx, dy, d = geom(z)
        ux, uy = dx / d, dy / d
        vals = np.concatenate([ux, -ux, uy, -uy, -np.ones(m), -np.ones(m)])
        return csr_matrix((vals, (rows_j, cols_j)), shape=(m, N))

    xi, xj, yi, yj = I, J, n + I, n + J
    hr = np.concatenate([xi, xj, xi, xj, yi, yj, yi, yj,
                         xi, yi, xj, yj, xi, yj, xj, yi])
    hc = np.concatenate([xi, xj, xj, xi, yi, yj, yj, yi,
                         yi, xi, yj, xj, yj, xi, yi, xj])

    def chess(z, v):
        dx, dy, d = geom(z)
        ux, uy = dx / d, dy / d
        h11 = v * (1 - ux * ux) / d
        h22 = v * (1 - uy * uy) / d
        h12 = -v * ux * uy / d
        vals = np.concatenate([h11, h11, -h11, -h11, h22, h22, -h22, -h22,
                               h12, h12, h12, h12, -h12, -h12, -h12, -h12])
        return coo_matrix((vals, (hr, hc)), shape=(N, N)).tocsr()

    # linear wall constraints
    an = np.arange(n)
    rows = np.concatenate([an, an, n + an, n + an, 2 * n + an, 2 * n + an, 3 * n + an, 3 * n + an])
    cols = np.concatenate([an, 2 * n + an, an, 2 * n + an, n + an, 2 * n + an, n + an, 2 * n + an])
    vals = np.concatenate([np.ones(n), -np.ones(n), np.ones(n), np.ones(n),
                           np.ones(n), -np.ones(n), np.ones(n), np.ones(n)])
    A = csr_matrix((vals, (rows, cols)), shape=(4 * n, N))
    lb = np.concatenate([np.zeros(n), np.full(n, -np.inf), np.zeros(n), np.full(n, -np.inf)])
    ub = np.concatenate([np.full(n, np.inf), np.ones(n), np.full(n, np.inf), np.ones(n)])

    cons = [LinearConstraint(A, lb, ub)]
    if m > 0:
        cons.append(NonlinearConstraint(cfun, 0.0, np.inf, jac=cjac, hess=chess))
    bounds = Bounds(np.zeros(N), np.concatenate([np.ones(2 * n), np.full(n, 0.5)]))
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            res = minimize(f, z0, jac=fg, hess=fh, method="trust-constr", bounds=bounds,
                           constraints=cons,
                           options={"maxiter": maxiter, "gtol": 1e-11, "xtol": 1e-13,
                                    "initial_tr_radius": 0.05, "verbose": 0})
        z = res.x
        if not np.all(np.isfinite(z)):
            z = z0
    except Exception:
        z = z0
    c = np.stack([z[:n], z[n:2 * n]], axis=1)
    c = np.clip(c, 0.0, 1.0)
    return c


def solve(n=26):
    t0 = time.time()
    budget = 200.0
    hard = 240.0
    rng = np.random.default_rng(12345)
    B = 64
    TOPK = 16
    best_c, best_r, best_s = None, None, -1.0

    def consider(c):
        nonlocal best_c, best_r, best_s
        r = _lp_radii(c)
        r = np.maximum(r - 1e-12, 0)
        if not _valid(c, r):
            r = _shrink_radii(c, r.copy())
        s = r.sum()
        if _valid(c, r) and s > best_s:
            best_c, best_r, best_s = c.copy(), r.copy(), s
        return s

    batch = 0
    while time.time() - t0 < budget:
        perturb = best_c is not None and batch % 2 == 1 and (time.time() - t0) > 0.35 * budget
        if perturb:
            X = np.repeat(best_c[None, :, 0], B, 0).copy()
            Y = np.repeat(best_c[None, :, 1], B, 0).copy()
            R = np.repeat(best_r[None], B, 0).copy() * 0.9
            sig = rng.uniform(0.005, 0.06, size=(B, 1))
            X += sig * rng.standard_normal((B, n))
            Y += sig * rng.standard_normal((B, n))
            for b in range(B):
                k = rng.integers(1, 4)
                idx = rng.choice(n, k, replace=False)
                X[b, idx] = rng.uniform(0.05, 0.95, k)
                Y[b, idx] = rng.uniform(0.05, 0.95, k)
                R[b, idx] = 0.03
            X = np.clip(X, 0.01, 0.99); Y = np.clip(Y, 0.01, 0.99)
            X, Y, R = _adam_batch(X, Y, R, 2500, 0.01, 2e-4, 100.0, 1e5)
        else:
            X = rng.uniform(0.05, 0.95, (B, n))
            Y = rng.uniform(0.05, 0.95, (B, n))
            R = rng.uniform(0.02, 0.1, (B, n))
            X, Y, R = _adam_batch(X, Y, R, 3500, 0.02, 2e-4, 10.0, 1e5)
        batch += 1
        scores = []
        lps = []
        for b in range(B):
            c = np.stack([X[b], Y[b]], 1)
            r = _lp_radii(c)
            lps.append(r)
            scores.append(r.sum())
        order = np.argsort(scores)[::-1]
        for b in order[:TOPK]:
            if time.time() - t0 > hard:
                break
            c = np.stack([X[b], Y[b]], 1)
            r = lps[b]
            c2 = _polish(c, r)
            consider(c2)
            consider(c)

    if best_c is None:
        c = rng.uniform(0.1, 0.9, (n, 2))
        return c, _shrink_radii(c, np.full(n, 0.01))
    return best_c, best_r
# EVOLVE-BLOCK-END
