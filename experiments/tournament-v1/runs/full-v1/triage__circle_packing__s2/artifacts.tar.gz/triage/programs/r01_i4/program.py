import numpy as np
from scipy.optimize import minimize
import warnings
warnings.filterwarnings('ignore')


def solve(n=26):
    """Return (centers, radii) for n disjoint circles inside the unit square,
    maximising the sum of the radii using iterated local search."""
    
    # Initialize with a good layout
    centers = [[0.5, 0.5]]
    centers += [[0.5 + 0.3 * np.cos(2 * np.pi * i / 8), 0.5 + 0.3 * np.sin(2 * np.pi * i / 8)] for i in range(8)]
    centers += [[0.5 + 0.7 * np.cos(2 * np.pi * i / 16), 0.5 + 0.7 * np.sin(2 * np.pi * i / 16)] for i in range(16)]
    centers += [[0.1 + 0.8 * np.random.rand(), 0.1 + 0.8 * np.random.rand()] for _ in range(n - len(centers))]
    centers = np.clip(np.array(centers[:n]), 0.01, 0.99)
    
    # Joint optimization
    best_centers, best_radii = joint_optimize(centers)
    best_score = np.sum(best_radii)
    
    # Iterated local search: remove-reinsert cycles
    max_iterations = 80
    for iteration in range(max_iterations):
        # Pick 1-3 smallest circles to remove
        num_to_remove = np.random.randint(1, min(4, len(best_centers)))
        radii = max_radii(best_centers)
        smallest_indices = np.argsort(radii)[:num_to_remove]
        
        # Remove smallest circles
        remaining_mask = np.ones(len(best_centers), dtype=bool)
        remaining_mask[smallest_indices] = False
        candidate_centers = best_centers[remaining_mask].copy()
        
        # For each removed circle, find best reinsertion location
        new_centers_list = []
        for removed_idx in smallest_indices:
            # Sample candidate positions (largest empty holes)
            best_pos = find_best_insertion_point(candidate_centers, num_samples=100)
            new_centers_list.append(best_pos)
        
        # Combine and optimize
        trial_centers = np.vstack([candidate_centers] + [np.array([pos]) for pos in new_centers_list])
        trial_centers = np.clip(trial_centers, 0.001, 0.999)
        
        trial_centers, trial_radii = joint_optimize(trial_centers)
        trial_score = np.sum(trial_radii)
        
        # Accept if better
        if trial_score > best_score:
            best_centers = trial_centers
            best_radii = trial_radii
            best_score = trial_score
    
    return best_centers, best_radii


def find_best_insertion_point(centers, num_samples=100):
    """Find position that maximizes distance to existing circles and walls."""
    best_pos = None
    best_distance = -1
    
    for _ in range(num_samples):
        # Random candidate point
        x, y = np.random.rand(2)
        
        # Distance to walls
        dist_to_wall = min(x, y, 1 - x, 1 - y)
        
        # Distance to nearest circle
        if len(centers) > 0:
            distances = np.linalg.norm(centers - np.array([x, y]), axis=1)
            dist_to_circle = np.min(distances)
        else:
            dist_to_circle = 1.0
        
        # Minimum distance to any obstacle
        min_dist = min(dist_to_wall, dist_to_circle)
        
        if min_dist > best_distance:
            best_distance = min_dist
            best_pos = np.array([x, y])
    
    # Also try grid sampling
    grid_size = 5
    for i in range(grid_size):
        for j in range(grid_size):
            x = (i + 0.5) / grid_size
            y = (j + 0.5) / grid_size
            
            dist_to_wall = min(x, y, 1 - x, 1 - y)
            if len(centers) > 0:
                distances = np.linalg.norm(centers - np.array([x, y]), axis=1)
                dist_to_circle = np.min(distances)
            else:
                dist_to_circle = 1.0
            
            min_dist = min(dist_to_wall, dist_to_circle)
            if min_dist > best_distance:
                best_distance = min_dist
                best_pos = np.array([x, y])
    
    if best_pos is None:
        best_pos = np.array([0.5, 0.5])
    
    return best_pos


def joint_optimize(centers):
    """Joint optimization of all circle centers using SLSQP."""
    n = len(centers)
    
    def objective(x):
        centers_flat = x.reshape(-1, 2)
        radii = max_radii(centers_flat)
        return -np.sum(radii)
    
    def constraint_builder():
        constraints = []
        
        # Pairwise non-overlap constraints
        for i in range(n):
            for j in range(i + 1, n):
                def make_constraint(idx_i, idx_j):
                    def constraint(x):
                        c = x.reshape(-1, 2)
                        d = np.linalg.norm(c[idx_i] - c[idx_j])
                        radii = max_radii(c)
                        return d - radii[idx_i] - radii[idx_j] - 0.001
                    return constraint
                constraints.append({'type': 'ineq', 'fun': make_constraint(i, j)})
        
        # Boundary constraints
        for i in range(n):
            def make_bound_x_min(idx):
                def constraint(x):
                    c = x.reshape(-1, 2)
                    radii = max_radii(c)
                    return c[idx, 0] - radii[idx] - 0.001
                return constraint
            def make_bound_x_max(idx):
                def constraint(x):
                    c = x.reshape(-1, 2)
                    radii = max_radii(c)
                    return 1 - c[idx, 0] - radii[idx] - 0.001
                return constraint
            def make_bound_y_min(idx):
                def constraint(x):
                    c = x.reshape(-1, 2)
                    radii = max_radii(c)
                    return c[idx, 1] - radii[idx] - 0.001
                return constraint
            def make_bound_y_max(idx):
                def constraint(x):
                    c = x.reshape(-1, 2)
                    radii = max_radii(c)
                    return 1 - c[idx, 1] - radii[idx] - 0.001
                return constraint
            
            constraints.append({'type': 'ineq', 'fun': make_bound_x_min(i)})
            constraints.append({'type': 'ineq', 'fun': make_bound_x_max(i)})
            constraints.append({'type': 'ineq', 'fun': make_bound_y_min(i)})
            constraints.append({'type': 'ineq', 'fun': make_bound_y_max(i)})
        
        return constraints
    
    x0 = centers.flatten()
    
    try:
        result = minimize(objective, x0, method='SLSQP', 
                         constraints=constraint_builder() if n <= 10 else [],
                         options={'maxiter': 100, 'ftol': 1e-6})
        optimized_centers = np.clip(result.x.reshape(-1, 2), 0.001, 0.999)
    except:
        optimized_centers = centers.copy()
    
    radii = max_radii(optimized_centers)
    return optimized_centers, radii


def max_radii(centers):
    """Largest radii for fixed centres: start from the wall distance, then shrink overlapping pairs."""
    n = len(centers)
    radii = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    scale = d / (radii[i] + radii[j])
                    radii[i] *= scale
                    radii[j] *= scale
                    changed = True
        if not changed:
            break
    
    return np.maximum(radii, 0.0)
