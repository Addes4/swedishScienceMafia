# EVOLVE-BLOCK-START
"""Penalty-method Adam optimisation (batched random restarts) + SLSQP polish + LP radii
+ final KKT Newton polish on the active set."""
import time
import numpy as np
from scipy.optimize import minimize, linprog


def _lp_radii(centers):
    n = len(centers)
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    A = np.zeros((len(I), n))
    A[np.arange(len(I)), I] = 1.0
    A[np.arange(len(I)), J] = 1.0
    wall = np.minimum.reduce([centers[:, 0], centers[:, 1], 1 - centers[:, 0], 1 - centers[:, 1]])
    wall = np.maximum(wall, 0.0)
    try:
        res = linprog(-np.ones(n), A_ub=A, b_ub=d, bounds=list(zip(np.zeros(n), wall)), method="highs")
        if res.status == 0:
            return np.maximum(res.x, 0.0)
    except Exception:
        pass
    return _shrink_radii(centers, wall.copy())


def _shrink_radii(centers, radii):
    n = len(centers)
    for _ in range(200):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(centers[i] - centers[j])
                if radii[i] + radii[j] > d:
                    s = d / (radii[i] + radii[j])
                    radii[i] *= s
                    radii[j] *= s
                    changed = True
        if not changed:
            break
    return np.maximum(radii, 0.0)


def _valid(centers, radii, tol=1e-12):
    n = len(centers)
    if np.any(radii < 0):
        return False
    if np.any(centers[:, 0] - radii < -tol) or np.any(centers[:, 1] - radii < -tol):
        return False
    if np.any(centers[:, 0] + radii > 1 + tol) or np.any(centers[:, 1] + radii > 1 + tol):
        return False
    I, J = np.triu_indices(n, 1)
    d = np.linalg.norm(centers[I] - centers[J], axis=1)
    return bool(np.all(radii[I] + radii[J] <= d + tol))


def _adam_batch(X, Y, R, iters, lr0, lr1, mu0, mu1):
    B, n = X.shape
    off = 1.0 - np.eye(n)[None]
    P = np.stack([X, Y, R])
    m = np.zeros_like(P)
    v = np.zeros_like(P)
    b1, b2, eps = 0.9, 0.999, 1e-8
    for t in range(iters):
        frac = t / max(iters - 1, 1)
        lr = lr0 * (lr1 / lr0) ** frac
        mu = mu0 * (mu1 / mu0) ** frac
        X, Y, R = P[0], P[1], P[2]
        dx = X[:, :, None] - X[:, None, :]
        dy = Y[:, :, None] - Y[:, None, :]
        d = np.sqrt(dx * dx + dy * dy + 1e-12)
        ov = np.maximum(R[:, :, None] + R[:, None, :] - d, 0.0) * off
        gR = 2 * ov.sum(2)
        coef = 2 * ov / d
        gX = -(coef * dx).sum(2)
        gY = -(coef * dy).sum(2)
        w = np.maximum(R - X, 0); gR += 2 * w; gX -= 2 * w
        w = np.maximum(R + X - 1, 0); gR += 2 * w; gX += 2 * w
        w = np.maximum(R - Y, 0); gR += 2 * w; gY -= 2 * w
        w = np.maximum(R + Y - 1, 0); gR += 2 * w; gY += 2 * w
        w = np.minimum(R, 0); gR += 2 * w
        g = mu * np.stack([gX, gY, gR])
        g[2] -= 1.0
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        mh = m / (1 - b1 ** (t + 1))
        vh = v / (1 - b2 ** (t + 1))
        P = P - lr * mh / (np.sqrt(vh) + eps)
        P[0] = np.clip(P[0], 0.0, 1.0)
        P[1] = np.clip(P[1], 0.0, 1.0)
    return P[0], P[1], P[2]


def _polish(centers, radii):
    n = len(centers)
    I, J = np.triu_indices(n, 1)
    npair = len(I)
    z0 = np.concatenate([centers[:, 0], centers[:, 1], radii])

    def f(z):
        return -np.sum(z[2 * n:])

    gf = np.zeros(3 * n)
    gf[2 * n:] = -1.0

    def fj(z):
        return gf

    def cons(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        d = np.sqrt((x[I] - x[J]) ** 2 + (y[I] - y[J]) ** 2 + 1e-18)
        return np.concatenate([d - r[I] - r[J], x - r, 1 - x - r, y - r, 1 - y - r])

    ar = np.arange(npair)
    an = np.arange(n)

    def cjac(z):
        x, y = z[:n], z[n:2 * n]
        dx = x[I] - x[J]
        dy = y[I] - y[J]
        d = np.sqrt(dx * dx + dy * dy + 1e-18)
        Jm = np.zeros((npair + 4 * n, 3 * n))
        Jm[ar, I] = dx / d
        Jm[ar, J] = -dx / d
        Jm[ar, n + I] = dy / d
        Jm[ar, n + J] = -dy / d
        Jm[ar, 2 * n + I] = -1
        Jm[ar, 2 * n + J] = -1
        o = npair
        Jm[o + an, an] = 1; Jm[o + an, 2 * n + an] = -1; o += n
        Jm[o + an, an] = -1; Jm[o + an, 2 * n + an] = -1; o += n
        Jm[o + an, n + an] = 1; Jm[o + an, 2 * n + an] = -1; o += n
        Jm[o + an, n + an] = -1; Jm[o + an, 2 * n + an] = -1
        return Jm

    bounds = [(0, 1)] * (2 * n) + [(0, 0.5)] * n
    try:
        res = minimize(f, z0, jac=fj, method="SLSQP", bounds=bounds,
                       constraints=[{"type": "ineq", "fun": cons, "jac": cjac}],
                       options={"maxiter": 400, "ftol": 1e-13})
        z = res.x
    except Exception:
        z = z0
    c = np.stack([z[:n], z[n:2 * n]], axis=1)
    c = np.clip(c, 0.0, 1.0)
    return c


def _kkt_polish(centers, radii, act_tol=1e-7, iters=40):
    """Newton's method on the KKT system restricted to the active set."""
    n = len(centers)
    x0, y0, r0 = centers[:, 0].copy(), centers[:, 1].copy(), radii.copy()
    I, J = np.triu_indices(n, 1)
    d0 = np.sqrt((x0[I] - x0[J]) ** 2 + (y0[I] - y0[J]) ** 2)
    pg = d0 - r0[I] - r0[J]
    pmask = pg < act_tol
    PI, PJ = I[pmask], J[pmask]
    walls = []  # (type, idx)
    wg = [x0 - r0, 1 - x0 - r0, y0 - r0, 1 - y0 - r0]
    for t in range(4):
        for i in np.nonzero(wg[t] < act_tol)[0]:
            walls.append((t, i))
    npc = len(PI)
    m = npc + len(walls)
    N = 3 * n
    if m == 0:
        return None

    def build(z):
        x, y, r = z[:n], z[n:2 * n], z[2 * n:]
        g = np.zeros(m)
        A = np.zeros((m, N))
        dx = x[PI] - x[PJ]
        dy = y[PI] - y[PJ]
        d = np.sqrt(dx * dx + dy * dy)
        g[:npc] = d - r[PI] - r[PJ]
        k = np.arange(npc)
        ux, uy = dx / d, dy / d
        A[k, PI] = ux; A[k, PJ] = -ux
        A[k, n + PI] = uy; A[k, n + PJ] = -uy
        A[k, 2 * n + PI] = -1; A[k, 2 * n + PJ] = -1
        for q, (t, i) in enumerate(walls):
            row = npc + q
            if t == 0:
                g[row] = x[i] - r[i]; A[row, i] = 1
            elif t == 1:
                g[row] = 1 - x[i] - r[i]; A[row, i] = -1
            elif t == 2:
                g[row] = y[i] - r[i]; A[row, n + i] = 1
            else:
                g[row] = 1 - y[i] - r[i]; A[row, n + i] = -1
            A[row, 2 * n + i] = -1
        return g, A, (ux, uy, d)

    def hess(geo, lam):
        ux, uy, d = geo
        H = np.zeros((N, N))
        for k in range(npc):
            l = lam[k]
            if l == 0:
                continue
            M = np.array([[1 - ux[k] ** 2, -ux[k] * uy[k]],
                          [-ux[k] * uy[k], 1 - uy[k] ** 2]]) * (l / d[k])
            ii = [PI[k], n + PI[k]]
            jj = [PJ[k], n + PJ[k]]
            H[np.ix_(ii, ii)] += M
            H[np.ix_(jj, jj)] += M
            H[np.ix_(ii, jj)] -= M
            H[np.ix_(jj, ii)] -= M
        return H

    gradf = np.zeros(N)
    gradf[2 * n:] = 1.0
    z = np.concatenate([x0, y0, r0])
    g, A, geo = build(z)
    lam = np.linalg.lstsq(A.T, -gradf, rcond=None)[0]

    def resid(z, lam):
        g, A, geo = build(z)
        return np.concatenate([gradf + A.T @ lam, g]), A, geo

    F, A, geo = resid(z, lam)
    fn = np.linalg.norm(F)
    for _ in range(iters):
        if fn < 1e-15:
            break
        H = hess(geo, lam)
        K = np.zeros((N + m, N + m))
        K[:N, :N] = H
        K[:N, N:] = A.T
        K[N:, :N] = A
        step = np.linalg.lstsq(K, -F, rcond=None)[0]
        dz, dl = step[:N], step[N:]
        a = 1.0
        improved = False
        for _ in range(20):
            zn = z + a * dz
            ln = lam + a * dl
            Fn, An, geon = resid(zn, ln)
            fnn = np.linalg.norm(Fn)
            if np.isfinite(fnn) and fnn < fn:
                improved = True
                break
            a *= 0.5
        if not improved:
            break
        z, lam, F, A, geo, fn = zn, ln, Fn, An, geon, fnn
    # sanity: don't move far
    if np.max(np.abs(z - np.concatenate([x0, y0, r0]))) > 1e-4:
        return None
    return z


def solve(n=26):
    t0 = time.time()
    budget = 200.0
    rng = np.random.default_rng(12345)
    B = 64
    best_c, best_r, best_s = None, None, -1.0

    def consider(c):
        nonlocal best_c, best_r, best_s
        r = _lp_radii(c)
        r = np.maximum(r - 1e-13, 0)
        if not _valid(c, r, tol=0.0):
            r = _shrink_radii(c, r.copy())
        s = r.sum()
        if _valid(c, r, tol=0.0) and s > best_s:
            best_c, best_r, best_s = c.copy(), r.copy(), s
        return s

    batch = 0
    while time.time() - t0 < budget:
        perturb = best_c is not None and batch % 2 == 1 and (time.time() - t0) > 0.35 * budget
        if perturb:
            X = np.repeat(best_c[None, :, 0], B, 0).copy()
            Y = np.repeat(best_c[None, :, 1], B, 0).copy()
            R = np.repeat(best_r[None], B, 0).copy() * 0.9
            sig = rng.uniform(0.005, 0.06, size=(B, 1))
            X += sig * rng.standard_normal((B, n))
            Y += sig * rng.standard_normal((B, n))
            for b in range(B):
                k = rng.integers(1, 4)
                idx = rng.choice(n, k, replace=False)
                X[b, idx] = rng.uniform(0.05, 0.95, k)
                Y[b, idx] = rng.uniform(0.05, 0.95, k)
                R[b, idx] = 0.03
            X = np.clip(X, 0.01, 0.99); Y = np.clip(Y, 0.01, 0.99)
            X, Y, R = _adam_batch(X, Y, R, 2500, 0.01, 2e-4, 100.0, 1e5)
        else:
            X = rng.uniform(0.05, 0.95, (B, n))
            Y = rng.uniform(0.05, 0.95, (B, n))
            R = rng.uniform(0.02, 0.1, (B, n))
            X, Y, R = _adam_batch(X, Y, R, 3500, 0.02, 2e-4, 10.0, 1e5)
        batch += 1
        scores = []
        for b in range(B):
            c = np.stack([X[b], Y[b]], 1)
            scores.append(_lp_radii(c).sum())
        order = np.argsort(scores)[::-1]
        for b in order[:4]:
            if time.time() - t0 > budget + 30:
                break
            c = np.stack([X[b], Y[b]], 1)
            r = _lp_radii(c)
            c2 = _polish(c, r)
            consider(c2)
            consider(c)

    if best_c is None:
        c = rng.uniform(0.1, 0.9, (n, 2))
        return c, _shrink_radii(c, np.full(n, 0.01))

    # Final high-precision KKT polish
    try:
        for tol_act in (1e-7, 1e-8, 1e-6):
            z = _kkt_polish(best_c, best_r, act_tol=tol_act)
            if z is None or not np.all(np.isfinite(z)):
                continue
            c = np.stack([z[:n], z[n:2 * n]], axis=1)
            r = np.maximum(z[2 * n:] - 1e-13, 0.0)
            if _valid(c, r, tol=0.0) and r.sum() > best_s:
                best_c, best_r, best_s = c.copy(), r.copy(), r.sum()
            else:
                r2 = np.maximum(_lp_radii(c) - 1e-13, 0.0)
                if _valid(c, r2, tol=0.0) and r2.sum() > best_s:
                    best_c, best_r, best_s = c.copy(), r2.copy(), r2.sum()
    except Exception:
        pass

    return best_c, best_r
# EVOLVE-BLOCK-END
