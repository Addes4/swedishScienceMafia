# EVOLVE-BLOCK-START
"""Simplex-shell construction: points x in Z>=0^d with m <= sum x <= n, base-(2n+1) embedding.
Candidates evaluated exactly with numpy within a time budget."""
import math
import time
import numpy as np


def _gen(d, n, m):
    B = 2 * n + 1
    vals = np.zeros(1, dtype=np.int64)
    sm = np.zeros(1, dtype=np.int64)
    for _ in range(d):
        nv = []
        ns = []
        for v in range(n + 1):
            mask = sm + v <= n
            if not mask.any():
                break
            nv.append(vals[mask] * B + v)
            ns.append(sm[mask] + v)
        vals = np.concatenate(nv)
        sm = np.concatenate(ns)
    keep = sm >= m
    return np.unique(vals[keep])


def _score(a):
    s = len(a)
    sums = np.unique((a[:, None] + a[None, :]).ravel()).size
    diffs = np.unique((a[:, None] - a[None, :]).ravel()).size
    if sums < 2:
        return -1.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / s) / 100


def _layer_count(d, n, m):
    # number of points with m <= sum <= n
    return sum(math.comb(s + d - 1, d - 1) for s in range(m, n + 1))


def solve():
    t0 = time.time()
    cands = []
    for d in range(2, 16):
        for n in range(1, 60):
            if n * (2 * n + 1) ** d > 10 ** 15:
                break
            if math.comb(n + d, d) > 300000:
                break
            if _layer_count(d, n, 0) <= 4000:
                cands.append((d, n, 0))
                continue
            # smallest m that fits
            m = 0
            while m <= n and _layer_count(d, n, m) > 4000:
                m += 1
            if m > n:
                continue
            for dm in range(0, 3):
                if m + dm <= n and _layer_count(d, n, m + dm) >= 20:
                    cands.append((d, n, m + dm))
    # baseline simplex candidates first (cheap), then shells
    cands.sort(key=lambda c: (c[2] != 0, -c[0]))
    best = None
    best_sc = -1.0
    for (d, n, m) in cands:
        if time.time() - t0 > 85:
            break
        cnt = _layer_count(d, n, m)
        if cnt > 4000 or cnt < 20:
            continue
        try:
            a = _gen(d, n, m)
        except MemoryError:
            continue
        if len(a) > 4000 or len(a) < 2:
            continue
        if time.time() - t0 + 4 * (len(a) / 4000.0) ** 2 > 100:
            continue
        sc = _score(a)
        if sc > best_sc:
            best_sc = sc
            best = a
    if best is None:
        return [0, 1, 3]
    return [int(x) for x in best]
# EVOLVE-BLOCK-END
