# EVOLVE-BLOCK-START
"""Simplex construction plus partial next layer to fill up to 4000 points, evaluated exactly."""
import math
import time
import numpy as np


def _formula(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            diffs += (math.factorial(d) // (math.factorial(i) * math.factorial(j) * math.factorial(d - i - j))
                      * math.comb(n, i) * math.comb(n, j))
    return size, sums, diffs


def _points(d, total, exact):
    res = []

    def rec(pos, rem, cur):
        if pos == d - 1:
            if exact:
                cur.append(rem)
                res.append(tuple(cur))
                cur.pop()
            else:
                for v in range(rem + 1):
                    cur.append(v)
                    res.append(tuple(cur))
                    cur.pop()
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(pos + 1, rem - v, cur)
            cur.pop()

    rec(0, total, [])
    return res


def _encode(pts, B):
    arr = np.array(pts, dtype=np.int64)
    d = arr.shape[1]
    pw = np.array([B ** (d - 1 - i) for i in range(d)], dtype=np.int64)
    return np.unique(arr @ pw)


def _eval(v):
    m = len(v)
    s = np.concatenate([v[i] + v[i:] for i in range(m)])
    ns = len(np.unique(s))
    del s
    df = np.concatenate([v[i] - v[:i] for i in range(1, m)])
    nd = 2 * len(np.unique(df)) + 1
    del df
    if ns < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / m) / 100


def solve():
    t0 = time.time()
    LIM = 4000
    cands = []
    for d in range(2, 60):
        for n in range(1, 200):
            size = math.comb(n + d, d)
            if size > LIM:
                break
            B = 2 * (n + 1) + 1
            if (n + 1) * B ** d > 10 ** 15 // 2:
                break
            s, su, di = _formula(d, n)
            if su < 2:
                continue
            sc = math.log(di) / math.log(su) + (1 - 1 / s) / 100
            # score of next simplex (potential)
            s2, su2, di2 = _formula(d, n + 1)
            sc2 = math.log(di2) / math.log(su2)
            cands.append((sc, sc2, d, n))
    cands.sort(reverse=True)
    base = cands[0]
    _, _, d, n = base
    B = 2 * (n + 1) + 1
    best_set = _encode(_points(d, n, False), B)
    best_sc = -1.0
    # exact eval of baseline
    best_sc = _eval(best_set)

    pot = sorted(cands, key=lambda c: -c[1])[:6]
    rng = np.random.RandomState(1)
    for _, _, d, n in pot:
        if time.time() - t0 > 85:
            break
        B = 2 * (n + 1) + 1
        base_pts = _points(d, n, False)
        k = LIM - len(base_pts)
        if k <= 0:
            continue
        layer = np.array(_points(d, n + 1, True), dtype=np.int64)
        if len(layer) == 0:
            continue
        k = min(k, len(layer))
        orders = []
        orders.append(np.lexsort(layer.T[::-1]))
        orders.append(np.lexsort(layer.T[::-1])[::-1])
        orders.append(rng.permutation(len(layer)))
        orders.append(np.argsort(-layer.max(axis=1), kind="stable"))
        orders.append(np.argsort((layer > 0).sum(axis=1), kind="stable"))
        for order in orders:
            if time.time() - t0 > 85:
                break
            chosen = layer[order[:k]]
            allp = np.vstack([np.array(base_pts, dtype=np.int64), chosen])
            v = _encode(allp, B)
            if len(v) > LIM or np.abs(v).max() > 10 ** 15:
                continue
            sc = _eval(v)
            if sc > best_sc:
                best_sc = sc
                best_set = v
    return [int(x) for x in best_set]
# EVOLVE-BLOCK-END
