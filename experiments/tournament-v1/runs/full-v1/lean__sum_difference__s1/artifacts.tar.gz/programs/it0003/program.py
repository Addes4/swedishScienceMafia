# EVOLVE-BLOCK-START
"""Simplex construction followed by exact incremental local search (add/remove points)."""
import math
import time
import random
import numpy as np


def _counts(d, n):
    size = math.comb(n + d, d)
    sums = math.comb(2 * n + d, d)
    diffs = 0
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            diffs += (math.factorial(d) // (math.factorial(i) * math.factorial(j) * math.factorial(d - i - j))
                      * math.comb(n, i) * math.comb(n, j))
    return size, sums, diffs


def _points(d, n):
    res = []

    def rec(pos, rem, cur):
        if pos == d:
            res.append(tuple(cur))
            return
        for v in range(rem + 1):
            cur.append(v)
            rec(pos + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def _obj(ns, nd, n):
    if ns < 2 or nd < 2 or n < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100


def solve():
    t0 = time.time()
    L = 2000
    best = None
    best_sc = -1.0
    for d in range(1, 30):
        for n in range(1, 100):
            size = math.comb(n + d, d)
            if size > L:
                break
            B = 2 * n + 3
            if float(B) ** d > 1e15:
                break
            size, sums, diffs = _counts(d, n)
            if sums < 2:
                continue
            sc = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
            if sc > best_sc:
                best_sc = sc
                best = (d, n)
    d, n = best
    B = 2 * n + 3

    def enc(p):
        v = 0
        for c in p:
            v = v * B + c
        return v

    start = sorted(enc(p) for p in _points(d, n))
    pool_all = [enc(p) for p in _points(d, n + 1)]
    sset = set(start)
    pool = [x for x in pool_all if x not in sset]
    inA = set(start)
    A = np.array(start, dtype=np.int64)

    # initial counts
    na = len(A)
    iu = np.triu_indices(na)
    M = np.add.outer(A, A)[iu]
    S, CS = np.unique(M, return_counts=True)
    CS = CS.astype(np.int64)
    Dm = np.subtract.outer(A, A).ravel()
    Dm = Dm[Dm != 0]
    D, CD = np.unique(Dm, return_counts=True)
    CD = CD.astype(np.int64)
    del M, Dm, iu
    ns = len(S)
    nd = len(D)
    cur = _obj(ns, nd, na)

    rng = random.Random(12345)
    limit = 100.0

    def lookup(arr, vals):
        idx = np.searchsorted(arr, vals)
        idxc = np.minimum(idx, len(arr) - 1)
        present = arr[idxc] == vals
        return idxc, present

    while time.time() - t0 < limit:
        na = len(A)
        do_add = rng.random() < 0.5 and len(pool) > 0 and na < 4000
        if not do_add and na <= 3:
            continue
        if do_add:
            pj = rng.randrange(len(pool))
            p = pool[pj]
            sv = np.concatenate((A + p, np.array([2 * p], dtype=np.int64)))
            idxs, pres_s = lookup(S, sv)
            new_s = int(np.count_nonzero((~pres_s) | (CS[idxs] == 0)))
            v = np.concatenate((p - A, A - p))
            u, c = np.unique(v, return_counts=True)
            idxd, pres_d = lookup(D, u)
            new_d = int(np.count_nonzero((~pres_d) | (CD[idxd] == 0)))
            ns2 = ns + new_s
            nd2 = nd + new_d
            f = _obj(ns2, nd2, na + 1)
            if f >= cur - 1e-15:
                # apply
                CS[idxs[pres_s]] += 1
                nv = np.sort(sv[~pres_s])
                if len(nv):
                    pos = np.searchsorted(S, nv)
                    S = np.insert(S, pos, nv)
                    CS = np.insert(CS, pos, 1)
                CD[idxd[pres_d]] += c[pres_d]
                nvd = ~pres_d
                if nvd.any():
                    nu = u[nvd]
                    nc = c[nvd]
                    pos = np.searchsorted(D, nu)
                    D = np.insert(D, pos, nu)
                    CD = np.insert(CD, pos, nc)
                A = np.append(A, p)
                inA.add(p)
                pool[pj] = pool[-1]
                pool.pop()
                ns, nd, cur = ns2, nd2, f
        else:
            i = rng.randrange(na)
            p = int(A[i])
            sv = A + p
            idxs = np.searchsorted(S, sv)
            lost_s = int(np.count_nonzero(CS[idxs] == 1))
            others = np.delete(A, i)
            v = np.concatenate((p - others, others - p))
            u, c = np.unique(v, return_counts=True)
            idxd = np.searchsorted(D, u)
            lost_d = int(np.count_nonzero(CD[idxd] == c))
            ns2 = ns - lost_s
            nd2 = nd - lost_d
            f = _obj(ns2, nd2, na - 1)
            if f > cur + 1e-15 or (f >= cur - 1e-15 and rng.random() < 0.3):
                CS[idxs] -= 1
                CD[idxd] -= c
                A = others
                inA.discard(p)
                pool.append(p)
                ns, nd, cur = ns2, nd2, f

    return sorted(int(x) for x in A.tolist())
# EVOLVE-BLOCK-END
