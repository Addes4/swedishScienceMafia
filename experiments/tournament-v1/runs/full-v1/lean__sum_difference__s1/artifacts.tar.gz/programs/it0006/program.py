# EVOLVE-BLOCK-START
"""Truncated simplex: A = {x in Z_{>=0}^d : sum x <= n, x_i <= c}, embedded into Z.
A+A = {y : y_i <= 2c, sum y <= 2n};  A-A = {z : |z_i|<=c, sum z+ <= n, sum z- <= n}."""
import math

DEG = 64
_cache = {}


def _poly(k, d):
    """coefficients of (1+x+...+x^k)^d truncated to degree DEG"""
    key = (k, d)
    if key in _cache:
        return _cache[key]
    if d == 0:
        p = [1] + [0] * DEG
    else:
        prev = _poly(k, d - 1)
        q = [0] * (DEG + 1)
        run = 0
        for s in range(DEG + 1):
            run += prev[s]
            q[s] = run
        p = [q[s] - (q[s - k - 1] if s - k - 1 >= 0 else 0) for s in range(DEG + 1)]
    _cache[key] = p
    return p


def _counts(d, n, c):
    P = _poly(c, d)
    size = sum(P[:n + 1])
    return size


def _full(d, n, c):
    size = sum(_poly(c, d)[:n + 1])
    S = sum(_poly(2 * c, d)[:2 * n + 1])
    cum = []
    for i in range(0, d + 1):
        if i > n:
            cum.append(0)
        else:
            Q = _poly(c - 1, i)
            cum.append(sum(Q[:n - i + 1]))
    D = 0
    for i in range(0, min(d, n) + 1):
        ci = math.comb(d, i) * cum[i]
        for j in range(0, min(d - i, n) + 1):
            D += ci * math.comb(d - i, j) * cum[j]
    return size, S, D


def _points(d, n, c):
    res = []

    def rec(pos, rem, cur):
        if pos == d:
            res.append(tuple(cur))
            return
        for v in range(min(rem, c) + 1):
            cur.append(v)
            rec(pos + 1, rem - v, cur)
            cur.pop()

    rec(0, n, [])
    return res


def solve():
    best = None
    best_sc = -1.0
    for c in range(1, 31):
        for d in range(1, 32):
            B = 2 * c + 1
            if c * (B ** d) > 10 ** 15:
                break
            for n in range(c, 31):
                size = _counts(d, n, c)
                if size > 4000:
                    break
                if size < 3:
                    continue
                size, S, D = _full(d, n, c)
                if S < 2:
                    continue
                sc = math.log(D) / math.log(S) + (1 - 1 / size) / 100
                if sc > best_sc:
                    best_sc = sc
                    best = (d, n, c)
    d, n, c = best
    B = 2 * c + 1
    out = []
    for p in _points(d, n, c):
        v = 0
        for x in p:
            v = v * B + x
        out.append(v)
    return sorted(set(out))
# EVOLVE-BLOCK-END
