# EVOLVE-BLOCK-START
"""Weighted simplex {x>=0 : sum w_i x_i <= n}, w_i in {1,2,3}, embedded into Z; exact numpy scoring."""
import math
import time
import random
import numpy as np


def _size(ds, n):
    cnt = [1] + [0] * n
    for w, d in zip((1, 2, 3), ds):
        for _ in range(d):
            new = [0] * (n + 1)
            for r in range(n + 1):
                if cnt[r]:
                    c = cnt[r]
                    k = 0
                    while r + k * w <= n:
                        new[r + k * w] += c
                        k += 1
            cnt = new
            if sum(cnt) > 4000:
                return 10 ** 9
    return sum(cnt)


def _build(ds, n):
    B = 2 * n + 1
    vals = np.zeros(1, dtype=np.int64)
    rem = np.full(1, n, dtype=np.int64)
    for w, d in zip((1, 2, 3), ds):
        for _ in range(d):
            nv = []
            nr = []
            for k in range(n // w + 1):
                m = rem >= k * w
                if not m.any():
                    break
                nv.append(vals[m] * B + k)
                nr.append(rem[m] - k * w)
            vals = np.concatenate(nv)
            rem = np.concatenate(nr)
    return np.unique(vals)


def _score(A):
    N = len(A)
    s = []
    df = []
    for i in range(N):
        s.append(A[i] + A[i:])
        if i + 1 < N:
            df.append(A[i + 1:] - A[i])
    ns = len(np.unique(np.concatenate(s)))
    nd = 2 * len(np.unique(np.concatenate(df))) + 1
    if ns < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / N) / 100


def solve():
    t0 = time.time()
    budget = 95.0
    cands = []
    for n in range(1, 13):
        B = 2 * n + 1
        for d3 in range(0, 9):
            for d2 in range(0, 16):
                for d1 in range(0, 30):
                    d = d1 + d2 + d3
                    if d == 0:
                        continue
                    if n * B ** d > 10 ** 15 // 2:
                        break
                    sz = _size((d1, d2, d3), n)
                    if sz > 4000:
                        break
                    if sz >= 1200:
                        cands.append((d1, d2, d3, n, sz))
    pure = [c for c in cands if c[1] == 0 and c[2] == 0]
    other = [c for c in cands if not (c[1] == 0 and c[2] == 0) and c[4] >= 2000]
    random.seed(1)
    random.shuffle(other)
    pure.sort(key=lambda c: -c[4])
    order = pure[:3] + other
    best = None
    best_sc = -1.0
    for (d1, d2, d3, n, sz) in order:
        if time.time() - t0 > budget - 1.5 * sz / 1000.0 - 1:
            break
        A = _build((d1, d2, d3), n)
        if len(A) > 4000 or np.abs(A).max() > 10 ** 15:
            continue
        sc = _score(A)
        if sc > best_sc:
            best_sc = sc
            best = A
    if best is None:
        return [0, 1, 3]
    return [int(x) for x in best]
# EVOLVE-BLOCK-END
