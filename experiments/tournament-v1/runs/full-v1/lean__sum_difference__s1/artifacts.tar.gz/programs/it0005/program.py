# EVOLVE-BLOCK-START
"""Simplex lattice points restricted to a random sublattice (c.x = 0 mod m), embedded in Z
with random large weights; candidates ranked by estimate, then verified exactly."""
import math
import time
import numpy as np


def _counts(d, n):
    sums = math.comb(2 * n + d, d)
    diffs = 0
    f = math.factorial
    for i in range(0, min(d, n) + 1):
        for j in range(0, min(d - i, n) + 1):
            diffs += (f(d) // (f(i) * f(j) * f(d - i - j)) * math.comb(n, i) * math.comb(n, j))
    return sums, diffs


def _gen(d, n):
    cur = np.zeros((1, 0), dtype=np.int8)
    s = np.zeros(1, dtype=np.int16)
    for _ in range(d):
        parts = []
        sp = []
        for v in range(n + 1):
            mask = s <= n - v
            c = cur[mask]
            col = np.full((c.shape[0], 1), v, dtype=np.int8)
            parts.append(np.hstack([c, col]))
            sp.append(s[mask] + v)
        cur = np.concatenate(parts)
        s = np.concatenate(sp)
    return cur


def _exact(A):
    A = np.unique(A)
    k = len(A)
    us = []
    ud = []
    step = 400
    for i in range(0, k, step):
        blk = A[i:i + step]
        us.append(np.unique((blk[:, None] + A[None, :]).ravel()))
        df = (blk[:, None] - A[None, :]).ravel()
        ud.append(np.unique(df[df > 0]))
    S = np.unique(np.concatenate(us)).size
    D = 2 * np.unique(np.concatenate(ud)).size + 1
    if S < 2:
        return -1.0
    return math.log(D) / math.log(S) + (1 - 1 / k) / 100


def _est(d, n, m):
    N = math.comb(n + d, d)
    Sf, Df = _counts(d, n)
    k = N / m
    if k < 50:
        return -1.0
    K = Sf / m
    P = k * (k + 1) / 2
    S = K * (1 - math.exp(-P / K))
    K2 = max(Df / m / 2.0, 1.0)
    P2 = k * (k - 1) / 2
    D = 1 + 2 * K2 * (1 - math.exp(-P2 / K2))
    if S < 2 or D < 2:
        return -1.0
    return math.log(D) / math.log(S) + (1 - 1 / k) / 100


def _build(d, n, m, rng):
    pts = _gen(d, n).astype(np.int64)
    if m > 1:
        best = None
        for _ in range(6):
            c = rng.integers(0, m, size=d)
            mask = (pts @ c) % m == 0
            cnt = int(mask.sum())
            if best is None or abs(cnt - 3500) < abs(best[1] - 3500):
                best = (mask, cnt)
            if 2500 <= cnt <= 4000:
                break
        pts = pts[best[0]]
    if len(pts) > 4000:
        idx = rng.choice(len(pts), 4000, replace=False)
        pts = pts[idx]
    hi = 10 ** 15 // (n + 1) - 1
    w = rng.integers(1, hi, size=d, dtype=np.int64)
    return np.unique(pts @ w)


def solve():
    t0 = time.time()
    rng = np.random.default_rng(12345)
    cands = {}
    for d in range(2, 26):
        for n in range(1, 13):
            N = math.comb(n + d, d)
            if N > 400000:
                break
            for t in (1500, 2500, 3700):
                m = max(1, -(-N // t))
                if m == 1 and N > 4000:
                    continue
                if (d, n, m) in cands:
                    continue
                cands[(d, n, m)] = _est(d, n, m)
    ranked = sorted(cands.items(), key=lambda kv: -kv[1])
    todo = [k for k, _ in ranked[:12]]
    m1 = [k for k, _ in ranked if k[2] == 1]
    if m1 and m1[0] not in todo:
        todo.append(m1[0])
    best_set = None
    best_sc = -1.0
    # baseline first (guaranteed valid)
    order = ([m1[0]] if m1 else []) + [k for k in todo if not (m1 and k == m1[0])]
    for (d, n, m) in order:
        if time.time() - t0 > 85 and best_set is not None:
            break
        try:
            A = _build(d, n, m, rng)
            if len(A) < 2 or len(A) > 4000:
                continue
            sc = _exact(A)
        except Exception:
            continue
        if sc > best_sc:
            best_sc = sc
            best_set = A
    if best_set is None:
        return [0, 1, 3]
    return [int(x) for x in best_set]
# EVOLVE-BLOCK-END
