# EVOLVE-BLOCK-START
"""Hybrid fit: prefer tight fits, avoid tiny leftover fragments."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = (bins - item).astype(np.float64)
    # Primary: tightest fit (smallest leftover wins).
    score = -leftover
    # Penalize leaving a small non-zero remnant (a likely-unusable fragment).
    frag = (leftover > 0.0) & (leftover < 10.0)
    score = score - np.where(frag, (10.0 - leftover) * 0.5, 0.0)
    return score
# EVOLVE-BLOCK-END
