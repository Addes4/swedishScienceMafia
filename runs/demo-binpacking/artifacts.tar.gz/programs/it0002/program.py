# EVOLVE-BLOCK-START
"""Best-fit with adaptive residual shaping.

Track the empirical distribution of item sizes seen so far. When choosing a bin,
slightly prefer placements whose leftover capacity can likely be filled by a
future item (i.e. leftover close to an observed item size or 0). This keeps the
primary best-fit ordering while reducing fragmentation into useless gaps.
"""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    # Update empirical size statistics.
    counts = _state["counts"]
    counts[item] += 1.0
    _state["n"] += 1.0
    n = _state["n"]

    remainder = bins - item  # leftover after placing item; >= 0 for shown bins

    # Estimate probability that a future item exactly matches each remainder.
    # Use smoothed empirical probabilities over observed sizes.
    probs = counts / n
    exact = probs  # probs[r] for r in 0..100

    # Base: best fit (prefer tightest, i.e. smallest remainder).
    score = -remainder.astype(np.float64)

    # Shaping: reward remainders that are likely fillable (0 or common sizes),
    # scaled small so it only breaks near-ties.
    r = remainder
    bonus = exact[np.clip(r, 0, 100)]
    # Extra small nudge to favor exactly-filled bins.
    bonus = bonus + 0.05 * (r == 0)
    score = score + 0.5 * bonus

    return score
# EVOLVE-BLOCK-END
