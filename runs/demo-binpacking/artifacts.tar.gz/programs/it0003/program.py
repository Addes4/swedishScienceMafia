# EVOLVE-BLOCK-START
"""Harmonic-ish best fit: prefer tight fits but avoid leaving small unusable gaps."""
import numpy as np


def priority(item, bins):
    """Rank bins; highest score wins (ties to earliest bin).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of fitting bins, in bin order.
    """
    rem = bins - item  # leftover space if item goes here

    # Concave (sqrt) reward for leftover space discourages creating tiny
    # fragments, since sqrt makes big remainders relatively more attractive
    # than the linear best-fit rule would. Ties broken by smaller leftover
    # (i.e. tighter fit) via the -rem term.
    return np.sqrt(rem.astype(np.float64)) - 0.01 * rem
# EVOLVE-BLOCK-END
