# EVOLVE-BLOCK-START
"""Bounded best-fit: tightest fit that either empties the bin or leaves room for a similar item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Prefer tight fits, but penalize small unusable leftovers (avoid fragments).
    # Bonus for leaving a remainder >= item (still usable) or exactly 0.
    usable = (leftover >= item) | (leftover == 0)
    return -leftover + usable * 0.5
# EVOLVE-BLOCK-END
