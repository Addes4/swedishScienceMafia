# EVOLVE-BLOCK-START
"""Best-fit with a slight preference for exact fits and larger usable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    left = bins - item  # remaining capacity after placing the item (>= 0)
    # Base: best fit (prefer smallest leftover).
    score = -left.astype(np.float64)
    # Small bonus for an exact fit (no wasted residual).
    score += 0.5 * (left == 0)
    # Mild tie-breaker: prefer bins leaving a larger residual over tiny fragments.
    score += 0.01 * left
    return score
# EVOLVE-BLOCK-END
