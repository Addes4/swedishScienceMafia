# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for leaving awkwardly small remainders."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    score = -rem.astype(np.float64)
    # Penalize remainders that are small but nonzero (hard to reuse),
    # leaving a gentle preference for perfectly filled bins and emptier bins.
    score -= np.where((rem > 0) & (rem <= 10), 1.0, 0.0)
    # Slightly prefer reusing already-open bins over brand-new ones when close.
    score -= np.where(bins == 100, 0.0, 0.0)
    return score
# EVOLVE-BLOCK-END
