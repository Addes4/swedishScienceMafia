# EVOLVE-BLOCK-START
"""Capped best-fit: best-fit only among bins whose remaining capacity is small enough."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Capped best-fit: among bins that "cap" the leftover (i.e. tightest fits) pick the
    # tightest one. Cap = leftover should be small relative to item size so that big
    # empty bins (100) are parked for future large items.
    cap = item // 2 + 10
    leftover = bins - item
    # Prefer bins whose leftover is <= cap; those get best-fit score. Otherwise demote.
    within = leftover <= cap
    score = -(bins - item).astype(np.float64)
    score = np.where(within, score, score - 1e6 + leftover * 1e-3)
    return score
# EVOLVE-BLOCK-END
